package com.secretvault.file.privary.activity;

import android.Manifest;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.secretvault.file.privary.CustomProgress;
import com.secretvault.file.privary.R;
import com.secretvault.file.privary.ads.AdmobAdManager;
import com.secretvault.file.privary.ads.AdEventListener;
import com.secretvault.file.privary.db.DatabaseHelper;
import com.secretvault.file.privary.db.FileItem;
import com.secretvault.file.privary.utils.Connectivity;
import com.secretvault.file.privary.utils.GoogleDriveHelper;
import com.secretvault.file.privary.utils.PreferenceHelper;
import com.secretvault.file.privary.utils.StorageUtil;
import com.secretvault.file.privary.utils.Utils;
import com.secretvault.file.privary.views.CustomTextView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException;
import com.google.api.client.googleapis.media.MediaHttpDownloader;
import com.google.api.client.googleapis.media.MediaHttpDownloaderProgressListener;
import com.google.api.client.googleapis.media.MediaHttpUploader;
import com.google.api.client.googleapis.media.MediaHttpUploaderProgressListener;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.About;
import com.google.api.services.drive.model.File;
import com.jiajunhui.xapp.medialoader.bean.PhotoItem;
import com.jiajunhui.xapp.medialoader.bean.VideoItem;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class CloudBackupActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {

    static final int REQUEST_AUTHORIZATION = 2;
    private static final String TAG = "CloudBackupActivity";
    private static final int REQUEST_ACCOUNT_PICKER = 0;
    public Drive service;
    public String photoDirID = "";
    public String videoDirID = "";
    public String fileDirID = "";
    String btnClick = "";
    Context mContext;

    CustomTextView tv_driveused;
    ProgressBar progressBar;
    DatabaseHelper databaseHelper;
    CustomProgress customProgress;

    LinearLayout lin_backup;
    private int GET_ACCOUNTS_PERMISSION = 0;
    private GoogleAccountCredential credential;
    private ActionBar actionBar;
    CustomTextView tv_backup;

    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_backup);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        mContext = CloudBackupActivity.this;
        databaseHelper = new DatabaseHelper(mContext);
        Init();
    }

    private void Init() {
        customProgress = CustomProgress.getInstance();
        lin_backup = findViewById(R.id.lin_backup);
        tv_driveused = findViewById(R.id.tv_driveused);
        progressBar = findViewById(R.id.progressBar);
        tv_backup = findViewById(R.id.tv_backup);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            //actionBar.setDisplayHomeAsUpEnabled(true);
            //actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            //actionBar.setDisplayShowTitleEnabled(true);

            CustomTextView tv_tital = findViewById(R.id.tv_tital);
            tv_tital.setText(R.string.tital_cloud_backup);
            ImageView iv_back = findViewById(R.id.iv_back);
            iv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
            findViewById(R.id.iv_option).setVisibility(View.GONE);

        }
        connectToServer();
        lin_backup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnClick = "export";
                DialogBakup();
            }
        });

        findViewById(R.id.lin_restore).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnClick = "import";
                DialogRestore();

            }
        });

        FrameLayout frameLayout = findViewById(R.id.fl_adplaceholder);

        AdmobAdManager admobAdManager = new AdmobAdManager(mContext);
        admobAdManager.loadNativeAd(mContext, getString(R.string.NATIVE_ID), frameLayout, true ,new AdEventListener() {
            @Override
            public void onAdLoaded() {
                frameLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {

            }

            @Override
            public void onLoadError(String errorCode) {
                frameLayout.setVisibility(View.GONE);
            }
        });

    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        Log.e(TAG, "CloudBackupActivity:onUserLeaveHint");
    }
    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        Log.e(TAG, "CloudBackupActivity:onUserInteraction");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.e(TAG, "CloudBackupActivity:onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.e(TAG, "CloudBackupActivity:onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.e(TAG, "CloudBackupActivity:onStop");
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Log.e(TAG, "CloudBackupActivity:onKeyDown:"+keyCode);
        if(keyCode == KeyEvent.KEYCODE_HOME)
        {
            Log.e(TAG, "CloudBackupActivity:Home button pressed!");
        }
        return super.onKeyDown(keyCode, event);
    }

    public void DialogBakup() {
        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_donot_bk, false)) {
            String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");

            if (accountName.length() > 0) {
                Log.e(TAG, "ac name accountName " + accountName);
                if (isValidEmail(accountName)) {
                    if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_photos_bk, false)) {
                        BakupPhotosTask g = new BakupPhotosTask();
                        g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    } else {
                        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_videos_bk, false)) {
                            BakupVideoTask g = new BakupVideoTask();
                            g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                        } else {
                            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_files_bk, false)) {
                                BakupFilesTask g = new BakupFilesTask();
                                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                            }
                        }
                    }
                } else
                    pickAccount();
            } else
                pickAccount();

        } else {

            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogTheme);
            View dialogView = View.inflate(this, R.layout.layout_dialog_backup, null);
            MaterialButton button_negative = dialogView.findViewById(R.id.button_negative);
            MaterialButton button_positive = dialogView.findViewById(R.id.button_positive);
            TextView title = dialogView.findViewById(R.id.textView_title);
            TextView textView_message = dialogView.findViewById(R.id.textView_message);

            CheckBox chk_photos = dialogView.findViewById(R.id.chk_photos);
            CheckBox chk_videos = dialogView.findViewById(R.id.chk_videos);
            CheckBox chk_files = dialogView.findViewById(R.id.chk_files);
            CheckBox chk_donot = dialogView.findViewById(R.id.chk_donot);
            title.setText("Select Content");
            textView_message.setText("Select content you want to upload backup.");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                button_negative.setIcon(getDrawable(R.drawable.ic_close_black_24dp));
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                button_positive.setIcon(getDrawable(R.drawable.ic_backup_black_24dp));
            }
            button_negative.setText("Cancel");
            button_positive.setText("Backup");
            button_negative.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bottomSheetDialog.dismiss();
                }
            });

            button_positive.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_photos_bk, chk_photos.isChecked());
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_videos_bk, chk_videos.isChecked());
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_files_bk, chk_files.isChecked());

                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_donot_bk, chk_donot.isChecked());
                    String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
                    if (accountName.length() > 0) {
                        Log.e(TAG, "ac name accountName " + accountName);
                        if (isValidEmail(accountName)) {
                            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_photos_bk, false)) {
                                BakupPhotosTask g = new BakupPhotosTask();
                                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                            } else {
                                if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_videos_bk, false)) {
                                    BakupVideoTask g = new BakupVideoTask();
                                    g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                                } else {
                                    if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_files_bk, false)) {
                                        BakupFilesTask g = new BakupFilesTask();
                                        g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Please select any option", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        } else
                            pickAccount();
                    } else
                        pickAccount();
                    bottomSheetDialog.dismiss();
                }
            });
            bottomSheetDialog.setContentView(dialogView);
            bottomSheetDialog.show();
        }
    }

    public void DialogRestore() {
        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_donot_rs, false)) {
            String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
            if (accountName.length() > 0) {
                Log.e(TAG, "ac name accountName " + accountName);
                if (isValidEmail(accountName)) {
                    if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_photos_rs, false)) {
                        BakupPhotosTask g = new BakupPhotosTask();
                        g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    } else {
                        if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_videos_rs, false)) {
                            BakupVideoTask g = new BakupVideoTask();
                            g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                        } else {
                            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_files_rs, false)) {
                                BakupFilesTask g = new BakupFilesTask();
                                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                            }
                        }
                    }
                } else
                    pickAccount();
            } else
                pickAccount();

        } else {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.BottomSheetDialogTheme);
            View dialogView = View.inflate(this, R.layout.layout_dialog_backup, null);
            MaterialButton button_negative = dialogView.findViewById(R.id.button_negative);
            MaterialButton button_positive = dialogView.findViewById(R.id.button_positive);
            TextView title = dialogView.findViewById(R.id.textView_title);
            TextView textView_message = dialogView.findViewById(R.id.textView_message);

            CheckBox chk_photos = dialogView.findViewById(R.id.chk_photos);
            CheckBox chk_videos = dialogView.findViewById(R.id.chk_videos);
            CheckBox chk_files = dialogView.findViewById(R.id.chk_files);
            CheckBox chk_donot = dialogView.findViewById(R.id.chk_donot);

            title.setText("Select Content");
            textView_message.setText("Select content you want to restore backup.");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                button_negative.setIcon(getDrawable(R.drawable.ic_close_black_24dp));
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                button_positive.setIcon(getDrawable(R.drawable.ic_cloud_download_black_24dp));
            }
            button_negative.setText("Cancel");
            button_positive.setText("Restore");
            button_negative.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bottomSheetDialog.dismiss();
                }
            });

            button_positive.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_photos_rs, chk_photos.isChecked());
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_videos_rs, chk_videos.isChecked());
                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_files_rs, chk_files.isChecked());

                    PreferenceHelper.setBooleanValue(mContext, PreferenceHelper.prf_chk_donot_rs, chk_donot.isChecked());

                    String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
                    if (accountName.length() > 0) {
                        Log.e(TAG, "ac name accountName " + accountName);
                        if (isValidEmail(accountName)) {
                            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_photos_rs, false)) {
                                RestorePhotoTask g = new RestorePhotoTask();
                                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                            } else {
                                if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_videos_rs, false)) {
                                    RestoreVideoTask g = new RestoreVideoTask();
                                    g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                                } else {
                                    if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_files_rs, false)) {
                                        RestoreFileTask g = new RestoreFileTask();
                                        g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Please select any option", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }

                        } else
                            pickAccount();
                    } else
                        pickAccount();

                    bottomSheetDialog.dismiss();
                }
            });
            bottomSheetDialog.setContentView(dialogView);
            bottomSheetDialog.show();
        }
    }

    private void connectToServer() {
        if (checkWriteExternalPermission()) {
            googleLogIn();
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(CloudBackupActivity.this, Manifest.permission.GET_ACCOUNTS)) {
                new AlertDialog.Builder(mContext)
                        .setTitle("Permission Needed")
                        .setMessage("App needs permission to read your accounts ... etc")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(CloudBackupActivity.this, new String[]{Manifest.permission.GET_ACCOUNTS}, GET_ACCOUNTS_PERMISSION);
                            }
                        })
                        .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .create().show();
            } else {
                ActivityCompat.requestPermissions(CloudBackupActivity.this, new String[]{Manifest.permission.GET_ACCOUNTS}, GET_ACCOUNTS_PERMISSION);
            }
        }
    }

    private boolean checkWriteExternalPermission() {
        String permission = android.Manifest.permission.GET_ACCOUNTS;
        int res = checkCallingOrSelfPermission(permission);
        return (res == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Init();
            }
        }
    }

    private void googleLogIn() {
        if (Connectivity.isConnectedFast(mContext)) {
            credential = GoogleAccountCredential.usingOAuth2(this, Arrays.asList(DriveScopes.DRIVE_FILE));
            String accountName = PreferenceHelper.getValue(mContext, PreferenceHelper.AccountName, "");
            if (accountName.length() > 0) {
                Log.e(TAG, "ac name accountName " + accountName);
                if (isValidEmail(accountName)) {
                    credential.setSelectedAccountName(accountName);
                    service = getDriveService(credential);
                    tv_backup.setText("Backup to : " + accountName);
                    if (service != null) {
                        Log.e(TAG, "googleLogIn: service not null");
                        CreateDirectoryTask g = new CreateDirectoryTask();
                        g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    } else {
                        Log.e(TAG, "googleLogIn: service null");
                    }
                } else
                    pickAccount();

            } else {
                pickAccount();
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.internet_title));
            builder.setMessage(getString(R.string.internet_message));
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(getApplicationContext(), "Please start internet and restart app.", Toast.LENGTH_LONG).show();
                    finish();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }
    }

    private void pickAccount() {
        startActivityForResult(credential.newChooseAccountIntent(), REQUEST_ACCOUNT_PICKER);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            switch (requestCode) {
                case REQUEST_ACCOUNT_PICKER:
                    if (resultCode == RESULT_OK && data != null && data.getExtras() != null) {
                        String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                        PreferenceHelper.setValue(mContext, PreferenceHelper.AccountName, accountName);
                        if (accountName != null) {

                            credential.setSelectedAccountName(accountName);
                            Log.e(TAG, "googleLogIn:AC " + credential.getSelectedAccountName());
                            tv_backup.setText("Backup to : " + accountName);
                            service = getDriveService(credential);
                            CreateDirectoryTask ga = new CreateDirectoryTask();
                            ga.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                            if (btnClick.equals("export")) {
                                BakupPhotosTask g = new BakupPhotosTask();
                                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                            } else if (btnClick.equals("import")) {
                                RestorePhotoTask g = new RestorePhotoTask();
                                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                            }
                        }
                    }
                    break;
                case REQUEST_AUTHORIZATION:
                    if (resultCode == Activity.RESULT_OK) {
                        if (btnClick.equals("export")) {
                            BakupPhotosTask g = new BakupPhotosTask();
                            g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                        } else if (btnClick.equals("import")) {
                            RestorePhotoTask g = new RestorePhotoTask();
                            g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                        }
                    } else {
                        pickAccount();
                    }
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    private Drive getDriveService(GoogleAccountCredential credential) {
        return new Drive.Builder(AndroidHttp.newCompatibleTransport(), new GsonFactory(), credential).setApplicationName(getString(R.string.app_name)).build();
    }

    public class updateProgressTask extends AsyncTask<Void, Void, Void> {
        String mimeType = "*/*";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            customProgress = CustomProgress.getInstance();
            customProgress.showProgress(CloudBackupActivity.this, "Update Data", "Please wait...");
        }

        @SuppressLint("WrongThread")
        @Override
        protected Void doInBackground(Void... voids) {
            printAbout(service);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

             if (customProgress != null && customProgress.isShowDialog())
                    customProgress.hideProgress();

//                Toast.makeText(mContext, "Backup upload successfully", Toast.LENGTH_SHORT).show();



        }
    }

    private void printAbout(Drive service1) {
        try {
            About about = service.about().get().execute();
            File Mainfolder = GoogleDriveHelper.getOrCreateFolder(service, getResources().getString(R.string.my_v_dri), about.getRootFolderId());
            File Mainfolder1 = GoogleDriveHelper.getOrCreateFolder(service, getResources().getString(R.string.photo_dri), Mainfolder.getId());
            File Mainfolder2 = GoogleDriveHelper.getOrCreateFolder(service, getResources().getString(R.string.video_dri), Mainfolder.getId());
            File Mainfolder3 = GoogleDriveHelper.getOrCreateFolder(service, getResources().getString(R.string.file_dri), Mainfolder.getId());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    double useSp = about.getQuotaBytesUsed() * 100;
                    double total = about.getQuotaBytesTotal();
                    double percentAvail = useSp / total;
                    Log.e(TAG, "run:== " + percentAvail + "  >?  " + Math.nextUp(percentAvail));
                    if (percentAvail < 1)
                        progressBar.setProgress(1);
                    else
                        progressBar.setProgress((int) Math.nextUp(percentAvail));
                    tv_driveused.setText(StorageUtil.convertStorage(about.getQuotaBytesUsed()) + "/" + StorageUtil.convertStorage(about.getQuotaBytesTotal()) + " used");
                }
            });
            photoDirID = Mainfolder1.getId();
            videoDirID = Mainfolder2.getId();
            fileDirID = Mainfolder3.getId();
            // TOTAL - USED = FREE SPACE
        } catch (UserRecoverableAuthIOException e) {
            Log.e(TAG,"UserRecoverableAuthIOException:"+e);
            startActivityForResult(e.getIntent(), REQUEST_AUTHORIZATION);
        } catch (IOException e) {
            Log.e(TAG,"IOException:"+e);
            runOnUiThread(() -> Toast.makeText(mContext, getResources().getString(R.string.lbl_slow_connection), Toast.LENGTH_LONG).show());
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                setResult(RESULT_OK);
                onBackPressed();
                return true;
            }
            default: {
                return false;
            }
        }
    }

    public class CreateDirectoryTask extends AsyncTask<Void, Void, Void> {
        ProgressDialog pd2;

        public CreateDirectoryTask() {
            pd2 = new ProgressDialog(CloudBackupActivity.this);
            pd2.setTitle("Connectd to server");
            pd2.setMessage("Please wait....");
            pd2.setCancelable(false);
            pd2.setIndeterminate(true);
            pd2.show();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            Log.e(TAG, "doInBackground:111 ");

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.e(TAG, "doInBackground:===22 ");
            pd2.dismiss();
            new updateProgressTask().execute();
        }
    }

    public class BakupPhotosTask extends AsyncTask<Void, Void, Void> {
        String mimeType = "*/*";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            customProgress = CustomProgress.getInstance();
            customProgress.showProgress(CloudBackupActivity.this, "Backup", "Please wait...");
        }

        @SuppressLint("WrongThread")
        @Override
        protected Void doInBackground(Void... voids) {
            if (photoDirID.equalsIgnoreCase("")) {
                /*CreateDirectoryTask gge = new CreateDirectoryTask();
                gge.execute();*/
            } else {
                ArrayList<PhotoItem> data = databaseHelper.getBackupImages();
                for (int i = 0; i < data.size(); i++) {
//                Log.e(TAG, "onClick: " + data.get(i).getDisplayName());
                    java.io.File uploadfile = new java.io.File(data.get(i).getNewPath());
                    if (uploadfile.exists()) {

                        File file = GoogleDriveHelper.createOrUpdateFileFromFile(service, uploadfile.getAbsolutePath(), photoDirID, mimeType);
                        Log.e(TAG, "doInBackground: werew " + i + " >> " + file.getId());
                        int dd = databaseHelper.updateImgCloudID(data.get(i).getId(), file.getId());
                        Log.e(TAG, "doInBackground: update " + dd);

                    }
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_videos_bk, false)) {
                if (videoDirID.equalsIgnoreCase("")) {
                    CreateDirectoryTask gge = new CreateDirectoryTask();
                    gge.execute();
                } else {
                    BakupVideoTask g = new BakupVideoTask();
                    g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                }

            } else {

                if (customProgress != null && customProgress.isShowDialog())
                    customProgress.hideProgress();

                new updateProgressTask().execute();
                Toast.makeText(mContext, "Backup upload successfully", Toast.LENGTH_SHORT).show();

            }

        }
    }

    public class BakupVideoTask extends AsyncTask<Void, Void, Void> {
        String mimeType = "*/*";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (customProgress != null && !customProgress.isShowDialog()) {
                customProgress = CustomProgress.getInstance();
                customProgress.showProgress(CloudBackupActivity.this, "Backup", "Please wait...");
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            ArrayList<VideoItem> data = databaseHelper.getBackupVideos();
            for (int i = 0; i < data.size(); i++) {
                java.io.File uploadfile = new java.io.File(data.get(i).getNewPath());
                if (uploadfile.exists()) {
                    File file = GoogleDriveHelper.createOrUpdateFileFromFile(service, uploadfile.getAbsolutePath(), videoDirID, mimeType);
                    Log.e(TAG, "doInBackground: werew " + i + " >> " + file.getId());
                    int dd = databaseHelper.updateVideoCloudID(data.get(i).getId(), file.getId());
                    Log.e(TAG, "doInBackground: update " + dd);
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_files_bk, false)) {
                BakupFilesTask g = new BakupFilesTask();
                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            } else {

                if (customProgress != null && customProgress.isShowDialog())
                    customProgress.hideProgress();
                new updateProgressTask().execute();
                Toast.makeText(mContext, "Backup upload successfully", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public class BakupFilesTask extends AsyncTask<Void, Void, Void> {
        String mimeType = "*/*";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (customProgress != null && !customProgress.isShowDialog()) {
                customProgress = CustomProgress.getInstance();
                customProgress.showProgress(CloudBackupActivity.this, "Backup", "Please wait...");
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            ArrayList<FileItem> data = databaseHelper.getBackupFiels();
            for (int i = 0; i < data.size(); i++) {
                Log.e(TAG, "onClick: " + data.get(i).getDisplayName());
                java.io.File uploadfile = new java.io.File(data.get(i).getNewPath());
                if (uploadfile.exists()) {
                    File file = GoogleDriveHelper.createOrUpdateFileFromFile(service, uploadfile.getAbsolutePath(), fileDirID, mimeType);
                    Log.e(TAG, "doInBackground: werew " + i + " >> " + file.getId());
                    int dd = databaseHelper.updateFileCloudID(data.get(i).getId(), file.getId());
                    Log.e(TAG, "doInBackground: update " + dd);
                }
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (customProgress != null && customProgress.isShowDialog())
                customProgress.hideProgress();
            new updateProgressTask().execute();
            Toast.makeText(mContext, "Backup upload successfully", Toast.LENGTH_SHORT).show();
        }
    }

    public class RestorePhotoTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            customProgress = CustomProgress.getInstance();
            customProgress.showProgress(CloudBackupActivity.this, "Restore backup", "Please wait, data is restore...");
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                ArrayList<PhotoItem> data = databaseHelper.getRestoreImages();

                Log.e("RestorePhotoTask", ""+service.files().list());
                for (int i = 0; i < data.size(); i++) {
                    if (!data.get(i).getCouldId().equalsIgnoreCase("null1")) {

                        Drive.Files.Get request1 = service.files().get(data.get(i).getCouldId());
                        request1.getMediaHttpDownloader().setProgressListener(new CloudBackupActivity.CustomProgressListener());
                        databaseHelper.reCoverPhoto(data.get(i).getId());
                        java.io.File dirFile = new java.io.File(Utils.nohideImage);
                        if (!dirFile.exists()) {
                            dirFile.mkdirs();
                        }
                        OutputStream out = new FileOutputStream(dirFile + "/" + data.get(i).displayName + ".bin");
                        request1.executeMediaAndDownloadTo(out);
                        out.close();
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "CloudBackupActivity:RestorePhotoTask:IOException:"+e);
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_videos_rs, false)) {
                if (videoDirID.equalsIgnoreCase("")) {
                    CreateDirectoryTask gge = new CreateDirectoryTask();
                    gge.execute();
                } else {
                    RestoreVideoTask g = new RestoreVideoTask();
                    g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                }
            } else {
                if (customProgress != null && customProgress.isShowDialog())
                    customProgress.hideProgress();
                setResult(RESULT_OK);
                Toast.makeText(mContext, "Restore backup successfully", Toast.LENGTH_LONG).show();
            }
        }
    }

    public class RestoreVideoTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (customProgress != null && !customProgress.isShowDialog()) {
                customProgress = CustomProgress.getInstance();
                customProgress.showProgress(CloudBackupActivity.this, "Restore backup", "Please wait, data is restore...");
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                ArrayList<VideoItem> data = databaseHelper.getRestoreVideo();
                for (int i = 0; i < data.size(); i++) {
                    if (!data.get(i).getCouldId().equalsIgnoreCase("null1")) {
                        Drive.Files.Get request1 = service.files().get(data.get(i).getCouldId());
                        request1.getMediaHttpDownloader().setProgressListener(new CloudBackupActivity.CustomProgressListener());
                        databaseHelper.reCoverVideo(data.get(i).getId());
                        java.io.File dirFile = new java.io.File(Utils.nohideVideo);
                        if (!dirFile.exists()) {
                            dirFile.mkdirs();
                        }
                        OutputStream out = new FileOutputStream(dirFile + "/" + data.get(i).displayName + ".bin");
                        request1.executeMediaAndDownloadTo(out);
                        out.close();
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "CloudBackupActivity:RestoreVideoTask:IOException:"+e);
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (PreferenceHelper.getBooleanValue(mContext, PreferenceHelper.prf_chk_files_rs, false)) {
                RestoreFileTask g = new RestoreFileTask();
                g.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            } else {

                if (customProgress != null && customProgress.isShowDialog())
                    customProgress.hideProgress();
                setResult(RESULT_OK);
                Toast.makeText(mContext, "Restore backup successfully", Toast.LENGTH_LONG).show();
            }
        }
    }

    public class RestoreFileTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (customProgress != null && !customProgress.isShowDialog()) {
                customProgress = CustomProgress.getInstance();
                customProgress.showProgress(CloudBackupActivity.this, "Restore backup", "Please wait, data is restore...");
            }
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                ArrayList<FileItem> data = databaseHelper.getRestoreFile();
                for (int i = 0; i < data.size(); i++) {
                    if (!data.get(i).getCouldId().equalsIgnoreCase("null1")) {
                        Drive.Files.Get request1 = service.files().get(data.get(i).getCouldId());
                        request1.getMediaHttpDownloader().setProgressListener(new CloudBackupActivity.CustomProgressListener());
                        databaseHelper.reCoverFile(data.get(i).getId());
                        java.io.File dirFile = new java.io.File(Utils.nohideFile);
                        if (!dirFile.exists()) {
                            dirFile.mkdirs();
                        }
                        OutputStream out = new FileOutputStream(dirFile + "/" + data.get(i).getDisplayName() + ".bin");
                        request1.executeMediaAndDownloadTo(out);
                        out.close();
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "CloudBackupActivity:RestoreFileTask:IOException:"+e);
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (customProgress != null && customProgress.isShowDialog())
                customProgress.hideProgress();
            setResult(RESULT_OK);
            Toast.makeText(mContext, "Restore backup successfully", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        super.onBackPressed();
    }

    class CustomProgressListener implements MediaHttpUploaderProgressListener, MediaHttpDownloaderProgressListener {
        public void progressChanged(MediaHttpUploader uploader) throws IOException {
            switch (uploader.getUploadState()) {
                case INITIATION_STARTED:
                    Log.e(TAG, "CloudBackupActivity:CustomProgressListener:Initiation has started!");
                    System.out.println("Initiation has started!");
                    break;
                case INITIATION_COMPLETE:
                    Log.e(TAG, "CloudBackupActivity:CustomProgressListener:Initiation has complete!");
                    System.out.println("Initiation is complete!");
                    break;
                case MEDIA_IN_PROGRESS:
                    Log.e(TAG, "CloudBackupActivity:CustomProgressListener:Initiation has IN_PROGRESS!"+uploader.getProgress());
                    System.out.println(uploader.getProgress());
                    break;
                case MEDIA_COMPLETE:
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setResult(RESULT_OK);
                            Toast.makeText(mContext, "Backup successfully uploaded on drive.", Toast.LENGTH_LONG).show();
                        }
                    });
            }
        }


        @Override
        public void progressChanged(MediaHttpDownloader downloader) throws IOException {
            switch (downloader.getDownloadState()) {
                case NOT_STARTED:
                    Log.e(TAG, "CloudBackupActivity:progressChanged:NOT_STARTED!");
                    break;
                case MEDIA_IN_PROGRESS:
                    System.out.println(downloader.getProgress());
                    break;
                case MEDIA_COMPLETE:
                    Log.e(TAG, "CloudBackupActivity:progressChanged:Initiation has IN_PROGRESS!"+downloader.getProgress());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
//                            Toast.makeText(mContext, "Import successfully downloading from drive.", Toast.LENGTH_LONG).show();
                        }
                    });
            }
        }
    }

}
