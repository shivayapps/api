package com.shreyaspatil.MaterialDialog.interfaces;

public interface OnCancelListener {
    void onCancel(DialogInterface dialogInterface);
}
