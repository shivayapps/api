package com.shreyaspatil.MaterialDialog.interfaces;

public interface OnDismissListener {
    void onDismiss(DialogInterface dialogInterface);
}
