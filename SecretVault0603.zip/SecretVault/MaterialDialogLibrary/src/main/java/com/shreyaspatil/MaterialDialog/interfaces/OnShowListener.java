package com.shreyaspatil.MaterialDialog.interfaces;

public interface OnShowListener {
    void onShow(DialogInterface dialogInterface);
}
