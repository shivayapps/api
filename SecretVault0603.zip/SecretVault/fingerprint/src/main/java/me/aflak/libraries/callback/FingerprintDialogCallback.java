package me.aflak.libraries.callback;

/**
 * Created by Omar on 08/01/2018.
 */

public interface FingerprintDialogCallback {
    void onAuthenticationSucceeded();
    void onAuthenticationCancel();
}
