package com.textmessages.domain.manager

interface ReferralManager {

    fun trackReferrer()

}
