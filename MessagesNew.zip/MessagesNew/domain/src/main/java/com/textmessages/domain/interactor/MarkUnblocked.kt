package com.textmessages.domain.interactor

import io.reactivex.Flowable
import com.textmessages.domain.repository.ConversationRepository
import javax.inject.Inject

class MarkUnblocked @Inject constructor(private val conversationRepo: ConversationRepository) :
    Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> conversationRepo.markUnblocked(*threadIds) }
    }

}