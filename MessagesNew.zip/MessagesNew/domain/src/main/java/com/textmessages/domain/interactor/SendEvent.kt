package com.textmessages.domain.interactor

import io.reactivex.Flowable
import com.textmessages.domain.manager.NotificationManager
import javax.inject.Inject

class SendEvent @Inject constructor(
    private val notificationManager: NotificationManager
) : Interactor<SendEvent.Params>() {

    data class Params(val event: String, val param_name: String, val param_val: String)

    override fun buildObservable(params: Params): Flowable<Unit> {
        return Flowable.just(Unit)
            .doOnNext {
                notificationManager.sendEvent(
                    params.event,
                    params.param_name,
                    params.param_val
                )
            }
    }

}