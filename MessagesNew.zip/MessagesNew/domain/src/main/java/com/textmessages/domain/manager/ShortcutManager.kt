package com.textmessages.domain.manager

interface ShortcutManager {

    fun updateBadge()

    fun updateShortcuts()

}