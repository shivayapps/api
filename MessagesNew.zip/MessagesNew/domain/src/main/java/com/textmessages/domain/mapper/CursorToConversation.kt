package com.textmessages.domain.mapper

import android.database.Cursor
import com.textmessages.domain.interactor.model.Conversation

interface CursorToConversation : Mapper<Cursor, Conversation> {

    fun getConversationsCursor(): Cursor?

}