package com.adconfig.adsutil

object Config {

    var isLibraryInitialized = false
//    var IS_DEBUG = true
    var isAdsEnable = true

    var isOpenAdEnable: Boolean = true
    var admobInterstitialAdId: String = ""
    var admobAppOpenId: String = ""
    var admobBannerId: String = ""
    var admobNativeId: String = ""
    var admobRewardId: String = ""

}