package com.adconfig.adsutil

import android.util.Log
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import java.util.Date

object Config {

    var mInterstitialAd: InterstitialAd? = null
    var isLibraryInitialized = false

    var admobAppOpenId: String = ""
    var showInterTime: Long = 0

}