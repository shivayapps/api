package com.adconfig.adsutil.utils

import android.content.Context
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat

var isAppForeground = false
var isAnyAdOpen = false
var isInterstitialAdShow = false

var isAnyAdShowing: Boolean = false

fun Context.getcolor(@ColorRes id: Int) = ContextCompat.getColor(this, id)