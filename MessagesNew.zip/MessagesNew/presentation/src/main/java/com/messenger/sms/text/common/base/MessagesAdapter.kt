package com.messenger.sms.text.common.base

import android.view.View
import android.widget.SectionIndexer
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.feature.compose.editing.ComposeItem


/**
 * Base RecyclerView.Adapter that provides some convenience when creating a new Adapter, such as
 * data list handing and item animations
 */
abstract class MessagesAdapter<T> : RecyclerView.Adapter<MessagesViewHolder>(), SectionIndexer {


    private var sectionsTranslator = HashMap<Int, Int>()
    private var mSectionPositions: ArrayList<Int> = arrayListOf()

    var data: List<T> = ArrayList()
        set(value) {
            if (field === value) return

            val diff = DiffUtil.calculateDiff(getDiffUtilCallback(field, value))
            field = value
            diff.dispatchUpdatesTo(this)
            onDatasetChanged()

            emptyView?.setVisible(value.isEmpty())
        }

    var data1: List<ComposeItem> = ArrayList()

    private val mSections = "❤ABCDEFGHIJKLMNOPQRSTUVWXYZ#".toList()

    /**
     * This view can be set, and the adapter will automatically control the visibility of this view
     * based on the data
     */
    var emptyView: View? = null
        set(value) {
            field = value
            field?.isVisible = data.isEmpty()
        }

    val selectionChanges: Subject<List<Long>> = BehaviorSubject.create()

    private val selection = mutableListOf<Long>()

    /**
     * Toggles the selected state for a particular view
     *
     * If we are currently in selection mode (we have an active selection), then the state will
     * toggle. If we are not in selection mode, then we will only toggle if [force]
     */
    protected fun toggleSelection(id: Long, force: Boolean = true): Boolean {
        if (!force && selection.isEmpty()) return false

        when (selection.contains(id)) {
            true -> selection.remove(id)
            false -> selection.add(id)
        }

        selectionChanges.onNext(selection)
        return true
    }

    protected fun isSelected(id: Long): Boolean {
        return selection.contains(id)
    }

    fun clearSelection() {
        selection.clear()
        selectionChanges.onNext(selection)
        notifyDataSetChanged()
    }

    fun getItem(position: Int): T {
        return data[position]
    }

    override fun getItemCount(): Int {
        return data.size
    }

    open fun onDatasetChanged() {}

    /**
     * Allows the adapter implementation to provide a custom DiffUtil.Callback
     * If not, then the abstract implementation will be used
     */
    private fun getDiffUtilCallback(oldData: List<T>, newData: List<T>): DiffUtil.Callback {
        return object : DiffUtil.Callback() {
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                areItemsTheSame(oldData[oldItemPosition], newData[newItemPosition])

            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                areContentsTheSame(oldData[oldItemPosition], newData[newItemPosition])

            override fun getOldListSize() = oldData.size

            override fun getNewListSize() = newData.size
        }
    }

    protected open fun areItemsTheSame(old: T, new: T): Boolean {
        return old == new
    }

    protected open fun areContentsTheSame(old: T, new: T): Boolean {
        return old == new
    }


    override fun getSections(): Array<String> {
        val sections: ArrayList<String> = ArrayList()
        val alphabetFull = arrayListOf<String>()

        for (newItem in data1.indices) {
            if(data1[newItem] !is ComposeItem.Recent){
                val conlist = data1[newItem].getContacts()
                for (value in conlist) {
                    val section: String = value.name
                    val word = section.substring(0, 1).uppercase()
                    if (!sections.contains(word)) {
                        sections.add(word)
                        mSectionPositions.add(newItem)
                    }
                }
            }else{
                if (!sections.contains("\uD83D\uDD54")) {
                    sections.add("\uD83D\uDD54")
                    alphabetFull.add("\uD83D\uDD54")
                    mSectionPositions.add(newItem)
                }
            }
        }
        for (element in mSections) {
            alphabetFull.add(element.toString())
        }
        sectionsTranslator = sectionsHelper(sections, alphabetFull)

        return alphabetFull.toTypedArray()
    }

    private fun sectionsHelper(
        sections: MutableList<String>,
        test: ArrayList<String>
    ): HashMap<Int, Int> {
        val mapOfSections = hashMapOf<Int, Int>()
        var lastFound = 0
        test.forEachIndexed { index, s ->
            if (sections.any { it == s }) {
                val value = sections.indexOfFirst { it == s }
                mapOfSections[index] = value
                lastFound = value
            } else {
                mapOfSections[index] = lastFound
            }
        }

        return mapOfSections
    }

    override fun getPositionForSection(sectionIndex: Int): Int {
        return mSectionPositions[sectionsTranslator[sectionIndex]!!]

    }

    override fun getSectionForPosition(position: Int): Int {
        return 0
    }

}