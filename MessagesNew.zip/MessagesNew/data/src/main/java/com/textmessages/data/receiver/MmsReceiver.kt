package com.textmessages.data.receiver

import com.android.mms.transaction.PushReceiver

class MmsReceiver : PushReceiver()