package com.textmessages.data.util

import com.textmessages.data.compat.SubscriptionInfoCompat
import com.textmessages.data.compat.SubscriptionManagerCompat
import io.reactivex.Observable
import io.reactivex.Observer
import io.reactivex.disposables.Disposable

class ActiveSubscriptionObservable(
    private val subscriptionManager: com.textmessages.data.compat.SubscriptionManagerCompat
) : Observable<List<com.textmessages.data.compat.SubscriptionInfoCompat>>() {

    override fun subscribeActual(observer: Observer<in List<com.textmessages.data.compat.SubscriptionInfoCompat>>) {
        observer.onNext(subscriptionManager.activeSubscriptionInfoList)

        val listener = Listener(subscriptionManager, observer)
        observer.onSubscribe(listener)
        subscriptionManager.addOnSubscriptionsChangedListener(listener)
    }

    internal class Listener(
        private val subscriptionManager: com.textmessages.data.compat.SubscriptionManagerCompat,
        private val observer: Observer<in List<com.textmessages.data.compat.SubscriptionInfoCompat>>
    ) : Disposable, com.textmessages.data.compat.SubscriptionManagerCompat.OnSubscriptionsChangedListener() {

        private var disposed: Boolean = false

        override fun onSubscriptionsChanged() {
            if (!isDisposed) {
                observer.onNext(subscriptionManager.activeSubscriptionInfoList)
            }
        }

        override fun isDisposed(): Boolean = disposed

        override fun dispose() {
            disposed = true
            subscriptionManager.removeOnSubscriptionsChangedListener(this)
        }

    }

}