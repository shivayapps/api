package com.photogallery.utils;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;
import static android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Intent;
import android.net.Uri;

import androidx.annotation.WorkerThread;


import com.photogallery.BuildConfig;


/**
 * Utility class containing methods to help manage image actions such as sharing, cropping, and
 * saving image.
 */
public class ImageActionUtils {

    private static final String AUTHORITY = BuildConfig.APPLICATION_ID + ".overview.fileprovider";
    private static final long FILE_LIFE = 1000L /*ms*/ * 60L /*s*/ * 60L /*m*/ * 24L /*h*/;
    private static final String SUB_FOLDER = "Overview";
    private static final String BASE_NAME = "overview_image_";
    private static final String TAG = "ImageActionUtils";

    
//    @UiThread
//    public static void startLensActivity(Context context, Supplier<Bitmap> bitmapSupplier,
//            Rect crop, Intent intent, String tag) {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            if (bitmapSupplier.get() == null) {
//                Log.e(tag, "No snapshot available, not starting share.");
//                return;
//            }
//        }
//
//        UI_HELPER_EXECUTOR.execute(() -> persistBitmapAndStartActivity(context,
//                bitmapSupplier.get(), crop, intent, ImageActionUtils::getLensIntentForImageUri,
//                tag));
//    }

//    @WorkerThread
//    public static Uri getImageUri(Bitmap bitmap, Rect crop, Context context, String tag) {
//        clearOldCacheFiles(context);
//        Bitmap croppedBitmap = cropBitmap(bitmap, crop);
//        int cropHash = crop == null ? 0 : crop.hashCode();
//        String baseName = BASE_NAME + bitmap.hashCode() + "_" + cropHash + ".png";
//        File parent = new File(context.getCacheDir(), SUB_FOLDER);
//        parent.mkdir();
//        File file = new File(parent, baseName);
//
//        try (FileOutputStream fos = new FileOutputStream(file)) {
//            croppedBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
//        } catch (IOException e) {
//            Log.e(tag, "Error saving image", e);
//        }
//
//        return FileProvider.getUriForFile(context, AUTHORITY, file);
//    }


    /**
     * Gets the intent used to share image.
     */
    @WorkerThread
    private static Intent[] getShareIntentForImageUri(Uri uri, Intent intent) {
        if (intent == null) {
            intent = new Intent();
        }
        ClipData clipdata = new ClipData(new ClipDescription("content",
                new String[]{"image/png"}),
                new ClipData.Item(uri));
        intent.setAction(Intent.ACTION_SEND)
                .setComponent(null)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .addFlags(FLAG_GRANT_READ_URI_PERMISSION)
                .setType("image/png")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .setClipData(clipdata);
        return new Intent[]{Intent.createChooser(intent, null).addFlags(FLAG_ACTIVITY_NEW_TASK)};
    }
    
    @WorkerThread
    public static Intent[] getLensIntentForImageUri(Uri uri) {
        Intent intent = new Intent();
        intent.setPackage("com.google.ar.lens");
        return getShareIntentForImageUri(uri, intent);
    }

}
