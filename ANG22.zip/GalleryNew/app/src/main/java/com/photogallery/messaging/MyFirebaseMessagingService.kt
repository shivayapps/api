package com.photogallery.messaging

import android.app.Notification.VISIBILITY_PUBLIC
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.photogallery.R
import com.photogallery.activities.HomeActivity
import com.photogallery.activities.StorageScanActivity
import com.photogallery.activities.SettingActivity
import com.photogallery.activities.LocationAlbumActivity
import com.photogallery.activities.LanguageSelectionActivity
import org.json.JSONObject
import java.util.Random


class MyFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        const val CHANNEL_ID = "Gallery"
        const val CHANNEL_NAME = "Gallery"
    }

    private val TAG = "FirebaseMessaging"
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        sendNotification(remoteMessage)
    }

    private fun sendNotification(remoteMessage: RemoteMessage) {
        Log.e(TAG, "onMessageReceived title==>> ${remoteMessage.notification?.title}  body==>> ${remoteMessage.notification?.body}")
        var intent = Intent(this, HomeActivity::class.java)
        //Background work here
        var mActivityName = "";
        try {

            //                Log.w(TAG, "FNS Message Notification imageUrl: " + imageUrl);
            val activity_name: String
            try {
                Log.w(TAG, "remoteMessage.data== ${remoteMessage.data}")
                val params: Map<String, String> = remoteMessage.data
                val jsonObject = JSONObject(params)
                activity_name = jsonObject.getString("activity")
                mActivityName = activity_name
                Log.w(TAG, "activity== $activity_name")
            } catch (e: Exception) {
                Log.w(TAG, "Exception.001:$e")
            }
            intent = if (mActivityName.contains("setting")) {
                Intent(this, SettingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } else if (mActivityName.contains("language")) {
                Intent(this, LanguageSelectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } else if (mActivityName.contains("cleaner")) {
                Intent(this, StorageScanActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } else if (mActivityName.contains("map")) {
                Intent(this, LocationAlbumActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } else {
                Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Exception.002:$e")
        }

        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pendingIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            } else {
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            }

            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationBuilder = NotificationCompat.Builder(this, getString(R.string.default_notification_channel_id))
                .setContentTitle(remoteMessage.notification?.title)
                .setContentText(remoteMessage.notification?.body)
                .setSmallIcon(R.drawable.ic_notification_logo)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)

            notificationBuilder.setVibrate(LongArray(0))

            try {
                notificationBuilder.setChannelId(getString(R.string.default_notification_channel_id))
                val mChannel = NotificationChannel(
                    getString(R.string.default_notification_channel_id),
                    getString(R.string.default_notification_channel_id),
                    NotificationManager.IMPORTANCE_HIGH
                )
                mChannel.description = "Notifications are info related."
                mChannel.lockscreenVisibility = VISIBILITY_PUBLIC
                mChannel.enableLights(true)
                mChannel.lightColor = Color.RED
                mChannel.enableVibration(true)
                mChannel.setShowBadge(true)
                mChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
                notificationBuilder.setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                notificationManager.createNotificationChannel(mChannel)
                notificationManager.notify(Random().nextInt(), notificationBuilder.build())
            } catch (e: IllegalStateException) {
                Log.e("NotificationError", "Failed to send notification:$e")
            }

        } catch (e: Exception) {
        }

    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
    }

    override fun onCreate() {
        super.onCreate()
    }

}
