package com.gallery.photo.image.video.mainduplicate.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import java.util.*

class IndividualVideosAdapter(
    var context: Context,
    var videosMarkedListener: MarkedListener,
    var groupOfDupesVideos: List<IndividualGroupModel>
) : RecyclerView.Adapter<IndividualVideosAdapter.MediaViewHolder>() {

    class MediaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var checkBox: CheckBox = itemView.findViewById(R.id.cb_grp_checkbox)
        var myGridView: RecyclerView = itemView.findViewById(R.id.gv_images)
        var textView: TextView = itemView.findViewById(R.id.tv_grp_name)

        init {

            myGridView.setHasFixedSize(true)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): MediaViewHolder {
        return MediaViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(R.layout.adapter_media, viewGroup, false)
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        val individualGroup = groupOfDupesVideos[position]
        holder.textView.text = "Set " + individualGroup.groupTag
        holder.checkBox.isChecked = individualGroup.isCheckBox
        holder.myGridView.layoutManager = GridLayoutManager(context, 2)
        holder.myGridView.adapter = ListVideoAdapter(
            context,
            videosMarkedListener,
            groupOfDupesVideos[position],
            individualGroup.individualGrpOfDupes!!,
            holder.checkBox
        )
        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                val individualGroup1 = groupOfDupesVideos[position]
                individualGroup1.isCheckBox = isChecked
                val gridVideoAdapter = ListVideoAdapter(
                    context,
                    videosMarkedListener,
                    groupOfDupesVideos[position],
                    setCheckBox(individualGroup1.individualGrpOfDupes, isChecked),
                    holder.checkBox
                )
                holder.myGridView.adapter = gridVideoAdapter
                gridVideoAdapter.notifyDataSetChanged()
            }
        }
    }

    override fun getItemCount(): Int {
        return groupOfDupesVideos.size
    }

    private fun setCheckBox(videoItems: List<ItemDuplicateModel>?, value: Boolean): List<ItemDuplicateModel> {
        val lListOfDupes: MutableList<ItemDuplicateModel> = ArrayList()
        for (i in videoItems!!.indices) {
            val videoItem = videoItems[i]
            when {
                i != 0 -> {
                    if (!value) {
                        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_videos.remove(videoItem)
                        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.subSizeVideos(videoItem.sizeOfTheFile)
                        videosMarkedListener.updateMarked()
                    } else if (!videoItem.isFileCheckBox) {
                        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_videos.add(videoItem)
                        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.addSizeVideos(videoItem.sizeOfTheFile)
                        videosMarkedListener.updateMarked()
                    }
                    videoItem.isFileCheckBox = value
                    lListOfDupes.add(videoItem)
                }
                videoItem.isFileCheckBox -> {
                    com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_videos.remove(videoItem)
                    videoItem.isFileCheckBox = false
                    lListOfDupes.add(videoItem)
                }
                else -> {
                    videoItem.isFileCheckBox = false
                    lListOfDupes.add(videoItem)
                }
            }
        }
        return lListOfDupes
    }
}