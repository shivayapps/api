package com.gallery.photo.image.video.fragment

import android.annotation.SuppressLint
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.GalleryApp
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activities.VideoAlbumActivity
import com.gallery.photo.image.video.activities.FavouriteListActivity
import com.gallery.photo.image.video.activities.HomeActivity
import com.gallery.photo.image.video.activities.ImageListActivity
import com.gallery.photo.image.video.activities.TimeLineActivity
import com.gallery.photo.image.video.activities.exploremap.MapAlbumActivity
import com.gallery.photo.image.video.adapter.AlbumAdapter
import com.gallery.photo.image.video.browser.WebBrowserActivity
import com.gallery.photo.image.video.customview.MyGridLayoutManager
import com.gallery.photo.image.video.customview.MyRecyclerView
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.FragmentAlbumBinding
import com.gallery.photo.image.video.dialog.AlbumDetailsDialog
import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.dialog.DeleteDialog
import com.gallery.photo.image.video.dialog.ProgressDialog
import com.gallery.photo.image.video.dialog.RenameFolderDialog
import com.gallery.photo.image.video.dialog.SelectAlbumFullDialog
import com.gallery.photo.image.video.dialog.SelectAlbumImageFullDialog
import com.gallery.photo.image.video.dialog.BatchFolderRenameDialog
import com.gallery.photo.image.video.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.event.CopyMoveEvent
import com.gallery.photo.image.video.event.DeleteEvent
import com.gallery.photo.image.video.event.DisplayDeleteEvent
import com.gallery.photo.image.video.event.RenameEvent
import com.gallery.photo.image.video.event.RestoreDataEvent
import com.gallery.photo.image.video.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beVisibleIf
import com.gallery.photo.image.video.extension.getParentFolder
import com.gallery.photo.image.video.extension.toast
import com.gallery.photo.image.video.mainduplicate.DuplicateFinderActivity
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.notes.NotesActivity
import com.gallery.photo.image.video.recover.RecoverMediaActivity
import com.gallery.photo.image.video.secret.activity.LockActivity
import com.gallery.photo.image.video.secret.activity.PrivateActivity
import com.gallery.photo.image.video.secret.activity.SelectImageActivity
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MAX_COLUMN_COUNT_ALBUM
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.TYPE_GIFS
import com.gallery.photo.image.video.utils.TYPE_IMAGES
//import com.gallery.photo.image.video.utils.TYPE_PORTRAITS
//import com.gallery.photo.image.video.utils.TYPE_RAWS
//import com.gallery.photo.image.video.utils.TYPE_SVGS
import com.gallery.photo.image.video.utils.TYPE_VIDEOS
import com.gallery.photo.image.video.utils.Utils
import com.gallery.photo.image.video.utils.photoExtensions
import com.gallery.photo.image.video.utils.rawExtensions
import com.gallery.photo.image.video.utils.videoExtensions
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.util.Calendar
import java.util.Collections
import kotlin.math.max
import kotlin.math.min


class AlbumFragment : Fragment() {

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        (mActivity as HomeActivity).longClickListener(isShowSelection, selected, isAllSelect)
    }

    var mActivity: AppCompatActivity? = null
    lateinit var binding: FragmentAlbumBinding
    lateinit var preferences: Preferences

    var dummyList: ArrayList<AlbumData> = ArrayList()
    var albumList: ArrayList<AlbumData> = ArrayList()

    var recentList: ArrayList<PictureData> = ArrayList()
//    var favouriteList: ArrayList<PictureData> = ArrayList()
//    var videoList: ArrayList<PictureData> = ArrayList()

    //    var customAlbumList: ArrayList<AlbumData> = ArrayList()
    var albumWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
    var albumAdapter: AlbumAdapter? = null
    var isEmpty = false

    var albumCount = 0

    private var lastLongPressedItem = -1
    var selectedItem = 0
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentAlbumBinding.inflate(layoutInflater, container, false)
        if (isAdded && !isDetached) {
            initView()
        }
        return binding.root
    }

    private fun initView() {
        if (isAdded) {
            if (mActivity == null) mActivity = requireActivity() as HomeActivity

            preferences = com.gallery.photo.image.video.GalleryApp.preferences
            getData()

            binding.swipeRefreshLayout.setOnRefreshListener {
                if (binding.swipeRefreshLayout.isEnabled) getData()
                else binding.swipeRefreshLayout.isRefreshing = false
            }
            binding.ivScrollTop.setOnClickListener {
                binding.albumRecycler.scrollToPosition(0)
                binding.ivScrollTop.beGone()
            }
            binding.root.doOnPreDraw {

                binding.albumRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                        val firstPositon =
                            (binding.albumRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()

                        binding.ivScrollTop.beVisibleIf(firstPositon > 3)
                    }
                })
            }
        }

    }

    fun getSelected(): ArrayList<AlbumData> {
        val selectAlbum: ArrayList<AlbumData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null) {
//                if (albumList[i] is PictureData) {
                val model: AlbumData = albumList[i] as AlbumData
                if (model.isSelected) {
                    selectAlbum.add(model)
//                        favList.add(model.filePath)
                }
//                }
            }
        }
        return selectAlbum
    }

    fun pinAlbum() {
        if (selectedItem == 0) {
            mActivity?.toast(getString(R.string.PleaseSelectAlbum))
        } else {

            val pinList: ArrayList<String> = ArrayList()
            pinList.addAll(preferences.getPinAlbumList())

            val list = albumList.filter { it.isSelected }
            for (i in list.indices) {
                if (list[i].isSelected) {

                    if (!pinList.contains(list[i].folderPath)) {

                        pinList.add(0, list[i].folderPath)
                    }
                }
            }
//            if (!favList.contains(filePath)) {
//                favList.add(0, filePath)
            preferences.setPinAlbumList(pinList)
            preferences.refreshMedia = true
            albumAdapter?.pinList = pinList
//            albumAdapter?.updatePinList()
//            setFilterData()
//            binding.swipeRefreshLayout.isEnabled=true
//            longClickListener(false, 0, false)
//            setRvLayoutManager()
            setCloseToolbar()

        }
    }

    fun unPinAlbum() {
        if (selectedItem == 0) {
            mActivity?.toast(getString(R.string.PleaseSelectAlbum))
        } else {

            val pinList: ArrayList<String> = ArrayList()
            pinList.addAll(preferences.getPinAlbumList())

            val list = albumList.filter { it.isSelected }
            for (i in list.indices) {
                if (list[i].isSelected) {
//                    albumList[i].isSelected=false
                    if (pinList.contains(list[i].folderPath)) {
                        pinList.remove(list[i].folderPath)
                    }
//                    else {
//                        pinList.add(0, list[i].folderPath)
//                    }
                }
            }
//            if (!favList.contains(filePath)) {
//                favList.add(0, filePath)
            preferences.setPinAlbumList(pinList)
            preferences.refreshMedia = true
            albumAdapter?.pinList = pinList
//            albumAdapter?.updatePinList()
//            setFilterData()
//            binding.swipeRefreshLayout.isEnabled=true
//            longClickListener(false, 0, false)
//            setRvLayoutManager()
            setCloseToolbar()
//            getData()
//                EventBus.getDefault().post(UpdateFavoriteEvent(filePath, true))
//            }

        }
    }

    private fun setData() {

        binding.swipeRefreshLayout.isRefreshing = false

        binding.albumRecycler.recycledViewPool.clear()
        enableScroll()
        if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged() else initAdapter()
        setEmptyData()

        binding.mSFLoading.stopShimmer()
        binding.mSFLoading.beGone()
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                        if (isSelectAll) selected++
                    }
                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun initAdapter() {
        setRvLayoutManager()

        albumAdapter = AlbumAdapter(mActivity!!, albumList,
            clickListener = {
                val albumData = albumList[it]
                if (albumData.isCheckboxVisible) {
                    if (!albumData.isCustomAlbum) {
                        albumData.isSelected = !albumData.isSelected
                        albumAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    }
                } else {

                    if (albumData.isCustomAlbum) {
//                        if (albumData.pictureData.size != 0) {
                        openImageList(albumData)
//                        } else {
//                            startActivity(Intent(mActivity, MediaActivity::class.java))
//                        }
                    } else {
                        openImageList(albumData)
                    }
                }
            }, longClickListener = {
                if (!albumList[it].isCustomAlbum) {
                    lastLongPressedItem = it
                    binding.albumRecycler.setDragSelectActive(it)
                    lastLongPressedItem = if (lastLongPressedItem == -1) {
                        it
                    } else {
                        val min = min(lastLongPressedItem, it)
                        val max = max(lastLongPressedItem, it)
                        for (i in min..max) {
                            toggleItemSelection(true, i, false)
                        }
//                    updateTitle()
                        it
                    }

                    if (albumList[it] is AlbumData) {
                        val pictureData = albumList[it] as AlbumData
                        for (i in albumList.indices) {
                            if (albumList[i] != null) {
                                val model = albumList[i] as AlbumData
                                model.isCheckboxVisible = true
                            }
                        }
                        pictureData.isCheckboxVisible = true
                        pictureData.isSelected = true
                        notifyAdapter()
                        setSelectedFile()
                    }
                }
            }, utilClickListener = { utilPos ->
                when (utilPos) {
                    0 -> {//llRecent
                        val recentAlbum = AlbumData(
                            getString(R.string.recent),
                            pictureData = recentList,
                            isCustomAlbum = true
                        )
                        openImageList(recentAlbum)
                    }
                    1 -> {
                        //llAllVideo
//                        val recentAlbum=AlbumData(
//                            getString(R.string.Favorite),
//                            pictureData = recentList,
//                            isCustomAlbum = true
//                        )
                        val intent = Intent(mActivity, VideoAlbumActivity::class.java)
                        intent.putExtra("title", getString(R.string.all_videos))
                        startActivity(intent)
                    }
                    2 -> {//llFavorite
                        val intent = Intent(mActivity, FavouriteListActivity::class.java)
                        intent.putExtra("title", getString(R.string.Favorite))
                        startActivity(intent)
                    }
                    3 -> {//llDuplicate
                        startActivity(Intent(mActivity, DuplicateFinderActivity::class.java))
                    }
                    4 -> {//llHidden
                        val intent = Intent(mActivity, LockActivity::class.java)
                        lockActivityResultLauncher.launch(intent)
                    }
                    5 -> {//llTimeLine
                        startActivity(Intent(mActivity, TimeLineActivity::class.java))
                    }
                    6 -> {//llMaps
                        startActivity(Intent(mActivity, MapAlbumActivity::class.java))
                    }
                    7 -> {//llNote
                        startActivity(Intent(mActivity, NotesActivity::class.java))
                    }
                    8 -> {//llBrowser
                        startActivity(Intent(mActivity, WebBrowserActivity::class.java))
                    }
                    9 -> {//llPdf

                        val intent=Intent(mActivity, RecoverMediaActivity::class.java)
                        startActivity(intent)
//                        val intent = Intent(mActivity, SelectImageActivity::class.java)
//                        intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
//                        startActivity(intent)
                    }

                }

            })
        binding.albumRecycler.adapter = albumAdapter

        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)
    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val intent = Intent(mActivity, PrivateActivity::class.java)
            privateActivityResultLauncher.launch(intent)
        }
    }

    var privateActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->

        Constant.isReCreateHomeSS = true
        val intent = mActivity?.intent
        mActivity?.finish()
        mActivity?.overridePendingTransition(0, 0)
        mActivity?.startActivity(intent)
        mActivity?.overridePendingTransition(0, 0)
        Constant.isChangeLanguage = false

    }

    fun setCloseToolbar() {
        if (isAdded) {
            setClose()
            longClickListener(false, 0, false)
        }
    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${albumList.size} ")
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                }
        }


        binding?.swipeRefreshLayout?.isEnabled = true

        notifyAdapter()
        setRvLayoutManager()
//        getData()
        selectedItem = 0
    }

    private fun deletePhotos(isPermanent: Boolean) {
//        val deleteList = ArrayList<String>()
        preferences.refreshMedia = true
        preferences.scanMedia = true

        var deleteCount = 0
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i].isSelected) {
                    val pictureList = albumList[i].pictureData
                    selectImage.addAll(pictureList)
                }
        }

        Utils.deleteFiles(mActivity!!, selectImage, isPermanent) { deleteList ->
            var i = 0
            for (a in albumList.indices) {
                val pictures = albumList[a].pictureData
                while (i < pictures.size) {
                    if (pictures[i] != null) if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is PictureData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is PictureData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                    i++
                }
            }
            true

            mActivity?.runOnUiThread {
//                progressDialog.dismiss()
                setBeforeDeleteUpdate(deleteList)
            }
        }
//        val progressDialog = ProgressDialog(
//            mActivity,
//            R.drawable.ic_drawer_delete,
//            selectImage.size,
//            mActivity.getString(R.string.Deleting),
//            ""
//        )
//        progressDialog.isCancelable = false
//        progressDialog.show(parentFragmentManager, progressDialog.tag)


//        val dataBase = AppDatabase.getInstance(mActivity)
//        selectImage.map { picture ->
//            val isDelete = Utils.deleteFile(mActivity, picture.filePath, dataBase, isPermanent)
//            if (isDelete) {
//                deleteCount++
//                deleteList.add(picture.filePath)
//                progressDialog.setProgress(deleteCount, selectImage.size)
//            }
//        }


    }

    @SuppressLint("CheckResult")
    private fun deletePhotoOld(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()
//        preferences?.refreshMedia = true

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i].isSelected) {
                    val pictureList = albumList[i].pictureData
                    selectImage.addAll(pictureList)
                }
        }

        val progressDialog = ProgressDialog(
            mActivity!!,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            mActivity?.getString(R.string.Deleting)!!,
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(parentFragmentManager, progressDialog.tag)

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(mActivity!!)

            for (picture in selectImage) {
//                CoroutineScope(Dispatchers.Main).launch {
//                    async {
//                    }.await()
//                }
                val isDelete =
                    Utils.deleteFile(mActivity!!, picture.filePath, dataBase, isPermanent)
                if (isDelete) {
                    deleteList.add(picture.filePath)
                    mActivity?.runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
                    }
                }
            }

            var i = 0
            for (a in albumList.indices) {
                val pictures = albumList[a].pictureData
                while (i < pictures.size) {
                    if (pictures[i] != null) if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is PictureData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is PictureData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                    i++
                }

            }
            true
        }.subscribeOn(Schedulers.io()).doOnError { _: Throwable? ->
            mActivity?.runOnUiThread {
//                if (dialog.isShowing)
                progressDialog.dismiss()
                setBeforeDeleteUpdate(deleteList)
            }
        }.subscribe { _: Boolean? ->
            mActivity?.runOnUiThread {
//                if (dialog.isShowing)
                progressDialog.dismiss()
                setBeforeDeleteUpdate(deleteList)
            }
        }

//        showUndoSnackbar(binding.root, selectedAlbum as ArrayList<AlbumData>)
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(0, deleteList))
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                }
        }
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout?.isEnabled = true
//        preferences.saveAlbumList(albumList)
        longClickListener(false, 0, false)
        setEmptyData()

        mActivity?.toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
    }

//    fun showUndoSnackbar(anchorView: View, deleteList: ArrayList<AlbumData>) {
//        var deletePhoto: ArrayList<PictureData> = ArrayList()
//        for (a in deleteList.indices) {
//            val pictures = deleteList[a].pictureData
//            deletePhoto.addAll(pictures)
//        }
//
//        val snackbar = Snackbar.make(
//            anchorView,
//            getString(R.string.successfully_deleted, deletePhoto.size),
//            Snackbar.LENGTH_INDEFINITE
//        )
////        snackbar.setAnchorView(anchorView)
//        val snackbarTextView =
//            snackbar.view.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
//        snackbarTextView.isSingleLine = true
//        snackbarTextView.maxWidth = 0
//        snackbarTextView.ellipsize = TextUtils.TruncateAt.MIDDLE
//        snackbarTextView.layoutParams = snackbarTextView.layoutParams.apply {
//            (this as LinearLayout.LayoutParams).weight = 1f
//        }
////        snackbarTextView.gravity=Gravity.BOTTOM
//        snackbarTextView.setOnClickListener {
//            //showToast("${App.recycleBinManager.deletedImageInfo?.info?.path}")
//        }
//        val snackbarContentLayout = snackbar.view as Snackbar.SnackbarLayout
//        val viewGroup = snackbarContentLayout.getChildAt(0) as ViewGroup
//        val customView = layoutInflater.inflate(
//            R.layout.layout_deleted_snackbar_buttons,
//            null
//        )
//        viewGroup.addView(customView)
//        val revokeTimer = customView.findViewById<TextView>(R.id.revokeTimer)
//        5.countdown(intervalMillis = 1000L) { count ->
//            revokeTimer.setText("$count")
//            if (count == 0) {
//                snackbar.dismiss()
////                resetCountdown()
////                onLockedOutChange(lockedOut = false)
//            }
//        }
//
//        val closeButton = customView.findViewById<Button>(R.id.closeButton)
//        closeButton.setOnClickListener {
//            snackbar.dismiss()
////            Thread {
////                App.recycleBinManager.deleteOldImageInRecycleBin()
////                this@MainActivity.runOnUiThread {
////                    sb.dismiss()
////                }
////            }.start()
//        }
//
//        val revokeButton = customView.findViewById<Button>(R.id.revokeButton)
//        revokeButton.setOnClickListener {
//            snackbar.dismiss()
//            Utils.restoreFiles(mActivity!! as AppCompatActivity, deletePhoto, deletePhoto.size, hideListener = {
//
//                mActivity?.toast(getString(R.string.restore_successfully))
//                selectedItem = 0
////                longClickListener(false, 0, false)
//                setClose()
//            })
////            Thread {
////                App.recycleBinManager.recover(onSuccess = { _, _ ->
////                    this@MainActivity.refreshAll {
////                        this@MainActivity.refreshCurrentImagePath()
////                        sb.dismiss()
////                    }
////                })
////            }.start()
//        }
//
//        snackbar.show()
//    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {

            for (path in deleteList) {
                for (pictureData in albumList) {
                    if (pictureData.folderPath == path) {
                        albumList.remove(pictureData)
                        break
                    }
                }
            }
//            getFindCount()
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0
        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in albumList.indices) {
            if (albumList[i] is AlbumData) {
                val model = albumList[i] as AlbumData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding?.swipeRefreshLayout?.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    private fun notifyAdapter() {
        if (albumAdapter != null) albumAdapter?.notifyDataSetChanged()
//binding.pictureRecycler.post { pictureAdapter?.notifyDataSetChanged() }
    }


    private fun initZoomListener() {
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_ALBUM) {
                        increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.albumRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {
//        val isGridShow = preferences?.getShowGrid()
//        if (isGridShow) {
//            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager

        mDragListener = object : MyRecyclerView.MyDragListener {

            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int, lastDraggedIndex: Int, minReached: Int, maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
//        } else {
//            mDragListener = null
//        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.albumRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {

        if (albumList[pos] is AlbumData) {
            if (select && !albumList[pos].isCustomAlbum) {
                albumList[pos].isSelected = true
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                albumList[pos].isSelected = false
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.remove(itemKey)
            }
        }

        albumAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences?.getAlbumGridCount()!!
        if (selectedGrid > 2) {
            preferences?.setAlbumGridCount(selectedGrid - 1)
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getAlbumGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_ALBUM) {
            preferences.setAlbumGridCount(selectedGrid + 1)
        }
        setColumnView()
    }

    private fun setColumnView() {
        (binding.albumRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getAlbumGridCount()
        albumAdapter?.apply {
            notifyItemRangeChanged(0, albumList.size)
        }
        setRvLayoutManager()
    }


    public fun openImageList(albumData: AlbumData) {

        Constant.albumData = AlbumData(
            albumData.title,
            albumData.pictureData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )
        val intent = Intent(mActivity, ImageListActivity::class.java)
        intent.putExtra("folderPath", "${albumData.folderPath}")
        startActivity(intent)
        setBackAlbumData()
//        }

    }

    public fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.pictureData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getAlbumGridCount()
        val isGridShow = preferences.getShowGrid()

        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanCount = gridCount
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < albumList.size) {
                        return if (albumAdapter!!.getItemViewType(position) === albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
                            gridCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } else {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return 1
                }
            }
//            layoutManager.spanSizeLookup = null
            mZoomListener = null

        }
    }

    fun setListGridData() {
        setRvLayoutManager()
        if (albumAdapter != null) {
            albumAdapter!!.notifyDataSetChanged()
        }
    }

    private fun setEmptyData() {
//        if (dummyList != null && dummyList.size != 0) {
        if (albumList != null && albumList.size ==1 ) {
//            isEmpty=false
            binding.albumRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        } else {
//            isEmpty=true
            binding.albumRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        }
    }


    var recentEndDate = Calendar.getInstance()
    var recentStartDate = Calendar.getInstance()

    fun getData() {
        if (!isAdded) return
        recentEndDate = Calendar.getInstance()
        recentStartDate = Calendar.getInstance()
        recentStartDate.add(Calendar.DATE, -15)

        disableScroll()

        binding.swipeRefreshLayout.isRefreshing = true

//        if (!preferences.refreshMedia) {
//            try {
//                val albumPref = preferences.getAlbumList()
//                if (albumPref != null && albumPref.size > 0) {
//                    albumList.clear()
//                    albumList.addAll(albumPref)
//                    dummyList.addAll(albumList)
//                    setData()
//                }
//            } catch (e: Exception) {
//
//            }
//        }


        binding.mSFLoading.startShimmer()
        binding.mSFLoading.beGone()
        CoroutineScope(Dispatchers.IO).launch {
//        ensureBackgroundThread {
            Observable.fromCallable<Boolean> {
                getImages()
                getVideos()
                true
            }.subscribeOn(Schedulers.io())
                .doOnError { throwable: Throwable? ->
                    mActivity?.runOnUiThread {
                        setFilterData()
                    }
                }
                .subscribe { result: Boolean? ->
                    mActivity?.runOnUiThread {
                        setFilterData()
                    }
                }
        }

    }


    private fun disableScroll() {
//        binding.albumRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.albumRecycler.suppressLayout(false)
    }

    fun setFilterData() {
        if (isAdded) {
            disableScroll()

            dummyList.clear()
            val folderKeys: Set<String> = albumWisePictures.keys
            val listFolderkeys = java.util.ArrayList(folderKeys)

            for (i in listFolderkeys.indices) {
                val imagesData: java.util.ArrayList<PictureData> = ArrayList()
                val list = albumWisePictures[listFolderkeys[i]]
                if (list != null) imagesData.addAll(list)

                if (imagesData.size != 0 && imagesData[0].folderName.isNotEmpty()) {
                    val albumData = AlbumData()
                    albumCount++
                    albumData.title = imagesData[0].folderName
                    albumData.pictureData = imagesData

                    val folderPath = listFolderkeys[i]
                    albumData.folderPath = folderPath
                    val file = File(folderPath)
                    albumData.date = file.lastModified()
                    albumData.fileSize = file.length()
//                albumList.add(albumData)
                    dummyList.add(albumData)
                    Log.e("setFilterData", "dummyList.addAlbum::${albumData.title}::")
                    Constant.deviceAlbumList.add(albumData)
//                albumBackupList.add(albumData)
                }
            }

            binding.swipeRefreshLayout.isRefreshing = true
            GlobalScope.launch(Dispatchers.IO) {
                sortAlbumMain()

                val filterMedia = preferences.getFilterMedia()

//                customAlbumList.clear()
//                if (recentList.size > 0) customAlbumList.add(
//                    AlbumData(
//                        getString(R.string.recent),
//                        pictureData = recentList,
//                        isCustomAlbum = true
//                    )
//                )
//                if (favouriteList.size > 0) customAlbumList.add(
//                    AlbumData(
//                        getString(R.string.Favorite),
//                        pictureData = favouriteList,
//                        isCustomAlbum = true
//                    )
//                )
//
//
//                if (filterMedia and TYPE_VIDEOS != 0 && videoList.size > 0) {
//                    customAlbumList.add(
//                        AlbumData(
//                            getString(R.string.all_videos),
//                            pictureData = videoList,
//                            isCustomAlbum = true
//                        )
//                    )
//                }

                val pinList = preferences?.getPinAlbumList()!!
//                val pinAlbum = albumList.filter { pinList.contains(it.folderPath) }
                val pinAlbum = dummyList.filter { pinList.contains(it.folderPath) }

                if (pinAlbum.isNotEmpty()) {
//                    albumList.removeAll(pinAlbum.toSet())
                    dummyList.removeAll(pinAlbum.toSet())
//                    customAlbumList.addAll(pinAlbum)
                }


                if (
                    (filterMedia and TYPE_IMAGES != 0)
//                    || (filterMedia and TYPE_RAWS != 0)
//                    || (filterMedia and TYPE_SVGS != 0)
//                    || (filterMedia and TYPE_PORTRAITS != 0)
                ) {
                    Log.e("setFilterData", "dummyList-${dummyList.size}")

//                    val albumCamera =
//                        dummyList.filter { it.title.lowercase().contains("camera", true) }
//                    if (albumCamera.isNotEmpty()) {
//                        Log.e("setFilterData", "albumCamera-${albumCamera.size}")
//                        dummyList.removeAll(albumCamera.toSet())
//                        if (!customAlbumList.contains(albumCamera.first())) customAlbumList.addAll(
//                            albumCamera
//                        )
//
//                    }

//                    val albumScreenshot =
//                        dummyList.filter { it.title.lowercase().contains("screenshot", true) }

//                    if (albumScreenshot.isNotEmpty()) {
//                        Log.e("setFilterData", "albumScreenshot-${albumScreenshot.size}")
////                        albumList.removeAll(albumScreenshot.toSet())
//                        dummyList.removeAll(albumScreenshot.toSet())
//                        if (!customAlbumList.contains(albumScreenshot.first())) customAlbumList.addAll(
//                            albumScreenshot
//                        )
//                    }

//                    val albumDownload = albumList.filter { it.title.contains("download", true) }
//                    val albumDownload =
//                        dummyList.filter { it.title.lowercase().contains("download", true) }
//                    if (albumDownload.isNotEmpty()) {
//                        Log.e("setFilterData", "albumDownload-${albumDownload.size}")
//                        dummyList.removeAll(albumDownload.toSet())
////                        albumList.removeAll(albumDownload.toSet())
//                        if (!customAlbumList.contains(albumDownload.first())) customAlbumList.addAll(
//                            albumDownload
//                        )
//                    }

                }

//                if (customAlbumList.size > 0) customAlbumList.add(
//                    AlbumData(
//                        getString(R.string.more_album),
//                        isCustomAlbum = true
//                    )
//                )

                val topLay = AlbumData(
                    "utility",
                    isCustomAlbum = true
                )

                isEmpty = dummyList.size == 0
                albumList.clear()
//                dummyList.addAll(0, customAlbumList)
                dummyList.add(0, topLay)
                albumList.addAll(0, dummyList)

                mActivity?.runOnUiThread {
                    try {
//                        preferences.saveAlbumList(albumList)
                        setData()
                    } catch (e: Exception) {
                    }
                }

            }
//        Observable.fromCallable {
//            sortAlbumMain()
//            sortPhotos()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread { setData() }
//            }
        }
    }

    private fun sortPhotos() {
        val sortType = preferences?.getAlbumSortType()
        val sortOrder = preferences?.getAlbumSortOrder()

        for (albumData in albumList) {
            Collections.sort(albumData.pictureData, Comparator { p1, p2 ->
                if (sortType == Constant.SORT_NAME) {
                    if (sortOrder == Constant.ORDER_ASCENDING) p1.fileName.compareTo(
                        p2.fileName,
                        true
                    )
                    else p2.fileName.compareTo(p1.fileName, true)
                } else if (sortType == Constant.SORT_PATH) {
                    if (sortOrder == Constant.ORDER_ASCENDING) p1.filePath.compareTo(
                        p2.filePath,
                        true
                    )
                    else p2.filePath.compareTo(p1.filePath, true)
                } else if (sortType == Constant.SORT_SIZE) {
                    if (sortOrder == Constant.ORDER_ASCENDING) p1.fileSize.compareTo(p2.fileSize)
                    else p2.fileSize.compareTo(p1.fileSize)
                } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                    if (sortOrder == Constant.ORDER_ASCENDING) p1.date.compareTo(p2.date)
                    else p2.date.compareTo(p1.date)
                } else if (sortType == Constant.SORT_DATE_TAKEN) {
                    if (sortOrder == Constant.ORDER_ASCENDING) p1.dateTaken.compareTo(p2.dateTaken)
                    else p2.dateTaken.compareTo(p1.dateTaken)
                } else p2.date.compareTo(p1.date)
            })


        }

//        for (albumData in albumList) {
//            Collections.sort(albumData.pictureData, Comparator { p1, p2 ->
//                if (sortType == Constant.SORT_NAME) {
//                    if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.fileName.compareTo(p2.fileName, true)
//                    else
//                        p2.fileName.compareTo(p1.fileName, true)
//                } else if (sortType == Constant.SORT_PATH) {
//                    if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.filePath.compareTo(p2.filePath, true)
//                    else
//                        p2.filePath.compareTo(p1.filePath, true)
//                } else if (sortType == Constant.SORT_SIZE) {
//                    if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.fileSize.compareTo(p2.fileSize)
//                    else
//                        p2.fileSize.compareTo(p1.fileSize)
//                } else if (sortType == Constant.SORT_LAST_MODIFIED) {
//                    if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.date.compareTo(p2.date)
//                    else
//                        p2.date.compareTo(p1.date)
//                } else if (sortType == Constant.SORT_DATE_TAKEN) {
//                    if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.dateTaken.compareTo(p2.dateTaken)
//                    else
//                        p2.dateTaken.compareTo(p1.dateTaken)
//                } else
//                    p2.date.compareTo(p1.date)
//            })
//        }

    }

    private fun sortAlbumMain() {
        val sortType = preferences?.getAlbumSortType()
        val sortOrder = preferences?.getAlbumSortOrder()

//        albumList.sortWith(Comparator { p1, p2 ->
        dummyList.sortWith(Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING) p1.title.compareTo(p2.title, true)
                else p2.title.compareTo(p1.title, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING) p1.folderPath.compareTo(
                    p2.folderPath,
                    true
                )
                else p2.folderPath.compareTo(p1.folderPath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING) p1.fileSize.compareTo(p2.fileSize)
                else p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING) p1.date.compareTo(p2.date)
                else p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING) p1.date.compareTo(p2.date)
                else p2.date.compareTo(p1.date)
            } else p2.date.compareTo(p1.date)
        })

    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }


    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {
        if (event.path.isNotEmpty()) {
            if (albumList.isNotEmpty()) {
                var isUpdateData = false
                for (albumData in albumList) {
                    if (!isUpdateData) for (pictureData in albumData.pictureData) {
                        if (pictureData.filePath == event.path) {
                            pictureData.isFavorite = event.isFavorite
                            isUpdateData = true
                            break
                        }
                    }
                    else {
                        break
                    }
                }
                if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged()
            }

//            if (albumBackupList.isNotEmpty()) {
//                var isUpdateData = false
//                for (albumData in albumBackupList) {
//                    if (!isUpdateData)
//                        for (pictureData in albumData.pictureData) {
//                            if (pictureData.filePath == event.path) {
//                                pictureData.isFavorite = event.isFavorite
//                                isUpdateData = true
//                                break
//                            }
//                        }
//                    else {
//                        break
//                    }
//                }
//            }
        } else if (event.unFavoriteList.isNotEmpty()) {
            if (albumList.isNotEmpty()) {
                var isUpdateData = false
                for (favPath in event.unFavoriteList) {
                    for (albumData in albumList) {
                        if (!isUpdateData) for (pictureData in albumData.pictureData) {
                            if (pictureData.filePath == favPath) {
                                pictureData.isFavorite = event.isFavorite
                                isUpdateData = true
                                break
                            }
                        }
                        else {
                            break
                        }
                    }
                }
                if (albumAdapter != null) albumAdapter?.notifyDataSetChanged()

//                for (favPath in event.unFavoriteList) {
//                    for (albumData in albumBackupList) {
//                        if (!isUpdateData)
//                            for (pictureData in albumData.pictureData) {
//                                if (pictureData.filePath == favPath) {
//                                    pictureData.isFavorite = event.isFavorite
//                                    isUpdateData = true
//                                    break
//                                }
//                            }
//                        else {
//                            break
//                        }
//                    }
//                }
            }
        }
    }


    fun setHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                mActivity,
                mActivity?.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = ConfirmationDialog(
                mActivity!!,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show(parentFragmentManager, hideDialog.tag)
        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i].isSelected) {
                    val pictureList = albumList[i].pictureData
                    selectImage.addAll(pictureList)
                }
        }

        Utils.hideFiles(mActivity!!, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                getActivity(),
                getString(R.string.hide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setCloseToolbar()
        })
    }

    fun showDeleteDialog() {
        if (isAdded) {
            if (selectedItem == 0) {
                mActivity?.toast(getString(R.string.PleaseSelectAlbum))
            } else {
                val deleteDialog = DeleteDialog(mActivity!!, btnClickListener = {
//                deletePhoto(it)
//                GlobalScope.launch {

                    deletePhotos(it)
//                }
                })
                deleteDialog.show(parentFragmentManager, deleteDialog.tag)
            }
        }
    }

    fun showDetailsDialog() {
        val albumData = albumList.filter { it.isSelected }
        val detailsDialog = AlbumDetailsDialog(albumData[0], false)
        detailsDialog.show(parentFragmentManager, detailsDialog.tag)
    }

    fun addToExclude() {
        val albumData = albumList.filter { it.isSelected }
        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences?.getExcludeList()!!)
        for (i in albumData.indices) {
            if (albumData[i] is AlbumData) {
                val model = albumData[i] as AlbumData
                if (model.isSelected && model.folderPath.isNotEmpty()) {
                    if (!excludeList.contains(model.folderPath)) excludeList.add(model.folderPath)
                }
            }
        }
        preferences?.setExcludeList(excludeList)
        preferences?.refreshMedia = true
        setCloseToolbar()
    }

    fun setDefaultCoverImage() {
        val albumData = albumList.firstOrNull { it.isSelected }
        preferences?.setCoverImage(albumData!!.folderPath, "")
        setCloseToolbar()
    }

    fun setCoverImage() {
        val albumData = albumList.firstOrNull { it.isSelected }

        val addAlbumDialog =
            SelectAlbumImageFullDialog(
                mActivity!!,
                albumData!!.pictureData,
                selectPathListener = { selectPath ->
                    preferences?.setCoverImage(albumData.folderPath, selectPath)
                    //setCopyMove(isCopy, selectPath, selectImage)
                    setCloseToolbar()
                },
                createAlbumListener = {

                })
        addAlbumDialog.show(parentFragmentManager, addAlbumDialog.tag)

    }

    fun showRenameDialog() {

        val albumData = albumList.filter { it.isSelected }

        val renameDialog = RenameFolderDialog(mActivity!!,
            albumData.get(0),
            positiveBtnClickListener = { renamePath, oldPath ->
                val file = File(renamePath)
//                    notifyAdapter()
                setCloseToolbar()
//                    displayImageList[binding.viewPager.currentItem].filePath = renamePath
//                    displayImageList[binding.viewPager.currentItem].fileName = file.name
//                    pagerAdapter.notifyDataSetChanged()

            },
            updateImageListener = {
//                    notifyAdapter()
                setCloseToolbar()
//                    pagerAdapter.notifyDataSetChanged()

            })
        renameDialog.show(parentFragmentManager, renameDialog.tag)
    }


//    fun tryUnLockFolder() {
//        unlockFolder()
//    }
//
//    fun tryLockFolder() {
//        lockFolder()
//    }
//
//    private fun lockFolder() {
//
//        val albumData = albumList.filter { it.isSelected }
//
//        val paths: ArrayList<String> = ArrayList()
//        paths.addAll(albumData.map { it.folderPath })
//        paths.filter { !preferences?.isFolderProtected(it) }.forEach {
//            preferences?.addFolderProtection(it)
//        }
//        setCloseToolbar()
//
//    }

//    private fun unlockFolder() {
//        lockOperation = 2
//
//        lockedAlbumAlbumList = albumList.filter { it.isSelected } as ArrayList<AlbumData>
//        val intent = Intent(activity, LockActivity::class.java)
//        intent.putExtra(Constant.EXTRA_IS_OPEN_ALBUM, true)
//        lockActivityResultLauncher.launch(intent)
//
//    }

//    fun showBatchRenameDialog() {
//
//        val albumData = albumList.filter { it.isSelected }
//        val paths: ArrayList<String> = ArrayList()
//        paths.addAll(albumData.map { it.folderPath })
//
//        val renameDialog = BatchFolderRenameDialog(mActivity!!,
//            false,
//            paths,
//            updateImageListener = {
////                    notifyAdapter()
//                preferences.scanMedia = true
//                preferences.refreshMedia = true
//                setCloseToolbar()
////                    pagerAdapter.notifyDataSetChanged()
//
//            })
//        renameDialog.show(parentFragmentManager, renameDialog.tag)
//    }

    fun showAddAlbumDialog(albums: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {
            requireActivity().toast(getString(R.string.PleaseSelectAlbum))
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            val selectedAlbum: ArrayList<AlbumData> = ArrayList()
            for (a in albumList.indices) {
                if (albumList[a].isSelected) {
                    selectedAlbum.add(albumList[a])
                    val pictures = albumList[a].pictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null) if (pictures[i] is PictureData) {
                            val model: PictureData = pictures[i] as PictureData
//                                if (model.isSelected) {
                            selectImage.add(model)
//                                }
                        }
                    }
                }
            }
            val addAlbumDialog =
                SelectAlbumDialog(
                    mActivity!!,
                    albums,
                    selectedAlbum,
                    isCopy,
                    selectPathListener = { selectPath ->
                        setCopyMove(isCopy, selectPath, selectImage)
                    },
                    createAlbumListener = {
                        val createDialog = CreateAlbumDialog(mActivity!!, createPathListener = {
                            setCopyMove(isCopy, it, selectImage)
                        })
                        createDialog.show(parentFragmentManager, createDialog.tag)
                    })
            addAlbumDialog.show(parentFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean, selectPath: String, selectImage: java.util.ArrayList<PictureData>
    ) {
        Log.e("newAlbum", "setCopyMove:$selectPath")
        if (isCopy)
            Utils.copyFiles(mActivity!!,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {

                    mActivity?.toast(getString(R.string.copy_successfully))
                    selectedItem = 0
//                getData()
//                longClickListener(false, 0, false)

                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    Handler(Looper.getMainLooper()).postDelayed({
                        setCloseToolbar()
                    }, 500)
                })
        else Utils.moveFiles(mActivity!!, selectPath, selectImage, selectedItem, copyListener = {

            mActivity?.toast(getString(R.string.move_successfully))
            selectedItem = 0
//            getData()
//            longClickListener(false, 0, false)

            preferences.refreshMedia = true
            preferences.scanMedia = true
            Handler(Looper.getMainLooper()).postDelayed({
                setCloseToolbar()
            }, 500)
        })

    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty()) updateDeleteImageData(event.deleteList)
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
//            if (albumBackupList.isNotEmpty()) {
//                val file = File(event.renamePath)
//                val parentPath = file.parentFile.path
//                for (albumData in albumBackupList) {
//                    if (albumData.folderPath == parentPath) {
//                        for (model in albumData.pictureData) {
//                            if (model.filePath == event.oldPath) {
//                                model.filePath = event.renamePath
//                                model.fileName = File(event.renamePath).name
//                                model.fileSize = File(event.renamePath).length()
//                                break
//                            }
//                        }
//                    }
//                }
//            }
            if (albumList.isNotEmpty()) {
                val file = File(event.renamePath)
                val parentPath = file.parentFile.path
                for (albumData in albumList) {
                    if (albumData.folderPath == parentPath) {
                        for (model in albumData.pictureData) {
                            if (model.filePath == event.oldPath) {
                                model.filePath = event.renamePath
                                model.fileName = File(event.renamePath).name
                                model.fileSize = File(event.renamePath).length()
                                break
                            }
                        }
                    }
                }

                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty()) {
            val list: ArrayList<String> = ArrayList()
            val imageList: ArrayList<String> = ArrayList()
//            val favList = preferences?.getFavoriteList()!!

//            for (restoreData in event.restoreList) {
//                list.add(restoreData.deletedPath)
//                imageList.add(restoreData.path)
//            }

            updateDeleteImageData(list)

            for (i in imageList.indices) {
                val file1 = File(imageList[i])
                if (file1.exists()) {
                    val pictureData = PictureData(
                        file1.path,
                        file1.name,
                        file1.parentFile.name,
                        file1.lastModified(),
                        file1.lastModified(),
                        file1.length()
                    )
//                    pictureData.isFavorite = favList.contains(file1.path)
                    if (Utils.isVideoFile(file1.path)) {
                        pictureData.isVideo = true
                    }

                    val file = file1.parentFile
                    var isAdd = false
                    for (albumData in albumList) {
                        if (albumData.title == file.name) {
                            val image: ArrayList<PictureData> = ArrayList()
                            image.addAll(albumData.pictureData)
                            image.add(pictureData)
                            albumData.pictureData = image
                            isAdd = true
                        }
                    }

                    if (!isAdd) {
                        val image: ArrayList<PictureData> = ArrayList()
                        image.add(pictureData)
                        val albumData = AlbumData()
                        albumData.title = file.name
                        albumData.folderPath = file.path
                        albumData.pictureData = image
                        albumData.date = file.lastModified()
                        albumData.fileSize = file.length()
                        albumList.add(albumData)
//                        albumBackupList.add(albumData)
                    }

                }
            }

            setFilterData()
        }
    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            val file = File(event.albumPath)

//            val favList = preferences?.getFavoriteList()!!

            if (event.deleteList.isNotEmpty()) updateDeleteImageData(event.deleteList)

            if (file.exists()) {
                val imagesData1 = ArrayList<PictureData>()
                for (i in imageList.indices) {
                    val file1 = File(imageList[i])
                    if (file1.exists()) {
                        val pictureData = PictureData(
                            file1.path,
                            file1.name,
                            file1.parentFile.name,
                            file1.lastModified(),
                            file1.lastModified(),
                            file1.length()
                        )
//                        pictureData.isFavorite = favList.contains(file1.path)
//                        if (Utils.isVideoFile(file1.path)) {
//                            pictureData.isVideo = true
//                        }
                        imagesData1.add(pictureData)
                    }
                }

                var isAdd = false
                for (albumData in albumList) {
                    if (albumData.title == file.name) {
                        val image: ArrayList<PictureData> = ArrayList()
                        image.addAll(albumData.pictureData)
                        image.addAll(imagesData1)
                        albumData.pictureData = image
                        isAdd = true
                    }
                }
//                            if (isAdd) {
//                for (albumData in albumList) {
//                    if (albumData.title == file.name) {
//                        val image: ArrayList<PictureData> = ArrayList()
//                        image.addAll(albumData.pictureData)
//                        image.addAll(imagesData1)
//                        albumData.pictureData = image
//                        isAdd = true
//                    }
//                }
//                            }

                if (!isAdd) {
                    val albumData = AlbumData()
                    albumData.title = file.name
                    albumData.folderPath = file.path
                    albumData.pictureData = imagesData1
                    albumData.date = file.lastModified()
                    albumData.fileSize = file.length()
                    albumList.add(albumData)
//                    albumBackupList.add(albumData)
                }
                if (mActivity != null) mActivity?.runOnUiThread {

                    setFilterData()
                }


            }
        }

    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty()) updateDeleteImageData(event.deleteList)
    }

    private fun updateDeleteImageData(deleteList: java.util.ArrayList<String>) {
        if (albumList != null && albumList.size != 0) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < albumList.size) {
                    if (albumList[i] != null) {
                        val photoHeader = albumList[i]
                        val photoList: ArrayList<PictureData> = ArrayList()
                        photoList.addAll(photoHeader.pictureData)
                        if (photoList.size != 0) {
                            for (p in photoList.indices) {
                                if (deleteList[d].equals(
                                        photoList[p].filePath, ignoreCase = true
                                    )
                                ) {
                                    photoList.removeAt(p)
                                    if (photoList.size == 0) {
                                        if (albumList[i].folderPath.isNotEmpty()) {
//                                            val file = File(albumList[i].folderPath)
//                                            file.delete()
//                                            MediaScannerConnection.scanFile(
//                                                activity, arrayOf(file.path), null
//                                            ) { _: String?, _: Uri? -> }
                                        }
                                        albumList.removeAt(i)
                                        if (i != 0) {
                                            i--
                                        }
                                    } else {
                                        photoHeader.pictureData = photoList
                                        albumList[i] = photoHeader
                                    }
                                    break
                                }
                            }
                        }
                    }
                    i++
                }
            }
            if (albumAdapter != null) {
                albumAdapter!!.notifyDataSetChanged()
            }
            setEmptyData()
        }

        if (albumList != null && albumList.size != 0) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < albumList.size) {
                    if (albumList[i] != null) {
                        val photoHeader = albumList[i]
                        val photoList: ArrayList<PictureData> = ArrayList()
                        photoList.addAll(photoHeader.pictureData)
                        if (photoList.size != 0) {
                            for (p in photoList.indices) {
                                if (deleteList[d].equals(
                                        photoList[p].filePath, ignoreCase = true
                                    )
                                ) {
                                    photoList.removeAt(p)
                                    if (photoList.size == 0) {
                                        if (albumList[i].folderPath.isNotEmpty()) {
//                                            val file = File(albumList[i].folderPath)
//                                            file.delete()
//                                            MediaScannerConnection.scanFile(
//                                                activity, arrayOf(file.path), null
//                                            ) { _: String?, _: Uri? -> }
                                        }
                                        albumList.removeAt(i)
                                        if (i != 0) {
                                            i--
                                        }
                                    } else {
                                        photoHeader.pictureData = photoList
                                        albumList[i] = photoHeader
                                    }
                                    break
                                }
                            }
                        }
                    }
                    i++
                }
            }

        }
    }

    private fun getImages() {
        Log.e("contentResolver.002", "getImages")
        Constant.deviceAlbumList.clear()
        dummyList.clear()
//        favouriteList.clear()
        recentList.clear()
//        videoList.clear()

        albumWisePictures.clear()
        mActivity?.runOnUiThread { if (albumAdapter != null) albumAdapter!!.notifyDataSetChanged() }

        val folderList: MutableList<String> = ArrayList()
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences?.getFavoriteList()!!)

        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences?.getExcludeList()!!)

        albumCount = 0
        val mCursor: Cursor?
        try {
            val BUCKET_DISPLAY_NAME: String = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.SIZE
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }
//            val uri = MediaStore.Files.getContentUri("external")

            val filterMedia = preferences?.getFilterMedia()!!
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = mActivity?.contentResolver!!.query(
                uri,  // Uri
                projection,  // Projection
                selection, selectionArgs, MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
//                Log.e("contentResolver.002", "getImage.mCursor.count::${mCursor.count}")
                mCursor.moveToFirst()

                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))

                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
//
                    var excluded = false
                    excluded = excludeList.any { bucketPath.startsWith(it) }

//                    if (!folderList.contains(bucketPath) && !excluded && File(path).exists()) {
                    if (!folderList.contains(bucketPath) && !excluded) {
                        var bucketName =
                            mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                        if (bucketName == null) bucketName = path.getParentFolder()

                        if (bucketName != null && bucketName.isNotEmpty()) {
                            var d =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                            d *= 1000
                            val fileSizeLength =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            var dt =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                            dt *= 1000
                            if (dt == 0L) dt = d
                            val pictureData = PictureData(
                                path, title, bucketName, d, dt, fileSizeLength, false
                            )

                            pictureData.bucketPath = bucketPath
//                            if (favList.contains(path)) {
//                                pictureData.isFavorite = true
//                                favouriteList.add(pictureData)
//                            }


                            if ((d >= recentStartDate.timeInMillis + 1) && (d <= recentEndDate.timeInMillis)) {
                                recentList.add(pictureData)
//                                Log.e("recentList", "getImages.recentList.add.false")
                            } else {
//                                Log.e("recentList", "getImages.recentList.else")
                            }

                            var imagesData2: ArrayList<PictureData> = ArrayList()
                            if (albumWisePictures.containsKey(bucketPath)) {
                                val list: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                                if (!list.isNullOrEmpty()) imagesData2.addAll(list)
                            } else {
                                imagesData2 = ArrayList()
                            }
                            imagesData2.add(pictureData)
                            albumWisePictures[bucketPath] = imagesData2
                        }
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            } else Log.e("contentResolver.002", "getImage.mCursor.null")
        } catch (e: Exception) {
            Log.e("contentResolver.002", "getImage.Exception::$e")
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    private fun getVideos() {
        Log.e("contentResolver.002", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val folderList: MutableList<String> = ArrayList<String>()
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences?.getFavoriteList()!!)

        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences?.getExcludeList()!!)

        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

//        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
//        val uri = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )


        val filterMedia = preferences?.getFilterMedia()!!
        val selection = getSelectionQuery(filterMedia)
        val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()
        try {
            val cursor = mActivity?.contentResolver!!.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )

            if (cursor != null) {
//                Log.e("contentResolver.002", "getVideos.mCursor.count::${cursor.count}")
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var excluded = false
                    excluded = excludeList.any { bucketPath.startsWith(it) }

//                    if (!folderList.contains(bucketPath) && !excluded && File(path).exists()) {
                    if (!folderList.contains(bucketPath) && !excluded) {
//                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L) dt = d
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
//                        val pictureData = PictureData()
//                        Log.e(
//                            "contentResolver.002",
//                            "getVideos path:$path, title:$title, bucketName:$bucketName, d:$d, dt:$dt, fileSizeLength:$fileSizeLength, duration:$duration"
//                        )
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isVideo = true

                        pictureData.bucketPath = bucketPath

//                        if (favList.contains(path)) {
//                            pictureData.isFavorite = true
//                            favouriteList.add(pictureData)
//                        }


                        if ((d >= recentStartDate.timeInMillis + 1) && (d <= recentEndDate.timeInMillis)) {
                            recentList.add(pictureData)
                        }
                        val imagesData2: ArrayList<PictureData> = ArrayList()
                        if (albumWisePictures.containsKey(bucketPath)) {
                            val list2: ArrayList<PictureData>? = albumWisePictures[bucketPath]
                            if (list2 != null) imagesData2.addAll(list2)
                        }
                        imagesData2.add(pictureData)
//                        videoList.add(pictureData)
                        albumWisePictures[bucketPath] = imagesData2
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            } else Log.e("contentResolver.002", "getVideos.mCursor.null::")
        } catch (exp: Exception) {
            Log.e("contentResolver.002", "getVideos.Exception::$exp")
            exp.printStackTrace()
        }

    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }
}