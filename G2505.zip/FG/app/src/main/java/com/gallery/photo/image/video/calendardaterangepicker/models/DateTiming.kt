package com.gallery.photo.image.video.calendardaterangepicker.models

internal enum class DateTiming {
    NONE,
    START,
    END
}
