package com.gallery.photo.image.video.edit.model

import android.content.res.TypedArray

data class StickerData(var name: String, var stickerList: TypedArray)
