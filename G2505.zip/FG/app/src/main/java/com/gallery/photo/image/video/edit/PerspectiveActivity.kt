package com.gallery.photo.image.video.edit

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.doOnPreDraw
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.gms.ads.AdView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityPerspectiveBinding
import com.gallery.photo.image.video.dialog.ProgressDialog
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beVisible
import com.gallery.photo.image.video.extension.updateStatusBarColor
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.views.ScaleView


class PerspectiveActivity : BaseActivity() {

    lateinit var binding: ActivityPerspectiveBinding
    private var imagePath = ""
    private var saveImageName = ""
    private var sourceImgBitmap: Bitmap? = null
//    private var adjustList: ArrayList<com.photos.gallery.images.model.edit.AdjustModel> = ArrayList()
//    private lateinit var adjustModel: com.photos.gallery.images.model.edit.AdjustModel
//    private var currentPos = -1

    private var isRefreshing = false
    private var currentPos = 0
    private val posHorizontal = 0
    private val posVertical = 1
    private var progressH = 0
    private var progressV = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPerspectiveBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateStatusBarColor(Color.parseColor("#131624"))

        intView()
        loadBanner()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {

    }
    private fun intView() {

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""

        binding.txtTitle.text = "Perspective"

        val bitmap = getBitmapFromFilePath(imagePath)
        binding.mainImg.setImageBitmap(bitmap)
//        binding.stickerView.setMainImage(binding.mainImg)
//        binding.stickerView.setMainBitmap(bitmap)

        intListener()

        isRefreshing = true
        currentPos = posHorizontal
        unSelectAll()
        binding.adjustX.beVisible()
        binding.adjustY.beGone()
//        binding.adjustLevel.setScaleNum(progressH.toInt())
//        binding.adjustLevel.mUnitValue = progressH

        val selectColor = Color.parseColor("#1878F3")
        val unSelectColor = Color.parseColor("#9B9999")
        binding.btnHorizontal.backgroundTintList= ColorStateList.valueOf(selectColor)
        binding.btnVertical.backgroundTintList= ColorStateList.valueOf(unSelectColor)

        setSelectTab(binding.ivHorizontal, binding.tvHorizontal)
        isRefreshing = false

//        Glide
//            .with(this)
//            .asBitmap()
//            .load(imagePath)
//            .into(object : CustomTarget<Bitmap>() {
//                override fun onResourceReady(
//                    resource: Bitmap,
//                    transition: Transition<in Bitmap>?
//                ) {
//                    sourceImgBitmap = resource
//                    binding.mainImageView.setImageBitmap(sourceImgBitmap)
////                        binding.mainImageView.setFilterWithConfig(BASIC_FILTER_CONFIG)
////                        binding.mainImageView.displayMode =
////                            ImageGLSurfaceView.DisplayMode.DISPLAY_ASPECT_FIT
//
//                }
//
//                override fun onLoadCleared(placeholder: Drawable?) {
//
//                }
//            })
//        binding.mainImageView.doOnPreDraw {
//            Log.e("EDITTAG", "doOnPreDraw")
//        }

//        updateAdjustSelected(0)
    }

    fun getBitmapFromView(view: View): Bitmap {
        val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        return bitmap
    }


    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            val progressDialog = ProgressDialog(
                this@PerspectiveActivity,
                0,
                0,
                getString(R.string.saving),
                ""
            )
            progressDialog.show(supportFragmentManager, progressDialog.tag)
            Thread {
                try {
//                    val bitmap = binding.mainFrame.createBitmap()
                    val bitmap = getBitmapFromView(binding.mainFrame)
                    val imagePath = saveEditImage(bitmap, saveImageName)
                    runOnUiThread {
                        if (imagePath != null) {
                            val intent = Intent()
                            intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                            setResult(RESULT_OK, intent)
                        }
                        progressDialog.dismiss()
                        finish()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        progressDialog.dismiss()
                        Toast.makeText(
                            this,
                            getString(R.string.image_editing_failed),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }.start()
        }


        binding.btnHorizontal.setOnClickListener {
            isRefreshing = true
            currentPos = posHorizontal

            unSelectAll()

            binding.adjustX.beVisible()
            binding.adjustY.beGone()

            val selectColor = Color.parseColor("#1878F3")
            val unSelectColor = Color.parseColor("#9B9999")
            binding.btnHorizontal.backgroundTintList= ColorStateList.valueOf(selectColor)
            binding.btnVertical.backgroundTintList= ColorStateList.valueOf(unSelectColor)

            setSelectTab(binding.ivHorizontal, binding.tvHorizontal)
            isRefreshing = false

        }
        binding.btnVertical.setOnClickListener {
            isRefreshing = true
            currentPos = posVertical

            unSelectAll()

            binding.adjustX.beGone()
            binding.adjustY.beVisible()

            val selectColor = Color.parseColor("#1878F3")
            val unSelectColor = Color.parseColor("#9B9999")
            binding.btnHorizontal.backgroundTintList= ColorStateList.valueOf(unSelectColor)
            binding.btnVertical.backgroundTintList= ColorStateList.valueOf(selectColor)
            setSelectTab(binding.ivVertical, binding.tvVertical)
            isRefreshing = false

        }

        val centerX = binding.mainImg.width / 2f
        val centerY = binding.mainImg.height / 2f
//        binding.mainImg.pivotX = centerX
//        binding.mainImg.pivotY = centerY
//        binding.mainImg.pivotX = 0f
//        binding.mainImg.pivotY = 0f

        binding.adjustX.setSelectScaleListener(object : com.gallery.photo.image.video.views.ScaleView.SelectScaleListener {
            override fun selectScale(value: Int) {
                if (!isRefreshing) {
                    progressV = value.toInt()
                    val scaleFactor = Math.cos(Math.toRadians(value.toDouble())).toFloat()
//                    binding.mainImg.pivotX = 0f
//                    binding.mainImg.pivotY = centerY

                    binding.mainImg.rotationY = value.toFloat()
//                    binding.mainImg.scaleX=scaleFactor
//                    binding.mainImg.scaleY=scaleFactor
                }
            }
        })
        binding.adjustY.setSelectScaleListener(object : com.gallery.photo.image.video.views.ScaleView.SelectScaleListener {
            override fun selectScale(value: Int) {
                if (!isRefreshing) {
                    progressH = value.toInt()
                    val scaleFactor = Math.cos(Math.toRadians(value.toDouble())).toFloat()
//                    binding.mainImg.pivotX = centerX
//                    binding.mainImg.pivotY = 0f

                    binding.mainImg.rotationX = value.toFloat()
//                    binding.mainImg.scaleX=scaleFactor
//                    binding.mainImg.scaleY=scaleFactor
                }
            }
        })
    }

//    private fun updateAdjustSelected(pos: Int) {
//        if (currentPos != pos) {
//            currentPos = pos
//
//            when (currentPos) {
//                posHorizontal -> {
//                    unSelectAll()
//                    binding.adjustLevel.setScaleNum(progressH.toInt())
////                    binding.adjustLevel.mUnitValue = progressH
//                    setSelectTab(binding.ivHorizontal, binding.tvHorizontal)
//                }
//
//                posVertical -> {
//                    unSelectAll()
//                    binding.adjustLevel.setScaleNum(progressV.toInt())
////                    binding.adjustLevel.mUnitValue = progressV
//                    setSelectTab(binding.ivVertical, binding.tvVertical)
//                }
//
//            }
//        }
//    }

    private fun unSelectAll() {
//        val selectColor = Color.parseColor("#9B9999")
//        binding.ivHorizontal.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
//        binding.ivVertical.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)

//        binding.tvHorizontal.setTextColor(selectColor)
//        binding.tvVertical.setTextColor(selectColor)
    }

    private fun setSelectTab(imageView: ImageView, textView: TextView) {
        val selectColor = Color.parseColor("#FFFFFF")
        imageView.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        textView.setTextColor(selectColor)
    }

}