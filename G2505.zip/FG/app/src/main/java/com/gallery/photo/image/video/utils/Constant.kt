package com.gallery.photo.image.video.utils

import android.os.Build
import android.os.Environment
import android.os.Looper
import androidx.annotation.ChecksSdkIntAtLeast
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData

const val NOMEDIA = ".nomedia"

val photoExtensions: Array<String>
    get() = arrayOf(
        ".jpg",
        ".png",
        ".jpeg",
        ".bmp",
        ".webp",
        ".heic",
        ".heif",
        ".apng",
        ".avif"
    )
val videoExtensions: Array<String>
    get() = arrayOf(
        ".mp4",
        ".mkv",
        ".webm",
        ".avi",
        ".3gp",
        ".mov",
        ".m4v",
        ".3gpp"
    )
val audioExtensions: Array<String>
    get() = arrayOf(
        ".mp3",
        ".wav",
        ".wma",
        ".ogg",
        ".m4a",
        ".opus",
        ".flac",
        ".aac",
        ".m4b"
    )
val rawExtensions: Array<String>
    get() = arrayOf(
        ".dng",
        ".orf",
        ".nef",
        ".arw",
        ".rw2",
        ".cr2",
        ".cr3"
    )

val extensionsSupportingEXIF: Array<String>
    get() = arrayOf(
        ".jpg",
        ".jpeg",
        ".png",
        ".webp",
        ".dng"
    )

val normalizeRegex = "\\p{InCombiningDiacriticalMarks}+".toRegex()

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.N)
fun isNougatPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.N_MR1)
fun isNougatMR1Plus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.O)
fun isOreoPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.O_MR1)
fun isOreoMr1Plus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.P)
fun isPiePlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.Q)
fun isQPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.R)
fun isRPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.S)
fun isSPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.TIRAMISU)
fun isTiramisuPlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
fun isUpsideDownCakePlus() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE

const val SHOW_ALL = "show_all"                           // display images and videos from all folders together

const val MAX_CLOSE_DOWN_GESTURE_DURATION = 300

const val SLIDESHOW_SLIDE_DURATION = 500L
const val SLIDESHOW_FADE_DURATION = 1500L

// slideshow animations
const val SLIDESHOW_ANIMATION_NONE = 0
const val SLIDESHOW_ANIMATION_SLIDE = 1
const val SLIDESHOW_ANIMATION_FADE = 2

const val CLICK_MAX_DURATION = 150
const val CLICK_MAX_DISTANCE = 100
const val DRAG_THRESHOLD = 8
const val SHORT_ANIMATION_DURATION = 150L

fun getDateFormats() = arrayListOf(
    "--MM-dd",
    "yyyy-MM-dd",
    "yyyyMMdd",
    "yyyy.MM.dd",
    "yy-MM-dd",
    "yyMMdd",
    "yy.MM.dd",
    "yy/MM/dd",
    "MM-dd",
    "MMdd",
    "MM/dd",
    "MM.dd"
)

const val DATE_FORMAT_ONE = "dd.MM.yyyy"
const val DATE_FORMAT_TWO = "dd/MM/yyyy"
const val DATE_FORMAT_THREE = "MM/dd/yyyy"
const val DATE_FORMAT_FOUR = "yyyy-MM-dd"
const val DATE_FORMAT_FIVE = "d MMMM yyyy"
const val DATE_FORMAT_SIX = "MMMM d yyyy"
const val DATE_FORMAT_SEVEN = "MM-dd-yyyy"
const val DATE_FORMAT_EIGHT = "dd-MM-yyyy"
const val DATE_FORMAT_NINE = "yyyyMMdd"
const val DATE_FORMAT_TEN = "yyyy.MM.dd"
const val DATE_FORMAT_ELEVEN = "yy-MM-dd"
const val DATE_FORMAT_TWELVE = "yyMMdd"
const val DATE_FORMAT_THIRTEEN = "yy.MM.dd"
const val DATE_FORMAT_FOURTEEN = "yy/MM/dd"

const val TIME_FORMAT_12 = "hh:mm a"
const val TIME_FORMAT_24 = "HH:mm"

const val FAST_FORWARD_VIDEO_MS = 10000

const val LOW_TILE_DPI = 160
const val NORMAL_TILE_DPI = 220
const val WEIRD_TILE_DPI = 240
const val HIGH_TILE_DPI = 280

const val TYPE_IMAGES = 1
const val TYPE_VIDEOS = 2
const val TYPE_GIFS = 8
//const val TYPE_RAWS = 8
//const val TYPE_SVGS = 16
//const val TYPE_PORTRAITS = 32

const val MAX_COLUMN_COUNT_ALBUM = 6
const val MAX_COLUMN_COUNT_PICTURE = 8
//fun getDefaultFileFilter() = TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS or TYPE_RAWS or TYPE_SVGS
fun getDefaultFileFilter() = TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS

fun isOnMainThread() = Looper.myLooper() == Looper.getMainLooper()

fun ensureBackgroundThread(callback: () -> Unit) {
    if (isOnMainThread()) {
        Thread {
            callback()
        }.start()
    } else {
        callback()
    }
}
var ImageArray = arrayOf(
    "2bp", "360", "abm", "accountpicture-ms",
    "acorn", "afx", "agif", "agp", "apd", "apng", "apx", "art", "asw", "avatar", "awd",
    "blkrt", "bm2", "bmc", "bmp", "bss", "can", "cd5", "cdg", "cin", "cit", "colz", "cpc",
    "cpg", "cps", "cpt", "csf", "dcm", "dds", "dib", "djvu", "dm3", "dmi", "dpx", "dt2",
    "dtw", "dvl", "ecw", "epp", "exr", "fits", "fpos", "fpx", "gbr", "gcdp", "gif", "gih",
    "gim", "hdp", "hdr", "hdrp", "hpi", "i3d", "ipx", "itc2", "ithmb", "iwi", "j2c", "jb2",
    "jbig2", "jbr", "jia", "jng", "jp2", "jpc", "jpeg", "jpg", "jps", "jpx", "jxr", "kdi",
    "lif", "mat", "max", "mbm", "mix", "mng", "mnr", "mpf", "mpo", "mrxs", "msp", "mxi",
    "myl", "ncd", "oc3", "oc4", "oc5", "oci", "omf", "ota", "pat", "pbm", "pcd", "pcx",
    "pdd", "pdn", "pe4", "pgf", "pgm", "pi2", "pic", "picnc", "pict", "pictclipping",
    "pixadex", "pmg", "png", "pnm", "pns", "pov", "ppf", "ppm", "prw", "psb", "psd",
    "psdx", "pse", "psf", "psp", "pspbrush", "pspimage", "ptg", "ptx", "pvr", "px",
    "pxd", "pxm", "pxr", "pzp", "qmg", "qti", "qtif", "ras", "rif", "rle", "rli",
    "rpf", "s2mv", "sct", "sdr", "sid", "sig", "skitch", "skm", "spa", "spe", "sph",
    "spj", "spp", "spr", "sup", "tbn", "tex", "tg4", "tga", "thm", "thumb", "tif",
    "tiff", "tjp", "tn", "tpf", "tps", "vss", "wb1", "wbc", "wbd", "wbmp", "wbz",
    "webp", "xcf", "xpm", "yuv", "zif", "jpg"
)
var VideoArray = arrayOf(
    "3g2", "3gp", "3gp2", "3gpp", "3p2", "890", "aaf", "aec", "aep",
    "aepx", "aetx", "ajp", "ale", "amc", "amv", "amx", "arcut", "arf", "asf", "asx", "avb", "avi", "avp", "avs",
    "avv", "axm", "bdm", "bdmv", "bdt3", "bik", "bmk", "bsf", "camproj", "camrec", "ced", "cine", "cip", "clpi",
    "cmmp", "cmmtpl", "cmproj", "cmrec", "cpi", "cst", "d2v", "d3v", "dce", "dck", "dcr", "dir", "divx", "dmsd",
    "dmsd3d", "dmsm", "dmss", "dmx", "dpa", "dpg", "dream", "dv", "dv-avi", "dvdmedia", "dvr", "dvr-ms", "dvx",
    "dxr", "dzm", "dzp", "dzt", "edl", "evo", "eye", "ezt", "f4p", "f4v", "fbr", "fbz", "fcp", "fcproject", "flc",
    "flh", "fli", "flv", "gfp", "gts", "hdmov", "hkm", "ifo", "imovieproj", "imovieproject", "ircp", "ism", "ismc",
    "ismv", "ivr", "izz", "izzy", "jss", "jts", "jtv", "m1pg", "m21", "m2p", "m2t", "m2ts", "m2v", "m4v", "mani",
    "mgv", "mj2", "mjp", "mk3d", "mkv", "mnv", "mod", "moi", "mov", "mp21", "mp4", "mpeg", "mpg", "mpgindex", "mpl",
    "mpls", "mpv", "mqv", "msdvd", "mse", "mswmm", "mts", "mtv", "mvd", "mve", "mvp", "mvy", "mxf", "mxv", "ncor",
    "nsv", "nuv", "nvc", "ogm", "ogv", "ogx", "otrkey", "pac", "pds", "pgi", "photoshow", "piv", "plproj", "pmf",
    "ppj", "prel", "pro", "prproj", "prtl", "psh", "pxv", "qtl", "qtz", "r3d", "rcd", "rcproject", "rdb", "rec",
    "rm", "rmd", "rmp", "rms", "rmvb", "roq", "rsx", "rum", "rv", "rvl", "sbk", "scc", "scm", "screenflow", "sedprj",
    "seq", "sfvidcap", "siv", "smi", "smil", "smk", "sqz", "srt", "stl", "stx", "svi", "swf", "swi", "swt", "tda3mt",
    "thp", "tivo", "tix", "tod", "tp", "tp0", "tpd", "tpr", "trp", "ts", "tsp", "ttxt", "tvs", "usf", "usm", "vc1",
    "vcpf", "vcv", "vdo", "vdr", "veg", "vep", "vf", "vfz", "vgz", "viewlet", "vlab", "vob", "vp6", "vp7", "vpj",
    "vro", "vsp", "wcp", "webm", "wlmp", "wmd", "wmmp", "wmv", "wmx", "wp3", "wpl", "wtv", "wvx", "xej", "xel",
    "xesc", "xfl", "xlmv", "xvid", "y4m", "yuv", "zm1", "zm2", "zm3", "zmv"
)



object Constant {

    val EXTRA_SELECT_TYPE: String = "select_type"

    val TYPE_EXCLUDED = "excluded_folders"


    val RENAME_SIMPLE = 0
    val RENAME_PATTERN = 1

    val LAST_VIDEO_POSITION_PREFIX = "last_video_position_"
    val REMEMBER_LAST_VIDEO_POSITION = "remember_last_video_position"


    // rotations
    val ROTATE_BY_SYSTEM_SETTING = 0
    val ROTATE_BY_DEVICE_ROTATION = 1
    val ROTATE_BY_ASPECT_RATIO = 2
    // editAction
    val SAVE_AS_COPY = 0
    val SAVE_AND_REPLACE = 1
    val ALWAYS_ASK = 2

    val EXTRA_IS_OPEN_FROM_SPLASH: String = "extra_isIntroduction"


    val EXT_NAME = 1
    val EXT_PATH = 2
    val EXT_SIZE = 4
    val EXT_RESOLUTION = 8
    val EXT_LAST_MODIFIED = 16
    val EXT_DATE_TAKEN = 32
    val EXT_CAMERA_MODEL = 64
    val EXT_EXIF_PROPERTIES = 128
    val EXT_DURATION = 256
    val EXT_ARTIST = 512
    val EXT_ALBUM = 1024
    val EXT_GPS = 2048

    val GROUP_BY_NONE = 1
    val GROUP_BY_LAST_MODIFIED_DAILY = 2
    val GROUP_BY_DATE_TAKEN_DAILY = 4
    val GROUP_BY_FILE_TYPE = 8
    val GROUP_BY_EXTENSION = 16
    val GROUP_BY_FOLDER = 32
    val GROUP_BY_LAST_MODIFIED_MONTHLY = 64
    val GROUP_BY_DATE_TAKEN_MONTHLY = 128

    //    val GROUP_DESCENDING = 1024
    val GROUP_SHOW_FILE_COUNT = 2048

    val SORT_NAME: Int = 1
    val SORT_PATH: Int = 2
    val SORT_SIZE: Int = 3
    val SORT_LAST_MODIFIED: Int = 4
    val SORT_DATE_TAKEN: Int = 5

    val ORDER_ASCENDING: Int = 1
    val ORDER_DESCENDING: Int = 2

    val THEME_LIGHT: Int = 1
    val THEME_DARK: Int = 2

    var selectedPosition:Int = 0
    var displayImageList: ArrayList<PictureData> = ArrayList()
    var selectedImageList: ArrayList<PictureData> = ArrayList()
    var albumData: AlbumData = AlbumData()
    var albumList: ArrayList<AlbumData> = ArrayList()
    var deviceAlbumList: ArrayList<AlbumData> = ArrayList()
    var videoData: PictureData = PictureData("", "", "", 0L, 0L, 0L)

    val EXTRA_DISPLAY_POS: String = "displayPos"
    val EXTRA_IS_OPEN_CAMERA_PERMISSION: String = "IsOpenCameraPer"
    val EXTRA_OPEN_TYPE_QUE: String = "OPEN_TYPE_QUE"
    val EXTRA_IS_OPEN_ALBUM: String = "isOpenAlbum"
//    val EXTRA_IS_OPEN_PRIVATE: String = "isOpenPrivate"
    val EXTRA_IS_OPEN_RECENTLY_DELETE: String = "isOpenRecentlyDelete"
    val EXTRA_RESET_PASS: String = "resetPass"
    val EXTRA_CHANGE_PASS: String = "ChangePass"
    val EXTRA_CHANGE_EMAIL: String = "ChangeEmail"
    val EXTRA_CHANGE_LOCK_STYLE: String = "ChangeLockStyle"
    val EXTRA_LOCK_STYLE: String = "LockStyle"
    val EXTRA_WALL_PAPER: String = "wall_paper"
    val EXTRA_IMAGE_PATH: String = "IMAGE_PATH"
    val EXTRA_ALBUM_PATH: String = "album_path"
    val EXTRA_EDIT_IMAGE_PATH: String = "editImagePath"
    val EXTRA_EDIT_IMAGE_NAME: String = "editImageName"
    val EXTRA_EDIT_SAVE_IMAGE: String = "imagePath"
    val EXTRA_OPEN_URL: String = "openUrl"
    val EXTRA_IS_OPEN_HISTORY: String = "IS_OPEN_HISTORY"
    val EXTRA_BROWSER_URL: String = "extra_Browser_url"


    val PREF_SLIDE_TIME: String = "pref_slide_time"
    val PREF_SLIDE_EFFECT: String = "pref_slide_effect"
    val PREF_SLIDE_INCLUDE_VIDEO: String = "pref_slide_include_video"
    val PREF_SLIDE_INCLUDE_GIF: String = "pref_slide_include_gif"
    val PREF_SLIDE_RANDOM_ORDER: String = "pref_slide_random_order"
    val PREF_SLIDE_BACKWARD: String = "pref_slide_backward"
    val PREF_SLIDE_LOOP: String = "pref_slide_loop"


    const val HIDE_FOLDER_NAME = ".Private"
    const val RECENT_DELETE_FOLDER_NAME = ".RecentlyDeleted"
//    val HIDE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/.Gallery/" + HIDE_FOLDER_NAME
//    val EDIT_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/Gallery/Edit"
//    val DELETE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + "/.Gallery/" + RECENT_DELETE_FOLDER_NAME

    val ROOT_PATH = Environment.getExternalStorageDirectory().path
    val HIDE_PATH = "$ROOT_PATH/.Gallery/$HIDE_FOLDER_NAME"
    val DELETE_PATH = "$ROOT_PATH/.Gallery/$RECENT_DELETE_FOLDER_NAME"

    val EDIT_PATH = "$ROOT_PATH/Gallery/Edit"
    val RECOVER_PATH = "$ROOT_PATH/Gallery/Recover"
//    val SCREEN_SHOT_PATH = Environment.getExternalStorageDirectory().path + "/Gallery"

    var isChangeLanguage: Boolean = false
    var isReCreateHomeSS: Boolean = false

    const val ASPECT_RATIO_FREE = 0
    const val ASPECT_RATIO_CENTER = 7
    const val ASPECT_RATIO_1_1 = 1
    const val ASPECT_RATIO_3_4 = 2
    const val ASPECT_RATIO_4_3 = 3
    const val ASPECT_RATIO_9_16 = 4
    const val ASPECT_RATIO_2_3 = 5
    const val ASPECT_RATIO_3_2 = 6
    const val ASPECT_RATIO_ONE_ONE = 1
    const val ASPECT_RATIO_FOUR_THREE = 2
    const val ASPECT_RATIO_SIXTEEN_NINE = 3
    const val ASPECT_RATIO_OTHER = 4

    const val SELECT_TYPE_CRATE_ALBUM = 1
    const val SELECT_TYPE_CRATE_PDF = 3
    const val SELECT_TYPE_HIDE = 2

    enum class AnimationTypes(val id: Int, val value: String) {
        NONE(0, "None"),
        ZOOM_IN(1, "ZoomIn"),
        ZOOM_OUT(2, "ZoomOut"),
        DEPTH_SLIDE(3, "Depth Slide"),
        CUBE_IN(4, "CubeIn"),
        CUBE_OUT(5, "CubeOut"),
        FLIP_HORIZONTAL(6, "Flip Horizontal"),
        FLIP_VERTICAL(7, "Flip Vertical"),
        FOREGROUND_TO_BACKGROUND(8, "ForegroundToBackground"),
        BACKGROUND_TO_FOREGROUND(9, "BackgroundToForeground"),
        ROTATE_UP(10, "Rotate Up"),
        ROTATE_DOWN(11, "Rotate Down"),
        GATE(12, "Gate"),
        TOSS(13, "Toss");
//        FIDGET_SPINNER("FidgetSpinner")
    }


}