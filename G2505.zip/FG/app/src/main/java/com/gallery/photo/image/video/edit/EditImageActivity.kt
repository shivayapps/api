package com.gallery.photo.image.video.edit

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.gms.ads.AdView
import com.gallery.photo.image.video.R

import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityEditImageBinding

import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.dialog.ProgressDialog
import com.gallery.photo.image.video.extension.updateStatusBarColor
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

class EditImageActivity : BaseActivity() {

    lateinit var preferences: Preferences
    lateinit var binding: ActivityEditImageBinding
    var imagePath = ""
    var mainImagePath = ""
    var saveImageName = ""
    var isEditImage = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditImageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateStatusBarColor(Color.parseColor("#131624"))
        preferences = Preferences(this)
        loadBanner()

        intView()
    }

    private fun intView() {

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        mainImagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        binding.txtTitle.text = getString(R.string.editor)

        setImageDoneColor()
        val width = getScreenWidth()
//        Log.e("EditTag", "width $width")

        imageLoad()
        intListener()

        val timeStamp = SimpleDateFormat("HHmmss_ddMyy").format(Date())
        saveImageName = "IMG_$timeStamp.jpg"
        Thread {
            val size = mainImagePath.getImageResolution()
            Log.e("EditTag", "width $width imageWidth ${size.x}")
            if (size.x > width) {

                Log.e("EditTag", "resize image")
                val ratio: Float = size.x / size.y.toFloat()
                val height = (width / ratio).toInt()
                val newBitmap =
                    Glide.with(this.applicationContext).asBitmap()
                        .load(mainImagePath)
                        .submit(width, height)
                        .get()
                val imageResizePath = saveEditImage(newBitmap, "IMG_Resize$timeStamp.jpg", 40)
                if (!imageResizePath.isNullOrEmpty())
                    imagePath = imageResizePath
                runOnUiThread {
                    Log.e("EditTag", "resize image successfully")
                }
            }
        }.start()
    }

    private fun imageLoad() {
        Glide.with(this)
            .load(imagePath)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(true)
            .into(binding.imageDisplay)
    }

    var editLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val path = result.data?.getStringExtra(Constant.EXTRA_EDIT_SAVE_IMAGE)
                if (path != null) {
                    imagePath = path
                    isEditImage = true
                }
                imageLoad()
                setImageDoneColor()
            }
        }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    private fun setImageDoneColor() {
//        val selectColor = ContextCompat.getColor(
//            this,
////            if (mainImagePath != imagePath) R.color.black_text else R.color.grayText
//            if (isEditImage) R.color.black_text else R.color.grayText
//        )
//        binding.ivDone.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)

    }

    override fun onBackPressed() {
        if (isEditImage) {
            val exitDialog = ConfirmationDialog(
                this,
                getString(R.string.discard),
                getString(R.string.exit_edit_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    super.onBackPressed()
                })
            exitDialog.show(supportFragmentManager, exitDialog.tag)
        } else
            super.onBackPressed()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }
    private fun loadBanner() {

        val isFirstSession=preferences.splashCounter==1
        val adId=getString(R.string.b_editActivity)
        BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd,binding.llAdPlace,adId,
            AdCache.editAdView,{ isLoaded, adView, message ->
                mAdView=adView
                AdCache.editAdView=adView
            isAdLoaded=isLoaded
        })
    }

    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
//            binding.ivDone.isEnabled = false

            if (mainImagePath.isNotEmpty() && imagePath.isNotEmpty() && isEditImage) {
//                if(!preferences.isConfirmEditAction) {
//                    val confirmDialog = EditConfirmationDialog(
//                        this,
//                        btnClickListener = { action, isDontShowChecked ->
//                            if(action!=2) {
//                                preferences.isConfirmEditAction = isDontShowChecked
//
//                                saveImage(action)
//                            }
//                        })
//                    confirmDialog.show(supportFragmentManager, confirmDialog.tag)
//                } else {
//                    saveImage(preferences.saveEditAction)
//                }
                saveImage()
            } else
                binding.ivDone.isEnabled = true
        }


        binding.btnFilter.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    FilterActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnAdjust.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    AdjustActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnCrop.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    CropActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnDoodle.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    DoodleActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnPerspective.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    PerspectiveActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }

        binding.btnText.setOnClickListener {
            editLauncher.launch(
                Intent(
                    this,
                    StickerActivity::class.java
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_PATH,
                    imagePath
                ).putExtra(
                    Constant.EXTRA_EDIT_IMAGE_NAME,
                    saveImageName
                )
            )
        }
    }

    private fun saveImage() {

        val copyFile = File(imagePath)
        var targetFile = File(mainImagePath)
//        var targetFolder = File(mainImagePath.getParentPath())
        var targetFolder = File(Constant.EDIT_PATH)

        val copyFileName = copyFile.name
//        preferences.saveEditAction=action

//        if (action == 0) {//replace
//            val dataBase = AppDatabase.getInstance(this)
//            mainImagePath
//            Utils.deleteFile(this, mainImagePath, dataBase, false)
//
//            //saveImage(action)
//        } else if (action == 1) {
//
//            //copy
//            //saveImage(action)
//            targetFolder = File(Constant.EDIT_PATH)
//            if (!targetFolder.exists())
//                targetFolder.mkdirs()
//
//            val separated = copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
//            val name = separated[0]
//            val type = separated[1]
//
//            val targetPath = targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
//
////            val targetPath = targetFolder.path + File.separator + copyFileName
//
//            targetFile = File(targetPath)
//        }

        //copy
        //saveImage(action)
        targetFolder = File(Constant.EDIT_PATH)
        if (!targetFolder.exists())
            targetFolder.mkdirs()

        val separated = copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        val name = separated[0]
        val type = separated[1]

        val targetPath = targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type

//            val targetPath = targetFolder.path + File.separator + copyFileName

        targetFile = File(targetPath)

        val copyFiles = java.util.ArrayList<String>()

        val progressDialog = ProgressDialog(
            this@EditImageActivity,
            0,
            0,
            getString(R.string.saving),
            ""
        )
        progressDialog.show(supportFragmentManager, progressDialog.tag)

        Observable.fromCallable {

            if (copyFile.exists()) {
//                val targetPath = targetFolder.path + File.separator + copyFileName
//                val targetFile = File(targetPath)
//                if (targetFile.exists()) {
//                    val separated =
//                        copyFile.name.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
//                    val name = separated[0]
//                    val type = separated[1]
//                    val newPath2 = targetFolder.path + "/" + name + "_" + System.currentTimeMillis() + "." + type
//
//                    val file2 = File(newPath2)
//                    val isCopied: Boolean =
//                        StorageUtils.copyFile(
//                            copyFile,
//                            file2,
//                            this
//                        )
//                    if (isCopied) {
//                        copyFiles.add(file2.path)
//                    }
//                } else {
//                }

                val isCopied: Boolean =
                    com.gallery.photo.image.video.utils.StorageUtils.copyFile(
                        copyFile,
                        targetFile,
                        this
                    )
                if (isCopied) {
                    copyFiles.add(targetFile.path)
                }
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    preferences.refreshMedia=true
//                    runOnUiThread {
//                        val glide = Glide.get(applicationContext)
//                        glide.clearDiskCache()
//                        glide.clearMemory()
//                    }
                    finish()
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    preferences.refreshMedia=true
//                    runOnUiThread {
//                        val glide = Glide.get(applicationContext)
//                        glide.clearDiskCache()
//                        glide.clearMemory()
//                    }
                    finish()
                }
            }
    }
}