package com.gallery.photo.image.video.mainduplicate.utils

import android.app.Activity
import android.content.Context


object RatingDialog {
    fun smileyRatingDialog(activity: Context) {
//        val isRated = ExitSPHelper(activity).isRated()
//        if (!isRated) {
//            NewRateDialog(activity){
//                if (it > 3) {
//                    activity.rateApp()
//                } else if (it >= 0) {
//                    activity.sendEmail()
//                }
//            }
//           /* activity.ratingDialog(object : OnRateListener {
//                override fun onRate(rate: Int) {
//                    if (rate >= 3) {
//                        activity.rateApp()
//                    } else if (rate >= 0) {
//                        val i = Intent(activity, FeedbackActivity::class.java)
//                        i.putExtra("key_smile", rate)
//                        activity.startActivity(i)
//                    }
//                }
//            })*/
//        }
    }
}