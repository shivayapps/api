package com.gallery.photo.image.video.activities

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.adconfig.AdsConfig
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityFeedbackBinding
import java.io.File

class FeedbackActivity : BaseActivity() {

    private var message = ""
    private var message1 = ""
    private var message2 = ""
    private var message3 = ""
    private var message4 = ""
    private var message5 = ""
    private var message6 = ""
    private var select1 = false
    private var select2 = false
    private var select3 = false
    private var select4 = false
    private var select5 = false
    private var select6 = false

    lateinit var binding:ActivityFeedbackBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initListner()

    }

    private fun initListner(){

        binding.icBack.setOnClickListener {
            finish()
        }

        binding.tvMessage1.setOnClickListener {
            if (select1) {
                select1 = false
                message = ""
                binding.tvMessage1.backgroundTintList=ColorStateList.valueOf(Color.parseColor("#D3D3D3"))
                binding.tvMessage1.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            } else {
                select1 = true
                message = "\n Tag : " + binding.tvMessage1.text.toString()
                binding.tvMessage1.backgroundTintList=ColorStateList.valueOf(resources.getColor(R.color.color_primary))
                binding.tvMessage1.setTextColor(ContextCompat.getColor(this,R.color.white))
            }
            setButtonColor()

        }
        binding.tvMessage2.setOnClickListener {
            if (select2) {
                select2 = false
                message1 = ""
                binding.tvMessage2.backgroundTintList=ColorStateList.valueOf(Color.parseColor("#D3D3D3"))
                binding.tvMessage2.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            } else {
                select2 = true
                message1 = "\n Tag : " + binding.tvMessage2.text.toString()
                binding.tvMessage2.backgroundTintList=ColorStateList.valueOf(resources.getColor(R.color.color_primary))
                binding.tvMessage2.setTextColor(ContextCompat.getColor(this,R.color.white))
            }
            setButtonColor()
        }
        binding.tvMessage3.setOnClickListener {
            if (select3) {
                select3 = false
                message2 = ""
                binding.tvMessage3.backgroundTintList=ColorStateList.valueOf(Color.parseColor("#D3D3D3"))
                binding.tvMessage3.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            } else {
                select3 = true
                message2 = "\n Tag : " + binding.tvMessage3.text.toString()
                binding.tvMessage3.backgroundTintList=ColorStateList.valueOf(resources.getColor(R.color.color_primary))
                binding.tvMessage3.setTextColor(ContextCompat.getColor(this,R.color.white))
            }
            setButtonColor()
        }
        binding.tvMessage4.setOnClickListener {
            if (select4) {
                select4 = false
                message3 = ""
                binding.tvMessage4.backgroundTintList=ColorStateList.valueOf(Color.parseColor("#D3D3D3"))
                binding.tvMessage4.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            } else {
                select4 = true
                message3 = "\n Tag : " + binding.tvMessage4.text.toString()
                binding.tvMessage4.backgroundTintList=ColorStateList.valueOf(resources.getColor(R.color.color_primary))
                binding.tvMessage4.setTextColor(ContextCompat.getColor(this,R.color.white))
            }
            setButtonColor()
        }
        binding.tvMessage5.setOnClickListener {
            if (select5) {
                select5 = false
                message4 = ""
//                binding.tvMessage5.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage5.backgroundTintList=ColorStateList.valueOf(Color.parseColor("#D3D3D3"))
                binding.tvMessage5.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            } else {
                select5 = true
                message4 = "\n Tag : " + binding.tvMessage5.text.toString()
//                binding.tvMessage5.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage5.backgroundTintList=ColorStateList.valueOf(resources.getColor(R.color.color_primary))
                binding.tvMessage5.setTextColor(ContextCompat.getColor(this,R.color.white))
            }
            setButtonColor()
        }
        binding.tvMessage6.setOnClickListener {
            if (select6) {
                select6 = false
                message5 = ""
//                binding.tvMessage6.setBackgroundResource(R.drawable.feedback_un_bg)
                binding.tvMessage6.backgroundTintList=ColorStateList.valueOf(Color.parseColor("#D3D3D3"))
                binding.tvMessage6.setTextColor(ContextCompat.getColor(this,R.color.black_text))
            } else {
                select6 = true
                message5 = "\n Tag : " + binding.tvMessage6.text.toString()
//                binding.tvMessage6.setBackgroundResource(R.drawable.feedback_select_bg)
                binding.tvMessage6.backgroundTintList=ColorStateList.valueOf(resources.getColor(R.color.color_primary))
                binding.tvMessage6.setTextColor(ContextCompat.getColor(this,R.color.white))
            }
            setButtonColor()
        }

        val mailId = getReviewEmail()

        binding.tvSend.setOnClickListener {
            val message_send = binding.etMessage.text.toString()
            if (TextUtils.isEmpty(message_send) && TextUtils.isEmpty(message) && TextUtils.isEmpty(
                    message1
                ) && TextUtils.isEmpty(message2) && TextUtils.isEmpty(message3) && TextUtils.isEmpty(
                    message4
                ) && TextUtils.isEmpty(message5) && TextUtils.isEmpty(message6)
            ) {
                Toast.makeText(
                    this,
                    getString(R.string.feedback_messages_enter_validation),
                    Toast.LENGTH_SHORT
                ).show()
            } else {

                email(
                    this,
                    mailId,
                    getString(R.string.app_name),
                    message_send + "\n" + message + message1 + message2 + message3 + message4 + message5 + message6 + ""
                )
            }
        }
    }

    fun email(
        context: Context,
        emailTo: String,
        subject: String,
        emailText: String
    ) {
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        val uris = ArrayList<Uri>()
//        for (file in filePaths) {
//            val fileIn = File(file)
//            val u = FileProvider.getUriForFile(
//                applicationContext,
//                "$packageName.provider", fileIn
//            );
//            uris.add(u)
//        }
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        AdsConfig.isSystemDialogOpen=true
//        MyApplication.disabledOpenAds()
        context.startActivity(Intent.createChooser(emailIntent, "Send mail..."))
        binding.etMessage.text.clear()
        finish()
    }

    fun setButtonColor() {
        val message_send = binding.etMessage.text.toString()
        if (TextUtils.isEmpty(message_send) && TextUtils.isEmpty(message) && TextUtils.isEmpty(
                message1
            ) && TextUtils.isEmpty(message2) && TextUtils.isEmpty(message3) && TextUtils.isEmpty(
                message4
            ) && TextUtils.isEmpty(message5) && TextUtils.isEmpty(message6)
        ) {
//            binding.tvSend.setTextColor(resources.getColor(R.color.grayText))
        } else {
//            binding.tvSend.setTextColor(ContextCompat.getColor(this, R.color.black_text))
        }
    }

}