package com.gallery.photo.image.video.edit.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ItemFilterBinding
import com.gallery.photo.image.video.edit.model.FilterItem

class FilterAdapter(
    var context: Context,
    var filterList: ArrayList<FilterItem>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<FilterAdapter.ViewHolder>() {
    private var strokeBackground = context.resources.getDrawable(R.drawable.stroke_background)
    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemFilterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return filterList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvTitle.text = filterList[position].filter.name

//        holder.binding.ivImageSelect.visibility =
//            if (selectPos == position) View.VISIBLE else View.GONE
        if (selectPos == position) {
            holder.binding.tvTitle.setBackgroundColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_primary
                )
            )
            holder.binding.editorFilterFrame.background = strokeBackground
        } else {
            holder.binding.tvTitle.setBackgroundColor(Color.parseColor("#80000000"))
            holder.binding.editorFilterFrame.background = null
        }

        holder.binding.ivImage.setImageBitmap(filterList[position].bitmap)

        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            clickListener(position)
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemFilterBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}