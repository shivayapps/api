package com.gallery.photo.image.video.edit.model

import android.graphics.drawable.Drawable

data class EditData(var name: String, var icon: Drawable? , var isSelected: Boolean = true)
