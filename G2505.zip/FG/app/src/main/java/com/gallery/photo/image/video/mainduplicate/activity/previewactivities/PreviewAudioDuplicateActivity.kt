package com.gallery.photo.image.video.mainduplicate.activity.previewactivities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityPreviewAudioBinding
import com.gallery.photo.image.video.mainduplicate.BaseSimpleActivity

import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.utils.MyUtils
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants

import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class PreviewAudioDuplicateActivity : BaseActivity(), View.OnClickListener {
    var mItemDuplicateModel: ItemDuplicateModel? = null
    var mFileName: String? = null
    var mFileSize: String? = null
    var mFileType: String? = null
    var mModifiedDate: String? = null
    var mPath: String? = null
    var mAudioDuration: String? = null


    lateinit var mContext:Activity
    lateinit var binding:ActivityPreviewAudioBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        binding=ActivityPreviewAudioBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_preview_audio)

        mContext=getContext()
//        initViews()
//        initAds()
        initData()
        initActions()
        com.gallery.photo.image.video.mainduplicate.utils.MyUtils.logError("preview Audio Activity!!!")
    }


    fun getContext(): Activity {
        return this@PreviewAudioDuplicateActivity
    }

    fun initData() {
        assignValuesToWidgets()
        binding.fileName1.text = mFileName
        binding.fileName.text = mFileName
        binding.fileType.text = mFileType
        binding.fileSize.text = mFileSize
        binding.imageResolution.text = mAudioDuration
        binding.modifiedDate.text = mModifiedDate
        binding.path.text = mPath
    }

    fun initActions() {
        binding.zoomableImageView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            val lFileUri = FileProvider.getUriForFile(mContext, applicationContext.packageName + ".fileprovider", File(mPath!!))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.setDataAndType(lFileUri, "audio/*")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
        binding.backpressAudio.setOnClickListener(this)
    }

    @SuppressLint("SimpleDateFormat")
    private fun assignValuesToWidgets() {
        val b = intent.extras
        if (b != null) {
            mItemDuplicateModel = b.getSerializable("audioFile") as ItemDuplicateModel?
        }
        mFileName = com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.getFileName(mItemDuplicateModel!!.filePath)
        mFileType = com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.getExtension(mItemDuplicateModel!!.filePath)
        mFileSize = com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.getReadableFileSize(mItemDuplicateModel!!.sizeOfTheFile)
        mAudioDuration = mItemDuplicateModel!!.fileDuration
        mModifiedDate = SimpleDateFormat("MMM dd,yyyy HH:mm:ss ").format(Date(mItemDuplicateModel!!.fileDateAndTime))
        mPath = mItemDuplicateModel!!.filePath
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime < 1000) {
            return
        }
        com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        if (view.id == R.id.backpress_audio) {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}