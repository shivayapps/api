package com.gallery.photo.image.video.edit.adapter

import android.content.Context
import android.graphics.Color
import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.ItemEditBottomOptionBinding
import com.gallery.photo.image.video.edit.model.EditData


class CropOptionAdapter(
    var context: Context,
    var editList: ArrayList<EditData>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<CropOptionAdapter.ViewHolder>() {

    var selectPos = 3

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemEditBottomOptionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return editList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvOption.text = editList[position].name

        holder.binding.ivIcon.setImageDrawable(editList[position].icon)

        if (selectPos == position)
            setSelectTab(holder.binding.ivIcon, holder.binding.tvOption)
        else
            setUnSelectTab(holder.binding.ivIcon, holder.binding.tvOption)

        holder.binding.root.setOnClickListener {
            if (editList[position].isSelected) {
                val p = selectPos
                selectPos = position
                notifyItemChanged(selectPos)
                if (p != -1)
                    notifyItemChanged(p)
                clickListener(position)
            } else
                clickListener(position)
        }
    }

    class ViewHolder(var binding: ItemEditBottomOptionBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    private fun setSelectTab(imageView: ImageView, textView: TextView) {
//        val selectColor = ContextCompat.getColor(context, R.color.black_text)
        val selectColor = Color.parseColor("#FFFFFF")
        imageView.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        textView.setTextColor(selectColor)
    }

    private fun setUnSelectTab(imageView: ImageView, textView: TextView) {
//        val selectColor = ContextCompat.getColor(context, R.color.home_unSelect_tab_icon)
        val selectColor = Color.parseColor("#9B9999")
        imageView.setColorFilter(selectColor, PorterDuff.Mode.SRC_IN)
        textView.setTextColor(selectColor)
    }
}