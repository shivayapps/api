package com.gallery.photo.image.video.photoeditor


enum class ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}