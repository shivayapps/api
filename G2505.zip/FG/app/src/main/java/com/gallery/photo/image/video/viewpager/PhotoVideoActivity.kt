package com.gallery.photo.image.video.viewpager

import android.animation.Animator
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipDescription
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.WorkerThread
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.util.UnstableApi
import androidx.viewpager.widget.ViewPager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.gallery.photo.image.video.BuildConfig
//import com.autotest.photo.editor.activities.PolishEditorActivity
//import com.autotest.photo.editor.polish.PolishPickerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activities.SetWallpaperActivity
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.ActivityPhotoVideoBinding
import com.gallery.photo.image.video.databinding.PopMenuImageBinding

import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.dialog.DeleteDialog
import com.gallery.photo.image.video.dialog.DetailsDialog
import com.gallery.photo.image.video.dialog.RenameDialog
import com.gallery.photo.image.video.dialog.ResizeDialog
import com.gallery.photo.image.video.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.dialog.SelectAlbumFullDialog
import com.gallery.photo.image.video.dialog.SlideshowDialog
import com.gallery.photo.image.video.event.DisplayDeleteEvent
import com.gallery.photo.image.video.event.RestoreDataEvent
import com.gallery.photo.image.video.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.extension.actionBarHeight
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beGoneIf
import com.gallery.photo.image.video.extension.beVisible
import com.gallery.photo.image.video.extension.beVisibleIf
import com.gallery.photo.image.video.extension.deleteEmptyFolders
import com.gallery.photo.image.video.extension.getFilenameFromPath
import com.gallery.photo.image.video.extension.getMimeType
import com.gallery.photo.image.video.extension.getParentPath
import com.gallery.photo.image.video.extension.getResolution
import com.gallery.photo.image.video.extension.hideSystemUI
import com.gallery.photo.image.video.extension.isGif
import com.gallery.photo.image.video.extension.isImageFast
import com.gallery.photo.image.video.extension.isPackageInstalled
import com.gallery.photo.image.video.extension.isPortrait
import com.gallery.photo.image.video.extension.isVideoFast
import com.gallery.photo.image.video.extension.navigationBarHeight
import com.gallery.photo.image.video.extension.onGlobalLayout
import com.gallery.photo.image.video.extension.openEditorIntent
import com.gallery.photo.image.video.extension.showSystemUI
import com.gallery.photo.image.video.extension.statusBarHeight
import com.gallery.photo.image.video.extension.toast
import com.gallery.photo.image.video.extension.updateStatusBarColor
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.model.RestoreData
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Constant.ROTATE_BY_DEVICE_ROTATION
import com.gallery.photo.image.video.utils.Constant.ROTATE_BY_SYSTEM_SETTING
import com.gallery.photo.image.video.utils.PopupWindowHelper
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.SLIDESHOW_ANIMATION_NONE
import com.gallery.photo.image.video.utils.SLIDESHOW_FADE_DURATION
//import com.gallery.photo.image.video.utils.TYPE_PORTRAITS
//import com.gallery.photo.image.video.utils.TYPE_RAWS
//import com.gallery.photo.image.video.utils.TYPE_SVGS
import com.gallery.photo.image.video.utils.Utils
import com.gallery.photo.image.video.utils.WindowHelper
import com.gallery.photo.image.video.utils.isPiePlus
import com.gallery.photo.image.video.utils.isRPlus
import com.gallery.photo.image.video.utils.isUpsideDownCakePlus
import com.gallery.photo.image.video.utils.transformation.BackgroundToForeground
import com.gallery.photo.image.video.utils.transformation.CubeIn
import com.gallery.photo.image.video.utils.transformation.CubeOut
import com.gallery.photo.image.video.utils.transformation.DefaultPageTransformer
import com.gallery.photo.image.video.utils.transformation.DepthSlide
import com.gallery.photo.image.video.utils.transformation.FlipHorizontal
import com.gallery.photo.image.video.utils.transformation.FlipVertical
import com.gallery.photo.image.video.utils.transformation.ForegroundToBackground
import com.gallery.photo.image.video.utils.transformation.Gate
import com.gallery.photo.image.video.utils.transformation.RotateDown
import com.gallery.photo.image.video.utils.transformation.RotateUp
import com.gallery.photo.image.video.utils.transformation.Toss
import com.gallery.photo.image.video.utils.transformation.ZoomIn
import com.gallery.photo.image.video.utils.transformation.ZoomOut
import com.gallery.photo.image.video.wallpaperlib.SetWallpaper
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.min

@UnstableApi
class PhotoVideoActivity : AppCompatActivity(), ViewPager.OnPageChangeListener,
    ViewPagerFragment.FragmentListener {

    var displayImageList: ArrayList<PictureData> = ArrayList()

    var selectedPosition = 0
    var isFromPrivate = false
    var isFromRecentlyDelete = false
    val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
    val formatTime = SimpleDateFormat("hh:mm aa", Locale.ENGLISH)

    private var mSlideshowHandler = Handler()
    var mSlideshowInterval = 3000
    private var mRandomSlideshowStopped = false
    private var mSlideshowMoveBackwards = false
    private var mIsOrientationLocked = false
    private var mIsSlideshowActive = false
    var isFileExists: Boolean = false
    var currentFilePath: String = ""
    private var mAreSlideShowMediaVisible = false
    lateinit var preferences: Preferences
    var mIsVideo = false
    var isLensInstalled = false

    lateinit var pagerAdapter: MyPagerAdapter
    lateinit var binding: ActivityPhotoVideoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityPhotoVideoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()
        updateStatusBarColor(Color.parseColor("#131624"))
        if (preferences.maxBrightness) {
            val attributes = window.attributes
            attributes.screenBrightness = 1f
            window.attributes = attributes
        }

        setupOrientation()
        initWindowInsetsController()

//        if (savedInstanceState != null) {
        isFromRecentlyDelete = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_RECENTLY_DELETE, false)
        isFromPrivate = intent.getBooleanExtra("isFromPrivate", false)
//        }
        intView()

        hideSystemUI()
    }

    override fun onDestroy() {
        super.onDestroy()
//        Constant.displayImageList.clear()
    }

    var isAdLoaded = false
    var mAdView:AdView?=null
    private fun loadBanner() {

        if (!isAdLoaded) {

            val isFirstSession = preferences.splashCounter == 1
            val adId = getString(R.string.b_photoVideoActivity)

            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.frameAd, adId,
                if (isFromPrivate) AdCache.privateViewerAdView
                else AdCache.photoVideoAdView,
                { isLoaded, adView, message ->
                    mAdView=adView
                    if (isFromPrivate) AdCache.privateViewerAdView = adView
                    else AdCache.photoVideoAdView = adView
//                AdCache.photoVideoAdView=adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun intView() {
        try {
            selectedPosition = Constant.selectedPosition
            displayImageList.addAll(Constant.displayImageList)

            setBottomVisible()

            binding.ivFavourite.visibility =
                if (isFromRecentlyDelete || isFromPrivate) View.GONE else View.VISIBLE
            binding.btnHide.beGoneIf(isFromPrivate)
            binding.btnEdit.beGoneIf(isFromPrivate)
            binding.btnUnhide.beVisibleIf(isFromPrivate)

            mPath = displayImageList[selectedPosition].filePath

            initContinue()
            viewPagerSetup()
            intListener()
            checkNotchSupport()
            initActionsLayout()
        } catch (e:Exception) {
            finish()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        var bottom = resources.getDimension(R.dimen.bottom_actions_height)
//        if (preferences.bottomActions) {
//            bottom += resources.getDimension(R.dimen.bottom_actions_height).toInt()
//        }

//        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE && activity?.hasNavBar() == true) {
//        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//            bottom = 0f
////            binding.llNav.layoutParams.height = navigationBarHeight
//            binding.llNav.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt()
////            binding.frameAd.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt()
//        } else {
////            binding.llNav.layoutParams.height = navigationBarHeight
//            binding.llNav.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
////            binding.frameAd.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
//        }

//        (binding.llBottomOption.layoutParams as RelativeLayout.LayoutParams).apply {
//            bottomMargin = bottom.roundToInt()
////            rightMargin = right
//        }
    }

    private fun initActionsLayout() {
        binding.llNav.layoutParams.height = navigationBarHeight
        binding.loutToolbar.layoutParams.height = statusBarHeight + actionBarHeight
//        binding.loutBottomMainOption.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
//        binding.frameBanner.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
//        if (preferences.bottomActions) {
        binding.llBottomOption.beVisible()
//        } else {
//            binding.bottomActions.root.beGone()
//        }

        fragmentClicked()
    }

    private fun initContinue() {
        setTitles(selectedPosition)

        binding.viewPager.onGlobalLayout {
            if (!isDestroyed) {
                if (displayImageList.isNotEmpty()) {
                    gotMedia(
                        displayImageList as ArrayList<PictureData>,
                        refetchViewPagerPosition = true
                    )
//                    checkSlideshowOnEnter()
                }
            }
        }

        // show the selected image asap, while loading the rest in the background to allow swiping between them. Might be needed at third party intents
//        if (displayImageList.isEmpty() && mPath.isNotEmpty() && mDirectory != FAVORITES) {
        if (displayImageList.isEmpty() && mPath.isNotEmpty()) {
            val filename = mPath.getFilenameFromPath()
            val folder = mPath.getParentPath()
//            val type = getTypeFromPath(mPath)
//            val medium = Medium(null, filename, mPath, folder, 0, 0, 0, type, 0, false, 0L, 0L)
            val medium = PictureData(
                filePath = mPath, fileName = filename, folderName = folder,
                date = 0,
                dateTaken = 0,
                fileSize = 0,
                isVideo = mPath.isVideoFast(),
                videoDuration = 0,
                bucketPath = "",
                isSelected = false,
                isCheckboxVisible = false,
                isFavorite = false,
                isPrivate = false,
                restorePath = "",
                idDataBase = 0L
            )
            displayImageList.add(medium)
            gotMedia(displayImageList as ArrayList<PictureData>, refetchViewPagerPosition = true)
        }

        refreshViewPager(true)
        binding.viewPager.offscreenPageLimit = 2


        if (preferences.maxBrightness) {
            val attributes = window.attributes
            attributes.screenBrightness = 1f
            window.attributes = attributes
        }

        if (preferences.hideSystemUI) {
            binding.viewPager.onGlobalLayout {
                Handler(Looper.getMainLooper()).postDelayed({
                    fragmentClicked()
                }, 500)
            }
        }

    }

    private var mPrevHashcode = 0

    private var mFavoritePaths = ArrayList<String>()
    private var mIgnoredPaths = ArrayList<String>()

//    private fun getTypeFromPath(path: String): Int {
//        return when {
//            path.isVideoFast() -> TYPE_VIDEOS
//            path.isGif() -> TYPE_GIFS
//            path.isSvg() -> TYPE_SVGS
//            path.isRawFast() -> TYPE_RAWS
//            path.isPortrait() -> TYPE_PORTRAITS
//            else -> TYPE_IMAGES
//        }
//    }

    private fun isDirEmpty(media: ArrayList<PictureData>): Boolean {
        return if (media.isEmpty()) {
            deleteDirectoryIfEmpty()
            finish()
            true
        } else {
            false
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (preferences.deleteEmptyFolders) {
            val fileDirItem = File(mDirectory)
            if (fileDirItem.isDirectory) {
                fileDirItem.deleteEmptyFolders(this)
            }
        }
    }


    private fun refreshViewPager(refetchPosition: Boolean = false) {
//        val isRandomSorting = config.getFolderSorting(mDirectory) and SORT_BY_RANDOM != 0
//        if (!isRandomSorting) {
//            GetMediaAsynctask(applicationContext, mDirectory, isPickImage = false, isPickVideo = false, showAll = mShowAll) {
//                gotMedia(it, refetchViewPagerPosition = refetchPosition)
//            }.execute()
//        }
    }

    private fun gotMedia(
        thumbnailItems: ArrayList<PictureData>,
        ignorePlayingVideos: Boolean = false,
        refetchViewPagerPosition: Boolean = false
    ) {
        val media = thumbnailItems.asSequence().filter {
            it is PictureData && !mIgnoredPaths.contains(it.filePath)
        }.map { it as PictureData }.toMutableList() as ArrayList<PictureData>

        if (isDirEmpty(media) || media.hashCode() == mPrevHashcode) {
            return
        }

        val isPlaying = (getCurrentFragment() as? PagerVideoFragment)?.mIsPlaying == true
        if (!ignorePlayingVideos && isPlaying) {
            return
        }

        refreshUI(media, refetchViewPagerPosition)
    }

    private fun refreshUI(media: ArrayList<PictureData>, refetchViewPagerPosition: Boolean) {
        mPrevHashcode = media.hashCode()
        displayImageList = media

        if (refetchViewPagerPosition || mPos == -1) {
            mPos = getPositionInList(media)
            if (mPos == -1) {
                min(mPos, media.lastIndex)
            }
        }

//        updateActionbarTitle()
        updatePagerItems(displayImageList.toMutableList())

        refreshMenuItems()
        checkOrientation()
//        initBottomActions()
    }

    private fun setBottomVisible() {
        binding.ivFavourite.visibility =
            if (isFromRecentlyDelete || isFromPrivate) View.GONE else View.VISIBLE
        binding.loutBottomMainOption.visibility =
            if (isFromRecentlyDelete) View.GONE else View.VISIBLE
        binding.loutReCentDeleteOption.visibility =
            if (isFromRecentlyDelete) View.VISIBLE else View.GONE
    }

    private fun startSlideShow() {

        binding.loutToolbar.setVisibility(View.GONE)
        binding.llBottomOption.visibility = View.GONE
        binding.loutReCentDeleteOption.visibility = View.GONE

        if (!isDestroyed) {
            val effect = preferences.getInt(Constant.PREF_SLIDE_EFFECT)
//            if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) == SLIDESHOW_ANIMATION_FADE) {

            if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) != SLIDESHOW_ANIMATION_NONE) {
//                setSlideAnimation(Constant.AnimationTypes.entries[effect])
                setSlideAnimation(effect)
//                binding.viewPager.setPageTransformer(false, FadePageTransformer())
            }
            enterImmersiveMode()
            mRandomSlideshowStopped = false
            mSlideshowInterval = preferences.getInt(Constant.PREF_SLIDE_TIME, 1)
            mSlideshowMoveBackwards = preferences.getBoolean(Constant.PREF_SLIDE_BACKWARD)
            mIsSlideshowActive = true
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            scheduleSwipe()
        }

    }

    //    fun setSlideAnimation(animationType: Constant.AnimationTypes){
    fun setSlideAnimation(animationType: Int) {

        when (animationType) {
            Constant.AnimationTypes.NONE.id -> {
//                binding.viewPager!!.setPageTransformer(true, ZoomIn())
//                binding.viewPager!!.setPageTransformer(true, ZoomIn())
            }

            Constant.AnimationTypes.ZOOM_IN.id -> {
                binding.viewPager!!.setPageTransformer(true, ZoomIn())
            }

            Constant.AnimationTypes.ZOOM_OUT.id -> {
                binding.viewPager!!.setPageTransformer(true, ZoomOut())
            }

            Constant.AnimationTypes.DEPTH_SLIDE.id -> {
                binding.viewPager!!.setPageTransformer(true, DepthSlide())
            }

            Constant.AnimationTypes.CUBE_IN.id -> {
                binding.viewPager!!.setPageTransformer(true, CubeIn())
            }

            Constant.AnimationTypes.CUBE_OUT.id -> {
                binding.viewPager!!.setPageTransformer(true, CubeOut())
            }

            Constant.AnimationTypes.FLIP_HORIZONTAL.id -> {
                binding.viewPager!!.setPageTransformer(true, FlipHorizontal())
            }

            Constant.AnimationTypes.FLIP_VERTICAL.id -> {
                binding.viewPager!!.setPageTransformer(true, FlipVertical())
            }

            Constant.AnimationTypes.ROTATE_UP.id -> {
                binding.viewPager!!.setPageTransformer(true, RotateUp())
            }

            Constant.AnimationTypes.ROTATE_DOWN.id -> {
                binding.viewPager!!.setPageTransformer(true, RotateDown())
            }

            Constant.AnimationTypes.FOREGROUND_TO_BACKGROUND.id -> {
                binding.viewPager!!.setPageTransformer(true, ForegroundToBackground())
            }

            Constant.AnimationTypes.BACKGROUND_TO_FOREGROUND.id -> {
                binding.viewPager!!.setPageTransformer(true, BackgroundToForeground())
            }

            Constant.AnimationTypes.TOSS.id -> {
                binding.viewPager!!.setPageTransformer(true, Toss())
            }

            Constant.AnimationTypes.GATE.id -> {
                binding.viewPager!!.setPageTransformer(true, Gate())
            }

            else -> {
//                binding.viewPager!!.setPageTransformer(true, FidgetSpinner())
            }
        }
    }

    private fun getCurrentMedium(): PictureData? {
        return if (displayImageList.isEmpty() || mPos == -1) {
            null
        } else {
            displayImageList[min(mPos, displayImageList.lastIndex)]
        }
    }

    private fun scheduleSwipe() {
        mSlideshowHandler.removeCallbacksAndMessages(null)
        Log.d("PhotoVideoActivity", "scheduleSwipe : $mIsSlideshowActive $mSlideshowInterval")
        if (mIsSlideshowActive) {
            if (getCurrentMedium()!!.filePath.isImageFast() || getCurrentMedium()!!.filePath.isGif() || getCurrentMedium()!!.filePath.isPortrait()) {
                mSlideshowHandler.postDelayed({
                    if (mIsSlideshowActive && !isDestroyed) {
                        swipeToNextMedium()
                    }
                }, mSlideshowInterval * 1000L)
            } else {
                (getCurrentFragment() as? PagerVideoFragment)!!.playVideo()
            }
        }
    }

    private fun getCurrentFragment() =
        (binding.viewPager.adapter as? MyPagerAdapter)?.getCurrentFragment(binding.viewPager.currentItem)

    private fun goToNextMedium(forward: Boolean) {
        Log.d("PhotoVideoActivity", "goToNextMedium : $forward")
        val oldPosition = binding.viewPager.currentItem
        val newPosition = if (forward) oldPosition + 1 else oldPosition - 1
        if (newPosition == -1 || newPosition > binding.viewPager.adapter!!.count - 1) {
            slideshowEnded(forward)
        } else {
            binding.viewPager.setCurrentItem(newPosition, false)
        }
    }

    private fun slideshowEnded(forward: Boolean) {
        if (preferences.getBoolean(Constant.PREF_SLIDE_LOOP)) {
            if (forward) {
                binding.viewPager.setCurrentItem(0, false)
            } else {
                binding.viewPager.setCurrentItem(binding.viewPager.adapter!!.count - 1, false)
            }
        } else {
            stopSlideshow()
            toast(R.string.slideshow_ended)
        }
    }

    private fun stopSlideshow() {
        if (mIsSlideshowActive) {
            binding.viewPager.setPageTransformer(false, DefaultPageTransformer())
//            binding.viewPager.setPageTransformer(null)
            mIsSlideshowActive = false
            exitImmersiveMode()
            mSlideshowHandler.removeCallbacksAndMessages(null)
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            mAreSlideShowMediaVisible = false

            if (preferences.getBoolean(Constant.PREF_SLIDE_RANDOM_ORDER)) {
                mRandomSlideshowStopped = true
            }
        }
    }

    private fun swipeToNextMedium() {
        if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) == SLIDESHOW_ANIMATION_NONE) {
            goToNextMedium(!mSlideshowMoveBackwards)
        } else {
            animatePagerTransition(!mSlideshowMoveBackwards)
        }
    }

    private var mPath = ""
    private var mDirectory = ""

    //    private var mIsFullScreen = false
    private var mIsFullScreen = true
    private var mPos = -1
    private var mSlideshowMedia = mutableListOf<PictureData>()
    private fun getMediaForSlideshow(): Boolean {
        mSlideshowMedia = displayImageList.filter {
            it.filePath.isImageFast() || it.filePath.isPortrait() || (preferences.getBoolean(
                Constant.PREF_SLIDE_INCLUDE_VIDEO
            ) && it.filePath.isVideoFast() || (preferences.getBoolean(Constant.PREF_SLIDE_INCLUDE_GIF) && it.filePath.isGif()))
        }.toMutableList()

        if (preferences.getBoolean(Constant.PREF_SLIDE_RANDOM_ORDER)) {
            mSlideshowMedia.shuffle()
            mPos = 0
        } else {
            mPath = getCurrentPath()
            mPos = getPositionInList(mSlideshowMedia)
        }

        return if (mSlideshowMedia.isEmpty()) {
            toast(R.string.no_media_for_slideshow)
            false
        } else {
            updatePagerItems(mSlideshowMedia)
            mAreSlideShowMediaVisible = true
            true
        }
    }


    private fun getCurrentPath() = getCurrentMedium()?.filePath ?: ""

    private fun getPositionInList(items: MutableList<PictureData>): Int {
        mPos = 0
        for ((i, medium) in items.withIndex()) {
//            val portraitPath = getPortraitPath()
//            val portraitPath = ""
//            if (portraitPath != "") {
//                val portraitPaths = File(portraitPath).parentFile?.list()
//                if (portraitPaths != null) {
//                    for (path in portraitPaths) {
//                        if (medium.fileName == path) {
//                            return i
//                        }
//                    }
//                }
//            } else
            if (medium.filePath.equals(mPath, true)) {
                return i
            }
        }
        return mPos
    }

//    private fun getPortraitPath() = intent.getStringExtra("PORTRAIT_PATH") ?: ""

    private fun updatePagerItems(media: MutableList<PictureData>) {
        pagerAdapter = MyPagerAdapter(this, supportFragmentManager, media)

        if (!isDestroyed) {
            pagerAdapter.shouldInitFragment = mPos < 5
            binding.viewPager.apply {
                // must remove the listener before changing adapter, otherwise it might cause `mPos` to be set to 0
                removeOnPageChangeListener(this@PhotoVideoActivity)
                adapter = pagerAdapter
                pagerAdapter.shouldInitFragment = true
                addOnPageChangeListener(this@PhotoVideoActivity)
                currentItem = mPos
            }
        }
    }

    override fun onBackPressed() {

        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }


    fun openEditor(path: String) {
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.ivInfo.setOnClickListener {
            showDetailsDialog()
        }
//        binding.btnEdit.beGone()
        binding.btnEdit.setOnClickListener {
            if (isFileExists) {
                openEditor(displayImageList[binding.viewPager.currentItem].filePath)
            } else {
                showToastMsg(getString(R.string.corrupted_image_edit))
            }
        }
        binding.btnDelete.setOnClickListener {
            if (isFileExists)
                showDeleteDialog()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_delete)
                    else getString(R.string.corrupted_image_delete)
                )
        }
        binding.btnUnhide.setOnClickListener {
            if (isFileExists)
                setUnHideData()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_unhide)
                    else getString(R.string.corrupted_image_unhide)
                )
        }
        binding.btnHide.setOnClickListener {

            if (isFileExists)
                setHideData()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_hide)
                    else getString(R.string.corrupted_image_hide)
                )
        }
        binding.btnMore.setOnClickListener {
//            showMenu()
            showDropDown(binding.btnMore)
//            getPowerMenu(this, binding.btnMore)
        }

        setUpLensIcon()

        binding.btnLens.setOnClickListener {
            val uri = FileProvider.getUriForFile(
                this,
                "${packageName}.provider",
                File(displayImageList[binding.viewPager.currentItem].filePath)
            )
            AdsConfig.isSystemDialogOpen = true
            startActivity(getLensIntentForImageUri(uri))
        }
        binding.btnShare.setOnClickListener {
            Utils.shareFile(
                this@PhotoVideoActivity,
                displayImageList[binding.viewPager.currentItem].filePath
            )
        }
        binding.ivFavourite.setOnClickListener {
            if (displayImageList[binding.viewPager.currentItem].isFavorite) {
                displayImageList[binding.viewPager.currentItem].isFavorite = false
                setFavImages(binding.viewPager.currentItem)
                setUnFavorite(displayImageList[binding.viewPager.currentItem].filePath)
            } else {
                displayImageList[binding.viewPager.currentItem].isFavorite = true
                setFavImages(binding.viewPager.currentItem)
                setFavorite(displayImageList[binding.viewPager.currentItem].filePath)
            }
        }
        binding.btnRestore.setOnClickListener {
            if (isFileExists) {
                val hideDialog = ConfirmationDialog(
                    this,
                    getString(R.string.restore),
                    getString(R.string.restore_msg_single),
                    getString(R.string.ok),
                    positiveBtnClickListener = {
                        restorePhoto()

                    })
                hideDialog.show(supportFragmentManager, hideDialog.tag)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_restore)
                    else getString(R.string.corrupted_image_restore)
                )
        }
        binding.btnRecentDelete.setOnClickListener {
            if (isFileExists) {
                val deleteDialog = ConfirmationDialog(
                    this,
                    getString(R.string.delete_permanently),
                    getString(R.string.permanently_delete_msg_single),
                    getString(R.string.Delete),
                    positiveBtnClickListener = {
                        recentDeletePhoto()
                    }, true
                )
                deleteDialog.show(supportFragmentManager, deleteDialog.tag)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_delete)
                    else getString(R.string.corrupted_image_delete)
                )
        }

//        binding.btnRename.setOnClickListener {
//            if (isFileExists)
//                showRenameDialog()
//            else
//                showToastMsg(
//                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_rename)
//                    else getString(R.string.corrupted_image_rename)
//                )
//        }
    }

    val LENS_PACKAGE = "com.google.ar.lens"
    val LENS_ACTIVITY = "com.google.vr.apps.ornament.app.lens.LensLauncherActivity"
    private fun setUpLensIcon() {
        val lensIntent = Intent.makeMainActivity(ComponentName(LENS_PACKAGE, LENS_ACTIVITY))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        if (packageManager.resolveActivity(lensIntent, 0) == null) return
//
//        isLensInstalled = isPackageInstalled(LENS_PACKAGE)
        isLensInstalled = true
        binding.btnLens.beVisibleIf(isLensInstalled)
//        binding.btnLens.beVisible()

        Log.e("PhotoVideo", "setUpLensIcon:$LENS_PACKAGE->$isLensInstalled")
    }

    //    @UiThread
    //    public static void startLensActivity(Context context, Supplier<Bitmap> bitmapSupplier,
    //            Rect crop, Intent intent, String tag) {
    //        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
    //            if (bitmapSupplier.get() == null) {
    //                Log.e(tag, "No snapshot available, not starting share.");
    //                return;
    //            }
    //        }
    //
    //        UI_HELPER_EXECUTOR.execute(() -> persistBitmapAndStartActivity(context,
    //                bitmapSupplier.get(), crop, intent, ImageActionUtils::getLensIntentForImageUri,
    //                tag));
    //    }
    //    @WorkerThread
    //    public static Uri getImageUri(Bitmap bitmap, Rect crop, Context context, String tag) {
    //        clearOldCacheFiles(context);
    //        Bitmap croppedBitmap = cropBitmap(bitmap, crop);
    //        int cropHash = crop == null ? 0 : crop.hashCode();
    //        String baseName = BASE_NAME + bitmap.hashCode() + "_" + cropHash + ".png";
    //        File parent = new File(context.getCacheDir(), SUB_FOLDER);
    //        parent.mkdir();
    //        File file = new File(parent, baseName);
    //
    //        try (FileOutputStream fos = new FileOutputStream(file)) {
    //            croppedBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
    //        } catch (IOException e) {
    //            Log.e(tag, "Error saving image", e);
    //        }
    //
    //        return FileProvider.getUriForFile(context, AUTHORITY, file);
    //    }
    private fun getShareIntentForImageUri(uri: Uri, mIntent: Intent): Intent {
        var intent = Intent()
        if (mIntent != null) {
            intent = mIntent
        }
        val clipdata = ClipData(
            ClipDescription("content", arrayOf("image/png")),
            ClipData.Item(uri)
        )
        intent.setAction(Intent.ACTION_SEND)
            .setComponent(null)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri).clipData = clipdata
        return Intent.createChooser(intent, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//        return intent
    }

    @WorkerThread
    fun getLensIntentForImageUri(uri: Uri): Intent {
        val intent = Intent()
        intent.setPackage("com.google.ar.lens")
        return getShareIntentForImageUri(uri, intent)
    }

    protected fun checkNotchSupport() {
        if (isPiePlus()) {
            val cutoutMode = when {
                preferences.showNotch -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                else -> WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER
            }

            window.attributes.layoutInDisplayCutoutMode = cutoutMode
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            if (preferences.showNotch) {
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            }
        }
    }

    private fun showToastMsg(msg: String) {
        toast(msg)
    }

    private fun showDropDown(anchor: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopMenuImageBinding.inflate(layoutInflater)

        val popupWindow =
            com.gallery.photo.image.video.utils.PopupWindowHelper(popUpBinding.root)
        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        if (isFromPrivate) {
            popUpBinding.menuCopy.visibility = View.GONE
            popUpBinding.menuMove.visibility = View.GONE
            popUpBinding.menuRename.visibility = View.GONE
            popUpBinding.menuResize.visibility = View.GONE
        } else {
            popUpBinding.menuCopy.visibility = View.VISIBLE
            popUpBinding.menuMove.visibility = View.VISIBLE
        }

        if (displayImageList[binding.viewPager.currentItem].isVideo || displayImageList[binding.viewPager.currentItem].filePath.isGif()) {
//            popUpBinding.menuRename.beGone()
            popUpBinding.menuResize.beGone()
            popUpBinding.menuSetWallpaper.beGone()
        } else {
//            popUpBinding.menuRename.beVisible()
            if(!isFromPrivate) {
                popUpBinding.menuResize.beVisible()
            }
            popUpBinding.menuSetWallpaper.beVisible()
        }

        popupWindow.showAsPopUp(anchor)

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists) {
                showAddAlbumDialog(Constant.deviceAlbumList, true)
//                showAddAlbumDialog(Constant.albumList, true)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_copy)
                    else getString(R.string.corrupted_image_copy)
                )
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists) {
                showAddAlbumDialog(Constant.deviceAlbumList, false)
//                showAddAlbumDialog(Constant.albumList, false)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_move)
                    else getString(R.string.corrupted_image_move)
                )
        }
        popUpBinding.menuSetWallpaper.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists) {

//                if (isUpsideDownCakePlus()) {
//                } else {

                val intent = Intent(this@PhotoVideoActivity, SetWallpaperActivity::class.java)
                intent.putExtra(
                    Constant.EXTRA_WALL_PAPER,
                    displayImageList[binding.viewPager.currentItem].filePath
                )
                startActivity(intent)
//                intentLauncher.launch(intent)
//                }

//                val realPath = displayImageList[binding.viewPager.currentItem].filePath
//                SetWallpaper.setWallpaper(this,realPath,BuildConfig.APPLICATION_ID + ".provider")
//                val uri = FileProvider.getUriForFile(
//                    this,
//                    BuildConfig.APPLICATION_ID + ".provider",
//                    File(realPath)
//                );
//
//                val intent = Intent(Intent.ACTION_ATTACH_DATA)
//                intent.addCategory(Intent.CATEGORY_DEFAULT)
//                intent.setDataAndType(uri, "image/jpeg")
//                intent.putExtra("mimeType", "image/jpeg")
//                startActivity(Intent.createChooser(intent, "Set as:"))

            } else
                showToastMsg(getString(R.string.corrupted_image_wallpaper))
        }


        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                showRenameDialog()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_rename)
                    else getString(R.string.corrupted_image_rename)
                )
        }
        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                showResizeDialog()
            else
                showToastMsg(getString(R.string.corrupted_image_resize))
        }
        popUpBinding.menuStartSlideshow.setOnClickListener {
            popupWindow.dismiss()

            val slideshowDialog = SlideshowDialog(updateListener = {
                startSlideShow()
            })
            slideshowDialog.show(supportFragmentManager, slideshowDialog.tag)
        }
    }


    var intentLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
//            if (preferences.refreshMedia) {
//
//            }
        }


    private fun animatePagerTransition(forward: Boolean) {
        Log.d("PhotoVideoActivity", "animatePagerTransition : animatePagerTransition")
        val oldPosition = binding.viewPager.currentItem
        val animator = ValueAnimator.ofInt(0, binding.viewPager.width)
        animator.addListener(object : Animator.AnimatorListener {
            override fun onAnimationEnd(animation: Animator) {
                if (binding.viewPager.isFakeDragging) {
                    try {
                        binding.viewPager.endFakeDrag()
                    } catch (ignored: Exception) {
                        stopSlideshow()
                    }

                    if (binding.viewPager.currentItem == oldPosition) {
                        slideshowEnded(forward)
                    }
                }
            }

            override fun onAnimationCancel(animation: Animator) {
                binding.viewPager.endFakeDrag()
            }

            override fun onAnimationStart(animation: Animator) {}

            override fun onAnimationRepeat(animation: Animator) {}
        })

//        if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) == SLIDESHOW_ANIMATION_SLIDE) {
//            animator.interpolator = DecelerateInterpolator()
//            animator.duration = SLIDESHOW_SLIDE_DURATION
//        } else {
        animator.duration = SLIDESHOW_FADE_DURATION
//        }

        animator.addUpdateListener(object : ValueAnimator.AnimatorUpdateListener {
            var oldDragPosition = 0
            override fun onAnimationUpdate(animation: ValueAnimator) {
                if (binding.viewPager.isFakeDragging == true) {
                    val dragPosition = animation.animatedValue as Int
                    val dragOffset = dragPosition - oldDragPosition
                    oldDragPosition = dragPosition
                    try {
                        binding.viewPager.fakeDragBy(dragOffset * (if (forward) -1f else 1f))
                    } catch (e: Exception) {
                        stopSlideshow()
                    }
                }
            }
        })

        binding.viewPager.beginFakeDrag()
        animator.start()
    }


    private fun showRenameDialog() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val renameDialog =
            RenameDialog(
                this,
                pictureData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    val file = File(renamePath)
                    displayImageList[binding.viewPager.currentItem].filePath = renamePath
                    displayImageList[binding.viewPager.currentItem].fileName = file.name
//                    pagerAdapter.notifyDataSetChanged()
                    refreshUI(displayImageList, true)
                })
        renameDialog.show(supportFragmentManager, renameDialog.tag)
    }

    private fun showResizeDialog() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val resizeDialog =
            ResizeDialog(
                this,
                pictureData,
                updateImageListener = { path ->
                    val file = File(path)
                    displayImageList.add(
                        0,
                        PictureData(
                            path,
                            file.name,
                            file.parentFile.path,
                            file.lastModified(),
                            file.lastModified(),
                            file.length()
                        )
                    )
                    refreshUI(displayImageList, true)
                })
        resizeDialog.show(supportFragmentManager, resizeDialog.tag)
    }

    private fun setHideData() {
        val hideDialog = ConfirmationDialog(
            this,
            getString(R.string.Private),
            getString(R.string.hide_msg_single),
            getString(R.string.hide),
            positiveBtnClickListener = {
                hidePhoto()
            })
        hideDialog.show(supportFragmentManager, hideDialog.tag)
    }

    private fun hidePhoto() {
        Log.e("hidePhoto", "displaySize.001:" + displayImageList.size)
        val selectImage: ArrayList<PictureData> = ArrayList()
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        selectImage.add(pictureData)

        Utils.hideFiles(this, selectImage, selectImage.size, hideListener = {

            toast(getString(R.string.hide_successfully))
            displayImageList.removeAt(i)
            if (displayImageList.size != 0)
                pagerAdapter.notifyDataSetChanged()
            Log.e("hidePhoto", "displaySize.002:" + displayImageList.size)
            if (displayImageList.size == 0) {
                finish()
            } else if (i < displayImageList.size - 1) {
                selectedPosition = i
                binding.viewPager.currentItem = selectedPosition
                viewPagerSetup()
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            } else {
                if (i != 0)
                    selectedPosition = i - 1
                binding.viewPager.currentItem = selectedPosition
                viewPagerSetup()
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            }
        })
    }

    private fun showAddAlbumDialog(albumList: java.util.ArrayList<AlbumData>, isCopy: Boolean) {
        val selectImage: ArrayList<PictureData> = ArrayList()
        val selectedAlbum: ArrayList<AlbumData> = ArrayList()

        val pictureData = displayImageList[binding.viewPager.currentItem]
        selectImage.add(pictureData)

        val addAlbumDialog =
            SelectAlbumDialog(
                this,
                albumList,
                selectedAlbum,
                isCopy,
                selectPathListener = { selectPath ->
                    setCopyMove(isCopy, selectPath, selectImage)
                },
                createAlbumListener = {
                    val createDialog = CreateAlbumDialog(this, createPathListener = {
                        setCopyMove(isCopy, it, selectImage)
                    })
                    createDialog.show(supportFragmentManager, createDialog.tag)
                })
        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        val i = binding.viewPager.currentItem
        if (isCopy)
            Utils.copyFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {

                    toast(getString(R.string.copy_successfully1))
                })
        else
            Utils.moveFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {

                    toast(getString(R.string.move_successfully1))
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    displayImageList.removeAt(binding.viewPager.currentItem)
//                    if (displayImageList.size != 0)
//                        adapter.notifyDataSetChanged()
                    if (displayImageList.size == 0) {
                        finish()
                    } else if (i < displayImageList.size - 1) {
                        selectedPosition = i
                        viewPagerSetup()
//                        binding.viewPager.currentItem = selectedPosition
//                        setTitles(selectedPosition)
//                        setFavImages(selectedPosition)
                    } else {
                        if (i != 0)
                            selectedPosition = i - 1
                        viewPagerSetup()
//                        binding.viewPager.currentItem = selectedPosition
//                        setTitles(selectedPosition)
//                        setFavImages(selectedPosition)
                    }

                })
    }

    private fun restorePhoto() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        val dataBase = AppDatabase.getInstance(this)
        val restoreList: ArrayList<RestoreData> = ArrayList()
        Observable.fromCallable {
            val list = Utils.restoreFile(this, pictureData, dataBase)
            restoreList.addAll(list)
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (restoreList.size != 0) {
//                        EventBus.getDefault().post(RestoreDataEvent(restoreList))
                        displayImageList.removeAt(i)
                        Log.e("restorePhoto", "size==>>  ${displayImageList.size}")
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            Log.e("restorePhoto", "size == 0 ")
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            Log.e("restorePhoto", "size - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            Log.e("restorePhoto", "i - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (restoreList.size != 0) {
//                        EventBus.getDefault().post(RestoreDataEvent(restoreList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        Log.e("restorePhoto", "size==>>  ${displayImageList.size}")
                        if (displayImageList.size == 0) {
                            Log.e("restorePhoto", "size == 0 ")
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            Log.e("restorePhoto", "size - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            Log.e("restorePhoto", "i - 1  selectedPosition $selectedPosition")
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
    }

    private fun recentDeletePhoto() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        val deleteList = ArrayList<String>()
        val dataBase = AppDatabase.getInstance(this)
        var isDelete = false
        Observable.fromCallable {
            isDelete = Utils.recentlyDeleteHideFile(this, pictureData, dataBase)
            isDelete
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
    }

    fun setUnHideData() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val hideDialog = ConfirmationDialog(
            this,
            getString(R.string.Unhide),
            if (pictureData.isVideo) getString(R.string.unhide_msg_video_single) else getString(R.string.unhide_msg_image_single),
            getString(R.string.ok),
            positiveBtnClickListener = {
                unHidePhoto()
            })
        hideDialog.show(supportFragmentManager, hideDialog.tag)
    }

    private fun unHidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        val pictureData = displayImageList[binding.viewPager.currentItem]
        selectImage.add(pictureData)
        val i = binding.viewPager.currentItem

        Utils.unHideFiles(this, selectImage, selectImage.size, hideListener = {

            toast(getString(R.string.UnHide_successfully))
            displayImageList.removeAt(binding.viewPager.currentItem)
            Log.e("", "displaySize ${displayImageList.size} pos==>> $i")
//            if (displayImageList.size != 0)
//                adapter.notifyDataSetChanged()

            if (displayImageList.size == 0) {
                finish()
            } else if (i < displayImageList.size - 1) {
                selectedPosition = i
                viewPagerSetup()
//                binding.viewPager.currentItem = selectedPosition
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            } else {
                if (i != 0)
                    selectedPosition = i - 1
                viewPagerSetup()
//                binding.viewPager.currentItem = selectedPosition
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            }
        })
    }

    private fun showDeleteDialog() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val deleteDialog = DeleteDialog(
            this,
            btnClickListener = {
                deleteFiles(it, pictureData)
            })
        deleteDialog.show(supportFragmentManager, deleteDialog.tag)
    }

    private fun deleteFiles(isPermanent: Boolean, pictureData: PictureData) {
        val i = binding.viewPager.currentItem
        val deleteList = ArrayList<String>()
        val dataBase = AppDatabase.getInstance(this)
        var isDelete = false

        preferences.refreshMedia = true
        preferences.scanMedia = true
        Observable.fromCallable {
            isDelete = Utils.deleteFile(this, pictureData.filePath, dataBase, isPermanent)
            isDelete
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (isDelete) {
                        preferences.refreshMedia = true
                        preferences.scanMedia = true
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
                        if (displayImageList.size != 0)
                            pagerAdapter.notifyDataSetChanged()

                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
                        if (displayImageList.size != 0)
                            pagerAdapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        }
                    }
                }
            }
    }

    private fun setFavImages(position: Int) {
        try {
            if (!isFromPrivate) {
                binding.btnEdit.beGoneIf(displayImageList[position].isVideo || displayImageList[position].filePath.isGif())
            }
        } catch (e: Exception) {

        }
//        else {
//            binding.btnEdit.visibility = if (!displayImageList[position].filePath.isVideoFast() || !displayImageList[position].filePath.isGif()) View.VISIBLE else View.GONE
//        }

        try {
            binding.ivFavourite.setImageDrawable(
                ContextCompat.getDrawable(
                    this@PhotoVideoActivity,
                    if (displayImageList[position].isFavorite) R.drawable.ic_favourite_checked else R.drawable.ic_favourite_uncheck
                )
            )
        } catch (e: Exception) {

        }
    }

    fun refreshMenuItems() {}

    private fun setTitles(position: Int) {
        if (position < displayImageList.size) {
            val strDate = format.format(displayImageList[position].date)
            val time = formatTime.format(displayImageList[position].date)
            binding.txtTitle.text = strDate
            binding.txtTime.text = time
        }
    }

    private fun showDetailsDialog() {
        val detailsDialog =
            DetailsDialog(displayImageList[binding.viewPager.currentItem], false)
        detailsDialog.show(supportFragmentManager, detailsDialog.tag)
    }

    private fun viewPagerSetup() {
        updatePagerItems(displayImageList.toMutableList())

        setTitles(selectedPosition)
        setFavImages(selectedPosition)

        val file = File(displayImageList[selectedPosition].toString())
        var filename = file.name
//        val type = when {
//            filename.isVideoFast() -> TYPE_VIDEOS
//            filename.isGif() -> TYPE_GIFS
//            filename.isRawFast() -> TYPE_RAWS
//            filename.isSvg() -> TYPE_SVGS
//            file.isPortrait() -> TYPE_PORTRAITS
//            else -> TYPE_IMAGES
//        }

//        mIsVideo = type == TYPE_VIDEOS
        mIsVideo = filename.isVideoFast()


    }

    private fun setFavorite(filePath: String) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        if (!favList.contains(filePath)) {
            favList.add(0, filePath)
            preferences.setFavoriteList(favList)
//            EventBus.getDefault().post(UpdateFavoriteEvent(filePath, true))
        }
    }

    private fun setUnFavorite(filePath: String) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        favList.remove(filePath)
        preferences.setFavoriteList(favList)
//        EventBus.getDefault().post(UpdateFavoriteEvent(filePath, false))
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
//        if (preferences.maxBrightness) {
//            val attributes = window.attributes
//            attributes.screenBrightness = 1f
//            window.attributes = attributes
//        }
//        setupOrientation()
//        refreshMenuItems()
    }

    private fun setupOrientation() {
        if (!mIsOrientationLocked) {
            if (preferences.screenRotation == ROTATE_BY_DEVICE_ROTATION) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
            } else if (preferences.screenRotation == ROTATE_BY_SYSTEM_SETTING) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    private fun checkOrientation() {
        if (!mIsOrientationLocked && preferences.screenRotation == Constant.ROTATE_BY_ASPECT_RATIO) {
            var flipSides = false
            try {
                val pathToLoad = getCurrentPath()
                val exif = ExifInterface(pathToLoad)
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1)
                flipSides =
                    orientation == ExifInterface.ORIENTATION_ROTATE_90 || orientation == ExifInterface.ORIENTATION_ROTATE_270
            } catch (e: Exception) {
            }
            val resolution = applicationContext.getResolution(getCurrentPath()) ?: return
            val width = if (flipSides) resolution.y else resolution.x
            val height = if (flipSides) resolution.x else resolution.y
            if (width > height) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else if (width < height) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }
    }


    override fun fragmentClicked() {
        mIsFullScreen = !mIsFullScreen
        if (mIsFullScreen) {
            enterImmersiveMode()
        } else {
            stopSlideshow()
            exitImmersiveMode()
        }

//        mIsFullScreen = !mIsFullScreen
        fullscreenToggled()

        val newAlpha = if (mIsFullScreen) 0f else 1f

        binding.llBottomOption.animate().alpha(newAlpha).withStartAction {
            binding.llBottomOption.beVisible()
            binding.btnLens.beVisibleIf(isLensInstalled)
        }.withEndAction {
            binding.llBottomOption.beVisibleIf(newAlpha == 1f)
            binding.btnLens.beVisibleIf(newAlpha == 1f && isLensInstalled)
        }.start()

        binding.loutToolbar.animate().alpha(newAlpha).withStartAction {
            binding.loutToolbar.beVisible()
        }.withEndAction {
            binding.loutToolbar.beVisibleIf(newAlpha == 1f)
        }.start()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        stopSlideshow()
    }


    private lateinit var windowInsetsController: WindowInsetsControllerCompat
    private fun initWindowInsetsController() {
        windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun enterImmersiveMode() {
//        WindowHelper.toggleFullscreen(window, true, preferences.showNotch)
//        hideSystemUI()
//        checkNotchSupport()
//        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
//        supportActionBar?.hide()
    }

    private fun exitImmersiveMode() {
//        WindowHelper.toggleFullscreen(window, false, preferences.showNotch)
//        showSystemUI()
//        checkNotchSupport()
//        windowInsetsController.show(WindowInsetsCompat.Type.systemBars())
//        supportActionBar?.show()
    }

    private fun fullscreenToggled() {
        binding.viewPager.adapter?.let {
            (it as MyPagerAdapter).toggleFullscreen(mIsFullScreen)
            val newAlpha = if (mIsFullScreen) 0f else 1f
//            binding.topShadow.animate().alpha(newAlpha).start()
            binding.llBottomOption.animate().alpha(newAlpha).withStartAction {
                binding.llBottomOption.beVisible()
            }.withEndAction {
                binding.llBottomOption.beVisibleIf(newAlpha == 1f)
            }.start()

            binding.loutToolbar.animate().alpha(newAlpha).withStartAction {
                binding.loutToolbar.beVisible()
            }.withEndAction {
                binding.loutToolbar.beVisibleIf(newAlpha == 1f)
            }.start()
        }
    }


    override fun videoEnded(): Boolean {
        if (mIsSlideshowActive) {
            swipeToNextMedium()
        }
        return mIsSlideshowActive
    }

    override fun goToPrevItem() {
        binding.viewPager.setCurrentItem(binding.viewPager.currentItem - 1, false)
        checkOrientation()
    }

    override fun goToNextItem() {
        binding.viewPager.setCurrentItem(binding.viewPager.currentItem + 1, false)
        checkOrientation()
    }

    override fun launchViewVideoIntent(path: String) {}

    override fun isSlideShowActive() = mIsSlideshowActive

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        selectedPosition = position
        setTitles(position)
        setFavImages(position)
        try {
            isFileExists = File(displayImageList[position].filePath).exists()
        } catch (e:Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    override fun onPageSelected(position: Int) {
        Log.d("PhotoVideoActivity", "onPageSelected : $position $mPos")
        if (mPos != position) {
            mPos = position
            setTitles(position)
            setFavImages(position)
            scheduleSwipe()
            try {
                isFileExists = File(displayImageList[position].filePath).exists()
                currentFilePath = displayImageList[position].filePath
            } catch (e:Exception) {
                Log.e("printStackTrace","printStackTrace:$e")
            }

        }
    }

    override fun onPageScrollStateChanged(state: Int) {
        if (state == ViewPager.SCROLL_STATE_IDLE && getCurrentMedium() != null) {
            checkOrientation()
        }
    }

}