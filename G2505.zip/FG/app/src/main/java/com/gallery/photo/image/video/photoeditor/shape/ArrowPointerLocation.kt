package com.gallery.photo.image.video.photoeditor.shape

enum class ArrowPointerLocation { START, END, BOTH }