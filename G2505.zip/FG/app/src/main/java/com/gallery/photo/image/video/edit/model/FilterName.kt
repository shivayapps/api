package com.gallery.photo.image.video.edit.model

enum class FilterName {
    BRIGHTNESS,
    CONTRAST,
    SATURATION,
    SHARPEN,
    VIGNETTE
}