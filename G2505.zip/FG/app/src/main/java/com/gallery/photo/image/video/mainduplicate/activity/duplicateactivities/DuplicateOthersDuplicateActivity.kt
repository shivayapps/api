package com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.Html
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.activity.scanningactivities.ScanningDuplicateActivity
import com.backup.restore.device.image.contacts.recovery.mainduplicate.adapter.IndividualOtherAdapter
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.DuplicateFileRemoverSharedPreferences
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.mainduplicate.model.PopUp
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activities.HomeActivity
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.ActivityDuplicateOthersBinding
import com.gallery.photo.image.video.mainduplicate.BaseSimpleActivity
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.utils.MyUtils
import com.gallery.photo.image.video.mainduplicate.utils.RatingDialog
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants
import com.gallery.photo.image.video.mainduplicate.utils.SharedPrefsConstant

import java.util.*

@SuppressLint("StaticFieldLeak", "SetTextI18n")
class DuplicateOthersDuplicateActivity : BaseActivity(), MarkedListener,
    View.OnClickListener {
    var mTAG : String = javaClass.simpleName
    var adapterList: List<IndividualGroupModel>? = null
    var individualOtherAdapter: IndividualOtherAdapter? = null
    var mLayoutManager: LinearLayoutManager? = null
    var mDuplicateFound = 0
    var index = -1
    var tempGroupOfDupes: List<IndividualGroupModel>? = null
    var top = -1

    companion object {
        @JvmField
        var filterListOthers = HashMap<String, Boolean>()

        @JvmField
        var groupOfDupes: List<IndividualGroupModel>? = null

        @JvmField
        var recyclerViewForIndividualGrp: RecyclerView? = null
    }

    lateinit var mContext:Activity
    lateinit var binding:ActivityDuplicateOthersBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        binding=ActivityDuplicateOthersBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_duplicate_others)

        mContext=getContext()
//        initViews()
//        initAds()
        initData()
        initActions()
        Log.e(mTAG, "onCreate: ")
    }

    fun getContext(): Activity {
        return this@DuplicateOthersDuplicateActivity
    }

    fun initData() {
        recyclerViewForIndividualGrp = findViewById(R.id.recycler_view_others)
        setSupportActionBar(binding.toolbar)
        mLayoutManager = LinearLayoutManager(mContext)
        recyclerViewForIndividualGrp!!.layoutManager = mLayoutManager
        recyclerViewForIndividualGrp!!.setHasFixedSize(true)
        initiateDataInPage()
    }

    fun initActions() {
        binding.delete!!.setOnClickListener(this)
        binding.backpressOther!!.setOnClickListener(this)
    }

    @SuppressLint("NonConstantResourceId")
    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
            return
        }
        com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.backpress_other -> onBackPressed()
            R.id.delete -> deleteDuplicate()
        }
    }

    private fun initiateDataInPage() {
        try {
            StartScan().execute("")
        } catch (e: Exception) {
            Log.e(mTAG, "initiateDataInPage: " + e.message)
        }
    }

    internal inner class StartScan : AsyncTask<String?, String?, String?>() {
         override fun doInBackground(vararg params: String?): String? {
            if (DuplicateFileRemoverSharedPreferences.isInitiateRescanAndEnterOtherPageFirstTimeAfterScan(mContext)) {
                DuplicateFileRemoverSharedPreferences.setInitiateRescanAndEnterOtherPageFirstTimeAfterScan(mContext, false)
                groupOfDupes = PopUp.sortByPhotosDateAscending(com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers)
                tempGroupOfDupes = PopUp.sortByPhotosDateAscending(com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers)
                adapterList = setCheckBox(true)
            } else {
                applyFilterIntDuplicates()
                if (DuplicateFileRemoverSharedPreferences.isInitiateOtherPageAfterApplyFilter(mContext)) {
                    DuplicateFileRemoverSharedPreferences.setInitiateOtherPageAfterApplyFilter(mContext, false)
                    adapterList = setCheckBox(true)
                } else {
                    adapterList = reassignWithDefaultSelection()
                    updateMarked()
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            updatePageDetails(null, null, 0, null)
            if (adapterList!!.isNotEmpty()) {
                recyclerViewForIndividualGrp!!.visibility = View.VISIBLE
                binding.llNoDuplicate!!.visibility = View.GONE
                binding.deleteExceptionFrameLayout!!.visibility = View.VISIBLE
                invalidateOptionsMenu()
                individualOtherAdapter = IndividualOtherAdapter(mContext, this@DuplicateOthersDuplicateActivity,
                    adapterList!!
                )
                recyclerViewForIndividualGrp!!.adapter = individualOtherAdapter
                individualOtherAdapter!!.notifyDataSetChanged()
                com.gallery.photo.image.video.mainduplicate.utils.SharedPrefsConstant.save(mContext, com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.RATE_DUPLICATE_COUNT, com.gallery.photo.image.video.mainduplicate.utils.SharedPrefsConstant.getInt(mContext, com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.RATE_DUPLICATE_COUNT) + 1)
                return
            }
            recyclerViewForIndividualGrp!!.visibility = View.GONE
            binding.deleteExceptionFrameLayout!!.visibility = View.GONE
            binding.llNoDuplicate!!.visibility = View.VISIBLE
            invalidateOptionsMenu()
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (requestCode == com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE && resultCode == -1) {
            if (com.gallery.photo.image.video.mainduplicate.utils.MyUtils.isSelectedStorageAccessFrameWorkPathIsProper(mContext, DocumentFile.fromTreeUri(mContext, resultData!!.data!!)!!.name)) {
                DuplicateFileRemoverSharedPreferences.setStorageAccessFrameWorkURIPermission(mContext, resultData.data.toString())
                showDeleteDialog()
                return
            }
            Toast.makeText(mContext, "Please Select Parent External Storage Dir", Toast.LENGTH_SHORT).show()
            startActivityForResult(Intent("android.intent.action.OPEN_DOCUMENT_TREE"), com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE)
        }
    }

    private fun showDeleteDialog() {
        if (com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.size == 1) {
            PopUp(mContext, mContext).deleteAlertPopUp("Other", getString(R.string.msg_delete_alert_message_other_single), getString(R.string.msg_delete_dialog_message_other_single), com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others, com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_others, com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers, this)
        } else {
            PopUp(mContext, mContext).deleteAlertPopUp("Other",getString(R.string.msg_delete_alert_message_others), getString(R.string.msg_delete_dialog_message_others), com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others, com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_others, com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.listOfGroupedDuplicatesOthers, this)
        }
    }

    private fun deleteDuplicate() {
//        when {
            if(com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_documents.size <= 0) {
                com.gallery.photo.image.video.mainduplicate.utils.MyUtils.showToastMsg(mContext, getString(R.string.error_please_select_one_item))
            }
//            Build.VERSION.SDK_INT >= 20 -> {
                else showDeleteDialog()
//            }
//            MyUtils.getSDCardPath(mContext) == null -> {
//                showDeleteDialog()
//            }
//            DuplicateFileRemoverSharedPreferences.getStorageAccessFrameWorkURIPermission(mContext) != null -> {
//                showDeleteDialog()
//            }
//            else -> {
//                grantPermissionWithAlertDialog()
//            }
//        }
    }

//    private fun grantPermissionWithAlertDialog() {
//        val builder = AlertDialog.Builder(mContext)
//        builder.setView(layoutInflater.inflate(R.layout.dialog_saf_permission, null))
//        builder.setCancelable(false)
//        builder.setPositiveButton("Allow Permission" as CharSequence, PermissionYes())
//        builder.setNegativeButton("Cancel" as CharSequence) { dialog: DialogInterface, _: Int -> dialog.dismiss() }
//        val dialog = builder.create()
//        dialog.show()
//        val pButton = dialog.getButton(-1)
//        pButton.setTextColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
//        pButton.isAllCaps = false
//        dialog.getButton(-2).isAllCaps = false
//    }

    internal inner class PermissionYes : DialogInterface.OnClickListener {
        override fun onClick(dialog: DialogInterface, which: Int) {
            dialog.dismiss()
            startActivityForResult(Intent("android.intent.action.OPEN_DOCUMENT_TREE"), com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.REQUEST_CODE_OPEN_DOCUMENT_TREE)
        }
    }

    private fun applyFilterIntDuplicates() {
        when {
            filterListOthers.size == com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.uniqueOthersExtensionAfterDuplicates.size -> {
                groupOfDupes = tempGroupOfDupes
            }
            filterListOthers.size > 0 -> {
                val newIndividualGroupOthers: MutableList<IndividualGroupModel> = ArrayList()
                for ((key) in filterListOthers) {
                    for (j in tempGroupOfDupes!!.indices) {
                        val individualGroupOthers1 = tempGroupOfDupes!![j]
                        if (individualGroupOthers1.groupExtension.equals(key, ignoreCase = true)) {
                            newIndividualGroupOthers.add(individualGroupOthers1)
                        }
                    }
                }
                groupOfDupes = newIndividualGroupOthers
            }
            else -> {
                groupOfDupes = tempGroupOfDupes
            }
        }
    }

    public override fun onPause() {
        var i = 0
        super.onPause()
        index = mLayoutManager!!.findFirstVisibleItemPosition()
        val v = recyclerViewForIndividualGrp!!.getChildAt(0)
        if (v != null) {
            i = v.top - recyclerViewForIndividualGrp!!.paddingTop
        }
        top = i
    }

    public override fun onResume() {
        super.onResume()
        if (index != -1) {
            mLayoutManager!!.scrollToPositionWithOffset(index, top)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.settings_1, menu)
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#ABABAB'>"+getString(R.string.label_menu_select_all)+"</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#ABABAB'>"+getString(R.string.label_menu_deselect_all)+"</font>")

        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#000000'>"+getString(R.string.label_menu_select_all)+"</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#000000'>"+getString(R.string.label_menu_deselect_all)+"</font>")
        }
        invalidateOptionsMenu()
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#ABABAB'>"+getString(R.string.label_menu_select_all)+"</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#ABABAB'>"+getString(R.string.label_menu_deselect_all)+"</font>")

        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
            menu.findItem(R.id.action_selectall).title = Html.fromHtml("<font color='#000000'>"+getString(R.string.label_menu_select_all)+"</font>")
            menu.findItem(R.id.action_deselectall).title = Html.fromHtml("<font color='#000000'>"+getString(R.string.label_menu_deselect_all)+"</font>")
        }
        invalidateOptionsMenu()
        return super.onPrepareOptionsMenu(menu)
    }

    @SuppressLint("WrongConstant")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val intent: Intent
        when (id) {
            R.id.action_home -> {
                intent = Intent(mContext, HomeActivity::class.java)
                intent.addFlags(335544320)
                startActivity(intent)
                finish()
                return true
            }
            R.id.action_rescan -> {
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.resetOneTimePopUp()
                filterListOthers.clear()
                intent = Intent(mContext, ScanningDuplicateActivity::class.java)
                intent.putExtra("IsCheckType", "Other")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(mContext, R.anim.slide_from_left, R.anim.slide_from_right).toBundle())
                onBackPressed()
                return true
            }
            R.id.action_selectall -> {
                if (mDuplicateFound == 0) {
                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(true)
                }
                return true
            }
            R.id.action_deselectall -> {
                if (mDuplicateFound == 0) {
                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(false)
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun imagesSelectAllAndDeselectAll(b: Boolean) {
        individualOtherAdapter = IndividualOtherAdapter(mContext, this, setCheckBox(b))
        recyclerViewForIndividualGrp!!.adapter = individualOtherAdapter
        individualOtherAdapter!!.notifyDataSetChanged()
        updatePageDetails(null, null, 0, null)
    }

    private fun reassignWithDefaultSelection(): List<IndividualGroupModel> {
        val listOfDupes: MutableList<IndividualGroupModel> = ArrayList()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.clear()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_others = 0
        if (groupOfDupes != null) {
            for (i in groupOfDupes!!.indices) {
                val individualGroup = groupOfDupes!![i]
                individualGroup.isCheckBox = individualGroup.isCheckBox
                val list: MutableList<ItemDuplicateModel> = ArrayList()
                for (j in individualGroup.individualGrpOfDupes!!.indices) {
                    val otherItem = individualGroup.individualGrpOfDupes!![j]
                    if (j == 0) {
                        otherItem.isFileCheckBox = false
                    } else {
                        if (individualGroup.isCheckBox) {
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.add(otherItem)
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.addSizeOthers(otherItem.sizeOfTheFile)
                        }
                        updateMarked()
                        otherItem.isFileCheckBox = individualGroup.isCheckBox
                    }
                    list.add(otherItem)
                }
                individualGroup.individualGrpOfDupes = list
                listOfDupes.add(individualGroup)
            }
        }
        updateDuplicateFound(listOfDupes.size)
        updateMarked()
        return listOfDupes
    }

    private fun setCheckBox(value: Boolean): List<IndividualGroupModel> {
        val listOfDupes: MutableList<IndividualGroupModel> = ArrayList()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.clear()
        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_others = 0
        if (groupOfDupes != null) {
            for (i in groupOfDupes!!.indices) {
                val individualGroup = groupOfDupes!![i]
                individualGroup.isCheckBox = value
                val list: MutableList<ItemDuplicateModel> = ArrayList()
                for (j in individualGroup.individualGrpOfDupes!!.indices) {
                    val otherItem = individualGroup.individualGrpOfDupes!![j]
                    if (j == 0) {
                        otherItem.isFileCheckBox = false
                    } else {
                        if (value) {
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_others.add(otherItem)
                            com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.addSizeOthers(otherItem.sizeOfTheFile)
                        }
                        updateMarked()
                        otherItem.isFileCheckBox = value
                    }
                    list.add(otherItem)
                }
                individualGroup.individualGrpOfDupes = list
                listOfDupes.add(individualGroup)
            }
        }
        updateDuplicateFound(listOfDupes.size)
        updateMarked()
        return listOfDupes
    }

    override fun updateDuplicateFound(duplicateFound: Int) {
        try {
            runOnUiThread {
                (findViewById<View>(R.id.dupes_found) as TextView).text = resources.getString(R.string.duplicate_found) + duplicateFound
            }
            mDuplicateFound = duplicateFound
        } catch (e: Exception) {
            Log.e(mTAG, "updateDuplicateFound: " + e.message)
        }
    }

    override fun updateMarked() {
        try {
            runOnUiThread(SetBottomMark())
        } catch (e: Exception) {
            Log.e(mTAG, "updateMarked: " + e.message)
        }
    }

    internal inner class SetBottomMark : Runnable {
        override fun run() {
            val tvMarked = findViewById<TextView>(R.id.marked)
            tvMarked.visibility = View.VISIBLE
            tvMarked.text = getString(R.string.label_duplicate_size, com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.getReadableFileSize(
                com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.size_Of_File_others))
        }
    }

    override fun cleaned(numberOfPhotosCleaned: Int) {
        Log.e(mTAG, "photosCleanedOthers: ")
        try {
            runOnUiThread {
                val filesCleaned = DuplicateFileRemoverSharedPreferences.getFilesCleaned(mContext) + numberOfPhotosCleaned
                DuplicateFileRemoverSharedPreferences.setFilesCleaned(mContext, filesCleaned)
            }
        } catch (e: Exception) {
            Log.e(mTAG, "Cleaned: " + e.message)
        }
    }

    override fun updatePageDetails(str1: String?, str2: String?, int1: Int, obj: Any?) {
        if (str1 == null) {
            var duplicateCount = 0
            if (groupOfDupes != null) {
                for (i in groupOfDupes!!.indices) {
                    val individualGroup = groupOfDupes!![i]
                    if (individualGroup.individualGrpOfDupes!!.size > 1) {
                        duplicateCount = individualGroup.individualGrpOfDupes!!.size + duplicateCount - 1
                    }
                }
                updateDuplicateFound(duplicateCount)
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}