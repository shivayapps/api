package com.gallery.photo.image.video.mainduplicate.adapter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.activity.previewactivities.PreviewAudioDuplicateActivity
import com.gallery.photo.image.video.mainduplicate.adapter.ListAudioAdapter.AudioViewHolder
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.utils.MyUtils
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants

class ListAudioAdapter(
    var listAudioAdapterContext: Context,
    var audiosMarkedListener: MarkedListener,
    var individualGroupAudios: IndividualGroupModel,
    var audio: List<ItemDuplicateModel>,
    var parentCheckbox: CheckBox) : RecyclerView.Adapter<AudioViewHolder>() {

    var inflater: LayoutInflater = listAudioAdapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0

    class AudioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var audioCheckbox: CheckBox = itemView.findViewById<View>(R.id.audiocheckbox) as CheckBox
        var audioFileName: TextView = itemView.findViewById(R.id.fileName)
        var audioFilePath: TextView = itemView.findViewById(R.id.filePath)
        var audioFileSize: TextView = itemView.findViewById(R.id.fileSize)
        var imageView: ImageView = itemView.findViewById(R.id.audioFile)
        var linearLayout: LinearLayout = itemView.findViewById(R.id.linear_audio_click)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AudioViewHolder {
        return AudioViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.row_list_of_audio_files_item, parent, false))
    }

    override fun onBindViewHolder(holder: AudioViewHolder, position: Int) {
        val lAudioItem = audio[position]
        holder.audioFileName.text = com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.getFileName(lAudioItem.filePath)
        holder.audioFileSize.text = com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.getReadableFileSize(lAudioItem.sizeOfTheFile)
        holder.audioFilePath.text = lAudioItem.filePath
        holder.audioCheckbox.isChecked = lAudioItem.isFileCheckBox
        holder.imageView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(listAudioAdapterContext, PreviewAudioDuplicateActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("audioFile", lAudioItem)
            intent.putExtras(bundle)
            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            listAudioAdapterContext.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listAudioAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())
        }
        holder.linearLayout.setOnClickListener {
            if (SystemClock.elapsedRealtime() - com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            com.gallery.photo.image.video.mainduplicate.utils.ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(listAudioAdapterContext, PreviewAudioDuplicateActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("audioFile", lAudioItem)
            intent.putExtras(bundle)
            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            listAudioAdapterContext.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(listAudioAdapterContext, R.anim.slide_from_right, R.anim.slide_from_left).toBundle())
        }
        holder.audioCheckbox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                lAudioItem.isFileCheckBox = isChecked
                var selectCount = 0
                val numOffline = itemCount
                if (lAudioItem.isFileCheckBox) {
                    for (i in 0 until itemCount) {
                        if (audio[i].isFileCheckBox) {
                            selectCount++
                        }
                    }
                    if (selectCount != numOffline) {
                        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios.add(lAudioItem)
                        com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.addSizeAudios(lAudioItem.sizeOfTheFile)
                        audiosMarkedListener.updateMarked()
                        individualGroupAudios.isCheckBox = true
                        parentCheckbox.isChecked = true
                    }
                } else {
                    com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_audios.remove(lAudioItem)
                    com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions.subSizeAudios(lAudioItem.sizeOfTheFile)
                    audiosMarkedListener.updateMarked()
                }
                if (selectCount < numOffline - 1) {
                    parentCheckbox.isChecked = false
                    individualGroupAudios.isCheckBox = false
                } else {
                    individualGroupAudios.isCheckBox = true
                    parentCheckbox.isChecked = true
                }
                if (numOffline == selectCount) {
                    com.gallery.photo.image.video.mainduplicate.utils.MyUtils.showToastMsg(listAudioAdapterContext, listAudioAdapterContext.getString(R.string.error_not_select_all_audio_in_same))
                    lAudioItem.isFileCheckBox = false
                    holder.audioCheckbox.isChecked = false
                    return@setOnClickListener
                }
                lAudioItem.isFileCheckBox = isChecked
            }
        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = audio.size
        return totalNumberOfflineInSet
    }

}