package com.gallery.photo.image.video.dialog

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.adconfig.AdsConfig
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.databinding.DialogRatingBinding
import com.gallery.photo.image.video.extension.toast
import java.lang.ref.WeakReference

class RatingDialog(var activity: BaseActivity) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogRatingBinding
    var rate: Float = 0f

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogRatingBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        bindingDialog.btRatingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            rate = rating
            when (rating) {
                0f -> {
                    bindingDialog.txtTitle.setText(getString(R.string.rate_title_good))
                    bindingDialog.ivTop.setImageResource(R.drawable.rate_five)
                }

                1f -> {
                    bindingDialog.txtTitle.setText(getString(R.string.rate_title_fair))
                    bindingDialog.ivTop.setImageResource(R.drawable.rate_one)
                }

                2f -> {
                    bindingDialog.txtTitle.setText(getString(R.string.rate_title_fair))
                    bindingDialog.ivTop.setImageResource(R.drawable.rate_two)
                }

                3f -> {
                    bindingDialog.txtTitle.setText(getString(R.string.rate_title_good))
                    bindingDialog.ivTop.setImageResource(R.drawable.rate_three)
                }

                4f -> {
                    bindingDialog.txtTitle.setText(getString(R.string.rate_title_good))
                    bindingDialog.ivTop.setImageResource(R.drawable.rate_four)
                }

                5f -> {
                    bindingDialog.txtTitle.setText(getString(R.string.rate_title_good))
                    bindingDialog.ivTop.setImageResource(R.drawable.rate_five)
                }
            }
        }

        intListener()

    }

    private fun showInAppRateDialog(activity: Activity) {
        Log.e("RatingDialog", "showInAppRateDialog")
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialog.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialog.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }


    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo
    ) {
        Log.e("RatingDialog", "showInAppRateDialogInternal")
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialogInternal.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    launchAppStore()
                    Log.e("RatingDialog", "showInAppRateDialogInternal.RateUsState.IGNORED")
//                    storeRateResult(fragmentActivity, RateUsState.IGNORED)
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialogInternal.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
        )
        activity.startActivity(intent)
    }

    private fun launchEmail() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "message/rfc822"
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(activity.getReviewEmail()))
        i.putExtra(
            Intent.EXTRA_SUBJECT,
            "${getString(R.string.app_name)} ${getString(R.string.feedback)}"
        )
        i.putExtra(Intent.EXTRA_TEXT, "")
        i.setPackage("com.google.android.gm")

        try {
            AdsConfig.isSystemDialogOpen = true
            startActivity(Intent.createChooser(i, getString(R.string.Send_mail)))
        } catch (ex: ActivityNotFoundException) {
            activity.toast(getString(R.string.not_installed))
        }
    }

    private fun intListener() {

        bindingDialog.btnOK.setOnClickListener {
            if (rate >= 4) {
                showInAppRateDialog(activity)
            } else {
                launchEmail()
            }
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}