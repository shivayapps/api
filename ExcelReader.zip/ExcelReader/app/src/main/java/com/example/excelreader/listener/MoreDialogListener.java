package com.example.excelreader.listener;

public interface MoreDialogListener {
    void onRename(String newName);

    void onDelete();

    void onRemove();

    void onFav();


}
