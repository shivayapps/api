package com.example.excelreader.listener;

public interface MergeChooseListener {
    void onMergeChoose(int position);
}
