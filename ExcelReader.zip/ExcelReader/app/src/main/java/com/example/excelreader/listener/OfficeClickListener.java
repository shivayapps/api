package com.example.excelreader.listener;

import com.example.excelreader.model.OfficeModel;

public interface OfficeClickListener {
    void onOfficeClick(OfficeModel officeModel);
}
