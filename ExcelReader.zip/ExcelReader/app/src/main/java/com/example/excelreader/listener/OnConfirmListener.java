package com.example.excelreader.listener;

public interface OnConfirmListener {
    void onConfirm();
}
