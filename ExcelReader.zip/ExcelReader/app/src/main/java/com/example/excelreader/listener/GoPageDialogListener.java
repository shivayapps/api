package com.example.excelreader.listener;

public interface GoPageDialogListener {
    void onPageNumber(int pageNumber);


}
