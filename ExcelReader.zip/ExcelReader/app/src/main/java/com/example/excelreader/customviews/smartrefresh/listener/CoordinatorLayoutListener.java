package com.example.excelreader.customviews.smartrefresh.listener;

public interface CoordinatorLayoutListener {
    void onCoordinatorUpdate(boolean enableRefresh, boolean enableLoadMore);
}