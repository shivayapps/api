package com.example.excelreader.listener;

public interface LanguageAdapterListener {
    void onLangSelected(int lang);

}
