package com.example.excelreader.listener;

public interface RenameDialogListener {
    void onRenameDialog(String newName);

}
