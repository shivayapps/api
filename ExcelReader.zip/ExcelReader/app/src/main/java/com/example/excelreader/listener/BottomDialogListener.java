package com.example.excelreader.listener;

public interface BottomDialogListener {
    void onRename(String filePath);

    void onDelete();
}
