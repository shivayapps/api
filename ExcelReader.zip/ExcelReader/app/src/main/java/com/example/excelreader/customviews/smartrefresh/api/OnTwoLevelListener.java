package com.example.excelreader.customviews.smartrefresh.api;


import androidx.annotation.NonNull;



public interface OnTwoLevelListener {

    boolean onTwoLevel(@NonNull RefreshLayout refreshLayout);
}