package com.example.excelreader.customviews.smartrefresh.api;



public interface RefreshHeader extends RefreshInternal {

}
