package com.gallery.photo.image.video.filepicker.controller.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.FileListItemBinding
import com.gallery.photo.image.video.filepicker.controller.DialogSelectionListener
import com.gallery.photo.image.video.filepicker.controller.NotifyItemChecked
import com.gallery.photo.image.video.filepicker.model.DialogConfigs
import com.gallery.photo.image.video.filepicker.model.DialogProperties
import com.gallery.photo.image.video.filepicker.model.FileListItem
import com.gallery.photo.image.video.filepicker.model.MarkedItemList
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileAdapter(
    val listItem: ArrayList<com.gallery.photo.image.video.filepicker.model.FileListItem>,
    val context: Context,
    val properties: com.gallery.photo.image.video.filepicker.model.DialogProperties,
    val onItemClick: (Int) -> Unit,
    val notifyItemChecked: com.gallery.photo.image.video.filepicker.controller.NotifyItemChecked? = null
) : RecyclerView.Adapter<FileAdapter.ViewHolder>() {

//    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            FileListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return listItem.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = listItem[position]
//        if (MarkedItemList.hasItem(item.location)) {
//            val animation = AnimationUtils.loadAnimation(context, R.anim.marked_item_animation)
////            view.setAnimation(animation)
//        } else {
//            val animation = AnimationUtils.loadAnimation(context, R.anim.unmarked_item_animation)
////            view.setAnimation(animation)
//        }

        if (item.isDirectory) {
            holder.binding.imageType.setImageResource(R.drawable.ic_deleteemptyfolder)
            holder.binding.imageType.setColorFilter(ContextCompat.getColor(context, R.color.color_primary))
            if (properties.selectionType == com.gallery.photo.image.video.filepicker.model.DialogConfigs.FILE_SELECT) {
                holder.binding.cbCheck.visibility = View.INVISIBLE
            } else {
                holder.binding.cbCheck.visibility = View.VISIBLE
            }
        } else {
            holder.binding.imageType.setImageResource(R.drawable.ic_file)
            holder.binding.imageType.setColorFilter(ContextCompat.getColor(context, R.color.color_accent))
            if (properties.selectionType == com.gallery.photo.image.video.filepicker.model.DialogConfigs.DIR_SELECT) {
                holder.binding.cbCheck.visibility = View.INVISIBLE
            } else {
                holder.binding.cbCheck.visibility = View.VISIBLE
            }
        }
        holder.binding.imageType.contentDescription = item.filename
        holder.binding.fname.text = item.filename
        val sdate = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH)
        val date = Date(item.time)

        if (position == 0 && item.filename.startsWith(context.getString(R.string.label_parent_dir))) {
            holder.binding.ftype.setText(R.string.label_parent_directory)
        } else {
            holder.binding.ftype.text = context.getString(R.string.last_edit, sdate.format(date))
        }
        if (holder.binding.cbCheck.visibility == View.VISIBLE) {
            if (position == 0 && item.filename.startsWith(context.getString(R.string.label_parent_dir))) {
                holder.binding.cbCheck.visibility = View.INVISIBLE
            }
            val hasItem = com.gallery.photo.image.video.filepicker.model.MarkedItemList.hasItem(item.location)
            holder.binding.cbCheck.isChecked = hasItem
        }

        holder.binding.cbCheck.setOnCheckedChangeListener { buttonView, isChecked ->
            item.isMarked = isChecked
            if (item.isMarked) {
                if (properties.selectionMode == com.gallery.photo.image.video.filepicker.model.DialogConfigs.MULTI_MODE) {
                    com.gallery.photo.image.video.filepicker.model.MarkedItemList.addSelectedItem(item)
                } else {
                    com.gallery.photo.image.video.filepicker.model.MarkedItemList.addSingleFile(item)
                }
            } else {
                com.gallery.photo.image.video.filepicker.model.MarkedItemList.removeSelectedItem(item.location)
            }
//            notifyItemChecked.notifyCheckBoxIsClicked()
            notifyItemChecked?.notifyCheckBoxIsClicked()
        }

        holder.itemView.setOnClickListener {
            onItemClick.invoke(position)
            //clickListener(position)
        }

    }

    class ViewHolder(var binding: FileListItemBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}