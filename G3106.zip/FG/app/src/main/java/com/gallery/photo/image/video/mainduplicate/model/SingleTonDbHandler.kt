package com.gallery.photo.image.video.mainduplicate.model

import android.content.Context

class SingleTonDbHandler(var singleTonDbHandlerContext: Context) {
    val instance: com.gallery.photo.image.video.mainduplicate.model.DBHandler?
        get() {
            if (mInstance == null) {
                mInstance =
                    com.gallery.photo.image.video.mainduplicate.model.DBHandler(
                        singleTonDbHandlerContext
                    )
            }
            return mInstance
        }

    companion object {
        var mInstance: com.gallery.photo.image.video.mainduplicate.model.DBHandler? = null
    }
}