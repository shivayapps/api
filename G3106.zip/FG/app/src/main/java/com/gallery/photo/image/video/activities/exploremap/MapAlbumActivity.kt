package com.gallery.photo.image.video.activities.exploremap

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import androidx.exifinterface.media.ExifInterface
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activities.ImageListActivity
import com.gallery.photo.image.video.adapter.PlaceAdapter
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.customview.MyGridLayoutManager
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.database.LocationEntity
import com.gallery.photo.image.video.databinding.ActivityMapAlbumBinding
import com.gallery.photo.image.video.databinding.ActivityMapExploreBinding
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.model.PlaceData
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.Preferences
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.io.IOException
import java.util.Locale

class MapAlbumActivity : BaseActivity() {

    lateinit var activity: Activity
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var albumList: ArrayList<PlaceData> = ArrayList()
    var albumAdapter: PlaceAdapter? = null

    lateinit var binding: ActivityMapAlbumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapAlbumBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()
//        dataBase = AppDatabase.getInstance(this)

        initView()
        initData()
//        getAllImagesFromGallery()
    }

    private fun initView() {
        binding.loutToolbar.icMenu.visibility=View.GONE
        binding.loutToolbar.txtTitle.text = getString(R.string.map)
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }

        activity = this@MapAlbumActivity
        preferences = Preferences(activity)

        albumAdapter = PlaceAdapter(activity, albumList,
            clickListener = {
                val albumData = albumList[it]
                openImageList(albumData)
            })

        binding.recyclerViewPlace.adapter = albumAdapter

        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanCount = 3
    }

    private fun openImageList(placeData: PlaceData) {

        Constant.albumData = AlbumData(
            placeData.place,
            placeData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent= Intent(activity, ImageListActivity::class.java)
        intent.putExtra("isFromMap",true)
        intent.putExtra("lati",placeData.lati)
        intent.putExtra("long",placeData.long)
        startActivity(intent)
    }

    private fun initData() {

        dataBase = AppDatabase.getInstance(activity)
        dataBase.dataDao().getLocationLiveEntityList()
            .observe(this) { places: List<LocationEntity> ->
                sortImage(places)
            }

        dataBase = AppDatabase.getInstance(this)
        dataBase?.dataDao()!!.getLocationLiveEntityList()
            .observe(this) { places: List<LocationEntity> ->
                setEmptyData(places)
            }

        Observable.fromCallable {
            getAllImagesFromGallery()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                Log.e("XXPermissions", "getAllImagesFromGallery:::getImageOnMap.001")
            }
            .subscribe { _: Boolean? ->
                Log.e("XXPermissions", "getAllImagesFromGallery:::getImageOnMap.002")
            }
    }

    private fun sortImage(placeList: List<LocationEntity>) {
//        val placeList = dataBase.dataDao().getLocationEntityList()
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")
        albumList.clear()
        placeList.forEach { data ->

            val strKey = data.title

            var imagesData1: ArrayList<PictureData> = ArrayList()

            val file = File(data.path)
            if(file.exists()) {

                val pictureData = PictureData(
                    file.path,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in albumList.indices) {
                    if (albumList[i].place == strKey) {
                        albumList[i].pictureData.add(pictureData)
                    }
                }

                if (albumList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(pictureData)
                    val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    albumList.add(placeData)
                }
            }
            else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }

        getImageOnMap()
        setEmptyData()
    }

    fun getImageOnMap() {
//        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
//        layoutManager.orientation = RecyclerView.VERTICAL
//        (binding.recyclerViewPlace.layoutManager as MyGridLayoutManager).spanCount =3
        Log.e("MapExploreActivity", "getImageOnMap:::albumWisePictures:${albumList.size}")
//        if (albumList != null && albumList.size > 0) {
//            albumList.forEach { album ->
////          for (album in albumList) {
//                addMarker(album)
//            }
//        }

        activity.runOnUiThread{
            if(albumAdapter!=null) {
                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.recyclerViewPlace.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.recyclerViewPlace.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun getAllImagesFromGallery() {
        Log.e("XXPermissions", "getAllImagesFromGallery")
//        val projection = arrayOf(
//            MediaStore.Images.Media._ID,
//            MediaStore.Images.Media.DATA,
//            MediaStore.MediaColumns.TITLE,
//            MediaStore.Images.Media.SIZE
//        )
        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
        )

        val orderBy = MediaStore.MediaColumns.DATE_MODIFIED
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val cursor: Cursor = contentResolver.query(
            uri,
            projection,
            null,
            null,
            "$orderBy DESC"
        )!!

        val pathIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
//        albumList.clear()

        while (cursor.moveToNext()) {
            val filePath = cursor.getString(pathIndex)
            var latLong = FloatArray(2)

            val entity = dataBase?.dataDao()!!.getLocationEntity(filePath)

            if (entity == null) {
                try {
//                    val inputStream: InputStream = requireContext().contentResolver.openInputStream(photoUri) ?: continue
                    val exifInterface = ExifInterface(filePath)
                    exifInterface.getLatLong(latLong)
                    Log.e("XXPermissions", "getLatLong:${latLong[0]},${latLong[0]}")
//                    inputStream.close()
                } catch (e: IOException) {
                    Log.e("XXPermissions", "IOException:$e")
                } catch (e: UnsupportedOperationException) {
                    Log.e("XXPermissions", "UnsupportedOperationException:$e")
                }

                if (latLong[0] != 0f && latLong[1] != 0f) {

                    var latLongToAddressString = ""
                    latLongToAddressString = latLongToAddressString(
                        latLong[0],
                        latLong[1]
                    )

                    dataBase?.dataDao()?.insertLocationEntity(
                        LocationEntity(
                            0,
                            latLongToAddressString,
                            filePath,
                            latLong[0],
                            latLong[1]
                        )
                    )
                    Log.i(
                        "XXPermissions", "004.latLongToAddressString：" + latLongToAddressString
                    )
                }
            }
        }
        cursor.close()
    }

    private fun latLongToAddressString(latitude: Float, longitude: Float): String {
        var addressString = ""
            val geocoder = Geocoder(this@MapAlbumActivity, Locale.getDefault())
            try {
                val addresses: List<Address>? =
                    geocoder.getFromLocation(latitude.toDouble(), longitude.toDouble(), 1)
                if (addresses != null) {
                    val returnedAddress: Address = addresses[0]
                    val strReturnedAddress = StringBuilder("")

                    Log.w(
                        "XXPermissions",
                        "addressline:::==================================================="
                    )
                    Log.w("XXPermissions", "addressline:::adminArea==>:${returnedAddress.adminArea}")
                    Log.w(
                        "XXPermissions",
                        "addressline:::featureName==>:${returnedAddress.featureName}"
                    )
                    Log.w("XXPermissions", "addressline:::locality==>:${returnedAddress.locality}")
                    Log.w(
                        "XXPermissions",
                        "addressline:::subLocality==>:${returnedAddress.subLocality}"
                    )
                    Log.w(
                        "XXPermissions",
                        "addressline:::countryName==>:${returnedAddress.countryName}"
                    )
                    Log.w(
                        "XXPermissions",
                        "addressline:::subAdminArea==>:${returnedAddress.subAdminArea}"
                    )
                    Log.w("XXPermissions", "addressline:::premises==>:${returnedAddress.premises}")


//                for (i in 0..returnedAddress.maxAddressLineIndex) {
//                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n")
//                }

                    if (returnedAddress.subLocality != null) {
                        strReturnedAddress.append(returnedAddress.subLocality)
                    } else if (returnedAddress.locality != null) {
                        strReturnedAddress.append(returnedAddress.locality)
                    }

                    addressString = strReturnedAddress.toString()
                }
            } catch (e: Exception) {
                Log.e("printStackTrace","printStackTrace:$e")
            }
        return addressString
    }

    private fun setEmptyData(placeList: List<LocationEntity>) {
        if (placeList != null && placeList.size != 0) {
            binding.llAdPlace.visibility = View.VISIBLE
        } else {
            binding.llAdPlace.visibility = View.GONE
        }
    }


    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {
            val isFirstSession=Preferences(this).splashCounter==1
            val adId=getString(R.string.b_mapExploreActivity)
            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd,binding.llAdParent,adId,
                AdCache.mapExploreAdView,{ isLoaded, adView, message ->
                    mAdView=adView
                    AdCache.mapExploreAdView=adView
                    isAdLoaded=isLoaded
                })
        }
    }

}