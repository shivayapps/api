package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.text.format.Formatter
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.AnimationUtils
import androidx.appcompat.widget.Toolbar
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDuplicatePreviewBinding
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.Utils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Objects

class DuplicatePreviewDialog(val fContext: Context, var mItemDuplicateModel: ItemDuplicateModel,val callback: (dismiss: Boolean) -> Unit) :
    Dialog(fContext) {

    lateinit var bindingDialog: DialogDuplicatePreviewBinding
    var mFileName: String? = null
    var mFileSize: String? = null
    var mFileType: String? = null
    var mModifiedDate: String? = null
    var mPath: String? = null
    var mAudioDuration: String? = null
    var mImageResolution: String? = null

    val Context.displayWidth: Int get() = resources.displayMetrics.widthPixels

    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
//        val sheetView = fContext.inflater.inflate(R.layout.new_rate_dialog, null)
        window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        bindingDialog = DialogDuplicatePreviewBinding.inflate(layoutInflater)

        setContentView(bindingDialog.root)
        setCancelable(false)
        setCanceledOnTouchOutside(false)

        window!!.setGravity(Gravity.CENTER)
        window!!.setLayout((0.9 * fContext.displayWidth).toInt(), Toolbar.LayoutParams.WRAP_CONTENT)
        intView()
//        initListeners()

//        val animZoomIn = AnimationUtils.loadAnimation(fContext, R.anim.zoon_in_out)
//        iv_rate_cartoon.startAnimation(animZoomIn)
        show()

    }


//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogDuplicatePreviewBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog.root
//    }

    private fun intView() {
        assignValuesToWidgets()
        intListener()
    }

    private fun assignValuesToWidgets() {
        mFileName = GlobalVarsAndFunctions.getFileName(mItemDuplicateModel.filePath)
        mFileType = GlobalVarsAndFunctions.getExtension(mItemDuplicateModel.filePath)
        mFileSize = ShareConstants.getReadableFileSize(mItemDuplicateModel.sizeOfTheFile)
        mAudioDuration = mItemDuplicateModel.fileDuration
        mModifiedDate = SimpleDateFormat("MMM dd,yyyy HH:mm:ss").format(Date(mItemDuplicateModel.fileDateAndTime))
        mPath = mItemDuplicateModel.filePath


        Glide.with(fContext)
            .load(mPath)
            .override(300, 300)
            .placeholder(R.drawable.img_thumb)
            .into(bindingDialog.zoomableImageView)

        bindingDialog.txtName.text = mFileName
        bindingDialog.txtFormat.text = mFileType
        bindingDialog.txtSize.text = mFileSize
        bindingDialog.txtResolution.text = mImageResolution
        bindingDialog.txtTime.text = mModifiedDate
        bindingDialog.txtPath.text = mPath
    }

    private fun intListener() {
        bindingDialog.btnOK.setOnClickListener {
            dismiss()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}