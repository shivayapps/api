package com.gallery.photo.image.video.picker

import android.app.Activity
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.customview.MyGridLayoutManager
import com.gallery.photo.image.video.customview.MyRecyclerView
import com.gallery.photo.image.video.databinding.FragmentMediaBinding
import com.gallery.photo.image.video.extension.getParentFolder
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MAX_COLUMN_COUNT_ALBUM
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.TYPE_GIFS
import com.gallery.photo.image.video.utils.TYPE_IMAGES
import com.gallery.photo.image.video.utils.TYPE_VIDEOS
import com.gallery.photo.image.video.utils.photoExtensions
import com.gallery.photo.image.video.utils.rawExtensions
import com.gallery.photo.image.video.utils.videoExtensions
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Collections
import java.util.Locale
import kotlin.math.max
import kotlin.math.min


private const val ARG_PARAM = "param"

class MediaFragment : Fragment() {

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        (activity as ImagePickerActivity).longClickListener(isShowSelection, selected, isAllSelect)
    }

    fun selectAlbum() {
        (activity as ImagePickerActivity).getAlbumListForSelect()
    }

    private var param: Int? = 0

    //    private var param2: String? = null
    companion object {
        @JvmStatic
        fun newInstance(param: Int) =
            MediaFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_PARAM, param)
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param = it.getInt(ARG_PARAM)
//            param2 = it.getString(ARG_PARAM2)
        }
    }

    private var lastLongPressedItem = -1
    var selectedItem = 0
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    var allList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()
    var dummyPictures = ArrayList<Any>()
    var pictureAdapter: PickerAdapter? = null
    lateinit var preferences: Preferences

    lateinit var binding: FragmentMediaBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMediaBinding.inflate(inflater, container, false)
        if (isAdded && !isDetached) {
            initView()
        }
        return binding.root
    }

    lateinit var activity: Activity
    private fun initView() {
        activity = requireActivity()
        preferences = Preferences(activity)

        setRvLayoutManager()
        getData()
    }


    fun getSelected(): ArrayList<String> {
        val selectImage: ArrayList<String> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model.filePath)
//                        favList.add(model.filePath)
                    }
                }
        }
        return selectImage
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
//        val gridLayoutManager = GridLayoutManager(getActivity(), gridCount, RecyclerView.VERTICAL, false)
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = gridCount
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
//        binding.pictureRecycler.layoutManager = gridLayoutManager
//        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//            override fun getSpanSize(position: Int): Int {
//                if (position >= 0 && position < pictures.size) {
//                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
//                        gridCount
//                    } else 1
//                } else {
//                    return 1
//                }
//            }
//        }
    }

    public fun getData() {
        allList.clear()
//        pictures.clear()
        dummyPictures.clear()
//        activity.runOnUiThread { if (pictureAdapter != null) pictureAdapter!!.notifyDataSetChanged() }
//        disableScroll()
//        isUpadteList = true
//        binding.swipeRefreshLayout.isRefreshing = true

        Glide.get(activity).clearMemory()
        Observable.fromCallable {
            Glide.get(activity).clearDiskCache()
//            videoCount = 0
//            imageCount = 0
            if (param == 0 || param == 1)
                getImages()

            if (param == 0 || param == 2)
                getVideos()

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                Log.e("gettingListPhoto", "getData:" + throwable)
                activity.runOnUiThread {
                    setFilterData()
//                    getFindCount()
                }
            }
            .subscribe { result: Boolean? ->
                activity.runOnUiThread {
                    setFilterData()
//                    getFindCount()
                }
            }

    }

    private fun getImages() {
        Log.e("contentResolver.001", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences.getFavoriteList())

        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )

            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

//            val uri = MediaStore.Files.getContentUri("external")

            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = activity.contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
//                Log.e("contentResolver.001", "getImages.mCursor.count::${mCursor.count}")
                mCursor.moveToFirst()
                val photoDataArrayList: ArrayList<PictureData> = ArrayList<PictureData>()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))

//                    val width = mCursor.getInt(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH))
//                    val height = mCursor.getInt(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT))

//                    Log.e("getImages", "fileSize $fileSizeLength title $title ")

                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                        pictureData.isCheckboxVisible = true
//                        pictureData.isFavorite = favList.contains(path)
                        allList.add(pictureData)

//                        imageCount++
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            } else Log.e("contentResolver.001", "getImages.mCursor.null::")
        } catch (e: Exception) {
            Log.e("contentResolver.001", "getImages.Exception::$e")
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    private fun getVideos() {
        Log.e("contentResolver.001", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

//        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
//        val uri = MediaStore.Files.getContentUri("external")

//        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )

//        val uri= if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            android.provider.MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
//        } else
//            android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
//
//        val projection = arrayOf(
//            MediaStore.Video.VideoColumns.DATA,
//            MediaStore.Video.Media.DISPLAY_NAME,
//            MediaStore.Video.VideoColumns.SIZE,
//            MediaStore.Video.VideoColumns.DURATION,
//            MediaStore.Video.VideoColumns.DATE_MODIFIED,
//            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
//        )

        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())

//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences.getFavoriteList())
        try {
            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            val cursor = activity.contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
//            val cursor = activity.contentResolver.query(
//                uri,
//                projection,
//                selection,
//                selectionArgs,
//                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
//            )

            if (cursor != null) {
//                Log.e("contentResolver.001", "getVideos.mCursor.count::${cursor.count}")
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))

                        dt *= 1000
                        if (dt == 0L)
                            dt = d

//                        Log.e("contentResolver.001", "getVideos path:$path, title:$title, bucketName:$bucketName, d:$d, dt:$dt, fileSizeLength:$fileSizeLength, duration:$duration")
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isCheckboxVisible = true
//                        pictureData.isFavorite = favList.contains(path)
                        pictureData.isVideo = true
                        allList.add(pictureData)

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            } else
                Log.e("contentResolver.001", "getVideos.mCursor.null::")
        } catch (exp: java.lang.Exception) {
            Log.e("contentResolver.001", "Exception.getVideos::$exp")
            exp.printStackTrace()
        }
    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }


    var isUpadteList = false
    fun setFilterData() {
        if (isAdded) {

            isUpadteList = true
//            disableScroll()
//            binding.swipeRefreshLayout.isRefreshing = true
            GlobalScope.launch(Dispatchers.IO) {
                setFilter()
                setList()
                activity.runOnUiThread {
                    setData()
//                    getFindCount()
                }
            }

//        Observable.fromCallable {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread { setData() }
//            }
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
//        binding.swipeRefreshLayout.isEnabled = false
        selectedItem = selected
    }

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = PickerAdapter(activity, pictures,
            clickListener = {
                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    if (pictureData.isCheckboxVisible) {
                        pictureData.isSelected = !pictureData.isSelected
                        pictureAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    } else {
//                        val dataList = ArrayList<PictureData>()
//                        var displayPos = 0
//                        for (i in pictures.indices) {
//                            if (pictures[i] is PictureData) {
//                                dataList.add(pictures[i] as PictureData)
//                                if (it == i) {
//                                    displayPos = dataList.size - 1
//                                }
//                            }
//                        }
//                        Constant.displayImageList = ArrayList()
//                        Constant.displayImageList.addAll(dataList)
////                        val intent = Intent(activity, ImageViewerActivity::class.java)
//                        val intent = Intent(activity, PhotoVideoActivity::class.java)
//                        intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
//                        startActivity(intent)
//                        selectAlbum()
                    }
                }
            }, longClickListener = {
//            binding.swipeRefreshLayout.isRefreshing = false
//            binding.swipeRefreshLayout.isEnabled = false
                lastLongPressedItem = it
                binding.pictureRecycler.setDragSelectActive(it)
                lastLongPressedItem = if (lastLongPressedItem == -1) {
                    it
                } else {
                    val min = min(lastLongPressedItem, it)
                    val max = max(lastLongPressedItem, it)
                    for (i in min..max) {
                        toggleItemSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is PictureData) {
                                val model = pictures[i] as PictureData
                                model.isCheckboxVisible = true
                            }
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }

            }, headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is PictureData) {
                            val model = pictures[pos] as PictureData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedFile()
                }
            })


        binding.pictureRecycler.adapter = pictureAdapter
//        val primaryColor = resources.getColor(R.color.color_primary)
//        binding.mediaFastscroller.updateColors(primaryColor)
//        binding.mediaFastscroller.handleDrawable=ColorDrawable(primaryColor)
//        binding.mediaFastscroller.popupTextView.setTextColor(primaryColor)
//        binding.mediaFastscroller.popupTextView.background.mutate().setColorFilter(primaryColor, PorterDuff.Mode.SRC_IN)


        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)

//        val snapHelper: SnapHelper = LinearSnapHelper()
//        snapHelper.attachToRecyclerView(binding.pictureRecycler)
    }


    private fun initZoomListener() {
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_ALBUM) {
                        increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.pictureRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {

        binding.pictureRecycler.setupDragListener(dragListener)
//        binding.pictureRecycler.setupDragListener(object : MyRecyclerView.MyDragListener {
//            override fun selectItem(position: Int) {
//                toggleItemSelection(true, position, true)
//            }
//
//            override fun selectRange(
//                initialSelection: Int,
//                lastDraggedIndex: Int,
//                minReached: Int,
//                maxReached: Int
//            ) {
//                selectItemRange(
//                    initialSelection,
//                    Math.max(0, lastDraggedIndex),
//                    Math.max(0, minReached),
//                    maxReached
//                )
//                if (minReached != maxReached) {
//                    lastLongPressedItem = -1
//                }
//            }
//        })
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        if (select && pictures[pos] is AlbumData) {
            return
        }

        if (pictures[pos] is PictureData) {

            if (select) {
                (pictures[pos] as PictureData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                (pictures[pos] as PictureData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
            }
        }
        pictureAdapter?.notifyItemChanged(pos)
        setSelectedFile()

    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid > 2) {
            preferences.setGridCount(selectedGrid - 1)
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_ALBUM) {
            preferences.setGridCount(selectedGrid + 1)
        }
        setColumnView()
    }

    private fun setColumnView() {
        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getGridCount()
        pictureAdapter?.apply {
            notifyItemRangeChanged(0, pictures.size)
        }
        setRvLayoutManager()
    }

    fun setData() {
        Log.e("gettingListPhoto", "Data is show")
        isUpadteList = false
//        binding.swipeRefreshLayout.isRefreshing = false

//        binding.pictureRecycler.suppressLayout(true)
        binding.pictureRecycler.recycledViewPool.clear()
        pictures.clear()
        pictures.addAll(dummyPictures)

//        enableScroll()

        if (pictureAdapter != null) notifyAdapter() else initAdapter()
//        RxBus.getInstance().post(CountShowEvent())
//        setEmptyData()
    }

    private fun notifyAdapter() {
        //        binding.pictureRecycler.suppressLayout(true)
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
//binding.pictureRecycler.post { pictureAdapter?.notifyDataSetChanged() }
    }

    fun setList() {

        try {

//            if(isAdded) {

//            binding.swipeRefreshLayout.isEnabled = true
//        binding.swipeRefreshLayout.isRefreshing = true
            dummyPictures.clear()
//        if (isSearch) activity.runOnUiThread { notifyAdapter() }

            val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
            var format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
//            var format = SimpleDateFormat(preferences.dateFormat)

//        val currentGrouping = context.config.getFolderGrouping(pathToCheck)
//            val currentGrouping = preferences.getGroupBy()
            val currentGrouping = Constant.GROUP_BY_LAST_MODIFIED_DAILY
//            val groupOrder = preferences.getGroupOrderBy()

            format = when (currentGrouping) {
                Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
                    SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
//                    SimpleDateFormat(preferences.dateFormat)
                }

                Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
                    SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
//                    SimpleDateFormat(preferences.dateFormat)
                }

                Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
                Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
                else -> SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
//                else -> SimpleDateFormat(preferences.dateFormat)
            }

            if (allList.size != 0) {
                for (pictureData in allList) {
//                val strKey = format.format(pictureData.date)
                    var strKey = format.format(pictureData.date)
                    strKey = format.format(getDayStartTS(pictureData.date, false))
//                    when (currentGrouping) {
//                        Constant.GROUP_BY_NONE -> strKey = ""
//                        Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
//                            strKey = format.format(getDayStartTS(pictureData.date, false))
//                        }
//
//                        Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
//                            strKey = format.format(getDayStartTS(pictureData.dateTaken, false))
//                        }
//
//                        Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> {
//                            strKey = format.format(getDayStartTS(pictureData.date, true))
//                        }
//
//                        Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> {
//                            strKey = format.format(getDayStartTS(pictureData.dateTaken, true))
//                        }
//
//                        Constant.GROUP_BY_EXTENSION -> {
//                            strKey = pictureData.fileName.getFilenameExtension()
//                                .lowercase(Locale.getDefault())
//
//                        }
//
//                        Constant.GROUP_BY_FOLDER -> {
////                            strKey = pictureData.bucketPath
////                        strKey = pictureData.filePath.getParentPath().getFilenameFromPath().lowercase(Locale.getDefault())
//                            strKey = pictureData.filePath.getParentFolder()
//                                .lowercase(Locale.getDefault())
//                        }
//
//                        Constant.GROUP_BY_FILE_TYPE -> {
//                            strKey = getFileTypeString(
//                                pictureData.fileName.getFilenameExtension()
//                                    .lowercase(Locale.getDefault())
//                            )
//                        }
//
//                        else -> {
//                            strKey = format.format(getDayStartTS(pictureData.dateTaken, false))
//                        }
//                    }

                    var imagesData1: ArrayList<PictureData> = ArrayList()
                    if (strKey.isNotEmpty() && dateWisePictures.containsKey(strKey)) {
                        val list: ArrayList<PictureData>? = dateWisePictures[strKey]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    if (strKey.isNotEmpty()) dateWisePictures[strKey] = imagesData1
                }


                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

//                if (groupOrder == Constant.ORDER_DESCENDING) {
                listKeys.reverse()
//                }

                if (listKeys.size == 0) {
//                pictures.addAll(allList)
                    dummyPictures.addAll(allList)
                }
                for (i in listKeys.indices) {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
//                    pictures.add(bucketData)
//                    pictures.addAll(imagesData)
                        dummyPictures.add(bucketData)
                        dummyPictures.addAll(imagesData)
                    }
                }
            }
//            binding.swipeRefreshLayout.isRefreshing = false
//            }
        } catch (e: Exception) {

        }

//        pictures.clear()
//        activity.runOnUiThread { notifyAdapter() }
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    private fun setFilter() {
        Log.e("", "imageVideo size==>> " + allList.size)
//        val sortType = preferences.getSortType()
//        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
//            if (sortOrder == Constant.ORDER_ASCENDING)
            p1.date.compareTo(p2.date)
//            else
//                p2.date.compareTo(p1.date)
//            if (sortType == Constant.SORT_NAME) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.fileName.compareTo(p2.fileName, true)
//                else
//                    p2.fileName.compareTo(p1.fileName, true)
//            } else if (sortType == Constant.SORT_PATH) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.filePath.compareTo(p2.filePath, true)
//                else
//                    p2.filePath.compareTo(p1.filePath, true)
//            } else if (sortType == Constant.SORT_SIZE) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.fileSize.compareTo(p2.fileSize)
//                else
//                    p2.fileSize.compareTo(p1.fileSize)
//            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
//
//            } else if (sortType == Constant.SORT_DATE_TAKEN) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.dateTaken.compareTo(p2.dateTaken)
//                else
//                    p2.dateTaken.compareTo(p1.dateTaken)
//            } else
//                p2.date.compareTo(p1.date)
        })
//        setList()
    }

}