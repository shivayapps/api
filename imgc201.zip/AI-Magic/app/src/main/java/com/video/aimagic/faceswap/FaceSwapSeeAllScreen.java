package com.video.aimagic.faceswap;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityFaceSwapSeeAllScreenBinding;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.faceswap.adapter.FaceSwapPagerAdapter;
import com.video.aimagic.faceswap.model.FaceSwapCategory;
import com.video.aimagic.faceswap.model.FaceSwapUrl;
import com.video.aimagic.faceswap.model.LocalizedName;
import com.video.aimagic.utils.JSONLoder;
import com.video.aimagic.utils.appconfig.RemoteConfigPref;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FaceSwapSeeAllScreen extends AppCompatActivity {
    private ActivityFaceSwapSeeAllScreenBinding binding;
    private RemoteConfigPref remoteConfigPref;
    private List<FaceSwapCategory> categories = new ArrayList<>();
    private String currentFilter = "all";
    private String currentJsonData = "";
    private int currentPosition = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFaceSwapSeeAllScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this,false);
        currentPosition = getIntent().getIntExtra("position", -1);
        Log.e("currentPosition", "currentPosition:" + currentPosition);

        remoteConfigPref=new RemoteConfigPref(this);
        currentJsonData=remoteConfigPref.getAllFace();
        parseJsonData(currentJsonData);
        setupClickListeners();
        setupViewPagerAndTabs();
    }

    private void parseJsonData(String faceData) {
//        String jsonData = JSONLoder.loadJSONFromRaw(this, R.raw.face_swap);
//        String jsonData = new RemoteConfigPref(this).getVideoSwapContent();
        String jsonData = faceData;
        Type type = new TypeToken<Map<String, JsonObject>>() {
        }.getType();
        Map<String, JsonObject> categoryMap = new Gson().fromJson(jsonData, type);

        categories.clear();
        for (Map.Entry<String, JsonObject> entry : categoryMap.entrySet()) {
            JsonObject categoryJson = entry.getValue();

            List<FaceSwapUrl> urls = parseUrls(categoryJson.getAsJsonArray("urls"));
            LocalizedName localizedName = parseLocalizedName(categoryJson.getAsJsonObject("cat_name_localised"), entry.getKey());

            categories.add(new FaceSwapCategory(
                    entry.getKey(),
                    urls,
                    getStringOrEmpty(categoryJson, "other_non_property"),
                    localizedName,
                    getStringOrDefault(categoryJson, "gender", "all")
            ));
        }
    }

    private List<FaceSwapUrl> parseUrls(JsonArray urlsArray) {
        List<FaceSwapUrl> urls = new ArrayList<>();
        if (urlsArray != null) {
            for (int i = 0; i < urlsArray.size(); i++) {
                JsonObject urlObject = urlsArray.get(i).getAsJsonObject();
                urls.add(new FaceSwapUrl(
                        getStringOrEmpty(urlObject, "tag"),
                        getStringOrEmpty(urlObject, "user_type"),
                        getStringOrEmpty(urlObject, "content"),
                        getStringOrEmpty(urlObject, "watch_ad"),
                        getStringOrEmpty(urlObject, "url")
                ));
            }
        }
        return urls;
    }

    private LocalizedName parseLocalizedName(JsonObject nameObject, String defaultName) {
        if (nameObject != null) {
            return new LocalizedName(
                    getStringOrDefault(nameObject, "en", defaultName),
                    getStringOrDefault(nameObject, "hi", defaultName)
            );
        }
        return new LocalizedName(defaultName, defaultName);
    }

    private String getStringOrEmpty(JsonObject obj, String key) {
        return obj != null && obj.has(key) ? obj.get(key).getAsString() : "";
    }

    private String getStringOrDefault(JsonObject obj, String key, String defaultValue) {
        return obj != null && obj.has(key) ? obj.get(key).getAsString() : defaultValue;
    }

    private void setupClickListeners() {
        binding.backButton.setOnClickListener(v -> finish());
        binding.filterButton.setOnClickListener(v -> toggleFilterDialog());

        // Filter options
        binding.filterOptionAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFilter("all");
                currentJsonData=(remoteConfigPref.getAllFace());
            }
        });
        binding.filterOptionMen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFilter("men");
                currentJsonData=(remoteConfigPref.getMenFace());
            }
        });
        binding.filterOptionWomen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFilter("women");
                currentJsonData=(remoteConfigPref.getWomenFace());
            }
        });
        binding.filterApplyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                setFilter("women");
                parseJsonData(currentJsonData);
                applyFilter();
            }
        });

//        binding.filterOptionAll.setOnClickListener(v -> setFilter("all"));
//        binding.filterOptionMen.setOnClickListener(v -> setFilter("men"));
//        binding.filterOptionWomen.setOnClickListener(v -> setFilter("women"));
//        binding.filterApplyButton.setOnClickListener(v -> applyFilter());
    }

    private void setupViewPagerAndTabs() {
        binding.viewPager.setAdapter(new FaceSwapPagerAdapter(this, getFilteredCategories()));

        new TabLayoutMediator(binding.tabLayout, binding.viewPager, (tab, position) -> {
            FaceSwapCategory category = getFilteredCategories().get(position);
            String tabName = category.getCatNameLocalised() != null ?
                    category.getCatNameLocalised().getEn() : category.getKey();
            tab.setText(tabName);
        }).attach();

        // Add tab selection listener to handle background changes
        binding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                View tabView = tab.view;
                if (tabView != null) {
                    tabView.setBackgroundResource(R.drawable.selected_tab);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                View tabView = tab.view;
                if (tabView != null) {
                    tabView.setBackgroundResource(R.drawable.unselected_tab);
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Handle tab reselection if needed
            }
        });

        // Set initial selection for the first tab
        if (binding.tabLayout.getTabCount() > 0) {
            TabLayout.Tab firstTab = binding.tabLayout.getTabAt(0);
            if (firstTab != null && firstTab.view != null) {
                firstTab.view.setBackgroundResource(R.drawable.selected_tab);
            }
        }

        if (currentPosition != -1) {
            binding.viewPager.setCurrentItem(currentPosition);
            currentPosition = -1;
        }
    }

    private List<FaceSwapCategory> getFilteredCategories() {
//        if ("all".equals(currentFilter))
        return categories;

//        List<FaceSwapCategory> filtered = new ArrayList<>();
//        for (FaceSwapCategory category : categories) {
//            if (currentFilter.equals(category.getGender())) {
//                filtered.add(category);
//            }
//        }
//        return filtered;
    }

    private void toggleFilterDialog() {
        boolean isVisible = binding.filterDialogCard.getVisibility() == View.VISIBLE;
        binding.filterDialogCard.setVisibility(isVisible ? View.GONE : View.VISIBLE);
    }

    private void setFilter(String filter) {
        currentFilter = filter;
        updateFilterIcons();
    }

    private void updateFilterIcons() {
        int selected = R.drawable.selected_fil;
        int unselected = R.drawable.un_selected_filter;

        binding.filterOptionAllIcon.setImageResource("all".equals(currentFilter) ? selected : unselected);
        binding.filterOptionMenIcon.setImageResource("men".equals(currentFilter) ? selected : unselected);
        binding.filterOptionWomenIcon.setImageResource("women".equals(currentFilter) ? selected : unselected);
    }

    private void applyFilter() {
        binding.filterDialogCard.setVisibility(View.GONE);
        setupViewPagerAndTabs();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}