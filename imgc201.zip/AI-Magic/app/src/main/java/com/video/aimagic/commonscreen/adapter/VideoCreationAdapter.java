package com.video.aimagic.commonscreen.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.video.aimagic.R;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VideoCreationAdapter
        extends RecyclerView.Adapter<VideoCreationAdapter.VideoViewHolder> {

    private final Context context;
    private final List<MediaItem> list;

    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public VideoCreationAdapter(Context context, List<MediaItem> list, OnItemClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.video_creation, parent, false);

        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
//        holder.setIsRecyclable(false);

        MediaItem item = list.get(position);

        Glide.with(context)
                .load(item.uri)
                .dontAnimate()
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(holder.imgThumbnail);

//        if (item.type == MediaItem.TYPE_VIDEO) {
            holder.playIcon.setVisibility(View.VISIBLE);
//        } else {
//            holder.playIcon.setVisibility(View.GONE);
//        }

        holder.imgThumbnail.setOnClickListener(v -> {
            listener.onItemClick(position);
        });

//        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
//        if (lp instanceof StaggeredGridLayoutManager.LayoutParams) {
//            ((StaggeredGridLayoutManager.LayoutParams) lp).setFullSpan(false);
//        }
    }



    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VideoViewHolder extends RecyclerView.ViewHolder {

        ImageView imgThumbnail;
        ImageView playIcon;
        TextView txtName;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            imgThumbnail = itemView.findViewById(R.id.imgThumbnail);
            playIcon = itemView.findViewById(R.id.playIcon);
            txtName = itemView.findViewById(R.id.txtTitle);
        }
    }
}
