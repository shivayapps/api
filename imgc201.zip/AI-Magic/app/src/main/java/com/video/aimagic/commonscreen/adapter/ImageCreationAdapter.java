package com.video.aimagic.commonscreen.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.makeramen.roundedimageview.RoundedImageView;
import com.video.aimagic.R;
import com.video.aimagic.utils.AspectRatioImageView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImageCreationAdapter extends RecyclerView.Adapter<ImageCreationAdapter.VideoViewHolder> {

    private final Context context;
    private final List<MediaItem> list;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public ImageCreationAdapter(Context context, List<MediaItem> list, OnItemClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.image_creation, parent, false);
        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {

        MediaItem item = list.get(position);

//        Glide.with(context)
//                .load(item.uri)
//                .dontAnimate()
//                .diskCacheStrategy(DiskCacheStrategy.NONE)
//                .into(holder.imgThumbnail);
//        Glide.with(context)
//                .load(item.uri)
//                .dontAnimate()
//                .override(Target.SIZE_ORIGINAL)
//                .diskCacheStrategy(DiskCacheStrategy.DATA)
//                .into(holder.imgThumbnail);

        int spanCount = 2;
        int spacing = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 8,
                context.getResources().getDisplayMetrics()
        );

        int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
        int columnWidth = (screenWidth - spacing * (spanCount + 1)) / spanCount;

        if (item.aspectRatio > 0) {
            int height = (int) (columnWidth / item.aspectRatio);

            ViewGroup.LayoutParams params = holder.imgThumbnail.getLayoutParams();
            params.width = columnWidth;
            params.height = height;
            holder.imgThumbnail.setLayoutParams(params);
        }

        Glide.with(context)
                .load(item.uri)
                .override(columnWidth, Target.SIZE_ORIGINAL)
                .diskCacheStrategy(DiskCacheStrategy.DATA)
                .into(holder.imgThumbnail);

        holder.imgThumbnail.setOnClickListener(v -> {
            listener.onItemClick(position);
        });

//        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
//        if (lp instanceof StaggeredGridLayoutManager.LayoutParams) {
////            setFullSpan(holder.itemView);
//            ((StaggeredGridLayoutManager.LayoutParams) lp).setFullSpan(false);
//        }
    }

    @Override
    public void onViewAttachedToWindow(@NonNull VideoViewHolder holder) {
        super.onViewAttachedToWindow(holder);

        ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
        if (lp instanceof StaggeredGridLayoutManager.LayoutParams) {
            ((StaggeredGridLayoutManager.LayoutParams) lp).setFullSpan(false);
        }
    }


    private void setFullSpan(@Nullable View view) {
        if (view != null) {
            int itemHeight = view.getLayoutParams() != null ? view.getLayoutParams().height : RecyclerView.LayoutParams.WRAP_CONTENT;

            int itemWidth = ViewGroup.LayoutParams.MATCH_PARENT;

            StaggeredGridLayoutManager.LayoutParams layoutParams = new StaggeredGridLayoutManager.LayoutParams(itemWidth, itemHeight);
            layoutParams.setFullSpan(false);
            view.setLayoutParams(layoutParams);
        }
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VideoViewHolder extends RecyclerView.ViewHolder {
        AspectRatioImageView imgThumbnail;
        TextView txtName;
        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            imgThumbnail = itemView.findViewById(R.id.imgThumbnail);
            txtName = itemView.findViewById(R.id.txtTitle);
        }
    }
}
