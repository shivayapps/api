package com.video.aimagic.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import android.widget.VideoView
import androidx.core.content.ContextCompat.startActivity
import com.bumptech.glide.Glide
import com.video.aimagic.R
import com.video.aimagic.commonscreen.screen.CommonProcessing
import com.video.aimagic.commonscreen.screen.CropScreen
import com.video.aimagic.commonscreen.screen.FeedbackDialog
import com.video.aimagic.commonscreen.screen.RatingDialog
import com.video.aimagic.utils.appconfig.getAllDeviceInfo


object Methods {


    val emailTo = "ahyansamiapps@gmail.com"

    fun rateApp(context: Context) {
        val uri = Uri.parse("market://details?id=${context.packageName}")
        val goToMarket = Intent(Intent.ACTION_VIEW, uri)
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        try {
            context.startActivity(goToMarket)
        } catch (e: ActivityNotFoundException) {
            context.startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/details?id=${context.packageName}")
                )
            )
        }
    }

    fun getBitmapFromView(view: View): Bitmap {
        val bitmap = Bitmap.createBitmap(
            view.getWidth(),
            view.getHeight(),
            Bitmap.Config.ARGB_8888
        )

        val canvas = Canvas(bitmap)
        view.draw(canvas)
        return bitmap
    }


    fun showBitmapPreviewDialog(context: Context, bitmap: Bitmap?) {
        val dialog = Dialog(context)
        dialog.setCancelable(true)

        val view: View = LayoutInflater.from(context)
            .inflate(R.layout.dialog_image_preview, null)

        val ivPreview = view.findViewById<ImageView?>(R.id.ivPreview)
        val ivClose = view.findViewById<ImageView?>(R.id.ivClose)
        val progressBar = view.findViewById<ProgressBar>(R.id.progressBar)


        Glide.with(context)
            .load(bitmap)
            .into(ivPreview)

        ivClose.setOnClickListener(View.OnClickListener { v: View? -> dialog.dismiss() })

        dialog.setContentView(view)

        // 👇 IMPORTANT: wrap content + margin from screen
        val window = dialog.getWindow()
        if (window != null) {
            window.setLayout(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            window.setDimAmount(0.8f)
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.attributes.windowAnimations = R.style.FadeDialogAnimation
        }

        dialog.show()
//        Handler(Looper.getMainLooper()).postDelayed({
//
//            Glide.with(context)
//                .load(bitmap)
//                .dontAnimate()
//                .into(ivPreview)
//
            progressBar.visibility = View.GONE
//            ivPreview.visibility = View.VISIBLE
//
//        }, 500)
        window?.let {
            val params = it.attributes
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT
            params.gravity = Gravity.CENTER
            it.attributes = params
        }
    }

    fun showImagePreviewDialog(context: Context, imageUrl: String?) {
        val dialog = Dialog(context)
        dialog.setCancelable(true)

        val view: View = LayoutInflater.from(context)
            .inflate(R.layout.dialog_image_preview, null)

        val ivPreview = view.findViewById<ImageView?>(R.id.ivPreview)
        val ivClose = view.findViewById<ImageView?>(R.id.ivClose)
        val progressBar = view.findViewById<ProgressBar?>(R.id.progressBar)

        Glide.with(context)
            .load(imageUrl)
            .into(ivPreview)

        ivClose.setOnClickListener(View.OnClickListener { v: View? -> dialog.dismiss() })

        dialog.setContentView(view)

        // 👇 IMPORTANT: wrap content + margin from screen
        val window = dialog.getWindow()
        if (window != null) {
            window.setLayout(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            window.setDimAmount(0.8f)
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.attributes.windowAnimations = R.style.FadeDialogAnimation
        }

        dialog.show()
//        Handler(Looper.getMainLooper()).postDelayed({
//
//            Glide.with(context)
//                .load(imageUrl)
//                .dontAnimate()
//                .into(ivPreview)
//
            progressBar.visibility = View.GONE
//            ivPreview.visibility = View.VISIBLE
//
//        }, 500)
        window?.let {
            val params = it.attributes
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT
            params.gravity = Gravity.CENTER
            it.attributes = params
        }
    }

    fun showVideoPreviewDialog(context: Context, videoUri: String,onDismiss:()->Unit) {

        val dialog = Dialog(context)
        dialog.setCancelable(true)

        val view = LayoutInflater.from(context)
            .inflate(R.layout.dialog_video_preview, null)

        val vvPreview = view.findViewById<VideoView>(R.id.vvPreview)
        val ivClose = view.findViewById<ImageView>(R.id.ivClose)
        val progressBar = view.findViewById<ProgressBar>(R.id.pbLoading)

        ivClose.setOnClickListener { dialog.dismiss() }

        progressBar.visibility = View.VISIBLE

        vvPreview.setVideoURI(Uri.parse(videoUri))

        vvPreview.setOnPreparedListener { mediaPlayer ->
            progressBar.visibility = View.GONE
            mediaPlayer.isLooping = true
            vvPreview.start()
        }

        vvPreview.setOnInfoListener { _, what, _ ->
            when (what) {
                MediaPlayer.MEDIA_INFO_BUFFERING_START -> {
                    progressBar.visibility = View.VISIBLE
                }

                MediaPlayer.MEDIA_INFO_BUFFERING_END -> {
                    progressBar.visibility = View.GONE
                }
            }
            true
        }

        vvPreview.setOnErrorListener { _, _, _ ->
            progressBar.visibility = View.GONE
            Toast.makeText(context, "Unable to play video", Toast.LENGTH_SHORT).show()
            true
        }

        dialog.setContentView(view)


        // 👇 IMPORTANT: wrap content + margin from screen
        val window = dialog.getWindow()
        if (window != null) {
            window.setLayout(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            window.setDimAmount(0.8f)
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.attributes.windowAnimations = R.style.FadeDialogAnimation
        }

        dialog.show()
        dialog.setOnDismissListener {
            onDismiss.invoke()
        }
        window?.let {
            val params = it.attributes
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT
            params.gravity = Gravity.CENTER
            it.attributes = params
        }
    }

    fun toastComingSoon(context: Context) {
        Toast.makeText(
            context,
            "Coming Soon",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun feedBackSupport(context: Context, feebBackText: String) {
        val emailText = feebBackText + "\n" + context.getAllDeviceInfo()
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name))
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        val uris = ArrayList<Uri>()
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        context.startActivity(Intent.createChooser(emailIntent, "Send mail..."))
    }


    fun showRatingDialog(context: Context) {
        val ratingDialog = RatingDialog(context)
        ratingDialog.show()
    }

    fun showFeedbackDialog(context: Context) {
        val feedbackDialog = FeedbackDialog(context)
        feedbackDialog.show()
    }

    fun requestBook(context: Context, tag: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$emailTo")
            when (tag) {
                "Book" -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens request")
                "feedback" -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens app Feedback")
                else -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens app Feedback")
            }
        }
        if (context.packageManager != null) startActivity(context, intent, null)
    }

    fun openLink(link: String, context: Context) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
    }


}