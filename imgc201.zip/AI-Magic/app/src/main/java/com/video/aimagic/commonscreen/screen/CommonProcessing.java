package com.video.aimagic.commonscreen.screen;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import android.window.OnBackInvokedDispatcher;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.adconfig.adsutil.admob.NativeAdHelper;
import com.adconfig.adsutil.admob.NativeLayoutType;
import com.adconfig.adsutil.utils.SmUtils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityCommonProcessingBinding;
import com.video.aimagic.aienhancer.api.post.EnhancerResponseHandler;
import com.video.aimagic.aivideos.api.post.VideoRequestManager;
import com.video.aimagic.babygen.api.BabyPredictorRequest;
import com.video.aimagic.backgroundchanger.api.ChangeBGRequest;
import com.video.aimagic.backgroundchanger.api.RemoveBGRequest;
import com.video.aimagic.callback.ApiCallback;
import com.video.aimagic.callback.ResponseCallBack;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.facedance.api.FaceDanceRequest;
import com.video.aimagic.faceswap.api.FaceSwapReq;
import com.video.aimagic.singletone.FileUtils;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.transformation.api.interfaces.CartoonCallback;
import com.video.aimagic.transformation.api.services.CartoonManager;
import com.video.aimagic.utils.ActivityUtils;
import com.video.aimagic.utils.Methods;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

//import org.greenrobot.eventbus.EventBus;
//import org.greenrobot.eventbus.Subscribe;
//import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Objects;

import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import okhttp3.ResponseBody;
import retrofit2.Response;


public class CommonProcessing extends AppCompatActivity implements CartoonCallback {

    private final String TAG = "CommonProcessing";
    private ActivityCommonProcessingBinding binding;
    private String currentFeature;
    private Handler mainHandler;
    private transient String requestId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCommonProcessingBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this,false);
        ActivityUtils.INSTANCE.register4Finish(CommonProcessing.this);

//        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this);

        currentFeature = getIntent().getStringExtra(AppConfig.INTENT_FEATURED_PASSED_AS);
        mainHandler = new Handler(Looper.getMainLooper());
        if (currentFeature == null) {
            handleError("No feature specified");
            return;
        }

        callByFeatureApi();
        loadTheAnimation();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Toast.makeText(CommonProcessing.this, "Please Wait", Toast.LENGTH_SHORT).show();
            }
        });


        String adId = getString(R.string.native_ad);
        new NativeAdHelper(
                CommonProcessing.this,
                binding.adsLayout,
                binding.adsLayout,
                NativeLayoutType.NativeBig,
                adId, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean) {
                return null;
            }
        }).loadAd();

    }
//    @Subscribe(threadMode = ThreadMode.MAIN)
//    private void onResultEvent(String result) {
//        if(Objects.equals(result, "complete")) {
//            finish();
//        }
//    }

//    override fun onDestroy() {
//        super.onDestroy()
//        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
//    }
    private void setUpSplashVideo() {

        String videoUriString =
                "android.resource://" + CommonProcessing.this.getPackageName() + "/" + R.raw.proces_1;
        Uri videoUri = Uri.parse(videoUriString);
        binding.proVideo.setVideoURI(videoUri);

        binding.proVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {

                mediaPlayer.setLooping(true);
                binding.proVideo.start();
            }
        });

        binding.proVideo.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.d(TAG, "onError:===========> what=" + what + ", extra=" + extra);
                Log.e("VideoError", "Can't play video. what=" + what + ", extra=" + extra);
                return true;
            }
        });

    }

    private void loadTheAnimation() {
        RequestOptions requestOptions1 = new RequestOptions().diskCacheStrategy(DiskCacheStrategy.DATA);
        Glide.with(CommonProcessing.this)
                .load(R.drawable.processing_gif)
                .transition(DrawableTransitionOptions.withCrossFade())
                .apply(requestOptions1)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                }).into(binding.loadingAnimation);

    }

    private void callByFeatureApi() {
        if (currentFeature == null) {
            handleError("Feature not available");
            return;
        }


        Log.e("ResultScreen", "CommonProcessing.currentFeature:" + currentFeature);
        switch (currentFeature) {
            case AppConfig.FEATURE_COUPLE:
            case AppConfig.FEATURE_INDIVISUAL:
            case AppConfig.FEATURE_AI_VIDEO_SINGLE:
                handleAIVideoFeature(new ResponseCallBack() {
                    @Override
                    public void onSuccess(String response) {
                        CommonProcessing.this.finish();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Log.d(TAG, "onError:===========> " + errorMessage);

                    }
                });
                break;
            case AppConfig.FEATURE_BABY_BOY:
            case AppConfig.FEATURE_BABY_GIRL:
                handleBabyFeature();
                break;
            case AppConfig.FEATURE_FACESWAP:
                uploadImages();
                break;
            case AppConfig.FEATURE_FACE_DANCE:
                handleFaceDanceFeature();
                break;
            case AppConfig.FEATURE_TRANSE_FACE_SWAP:
                handleTransFaceSwapFeature();
                break;
            case AppConfig.FEATURE_CHANGE_BG:
                changeBGClient(new ResponseCallBack() {
                    @Override
                    public void onSuccess(String response) {
                        CommonProcessing.this.finish();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Log.d(TAG, "onError:===========> " + errorMessage);

                    }
                });
                break;
            case AppConfig.FEATURE_REMOVE_BG:
                removeBGClient(new ResponseCallBack() {
                    @Override
                    public void onSuccess(String response) {
                        CommonProcessing.this.finish();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Log.d(TAG, "onError:===========> " + errorMessage);

                    }
                });
                break;

            case AppConfig.FEATURE_AIENHANCER:
                enhancerThePhoto(new ResponseCallBack() {
                    @Override
                    public void onSuccess(String response) {
                        CommonProcessing.this.finish();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Log.d(TAG, "onError:===========> " + errorMessage);
                    }
                });
                break;
            default:
                handleUnknownFeature(currentFeature);
                break;
        }
    }

    private void enhancerThePhoto(ResponseCallBack apiCallback) {
        EnhancerResponseHandler.getInstance(CommonProcessing.this, apiCallback).makeRequest();
    }

    private void removeBGClient(ResponseCallBack apiCallback) {
        RemoveBGRequest.getInstance(CommonProcessing.this, apiCallback).makeRequest();
    }

    private void changeBGClient(ResponseCallBack apiCallback) {
        ChangeBGRequest.getInstance(CommonProcessing.this, apiCallback).makeRequest();
    }

    private void handleBabyFeature() {
        BabyPredictorRequest.getInstance(CommonProcessing.this, new ResponseCallBack() {
            @Override
            public void onSuccess(String response) {
                Log.d(TAG, "onSuccess:===========> " + response);
//                CommonProcessing.this.finish();
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    CommonProcessing.this.finish();
                }, 50);
            }

            @Override
            public void onError(String errorMessage) {
                Log.d(TAG, "onError:===========> " + errorMessage);

            }
        }).makeRequest();
    }

    private void handleAIVideoFeature(ResponseCallBack apiCallback) {
        VideoRequestManager.getSharedInstance(apiCallback).executeVideoConversionRequest(CommonProcessing.this);
    }


    private void handleError(String errorMessage) {
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void handleUnknownFeature(String feature) {
        Log.e("CommonProcessing", "Unknown feature: " + feature);
        handleError("Unsupported feature: " + feature);
    }


    private void handleFaceDanceFeature() {
        FaceDanceRequest.getInstance(CommonProcessing.this, new ResponseCallBack() {
            @Override
            public void onSuccess(String response) {
                CommonProcessing.this.finish();
            }

            @Override
            public void onError(String errorMessage) {
                Log.d("FaceDance", "Common Processing onError::" + errorMessage);

            }
        }).makeRequest();
    }

    private void handleTransFaceSwapFeature() {
        Log.d("CommonProcessing", "Handling trans face swap feature");
        String actualFcmToken = "f0FmZMczSOGuy1OWbjIANh:APA91bHEbepPVgX6-z3Da86MJjRfQY5EVvfWNDRtFf74dVJ3T3kx5JZYDyLA7iIWAOuRHLNOTCvnmwdb7hN1EcAJiOt5yQ6JNxnfTivePaM419_2nVVolbEm_NlzWGGzxpXqjuGV-fMN";
        String actualAppCheckToken = "eyJraWQiOiJYcEhKU0EiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxOjM5ODIzMDg3ODg2MzphbmRyb2lkOjQwNjIxYzNjNzI4YTc4OGI4ZDBlZmEiLCJhdWQiOlsicHJvamVjdHNcLzM5ODIzMDg3ODg2MyIsInByb2plY3RzXC9mYWNlLXN3YXAtbWFnaWMtYzU4ZGQiXSwicHJvdmlkZXIiOiJkZWJ1ZyIsImlzcyI6Imh0dHBzOlwvXC9maXJlYmFzZWFwcGNoZWNrLmdvb2dsZWFwaXMuY29tXC8zOTgyMzA4Nzg4NjMiLCJleHAiOjE3MTQzODIxMjAsImlhdCI6MTcxNDM3ODUyMCwianRpIjoia3M3TXB2Yk1Qcmx6VFpVY04xcDRFTEhzVTZLZ05iLVAwQ3VONXY4TUZ5NCJ9.NHI10JR5S8Ut_uEdDFz44KIERlZKnTlDw3bPc6CuAQUvFdwtqyLr73i0AcAw5F9YBE4bC-1cNHbt2gmJw3ZRo_uYHcL3rLBWpW_eaoUCLXhj58b7WVh8Bvd9aRavBnC3ZwTo79jxO-pqCW--moESVt1hR4FDgAEEOsI_7CYbv50EZ15O12ndFv_FGUg1VxxfEbk79lrN4Gfo6WhPmTZLhJQL0_wzZ4tHdFh54wjQqoHO2dWfpbh0kdw23j7DFvEB6jxgbTgSxvufL8RwRGdGZ8duY_Cf6LzRwOYMmH6_AClaoHL9wycfKTxDDUwk_L_8xnEIfehmvD5b3PJSSgnAVtzD5ACTMW0L_M6DxeG1O0pJS9P58df_GCo0trNuuTUIIE0p5Ij2lKBuNwa8-cV60iiEID9v_uC9kur9GB6o6DsLSVTrWHK_7966OIi8scV1EP9Aup3cPxkGZZk2SNsLUKUvgEGoTT0DtySgVcqUpr77qnyNg01tEg9li_XA5XeG";
        CartoonManager.initialize(actualFcmToken, actualAppCheckToken);
        CartoonManager.setActivity(this);
        generateCartoon();
    }

    private void generateCartoon() {
        if (CartoonManager.isInitialized()) {
            CartoonManager.generateCartoon(PhotoUploadManager.getInstance().getCurrentImageUriStringPath());
        } else {
            Log.d("CommonProcessing", "!isInitialized");
        }
    }


    private void uploadImages() {
        String bikeImageName = AppConfig.SELECTED_FACE_SWAP_URL_NAME_FOLDER_IMAGE_NAME;
        String sourceImagePath = PhotoUploadManager.getInstance().getCurrentImageUriStringPath();
        String fcmToken = "f0FmZMczSOGuy1OWbjIANh:APA91bHEbepPVgX6-z3Da86MJjRfQY5EVvfWNDRtFf74dVJ3T3kx5JZYDyLA7iIWAOuRHLNOTCvnmwdb7hN1EcAJiOt5yQ6JNxnfTivePaM419_2nVVolbEm_NlzWGGzxpXqjuGV-fMN";
        String appCheckToken = "eyJraWQiOiJYcEhKU0EiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxOjM5ODIzMDg3ODg2MzphbmRyb2lkOjQwNjIxYzNjNzI4YTc4OGI4ZDBlZmEiLCJhdWQiOlsicHJvamVjdHNcLzM5ODIzMDg3ODg2MyIsInByb2plY3RzXC9mYWNlLXN3YXAtbWFnaWMtYzU4ZGQiXSwicHJvdmlkZXIiOiJkZWJ1ZyIsImlzcyI6Imh0dHBzOlwvXC9maXJlYmFzZWFwcGNoZWNrLmdvb2dsZWFwaXMuY29tXC8zOTgyMzA4Nzg4NjMiLCJleHAiOjE3MTQzODIxMjAsImlhdCI6MTcxNDM3ODUyMCwianRpIjoia3M3TXB2Yk1Qcmx6VFpVY04xcDRFTEhzVTZLZ05iLVAwQ3VONXY4TUZ5NCJ9.NHI10JR5S8Ut_uEdDFz44KIERlZKnTlDw3bPc6CuAQUvFdwtqyLr73i0AcAw5F9YBE4bC-1cNHbt2gmJw3ZRo_uYHcL3rLBWpW_eaoUCLXhj58b7WVh8Bvd9aRavBnC3ZwTo79jxO-pqCW--moESVt1hR4FDgAEEOsI_7CYbv50EZ15O12ndFv_FGUg1VxxfEbk79lrN4Gfo6WhPmTZLhJQL0_wzZ4tHdFh54wjQqoHO2dWfpbh0kdw23j7DFvEB6jxgbTgSxvufL8RwRGdGZ8duY_Cf6LzRwOYMmH6_AClaoHL9wycfKTxDDUwk_L_8xnEIfehmvD5b3PJSSgnAVtzD5ACTMW0L_M6DxeG1O0pJS9P58df_GCo0trNuuTUIIE0p5Ij2lKBuNwa8-cV60iiEID9v_uC9kur9GB6o6DsLSVTrWHK_7966OIi8scV1EP9Aup3cPxkGZZk2SNsLUKUvgEGoTT0DtySgVcqUpr77qnyNg01tEg9li_XA5XeG";
        String appName = AppConfig.DEFAULT_APP_NAME;

        if (!FileUtils.fileExists(sourceImagePath)) {
            Toast.makeText(this, "Image file is not available. Please select image again.", Toast.LENGTH_SHORT).show();
            return;
        }

        FaceSwapReq.getInstance().uploadImages(
                this,
                bikeImageName,
                sourceImagePath,
                fcmToken,
                appCheckToken,
                appName
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this);
        binding = null;
    }

    @Override
    public void onCartoonSuccess(Response<ResponseBody> response) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    // Print response details
                    Log.d("CartoonResponse", "Response code: " + response.code());
                    Log.d("CartoonResponse", "Response message: " + response.message());
                    Log.d("CartoonResponse", "Response headers: " + response.headers().toString());

                    if (response.isSuccessful() && response.body() != null) {
                        // Read the response body
                        String responseBody = response.body().string();
                        Log.d("CartoonResponse", "Response body: " + responseBody);

                        // Extract the request_id from JSON response
                        JSONObject jsonResponse = new JSONObject(responseBody);
                        requestId = jsonResponse.getString("request_id");


//                        Toast.makeText(CommonProcessing.this,
//                                "Cartoon generated successfully!",
//                                Toast.LENGTH_SHORT).show();

                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // Call processToNextScreen with the extracted requestId
                                processToNextScreen(requestId);
                            }
                        }, 10000); // 10000 milliseconds = 10 seconds

                    } else {
                        String errorBody = "";
                        if (response.errorBody() != null) {
                            errorBody = response.errorBody().string();
                        }
                        Log.e("CartoonResponse", "Error response: " + errorBody);
                        Log.e("CartoonResponse", "Error code: " + response.code());

                        Toast.makeText(CommonProcessing.this,
                                "Server error: " + response.code() + " - " + errorBody,
                                Toast.LENGTH_LONG).show();
                    }
                } catch (IOException e) {
                    Log.e("CartoonResponse", "Error reading response: " + e.getMessage());
                    Toast.makeText(CommonProcessing.this,
                            "Error processing response: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    Log.e("CartoonResponse", "Error parsing JSON: " + e.getMessage());
                    Toast.makeText(CommonProcessing.this,
                            "Error parsing server response: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void processToNextScreen(String requestId) {
        if (SmUtils.INSTANCE.isConnected(this)) {
            Log.d(TAG, "Generate face swap button clicked");

            Intent intent = new Intent(this, CommonResultScreen.class);
            intent.putExtra(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId);
            intent.putExtra(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_TRANSE_FACE_SWAP);
            startActivity(intent);
            overridePendingTransition(
                    R.anim.cusotm_slide_in_right,
                    R.anim.custom_slide_out_left
            );
            CommonProcessing.this.finish();

//            StartActivityGlobally.
//                    navigateToActivityWithFeature(
////                    CommonProcessing.this,
////                    CommonResultScreen.class,
//                    new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
//                    new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_TRANSE_FACE_SWAP)
//            );


        } else {
            Toast.makeText(this, "Please connect to internet.", Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    public void onCartoonError(String errorMessage) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(CommonProcessing.this,
                        "Error: " + errorMessage,
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onCartoonNetworkError() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(CommonProcessing.this,
                        "Network error - please check your internet connection",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onCartoonUnknownError() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(CommonProcessing.this,
                        "An unknown error occurred. Please try again.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}