package com.video.aimagic.commonscreen.screen

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RatingBar
import com.video.aimagic.R
import com.video.aimagic.databinding.DialogFeedbackBinding
import com.video.aimagic.databinding.DialogRatingBinding
import com.video.aimagic.utils.Methods

class FeedbackDialog(context: Context) : Dialog(context),
    View.OnClickListener {
    private lateinit var binding: DialogFeedbackBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DialogFeedbackBinding.inflate(layoutInflater)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        setContentView(
            binding.root
        )
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        initViews()
    }

    private fun initViews() {
        binding.submitBtn.apply {
            setOnClickListener(this@FeedbackDialog)
        }
        binding.cancelBtn.apply {
            setOnClickListener(this@FeedbackDialog)
        }

    }


    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.submitBtn -> {
                val feebBackText=binding.edtText.text.toString()
                if(feebBackText.isNotEmpty()) {
                    Methods.feedBackSupport(context,feebBackText)
                    dismiss()
                }else{
                    binding.edtText.error="Please enter feedback"
                }
                //requestBook(context, "feedback")
            }

            R.id.cancelBtn -> {
                dismiss()
            }
        }
    }
}