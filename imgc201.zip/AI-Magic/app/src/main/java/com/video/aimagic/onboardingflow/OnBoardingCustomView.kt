package com.video.aimagic.onboardingflow

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.video.aimagic.R
import com.video.aimagic.databinding.CustomOnboardingViewBinding
import com.video.aimagic.onboardingflow.core.TutorialSlidesAdapter
import com.video.aimagic.onboardingflow.core.applyParallaxEffect
import com.video.aimagic.onboardingflow.dataset.CustomOnBoardingPage
import com.video.aimagic.onboardingflow.dataset.CustomOnBoardingPrefManager
import com.video.aimagic.commonscreen.screen.HomeScreen

class OnBoardingCustomView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : FrameLayout(context, attrs, defStyleAttr, defStyleRes) {

    private companion object {
        private const val TAG = "OnBoardingCustomView"
    }

    private val binding: CustomOnboardingViewBinding by lazy {
        CustomOnboardingViewBinding.inflate(LayoutInflater.from(context), this, true)
    }

    private val prefManager: CustomOnBoardingPrefManager by lazy {
        CustomOnBoardingPrefManager(context)
    }

    private val adapter: TutorialSlidesAdapter by lazy {
        TutorialSlidesAdapter()
    }

    private val numberOfPages: Int by lazy {
        CustomOnBoardingPage.entries.size
    }

    private val pageChangeCallback = object : ViewPager2.OnPageChangeCallback() {
        override fun onPageSelected(position: Int) {
            handlePageSelection(position)
        }

        override fun onPageScrollStateChanged(state: Int) {
            handleScrollStateChange(state)
        }

        override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
            // Optional: Handle scroll if needed
        }
    }

    init {
        initializeView()
    }

    private fun initializeView() {
        configureSlider()
        setupEventListeners()
        applyTransformations()
    }

    private fun configureSlider() {
        // Set adapter first
        binding.slider.adapter = adapter

        // Register page change callback
        binding.slider.registerOnPageChangeCallback(pageChangeCallback)
        binding.slider.currentItem = 0

        // Wait for the ViewPager2 to be laid out before attaching indicator
//        binding.slider.doOnLayout {
        binding.pageIndicator.attachTo(binding.slider)
//        }
    }

    private fun setupEventListeners() {
        binding.nextBtn.setOnClickListener {
            handleNextButtonClick()
        }
        binding.skipBtn.setOnClickListener {
            handleSkipButtonClick()
        }
    }

    private fun applyTransformations() {
        binding.slider.setPageTransformer { page, position ->
            applyParallaxEffect(page, position)
        }
    }

    private fun handlePageSelection(position: Int) {
        adapter.updateActiveSlide(position)
        updateNextButtonAppearance(position)
    }

    private fun updateNextButtonAppearance(position: Int) {
        with(binding.nextBtn) {
            text = if (position == numberOfPages - 1) {
                "Get Started"
            } else {
                resources.getString(R.string.next)
            }

            setTextColor(
                Color.parseColor(
                    if (position == numberOfPages - 1) "#FFFFFF" else "#FFFFFF"
                )
            )

            background = ContextCompat.getDrawable(
                context,
                if (position == numberOfPages - 1) R.drawable.next_btn_clr_code else R.drawable
                    .pro_gradient_home_code
            )
        }
    }

    private fun handleScrollStateChange(state: Int) {
        if (state == ViewPager2.SCROLL_STATE_DRAGGING) {
            adapter.pauseActiveMedia()
        }
    }

    private fun handleNextButtonClick() {
        val nextPosition = binding.slider.currentItem + 1
        if (nextPosition < numberOfPages) {
            navigateToSlide(nextPosition)
        } else {
            completeOnboarding()
        }
    }

    private fun navigateToSlide(position: Int) {
        binding.slider.setCurrentItem(position, true)
    }

    private fun handleSkipButtonClick() {
        navigateToHomeScreen()
    }

    private fun completeOnboarding() {
        Log.d(TAG, "Navigating to MainActivity")
        prefManager.initialAppLaunch = false
        navigateToHomeScreen()
    }

    private fun navigateToHomeScreen() {
        adapter.stopAllMediaPlayback()

        Intent(context, HomeScreen::class.java).apply {
            putExtra("fromSplash", "toHome")
        }.also { intent ->
            context.startActivity(intent)
            (context as Activity).apply {
                overridePendingTransition(
                    R.anim.cusotm_slide_in_right,
                    R.anim.custom_slide_out_left
                )
                finish()
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        binding.slider.unregisterOnPageChangeCallback(pageChangeCallback)
        adapter.pauseActiveMedia()
    }
}

inline fun View.doOnLayout(crossinline action: (view: View) -> Unit) {
    if (isLaidOut) {
        action(this)
    } else {
        addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
            override fun onLayoutChange(
                view: View,
                left: Int, top: Int, right: Int, bottom: Int,
                oldLeft: Int, oldTop: Int, oldRight: Int, oldBottom: Int
            ) {
                view.removeOnLayoutChangeListener(this)
                action(view)
            }
        })
    }
}