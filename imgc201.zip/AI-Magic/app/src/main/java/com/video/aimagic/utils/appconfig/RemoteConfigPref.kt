package com.video.aimagic.utils.appconfig

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.android.gms.common.Feature
import com.google.android.gms.tasks.Task
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import org.json.JSONException
import java.lang.Void


class RemoteConfigPref(var context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("remote_config_prefs", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = prefs.edit()


    var isRemoteInit: Boolean
        get() = prefs.getBoolean("is_remote_init", false)
        set(value) = prefs.edit().putBoolean("is_remote_init", value).apply()
    var allFace: String
        get() = prefs.getString("all_face", "") ?: ""
        set(value) = prefs.edit().putString("all_face", value).apply()
    var menFace: String
        get() = prefs.getString("men_face", "") ?: ""
        set(value) = prefs.edit().putString("men_face", value).apply()

    var womenFace: String
        get() = prefs.getString("women_face", "") ?: ""
        set(value) = prefs.edit().putString("women_face", value).apply()
    var videoSwapContent: String
        get() = prefs.getString("videoswapcontent", "") ?: ""
        set(value) = prefs.edit().putString("videoswapcontent", value).apply()
    var appContent: String
        get() = prefs.getString("appcontent", "") ?: ""
        set(value) = prefs.edit().putString("appcontent", value).apply()
    var lipSyncJson: String
        get() = prefs.getString("lipsyncjson", "") ?: ""
        set(value) = prefs.edit().putString("lipsyncjson", value).apply()
    var faceDanceEffectJson: String
        get() = prefs.getString("faceDanceEffectJson", "") ?: ""
        set(value) = prefs.edit().putString("faceDanceEffectJson", value).apply()
    var greetingsJson: String
        get() = prefs.getString("greetingsjson", "") ?: ""
        set(value) = prefs.edit().putString("greetingsjson", value).apply()

    fun setString(key: String, result: String) {
        editor.putString(key, result)
        editor.apply()
    }

    fun getString(key: String, default: String? = ""): String {
        return prefs.getString(key, default!!) ?: ""
    }

}


fun Context.initFirebaseConfig(successListener: (success: Boolean) -> Unit = {}) {
    Log.e("fireBaseConfigGet", "initFirebaseConfig")

    try {
        val remotePref = RemoteConfigPref(this)

        val remoteConfig = FirebaseRemoteConfig.getInstance()

        remoteConfig.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(5)
                .setFetchTimeoutInSeconds(5)
                .build()
        )
//            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
        remoteConfig.fetch(0)
            .addOnCompleteListener { task: Task<Void?> ->
                if (task.isSuccessful) {
                    Log.e("fireBaseConfigGet", "Successful")
                    remoteConfig.fetchAndActivate()
                    try {

                        val allFace = remoteConfig.getString("all_face")
                        remotePref.allFace = allFace
                        val menFace = remoteConfig.getString("men_face")
                        remotePref.menFace = menFace

                        val womenFace = remoteConfig.getString("women_face")
                        remotePref.womenFace = womenFace
                        val videoSwapContent = remoteConfig.getString("videoswapcontent")
                        remotePref.videoSwapContent = videoSwapContent
                        val appContent = remoteConfig.getString("appcontent")
                        remotePref.appContent = appContent
                        val lipSyncJson = remoteConfig.getString("lipsyncjson")
                        remotePref.lipSyncJson = lipSyncJson
                        val faceDanceEffectJson = remoteConfig.getString("faceDanceEffectJson")
                        remotePref.faceDanceEffectJson = faceDanceEffectJson
                        val greetingsJson = remoteConfig.getString("greetingsjson")
                        remotePref.greetingsJson = greetingsJson

                        Log.e("fireBaseConfigGet", "successListener.invoke")
                        Log.e("fireBaseConfigGet", "successListener.allFace:$allFace")
                        Log.e("fireBaseConfigGet", "successListener.menFace:$menFace")
                        Log.e("fireBaseConfigGet", "successListener.womenFace:$womenFace")

                        Log.e(
                            "fireBaseConfigGet",
                            "successListener.videoSwapContent:$videoSwapContent"
                        )
                        Log.e("fireBaseConfigGet", "successListener.appContent:$appContent")
                        Log.e("fireBaseConfigGet", "successListener.lipSyncJson:$lipSyncJson")
                        Log.e(
                            "fireBaseConfigGet",
                            "successListener.faceDanceEffectJson:$faceDanceEffectJson"
                        )
                        Log.e("fireBaseConfigGet", "successListener.greetingsJson:$greetingsJson")
                        successListener.invoke(true)
                        remotePref.isRemoteInit = true
                    } catch (e: JSONException) {
                        Log.e("fireBaseConfigGet", "JSONException:$e")
                        successListener.invoke(false)
                    }
                } else {
                    Log.e("fireBaseConfigGet", "Failed:${task.exception}")
                    successListener.invoke(false)
                }
            }
    } catch (e: java.lang.Exception) {
        Log.e("fireBaseConfigGet", "printStackTrace:$e")
        successListener.invoke(false)
    }
}
