package com.video.aimagic.commonscreen.screen

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.video.aimagic.R
import com.video.aimagic.commonscreen.adapter.DrawableAdapter
import com.video.aimagic.commonscreen.data.DrawableCategory
import com.video.aimagic.commonscreen.data.DrawableProvider
import com.video.aimagic.commonscreen.data.OnDrawableSelectedListener

class DrawableListFragment : Fragment() {

    private lateinit var category: DrawableCategory

    private var callback: OnDrawableSelectedListener? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        callback = parentFragment as? OnDrawableSelectedListener
    }

    override fun onDetach() {
        super.onDetach()
        callback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        category = arguments?.getSerializable(ARG_CATEGORY) as DrawableCategory
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_drawable_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)

        recyclerView.layoutManager = GridLayoutManager(requireContext(), 3)
        recyclerView.adapter = DrawableAdapter(
            DrawableProvider.getDrawables(category)
        ){ drawableRes ->
            callback?.onDrawableSelected(category, drawableRes)
        }
    }

    companion object {
        private const val ARG_CATEGORY = "arg_category"

        fun newInstance(category: DrawableCategory): DrawableListFragment {
            return DrawableListFragment().apply {
                arguments = Bundle().apply {
                    putSerializable(ARG_CATEGORY, category)
                }
            }
        }
    }
}
