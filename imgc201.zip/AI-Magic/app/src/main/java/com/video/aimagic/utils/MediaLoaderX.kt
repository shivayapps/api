package com.video.aimagic.utils

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import com.video.aimagic.commonscreen.adapter.MediaItem
import kotlinx.coroutines.*
import java.io.File
import java.util.Calendar

val SORT_NAME: Int = 1

//    val SORT_PATH: Int = 2
val SORT_SIZE: Int = 3
val SORT_DATE: Int = 4
val ORDER_ASCENDING: Int = 1
val ORDER_DESCENDING: Int = 2

fun String.getFilenameFromPath() = substring(lastIndexOf("/") + 1)
fun String.getParentPath() = removeSuffix("/${getFilenameFromPath()}")
fun String.getParentFolder() = getParentPath().getFilenameFromPath()

val photoExtensions: Array<String>
    get() = arrayOf(
        ".jpg",
        ".png",
        ".jpeg",
        ".bmp",
        ".webp",
        ".heic",
        ".heif",
        ".apng",
        ".avif"
    )
val videoExtensions: Array<String>
    get() = arrayOf(
        ".mp4",
        ".mkv",
        ".webm",
        ".avi",
        ".3gp",
        ".mov",
        ".m4v",
        ".3gpp"
    )

class MediaLoaderX(
    private val mContext: Context,
    var loadImage: Boolean = true,
    var loadVideo: Boolean = true,
) {

    private val TAG = "MediaLoaderX"
    private var ROOT_PATH = ""
    private var mJob: Job = Job()
    var recentEndDate = Calendar.getInstance()
    var recentStartDate = Calendar.getInstance()

    val projectionImage = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DATA,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
    )
    val projectionVideo = arrayOf(
        MediaStore.Video.VideoColumns._ID,
        MediaStore.Video.VideoColumns.DATA,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.VideoColumns.SIZE,
        MediaStore.Video.VideoColumns.DURATION,
        MediaStore.Video.VideoColumns.DATE_MODIFIED,
        MediaStore.Video.VideoColumns.DATE_TAKEN,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
    )


    fun refreshLoader(prefKey: String) {
//        sortType = SORT_DATE
//        sortOrder = ORDER_DESCENDING
    }

    init {
//        refreshLoader(prefKey)

        recentEndDate = Calendar.getInstance()
        recentStartDate = Calendar.getInstance()
        recentStartDate.add(Calendar.DATE, -15)
    }


    fun getAllMedia(
        folderPath: String,
        onSuccess: (images: List<MediaItem>, videos: List<MediaItem>) -> Unit,
        onFailed: (String) -> Unit
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val images = getImages(folderPath)
                val videos = getVideos(folderPath)

                withContext(Dispatchers.Main) {
                    onSuccess(images, videos)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed(e.message ?: "Failed to load media")
                }
            }
        }
    }

    private fun getImages(folderPath: String): ArrayList<MediaItem> {
        val list = arrayListOf<MediaItem>()

        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        val cursor = mContext.contentResolver.query(
            uri,
            projectionImage,
            null,
            null,
            MediaStore.Images.Media.DATE_MODIFIED + " DESC"
        )

        Log.e(TAG,"getImages.cursor:${cursor?.columnCount}")
        Log.e(TAG,"getImages.folderPath:${folderPath.getFilenameFromPath()}")
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val name = it.getString(nameCol)
                val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                var bucketName =
                    it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                        ?: path.getParentFolder()


                val contentUri = ContentUris.withAppendedId(uri, id)

                Log.e(TAG,"getImages.bucketName:${bucketName}")
                if (bucketName == folderPath.getFilenameFromPath())
                    list.add(
                        MediaItem(
                            name,
                            contentUri,
                            MediaItem.TYPE_IMAGE,
                            0L
                        )
                    )
            }
        }

        return list
    }

    private fun getVideos(folderPath: String): ArrayList<MediaItem> {
        val list = arrayListOf<MediaItem>()

        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val cursor = mContext.contentResolver.query(
            uri,
            projectionVideo,
            null,
            null,
            MediaStore.Video.Media.DATE_MODIFIED + " DESC"
        )

        Log.e(TAG,"getVideos.cursor:${cursor?.columnCount}")
        Log.e(TAG,"getVideos.folderPath:${folderPath.getFilenameFromPath()}")
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durationCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)

            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val name = it.getString(nameCol)
                val duration = it.getLong(durationCol)
                val path = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                var bucketName =
                    it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                        ?: path.getParentFolder()

                val contentUri = ContentUris.withAppendedId(uri, id)

                Log.e(TAG,"getVideos.bucketName:${bucketName}")
                if (bucketName == folderPath.getFilenameFromPath())
                    list.add(
                        MediaItem(
                            name,
                            contentUri,
                            MediaItem.TYPE_VIDEO,
                            duration
                        )
                    )
            }
        }

        return list
    }


    private fun getFolderSelection(folderPath: String): String? {
        return if (folderPath.isNotEmpty()) {
            "${MediaStore.MediaColumns.DATA} LIKE ?"
        } else {
            null
        }
    }

    private fun getFolderSelectionArgs(folderPath: String): Array<String>? {
        return if (folderPath.isNotEmpty()) {
            arrayOf("$folderPath/%")
        } else {
            null
        }
    }

    fun applyMediaSorting(
        list: MutableList<MediaItem>,
        sortType: Int,
        sortOrder: Int
    ): List<MediaItem> {

        val comparator = when (sortType) {
            SORT_NAME -> compareBy<MediaItem> { it.name.lowercase() }
            SORT_DATE -> compareBy<MediaItem> { it.uri.lastPathSegment ?: "" }
            else -> compareBy { it.name }
        }

        return if (sortOrder == ORDER_ASCENDING) {
            list.sortedWith(comparator)
        } else {
            list.sortedWith(comparator.reversed())
        }
    }


    private fun getSelectionQuery(): String {
        val query = StringBuilder()
//        if (filterMedia and TYPE_IMAGES != 0) {
        photoExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

//        if (filterMedia and TYPE_VIDEOS != 0) {
        videoExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
//        }

//        if (filterMedia and TYPE_GIFS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
        return query.toString().trim().removeSuffix("OR")
    }

    fun destroyLoader() {
        mJob.cancel()
    }

}
