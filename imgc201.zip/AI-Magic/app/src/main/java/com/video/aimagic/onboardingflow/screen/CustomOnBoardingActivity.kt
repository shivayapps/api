package com.video.aimagic.onboardingflow.screen


import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.video.aimagic.databinding.ActivityCustomOnBoardingBinding
import com.video.aimagic.extension.applySystemBarInsets
import com.video.aimagic.extension.setStatusBarFontColor
import com.video.aimagic.utils.appconfig.initFirebaseConfig

class CustomOnBoardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCustomOnBoardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomOnBoardingBinding.inflate(layoutInflater)
        this.enableEdgeToEdge()
        setContentView(binding.root)
        binding.root.applySystemBarInsets()
        setStatusBarFontColor(false)
        hideSystemUI()
        initFirebaseConfig {}
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.apply {
                hide(WindowInsets.Type.systemBars())
                systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_FULLSCREEN
                    )
        }
    }

    override fun onBackPressed() {
    }
}