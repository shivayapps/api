package com.adconfig.adsutil

object SmSession {

    var isLibraryInitialized = false
    var IS_DEBUG = true
    var admobInterstitialAdId: String = "ca-app-pub-2750800778809761/6579918502"
    var admobAppOpenId: String = "ca-app-pub-2750800778809761/1021852955"
    var admobBannerId: String = "ca-app-pub-2750800778809761/9206081840"
    var admobNativeId: String = "ca-app-pub-2750800778809761/9353421501"
    var admobRewardId: String = "ca-app-pub-3940256099942544/5224354917"
    var adNetwork: AdNetwork = AdNetwork.ADMOB

}