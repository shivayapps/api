package com.backup.restore.device.image.recovery.ads.inapp

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.Purchase
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.utilities.fontPath
import com.example.jdrodi.utilities.OnPositive
import com.example.jdrodi.utilities.showAlert
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.annotations.NotNull


const val PLAY_STORE_SUBSCRIPTION_URL = "https://play.google.com/store/account/subscriptions"
const val PLAY_STORE_SUBSCRIPTION_DEEPLINK_URL = "https://play.google.com/store/account/subscriptions?sku=%s&package=%s"

// Products Id's
const val SUB_MONTHLY = "com.backupandrecovery.purchase.monthly"
const val SUB_YEARLY = "com.backupandrecovery.purchase.yearly"
const val PRODUCT_PURCHASED = "com.backupandrecovery.adremoved"
// const val PRODUCT_PURCHASED = "android.test.purchased"

// List of purchased products
val purchaseHistory: ArrayList<Purchase> = ArrayList()

// List of available products to buy
val PRODUCT_LIST: ArrayList<DaoProducts> = ArrayList()

// SKU list
val skuPurchaseList = listOf(PRODUCT_PURCHASED)
val skuSubList = listOf(SUB_MONTHLY,SUB_YEARLY)

fun Context.showPurchaseAlert(@NotNull productId: String, fIsConsumable: Boolean) {
    val title = getString(R.string.app_name)
    val message = getString(R.string.ask_remove_ads)
    val positiveBtn = resources.getString(R.string.dialog_yes)
    val negativeBtn = resources.getString(R.string.dialog_no)
    showAlert(title, message, positiveBtn, negativeBtn, fontPath, object : OnPositive {
        override fun onYes() {
            GlobalScope.launch {
                InAppPurchaseHelper.instance!!.purchaseProduct(productId, fIsConsumable)
            }
        }
    })
}


fun Activity.showPurchaseSuccess() {
    val title = getString(R.string.app_name)
    val message = resources.getString(R.string.remove_ads_msg)
    val positiveBtn = resources.getString(R.string.dialog_ok)

//    if (!AdsManager(this).isDialogShowing()) {
//        AdsManager(this).saveDialogStatus(true)
        showAlert(title, message, positiveBtn, null, fontPath, object : OnPositive {
            override fun onYes() {
//                AdsManager(this@showPurchaseSuccess).saveDialogStatus(false)
            }
        })
//    }
}

//fun Context.showPurchaseAlert() {
//    showAlertInfo(getString(R.string.app_name), getString(R.string.remove_ads_msg))
//}
