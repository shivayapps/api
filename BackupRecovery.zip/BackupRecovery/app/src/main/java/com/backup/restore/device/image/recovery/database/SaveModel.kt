package com.backup.restore.device.image.recovery.database
//
//class SaveModel(
//    var id : Int,
//    var savePath : String,
//    var saveValue: String
//)