package com.backup.restore.device.image.recovery.utilities.common;

//import static com.backup.restore.device.image.recovery.utilities.common.MyUtils.getSDCardPath;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.MediaStore.Files;
import android.util.Log;

import androidx.documentfile.provider.DocumentFile;

import com.backup.restore.device.image.recovery.duplicatenew.models.DuplicateGroupModel;
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails;
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFileRemoverSharedPreferences;
import com.backup.restore.device.image.recovery.mainduplicate.model.IndividualGroupModel;
import com.backup.restore.device.image.recovery.mainduplicate.model.ItemDuplicateModel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class GlobalVarsAndFunctions {
    public static final String KEY_EXTENSION = "extension";
    public static final String DATABASE_NAME = "duplicateFilesDb";
    public static final String TABLE_ALL_FILES_INFO = "allFilesInfoTable";
    public static final String TABLE_ALL_FILES_INFO_NOTIFICATION = "allFilesInfoTableNotification";

    public static final String KEY_MD5 = "md5";
    public static final String KEY_PATH = "path";

    public static final String ZIP = ".zip";
    public static final String APK = ".apk";
    public static final String VCF = ".vcf";
    public static final String OGGOTHER = ".ogg";
    public static final String DB = ".db";
    public static final String OGG = ".ogg";
    public static final String AAC = ".aac";
    public static final String ABMP = ".BMP";
    public static final String AJPEG = ".JPEG";
    public static final String WEBP = ".webp";
    public static final String AJPG = ".JPG";
    public static final String APNG = ".PNG";
    public static final String ASF = ".asf";
    public static final String AVI = ".avi";
    public static final String BMP = ".bmp";
    public static final String CHM = ".chm";
    public static final String CPT = ".cpt";
    public static final String CR2 = ".cr2";
    public static final String CRW = ".crw";
    public static final String CSV = ".csv";
    public static final String DIVX = ".divx";
    public static final String DNG = ".dng";
    public static final String DOC = ".doc";
    public static final String DOCX = ".docx";
    public static final String DWG = ".dwg";
    public static final String GIF = ".gif";
    public static final String GP3 = ".3gp";
    public static final String GP33 = ".3gpp";
    public static final String JPEG = ".jpeg";
    public static final String HEIC = ".heic";
    public static final String JPG = ".jpg";
    public static final String KDC = ".kdc";
    public static final String M4A = ".m4a";
    public static final String M4V = ".m4v";
    public static final String MOV = ".mov";
    public static final String MP3 = ".mp3";
    public static final String MP4 = ".mp4";
    public static final String MKV = ".mkv";
    public static final String NRW = ".NRW";
    public static final String PCD = ".pcd";
    public static final String PDF = ".pdf";
    public static final String ORF = ".orf";
    public static final String PIC = ".pic";
    public static final String PNG = ".png";
    public static final String PPT = ".ppt";
    public static final String PPTX = ".pptx";
    public static final String PSD = ".psd";
    public static final String RAW = ".raw";
    public static final String RTF = ".rtf";
    public static final String SR2 = ".sr2";
    public static final String SRF = ".srf";
    public static final String TIF = ".tif";
    public static final String TIFF = ".tiff";
    public static final String TXT = ".txt";
    public static final String WAV = ".wav";
    public static final String WMA = ".wma";
    public static final String WMV = ".wmv";
    public static final String WPG = ".wpg";
    public static final String XLS = ".xls";
    public static final String XLSX = ".xlsx";
    public static final String XLT = ".xlt";
    public static final String XLTX = ".xltx";
    public static final String XVID = ".xvid";
    public static final String RATE = "RATE";

    public static boolean ONE_TIME_DUPLICATE_INFORMATION_POPUP = false;
    public static boolean ONE_TIME_POPUP_AUDIOS = false;
    public static boolean ONE_TIME_POPUP_DOCUMENTS = false;
    public static boolean ONE_TIME_POPUP_OTHERS = false;
    public static boolean ONE_TIME_POPUP_PHOTOS = false;
    public static boolean ONE_TIME_POPUP_VIDEOS = false;

    public static final String PHOTOS = "photos";
    public static final String VIDEOS = "videos";
    public static final String AUDIOS = "audios";
    public static final String DOCUMENTS = "documents";
    public static final String OTHERS = "others";

    public static int REQUEST_CODE_OPEN_DOCUMENT_TREE = 432;

    public static final String SDCARD_1 = "/ext_card/";
    public static final String SDCARD_2 = "/mnt/sdcard/external_sd/";
    public static final String SDCARD_3 = "/storage/extSdCard/";
    public static final String SDCARD_4 = "/mnt/extSdCard/";
    public static final String SDCARD_5 = "/mnt/external_sd/";
    public static final String SDCARD_6 = "/storage/sdcard1/";

    public static ArrayList<ItemDuplicateModel> file_to_be_deleted_others = new ArrayList<>();
    public static List<IndividualGroupModel> listOfGroupedDuplicatesOthers = new ArrayList<>();

    public static final HashMap<String, String> uniqueMd5Value = new HashMap();
    public static List<DuplicateGroupModel> listOfDuplicates = new ArrayList<>();
    public static final ArrayList<FileDetails> fileToBeDeleted = new ArrayList();

    public static final Set<String> audiosExtensionHashSet = new HashSet();
    public static final Set<String> documentsExtensionHashSet = new HashSet();
    public static final Set<String> extensionHashSet = new HashSet();
    public static final Set<String> photosExtensionHashSet = new HashSet();
    public static final Set<String> videosExtensionHashSet = new HashSet();

    public static HashMap<String, String> notificationUniqueOtherExtensionsMap = new HashMap<>();

    public static int resetDeleteClickAction = 0;
    public static int resetDeleteClickAction_temp = 0;

    public static long size_Of_File_audios;
    public static long size_Of_File_documents;
    public static long size_Of_File_images;
    public static long size_Of_File_others;
    public static long size_Of_File_videos;

    public static HashMap<String, Boolean> tempFilterListAudios = new HashMap<>();
    public static HashMap<String, Boolean> tempFilterListDocuments = new HashMap<>();
    public static HashMap<String, Boolean> tempFilterListOthers = new HashMap<>();
    public static HashMap<String, Boolean> tempFilterListPhotos = new HashMap<>();
    public static HashMap<String, Boolean> tempFilterListVideos = new HashMap<>();

//    public static HashMap<String, String> uniqueMd5Value = new HashMap<>();

    public static HashMap<String, String> uniqueOtherExtensionsMap = new HashMap<>();
    public static Set<String> uniqueOthersExtensionAfterDuplicates = new HashSet<>();
    public static Set<String> uniqueOthersExtensionBeforeDuplicates = new HashSet<>();

    public static Set<String> uniquePhotosExtension = new HashSet<>();
    public static Set<String> uniqueVideosExtension = new HashSet<>();
    public static Set<String> uniqueAudiosExtension = new HashSet<>();
    public static Set<String> uniqueDocumentsExtension = new HashSet<>();
    public static Set<String> uniqueExtension = new HashSet<>();

    public static String getExtension(String path) {
        String[] fileNameArray = path.split("\\.");
        return fileNameArray[fileNameArray.length - 1].toLowerCase();
    }

    public static String getMd5Checksum(String path, Context context) {
        return new MD5Checksum().fileToMD5(path, context);
    }

    public static String getFileName(String path) {
        String[] pathSplitArray = path.split("/");
        return pathSplitArray[pathSplitArray.length - 1];
    }

    public static long getFileSize(String path) {
        return new File(path).length();
    }


    public static String getImageResolution(String str) {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        return "" + options.outWidth + " x " + options.outHeight;
    }

    @SuppressLint("DefaultLocale")
    public static String getVideoDuration(Context context, String uriOfFile) {
        MediaPlayer mp = MediaPlayer.create(context, Uri.parse(uriOfFile));
        if (mp == null) {
            return "NA";
        }
        int duration = mp.getDuration();
        mp.release();
        return String.format("%d min, %d sec", TimeUnit.MILLISECONDS.toMinutes((long) duration), TimeUnit.MILLISECONDS.toSeconds((long) duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) duration)));
    }

    public static long getDateAndTime(String path) {
        return new File(path).lastModified();
    }

    public static String readDuplicateFiles(String md5, String extension, String tableName) {
        String toLowerCase = extension.toLowerCase();
        int obj = -1;
        switch (toLowerCase.hashCode()) {
            case 1422702:
                if (toLowerCase.equals(GP3)) {
                    obj = 31;
                    break;
                }
                break;
            case 44103874:
                if (toLowerCase.equals(GP33)) {
                    obj = 55;
                    break;
                }
                break;
            case 1436279:
                if (toLowerCase.equals(ABMP)) {
                    obj = 7;
                    break;
                }
                break;
            case 1444051:
                if (toLowerCase.equals(AJPG)) {
                    obj = 1;
                    break;
                }
                break;
            case 1447973:
                if (toLowerCase.equals(NRW)) {
                    obj = 23;
                    break;
                }
                break;
            case 1449755:
                if (toLowerCase.equals(APNG)) {
                    obj = 5;
                    break;
                }
                break;
            case 1466709:
                if (toLowerCase.equals(AAC)) {
                    obj = 35;
                    break;
                }
                break;
            case 1467270:
                if (toLowerCase.equals(ASF)) {
                    obj = 30;
                    break;
                }
                break;
            case 1467366:
                if (toLowerCase.equals(AVI)) {
                    obj = 34;
                    break;
                }
                break;
            case 1468055:
                if (toLowerCase.equals(BMP)) {
                    obj = 6;
                    break;
                }
                break;
            case 1468858:
                if (toLowerCase.equals(CHM)) {
                    obj = 52;
                    break;
                }
                break;
            case 1469109:
                if (toLowerCase.equals(CR2)) {
                    obj = 18;
                    break;
                }
                break;
            case 1469113:
                if (toLowerCase.equals(CPT)) {
                    obj = 13;
                    break;
                }
                break;
            case 1469178:
                if (toLowerCase.equals(CRW)) {
                    obj = 17;
                    break;
                }
                break;
            case 1469208:
                if (toLowerCase.equals(CSV)) {
                    obj = 48;
                    break;
                }
                break;
            case 1469999:
                if (toLowerCase.equals(DNG)) {
                    obj = 21;
                    break;
                }
                break;
            case 1470026:
                if (toLowerCase.equals(DOC)) {
                    obj = 42;
                    break;
                }
                break;
            case 1470278:
                if (toLowerCase.equals(DWG)) {
                    obj = 14;
                    break;
                }
                break;
            case 1472726:
                if (toLowerCase.equals(GIF)) {
                    obj = 12;
                    break;
                }
                break;
            case 1475827:
                if (toLowerCase.equals(JPG)) {
                    obj = 0;
                    break;
                }
                break;
            case 1476412:
                if (toLowerCase.equals(KDC)) {
                    obj = 22;
                    break;
                }
                break;
            case 1476844:
                if (toLowerCase.equals(M4A)) {
                    obj = 38;
                    break;
                }
                break;
            case 1476865:
                if (toLowerCase.equals(M4V)) {
                    obj = 32;
                    break;
                }
                break;
            case 1478658:
                if (toLowerCase.equals(MP3)) {
                    obj = 36;
                    break;
                }
                break;
            case 1478659:
                if (toLowerCase.equals(MP4)) {
                    obj = 26;
                    break;
                }
                break;
            case 1478694:
                if (toLowerCase.equals(MOV)) {
                    obj = 33;
                    break;
                }
                break;
            case 1480693:
                if (toLowerCase.equals(ORF)) {
                    obj = 24;
                    break;
                }
                break;
            case 1481187:
                if (toLowerCase.equals(PCD)) {
                    obj = 15;
                    break;
                }
                break;
            case 1481220:
                if (toLowerCase.equals(PDF)) {
                    obj = 40;
                    break;
                }
                break;
            case 1481372:
                if (toLowerCase.equals(PIC)) {
                    obj = 11;
                    break;
                }
                break;
            case 1481531:
                if (toLowerCase.equals(PNG)) {
                    obj = 4;
                    break;
                }
                break;
            case 1481606:
                if (toLowerCase.equals(PPT)) {
                    obj = 46;
                    break;
                }
                break;
            case 1481683:
                if (toLowerCase.equals(PSD)) {
                    obj = 10;
                    break;
                }
                break;
            case 1483066:
                if (toLowerCase.equals(RAW)) {
                    obj = 19;
                    break;
                }
                break;
            case 1483638:
                if (toLowerCase.equals(RTF)) {
                    obj = 51;
                    break;
                }
                break;
            case 1484485:
                if (toLowerCase.equals(SR2)) {
                    obj = 25;
                    break;
                }
                break;
            case 1484537:
                if (toLowerCase.equals(SRF)) {
                    obj = 20;
                    break;
                }
                break;
            case 1485219:
                if (toLowerCase.equals(TIF)) {
                    obj = 9;
                    break;
                }
                break;
            case 1485698:
                if (toLowerCase.equals(TXT)) {
                    obj = 41;
                    break;
                }
                break;
            case 1487870:
                if (toLowerCase.equals(WAV)) {
                    obj = 39;
                    break;
                }
                break;
            case 1488221:
                if (toLowerCase.equals(WMA)) {
                    obj = 37;
                    break;
                }
                break;
            case 1488242:
                if (toLowerCase.equals(WMV)) {
                    obj = 27;
                    break;
                }
                break;
            case 1488320:
                if (toLowerCase.equals(WPG)) {
                    obj = 16;
                    break;
                }
                break;
            case 1489169:
                if (toLowerCase.equals(XLS)) {
                    obj = 44;
                    break;
                }
                break;
            case 1489170:
                if (toLowerCase.equals(XLT)) {
                    obj = 49;
                    break;
                }
                break;
            case 44765590:
                if (toLowerCase.equals(AJPEG)) {
                    obj = 3;
                    break;
                }
                break;
            case 45565749:
                if (toLowerCase.equals(DIVX)) {
                    obj = 29;
                    break;
                }
                break;
            case 45570926:
                if (toLowerCase.equals(DOCX)) {
                    obj = 43;
                    break;
                }
                break;
            case 45750678:
                if (toLowerCase.equals(JPEG)) {
                    obj = 2;
                    break;
                }
                break;
            case 45929906:
                if (toLowerCase.equals(PPTX)) {
                    obj = 47;
                    break;
                }
                break;
            case 46041891:
                if (toLowerCase.equals(TIFF)) {
                    obj = 8;
                    break;
                }
                break;
            case 46164359:
                if (toLowerCase.equals(XLSX)) {
                    obj = 45;
                    break;
                }
                break;
            case 46164390:
                if (toLowerCase.equals(XLTX)) {
                    obj = 50;
                    break;
                }
                break;
            case 46173639:
                if (toLowerCase.equals(XVID)) {
                    obj = 28;
                    break;
                }
                break;
            case 1478570:
                if (toLowerCase.equals(MKV)) {
                    obj = 53;
                    break;
                }
                break;
            case 46127306:
                if (toLowerCase.equals(WEBP)) {
                    obj = 54;
                    break;
                }
                break;
            case 45680645:
                if (toLowerCase.equals(HEIC)) {
                    obj = 56;
                    break;
                }
                break;
        }
        switch (obj) {
            case 0:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + JPG + "'";
            case 1:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + AJPG + "'";
            case 2:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + JPEG + "'";
            case 3:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + AJPEG + "'";
            case 4:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + PNG + "'";
            case 5:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + APNG + "'";
            case 6:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + BMP + "'";
            case 7:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + ABMP + "'";
            case 8:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + TIFF + "'";
            case 9:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + TIF + "'";
            case 10:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + PSD + "'";
            case 11:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + PIC + "'";
            case 12:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + GIF + "'";
            case 13:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + CPT + "'";
            case 14:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + DWG + "'";
            case 15:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + PCD + "'";
            case 16:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + WPG + "'";
            case 17:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + CRW + "'";
            case 18:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + CR2 + "'";
            case 19:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + RAW + "'";
            case 20:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + SRF + "'";
            case 21:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + DNG + "'";
            case 22:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + KDC + "'";
            case 23:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + NRW + "'";
            case 24:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + ORF + "'";
            case 25:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + SR2 + "'";
            case 26:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + MP4 + "'";
            case 27:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + WMV + "'";
            case 28:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + XVID + "'";
            case 29:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + DIVX + "'";
            case 30:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + ASF + "'";
            case 31:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + GP3 + "'";
            case 32:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + M4V + "'";
            case 33:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + MOV + "'";
            case 34:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + AVI + "'";
            case 35:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + AAC + "'";
            case 36:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + MP3 + "'";
            case 37:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + WMA + "'";
            case 38:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + M4A + "'";
            case 39:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + WAV + "'";
            case 40:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + PDF + "'";
            case 41:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + TXT + "'";
            case 42:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + DOC + "'";
            case 43:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + DOCX + "'";
            case 44:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + XLS + "'";
            case 45:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + XLSX + "'";
            case 46:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + PPT + "'";
            case 47:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + PPTX + "'";
            case 48:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + CSV + "'";
            case 49:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + XLT + "'";
            case 50:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + XLTX + "'";
            case 51:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + RTF + "'";
            case 52:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + CHM + "'";
            case 53:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + MKV + "'";
            case 54:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + WEBP + "'";
            case 55:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + GP33 + "'";
            case 56:
                return "select path,extension from " + tableName + " where " + KEY_MD5 + " = '" + md5 + "'" + " and " + KEY_EXTENSION + " = '" + HEIC + "'";
            default:
                return null;
        }
    }

    public static int checkNumberOfDigits(int photosCleaned) {
        return ((int) Math.log10((double) photosCleaned)) + 1;
    }

    public static void addSizeImages(long size) {
        size_Of_File_images += size;
    }

    public static void addSizeVideos(long size) {
        size_Of_File_videos += size;
    }

    public static void addSizeAudios(long size) {
        size_Of_File_audios += size;
    }

    public static void addSizeDocuments(long size) {
        size_Of_File_documents += size;
    }

    public static void addSizeOthers(long size) {
        size_Of_File_others += size;
    }

    public static void subSizeImages(long size) {
        size_Of_File_images -= size;
    }

    public static void subSizeVideos(long size) {
        size_Of_File_videos -= size;
    }

    public static void subSizeAudios(long size) {
        size_Of_File_audios -= size;
    }

    public static void subSizeDocuments(long size) {
        size_Of_File_documents -= size;
    }

    public static void subSizeOthers(long size) {
        size_Of_File_others -= size;
    }

    public static void deleteFile(Activity deleteActivity, Context context, String path) {
        Log.e("GlobalVarsAndFunctions","deleteFile:"+path);
        File file = new File(path);
        if (file.exists()) {
            if (file.delete()) {
                Log.e("GlobalVarsAndFunctions", "clearFile-done:" + file.getPath());
            } else {
                Log.e("GlobalVarsAndFunctions", "clearFile-error:" + file.getPath());
            }
        }

        if (VERSION.SDK_INT <= 20) {
            List<Boolean> checkSDCardFile = new ArrayList<>();
            if (MyUtils.getSDCardPath(context) != null) {
                DocumentFile documentFile = DocumentFile.fromTreeUri(deleteActivity, Uri.parse(DuplicateFileRemoverSharedPreferences.getStorageAccessFrameWorkURIPermission(context)));
                String[] parts = file.getPath().split("/");
                for (String part : parts) {
                    assert documentFile != null;
                    checkSDCardFile.add(part.equals(documentFile.getName()));
                    if (documentFile.getName() != null) {
                        if (part.equals(documentFile.getName())) {
                            for (int i = 3; i < parts.length; i++) {
                                if (documentFile != null) {
                                    documentFile = documentFile.findFile(parts[i]);
                                }
                            }
                            if (documentFile != null) {
                                if(!documentFile.delete()) {
                                    Log.e("GlobalVarsAndFunctions","failed-delete-documentFile:"+documentFile.getUri());
                                    file.delete();
                                }
                                Log.e("GlobalVarsAndFunctions","documentFile:"+documentFile.getUri());
                            } else {
                                normalFunctionForDeleteFile(context, file);
                            }
                        }
                    } else {
                        normalFunctionForDeleteFile(context, file);
                    }
                }
                if (!checkSDCardFile.contains(Boolean.TRUE)) {
                    normalFunctionForDeleteFile(context, file);
                    return;
                }
                Log.e("GlobalVarsAndFunctions","return:001");
                //return;
            }
            normalFunctionForDeleteFile(context, file);
            return;
        } else {
            normalFunctionForDeleteFile(context, file);
        }
    }

    public static byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        while (true) {
            int len = inputStream.read(buffer);
            if (len == -1) {
                return byteBuffer.toByteArray();
            }
            byteBuffer.write(buffer, 0, len);
        }
    }

    private static void normalFunctionForDeleteFile(Context context, File file) {
        Log.e("GlobalVarsAndFunctions", "normalFunctionForDeleteFile:" + file.getPath());
        File f = new File(file.getAbsolutePath());
        if (!f.exists()) {
            Log.e("GlobalVarsAndFunctions", "normalFunctionForDeleteFile-not-exists" );
            return;
        }
        if (f.delete()) {
            deleteFileFromMediaStore(context.getContentResolver(), f);
        } else {
            deleteFileFromMediaStore(context.getContentResolver(), f);
        }
    }

    public static void deleteFileFromMediaStore(ContentResolver contentResolver, File file) {
        String canonicalPath;
        try {
            canonicalPath = file.getCanonicalPath();
        } catch (IOException e) {
            canonicalPath = file.getAbsolutePath();
        }
        Uri uri = Files.getContentUri("external");
        if (contentResolver.delete(uri, "_data=?", new String[]{canonicalPath}) == 0) {
            if (!file.getAbsolutePath().equals(canonicalPath)) {
                contentResolver.delete(uri, "_data=?", new String[]{file.getAbsolutePath()});
            }
        }
    }

    public static ArrayList<String> getListOfPhotosExtensions() {
        ArrayList<String> listOfFileExtension = new ArrayList<>();
        listOfFileExtension.add(JPG);
        listOfFileExtension.add(AJPG);
        listOfFileExtension.add(JPEG);
        listOfFileExtension.add(PNG);
        listOfFileExtension.add(BMP);
        listOfFileExtension.add(TIFF);
        listOfFileExtension.add(TIF);
        listOfFileExtension.add(WEBP);
        listOfFileExtension.add(HEIC);
        listOfFileExtension.add(PSD);
        listOfFileExtension.add(PIC);
        listOfFileExtension.add(GIF);
        listOfFileExtension.add(CPT);
        listOfFileExtension.add(DWG);
        listOfFileExtension.add(PCD);
        listOfFileExtension.add(WPG);
        listOfFileExtension.add(CRW);
        listOfFileExtension.add(CR2);
        listOfFileExtension.add(RAW);
        listOfFileExtension.add(SRF);
        listOfFileExtension.add(DNG);
        listOfFileExtension.add(KDC);
        listOfFileExtension.add(NRW);
        listOfFileExtension.add(ORF);
        listOfFileExtension.add(SR2);
        return listOfFileExtension;
    }

    public static ArrayList<String> getListOfVideosExtensions() {
        ArrayList<String> listOfFileExtension = new ArrayList<>();
        listOfFileExtension.add(MP4);
        listOfFileExtension.add(WMV);
        listOfFileExtension.add(MKV);
        listOfFileExtension.add(XVID);
        listOfFileExtension.add(DIVX);
        listOfFileExtension.add(ASF);
        listOfFileExtension.add(GP3);
        listOfFileExtension.add(GP33);
        listOfFileExtension.add(M4V);
        listOfFileExtension.add(MOV);
        listOfFileExtension.add(AVI);
        return listOfFileExtension;
    }

    public static ArrayList<String> getListOfAudiosExtensions() {
        ArrayList<String> listOfFileExtension = new ArrayList<>();
        listOfFileExtension.add(AAC);
        listOfFileExtension.add(MP3);
        listOfFileExtension.add(WMA);
        listOfFileExtension.add(M4A);
        listOfFileExtension.add(WAV);
        return listOfFileExtension;
    }

    public static ArrayList<String> getListOfDocumentsExtensions() {
        ArrayList<String> listOfFileExtension = new ArrayList<>();
        listOfFileExtension.add(DOC);
        listOfFileExtension.add(DOCX);
        listOfFileExtension.add(TXT);
        listOfFileExtension.add(PDF);
        listOfFileExtension.add(XLS);
        listOfFileExtension.add(XLSX);
        listOfFileExtension.add(PPT);
        listOfFileExtension.add(PPTX);
        listOfFileExtension.add(CSV);
        listOfFileExtension.add(XLT);
        listOfFileExtension.add(XLTX);
        listOfFileExtension.add(RTF);
        listOfFileExtension.add(CHM);
        return listOfFileExtension;
    }

    public static boolean containsExtension(Set<String> list, String extension) {
        for (String object : list) {
            if (object.equalsIgnoreCase(extension)) {
                return true;
            }
        }
        return false;
    }

    public static void resetOneTimePopUp() {
        ONE_TIME_DUPLICATE_INFORMATION_POPUP = false;
        ONE_TIME_POPUP_PHOTOS = false;
        ONE_TIME_POPUP_VIDEOS = false;
        ONE_TIME_POPUP_AUDIOS = false;
        ONE_TIME_POPUP_DOCUMENTS = false;
        ONE_TIME_POPUP_OTHERS = false;
    }

}
