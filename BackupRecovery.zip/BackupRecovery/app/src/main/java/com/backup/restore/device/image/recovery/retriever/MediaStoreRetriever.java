package com.backup.restore.device.image.recovery.retriever;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.widget.Toast;

import androidx.loader.content.CursorLoader;

import com.backup.restore.device.image.recovery.utilities.OnFolderLoaded;

import java.io.File;
import java.util.ArrayList;

//loading media through MediaStore
//advantage: speed, disadvantage: might be missing some items
public class MediaStoreRetriever extends Retriever {

    public static int TYPE_AUDIO = MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO;
    public static int TYPE_VIDEO = MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;
    public static int TYPE_IMAGE = MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
//    public static int TYPE_IMAGE = MediaStore.Images.Thumbnails.MICRO_KIND;
    public static int TYPE_DOCUMENT = MediaStore.Files.FileColumns.MEDIA_TYPE_DOCUMENT;


    private static final String[] projection = new String[]{
            MediaStore.Files.FileColumns.DATA,
            /*MediaStore.Files.FileColumns.PARENT,*/
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Images.ImageColumns.DATE_TAKEN,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            BaseColumns._ID};

    /**
     * Image attribute.
     */
    private static final String[] IMAGES = {
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.LATITUDE,
            MediaStore.Images.Media.LONGITUDE,
            MediaStore.Images.Media.SIZE
    };

    /**
     * Video attribute.
     */
    private static final String[] VIDEOS = {
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.LATITUDE,
            MediaStore.Video.Media.LONGITUDE,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION
    };

    @Override
    public void loadAlbums(final Activity context, boolean hiddenFolders, int type) {

        if(type==TYPE_IMAGE) loadImage(context);
        else if(type==TYPE_VIDEO) loadVideo(context);
        else {


            final long startTime = System.currentTimeMillis();

            final ArrayList<Album> albums = new ArrayList<>();

            String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "=" + type;

            Uri queryUri = MediaStore.Files.getContentUri("external");

            CursorLoader cursorLoader = new CursorLoader(
                    context,
                    queryUri,
                    projection,
                    selection,
                    null, // Selection args (none).
                    MediaStore.Files.FileColumns.DATE_ADDED);

            final Cursor cursor = cursorLoader.loadInBackground();

            if (cursor == null) {
                return;
            }

            //search hiddenFolders
            if (hiddenFolders) {
                ArrayList<Album> hiddenAlbums = checkHiddenFolders(context);
                albums.addAll(hiddenAlbums);
            }

            AsyncTask.THREAD_POOL_EXECUTOR.execute(new Runnable() {
                @Override
                public void run() {
                    if (cursor.moveToFirst()) {
                        String path;
                        long dateTaken, id;
                        int pathColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA);
                        int idColumn = cursor.getColumnIndex(BaseColumns._ID);

                        do {
                            path = cursor.getString(pathColumn);
                            AlbumItem albumItem = AlbumItem.getInstance(context, path);
                            if (albumItem != null && new File(path).length() != 0) {

                                id = cursor.getLong(idColumn);
                                Uri uri = ContentUris.withAppendedId(MediaStore.Files.getContentUri("external"), id);
                                albumItem.setUri(uri);

                                //search bucket
                                boolean foundBucket = false;
                                for (int i = 0; i < albums.size(); i++) {
                                    if (albums.get(i).getPath().equals(getParentPath(path))) {
                                        albums.get(i).getAlbumItems().add(0, albumItem);
                                        foundBucket = true;
                                        break;
                                    }
                                }

                                if (!foundBucket) {
                                    //no bucket found
                                    String bucketPath = getParentPath(path);
                                    if (bucketPath != null && !path.endsWith(".svg") && !path.endsWith(".psd")) {
                                        Album album = new Album();
                                        album.setPath(bucketPath);
                                        album.setLastModified(new File(bucketPath).lastModified());
                                        albums.add(album);
//                                    albums.add(new Album().setLastModified(new File(bucketPath).lastModified()));

                                        albums.get(albums.size() - 1).getAlbumItems().add(0, albumItem);
                                    }
                                }
                            }

                        } while (cursor.moveToNext());

                    }
                    cursor.close();

                    //done loading media with content resolver
                    OnFolderLoaded callback = getCallback();
                    if (callback != null) {
                        callback.onFolderLoaded(albums);
                    }

                    //Log.d("MediaStoreRetriever", "onMediaLoaded(): " + String.valueOf(System.currentTimeMillis() - startTime) + " ms");
                }
            });
        }
    }

    public void loadImage(final Activity context) {

        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                IMAGES,
                null,
                null,
                null);


        AsyncTask.THREAD_POOL_EXECUTOR.execute(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Album> allFileFolder = new ArrayList<>();
                OnFolderLoaded callback = getCallback();

                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        String path = cursor.getString(0);
                        long addDate = cursor.getLong(3);
                        long size = cursor.getLong(6);

//                AlbumFile imageFile = new AlbumFile();
                        AlbumItem imageFile = AlbumItem.getInstance(context, path);
                        imageFile.setDate(addDate);
                        imageFile.setSize(size);

//search bucket
                        boolean foundBucket = false;
                        for (int i = 0; i < allFileFolder.size(); i++) {
                            if (allFileFolder.get(i).getPath().equals(getParentPath(path)) ) {
                                allFileFolder.get(i).getAlbumItems().add(0, imageFile);
                                foundBucket = true;
                                break;
                            }
                        }

                        if (!foundBucket) {
                            //no bucket found
                            String bucketPath = getParentPath(path);
                            if (bucketPath != null && !path.endsWith(".svg")&& !path.endsWith(".psd")) {
                                Album album=new Album();
                                album.setPath(bucketPath);
                                album.setLastModified(new File(bucketPath).lastModified());
                                allFileFolder.add(album);
                                allFileFolder.get(allFileFolder.size() - 1).getAlbumItems().add(0, imageFile);

                                if (callback != null) {
                                    callback.onSingleFolder(album);
                                }
                            }
                        }

                    }
                    cursor.close();
                }

                if (callback != null) {
                    callback.onFolderLoaded(allFileFolder);
                }
            }
        });



    }

    public void loadVideo(final Activity context) {

        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                VIDEOS,
                null,
                null,
                null);


        AsyncTask.THREAD_POOL_EXECUTOR.execute(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Album> allFileFolder = new ArrayList<>();
                OnFolderLoaded callback = getCallback();

                if (cursor != null) {
                    while (cursor.moveToNext()) {

                        String path = cursor.getString(0);
                        String bucketName = cursor.getString(1);
                        String mimeType = cursor.getString(2);
                        long addDate = cursor.getLong(3);
                        float latitude = cursor.getFloat(4);
                        float longitude = cursor.getFloat(5);
                        long size = cursor.getLong(6);
                        long duration = cursor.getLong(7);

//                AlbumFile imageFile = new AlbumFile();
                        AlbumItem imageFile = AlbumItem.getInstance(context, path);
                        imageFile.setDate(addDate);
                        imageFile.setSize(size);

//search bucket
                        boolean foundBucket = false;
                        for (int i = 0; i < allFileFolder.size(); i++) {
                            if (allFileFolder.get(i).getPath().equals(getParentPath(path)) ) {
                                allFileFolder.get(i).getAlbumItems().add(0, imageFile);
                                foundBucket = true;
                                break;
                            }
                        }

                        if (!foundBucket) {
                            //no bucket found
                            String bucketPath = getParentPath(path);
                            if (bucketPath != null) {
                                Album album=new Album();
                                album.setPath(bucketPath);
                                album.setLastModified(new File(bucketPath).lastModified());
                                allFileFolder.add(album);
                                allFileFolder.get(allFileFolder.size() - 1).getAlbumItems().add(0, imageFile);
                                if (callback != null) {
                                    callback.onSingleFolder(album);
                                }
                            }
                        }
                    }
                    cursor.close();
                }

                if (callback != null) {
                    callback.onFolderLoaded(allFileFolder);
                }
            }
        });


    }

    @Override
    public void onDestroy() {

    }

    public static String getParentPath(String path) {
        return new File(path).getParent();
    }

    private ArrayList<Album> checkHiddenFolders(final Activity context) {

        ArrayList<Album> hiddenAlbums = new ArrayList<>();

        // Scan all no Media files
        String nonMediaCondition = MediaStore.Files.FileColumns.MEDIA_TYPE
                + "=" + MediaStore.Files.FileColumns.MEDIA_TYPE_NONE;

        // Files with name contain .nomedia
        String selection = nonMediaCondition + " AND "
                + MediaStore.Files.FileColumns.TITLE + " LIKE ?";

        String[] params = new String[]{"%.nomedia%"};
//        String[] params = new String[]{"%.%"};

        // make query for non media files with file title contain ".nomedia" as
        // text on External Media URI
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Files.getContentUri("external"),
                new String[]{MediaStore.Files.FileColumns.DATA},
                selection,
                params,
                MediaStore.Images.Media.DATE_TAKEN);

        if (cursor == null || cursor.getCount() == 0) {
            return hiddenAlbums;
        }

        if (cursor.moveToFirst()) {
            int pathColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA);

            do {
                String path = cursor.getString(pathColumn);
                path = path.replace(".nomedia", "");
                File dir = new File(path);

                Album album=new Album();
                album.setPath(path);
                album.setLastModified(new File(path).lastModified());

//                final Album album = new Album().setPath(path);

                File[] files = dir.listFiles();

                if (files != null) {
                    for (int i = 0; i < files.length; i++) {
                        AlbumItem albumItem = AlbumItem.getInstance(files[i].getPath());
                        if (albumItem != null) {
                            album.getAlbumItems().add(albumItem);
                        }
                    }
                }

                if (album.getAlbumItems().size() > 0) {
                    hiddenAlbums.add(album);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        return hiddenAlbums;
    }

    public static String getPathForUri(Context context, Uri uri) {
        CursorLoader cursorLoader = new CursorLoader(
                context, uri, new String[]{MediaStore.Files.FileColumns.DATA},
                null, null, null);

        try {
            final Cursor cursor = cursorLoader.loadInBackground();

            if (cursor != null && cursor.getCount() > 0) {
                cursor.moveToFirst();
                return cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA));
            }
            return null;
        } catch (SecurityException e) {
            Toast.makeText(context, "Permission Error", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

}
