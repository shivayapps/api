package com.backup.restore.device.image.recovery.widget;

import static com.backup.restore.device.image.recovery.utilities.ConstantKt.fontPathBold;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;


public class BoldTextView extends AppCompatTextView {
    public BoldTextView(Context context) {
        super(context);
        init(null);
    }

    public BoldTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    public BoldTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs);
    }

    private void init(AttributeSet attrs) {
        if (attrs != null) {
            Typeface myTypeface = Typeface.createFromAsset(getContext().getAssets(), fontPathBold);
            setTypeface(myTypeface);
        }
    }
}