package com.backup.restore.device.image.recovery.ads.rateandfeedback

import android.app.Activity
import com.google.android.gms.ads.interstitial.InterstitialAd


const val rateDialogCount = 5


fun Activity.displayExitDialog(interstitialAd: InterstitialAd?) {
    val sp = ExitSPHelper(this)
    if (!sp.isRated() && sp.getExitCount() >= rateDialogCount && !sp.isDismissed()) {
        ratingDialog(object : OnRateListener {
            override fun onRate(rate: Int) {
                if (rate >= 4) {
                    rateApp()
                } else if (rate >= 0) {
                    ratingFeedback(rate)
//                    startActivity(FeedbackActivity.newIntent(this@displayExitDialog, rate))
                }
            }
        })
    } else {
        exitDialog(interstitialAd)
    }
}