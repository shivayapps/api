/*
Copyright 2020 Mrudul Tora (ToraLabs)
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package com.backup.restore.device.image.recovery.mainapps.adapter

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.hardware.SensorManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.backup.restore.device.image.recovery.mainapps.model.SensorListModel
import androidx.recyclerview.widget.RecyclerView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.backup.restore.device.image.recovery.R
import com.example.jdrodi.utilities.camelCaseString

/**
 * Created by @mrudultora
 */
class SensorAdapter(private val context: Context, private val list: List<SensorListModel>) : RecyclerView.Adapter<SensorAdapter.Viewholder>() {


    var sensorManager: SensorManager? = null

    init {
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Viewholder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_sensor_layout, parent, false)
        return Viewholder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: Viewholder, position: Int) {
        if (holder.type != null) {
            holder.type!!.visibility = View.VISIBLE
            holder.type!!.text =
                context.resources.getString(R.string.type) + " : " + list.get(position).typeName
        }
        if (holder.img_sensor != null) {
            holder.img_sensor!!.visibility = View.VISIBLE
            holder.img_sensor!!.setImageDrawable(
                ContextCompat.getDrawable(
                    context, list[position].image
                )
            )
        }
        holder.name.text = camelCaseString(list.get(position).name)
        holder.vendor.text = context.resources.getString(R.string.vendor) + " : " + list.get(position).vendor
        holder.power.text = context.resources.getString(R.string.power) + " : " + list.get(position).power
        holder.card_sensor.setOnLongClickListener(View.OnLongClickListener {
            var data: String = (context.resources.getString(R.string.sensorname) + " : " + list[position].name + "\n" +
                    context.resources.getString(R.string.vendor) + " : " + list[position].vendor + "\n" +
                    context.resources.getString(R.string.power) + " : " + list[position].power + "\n")
            if (holder.type != null) {
                data += context.resources.getString(R.string.type) + " : " + list[position].typeName + "\n"
            }
            val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clipData = ClipData.newPlainText("Label", data)
            manager.setPrimaryClip(clipData)
            Toast.makeText(context.applicationContext, context.resources.getString(R.string.copied) + " " + list[position].name + " " + context.resources.getString(
                    R.string.details
                ), Toast.LENGTH_SHORT).show()
            true
        })
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class Viewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var name: TextView
        var vendor: TextView
        var type: TextView?
        var power: TextView
        var img_sensor: ImageView?
        var card_sensor: CardView

        init {
            img_sensor = itemView.findViewById(R.id.img_sensor)
            name = itemView.findViewById(R.id.sensor_name)
            vendor = itemView.findViewById(R.id.vendor_name)
            type = itemView.findViewById(R.id.txt_type)
            power = itemView.findViewById(R.id.txt_power)
            card_sensor = itemView.findViewById(R.id.card_sensor)
        }
    }
}