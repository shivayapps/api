package com.backup.restore.device.image.recovery.mainapps.activity

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.EnvironmentCompat
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.databinding.ActivityTrashSaveBinding
import com.backup.restore.device.image.recovery.mainapps.fragment.*
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.custom.SwitchButton
//import com.example.app.ads.helper.GiftIconHelper
//import kotlinx.android.synthetic.main.activity_trash_save.*
import java.io.File
import java.io.InputStream
import java.util.*


class TrashSaveActivity : MyCommonBaseActivity() {

    lateinit var binding:ActivityTrashSaveBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_trash_save)
        binding=ActivityTrashSaveBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(TrashSaveActivity::class.simpleName!!)

    }

    override fun getContext(): AppCompatActivity {
        return this@TrashSaveActivity
    }

    override fun initData() {
        binding.swTrashImages.isChecked = SharedPrefsConstant.getBoolean(mContext, "sw_trash_images", true)
        binding.swTrashVideos.isChecked = SharedPrefsConstant.getBoolean(mContext, "sw_trash_videos", true)
        binding.swTrashAudios.isChecked = SharedPrefsConstant.getBoolean(mContext, "sw_trash_audios", true)
        binding.swTrashDocument.isChecked = SharedPrefsConstant.getBoolean(mContext, "sw_trash_document", true)
        binding.swTrashOther.isChecked = SharedPrefsConstant.getBoolean(mContext, "sw_trash_other", true)

//        sw_trash_images.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) SharedPrefsConstant.savePref(mContext, "sw_trash_images", true)
//            else SharedPrefsConstant.savePref(mContext, "sw_trash_images", false)
//        }
//        sw_trash_videos.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) SharedPrefsConstant.savePref(mContext, "sw_trash_videos", true)
//            else SharedPrefsConstant.savePref(mContext, "sw_trash_videos", false)
//        }
//        sw_trash_audios.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) SharedPrefsConstant.savePref(mContext, "sw_trash_audios", true)
//            else SharedPrefsConstant.savePref(mContext, "sw_trash_audios", false)
//        }
//        sw_trash_document.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) SharedPrefsConstant.savePref(mContext, "sw_trash_document", true)
//            else SharedPrefsConstant.savePref(mContext, "sw_trash_document", false)
//        }
//        sw_trash_other.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) SharedPrefsConstant.savePref(mContext, "sw_trash_other", true)
//            else SharedPrefsConstant.savePref(mContext, "sw_trash_other", false)
//        }

        if (AdsManager(mContext).isNeedToShowAds()) {
            if (NetworkManager.isInternetConnected(mContext)) {
//                GiftIconHelper.loadGiftAd(
//                    fContext = mContext,
//                    fivGiftIcon = findViewById(R.id.main_la_gift),
//                    fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//                )
            }
        }
    }

    override fun initActions() {

        binding.ivBack.setOnClickListener(this)
        binding.llTrashImages.setOnClickListener(this)
        binding.llTrashVideo.setOnClickListener(this)
        binding.llTrashDocument.setOnClickListener(this)
        binding.llTrashAudio.setOnClickListener(this)
        binding.llTrashOther.setOnClickListener(this)

//        txt_more_image.setOnClickListener(this)
//        txt_more_video.setOnClickListener(this)
//        txt_more_audio.setOnClickListener(this)
//        txt_more_document.setOnClickListener(this)
//        txt_more_other.setOnClickListener(this)

        binding.txtImage.isSelected = true
        binding.txtMoreImage.isSelected = true
        binding.txtVideo.isSelected = true
        binding.txtMoreVideo.isSelected = true
        binding.txtAudio.isSelected = true
        binding.txtMoreAudio.isSelected = true
        binding.txtDocument.isSelected = true
        binding.txtMoreDocument.isSelected = true
        binding.txtOther.isSelected = true
        binding.txtMoreOther.isSelected = true

    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onClick(view: View) {
//        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 800) {
//            return
//        }
//        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.iv_back -> {
                onBackPressed()
            }
            R.id.ll_trash_images -> {
//            R.id.txt_more_image -> {
                if(binding.swTrashImages.isChecked) {
                    binding.swTrashImages.isChecked=false
                    SharedPrefsConstant.savePref(mContext, "sw_trash_images", false)
                } else {
                    if(!isDialogOpen) dialogDetailExtension(getString(R.string.supported_image_file_types), SharedPrefsConstant.ImageArray, "sw_trash_images", binding.swTrashImages)
                }

            }
            R.id.ll_trash_video -> {
//            R.id.txt_more_video -> {
                if(binding.swTrashVideos.isChecked) {
                    binding.swTrashVideos.isChecked=false
                    SharedPrefsConstant.savePref(mContext, "sw_trash_videos", false)
                } else {
                    if(!isDialogOpen) dialogDetailExtension(getString(R.string.supported_video_file_types), SharedPrefsConstant.VideoArray, "sw_trash_videos", binding.swTrashVideos)
                }
            }
            R.id.ll_trash_audio -> {
//            R.id.txt_more_audio -> {
                if(binding.swTrashAudios.isChecked) {
                    binding.swTrashAudios.isChecked=false
                    SharedPrefsConstant.savePref(mContext, "sw_trash_audios", false)
                } else {
                    if(!isDialogOpen) dialogDetailExtension(getString(R.string.supported_audio_file_types), SharedPrefsConstant.AudioArray, "sw_trash_audios", binding.swTrashAudios)
                }
            }
            R.id.ll_trash_document -> {
//            R.id.txt_more_document -> {
                if(binding.swTrashDocument.isChecked) {
                    binding.swTrashDocument.isChecked=false
                    SharedPrefsConstant.savePref(mContext, "sw_trash_document", false)
                } else {
                    if(!isDialogOpen) dialogDetailExtension(getString(R.string.supported_document_file_types), SharedPrefsConstant.DocumentArray, "sw_trash_document", binding.swTrashDocument)
                }
            }
            R.id.ll_trash_other -> {
//            R.id.txt_more_other -> {
                if(binding.swTrashOther.isChecked) {
                    binding.swTrashOther.isChecked=false
                    SharedPrefsConstant.savePref(mContext, "sw_trash_other", false)
                } else {
                    if(!isDialogOpen) dialogDetailExtension(getString(R.string.supported_other_file_types), SharedPrefsConstant.OtherArray,"sw_trash_other", binding.swTrashOther)
                }
            }

        }
    }


    var isDialogOpen=false
    private fun dialogDetailExtension(
        title: String,
        extensionArray: Array<String>,
        key: String,
        swButton: SwitchButton
    ) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_more_extension)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val tv_title = dialog.findViewById<TextView>(R.id.tv_title)
        val tv_detail_text = dialog.findViewById<TextView>(R.id.tv_detail_text)

        tv_title.text = title
        tv_detail_text.text = extensionArray.joinToString(
            transform = { "\""+it+"\"" }
        )

        dialog.findViewById<View>(R.id.dialogButtonOk).setOnClickListener {
            swButton.isChecked=true
            SharedPrefsConstant.savePref(mContext, key, true)
            isDialogOpen=false
            dialog.dismiss()
        }
        isDialogOpen=true
        dialog.show()
    }


    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        startActivity(intent)
//        dialogSelectLocation()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4010) {
            val uri: Uri? = data?.data
            grantUriPermission(packageName, uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val takeFlags = data?.flags?.and(
                (Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                takeFlags?.let { contentResolver.takePersistableUriPermission(uri!!, it) }
            }
        }
    }

    private fun takeCardUriPermission(sdCardRootPath: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val sdCard = File(sdCardRootPath)
            val storageManager: StorageManager =
                getSystemService(Context.STORAGE_SERVICE) as StorageManager
            val storageVolume: StorageVolume? = storageManager.getStorageVolume(sdCard)
            val intent: Intent? = storageVolume?.createAccessIntent(null)
            try {
                startActivityForResult(intent, 4010)
            } catch (e: ActivityNotFoundException) {
            }
        }
    }

    private fun getExternalStorageDirectories(): Array<String?> {
        val results: MutableList<String> = ArrayList()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //Method 1 for KitKat & above
            val externalDirs = getExternalFilesDirs(null)
            val internalRoot = Environment.getExternalStorageDirectory().absolutePath.toLowerCase()
            for (file in externalDirs) {
                if (file == null) //solved NPE on some Lollipop devices
                    continue
                val path = file.path.split("/Android".toRegex()).toTypedArray()[0]
                if (path.toLowerCase().startsWith(internalRoot)) continue
                var addPath = false
                addPath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    Environment.isExternalStorageRemovable(file)
                } else {
                    Environment.MEDIA_MOUNTED == EnvironmentCompat.getStorageState(file)
                }
                if (addPath) {
                    results.add(path)
                }
            }
        }
        if (results.isEmpty()) {
            //Method 2 for all versions
            // better variation of: http://stackoverflow.com/a/40123073/5002496
            var output = ""
            try {
                val process = ProcessBuilder().command("mount | grep /dev/block/vold")
                    .redirectErrorStream(true).start()
                process.waitFor()
                val `is`: InputStream = process.inputStream
                val buffer = ByteArray(1024)
                while (`is`.read(buffer) !== -1) {
                    output = output + String(buffer)
                }
                `is`.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (output.trim { it <= ' ' }.isNotEmpty()) {
                val devicePoints = output.split("\n".toRegex()).toTypedArray()
                for (voldPoint in devicePoints) {
                    results.add(voldPoint.split(" ".toRegex()).toTypedArray()[2])
                }
            }
        }

        //Below few lines is to remove paths which may not be external memory card, like OTG (feel free to comment them out)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var i = 0
            while (i < results.size) {
                if (!results[i].toLowerCase().matches(".*[0-9a-f]{4}[-][0-9a-f]{4}".toRegex())) {
//                    Log.d(ImageViewTouchBase.LOG_TAG, results[i] + " might not be extSDcard")
                    results.removeAt(i--)
                }
                i++
            }
        } else {
            var i = 0
            while (i < results.size) {
                if (!results[i].toLowerCase().contains("ext") && !results[i].toLowerCase()
                        .contains("sdcard")
                ) {
//                    Log.d(ImageViewTouchBase.LOG_TAG, results[i] + " might not be extSDcard")
                    results.removeAt(i--)
                }
                i++
            }
        }
        val storageDirectories = arrayOfNulls<String>(results.size)
        for (i in results.indices) storageDirectories[i] = results[i]
        return storageDirectories
    }

    private fun dialogScanLocation() {
        addEvent("ScanType")
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_scan_type)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val rbInternal = dialog.findViewById<RadioButton>(R.id.rb_internal)
        val rbExternal = dialog.findViewById<RadioButton>(R.id.rb_external)
        val rbCustom = dialog.findViewById<RadioButton>(R.id.rb_custom)
//        var selectedRb = "internal"

        if (Utils.getExternalMounts().size > 0) {
            rbExternal.visibility = View.VISIBLE
        } else {
            rbExternal.visibility = View.GONE
        }

        val scanType = SharedPrefsConstant.getInt(this, "scanTypeLabel", R.string.internal)
        var selectedRb = SharedPrefsConstant.getString(this, "scanType", "internal")
        Log.e("scanTypeRb", "dialogScan: $selectedRb")

        if (selectedRb.equals("internal", true)) {
            selectedRb = "internal"
            rbInternal.isChecked = true
            rbExternal.isChecked = false
            rbCustom.isChecked = false
        } else if (selectedRb.equals("external", true)) {
            selectedRb = "external"
            rbInternal.isChecked = false
            rbExternal.isChecked = true
            rbCustom.isChecked = false
        } else if (selectedRb.equals("custom", true)) {
            selectedRb = "custom"
            rbInternal.isChecked = false
            rbExternal.isChecked = false
            rbCustom.isChecked = true
        }

        rbInternal.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "internal"
                //rb_internal.isChecked=false
                rbExternal.isChecked = false
                rbCustom.isChecked = false
            }
        }
        rbExternal.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "external"
                rbInternal.isChecked = false
                //rb_external.isChecked=false
                rbCustom.isChecked = false
            }
        }
        rbCustom.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                //selectedRb="custom"
                rbInternal.isChecked = false
                rbExternal.isChecked = false
                //rb_custom.isChecked=false
            }
        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {

            dialog.dismiss()

        }
        dialog.show()
    }


    override fun onResume() {
        super.onResume()
        changeLanguage()
    }
}