package com.backup.restore.device.image.recovery.junckcleaner.interfaces;

public interface SendData {
    public void data(String data);
}
