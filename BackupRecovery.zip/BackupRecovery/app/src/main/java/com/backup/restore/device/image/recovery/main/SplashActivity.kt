package com.backup.restore.device.image.recovery.main


import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.*
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.AdsConfig
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.backup.restore.device.image.recovery.BuildConfig
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.inapp.InAppPurchaseHelper
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.ads.retrofit.APIService
import com.backup.restore.device.image.recovery.ads.retrofit.model.ForceUpdateModel
import com.backup.restore.device.image.recovery.ads.updatejsonparsing.GetJsonUpdateResponseTask
import com.backup.restore.device.image.recovery.ads.updatejsonparsing.getForceUpdate
import com.backup.restore.device.image.recovery.ads.updatejsonparsing.saveForceUpdate
import com.backup.restore.device.image.recovery.jsonparsing.JsonParserCallback
import com.backup.restore.device.image.recovery.mainapps.activity.LanguageActivity
import com.backup.restore.device.image.recovery.service.ManagerService
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager.isInternetConnected
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.example.jdrodi.utilities.OnPositive
import com.example.jdrodi.utilities.isOnline
import com.example.jdrodi.utilities.showAlert
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.util.*

@Suppress("DEPRECATION")
class SplashActivity : BaseActivity(), InAppPurchaseHelper.OnPurchased {

    private val mTAG: String = "SplashActivity"
    val mSplashDelay = 5000
//    var isFromNotification = false

    companion object {
        lateinit var databaseInputStream1: InputStream
    }

    private var isPaused = false
    private var adsCountDownTimer: AdsCountDownTimer? = null
    private var isAdClosed = false

//    override fun attachBaseContext(newBase: Context?) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase!!))
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_splash_screen)
//        lateinit var binding:ActivityBinding
//        binding=ActivityBinding.inflate(layoutInflater)
//        setContentView(binding.root)

        addEvent(mTAG)
    }


    override fun getContext(): AppCompatActivity {
        return this@SplashActivity
    }


    override fun initAds() {
        Log.e(mTAG, "initAds: Ads Loading")
//        InterstitialAdHelper.loadInterstitialAd(fContext = mContext, onAdLoaded = {
//            Log.e(mTAG, "initAds: Ad Loaded" )
//        })
    }


    override fun initData() {
        //  Call Daily Notification to received offline notification
//        dailyNotifications()

        SharedPrefsConstant.save(this, ShareConstants.RATE_LATTER,0)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Log.e(mTAG, "initData: ScanningDone --> " +  SharedPrefsConstant.getBooleanNoti(mContext,"ScanningDone",false) )
            Log.e(mTAG, "initData: ScanningDone Permission --> " +  Environment.isExternalStorageManager() )
            if (Environment.isExternalStorageManager() && SharedPrefsConstant.getBooleanNoti(mContext,"ScanningDone",false)) {
                startServiceMethod()
            }
        } else {
            if (checkPermissionStorage(this)) {
                startServiceMethod()
            }
        }

        if (ExitSPHelper(mContext).isDismissed()) {
            ExitSPHelper(mContext).saveDismissed(false)
        }


        if (mContext.isOnline()) {

            // Fetch App center data from the server
            if (isSDKBelow21()) {
                // Simple json parsing
                val url = mContext.getUpdateBaseUrl() + "ApkVersion"
                val pkgName = packageName
                val version = BuildConfig.VERSION_NAME.toDouble()
                GetJsonUpdateResponseTask(object : JsonParserCallback {
                    override fun onSuccess(response: String) {
                        Log.i(mTAG, response)
                        saveForceUpdate(response)
                        checkUpdateStatus(getForceUpdate())
                    }

                    override fun onFailure(message: String) {
                        Log.e(mTAG, message)
                        initBilling()
                    }

                }).executeOnExecutor(
                    AsyncTask.THREAD_POOL_EXECUTOR,
                    url,
                    pkgName,
                    version.toString()
                )

            } else {
                // Using retrofit with kotlin coroutine
                // To verify force update status
                launch {
                    checkForceUpdateStatus()
                }
            }


        } else {
            Log.i(mTAG, "offline")
            initBilling()
        }

    }


    private fun startServiceMethod() {
        try {
            if (!isMyServiceRunning(mContext,ManagerService::class.java)) {
                SharedPrefsConstant.savePrefNoti(mContext, "IsFromService", false)
                ManagerService.setData(mContext)
                startService(Intent(this, ManagerService::class.java))
                Log.e(mTAG, "startServiceMethod: " + SharedPrefsConstant.getBooleanNoti(mContext, "IsFromService", false))
            }
//            ManagerService.checkJunkAutoClean(mContext)
        } catch (e: java.lang.Exception) {
            Log.e(mTAG, "startServiceMethod: " + e.message)
            e.printStackTrace()
        }

        //        setProgressDialog();

    }

    private suspend fun checkForceUpdateStatus() {
        return withContext(Dispatchers.IO) {
            val retroApiInterface = APIService().getUpdateClient(mContext)
            try {
                val pkgName = packageName
                val version = BuildConfig.VERSION_NAME.toDouble()

                val reqUpdateStatus = retroApiInterface.getUpdateStatusAsync(pkgName, version)

                val resUpdateStatus = reqUpdateStatus.await()
                if (resUpdateStatus.isSuccessful && resUpdateStatus.body() != null) {
                    val body = resUpdateStatus.body()!!
                    checkUpdateStatus(body)
                } else {
                    Log.e(mTAG, "isSuccessful: false")
                    initBilling()
                }

            } catch (exception: Exception) {
                Log.e(mTAG, exception.toString())
                initBilling()

            }
        }
    }

    private fun checkUpdateStatus(forceUpdateModel: ForceUpdateModel) {
        Log.e(mTAG, "message: " + forceUpdateModel.message)
        if (forceUpdateModel.is_need_to_update) {
            Log.i(mTAG, "is_need_to_update: true")
            runOnUiThread {
                showAlert(
                    getString(R.string.update_required),
                    getString(R.string.update_message),
                    getString(R.string.update_positive),
                    getString(R.string.update_negative),
                    fontPath,
                    object : OnPositive {
                        override fun onYes() {
                            rateApp()
                            finish()
                        }

                        override fun onNo() {
                            super.onNo()
                            finishAffinity()
                        }
                    })
            }
        } else {
            Log.e(mTAG, "is_need_to_update: false")
            initBilling()
        }
    }


    override fun initActions() {
//        startWithoutRemoveAds()
    }


    //    private fun isOpenFromNotification(): Boolean {
//
//
//        OneSignal.setNotificationOpenedHandler { result ->
////            val actionId = result.action.actionId
////            val type: String = result.action.type.toString() // "ActionTaken" | "Opened"
////            val title = result.notification.title
//
//            // Printing out the full OSNotification object to the logcat for easier debugging.
//            val data = result.notification.additionalData
//
//            Log.e(mTAG, "startHome: $data")
//
//            if (data != null) {
//                val customKey = data.optString("OpenActivity", null)
//                if (customKey != null) {
//                    when (customKey) {
//                        "AppsBackupActivity" -> {
//                            startActivity(Intent(mContext, AppsBackupActivity::class.java))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                        "ContactMainActivity" -> {
//                            startActivity(Intent(mContext, ContactMainActivity::class.java))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                        "ScanningActivity_Image" -> {
//                            startActivity(Intent(mContext, ScanningActivity::class.java).putExtra("IsCheckType","Image"))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                        "ScanningActivity_Video" -> {
//                            startActivity(Intent(mContext, ScanningActivity::class.java).putExtra("IsCheckType","Video"))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                        "ScanningActivity_Audio" -> {
//                            startActivity(Intent(mContext, ScanningActivity::class.java).putExtra("IsCheckType","Audio"))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                        "ScanningActivity_Document" -> {
//                            startActivity(Intent(mContext, ScanningActivity::class.java).putExtra("IsCheckType","Document"))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                        "ScanningActivity_Other" -> {
//                            startActivity(Intent(mContext, ScanningActivity::class.java).putExtra("IsCheckType","Other"))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                        "RecoverImageActivity" -> {
//                            startActivity(Intent(mContext, RecoverImageActivity::class.java).putExtra("IsFromNotification", "yes"))
//                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                            isFromNotification = true
//                        }
//                    }
//                }
//            }
//        }
//
//        return isFromNotification
//    }
    fun rateApp() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (exception: ActivityNotFoundException) {
            Log.e(mTAG, exception.toString())
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
        }
    }


    // Every time to need initialize billing
    // to check if subscription or in-app purchase was made or not and even if it is made then to check is it active or expired
    private fun initBilling() {
        runOnUiThread {
//            interstitial = InterstitialAdHelper.instance!!.load(mContext, this)
            try {
                InAppPurchaseHelper.instance!!.initBillingClient(mContext, this)
                Log.e(mTAG, "initBilling: " )
            } catch (e: Exception) {
                Log.e(mTAG, "initBillingClient: " + e.message)
            }
        }
    }

    override fun onClick(view: View) {

    }


    /**
     * Called when leaving the mContext
     */
    public override fun onPause() {
        super.onPause()
        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }
//        if (interstitial != null) {
//            isPaused = true
////            Log.e(TAG, "onPause")
//        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()
//        Log.e(TAG, "onBackPressed")
//        exitProcess(0)
    }

    /**
     * Called when returning to the mContext
     */
    public override fun onResume() {
        super.onResume()
        changeLanguage()
//        Log.e(TAG, "onResume")

        if (isAdClosed) {
//            Log.e(TAG, "isAdClosed")
        } else {
            // Perform your task
            if (AdsManager(mContext).isNeedToShowAds()) {
                if (!SharedPrefsConstant.getBoolean(mContext, "isFromOneSignalNotificationForAd", false)) {
                    if (!SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true)) {
                        isAdClosed = false
                        MyApplication.isInterstitialShown = true
                        AdsConfig.showInterstitialAd(mContext,{
                            MyApplication.isInterstitialShown = false
                            isAdClosed = true
                            startHome()
                            Log.e(mTAG, "startHome::001")
                        })
//                        mContext.isShowInterstitialAd { isShowFullScreenAd ->
//                            Log.e(mTAG, "onClick: isShowFullScreenAd::$isShowFullScreenAd")
//                            MyApplication.isInterstitialShown = false
//                            isAdClosed = true
//                            startHome()
//                            Log.e(mTAG, "startHome::001")
//                        }
                    }
                } else {
                    SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", false)
                }
            }
            if (!isPaused) {
                return
            }
//            isAdClosed = true
//            startHome()
//            Handler().postDelayed({ startHome() }, 100)

//            Log.e(TAG, "Ads not loaded or may be null")
        }

    }

    /**
     * AdsCountDownTimer for 5 sec delay
     */
    inner class AdsCountDownTimer(millisInFuture: Long, countDownInterval: Long) :
        CountDownTimer(millisInFuture, countDownInterval) {
        override fun onTick(millisUntilFinished: Long) {
//            Log.e(mTAG, "startSplashDelay: " + (((mSplashDelay - millisUntilFinished) / 1000) + 1).toString())
        }

        override fun onFinish() {
//            Log.e(TAG, "countDownTimer: onFinish")

            if (isAdClosed) {
//                Log.e(TAG, "isAdClosed")
            } else {

                AdsConfig.showInterstitialAd(mContext,{
                    startHome()
                })
//                mContext.isShowInterstitialAd {
//                    startHome()
//                }

                /*if (window.decorView.rootView.isShown) {
                    startHome()
                    Log.e(mTAG, "startHome::002")
                }*/

            }
        }
    }


    /**
     * If app is not purchased or subscription not found start count down for 5 sec and load ad
     */
    private fun startSplashDelay() {

        Log.e(mTAG, "startSplashDelay: ")
        try {
            if (isInternetConnected(this)) {
                adsCountDownTimer = AdsCountDownTimer(5000, 1000)
                adsCountDownTimer!!.start()
                Log.e(mTAG, "startSplashDelay:5000 ")
            } else {
                adsCountDownTimer = AdsCountDownTimer(1000, 1000)
                adsCountDownTimer!!.start()
                Log.e(mTAG, "startSplashDelay:1000 ")
            }
            Log.e(mTAG, "startSplashDelay:Loading... ")
        } catch (e: java.lang.Exception) {
            Log.e(mTAG, "startSplashDelay: " + e.message)
            Thread.sleep(3000)
            if (isAdClosed) {
//                Log.e(TAG, "isAdClosed")
            } else {
                if (!SharedPrefsConstant.getBoolean(mContext, "isFromOneSignalNotificationForAd", false)) {
                    if (!SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true)) {
                        isAdClosed = false
                        MyApplication.isInterstitialShown = true

                        AdsConfig.showInterstitialAd(mContext,{
                            MyApplication.isInterstitialShown = false
                            isAdClosed = true
                            startHome()
                        })
//                        mContext.isShowInterstitialAd { isShowFullScreenAd ->
//                            Log.e(mTAG, "onClick: isShowFullScreenAd::$isShowFullScreenAd")
//                            MyApplication.isInterstitialShown = false
//                            isAdClosed = true
//                            startHome()
//                            Log.e(mTAG, "startHome::003")
//                        }
                    }
                } else {
                    SharedPrefsConstant.savePref(mContext, "isFromOneSignalNotificationForAd", false)
                }

            }
        }


//        InterstitialAdHelper.instance!!.load(mContext, this)

    }

    /**
     * Start your splash home our desire activity
     */
    private fun startHome() {
        Log.e(mTAG, "startHome: ")
        MyApplication.isInterstitialShown = false
        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }
        if (isFirstLaunch()) {
            saveFirstLaunch()

//            startActivity(NewHomeActivity.newIntent(this))
            val i = Intent(mContext, LanguageActivity::class.java)
            i.putExtra("isFromSplash", true)
            startActivity(i)
        } else {
            startActivity(NewHomeActivity.newIntent(mContext))
        }
        finish()
    }



    override fun onPurchasedSuccess(purchase: Purchase) {

    }


    override fun onProductAlreadyOwn() {

    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
            // The BillingClient is ready. You can query purchases here.
            GlobalScope.launch(Dispatchers.Main) {
//                InAppPurchaseHelper.instance!!.initProducts()
                InAppPurchaseHelper.instance!!.initSubscription()
                Log.e(mTAG, "IN_APP_BILLING | Done")
                redirectToNextActivity()
            }
        } else {
            GlobalScope.launch(Dispatchers.Main) {
                Log.e(mTAG, "IN_APP_BILLING | Done")
                redirectToNextActivity()
            }
        }

//        if (!isOpenFromNotification()){
//        }

    }


    override fun onBillingUnavailable() {
        Log.e(mTAG, "onBillingUnavailable: ")
        redirectToNextActivity()
    }

    override fun onBillingKeyNotFound(productId: String) {
        Log.e(mTAG, "onBillingKeyNotFound: ")
    }


    private fun redirectToNextActivity() {
        // Check if in-app or subscription already purchased

//        SharedPrefs.save(mContext, SharedPrefs.IS_ADS_REMOVED, !AdsManager(mContext).isNeedToShowAds())

        if (AdsManager(mContext).isNeedToShowAds()) {
            startSplashDelay()
        } else {
            startHome()
            Log.e(mTAG, "startHome::004")
        }
    }

//    private fun forceCrash() {
//        throw  RuntimeException("Test Crash") // Force a crash
//    }

//    inner class CopyDB : AsyncTask<Void, Void, Void>() {
//        override fun doInBackground(vararg params: Void?): Void? {
//            try {
//                val dbPath = "/data/data/$packageName/databases/contacts.sql"
//                val f = File(dbPath)
//                Log.e(mTAG, "f  : $f")
//                if (!f.exists()) {
//                    try {
//                        val dba = DBAdapter(mContext)
//                        dba.open()
//                        dba.close()
//                        Log.e(mTAG, "doInBackground: Database is copying.....")
//                        databaseInputStream1 = assets.open("contacts.sql")
//                        ImportDatabase.copyDataBase()
//
//                        Log.e(mTAG, "Database is copying.....")
//
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                        Log.e(mTAG, "fCopyDB: $e")
//                    }
//                }
//            } catch (e: Exception) {
//                e.printStackTrace()
////                Log.e(TAG, " catch  : $e")
//            }
//            return null
//        }
//
//
//    }


}
