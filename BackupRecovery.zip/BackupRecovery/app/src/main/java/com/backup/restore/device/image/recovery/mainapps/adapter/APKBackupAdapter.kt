package com.backup.restore.device.image.recovery.mainapps.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainapps.model.SelectedApk
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.example.jdrodi.callback.RVClickListener
import java.util.*

class APKBackupAdapter(
    val mContext: Activity,
    private var filterInstalledApps: List<SelectedApk>,
    private val mCheckAll: CheckBox,
    var mLlRefresh: LinearLayout,
    private val mRvListener: RVClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        var view: View = itemView.findViewById(R.id.view)
        var applicationIconImage: ImageView = itemView.findViewById(R.id.application_icon_image)
        var applicationLabelText: TextView = itemView.findViewById(R.id.application_label_text)
        var applicationDetail: TextView = itemView.findViewById(R.id.tv_detail)
        var cbSelect: CheckBox = itemView.findViewById(R.id.cb_select)
    }

    override fun getItemCount(): Int {
        return filterInstalledApps.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val menuItemLayoutView = LayoutInflater.from(parent.context).inflate(R.layout.raw_apk_item, parent, false)
        return MyViewHolder(menuItemLayoutView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val menuItemHolder = holder as MyViewHolder
        try {
//            if(position == filterInstalledApps.size -1 ){
//                holder.view.visibility = View.GONE
//            }else{
//                holder.view.visibility = View.VISIBLE
//            }

            menuItemHolder.applicationIconImage.setImageDrawable(filterInstalledApps[position].drawable)

            menuItemHolder.applicationLabelText.text = filterInstalledApps[position].appName + ".apk"

            val size= Utils.getDataSizeWithPrefix(mContext, filterInstalledApps!![position].size!!)
            menuItemHolder.applicationDetail.text = "${size.first} ${size.second}, ${filterInstalledApps!![position].installedTime}"
//            mLlRefresh.alpha = 1f
//            mLlRefresh.isEnabled = true
//            mLlRefresh.isClickable = true
//            menuItemHolder.cbSelect.isChecked = filterInstalledApps[position].isChecked
            menuItemHolder.cbSelect.isChecked = filterInstalledApps[position].isChecked
            menuItemHolder.itemView.setOnClickListener {
                try {
                    if (menuItemHolder.cbSelect.isChecked) {
                        menuItemHolder.cbSelect.isChecked = false
                        filterInstalledApps[position].isChecked = false
                    } else {
                        menuItemHolder.cbSelect.isChecked = true
                        filterInstalledApps[position].isChecked = true
                    }

                    val selectedSize = selectedApk().size
                    if (selectedSize == 0) {
                        mCheckAll.isChecked = false
                    } else {
                        mCheckAll.isChecked = selectedSize == filterInstalledApps.size
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun selectedApk(): ArrayList<SelectedApk> {
        val selectedApks = ArrayList<SelectedApk>()
        for (i in filterInstalledApps.indices) {
            if (filterInstalledApps[i].isChecked) {
                selectedApks.add(filterInstalledApps[i])
            }
        }
        return selectedApks
    }

    fun setApkList(filteredNames: List<SelectedApk>) {
        filterInstalledApps=filteredNames
        notifyDataSetChanged()
    }

    fun filterList(filteredNames: List<SelectedApk>) {
        filterInstalledApps = filteredNames
        if (filterInstalledApps.isEmpty()) {
            mRvListener.onEmpty()
        } else {
            mRvListener.onNotEmpty()
            val selectedSize = selectedApk().size
            if (selectedSize == filterInstalledApps.size) {
                mCheckAll.isChecked = true
            }
        }
        notifyDataSetChanged()
    }
}