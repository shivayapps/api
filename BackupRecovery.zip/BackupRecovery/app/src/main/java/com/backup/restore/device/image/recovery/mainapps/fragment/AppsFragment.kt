package com.backup.restore.device.image.recovery.mainapps.fragment

import android.app.Dialog
import android.app.ProgressDialog
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.*
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.annotation.DrawableRes
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.apkinfo.ApkInformationExtractor
import com.backup.restore.device.image.recovery.apkinfo.AppInfo
import com.backup.restore.device.image.recovery.apkinfo.AppManager
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.mainapps.activity.AppManagerActivity
import com.backup.restore.device.image.recovery.mainapps.adapter.AppAdapter
import com.backup.restore.device.image.recovery.utilities.CreateShortcutTool
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.*


/**
 * A placeholder fragment containing a simple view.
 */
class AppsFragment : Fragment() {

    var rootView: View? = null
    private var tv_emty_msg: TextView? = null
    private var ll_empty: LinearLayout? = null
    var rv_apps: RecyclerView? = null
    var lottie_apps: LottieAnimationView? = null
    var buttonUninstall: CardView? = null
    var buttonRecover: CardView? = null
    var button: LinearLayout? = null
    var alertSystem: TextView? = null
//    var lastVisible: Boolean = false

    lateinit var mContext: FragmentActivity
    var appType = "user"

    private var apkInformationExtractor: ApkInformationExtractor? = null
    private var progressDialog: ProgressDialog? = null

    public var adapter: AppAdapter? = null
    public var appList: MutableList<AppInfo>? = null
    public var appToUninstall: MutableList<AppInfo>? = null
    public var userAppList: MutableList<AppInfo>? = null
    public var systemAppList: MutableList<AppInfo>? = null
    private var mDbHelper: DBAdapter? = null
    var mCopyApks: AsyncTask<*, *, *>? = null
    private var path = ""

    //    internal var arrAppType: Array<String>? = null
    private var recyclerViewLayoutManager: RecyclerView.LayoutManager? = null
    private var appManOb: AppManager? = null
    private var numberOfUserApps: String? = " "
    private var numberOfSystemApps: String? = " "
    private var appInAction: AppInfo? = null
    var isActionDialog = false
    var isVisibleToUser = false


    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"

        @JvmStatic
        fun newInstance(type: String): AppsFragment {
            val fragment = AppsFragment()
            val bundle = Bundle()
            bundle.putString(ARG_SECTION_NUMBER, type)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        //super.setUserVisibleHint(isVisibleToUser)
        this.isVisibleToUser = isVisibleToUser
//        if(isVisibleToUser) {
//        }
//        else {
//        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = requireActivity()
        if (arguments != null) {
            appType = requireArguments().getString(ARG_SECTION_NUMBER)!!
        }
//        initAds()
    }

    fun deSelectAll() {
        appToUninstall?.clear()
        button?.visibility=View.GONE
        adapter?.deSelectAll()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_apps, container, false)
        tv_emty_msg = rootView?.findViewById(R.id.tv_emty_msg)
        ll_empty = rootView?.findViewById(R.id.ll_empty)
        rv_apps = rootView?.findViewById(R.id.rv_apps)
        buttonRecover = rootView?.findViewById(R.id.buttonRecover)
        buttonUninstall = rootView?.findViewById(R.id.buttonUninstall)
        button = rootView?.findViewById(R.id.button)
        alertSystem = rootView?.findViewById(R.id.alertSystem)

        lottie_apps = (requireActivity() as AppManagerActivity).findViewById(R.id.lottie_apps)

        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        path = ShareConstants.mRootPath + "/Backup And Recovery/Apk Backup/"

        initData()
        initActions()
        return rootView;
    }

    fun initData() {
        mDbHelper = DBAdapter(mContext)

        progressDialog = ProgressDialog(mContext)
        progressDialog!!.setMessage(getString(R.string.please_wait))
        progressDialog!!.setCancelable(false)
        progressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        progressDialog!!.isIndeterminate = true
        progressDialog!!.progress = 0

        appList = ArrayList()

        appManOb = AppManager()

        userAppList = ArrayList()
        systemAppList = ArrayList()
        appToUninstall = ArrayList()

        apkInformationExtractor = ApkInformationExtractor(mContext)
        recyclerViewLayoutManager = GridLayoutManager(mContext, 1)
//        recyclerViewLayoutManager = LinearLayoutManager(mContext,RecyclerView.VERTICAL,false)

        if (appType == "user") {
//            buttonUninstall.visibility=View.VISIBLE
            tv_emty_msg?.text = getString(R.string.user_app_list_is_empty)
            alertSystem?.visibility=View.GONE
        } else {
//            buttonUninstall?.visibility=View.GONE
            tv_emty_msg?.text = getString(R.string.system_app_list_is_empty)
            alertSystem?.visibility=View.VISIBLE
        }
        button?.visibility = View.GONE
        buttonUninstall?.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

            if (appToUninstall?.size!! > 0) {
                uninstallApp(appToUninstall!![0])
            }
        }
        buttonRecover?.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

            goForCopy()
//            if (appToUninstall?.size!! > 0) {
//                uninstallApp(appToUninstall!![0])
//            }
        }

        adapter = AppAdapter(mContext, appList!!, appType, object : AppAdapter.OnAppSelect {
            override fun onAppClick(position: Int, appInfo: AppInfo) {
                if (!adapter?.isMultiSelect!! && !isActionDialog) appActionDialog(appInfo, appType)
            }

            override fun onAppSelect(position: Int, isChecked: Boolean, appInfo: AppInfo) {
//                appActionDialog(appInfo,appType)
                if (isChecked) {
//                    Log.e("AppsFragment", "appToUninstall-add: ${appInfo.appPackage}")
//                    Log.e("AppsFragment", "onAppSelect-appToUninstall: ${appToUninstall.size}")
                    appToUninstall?.add(appInfo)
//                    AppManagerActivity.selectedPackage.add(appInfo.appPackage!!)
                } else {
//                    Log.e("AppsFragment", "appToUninstall-remove: ${appInfo.appPackage}")
//                    Log.e("AppsFragment", "onAppSelect-appToUninstall: ${appToUninstall.size}")
                    appToUninstall?.remove(appInfo)
//                    AppManagerActivity.selectedPackage.remove(appInfo.appPackage!!)
                }

                rv_apps?.scrollToPosition(position)

                if (appToUninstall?.size!! > 0) {
                    adapter?.isMultiSelect=true
                    button?.visibility = View.VISIBLE
                } else {
                    adapter?.isMultiSelect=false
                    button?.visibility = View.GONE
                }
                adapter?.notifyDataSetChanged()
            }
        })

        rv_apps?.layoutManager = recyclerViewLayoutManager
        rv_apps?.adapter = adapter
        rv_apps?.setItemViewCacheSize(500)

        getApps(mContext, appType)

//        if (AdsManager(mContext).isNeedToShowAds()) {
//            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
//        }
    }

    override fun onResume() {
        super.onResume()
    }


    private fun goForCopy() {
        if (appToUninstall!!.size != 0) {
            mCopyApks = CopyFiles(appToUninstall!!).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        } else {
            Toast.makeText(mContext, getString(R.string.select_item_first), Toast.LENGTH_SHORT).show()
        }
    }

    private inner class CopyFiles(var selectedApp: MutableList<AppInfo>) : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(activity!! as AppManagerActivity)
        var progress_text : TextView?=null
        var permission_text : TextView?=null
//        var selectedApp: MutableList<AppInfo>? = null

//        override fun CopyFiles(selectedApp: MutableList<AppInfo>) {
//            this.selectedApp=selectedApp
//        }
        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            progress_text=dialog.findViewById<TextView>(R.id.permission)
            progress_text?.text = getString(R.string.label_please_wait)
            permission_text=dialog.findViewById<TextView>(R.id.permission_text)
            permission_text?.text = getString(R.string.copying_apk_files)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)

            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                dialog.cancel()
                MyApplication.isDialogOpen = false
                if (mCopyApks != null) {
                    mCopyApks!!.cancel(true)
                }
            }

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
        }

        override fun doInBackground(vararg strings: String?): String? {
//            val selectedInfoList = mApkBackupAdapter!!.selectedApk()
//            if (selectedInfoList.isNotEmpty()) {
                for (i in selectedApp.indices) {
                    if (mCopyApks != null) {
                        if (mCopyApks!!.isCancelled) {
                            updateUi(dialog)
                        } else {
                            val file = File(selectedApp[i].publicSourceDir!!)
                            val dir = File(path)
                            if (dir.exists() || dir.mkdirs()) {
                                try {
                                    copy(file, selectedApp[i].appName, selectedApp[i].appName)
                                    activity!!.sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    }
                    activity?.runOnUiThread {
                        permission_text?.text="${getString(R.string.copying_apk_files)} $i/${selectedApp.size}"
                    }
                }
//            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)

            try {
                Handler(Looper.getMainLooper()).post {
                    deSelectAll()
//                    if(isAdded) {
//                        checkAll!!.isChecked = false
//                    }
                }

                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    try {
                        if (dialog != null && dialog.isShowing) {
                            dialog.cancel()
                            MyApplication.isDialogOpen = false
                        }
                    } catch (e: Exception) {
//                        mContext!!.addEvent(e.message!!)
                    }
                }, 100)

//                mContext!!.viewpager.currentItem = 1
                SharedPrefsConstant.save(mContext, ShareConstants.RATE_RECOVER_APK_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_RECOVER_APK_COUNT) + 1)
                SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_APK_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_APK_COUNT) + 1)

                Toast.makeText(mContext, getString(R.string.apks_copied) + path, Toast.LENGTH_LONG).show()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


    fun updateUi(pd: Dialog) {
        mContext.runOnUiThread {
            deSelectAll()
            pd.cancel()
        }
    }

    private fun copy(fileToCopy: File, lPackageName: String?, lAppName: String?) {
        try {
            val destinationFile = File(path, "$lAppName#$lPackageName.apk")
            Log.e("mTAG", "copy: destinationFile -- > $destinationFile")
            val fis = FileInputStream(fileToCopy)
            val fos = FileOutputStream(destinationFile)
            val b = ByteArray(1024)
            var noOfBytesRead: Int
            while (fis.read(b).also { noOfBytesRead = it } != -1) {
                fos.write(b, 0, noOfBytesRead)
            }
            fis.close()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun uninstallApp(appToUninstall: AppInfo) {

        SharedPrefsConstant.save(activity, ShareConstants.RATE_UNINSTALLER, SharedPrefsConstant.getInt(activity, ShareConstants.RATE_UNINSTALLER) + 1)

        appInAction = appToUninstall
        val appPackage: String = appInAction?.appPackage!!
        val uri = Uri.parse("package:$appPackage")
        val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri)
        startActivityForResult(intent, 115)
    }

    private fun appActionDialog(appInfo: AppInfo, appType: String) {
        appInAction = appInfo
        isActionDialog=true
        val bitmapIcon = getAppIconBitmapByPackageName(appInfo.appPackage!!)
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_app_action)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        val title = dialog.findViewById<TextView>(R.id.permission)
        val imageIcon = dialog.findViewById<ImageView>(R.id.imageIcon)
//        val imageCircle = dialog.findViewById<CircleImageView>(R.id.imageCircle)
        val radioGroup = dialog.findViewById<RadioGroup>(R.id.ll_radio)

        dialog.findViewById<RadioButton>(R.id.rb_uninstall).setShadowLayer(1.5f, -1F, 1F, Color.WHITE);
        dialog.findViewById<RadioButton>(R.id.rb_launch).setShadowLayer(1.5f, -1F, 1F, Color.WHITE);
        dialog.findViewById<RadioButton>(R.id.rb_detail).setShadowLayer(1.5f, -1F, 1F, Color.WHITE);
        dialog.findViewById<RadioButton>(R.id.rb_playstore).setShadowLayer(1.5f, -1F, 1F, Color.WHITE);
        dialog.findViewById<RadioButton>(R.id.rb_shortcut).setShadowLayer(1.5f, -1F, 1F, Color.WHITE);

        if (appType == "system") {
            dialog.findViewById<RadioButton>(R.id.rb_uninstall).visibility = View.GONE
            radioGroup.check(R.id.rb_launch)
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            dialog.findViewById<RadioButton>(R.id.rb_shortcut).visibility = View.GONE
        }

        title.setText(appInfo.appName)

        val uri = appInfo.appDrawableURI
        try {
            if (uri != Uri.EMPTY) {

                Glide.with(mContext)
                    .load(uri)
                    .into(imageIcon)
//                imageCircle.setImageResource(R.drawable.ic_circle_white)
            } else {
                val img = ContextCompat.getDrawable(mContext, R.drawable.ic_icon)
                imageIcon.setImageDrawable(img)
            }
        } catch (e: Exception) {
            val img = ContextCompat.getDrawable(mContext, R.drawable.ic_icon)
            imageIcon.setImageDrawable(img)
        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

            if (appType == "system") {
                AppManagerActivity.actionToInterstitialAd=true
//                AppManagerActivity.needInterstitialAd=true
            }
            MyApplication.isDialogOpen = false
            when (radioGroup.checkedRadioButtonId) {
                R.id.rb_uninstall -> {
                    dialog.dismiss()
                    val appPackage: String = appInfo.appPackage!!
                    val uri = Uri.parse("package:$appPackage")
                    val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri)
                    startActivityForResult(intent, 112)
                }
                R.id.rb_launch -> {
                    dialog.dismiss()

                    try {
                        val intent =
                            mContext.packageManager.getLaunchIntentForPackage(appInfo.appPackage!!)
                        if (intent != null) {
                            mContext.startActivity(intent)
                        } else {
                            Log.d("Exception", "Exception Handled")
                        }
                    } catch (e: Exception) {
                        Log.d("Exception", "Exception Handled")
                    }
                }
                R.id.rb_detail -> {
                    dialog.dismiss()
                    try {
                        //Open the specific App Info page:
                        val intent =
                            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        intent.data = Uri.parse("package:" + appInfo.appPackage!!)
                        startActivity(intent)

                    } catch (e: ActivityNotFoundException) {
                        //e.printStackTrace();
                        val intent =
                            Intent(android.provider.Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
                        startActivity(intent)
                    }
                }
                R.id.rb_playstore -> {
                    dialog.dismiss()
                    try {
                        val marketUri = Uri.parse("market://details?id=${appInfo.appPackage!!}")
                        val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
                        startActivity(marketIntent)
                    } catch (e: ActivityNotFoundException) {
                        val marketUri =
                            Uri.parse("https://play.google.com/store/apps/details?id=${appInfo.appPackage!!}")
                        val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
                        startActivity(marketIntent)
                    }
                }
                R.id.rb_shortcut -> {
                    dialog.dismiss()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        CreateShortcutTool.createHomeScreenShortcutNew(mContext,appInfo.appPackage!!)
                    } else {
                        Toast.makeText(mContext, "${getString(R.string.shortcut_can_only_be_pinned_on_oreo_and_above)}", Toast.LENGTH_SHORT).show()
                    }
                }
            }

        }
        dialog.setOnDismissListener {
            isActionDialog=false
        }
        dialog.show()
        MyApplication.isDialogOpen = true
        MyApplication.isInternalCall = true

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("onActivityResult", "fragment-requestCode: $requestCode")
        Log.e("onActivityResult", "fragment-resultCode: $resultCode")
        if (requestCode == 112) {
            //public void saveAppHistory(String name, String packageName, String size, String date)

            if (!ApkInformationExtractor(mContext).isPackageInstalled(appInAction?.appPackage!!)) {

                val formatter = SimpleDateFormat("EEE-MMM dd,yyyy", Locale.getDefault())
                val calendar = Calendar.getInstance()
                mDbHelper!!.saveAppHistory(
                    appInAction?.appName,
                    appInAction?.appPackage,
                    "${appInAction?.appSize}",
                    formatter.format(calendar.time)
                )
                AppManagerActivity.needInterstitialAd=true
                Handler(Looper.getMainLooper()).postDelayed({
                    getApps(mContext, appType)
                }, 500)
            }
        }
        if (requestCode == 115) {

            if (!ApkInformationExtractor(mContext).isPackageInstalled(appInAction?.appPackage!!)) {
                //public void saveAppHistory(String name, String packageName, String size, String date)
                appToUninstall?.remove(appInAction)
//                Log.e("AppsFragment", "appToUninstall-removeAppInAction: ${appInAction?.appPackage}")
//                Log.e("AppsFragment", "onActivityResult-appToUninstall: ${appToUninstall.size}")

                val formatter = SimpleDateFormat("EEE-MMM dd,yyyy", Locale.getDefault())
                val calendar = Calendar.getInstance()
                mDbHelper!!.saveAppHistory(
                    appInAction?.appName,
                    appInAction?.appPackage,
                    "${appInAction?.appSize}",
                    formatter.format(calendar.time)
                )

                if (appToUninstall?.size!! > 0) {
                    adapter?.isMultiSelect=true
                    uninstallApp(appToUninstall!![0])
                    button?.visibility = View.VISIBLE
//                    if(lastVisible) rv_apps?.scrollToPosition(adapter?.itemCount!!)
                } else {
                    AppManagerActivity.needInterstitialAd=true

                    adapter?.isMultiSelect=false
                    Handler(Looper.getMainLooper()).postDelayed({
                        getApps(mContext, appType)
                    }, 500)
                }
            } else {
                appToUninstall?.remove(appInAction)
//                appToUninstall.clear()
                if (appToUninstall?.size!! > 0) {
                    adapter?.isMultiSelect=true
                    uninstallApp(appToUninstall!![0])
                    button?.visibility = View.VISIBLE
//                    if(lastVisible) rv_apps?.scrollToPosition(adapter?.itemCount!!)
                } else {
//                    AppManagerActivity.needInterstitialAd=true
//                    if (AdsManager(activity!!).isNeedToShowAds() && mInterstitial != null) {
//                        if (!SharedPrefsConstant.getBoolean(
//                                activity!!,
//                                SharedPrefsConstant.IS_APP_IN_BACKGROUND,
//                                true
//                            )
//                        ) {
//                            if (mInterstitial != null) mInterstitial!!.show(activity!!)
//                        }
//                    }

                    adapter?.isMultiSelect=false
                    Handler(Looper.getMainLooper()).postDelayed({
                        getApps(mContext, appType)
                    }, 500)
                }
            }

        }
    }

    fun drawableToBitmap(drawable: Drawable): Bitmap? {
        var bitmap: Bitmap? = null
        if (drawable is BitmapDrawable) {
            val bitmapDrawable: BitmapDrawable = drawable as BitmapDrawable
            if (bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap()
            }
        }
        bitmap = if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            Bitmap.createBitmap(
                1,
                1,
                Bitmap.Config.ARGB_8888
            ) // Single color bitmap will be created of 1x1 pixel
        } else {
            Bitmap.createBitmap(
                drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(),
                Bitmap.Config.ARGB_8888
            )
        }
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight())
        drawable.draw(canvas)
        return bitmap
    }

    private fun getAppIconBitmapByPackageName(ApkTempPackageName: String): Bitmap? {
        val drawable: Drawable? = try {
            mContext.packageManager.getApplicationIcon(ApkTempPackageName)
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            ContextCompat.getDrawable(mContext, R.mipmap.ic_launcher)
        }
        return drawableToBitmap(drawable!!)
//        return drawable
    }

    fun createShortcut(context: Context, name: String, intent: Intent, icon: IconCompat): Boolean {
        if (ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            val pinShortcutInfo = ShortcutInfoCompat.Builder(context, name)
                .setIcon(icon)
                .setShortLabel(name)
                .setIntent(intent)
                .build()
            return ShortcutManagerCompat.requestPinShortcut(context, pinShortcutInfo, null)
        }
        return false
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun shortcutDialog1(appInfo: AppInfo, bitmapIcon: Bitmap) {
        val manager = mContext.getSystemService(ShortcutManager::class.java)
        if (manager.isRequestPinShortcutSupported) {

            val intent =
                Intent(mContext.packageManager.getLaunchIntentForPackage(appInfo.appPackage!!))

            val shortcut = ShortcutInfo.Builder(
                activity,
                generateId(appInfo.appName!!)
            )
                .setShortLabel(appInfo.appName!!)
                .setIcon(Icon.createWithBitmap(bitmapIcon))
                .setIntent(intent)
                .build()

            manager.requestPinShortcut(shortcut, null)

        } else {
            Toast.makeText(context, "The shortcut not supported", Toast.LENGTH_LONG).show()
        }
    }


    fun createLauncherIcon(context: Context, activityModel: AppInfo, bitmap: Bitmap?) {
        val intent = activityModelToIntent(activityModel)
        val iconCompat = IconCompat.createWithBitmap(bitmap!!)
        try {
            createShortcut(context, activityModel.appName!!, intent, iconCompat)
        } catch (e: Exception) { // android.os.TransactionTooLargeException
            createLauncherIcon(context, activityModel.appName!!, intent, R.mipmap.ic_launcher)
        }
    }

    fun createLauncherIcon(context: Context, name: String, intent: Intent, @DrawableRes icon: Int) {
        val iconCompat = IconCompat.createWithResource(context, icon)
        createShortcut(context, name, intent, iconCompat)
    }

    private fun activityModelToIntent(activityModel: AppInfo): Intent {

        val intent =
            Intent(mContext.packageManager.getLaunchIntentForPackage(activityModel.appPackage!!))
        return intent
    }

    private fun generateId(str: String): String {
        return str + (Random().nextInt(91) + 10)
    }

    public fun filter(filter: String) {
        if (!filter.isEmpty()) {
            Log.e("AppsFragment", "filter-filterAppList: $appType")
            if (appType.equals("user")) {
//                filterAppList(filter, userAppList!!)
                filterAppList(filter, adapter?.getAppList()!!)
            } else if (appType.equals("system")) {
//                filterAppList(filter, systemAppList!!)
                filterAppList(filter, adapter?.getAppList()!!)
            }
        } else {
            Log.e("AppsFragment", "filter-updateAppList: $appType")
            if (appType.equals("user")) {
                updateAppList(userAppList!!)
            } else if (appType.equals("system")) {
                updateAppList(systemAppList!!)
            }
        }

    }

    private fun getApps(context: Context, type: String) {
        if((activity as AppManagerActivity)!=null && isAdded) {
                (activity as AppManagerActivity).binding.etSearch.setText("")
        }
        Log.e("AppsFragment", "fragment-getApps: $type")
        if (appToUninstall?.size!! > 0) {
            adapter?.isMultiSelect=true
            button?.visibility = View.VISIBLE
//            if(lastVisible) rv_apps?.scrollToPosition(adapter?.itemCount!!)
        } else {
            adapter?.isMultiSelect=false
            button?.visibility = View.GONE
        }
        lottie_apps?.playAnimation()
        lottie_apps?.visibility=View.VISIBLE
        ll_empty?.visibility=View.GONE

        val contextRef: WeakReference<Context> = WeakReference(context)

        //Coroutine
        GlobalScope.launch(Dispatchers.Default) {
            try {
                val context1 = contextRef.get()
                appManOb = ApkInformationExtractor(context).appManagerInitValues()

                userAppList?.clear()
                systemAppList?.clear()

                if (appManOb != null) {
                    numberOfUserApps = " " + appManOb!!.userAppSize
                    numberOfSystemApps = " " + appManOb!!.systemAppSize

                    userAppList?.addAll(appManOb!!.userApps)
                    systemAppList?.addAll(appManOb!!.systemApps)

                } else {
                    numberOfUserApps = " " + "0"
                    numberOfSystemApps = " " + "0"

                }

                //UI Thread
                withContext(Dispatchers.Main) {

                    Log.e("AppsFragment", "withContext-updateAppList: $type")
                    if (type.equals("user")) {
                        updateAppList(userAppList!!)
                    } else if (type.equals("system")) {
                        updateAppList(systemAppList!!)
                    }
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun filterAppList(filter: String, newAppList: MutableList<AppInfo>) {
        val filteredList = ArrayList<AppInfo>()
//        var isUninstalledFilter=false
        for (app in newAppList) {
            if (app.appName.toString().lowercase(Locale.getDefault()).contains(filter)) {
                filteredList.add(app)
            }
//            if(app.isSelected) isUninstalledFilter=true
        }
        updateAppList(filteredList)
//        if (appToUninstall?.size!! > 0 && isUninstalledFilter) {
//            adapter?.isMultiSelect=true
//            buttonUninstall?.visibility = View.VISIBLE
//        } else {
//            adapter?.isMultiSelect=false
//            buttonUninstall?.visibility = View.GONE
//        }
    }

    private fun updateAppList(newAppList: MutableList<AppInfo>) {
        Log.e("AppsFragment", "updateAppList-newAppList: ${newAppList.size}")

        var isUninstalledFilter=false
        for (app in newAppList) {
            if(app.isSelected) isUninstalledFilter=true
        }
        if (appToUninstall?.size!! > 0 && isUninstalledFilter) {
            adapter?.isMultiSelect=true
            button?.visibility = View.VISIBLE
        } else {
            adapter?.isMultiSelect=false
            button?.visibility = View.GONE
        }

        if (newAppList.size > 0) {
            appList?.clear()
            appList?.addAll(newAppList)
            adapter?.updateList(newAppList)

            ll_empty?.visibility = View.GONE
            rv_apps?.visibility = View.VISIBLE
        } else {
            ll_empty?.visibility = View.VISIBLE
            rv_apps?.visibility = View.GONE
        }

        lottie_apps?.visibility = View.GONE
        if (progressDialog!!.isShowing) {
            progressDialog!!.dismiss()
        }

        if (appType.equals("user")) {
            (activity as AppManagerActivity).binding.tvUserApps.text="${getString(R.string.user_apps)} (${newAppList?.size})"
        } else if (appType.equals("system")) {
            (activity as AppManagerActivity).binding.tvSystemApps.text="${getString(R.string.system_apps)} (${newAppList?.size})"
        }

    }

    fun initActions() {
    }


    override fun onDestroyView() {
        super.onDestroyView()
//        rootView = null
    }


}