package com.backup.restore.device.image.recovery.mainduplicate.callbacks

import java.io.Serializable

interface DuplicateListener : Serializable{
    fun checkScanFinish(mEmptyFolderList: ArrayList<String>)
}