package com.backup.restore.device.image.recovery.retriever;

import android.os.Parcel;


public class RAWImage extends Photo {

    RAWImage() {

    }

    RAWImage(Parcel parcel) {
        super(parcel);
    }

//    @Override
//    public int[] retrieveImageDimens(Context context) {
//        return Utils.getImageDimensions(context, getUri(context));
//    }

//    @Override
//    public String getType(Context context) {
//        return "raw_image";
//    }
}
