package com.backup.restore.device.image.recovery.ads.rateandfeedback.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.example.jdrodi.callback.RVClickListener


class OptionsAdapter(
    val mContext: Context,
    private val listOptions: Array<String>,
    val listener: RVClickListener,
) : RecyclerView.Adapter<OptionsAdapter.ViewHolder>() {

    var lastCheckedPosition = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.raw_option, parent, false))
    }

    override fun getItemCount(): Int {
        return listOptions.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val option = listOptions[position]

        holder.cbSelect.text = option
        holder.cbSelect.setChecked(position == lastCheckedPosition);

//        holder.cbSelect.setOnClickListener {
//            val copyOfLastCheckedPosition: Int = lastCheckedPosition
//            lastCheckedPosition = position
//            notifyItemChanged(copyOfLastCheckedPosition)
//            notifyItemChanged(lastCheckedPosition)
//        }

        holder.itemView.setOnClickListener {
            listener.onItemClick(position)
            val copyOfLastCheckedPosition: Int = lastCheckedPosition
            lastCheckedPosition = position
            notifyItemChanged(copyOfLastCheckedPosition)
            notifyItemChanged(lastCheckedPosition)
        }

    }

    public class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        //        var cbSelect: RadioButton? = null
        val cbSelect: RadioButton = itemView.findViewById(R.id.cb_select)

//        init {
//            cbSelect = itemView.findViewById(R.id.cb_select)
//            cbSelect.setOnClickListener {
//                val copyOfLastCheckedPosition: Int = lastCheckedPosition
//                lastCheckedPosition = adapterPosition
//                notifyItemChanged(copyOfLastCheckedPosition)
//                notifyItemChanged(lastCheckedPosition)
//            }
//        }
    }
//    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        val cbSelect: RadioButton = itemView.findViewById(R.id.cb_select)
//
//    }
}