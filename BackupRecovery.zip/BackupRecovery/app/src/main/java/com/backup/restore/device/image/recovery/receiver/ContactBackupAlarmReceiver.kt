package com.backup.restore.device.image.recovery.receiver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.maincontact.activity.ContactMainActivity
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant

/**
 * Created by Vasundhara on 03-May-18.
 */
class ContactBackupAlarmReceiver : BroadcastReceiver() {
    var mTAG: String = javaClass.simpleName
    var mNotificationManager: NotificationManager? = null
    var mContext: Context? = null
    var mNotificationId = 0

    override fun onReceive(context: Context, intent: Intent) {
        this.mContext = context
        if (!SharedPrefsConstant.getBoolean(context, SharedPrefsConstant.AUTO_BACKUP)) {
            Log.e(mTAG, "cancel")
        } else {
            mNotificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            customNotificationConfirm()
            val intentMap = Intent("my_backups")
            LocalBroadcastManager.getInstance(context).sendBroadcast(intentMap)
        }
    }

    private fun customNotificationConfirm() {
        mNotificationId = System.currentTimeMillis().toInt()
        val lNotificationIntent = Intent(mContext, ContactMainActivity::class.java)
        lNotificationIntent.putExtra("notification", "confirm_request")
        lNotificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(mContext, 0, lNotificationIntent, PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE)
        val lChannelId = mContext!!.resources.getString(R.string.app_name)
        val notificationBuilder = NotificationCompat.Builder(mContext!!, lChannelId)
            .setSmallIcon(R.drawable.ic_auto_backup)
            .setContentTitle(mContext!!.getText(R.string.app_name))
            .setContentText(mContext!!.getText(R.string.time_to_take_auto_backup_of_contacts))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setColor(mContext!!.resources.getColor(R.color.colorPrimary))
            .setVibrate(longArrayOf(1000, 1000, 1000, 1000, 1000))
        val manager = mContext!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = notificationBuilder.build()
        notification.defaults = notification.defaults or Notification.DEFAULT_VIBRATE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(lChannelId, lChannelId, importance)
            manager.createNotificationChannel(channel)
        }
        manager.notify(mNotificationId, notificationBuilder.build())
    }
}