package com.backup.restore.device.image.recovery.junckcleaner.activities

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.util.Pair
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.airbnb.lottie.LottieAnimationView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.junckcleaner.adapters.JunkAdapter1
import com.backup.restore.device.image.recovery.junckcleaner.interfaces.*
import com.backup.restore.device.image.recovery.junckcleaner.models.FileModel
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.mainapps.model.Utils.*
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.checkPermissionStorage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.RatingDialog
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.widget.LoadingDots
//import com.example.app.ads.helper.GiftIconHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityJunkBinding
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
//import kotlinx.android.synthetic.main.activity_junk.*
//import kotlinx.android.synthetic.main.layout_junk_finished.*
import java.io.File
import java.util.*
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class JunkActivity : AppCompatActivity(), SelectAll {

    var mTAG = "JunkActivity"
//    var apkInterface: ApkInterface? = null
//    var sysInterface: SysInterface? = null
//    var userAppInterface: UserAppInterface? = null

    var cl_calculating_super: ConstraintLayout? = null
    var cl_blur: ConstraintLayout? = null
    var cl_calculating: ConstraintLayout? = null
    var cl_temp_head: CardView? = null
    var cl_apksHead: CardView? = null
    var cl_trashHead: CardView? = null
    var cl_emptyHead: CardView? = null
    var cl_uninstalledHead: CardView? = null
    var cl_apksRecyclerView: ConstraintLayout? = null
    var cl_tempRecyclerView: ConstraintLayout? = null
    var cl_trashRecyclerView: ConstraintLayout? = null
    var cl_emptyRecyclerView: ConstraintLayout? = null
    var cl_uninstalledRecyclerView: ConstraintLayout? = null
    var scrollView_junk_calculated: ScrollView? = null
    var layout_junk_finished: View? = null
    var textView_filePath: TextView? = null
    var textView_junk_prefix: TextView? = null
    var textView_junk_size: TextView? = null
    var txt_success: TextView? = null
    var txt_cleaned: TextView? = null
    var textView_apks_size: TextView? = null
    var textView_temp_size: TextView? = null
    var textView_trash_size: TextView? = null
    var textView_empty_size: TextView? = null
    var textView_uninstalled_size: TextView? = null
    var buttonScan: LinearLayout? = null
    var txt_scan: TextView? = null
    var imageView_trash: ImageView? = null
    var imageView_empty_folder: ImageView? = null
    var imageView_uninstalled: ImageView? = null
    var imageView_temp_files: ImageView? = null
    var imageView_useless_apks: ImageView? = null
    var imageView_apks_upDown: ImageView? = null
    var imageView_temp_upDown: ImageView? = null
    var imageView_trash_upDown: ImageView? = null
    var imageView_empty_upDown: ImageView? = null
    var imageView_uninstalled_upDown: ImageView? = null
    var imageView_apks_select: ImageView? = null
    var imageView_temp_select: ImageView? = null
    var imageView_trash_select: ImageView? = null
    var imageView_empty_select: ImageView? = null
    var imageView_uninstalled_select: ImageView? = null

    //var imageView_back_finished: ImageView? = null
    var imageView_back_1: ImageView? = null

    var imageView_apks_upDown_click: ImageView? = null
    var imageView_temp_upDown_click: ImageView? = null
    var imageView_trash_upDown_click: ImageView? = null
    var imageView_empty_upDown_click: ImageView? = null
    var imageView_uninstalled_upDown_click: ImageView? = null

    var imageView_apks_select_click: ImageView? = null
    var imageView_temp_select_click: ImageView? = null
    var imageView_trash_select_click: ImageView? = null
    var imageView_empty_select_click: ImageView? = null
    var imageView_uninstalled_select_click: ImageView? = null

    var process_dots: LoadingDots? = null

    var lottie_trash: LottieAnimationView? = null
    var lottie_logtemp: LottieAnimationView? = null
    var lottie_useless_apks: LottieAnimationView? = null
    var lottie_empty_folder: LottieAnimationView? = null
    var lottie_uninstalled: LottieAnimationView? = null
    var lottie_loading: LottieAnimationView? = null

    var recyclerView_apks: RecyclerView? = null
    var recyclerView_temp: RecyclerView? = null
    var recyclerView_trash: RecyclerView? = null
    var recyclerView_empty: RecyclerView? = null
    var recyclerView_uninstalled: RecyclerView? = null

    var apksExpended = false
    var tempExpanded = false
    var trashExpanded = false
    var emptyExpanded = false
    var uninstalledExpanded = false
    var apksSelectedAll = true
    var tempSelectedAll = true
    var trashSelectedAll = true
    var emptySelectedAll = true
    var uninstalledSelectedAll = true
    var scanning = false
    var totalType = 0

    //    boolean isScanComplete = false;
    var apksAdapter: JunkAdapter1? = null
    var tempAdapter: JunkAdapter1? = null
    var trashAdapter: JunkAdapter1? = null
    var emptyAdapter: JunkAdapter1? = null
    var uninstalledAdapter: JunkAdapter1? = null
    var apksList: MutableList<FileModel> = ArrayList()
    var tempList: MutableList<FileModel> = ArrayList()
    var trashList: MutableList<FileModel> = ArrayList()
    var emptyList: MutableList<FileModel> = ArrayList()
    var uninstalledList: MutableList<FileModel> = ArrayList()
    var total: Double = 0.0
    var apkTotal: Double = 0.0
    var tempTotal: Double = 0.0
    var trashTotal: Double = 0.0
    var emptyTotal: Double = 0.0
    var uninstalledTotal: Double = 0.0
    var calendar: Calendar? = null

    //    var getJunkData: GetJunkData? = null
    var getTempFiles: GetTempFiles? = null
    var getApkFiles: GetApkFiles? = null
    var getTrashFiles: GetTrashFiles? = null
    var getEmptyFiles: GetEmptyFiles? = null
    var getUninstalledFiles: GetUninstalledFiles? = null

    var apks: ArrayList<FileModel>? = null
    var tempLog: ArrayList<FileModel>? = null
    var trashCache: ArrayList<FileModel>? = null
    var emptyFolder: ArrayList<FileModel>? = null
    var uninstalledFolder: ArrayList<FileModel>? = null

    var filterTemps = ArrayList<String>()
    var filterTrash = ArrayList<String>()
    var filterInstalled = ArrayList<String>()
    var path = ""

    var isFromOneSignal = false

    interface OnTaskCompleted {
        fun onTaskCompleted(type: Int)
    }

    lateinit var binding:ActivityJunkBinding
    var onTaskListner: OnTaskCompleted? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        changeLanguage()
//        setContentView(R.layout.activity_junk)
        binding=ActivityJunkBinding.inflate(layoutInflater)
        setContentView(binding.root)
        addEvent(JunkActivity::class.simpleName!!)

        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }

        cl_apksHead = findViewById(R.id.cl_apksHead)
        cl_apksRecyclerView = findViewById(R.id.cl_apksRecyclerView)
        cl_tempRecyclerView = findViewById(R.id.cl_tempRecyclerView)
        cl_trashRecyclerView = findViewById(R.id.cl_trashRecyclerView)
        cl_emptyRecyclerView = findViewById(R.id.cl_emptyRecyclerView)
        cl_uninstalledRecyclerView = findViewById(R.id.cl_uninstalledRecyclerView)
        cl_trashHead = findViewById(R.id.cl_trashHead)
        cl_emptyHead = findViewById(R.id.cl_emptyHead)
        cl_temp_head = findViewById(R.id.cl_temp_head)
        cl_uninstalledHead = findViewById(R.id.cl_uninstalledHead)
        cl_calculating_super = findViewById(R.id.cl_calculating_super)
        cl_blur = findViewById(R.id.cl_blur)
        cl_calculating = findViewById(R.id.cl_calculating)
        scrollView_junk_calculated = findViewById(R.id.scrollView_junk_calculated)
        layout_junk_finished = findViewById(R.id.layout_junk_finished)
        recyclerView_apks = findViewById(R.id.recyclerView_apks)
        recyclerView_temp = findViewById(R.id.recyclerView_temps)
        recyclerView_trash = findViewById(R.id.recyclerView_trash)
        recyclerView_empty = findViewById(R.id.recyclerView_empty)
        recyclerView_uninstalled = findViewById(R.id.recyclerView_uninstalled)
        textView_apks_size = findViewById(R.id.textView_apks_size)
        textView_temp_size = findViewById(R.id.textView_temp_size)
        textView_trash_size = findViewById(R.id.textView_trash_size)
        textView_empty_size = findViewById(R.id.textView_empty_size)
        textView_uninstalled_size = findViewById(R.id.textView_uninstalled_size)
        textView_junk_size = findViewById(R.id.textView_junk_size)
        textView_junk_prefix = findViewById(R.id.textView_junk_prefix)
        txt_success = findViewById(R.id.txt_success)
        txt_cleaned = findViewById(R.id.txt_cleaned)
        textView_filePath = findViewById(R.id.textView_filePath)
        buttonScan = findViewById(R.id.btn_scan)
        txt_scan = findViewById(R.id.txt_scan)
        imageView_apks_upDown_click = findViewById(R.id.imageView_apks_upDown_click)
        imageView_temp_upDown_click = findViewById(R.id.imageView_temp_upDown_click)
        imageView_trash_upDown_click = findViewById(R.id.imageView_trash_upDown_click)
        imageView_empty_upDown_click = findViewById(R.id.imageView_empty_upDown_click)
        imageView_uninstalled_upDown_click = findViewById(R.id.imageView_uninstalled_upDown_click)
        imageView_apks_upDown = findViewById(R.id.imageView_apks_upDown)
        imageView_temp_upDown = findViewById(R.id.imageView_temp_upDown)
        imageView_trash_upDown = findViewById(R.id.imageView_trash_upDown)
        imageView_empty_upDown = findViewById(R.id.imageView_empty_upDown)
        imageView_uninstalled_upDown = findViewById(R.id.imageView_uninstalled_upDown)
        imageView_useless_apks = findViewById(R.id.imageView_useless_apks)
        imageView_temp_files = findViewById(R.id.imageView_temp_files)
        imageView_trash = findViewById(R.id.imageView_trash)
        imageView_empty_folder = findViewById(R.id.imageView_empty_folder)
        imageView_uninstalled = findViewById(R.id.imageView_uninstalled)
        imageView_apks_select_click = findViewById(R.id.imageView_apks_select_click)
        imageView_temp_select_click = findViewById(R.id.imageView_temp_select_click)
        imageView_trash_select_click = findViewById(R.id.imageView_trash_select_click)
        imageView_empty_select_click = findViewById(R.id.imageView_empty_select_click)
        imageView_uninstalled_select_click = findViewById(R.id.imageView_uninstalled_select_click)
        imageView_apks_select = findViewById(R.id.imageView_apks_select)
        imageView_temp_select = findViewById(R.id.imageView_temp_select)
        imageView_trash_select = findViewById(R.id.imageView_trash_select)
        imageView_empty_select = findViewById(R.id.imageView_empty_select)
        imageView_uninstalled_select = findViewById(R.id.imageView_uninstalled_select)
        imageView_back_1 = findViewById(R.id.imageView_back_1)
        process_dots = findViewById(R.id.process_dots)
        lottie_loading = findViewById(R.id.lottie_loading)
        lottie_empty_folder = findViewById(R.id.lottie_empty_folder)
        lottie_uninstalled = findViewById(R.id.lottie_uninstalled)
        lottie_useless_apks = findViewById(R.id.lottie_useless_apks)
        lottie_logtemp = findViewById(R.id.lottie_logtemp)
        lottie_trash = findViewById(R.id.lottie_trash)

        binding.appCompatTextView13.isSelected = true
        binding.appCompatTextView16.isSelected = true
        binding.appCompatTextView19.isSelected = true
        binding.appCompatTextView20.isSelected = true
        binding.appCompatTextView21.isSelected = true

        path = Environment.getExternalStorageDirectory().toString()

//        if (application != null) {
//            val tempFolders: List<String> = ArrayList(Arrays.asList(*application!!.resources.getStringArray(R.array.generic_filter_folders)))
//            for (folder in tempFolders) filterTemps.add(getRegexForFolder(folder))
//        }

        if (application != null) {
            val tempFiles: List<String> =
                ArrayList(Arrays.asList(*application!!.resources.getStringArray(R.array.generic_filter_files)))
            for (file in tempFiles) filterTemps.add(getRegexForFile(file))
        }

//        if (application != null) {
//            val trashFolders: List<String> = ArrayList(Arrays.asList(*application!!.resources.getStringArray(R.array.aggressive_filter_folders)))
//            for (folder in trashFolders) filterTrash.add(getRegexForFolder(folder))
//        }
        if (application != null) {
            val trashFiles: List<String> =
                ArrayList(Arrays.asList(*application!!.resources.getStringArray(R.array.aggressive_filter_files)))
            for (file in trashFiles) filterTrash.add(getRegexForFile(file))
        }

        if (application != null) filterInstalled.addAll(getInstalledPackages(application!!.baseContext))

        if (AdsManager(this@JunkActivity).isNeedToShowAds() && NetworkManager.isInternetConnected(this@JunkActivity)) {
//            GiftIconHelper.loadGiftAd(
//                fContext = this@JunkActivity,
//                fivGiftIcon = findViewById(R.id.main_la_gift),
//                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//            )
        }

        calendar = Calendar.getInstance()

        findViewById<TextView>(R.id.permission)!!.text = getString(R.string.please_wait)
        findViewById<TextView>(R.id.permission_text)!!.visibility = View.GONE
        findViewById<Button>(R.id.dialogButtonCancel)!!.visibility = View.GONE

        layout_junk_finished?.setVisibility(View.GONE)
        scrollView_junk_calculated?.setVisibility(View.GONE)
        cl_calculating?.setVisibility(View.VISIBLE)
        onTaskListner = object : OnTaskCompleted {
            override fun onTaskCompleted(type: Int) {
                Log.e(mTAG, "onTaskCompleted:$type")
                if (type == 2) {
                    Log.e(mTAG, "onTaskCompleted:apks")
                    apks?.forEach { apks ->
                        if (apks != null) {
                            apksList.add(apks)
                            apkTotal += apks.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setApksRecyclerView")
                        totalType += 1
                        setApksRecyclerView(apksList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 2)
                        lottieVisibility(false, 2)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getApks-Exception:" + e)
                    }
                }
                if (type == 3) {
                    Log.e(mTAG, "onTaskCompleted:temps")
                    tempLog?.forEach { temps ->
                        if (temps != null) {
                            tempList.add(temps)
                            tempTotal += temps.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setTempRecyclerView")
                        totalType += 1
                        setTempRecyclerView(tempList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 3)
                        lottieVisibility(false, 3)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getTempLog-Exception:" + e)
                    }
                }
                if (type == 1) {
                    Log.e(mTAG, "onTaskCompleted:trash")
                    trashCache?.forEach { trash ->
                        if (trash != null) {
                            trashList.add(trash)
                            trashTotal += trash.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setTrashRecyclerView")
                        totalType += 1
                        setTrashRecyclerView(trashList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 1)
                        lottieVisibility(false, 1)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getTrashCache-Exception:" + e)
                    }
                }
                if (type == 4) {
                    Log.e(mTAG, "onTaskCompleted:empty")
                    emptyFolder?.forEach { empty ->
                        if (empty != null) {
                            emptyList.add(empty)
                            emptyTotal += empty.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setEmptyRecyclerView")
                        totalType += 1
                        setEmptyRecyclerView(emptyList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 4)
                        lottieVisibility(false, 4)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getEmptyFolder-Exception:" + e)
                    }

                }
                if (type == 5) {
                    Log.e(mTAG, "onTaskCompleted:uninstalled")
                    uninstalledFolder?.forEach { uninstalled ->
                        if (uninstalled != null) {
                            uninstalledList.add(uninstalled)
                            uninstalledTotal += uninstalled.getSize().toFloat()
                        }
                    }
                    try {
                        Log.e(mTAG, "onTaskCompleted:setUninstalledRecyclerView")
                        totalType += 1
                        setUninstalledRecyclerView(uninstalledList)
                        total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                        val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                        setSizeAnimation(size)
                        imagesDoneVisibility(true, 5)
                        lottieVisibility(false, 5)
                        if (totalType >= 5) {
                            junkCalculating()
                            countJunkSize()
                        }
                    } catch (e: Exception) {
                        Log.e(mTAG, "getUninstalled-Exception:" + e)
                    }
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            if (checkPermissionStorage(this@JunkActivity)) {
                runScanner()
            } else {
                val permissions: List<String> = ArrayList(
                    Arrays.asList(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                )
                givePermissions(permissions)
            }
        }
//        }

        cl_blur?.setOnClickListener {
            Toast.makeText(
                this,
                getString(R.string.cleaner_running_please_wait),
                Toast.LENGTH_SHORT
            ).show()
        }

        // recycler views visibilities settings
        buttonScan?.setOnClickListener(View.OnClickListener { v: View? ->

            if (apksAdapter != null) apkTotal = apksAdapter?.allTotal!!
            if (tempAdapter != null) tempTotal = tempAdapter?.allTotal!!
            if (trashAdapter != null) trashTotal = trashAdapter?.allTotal!!
            if (emptyAdapter != null) emptyTotal = emptyAdapter?.allTotal!!
            if (uninstalledAdapter != null) uninstalledTotal = uninstalledAdapter?.allTotal!!
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            if (total == 0.0) {
                Toast.makeText(this, getString(R.string.no_file_to_delete), Toast.LENGTH_SHORT)
                    .show()
                return@OnClickListener
            }
            changeLoading(lottie_loading!!, "cleaner_running.json")
//            lottie_loading?.clearAnimation()
//            lottie_loading?.setAnimation("cleaner_running.json")
//            lottie_loading?.setRepeatCount(99)
//            lottie_loading?.playAnimation()
            if (!scanning) {
//                buttonScan?.isEnabled=false
                cl_blur?.visibility = View.VISIBLE
                process_dots?.visibility = View.VISIBLE
                buttonScan!!.alpha = 0.5f
                scanning = true

                if (apksAdapter != null) apksAdapter!!.clearFile()
                if (tempAdapter != null) tempAdapter!!.clearFile()
                if (trashAdapter != null) trashAdapter!!.clearFile()
                if (emptyAdapter != null) emptyAdapter!!.clearFile()
                if (uninstalledAdapter != null) uninstalledAdapter!!.clearFile()

                txt_scan?.setText(getString(R.string.cleaning))
                cleanProgressAnimation(total)
            }
        })

        imageView_back_1?.setOnClickListener(View.OnClickListener { v: View? ->
            onBackPressed()
//            if (!scanning) {
//                finish()
//            }
        })
        imageView_apks_upDown_click?.setOnClickListener(View.OnClickListener { v: View? ->
            if (!apksExpended) {
//                imageView_apks_upDown.setImageResource(R.drawable.ic_arrow_up);
                imageView_apks_upDown?.setRotation(180f)
//                cl_apksHead.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                cl_apksRecyclerView?.setVisibility(View.VISIBLE)
                apksExpended = true
            } else {
                imageView_apks_upDown?.setRotation(0f)
                imageView_apks_upDown?.setImageResource(R.drawable.ic_arrow_down)
//                cl_apksHead.setBackgroundResource(R.drawable.shape_stroke_curved_white_opacity_10);
                cl_apksRecyclerView?.setVisibility(View.GONE)
                apksExpended = false
            }
        })
        imageView_temp_upDown_click?.setOnClickListener(View.OnClickListener { v: View? ->
            if (!tempExpanded) {
//                imageView_temp_upDown.setImageResource(R.drawable.ic_arrow_up);
                imageView_temp_upDown?.setRotation(180f)
//                cl_temp_head.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                cl_tempRecyclerView?.setVisibility(View.VISIBLE)
                tempExpanded = true
            } else {
//                imageView_temp_upDown.setImageResource(R.drawable.ic_arrow_down);
                imageView_temp_upDown?.setRotation(0f)
//                cl_temp_head.setBackgroundResource(R.drawable.shape_stroke_curved_white_opacity_10);
                cl_tempRecyclerView?.setVisibility(View.GONE)
                tempExpanded = false
            }
        })
        imageView_trash_upDown_click?.setOnClickListener(View.OnClickListener { v: View? ->
            if (!trashExpanded) {
//                imageView_trash_upDown.setImageResource(R.drawable.ic_arrow_up);
                imageView_trash_upDown?.setRotation(180f)
//                cl_trashHead.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                cl_trashRecyclerView?.setVisibility(View.VISIBLE)
                trashExpanded = true
            } else {
//                imageView_trash_upDown.setImageResource(R.drawable.ic_arrow_down);
                imageView_trash_upDown?.setRotation(0f)
//                cl_trashHead.setBackgroundResource(   R.drawable.shape_stroke_curved_white_opacity_10);
                cl_trashRecyclerView?.setVisibility(View.GONE)
                trashExpanded = false
            }
        })
        imageView_empty_upDown_click?.setOnClickListener(View.OnClickListener { v: View? ->
            if (!emptyExpanded) {
//                imageView_empty_upDown.setImageResource(R.drawable.ic_arrow_up);
                imageView_empty_upDown?.setRotation(180f)
//                cl_emptyHead.setBackgroundResource(R.drawable.shape_stroke_above_curved_white_opacity_10);
                cl_emptyRecyclerView?.setVisibility(View.VISIBLE)
                emptyExpanded = true
            } else {
//                imageView_empty_upDown.setImageResource(R.drawable.ic_arrow_down);
                imageView_empty_upDown?.setRotation(0f)
//                cl_emptyHead.setBackgroundResource(R.drawable.shape_stroke_curved_white_opacity_10);
                cl_emptyRecyclerView?.setVisibility(View.GONE)
                emptyExpanded = false
            }
        })
        imageView_uninstalled_upDown_click?.setOnClickListener(View.OnClickListener { v: View? ->
            if (!uninstalledExpanded) {
                imageView_uninstalled_upDown?.setRotation(180f)
                cl_uninstalledRecyclerView?.setVisibility(View.VISIBLE)
                uninstalledExpanded = true
            } else {
                imageView_uninstalled_upDown?.setRotation(0f)
                cl_uninstalledRecyclerView?.setVisibility(View.GONE)
                uninstalledExpanded = false
            }
        })

//        if (AdsManager(this).isNeedToShowAds()) {
//            InterstitialAdHelper.loadInterstitialAd(fContext = this@JunkActivity)
//        }
        stopServiceMethod()

        if (AdsManager(this@JunkActivity).isNeedToShowAds() && NetworkManager.isInternetConnected(
                this@JunkActivity
            )
        ) {
            NativeAdHelper(this,binding.layoutJunkFinished.adview, NativeLayoutType.NativeMedium).loadAd()
//            NativeAdvancedModelHelper(this@JunkActivity).loadNativeAdvancedAd(
//                NativeAdsSize.Big,
//                findViewById(R.id.ad_view_container)
//            )
        } else {
            binding.layoutJunkFinished.adview.visibility = View.GONE
        }
    }

    fun initTempLogs() {
    }

    fun initTrashCache() {
    }

    fun initEmpty() {
    }

    fun initApks() {
    }

    fun initUninstalled() {
    }


    private fun getAllUninstalled(
        path: String,
        filterInstalled: ArrayList<String>
    ): List<FileModel> {
//        Log.e("Utils", "getAllUninstalled:" + path);
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllUninstalledFilter(filterInstalled))
        if (mlist != null) {
//            Log.e("Utils", "getAllUninstalled:mlist:" + mlist.length);
            for (f in mlist) {
                if (f.isDirectory && f.absolutePath.contains("Android")) {
                    if (!f.absolutePath.contains("Backup And Recovery")) {
                        val fList = getAllUninstalled(f.absolutePath, filterInstalled)
                        docList.addAll(fList)
                    }
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private val emptyDocList: MutableList<FileModel> = ArrayList()
    private fun getAllEmptyNew(path: String): List<FileModel> {
        Log.e("Utils", "getAllEmptyNew:$path")
        val fold = File(path)
//        val docList: List<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        if (mlist != null && mlist.size != 0) {
            for (f in mlist) {
                if (f.isDirectory) {
                    if (!f.toString().startsWith("/storage/emulated/0/Android/data")
                        && !f.toString().startsWith("/storage/emulated/0/Android/obb")
                    ) {
//                        docList.addAll(getAllEmptyNew(f.getAbsolutePath()));
                        getAllEmptyNew(f.absolutePath)
                    }
                }
            }
        } else {
            Log.e("Utils", "getAllEmptyNew:emptySize" + emptyDocList.size)
            Log.e("Utils", "getAllEmptyNew:fold:" + fold.path)
            if (fold.isDirectory) {
                if (!fold.toString().startsWith("/storage/emulated/0/Android/data")
                    && !fold.toString().startsWith("/storage/emulated/0/Android/obb")
                ) {
                    val doc = FileModel()
                    doc.name = fold.name
                    doc.setSize(fold.length())
                    doc.path = fold.absolutePath
                    if (fold.length() > 0) {
                        Log.e("Utils", "getAllEmptyNew:getPath_001:" + fold.path)
                        //                        docList.add(doc);
                        emptyDocList.add(doc)
                    }
                }
            }
        }
        //        return docList;
        return emptyDocList
    }

    private fun getAllTrash(path: String, trashFilters: ArrayList<String>): List<FileModel> {
//        Log.e("Utils", "getAllTrash:" + path);
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllTempLogsFilter(trashFilters))
        if (mlist != null) {
//            Log.e("Utils", "getAllTrash:mlist:" + mlist.length);
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllTrash(f.absolutePath, trashFilters)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getAllTempLogs(path: String, tempFilters: ArrayList<String>): List<FileModel> {
        Log.e("Utils", "getAllTempLogs:$path")
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllTempLogsFilter(tempFilters))
        if (mlist != null) {
            Log.e("Utils", "getAllTempLogs:mlist:" + mlist.size)
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllTempLogs(f.absolutePath, tempFilters)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getAllPackages(path: String): List<FileModel> {

//        Log.e("Utils", "getAllPackages:" + path);
        val fold = File(path)
        val docList: MutableList<FileModel> = ArrayList()
        val mlist = fold.listFiles()
        val mFilelist = fold.listFiles(AllPackagesFilter())

        if (mlist != null) {
            for (f in mlist) {
                if (f.isDirectory) {
                    val fList = getAllPackages(f.absolutePath)
                    docList.addAll(fList)
                }
            }
            if (mFilelist != null) {
                for (f in mFilelist) {
                    if (!f.name.isEmpty() || !f.absolutePath.contains("Backup And Recovery")) {
                        val doc = FileModel()
                        doc.name = f.name
                        doc.setSize(f.length())
                        doc.path = f.absolutePath
                        if (f.length() > 0) {
                            docList.add(doc)
                        }
                    }
                }
            }
        }
        return docList
    }

    private fun getRegexForFolder(folder: String): String {
        return ".*(\\\\|/)$folder(\\\\|/|$).*"
    }

    private fun getRegexForFile(file: String): String {
        return ".+" + file.replace(".", "\\.") + "$"
    }

    private fun getInstalledPackages(context: Context): List<String> {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val packagesString: MutableList<String> = ArrayList()
        for (packageInfo in packages) {
            packagesString.add(packageInfo.packageName)
        }
        return packagesString
    }

    private fun startServiceMethod() {
        try {
            SharedPrefsConstant.savePrefNoti(this@JunkActivity, "isDeleteFromEmpty", false)
        } catch (e: java.lang.Exception) {
            Log.e(mTAG, "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }

    private fun stopServiceMethod() {
        try {
            SharedPrefsConstant.savePrefNoti(this@JunkActivity, "isDeleteFromEmpty", true)
        } catch (e: java.lang.Exception) {
            Log.e(mTAG, "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }

    private fun changeLoading(lottieView: LottieAnimationView, assetName: String) {
        runOnUiThread {
            lottieView.clearAnimation()
            lottieView.setAnimation(assetName)
            lottieView.loop(true)
            lottieView.playAnimation()
        }
    }

    private fun givePermissions(permissions: List<String>) {
        MyApplication.isInternalCall = true
        Dexter.withContext(this@JunkActivity).withPermissions(permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(multiplePermissionsReport: MultiplePermissionsReport) {
                    if (multiplePermissionsReport.areAllPermissionsGranted()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            checkAllFilePermission()
                        } else {
                            runScanner()
                        }
                        showSettingsDialog()
                    } else if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied) {
                        showSettingsDialog()
                    } else givePermissions(permissions)
                }

                override fun onPermissionRationaleShouldBeShown(
                    list: List<PermissionRequest>,
                    permissionToken: PermissionToken
                ) {
                    permissionToken.continuePermissionRequest()
                }
            })
    }

    private fun showSettingsDialog() {
        val dialog = Dialog(this@JunkActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.findViewById<View>(R.id.dialogButtonOk)
            .setOnClickListener(View.OnClickListener {
                MyApplication.isDialogOpen = false
                dialog.cancel()
                openSettings()
            })
        dialog.findViewById<View>(R.id.dialogButtonCancel)
            .setOnClickListener {
                MyApplication.isDialogOpen = false
                dialog.cancel()

                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                } else {
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }
        dialog.show()
        MyApplication.isDialogOpen = true
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    runScanner()
                } else {
                    Toast.makeText(
                        this@JunkActivity,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(this@JunkActivity)) {
                runScanner()
            } else {
                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                } else {
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
                Toast.makeText(
                    this@JunkActivity,
                    getString(R.string.permission_required),
                    Toast.LENGTH_SHORT
                ).show()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    var stopDialog: Dialog? = null
    private fun dialogStopScan() {
        stopDialog = Dialog(this@JunkActivity)
        stopDialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        stopDialog?.setCancelable(false)
        stopDialog?.setContentView(R.layout.dialog_confirmation)
        stopDialog?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        stopDialog?.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        (stopDialog?.findViewById<View>(R.id.imageIcon) as ImageView).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_exit_scan))
        (stopDialog?.findViewById<View>(R.id.permission) as TextView).text = getString(R.string.scanning_in_progress)
        (stopDialog?.findViewById<View>(R.id.permission_text) as TextView).text = getString(R.string.are_you_sure_you_want_to_stop_scanning_your_device)
        (stopDialog?.findViewById<View>(R.id.dialogButtonOk) as TextView).text = getString(R.string.doit_close)
        (stopDialog?.findViewById<View>(R.id.dialogButtonCancel) as TextView).text = getString(R.string.stop)
        stopDialog?.findViewById<View>(R.id.dialogButtonOk)!!.setOnClickListener {
            stopDialog?.cancel()
        }
        stopDialog?.findViewById<View>(R.id.dialogButtonCancel)!!
            .setOnClickListener {
                stopDialog?.cancel()

                if (getTempFiles?.status == AsyncTask.Status.RUNNING) {
                    getTempFiles?.cancel(true)
                }
                if (getApkFiles?.status == AsyncTask.Status.RUNNING) {
                    getApkFiles?.cancel(true)
                }
                if (getTrashFiles?.status == AsyncTask.Status.RUNNING) {
                    getTrashFiles?.cancel(true)
                }
                if (getEmptyFiles?.status == AsyncTask.Status.RUNNING) {
                    getEmptyFiles?.cancel(true)
                }
                if (getUninstalledFiles?.status == AsyncTask.Status.RUNNING) {
                    getUninstalledFiles?.cancel(true)
                }
                scanning = false
//                onBackPressed()
                startServiceMethod()
                Handler(Looper.getMainLooper()).postDelayed({ onBackPressed() }, 500)
            }
        stopDialog?.show()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                runScanner()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse(
                        String.format("package:%s", packageName)
                    )
                )
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    private fun runScanner() {
        if (!scanning) {
            scanning = true

            changeLoading(lottie_loading!!, "cleaner_running.json")
//            lottie_loading!!.clearAnimation()
//            lottie_loading!!.setAnimation("cleaner_running.json")
//            lottie_loading!!.repeatCount = 99
//            lottie_loading!!.playAnimation()
//            repositoryStorage = RepositoryStorage(application)
//            repositoryStorage?.initJunk()

            scrollView_junk_calculated!!.visibility = View.GONE
            cl_calculating!!.visibility = View.VISIBLE
            imagesDoneVisibility(false, 1)
            lottieVisibility(true, 1)
            imagesDoneVisibility(false, 2)
            lottieVisibility(true, 2)
            imagesDoneVisibility(false, 3)
            lottieVisibility(true, 3)
            imagesDoneVisibility(false, 4)
            lottieVisibility(true, 4)
            imagesDoneVisibility(false, 5)
            lottieVisibility(true, 5)

//            getJunkData = GetJunkData(this@JunkActivity, repositoryStorage!!, onTaskListner)
            getTempFiles = GetTempFiles(this@JunkActivity, onTaskListner)
            getApkFiles = GetApkFiles(this@JunkActivity, onTaskListner)
            getTrashFiles = GetTrashFiles(this@JunkActivity, onTaskListner)
            getEmptyFiles = GetEmptyFiles(this@JunkActivity, onTaskListner)
            getUninstalledFiles = GetUninstalledFiles(this@JunkActivity, onTaskListner)

//            getJunkData?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            if (SharedPrefsConstant.getInt(this@JunkActivity, "JunkRunCount") == 0) {
                SharedPrefsConstant.save(
                    this@JunkActivity,
                    "JunkRunCount",
                    SharedPrefsConstant.getInt(this@JunkActivity, "JunkRunCount") + 1
                )
            }

            Log.e(
                mTAG,
                "AsyncTask-JunkCount:${
                    SharedPrefsConstant.getInt(
                        this@JunkActivity,
                        "JunkRunCount"
                    )
                }"
            )

            getTempFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getApkFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getTrashFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getEmptyFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

            getUninstalledFiles?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

        }
    }


    inner class GetTempFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:3")
            try {
//                initTempLogs()
//        tempLog = getTempLogs(path, filterTemps)
//        tempLog!!.addAll(getAllTempLogs(path,filterTemps))
                tempLog = ArrayList(getAllTempLogs(path, filterTemps))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-3:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask-onTaskCompleted:3")
            onTaskCompleted!!.onTaskCompleted(3)
        }
    }

    inner class GetApkFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:2")
            try {
//                initApks()
//        apks = getFilesApks(path)
//        apks!!.addAll(getAllPackages(path))
                apks = ArrayList(getAllPackages(path))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-2:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask-onTaskCompleted:2")
            onTaskCompleted!!.onTaskCompleted(2)
        }
    }

    inner class GetTrashFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask-doInBackground:1")
            try {
                trashCache = ArrayList(getAllTrash(path, filterTrash))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask-1:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:1")
//            ShareConstants.isTrashInitialized=1
            onTaskCompleted!!.onTaskCompleted(1)
        }
    }

    inner class GetEmptyFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask+doInBackground:4")
            try {
//                initEmpty()
//        emptyFolder = getEmpty(path)
                emptyDocList.clear()
//        emptyFolder!!.addAll(getAllEmptyNew(path))
                emptyFolder = ArrayList(getAllEmptyNew(path))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask+4:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:4")
//            ShareConstants.isEmptyInitialized=1
            onTaskCompleted!!.onTaskCompleted(4)
        }
    }

    inner class GetUninstalledFiles(
        var context: Activity,
        var onTaskCompleted: OnTaskCompleted?
    ) : AsyncTask<String, String, String>() {

        override fun onPreExecute() {
            super.onPreExecute()
        }

        protected override fun doInBackground(vararg strings: String): String? {
            Log.e(mTAG, "AsyncTask+doInBackground:5")
            try {
//                initUninstalled()
//        uninstalledFolder = getUninstalled(path, filterInstalled)
//        uninstalledFolder!!.addAll(getAllUninstalled(path, filterInstalled))
                uninstalledFolder = ArrayList(getAllUninstalled(path, filterInstalled))
            } catch (e: Exception) {
                Log.e(mTAG, "AsyncTask+5:Exception:$e")
            }
            System.gc()
            return null
        }

        override fun onPostExecute(str: String?) {
            super.onPostExecute(str)
            Log.e(mTAG, "AsyncTask+onTaskCompleted:5")
            onTaskCompleted!!.onTaskCompleted(5)
        }
    }

    fun verifyInstallerId(context: Context, packageName: String?): Boolean {

        // A list with valid installers package name
        val validInstallers: List<String?> =
            ArrayList(Arrays.asList("com.android.vending", "com.google.android.feedback"))

        // The package name of the app that has installed your app
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val installer = context.packageManager.getInstallSourceInfo(
                    (packageName)!!
                )
                installer.initiatingPackageName
                //                installer.getInstallingPackageName();
                return validInstallers.contains(installer.initiatingPackageName) ||
                        validInstallers.contains(installer.installingPackageName)
            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }
        } else {
            val installer1 = context.packageManager.getInstallerPackageName(
                (packageName)!!
            )
            return installer1 != null && validInstallers.contains(installer1)
        }
        return false
    }

    fun imagesDoneVisibility(visible: Boolean, num: Int) {
        if (visible) {
            if (num == 1) {
                imageView_trash!!.visibility = View.VISIBLE
            } else if (num == 2) {
                imageView_useless_apks!!.visibility = View.VISIBLE
            } else if (num == 3) {
                imageView_temp_files!!.visibility = View.VISIBLE
            } else if (num == 4) {
                imageView_empty_folder!!.visibility = View.VISIBLE
            } else if (num == 5) {
                imageView_uninstalled!!.visibility = View.VISIBLE
            }
        } else {
            if (num == 1) {
                imageView_trash!!.visibility = View.INVISIBLE
            } else if (num == 2) {
                imageView_useless_apks!!.visibility = View.INVISIBLE
            } else if (num == 3) {
                imageView_temp_files!!.visibility = View.INVISIBLE
            } else if (num == 4) {
                imageView_empty_folder!!.visibility = View.INVISIBLE
            } else if (num == 5) {
                imageView_uninstalled!!.visibility = View.INVISIBLE
            }
        }
    }

    fun lottieVisibility(visible: Boolean, num: Int) {
        if (visible) {
            if (num == 1) {
                lottie_trash!!.visibility = View.VISIBLE
            } else if (num == 2) {
                lottie_useless_apks!!.visibility = View.VISIBLE
            } else if (num == 3) {
                lottie_logtemp!!.visibility = View.VISIBLE
            } else if (num == 4) {
                lottie_empty_folder!!.visibility = View.VISIBLE
            } else if (num == 5) {
                lottie_uninstalled!!.visibility = View.VISIBLE
            }
        } else {
            if (num == 1) {
                lottie_trash!!.visibility = View.INVISIBLE
            } else if (num == 2) {
                lottie_useless_apks!!.visibility = View.INVISIBLE
            } else if (num == 3) {
                lottie_logtemp!!.visibility = View.INVISIBLE
            } else if (num == 4) {
                lottie_empty_folder!!.visibility = View.INVISIBLE
            } else if (num == 5) {
                lottie_uninstalled!!.visibility = View.INVISIBLE
            }
        }
    }

    fun setApksRecyclerView(list: List<FileModel>) {
        val lm1 = LinearLayoutManager(this)
        lm1.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        apksAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "apk", apkTotal)
        recyclerView_apks!!.layoutManager = lm1
        recyclerView_apks!!.adapter = apksAdapter
//        apksAdapter!!.setSendData(this)
        apksAdapter!!.setSelectAll(this)
        apksAdapter!!.submitList(list)
        if (list.isEmpty()) {
            imageView_apks_select!!.setImageResource(R.drawable.ic_radio_unselect)
        } else {
            imageView_apks_select!!.setImageResource(R.drawable.ic_test_check)
        }
        apkTotal = apksAdapter!!.allTotal
        val size = Utils.getDataSizeWithPrefix(applicationContext, apkTotal)
        textView_apks_size!!.setText("${size.first} ${size.second}")
        imageView_apks_select_click!!.setOnClickListener { v: View? ->
            if (apksSelectedAll) {
                imageView_apks_select!!.setImageResource(R.drawable.ic_radio_unselect)
                apksAdapter!!.clearList()
                apksSelectedAll = false
//                total=total-apkTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            } else {
                apksSelectedAll = true
                apksAdapter!!.selectAll()
                imageView_apks_select!!.setImageResource(R.drawable.ic_test_check)
//                total=total+apkTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            }
        }
        if (apksList.isEmpty()) {
            cl_apksHead!!.visibility = View.GONE
            imageView_apks_upDown!!.visibility = View.INVISIBLE
            imageView_apks_select!!.visibility = View.INVISIBLE
            imageView_apks_upDown_click!!.visibility = View.INVISIBLE
            imageView_apks_select_click!!.visibility = View.INVISIBLE
            textView_apks_size!!.visibility = View.INVISIBLE
        } else {
            cl_apksHead!!.visibility = View.VISIBLE
            imageView_apks_upDown!!.visibility = View.VISIBLE
            imageView_apks_select!!.visibility = View.VISIBLE
            imageView_apks_upDown_click!!.visibility = View.VISIBLE
            imageView_apks_select_click!!.visibility = View.VISIBLE
            textView_apks_size!!.visibility = View.VISIBLE
        }
    }

    fun setTempRecyclerView(list: List<FileModel>) {
        val lm1 = LinearLayoutManager(this)
        lm1.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        tempAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "temp", tempTotal)
        recyclerView_temp!!.layoutManager = lm1
        recyclerView_temp!!.adapter = tempAdapter
//        tempAdapter!!.setSendData(this)
        tempAdapter!!.setSelectAll(this)
        tempAdapter!!.submitList(list)
        if (!list.isEmpty()) {
            imageView_temp_select!!.setImageResource(R.drawable.ic_test_check)
        }
        tempTotal = tempAdapter!!.allTotal
//        textView_temp_size!!.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                tempTotal.toLong()
//            )
//        )

//        textView_temp_size!!.setText("${String.format(Locale.ENGLISH,"%.2f", tempTotal)} ${getString(R.string.mb)}")

        val size = Utils.getDataSizeWithPrefix(applicationContext, tempTotal)
        textView_temp_size!!.setText("${size.first} ${size.second}")
        imageView_temp_select_click!!.setOnClickListener { v: View? ->
            if (!tempSelectedAll) {
                tempSelectedAll = true
                imageView_temp_select!!.setImageResource(R.drawable.ic_test_check)
                tempAdapter!!.selectAll()
//                total=total+tempTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            } else {
                tempAdapter!!.clearList()
                tempSelectedAll = false
                imageView_temp_select!!.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-tempTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            }
        }
        if (tempList.isEmpty()) {
            cl_temp_head!!.visibility = View.GONE
            imageView_temp_upDown!!.visibility = View.INVISIBLE
            imageView_temp_select!!.visibility = View.INVISIBLE
            imageView_temp_upDown_click!!.visibility = View.INVISIBLE
            imageView_temp_select_click!!.visibility = View.INVISIBLE
            textView_temp_size!!.visibility = View.INVISIBLE
        } else {
            cl_temp_head!!.visibility = View.VISIBLE
            imageView_temp_upDown!!.visibility = View.VISIBLE
            imageView_temp_select!!.visibility = View.VISIBLE
            imageView_temp_upDown_click!!.visibility = View.VISIBLE
            imageView_temp_select_click!!.visibility = View.VISIBLE
            textView_temp_size!!.visibility = View.VISIBLE
        }
    }

    fun setTrashRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        trashAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "trash", trashTotal)
        recyclerView_trash!!.layoutManager = lm3
        recyclerView_trash!!.adapter = trashAdapter
//        trashAdapter!!.setSendData(this)
        trashAdapter!!.setSelectAll(this)
        trashAdapter!!.submitList(list)
        if (!list.isEmpty()) {
            imageView_trash_select!!.setImageResource(R.drawable.ic_test_check)
        }
        trashTotal = trashAdapter!!.allTotal
//        textView_trash_size!!.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                trashTotal.toLong()
//            )
//        )
//        textView_trash_size!!.setText("${String.format(Locale.ENGLISH,"%.2f", trashTotal)} ${getString(R.string.mb)}")
        val size = Utils.getDataSizeWithPrefix(applicationContext, trashTotal)
        textView_trash_size!!.setText("${size.first} ${size.second}")
        imageView_trash_select_click!!.setOnClickListener { v: View? ->
            if (!trashSelectedAll) {
                imageView_trash_select!!.setImageResource(R.drawable.ic_test_check)
                trashAdapter!!.selectAll()
                trashSelectedAll = true
//                total=total+trashTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            } else {
                trashAdapter!!.clearList()
                trashSelectedAll = false
                imageView_trash_select!!.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-trashTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            }
        }
        if (trashList.isEmpty()) {
            cl_trashHead!!.visibility = View.GONE
            imageView_trash_upDown_click!!.visibility = View.INVISIBLE
            imageView_trash_upDown!!.visibility = View.INVISIBLE
            textView_trash_size!!.visibility = View.INVISIBLE
            imageView_trash_select!!.visibility = View.INVISIBLE
            imageView_trash_select_click!!.visibility = View.INVISIBLE
        } else {
            cl_trashHead!!.visibility = View.VISIBLE
            imageView_trash_upDown_click!!.visibility = View.VISIBLE
            imageView_trash_upDown!!.visibility = View.VISIBLE
            textView_trash_size!!.visibility = View.VISIBLE
            imageView_trash_select!!.visibility = View.VISIBLE
            imageView_trash_select_click!!.visibility = View.VISIBLE
        }
    }

    fun setEmptyRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        emptyAdapter = JunkAdapter1(this@JunkActivity, list1, list2, "empty", emptyTotal)
        recyclerView_empty!!.layoutManager = lm3
        recyclerView_empty!!.adapter = emptyAdapter
//        emptyAdapter!!.setSendData(this)
        emptyAdapter!!.setSelectAll(this)
        emptyAdapter!!.submitList(list)
        if (!list.isEmpty()) {
            imageView_empty_select!!.setImageResource(R.drawable.ic_test_check)
        }
        emptyTotal = emptyAdapter!!.allTotal
//        textView_empty_size!!.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                emptyTotal.toLong()
//            )
//        )
//        textView_empty_size!!.setText("${String.format(Locale.ENGLISH,"%.2f", emptyTotal)} ${getString(R.string.mb)}")

        val size = Utils.getDataSizeWithPrefix(applicationContext, emptyTotal)
        textView_empty_size!!.setText("${size.first} ${size.second}")

        imageView_empty_select_click!!.setOnClickListener { v: View? ->
            if (!emptySelectedAll) {
                imageView_empty_select!!.setImageResource(R.drawable.ic_test_check)
                emptyAdapter!!.selectAll()
                emptySelectedAll = true
//                total=total+emptyTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            } else {
                emptyAdapter!!.clearList()
                emptySelectedAll = false
                imageView_empty_select!!.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-emptyTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            }
        }
        if (emptyList.isEmpty()) {
            cl_emptyHead!!.visibility = View.GONE
            imageView_empty_upDown_click!!.visibility = View.INVISIBLE
            imageView_empty_upDown!!.visibility = View.INVISIBLE
            textView_empty_size!!.visibility = View.INVISIBLE
            imageView_empty_select!!.visibility = View.INVISIBLE
            imageView_empty_select_click!!.visibility = View.INVISIBLE
        } else {
            cl_emptyHead!!.visibility = View.VISIBLE
            imageView_empty_upDown_click!!.visibility = View.VISIBLE
            imageView_empty_upDown!!.visibility = View.VISIBLE
            textView_empty_size!!.visibility = View.VISIBLE
            imageView_empty_select!!.visibility = View.VISIBLE
            imageView_empty_select_click!!.visibility = View.VISIBLE
        }
    }

    fun setUninstalledRecyclerView(list: List<FileModel>) {
        val lm3 = LinearLayoutManager(this)
        lm3.orientation = LinearLayoutManager.VERTICAL
        val list1: List<FileModel> = ArrayList(list)
        val list2: List<FileModel> = ArrayList(list)
        uninstalledAdapter =
            JunkAdapter1(this@JunkActivity, list1, list2, "uninstall", uninstalledTotal)
        recyclerView_uninstalled!!.layoutManager = lm3
        recyclerView_uninstalled!!.adapter = uninstalledAdapter
//        uninstalledAdapter!!.setSendData(this)
        uninstalledAdapter!!.setSelectAll(this)
        uninstalledAdapter!!.submitList(list)
        if (!list.isEmpty()) {
            imageView_uninstalled_select!!.setImageResource(R.drawable.ic_test_check)
        }
        uninstalledTotal = uninstalledAdapter!!.allTotal
//        textView_uninstalled_size!!.setText(
//            Formatter.formatFileSize(
//                this@JunkActivity,
//                uninstalledTotal.toLong()
//            )
//        )
//        textView_uninstalled_size!!.setText("${String.format(Locale.ENGLISH,"%.2f", uninstalledTotal)} ${getString(R.string.mb)}")

        val size = Utils.getDataSizeWithPrefix(applicationContext, uninstalledTotal)
        textView_uninstalled_size!!.setText("${size.first} ${size.second}")
        imageView_uninstalled_select_click!!.setOnClickListener { v: View? ->
            if (!uninstalledSelectedAll) {
                imageView_uninstalled_select!!.setImageResource(R.drawable.ic_test_check)
                uninstalledAdapter!!.selectAll()
                uninstalledSelectedAll = true
//                total=total+uninstalledTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            } else {
                uninstalledAdapter!!.clearList()
                uninstalledSelectedAll = false
                imageView_uninstalled_select!!.setImageResource(R.drawable.ic_radio_unselect)
//                total=total-uninstalledTotal
                total =
                    apksAdapter!!.allTotal + trashAdapter!!.allTotal + tempAdapter!!.allTotal + uninstalledAdapter!!.allTotal + emptyAdapter!!.allTotal
                val size = Utils.getDataSizeWithPrefix(applicationContext, total)
                textView_junk_size!!.setText(
                    String.format(
                        Locale.ENGLISH,
                        "%.2f",
                        size.first.toFloat()
                    )
                )
                textView_junk_prefix?.setText(size.second)
            }
        }
        if (uninstalledList.isEmpty()) {
            cl_uninstalledHead!!.visibility = View.GONE
            imageView_uninstalled_upDown_click!!.visibility = View.INVISIBLE
            imageView_uninstalled_upDown!!.visibility = View.INVISIBLE
            textView_uninstalled_size!!.visibility = View.INVISIBLE
            imageView_uninstalled_select!!.visibility = View.INVISIBLE
            imageView_uninstalled_select_click!!.visibility = View.INVISIBLE
        } else {
            cl_uninstalledHead!!.visibility = View.VISIBLE
            imageView_uninstalled_upDown_click!!.visibility = View.VISIBLE
            imageView_uninstalled_upDown!!.visibility = View.VISIBLE
            textView_uninstalled_size!!.visibility = View.VISIBLE
            imageView_uninstalled_select!!.visibility = View.VISIBLE
            imageView_uninstalled_select_click!!.visibility = View.VISIBLE
        }
    }

    fun junkCalculating() {
        //pre execute
        scanning = false
        cl_calculating!!.setVisibility(View.INVISIBLE)
        scrollView_junk_calculated!!.setVisibility(View.VISIBLE)
        textView_filePath!!.setVisibility(View.GONE)
//                    if(stopDialog?.isShowing!!) stopDialog?.cancel()

        cl_blur?.visibility = View.GONE
        process_dots?.visibility = View.GONE
//                    buttonScan?.alpha = 1.0f
        txt_scan!!.text = getString(R.string.clean)
        buttonScan?.alpha = 1.0f

        if (stopDialog != null) {
            if (stopDialog?.isShowing!!) stopDialog?.cancel()
        }

        changeLoading(lottie_loading!!, "cleaner_loading.json")
//                    lottie_loading!!.clearAnimation()
//                    lottie_loading!!.setAnimation("cleaner_loading.json")
//                    lottie_loading!!.repeatCount = 99
//                    lottie_loading!!.playAnimation()

        countJunkSize()

        val executor: Executor = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())
        executor.execute {
            handler.post {
//                setApksPathAnimation(apksList, apksList.isEmpty())
                val size = Utils.getDataSizeWithPrefix(
                    applicationContext,
                    apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
                )
                setSizeAnimation(size)
//                setSizeAnimation(0.0f, Utils.getCalculatedDataSizeMB(total).toFloat())
                //setProgressAnimation(0, 100)
            }
        }

        if (total <= 0) scanningFinish(total)
    }

    private fun countJunkSize() {

        var junkTotal: Double = 0.0
        for (apk in apksList) {
            junkTotal += apk.size
        }

        for (temp in tempList) {
            junkTotal += temp.size
        }

        for (trash in trashList) {
            junkTotal += trash.size
        }

        for (empty in emptyList) {
            junkTotal += empty.size
        }


        for (uninstall in uninstalledList) {
            junkTotal += uninstall.size
        }

        val size = Utils.getDataSizeWithPrefix(applicationContext, junkTotal)

        setSizeAnimation(size)

    }

    private fun cleanProgressAnimation(total: Double) {
        scanning = false
        val size = Utils.getDataSizeWithPrefix(applicationContext, this.total)
        setSizeAnimation(size)
        txt_cleaned?.setText("${textView_junk_size!!.text} ${textView_junk_prefix!!.text}")

        MyApplication.isInterstitialShown = true
        if (AdsManager(this@JunkActivity).isNeedToShowAds() && total >= 20) {
            if (!SharedPrefsConstant.getBoolean(
                    this@JunkActivity,
                    SharedPrefsConstant.IS_APP_IN_BACKGROUND,
                    true
                )
            ) {

                AdsConfig.showInterstitialAd(this@JunkActivity,{
                    MyApplication.isInterstitialShown = false
                    scanningFinish()
                })
//                isShowInterstitialAd { isShowFullScreenAd ->
//                    MyApplication.isInterstitialShown = false
//                    scanningFinish()
//                }
            }
        } else {
            scanningFinish()
        }

//        txt_scan!!.setText(getString(R.string.scan))
        changeLoading(lottie_loading!!, "cleaner_done.json")
//                lottie_loading!!.clearAnimation()
//                lottie_loading!!.setAnimation("cleaner_done.json")
//                lottie_loading!!.setRepeatCount(1)
//                lottie_loading!!.playAnimation()
//                showInterstitialActivity(this);
    }

    @SuppressLint("DefaultLocale", "SetTextI18n")
    private fun setBackgroundColorAnimation(from: Int, to: Int) {
        val animator = ValueAnimator.ofInt(from, to)
        animator.duration = 5000
        animator.setEvaluator(ArgbEvaluator())
        animator.addUpdateListener { valueAnimator: ValueAnimator ->
            val value: Int = valueAnimator.getAnimatedValue() as Int
            cl_calculating_super!!.setBackgroundColor(value)
        }
        animator.start()
    }

    @SuppressLint("DefaultLocale", "SetTextI18n")
    private fun setSizeAnimation(size: Pair<String, String>) {

        Handler(Looper.getMainLooper()).post {
            textView_junk_size?.setText(
                String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toDouble()
                )
            )
            textView_junk_prefix?.setText(size.second)

        }
    }

//    @SuppressLint("DefaultLocale")
//    private fun setApksPathAnimation(list: List<FileModel>, empty: Boolean) {
//        Handler(Looper.getMainLooper()).post {
//            Handler(Looper.getMainLooper()).postDelayed(
//                Runnable { apkInterface!!.done(true) },
//                3000
//            )
//        }
//    }

    override fun onBackPressed() {
        if (!scanning) {
//            super.onBackPressed()

            val isRated = ExitSPHelper(this@JunkActivity).isRated()
            if (!isRated) {
                if (SharedPrefsConstant.getInt(
                        this@JunkActivity,
                        ShareConstants.RATE_JUNK_CLEANER
                    ) >= 3 && SharedPrefsConstant.getInt(
                        this@JunkActivity,
                        ShareConstants.RATE_LATTER,
                        1
                    ) == 0
                ) {
                    RatingDialog.smileyRatingDialog(this@JunkActivity)

                } else {
                    startServiceMethod()
                    if (getTempFiles?.status == AsyncTask.Status.RUNNING) {
                        getTempFiles?.cancel(true)
                    }
                    if (getApkFiles?.status == AsyncTask.Status.RUNNING) {
                        getApkFiles?.cancel(true)
                    }
                    if (getTrashFiles?.status == AsyncTask.Status.RUNNING) {
                        getTrashFiles?.cancel(true)
                    }
                    if (getEmptyFiles?.status == AsyncTask.Status.RUNNING) {
                        getEmptyFiles?.cancel(true)
                    }
                    if (getUninstalledFiles?.status == AsyncTask.Status.RUNNING) {
                        getUninstalledFiles?.cancel(true)
                    }
                    scanning = false

                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                        finish()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    } else {
                        super.onBackPressed()
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    }
                }
            } else {
                startServiceMethod()

                if (getTempFiles?.status == AsyncTask.Status.RUNNING) {
                    getTempFiles?.cancel(true)
                }
                if (getApkFiles?.status == AsyncTask.Status.RUNNING) {
                    getApkFiles?.cancel(true)
                }
                if (getTrashFiles?.status == AsyncTask.Status.RUNNING) {
                    getTrashFiles?.cancel(true)
                }
                if (getEmptyFiles?.status == AsyncTask.Status.RUNNING) {
                    getEmptyFiles?.cancel(true)
                }
                if (getUninstalledFiles?.status == AsyncTask.Status.RUNNING) {
                    getUninstalledFiles?.cancel(true)
                }
                scanning = false

                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                } else {
                    super.onBackPressed()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        } else {
            dialogStopScan()
        }
    }

//    override fun data(data: String) {}

    override fun selectAll(isSelectAll: Boolean, type: String) {
        Log.e(mTAG, "selectAll-type:$type")

        if (apksAdapter != null) apkTotal = apksAdapter?.allTotal!!
        if (tempAdapter != null) tempTotal = tempAdapter?.allTotal!!
        if (trashAdapter != null) trashTotal = trashAdapter?.allTotal!!
        if (emptyAdapter != null) emptyTotal = emptyAdapter?.allTotal!!
        if (uninstalledAdapter != null) uninstalledTotal = uninstalledAdapter?.allTotal!!

        if (type.equals("apk", true)) {
            if (isSelectAll) {
                imageView_apks_select!!.setImageResource(R.drawable.ic_test_check)
                apksSelectedAll = true
            } else {
                apksSelectedAll = false
                imageView_apks_select!!.setImageResource(R.drawable.ic_radio_unselect)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = Utils.getDataSizeWithPrefix(applicationContext, total)
            textView_junk_size!!.setText(
                String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                )
            )
            textView_junk_prefix?.setText(size.second)
        } else if (type.equals("temp", true)) {
            if (isSelectAll) {
                imageView_temp_select!!.setImageResource(R.drawable.ic_test_check)
                tempSelectedAll = true
            } else {
                tempSelectedAll = false
                imageView_temp_select!!.setImageResource(R.drawable.ic_radio_unselect)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = Utils.getDataSizeWithPrefix(applicationContext, total)
            textView_junk_size!!.setText(
                String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                )
            )
            textView_junk_prefix?.setText(size.second)
        } else if (type.equals("trash", true)) {
            if (isSelectAll) {
                imageView_trash_select!!.setImageResource(R.drawable.ic_test_check)
                trashSelectedAll = true
            } else {
                trashSelectedAll = false
                imageView_trash_select!!.setImageResource(R.drawable.ic_radio_unselect)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = Utils.getDataSizeWithPrefix(applicationContext, total)
            textView_junk_size!!.setText(
                String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                )
            )
            textView_junk_prefix?.setText(size.second)
        } else if (type.equals("empty", true)) {
            if (isSelectAll) {
                imageView_empty_select!!.setImageResource(R.drawable.ic_test_check)
                emptySelectedAll = true
            } else {
                emptySelectedAll = false
                imageView_empty_select!!.setImageResource(R.drawable.ic_radio_unselect)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = Utils.getDataSizeWithPrefix(applicationContext, total)
            textView_junk_size!!.setText(
                String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                )
            )
            textView_junk_prefix?.setText(size.second)
        } else {
            if (isSelectAll) {
                imageView_uninstalled_select!!.setImageResource(R.drawable.ic_test_check)
                uninstalledSelectedAll = true
            } else {
                uninstalledSelectedAll = false
                imageView_uninstalled_select!!.setImageResource(R.drawable.ic_radio_unselect)
            }
            total = apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal

            val size = Utils.getDataSizeWithPrefix(
                applicationContext,
                apkTotal + tempTotal + trashTotal + emptyTotal + uninstalledTotal
            )
            textView_junk_size!!.setText(
                String.format(
                    Locale.ENGLISH,
                    "%.2f",
                    size.first.toFloat()
                )
            )
            textView_junk_prefix?.setText(size.second)
        }
    }

    fun scanningFinish(total: Double = 1.0) {
        scanning = false
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.MINUTE, 2)
        SharedPrefsConstant.save(
            this@JunkActivity,
            Utils.JUNK_LAST_CLEANED_TIME,
            calendar.timeInMillis
        )
        startServiceMethod()
        if (stopDialog != null) {
            if (stopDialog?.isShowing!!) stopDialog?.cancel()
        }

        if (total <= 0) {
            txt_success?.text = getString(R.string.already_cleaned)
            txt_cleaned?.visibility = View.GONE
        } else {
            txt_cleaned?.setText("${textView_junk_size!!.text} ${textView_junk_prefix!!.text}")
        }
        layout_junk_finished!!.visibility = View.VISIBLE
        cl_calculating_super!!.visibility = View.GONE

        SharedPrefsConstant.save(
            this@JunkActivity,
            ShareConstants.RATE_JUNK_CLEANER,
            SharedPrefsConstant.getInt(this@JunkActivity, ShareConstants.RATE_JUNK_CLEANER) + 1
        )
    }
}