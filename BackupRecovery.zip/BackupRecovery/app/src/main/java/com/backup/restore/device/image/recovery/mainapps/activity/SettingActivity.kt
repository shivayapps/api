package com.backup.restore.device.image.recovery.mainapps.activity

import android.Manifest
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.EnvironmentCompat
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.inapp.InAppActivity
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.FeedbackActivity
import com.backup.restore.device.image.recovery.databinding.ActivitySettingBinding
import com.backup.restore.device.image.recovery.filepicker.model.DialogConfigs
import com.backup.restore.device.image.recovery.filepicker.model.DialogProperties
import com.backup.restore.device.image.recovery.filepicker.view.FilePickerDialog
import com.backup.restore.device.image.recovery.main.HowToUseActivity
import com.backup.restore.device.image.recovery.mainapps.fragment.*
import com.backup.restore.device.image.recovery.mainapps.model.ExternalStorage
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.getShareMessage
import com.backup.restore.device.image.recovery.utilities.shareApp
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
//import kotlinx.android.synthetic.main.activity_setting.*
import java.io.File
import java.io.InputStream
import java.util.*


class SettingActivity : MyCommonBaseActivity() {

    lateinit var binding:ActivitySettingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_setting)
        binding=ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(SettingActivity::class.simpleName!!)

    }

    override fun getContext(): AppCompatActivity {
        return this@SettingActivity
    }

    override fun initData() {
//        sw_duplicate_selection.isChecked = SharedPrefsConstant.getBoolean(mContext, "duplicateSelection", true)
        binding.swRecoverNotification.isChecked = SharedPrefsConstant.getBoolean(mContext, "NotificationForDelete", true)

        if (AdsManager(mContext).isNeedToShowAds()) {
            if (NetworkManager.isInternetConnected(mContext)) {
//                NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
//                    NativeAdsSize.Medium,
//                    findViewById(R.id.ad_view_container)
//                )
//                GiftIconHelper.loadGiftAd(
//                    fContext = mContext,
//                    fivGiftIcon = findViewById(R.id.main_la_gift),
//                    fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//                )
            }
        } else {
            binding.llSubscribeApp.visibility = View.GONE
        }
    }

    override fun initActions() {

        val scanType = SharedPrefsConstant.getInt(this, "scanTypeLabel", R.string.internal)
        val language = SharedPrefsConstant.getString(this, ShareConstants.SELECTED_LANGUAGE_LABLE, "English")

        binding.tvValLanguage.text = language

        val scanTypeRb = SharedPrefsConstant.getString(this, "scanType", "internal")

        Log.e("scanTypeRb", "initActions: $scanTypeRb")

//        if (scanTypeRb.equals("custom", true)) {
//            val pathToScan = SharedPrefsConstant.getString(mContext, "scanLocation", "internal")
//            tv_valScanType.text = File(pathToScan).name
//        } else tv_valScanType.text = getString(scanType)


        binding.ivBack.setOnClickListener(this)
        binding.llShareApp.setOnClickListener(this)
//        ll_duplicate_scan_type.setOnClickListener(this)
        binding.llIgnoreList.setOnClickListener(this)
        binding.llWhatSave.setOnClickListener(this)
//        ll_auto_clean.setOnClickListener(this)
        binding.llChangeLanguage.setOnClickListener(this)
        binding.llHowTo.setOnClickListener(this)
//        ll_feedback.setOnClickListener(this)
//        ll_subscribe_app.setOnClickListener(this)
//        ll_intro_app.setOnClickListener(this)

        binding.llRecoverNotification.setOnClickListener {
            if (SharedPrefsConstant.getBoolean(mContext, "NotificationForDelete", true)) {
                binding.swRecoverNotification.isChecked = false
                SharedPrefsConstant.savePref(mContext, "NotificationForDelete", false)
            } else {
                binding.swRecoverNotification.isChecked = true
                SharedPrefsConstant.savePref(mContext, "NotificationForDelete", true)
            }
        }
//        ll_duplicate_selection.setOnClickListener {
//            if (SharedPrefsConstant.getBoolean(mContext, "duplicateSelection", true)) {
//                sw_duplicate_selection.isChecked = false
//                SharedPrefsConstant.savePref(mContext, "duplicateSelection", false)
//            } else {
//                sw_duplicate_selection.isChecked = true
//                SharedPrefsConstant.savePref(mContext, "duplicateSelection", true)
//            }
//        }

        binding.txtSetting1.isSelected = true
//        txt_setting_2.isSelected = true
//        txt_setting_3.isSelected = true
        binding.txtSetting4.isSelected = true
//        txt_setting_5.isSelected = true
        binding.txtSetting4.isSelected = true
//        txt_setting_7.isSelected = true
        binding.txtSetting8.isSelected = true
        binding.txtSetting9.isSelected = true
//        txt_setting_10.isSelected = true
//        txt_setting_11.isSelected = true
        binding.txtSetting12.isSelected = true
        binding.txtSetting13.isSelected = true
        binding.tvValLanguage.isSelected = true
//        tv_valScanType.isSelected = true
//        tv_valAutoTrash.isSelected = true

    }

    override fun onBackPressed() {
        super.onBackPressed()
        setResult(RESULT_OK)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

//        startActivity(NewHomeActivity.newIntent(mContext))
//        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//        this@SettingActivity.finish()

//        if(SharedPrefsConstant.getBoolean(mContext,"isLocaleChanged",false)) {
//            SharedPrefsConstant.savePref(mContext, "isLocaleChanged", false)
//            startActivity(NewHomeActivity.newIntent(this))
//            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            finish()
//        } else {
//            super.onBackPressed()
//            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//        }
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()


        when (view.id) {
            R.id.iv_back -> {
                onBackPressed()
            }
            R.id.ll_change_language -> {
                val intent = Intent(mContext, LanguageActivity::class.java)
                startActivity(intent)
//                startActivityForResult(intent, 229)
            }
            R.id.ll_subscribe_app -> {
                startActivity(Intent(mContext, InAppActivity::class.java))
            }
//            R.id.ll_duplicate_scan_type -> {
//                dialogScanLocation()
//            }
            R.id.ll_ignore_list -> {
                startActivity(Intent(mContext, IgnoreListActivity::class.java))
            }
            R.id.ll_what_save -> {
                startActivity(Intent(mContext, TrashSaveActivity::class.java))
            }
//            R.id.ll_auto_clean -> {
//                dialogSelectFrequency()
//            }
//            R.id.ll_feedback -> {
//                startActivity(Intent(mContext, FeedbackActivity::class.java))
//            }
            R.id.ll_share_app -> {
                shareApp()
            }
            R.id.ll_how_to -> {
                val i = Intent(mContext, HowToUseActivity::class.java)
                i.putExtra("lIsFromActivity", "NewHomeActivity")
                startActivity(i)
            }

        }
    }


    private fun dialogSelectFrequency() {
        addEvent("AutoCleanFrequency")
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_autotrash_frequency)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val rb_Off = dialog.findViewById<RadioButton>(R.id.rb_Off)
        val rb_1week = dialog.findViewById<RadioButton>(R.id.rb_1week)
        val rb_1month = dialog.findViewById<RadioButton>(R.id.rb_1month)
        val rb_3month = dialog.findViewById<RadioButton>(R.id.rb_3month)
        var selectedRb = "off"
        var selectedRbLable = R.string.off

        val interval = SharedPrefsConstant.getString(this, "cleanTrashInterval", "off")
        if (interval == "off") {
            selectedRb = "off"
            selectedRbLable = R.string.off
            rb_Off.isChecked = true
            rb_1week.isChecked = false
            rb_1month.isChecked = false
            rb_3month.isChecked = false
        } else if (interval == "1week") {
            selectedRb = "1week"
            selectedRbLable = R.string._1_week
            rb_Off.isChecked = false
            rb_1week.isChecked = true
            rb_1month.isChecked = false
            rb_3month.isChecked = false
        } else if (interval == "1month") {
            selectedRb = "1month"
            selectedRbLable = R.string._1_month
            rb_Off.isChecked = false
            rb_1week.isChecked = false
            rb_1month.isChecked = true
            rb_3month.isChecked = false
        } else if (interval == "3month") {
            selectedRb = "3month"
            selectedRbLable = R.string._3_month
            rb_Off.isChecked = false
            rb_1week.isChecked = false
            rb_1month.isChecked = false
            rb_3month.isChecked = true
        }

        rb_Off.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "off"
                selectedRbLable = R.string.off
                //rb_Off.isChecked=false
                rb_1week.isChecked = false
                rb_1month.isChecked = false
                rb_3month.isChecked = false
            }
        }
        rb_1week.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "1week"
                selectedRbLable = R.string._1_week
                rb_Off.isChecked = false
                //rb_1week.isChecked=false
                rb_1month.isChecked = false
                rb_3month.isChecked = false
            }
        }
        rb_1month.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "1month"
                selectedRbLable = R.string._1_month
                rb_Off.isChecked = false
                rb_1week.isChecked = false
                //rb_1month.isChecked=false
                rb_3month.isChecked = false
            }
        }
        rb_3month.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                selectedRb = "3month"
                selectedRbLable = R.string._3_month
                rb_Off.isChecked = false
                rb_1week.isChecked = false
                rb_1month.isChecked = false
                //rb_3month.isChecked=false
            }
        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {

//            tv_valAutoTrash.text = getString(selectedRbLable)
            SharedPrefsConstant.save(this, "cleanTrashInterval", selectedRb)
            SharedPrefsConstant.save(this, "cleanTrashIntervalLabel", selectedRbLable)
            dialog.dismiss()

        }
        dialog.show()
    }


//    private fun checkPermissions(permissions: Array<String>) {
//
//        MyApplication.isInternalCall = true
//
//        Dexter.withContext(mContext)
//            .withPermissions(*permissions)
//            .withListener(object : MultiplePermissionsListener {
//                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
//
//                    when {
//                        report.areAllPermissionsGranted() -> {
//                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                                checkAllFilePermission()
//                            } else {
//                                dialogSelectLocation()
//                            }
//                        }
//                        report.isAnyPermissionPermanentlyDenied -> {
//                            showSettingsDialog()
//                        }
//                        else -> {
//                            Toast.makeText(
//                                mContext,
//                                getString(R.string.permission_required),
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                    }
//                }
//
//                override fun onPermissionRationaleShouldBeShown(
//                    permissions: List<PermissionRequest>,
//                    token: PermissionToken
//                ) {
//                    token.continuePermissionRequest()
//                }
//            }).check()
//
//
//    }

//    private fun checkPermissionsold(permissions: Array<String>) {
//
//        MyApplication.isInternalCall = true
//
//        Dexter.withContext(mContext)
//            .withPermissions(*permissions)
//            .withListener(object : MultiplePermissionsListener {
//                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
//
//                    when {
//                        report.areAllPermissionsGranted() -> {
//                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                                checkAllFilePermission()
//                            } else {
//                                dialogSelectLocation()
//                            }
//                        }
//                        report.isAnyPermissionPermanentlyDenied -> {
//                            showSettingsDialog()
//                        }
//                        else -> {
//                            Toast.makeText(
//                                mContext,
//                                getString(R.string.permission_required),
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                    }
//                }
//
//                override fun onPermissionRationaleShouldBeShown(
//                    permissions: List<PermissionRequest>,
//                    token: PermissionToken
//                ) {
//                    token.continuePermissionRequest()
//                }
//            }).check()
//
//
//    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        startActivity(intent)
//        dialogSelectLocation()
    }

//    fun checkAllFilePermission() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            if (Environment.isExternalStorageManager()) {
//                dialogSelectLocation()
//            } else {
//                val intent = Intent(
//                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
//                    Uri.parse(String.format("package:%s", packageName))
//                )
//                try {
//                    MyApplication.isInternalCall = true
//                    startActivityForResult(intent, 2296)
//                } catch (e: ActivityNotFoundException) {
//                }
//            }
//        }
//    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("onActivityResult", "requestCode:" + requestCode)
        Log.e("onActivityResult", "resultCode:" + resultCode)
        if (requestCode == 4010) {
            val uri: Uri? = data?.data
            grantUriPermission(
                packageName,
                uri,
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            val takeFlags = data?.flags?.and(
                (Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                takeFlags?.let { contentResolver.takePersistableUriPermission(uri!!, it) }
            }
        }
//        else if (requestCode == 2296) {
//
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                if (Environment.isExternalStorageManager()) {
//                    dialogSelectLocation()
//                    Log.e("onActivityResult", "onActivityResult: Service Start ")
//                } else {
//                    Toast.makeText(
//                        mContext,
//                        getString(R.string.permission_required),
//                        Toast.LENGTH_SHORT
//                    ).show()
//                }
//            }
//        }
        else if (requestCode == 229) {
//            changeLanguageNew()
            Log.e(
                "onActivityResult",
                "SELECTED_LANGUAGE:" + SharedPrefsConstant.getString(
                    this,
                    ShareConstants.SELECTED_LANGUAGE,
                    "en"
                )
            )
            var localKey="en"

            if(data!!.hasExtra("key")) {
                localKey = data.getStringExtra("key").toString()
            }

            Log.e(
                "onActivityResult",
                "SELECTED_LANGUAGE_Intent:" + localKey
            )

//            val locale = Locale(SharedPrefsConstant.getString(this, ShareConstants.SELECTED_LANGUAGE, "en")!!)
            val locale = Locale(localKey)
            val config = this.resources.configuration
            config.locale = locale
            config.setLocale(locale)
            Locale.setDefault(locale)
            this.resources.updateConfiguration(config, this.resources.displayMetrics)

            Log.e(
                "onActivityResult",
                "SELECTED_LANGUAGE_locale:" + locale.language
            )

            runOnUiThread {
                recreate()
            }

            binding.llContent.invalidate()
            binding.llContent.requestLayout()


            binding.txtSetting1.text = getLocaleStringResource(mContext,locale,R.string.change_language)
//            txt_setting_2.text = getLocaleStringResource(mContext,locale,R.string.duplicate_item_auto_selection)
//            txt_setting_3.text = getLocaleStringResource(mContext,locale,R.string.duplicate_scan_type)
            binding.txtSetting4.text = getLocaleStringResource(mContext,locale,R.string.recover_notification)
//            txt_setting_5.text = getLocaleStringResource(mContext,locale,R.string.auto_clean_trash_option)
            binding.txtSetting6.text = getLocaleStringResource(mContext,locale,R.string.add_widget)
//            txt_setting_7.text = getLocaleStringResource(mContext,locale,R.string.more_app)
            binding.txtSetting8.text = getLocaleStringResource(mContext,locale,R.string.share_app)
            binding.txtSetting9.text = getLocaleStringResource(mContext,locale,R.string.subscription)
//            txt_setting_10.text = getLocaleStringResource(mContext,locale,R.string.how_to_use)
//            txt_setting_11.text = getLocaleStringResource(mContext,locale,R.string.feedback)
            binding.txtSetting12.text = getLocaleStringResource(mContext,locale,R.string.what_do_you_want_to_save)
            binding.txtSetting13.text = getLocaleStringResource(mContext,locale,R.string.duplicate_ignore_folder_list)

//            tv_valLanguage.text = getString(R.string.change_language)
//            tv_valScanType.text = getString(R.string.change_language)
//            tv_valAutoTrash.text = getString(R.string.change_language)

            binding.txtSetting1.invalidate()
            binding.txtSetting1.requestLayout()

//            txt_setting_2.invalidate()
//            txt_setting_2.requestLayout()

//            txt_setting_3.invalidate()
//            txt_setting_3.requestLayout()

            binding.txtSetting4.invalidate()
            binding.txtSetting4.requestLayout()

//            txt_setting_5.invalidate()
//            txt_setting_5.requestLayout()

            binding.txtSetting6.invalidate()
            binding.txtSetting6.requestLayout()

//            txt_setting_7.invalidate()
//            txt_setting_7.requestLayout()

            binding.txtSetting8.invalidate()
            binding.txtSetting8.requestLayout()

            binding.txtSetting9.invalidate()
            binding.txtSetting9.requestLayout()

//            txt_setting_10.invalidate()
//            txt_setting_10.requestLayout()

//            txt_setting_11.invalidate()
//            txt_setting_11.requestLayout()

            binding.txtSetting12.invalidate()
            binding.txtSetting12.requestLayout()

            binding.txtSetting13.invalidate()
            binding.txtSetting13.requestLayout()

            setContentView(R.layout.activity_setting)
//        lateinit var binding:ActivityBinding
//        binding=ActivityBinding.inflate(layoutInflater)
//        setContentView(binding.root)

            Log.e(
                "onActivityResult",
                "SELECTED_LANGUAGE_recreate:" + Locale.getDefault().language
            )

        }
    }

    fun getLocaleStringResource(
        context: Context,
        requestedLocale: Locale,
        resourceId: Int
    ): String? {
        val result: String
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) { // use latest api
            val config = Configuration(context.resources.configuration)
            config.setLocale(requestedLocale)
            result = context.createConfigurationContext(config).getText(resourceId).toString()
        } else { // support older android versions
            val resources: Resources = context.resources
            val conf: Configuration = resources.getConfiguration()
            val savedLocale: Locale = conf.locale
            conf.locale = requestedLocale
            resources.updateConfiguration(conf, null)

            // retrieve resources from desired locale
            result = resources.getString(resourceId)

            // restore original locale
            conf.locale = savedLocale
            resources.updateConfiguration(conf, null)
        }
        return result
    }

    private fun takeCardUriPermission(sdCardRootPath: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val sdCard = File(sdCardRootPath)
            val storageManager: StorageManager =
                getSystemService(Context.STORAGE_SERVICE) as StorageManager
            val storageVolume: StorageVolume? = storageManager.getStorageVolume(sdCard)
            val intent: Intent? = storageVolume?.createAccessIntent(null)
            try {
                startActivityForResult(intent, 4010)
            } catch (e: ActivityNotFoundException) {
            }
        }
    }

    private fun getExternalStorageDirectories(): Array<String?> {
        val results: MutableList<String> = ArrayList()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //Method 1 for KitKat & above
            val externalDirs = getExternalFilesDirs(null)
            val internalRoot = Environment.getExternalStorageDirectory().absolutePath.toLowerCase()
            for (file in externalDirs) {
                if (file == null) //solved NPE on some Lollipop devices
                    continue
                val path = file.path.split("/Android".toRegex()).toTypedArray()[0]
                if (path.toLowerCase().startsWith(internalRoot)) continue
                var addPath = false
                addPath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    Environment.isExternalStorageRemovable(file)
                } else {
                    Environment.MEDIA_MOUNTED == EnvironmentCompat.getStorageState(file)
                }
                if (addPath) {
                    results.add(path)
                }
            }
        }
        if (results.isEmpty()) {
            //Method 2 for all versions
            // better variation of: http://stackoverflow.com/a/40123073/5002496
            var output = ""
            try {
                val process = ProcessBuilder().command("mount | grep /dev/block/vold")
                    .redirectErrorStream(true).start()
                process.waitFor()
                val `is`: InputStream = process.inputStream
                val buffer = ByteArray(1024)
                while (`is`.read(buffer) !== -1) {
                    output = output + String(buffer)
                }
                `is`.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (output.trim { it <= ' ' }.isNotEmpty()) {
                val devicePoints = output.split("\n".toRegex()).toTypedArray()
                for (voldPoint in devicePoints) {
                    results.add(voldPoint.split(" ".toRegex()).toTypedArray()[2])
                }
            }
        }

        //Below few lines is to remove paths which may not be external memory card, like OTG (feel free to comment them out)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var i = 0
            while (i < results.size) {
                if (!results[i].toLowerCase().matches(".*[0-9a-f]{4}[-][0-9a-f]{4}".toRegex())) {
//                    Log.d(ImageViewTouchBase.LOG_TAG, results[i] + " might not be extSDcard")
                    results.removeAt(i--)
                }
                i++
            }
        } else {
            var i = 0
            while (i < results.size) {
                if (!results[i].toLowerCase().contains("ext") && !results[i].toLowerCase()
                        .contains("sdcard")
                ) {
//                    Log.d(ImageViewTouchBase.LOG_TAG, results[i] + " might not be extSDcard")
                    results.removeAt(i--)
                }
                i++
            }
        }
        val storageDirectories = arrayOfNulls<String>(results.size)
        for (i in results.indices) storageDirectories[i] = results[i]
        return storageDirectories
    }

//    private fun dialogScanLocation() {
//        addEvent("ScanType")
//        val dialog = Dialog(mContext)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_scan_type)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        val rbInternal = dialog.findViewById<RadioButton>(R.id.rb_internal)
//        val rbExternal = dialog.findViewById<RadioButton>(R.id.rb_external)
//        val rbCustom = dialog.findViewById<RadioButton>(R.id.rb_custom)
////        var selectedRb = "internal"
//
//        val externalLocations = ExternalStorage.getAllStorageLocations()
////        val sdCard = externalLocations[ExternalStorage.SD_CARD]?.absolutePath
//        val sdCard = Environment.getExternalStorageDirectory().toString()
////        var externalSdCard = externalLocations[ExternalStorage.EXTERNAL_SD_CARD]
//        var externalSdCard = ""
//
//        val storagePath = getExternalStorageDirectories()
//        for (str in storagePath) {
//            externalSdCard = str!!
//            Log.e("ScanLocation", "dialogScanLocation:str: " + str)
//        }
//
//        if (Utils.getExternalMounts().size > 0) {
//            rbExternal.visibility = View.VISIBLE
//        } else {
//            rbExternal.visibility = View.GONE
//        }
//
//        val scanType = SharedPrefsConstant.getInt(this, "scanTypeLabel", R.string.internal)
//        var selectedRb = SharedPrefsConstant.getString(this, "scanType", "internal")
//        Log.e("scanTypeRb", "dialogScan: $selectedRb")
//
//        if (selectedRb.equals("internal", true)) {
//            selectedRb = "internal"
//            rbInternal.isChecked = true
//            rbExternal.isChecked = false
//            rbCustom.isChecked = false
//        } else if (selectedRb.equals("external", true)) {
//            selectedRb = "external"
//            rbInternal.isChecked = false
//            rbExternal.isChecked = true
//            rbCustom.isChecked = false
//        } else if (selectedRb.equals("custom", true)) {
//            selectedRb = "custom"
//            rbInternal.isChecked = false
//            rbExternal.isChecked = false
//            rbCustom.isChecked = true
//        }
//
//        rbInternal.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) {
//                selectedRb = "internal"
//                //rb_internal.isChecked=false
//                rbExternal.isChecked = false
//                rbCustom.isChecked = false
//            }
//        }
//        rbExternal.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) {
//                selectedRb = "external"
//                rbInternal.isChecked = false
//                //rb_external.isChecked=false
//                rbCustom.isChecked = false
//            }
//        }
//        rbCustom.setOnCheckedChangeListener { buttonView, isChecked ->
//            if (isChecked) {
//                //selectedRb="custom"
//                rbInternal.isChecked = false
//                rbExternal.isChecked = false
//                //rb_custom.isChecked=false
//            }
//        }
//
//        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
//            dialog.dismiss()
//        }
//        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
//
//            if (rbInternal.isChecked) {
////                dialogSelectLocation()
////                val path = externalLocations[ExternalStorage.SD_CARD]
////                selectedRb=sdCard!!
//                tv_valScanType.text = getString(R.string.internal)
//                SharedPrefsConstant.save(this, "scanTypeLabel", R.string.internal)
//                SharedPrefsConstant.save(this, "scanLocation", sdCard)
//                SharedPrefsConstant.save(this, "scanType", selectedRb)
//            } else if (rbExternal.isChecked) {
////                dialogSelectLocation()
////                val path = externalLocations[ExternalStorage.EXTERNAL_SD_CARD]
////                selectedRb=path!!.absolutePath
////                SharedPrefsConstant.save(this, "scanLocation", selectedRb)
////                takeCardUriPermission(externalSdCard)
////                selectedRb=externalSdCard
//                tv_valScanType.text = getString(R.string.external)
//                SharedPrefsConstant.save(this, "scanTypeLabel", R.string.external)
//                SharedPrefsConstant.save(this, "scanLocation", externalSdCard)
//                SharedPrefsConstant.save(this, "scanType", selectedRb)
//            } else if (rbCustom.isChecked) {
//
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                    checkAllFilePermission()
//                } else {
//                    checkPermissions(arrayOf(
//                        Manifest.permission.READ_EXTERNAL_STORAGE,
//                        Manifest.permission.WRITE_EXTERNAL_STORAGE
//                    ))
//                }
//
//            }
//            dialog.dismiss()
//
//        }
//        dialog.show()
//    }

//    private fun dialogSelectLocation() {
//
//        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
//        val dialogProperties = DialogProperties()
//        dialogProperties.selection_type = DialogConfigs.DIR_SELECT
//        dialogProperties.selection_mode = DialogConfigs.SINGLE_MODE
//        dialogProperties.show_hidden_files = true
//        dialogProperties.root = File(DialogConfigs.DEFAULT_DIR)
//        dialogProperties.offset = File(DialogConfigs.DEFAULT_DIR)
//        dialogProperties.root = File(ShareConstants.mRootPath)
//
//        val pickerDialog = FilePickerDialog(this@SettingActivity, dialogProperties)
//        pickerDialog.setTitle(getString(R.string.select_a_file))
//        pickerDialog.setPositiveBtnName(getString(R.string.filechooser_ok))
//
//        //Method handle selected files.
//        pickerDialog.setDialogSelectionListener { files ->
//            //files is the array of paths selected by the App User.
//            if (!files.isEmpty()) {
//                for (path in files) {
//                    val file = File(path)
////                val pathToScan = SharedPrefsConstant.getString(mContext, "scanLocation", "internal")
////                tv_valScanType.text=File(pathToScan).name
//
//                    Log.e("ScanLocation", "dialogScanLocation:custom: " + file.absolutePath)
//                    SharedPrefsConstant.save(this, "scanType", "custom")
//                    SharedPrefsConstant.save(this, "scanTypeLabel", R.string.custom)
//                    SharedPrefsConstant.save(this@SettingActivity, "scanLocation", file.path)
//                    tv_valScanType.text = file.name
//                }
//            }
//
//        }
//        pickerDialog.properties = dialogProperties
//
//        pickerDialog.show()
//    }



    override fun onResume() {
        super.onResume()
        Log.e("UtilsKT", "onResume:SettingActivity")
//        changeLanguage()

        if (!AdsManager(mContext).isNeedToShowAds()) {
            binding.llSubscribeApp.visibility = View.GONE
        }
    }
}