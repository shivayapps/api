package com.backup.restore.device.image.recovery.database;
//
//import androidx.room.PrimaryKey;
//
//import io.realm.RealmObject;
//
//public class SaveDeletedImageModel extends RealmObject {
//
//    @PrimaryKey
//    private int id;
//
//    private String Path;
//
//    private String PathValue;
//
//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String getPath() {
//        return Path;
//    }
//
//    public void setPath(String path) {
//        Path = path;
//    }
//
//    public String getPathValue() {
//        return PathValue;
//    }
//
//    public void setPathValue(String pathValue) {
//        PathValue = pathValue;
//    }
//
//}
