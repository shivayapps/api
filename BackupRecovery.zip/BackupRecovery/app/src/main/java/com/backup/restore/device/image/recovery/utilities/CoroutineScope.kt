package com.backup.restore.device.image.recovery.utilities;

import kotlinx.coroutines.*

val job = SupervisorJob()
val backgroundscope = CoroutineScope(Dispatchers.Default + job)
val ioscope = CoroutineScope(Dispatchers.IO + job)
val mainscope = CoroutineScope(Dispatchers.Main + job)

fun cancelAllWork() {
    backgroundscope.coroutineContext.cancelChildren()
    ioscope.coroutineContext.cancelChildren()
    mainscope.coroutineContext.cancelChildren()
}

fun doBackgroundTask(backGroundTask : () -> Any, foregroundTask : (Any) -> Unit){
    backgroundscope.launch {
        val returns = backGroundTask()
        mainscope.launch {
            foregroundTask(returns)
        }
    }
}
