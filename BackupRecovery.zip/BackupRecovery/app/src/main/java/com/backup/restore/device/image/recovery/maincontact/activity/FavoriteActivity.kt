package com.backup.restore.device.image.recovery.maincontact.activity

import android.app.Dialog
import android.content.*
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.maincontact.adapter.FavoriteAdapter
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
//import com.example.app.ads.helper.GiftIconHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityFavoriteBinding
import java.util.*

@Suppress("DEPRECATION")
class FavoriteActivity : MyCommonBaseActivity() {
    var mTAG : String = javaClass.simpleName

    private var mDbAdapter: DBAdapter? = null
    private var mFavCursor: Cursor? = null
    var mFavAsyncTask: AsyncTask<*, *, *>? = null
    private var favorite = false
    var mIntentFilter: IntentFilter? = null
    var favoriteAdapter :FavoriteAdapter? =null
    companion object {
        var FavContactList = ArrayList<ContactModel>()
        var favActivity: FavoriteActivity? = null
        var isShowDialogFav = false
    }

    lateinit var binding:ActivityFavoriteBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_favorite)
        binding= ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun getContext(): AppCompatActivity {
        return this@FavoriteActivity
    }

    override fun initData() {
        mIntentFilter = IntentFilter("FavoriteActivityCheck")
        favActivity = this@FavoriteActivity
        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            GiftIconHelper.loadGiftAd(
//                fContext = mContext,
//                fivGiftIcon = findViewById(R.id.main_la_gift),
//                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//            )
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()
//            binding.llGift.visibility = View.VISIBLE
        }else{
            binding.adview.visibility = View.GONE
//            binding.llGift.visibility = View.INVISIBLE
        }

        binding.rvContact!!.layoutManager = LinearLayoutManager(mContext)
        mDbAdapter = DBAdapter(mContext)

        mFavAsyncTask = FavAsyncTask().execute()

    }

    override fun initActions() {
        binding.ivBack!!.setOnClickListener(this)
        binding.etSearchApk.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (binding.etSearchApk.text.toString().isEmpty()) {
                    binding.etSearchApk.clearFocus()
                    MyUtils.hideKeyboard(applicationContext, binding.etSearchApk)
                } else {
                    binding.etSearchApk.requestFocus()
                }
            }

            override fun afterTextChanged(s: Editable) {
                searchContact(s.toString())
            }
        })

    }

    private val favContactReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            mFavAsyncTask = FavAsyncTask().execute()
        }
    }

    override fun onClick(view: View) {
        if (view == binding.ivBack) {
            if (FavContactList.size != 0) binding.rvContact!!.stopScroll()
            onBackPressed()
            FavContactList.clear()
        }
    }

    private inner class FavAsyncTask : AsyncTask<Void?, Void?, Void?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            dialog.findViewById<TextView>(R.id.permission).text =  getString(R.string.loading_)
            dialog.findViewById<TextView>(R.id.permission_text).visibility = View.GONE
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
                mFavAsyncTask!!.cancel(true)
            }


            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }
            if (!dialog.isShowing && !isShowDialogFav) {
                dialog.show()
                MyApplication.isDialogOpen = true
                Log.e(mTAG,"ContactDetailsActivity onPreExecute: show"  )
            }
            binding.tvEmpty!!.visibility = View.GONE
            binding.frag.visibility = View.GONE
            binding.rvContact!!.visibility = View.GONE

        }

        override fun doInBackground(vararg voids: Void?): Void? {
            FavContactList.clear()
            mFavCursor = mDbAdapter?.favData
            var bitmap: Bitmap?
            if (mFavCursor?.count != 0) {
                if (mFavCursor?.moveToFirst()!!) {
                    do {
                        if (mFavCursor?.getString(mFavCursor?.getColumnIndex(DBAdapter.KEY_ID)!!) != null) {
                            val contactId = mFavCursor?.getString(mFavCursor!!.getColumnIndex(DBAdapter.KEY_ID))
                            Log.e(mTAG, "contact_id =>$contactId")
                            val photoUri = getPhotoUri(contactId.toString())
                            val contactModel = ContactModel()
                            try {
                                if (photoUri != null) {
//                                    bitmap=  MediaStore.Images.Media.getBitmap(contentResolver, Uri.parse(photoUri.toString()))
                                    contactModel.mContactImageUri = photoUri.toString()
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            contactModel.mContactName = mFavCursor?.getString(mFavCursor!!.getColumnIndex(DBAdapter.KEY_NAME))
                            contactModel.mNumber = mFavCursor?.getString(mFavCursor!!.getColumnIndex(DBAdapter.KEY_NUMBER))
                            contactModel.mContactId = mFavCursor?.getString(mFavCursor!!.getColumnIndex(DBAdapter.KEY_ID))
                            val cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(contactId), null)
                            if (cursor != null) {
                                if (cursor.count != 0)  FavContactList.add(contactModel)
                            }
                        } else {
                            Log.e(mTAG, "Delete ===>")
                            mDbAdapter!!.deleteFavContactDetails(mFavCursor?.getString(mFavCursor?.getColumnIndex(DBAdapter.KEY_ID)!!))
                        }
                        if (mFavAsyncTask!!.isCancelled) {
                            runOnUiThread {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false
                                finish()
                                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                            }
                            break
                        }
                    } while (mFavCursor!!.moveToNext())
                }
            } else {
                favorite = true
            }
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            dialog.cancel()
            MyApplication.isDialogOpen = false
            if (favorite) {
                favorite = false
                binding.rvContact!!.visibility = View.GONE
                binding.tvEmpty!!.visibility = View.VISIBLE
                binding.frag.visibility = View.GONE
            } else {
                if (FavContactList.size != 0) {
                    reverse(FavContactList)
                    favoriteAdapter = FavoriteAdapter(mContext, FavContactList)
                    binding.rvContact!!.adapter = favoriteAdapter
                    binding.rvContact!!.visibility = View.VISIBLE
                    binding.tvEmpty!!.visibility = View.GONE
                    binding.frag.visibility = View.VISIBLE
                } else {
                    binding.rvContact!!.visibility = View.GONE
                    binding.tvEmpty!!.visibility = View.VISIBLE
                    binding.frag.visibility = View.GONE
                }
            }
        }
    }

    fun reverse(list: ArrayList<ContactModel>): ArrayList<ContactModel> {
        var i = 0
        val j = list.size - 1
        while (i < j) {
            list.add(i, list.removeAt(j))
            i++
        }
        return list
    }

    fun getContactIDFromNumber(contactNumber: String?, context: Context): Int {
        var contactNumber = contactNumber
        contactNumber = Uri.encode(contactNumber)
        var phoneContactID = Random().nextInt()
        val contactLookupCursor = context.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, contactNumber),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID), null, null, null
        )
        while (contactLookupCursor!!.moveToNext()) {
            phoneContactID = contactLookupCursor.getInt(contactLookupCursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup._ID))
        }
        contactLookupCursor.close()
        return phoneContactID
    }

    fun getPhotoUri(photo: String?): Uri? {
        try {
            val cur: Cursor = mContext.contentResolver.query(ContactsContract.Data.CONTENT_URI, null, ContactsContract.Data.CONTACT_ID + "=" + photo + " AND " + ContactsContract.Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE + "'", null, null)!!
            if (cur != null) {
                if (!cur.moveToFirst()) {
                    return null // no photo
                }
            } else {
                return null // error in cursor process
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
        val person: Uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, photo!!.toLong())
        return Uri.withAppendedPath(person, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY)
    }



    private fun searchContact(str: String) {
        val toLowerCase: CharSequence = str.toLowerCase(Locale.ROOT)
        val arrayList = ArrayList<ContactModel>()
        for (i in FavContactList.indices) {
            if (FavContactList[i].mContactName!!.toLowerCase(Locale.ROOT).contains(toLowerCase) || FavContactList[i].mNumber!!.toLowerCase(Locale.ROOT).replace("-", "").contains(toLowerCase)) {
                arrayList.add(FavContactList[i])
            }
        }
        if (arrayList.size != 0) {
            binding.rvContact.visibility = View.VISIBLE
            binding.tvEmpty.visibility = View.GONE
        } else {
            binding.rvContact.visibility = View.GONE
            binding.tvEmpty.visibility = View.VISIBLE
        }

        favoriteAdapter = FavoriteAdapter(mContext, FavContactList)
        binding.rvContact.adapter = favoriteAdapter
        favoriteAdapter!!.setList(arrayList)
        favoriteAdapter!!.notifyDataSetChanged()
    }


    override fun onBackPressed() {
        super.onBackPressed()
        binding.etSearchApk.clearFocus()
        MyUtils.hideKeyboard(applicationContext, binding.etSearchApk)
        binding.etSearchApk.setText("")

        if (FavContactList.size != 0) binding.rvContact!!.stopScroll()
        FavContactList.clear()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
        Log.e(mTAG, "onResume: ")
        binding.etSearchApk.setText("")
        registerReceiver(favContactReceiver, mIntentFilter)

        Log.e(mTAG, "onResume: "+ ContactDetailsActivity.isModify )
        if(ContactDetailsActivity.isModify) {
            ContactDetailsActivity.isModify=false
            mFavAsyncTask = FavAsyncTask().execute()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        FavContactList.clear()
        unregisterReceiver(favContactReceiver)
        ShareConstants.fav_activity = false
    }

}