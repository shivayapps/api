package com.backup.restore.device.image.recovery.mainapps.adapter

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainduplicate.model.AppHistory
import java.util.*


class AppHistoryAdapter(
    private val mContext: Context, private val appInfoList: MutableList<AppHistory>, val onAppSelect :OnAppSelect
) : RecyclerView.Adapter<AppHistoryAdapter.ViewHolder>() {

    interface OnAppSelect {
        fun onAppClick(position: Int,appInfo: AppHistory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.raw_list_of_app, parent, false))
    }

    override fun getItemCount(): Int {
        return appInfoList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val appInfo = appInfoList[position]
        holder.tvTitle.text=appInfo.appName

        val size=String.format(Locale.ENGLISH, "%.2f", appInfo.size.toFloat())
        holder.tvDetail.text="$size MB, ${appInfo.date}"

        holder.ivDelete.setOnClickListener {
            onAppSelect.onAppClick(position,appInfo)
        }
        holder.ll_info.setOnClickListener {
            redirectPlaystore(appInfo.packageName)
        }
        holder.ivThumb.setOnClickListener {
            try {
                val marketUri = Uri.parse("market://details?id=${appInfo.packageName}")
                val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
                mContext.startActivity(marketIntent)
            } catch (e: ActivityNotFoundException) {
                val marketUri = Uri.parse("https://play.google.com/store/apps/details?id=${appInfo.packageName}")
                val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
                mContext.startActivity(marketIntent)
            }
        }
        holder.ivOption.visibility=View.GONE
        holder.ivDelete.visibility=View.VISIBLE
    }

    fun redirectPlaystore(packageName:String){

        try {
            val marketUri = Uri.parse("market://details?id=${packageName}")
            val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
            mContext.startActivity(marketIntent)
        } catch (e: ActivityNotFoundException) {
            val marketUri = Uri.parse("https://play.google.com/store/apps/details?id=${packageName}")
            val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
            mContext.startActivity(marketIntent)
        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.txt_name)
        val tvDetail: TextView = itemView.findViewById(R.id.tv_detail)
        val ivThumb: ImageView = itemView.findViewById(R.id.application_icon_image)
        val ivOption: ImageView = itemView.findViewById(R.id.img_arrow)
        val ivDelete: ImageView = itemView.findViewById(R.id.img_delete)
        val ll_info: LinearLayout = itemView.findViewById(R.id.ll_info)
    }

}