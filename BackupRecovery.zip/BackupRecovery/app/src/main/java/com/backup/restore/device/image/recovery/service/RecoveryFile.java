//package com.backup.restore.device.image.recovery.service;
//
//import static android.app.NotificationManager.IMPORTANCE_MIN;
//import static com.backup.restore.device.image.recovery.utilities.common.MyUtils.mHiddenCopyImagePath;
//import static com.backup.restore.device.image.recovery.utilities.common.MyUtils.mNewFilePath;
//
//import android.app.Notification;
//import android.app.NotificationChannel;
//import android.app.NotificationManager;
//import android.app.PendingIntent;
//import android.app.Service;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.Build;
//import android.os.Environment;
//import android.os.FileObserver;
//import android.os.Handler;
//import android.os.IBinder;
//import android.os.Looper;
//import android.service.notification.StatusBarNotification;
//import android.util.Log;
//
//import androidx.annotation.Nullable;
//import androidx.core.app.NotificationCompat;
//import androidx.core.content.ContextCompat;
//
//import com.backup.restore.device.image.recovery.R;
//import com.backup.restore.device.image.recovery.database.DatabaseHelper;
//import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity;
//import com.backup.restore.device.image.recovery.utilities.common.MyUtils;
//
//import org.apache.commons.io.FileUtils;
//import org.apache.commons.io.FilenameUtils;
//
//import java.io.File;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Stack;
//import java.util.concurrent.ConcurrentHashMap;
//
//public class RecoveryFile extends Service {
//
//    public static String TAG = RecoveryFile.class.getSimpleName();
//    public static String CHANNEL_ID = "BackupAndRecoveryForegroundServiceChannel";
//    public static NotificationManager mNotificationManager;
//    private static final ConcurrentHashMap<String, Boolean> mBooleanList = new ConcurrentHashMap<>();
//    String mStringPath;
//    Boolean isSendNotification = false;
//    SharedPreferences sharedPreferences;
//    File lStoreImageFile;
////    public static int Count;
////    long SpaceAvailable;
//    DatabaseHelper mDatabaseHelper ;
//
//    @Nullable
//    @Override
//    public IBinder onBind(Intent intent) {
//        return null;
//    }
//
//    @Override
//    public void onCreate() {
//        super.onCreate();
//
////        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
////            SpaceAvailable = getAvailableInternalMemorySizeInLong();
////        } else {
////            SpaceAvailable = getAvailableROMSize();
////        }
//
////        Log.e(TAG, "onCreate: MainSpace " + getReadableFileSize(SpaceAvailable));
////        SpaceAvailable = SpaceAvailable / 2;
////        Log.e(TAG, "onCreate: AfterSpace " + getReadableFileSize(SpaceAvailable));
//
//        mNewFilePath = Environment.getExternalStorageDirectory() + File.separator + "Android" + File.separator + "data" + File.separator + getPackageName() + "/Backup And Recovery/B&R";
//        File lFile = new File(mNewFilePath);
//        if (!lFile.exists()) {
//            lFile.mkdir();
//        }
//
//        mDatabaseHelper = new DatabaseHelper(RecoveryFile.this);
//
//        mHiddenCopyImagePath = getCacheDir() + "/Backup And Recovery/";
//        lStoreImageFile = new File(mHiddenCopyImagePath);
//        if (!lStoreImageFile.exists()) {
//            lStoreImageFile.mkdir();
//        }
//
//        sharedPreferences = getSharedPreferences("MyShareForNotification", MODE_PRIVATE);
//
//        Log.e(TAG, "onCreate: ");
//    }
//
//    @Override
//    public int onStartCommand(Intent intent, int i, int i2) {
//        RecoverImageService.isRunningService = true;
//        if (intent != null) {
//            String action = intent.getAction();
//            if ("com.backup.restore.device.image.recovery.OBSERVE".equals(action)) {
//                this.mStringPath = intent.getStringExtra("com.backup.restore.device.image.recovery.EXTRA_PATH");
//                new Thread(() -> {
//                    try {
//                        checkPath();
//                    } catch (Exception e) {
//                        Log.e(TAG, "catch: " + e.getMessage());
//                    }
//                }).start();
//
//            }
//        }
//        return START_STICKY;
//    }
//
//    public void checkPath() {
//        if (mStringPath != null) {
//            new File(mStringPath);
//            mBooleanList.clear();
//            observerPictures bVar = new observerPictures(mStringPath, this);
//            bVar.startWatching();
//        }
//    }
//
//    class observerPictures extends FileObserver {
//
//        String lNewCopiedPath;
//        List<singleObserver> mObserversList;
//        String mPath;
//        int mMask;
//        Context mContext;
//
//        public observerPictures(String path, Context context) {
//            this(path, ALL_EVENTS, context);
//        }
//
//        public observerPictures(String path, int mask, Context context) {
//            super(path, mask);
//            mPath = path;
//            mMask = mask;
//            mContext = context;
//        }
//
//        public void startWatching() {
//            int i;
//            if (mObserversList == null) {
//                mObserversList = new ArrayList<>();
//                Stack<String> stack = new Stack<>();
//                stack.push(this.mPath);
//
//                while (!stack.empty()) {
//                    i = 0;
//                    String str = stack.pop();
//                    this.mObserversList.add(new singleObserver(str, this.mMask));
//                    File[] listFiles = new File(str).listFiles();
//                    if (listFiles != null) {
//                        while (i < listFiles.length) {
//                            String Extension = FilenameUtils.getExtension(listFiles[i].getName());
//                            HashSet<String> lImageExtensionList = new HashSet<>(Arrays.asList(MyUtils.ImageExtension));
//                            if (listFiles[i].isDirectory()
//                                    && !listFiles[i].getName().equals(".")
//                                    && !listFiles[i].getName().equals("..")
//                                    && !listFiles[i].getName().equals("Backup And Recovery")
//                                    && !listFiles[i].getName().startsWith("data")
//                                    && !listFiles[i].getName().startsWith("obb")
//                                    && !listFiles[i].getName().startsWith("obj")
//                                    && !listFiles[i].getAbsolutePath().contains("cache")
//                                    && !listFiles[i].isHidden()) {
//                                stack.push(listFiles[i].getPath());
//
//                            } else if (!listFiles[i].isDirectory() && !listFiles[i].isHidden() &&
//                                    !listFiles[i].getName().startsWith("temp")
//                                    && lImageExtensionList.contains(Extension)
//                                    && listFiles[i].getName().endsWith(Extension)
//                                    && !isCheck(listFiles[i].getPath())) {
//                                CopyImage(listFiles[i].getPath());
//                            }
//                            i++;
//                        }
//                    }
//                }
//                for (int i2 = 0; i2 < mObserversList.size(); i2++) {
//                    mObserversList.get(i2).startWatching();
//                }
//            }
//            Log.e(TAG, "streamHashMap startWatching: end ");
//            new Handler(Looper.getMainLooper()).postDelayed(() -> {
//                if (mStringPath != null) {
//                    try {
//                        checkPath();
//                    } catch (Exception e) {
//                        Log.e(TAG, "catch: " + e.getMessage());
//                    }
//                    Log.e(TAG, "streamHashMap startWatching: again Start");
//                }
//            }, 60000);
//
//        }
//
//
//        public void stopWatching() {
//            if (mObserversList != null) {
//                for (int i = 0; i < mObserversList.size(); i++) {
//                    mObserversList.get(i).stopWatching();
//                }
//                mObserversList.clear();
//                mObserversList = null;
//            }
//        }
//
//        public void onEvent(int i, String oldPath) {
//            String Extension = FilenameUtils.getExtension(oldPath);
//            String ImageName = FilenameUtils.getName(oldPath);
//            HashSet<String> lImageExtensionList = new HashSet<>(Arrays.asList(MyUtils.ImageExtension));
//            boolean isExtensionMatches = lImageExtensionList.contains(Extension) && oldPath.endsWith(Extension) && !oldPath.contains("/.") && !ImageName.startsWith("temp");
//            switch (i) {
//                case ACCESS:
//                case MODIFY:
//                case ATTRIB:
//                case CLOSE_WRITE:
//                case CLOSE_NOWRITE:
//                case MOVED_FROM:
//                case MOVED_TO:
//                case CREATE:
//                case MOVE_SELF:
//                case OPEN:
//                    if (isExtensionMatches && !isCheck(oldPath)) {
//                        try {
//                            Log.e(TAG, "run: ");
//                            Thread.sleep(600);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
//                        CopyImage(oldPath);
//                        return;
//                    }
//                    break;
//
//                case DELETE:
//                case DELETE_SELF:
//                    if (isExtensionMatches) {
//                        if (isCheck(oldPath)) {
//                            String lExtensions = FilenameUtils.getExtension(oldPath);
//                            String lFileName = FilenameUtils.removeExtension(oldPath);
//                            String RemoveFirstSlash = lFileName.substring(1);
//                            if(mDatabaseHelper.checkAvailable(oldPath)){
//                            lNewCopiedPath = mNewFilePath + "/" + RemoveFirstSlash.replace("/", "_slash_").replace(".", "_esh_").replace("-", "_dash_").replace(",", "_coma_");
//                            String newName = lNewCopiedPath + "." + lExtensions;
////                            File des = new File(newName);
////                            if (!des.exists()) {
//                                copyImageBeforeDelete(oldPath, newName);
//                            }
//                        }
//
//                    }
//                    break;
//
//                default:
//            }
//        }
//
//        class singleObserver extends FileObserver {
//
//            private String mPath;
//
//            public singleObserver(String path) {
//                this(path, ALL_EVENTS);
//                mPath = path;
//            }
//
//            public singleObserver(String str, int i) {
//                super(str, i);
//                this.mPath = str;
//            }
//
//            public final void onEvent(int i, String path) {
//                String newPath = mPath + "/" + path;
//                observerPictures.this.onEvent(i, newPath);
//            }
//        }
//    }
//
//    public void onTaskRemoved(Intent intent) {
//        try {
//            Intent intent1 = new Intent(this, RecoverImageService.class);
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                startForegroundService(intent1);
//            } else {
//                startService(intent1);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        RecoverImageService.isRunningService = false;
//        onDestroy();
//        super.onTaskRemoved(intent);
//    }
//
//
//    @Override
//    public boolean onUnbind(Intent intent) {
//        RecoverImageService.isRunningService = false;
//        return super.onUnbind(intent);
//    }
//
//    @Override
//    public void onDestroy() {
//        RecoverImageService.isRunningService = false;
//        super.onDestroy();
//        try {
//            Intent intent1 = new Intent(this, RecoverImageService.class);
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                startForegroundService(intent1);
//            } else {
//                startService(intent1);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    public Boolean isCheck(String mStringPath) {
//        boolean z = false;
////        File file = new File(lStoreImageFile, mStringPath.replace("/", "_"));
////        if (file.exists()) {
//        if(mDatabaseHelper.checkAvailable(mStringPath)){
//            z = true;
//        }
//        return z;
//    }
//
//    public void CopyImage(String mStringPath) {
//
//        if (!lStoreImageFile.exists()) {
//            lStoreImageFile.mkdir();
//        }
//
//        File oldFile = new File(mStringPath);
//        if(!mDatabaseHelper.checkAvailable(String.valueOf(oldFile))) {
//            Log.e(TAG, "getAllImages: not Exists"  );
//            mDatabaseHelper.insertData(oldFile.toString(),oldFile.toString());
//        }else {
//            Log.e(TAG, "getAllImages: Exists"  );
//        }
//    }
//
//
//    void copyImageBeforeDelete(String lOldPath, String lNewPath) {
//        Notification mBuilder;
//        Boolean bool = mBooleanList.get(lOldPath);
//        if (bool == null || !bool) {
//            if (sharedPreferences.getBoolean("NotificationForDelete", true)) {
//                try {
//                    if (mNotificationManager == null) {
//                        mNotificationManager = (NotificationManager) (RecoveryFile.this).getSystemService(NOTIFICATION_SERVICE);
//                    }
//                    StatusBarNotification[] notifications;
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                        notifications = mNotificationManager.getActiveNotifications();
//                        for (StatusBarNotification notification : notifications) {
//                            if (notification.getId() == 150) {
//                                isSendNotification = true;
//                                break;
//                            } else if (notification.getId() != 150) {
//                                isSendNotification = false;
//                            }
//                        }
//                    }
//                    if (!isSendNotification) {
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                            if (mNotificationManager.getNotificationChannel(CHANNEL_ID) == null) {
//                                NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "BackupAndRecovery", NotificationManager.IMPORTANCE_HIGH);
//                                notificationChannel.enableVibration(true);
//                                notificationChannel.setVibrationPattern(new long[]{0, 250, 250, 250});
//                                mNotificationManager.createNotificationChannel(notificationChannel);
//                            }
//                        }
//                        Intent intent = new Intent(RecoveryFile.this, NewRecoverImageActivity.class);
//                        intent.putExtra("IsFromNotification", "yes");
//                        PendingIntent pendingIntent = PendingIntent.getActivity(RecoveryFile.this, 0, intent, 0);
//
//                        mBuilder = new NotificationCompat.Builder(RecoveryFile.this, CHANNEL_ID)
//                                .setContentTitle(getString(R.string.app_name))
//                                .setContentText("Successfully Backup Your Deleted Image!")
//                                .setSmallIcon(R.drawable.ic_icon)
//                                .setColor(ContextCompat.getColor(RecoveryFile.this, R.color.colorPrimary))
//                                .setPriority(IMPORTANCE_MIN)
//                                .setContent(null)
//                                .setAutoCancel(true)
//                                .setContentIntent(pendingIntent).build();
//
//                        mNotificationManager.notify(150, mBuilder);
//                    }
//                } catch (Exception e9) {
//                    Log.e(TAG, "copyImageBeforeDelete: " + e9.getMessage() );
//                }
//            }
//            mBooleanList.put(lOldPath, Boolean.TRUE);
//
//            File file = new File(lStoreImageFile, lOldPath.replace("/", "_"));
//            Log.e(TAG, "copyImageBeforeDelete:--> " + file);
//            try {
//                FileUtils.copyFile(file, new File(lNewPath));
//                if (file.exists()) {
//                    file.delete();
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
