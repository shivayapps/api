package com.backup.restore.device.image.recovery.mainphotos.activity


import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.*
import android.service.notification.StatusBarNotification
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.inapp.InAppActivity
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity.Companion.mIsFromForImageCheck
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableImageModel
import com.backup.restore.device.image.recovery.mainphotos.recoverableadapter.RecoverableOtherAdapter
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.*
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.*
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.OtherArray
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityViewRecoverableOtherListBinding
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ViewRecoverableOtherListActivity : MyCommonBaseActivity() {

    var mTAG: String = "ViewRecoverableImageList"

    var mGetRecoverableImage: AsyncTask<*, *, *>? = null
    private var mRecoverableImageAdapter: RecoverableOtherAdapter? = null

    private var moImageLists: MutableList<RecoverableImageModel> = ArrayList()
    private var isRecover = false
    var isAsyncRunning: Boolean = false
    var mFolderPath: String? = null
    private var mSavePath: String? = null

    var mIsDateClick = true
    var mIsSizeClick = true
    private var rewardedAd: RewardedAd? = null
    private var isRewardVideoAdLoaded: Boolean = false


    lateinit var binding: ActivityViewRecoverableOtherListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_view_recoverable_other_list)
        binding=ActivityViewRecoverableOtherListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(ViewRecoverableOtherListActivity::class.simpleName!!)
    }

    override fun getContext(): AppCompatActivity {
        return this@ViewRecoverableOtherListActivity
    }

    override fun initData() {
        binding.scanImage!!.setHasFixedSize(true)
        binding.scanImage!!.isNestedScrollingEnabled = false

        isManualHiddenClick = false

        binding.ivSpan.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        binding.tvHeader.text = intent.getStringExtra("folderName")
        binding.tvHeader!!.isSelected=true

        mFolderPath = intent.getStringExtra("folderPath")
        mRootPath = Environment.getExternalStorageDirectory().toString()
        mSavePath = "$mRootPath/Backup And Recovery/Other/"

        mRecoverableImageAdapter = RecoverableOtherAdapter(binding.scanImage, mContext, moImageLists, binding.checkAll)
        binding.scanImage!!.adapter = mRecoverableImageAdapter

        Log.e("TAG", "Root : $mSavePath")
        mGetRecoverableImage = GetRecoverableImage().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(mContext,binding.adview, NativeLayoutType.NativeMedium,null).loadAd()
//            NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
//                NativeAdsSize.Medium,
//                findViewById(R.id.ad_view_container)
//            )
        } else {
            binding.adview.visibility = View.GONE
        }
    }

    override fun initActions() {
        binding.ivBack!!.setOnClickListener {
            onBackPressed()
        }
        binding.checkAll!!.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            if (isChecked) {
                selectAll()
                if (mRecoverableImageAdapter != null) {
                    mRecoverableImageAdapter!!.notifyDataSetChanged()
                }
            } else {
                if (!isManualHiddenClick) {
                    diSelectAll()
                    if (mRecoverableImageAdapter != null) {
                        mRecoverableImageAdapter!!.notifyDataSetChanged()
                    }
                }
                isManualHiddenClick = false
            }
        }
        binding.btnRecover.setOnClickListener {
            if (SharedPrefsConstant.getInt(mContext, FREE_RECOVER_IMAGE_COUNT) >= 4 && AdsManager(this@ViewRecoverableOtherListActivity).isNeedToShowAds()) {

                if (mRecoverableImageAdapter != null) {
                    if (mRecoverableImageAdapter!!.getSelectedCounted() != 0) {
                        dialogUnlockPro()
                    } else {
                        Toast.makeText(
                            mContext,
                            getString(R.string.select_an_document),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {

                        Toast.makeText(
                            mContext,
                            getString(R.string.select_an_document),
                            Toast.LENGTH_SHORT
                        ).show()
                }

            } else {
                btnRecoverClicked()
            }
        }
        binding.ivSpan.visibility=View.GONE
        binding.ivSpan.setOnClickListener {
            if(isAsyncRunning) return@setOnClickListener
            if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            NewRecoverImageActivity.isGridChange = true
            setSpanCount()
        }

        binding.llSelectAll.setOnClickListener { binding.checkAll!!.isChecked = !binding.checkAll!!.isChecked }

        binding.llDateWise.setOnClickListener {
            if(isAsyncRunning) return@setOnClickListener
            if (moImageLists.isNotEmpty()) {
                binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                binding.tvDate.setTextColor(resources.getColor(R.color.colorAccent))
                if (mIsDateClick) {
                    Collections.sort(moImageLists, dateComparator())
                    mIsDateClick = false
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                } else {
                    Collections.sort(moImageLists, dateComparatorRevers())
                    mIsDateClick = true
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down))
                }
                mIsSizeClick = true
                mRecoverableImageAdapter!!.notifyDataSetChanged()
            }
        }
        binding.llSizeWise.setOnClickListener {
            if(isAsyncRunning) return@setOnClickListener
            if (moImageLists.isNotEmpty()) {
                binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                binding.tvDate.setTextColor(resources.getColor(R.color.filter_text_color))
                binding.tvSize.setTextColor(resources.getColor(R.color.colorAccent))
                if (mIsSizeClick) {
                    Collections.sort(moImageLists, sizeComparator())
                    mIsSizeClick = false
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                } else {
                    Collections.sort(moImageLists, sizeComparatorRevers())
                    mIsSizeClick = true
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down))
                }
                mIsDateClick = true
                mRecoverableImageAdapter!!.notifyDataSetChanged()
            }
        }
    }

    private fun btnRecoverClicked() {
        if (mRecoverableImageAdapter != null) {
            if (mRecoverableImageAdapter!!.getSelectedCounted() != 0) {
                isRecover = true
                if (!isAsyncRecover) {
                    AsyncTaskRunner().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                } else {
                    Toast.makeText(
                        mContext,
                        getString(R.string.task_already_running),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(
                    mContext,
                    getString(R.string.select_an_document),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun createAndLoadRewardedAd() {
        RewardedAd.load(this, resources.getString(R.string.rewarded_ad_id), AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(p0: RewardedAd) {
                super.onAdLoaded(p0)
                rewardedAd = p0
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                Log.e("TAG", "onAdFailedToLoad: =>"+p0.message)
                rewardedAd = null
            }
        })
    }

    private fun showRewardedAd() {
        val activityContext: Activity = this@ViewRecoverableOtherListActivity
        rewardedAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {

            override fun onAdDismissedFullScreenContent() {
                Log.i("TAG", "onAdDismissedFullScreenContent")
                rewardedAd=null
                Log.d("TAG", "The rewarded close.")
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
            }

            override fun onAdShowedFullScreenContent() {
                Log.i("TAG", "onAdShowedFullScreenContent")
            }

        }

        rewardedAd!!.show(activityContext) {
            Log.e("TAG", "onFinish: sds=>")
            SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_IMAGE_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_IMAGE_COUNT) - 1)
            btnRecoverClicked()
        }
    }

    private fun dialogUnlockPro() {
        createAndLoadRewardedAd()
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_unloack_pro)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)

        watchVideo.setOnClickListener {
            if (!NetworkManager.isInternetConnected(mContext)) {
                Toast.makeText(mContext,getString(R.string.no_internet_access),Toast.LENGTH_SHORT).show()
                createAndLoadRewardedAd()
            } else if (rewardedAd != null) {
                showRewardedAd()
                dialog.dismiss()
            } else  {
                Toast.makeText(mContext,getString(R.string.please_wait_for_ads_loading),Toast.LENGTH_SHORT).show()
                createAndLoadRewardedAd()
                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
            }
        }
        purchasePro.setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(mContext, InAppActivity::class.java))
        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

//    private fun dialogUnlockPro() {
//        //createAndLoadRewardedAd()
//
//        val dialog = Dialog(mContext)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_unloack_pro)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
//        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)
//        watchVideo.alpha = 0.5f
//        watchVideo.isClickable = false
//
//
//        val activityContext: Activity = this@ViewRecoverableOtherListActivity
//        InterstitialRewardHelper.loadRewardedInterstitialAd(activityContext)
//
//        isShowRewardedInterstitialAd(
//            onStartToLoadRewardedInterstitialAd = {
//            },
//            onUserEarnedReward = {
//                Log.e("TAG", "onFinish: sds=>")
//                SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_IMAGE_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_IMAGE_COUNT) - 1)
//                btnRecoverClicked()
//            },
//            onAdLoaded = {
//                watchVideo.alpha = 1.0f
//                watchVideo.isClickable = true
//                isRewardVideoAdLoaded = true
//            }
//        )
//
//        watchVideo.setOnClickListener {
//            if (!NetworkManager.isInternetConnected(mContext)) {
//                Toast.makeText(mContext,getString(R.string.no_internet_access),Toast.LENGTH_SHORT).show()
//                //createAndLoadRewardedAd()
//            } else if (isRewardVideoAdLoaded) {
//                showRewardVideoAd()
//                dialog.dismiss()
//            } else  {
//                Toast.makeText(mContext,getString(R.string.please_wait_for_ads_loading),Toast.LENGTH_SHORT).show()
//                //createAndLoadRewardedAd()
//                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
//            }
//        }
//        purchasePro.setOnClickListener {
//            dialog.dismiss()
//            startActivity(Intent(mContext, InAppActivity::class.java))
//        }
//
//        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
//            dialog.dismiss()
//        }
//        dialog.show()
//    }

    private inner class GetRecoverableImage : AsyncTask<Void?, String?, String?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            try {

                isAsyncRunning=true
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setCancelable(false)
                dialog.setContentView(R.layout.dialog_progress)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )

                dialog.findViewById<TextView>(R.id.permission).text =
                    getString(R.string.label_please_wait)
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.scanning_pictures)
                dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
                    if (mGetRecoverableImage != null) {
                        mGetRecoverableImage!!.cancel(true)
                    }
                }

                binding.lottieAnim.visibility = View.VISIBLE
                binding.btnRecover.alpha = 0.5F
                binding.btnRecover.isEnabled = false
                binding.llSelectAll.alpha = 0.5F
                binding.llSelectAll.isEnabled = false
                binding.checkAll.alpha = 0.5F
                binding.checkAll.isEnabled = false
                binding.ivSpan.alpha = 0.5F
                binding.ivSpan.isEnabled = false
                if (!dialog.isShowing) {
//                    dialog.show()
//                    MyApplication.isDialogOpen = true
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        override fun doInBackground(vararg voids: Void?): String? {
            moImageLists.clear()
            Log.e(mTAG, "doInBackground:::::::::: root $mFolderPath")
            moImageLists = createGridItems(mFolderPath, dialog)
            return mFolderPath
        }

        override fun onPostExecute(mFolderPath: String?) {

            isAsyncRunning=false
            binding.checkAll!!.isChecked = false
            if (isCancelled) {
                runOnUiThread {
                    binding.tvPhoto.visibility = View.VISIBLE
                    binding.scanImage!!.visibility = View.GONE

                    binding.btnRecover.alpha = 0.5F
                    binding.btnRecover.isEnabled = false
                    binding.llSelectAll.alpha = 0.5F
                    binding.llSelectAll.isEnabled = false
                    binding.checkAll.alpha = 0.5F
                    binding.checkAll.isEnabled = false
                }
            }

            Handler(Looper.getMainLooper()).post {
                try {
                    if (moImageLists.isEmpty()) {
                        binding.tvPhoto.visibility = View.VISIBLE
                        binding.scanImage!!.visibility = View.GONE
                        binding.btnRecover.alpha = 0.5f
                        binding.checkAll!!.alpha = 0.5f
                        binding.btnRecover.isEnabled = false
                        binding.llSelectAll.isEnabled = false
                        binding.llSelectAll.isClickable = false
                        binding.ivSpan.alpha = 0.5F
                        binding.ivSpan.isEnabled = false
                        binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                        binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                        binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                        binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                        binding.tvDate.setTextColor(resources.getColor(R.color.filter_text_color))
                        binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                        finish()
                    } else {
                        binding.scanImage!!.visibility = View.VISIBLE
                        binding.tvPhoto.visibility = View.GONE
                        binding.btnRecover.alpha = 1.0F
                        binding.checkAll!!.alpha = 1f
                        binding.btnRecover.isEnabled = true
                        binding.llSelectAll.isEnabled = true
                        binding.llSelectAll.isClickable = true
                        binding.ivSpan.alpha = 1F
                        binding.ivSpan.isEnabled = true
                        mIsDateClick = true
                        binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                        binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                        binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                        binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                        binding.tvDate.setTextColor(resources.getColor(R.color.colorPrimary))
                        binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                        binding.scanImage!!.layoutManager = GridLayoutManager(mContext, 1)
                        Collections.sort(moImageLists, dateComparator())
//                    mRecoverableImageAdapter!!.runLayoutAnimation()
                    }

                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        try {
                            binding.lottieAnim.visibility = View.GONE
                            binding.btnRecover.alpha = 1F
                            binding.btnRecover.isEnabled = true
                            binding.llSelectAll.alpha = 1F
                            binding.llSelectAll.isEnabled = true
                            binding.checkAll.alpha = 1F
                            binding.checkAll.isEnabled = true
                            binding.ivSpan.alpha = 1F
                            binding.ivSpan.isEnabled = true
                            if (dialog != null && dialog.isShowing) {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false

                            }
                        } catch (e: Exception) {
//                            mContext.addEvent(e.message!!)
                        }
                    }, 500)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    var mNotificationManager: NotificationManager? = null
    var isBackground = false
    var isBackPressed = false
    companion object {
        var isAsyncRecover = false
    }

    private inner class AsyncTaskRunner : AsyncTask<String?, String?, String>() {
        val dialog = Dialog(mContext)
        var CHANNEL_ID = "Restoring"
        var mNoti = "Restoring in progress"
        var notificationId = 175
        var isSendNotification = true

        //var mBuilder : Notification?=null
        var mBuilder = NotificationCompat.Builder(mContext, CHANNEL_ID)

        override fun onPreExecute() {
            ViewRecoverableImageListActivity.isAsyncRecover = true
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.setOnKeyListener { dialog, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    Log.e(mTAG, "AsyncTaskRunner:onBack")
//                    if(status==AsyncTask.Status.RUNNING) {
//                        cancel(true)
                    isBackground = true
                    mContext.onBackPressed()
//                    }
                }
                return@setOnKeyListener true
            }

            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.restoring)
//            dialog.findViewById<TextView>(R.id.permission_text).text = "Scanning Albums..."
//            dialog.findViewById<Button>(R.id.dialogButtonCancel).visibility = View.VISIBLE

            var btnCancel = dialog.findViewById<Button>(R.id.dialogButtonCancel)
            btnCancel.visibility = View.VISIBLE
            btnCancel.text = getString(R.string.background)
            btnCancel.setOnClickListener {
//                cancel(true)
                isBackground=true
                dialog.dismiss()
            }

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (dialog.isShowing == false) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }

            try {
                if (mNotificationManager == null) {
                    mNotificationManager =
                        mContext.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                }

                val notifications: Array<StatusBarNotification>
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    notifications = mNotificationManager?.activeNotifications!!
                    for (notification in notifications) {
                        if (notification.id == notificationId) {
                            isSendNotification = true
                            break
                        } else if (notification.id != notificationId) {
                            isSendNotification = false
                        }
                    }
                }
                if (!isSendNotification) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (mNotificationManager?.getNotificationChannel(CHANNEL_ID) == null) {
                            val notificationChannel = NotificationChannel(
                                CHANNEL_ID,
                                "BackupAndRecovery",
                                NotificationManager.IMPORTANCE_HIGH
                            )
//                            notificationChannel.setSound(null, null);
//                            notificationChannel.enableLights(false)
                            notificationChannel.setVibrationPattern(longArrayOf(0))
                            notificationChannel.enableVibration(true)
                            mNotificationManager?.createNotificationChannel(notificationChannel)
                        }
                    }
                }
            } catch (e9: java.lang.Exception) {
                Log.e(mTAG, "copyImageBeforeDelete: " + e9.message)
            }
        }

        override fun doInBackground(vararg params: String?): String {
            val tempSize = mRecoverableImageAdapter!!.getSelectedCounted()
            var finalI1 = 0
            var recoverd = 0
            try {

                Log.e(mTAG, "run: AsyncTaskRunner-> $moImageLists.indices")
                for (i in moImageLists.indices) {
                    ViewRecoverableImageListActivity.isAsyncRecover = true
                    if (mRecoverableImageAdapter!!.getSelected(i)) {
                        val finalI = finalI1
                        runOnUiThread {
                            dialog.findViewById<TextView>(R.id.permission_text).text =
                                getString(R.string.image) + " " + recoverd + "/" + tempSize + " " + getString(
                                    R.string.restore
                                )
                            Log.e(mTAG, "run: finalI-> $finalI")
                        }
                        val format = moImageLists[i].filePath
                        val filename = format.substring(format.lastIndexOf("/") + 1)
                        val fileNameWithOutExt = removeExtension(filename)
                        val fileExtension = getExtension(filename)
                        val timestamp = SimpleDateFormat("mm_ss_SSS").format(Date())
                        val fileNewFileName = "$fileNameWithOutExt$timestamp.$fileExtension"
                        val dir = File(mSavePath!!)
                        if (dir.exists() || dir.mkdirs()) {
                            Log.e(mTAG, "run: AsyncTaskRunner-> mkdirs")
                            Log.e(mTAG, "run: AsyncTaskRunner-> ${moImageLists[i].filePath}")
                            Log.e(
                                mTAG,
                                "run: AsyncTaskRunner-> ${mSavePath + File(fileNewFileName).name}"
                            )
                            //FileUtils.copyFile(File(moImageLists[i].filePath), File(mSavePath + File(fileNewFileName).name))
                            doCopyFile(
                                File(moImageLists[i].filePath),
                                File(mSavePath + File(fileNewFileName).name),
                                true
                            )
                            MediaScannerConnection.scanFile(
                                mContext,
                                arrayOf(File(mSavePath + File(fileNewFileName).name).absolutePath),
                                null
                            ) { _: String?, _: Uri? -> }
                            Log.e(mTAG, "run: AsyncTaskRunner-> ///mkdirs")
                        }
                        recoverd += 1
                    }
                    finalI1 += 1
                    mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                        .setContentText("$mNoti ${recoverd}/${tempSize}")
                        .setSmallIcon(R.drawable.ic_icon)
                        .setDefaults(Notification.DEFAULT_ALL)
                        .setOngoing(true)
                        .setProgress(moImageLists.size, finalI1, false)
                        .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                        .setPriority(NotificationManager.IMPORTANCE_HIGH)
                        .setContent(null)
                        .setAutoCancel(false)

                    mNotificationManager?.notify(notificationId, mBuilder.build())
                }
            } catch (e: Exception) {
                Log.e(mTAG, "doInBackground: catch =-> ")
                e.printStackTrace()
            }
            return ""
        }

        override fun onPostExecute(result: String) {
            Log.e(mTAG, "run: AsyncTaskRunner-> onPostExecute")
            try {
                if(!isBackPressed) isBackground = false
                ViewRecoverableImageListActivity.isAsyncRecover = false
                if (dialog.isShowing == true) {
                    dialog.dismiss()
                    MyApplication.isDialogOpen = false
                }
            } catch (e: Exception) {
//                mContext.addEvent(e.message!!)
            }

            if (mRecoverableImageAdapter!!.getSelectedCounted() != 0) {
                if(!isBackPressed) isBackground = false
                ViewRecoverableImageListActivity.isAsyncRecover = false

                mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                    .setContentText("${getString(R.string.restore_successfully)}")
                    .setSmallIcon(R.drawable.ic_icon)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setProgress(0, 0, true)
                    .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                    .setPriority(NotificationManager.IMPORTANCE_HIGH)
                    .setContent(null)
                    .setAutoCancel(true)
                mNotificationManager?.notify(notificationId, mBuilder.build())
                mNotificationManager?.cancel(notificationId)
                mNotificationManager?.cancelAll()

                Toast.makeText(
                    mContext,
                    getString(R.string.file_restored_at) + mSavePath,
                    Toast.LENGTH_SHORT
                ).show()
                diSelectAll()
                binding.scanImage!!.adapter = mRecoverableImageAdapter
                binding.checkAll!!.isChecked = false
                isManualHiddenClick = false
                isRecover = false
                SharedPrefsConstant.save(
                    mContext,
                    RATE_RECOVER_IMAGE_COUNT,
                    SharedPrefsConstant.getInt(mContext, RATE_RECOVER_IMAGE_COUNT) + 1
                )
                SharedPrefsConstant.save(
                    mContext,
                    FREE_RECOVER_IMAGE_COUNT,
                    SharedPrefsConstant.getInt(mContext, FREE_RECOVER_IMAGE_COUNT) + 1
                )
                if (!isBackground) {
                    mIsFromForImageCheck = "Recoverable"
                    SharedPrefsConstant.savePref(mContext, "AfterRecover", true)
                    startActivity(
                        Intent(
                            mContext,
                            NewRecoverImageActivity::class.java
                        ).putExtra("IsFromNotification", "No")
                    )
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            } else {
                Toast.makeText(mContext, getString(R.string.select_an_document), Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun createGridItems(
        directoryPath: String?,
        moProgressDialog: Dialog?
    ): MutableList<RecoverableImageModel> {
        val files = File(directoryPath!!).listFiles()
        if (files != null) {
            for (file in files) {
                if (file.isDirectory) {
//                    createGridItems(file.path, moProgressDialog)
                } else {
                    val filePath = file.absolutePath
                    val lExtension = getExtension(filePath)
//                    val lImageExtensionList = HashSet(listOf(ImageArray))
                    val isExtensionMatches = OtherArray.contains(lExtension) && filePath.endsWith(lExtension)
                    if (isExtensionMatches && file.length().toString() != "0") {
                        if (filePath.contains("/.")) {
                            val loImageList = RecoverableImageModel(
                                filePath,
                                false,
                                file.lastModified(),
                                file.length()
                            )
                            moImageLists.add(loImageList)
                            runOnUiThread {
                                Handler(Looper.getMainLooper()).post {
                                    Log.e(mTAG, "gridRecoverableAlbumImage: " + moImageLists.size)
                                    mRecoverableImageAdapter!!.notifyDataSetChanged()
                                }
                            }
                        }
                    }
                }
                if (mGetRecoverableImage != null) {
                    if (mGetRecoverableImage!!.isCancelled) {
                        runOnUiThread {
                            moProgressDialog!!.cancel()
                            MyApplication.isDialogOpen = false
                            finish()
                            overridePendingTransition(
                                android.R.anim.fade_in,
                                android.R.anim.fade_out
                            )
                        }
                        break
                    }
                }
            }
        }
        return moImageLists
    }

    private fun setSpanCount() {
        var mCurrentSpanCount = mContext.getGridCount()
        mCurrentSpanCount = if (mCurrentSpanCount == SPAN_COUNT_THREE) {
            SPAN_COUNT_TWO
        } else {
            SPAN_COUNT_THREE
        }
        mContext.saveGridCount(mCurrentSpanCount)
        binding.ivSpan.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        spanCount()
    }

    fun spanCount() {
        if (mRecoverableImageAdapter != null) {
            val lCurrentSpanCount = 1
            if (binding.scanImage!!.itemDecorationCount > 0) {
                binding.scanImage!!.removeItemDecorationAt(0)
            }
            binding.scanImage!!.layoutManager = GridLayoutManager(mContext, lCurrentSpanCount)
            mRecoverableImageAdapter!!.notifyItemRangeChanged(0, lCurrentSpanCount)
        }
    }

    fun selectAll() {
        for (i in moImageLists.indices) {
            moImageLists[i].isSelected = true
        }
        Log.e(mTAG, "selectAll: moImageLists " + moImageLists.size)
    }

    fun diSelectAll() {
        for (i in moImageLists.indices) {
            moImageLists[i].isSelected = false
        }
    }

    public override fun onPause() {
        super.onPause()
        if (isRecover) {
            if (mRecoverableImageAdapter!!.getSelectedCounted() != 0) {
                AsyncTaskRunner().cancel(true)
                Log.e(mTAG, "onPause: AsyncTask Cancel")
            }
        }
    }

    public override fun onResume() {
        super.onResume()
        changeLanguage()
        if (isRecover) {
            Log.e(mTAG, "onResume: new Recover ")
        }
    }

    override fun onBackPressed() {
        isBackPressed=true
        isBackground=true
        if(mGetRecoverableImage!=null) {
            if(mGetRecoverableImage?.status==AsyncTask.Status.RUNNING) {
                mGetRecoverableImage?.cancel(true)
            }
        }
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}