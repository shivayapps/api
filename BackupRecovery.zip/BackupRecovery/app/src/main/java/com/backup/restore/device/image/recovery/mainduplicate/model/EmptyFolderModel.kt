package com.backup.restore.device.image.recovery.mainduplicate.model

class EmptyFolderModel {
    var path : String? = null
    var isCheckBox = true
}