package com.backup.restore.device.image.recovery.junckcleaner.interfaces;

public interface AdClosed {
    void addDismissed(boolean closed);

    void addFailed(boolean closed);
}
