package com.aainc.recyclebin.storage;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class a {
    private static final String a = a.class.getSimpleName();
    private static a b;
    private c c = new c();

    public class C0027a {
        private bina b;
        private String c;
        private Integer d;

        public C0027a(bina bVar, String str, Integer num) {
            this.b = bVar;
            this.c = str;
            this.d = num;
        }

        public final bina a() {
            return this.b;
        }

        public final String b() {
            return this.c;
        }

        public final Integer c() {
            return this.d;
        }

        public boolean equals(Object obj) {
            C0027a aVar = (C0027a) obj;
            if (!this.c.equals(aVar.b())) {
                return this.d.equals(aVar.c());
            }
            return true;
        }

        public int hashCode() {
            return this.d.intValue();
        }
    }

    public enum bina {
        EXTERNAL_SD_CARD,
        REMOVABLE_SD_CARD
    }

    private class c {
        private ArrayList<C0027a> b;
        private ArrayList<C0027a> c;

        private c() {
            this.b = null;
            this.c = null;
        }

        private int a(File file) {
            StringBuilder sb = new StringBuilder();
            sb.append(file.getTotalSpace());
            sb.append(file.getUsableSpace());
            for (File file2 : file.listFiles()) {
                sb.append(file2.getName());
                if (file2.isFile()) {
                    sb.append(file2.length());
                }
            }
            return sb.toString().hashCode();
        }

        private C0027a a(String str, bina bVar) {
            File file = new File(str);
            if (!file.exists() || !file.isDirectory() || !file.canWrite()) {
                return null;
            }
            return new C0027a(bVar, str, Integer.valueOf(a(file)));
        }

        private List<C0027a> d() {
            C0027a a2;
            ArrayList arrayList = new ArrayList(3);
            String absolutePath = Environment.getExternalStorageDirectory().getAbsolutePath();
            if (!absolutePath.trim().isEmpty() && Environment.getExternalStorageState().equals("mounted") && (a2 = a(absolutePath, bina.EXTERNAL_SD_CARD)) != null) {
                arrayList.add(a2);
            }
            String str = System.getenv("SECONDARY_STORAGE");
            if (str != null && !str.isEmpty()) {
                for (String str2 : str.split(File.pathSeparator)) {
                    C0027a a3 = a(absolutePath, bina.REMOVABLE_SD_CARD);
                    if (a3 != null) {
                        arrayList.add(a3);
                    }
                }
            }
            return arrayList;
        }

        private java.util.List<com.aainc.recyclebin.storage.a.C0027a> e() {
            com.aainc.recyclebin.storage.a.c r8 = this;
            int r2 = 0;
            int r7 = 1;
            java.util.ArrayList r5 = new java.util.ArrayList();
            int r01 = 3;


            r5.add(3);
            java.lang.Runtime r0 = java.lang.Runtime.getRuntime();
            java.lang.String r1 = "mount";
            Process r6 = null;
            try {
                r6 = r0.exec(r1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            java.io.InputStream r4 = r6.getInputStream();
            java.io.InputStreamReader r3 = new java.io.InputStreamReader(r4);

            r5.add(r0);


            Log.e("TAG", "e: FileSystemHandleř --> " + r5.size());

            e1();

            return r5;
        }

        private java.util.List<com.aainc.recyclebin.storage.a.C0027a> e1() {
            try {
                com.aainc.recyclebin.storage.a.c r8 = this;
                int r2 = 0;
                int r7 = 1;
                java.util.ArrayList r5 = new java.util.ArrayList(3);
                java.lang.Runtime r0 = java.lang.Runtime.getRuntime();
                java.lang.String r1 = "mount";
                java.lang.Process r6 = r0.exec(r1);
                java.io.InputStream r4 = r6.getInputStream();
                java.io.InputStreamReader r3 = new java.io.InputStreamReader(r4);
                java.io.BufferedReader rr1 = new java.io.BufferedReader(r3);

                while (rr1.readLine() != null) {
                    if (rr1.readLine() != null) {
                        java.lang.String r0c = rr1.readLine();

                        java.lang.String r26 = " ";
                        java.lang.String[] r0sd = r0c.split(r26);

                        int r2g = r0sd.length;
                        r2 = 1;
                        String r0d = r0sd[r2];
                        bina rs2 = bina.REMOVABLE_SD_CARD;
                        C0027a r0a = r8.a(r0d, rs2);
                        r5.add(r0a);

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
          }

        public ArrayList<C0027a> a() {
            return this.b;
        }

        public ArrayList<C0027a> b() {
            return this.c;
        }

        public void c() {
            List<C0027a> d = d();
            List<C0027a> e = e();
            for (C0027a b2 : d) {
                String b3 = b2.b();
                Iterator<C0027a> it = e.iterator();
                while (true) {
                    if (it.hasNext()) {
                        if (b3.equals(it.next().b())) {
                            it.remove();
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
            d.addAll(e);
            this.b = new ArrayList<>(d.size());
            this.c = new ArrayList<>(d.size());
            for (C0027a next : d) {
                if (next.a() == bina.EXTERNAL_SD_CARD) {
                    this.b.add(next);
                } else {
                    this.c.add(next);
                }
            }
        }
    }

    public a() {
        this.c.c();
    }

    public static a a() {
        if (b == null) {
            b = new a();
        }
        return b;
    }

    private static String a(Context context) {
        if (context != null) {
            return context.getPackageName();
        }
        throw new NullPointerException("Parameter is invalid. Context can't be null.");
    }

    public String a(String str) {
        if (str != null) {
            for (C0027a next : b()) {
                if (str.indexOf(next.b()) != -1) {
                    return next.b();
                }
            }
        }
        return null;
    }


    public ArrayList<C0027a> b() {
        ArrayList<C0027a> arrayList = new ArrayList<>();
        arrayList.addAll(this.c.a());
        arrayList.addAll(this.c.b());
        return arrayList;
    }

    public ArrayList<C0027a> c() {
        return this.c.a();
    }

    public ArrayList<C0027a> d() {
        return this.c.b();
    }
}
