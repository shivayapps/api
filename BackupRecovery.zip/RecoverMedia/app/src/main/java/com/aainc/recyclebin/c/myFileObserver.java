package com.aainc.recyclebin.c;

import static com.backup.restore.device.image.recovery.utilities.UtilsKt.getExtension;

import android.content.Context;
import android.os.FileObserver;
import android.util.Log;

import com.aainc.recyclebin.b.myclass;
import com.aainc.recyclebin.d.c;
import com.aainc.recyclebin.storage.FileSystemHandler;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Map;

public class myFileObserver extends FileObserver {

    private static final String FILE_OBSERVER = "FileObserver";
    private String string;
    private int anInt;
    private FileSystemHandler fileSystemHandler;
    private Collection<myclass> myclassCollection;

    private Map<String, Integer> stringIntegerMap;
    private Map<String, Long> stringLongMap;
    Context mContexts;

    public myFileObserver(Map<String, Integer> map, Map<String, Long> map2, String str, int i,
                          FileSystemHandler fileSystemHandler, Collection<myclass> collection, Context mContext) {
        super(str, i);
        stringIntegerMap = null;
        this.stringIntegerMap = map;
        this.stringLongMap = map2;
        this.string = str;
        this.anInt = i;
        this.fileSystemHandler = fileSystemHandler;
        this.myclassCollection = collection;
        this.mContexts = mContext;

    }

    private synchronized void setImageMap(String mPath) {
//        Log.e(FILE_OBSERVER, "setImageMap: mContext " + mContexts );
        Log.e(FILE_OBSERVER, "setImageMap: " + mPath );
//        writeStringAsFile22(mContext ,mPath);
        if (!mPath.contains("Backup And Recovery/") && !mPath.contains("/.") && !mPath.contains("/DCIM/Camera/temp_")) {
            Log.e(FILE_OBSERVER, "setImageMap: if"  );
            synchronized (this) {

                if (mPath != null) {

                    int r03 = this.stringIntegerMap.get(mPath);
                    Long r1 = this.stringLongMap.get(mPath);

                    if (r03 == 0) {

                        FileSystemHandler r0 = this.fileSystemHandler;
                        java.util.List r201 = r0.b();
                        java.util.Iterator r21 = r201.iterator();

                        while (r21.hasNext()) {
                            Object object = r21.next();
                            FileObserver fr0 = (FileObserver) object;
                            boolean r2 = fr0 instanceof myFileObserver;

                            if (r2) {

                                myFileObserver fr01 = (myFileObserver) fr0;
                                String str2 = fr01.setString();

                                if (!str2.equals(mPath)) {
                                    FileSystemHandler fr1 = this.fileSystemHandler;
                                    fr1.a(fr01, mPath);
                                    FileSystemHandler ffr1 = this.fileSystemHandler;
                                    ffr1.a(fr01);
                                    return;
                                }

                            }
                            else {
                                throw new java.lang.ClassCastException("Can't cast FileObserver object to FileSystemObserver class.");
                            }

                        }

                    }
                    else {

                        if (r1 == null) {

                            FileSystemHandler r0 = this.fileSystemHandler;
                            java.util.List r201 = r0.b();
                            java.util.Iterator r21 = r201.iterator();

                            while (r21.hasNext()) {
                                Object object = r21.next();
                                FileObserver fr0 = (FileObserver) object;
                                boolean r2 = fr0 instanceof myFileObserver;

                                if (r2) {

                                    myFileObserver fr01 = (myFileObserver) fr0;
                                    String mobjpath = fr01.setString();

                                    if (!mobjpath.equals(mPath)) {
                                        FileSystemHandler fr1 = this.fileSystemHandler;
                                        fr1.a(fr01, mPath);
                                        FileSystemHandler ffr1 = this.fileSystemHandler;
                                        ffr1.a(fr01);
                                        return;
                                    }

                                } else {
                                    throw new java.lang.ClassCastException("Can't cast FileObserver object to FileSystemObserver class.");
                                }

                            }

                        }
                        else {

                            FileSystemHandler r2 = this.fileSystemHandler;
                            int r031 = r03;
                            long r4 = r1.longValue();
                            r2.a(r031, r4, mPath);
                            java.util.Map<String, java.lang.Integer> r0 = this.stringIntegerMap;
                            r0.remove(mPath);
                            java.util.Map<String, java.lang.Long> r034 = this.stringLongMap;
                            r034.remove(mPath);
                            java.util.Collection<myclass> r0h = this.myclassCollection;
                            java.util.Iterator r1h = r0h.iterator();


                            while (r1h.hasNext()) {

                                Object object = r1h.next();
                                myclass a1 = (myclass) object;
                                if (a1 != null) {
                                    String str0 = a1.a();
                                    boolean br0 = str0.equals(mPath);
                                    if (br0) {
                                        java.util.Collection<myclass> aCollection = this.myclassCollection;
                                        int i0 = aCollection.size();
                                        if (i0 != 1) {
                                            r1h.remove();
                                            return;
                                        }
                                        FileSystemHandler fileSystemHandler = this.fileSystemHandler;
                                        fileSystemHandler.a(this);
                                    }
                                }
                                r1h.remove();
                            }


                        }
                    }

                }
                else {
                    java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException("Parameter is invalid. Event path can't be null.");
                    throw r0;
                }

            }
        }

    }

//    private void getVideoPath(String lPath, Context mContext) {
//        try {
//            ExifInterface exif = new ExifInterface(new File(lPath).getPath());
//            byte[] imageData=exif.getThumbnail();
//            if (imageData!=null) {//it can not able to get the thumbnail for very small images , so better to check null
//                Bitmap thumbnail = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
//                Log.e(FILE_OBSERVER, "getVideoPath: " + thumbnail );
//            }


//            Bitmap bmThumbnail = ThumbnailUtils.createVideoThumbnail(lPath, MediaStore.Images.Thumbnails.MICRO_KIND);
//            Log.e(TAG, "getVideoPath:bmThumbnail " + bmThumbnail );
            /*Log.e(TAG, "getVideoPath: " + mContext );
            Log.e(TAG, "Uri.parse(lPath): " + Uri.parse(lPath) );
            Cursor cursor = MediaStore.Images.Thumbnails.queryMiniThumbnails(mContext.getContentResolver(), Uri.parse(lPath), MediaStore.Images.Thumbnails.MINI_KIND, null );
            Log.e(TAG, "cursor: " + cursor );
            if( cursor != null && cursor.getCount() > 0 ) {
                cursor.moveToFirst();//**EDIT**
                String uri = cursor.getString( cursor.getColumnIndex( MediaStore.Images.Thumbnails.DATA ) );
                Log.e(TAG, "getVideoPath:uri " + uri );
            }*/

//            String[] filePathColumn = {MediaStore.Images.Media.DATA};
//            Log.e(TAG, "filePathColumn: " + new Gson().toJson(filePathColumn));
//            Log.e(TAG, "Uri.parse(lPath): " + Uri.parse(lPath) );
//            Log.e(TAG, "lPath: " + new File(lPath).exists() );
//            Cursor cursor = mContext.getContentResolver().query(Uri.parse(lPath), filePathColumn, null, null, null);
//            Log.e(TAG, "cursor: " + cursor );
//            cursor.moveToFirst();
//            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
//            String picturePath = cursor.getString(columnIndex);
//            cursor.close();
//            Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(picturePath, MediaStore.Video.Thumbnails.MICRO_KIND);
//
//            Log.e(TAG, "getVideoPath: " + bitmap );
//        }catch (Exception e){
//            Log.e(FILE_OBSERVER, "Exception: e " + e.getMessage() );
//        }
//    }


    public Map<String, Integer> setImageMap() {
        return this.stringIntegerMap;
    }

    public Map<String, Long> setLoadMap() {
        return this.stringLongMap;
    }

    public String setString() {
        return this.string;
    }

//    public Collection<myclass> setMyclasss() {
//        return this.myclassCollection;
//    }

    @Override
    public void onEvent(int i, String str) {


        int i2 = i & 4095;
        try {
            if (this.fileSystemHandler == null) {
                throw new NullPointerException("FileSystemHandler is null.");
            }
            switch (i2) {
                case MODIFY:
                case ATTRIB:
                case MOVED_TO:
                    try {
                        String lPath = this.string + File.separator + str;
                        this.fileSystemHandler.b(this, lPath);
//                        getVideoPath(lPath,mContexts);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                    return;

                case MOVED_FROM:
                    this.fileSystemHandler.a(this, this.string + File.separator + str);
                    return;
                case CREATE:
                    if (new c().a(this.string + File.separator + str)) {
                        try {
                            myFileObserver a12 = this;
                            this.fileSystemHandler.b(a12, this.string + File.separator + str);
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                        return;
                    }
                    return;
                case DELETE:
                    if(!SharedPrefsConstant.getBooleanNoti(mContexts, "isDeleteFromEmpty", false)) {
                        String lPath = this.string + File.separator + str;
                        Log.e(FILE_OBSERVER, "onEvent: Delete " + lPath );
                        String lExtension = getExtension(new File( lPath).getName());
                        Log.e(FILE_OBSERVER, "onEvent: lExtension " + lExtension );
                        setImageMap(lPath);
                    }
                    return;
                case DELETE_SELF:
                    Log.e(FILE_OBSERVER, "onEvent: Delete " + this.string + File.separator + str);
                    return;
                case MOVE_SELF:
                    this.fileSystemHandler.a(this);
                    return;
                default:
                    return;
            }
        } catch (ClassCastException e2) {
            e2.printStackTrace();
        } catch (IllegalArgumentException e3) {
            e3.printStackTrace();
        } catch (NullPointerException e4) {
            e4.printStackTrace();
        }
    }


}
