package com.backup.restore.device.image.recovery.mainapps.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent

class ShortcutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        addEvent(ShortcutActivity::class.simpleName!!)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        val stringExtra = intent.getStringExtra("pkgName")
        if (stringExtra != null) {
            startActivity(packageManager.getLaunchIntentForPackage(stringExtra))
            finish()
        }
        super.onCreate(savedInstanceState)
    }
}