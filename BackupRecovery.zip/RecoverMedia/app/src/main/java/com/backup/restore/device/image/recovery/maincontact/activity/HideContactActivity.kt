package com.backup.restore.device.image.recovery.maincontact.activity

import android.app.Activity
import android.app.Dialog
import android.content.*
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.maincontact.adapter.HideContactAdapter
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnHideItemClick
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.newsecurity.BaseActivity_Lock
import com.backup.restore.device.image.recovery.receiver.ScreenReceiver
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.MyUtils.hideKeyboard
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
//import com.example.app.ads.helper.GiftIconHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityFavoriteBinding
//import kotlinx.android.synthetic.main.activity_favorite.*
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.*


class HideContactActivity : BaseActivity_Lock(), View.OnClickListener {
    var mTAG: String = javaClass.simpleName

    var mContext = this
    private var mDbAdapter: DBAdapter? = null
    private var mHideContactCursor: Cursor? = null
    var mHideContactAsyncTask: AsyncTask<*, *, *>? = null
    private var hide = false
    var hideContactAdapter: HideContactAdapter? = null
    var mDbHelper: DBAdapter? = null

    var mScreenReceiver: ScreenReceiver = ScreenReceiver()

    companion object {
        var HideContactList = ArrayList<ContactModel>()
        var hideContactActivity: HideContactActivity? = null
        var isShowDialogHide = false
        @JvmField
        var context: Activity? = null
    }

    lateinit var binding:ActivityFavoriteBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_favorite)
        binding=ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mContext = this
        addEvent(javaClass.simpleName)
        initData()
        initActions()
    }


    fun initData() {
        context = this
        hideContactActivity = this@HideContactActivity

        registerReceiver(mScreenReceiver, IntentFilter("android.intent.action.SCREEN_OFF"))

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            GiftIconHelper.loadGiftAd(
//                fContext = mContext,
//                fivGiftIcon = findViewById(R.id.main_la_gift),
//                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//            )
//        }
        mDbHelper = DBAdapter(mContext)
        binding.header.text = getString(R.string.hiden_contact)
        binding.txtEmpty.text = getString(R.string.empty_hiden_contact)
//        iv_empty.setImageDrawable(resources.getDrawable(R.drawable.ic_backup_not_found_contact))


        binding.rvContact!!.layoutManager = LinearLayoutManager(mContext)
        mDbAdapter = DBAdapter(mContext)

        mHideContactAsyncTask = HideContactAsyncTask().execute()

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()
//        }else{
//            binding.adview.visibility = View.GONE
//        }
    }

    fun initActions() {
        binding.ivBack!!.setOnClickListener(this)
        binding.etSearchApk.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (binding.etSearchApk.text.toString().isEmpty()) {
                    binding.etSearchApk.clearFocus()
                    hideKeyboard(applicationContext, binding.etSearchApk)
                } else {
                    binding.etSearchApk.requestFocus()
                }
            }

            override fun afterTextChanged(s: Editable) {
                searchContact(s.toString())
            }
        })

    }


    override fun onClick(view: View) {
        if (view == binding.ivBack) {
            if (HideContactList.size != 0) binding.rvContact!!.stopScroll()
            onBackPressed()
            HideContactList.clear()
        }
    }

    private inner class HideContactAsyncTask : AsyncTask<Void?, Void?, Void?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.loading_)
            dialog.findViewById<TextView>(R.id.permission_text).visibility = View.GONE
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
                mHideContactAsyncTask!!.cancel(true)
            }

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }


            if (!dialog.isShowing && !isShowDialogHide) {
                dialog.show()
                MyApplication.isDialogOpen = true
                Log.e(mTAG, "ContactDetailsActivity onPreExecute: show")
            }
            binding.tvEmpty!!.visibility = View.GONE
            binding.rvContact!!.visibility = View.GONE
            binding.frag.visibility = View.GONE
            HideContactList.clear()

        }

        override fun doInBackground(vararg voids: Void?): Void? {

            mHideContactCursor = mDbAdapter!!.hideData
            var bitmap: Bitmap?
            if (mHideContactCursor!!.count != 0) {
                if (mHideContactCursor!!.moveToFirst()) {
                    do {
                        if (mHideContactCursor!!.getString(mHideContactCursor!!.getColumnIndex(DBAdapter.KEY_HIDE_ID)) != null) {
                            val contactId = mHideContactCursor!!.getString(mHideContactCursor!!.getColumnIndex(DBAdapter.KEY_HIDE_ID))
                            Log.e(mTAG, "contact_id =>$contactId")
                            val photoUri = getPhotoUri(contactId.toString())
                            val contactModel = ContactModel()
                            try {
                                if (photoUri != null) {
                                    contactModel.mContactImageUri = photoUri.toString()
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            contactModel.mContactName = mHideContactCursor!!.getString(mHideContactCursor!!.getColumnIndex(DBAdapter.KEY_HIDE_NAME))
                            contactModel.mNumber = mHideContactCursor!!.getString(mHideContactCursor!!.getColumnIndex(DBAdapter.KEY_HIDE_NUMBER))
                            contactModel.mContactId = mHideContactCursor!!.getString(mHideContactCursor!!.getColumnIndex(DBAdapter.KEY_HIDE_ID))
                            contactModel.mContactImageUri = mHideContactCursor!!.getString(mHideContactCursor!!.getColumnIndex(DBAdapter.KEY_HIDE_IMAGE))
                            HideContactList.add(contactModel)
                        } else {
                            Log.e(mTAG, "Delete ===>")
                            mDbAdapter!!.deleteHideContactDetails(mHideContactCursor!!.getString(mHideContactCursor!!.getColumnIndex(DBAdapter.KEY_HIDE_ID)))
                        }
                        if (mHideContactAsyncTask!!.isCancelled) {
                            runOnUiThread {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false
                                finish()
                                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out) }
                            break
                        }
                    } while (mHideContactCursor!!.moveToNext())
                }
            } else {
                hide = true
            }
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            dialog.cancel()
            MyApplication.isDialogOpen = false
            if (hide) {
                hide = false
                binding.rvContact!!.visibility = View.GONE
                binding.tvEmpty!!.visibility = View.VISIBLE
                binding.frag.visibility = View.GONE
            } else {
                if (HideContactList.size != 0) {
                    reverse(HideContactList)
                    hideContactAdapter =
                        HideContactAdapter(mContext, HideContactList, object : OnHideItemClick {
                            override fun onHideContactItemClick(position: Int) {
                                unHideContactMethod(HideContactList, position)
                            }

                        })
                    binding.rvContact!!.adapter = hideContactAdapter
                    binding.rvContact!!.visibility = View.VISIBLE
                    binding.tvEmpty!!.visibility = View.GONE
                    binding.frag.visibility = View.VISIBLE
                } else {
                    binding.rvContact!!.visibility = View.GONE
                    binding.tvEmpty!!.visibility = View.VISIBLE
                    binding.frag.visibility = View.GONE
                }
            }
        }
    }

    fun reverse(list: ArrayList<ContactModel>): ArrayList<ContactModel> {
        var i = 0
        val j = list.size - 1
        while (i < j) {
            list.add(i, list.removeAt(j))
            i++
        }
        return list
    }

    fun getContactIDFromNumber(lContactNumber: String?, context: Context): Int {
        var contactNumber = lContactNumber
        contactNumber = Uri.encode(contactNumber)
        var phoneContactID = Random().nextInt()
        val contactLookupCursor = context.contentResolver.query(
            Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, contactNumber),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID),
            null,
            null,
            null
        )
        while (contactLookupCursor!!.moveToNext()) {
            phoneContactID = contactLookupCursor.getInt(contactLookupCursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup._ID))
        }
        contactLookupCursor.close()
        return phoneContactID
    }

    fun getPhotoUri(photo: String?): Uri? {
        try {
            val cur: Cursor = mContext.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + "=" + photo + " AND " + ContactsContract.Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE + "'",
                null,
                null
            )!!
            if (cur != null) {
                if (!cur.moveToFirst()) {
                    return null // no photo
                }
            } else {
                return null // error in cursor process
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
        val person: Uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, photo!!.toLong())
        return Uri.withAppendedPath(person, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY)
    }

    private fun searchContact(str: String) {
        val toLowerCase: CharSequence = str.toLowerCase(Locale.ROOT)
        val arrayList = ArrayList<ContactModel>()
        for (i in HideContactList.indices) {
            if (HideContactList[i].mContactName!!.toLowerCase(Locale.ROOT).contains(toLowerCase) || HideContactList[i].mNumber!!.toLowerCase(Locale.ROOT).replace("-", "").contains(toLowerCase)) {
                arrayList.add(HideContactList[i])
            }
        }
        if (arrayList.size != 0) {
            binding.rvContact.visibility = View.VISIBLE
            binding.tvEmpty.visibility = View.GONE
        } else {
            binding.rvContact.visibility = View.GONE
            binding.tvEmpty.visibility = View.VISIBLE
        }

        hideContactAdapter = HideContactAdapter(mContext, HideContactList, object : OnHideItemClick {
                override fun onHideContactItemClick(position: Int) {
                    unHideContactMethod(arrayList, position)
                }
            })
        binding.rvContact.adapter = hideContactAdapter
        hideContactAdapter!!.setList(arrayList)
        hideContactAdapter!!.notifyDataSetChanged()
    }

    private fun unHideContactMethod(arrayList: ArrayList<ContactModel>, position: Int) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_dialog_hide_contact))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.unhide_contact)
        dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.add_contact_in_phonebook)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.unhide)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {

            dialog.cancel()
            MyApplication.isDialogOpen = false

            ShareConstants.hide_activity = true
            isShowDialogHide = true
            mDbHelper!!.deleteHideContactDetails(arrayList[position].mContactId)
            if (ShareConstants.hide_activity) {
                if (arrayList.size != 0) {
                    val mContactModel = arrayList[position]
                    addContact(arrayList[position].mContactName!!, arrayList[position].mNumber!!,arrayList[position].mContactImageUri)
                    HideContactList.remove(mContactModel)
                    if(arrayList.isNotEmpty() && arrayList.contains(mContactModel)) {
                        arrayList.remove(mContactModel)
                    }
                    binding.etSearchApk.text = null
                    binding.etSearchApk.clearFocus()
                    hideKeyboard(mContext,binding.etSearchApk)
                    hideContactAdapter!!.notifyDataSetChanged()
                    if(HideContactList.isEmpty()){
                        binding.frag.visibility = View.GONE
                    }else{
                        binding.frag.visibility = View.VISIBLE
                    }
                    Toast.makeText(mContext,getString(R.string.contact_unhide_successfully),Toast.LENGTH_SHORT).show()
//                    val intent2 = Intent("MainActivityReceiver")
//                    sendBroadcast(intent2)
                }
            }

        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun addContact(given_name: String, mobile: String, mContactImageUri: String?) {
        val contact = ArrayList<ContentProviderOperation>()

        var imageUri: Uri?
        try {
            imageUri = Uri.parse(mContactImageUri)
            if (imageUri == null) {
                imageUri = null
            }
        } catch (e: java.lang.Exception) {
            imageUri = null
        }


        contact.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())

        // first and last names
        contact.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.RawContacts.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.RawContacts.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
            .withValue(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, given_name).build())

        // Contact No Mobile
        contact.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.RawContacts.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, mobile)
            .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build())

        if (imageUri != null) {
            Log.e(mTAG, "addcontact : imageUri : $imageUri")
            var imgByte: ByteArray? = imageUriToBytes(imageUri)
            Log.e(mTAG, "addcontact : imgByte : $imgByte")
            try {
                val mBitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)

                val stream = ByteArrayOutputStream()
                if (mBitmap != null) {    // If an image is selected successfully
                    mBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                    // Adding insert operation to operations list
                    // to insert Photo in the table ContactsContract.Data
                    contact.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.RawContacts.Data.RAW_CONTACT_ID, 0)
//                            .withValue(ContactsContract.Data.IS_SUPER_PRIMARY, 1)
                            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.Photo.PHOTO, stream.toByteArray())
                            .build()
                    )
                    try {
                        stream.flush()
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }

            } catch (e: java.lang.Exception) {
                Log.e(mTAG, "addcontact: $e")
            }


        }

        try {
            val results = contentResolver.applyBatch(ContactsContract.AUTHORITY, contact)
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    fun imageUriToBytes(imageUri: Uri): ByteArray? {
        var bmp: Bitmap
        var bos: ByteArrayOutputStream = ByteArrayOutputStream()
        try {
            bmp = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, bos)
            return bos.toByteArray()

        } catch (e: java.lang.Exception) {
            return null
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        binding.etSearchApk.clearFocus()
        hideKeyboard(applicationContext, binding.etSearchApk)
        binding.etSearchApk.setText("")

        if (HideContactList.size != 0) binding.rvContact!!.stopScroll()
        HideContactList.clear()
        SharedPrefsConstant.savePref(mContext,"IsFromHideActivity",true)
//        startActivity(Intent(mContext,ContactMainActivity::class.java).putExtra("IsFromHideActivity",true))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    override fun onPause() {
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
        Log.e(mTAG, "onResume: ")
        binding.etSearchApk.setText("")
    }

    override fun onDestroy() {
        super.onDestroy()
        HideContactList.clear()
        ShareConstants.hide_activity = false
        if (mScreenReceiver != null) {
            unregisterReceiver(mScreenReceiver)
        }
    }


    override fun initialize() {
    }

    override fun lockEnable() {
    }
}