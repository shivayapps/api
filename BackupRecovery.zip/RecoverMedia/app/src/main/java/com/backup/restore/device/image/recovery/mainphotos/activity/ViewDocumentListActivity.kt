package com.backup.restore.device.image.recovery.mainphotos.activity


import android.app.*
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainphotos.recoverdadapter.OtherRecoveredAdapter
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.*
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.*
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.DocumentArray
//import com.example.app.ads.helper.GiftIconHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityViewDocumentListBinding
import java.io.File
import java.util.*

class ViewDocumentListActivity : MyCommonBaseActivity() {

    var mTAG: String = "ViewRecoverableImageList"

    var mGetRecoverableImage: AsyncTask<*, *, *>? = null
    private var mRecoverableImageAdapter: OtherRecoveredAdapter? = null

    private var moImageLists: ArrayList<File> = ArrayList()
    private var isRecover = false
    var mFolderPath: String? = null
    private var mSavePath: String? = null

    var mIsDateClick = true
    var mIsSizeClick = true
    var mClGift: ConstraintLayout? = null


    lateinit var binding:ActivityViewDocumentListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_view_document_list)
        binding= ActivityViewDocumentListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(ViewDocumentListActivity::class.simpleName!!)
    }

    override fun getContext(): AppCompatActivity {
        return this@ViewDocumentListActivity
    }

    override fun initData() {
        mClGift = findViewById(R.id.cl_gift)
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            GiftIconHelper.loadGiftAd(
//                fContext = mContext,
//                fivGiftIcon = findViewById(R.id.main_la_gift),
//                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//            )
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()
//        } else {
//            binding.adview.visibility = View.GONE
//        }
//        stopServiceMethod()
        binding.scanImage!!.setHasFixedSize(true)
        binding.scanImage!!.isNestedScrollingEnabled = false

        isManualHiddenClick = false

        binding.ivSpan.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        binding.tvHeader.text = intent.getStringExtra("folderName")
        binding.tvHeader.isSelected=true

        mFolderPath = intent.getStringExtra("folderPath")
        mRootPath = Environment.getExternalStorageDirectory().toString()
        mSavePath = "$mRootPath/Backup And Recovery/Document/"

//        mRecoverableImageAdapter = SimpleOtherAdapter(binding.scanImage, mContext, moImageLists)
        mRecoverableImageAdapter = OtherRecoveredAdapter(this@ViewDocumentListActivity, moImageLists, binding.scanImage, binding.tvPhoto, ImageView(mContext),"Documenr",false)
        binding.scanImage!!.adapter = mRecoverableImageAdapter

        Log.e("TAG", "Root : $mSavePath")
        mGetRecoverableImage =
            GetRecoverableImage().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    private fun startServiceMethod() {
        try {
            SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", false)
        } catch (e: java.lang.Exception) {
            Log.e("mTAG", "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }

    private fun stopServiceMethod() {
        try {
            SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", true)
        } catch (e: java.lang.Exception) {
            Log.e("mTAG", "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }

    override fun initActions() {
        binding.ivBack!!.setOnClickListener {
            onBackPressed()
        }
        binding.ivSpan.visibility=View.GONE
        binding.ivSpan.setOnClickListener {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            setSpanCount()
        }

        binding.llDateWise.setOnClickListener {
            if (moImageLists.isNotEmpty()) {
                binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                binding.tvDate.setTextColor(resources.getColor(R.color.colorAccent))
                if (mIsDateClick) {
                    Collections.sort(moImageLists, dateComparatorFile())
                    mIsDateClick = false
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                } else {
                    Collections.sort(moImageLists, dateComparatorReversFile())
                    mIsDateClick = true
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down))
                }
                mIsSizeClick = true
                mRecoverableImageAdapter!!.notifyDataSetChanged()
            }
        }
        binding.llSizeWise.setOnClickListener {
            if (moImageLists.isNotEmpty()) {
                binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                binding.tvDate.setTextColor(resources.getColor(R.color.filter_text_color))
                binding.tvSize.setTextColor(resources.getColor(R.color.colorAccent))
                if (mIsSizeClick) {
                    Collections.sort(moImageLists, sizeComparatorFile())
                    mIsSizeClick = false
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                } else {
                    Collections.sort(moImageLists, sizeComparatorReversFile())
                    mIsSizeClick = true
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down))
                }
                mIsDateClick = true
                mRecoverableImageAdapter!!.notifyDataSetChanged()
            }
        }
    }

    private inner class GetRecoverableImage : AsyncTask<Void?, String?, String?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            try {

                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setCancelable(false)
                dialog.setContentView(R.layout.dialog_progress)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )

                dialog.findViewById<TextView>(R.id.permission).text =
                    getString(R.string.label_please_wait)
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.scanning_pictures)
                dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
                    if (mGetRecoverableImage != null) {
                        mGetRecoverableImage!!.cancel(true)
                    }
                }

                binding.lottieAnim.visibility = View.VISIBLE
                binding.ivSpan.alpha = 0.5F
                binding.ivSpan.isEnabled = false
                if (!dialog.isShowing) {
//                    dialog.show()
//                    MyApplication.isDialogOpen = true
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        override fun doInBackground(vararg voids: Void?): String? {
            moImageLists.clear()
            Log.e(mTAG, "doInBackground:::::::::: root $mFolderPath")
            moImageLists = createGridItems(mFolderPath, dialog)
            return mFolderPath
        }

        override fun onPostExecute(mFolderPath: String?) {

            if (isCancelled) {
                runOnUiThread {
                    binding.tvPhoto.visibility = View.VISIBLE
                    binding.scanImage!!.visibility = View.GONE

                }
            }

            Handler(Looper.getMainLooper()).post {
                try {
                    if (moImageLists.isEmpty()) {
                        binding.tvPhoto.visibility = View.VISIBLE
                        binding.scanImage!!.visibility = View.GONE
                        binding.ivSpan.alpha = 0.5F
                        binding.ivSpan.isEnabled = false
                        binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                        binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                        binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                        binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                        binding.tvDate.setTextColor(resources.getColor(R.color.filter_text_color))
                        binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                        finish()
                    } else {
                        binding.scanImage!!.visibility = View.VISIBLE
                        binding.tvPhoto.visibility = View.GONE
                        binding.ivSpan.alpha = 1F
                        binding.ivSpan.isEnabled = true
                        mIsDateClick = true
                        binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                        binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                        binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                        binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                        binding.tvDate.setTextColor(resources.getColor(R.color.colorPrimary))
                        binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                        binding.scanImage!!.layoutManager = GridLayoutManager(mContext, 1)
                        Collections.sort(moImageLists, dateComparatorFile())
//                    mRecoverableImageAdapter!!.runLayoutAnimation()
                    }

                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        try {
                            binding.lottieAnim.visibility = View.GONE
                            binding.ivSpan.alpha = 1F
                            binding.ivSpan.isEnabled = true
                            if (dialog != null && dialog.isShowing) {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false

                            }
                        } catch (e: Exception) {
//                            mContext.addEvent(e.message!!)
                        }
                    }, 500)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    var mNotificationManager: NotificationManager? = null
    var isBackground = false
    var isBackPressed = false
    companion object {
        var isAsyncRecover = false
    }

    private fun createGridItems(
        directoryPath: String?,
        moProgressDialog: Dialog?
    ): ArrayList<File> {
        val files = File(directoryPath!!).listFiles()
        if (files != null) {
            for (file in files) {
                if (file.isDirectory) {
//                    createGridItems(file.path, moProgressDialog)
                } else {
                    val filePath = file.absolutePath
                    val lExtension = getExtension(filePath)
//                    val lImageExtensionList = HashSet(listOf(ImageArray))
                    val isExtensionMatches = DocumentArray.contains(lExtension) && filePath.endsWith(lExtension)
                    if (isExtensionMatches && file.length().toString() != "0") {
                        if (filePath.contains("/.")) {
                        }else{
//                            val loImageList = RecoverableImageModel(
//                                filePath,
//                                false,
//                                File(filePath).lastModified(),
//                                File(filePath).length().toInt()
//                            )
                        moImageLists.add(File(filePath))
                            runOnUiThread {
                                Handler(Looper.getMainLooper()).post {
                                    Log.e(mTAG, "gridRecoverableAlbumImage: " + moImageLists.size)
                                    mRecoverableImageAdapter!!.notifyDataSetChanged()
                                }
                            }
                        }
                    }
                }
                if (mGetRecoverableImage != null) {
                    if (mGetRecoverableImage!!.isCancelled) {
                        runOnUiThread {
                            moProgressDialog!!.cancel()
                            MyApplication.isDialogOpen = false
                            finish()
                            overridePendingTransition(
                                android.R.anim.fade_in,
                                android.R.anim.fade_out
                            )
                        }
                        break
                    }
                }
            }
        }
        return moImageLists
    }

    private fun setSpanCount() {
        var mCurrentSpanCount = mContext.getGridCount()
        mCurrentSpanCount = if (mCurrentSpanCount == SPAN_COUNT_THREE) {
            SPAN_COUNT_TWO
        } else {
            SPAN_COUNT_THREE
        }
        mContext.saveGridCount(mCurrentSpanCount)
        binding.ivSpan.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        spanCount()
    }

    fun spanCount() {
        if (mRecoverableImageAdapter != null) {
            val lCurrentSpanCount = 1
            if (binding.scanImage!!.itemDecorationCount > 0) {
                binding.scanImage!!.removeItemDecorationAt(0)
            }
            binding.scanImage!!.layoutManager = GridLayoutManager(mContext, lCurrentSpanCount)
            mRecoverableImageAdapter!!.notifyItemRangeChanged(0, lCurrentSpanCount)
        }
    }

    public override fun onPause() {
        super.onPause()
//        if (isRecover) {
//            if (mRecoverableImageAdapter!!.getSelectedCounted() != 0) {
//                AsyncTaskRunner().cancel(true)
//                Log.e(mTAG, "onPause: AsyncTask Cancel")
//            }
//        }
    }

    public override fun onResume() {
        super.onResume()
        changeLanguage()
        if (isRecover) {
            Log.e(mTAG, "onResume: new Recover ")
        }
    }

    override fun onBackPressed() {
        startServiceMethod()
        isBackPressed=true
        isBackground=true
        if(mGetRecoverableImage!=null) {
            if(mGetRecoverableImage?.status==AsyncTask.Status.RUNNING) {
                mGetRecoverableImage?.cancel(true)
            }
        }
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}