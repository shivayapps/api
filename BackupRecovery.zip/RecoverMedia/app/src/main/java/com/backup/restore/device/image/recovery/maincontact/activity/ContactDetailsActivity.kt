package com.backup.restore.device.image.recovery.maincontact.activity

import android.app.Dialog
import android.content.ContentUris
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.ContactsContract
import android.text.Html
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.amulyakhare.textdrawable.TextDrawable
import com.amulyakhare.textdrawable.util.ColorGenerator
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.bumptech.glide.Glide
//import com.example.app.ads.helper.GiftIconHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityContactDetailsBinding
import com.example.jdrodi.utilities.camelCaseString
import java.util.*


@Suppress("DEPRECATION")
class ContactDetailsActivity : MyCommonBaseActivity() {

    val mTAG: String = javaClass.simpleName
    private var mDbHelper: DBAdapter? = null
    private var mContactId: String? = null
//    private var mBitmap: Bitmap? = null

    var dialog: Dialog? = null
    private val mColorGenerator = ColorGenerator.MATERIAL
    private var mDrawableBuilder: TextDrawable.IBuilder? = null


    companion object {
        var isModify = false
    }

    lateinit var binding: ActivityContactDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_contact_details)
        binding=ActivityContactDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)


        Log.e(mTAG, "onCreate: ")

    }

    override fun getContext(): AppCompatActivity {
        return this@ContactDetailsActivity
    }

    override fun initData() {
        mDbHelper = DBAdapter(mContext)

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
////            GiftIconHelper.loadGiftAd(
////                fContext = mContext,
////                fivGiftIcon = findViewById(R.id.main_la_gift),
////                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
////            )
//        }
        mContactId = ShareConstants.user_id
        if (ShareConstants.fav_activity) {
            binding.llEdit!!.visibility = View.GONE
            binding.llVisibility!!.visibility = View.GONE
        }
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()
//            binding.llGift.visibility = View.VISIBLE
//        }else{
//            binding.adview.visibility = View.GONE
//            binding.llGift.visibility = View.INVISIBLE
//        }
    }

    override fun initActions() {

        binding.llCall!!.setOnClickListener(this)
        binding.llEdit!!.setOnClickListener(this)
        binding.llVisibility!!.setOnClickListener(this)
        binding.ivFav!!.setOnClickListener(this)
        binding.ivUnFav!!.setOnClickListener(this)
        binding.messageBtn!!.setOnClickListener(this)
        binding.ivBack!!.setOnClickListener(this)
    }

//    fun fetchContactIdFromPhoneNumber(phoneNumber: String?): String {
//        var contactId = ""
//        try {
//            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber))
//
//            val cursor = contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID), null, null, null)
//            if (cursor!!.moveToFirst()) {
//                do {
//                    contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup._ID))
//                } while (cursor.moveToNext())
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        return contactId
//    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

        if (view == binding.llCall) {
            isModify = true
            MyApplication.isInternalCall = true
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:" + ShareConstants.user_number)
            startActivity(intent)
        } else if (view == binding.messageBtn) {
            isModify = true
            MyApplication.isInternalCall = true
            val intent = Intent("android.intent.action.VIEW")
            intent.data = Uri.parse("sms:" + ShareConstants.user_number)
            startActivity(intent)
        } else if (view == binding.llEdit) {
            try {
                isModify = true
                MyApplication.isInternalCall = true
                val j = mContactId!!.toLong()
                val intent = Intent("android.intent.action.EDIT")
                val person = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, j)
                intent.data = person
                intent.putExtra("finishActivityOnSaveCompleted", true)
                startActivity(intent)
            } catch (e: Exception) {
                Log.e(mTAG, "onClick: exception :$e")
                e.printStackTrace()
            }
        }else if (view == binding.llVisibility) {

            hideContactMethod()

        }  else if (view == binding.llFav) {
            isModify = true
        } else if (view == binding.ivUnFav) {
            binding.ivUnFav!!.visibility = View.GONE
            binding.ivFav!!.visibility = View.VISIBLE
            mDbHelper!!.saveFavoriteContact(ShareConstants.user_name, ShareConstants.user_number, ShareConstants.user_id)
            if (ShareConstants.fav_activity) {
                val contactModel = ContactModel()
                contactModel.mContactName = ShareConstants.user_name
                contactModel.mNumber = ShareConstants.user_number
//                contactModel.mContactPhoto = mBitmap
                contactModel.mContactImageUri = ShareConstants.contact_image_uri
                FavoriteActivity.FavContactList.add(contactModel)
            }
        } else if (view == binding.ivFav) {
            binding.ivUnFav!!.visibility = View.VISIBLE
            binding.ivFav!!.visibility = View.GONE
            unFavorite()
        } else if (view == binding.ivBack) {
            onBackPressed()
        }
    }

    private fun hideContactMethod() {

        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_hide_contact)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val first = getString(R.string.sure_to_hide_contact)
        val next = "<font color='#EE0000'>" + getString(R.string.note) + "</font>"
        val last = getString(R.string.remove_from_fav)
        dialog.findViewById<TextView>(R.id.permission_text).text = Html.fromHtml("$first<br />$next$last")

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false

            mDbHelper!!.deleteFavContactDetails(ShareConstants.user_id)
            val query = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null as Array<String?>?, "_id = ? ", arrayOf(mContactId), null as String?)
            if (query != null && query.count > 0) {
                while (query.moveToNext()) {
                    try {
                        contentResolver.delete(
                            Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, query.getString(query.getColumnIndex("lookup"))),
                            null as String?,
                            null as Array<String?>?
                        )
                    } catch (e: Exception) {
                        Log.e(mTAG, "onClick: " + e.message)
                    }
                }
            }
            query?.close()

            mDbHelper!!.saveHideContact(ShareConstants.user_name, ShareConstants.user_number, ShareConstants.user_id,ShareConstants.contact_image_uri)
            val contactModel = ContactModel()
            contactModel.mContactName = ShareConstants.user_name
            contactModel.mNumber = ShareConstants.user_number
//            contactModel.mContactPhoto = mBitmap
            contactModel.mContactImageUri = ShareConstants.contact_image_uri
            HideContactActivity.HideContactList.add(contactModel)
            Toast.makeText(mContext,getString(R.string.contact_hide_successfully),Toast.LENGTH_SHORT).show()

            onBackPressed()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true

    }

    override fun onBackPressed() {
//        super.onBackPressed()
        if(intent.getStringExtra("IsFromContact") == "Fav"){
            super.onBackPressed()
        }else {
            SharedPrefsConstant.savePref(mContext,"IsFromHideActivity",true)
            super.onBackPressed()
//            startActivity(Intent(mContext, ContactMainActivity::class.java)/*.putExtra("IsFromHideActivity", true)*/)
        }
        finish()
        ContactMainActivity.isShowDialogContact = false
        FavoriteActivity.isShowDialogFav = false
        HideContactActivity.isShowDialogHide = false
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun unFavorite() {
        dialog = Dialog(mContext)
        dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog!!.setCancelable(false)
        dialog!!.setContentView(R.layout.dialog_confirmation)
        dialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog!!.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog!!.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_favorite))
        dialog!!.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_unfav)
        dialog!!.findViewById<TextView>(R.id.permission_text).text = getString(R.string.sure_to_unfavorite)
        dialog!!.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog!!.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog!!.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog!!.cancel()
            mDbHelper!!.deleteFavContactDetails(ShareConstants.user_id)
            if (ShareConstants.fav_activity) {
                if (FavoriteActivity.FavContactList.size != 0) {
                    FavoriteActivity.FavContactList.removeAt(ShareConstants.fav_position)
                }
            }
            Toast.makeText(mContext,getString(R.string.remove_from_fav_successfully),Toast.LENGTH_SHORT).show()
            isModify = true
        }
        dialog!!.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog!!.cancel()
            binding.ivUnFav!!.visibility = View.GONE
            binding.ivFav!!.visibility = View.VISIBLE
        }
        dialog!!.show()
    }

    private fun setData() {
        try {
            updateData()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e(mTAG, "setData: exception from update data :$e")
        }
        val favCursor = mDbHelper!!.favData
        try {
            if (favCursor.count != 0) {
                if (favCursor.moveToFirst()) {
                    do {
                        if (ShareConstants.user_number == favCursor.getString(favCursor.getColumnIndex(DBAdapter.KEY_NUMBER))
                            && ShareConstants.user_name == favCursor!!.getString(favCursor.getColumnIndex(DBAdapter.KEY_NAME))) {
                            binding.ivUnFav!!.visibility = View.GONE
                            binding.ivFav!!.visibility = View.VISIBLE
                        }
                    } while (favCursor.moveToNext())
                }
            }
        } catch (e: Exception) {
            Log.e(mTAG, "setData: exception :$e")
            e.printStackTrace()
        }
    }

    private fun updateData() {
        mContactId = ShareConstants.user_id
        if (mContactId != "") {
            val cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(mContactId), null)
            while (cursor!!.moveToNext()) {
                val name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY))
                val number = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.Data.DATA1))
                val photoUri = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.PHOTO_URI))
                binding.nameAdd!!.text = camelCaseString(name)
                ShareConstants.user_name = name
                binding.noAdd!!.text = number
                ShareConstants.user_number = number
                ShareConstants.contact_image_uri = photoUri
                if (photoUri != null) {

                    Glide.with(mContext).load(photoUri).placeholder(R.drawable.no_user_contact_image).into(binding.picAdd)
//                    try {
//                        mBitmap = MediaStore.Images.Media.getBitmap(contentResolver, Uri.parse(photoUri))
//                        if(mBitmap !=null) {
//                            picAdd!!.setImageBitmap(mBitmap)
//                        }
//                    } catch (e: IOException) {
//                        e.printStackTrace()
//                    }
                } else {
                    if (name!!.isNotEmpty() && !TextUtils.isDigitsOnly(name.substring(0, 1))) {

                        val mTypeface: Typeface = Typeface.createFromAsset(assets, "app_font/firasans_medium.ttf")

                        mDrawableBuilder = TextDrawable.builder()
                            .beginConfig()
                            .bold()
                            .useFont(mTypeface)
                            .height(50)
                            .width(50)
                            .endConfig()
                            .roundRect(2)

                        val drawable = mDrawableBuilder!!.build(name!![0].toString().capitalize(), mColorGenerator.getColor(name))

                        binding.picAdd.setImageDrawable(drawable)
                    } else {
                        binding.picAdd.setImageDrawable(mContext.resources.getDrawable(R.drawable.no_user_contact_image))
                    }
                }
                if (binding.ivFav!!.visibility == View.VISIBLE) {
                    mDbHelper!!.updateDetails(name, number, ShareConstants.user_id)
                    val contactModel = ContactModel()
                    contactModel.mContactName = name
                    contactModel.mContactImageUri = photoUri
                    contactModel.mNumber = number
//                    if (mBitmap != null) contactModel.mContactPhoto = mBitmap
                    if (ContactMainActivity.MainContactList.size != 0) {
                        ContactMainActivity.MainContactList[ShareConstants.user_position] = contactModel
                    }
                    if (FavoriteActivity.favActivity != null) {
                        if (FavoriteActivity.FavContactList.size != 0) {
                            FavoriteActivity.FavContactList[ShareConstants.fav_position] = contactModel
                        }
                    }
                    if(HideContactActivity.hideContactActivity != null){
                        if(HideContactActivity.HideContactList.size != 0){
                            HideContactActivity.HideContactList[ShareConstants.hide_position] =contactModel
                        }
                    }
                }
            }
            if (cursor.count != 0) {
            } else {
                onBackPressed()
            }
            cursor.close()
        }
    }

    private fun getPhotoUri(photo: String?): Uri? {
        try {
            val cur: Cursor = mContext.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + "=" + photo + " AND " + ContactsContract.Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE + "'",
                null,
                null
            )!!
            if (cur != null) {
                if (!cur.moveToFirst()) {
                    return null // no photo
                }
            } else {
                return null // error in cursor process
            }
        } catch (e: Exception) {
            Log.e(mTAG, "getPhotoUri: exception :$e")
            e.printStackTrace()
            return null
        }
        val person: Uri =
            ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, photo!!.toLong())
        return Uri.withAppendedPath(person, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY)
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
        Log.e(mTAG, "onResume")
        if (dialog != null) {
            if (dialog!!.isShowing) {
                binding.ivUnFav!!.visibility = View.VISIBLE
                binding.ivFav!!.visibility = View.GONE
            }
        }
        setData()

        if (isModify) {
            Log.e(mTAG, "onResume: $isModify")
            isModify = false
            val intent2 = Intent("MainActivityReceiver")
            sendBroadcast(intent2)
            val intent3 = Intent("FavoriteActivityCheck")
            sendBroadcast(intent3)
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        ShareConstants.fav_activity = false
    }
}