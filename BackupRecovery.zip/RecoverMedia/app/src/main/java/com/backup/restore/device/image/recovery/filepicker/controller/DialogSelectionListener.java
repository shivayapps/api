package com.backup.restore.device.image.recovery.filepicker.controller;

/**
 * @author akshay sunil masram
 */
public interface DialogSelectionListener {
    void onSelectedFilePaths(String[] files);
}