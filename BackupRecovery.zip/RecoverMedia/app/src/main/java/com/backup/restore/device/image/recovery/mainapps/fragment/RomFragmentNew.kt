package com.backup.restore.device.image.recovery.mainapps.fragment

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import java.io.File

/**
 * A placeholder fragment containing a simple view.
 */
class RomFragmentNew : Fragment() {
    var rootView: View? = null

    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        @JvmStatic
        fun newInstance(): RomFragmentNew {
            val fragment = RomFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
//        rootView = inflater.inflate(R.layout.fragment_rom, container, false)
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()

//        iv_share?.setOnClickListener {
//            context?.shareApp()
//        }

        getRomInfo()

//        if (AdsManager(requireActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(requireActivity())) {
            NativeAdHelper(requireActivity(),rootView?.findViewById(R.id.adview)!!, NativeLayoutType.NativeMedium).loadAd()
//        } else {
//            rootView?.findViewById<FrameLayout>(R.id.adview)?.visibility = View.GONE
//        }

//        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
//        scrollMain.scrollTo(0,0)
        return rootView
    }

    private fun getRomInfo(): Unit {
        ivType!!.setImageResource(R.drawable.ic_rom)
        tvTitle!!.text = getString(R.string.rom_information)

        var freeROM = "" + getFreeROM().toUpperCase()
        var useROM = "" + getUsedROM().toUpperCase()
        var totalROM = "" + getTotalROM().toUpperCase()


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            freeROM = "" + getAvailableInternalMemorySize()!!.toUpperCase()
            useROM = "" + getUsedMemory()!!.toUpperCase()
            totalROM = "" + getTotalInternalMemorySize()!!.toUpperCase()
        }

        var freeROM1 = getFreeROM(false).toLong()
        var useROM1 = getUsedROM(false).toLong()
        var totalROM1 = getTotalROM(false).toLong()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            useROM1 = getUsedMemory(false)!!.toLong()
            totalROM1 = getTotalInternalMemorySize(false)!!.toLong()
        }
        var percentage=(useROM1 * 100)/totalROM1
        if(percentage<=0) percentage=0

        tvSubTitle?.text = totalROM
        tvTitle!!.isSelected=true
        tvSubTitle!!.isSelected=true

//        tv_percentage?.setShadowLayer(1.5f, -1F, 1F, Color.BLACK);
//        tv_percentage?.background?.setLevel(percentage.toInt()*100)

        val parents = ArrayList<ParentModel>()
        parents.add(ParentModel(resources.getString(R.string.internal_storage),ArrayList<FeaturesHW>()))
        val lists: ArrayList<FeaturesHW> = parents.get(0).lists
        lists.add(FeaturesHW(getString(R.string.free_rom), "${getProperText(freeROM)}"))
        lists.add(FeaturesHW(getString(R.string.used_rom), "${getProperText(useROM)}"))
        lists.add(FeaturesHW(getString(R.string.total_rom), "${getProperText(totalROM)}"))
        lists.add(FeaturesHW(getString(R.string.percentage), "$percentage %", percentage))

        if (Utils.getExternalMounts().size > 0) {

            val dirs: Array<File> = context?.let { ContextCompat.getExternalFilesDirs(it, null) }!!
            /** External Memory usage */
            var totalExternalValue = getTotalSdCard(dirs,false).toLong()
            val freeExternalValue = getFreeSdCard(dirs,false).toLong()
            val usedExternalValue = getUsedSdCard(dirs,false).toLong()

//            tv_free_rom_ex?.text = "" + getFreeSdCard(dirs)
//            tv_use_rom_ex?.text = "" + getUsedSdCard(dirs)
//            tv_total_rom_ex?.text = "" + getTotalSdCard(dirs)

            if(totalExternalValue.equals(0)) totalExternalValue=1
            var externalPercentage=(usedExternalValue * 100)/totalExternalValue
            if(externalPercentage<=0) externalPercentage=0

//            tv_percentage_ex?.setShadowLayer(1.5f, -1F, 1F, Color.BLACK);
//            tv_percentage_ex?.background?.setLevel(percentage.toInt()*100)

            parents.add(ParentModel(resources.getString(R.string.external_storage),ArrayList<FeaturesHW>()))
            val lists1: ArrayList<FeaturesHW> = parents.get(0).lists
            lists1.add(FeaturesHW(getString(R.string.free_rom), "${getProperText(getFreeSdCard(dirs))}"))
            lists1.add(FeaturesHW(getString(R.string.used_rom), "${getProperText(getUsedSdCard(dirs))}"))
            lists1.add(FeaturesHW(getString(R.string.total_rom), "${getProperText(getTotalSdCard(dirs))}"))
            lists1.add(FeaturesHW(getString(R.string.percentage), "$externalPercentage %", externalPercentage))
        }

        val adapter = ParentAdapter(parents, requireContext())
        rvFeatureList?.adapter = adapter

        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        Handler(Looper.getMainLooper()).postDelayed({
            scrollMain.scrollTo(0,0)
        },100)
    }

    private fun getProperText(textValue: String?) : String {
        if(textValue.isNullOrEmpty()) {
            return getString(R.string.unavailable)
        } else return textValue
    }
    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

}