package com.backup.restore.device.image.recovery.mainapps.fragment

import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.getFreeRAM
import com.backup.restore.device.image.recovery.utilities.getTotalRAM
import com.backup.restore.device.image.recovery.utilities.getUsedRAM
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper

/**
 * A placeholder fragment containing a simple view.
 */
class FeatureFragmentNew : Fragment() {
    var rootView: View? = null

    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null
    var packageManager: PackageManager? = null

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        @JvmStatic
        fun newInstance(): FeatureFragmentNew {
            val fragment = FeatureFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()

        packageManager = activity?.packageManager

        checkAvailableFeatures()

//        if (AdsManager(requireActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(requireActivity())) {

            NativeAdHelper(requireActivity(),rootView?.findViewById(R.id.adview)!!, NativeLayoutType.NativeMedium).loadAd()
//        } else {
//            rootView?.findViewById<FrameLayout>(R.id.adview)?.visibility = View.GONE
//        }

//        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
//        scrollMain.scrollTo(0,0)
        return rootView
    }

    private fun checkAvailableFeatures(): LinkedHashMap<String, Boolean> {

        val allFeatures = linkedMapOf<String, Boolean>(

            "COMPASS" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_COMPASS),
            "BLUETOOTH" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH),
            "ANY CAMERA" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY),
            "CAMERA WITH FLASH" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH),
            "FRONT SELFIE CAMERA" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT),
            "NETWORK CARD" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_ETHERNET),
            "FACE BIOMETRIC HARDWARE" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_FACE),
            "ADVANCED SENSORS" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_HIFI_SENSORS),
            "HOMESCREEN THEMING SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_HOME_SCREEN),
            "EYE BIOMETRIC HARDWARE" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_IRIS),
            "LIVE WALLPAPER SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_LIVE_WALLPAPER),
            "GPS SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS),
            "MICROPHONE" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_MICROPHONE),
            "NFC SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_NFC),
            "PICTURE IN PICTURE MODE SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE),
            "LANDSCAPE ORIENTATION SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SCREEN_LANDSCAPE),
            "PORTRAIT ORIENTATION SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SCREEN_PORTRAIT),
            "ACCELEROMETER" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_ACCELEROMETER),
            "TEMPERATURE SENSOR" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_AMBIENT_TEMPERATURE),
            "BAROMETER SENSOR" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_BAROMETER),
            "COMPASS" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_COMPASS),
            "GYROSCOPE" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_GYROSCOPE),
            "HEART RATE SENSOR" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_HEART_RATE),
            "LIGHT SENSOR" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_LIGHT),
            "PROXIMITY SENSOR" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_PROXIMITY),
            "HUMIDITY SENSOR" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SENSOR_RELATIVE_HUMIDITY),
            "TELEPHONE SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_TELEPHONY),
            "CDMA TELEPHONE SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_TELEPHONY_CDMA),
            "GSM TELEPHONE SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_TELEPHONY_GSM),
            "TOUCHSCREEN" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN),
            "TOUCHSCREEN MULTITOUCH SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH),
            "AUDIO LOW-LATENCY" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY),
            "AUDIO OUTPUT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_AUDIO_OUTPUT),
            "AUDIO PRINTING" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_PRINTING),
            "APP WIDGETS" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_APP_WIDGETS),
            "SIP" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SIP),
            "SIP-based VOIP" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_SIP_VOIP),
            "USB HOST" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_USB_HOST),
            "USB SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_USB_ACCESSORY),
            "WEBVIEW SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_WEBVIEW),
            "WIFI SUPPORT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_WIFI),
            "WIFI DIRECT" to packageManager!!.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT),
        )

        return allFeatures

    }

    private fun getProperText(textValue: String?) : String {
        if(textValue.isNullOrEmpty()) {
            return getString(R.string.unavailable)
        } else return textValue
    }

    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

}