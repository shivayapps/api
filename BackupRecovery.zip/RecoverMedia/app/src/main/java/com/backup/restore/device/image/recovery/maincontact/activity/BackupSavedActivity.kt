package com.backup.restore.device.image.recovery.maincontact.activity

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.*
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.SystemClock
import android.provider.Contacts
import android.provider.ContactsContract
import android.provider.MediaStore
import android.util.Log
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.adconfig.AdsConfig
import com.adconfig.AdsConfig.Companion.showInterstitialAd
import com.backup.restore.device.image.recovery.BuildConfig
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.inapp.InAppActivity
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.maincontact.model.RestoreModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.mLastClickTime
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.custom.HoloCircleSeekBar
import com.backup.restore.device.image.recovery.utilities.getShareMessage
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.utils.isInterstitialAdShow
import com.backup.restore.device.image.recovery.databinding.ActivityBackupSavedBinding
import ezvcard.Ezvcard
import ezvcard.VCard
import java.io.File
import java.util.*

class BackupSavedActivity : AppCompatActivity(), View.OnClickListener {

    val mTAG : String = javaClass.simpleName
    var list: File? = null
    private val mContactList = ArrayList<RestoreModel>()
    var mGetDataAsyncTask: AsyncTask<*, *, *>? = null
    var mContext: BackupSavedActivity = this
//    private var rewardedAd: RewardedAd? = null
//    private var isRewardVideoAdLoaded: Boolean = false


    lateinit var binding: ActivityBackupSavedBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        changeLanguage()
//        setContentView(R.layout.activity_backup_saved)
        binding=ActivityBackupSavedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(javaClass.simpleName)
        mContext = this@BackupSavedActivity

        list = File(intent.getStringExtra("list")!!)
        Log.e(mTAG, "onCreate: onPostExecute $list")

        mGetDataAsyncTask = GetDataAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()
//        }else{
//            binding.adview.visibility = View.GONE
//        }
    }

    private fun initView() {

        binding.llShare.setOnClickListener(this)
        binding.llRestore.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)
        setData()
    }

    private fun setData() {
        binding.tvCount!!.text = ShareConstants.count.toString() + " " + getString(R.string.contacts)
        binding.tvDateTime!!.text = ShareConstants.date_time.replace(".vcf", "")
    }

//    private fun createAndLoadRewardedAd() {
//
//        RewardedAd.load(this, resources.getString(R.string.rewarded_ad_id), AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
//            override fun onAdLoaded(p0: RewardedAd) {
//                super.onAdLoaded(p0)
//                rewardedAd = p0
//            }
//            override fun onAdFailedToLoad(p0: LoadAdError) {
//                super.onAdFailedToLoad(p0)
//                Log.e("TAG", "onAdFailedToLoad: =>"+p0.message)
//                rewardedAd = null
//            }
//        })
//    }

//    private fun showRewardedAd() {
//        val activityContext: Activity = this@BackupSavedActivity
//        rewardedAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
//
//            override fun onAdDismissedFullScreenContent() {
//                Log.i("TAG", "onAdDismissedFullScreenContent")
//                rewardedAd=null
//                Log.d("TAG", "The rewarded close.")
//            }
//
//            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
//            }
//
//            override fun onAdShowedFullScreenContent() {
//                Log.i("TAG", "onAdShowedFullScreenContent")
//            }
//
//        }
//
//        rewardedAd!!.show(activityContext) {
//            Log.e("TAG", "onFinish: sds=>")
//            SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_CONTACT_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_CONTACT_COUNT) - 1)
//            RestoreContactAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        }
//
//    }

//    private fun dialogUnlockPro() {
//        createAndLoadRewardedAd()
//        val dialog = Dialog(mContext)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_unloack_pro)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
//        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)
//
//        watchVideo.setOnClickListener {
//            if (!NetworkManager.isInternetConnected(mContext)) {
//                Toast.makeText(mContext,getString(R.string.no_internet_access),Toast.LENGTH_SHORT).show()
//                createAndLoadRewardedAd()
//            } else if (rewardedAd != null) {
//                showRewardedAd()
//                dialog.dismiss()
//            } else  {
//                Toast.makeText(mContext,getString(R.string.please_wait_for_ads_loading),Toast.LENGTH_SHORT).show()
//                createAndLoadRewardedAd()
//                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
//            }
//        }
//        purchasePro.setOnClickListener {
//            dialog.dismiss()
//            startActivity(Intent(mContext, InAppActivity::class.java))
//        }
//
//        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
//            dialog.dismiss()
//        }
//        dialog.show()
//    }

//    private fun dialogUnlockPro() {
//        createAndLoadRewardedAd()
//
//        val dialog = Dialog(mContext)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_unloack_pro)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
//        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)
//        watchVideo.alpha = 0.5f
//        watchVideo.isClickable = false
//        isRewardVideoAdLoaded = false
//
//
//        val activityContext: Activity = this@BackupSavedActivity
//        InterstitialRewardHelper.loadRewardedInterstitialAd(activityContext)
//        isShowRewardedInterstitialAd(
//            onStartToLoadRewardedInterstitialAd = {
//
//            },
//            onUserEarnedReward = {
//                Log.e("TAG", "onFinish: sds=>")
//                SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_CONTACT_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_CONTACT_COUNT) - 1)
//                RestoreContactAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//            },
//            onAdLoaded = {
//                watchVideo.alpha = 1.0f
//                watchVideo.isClickable = true
//                isRewardVideoAdLoaded = true
//            }
//        )
//
//
//        watchVideo.setOnClickListener {
//            if (!NetworkManager.isInternetConnected(mContext)) {
//                Toast.makeText(mContext,getString(R.string.no_internet_access),Toast.LENGTH_SHORT).show()
//                createAndLoadRewardedAd()
//            } else if (isRewardVideoAdLoaded) {
//                showRewardVideoAd()
//                dialog.dismiss()
//            } else  {
//                Toast.makeText(mContext,getString(R.string.please_wait_for_ads_loading),Toast.LENGTH_SHORT).show()
//                createAndLoadRewardedAd()
//                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
//            }
//        }
//        purchasePro.setOnClickListener {
//            dialog.dismiss()
//            startActivity(Intent(mContext, InAppActivity::class.java))
//        }
//
//        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
//            dialog.dismiss()
//        }
//        dialog.show()
//    }

    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1200) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        if (v == binding.llRestore) {

            MyApplication.isInternalCall = true
            if (list!!.exists()) {
                if (SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_CONTACT_COUNT) >= 3 ) {
                    //show dialog
                    showInterstitialAd(mContext,{
                        RestoreContactAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                    })
//                    if(mContactList.size!=0) dialogUnlockPro()
//                    else Toast.makeText(this@BackupSavedActivity,getString(R.string.no_file_selected),Toast.LENGTH_SHORT).show()
                } else {
                    RestoreContactAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                }
            } else {
                Toast.makeText(mContext, getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                finish()
            }
        } else if (v == binding.llShare) {
            Log.e(mTAG, "path ========>" + ShareConstants.path)
            MyApplication.isInternalCall = true
            val fileImagePath = FileProvider.getUriForFile(
                mContext, BuildConfig.APPLICATION_ID + ".provider",
                ShareConstants.path
            )
            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "*/*"
            sharingIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))
            sharingIntent.putExtra(Intent.EXTRA_TEXT, mContext.getShareMessage())
            sharingIntent.putExtra(Intent.EXTRA_STREAM, fileImagePath)
            startActivity(Intent.createChooser(sharingIntent, "Share image using"))
        } else if (v == binding.ivBack) {
            onBackPressed()
        }
    }


    private inner class RestoreContactAsyncTask : AsyncTask<String?, String?, String?>() {
        var dialog: AlertDialog? = null
        var holoCircleSeekBar: HoloCircleSeekBar? = null
        var dialogButtonCancel: Button? = null

        override fun onPreExecute() {
            super.onPreExecute()
            val alertDialogBuilder = AlertDialog.Builder(mContext)
            val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val view = inflater.inflate(R.layout.dialog_contacts_backup, null)
            alertDialogBuilder.setView(view)
            alertDialogBuilder.setCancelable(false)
            dialog = alertDialogBuilder.create()
            dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//            dialog?.setOnKeyListener { dialog, keyCode, event ->
//                if(keyCode== KeyEvent.KEYCODE_BACK) {
//                    Log.e(mTAG,"DeleteAllImageVideo:onBack")
//                    if(status==AsyncTask.Status.RUNNING) {
////                        cancel(true)
//                        mContext.onBackPressed()
//                    }
//                }
//                return@setOnKeyListener true
//            }
            dialogButtonCancel=view.findViewById(R.id.dialogButtonCancel)
            dialogButtonCancel?.visibility=View.GONE
            dialogButtonCancel?.setOnClickListener {
                if (status == AsyncTask.Status.RUNNING) {
                    cancel(true)
                }
                dialog?.dismiss()
            }
            val lTvRecoverableFiles = view.findViewById<TextView>(R.id.tv_recoverableFiles)
            lTvRecoverableFiles.text = getString(R.string.restoring_contacts)
            holoCircleSeekBar = view.findViewById(R.id.holoCircleSeekbar)

            dialog!!.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog!!.isShowing) {
                dialog!!.show()
                MyApplication.isDialogOpen = true
            }
        }

        override fun doInBackground(vararg params: String?): String? {
            for (i in mContactList.indices) {
                Log.e(mTAG, "name :=>>>>>>>>>>> " + mContactList[i].name)
                if(mContactList[i].name == null){
                    mContactList[i].name = mContactList[i].number!!
                }
                if(mContactList[i].number != null) {
                    addContact(mContactList[i].name!!, mContactList[i].number!!)
                    publishProgress((i + 1).toString())
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {
                if(dialog!!.isShowing) {
                    dialog!!.cancel()
                }
            }catch (e : Exception){
                e.printStackTrace()
            }

            MyApplication.isDialogOpen = false
//            if (mContactList.size > 0) {
            Toast.makeText(mContext, getString(R.string.restore_successfully), Toast.LENGTH_SHORT).show()
            finish()
            SharedPrefsConstant.save(mContext, ShareConstants.FREE_RECOVER_CONTACT_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_CONTACT_COUNT) + 1)
            SharedPrefsConstant.save(mContext, ShareConstants.RATE_BACKUP_CONTACT_COUNT, SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_BACKUP_CONTACT_COUNT) + 1)
//            }

        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            val parseInt = values[0]!!.toInt()
            holoCircleSeekBar!!.setMax(100)
            val value = parseInt * 100 / mContactList.size
            holoCircleSeekBar!!.setValue(value.toFloat())
        }
    }

    private fun addContact(name: String, phone: String) {
        val values = ContentValues()
        values.put(Contacts.People.NUMBER, phone)
        values.put(Contacts.People.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM)
        values.put(Contacts.People.LABEL, name)
        values.put(Contacts.People.NAME, name)
        val dataUri = contentResolver.insert(Contacts.People.CONTENT_URI, values)
        var updateUri = Uri.withAppendedPath(dataUri, Contacts.People.Phones.CONTENT_DIRECTORY)
        values.clear()
        values.put(Contacts.People.Phones.TYPE, Contacts.People.TYPE_MOBILE)
        values.put(Contacts.People.NUMBER, phone)
        updateUri = contentResolver.insert(updateUri!!, values)
        Log.e("New Contact", "----uri$updateUri")
    }

    private inner class GetDataAsyncTask : AsyncTask<Void?, Void?, Void?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            super.onPreExecute()
            Log.e(mTAG, "onPreExecute: " )

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.getting_contact)
//            dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.contact) + mContactList.size + "/" + ShareConstants.count + " " + getString(R.string.recover)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).setOnClickListener {
                mGetDataAsyncTask!!.cancel(true)
            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
                Log.e(mTAG, "doInBackground:vCards progressDialog!!.show()" )
            }
            mContactList.clear()
        }


        override fun doInBackground(vararg voids: Void?): Void? {
            try {
                mContactList.clear()
//                var reader: VCardReader? = null
                val vcardFile = list
                if (!vcardFile!!.exists()) {
//                    throw RuntimeException("vCard file does not exist: " + ShareConstants.path)
                }
                try {
//                    reader = VCardReader(vcardFile)
                    Log.e(mTAG, "doInBackground: " )
                    val vCards: List<VCard> = Ezvcard.parse(vcardFile).all()

                    for (vCard2 in vCards) {
                        runOnUiThread {
                            Log.e(mTAG, "doInBackground: vcard" + mContactList.size)
//                            dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.contact) + mContactList.size + "/" + vCards.size + " " + getString(R.string.recover)
                            dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.contact) + mContactList.size + "/" + ShareConstants.count.toString() + " " + getString(R.string.recover)
                        }
                        val telePhoneNumbers = vCard2.telephoneNumbers
                        val restoreModel = RestoreModel()
                        if (vCard2.formattedName != null) {
                            restoreModel.name = vCard2.formattedName.value
                        }
                        if (telePhoneNumbers.size != 0) {
                            restoreModel.number = telePhoneNumbers[0].text
                            if (getContactIDFromNumber(telePhoneNumbers[0].text,mContext) != null) {
                                val lContactId = getContactIDFromNumber(telePhoneNumbers[0].text,mContext).toLong()
                                val photo = getPhotoUri(lContactId.toString())
                                restoreModel.imageUri = photo.toString()
                                try {
                                    if (photo != null) {
                                        val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, photo)
                                        restoreModel.bitmap = bitmap
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }

                            mContactList.add(restoreModel)
//                            Log.e(mTAG, "doInBackground: " + mContactList.size)
                        }
                        if(mGetDataAsyncTask != null) {
                            if (mGetDataAsyncTask!!.isCancelled) {
                                runOnUiThread {
                                    Log.e(mTAG, "doInBackground: " + mGetDataAsyncTask!!.isCancelled)
                                    dialog.cancel()
                                    MyApplication.isDialogOpen = false
                                    finish()
                                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                                }
                                break
                            }
                        }
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                    println("ERROR__:$e")
                    Log.e(mTAG, "Exception: ERROR__ " + e.message )
                }
            } catch (e1: Exception) {
                e1.printStackTrace()
                println("ERROR__1:$e1")
                Log.e(mTAG, "Exception: ERROR__1 " + e1.message )
            }
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            dialog.cancel()
            MyApplication.isDialogOpen = false
            initView()
        }
    }

    fun getContactIDFromNumber(contactNumber: String?, context: Context): Int {
        var contactNumber = contactNumber
        contactNumber = Uri.encode(contactNumber)
        var phoneContactID = Random().nextInt()
        val contactLookupCursor = context.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, contactNumber),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID), null, null, null
        )
        while (contactLookupCursor!!.moveToNext()) {
            phoneContactID = contactLookupCursor.getInt(contactLookupCursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup._ID))
        }
        contactLookupCursor.close()
        return phoneContactID
    }

    fun getPhotoUri(photo: String?): Uri? {
        try {
            val cur: Cursor = mContext.contentResolver.query(ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + "=" + photo + " AND " +
                        ContactsContract.Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE + "'",
                null, null)!!
            if (cur != null) {
                if (!cur.moveToFirst()) {
                    return null // no photo
                }
            } else {
                return null // error in cursor process
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
        val person: Uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, photo!!.toLong())
        return Uri.withAppendedPath(person, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY)
    }

//    fun fetchContactIdFromPhoneNumber(phoneNumber: String?): String {
//        var contactId = ""
//        try {
//            val uri = Uri.withAppendedPath(
//                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
//                Uri.encode(phoneNumber)
//            )
//            val cursor = contentResolver.query(
//                uri,
//                arrayOf(
//                    ContactsContract.PhoneLookup.DISPLAY_NAME,
//                    ContactsContract.PhoneLookup._ID
//                ), null, null, null
//            )
//            if (cursor != null) {
//                if (cursor.moveToFirst()) {
//                    do {
//                        contactId =
//                            cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup._ID))
//                    } while (cursor.moveToNext())
//                }
//                cursor.close()
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        return contactId
//    }

//    fun getPhotoUri(contactId: Long): Uri? {
//        val contentResolver = contentResolver
//        try {
//            val cursor = contentResolver.query(
//                ContactsContract.Data.CONTENT_URI,
//                null,
//                ContactsContract.Data.CONTACT_ID
//                        + "="
//                        + contactId
//                        + " AND "
//                        + ContactsContract.Data.MIMETYPE
//                        + "='"
//                        + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE
//                        + "'", null, null
//            )
//            if (cursor != null) {
//                if (!cursor.moveToFirst()) {
//                    return null // no photo
//                }
//            } else {
//                return null // error in recentCallsCursor process
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//            return null
//        }
//        val person = ContentUris.withAppendedId(
//            ContactsContract.Contacts.CONTENT_URI, contactId
//        )
//        return Uri.withAppendedPath(
//            person,
//            ContactsContract.Contacts.Photo.CONTENT_DIRECTORY
//        )
//    }

    override fun onBackPressed() {
//        super.onBackPressed()
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    public override fun onResume() {
        super.onResume()
        changeLanguage()
    }
}