package com.backup.restore.device.image.recovery.mainapps.activity


import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainapps.adapter.LanguageAdapter
import com.backup.restore.device.image.recovery.mainapps.fragment.*
import com.backup.restore.device.image.recovery.multilang.LocaleManager
import com.backup.restore.device.image.recovery.utilities.Language
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.getLanguageOptions
import com.backup.restore.device.image.recovery.utilities.saveFirstLaunch
//import com.example.app.ads.helper.GiftIconHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityLanguageBinding
import com.example.jdrodi.callback.RVClickListener
import com.example.jdrodi.utilities.RvGridSpacingItemDecoration
import java.util.*


class LanguageActivity : MyCommonBaseActivity(), View.OnClickListener {

    private var languageClick = Language(R.string.english, R.drawable.ic_english, "en")
    var isFromSplash = false

    lateinit var binding:ActivityLanguageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_language)
        binding=ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(LanguageActivity::class.simpleName!!)

        val mIntent = intent
        if (mIntent.hasExtra("isFromSplash")) {
            isFromSplash = mIntent.getBooleanExtra("isFromSplash", false)

            if (isFromSplash) {
                binding.ivBack.visibility = View.INVISIBLE
//                binding.frameGift.visibility = View.GONE
                binding.ivDone.visibility = View.VISIBLE
            }
        }

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()

//        } else {
//            binding.adview.visibility = View.GONE
//        }

    }

    override fun getContext(): AppCompatActivity {
        return this@LanguageActivity
    }

    override fun initData() {

        val languageOptions = getLanguageOptions()

        val languageAdapter = LanguageAdapter(mContext, languageOptions, object : RVClickListener {
            override fun onItemClick(position: Int) {
                languageOptions[position].isSelected = true
                languageClick = languageOptions[position]

                if (isFromSplash) {
                    SharedPrefsConstant.save(
                        mContext,
                        ShareConstants.SELECTED_LANGUAGE,
                        languageClick.type
                    )
                    Log.e("ChangeLanguage", "languageClick:" + languageClick.type)
                    manageLanguage()
                } else {
                    dialogChangeLanguage(languageClick)
                }
            }
        })
        binding.rvLanguage.addItemDecoration(RvGridSpacingItemDecoration(1, 0, true))
        binding.rvLanguage.adapter = languageAdapter
    }


    private fun dialogChangeLanguage(languageClick: Language) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_language_confirm)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<View>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonOk).setOnClickListener {

            SharedPrefsConstant.save(mContext, ShareConstants.SELECTED_LANGUAGE, languageClick.type)
            SharedPrefsConstant.save(
                mContext,
                ShareConstants.SELECTED_LANGUAGE_LABLE,
                getString(languageClick.name)
            )
            Log.e("ChangeLanguage", "languageClick:" + languageClick.type)
            manageLanguage()

            dialog.dismiss()
        }
        dialog.show()
    }

    override fun initActions() {
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext) && !isFromSplash) {
////            GiftIconHelper.loadGiftAd(
////                fContext = mContext,
////                fivGiftIcon = findViewById(R.id.main_la_gift),
////                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
////            )
//        }
        binding.ivBack.setOnClickListener(this)
        binding.ivDone.setOnClickListener(this)
    }

    fun manageLanguage() {
        LocaleManager.setNewLocale(mContext,languageClick.type)

//        when (languageClick.type) {
//            "en" -> {
//                SharedPrefsConstant.save(this@LanguageActivity, ShareConstants.SELECTED_LANGUAGE, "en")
//                changeLanguage()
//                Log.e("ChangeLanguage", "languageClick:TYPE_ENGLISH")
//            }
//            "hi" -> {
//                SharedPrefsConstant.save(this@LanguageActivity, ShareConstants.SELECTED_LANGUAGE, "hi")
//                changeLanguage()
//                Log.e("ChangeLanguage", "languageClick:TYPE_HINDI")
//            }
//            "ar" -> {
//                SharedPrefsConstant.save(this@LanguageActivity, ShareConstants.SELECTED_LANGUAGE, "ar")
//                changeLanguage()
//                Log.e("ChangeLanguage", "languageClick:TYPE_ARABIC")
//            }
//            "ur" -> {
//                SharedPrefsConstant.save(this@LanguageActivity, ShareConstants.SELECTED_LANGUAGE, "ur")
//                changeLanguage()
//                Log.e("ChangeLanguage", "languageClick:TYPE_URDU")
//            }
//            "pt" -> {
//                SharedPrefsConstant.save(this@LanguageActivity, ShareConstants.SELECTED_LANGUAGE, "pt")
//                changeLanguage()
//                Log.e("ChangeLanguage", "languageClick:TYPE_PORTUGUESE")
//            }
//
//        }

        SharedPrefsConstant.savePref(mContext,"isLocaleChanged",true)
        if (!isFromSplash) {
            onBackPressed()
        } else {
            SharedPrefsConstant.save(mContext, ShareConstants.SELECTED_LANGUAGE, languageClick.type)
            SharedPrefsConstant.save(mContext, ShareConstants.SELECTED_LANGUAGE_LABLE, getString(languageClick.name))
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
//        Handler(Looper.getMainLooper()).postDelayed({
//        setResult(RESULT_OK,Intent().putExtra("key",languageClick.type))
//        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//        },1000)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.iv_back -> onBackPressed()
            R.id.iv_done -> {

                val locale = Locale(SharedPrefsConstant.getString(this, ShareConstants.SELECTED_LANGUAGE, "en")!!)
                val config = this.resources.configuration
                config.locale = locale
                Locale.setDefault(locale)
                this.resources.updateConfiguration(config, this.resources.displayMetrics)

                saveFirstLaunch()
                startActivity(NewHomeActivity.newIntent(this))

//                val i = Intent(mContext, IntroActivity::class.java)
//                if (isFromSplash) i.putExtra("isFromSplash", true)
//                startActivity(i)
                finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }
}