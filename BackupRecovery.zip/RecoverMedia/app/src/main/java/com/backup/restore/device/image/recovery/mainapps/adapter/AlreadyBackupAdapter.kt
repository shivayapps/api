package com.backup.restore.device.image.recovery.mainapps.adapter

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainapps.activity.AppsBackupActivity
import com.backup.restore.device.image.recovery.mainapps.fragment.AlreadyBackupApkFragment
import com.backup.restore.device.image.recovery.mainapps.model.SelectedApk
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.getShareMessage
import com.example.jdrodi.callback.RVClickListener
import java.io.File
import java.util.*

class AlreadyBackupAdapter(
    private val mContext: Activity,
    var SavedApps: ArrayList<SelectedApk>,
    var mTvMsg: LinearLayout,
    var mRvListener: RVClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    companion object {
        @JvmField
        var filterSavedApps: ArrayList<SelectedApk>? = null
    }

    init {
        filterSavedApps = SavedApps
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        var view: View = itemView.findViewById(R.id.view)
        var llDelete: ImageView = itemView.findViewById(R.id.img_delete)
        var llShare: ImageView = itemView.findViewById(R.id.img_share)
        var applicationIconImage: ImageView = itemView.findViewById(R.id.application_icon_image)
        var applicationLabelText: TextView = itemView.findViewById(R.id.application_label_text)
        var applicationDetail: TextView = itemView.findViewById(R.id.tv_detail)

    }

    override fun getItemCount(): Int {
        return filterSavedApps!!.size
    }

    fun getItem(position: Int): SelectedApk {
        return filterSavedApps!![position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val menuItemLayoutView = LayoutInflater.from(parent.context)
            .inflate(R.layout.raw_already_backup_apk_item, parent, false)
        return MyViewHolder(menuItemLayoutView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val menuItemHolder = holder as MyViewHolder
        try {
//            if (position == filterSavedApps!!.size - 1) {
//                holder.view.visibility = View.GONE
//            } else {
//                holder.view.visibility = View.VISIBLE
//            }

//            val packageInfo = mContext.packageManager.getPackageArchiveInfo(filterSavedApps!![position].absolutePath, 0)
//            if (packageInfo != null) {
//                packageInfo.applicationInfo.sourceDir = filterSavedApps!![position].absolutePath
//                packageInfo.applicationInfo.publicSourceDir = filterSavedApps!![position].absolutePath
//                val icon = packageInfo.applicationInfo.loadIcon(mContext.packageManager)
//            }
                menuItemHolder.applicationIconImage.setImageDrawable(filterSavedApps!![position].drawable)
            val lPackageName = filterSavedApps!![position].label
            val tempName = lPackageName!!.split("#").toTypedArray()
            val appName = tempName[0] + ".apk"
            menuItemHolder.applicationLabelText.text = appName
            val size= Utils.getDataSizeWithPrefix(mContext,filterSavedApps!![position].size!!)
            menuItemHolder.applicationDetail.text = "${size.first} ${size.second}, ${filterSavedApps!![position].installedTime}"

            menuItemHolder.itemView.setOnClickListener {
                try {
                    if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                        return@setOnClickListener
                    }
                    ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

                    AlreadyBackupApkFragment.isResumeCheck = false
                    AppsBackupActivity.isFrom = "AlreadyBackup"
                    val uri: Uri =
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) FileProvider.getUriForFile(
                            mContext, mContext.packageName + ".provider",
                            File(filterSavedApps!![position].appName)
                        ) else Uri.fromFile(
                            File(filterSavedApps!![position].appName)
                        )
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    intent.setDataAndType(uri, "application/vnd.android.package-archive")
                    mContext.startActivity(intent)
                    MyApplication.isInternalCall = true

                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
            menuItemHolder.llDelete.setOnClickListener {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                mRvListener.onItemClick(position)
            }
            menuItemHolder.llShare.setOnClickListener {
                AlreadyBackupApkFragment.isResumeCheck = false
                AppsBackupActivity.isFrom = "AlreadyBackup"
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                MyApplication.isInternalCall = true
                val uri = FileProvider.getUriForFile(
                    mContext,
                    mContext.packageName + ".provider",
                    File(filterSavedApps!![position].appName)
                )
                val share = Intent(Intent.ACTION_SEND)
                share.type = "*/*"
                share.putExtra(
                    Intent.EXTRA_SUBJECT,
                    mContext.resources.getString(R.string.app_name)
                )
                share.putExtra(Intent.EXTRA_STREAM, uri)
                share.putExtra(Intent.EXTRA_TEXT, mContext.getShareMessage())
                mContext.startActivity(Intent.createChooser(share, "Share Apk"))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun filterList(filteredNames: ArrayList<SelectedApk>) {
        filterSavedApps = filteredNames
        if (filterSavedApps!!.isEmpty()) {
            mRvListener.onEmpty()
        } else {
            mRvListener.onNotEmpty()
        }
        notifyDataSetChanged()
    }
}