package com.backup.restore.device.image.recovery.service
//
//import android.app.*
//import android.content.Intent
//import android.os.Build
//import android.os.Environment
//import android.os.IBinder
//import android.util.Log
//import androidx.core.app.NotificationCompat
//import androidx.core.content.ContextCompat
//import com.backup.restore.device.image.recovery.R
//import com.backup.restore.device.image.recovery.main.NewHomeActivity
//
//class RecoverImageService : Service() {
//
//    var mTAG : String = javaClass.simpleName
//
//    var mChannelId = "RecoveryForegroundServiceChannel"
////    var mHandler: Handler? = Handler()
//    var mNotificationManager: NotificationManager? = null
//
//    companion object {
//        @JvmField
//        var isRunningService = false
//        var mRunnable: Runnable? = null
//    }
//
//    override fun onBind(intent: Intent): IBinder? {
//        return null
//    }
//
//    override fun onDestroy() {
//        Log.e(mTAG, "onDestroy: ")
//        //        Intent broadcastIntent = new Intent();
////        broadcastIntent.setAction( "android.intent.action.BOOT_COMPLETED");
////        broadcastIntent.setClass(RecoverImageService.this, BootReceiver.class);
////        sendBroadcast(broadcastIntent);
//    }
//
//    override fun onStart(intent: Intent, i: Int) {}
//    override fun onCreate() {
//        startService()
//        Log.e("Created", "BG Service")
////        mHandler = Handler()
//        try {
//            if (isRunningService) {
//                if (!isMyServiceRunning(RecoveryFile::class.java)) {
//                    startService()
//                }
//            } else if (!isMyServiceRunning(RecoveryFile::class.java)) {
//                startService()
//            }
//        } catch (e: Exception) {
//            Log.e(mTAG, "run: " + e.message)
//            e.printStackTrace()
//        }
////        mHandler!!.postDelayed(mRunnable!!, 2000)
//    }
//
//    fun startService() {
//        Log.e(mTAG, "StartServiceMethod: ")
//        val intent = Intent(this, RecoveryFile::class.java)
//        intent.action = "com.backup.restore.device.image.recovery.OBSERVE"
//        intent.setPackage(packageName)
//        intent.putExtra("com.backup.restore.device.image.recovery.EXTRA_PATH", Environment.getExternalStorageDirectory().toString())
//        startService(intent)
//    }
//
//    override fun onUnbind(intent: Intent): Boolean {
//        return super.onUnbind(intent)
//    }
//
//    override fun onStartCommand(intent: Intent, i: Int, i2: Int): Int {
//        Log.e(mTAG, "onStartCommand: ")
//        //        startService();
//        if (mNotificationManager == null) {
//            mNotificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
//        }
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            if (mNotificationManager!!.getNotificationChannel(mChannelId) == null) {
//                val notificationChannel = NotificationChannel(mChannelId, "My Recovery Background Service", NotificationManager.IMPORTANCE_LOW)
//                mNotificationManager!!.createNotificationChannel(notificationChannel)
//            }
//        }
//        val pendingIntent = PendingIntent.getActivity(this, 0, Intent(this, NewHomeActivity::class.java), 0)
//        val mBuilder = NotificationCompat.Builder(this, mChannelId)
//            .setContentTitle(getString(R.string.app_name))
//            .setContentText(getString(R.string.protecting_your_deleted_iamge))
//            .setSmallIcon(R.drawable.ic_icon)
//            .setCategory(Notification.CATEGORY_SERVICE)
//            .setColor(ContextCompat.getColor(this, R.color.colorPrimary))
//            .setPriority(NotificationManager.IMPORTANCE_MIN)
//            .setContent(null)
//            .setContentIntent(pendingIntent).build()
//        startForeground(1500, mBuilder)
//        return START_STICKY
//    }
//
//    fun isMyServiceRunning(cls: Class<*>): Boolean {
//        for (runningServiceInfo in (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getRunningServices(Int.MAX_VALUE)) {
//            if (cls.name == runningServiceInfo.service.className) {
//                return true
//            }
//        }
//        return false
//    }
//
//}