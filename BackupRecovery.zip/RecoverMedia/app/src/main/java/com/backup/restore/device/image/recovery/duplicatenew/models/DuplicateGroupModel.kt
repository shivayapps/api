package com.backup.restore.device.image.recovery.duplicatenew.models

class DuplicateGroupModel {
    var isCheckBox = false
    var md5CheckSum = ""
    var individualGrpOfDupes: List<FileDetails>? = null
}