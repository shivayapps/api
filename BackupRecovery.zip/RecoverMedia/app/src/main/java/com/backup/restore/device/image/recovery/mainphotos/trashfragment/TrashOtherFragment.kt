package com.backup.restore.device.image.recovery.mainphotos.trashfragment

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.aainc.recyclebin.database.FilesProtectionContentProvider
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.databinding.FragmentTrashAudioDocBinding
import com.backup.restore.device.image.recovery.mainphotos.activity.TrashImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.TrashImageActivity.Companion.resumeOtherCount
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel
import com.backup.restore.device.image.recovery.mainphotos.trashadapter.AudioOtherTrashAdapter
//import kotlinx.android.synthetic.main.activity_recover_image_new.*
//import kotlinx.android.synthetic.main.fragment_trash_audio_doc.*

class TrashOtherFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    lateinit var mView: View
    var mainCommonAdapter: AudioOtherTrashAdapter? = null
    var selectedList = ArrayList<TrashModel>()
    var isVisibleHint: Boolean = false
    var mCursor: Cursor? = null
    var isForSort = "date_asc"
    var mPrevCursor: Cursor? = null

    fun TrashOtherFragment() {
    }

    companion object {
        fun newInstance(): TrashOtherFragment {
            return TrashOtherFragment()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        context!!.registerReceiver(
            refreshMediaBroadcast,
            IntentFilter("com.progress.other.Refresh")
        )
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isAdded) {
            isVisibleHint = isVisibleToUser
            Log.e(mTAG, "setUserVisibleHint: same $isVisibleToUser")
            if (isVisibleHint) {
                if (mCursor != null && mCursor!!.count != 0) {
                    if (requireActivity() is TrashImageActivity) {
                        (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                            true
                        )
//                        requireActivity().iv_span.alpha = 1.0F
//                        requireActivity().iv_span.isEnabled = true
                        when (isForSort) {
                            "size_asc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeAsc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "size_desc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "date_desc" -> {
                                (requireActivity() as TrashImageActivity).selectDateDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                            "date_asc" -> {
                                (requireActivity() as TrashImageActivity).selectTop(2)
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                        }
                    }
                } else {
                    if (requireActivity() is TrashImageActivity) {
                        (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                            false
                        )
                        (requireActivity() as TrashImageActivity).unSelectAll()
                        (requireActivity() as TrashImageActivity).binding.ivSpan.alpha = 0.5F
                        (requireActivity() as TrashImageActivity).binding.ivSpan.isEnabled = false
                    }
                }
            }
        }
    }

    lateinit var binding: FragmentTrashAudioDocBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
//        mView = inflater.inflate(R.layout.fragment_trash_audio_doc, container, false)
        binding= FragmentTrashAudioDocBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_other)
        binding.tvNotFound.setText(R.string.file_not_found)
    }

    override fun onClick(view: View) {

    }

    override fun onResume() {
        super.onResume()
        resumeOtherCount += 1
        Log.e(mTAG, "onResume: $isVisibleHint")
        val whereClause = "type_file=?"
        val whereArgs = arrayOf("Other")
        var sortOrder = ""
        Log.e("TAG", "ListImage  --> onCreate: Other")
        mPrevCursor = mCursor
        when (isForSort) {
            "size_asc" -> {
                sortOrder = "cast(file_size as INTEGER) ASC"
            }
            "size_desc" -> {
                sortOrder = "cast(file_size as INTEGER) DESC"
            }
            "date_desc" -> {
                sortOrder = "deleted_at ASC"
            }
            "date_asc" -> {
                sortOrder = "deleted_at DESC"
            }

        }
        mCursor = requireActivity().contentResolver.query(
            FilesProtectionContentProvider.a,
            null as Array<String?>?,
            whereClause,
            whereArgs,
            sortOrder
        )!!
//        mCursor = requireActivity().contentResolver.query(FilesProtectionContentProvider.a, null as Array<String?>?, whereClause, whereArgs, null)!!

        Log.e(mTAG, "ListImage  --> onCreate: ${mCursor!!.count}")
        if (mCursor!!.count == 0) {
            binding.tvTrashAlbum.visibility = View.VISIBLE
            binding.lottieTrashAudio.visibility = View.GONE
            binding.deletedFilesTrashAudioDoc.visibility = View.GONE
        } else {
            binding.tvTrashAlbum.visibility = View.GONE
            binding.deletedFilesTrashAudioDoc.visibility = View.VISIBLE
        }
        mainCommonAdapter = AudioOtherTrashAdapter(
            requireActivity(),
            this,
            mCursor,
            2,
            "Other",
            (requireActivity() as TrashImageActivity).binding.checkAll,
            isForSort
        )
        binding.deletedFilesTrashAudioDoc.adapter = mainCommonAdapter

        if (isVisibleHint && TrashImageActivity.mIsFromForImageCheck == "Trash") {
            if ((requireActivity() as TrashImageActivity).binding.checkAll != null) (requireActivity() as TrashImageActivity).binding.checkAll.isChecked =
                mCursor!!.count == selectedList.size
            if (mCursor != null && mCursor!!.count != 0) {
                if (requireActivity() is TrashImageActivity) {
                    (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                        true
                    )
//                    requireActivity().iv_span.alpha = 1.0F
//                    requireActivity().iv_span.isEnabled = true
                    if (mPrevCursor != null && mPrevCursor!!.count == 0) {
                        (requireActivity() as TrashImageActivity).selectTop(2)
                    }
                }
            } else {
                if (requireActivity() is TrashImageActivity) {
                    (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                        false
                    )
                    (requireActivity() as TrashImageActivity).unSelectAll()
//                    requireActivity().iv_span.alpha = 0.5F
//                    requireActivity().iv_span.isEnabled = false
                }
            }

//            Log.e("$mTAG Other", "initActions: fragment size  --> " + selectedList.size)
//            Log.e("$mTAG Other", "initActions: fragment count --> " + mCursor!!.count)
//            Log.e("$mTAG Other", "initActions: fragment mCursor-> $mCursor")
            if (mCursor != null && selectedList.size == mCursor!!.count) {
                mainCommonAdapter!!.selectAll()
            }
        }
        object : AsyncTask<Void, Long, Void>() {
            override fun doInBackground(vararg voids: Void): Void? {
                Log.e(mTAG, "doInBackground: stopLoading")
                stopLoading()
                return null
            }

            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    fun stopLoading() {
        activity?.runOnUiThread {
            Handler(Looper.getMainLooper()).postDelayed({
                resumeOtherCount -= 1
                Log.e(mTAG, "stopLoading: $resumeOtherCount")
                if (resumeOtherCount <= 0) {
                    if (isAdded) {
                        if (isVisibleHint) {
                            if (mCursor != null && mCursor!!.count != 0) {
                                if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 4) {
                                    (requireActivity() as TrashImageActivity).selectTop(2)
                                    if ((requireActivity() as TrashImageActivity).binding.ivSpan != null) {
                                        (requireActivity() as TrashImageActivity).binding.ivSpan.alpha = 1F
                                        (requireActivity() as TrashImageActivity).binding.ivSpan.isEnabled = true
                                    }
                                    if ((requireActivity() as TrashImageActivity).binding.btnRecover != null) {
                                        (requireActivity() as TrashImageActivity).binding.btnRecover.alpha = 1F
                                        (requireActivity() as TrashImageActivity).binding.btnRecover.isEnabled = true
                                    }
                                    if ((requireActivity() as TrashImageActivity).binding.llSelectAll != null) {
                                        (requireActivity() as TrashImageActivity).binding.llSelectAll.alpha = 1F
                                        (requireActivity() as TrashImageActivity).binding.llSelectAll.isEnabled = true
                                    }
                                }

                                if (binding.lottieTrashAudio != null) binding.lottieTrashAudio.visibility =
                                    View.GONE
                                Log.e(mTAG, "stopLoading: ")
//                        }
                            } else {
//                                if(isVisibleHint) {
                                if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 4) {
                                    (requireActivity() as TrashImageActivity).unSelectAll()
                                }
//                                    requireActivity().iv_span.alpha = 0.5F
//                                    requireActivity().iv_span.isEnabled = false
//                                    requireActivity().btnRecover.alpha = 0.5F
//                                    requireActivity().btnRecover.isEnabled = false
//                                    requireActivity().llSelectAll.alpha = 0.5F
//                                    requireActivity().llSelectAll.isEnabled = false
//                                }
//                            binding.lottieTrashAudio.visibility = View.VISIBLE
                            }
                        }
                    }
                }
            }, 1000)
        }
    }

    var refreshMediaBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent!!.action == "com.progress.other.Refresh") {
                Handler(Looper.getMainLooper()).post {
                    onResume()
                }
//                if(isVisibleHint) {
                (requireActivity() as TrashImageActivity).unSelectAll()
                (requireActivity() as TrashImageActivity).binding.ivSpan.alpha = 0.5F
                (requireActivity() as TrashImageActivity).binding.ivSpan.isEnabled = false
                (requireActivity() as TrashImageActivity).binding.btnRecover.alpha = 0.5F
                (requireActivity() as TrashImageActivity).binding.btnRecover.isEnabled = false
                (requireActivity() as TrashImageActivity).binding.llSelectAll.alpha = 0.5F
                (requireActivity() as TrashImageActivity).binding.llSelectAll.isEnabled = false
                binding.lottieTrashAudio.visibility = View.VISIBLE
//                }
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        context!!.unregisterReceiver(refreshMediaBroadcast)
    }
}