package com.backup.restore.device.image.recovery.maincontact.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityShareBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


class ShareActivity : MyCommonBaseActivity() {

    var mPath = "/"
    companion object {
        var isDelete=false
    }

    lateinit var binding:ActivityShareBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_share)
        binding=ActivityShareBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mIntent = intent
        var mType = 0
        if(mIntent.hasExtra("file_type")) {
            mType = mIntent.getIntExtra("file_type", 0)
        }

        //var mPath = "/"
        if(mIntent.hasExtra("file_path")) {
            mPath=mIntent.getStringExtra("file_path")!!
        }
        val filename: String = mPath.substring(mPath.lastIndexOf("/") + 1)
        var subTitle: String = ""
        if(mType==0) {
            binding.imgType.setImageDrawable(resources.getDrawable(R.drawable.ic_excel_icon))
            binding.tvTitle.setText(getString(R.string.excel_file))
            subTitle=filename.toLowerCase().replace("contact_","").replace(".xlsx","").replace(".xls","")
        } else {
            binding.tvTitle.setText(getString(R.string.pdf_file))
            binding.imgType.setImageDrawable(resources.getDrawable(R.drawable.ic_pdf_icon))
            subTitle=filename.toLowerCase().replace("contact_","").replace(".pdf","")
        }

        binding.mTitle.text=filename

        val formatter = SimpleDateFormat("ddMMyyyy_hh_mm_ss", Locale.getDefault())
        val date = formatter.parse(subTitle)
        val formatter1 = SimpleDateFormat("dd/MM/yyyy hh:mm aa", Locale.getDefault())
        binding.subTitle.text=formatter1.format(date!!)

        binding.buttonOpen.setOnClickListener {
            try {
                val file = File(mPath)
//            val uri: Uri = Uri.fromFile(file)
                val uri: Uri = FileProvider.getUriForFile(mContext, "$packageName.provider", file)
                val mime = contentResolver.getType(uri)
                val intent = Intent()
                intent.action = Intent.ACTION_VIEW
                intent.setDataAndType(uri, mime)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(intent)
            } catch (e:Exception) {
                Toast.makeText(mContext,getString(R.string.file_not_supported_by_device),Toast.LENGTH_SHORT).show()
            }
        }
        binding.buttonShare.setOnClickListener {
            try {
                val uri: Uri = FileProvider.getUriForFile(mContext, "$packageName.provider", File(mPath))
                val sharingIntent = Intent(Intent.ACTION_SEND)
                sharingIntent.setType("*/*")
                sharingIntent.putExtra(Intent.EXTRA_STREAM, uri)
                startActivity(Intent.createChooser(sharingIntent, "Share using"));
            } catch (e:Exception) {
                Toast.makeText(mContext,getString(R.string.file_not_supported_by_device),Toast.LENGTH_SHORT).show()
            }
        }

    }

    override fun getContext(): AppCompatActivity {
        return this@ShareActivity
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()
//        } else {
//            binding.adview.visibility = View.GONE
//        }
    }

    override fun initData() {

    }

    override fun initActions() {
        binding.ivBack.setOnClickListener(this)
        binding.ivDelete.setOnClickListener(this)
    }

    private fun deleteBackups() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.delete_alert_message_document_single)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {

            if (File(mPath).exists()) {
                Log.e("TAG", "deleteBackups: path-->  $mPath")
                if(File(mPath).delete()) {
                    isDelete=true
                    Toast.makeText(mContext, getString(R.string.contact_backup_delete_successfully), Toast.LENGTH_SHORT).show()
                } else {
                    isDelete=false
                }
            }

            dialog.cancel()
//            File(mPath).delete()
            val handler = Handler()
            handler.postDelayed({
                onBackPressed()
            }, 500)

        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.iv_back -> onBackPressed()
            R.id.iv_delete -> {
                deleteBackups()
            }
        }
    }
}