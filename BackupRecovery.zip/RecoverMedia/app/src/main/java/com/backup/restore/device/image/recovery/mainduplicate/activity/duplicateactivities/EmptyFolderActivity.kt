package com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.AsyncTask
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.*
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.databinding.ActivityEmptyFolderBinding
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainduplicate.activity.scanningactivities.EmptyFolderScanningActivity
import com.backup.restore.device.image.recovery.mainduplicate.adapter.EmptyFolderAdapter
import com.backup.restore.device.image.recovery.mainduplicate.model.EmptyFolderModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.RatingDialog
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class EmptyFolderActivity : MyCommonBaseActivity() {

    val mTAG: String = javaClass.simpleName

    var mEmptyFolderAdapter: EmptyFolderAdapter? = null
    var isFromOneSignal = false
    var mEmptyFolderList = ArrayList<EmptyFolderModel>()
    var mEmptyFolder = ""
    var top = -1
    var mLayoutManager: LinearLayoutManager? = null
    var mDuplicateFound = 0
    var mDeleteDuplicateFound = 0

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    lateinit var binding:ActivityEmptyFolderBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_empty_folder)
        binding=ActivityEmptyFolderBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    override fun getContext(): AppCompatActivity {
        return this@EmptyFolderActivity
    }

    override fun initData() {

        setSupportActionBar(binding.toolbar)

        mLayoutManager = LinearLayoutManager(mContext)

        binding.scanEmptyFolder.layoutManager = mLayoutManager
        binding.scanEmptyFolder.setHasFixedSize(true)



        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }

        mEmptyFolder = intent.getStringExtra("mEmptyFolderListFinal")!!
        val myType = object : TypeToken<ArrayList<EmptyFolderModel>>() {}.type
        mEmptyFolderList = Gson().fromJson(mEmptyFolder, myType)
        mDuplicateFound = mEmptyFolderList.size

        binding.dupesFound.text = getString(R.string.empty_folder_colon) + mDuplicateFound
        Log.e(mTAG, "initData: " + mEmptyFolderList.size)
        try {
            if (mEmptyFolderList.size <= 0) {
                Log.e(mTAG, "onPostExecute: size 0 ")
                binding.tvEmptyFolder!!.visibility = View.VISIBLE
                binding.scanEmptyFolder!!.visibility = View.GONE
                binding.deleteExceptionFrameLayout!!.visibility = View.GONE
            } else {

                var lFinalDate = Date()
                val cal = Calendar.getInstance()
                cal.time = lFinalDate
                lFinalDate = cal.time

                val zero:Long = 0

                val dateFormat = SimpleDateFormat("dd/MM/yyyy")
                when {
//                    SharedPrefsConstant.getString(mContext, "IsLastScanDate") == dateFormat.format(lFinalDate) -> {
                    SharedPrefsConstant.getLong(mContext, "IsLastScanMillis") <= cal.timeInMillis -> {
                        binding.tvEmptyFolder!!.visibility = View.GONE
                        binding.scanEmptyFolder!!.visibility = View.VISIBLE
                        binding.deleteExceptionFrameLayout!!.visibility = View.VISIBLE
                    }
//                    SharedPrefsConstant.getString(mContext, "IsLastScanDate").equals("") -> {
                    SharedPrefsConstant.getLong(mContext, "IsLastScanMillis") == zero -> {
                        binding.tvEmptyFolder!!.visibility = View.GONE
                        binding.scanEmptyFolder!!.visibility = View.VISIBLE
                        binding.deleteExceptionFrameLayout!!.visibility = View.VISIBLE
                    }
                    else -> {
                        binding.tvEmptyFolder!!.visibility = View.VISIBLE
                        binding.scanEmptyFolder!!.visibility = View.GONE
                        binding.deleteExceptionFrameLayout!!.visibility = View.GONE
                        mDuplicateFound = 0
                        mEmptyFolderList.clear()
                    }
                }
            }
            mEmptyFolderAdapter = EmptyFolderAdapter(mEmptyFolderList)
            binding.scanEmptyFolder!!.adapter = mEmptyFolderAdapter
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun initActions() {
        binding.backpressEmptyFolder.setOnClickListener {
            onBackPressed()
        }

        binding.btnDelete.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 800) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

            if (mEmptyFolderAdapter!!.getSelectedCounted().isEmpty()) {
                Toast.makeText(
                    mContext,
                    getString(R.string.select_at_least_one_item),
                    Toast.LENGTH_SHORT
                ).show()
            } else {

                val dialog = Dialog(mContext)
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setCancelable(false)
                dialog.setContentView(R.layout.dialog_confirmation)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )


                dialog.findViewById<TextView>(R.id.permission).text =
                    getString(R.string.delete_alert_title)
                if (mEmptyFolderAdapter!!.getSelectedCounted().size == 1) {
                    dialog.findViewById<TextView>(R.id.permission_text).text =
                        getString(R.string.delete_alert_message_empty_folder_single)
                } else {
                    dialog.findViewById<TextView>(R.id.permission_text).text =
                        getString(R.string.delete_alert_message_empty_folder)
                }

                dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
                dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

                dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
                    dialog.cancel()
                    SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", true)
                    MyApplication.isDialogOpen = false
                    mDeleteDuplicateFound = mEmptyFolderAdapter!!.getSelectedCounted().size
                    DeleteEmptyFolder().execute()
                    SharedPrefsConstant.save(
                        mContext,
                        ShareConstants.RATE_DUPLICATE_COUNT,
                        SharedPrefsConstant.getInt(
                            mContext,
                            ShareConstants.RATE_DUPLICATE_COUNT
                        ) + 1
                    )

                }
                dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                    dialog.cancel()
                    MyApplication.isDialogOpen = false
                }
                dialog.setOnDismissListener {
                    MyApplication.isDialogOpen = false
                }


                dialog.show()
                MyApplication.isDialogOpen = true
            }
        }
    }

    private inner class DeleteEmptyFolder : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_delete_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            if (mEmptyFolderAdapter!!.getSelectedCounted().size == 1) {
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.delete_dialog_message_empty_folder_single)
            } else {
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.delete_dialog_message_empty_folder)
            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }


            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
        }

        override fun doInBackground(vararg strings: String?): String? {
            val selectedList = mEmptyFolderAdapter!!.getSelectedCounted()
            selectedList.forEach {
                val mFile = File(it.path!!)
                if (mFile.exists()) {
                    mFile.delete()
                }
                runOnUiThread {
                    mEmptyFolderList.remove(it)
//                    mEmptyFolderAdapter!!.notifyItemRemoved(selectedList.indexOf(it))
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {
                try {
                    if (dialog != null && dialog.isShowing) {
                        dialog.cancel()
                        MyApplication.isDialogOpen = false
                    }
                } catch (e: Exception) {
//                    mContext.addEvent(e.message!!)
                }


                if (mEmptyFolderList.size == 0) {
                    Log.e(mTAG, "onPostExecute: size 0 ")
                    binding.scanEmptyFolder!!.visibility = View.GONE
                    binding.tvEmptyFolder!!.visibility = View.VISIBLE

                    var lFinalDate = Date()
                    val cal = Calendar.getInstance()
                    cal.time = lFinalDate
                    cal.add(Calendar.DATE, 7)
                    lFinalDate = cal.time

                    val dateFormat = SimpleDateFormat("dd/MM/yyyy")
                    Log.e(mTAG, "onPostExecute: " + dateFormat.format(lFinalDate))
//                    SharedPrefsConstant.save(mContext,"IsLastScanDate",dateFormat.format(lFinalDate))
                    SharedPrefsConstant.save(mContext,"IsLastScanMillis",cal.timeInMillis)
                    binding.deleteExceptionFrameLayout!!.visibility = View.GONE
                    mDuplicateFound = 0
                } else {
                    binding.tvEmptyFolder!!.visibility = View.GONE
                    binding.scanEmptyFolder!!.visibility = View.VISIBLE
                    binding.deleteExceptionFrameLayout!!.visibility = View.VISIBLE
                    mDuplicateFound = mEmptyFolderList.size
                    binding.dupesFound.text = getString(R.string.empty_folder_colon) + mDuplicateFound
                }
                SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", false)

//                mEmptyFolderListFinal = mEmptyFolderList
                mEmptyFolderAdapter!!.notifyDataSetChanged()
                showRegainDialog()
//                Toast.makeText(mContext, "Empty Folder Deleted Successfully", Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun showRegainDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_memory_regained)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.permission).text =
            getString(R.string.empty_folder_remover)

        val tv1 = dialog.findViewById<TextView>(R.id.cleaned_photo)
        tv1.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv1.text = getString(R.string.empty_folder_cleaned) + mDeleteDuplicateFound

        val tv2 = dialog.findViewById<TextView>(R.id.cleaned_memory)
        tv2.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv2.visibility = View.GONE

        dialog.findViewById<View>(R.id.dialogButtonrescan).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            intent = Intent(mContext, EmptyFolderScanningActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(
                intent,
                ActivityOptionsCompat.makeCustomAnimation(
                    mContext,
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
                ).toBundle()
            )
            finish()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {

            val isRated = ExitSPHelper(mContext).isRated()
            if (!isRated) {
                if (SharedPrefsConstant.getInt(
                        mContext,
                        ShareConstants.RATE_DUPLICATE_COUNT
                    ) >= 3 && SharedPrefsConstant.getInt(
                        mContext,
                        ShareConstants.RATE_LATTER,
                        1
                    ) == 0
                ) {
                    RatingDialog.smileyRatingDialog(mContext)
                } else {
                }
            }
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }


        dialog.show()
        MyApplication.isDialogOpen = true
    }

    override fun onBackPressed() {
        if (isFromOneSignal) {
            val i = Intent(mContext, NewHomeActivity::class.java)
            startActivity(i)
            finish()
        } else {
            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.settings_1, menu)
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
        }
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val intent: Intent
        when (id) {
            R.id.action_home -> {
                finish()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                intent = Intent(mContext, NewHomeActivity::class.java)
//                intent.addFlags(335544320)
//                startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(mContext, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
//                finish()
                return true
            }
            R.id.action_rescan -> {
                GlobalVarsAndFunctions.resetOneTimePopUp()
                intent = Intent(mContext, EmptyFolderScanningActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(
                    intent,
                    ActivityOptionsCompat.makeCustomAnimation(
                        mContext,
                        android.R.anim.fade_in,
                        android.R.anim.fade_out
                    ).toBundle()
                )
                finish()
                return true
            }
            R.id.action_selectall -> {
                if (mDuplicateFound == 0) {
//                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(true)
                }
                return true
            }
            R.id.action_deselectall -> {
                if (mDuplicateFound == 0) {
//                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(false)
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun imagesSelectAllAndDeselectAll(b: Boolean) {
        mEmptyFolderAdapter!!.toggleSelection(b)
    }

    //    public override fun onPause() {
//        var i = 0
//        super.onPause()
//        index = mLayoutManager!!.findFirstVisibleItemPosition()
//        val v = binding.scanEmptyFolder.getChildAt(0)
//        if (v != null) {
//            i = v.top - binding.scanEmptyFolder.paddingTop
//        }
//        top = i
//    }
//
    public override fun onResume() {
        super.onResume()
        changeLanguage()
//        if (index != -1) {
//            mLayoutManager!!.scrollToPositionWithOffset(index, top)
//        }
    }

}