package com.backup.restore.device.image.recovery.duplicatenew.utils.algorathm

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.AsyncTask
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.MimeTypeMap
import android.widget.TextView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.duplicatenew.models.DuplicateGroupModel
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails
import com.backup.restore.device.image.recovery.duplicatenew.utils.Constants
import com.backup.restore.device.image.recovery.duplicatenew.utils.DuplicatePreferences
import com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities.NewDuplicateMediaActivityNEW
import com.backup.restore.device.image.recovery.mainduplicate.model.IgnorePath
import com.backup.restore.device.image.recovery.utilities.DuplicateScanningListener
import com.backup.restore.device.image.recovery.utilities.MyAnnotations
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import java.io.File

class DuplicateFilesAsyncTask(
    var mContext: Context,
    var duplicateScanningListener: DuplicateScanningListener,
    var scanType: String
) : AsyncTask<Void?, Void?, Void?>() {

    var count = 1
//    var stopped = false

    val dialog = Dialog(mContext)

    override fun onPreExecute() {
        super.onPreExecute()
        NewDuplicateMediaActivityNEW.isScanRunning=true
        resetAllBeforeStartScan()

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_progress)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.permission).text = mContext.getString(R.string.label_please_wait)
        dialog.findViewById<TextView>(R.id.permission_text).visibility=View.GONE
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).visibility=View.GONE

        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

    }

    override fun doInBackground(vararg params: Void?): Void? {
        count = 0
        if (scanType == MyAnnotations.IMAGES || scanType == MyAnnotations.VIDEOS || scanType == MyAnnotations.AUDIOS || scanType == MyAnnotations.DOCUMENTS || scanType == MyAnnotations.OTHER) {
            getAllMediaByContent(mContext as Activity)
        }
        return null
    }

    override fun onPostExecute(result: Void?) {
        super.onPostExecute(result)
//        stopped = true
//        if (!dialog.isShowing) {
//            dialog.show()
//            MyApplication.isDialogOpen = true
//        }
        NewDuplicateMediaActivityNEW.isScanRunning=false
        DuplicatePreferences.setScanStop(mContext, true)
        var listOfDuplicatesFinal: MutableList<DuplicateGroupModel> = ArrayList()
        for (duplicate in listOfDuplicates) {
            if (duplicate.individualGrpOfDupes!!.size != 1) {
                val duplicateModel = DuplicateGroupModel()
                duplicateModel.isCheckBox = SharedPrefsConstant.getBooleanNoti(mContext, "duplicateSelection", true)
                duplicateModel.individualGrpOfDupes = duplicate.individualGrpOfDupes
                listOfDuplicatesFinal.add(duplicateModel)
            }
        }

        Handler(Looper.getMainLooper()).post {
            duplicateScanningListener.publishProgress(
                listOfDuplicatesFinal
            )
        }


        Handler(Looper.getMainLooper()).postDelayed({
            if (dialog.isShowing) {
                dialog.cancel()
                MyApplication.isDialogOpen = false
            }
        },1500)
    }


    private fun resetAllBeforeStartScan() {
        DuplicatePreferences.setScanStop(mContext, false)
        DuplicatePreferences.setSortBy(mContext, Constants.DATE_DOWN)
        DuplicatePreferences.setInitiateRescanAndEnterImagePageFirstTimeAfterScan(mContext, true)
        DuplicatePreferences.setInitiateRescanAndEnterVideoPageFirstTimeAfterScan(mContext, true)
        DuplicatePreferences.setInitiateRescanAndEnterAudioPageFirstTimeAfterScan(mContext, true)
        DuplicatePreferences.setInitiateRescanAndEnterDocumentPageFirstTimeAfterScan(mContext, true)
        DuplicatePreferences.setInitiateRescanAndEnterOtherPageFirstTimeAfterScan(mContext, true)

        Constants.resetOneTimePopUp()
        GlobalVarsAndFunctions.listOfDuplicates.clear()
        GlobalVarsAndFunctions.fileToBeDeleted.clear()
        GlobalVarsAndFunctions.uniqueMd5Value.clear()
        GlobalVarsAndFunctions.extensionHashSet.clear()
        GlobalVarsAndFunctions.audiosExtensionHashSet.clear()
        GlobalVarsAndFunctions.documentsExtensionHashSet.clear()
        GlobalVarsAndFunctions.photosExtensionHashSet.clear()
        GlobalVarsAndFunctions.videosExtensionHashSet.clear()
    }

    var listOfDuplicates: MutableList<DuplicateGroupModel> = ArrayList()
    var fileDetailMapStr: HashMap<String, ArrayList<FileDetails>> = HashMap()
    var fileDuplicateMapStr: HashMap<String, ArrayList<DuplicateGroupModel>> = HashMap()
    var fileDetails: FileDetails? = null

    //fun getAllMediaByContent(activity: Activity): HashMap<String, ArrayList<FileDetails>> {
    fun getAllMediaByContent(activity: Activity) {
        val sdCard = Environment.getExternalStorageDirectory().toString()
//        val pathToScan = SharedPrefsConstant.getString(mContext, "scanLocation", sdCard)
        val ignoredList = DBAdapter(mContext).ignoredPath

//        ArrayList<FileDetails> arrayList1 = new ArrayList<>();
        var arrayList = ArrayList<FileDetails>()
        //        List<String> list;
        var fileDetails: FileDetails? = FileDetails()
        var counter = 0
        var total = 0

        try {

            fileDetailMapStr = HashMap()
//            this.duplicateDetailMap = new ArrayList<>();
            //            this.duplicateDetailMap = new ArrayList<>();
            listOfDuplicates = ArrayList()
            var query: Cursor? = null
            when (scanType) {
                MyAnnotations.IMAGES -> {
                    query = activity.contentResolver
                        .query(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            arrayOf(MediaStore.Images.Media.DATA),
                            null,
                            null,
                            null
                        )
                }
                MyAnnotations.VIDEOS ->  {
                    query = activity.contentResolver.query(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        arrayOf(MediaStore.Video.Media.DATA),
                        null,
                        null,
                        null
                    )
                }
                MyAnnotations.AUDIOS -> {
                    query = activity.contentResolver.query(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        arrayOf(MediaStore.Audio.Media.DATA),
                        null,
                        null,
                        null
                    )
                }
                MyAnnotations.DOCUMENTS -> {
                    val mimeTypeDOC = MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc")
                    val mimeTypeDOCX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx")
                    val mimeTypeTXT = MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt")
                    val mimeTypePDF = MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf")
                    val mimeTypeXLS = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls")
                    val mimeTypeXLSX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx")
                    val mimeTypePPT = MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt")
                    val mimeTypePPTX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx")
                    val mimeTypeCSV = MimeTypeMap.getSingleton().getMimeTypeFromExtension("csv")
                    val mimeTypeXLT = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlt")
                    val mimeTypeXLTX = MimeTypeMap.getSingleton().getMimeTypeFromExtension("xltx")
                    val mimeTypeRTF = MimeTypeMap.getSingleton().getMimeTypeFromExtension("rtf")
                    val mimeTypeCHM = MimeTypeMap.getSingleton().getMimeTypeFromExtension("chm")
                    val selectionArgs = "application/pdf"
                    val selectionArgsPdf = arrayOf(
                        mimeTypeDOC,
                        mimeTypeDOCX,
                        mimeTypeTXT,
                        mimeTypePDF,
                        mimeTypeXLS,
                        mimeTypeXLSX,
                        mimeTypePPT,
                        mimeTypePPTX,
                        mimeTypeCSV,
                        mimeTypeXLT,
                        mimeTypeXLTX,
                        mimeTypeRTF,
                        mimeTypeCHM
                    )
                    val selectionMimeTypeDocument =
                        MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeDOC + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeDOCX + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeTXT + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypePDF + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLS + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLSX + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypePPT + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypePPTX + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeCSV + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLT + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeXLTX + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeRTF + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeCHM + "')"
                    query = activity.contentResolver
                        .query(
                            MediaStore.Files.getContentUri("external"),
                            arrayOf(MediaStore.Files.FileColumns.DATA),
                            selectionMimeTypeDocument,
                            null,
                            null
                        )
                }
                MyAnnotations.OTHER -> {
                    val mimeTypeZIP = MimeTypeMap.getSingleton().getMimeTypeFromExtension("zip")
                    val mimeTypeWMV = MimeTypeMap.getSingleton().getMimeTypeFromExtension("wmv")
                    val mimeTypeAPK = MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk")
                    val mimeTypeVCF = MimeTypeMap.getSingleton().getMimeTypeFromExtension("vcf")
                    val mimeTypeOGGOTHER =
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("ogg")
                    val mimeTypeDB = MimeTypeMap.getSingleton().getMimeTypeFromExtension("db")
                    val selectionMimeTypeOther =
                        MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeWMV + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeZIP + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeAPK + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeVCF + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeOGGOTHER + "')" + " OR " +
                                MediaStore.Files.FileColumns.MIME_TYPE + " IN('" + mimeTypeDB + "')"
                    query = activity.contentResolver
                        .query(
                            MediaStore.Files.getContentUri("external"),
                            arrayOf(MediaStore.Files.FileColumns.DATA),
                            selectionMimeTypeOther,
                            null,
                            null
                        )
                }
            }

            if (query == null || !query.moveToFirst()) {
                query!!.close()
                Handler(Looper.getMainLooper()).post {
                    duplicateScanningListener.publishProgress(
                        listOfDuplicates
                    )
                }
                //return fileDetailMapStr
                return
            }

            total = query.count
            do {
                if (NewDuplicateMediaActivityNEW.isScanRunning && status==Status.RUNNING) {
                    counter++
                    val finalCounter = counter
                    val finalTotal = total
                    Handler(Looper.getMainLooper()).post {
                        duplicateScanningListener.publishProgress(
                            *arrayOf(finalCounter.toString(), finalTotal.toString())
                        )
                    }
                    @SuppressLint("Range") val string = query.getString(0)
                    var isConditionTrue = false

                    Log.e("getAllMediaByContent", "counter:$counter path: $string" )

                    isConditionTrue = when (scanType) {
                        MyAnnotations.AUDIOS ->
                            GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.AAC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MP3)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WMA)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.M4A)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.OGG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WAV)
                        MyAnnotations.DOCUMENTS ->
                            GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DOC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DOCX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.TXT)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PDF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLS)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLSX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PPT)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PPTX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.CSV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLT)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XLTX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.RTF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.CHM)
                        MyAnnotations.IMAGES ->
                            GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.JPG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.AJPG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.JPEG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PNG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.BMP)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.TIFF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PSD)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.PIC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.GIF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WEBP)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.HEIC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DWG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.RAW)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.SRF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DNG)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.KDC)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.NRW)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.ORF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.CPT)
                        MyAnnotations.VIDEOS ->
                            GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MP4)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WMV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.XVID)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DIVX)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.ASF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.GP3)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.GP33)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.M4V)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MOV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.MKV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.AVI)
                        MyAnnotations.OTHER ->
                            GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.ZIP)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.WMV)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.APK)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.VCF)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.OGGOTHER)
                                    || GlobalVarsAndFunctions.getFileName(string).endsWith(GlobalVarsAndFunctions.DB)
                        else -> true
                    }

                    val isIgnored = checkPathContain(ignoredList, string)

                    Log.e("getAllMediaByContent", "isConditionTrue:$isConditionTrue" )
                    Log.e("getAllMediaByContent", "isIgnored:$isIgnored" )

//                    if (isConditionTrue && string.contains(pathToScan) && isIgnored) {
                    if (isConditionTrue && isIgnored) {
                        if (File(string).exists()) {
                            Log.e("getAllMediaByContent", "path: $string exist" )

                            val length = File(string).length()

                            this.fileDetails = FileDetails()
                            this.fileDetails!!.fileSize = length
                            this.fileDetails!!.fileName = File(string).name
                            this.fileDetails!!.filePath = string

                            val md5CheckSum = Constants.getMd5Checksum(string, mContext)
                            GlobalVarsAndFunctions.uniqueMd5Value[md5CheckSum] = "." + Constants.getExtension(string)
                            GlobalVarsAndFunctions.extensionHashSet.add("." + Constants.getExtension(string))

                            if (md5CheckSum == null) {
                                Log.e("getAllMediaByContent", "null md5CheckSum" )
                                continue
                            }

                            //if (fileDetailMapStr.containsKey(md5CheckSum)) {
                            Log.e("getAllMediaByContent", "listOfDuplicates.filter:"+listOfDuplicates.filter { it.md5CheckSum == md5CheckSum }.size )

                            if (listOfDuplicates.filter { it.md5CheckSum == md5CheckSum }.isNotEmpty()) {
                                //arrayList = fileDetailMapStr[md5CheckSum]!!
                                arrayList = listOfDuplicates.filter { it.md5CheckSum == md5CheckSum }.firstOrNull()!!.individualGrpOfDupes as ArrayList<FileDetails>
                                fileDetails = this.fileDetails

                                val duplicateList=listOfDuplicates.filter { it.individualGrpOfDupes?.size!! > 1 }
                                Handler(Looper.getMainLooper()).post {
                                    duplicateScanningListener.publishProgress(
                                        duplicateList
                                    )
                                }

                            } else {

                                val arrayList3: ArrayList<FileDetails> = ArrayList<FileDetails>()
                                arrayList3.add(this.fileDetails as FileDetails)
//                                fileDetailMapStr[md5CheckSum] = ArrayList<FileDetails>(arrayList3)
                                val duplicateGroupModel= DuplicateGroupModel()
                                duplicateGroupModel.md5CheckSum=md5CheckSum
                                duplicateGroupModel.isCheckBox=SharedPrefsConstant.getBooleanNoti(mContext, "duplicateSelection", true)
                                duplicateGroupModel.isCheckBox=false
                                duplicateGroupModel.individualGrpOfDupes=ArrayList<FileDetails>(arrayList3)
                                listOfDuplicates.add(duplicateGroupModel)

                            }

                            arrayList.add(fileDetails!!)
                            arrayList = ArrayList()
                        }
                        else {
                            Log.e("getAllMediaByContent", "path: $string not exist" )
                        }
                    }

                } else {
                    //query.moveToLast()
                    Handler(Looper.getMainLooper()).post {
                        duplicateScanningListener.publishProgress(
                            *arrayOf(counter.toString(), counter.toString())
                        )
                    }
                    break
                }
            } while (query.moveToNext())
            query.close()


//            val duplicateList=listOfDuplicates.filter { it.individualGrpOfDupes?.size!! > 1 }
//            Handler(Looper.getMainLooper()).post {
//                duplicateScanningListener.publishProgress(
//                    duplicateList
//                )
//            }


            fileDetailMapStr.clear()
            //return fileDetailMapStr

        } catch (e:Exception) {
            e.printStackTrace();

            Handler(Looper.getMainLooper()).post {
                duplicateScanningListener.publishProgress(
                    listOfDuplicates
                )
            }
            Log.e("test", "exception" + e.message + " " + e.cause);
            //return this.fileDetailMapStr;
        }
    }

    private fun checkPathContain(pathList: ArrayList<IgnorePath>, currentPath: String): Boolean {
        var needToAdd = true
        for (path in pathList) {
            if (currentPath.contains(path.path + "/")) {
                needToAdd = false
                return needToAdd
            }
        }
        return needToAdd
    }


}