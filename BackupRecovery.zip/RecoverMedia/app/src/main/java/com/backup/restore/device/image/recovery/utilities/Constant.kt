package com.backup.restore.device.image.recovery.utilities

import com.backup.restore.device.image.recovery.R

@JvmField
var SPAN_COUNT_THREE = 3

@JvmField
var SPAN_COUNT_TWO = 2


const val fontPath = "app_font/firasans_regular.ttf"
const val fontPathBold = "app_font/firasans_medium.ttf"

enum class Type { BACKUP_RECOVERABLE, BACKUP_TRASH, BACKUP_RECOVERED, FEEDBACK, SHARE, WIDGET, APK, CONTACTS, PICTURE, VIDEO, AUDIO, DOCUMENT, OTHER, EMPTYFOLDER, DUPLICATECONTACT, CLEANER, DEVICE, OS, CPU, BATTERY, WIFI, DISPLAY, RAM, ROM, CAMERA, SENSOR, TEST, UNINSTALLER }
data class Info(val name: Int, val thumb: Int, val type: Type)

//enum class TypeLanguage { TYPE_ENGLISH, TYPE_HINDI, TYPE_URDU, TYPE_ARABIC, TYPE_PORTUGUESE }
data class Language(val name: Int, val flag: Int, val type: String, var isSelected: Boolean = false)

fun getBackupOptions(): MutableList<Info> {
    val options: MutableList<Info> = ArrayList()
//    options.add(Info(R.string.recover, R.drawable.ic_home_photo_recover, Type.PICTURE_BACKUP))
    options.add(Info(R.string.trash, R.drawable.ic_home_trash, Type.BACKUP_TRASH))
    options.add(Info(R.string.scan, R.drawable.ic_home_recoverable, Type.BACKUP_RECOVERABLE))
    options.add(Info(R.string.recovered, R.drawable.ic_home_photo_recover, Type.BACKUP_RECOVERED))
    options.add(Info(R.string.apk_backup, R.drawable.ic_home_apk_backup_recover, Type.APK))
    options.add(Info(R.string.contacts, R.drawable.ic_home_contact_backup, Type.CONTACTS))
    options.add(Info(R.string.cleaner, R.drawable.ic_cleaner, Type.CLEANER))
//    options.add(Info(R.string.deep_scan, R.drawable.ic_deep_scan, Type.DEEP_SCAN))
    return options
}

fun getDuplicateOptions(): MutableList<Info> {
    val options: MutableList<Info> = ArrayList()
    options.add(Info(R.string.photo, R.drawable.ic_home_image_remover, Type.PICTURE))
    options.add(Info(R.string.video, R.drawable.ic_home_video_remover, Type.VIDEO))
    options.add(Info(R.string.audio, R.drawable.ic_home_audio_remover, Type.AUDIO))
    options.add(Info(R.string.document, R.drawable.ic_home_doc_remover, Type.DOCUMENT))
    options.add(Info(R.string.other_file, R.drawable.ic_home_other_file_remover, Type.OTHER))
    options.add(Info(R.string.empty_folder, R.drawable.ic_home_folder, Type.EMPTYFOLDER))
//    options.add(Info(R.string.contacts, R.drawable.ic_home_contact, Type.DUPLICATECONTACT))
//    options.add(Info(R.string.cleaner, R.drawable.ic_cleaner, Type.CLEANER))
    return options
}

fun getInformationOptions(): MutableList<Info> {
    val options: MutableList<Info> = ArrayList()
    options.add(Info(R.string.device, R.drawable.ic_device, Type.DEVICE))
    options.add(Info(R.string.os, R.drawable.ic_os, Type.OS))
    options.add(Info(R.string.cpu, R.drawable.ic_cpu, Type.CPU))
    options.add(Info(R.string.battery, R.drawable.ic_battery, Type.BATTERY))
    options.add(Info(R.string.wifi, R.drawable.ic_wifi, Type.WIFI))
    options.add(Info(R.string.display, R.drawable.ic_display, Type.DISPLAY))
    options.add(Info(R.string.ram, R.drawable.ic_ram, Type.RAM))
    options.add(Info(R.string.rom, R.drawable.ic_rom, Type.ROM))
    options.add(Info(R.string.camera, R.drawable.ic_camera_info, Type.CAMERA))
    options.add(Info(R.string.sensor, R.drawable.ic_sensor_info, Type.SENSOR))
    options.add(Info(R.string.device_test, R.drawable.ic_device_test, Type.TEST))
//    options.add(Info(R.string.add_widget, R.drawable.ic_widget, Type.WIDGET))
//    options.add(Info(R.string.feedback, R.drawable.ic_home_feedback, Type.FEEDBACK))
//    options.add(Info(R.string.share, R.drawable.ic_share_home, Type.SHARE))
    return options
}

fun getLanguageOptions(): MutableList<Language> {
    val options: MutableList<Language> = ArrayList()
    options.add(Language(R.string.english, R.drawable.ic_english, "en", true))
    options.add(Language(R.string.hindi, R.drawable.ic_hindi, "hi"))
    options.add(Language(R.string.urdu, R.drawable.ic_urdu, "ur"))
    options.add(Language(R.string.arabic, R.drawable.ic_arabic, "ar"))
    options.add(Language(R.string.portuguese, R.drawable.ic_portuguese, "pt"))
    return options
}
