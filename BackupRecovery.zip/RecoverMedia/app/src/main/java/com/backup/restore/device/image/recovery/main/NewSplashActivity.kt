package com.backup.restore.device.image.recovery.main

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.*
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import com.adconfig.AdsConfig
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.backup.restore.device.image.recovery.BuildConfig
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper

import com.backup.restore.device.image.recovery.ads.retrofit.model.ForceUpdateModel
import com.backup.restore.device.image.recovery.ads.updatejsonparsing.GetJsonUpdateResponseTask
import com.backup.restore.device.image.recovery.ads.updatejsonparsing.getForceUpdate
import com.backup.restore.device.image.recovery.ads.updatejsonparsing.saveForceUpdate
import com.backup.restore.device.image.recovery.databinding.ActivitySplashScreenBinding
import com.backup.restore.device.image.recovery.jsonparsing.JsonParserCallback
import com.backup.restore.device.image.recovery.mainapps.activity.LanguageActivity
import com.backup.restore.device.image.recovery.mainapps.asynctask.AutoCleanTrashAsyncTask
import com.backup.restore.device.image.recovery.multilang.LocaleManager
import com.backup.restore.device.image.recovery.service.ManagerService
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.example.jdrodi.utilities.OnPositive
import com.example.jdrodi.utilities.isOnline
import com.example.jdrodi.utilities.showAlert
import kotlinx.coroutines.*
import java.io.File
import java.util.*

class NewSplashActivity : BaseActivity() {
//class NewSplashActivity : BaseBindingActivity<ActivitySplashBinding>(), ProductPurchaseListener {

//    private var isActivityPause = false
//    private var isShouldUpdate = false
//    private var isCallOpenActivityWithAd = false

    private var mTimer: AdsCountDownTimer? = null
    private val TAG: String = "SplashActivity"

    lateinit var binding:ActivitySplashScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
//        changeLanguage()
        LocaleManager.setLocale(this@NewSplashActivity)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
//        setContentView(R.layout.activity_splash_screen)
        binding=ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(TAG)
    }

    override fun getContext(): BaseActivity {
        return this@NewSplashActivity
    }

//
//    fun changeLanguage() {
//        Log.e("SplashActivity", "changeLanguage")
//        val locale =
//            Locale(SharedPrefsConstant.getString(this, ShareConstants.SELECTED_LANGUAGE, "en")!!)
//        val config = this.resources.configuration
//
//        Log.e("SplashActivity", "changeLanguage-locale:$locale")
//        Log.e("SplashActivity", "changeLanguage-config.locale:" + config.locale)
//        if (config.locale != locale) {
//            config.locale = locale
//            Locale.setDefault(locale)
//            this.resources.updateConfiguration(config, this.resources.displayMetrics)
////            recreate()
//        }
//    }

    override fun initData() {
        SharedPrefsConstant.save(this, ShareConstants.RATE_LATTER, 0)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Log.e(
                TAG,
                "initData: ScanningDone --> " + SharedPrefsConstant.getBooleanNoti(
                    mContext,
                    "ScanningDone",
                    false
                )
            )
            Log.e(
                TAG,
                "initData: ScanningDone Permission --> " + Environment.isExternalStorageManager()
            )
            if (Environment.isExternalStorageManager() && SharedPrefsConstant.getBooleanNoti(
                    mContext,
                    "ScanningDone",
                    false
                )
            ) {
                startServiceMethod()
            }
        } else {
            if (checkPermissionStorage(this)) {
                startServiceMethod()
            }
        }

        if (ExitSPHelper(mContext).isDismissed()) {
            ExitSPHelper(mContext).saveDismissed(false)
        }

//        val calendar = Calendar.getInstance()
//        val currentTime = calendar.timeInMillis
//        val nextNotification = SharedPrefsConstant.getLong(this, "NextTimeToCleanTrash")
//        val previousCleanTime = SharedPrefsConstant.getLong(this, "PreviousCleanTime")
//        Log.e("junkReminder", "currentTime:$currentTime")
//        Log.e("junkReminder", "nextNotification:$nextNotification")
//        Log.e("junkReminder", "previousCleanTime:$previousCleanTime")
//        if (printDifference(previousCleanTime,currentTime)>=11 || previousCleanTime<=0 ) {
//            junkReminder()
//        }
    }

    private fun startServiceMethod() {
        try {
            if (!isMyServiceRunning(mContext, ManagerService::class.java)) {
                SharedPrefsConstant.savePrefNoti(mContext, "IsFromService", false)
                ManagerService.setData(mContext)
                startService(Intent(this, ManagerService::class.java))
                Log.e(
                    TAG,
                    "startServiceMethod: " + SharedPrefsConstant.getBooleanNoti(
                        mContext,
                        "IsFromService",
                        false
                    )
                )
            }
        } catch (e: java.lang.Exception) {
            Log.e(TAG, "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }


    fun printDifference(startDate: Long, endDate: Long): Long {
        //milliseconds
//        long different = endDate.getTime() - startDate.getTime();
        var different = endDate - startDate
        val secondsInMilli: Long = 1000
        val minutesInMilli = secondsInMilli * 60
        val hoursInMilli = minutesInMilli * 60
        val daysInMilli = hoursInMilli * 24
        val elapsedDays = different / daysInMilli
        different = different % daysInMilli
        val elapsedHours = different / hoursInMilli
//        different = different % hoursInMilli
//        val elapsedMinutes = different / minutesInMilli
//        different = different % minutesInMilli
//        val elapsedSeconds = different / secondsInMilli
        Log.e("junkReminder", "Days:$elapsedDays")
        Log.e("junkReminder", "Hours:$elapsedHours")
//        Log.e("junkReminder", "Minutes:$elapsedMinutes")
//        Log.e("junkReminder", "Seconds:$elapsedSeconds")
        return elapsedHours + (elapsedDays*24)
    }

    fun a(str: String?): String? {
        requireNotNull(str) { "Parameter is invalid. File path can't be null." }
        val sb = StringBuilder()
        try {
            val mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "DCIM/Backup And Recovery"
            sb.append(mRootPath)
        } catch (e: IllegalArgumentException) {
            val mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "DCIM/Backup And Recovery"
            sb.append(mRootPath)
        } catch (e: NullPointerException) {
            val mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "DCIM/Backup And Recovery"
            sb.append(mRootPath)
        }
        sb.append(File.separator)
        sb.append(".trash")
        sb.append(File.separator)
        return sb.toString()
    }

//    private fun junkReminder() {
//        val calendar = Calendar.getInstance()
//        val currentTime = calendar.timeInMillis
//
//        val interval = SharedPrefsConstant.getString(this, "cleanTrashInterval", "off")
//        Log.e("junkReminder", "interval:$interval")
//        if (interval == "off") {
//            // off
//        } else if (interval == "1week") {
//            // 1 week
//            Handler(Looper.getMainLooper()).post {
//                calendar.add(Calendar.HOUR, 12)
//                SharedPrefsConstant.save(mContext, "NextTimeToCleanTrash", calendar.timeInMillis)
//                SharedPrefsConstant.save(mContext, "PreviousCleanTime", currentTime)
//                AutoCleanTrashAsyncTask(mContext, "", a("/"), 7).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//            }
//        } else if (interval == "1month") {
//            // 1 month
//            Handler(Looper.getMainLooper()).post {
//                calendar.add(Calendar.HOUR, 12)
//                SharedPrefsConstant.save(mContext, "NextTimeToCleanTrash", calendar.timeInMillis)
//                SharedPrefsConstant.save(mContext, "PreviousCleanTime", currentTime)
//                AutoCleanTrashAsyncTask(mContext, "", a("/"), 30).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//            }
//        } else if (interval == "3month") {
//            // 3 month;
//            Handler(Looper.getMainLooper()).post {
//                calendar.add(Calendar.HOUR, 12)
//                SharedPrefsConstant.save(mContext, "NextTimeToCleanTrash", calendar.timeInMillis)
//                SharedPrefsConstant.save(mContext, "PreviousCleanTime", currentTime)
//                AutoCleanTrashAsyncTask(mContext, "", a("/"), 90).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//            }
//        }
//    }


    override fun initActions() {
        setAdDelay()
    }

//    override fun onResume() {
//        super.onResume()
//        if (isActivityPause) {
//            isActivityPause = false
//            mTimer?.start()
////            redirectToNextActivity()
//        }
//    }

    override fun initViews() {
        super.initViews()
//        forceUpdateNew()

//        if (mContext.isOnline()) {
//
//            // Fetch App center data from the server
//            if (isSDKBelow21()) {
//                // Simple json parsing
////                val url = mContext.getUpdateBaseUrl() + "ApkVersion"
////                val pkgName = packageName
////                val version = BuildConfig.VERSION_NAME.toDouble()
////                GetJsonUpdateResponseTask(object : JsonParserCallback {
////                    override fun onSuccess(response: String) {
////                        Log.i(TAG, response)
////                        saveForceUpdate(response)
////                        checkUpdateStatus(getForceUpdate())
////                    }
////
////                    override fun onFailure(message: String) {
////                        Log.e(TAG, message)
////                        bindServices()
////                    }
////
////                }).executeOnExecutor(
////                    AsyncTask.THREAD_POOL_EXECUTOR,
////                    url,
////                    pkgName,
////                    version.toString()
////                )
//
//            } else {
//                // Using retrofit with kotlin coroutine
//                // To verify force update status
//                launch {
//                    checkForceUpdateStatus()
//                }
//            }
//
//
//        }
//        else {
//            Log.i(TAG, "offline")
            bindServices()
//        }

    }

    private suspend fun checkForceUpdateStatus() {
        return withContext(Dispatchers.IO) {
            bindServices()
//            val retroApiInterface = APIService().getUpdateClient(mContext)
//            try {
//                val pkgName = packageName
//                val version = BuildConfig.VERSION_NAME.toDouble()
//
//                val reqUpdateStatus = retroApiInterface.getUpdateStatusAsync(pkgName, version)
//
//                val resUpdateStatus = reqUpdateStatus.await()
//                if (resUpdateStatus.isSuccessful && resUpdateStatus.body() != null) {
//                    val body = resUpdateStatus.body()!!
//                    checkUpdateStatus(body)
//                } else {
//                    Log.e(TAG, "isSuccessful: false")
//                    bindServices()
//                }
//
//            } catch (exception: Exception) {
//                Log.e(TAG, exception.toString())
//                bindServices()
//            }
        }
    }

    fun rateApp() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (exception: ActivityNotFoundException) {
            Log.e(TAG, exception.toString())
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                )
            )
        }
    }

    private fun checkUpdateStatus(forceUpdateModel: ForceUpdateModel) {
        Log.e(TAG, "message: " + forceUpdateModel.message)
        if (forceUpdateModel.is_need_to_update) {
            Log.i(TAG, "is_need_to_update: true")
            runOnUiThread {
                showAlert(
                    getString(R.string.update_required),
                    getString(R.string.update_message),
                    getString(R.string.update_positive),
                    getString(R.string.update_negative),
                    fontPath,
                    object : OnPositive {
                        override fun onYes() {
                            rateApp()
                            finish()
                        }

                        override fun onNo() {
                            super.onNo()
                            finishAffinity()
                        }
                    })
            }
        } else {
            Log.e(TAG, "is_need_to_update: false")
            bindServices()
        }
    }

//    override fun initView() {
//        super.initView()
//
//        forceUpdateNew()
//    }

//    private fun forceUpdateNew() {
//        ForceUpdateHelper(mActivity).checkForceUpdateStatus(object :
//            ForceUpdateHelper.ForceUpateEvent {
//            override fun onUpdateNeeded(shouldUpdate: Boolean) {
//                isShouldUpdate = shouldUpdate
//                if (!shouldUpdate) {
//                    bindServices()
//                }
//            }
//        })
//    }

    private fun bindServices() {
//        runOnUiThread {
//            try {
//                Log.e(TAG, "bindServices: try")
//                InAppPurchaseHelper.instance!!.initBillingClient(mContext, this)
//            } catch (e: Exception) {
//                Log.e(TAG, "initBillingClient: " + e.message)
//            }
//        }
    }

    override fun onClick(v: View) {}

    //<editor-fold desc="For Check In-App Purchase">
//    override fun onPurchasedSuccess(purchase: Purchase) {}
//
//    override fun onProductAlreadyOwn() {}
//
//    override fun onBillingSetupFinished(billingResult: BillingResult) {
//
//        when (billingResult.responseCode) {
//            BillingClient.BillingResponseCode.OK -> {
//                GlobalScope.launch(Dispatchers.Main) {
////                    InAppPurchaseHelper.instance!!.initProducts()
//                    InAppPurchaseHelper.instance!!.initSubscription()
//                    Log.e(TAG, "IN_APP_BILLING | Done")
//                    redirectToNextActivity()
//                }
//            }
//            else -> {
//                CoroutineScope(Dispatchers.Main).launch {
//                    Log.i(TAG, "onBillingSetupFinished: IN_APP_BILLING | Else")
//                    redirectToNextActivity()
//                }
//            }
//        }
//    }
//
//    override fun onBillingUnavailable() {
//        redirectToNextActivity()
//    }
//
//    override fun onBillingKeyNotFound(productId: String) {
//    }

    private fun redirectToNextActivity() {
//        save(IS_ADS_REMOVED, !isRemovedAds)
//        isNeedToAdShow
//        if (!isCallOpenActivityWithAd) {
//            checkLoadAds()
//        } else {
//            mTimer?.start()
//        }


    }

    private fun checkLoadAds() {
//        Log.e(TAG, "checkLoadAds: getBoolean -> ${getBoolean(IS_ADS_REMOVED)}")

//        if (AdsManager(mContext).isNeedToShowAds()) {
////        if (contain(IS_ADS_REMOVED) && getBoolean(IS_ADS_REMOVED)) {
//            setPurchasedSplashDelay()
//        } else {
            setAdDelay()
//        }
    }
    //</editor-fold>

    //<editor-fold desc="Splash Screen Showing Time">
    private fun setPurchasedSplashDelay() {
        startTimer(1000)
    }

    private fun setAdDelay() {
        if (mContext.isOnline()) {

            startTimer(3000)
            Log.e(TAG, "initAds: Ads Loading")

//            InterstitialAdHelper.loadInterstitialAd(
//                fContext = mContext,
//                fIsShowFullScreenNativeAd = false,
//                onAdLoaded = {
//                    Log.e(TAG, "initAds: Ad Loaded")
//                    MyApplication.isInterstitialShown = false
//                    openActivityWithAd()
//                })

            openActivityWithAd()
        } else {
            setPurchasedSplashDelay()
        }
    }

    private fun startTimer(fTime: Long) {
        mTimer?.cancel()
        mTimer = AdsCountDownTimer(millisInFuture = fTime, countDownInterval = 1000)
        mTimer?.start()
    }
    //</editor-fold>

    //<editor-fold desc="Call Next Activity">
    private fun openActivityWithAd() {

        mTimer?.cancel()
        mTimer = null

        AdsConfig.showInterstitialAd(mContext,{

            MyApplication.isInterstitialShown = false
            startNextActivity()
        })
    }

    private fun startNextActivity() {
//        if (!isShouldUpdate && !isSplashCallDashboard) {
        Log.e(TAG, "startNextActivity: ")
//            isSplashCallDashboard = true
        if (isFirstLaunch()) {
//            saveFirstLaunch()

            val i = Intent(mContext, LanguageActivity::class.java)
//            val i = Intent(mContext, IntroActivity::class.java)
            i.putExtra("isFromSplash", true)
            startActivity(i)
        } else {
            startActivity(NewHomeActivity.newIntent(mContext))
        }
        finish()
//        }
    }
    //</editor-fold>

    override fun onBackPressed() {}

    override fun onPause() {
        super.onPause()
//        mTimer?.cancel()
    }

    inner class AdsCountDownTimer(private val millisInFuture: Long, countDownInterval: Long) :
        CountDownTimer(millisInFuture, countDownInterval) {
        override fun onTick(millisUntilFinished: Long) {
            Log.e(TAG, "onTick: Time::${(((millisInFuture - millisUntilFinished) / 1000) + 1)}")
        }

        override fun onFinish() {
            Log.e(TAG, "countDownTimer: onFinish")
            openActivityWithAd()
        }
    }
}