package com.backup.restore.device.image.recovery.mainapps.adapter

import android.app.Activity
import android.content.ActivityNotFoundException
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.example.jdrodi.callback.RVClickListener
import java.text.SimpleDateFormat
import java.util.*

class ContactHistoryAdapter(
    private val mContext: Activity,
    var savedHistory: ArrayList<String>,
    var mType: Int,
    var mRvListener: RVClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


//    companion object {
//        @JvmField
//        var filterSavedFiles: ArrayList<String>? = null
//    }
//
//    init {
//        filterSavedFiles = savedHistory
//    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ll_item: LinearLayout = itemView.findViewById(R.id.ll_item)
        var iconImage: ImageView = itemView.findViewById(R.id.application_icon_image)
        var titleText: TextView = itemView.findViewById(R.id.application_label_text)
        var subTitleText: TextView = itemView.findViewById(R.id.application_sub_title)

    }

    override fun getItemCount(): Int {
        return savedHistory!!.size
    }

    fun getItem(position: Int): String {
        return savedHistory!![position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val menuItemLayoutView = LayoutInflater.from(parent.context)
            .inflate(R.layout.raw_backup_history_item, parent, false)
        return MyViewHolder(menuItemLayoutView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val menuItemHolder = holder as MyViewHolder
        try {


            val mPath = savedHistory!![position]
            Log.e("onBindViewHolder", "mType :$mType")
            Log.e("onBindViewHolder", "mPath :$mPath")
            Log.e("onBindViewHolder", ":::::::::::::::::::")
            val tempName = mPath!!.split("#").toTypedArray()
//            val filename = tempName[0]


//            var mPath = "/"
            val filename: String = mPath.substring(mPath.lastIndexOf("/") + 1)
            var subTitle: String = ""
            if(mType==0) {
                menuItemHolder.iconImage.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_excel_icon))
                subTitle=filename.toLowerCase().replace("contact_","").replace(".xlsx","").replace(".xls","")
                if(subTitle.trim().isEmpty()) subTitle=filename.replace(".xlsx","").replace(".xls","")
            } else {
                menuItemHolder.iconImage.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_pdf_icon))
                subTitle=filename.toLowerCase().replace("contact_","").replace(".pdf","")
                if(subTitle.trim().isEmpty()) subTitle=filename.replace(".pdf","")
            }

            val formatter = SimpleDateFormat("ddMMyyyy_hh_mm_ss", Locale.getDefault())
            val date = formatter.parse(subTitle)
            val formatter1 = SimpleDateFormat("dd/MM/yyyy hh:mm aa", Locale.getDefault())

            menuItemHolder.titleText.text = filename
            menuItemHolder.subTitleText.text = formatter1.format(date!!)

            menuItemHolder.ll_item.setOnClickListener {
                try {
                    mRvListener.onItemClick(position)
//                    val uri: Uri =
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) FileProvider.getUriForFile(
//                            mContext, mContext.packageName + ".provider",
//                            File(savedHistory!![position])
//                        ) else Uri.fromFile(
//                            File(savedHistory!![position])
//                        )
//                    val intent = Intent(Intent.ACTION_VIEW)
//                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
//                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//                    intent.setDataAndType(uri, "application/vnd.android.package-archive")
//                    mContext.startActivity(intent)
//                    isInternalCall = true
                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun filterList(filteredNames: ArrayList<String>) {
        savedHistory = filteredNames
        if (savedHistory!!.isEmpty()) {
            mRvListener.onEmpty()
        } else {
            mRvListener.onNotEmpty()
        }
        notifyDataSetChanged()
    }
}