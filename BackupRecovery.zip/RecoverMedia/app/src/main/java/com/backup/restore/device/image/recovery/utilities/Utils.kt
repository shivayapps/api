package com.backup.restore.device.image.recovery.utilities

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.util.Base64
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityOptionsCompat
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.getReadableFileSize
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.example.jdrodi.utilities.isValidEmail
import java.io.*
import java.nio.charset.Charset
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Matcher
import java.util.regex.Pattern

fun getBaseUrl(encoded: String): String {
    val dataDec: ByteArray = Base64.decode(encoded, Base64.DEFAULT)
    var decodedString = ""
    try {
        decodedString = String(dataDec, Charset.forName("UTF-8"))
    } catch (e: UnsupportedEncodingException) {
        e.printStackTrace()
    } finally {
        return decodedString
    }
}

fun Activity.changeLanguage() {
//    Log.e("UtilsKT", "changeLanguage:" + this.localClassName)
//    val locale = Locale(SharedPrefsConstant.getString(this, ShareConstants.SELECTED_LANGUAGE, "en")!!)
//    val config = this.resources.configuration
//
//    config.locale = locale
//    Locale.setDefault(locale)
//    this.resources.updateConfiguration(config, this.resources.displayMetrics)
//    recreate()
}

fun Activity.changeLanguageNew() {
    Log.e("UtilsKT", "changeLanguage:" + this.localClassName)
    val locale = Locale(SharedPrefsConstant.getString(this, ShareConstants.SELECTED_LANGUAGE, "en")!!)
    val config = this.resources.configuration

    config.locale = locale
    Locale.setDefault(locale)
    this.resources.updateConfiguration(config, this.resources.displayMetrics)
    recreate()
}

fun Activity.changeLanguageAndAnimate() {
    Log.e("UtilsKT", "changeLanguage:" + this.localClassName)
    val locale =
        Locale(SharedPrefsConstant.getString(this, ShareConstants.SELECTED_LANGUAGE, "en")!!)
    val config = this.resources.configuration

    config.locale = locale
    Locale.setDefault(locale)
    this.resources.updateConfiguration(config, this.resources.displayMetrics)
//    if(animate) {
//    recreateWithAnimation(this)

    val restartIntent = Intent(this, this.javaClass)
    val extras = this.intent.extras
    if (extras != null) {
        restartIntent.putExtras(extras)
    }
//    this.recreate()
    this.finish()
    ActivityCompat.startActivity(
        this,
        restartIntent,
        ActivityOptionsCompat
            .makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out)
            .toBundle()
    )

//    } else {
//        recreate()
//    }
}

fun recreateWithAnimation(activity: Activity) {
    val restartIntent = Intent(activity, activity.javaClass)
    val extras = activity.intent.extras
    if (extras != null) {
        restartIntent.putExtras(extras)
    }
//    activity.recreate()
    ActivityCompat.startActivity(
        activity,
        restartIntent,
        ActivityOptionsCompat
            .makeCustomAnimation(activity, android.R.anim.fade_in, android.R.anim.fade_out)
            .toBundle()
    )
    activity.finish()
}


//fun Context.getUpdateBaseUrl(): String {
//    return getBaseUrl(getString(R.string.base_url_update))
//}
//fun Context.getReviewBaseUrl(): String {
//    return getBaseUrl(getString(R.string.base_url_review_live))
//}

//fun Context.getPrivacyPolicyUrl(): String {
//    return getBaseUrl(getString(R.string.base_url_privacy_policy))
//}

//fun Context.getTermConditionUrl(): String {
//    return getBaseUrl(getString(R.string.base_url_term_condition))
//}

private val mB = java.lang.Long.valueOf(1073741824)
private val mi = ActivityManager.MemoryInfo()

@SuppressLint("WrongConstant")
fun getUseRam(activity: Activity): String? {
    (activity.getSystemService("activity") as ActivityManager).getMemoryInfo(mi)
    val availableRAM = java.lang.Long.valueOf(mi.availMem / mB.toLong())
    val totalMegs = java.lang.Long.valueOf(mi.totalMem / mB.toLong())
    val useRAM = java.lang.Long.valueOf(totalMegs - availableRAM)
    return getReadableFileSize(useRAM)
}

@SuppressLint("WrongConstant")
fun getFreeRam(activity: Activity): String? {
    (activity.getSystemService("activity") as ActivityManager).getMemoryInfo(mi)
    val availableRAM = java.lang.Long.valueOf(mi.availMem / mB.toLong())
    return getReadableFileSize(availableRAM)
}

@SuppressLint("WrongConstant")
fun getTotalRam(activity: Activity): String? {
    (activity.getSystemService("activity") as ActivityManager).getMemoryInfo(mi)
    val totalMegs = java.lang.Long.valueOf(mi.totalMem / mB.toLong())
    return getReadableFileSize(totalMegs)
}

//public static String removeExtension(String filename) {
fun removeExtension(filename: String?): String {
    if (filename == null) {
        return "";
    }
    val index = indexOfExtension(filename);
    if (index == -1) {
        return filename;
    } else {
        return filename.substring(0, index);
    }
}

fun generateEmptyFile(prefix: String, ext: String): File {
    val timeStamp = SimpleDateFormat("ddMMyyyy_HH_mm_ss", Locale.getDefault()).format(Date())
    val FILENAME = "${prefix}_$timeStamp.${ext}"

    ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
    val path = ShareConstants.mRootPath + "/Backup And Recovery/Contact Backup/"
    val dir = File(path)
    if (!dir.exists()) {
        dir.mkdir()
    }
    var filePath = dir.path + File.separator + FILENAME
    val file = File(dir.path + File.separator + FILENAME)

    if (File(filePath).exists()) {
        File(filePath).delete()
    }
    if (!File(file.parent!!).exists()) {
        File(file.parent!!).mkdir()
    }

    if (!file.exists()) File(file.parent).mkdirs()
    return file
}

fun getExtension(filename: String?): String {
    if (filename == null) {
        return ""
    }
    val index = indexOfExtension(filename)
    return if (index == -1) {
        ""
    } else {
        filename.substring(index + 1)
    }
}

fun indexOfExtension(filename: String?): Int {
    if (filename == null) {
        return -1
    }
    val extensionPos = filename.lastIndexOf('.')
    val lastSeparator = indexOfLastSeparator(filename)
    return if (lastSeparator > extensionPos) -1 else extensionPos
}

fun indexOfLastSeparator(filename: String?): Int {
    if (filename == null) {
        return -1
    }
    val lastUnixPos = filename.lastIndexOf('/')
    val lastWindowsPos = filename.lastIndexOf('\\')
    return Math.max(lastUnixPos, lastWindowsPos)
}

fun doCopyFile(srcFile: File, destFile: File, preserveFileDate: Boolean) {
    if (destFile.exists() && destFile.isDirectory) {
        throw IOException("Destination '$destFile' exists but is a directory")
    }
    if (!destFile.exists()) File(destFile.parent).mkdirs()

    val input = FileInputStream(srcFile)
    try {
        val output = FileOutputStream(destFile)
        try {
            val count = copyLarge(input, output)
            if (count > Int.MAX_VALUE) {
                -1
            } else count.toInt()
        } finally {
            output.close()
        }
    } finally {
        input.close()
    }
    if (srcFile.length() != destFile.length()) {
        throw IOException(
            "Failed to copy full contents from '" +
                    srcFile + "' to '" + destFile + "'"
        )
    }
    if (preserveFileDate) {
        destFile.setLastModified(srcFile.lastModified())
    }
}

@Throws(IOException::class)
fun copyLarge(input: InputStream, output: OutputStream): Long {
    val buffer = ByteArray(1024 * 4)
    var count: Long = 0
    var n = 0
    while (-1 != input.read(buffer).also { n = it }) {
        output.write(buffer, 0, n)
        count += n.toLong()
    }
    return count
}

fun checkPermissionStorage(context: Context): Boolean {
    return ActivityCompat.checkSelfPermission(
        context,
        Manifest.permission.READ_EXTERNAL_STORAGE
    ) == PackageManager.PERMISSION_GRANTED
            && ActivityCompat.checkSelfPermission(
        context,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    ) == PackageManager.PERMISSION_GRANTED
}

fun checkPermissionContact(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        (ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED)
    } else {
        (ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED)
    }
}

fun Context.getUsedMemorySize(): String? {
    return getReadableFileSize(busyMemory())
}

fun Context.getFreeMemorySize(): String? {
    return getReadableFileSize(freeMemory())
}

fun Context.getTotalMemorySize(): String? {
    return getReadableFileSize(totalMemory())
}

public fun Drawable.toBitmap(): Bitmap {
    var bitmap: Bitmap? = null
    if (this is BitmapDrawable) {
        val bitmapDrawable: BitmapDrawable = this as BitmapDrawable
        if (bitmapDrawable.bitmap != null) {
            return bitmapDrawable.bitmap
        }
    }
    bitmap = if (this.intrinsicWidth <= 0 || this.intrinsicHeight <= 0) {
        Bitmap.createBitmap(
            1,
            1,
            Bitmap.Config.ARGB_8888
        ) // Single color bitmap will be created of 1x1 pixel
    } else {
        Bitmap.createBitmap(
            this.intrinsicWidth,
            this.intrinsicHeight,
            Bitmap.Config.ARGB_8888
        )
    }
    val canvas = Canvas(bitmap)
    this.setBounds(0, 0, canvas.width, canvas.height)
    this.draw(canvas)
    return bitmap

}

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
fun getUsedMemory(isReadable: Boolean = true): String? {
    val path = Environment.getDataDirectory()
    val stat = StatFs(path.path)
    val blockSize = stat.blockSizeLong
    val availableBlocks = stat.availableBlocksLong
    val totalBlocks = stat.blockCountLong
    val freeStorage = totalBlocks - availableBlocks
    return if (isReadable) getReadableFileSize(freeStorage * blockSize)
    else (freeStorage * blockSize).toString()

}

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
fun getAvailableInternalMemorySize(isReadable: Boolean = true): String? {
    val path = Environment.getDataDirectory()
    val stat = StatFs(path.path)
    val blockSize = stat.blockSizeLong
    val availableStorage = stat.availableBlocksLong
    return if (isReadable) getReadableFileSize(availableStorage * blockSize)
    else (availableStorage * blockSize).toString()
}

public fun String.isValidContactInformation(): Boolean {
    return when {
        this.contains("@") -> {
            this.isValidEmail()
        }
        this.isValidPhone() -> {
            return true
        }
        else -> {
            return false
        }
    }
}

fun String.isValidPhone(): Boolean {
    val phonePattern = "^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$"
    val pattern = Pattern.compile(phonePattern)
    val matcher: Matcher = pattern.matcher(this)
    return matcher.matches()
}

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
fun getAvailableInternalMemorySizeInLong(): Long {
    val path = Environment.getDataDirectory()
    val stat = StatFs(path.path)
    val blockSize = stat.blockSizeLong
    val availableStorage = stat.availableBlocksLong
    return availableStorage * blockSize
}

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
fun getTotalInternalMemorySize(isReadable: Boolean = true): String? {
    val path = Environment.getDataDirectory()
    val stat = StatFs(path.path)
    val blockSize = stat.blockSizeLong
    val totalBlocks = stat.blockCountLong
    return if (isReadable) getReadableFileSize(totalBlocks * blockSize)
    else (totalBlocks * blockSize).toString()
}

fun Context.loadImage(resId: Int, imageView: ImageView, progressBar: View?) {

    val thumbnail = R.drawable.ic_home_photo_recover
    val thumbnailRequest = Glide.with(this).load(thumbnail)

    Glide.with(this)
        .load(resId)
        .placeholder(thumbnail)
        .error(thumbnail)
        .thumbnail(thumbnailRequest)
        .centerInside()
        .listener(object : RequestListener<Drawable?> {
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable?>?,
                isFirstResource: Boolean
            ): Boolean {
                progressBar?.visibility = View.GONE
                imageView.visibility = View.VISIBLE
                return false
            }

            override fun onResourceReady(
                resource: Drawable?,
                model: Any?,
                target: Target<Drawable?>?,
                dataSource: DataSource?,
                isFirstResource: Boolean
            ): Boolean {
                progressBar?.visibility = View.GONE
                imageView.visibility = View.VISIBLE
                return false
            }
        }).into(imageView)
}

/*************************************************************************************************
 * Returns size in bytes.
 *
 * If you need calculate external memory, change this:
 * StatFs statFs = new StatFs(Environment.getRootDirectory().getAbsolutePath());
 * to this:
 * StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
 */

fun totalMemory(): Long {
    val statFs = StatFs(Environment.getExternalStorageDirectory().absolutePath)
    return (statFs.blockCount * statFs.blockSize).toLong()
}

fun freeMemory(): Long {
    val statFs = StatFs(Environment.getExternalStorageDirectory().absolutePath)
    return (statFs.availableBlocks * statFs.blockSize).toLong()
}

fun busyMemory(): Long {
    val statFs = StatFs(Environment.getExternalStorageDirectory().absolutePath)
    val total = (statFs.blockCount * statFs.blockSize).toLong()
    val free = (statFs.availableBlocks * statFs.blockSize).toLong()
    return total - free
}


fun isMyServiceRunning(mContext: Context, serviceClass: Class<*>): Boolean {
    val manager = mContext.getSystemService(AppCompatActivity.ACTIVITY_SERVICE) as ActivityManager
    for (service in manager.getRunningServices(Int.MAX_VALUE)) {
        if (serviceClass.name == service.service.className) {
            return true
        }
    }
    return false
}

fun floatForm(d: Double): String {
    return DecimalFormat("#.##").format(d)
}

//fun bytesToHuman(size: Long): String? {
//    val Kb = 1 * 1024.toLong()
//    val Mb = Kb * 1024
//    val Gb = Mb * 1024
//    val Tb = Gb * 1024
//    val Pb = Tb * 1024
//    val Eb = Pb * 1024
//    if (size < Kb) return floatForm(size.toDouble()) + " byte"
//    if (size in Kb until Mb) return floatForm(size.toDouble() / Kb) + " KB"
//    if (size in Mb until Gb) return floatForm(size.toDouble() / Mb) + " Mb"
//    if (size in Gb until Tb) return floatForm(size.toDouble() / Gb) + " Gb"
//    if (size in Tb until Pb) return floatForm(size.toDouble() / Tb) + " Tb"
//    if (size in Pb until Eb) return floatForm(size.toDouble() / Pb) + " Pb"
//    return if (size >= Eb) floatForm(size.toDouble() / Eb) + " Eb" else "???"
//}


fun isSDKBelow21(): Boolean {
    // Check if we're running on Android 5.0 or higher
    return Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP
}

