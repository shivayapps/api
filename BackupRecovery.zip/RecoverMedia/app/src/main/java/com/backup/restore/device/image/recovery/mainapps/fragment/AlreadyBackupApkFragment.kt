package com.backup.restore.device.image.recovery.mainapps.fragment

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.databinding.FragmentAlreadyBackupApkBinding
import com.backup.restore.device.image.recovery.mainapps.activity.AppsBackupActivity
import com.backup.restore.device.image.recovery.mainapps.adapter.AlreadyBackupAdapter
import com.backup.restore.device.image.recovery.mainapps.model.SelectedApk
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.mLastClickTime
import com.example.jdrodi.callback.RVClickListener
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@Suppress("DEPRECATION")
class AlreadyBackupApkFragment : Fragment(), View.OnClickListener {

    val mTAG: String = AlreadyBackupApkFragment::class.java.simpleName

    private var path = ""
    var mSavedApps = ArrayList<SelectedApk>()
    var mAlreadyBackupAdapter: AlreadyBackupAdapter? = null
    var mGetFiles: AsyncTask<*, *, *>? = null
    var isVisibleToUser = false
    var mTempList = ArrayList<SelectedApk>()
    var mContext : AppsBackupActivity? = null

    var search_apk : EditText? = null

    companion object {
        var isResumeCheck = true
        fun newInstance(): AlreadyBackupApkFragment {
            val fragment = AlreadyBackupApkFragment()
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = (requireActivity() as AppsBackupActivity)
    }


    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        this.isVisibleToUser = isVisibleToUser
        if (isVisibleToUser && ShareConstants.isBackup) {
            initViewsActions("Visible")
            ShareConstants.isBackup = false
        }
    }

//    lateinit var mView: View
    lateinit var binding: FragmentAlreadyBackupApkBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
//        mView = inflater.inflate(R.layout.fragment_already_backup_apk, container, false)
        binding = FragmentAlreadyBackupApkBinding.inflate(layoutInflater, container, false)
        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        path = ShareConstants.mRootPath + "/Backup And Recovery/Apk Backup/"
        Log.e(mTAG, "Root : $path")
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        findViews()
        setListeners()
        initViewsActions("Create")
    }

    private fun initViewsActions( From : String) {
        Log.e(mTAG, "getAppList: getFile $From")
        mGetFiles = GetFiles().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    private fun findViews() {
        mContext = (requireActivity() as AppsBackupActivity)

        search_apk = mContext!!.binding.etSearchApk

        MyUtils.hideKeyboard(mContext, search_apk)
        binding.rvAlreadyBackup.layoutManager = LinearLayoutManager(mContext)
        binding.rvAlreadyBackup.setHasFixedSize(true)
        binding.tvMsg!!.visibility = View.GONE

    }

    private fun setListeners() {
        mContext!!.binding.ivDeleteAll!!.setOnClickListener(this)
        search_apk!!.setOnClickListener {
           search_apk!!.isFocusable = true
           search_apk!!.isFocusableInTouchMode = true
           search_apk!!.requestFocus()
        }
        search_apk!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (search_apk!!.text.toString().isEmpty()) {
                    search_apk!!.clearFocus()
                    MyUtils.hideKeyboard(mContext, search_apk)
                } else {
                    search_apk!!.requestFocus()
                }
            }

            override fun afterTextChanged(s: Editable) {
                if (mAlreadyBackupAdapter != null) {
                    filter(s.toString())
                }
            }
        })
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {

            R.id.ivDeleteAll -> {
                val dialog = Dialog(mContext!!)
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setCancelable(false)
                dialog.setContentView(R.layout.dialog_confirmation)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialog.window!!.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )

//                dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
                dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
                dialog.findViewById<TextView>(R.id.permission_text).setText(R.string.sure_to_delete_all_apk_file)
                dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
                dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

                dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
                    dialog.cancel()
                    MyApplication.isDialogOpen = false
                    Handler().postDelayed(
                        {
                            binding.tvMsg!!.visibility = View.GONE
                            clearSearch()
                            binding.rvAlreadyBackup!!.stopScroll()
                            DeleteAllFiles().execute()
                        }, 500
                    )
                }
                dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                    dialog.cancel()
                    MyApplication.isDialogOpen = false
                }
                dialog.setOnDismissListener {
                    MyApplication.isDialogOpen = false
                }

                dialog.show()
                MyApplication.isDialogOpen = true
                MyApplication.isInternalCall = true
            }
        }
    }

    fun clearSearch() {
       search_apk!!.text = null
       search_apk!!.clearFocus()
        MyUtils.hideKeyboard(mContext, search_apk)
    }

    private fun filter(text: String) {
        mTempList = mSavedApps
        val filteredList = ArrayList<SelectedApk>()
        for (s in mTempList) {
            val lPackageName = s.label
            val tempName = lPackageName?.split("#")?.toTypedArray()
            val appName = tempName?.get(0)
            if (appName!!.toLowerCase(Locale.ROOT).contains(text.toLowerCase(Locale.ROOT))) {
                filteredList.add(s)
            }
        }
        mTempList = filteredList
        mAlreadyBackupAdapter!!.filterList(mTempList)
    }

    private inner class GetFiles : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(mContext!!)

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.findViewById<TextView>(R.id.permission).text =
                getString(R.string.label_please_wait)
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.fetching_backup_apk)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)

            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                dialog.cancel()
                MyApplication.isDialogOpen = false
                cancel(true)
            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (isVisibleToUser) {
                if (!dialog.isShowing) {
                    dialog.show()
                    MyApplication.isDialogOpen = true
                }
            }
            mSavedApps.clear()
        }

        override fun doInBackground(vararg strings: String?): String? {
            mSavedApps.clear()
            val dir = File(path)
            Log.e(mTAG, "doInBackground:path::> $path")
            val files = dir.listFiles()
            if (files != null) {
                for (file in files) {
                    if (file.name.endsWith(".apk")) {
                        var obj = SelectedApk()
                        val packageInfo =  mContext!!.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
                        if (packageInfo != null) {
                            packageInfo.applicationInfo.sourceDir = file.absolutePath
                            packageInfo.applicationInfo.publicSourceDir = file.absolutePath
                            try {
                                val icon = packageInfo.applicationInfo.loadIcon(mContext!!.packageManager)
                                Log.e(mTAG, "doInBackground:icon --> $icon")
                                obj.drawable = icon
                            }catch (Ex : Exception){
                                Log.e(mTAG, "doInBackground:Exception --> " +Ex.message )
                            }
                        }

                        obj.size = file.length().toDouble()
                        obj.installedTime = getDate(file.lastModified())
                        obj.appName = file.absolutePath
                        obj.label = file.name
                        obj.size = file.length().toDouble()
                        obj.installedTime=getDate(file.lastModified())

                        mSavedApps.add(obj)
                    }
                    if (mGetFiles!!.isCancelled) {
                        mContext!!.runOnUiThread {
                            dialog.cancel()
                            MyApplication.isDialogOpen = false
                            ShareConstants.isBackup = true
                        }
                        break
                    }
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {
                if(isAdded) {
                    Handler(Looper.getMainLooper()).post {
                        search_apk!!.isFocusable = true
                        MyUtils.hideKeyboard(mContext, search_apk)
                        if (mSavedApps.size == 0) {
                            binding.rvAlreadyBackup!!.visibility = View.GONE
                            binding.tvMsg!!.visibility = View.VISIBLE
                            mContext!!.binding.ivDeleteAll!!.isEnabled = false
                            mContext!!.binding.ivDeleteAll!!.alpha = 0.5f
                        } else {
                            binding.tvMsg!!.visibility = View.GONE
                            binding.rvAlreadyBackup!!.visibility = View.VISIBLE
                            mContext!!.binding.ivDeleteAll!!.isEnabled = true
                            mContext!!.binding.ivDeleteAll!!.alpha = 1.0f
                            for (i in mSavedApps.indices) {
                                if (File(mSavedApps[i].appName!!).length() == 0L) {
                                    mSavedApps.removeAt(i)
                                }
                            }
                            try {
                                if (mSavedApps != null) {
                                    Collections.sort(mSavedApps) { lhs: SelectedApk, rhs: SelectedApk ->
                                        lhs.appName!!.compareTo(rhs.appName!!)
                                    }
                                }

                            } catch (e : java.lang.Exception){

                            }

                            mAlreadyBackupAdapter = AlreadyBackupAdapter(mContext!!, mSavedApps, binding.tvMsg!!,
                                object : RVClickListener {
                                    override fun onItemClick(position: Int) {
                                        deleteApp(
                                            File(mAlreadyBackupAdapter!!.getItem(position).appName),
                                            position
                                        )
                                    }

                                    override fun onEmpty() {
                                        binding.tvMsg!!.visibility = View.VISIBLE
                                        binding.rvAlreadyBackup!!.visibility = View.GONE
//                                binding.tvMsg!!.visibility = View.GONE
                                        mContext!!.binding.ivDeleteAll!!.isEnabled = false
                                        mContext!!.binding.ivDeleteAll!!.alpha = 0.5f
                                        if (mSavedApps.isEmpty()) {
                                            binding.rvAlreadyBackup!!.visibility = View.GONE
                                            binding.tvMsg!!.visibility = View.VISIBLE
                                            mContext!!.binding.ivDeleteAll!!.isEnabled = false
                                            mContext!!.binding.ivDeleteAll!!.alpha = 0.5f
//                                    tv_no_apk_msg!!.visibility = View.GONE
                                        }
                                    }

                                    override fun onNotEmpty() {
//                                tv_no_apk_msg!!.visibility = View.GONE
                                        mContext!!.binding.ivDeleteAll!!.isEnabled = true
                                        mContext!!.binding.ivDeleteAll!!.alpha = 1.0f
                                        binding.rvAlreadyBackup!!.visibility = View.VISIBLE
                                        binding.rvAlreadyBackup!!.stopScroll()
                                        binding.tvMsg!!.visibility = View.GONE
                                    }
                                })
                            binding.rvAlreadyBackup!!.layoutManager = LinearLayoutManager(mContext)
                            binding.rvAlreadyBackup!!.adapter = mAlreadyBackupAdapter
                        }
                    }

                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        try {
                            if (dialog != null && dialog.isShowing) {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false
                            }
                        } catch (e: Exception) {
//                            mContext!!.addEvent(e.message!!)
                        }
                    }, 1000)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }


        }
    }

    private fun getDate(milliSeconds: Long): String {
        val formatter = SimpleDateFormat("EEE-MMM dd,yyyy")
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = milliSeconds
        return formatter.format(calendar.time)
    }

    private fun deleteApp(apk: File, position: Int) {

        val dialog = Dialog(mContext!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        dialog.findViewById<TextView>(R.id.permission_text).text =
            getString(R.string.delete_apk_from_list)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            if (apk.exists()) {
                apk.delete()
                AlreadyBackupAdapter.filterSavedApps!!.removeAt(position)
                deleteAppFromList(apk)
                mAlreadyBackupAdapter!!.notifyItemRemoved(position)
                mAlreadyBackupAdapter!!.notifyItemRangeChanged(
                    position,
                    mAlreadyBackupAdapter!!.itemCount
                )
                if (mSavedApps.isEmpty()) {
                    binding.rvAlreadyBackup!!.visibility = View.GONE
                    binding.tvMsg!!.visibility = View.VISIBLE
                    mContext!!.binding.ivDeleteAll!!.isEnabled = false
                    mContext!!.binding.ivDeleteAll!!.alpha = 0.5f
                } else {
                    if (AlreadyBackupAdapter.filterSavedApps!!.isEmpty()) {
                        binding.tvMsg!!.visibility = View.VISIBLE
                        binding.rvAlreadyBackup!!.visibility = View.GONE
                        mContext!!.binding.ivDeleteAll!!.isEnabled = false
                        mContext!!.binding.ivDeleteAll!!.alpha = 0.5f
                    } else {
                        binding.tvMsg!!.visibility = View.GONE
                        binding.rvAlreadyBackup!!.visibility = View.VISIBLE
                        mContext!!.binding.ivDeleteAll!!.isEnabled = true
                        mContext!!.binding.ivDeleteAll!!.alpha = 1.0f
                    }
                }
            }

        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }
        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun deleteAppFromList(apk: File) {
        for (i in mSavedApps.indices) {
            if (apk.absolutePath == mSavedApps[i].appName) {
                mSavedApps.removeAt(i)
                break
            }
        }
    }

    private inner class DeleteAllFiles : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(mContext!!)
        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.findViewById<TextView>(R.id.permission).text =
                getString(R.string.label_please_wait)
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.deleting_files)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).visibility = View.GONE

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
        }

        override fun doInBackground(vararg strings: String?): String? {
            for (i in mSavedApps.indices) {
                if (File(mSavedApps[i].appName).exists()) {
                    File(mSavedApps[i].appName).delete()
                }
            }
            mSavedApps.clear()
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {

                Handler(Looper.getMainLooper()).post {
//                tv_no_apk_msg!!.visibility = View.GONE
                    if (mSavedApps.size == 0) {
                        binding.rvAlreadyBackup!!.visibility = View.GONE
                        binding.tvMsg!!.visibility = View.VISIBLE
                        mContext!!.binding.ivDeleteAll!!.isEnabled = false
                        mContext!!.binding.ivDeleteAll!!.alpha = 0.5f
                        Toast.makeText(mContext, getString(R.string.all_apks_deleted_successfully), Toast.LENGTH_SHORT).show()
                    } else {
                        binding.tvMsg!!.visibility = View.GONE
                        binding.rvAlreadyBackup!!.visibility = View.VISIBLE
                        mContext!!.binding.ivDeleteAll!!.isEnabled = true
                        mContext!!.binding.ivDeleteAll!!.alpha = 1.0f
                    }
                }
                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    try {
                        if (dialog != null && dialog.isShowing) {
                            dialog.cancel()
                            MyApplication.isDialogOpen = false
                        }
                    } catch (e: Exception) {
//                        mContext!!.addEvent(e.message!!)
                    }
                }, 500)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (AppsBackupActivity.isFrom == "AlreadyBackup" && isVisibleToUser) {
            if (isResumeCheck) {
                isResumeCheck = false
                initViewsActions("Resume")
            } else {
                isResumeCheck = true
            }
            search_apk!!.text = null
            Handler().postDelayed({
                search_apk!!.isFocusable = true
                search_apk!!.isFocusableInTouchMode = true
                Log.e(mTAG, "findViews: focus ")
            }, 500)
            MyUtils.hideKeyboard(mContext,search_apk)
        }
    }

    override fun onPause() {
        super.onPause()
        search_apk!!.isFocusable = false
    }

    override fun onStart() {
        EventBus.getDefault().register(this)
        super.onStart()
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    override fun onDestroy() {
        super.onDestroy()

        if(mGetFiles!=null) {
            if(mGetFiles?.status==AsyncTask.Status.RUNNING) {
                mGetFiles?.cancel(true)
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRefreshAuctionsAlreadyBackup(event: String) {
        if (event == "ToggleAlreadyBackup") {
            if (mGetFiles != null) {
                mGetFiles!!.cancel(true)
            }
            clearSearch()
        }
    }

}