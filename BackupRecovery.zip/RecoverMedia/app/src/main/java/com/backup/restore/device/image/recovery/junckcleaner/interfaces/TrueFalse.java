package com.backup.restore.device.image.recovery.junckcleaner.interfaces;

public interface TrueFalse {
    void isTrue(boolean isTrue);
}
