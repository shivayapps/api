package com.backup.restore.device.image.recovery.mainphotos.callbacks

interface ItemClickListener {
    fun onPicClicked(pictureFolderPath: String?, folderName: String?)
}