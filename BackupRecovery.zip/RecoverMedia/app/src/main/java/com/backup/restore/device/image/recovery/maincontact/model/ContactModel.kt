package com.backup.restore.device.image.recovery.maincontact.model

class ContactModel {
    var mContactName: String? = null
    var mNumber: String? = null
    var mContactId: String? = null
    var mContactImageUri : String? =null
    var mDOB : String? =null
    var mEmail : String? =null
    var isSelected = false

}