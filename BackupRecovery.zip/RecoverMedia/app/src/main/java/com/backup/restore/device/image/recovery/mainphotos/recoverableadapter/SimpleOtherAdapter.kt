package com.backup.restore.device.image.recovery.mainphotos.recoverableadapter

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableImageModel
import com.backup.restore.device.image.recovery.mainphotos.recoverdadapter.OtherRecoveredAdapter
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.getShareMessage
import java.io.File
import java.util.*

class SimpleOtherAdapter(
    var mScanImageRecycle: RecyclerView,
    private val mContext: Context,
    private val loImageList: List<RecoverableImageModel>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var TAG = "RecoverableOtherAdapter"

    class MyRecoverableViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvDir: TextView = view.findViewById(R.id.filePath)
        var fileName: TextView = view.findViewById(R.id.fileName)
        var fileSize: TextView = view.findViewById(R.id.fileSize)
        var thumbnail: ImageView = view.findViewById(R.id.audioFile)
        var llDelete: LinearLayout = itemView.findViewById(R.id.llDelete)
        var llShare: LinearLayout = itemView.findViewById(R.id.llShare)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.raw_list_of_recovered_files_item, parent, false)
        return MyRecoverableViewHolder(itemView)
    }

    override fun onBindViewHolder(holders: RecyclerView.ViewHolder, position: Int) {
        val holder = holders as MyRecoverableViewHolder

//        Glide.with(mContext)
//            .load(File(loImageList[position].filePath))
//            .override(300, 300)
//            .placeholder(R.drawable.img_thumb)
//            .into(holder.thumbnail)

        val extension=File(loImageList[position].filePath).extension

        if(SharedPrefsConstant.AudioArray.contains(extension)) {
            holder.thumbnail.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_audios))
        } else {
            holder.thumbnail.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_doc_file))
        }

        holder.fileName.text = File(loImageList[position].filePath).name
        holder.fileSize.text = String.format("%s", ShareConstants.getReadableFileSize(File(loImageList[position].filePath).length()))
        holder.tvDir.text = loImageList[position].filePath
        holder.tvDir.isSelected = true

        holder.itemView.setOnClickListener {

            MyApplication.isInternalCall = true
            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            val lFileUri = FileProvider.getUriForFile(mContext, mContext.applicationContext.packageName + ".provider", File(
                loImageList!![position].filePath))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if(SharedPrefsConstant.AudioArray.contains(extension)) {
                intent.setDataAndType(lFileUri, "audio/*")
            } else {
                intent.setDataAndType(lFileUri, "*/*")
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            mContext.startActivity(intent)
        }
        holder.llDelete.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            deleteMethod(position)

        }
        holder.llShare.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            NewRecoverImageActivity.isRefresh = false
            val uri = FileProvider.getUriForFile(mContext, mContext.packageName + ".provider", OtherRecoveredAdapter.mSavedFiles!![position])
            val share = Intent(Intent.ACTION_SEND)
            if(SharedPrefsConstant.AudioArray.contains(extension)) {
                share.type = "audio/*"
            }else{
                share.type = "*/*"
            }
            share.putExtra(Intent.EXTRA_SUBJECT, mContext.resources.getString(R.string.app_name))
            share.putExtra(Intent.EXTRA_STREAM, uri)
            share.putExtra(Intent.EXTRA_TEXT, mContext.getShareMessage())
            MyApplication.isInternalCall = true
            mContext.startActivity(Intent.createChooser(share, "Share with"))

        }

//        holder.audiocheckbox.setOnClickListener {
//            if(holder.audiocheckbox.isSelected) {
//                holder.audiocheckbox.isSelected=false
//                loImageList[position].isSelected=false
//            } else {
//                holder.audiocheckbox.isSelected=true
//                loImageList[position].isSelected=true
//            }
//            if (checkAll.isChecked && getSelectedCounted() != itemCount) {
//                Log.e(TAG, "onBindViewHolder: " + checkAll.isChecked)
//                Log.e(TAG, "onBindViewHolder: " + getSelectedCounted())
//                Log.e(TAG, "onBindViewHolder: $itemCount")
//                ShareConstants.isManualHiddenClick = true
//                checkAll.isChecked = getSelectedCounted() == itemCount
//            } else if (getSelectedCounted() == itemCount) {
//                checkAll.isChecked = true
//            }
//        }

    }

    private fun deleteMethod(position: Int) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = mContext.getString(R.string.confirm_delete)
        val extension=File(loImageList[position].filePath).extension
        if(SharedPrefsConstant.AudioArray.contains(extension)) {
            dialog.findViewById<TextView>(R.id.permission_text).text = mContext.getString(R.string.never_get_back_audio)
        } else {
            dialog.findViewById<TextView>(R.id.permission_text).text = mContext.getString(R.string.never_get_back_file)
        }

        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = mContext.getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = mContext.getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            if (OtherRecoveredAdapter.mSavedFiles!![position].exists()) {
                OtherRecoveredAdapter.mSavedFiles!![position].delete()
                OtherRecoveredAdapter.mSavedFiles!!.removeAt(position)
                Toast.makeText(mContext, R.string.deleted_success, Toast.LENGTH_SHORT).show()

                if (OtherRecoveredAdapter.mSavedFiles!!.size == 0) {
//                    mRvAlreadyBackup.visibility = View.GONE
//                    mTv_Msg.visibility = View.VISIBLE
//                    mIvDeleteAll.isEnabled = false
//                    mIvDeleteAll.alpha = 0.5f

                    if (mContext is NewRecoverImageActivity) {
                        (mContext as NewRecoverImageActivity).unSelectAll()
                    }

                } else {
//                    mTv_Msg.visibility = View.GONE;
//                    mRvAlreadyBackup.visibility = View.VISIBLE
//                    mIvDeleteAll.isEnabled = true
//                    mIvDeleteAll.alpha = 1.0f
                }
                notifyDataSetChanged()
            }
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    fun runLayoutAnimation() {
        val lController = AnimationUtils.loadLayoutAnimation(mContext, R.anim.layout_animation_fall_down)
        mScanImageRecycle.layoutAnimation = lController
        Objects.requireNonNull(mScanImageRecycle.adapter).notifyDataSetChanged()
        mScanImageRecycle.scheduleLayoutAnimation()
    }

    override fun getItemCount(): Int {
        return loImageList.size
    }

    fun getSelected(pos: Int): Boolean {
        return loImageList[pos].isSelected
    }

    fun getSelectedCounted(): Int {
        val selectedList = loImageList.filter { it.isSelected }
        return selectedList.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (itemCount > 0) {
            position
        } else super.getItemViewType(position)
    }
}