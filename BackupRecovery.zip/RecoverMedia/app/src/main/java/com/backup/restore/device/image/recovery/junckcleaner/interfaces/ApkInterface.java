package com.backup.restore.device.image.recovery.junckcleaner.interfaces;

public interface ApkInterface {
    void done(boolean flag);
}

