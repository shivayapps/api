package com.backup.restore.device.image.recovery.maincontact.model

class CountNameModel {
    var count = 0
    var name: String? = null
}