package com.adconfig.adsutil.admob

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Rect
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowMetrics
import com.adconfig.AdsConfig
import com.adconfig.R
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.utils.isOnline
import com.adconfig.checkLibrary

import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

object BannerAdHelper {

    val TAG = "ADCONFIG_BannerAdHelper"
    fun showBanner(
        context: Activity,
        view: ViewGroup,
        parent: ViewGroup,
        adId: String,
        onLoaded: (isLoaded: Boolean,message: String) -> Unit,
        mAdSize: AdSize?=null,
    ) {
        var mShimmerLayout: Int = R.layout.layout_shimmer_ad_banner
//        Log.d(TAG, "Banner: showBanner:$adId")
        if (Config.isAdsEnable) {
            checkLibrary()

            if (!context.isOnline()) {
                view.visibility = View.GONE
                return
            }


            val adView = AdView(context)
            if(mAdSize!=null) {
                adView.setAdSize(mAdSize)
            }else {
                adView.setAdSize(
                    getAdSize(
                        context, view
                    )
                )
            }
            adView.adUnitId = adId
            adView.adListener = object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    onLoaded.invoke(false,"onAdFailedToLoad:${adError.code},${adError.message}")
                    view.visibility = View.GONE
                    parent.visibility = View.GONE
//                viewDivider?.visibility = View.GONE
//                viewDivider1?.visibility = View.GONE
                    Log.i(
                        TAG,
                        "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                    )
                }

                override fun onAdLoaded() {
                    onLoaded.invoke(true,"ok")
                    if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
                    if (view.childCount > 0) view.removeAllViews()
                    view.addView(adView)
                    view.visibility = View.VISIBLE
                    parent.visibility = View.VISIBLE

                    Log.d(TAG, "onAdLoaded: Banner Id -> $adId")

                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    AdsConfig.isSystemDialogOpen = true
                }
            }
            adView.loadAd(AdRequest.Builder().build())
        } else {
            view.visibility = View.GONE
            parent.visibility = View.GONE
        }
    }

    private fun getAdSize(activity: Activity, view: ViewGroup): AdSize {
//        val display = activity.windowManager.defaultDisplay
//        val outMetrics = DisplayMetrics()
//        display.getMetrics(outMetrics)
//        val widthPixels = outMetrics.widthPixels.toFloat()
//        val density = outMetrics.density
//        val adWidth = (widthPixels / density).toInt()
        val adWidth = AdsParameters(activity).adWidth
        Log.e(TAG,"adWidth:$adWidth")

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
            activity, adWidth
        )
    }


}