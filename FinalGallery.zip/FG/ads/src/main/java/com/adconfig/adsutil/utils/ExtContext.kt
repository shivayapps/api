package com.adconfig.adsutil.utils

import android.content.Context
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat

var isNeedToShowAds = true
var isAppForeground = false
var isAnyAdOpen = false
var isInterstitialAdShow = false

var isAnyAdShowing: Boolean = false
//var openAdCounter: Int = 0
var needToBlockOpenAdInternally: Boolean = false

fun Context.getcolor(@ColorRes id: Int) = ContextCompat.getColor(this, id)