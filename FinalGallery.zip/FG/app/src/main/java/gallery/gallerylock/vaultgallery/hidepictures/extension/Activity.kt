package gallery.gallerylock.vaultgallery.hidepictures.extension

import android.annotation.TargetApi
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.biometric.auth.AuthPromptCallback
import androidx.biometric.auth.AuthPromptHost
import androidx.biometric.auth.Class2BiometricAuthPrompt
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import com.bumptech.glide.Glide
import gallery.gallerylock.vaultgallery.hidepictures.R
import com.squareup.picasso.Picasso
import gallery.gallerylock.vaultgallery.hidepictures.edit.EditImageActivity
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.ensureBackgroundThread
import java.io.*


val Context.audioManager get() = getSystemService(Context.AUDIO_SERVICE) as AudioManager

fun FragmentActivity.isFullScreen(): Boolean {
    return window.decorView.systemUiVisibility.and(View.SYSTEM_UI_FLAG_FULLSCREEN) == View.SYSTEM_UI_FLAG_FULLSCREEN
}

fun Activity.openPath(path: String, forceChooser: Boolean, extras: HashMap<String, Boolean> = HashMap()) {
    openPathIntent(path, forceChooser, BuildConfig.APPLICATION_ID, extras = extras)
}

fun Activity.openPathIntent(path: String, forceChooser: Boolean, applicationId: String, forceMimeType: String = "", extras: HashMap<String, Boolean> = HashMap()) {
    ensureBackgroundThread {
        val newUri = getFinalUriFromPath(path, applicationId) ?: return@ensureBackgroundThread
        val mimeType = if (forceMimeType.isNotEmpty()) forceMimeType else getUriMimeType(path, newUri)
        Intent().apply {
            action = Intent.ACTION_VIEW
            setDataAndType(newUri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

//            if (applicationId == "com.gallery.photo.image.video") {
//                putExtra(IS_FROM_GALLERY, true)
//            }

            for ((key, value) in extras) {
                putExtra(key, value)
            }

            putExtra("real_file_path_2", path)

            try {
                val chooser = Intent.createChooser(this, "Open with")
                startActivity(if (forceChooser) chooser else this)
            } catch (e: ActivityNotFoundException) {
                if (!tryGenericMimeType(this, mimeType, newUri)) {
                    toast(R.string.no_app_found)
                }
            } catch (e: Exception) {
                showErrorToast(e)
            }
        }
    }
}


fun Activity.tryGenericMimeType(intent: Intent, mimeType: String, uri: Uri): Boolean {
    var genericMimeType = mimeType.getGenericMimeType()
    if (genericMimeType.isEmpty()) {
        genericMimeType = "*/*"
    }

    intent.setDataAndType(uri, genericMimeType)

    return try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}

fun Activity.isSupportWithErrorInfo(
    ctx: Context,
    type: Int,
): Pair<Boolean, String> {
    val biometricManager = BiometricManager.from(ctx)
    val authStatusCode = biometricManager.canAuthenticate(type)

    Log.e(
        "BiometricManager",
        "isSupportWithErrorInfo\nauthStatusCode:$authStatusCode\n,type:$type"
    )

    if (authStatusCode == BiometricManager.BIOMETRIC_STATUS_UNKNOWN ||
        authStatusCode == BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED ||
        authStatusCode == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
    ) {
//            return Pair(false, "Device_unsupported")
        return Pair(false, getString(R.string.device_unsupported))
    } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE) {
        return Pair(false, getString(R.string.setting_biometric_error_hardware_unavailable))
    } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED) {
        return Pair(false, getString(R.string.setting_biometric_error_not_secure))
    } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) {
        return Pair(false, getString(R.string.setting_biometric_error_none_enrolled))
    }
//        if (!isKeyguardSecure(ctx)) {
//            return Pair(false, ctx.getString(R.string.setting_biometric_error_pin_not_set))
//        }
//        if (!isSecureHardware()) {
//            return Pair(false, "isSecureHardware ${ctx.getString(R.string.setting_biometric_error_not_secure)}")
//        }
//        if (RootUtil.isDeviceRooted) {
//            return Pair(false, ctx.getString(R.string.setting_biometric_error_rooted))
//        }
    return Pair(true, "")
}
fun Activity.openEditorIntent(path: String) {

    val intent = Intent(this, EditImageActivity::class.java)
    intent.putExtra(Constant.EXTRA_EDIT_IMAGE_PATH, path)
    startActivity(intent)

//    ensureBackgroundThread {
//        val newUri = getFinalUriFromPath(path, packageName) ?: return@ensureBackgroundThread
//        val intent = Intent(
//            this,
//            EditImageActivity::class.java
//        )
//        intent.apply {
//            setDataAndType(newUri, getUriMimeType(path, newUri))
//            val parent = path.getParentPath()
//            val newFilename = "${path.getFilenameFromPath().substringBeforeLast('.')}_1"
//            val extension = path.getFilenameExtension()
//            val newFilePath = File(parent, "$newFilename.$extension")
//            val outputUri = getFinalUriFromPath("$newFilePath", packageName)
//            if (!isRPlus()) {
//                val resInfoList = packageManager.queryIntentActivities(
//                    this,
//                    PackageManager.MATCH_DEFAULT_ONLY
//                )
//                for (resolveInfo in resInfoList) {
//                    val packageName = resolveInfo.activityInfo.packageName
//                    grantUriPermission(
//                        packageName,
//                        outputUri,
//                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
//                    )
//                }
//            }
//            if (!isRPlus()) {
//                putExtra(MediaStore.EXTRA_OUTPUT, outputUri)
//            }
//            putExtra("REAL_FILE_PATH", path)
//            try {
//                startActivity(intent)
//            } catch (e: ActivityNotFoundException) {
//                toast(R.string.no_app_found)
//            } catch (e: Exception) {
//                showErrorToast(e)
//            }
//        }
//    }
}
fun Activity.launchGrantAllFilesIntent() {
    try {
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
        intent.addCategory("android.intent.category.DEFAULT")
        intent.data = Uri.parse("package:$packageName")
        startActivity(intent)
    } catch (e: Exception) {
        val intent = Intent()
        intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast(getString(R.string.permission_toast_msg))
        }
    }
}

fun FragmentActivity.toggleFullScreen() {
    if (isFullScreen()) {
        // If we are exiting full screen, reset the orientation
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    val newUiOptions = window.decorView.systemUiVisibility
        .xor(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
        .xor(View.SYSTEM_UI_FLAG_FULLSCREEN)
        .xor(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

    window.decorView.systemUiVisibility = newUiOptions
}

fun Window.toggleSystemBars(@WindowInsetsCompat.Type.InsetsType types: Int, showBars: Boolean) {
    WindowCompat.getInsetsController(this, decorView).apply {
        systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (showBars) {
            show(types)
        } else {
            hide(types)
        }
    }
}

fun AppCompatActivity.showSystemUI() {
    toggleFullScreen()
    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
}

fun AppCompatActivity.hideSystemUI() {
    toggleFullScreen()
    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
        View.SYSTEM_UI_FLAG_LOW_PROFILE or
        View.SYSTEM_UI_FLAG_FULLSCREEN or
        View.SYSTEM_UI_FLAG_IMMERSIVE
}

fun Activity.hasNavBar(): Boolean {
    val display = windowManager.defaultDisplay

    val realDisplayMetrics = DisplayMetrics()
    display.getRealMetrics(realDisplayMetrics)

    val displayMetrics = DisplayMetrics()
    display.getMetrics(displayMetrics)

    return (realDisplayMetrics.widthPixels - displayMetrics.widthPixels > 0) || (realDisplayMetrics.heightPixels - displayMetrics.heightPixels > 0)
}

fun Activity.saveRotatedImageToFile(oldPath: String, newPath: String, degrees: Int, showToasts: Boolean, callback: () -> Unit) {
    var newDegrees = degrees
    if (newDegrees < 0) {
        newDegrees += 360
    }

    Glide.get(this).clearDiskCache()
    if (oldPath == newPath && oldPath.isJpg()) {
        if (tryRotateByExif(oldPath, newDegrees, showToasts, callback)) {
            return
        }
    }

//    val tmpPath = "$recycleBinPath/.tmp_${newPath.getFilenameFromPath()}"
//    val tmpFileDirItem = FileDirItem(tmpPath, tmpPath.getFilenameFromPath())
//    try {
//        getFileOutputStream(tmpFileDirItem) {
//            if (it == null) {
//                if (showToasts) {
//                    toast(R.string.unknown_error_occurred)
//                }
//                return@getFileOutputStream
//            }
//
//            val oldLastModified = File(oldPath).lastModified()
//            if (oldPath.isJpg()) {
//                copyFile(oldPath, tmpPath)
//                saveExifRotation(ExifInterface(tmpPath), newDegrees)
//            } else {
//                val inputstream = getFileInputStreamSync(oldPath)
//                val bitmap = BitmapFactory.decodeStream(inputstream)
//                saveFile(tmpPath, bitmap, it as FileOutputStream, newDegrees)
//            }
//
//            copyFile(tmpPath, newPath)
//            rescanPaths(arrayListOf(newPath))
//            fileRotatedSuccessfully(newPath, oldLastModified)
//
//            it.flush()
//            it.close()
//            callback.invoke()
//        }
//    } catch (e: OutOfMemoryError) {
//        if (showToasts) {
//            toast(R.string.out_of_memory_error)
//        }
//    } catch (e: Exception) {
//        if (showToasts) {
//            showErrorToast(e)
//        }
//    } finally {
//        tryDeleteFileDirItem(tmpFileDirItem, false, true)
//    }
}

@TargetApi(Build.VERSION_CODES.N)
fun Activity.tryRotateByExif(path: String, degrees: Int, showToasts: Boolean, callback: () -> Unit): Boolean {
    return try {
        val file = File(path)
        val oldLastModified = file.lastModified()
        if (saveImageRotation(path, degrees)) {
            fileRotatedSuccessfully(path, oldLastModified)
            callback.invoke()
            if (showToasts) {
                toast(R.string.file_saved)
            }
            true
        } else {
            false
        }
    } catch (e: Exception) {
        // lets not show IOExceptions, rotating is saved just fine even with them
        if (showToasts && e !is IOException) {
            showErrorToast(e)
        }
        false
    }
}

//@RequiresApi(Build.VERSION_CODES.N)
fun Context.saveImageRotation(path: String, degrees: Int): Boolean {
//    if (!needsStupidWritePermissions(path)) {
//        saveExifRotation(ExifInterface(path), degrees)
//        return true
//    } else
//    if (isNougatPlus()) {
//        val documentFile = getSomeDocumentFile(path)
//        if (documentFile != null) {
//            val parcelFileDescriptor = contentResolver.openFileDescriptor(documentFile.uri, "rw")
//            val fileDescriptor = parcelFileDescriptor!!.fileDescriptor
//            saveExifRotation(ExifInterface(fileDescriptor), degrees)
            setOrientation(File(path), degrees)
            return true
//        }
//    }
    return false
}



//fun Context.getFastDocumentFile(path: String): DocumentFile? {
////    if (isPathOnOTG(path)) {
////        return getOTGFastDocumentFile(path)
////    }
////
////    if (baseConfig.sdCardPath.isEmpty()) {
////        return null
////    }
//
//    val externalPathPart = baseConfig.sdCardPath.split("/").lastOrNull(String::isNotEmpty)?.trim('/') ?: return null
//    val fullUri = "${baseConfig.sdTreeUri}/document/$externalPathPart%3A$relativePath"
//    return DocumentFile.fromSingleUri(this, Uri.parse(fullUri))
//}

//fun Context.getDocumentFile(path: String): DocumentFile? {
////    val isOTG = isPathOnOTG(path)
//    var relativePath = path.substring(if (isOTG) otgPath.length else sdCardPath.length)
//    if (relativePath.startsWith(File.separator)) {
//        relativePath = relativePath.substring(1)
//    }
//
//    return try {
//        val treeUri = Uri.parse(if (isOTG) baseConfig.OTGTreeUri else baseConfig.sdTreeUri)
//        var document = DocumentFile.fromTreeUri(applicationContext, treeUri)
//        val parts = relativePath.split("/").filter { it.isNotEmpty() }
//        for (part in parts) {
//            document = document?.findFile(part)
//        }
//        document
//    } catch (ignored: Exception) {
//        null
//    }
//}

//fun Context.getSomeDocumentFile(path: String) = getFastDocumentFile(path) ?: getDocumentFile(path)
//fun Context.getSomeDocumentFile(path: String) = getDocumentFile(path)
fun Activity.updateStatusBarColor(color: Int) {
    window.statusBarColor = color

    if (color.getContrastColor() == DARK_GREY) {
        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
    } else {
        window.decorView.systemUiVisibility = window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
    }
}
fun Activity.fileRotatedSuccessfully(path: String, lastModified: Long) {
//    if (config.keepLastModified && lastModified != 0L) {
    if (lastModified != 0L) {
        File(path).setLastModified(lastModified)
        updateLastModified(path, lastModified)
    }

    Picasso.get().invalidate(path.getFileKey(lastModified))
    // we cannot refresh a specific image in Glide Cache, so just clear it all
    val glide = Glide.get(applicationContext)
    glide.clearDiskCache()
    runOnUiThread {
        glide.clearMemory()
    }
}


fun Context.getFinalUriFromPath(path: String, applicationId: String): Uri? {
    val uri = try {
        ensurePublicUri(path, applicationId)
    } catch (e: Exception) {
        showErrorToast(e)
        return null
    }

    if (uri == null) {
        toast(R.string.unknown_error_occurred)
        return null
    }

    return uri
}

fun Activity.showBiometricPrompt(
    successCallback: (icSuccess: Boolean) -> Unit,
    failureCallback: (icFailed: Boolean,errorCode: Int, errString: CharSequence) -> Unit
) {
    Class2BiometricAuthPrompt.Builder(getText(R.string.authenticate), getText(R.string.cancel))
        .build()
        .startAuthentication(
            AuthPromptHost(this as FragmentActivity),
            object : AuthPromptCallback() {
                override fun onAuthenticationSucceeded(activity: FragmentActivity?, result: BiometricPrompt.AuthenticationResult) {
                    successCallback.invoke(true)
                }

                override fun onAuthenticationError(activity: FragmentActivity?, errorCode: Int, errString: CharSequence) {
                    val isCanceledByUser = errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON || errorCode == BiometricPrompt.ERROR_USER_CANCELED
                    if (!isCanceledByUser) {
                        toast(errString.toString())
                    }
                    failureCallback.invoke(false,errorCode,errString)
                }

                override fun onAuthenticationFailed(activity: FragmentActivity?) {
                    successCallback.invoke(false)
                }
            }
        )
}