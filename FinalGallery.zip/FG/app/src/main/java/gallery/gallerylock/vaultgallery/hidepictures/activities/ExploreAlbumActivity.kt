package gallery.gallerylock.vaultgallery.hidepictures.activities

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.google.android.gms.ads.AdView
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.adapter.AlbumAdapter
import gallery.gallerylock.vaultgallery.hidepictures.adapter.PictureAdapter
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.customview.MyGridLayoutManager
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityExploreAlbumBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.CalendarDialog
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.extension.getParentFolder
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.utils.AdCache
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_GIFS
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_IMAGES
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_PORTRAITS
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_RAWS
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_SVGS
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_VIDEOS
import gallery.gallerylock.vaultgallery.hidepictures.utils.photoExtensions
import gallery.gallerylock.vaultgallery.hidepictures.utils.rawExtensions
import gallery.gallerylock.vaultgallery.hidepictures.utils.videoExtensions
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ExploreAlbumActivity : BaseActivity() {

    //    var albumBackupList: ArrayList<AlbumData> = ArrayList()
    var allList = ArrayList<Any>()
    var allBackList = ArrayList<PictureData>()
    var albumList: ArrayList<AlbumData> = ArrayList()

    var albumAdapter: AlbumAdapter? = null
    lateinit var preferences: Preferences

    lateinit var activity: Activity

    var searchAdapter: PictureAdapter? = null
    lateinit var binding: ActivityExploreAlbumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityExploreAlbumBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()
        activity = this@ExploreAlbumActivity

        albumList = Constant.albumList

        initView()

    }

    public fun getData() {

        Glide.get(this).clearMemory()
        Observable.fromCallable {
            Glide.get(this).clearDiskCache()
            allList.clear()

//            videoCount = 0
//            imageCount = 0
            getImages()
            getVideos()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
//                runOnUiThread {
//                setFilterData()
//                    getFindCount()
//                }
            }
            .subscribe { result: Boolean? ->
//                runOnUiThread {
//                setFilterData()
//                    getFindCount()
//                }
            }
    }

    private fun getImages() {
        Log.e("gettingListPhoto", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
                mCursor.moveToFirst()
                val photoDataArrayList: ArrayList<PictureData> = ArrayList<PictureData>()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))


                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                        pictureData.isFavorite = favList.contains(path)
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        imageCount++
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }


    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

    private fun getVideos() {
        Log.e("gettingListPhoto", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )
        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {
            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            val cursor = contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.isVideo = true
//                        allList.add(pictureData)
                        allBackList.add(pictureData)

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            }
        } catch (exp: java.lang.Exception) {
            exp.printStackTrace()
        }
    }
    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {

        if (!isAdLoaded) {

            val adId=getString(R.string.b_exploreAlbumActivity)
            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd,binding.llAdPlace,adId,
                AdCache.exploreAlbumAdView,{ isLoaded, adView, message ->
                    mAdView=adView
                    AdCache.exploreAlbumAdView=adView
                    isAdLoaded=isLoaded
                })
        }
    }

    private fun initView() {
        if (intent.hasExtra("title")) {
            binding.txtTitle.text = intent.getStringExtra("title")
        }
//        binding.icMenu.beGone()
//        if (intent.hasExtra("showTimeline")) {
//            val showTimeline=intent.getBooleanExtra("showTimeline",false)
//            if(showTimeline) {
//            }
//        }

        intListener()
        initAdapter()
    }

    private fun initAdapter() {
        setRvLayoutManager()

        albumAdapter = AlbumAdapter(activity, albumList,
            clickListener = {
                val albumData = albumList[it]
//                if (albumData.isCheckboxVisible) {
//                    albumData.isSelected = !albumData.isSelected
//                    albumAdapter?.notifyItemChanged(it)
//                    setSelectedFile()
//                } else {

                openImageList(albumData)
//                }
            },
            longClickListener = {
//                lastLongPressedItem = it
//                binding.albumRecycler.setDragSelectActive(it)
//                lastLongPressedItem = if (lastLongPressedItem == -1) {
//                    it
//                } else {
//                    val min = min(lastLongPressedItem, it)
//                    val max = max(lastLongPressedItem, it)
//                    for (i in min..max) {
//                        toggleItemSelection(true, i, false)
//                    }
////                    updateTitle()
//                    it
//                }

//                if (albumList[it] is AlbumData) {
//                    val pictureData = albumList[it] as AlbumData
//                    for (i in albumList.indices) {
//                        if (albumList[i] != null) {
//                            val model = albumList[i] as AlbumData
//                            model.isCheckboxVisible = true
//                        }
//                    }
//                    pictureData.isCheckboxVisible = true
//                    pictureData.isSelected = true
//                    notifyAdapter()
//                    setSelectedFile()
//                }
            })

        binding.albumRecycler.adapter = albumAdapter


//        initZoomListener()
//        setupZoomListener(mZoomListener)
//        initDragListener()
//        setupDragListener(mDragListener)
    }

    public fun openImageList(albumData: AlbumData) {

        Constant.albumData = AlbumData(
            albumData.title,
            albumData.pictureData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )

        val intent = Intent(activity, ImageListActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
//        setBackAlbumData()
    }

    public fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.pictureData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getAlbumGridCount()
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanCount = gridCount
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < albumList.size) {
                        return if (albumAdapter!!.getItemViewType(position) === albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
                            gridCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } else {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
//            mZoomListener = null
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.albumRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.llAdPlace.beVisible()
        } else {
            binding.albumRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.llAdPlace.beGone()
        }
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            onBackPressed()
        }

//        binding.icMenu.setOnClickListener {
//            showTimeline()
//        }

    }

    var startDate = 0L
    var endDate = 0L
    private fun showTimeline() {
        val c = Calendar.getInstance()
        if (startDate > 0) c.timeInMillis = startDate

        val y = c.get(Calendar.YEAR)
        val m = c.get(Calendar.MONTH)
        val d = c.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = CalendarDialog(updateListener = { startDate, endDate ->

            val strStartDate = SimpleDateFormat(
                "dd MMM yyyy",
                Locale.ENGLISH
            ).format(startDate.timeInMillis)

            val strEndDate = SimpleDateFormat(
                "dd MMM yyyy", Locale.ENGLISH
            ).format(endDate.timeInMillis)

//            binding.txtStartDate.text = "$strStartDate - $strEndDate"

            setListTimeRange(startDate.timeInMillis, endDate.timeInMillis)

        })
        datePickerDialog.show(supportFragmentManager, datePickerDialog.tag)
    }
    private fun setListTimeRange(startDate: Long, endDate: Long) {
        Log.e("setList", "setListTimeRange.startDate:$startDate")
        Log.e("setList", "setListTimeRange.endDate:$endDate")
//        timeRangeList.clear()
        allList.clear()
        if (startDate > 0 && endDate > 0) {
//            timeRangeList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
            allList.addAll(allBackList.filter { it.date in (startDate + 1)..<endDate })
        } else if (startDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date > startDate })
            allList.addAll(allBackList.filter { it.date > startDate })
        } else if (endDate == 0L) {
//            timeRangeList.addAll(allBackList.filter { it.date < endDate })
            allList.addAll(allBackList.filter { it.date < endDate })
        } else {
//            timeRangeList.clear()
            allList.clear()
        }

        Log.e("setList", "ListTimeRange.size:${allList.size}")
//        binding.txtAllRange.beGoneIf(timeRangeList.size == 0)
//        binding.txtAllRange.beGoneIf(allList.size == 0)
//        binding.llSearch.beGone()

        setData()

    }

    private fun setData() {
        Log.e("gettingListPhoto", "Data is show")
//        isUpadteList = false
//        enableScroll()

        runOnUiThread {
            //if (searchAdapter != null)
            notifyAdapter()
            setEmptyData()
        }
    }
    private fun notifyAdapter() {

        if (searchAdapter != null) {
//            binding.txtCount.text = "${allList.size} ${getString(R.string.photos)}"
            searchAdapter?.notifyDataSetChanged()
        }

//        if (timeLineAdapter != null)
//            timeLineAdapter?.notifyDataSetChanged()
    }

    override fun onDestroy() {
        super.onDestroy()
//        EventBus.getDefault().unregister(this)
    }


    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
//            setCloseToolbar()
        } else {
            if (preferences.isNeedInterAd) {

                AdsConfig.showInterstitialAd(this) {
                    if(it) preferences.isNeedInterAd = false
                    finish()
                }
            } else {
                super.onBackPressed()
            }
        }
    }


}