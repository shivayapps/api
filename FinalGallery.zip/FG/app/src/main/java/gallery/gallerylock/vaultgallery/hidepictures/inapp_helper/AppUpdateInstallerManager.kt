package gallery.gallerylock.vaultgallery.hidepictures.inapp_helper

import android.content.Intent
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.gms.tasks.Task

interface AppUpdateInstallerManager {
    fun startCheckUpdate()
    fun resumeCheckUpdate(@AppUpdateType updateType: Int)
    fun completeUpdate(): Task<Void>
//    fun completeUpdate()
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?)
    fun addAppUpdateListener(listener: AppUpdateInstallerListener?)
}