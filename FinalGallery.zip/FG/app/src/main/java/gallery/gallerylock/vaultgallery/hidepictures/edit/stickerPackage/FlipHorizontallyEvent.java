package gallery.gallerylock.vaultgallery.hidepictures.edit.stickerPackage;

public class FlipHorizontallyEvent extends AbstractFlipEvent {

  @Override @StickerView.Flip protected int getFlipDirection() {
    return  StickerView.FLIP_HORIZONTALLY;
  }
}
