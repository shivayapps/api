package gallery.gallerylock.vaultgallery.hidepictures.utils

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.text.format.DateFormat
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.extension.getInternalStoragePath
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.ASPECT_RATIO_FREE
import java.text.SimpleDateFormat
import java.util.LinkedList
import java.util.Locale


class Preferences(var context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(Constant.PREF_NAME, Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = prefs.edit()

    fun saveObjectList(objectList: ArrayList<Any>) {
        Log.e("Preferences","saveObjectList.size:${objectList.size}")
        val editor: SharedPreferences.Editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(objectList)

        Log.e("Preferences","saveObjectList.json:${json}")
        editor.putString("media_list", json)
        editor.apply()
    }
    fun getObjectList(): ArrayList<Any> {
        val gson = Gson()
        val json: String = prefs.getString("media_list", "")?:""
        Log.e("Preferences","getObjectList.json:${json}")
        val type: Type = object : TypeToken<ArrayList<Any>>() {}.type
        val objectList: ArrayList<Any> = gson.fromJson(json, type)
        Log.e("Preferences","getObjectList.size:${objectList.size}")
        return objectList
    }
    fun saveMediaList(objectList: ArrayList<PictureData>) {
        Log.e("Preferences","saveMediaList.size:${objectList.size}")
        val editor: SharedPreferences.Editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(objectList)

//        Log.e("Preferences","saveObjectList.json:${json}")
        editor.putString("media_list", json)
        editor.apply()
    }
    fun getMediaList(): ArrayList<PictureData> {
        val gson = Gson()
        val json: String = prefs.getString("media_list", "")?:""
//        Log.e("Preferences","getObjectList.json:${json}")
        val type: Type = object : TypeToken<ArrayList<PictureData>>() {}.type
        val objectList: ArrayList<PictureData> = gson.fromJson(json, type)
        Log.e("Preferences","getMediaList.size:${objectList.size}")
        return objectList
    }
    fun saveAlbumList(objectList: ArrayList<AlbumData>) {
        Log.e("Preferences","saveAlbumList.size:${objectList.size}")
        val editor: SharedPreferences.Editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(objectList)

//        Log.e("Preferences","saveObjectList.json:${json}")
        editor.putString("album_list", json)
        editor.apply()
    }
    fun getAlbumList(): ArrayList<AlbumData> {
        val gson = Gson()
        val json: String = prefs.getString("album_list", "")?:""
//        Log.e("Preferences","getObjectList.json:${json}")
        val type: Type = object : TypeToken<ArrayList<AlbumData>>() {}.type
        val objectList: ArrayList<AlbumData> = gson.fromJson(json, type)
        Log.e("Preferences","getAlbumList.size:${objectList.size}")
        return objectList
    }

    var isFirstTimeInstall: Boolean
        get() = prefs.getBoolean("isFirstTimeInstall", true)
        set(value) = prefs.edit().putBoolean("isFirstTimeInstall", value).apply()
    var isEnableAds: Boolean
        get() = prefs.getBoolean("isEnableAds", true)
        set(value) = prefs.edit().putBoolean("isEnableAds", value).apply()
    var isEnableOpenAds: Boolean
        get() = prefs.getBoolean("isEnableOpenAds", true)
        set(value) = prefs.edit().putBoolean("isEnableOpenAds", value).apply()
    var isRatingDone: Boolean
        get() = prefs.getBoolean("isRatingDone", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("isRatingDone", allowVideoGestures).apply()
    var isNeedInterAd: Boolean
        get() = prefs.getBoolean("isNeedInterAd", true)
        set(allowVideoGestures) = prefs.edit().putBoolean("isNeedInterAd", allowVideoGestures).apply()

    var refreshMedia: Boolean
        get() = prefs.getBoolean("addedNewMedia", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("addedNewMedia", allowVideoGestures).apply()
    var scanMedia: Boolean
        get() = prefs.getBoolean("scanMedia", false)
        set(allowVideoGestures) = prefs.edit().putBoolean("scanMedia", allowVideoGestures).apply()
    var deleteAfter30Days: Boolean
        get() = prefs.getBoolean("deleteAfter30Days", false)
        set(deleteAfter30Days) = prefs.edit().putBoolean("deleteAfter30Days", deleteAfter30Days).apply()

//    fun addFolderProtection(path: String) {
//        prefs.edit()
//            .putBoolean("isProtected$path", true)
//            .apply()
//    }
//    fun removeFolderProtection(path: String) {
//        prefs.edit()
//            .remove("isProtected$path")
//            .apply()
//    }

//    fun isFolderProtected(path: String) =prefs.getBoolean("isProtected$path", false)


    var allowDownGesture: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_DOWN_GESTURE, true)
        set(allowDownGesture) = prefs.edit().putBoolean(Constant.ALLOW_DOWN_GESTURE, allowDownGesture).apply()

    var deleteEmptyFolders: Boolean
        get() = prefs.getBoolean("deleteEmptyFolders", false)
        set(deleteEmptyFolders) = prefs.edit().putBoolean("deleteEmptyFolders", deleteEmptyFolders).apply()

    var allowVideoGestures: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_VIDEO_GESTURES, true)
        set(allowVideoGestures) = prefs.edit().putBoolean(Constant.ALLOW_VIDEO_GESTURES, allowVideoGestures).apply()

    var autoplayVideos: Boolean
        get() = prefs.getBoolean(Constant.AUTOPLAY_VIDEOS, false)
        set(autoplayVideos) = prefs.edit().putBoolean(Constant.AUTOPLAY_VIDEOS, autoplayVideos).apply()

    var lastEditorCropAspectRatio: Int
        get() = prefs.getInt("LAST_EDITOR_CROP_ASPECT_RATIO", ASPECT_RATIO_FREE)
        set(lastEditorCropAspectRatio) = prefs.edit().putInt("LAST_EDITOR_CROP_ASPECT_RATIO", lastEditorCropAspectRatio).apply()

    var lastEditorCropOtherAspectRatioX: Float
        get() = prefs.getFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_X", 2f)
        set(lastEditorCropOtherAspectRatioX) = prefs.edit().putFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_X", lastEditorCropOtherAspectRatioX).apply()

    var lastEditorCropOtherAspectRatioY: Float
        get() = prefs.getFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_Y", 1f)
        set(lastEditorCropOtherAspectRatioY) = prefs.edit().putFloat("LAST_EDITOR_CROP_OTHER_ASPECT_RATIO_Y", lastEditorCropOtherAspectRatioY).apply()

    var lastEditorDrawColor: Int
        get() = prefs.getInt("LAST_EDITOR_DRAW_COLOR", ContextCompat.getColor(context, R.color.color_primary))
        set(lastEditorDrawColor) = prefs.edit().putInt("LAST_EDITOR_DRAW_COLOR", lastEditorDrawColor).apply()

    var lastEditorBrushSize: Int
        get() = prefs.getInt("LAST_EDITOR_BRUSH_SIZE", 50)
        set(lastEditorBrushSize) = prefs.edit().putInt("LAST_EDITOR_BRUSH_SIZE", lastEditorBrushSize).apply()

    // color picker last used colors
    var colorPickerRecentColors: LinkedList<Int>
        get(): LinkedList<Int> {
            val defaultList = arrayListOf(
                ContextCompat.getColor(context, R.color.color_picker_1),
                ContextCompat.getColor(context, R.color.color_picker_5),
                ContextCompat.getColor(context, R.color.color_picker_10),
                ContextCompat.getColor(context, R.color.color_picker_15),
                ContextCompat.getColor(context, R.color.color_picker_20)
            )
            return LinkedList(prefs.getString("COLOR_PICKER_RECENT_COLORS", null)?.lines()?.map { it.toInt() } ?: defaultList)
        }
        set(recentColors) = prefs.edit().putString("COLOR_PICKER_RECENT_COLORS", recentColors.joinToString(separator = "\n")).apply()

//    var openVideosOnSeparateScreen: Boolean
//        get() = prefs.getBoolean(Constant.OPEN_VIDEOS_ON_SEPARATE_SCREEN, false)
//        set(openVideosOnSeparateScreen) = prefs.edit().putBoolean(Constant.OPEN_VIDEOS_ON_SEPARATE_SCREEN, openVideosOnSeparateScreen).apply()

//    var bottomActions: Boolean
//        get() = prefs.getBoolean(Constant.BOTTOM_ACTIONS, true)
//        set(bottomActions) = prefs.edit().putBoolean(Constant.BOTTOM_ACTIONS, bottomActions).apply()

    var use24HourFormat: Boolean
        get() = prefs.getBoolean("USE_24_HOUR_FORMAT", DateFormat.is24HourFormat(context))
        set(use24HourFormat) = prefs.edit().putBoolean("USE_24_HOUR_FORMAT", use24HourFormat).apply()

    var dateFormat: String
        get() = prefs.getString("DATE_FORMAT", getDefaultDateFormat())!!
        set(dateFormat) = prefs.edit().putString("DATE_FORMAT", dateFormat).apply()

    private fun getDefaultDateFormat(): String {
        val format = DateFormat.getDateFormat(context)
        val pattern = (format as SimpleDateFormat).toLocalizedPattern()
        return when (pattern.lowercase().replace(" ", "")) {
            "d.M.y" -> DATE_FORMAT_ONE
            "dd/mm/y" -> DATE_FORMAT_TWO
            "mm/dd/y" -> DATE_FORMAT_THREE
            "y-mm-dd" -> DATE_FORMAT_FOUR
            "dmmmmy" -> DATE_FORMAT_FIVE
            "mmmmdy" -> DATE_FORMAT_SIX
            "mm-dd-y" -> DATE_FORMAT_SEVEN
            "dd-mm-y" -> DATE_FORMAT_EIGHT
            else -> DATE_FORMAT_ONE
        }
    }

    var enableFingerprint: Boolean
        get() = prefs.getBoolean("USE_FINGERPRINT", false)
        set(enableFingerprint) = prefs.edit().putBoolean("USE_FINGERPRINT", enableFingerprint).apply()
    var hideSystemUI: Boolean
        get() = prefs.getBoolean("HIDE_SYSTEM_UI", false)
        set(hideSystemUI) = prefs.edit().putBoolean("HIDE_SYSTEM_UI", hideSystemUI).apply()

    var hideVault: Boolean
        get() = prefs.getBoolean("VAULT_VISIBILITY", false)
        set(hideVault) = prefs.edit().putBoolean("VAULT_VISIBILITY", hideVault).apply()
//    var hintExclude: Boolean
//        get() = prefs.getBoolean("hintExclude", false)
//        set(hideVault) = prefs.edit().putBoolean("hintExclude", hideVault).apply()
//    var hintRecycle: Boolean
//        get() = prefs.getBoolean("hintRecycle", false)
//        set(hideVault) = prefs.edit().putBoolean("hintRecycle", hideVault).apply()
//    var hideCamera: Boolean
//        get() = prefs.getBoolean("CAMERA_VISIBILITY", false)
//        set(hideVault) = prefs.edit().putBoolean("CAMERA_VISIBILITY", hideVault).apply()

    var maxBrightness: Boolean
        get() = prefs.getBoolean("MAX_BRIGHTNESS", false)
        set(maxBrightness) = prefs.edit().putBoolean("MAX_BRIGHTNESS", maxBrightness).apply()

    var keepLastModified: Boolean
        get() = prefs.getBoolean("KEEP_LAST_MODIFIED", true)
        set(keepLastModified) = prefs.edit().putBoolean("KEEP_LAST_MODIFIED", keepLastModified).apply()

//    var passwordRetryCount: Int
//        get() = prefs.getInt("PASSWORD_RETRY_COUNT", 0)
//        set(passwordRetryCount) = prefs.edit().putInt("PASSWORD_RETRY_COUNT", passwordRetryCount).apply()
//    var passwordCountdownStartMs: Long
//        get() = prefs.getLong("PASSWORD_COUNTDOWN_START_MS", 0L)
//        set(passwordCountdownStartMs) = prefs.edit().putLong("PASSWORD_COUNTDOWN_START_MS", passwordCountdownStartMs).apply()

    fun removeLastVideoPosition(path: String) {
        prefs.edit().remove("${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(Locale.getDefault())}").apply()
    }

    fun saveLastVideoPosition(path: String, value: Int) {
        if (path.isNotEmpty()) {
            prefs.edit().putInt("${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(Locale.getDefault())}", value).apply()
        }
    }

    fun getLastVideoPosition(path: String) = prefs.getInt("${Constant.LAST_VIDEO_POSITION_PREFIX}${path.lowercase(
        Locale.getDefault())}", 0)

    fun getAllLastVideoPositions() = prefs.all.filterKeys {
        it.startsWith(Constant.LAST_VIDEO_POSITION_PREFIX)
    }

    var loopVideos: Boolean
        get() = prefs.getBoolean(Constant.LOOP_VIDEOS, false)
        set(loop) = prefs.edit().putBoolean(Constant.LOOP_VIDEOS, loop).apply()

    var rememberLastVideoPosition: Boolean
        get() = prefs.getBoolean("remember_last_video_position", false)
        set(rememberLastVideoPosition) {
            if (!rememberLastVideoPosition) {
                getAllLastVideoPositions().forEach {
                    prefs.edit().remove(it.key).apply()
                }
            }
            prefs.edit().putBoolean("remember_last_video_position", rememberLastVideoPosition).apply()
        }

    var showNotch: Boolean
        get() = prefs.getBoolean("SHOW_NOTCH", true)
        set(showNotch) = prefs.edit().putBoolean("SHOW_NOTCH", showNotch).apply()

    var screenRotation: Int
        get() = prefs.getInt(Constant.SCREEN_ROTATION, Constant.ROTATE_BY_SYSTEM_SETTING)
        set(screenRotation) = prefs.edit().putInt(Constant.SCREEN_ROTATION, screenRotation).apply()
    var saveEditAction: Int
        get() = prefs.getInt("saveEditAction", Constant.ALWAYS_ASK)
        set(value) = prefs.edit().putInt("saveEditAction", value).apply()

    var hintEditShown: Boolean
        get() = prefs.getBoolean("hintEditShown", false)
        set(value) = prefs.edit().putBoolean("hintEditShown", value).apply()
    var isConfirmEditAction: Boolean
        get() = prefs.getBoolean("isConfirmEditAction", false)
        set(value) = prefs.edit().putBoolean("isConfirmEditAction", value).apply()

    var blackBackground: Boolean
        get() = prefs.getBoolean(Constant.BLACK_BACKGROUND, true)
        set(blackBackground) = prefs.edit().putBoolean(Constant.BLACK_BACKGROUND, blackBackground).apply()

    var showExtendedDetails: Boolean
        get() = prefs.getBoolean(Constant.SHOW_EXTENDED_DETAILS, false)
        set(showExtendedDetails) = prefs.edit().putBoolean(Constant.SHOW_EXTENDED_DETAILS, showExtendedDetails).apply()

    var hideExtendedDetails: Boolean
        get() = prefs.getBoolean(Constant.HIDE_EXTENDED_DETAILS, false)
        set(hideExtendedDetails) = prefs.edit().putBoolean(Constant.HIDE_EXTENDED_DETAILS, hideExtendedDetails).apply()

    var extendedDetails: Int
        get() = prefs.getInt(Constant.EXTENDED_DETAILS, Constant.EXT_RESOLUTION or Constant.EXT_LAST_MODIFIED or Constant.EXT_EXIF_PROPERTIES)
        set(extendedDetails) = prefs.edit().putInt(Constant.EXTENDED_DETAILS, extendedDetails).apply()

    var showHighestQuality: Boolean
        get() = prefs.getBoolean(Constant.SHOW_HIGHEST_QUALITY, false)
        set(showHighestQuality) = prefs.edit().putBoolean(Constant.SHOW_HIGHEST_QUALITY, showHighestQuality).apply()

    var allowPhotoGestures: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_PHOTO_GESTURES, false)
        set(allowPhotoGestures) = prefs.edit().putBoolean(Constant.ALLOW_PHOTO_GESTURES, allowPhotoGestures).apply()

    var allowZoomingImages: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_ZOOMING_IMAGES, true)
        set(allowZoomingImages) = prefs.edit().putBoolean(Constant.ALLOW_ZOOMING_IMAGES, allowZoomingImages).apply()

    var allowInstantChange: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_INSTANT_CHANGE, false)
        set(allowInstantChange) = prefs.edit().putBoolean(Constant.ALLOW_INSTANT_CHANGE, allowInstantChange).apply()

    var allowOneToOneZoom: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_ONE_TO_ONE_ZOOM, false)
        set(allowOneToOneZoom) = prefs.edit().putBoolean(Constant.ALLOW_ONE_TO_ONE_ZOOM, allowOneToOneZoom).apply()

    var allowRotatingWithGestures: Boolean
        get() = prefs.getBoolean(Constant.ALLOW_ROTATING_WITH_GESTURES, true)
        set(allowRotatingWithGestures) = prefs.edit().putBoolean(Constant.ALLOW_ROTATING_WITH_GESTURES, allowRotatingWithGestures).apply()
    var isSetLanguage: Boolean
        get() = prefs.getBoolean("isSetLanguage", false)
        set(isSetLanguage) = prefs.edit().putBoolean("isSetLanguage", isSetLanguage).apply()

    fun getCoverImage(album: String):String {
        return prefs.getString("AlbumCover$album", "")?:""
    }
    fun setCoverImage(album: String,path: String)  {
        editor.putString("AlbumCover$album",path)
        editor.apply()
    }

    var appOpenCounter: Int
        get() = prefs.getInt("appOpenCounter", 0)
        set(appOpenCounter) = prefs.edit().putInt("appOpenCounter", appOpenCounter).apply()

    var splashCounter: Int
        get() = prefs.getInt("splashCounter", 0)
        set(splashCounter) = prefs.edit().putInt("splashCounter", splashCounter).apply()

    fun putTheme(themeValue: Int) {
        editor.putInt(Constant.PREF_KEY_THEME, themeValue)
        editor.apply()
    }

    fun getThemeValue(): Int {
//        return prefs.getInt(Constant.PREF_KEY_THEME, Constant.THEME_DARK)
        return prefs.getInt(Constant.PREF_KEY_THEME, Constant.THEME_LIGHT)
    }

    fun setSelectLanguage(result: Int) {
        editor.putInt(Constant.PREF_KEY_LANGUAGE, result)
        editor.apply()
    }

    fun getSelectLanguage(): Int {
        return prefs.getInt(Constant.PREF_KEY_LANGUAGE, 0)
    }
    fun setLastAlBumCreated(result: String) {
        editor.putString(Constant.PREF_ALBUM_CREATED, result)
        editor.apply()
    }
    fun removeLastAlBumCreated() {
        editor.remove(Constant.PREF_ALBUM_CREATED)
        editor.apply()
    }

    fun getLastAlBumCreated(): String {
        return prefs.getString(Constant.PREF_ALBUM_CREATED,"")?:""
    }

    fun setAlbumSortType(result: Int,folder:String?="") {
        editor.putInt("${Constant.PREFS_FOLDER_SORT_TYPE}$folder", result)
        editor.apply()
    }

    fun getAlbumSortType(folder:String?=""): Int {
        return prefs.getInt("${Constant.PREFS_FOLDER_SORT_TYPE}$folder", Constant.SORT_LAST_MODIFIED)
    }

//    fun setAlbumSortType(result: Int) {
//        editor.putInt(Constant.PREFS_FOLDER_SORT_TYPE, result)
//        editor.apply()
//    }
//    fun getAlbumSortType(): Int {
//        return prefs.getInt(Constant.PREFS_FOLDER_SORT_TYPE, Constant.SORT_LAST_MODIFIED)
//    }


    fun setSortType(result: Int,folder:String?="") {
        editor.putInt("${Constant.PREFS_SORT_TYPE}$folder", result)
        editor.apply()
    }

    fun getSortType(folder:String?=""): Int {
        return prefs.getInt("${Constant.PREFS_SORT_TYPE}$folder", Constant.SORT_LAST_MODIFIED)
    }

    fun setFilterMedia(result: Int) {
        editor.putInt(Constant.FILTER_MEDIA, result)
        editor.apply()
    }

    fun getFilterMedia(): Int {
        return prefs.getInt(Constant.FILTER_MEDIA, getDefaultFileFilter())
    }

    fun setGroupBy(result: Int,folder:String?="") {
        editor.putInt("${Constant.GROUP_BY}$folder", result)
        editor.apply()
    }
    fun getGroupBy(folder:String?=""): Int {
//        return prefs.getInt(Constant.GROUP_BY, Constant.GROUP_BY_LAST_MODIFIED_DAILY)
        return prefs.getInt("${Constant.GROUP_BY}$folder", Constant.GROUP_BY_LAST_MODIFIED_DAILY)
    }

//    fun setAlbumGroupType(result: Int) {
//        editor.putInt(Constant.PREFS_FOLDER_GROUP_TYPE, result)
//        editor.apply()
//    }
//    fun getAlbumGroupType(): Int {
//        return prefs.getInt(Constant.PREFS_FOLDER_GROUP_TYPE, Constant.GROUP_BY_LAST_MODIFIED_DAILY)
//    }

    fun setGroupOrderBy(result: Int,folder:String?="") {
        editor.putInt("${Constant.GROUP_ORDER_BY}$folder", result)
        editor.apply()
    }
    fun getGroupOrderBy(folder:String?=""): Int {
        return prefs.getInt("${Constant.GROUP_ORDER_BY}$folder", Constant.GROUP_BY_NONE)
    }

    fun setAlbumSortOrder(result: Int,folder:String?="") {
        editor.putInt("${Constant.PREFS_FOLDER_SORT_ORDER}$folder", result)
        editor.apply()
    }

    fun getAlbumSortOrder(folder:String?=""): Int {
        return prefs.getInt("${Constant.PREFS_FOLDER_SORT_ORDER}$folder", Constant.SORT_LAST_MODIFIED)
    }
//    fun setAlbumSortOrder(result: Int) {
//        editor.putInt(Constant.PREFS_FOLDER_SORT_ORDER, result)
//        editor.apply()
//    }
//    fun getAlbumSortOrder(): Int {
//        return prefs.getInt(Constant.PREFS_FOLDER_SORT_ORDER, Constant.ORDER_DESCENDING)
//    }

    fun setInt(key:String,result: Int) {
        editor.putInt(key, result)
        editor.apply()
    }

    fun getInt(key:String,default:Int?=0): Int {
        return prefs.getInt(key, default!!)
    }
    fun setString(key:String,result: String) {
        editor.putString(key, result)
        editor.apply()
    }

    fun getString(key:String,default:String?=""): String {
        return prefs.getString(key, default!!)?:""
    }

    fun setBoolean(key:String,result: Boolean) {
        editor.putBoolean(key, result)
        editor.apply()
    }

    fun getBoolean(key:String,default: Boolean?=false): Boolean {
        return prefs.getBoolean(key, default!!)
    }

//    fun setAlbumGroupOrder(result: Int) {
//        editor.putInt(Constant.PREFS_FOLDER_GROUP_ORDER, result)
//        editor.apply()
//    }
//    fun getAlbumGroupOrder(): Int {
//        return sharedPreferences.getInt(Constant.PREFS_FOLDER_GROUP_ORDER, Constant.ORDER_DESCENDING)
//    }


    fun setSortOrder(result: Int,folder:String?="") {
        editor.putInt("${Constant.PREFS_SORT_ORDER}$folder", result)
        editor.apply()
    }

    fun getSortOrder(folder:String?=""): Int {
        return prefs.getInt("${Constant.PREFS_SORT_ORDER}$folder", Constant.ORDER_DESCENDING)
    }

    fun setGridCount(result: Int,folder:String?="") {
        editor.putInt("${Constant.PREFS_GRID_COUNT}$folder", result)
        editor.apply()
    }

    fun getGridCount(folder:String?=""): Int {
        return prefs.getInt("${Constant.PREFS_GRID_COUNT}$folder", 3)
//        return prefs.getInt(Constant.PREFS_GRID_COUNT, 3)
    }

    fun setAlbumGridCount(result: Int) {
        editor.putInt(Constant.PREFS_ALBUM_GRID_COUNT, result)
        editor.apply()
    }

    fun getAlbumGridCount(): Int {
        return prefs.getInt(Constant.PREFS_ALBUM_GRID_COUNT, 3)
    }

    fun putShowGrid(result: Boolean) {
        editor.putBoolean(Constant.PREFS_GRID_SHOW, result)
        editor.apply()
    }

    fun getShowGrid(): Boolean {
        return prefs.getBoolean(Constant.PREFS_GRID_SHOW, true)
    }
    fun putShowFileCount(result: Boolean) {
        editor.putBoolean(Constant.PREFS_SHOW_FILE_COUNT, result)
        editor.apply()
    }

    fun getShowFileCount(): Boolean {
        return prefs.getBoolean(Constant.PREFS_SHOW_FILE_COUNT, false)
    }

    fun putShowPinLock(result: Boolean) {
        editor.putBoolean(Constant.PREFS_LOCK_STYLE, result)
        editor.apply()
    }

    fun getShowPINLock(): Boolean {
        return prefs.getBoolean(Constant.PREFS_LOCK_STYLE, true)
    }

    fun putSetPass(result: Boolean) {
        editor.putBoolean("passcode_set", result)
        editor.apply()
    }

    fun getSetPass(): Boolean {
        return prefs.getBoolean("passcode_set", false)
    }

    fun putPass(result: String) {
        editor.putString(Constant.PREF_PASSCODE, result)
        editor.apply()
    }

    fun getPass(): String? {
        return prefs.getString(Constant.PREF_PASSCODE, "")
    }

    fun putSetPattern(result: Boolean) {
        editor.putBoolean(Constant.PREF_PATTERN_SET, result)
        editor.apply()
    }

    fun getSetPattern(): Boolean {
        return prefs.getBoolean(Constant.PREF_PATTERN_SET, false)
    }

    fun putPattern(result: String) {
        editor.putString(Constant.PREF_PATTERN, result)
        editor.apply()
    }

    fun getPattern(): String? {
        return prefs.getString(Constant.PREF_PATTERN, "")
    }

    fun putSetQuestion(result: Boolean) {
        editor.putBoolean(Constant.PREF_SECURITY_SET, result)
        editor.apply()
    }

    fun getSetQuestion(): Boolean {
        return prefs.getBoolean(Constant.PREF_SECURITY_SET, false)
    }
    fun putIgnoreQuestion(result: Boolean) {
        editor.putBoolean(Constant.PREF_IGNOR_SECURITY_QUESTION, result)
        editor.apply()
    }
    fun getIgnoreQuestion(): Boolean {
        return prefs.getBoolean(Constant.PREF_IGNOR_SECURITY_QUESTION, false)
    }

    var securityEmail: String
        get() = prefs.getString(Constant.PREF_SECURITY_EMAIL, "")?:""
        set(securityEmail) = prefs.edit().putString(Constant.PREF_SECURITY_EMAIL, securityEmail).apply()
//    fun putSecurityEmail(result: String) {
//        editor.putString(Constant.PREF_SECURITY_EMAIL, result)
//        editor.apply()
//    }
//
//    fun getSecurityEmail(): String {
//        return prefs.getString(Constant.PREF_SECURITY_EMAIL, "")?:""
//    }
    fun putSecurityQuestion(result: Int) {
        editor.putInt(Constant.PREF_SECURITY_QUESTION, result)
        editor.apply()
    }

    fun getSecurityQuestion(): Int {
        return prefs.getInt(Constant.PREF_SECURITY_QUESTION, 0)
    }


    fun putAnswerQuestion(result: String) {
        editor.putString(Constant.PREF_SECURITY_ANS, result)
        editor.apply()
    }

    fun getAnswerQuestion(): String? {
        return prefs.getString(Constant.PREF_SECURITY_ANS, "")
    }

    fun putVeriCode(result: String,time:Long) {
        editor.putString(Constant.PREF_OTP, result)
        editor.putLong(Constant.PREF_OTP_TIME, time)
        editor.apply()
    }

    fun getVeriCode(): String {
        return prefs.getString(Constant.PREF_OTP, "")?:""
    }
    fun getOtpTimeOut(): Long {
        return prefs.getLong(Constant.PREF_OTP_TIME, 0)?:0
    }

    var shouldShowHidden = showHiddenMedia || temporarilyShowHidden

    var showHiddenMedia: Boolean
        get() = prefs.getBoolean("SHOW_HIDDEN_MEDIA", false)
        set(showHiddenFolders) = prefs.edit().putBoolean("SHOW_HIDDEN_MEDIA", showHiddenFolders).apply()

    var temporarilyShowHidden: Boolean
        get() = prefs.getBoolean("TEMPORARILY_SHOW_HIDDEN", false)
        set(temporarilyShowHidden) = prefs.edit().putBoolean("TEMPORARILY_SHOW_HIDDEN", temporarilyShowHidden).apply()

    var temporarilyShowExcluded: Boolean
        get() = prefs.getBoolean("TEMPORARILY_SHOW_EXCLUDED", false)
        set(temporarilyShowExcluded) = prefs.edit().putBoolean("TEMPORARILY_SHOW_EXCLUDED", temporarilyShowExcluded).apply()

    // if a user hides a folder, then enables temporary hidden folder displaying, make sure we show it properly
    var everShownFolders: Set<String>
        get() = prefs.getStringSet("EVER_SHOWN_FOLDERS", getEverShownFolders())!!
        set(everShownFolders) = prefs.edit().putStringSet("EVER_SHOWN_FOLDERS", everShownFolders).apply()

    var internalStoragePath: String
        get() = prefs.getString("INTERNAL_STORAGE_PATH", getDefaultInternalPath())!!
        set(internalStoragePath) = prefs.edit().putString("INTERNAL_STORAGE_PATH", internalStoragePath).apply()

    private fun getDefaultInternalPath() = if (prefs.contains("INTERNAL_STORAGE_PATH")) "" else context.getInternalStoragePath()

    private fun getEverShownFolders() = hashSetOf(
        internalStoragePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath,
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath,
        "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath}/Screenshots",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Images/Sent",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video",
        "$internalStoragePath/WhatsApp/Media/WhatsApp Video/Sent",
        "$internalStoragePath/WhatsApp/Media/.Statuses",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images",
        "$internalStoragePath/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video"
    )

    fun getIncludeList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
        val response: String =
            prefs.getString(Constant.SHARED_PREFS_INCLUDE_LIST, "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setIncludeList(list: ArrayList<String>) {
        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString(Constant.SHARED_PREFS_INCLUDE_LIST, resultString)
        editor.apply()
    }

    fun getExcludeList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
        val response: String =
            prefs.getString(Constant.SHARED_PREFS_EXCLUDE_LIST, "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setExcludeList(list: ArrayList<String>) {
        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString(Constant.SHARED_PREFS_EXCLUDE_LIST, resultString)
        editor.apply()
    }

    fun getFavoriteList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
//        try {
//            val response: String =
//                sharedPreferences.getString("Favorite_list", "")!!
//            if (response.isNotEmpty()) {
//                val gson = Gson()
//                val typeToken: TypeToken<List<String>> = object : TypeToken<List<String>>() {}
//
////                val type = object : TypeToken<List<String>>() {}.type
//                val type = typeToken.type
//                list = gson.fromJson(response, type)
//            }
//        } catch (e: Exception) {
//            Log.e("printStackTrace","printStackTrace:$e")
//        }
        val response: String =
            prefs.getString("Favorite_list", "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setFavoriteList(list: ArrayList<String>) {

        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString("Favorite_list", resultString)
        editor.apply()
    }

    fun getPinAlbumList(): ArrayList<String> {
        val list: ArrayList<String> = ArrayList()
        val response: String =
            prefs.getString("pin_top_list", "") ?: ""
        if (!response.isNullOrEmpty()) {
            val delimiter = "(,/^)"
            val stringArray = response.split(delimiter)
            if (!stringArray.isNullOrEmpty())
                list.addAll(stringArray)
        }
        return list
    }

    fun setPinAlbumList(list: ArrayList<String>) {
        val delimiter = "(,/^)"
        val resultString = if (list.isEmpty())
            "" else
            list.joinToString(delimiter)
        Log.e("TAGPREF", "SETResultString $resultString")
        val editor: SharedPreferences.Editor = prefs.edit()
        editor.putString("pin_top_list", resultString)
        editor.apply()
    }


}