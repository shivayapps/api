package gallery.gallerylock.vaultgallery.hidepictures.edit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.adconfig.adsutil.admob.BannerAdHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.transition.Transition
import com.google.android.gms.ads.AdView

import com.zomato.photofilters.FilterPack
import com.zomato.photofilters.imageprocessors.Filter
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityFilterBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ProgressDialog
import gallery.gallerylock.vaultgallery.hidepictures.edit.adapter.FilterAdapter
import gallery.gallerylock.vaultgallery.hidepictures.edit.model.FilterItem
import gallery.gallerylock.vaultgallery.hidepictures.extension.updateStatusBarColor
import gallery.gallerylock.vaultgallery.hidepictures.helper.FilterThumbnailsManager
import gallery.gallerylock.vaultgallery.hidepictures.utils.AdCache
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File

class FilterActivity : BaseActivity() {
    lateinit var binding: ActivityFilterBinding
    var filterNewList: ArrayList<FilterItem> = ArrayList()
    var imagePath = ""
    var saveImageName = ""
    var sourceImgBitmap: Bitmap? = null
    var filterBitmap: Bitmap? = null
    lateinit var adapter: FilterAdapter
    var selectPos = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        System.loadLibrary("NativeImageProcessor")
        updateStatusBarColor(Color.parseColor("#131624"))

        intView()
        loadBanner()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {

//        val isFirstSession = Preferences(this).splashCounter == 1
//        val adId =
//            getString(R.string.b_editActivity)
//        BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.llAdPlace, adId,
//            AdCache.editAdView, { isLoaded, adView, message ->
//                mAdView = adView
//                AdCache.editAdView = adView
//                isAdLoaded = isLoaded
//            })
    }

    private fun intView() {

        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""
        binding.txtTitle.text = getString(R.string.Filter)

        intListener()

//        setFilterData()
        val file = File(imagePath)
        if (file.exists()) {
            Glide.with(this)
                .load(imagePath)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into(binding.imageDisplay)

            Glide
                .with(this)
                .asBitmap()
                .load(imagePath)
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?
                    ) {
                        sourceImgBitmap = resource


                    }

                    override fun onLoadCleared(placeholder: Drawable?) {

                    }
                })

            getFilterData()
        } else {
            Toast.makeText(this, getString(R.string.image_not_support), Toast.LENGTH_SHORT).show()
        }
    }

    private fun getFilterData() {
        var bitmap: Bitmap? = null
        Observable.fromCallable {
            val thumbnailSize = 70
            bitmap = try {
                Glide.with(this)
                    .asBitmap()
                    .load(imagePath).listener(object : RequestListener<Bitmap> {
                        override fun onLoadFailed(
                            e: GlideException?,
                            model: Any?,
                            target: Target<Bitmap>,
                            isFirstResource: Boolean
                        ): Boolean {

                            return false
                        }

                        override fun onResourceReady(
                            resource: Bitmap,
                            model: Any,
                            target: Target<Bitmap>,
                            dataSource: DataSource,
                            isFirstResource: Boolean
                        ) = false
                    })
                    .submit(thumbnailSize, thumbnailSize)
                    .get()
            } catch (e: Exception) {
                null
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    getThumbList(bitmap)
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    getThumbList(bitmap)
                }
            }
    }


    private fun getThumbList(bm: Bitmap?) {

        val bitmap = bm
            ?: getBitmapFromDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.ic_filter_none
                )
            )

        val filterThumbnailsManager = FilterThumbnailsManager()
        filterThumbnailsManager.clearThumbs()

        val noFilter = Filter(getString(R.string.None))
        filterThumbnailsManager.addThumb(FilterItem(bitmap, noFilter))

        FilterPack.getFilterPack(this).forEach {
            val filterItem = FilterItem(bitmap, it)
            filterThumbnailsManager.addThumb(filterItem)
        }
        val filterItems = filterThumbnailsManager.processThumbs()
        filterNewList.addAll(filterItems)

        setFilterData()
    }


    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
            if (selectPos != 0 && filterBitmap != null) {
                val progressDialog = ProgressDialog(
                    this@FilterActivity,
                    0,
                    0,
                    getString(R.string.saving),
                    ""
                )
                progressDialog.show(supportFragmentManager, progressDialog.tag)
                Thread {
                    val imagePath = saveEditImage(filterBitmap!!, saveImageName)
                    runOnUiThread {
                        if (imagePath != null) {
                            val intent = Intent()
                            intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                            setResult(RESULT_OK, intent)
                        }
                        progressDialog.dismiss()
                        finish()
                    }
                }.start()
            } else
                finish()
        }
    }

    private fun setFilterData() {
        adapter = FilterAdapter(this, filterNewList, clickListener = {
            selectPos = it
            applyNewFilter(filterNewList[it])
//            if (selectPos == 0) {
//                filterBitmap = sourceImgBitmap
//                binding.imageDisplay.setImageBitmap(sourceImgBitmap)
//            } else
//                applyFilter(filterList[selectPos].filter)
        })
        binding.recyclerView.adapter = adapter

    }

    private fun applyNewFilter(filterItem: FilterItem) {
        val progressDialog = ProgressDialog(
            this@FilterActivity,
            0,
            0,
            getString(R.string.applying),
            ""
        )
        progressDialog.show(supportFragmentManager, progressDialog.tag)
//        Thread {
        try {
            val newBitmap = Bitmap.createBitmap(sourceImgBitmap!!)
            filterBitmap = filterItem.filter.processFilter(newBitmap)
            runOnUiThread {
                if (filterBitmap != null)
                    binding.imageDisplay.setImageBitmap(filterBitmap)
                progressDialog.dismiss()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
            runOnUiThread {
                progressDialog.dismiss()
            }
        }

//        }.start()
    }

}