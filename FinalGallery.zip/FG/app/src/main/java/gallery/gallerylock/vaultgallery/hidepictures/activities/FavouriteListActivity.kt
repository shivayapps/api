package gallery.gallerylock.vaultgallery.hidepictures.activities

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import gallery.gallerylock.vaultgallery.hidepictures.BuildConfig
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.adapter.FavouriteAdapter
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.database.AppDatabase
import gallery.gallerylock.vaultgallery.hidepictures.databinding.PopBottomMenuBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ConfirmationDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.CreateAlbumDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.DeleteDialog
import gallery.gallerylock.vaultgallery.hidepictures.event.CopyMoveEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.DeleteEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.DisplayDeleteEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.RenameEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.UpdateFavoriteEvent
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import gallery.gallerylock.vaultgallery.hidepictures.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityFavouriteListBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.DetailsDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ProgressDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.RenameDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ResizeDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.SelectAlbumFullDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.BatchFolderRenameDialog
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisibleIf
import gallery.gallerylock.vaultgallery.hidepictures.extension.getFinalUriFromPath
import gallery.gallerylock.vaultgallery.hidepictures.extension.getUriMimeType
import gallery.gallerylock.vaultgallery.hidepictures.extension.isGif
import gallery.gallerylock.vaultgallery.hidepictures.extension.openEditorIntent
import gallery.gallerylock.vaultgallery.hidepictures.extension.showErrorToast
import gallery.gallerylock.vaultgallery.hidepictures.extension.toast
import gallery.gallerylock.vaultgallery.hidepictures.utils.AdCache
import gallery.gallerylock.vaultgallery.hidepictures.utils.PopupWindowHelper
import gallery.gallerylock.vaultgallery.hidepictures.utils.ensureBackgroundThread

import gallery.gallerylock.vaultgallery.hidepictures.viewpager.PhotoVideoActivity
import java.util.Locale

class FavouriteListActivity : BaseActivity() {

    var allList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: FavouriteAdapter? = null
    lateinit var preferences: Preferences
    var selectedItem = 0
    var isSelectAll = false

    lateinit var binding: ActivityFavouriteListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityFavouriteListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()

        EventBus.getDefault().register(this)
        intView()

    }

    private fun intView() {
        binding.txtTitle.text = getString(R.string.Favorite)

//        binding.icMenu.setImageDrawable(
//            ContextCompat.getDrawable(
//                this,
//                R.drawable.ic_favourite_uncheck
//            )
//        )
        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
        intListener()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {
        if (!isAdLoaded) {
            val adId = getString(R.string.b_favoriteListActivity)
            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.llAdPlace, adId,
                AdCache.favoriteListAdView,{ isLoaded, adView, message ->
                    mAdView=adView
                    AdCache.favoriteListAdView=adView
                    isAdLoaded=isLoaded
                })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }



    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }
//        binding.icMenu.setOnClickListener {
//            val clearDialog = ConfirmationDialog(
//                this,
//                getString(R.string.clearFavorites),
//                getString(R.string.clearFavoritesMsg),
//                getString(R.string.clear),
//                positiveBtnClickListener = {
//                    clearFav()
//                })
//            clearDialog.show(supportFragmentManager, clearDialog.tag)
//        }
        binding.btnShare.setOnClickListener {
            shareImages()
        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }
//        binding.btnUnFavorite.setOnClickListener {
//            setUnFavoriteData()
//        }
        binding.btnHide.setOnClickListener {
            setHideData()
        }
        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }
    }

    private fun clearFav() {
        preferences.setFavoriteList(ArrayList())
        allList.clear()
        pictures.clear()
//        EventBus.getDefault().post(UpdateFavoriteEvent(unFavoriteList = favList, isFavorite = false))
        setData()
    }

    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        var needToAddFav = false
        var needToRemoveFav = false
        var isVideoSelected = false

        for (i in pictures.indices) {
            if (pictures[i] is PictureData) {
                val model: PictureData = pictures[i] as PictureData
                if (model.isSelected) {
                    if (model.isVideo || model.filePath.isGif()) isVideoSelected = true

                    if (model.isFavorite)
                        needToRemoveFav = true
                    else
                        needToAddFav = true
                }
            }
        }

        popUpBinding.menuEdit.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuSetAs.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuResize.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuInfo.beVisibleIf(selectedItem == 1)
        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)
        popUpBinding.menuCover.beGone()
        popUpBinding.menuExclude.beGone()

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem > 1) {
                showBatchRenameDialog()
            } else showRenameDialog()
        }
        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            setAs()
        }
        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            showResizeDialog()
        }
        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(true)
        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(false)
        }
        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
            val selectImage: ArrayList<PictureData> = ArrayList()
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }
            val pictureData = selectImage[0]
            openEditor(pictureData.filePath)

        }
        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
//            showAddAlbumDialog(Constant.albumList, true)
            showAddAlbumDialog(Constant.deviceAlbumList, true)
            popupWindow.dismiss()
        }
        popUpBinding.menuMove.setOnClickListener {
//            showAddAlbumDialog(Constant.albumList, false)
            showAddAlbumDialog(Constant.deviceAlbumList, false)
            popupWindow.dismiss()
        }
        popupWindow.showAsPopUp(view)
    }


    fun showDetailsDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val detailsDialog = DetailsDialog(pictureData, false)
        detailsDialog.show(supportFragmentManager, detailsDialog.tag)
    }
    fun openEditor(path: String) {
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }
    fun setAs() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        ensureBackgroundThread {
            val newUri =
                getFinalUriFromPath(pictureData.filePath, BuildConfig.APPLICATION_ID)
                    ?: return@ensureBackgroundThread
            Intent().apply {
                action = Intent.ACTION_ATTACH_DATA
                setDataAndType(newUri, getUriMimeType(pictureData.filePath, newUri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(this, getString(R.string.set_as))

                try {
                    startActivityForResult(chooser, 101)
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.no_app_found)
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
        }

    }
    private fun showDropDownOld(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        var needToAddFav = false
        var needToRemoveFav = false
        var isVideoSelected = false
//        val selectedItem = pictures

        for (i in pictures.indices) {
            if (pictures[i] is PictureData) {
                val model: PictureData = pictures[i] as PictureData
                if (model.isSelected){
                    if (model.isVideo || model.filePath.isGif()) isVideoSelected = true
                    if (model.isFavorite)
                        needToRemoveFav = true
                    else
                        needToAddFav = true
                }
            }
        }

        popUpBinding.menuEdit.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuSetAs.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuResize.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)
        popUpBinding.menuCover.beGone()
        popUpBinding.menuExclude.beGone()

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem > 1) {
                showBatchRenameDialog()
            } else showRenameDialog()
        }
        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            showResizeDialog()
        }
        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(true)
        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(false)
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            showAddAlbumDialog(Constant.albumList, true)
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            showAddAlbumDialog(Constant.albumList, false)
        }
        popupWindow.showAsPopUp(view)
    }

    fun showBatchRenameDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        val albumData = selectImage.filter { it.isSelected }
        val paths: ArrayList<String> = ArrayList()
        paths.addAll(albumData.map { it.filePath })

        val renameDialog =
            BatchFolderRenameDialog(
                this,
                true,
                paths,
                updateImageListener = {
                    preferences.scanMedia=true
                    preferences.refreshMedia=true
                    setCloseToolbar()
                })
        renameDialog.show(supportFragmentManager, renameDialog.tag)
    }

    fun showRenameDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        val pictureData = selectImage[0]
        val renameDialog =
            RenameDialog(
                this,
                pictureData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    notifyAdapter()
                })
        renameDialog.show(supportFragmentManager, renameDialog.tag)
    }

    fun showResizeDialog() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val resizeDialog =
            ResizeDialog(
                this,
                pictureData,
                updateImageListener = { path ->
                    val file = File(path)
                    pictures.add(
                        0,
                        PictureData(
                            path,
                            file.name,
                            file.parentFile.path,
                            file.lastModified(),
                            file.lastModified(),
                            file.length()
                        )
                    )
                    setCloseToolbar()
                })
        resizeDialog.show(supportFragmentManager, resizeDialog.tag)
    }

    fun setFavorite(isFavorite: Boolean) {

        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        for (i in pictures.indices) {
            if (pictures[i] is PictureData) {
                val model: PictureData = pictures[i] as PictureData
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath))
                            favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath))
                            favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
        preferences.refreshMedia = true

        setCloseToolbar()
        getData()
//        Handler(Looper.getMainLooper()).postDelayed({
//            runOnUiThread {
//                setCloseToolbar()
//                getData()
//            }
//        }, 1500)

    }

    private fun notifyAdapter() {
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
    }

    private fun setData() {
        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
        setEmptyData()
    }

    private fun setEmptyData() {
        if (pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottom.beVisible()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottom.beGone()
        }

    }

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = FavouriteAdapter(this, pictures, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (pictureData.isCheckboxVisible) {
                    pictureData.isSelected = !pictureData.isSelected
                    pictureAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<PictureData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            dataList.add(pictures[i] as PictureData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    Constant.selectedPosition= displayPos
                    if(Constant.displayImageList.size>0) {
                        val intent = Intent(this, PhotoVideoActivity::class.java)
                        intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                        startActivity(intent)
                    }
                }
            }
        }, longClickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                for (i in pictures.indices) {
                    if (pictures[i] != null)
                        if (pictures[i] is AlbumData) {
                            val model = pictures[i] as AlbumData
                            model.isCheckboxVisible = true
                        } else if (pictures[i] is PictureData) {
                            val model = pictures[i] as PictureData
                            model.isCheckboxVisible = true
                        }
                }
                pictureData.isCheckboxVisible = true
                pictureData.isSelected = true
                notifyAdapter()
                setSelectedFile()
            }
        }, headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is PictureData) {
                        val model = pictures[pos] as PictureData
                        model.isSelected = isSelectAll
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
                notifyAdapter()
                setSelectedFile()
            }
        })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else {
            if (preferences.isNeedInterAd) {


                AdsConfig.showInterstitialAd(this) {
                    if(it) preferences.isNeedInterAd = false
                    finish()
                }
            } else {
                finish()
            }
        }
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text =
            "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if(!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val uris = ArrayList<Uri>()
            ensureBackgroundThread {
                runOnUiThread {
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            val model = pictures[i] as PictureData
                            if (model.isSelected) {
                                val uri = FileProvider.getUriForFile(
                                    this,
                                    this.packageName + ".provider",
                                    File(model.filePath)
                                )
                                uris.add(uri)
                            }
                        }
                    }
                    Utils.shareFilesList(this, uris)
                }
            }
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog = DeleteDialog(
                this,
//                getString(R.string.selected_delete_msg),
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }

    private fun setUnFavoriteData() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val clearDialog = ConfirmationDialog(
                this,
                getString(R.string.unfavorite),
                getString(R.string.unFavorites_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    setUnFavoriteSelect()
                })
            clearDialog.show(supportFragmentManager, clearDialog.tag)
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show(supportFragmentManager, hideDialog.tag)
        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils.hideFiles(this, selectImage, selectedItem, hideListener = {
            toast(getString(R.string.hide_successfully))
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
        }, "", true)
    }

    fun showAddAlbumDialog(albumList: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            val selectedAlbum: ArrayList<AlbumData> = ArrayList()
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }

            val addAlbumDialog =
                SelectAlbumFullDialog(this, albumList,selectedAlbum, isCopy, selectPathListener = { selectPath ->
                    setCopyMove(isCopy, selectPath, selectImage)

                }, createAlbumListener = {
                    val createDialog = CreateAlbumDialog(this, createPathListener = {
                        setCopyMove(isCopy, it, selectImage)
                    })
                    createDialog.show(supportFragmentManager, createDialog.tag)
                })
            addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        if (isCopy)
            Utils.copyFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {

                    toast(getString(R.string.copy_successfully))
                    selectedItem = 0
                    preferences.refreshMedia = true
                    longClickListener(false, 0, false)
                    setClose()
                })
        else
            Utils.moveFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {

                    toast(getString(R.string.move_successfully))
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    longClickListener(false, 0, false)
                    setClose()
                }, true
            )

    }

    private fun setUnFavoriteSelect() {
        val unFavList = ArrayList<String>()
        val favList = preferences.getFavoriteList()
        Observable.fromCallable {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            if (favList.contains(model.filePath)) {
                                favList.remove(model.filePath)
                                unFavList.add(model.filePath)
                            }
                        } else {
                            model.isCheckboxVisible = false
                        }
                    }
            }

            var index = 0
            while (index < pictures.size) {
                if (pictures[index] != null)
                    if (pictures[index] is AlbumData) {
                        val model = pictures[index] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[index] is PictureData) {
                        val model = pictures[index] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (index != 0) {
                                isPre = pictures[index - 1] is AlbumData
                            }
                            if (index < pictures.size - 2) {
                                isNext = pictures[index + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(index)
                                pictures.removeAt(index - 1)
                            } else if (index == pictures.size - 1) {
                                pictures.removeAt(index)
                                if (isPre) {
                                    pictures.removeAt(index - 1)
                                }
                            } else {
                                pictures.removeAt(index)
                            }
                            if (index != 0) {
                                index--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                index++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    setUpdateFavorite(unFavList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    setUpdateFavorite(unFavList)
                }
            }
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            this@FavouriteListActivity,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.show(supportFragmentManager, progressDialog.tag)

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
//                        runOnUiThread {
//                            bindingDialog.txtTitle.text = model.fileName
//                        }

                        val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            runOnUiThread {
                                progressDialog.setProgress(deleteList.size, selectedItem)
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                } else if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()

        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
    }

    private fun setUpdateFavorite(unFavoriteList: ArrayList<String>) {
//        EventBus.getDefault().post(UpdateFavoriteEvent(unFavoriteList = unFavoriteList, isFavorite = false))
        selectedItem = 0
        notifyAdapter()
        longClickListener(false, 0, false)
        setEmptyData()

        toast(getString(R.string.FilesUnfavoritesuccessfully))
        deleteMainList(unFavoriteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>, isFromFav: Boolean = false) {
        if (deleteList.size != 0) {
            val favList = preferences.getFavoriteList()
            for (path in deleteList) {
                if (!isFromFav)
                    if (favList.contains(path))
                        favList.remove(path)
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }

            preferences.setFavoriteList(favList)
        }
    }

    private fun getData() {
        disableScroll()
        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences.getExcludeList())

        allList.clear()
        pictures.clear()
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable<Boolean> {
            var favList = preferences.getFavoriteList()
            if (!favList.isNullOrEmpty()) {
                for (favPath in favList) {
                    var file = File(favPath)
                    var excluded = false
                    excluded = excludeList.any { favPath.startsWith(it) }
                    if (file.exists() && !excluded) {
                        val pictureData =
                            PictureData(
                                favPath,
                                file.name,
                                file.parentFile.name,
                                file.lastModified(),
                                file.lastModified(),
                                file.length(),
                                Utils.isVideoFile(favPath)
                            )
                        pictureData.isFavorite = true
                        allList.add(pictureData)
                    }
                }

            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                runOnUiThread {
                    setFilterData()
                }
            }
            .subscribe { result: Boolean? ->
                runOnUiThread {
                    setFilterData()
                }
            }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }

    private fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()

            runOnUiThread {
                setData()
            }
        }
//        Observable.fromCallable<Boolean> {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                runOnUiThread { setData() }
//            }
    }

    private fun setFilter() {
        Log.e("", "imageVideo size==>> " + allList.size)
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        setList()
    }


    private fun setList() {
        pictures.clear()

        val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
        val currentGrouping = preferences.getGroupBy()
        val groupOrder = preferences.getGroupOrderBy()
//        var format = SimpleDateFormat("dd MMM yyyy")
        var format = SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)

        format = when (currentGrouping) {
            Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
//                SimpleDateFormat("dd MMM yyyy")
                SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            }

            Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
//                SimpleDateFormat("dd MMM yyyy")
                SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            }

            Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
            else -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
        }

        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)

                var imagesData1: ArrayList<PictureData> = ArrayList()
                if (dateWisePictures.containsKey(strDate)) {
                    val list: ArrayList<PictureData>? = dateWisePictures[strDate]
                    if (!list.isNullOrEmpty())
                        imagesData1.addAll(list)
                } else {
                    imagesData1 = ArrayList()
                }
                imagesData1.add(pictureData)
                dateWisePictures[strDate] = imagesData1
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

            if (groupOrder == Constant.ORDER_DESCENDING) {
                listKeys.reverse()
            }

            for (i in listKeys.indices) {
                val imagesData = dateWisePictures[listKeys[i]]
                if (imagesData != null && imagesData.size != 0) {
//                    val bucketData = AlbumData(listKeys[i])
                    val bucketData = AlbumData(listKeys[i], imagesData)
                    pictures.add(bucketData)
                    pictures.addAll(imagesData)
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }


    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {

        if (pictures.isNotEmpty() && event.path.isNotEmpty()) {
            for (picture in pictures) {
                if (picture is PictureData) {
                    val pictureData: PictureData = picture as PictureData
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
            }
            notifyAdapter()
        }
        if (allList.isNotEmpty() && event.path.isNotEmpty())
            for (pictureData in allList) {
                if (pictureData.filePath == event.path) {
                    pictureData.isFavorite = event.isFavorite
                    break
                }
            }
    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList, event.isFromFav)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            pictureAdapter?.notifyDataSetChanged()

            for (pictureData in allList) {
                if (pictureData.filePath == event.oldPath) {
                    pictureData.filePath = event.renamePath
                    pictureData.fileName = File(event.renamePath).name
                    pictureData.fileSize = File(event.renamePath).length()
                    break
                }
            }
        }
    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            if (event.isOpenFromFavorite) {
                if (event.deleteList.isNotEmpty())
                    if (pictures.isNotEmpty()) {
//                                    deleteMainList(event.deleteList)
                        val favList = preferences.getFavoriteList()
                        var isDataChange = false
                        for (i in event.deleteList.indices) {
                            val deletePath = event.deleteList[i]
                            if (favList.contains(deletePath)) {
                                favList.remove(deletePath)
                                if (i < event.copyMoveList.size) {
                                    val moveFilePath = event.copyMoveList[i]
                                    for (picture in pictures) {
                                        if (picture is PictureData) {
                                            val model = picture as PictureData
                                            if (model.filePath == deletePath) {
                                                model.filePath = moveFilePath
                                                model.folderName = event.albumName
                                                model.date =
                                                    File(moveFilePath).lastModified()
                                                isDataChange = true
                                                break
                                            }
                                        }
                                    }

                                    for (pictureData in allList) {
                                        if (pictureData.filePath == deletePath) {
                                            pictureData.filePath = moveFilePath
                                            pictureData.folderName = event.albumName
                                            pictureData.date =
                                                File(moveFilePath).lastModified()
                                            break
                                        }
                                    }

                                }
                            }
                        }
                        setData()
                    }
            }
        }
    }
}