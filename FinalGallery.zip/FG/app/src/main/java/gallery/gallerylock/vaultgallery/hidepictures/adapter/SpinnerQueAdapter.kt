package gallery.gallerylock.vaultgallery.hidepictures.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat
import gallery.gallerylock.vaultgallery.hidepictures.R

class SpinnerQueAdapter(
    private val context: Context,
    private val itemList: Array<String>
) :
    BaseAdapter() {
    override fun getCount(): Int {
        return itemList.size
    }

    override fun getItem(position: Int): Any {
        return itemList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val viewHolder: ViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        val item = itemList[position]
        viewHolder.itemTextView.text = item
        viewHolder.itemTextView.setTextColor(
            ContextCompat.getColor(
                context,
                R.color.black_text
            )
        )

        viewHolder.itemTextView.visibility = if (position == 0) View.GONE else View.VISIBLE

        return view
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val viewHolder: ViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_spinner_que, parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        val item = itemList[position]
        viewHolder.itemTextView.text = item
        if (position == 0)
            viewHolder.itemTextView.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.cancel_btn_text
                )
            )
        else {
//            viewHolder.itemTextView.setTextColor(ContextCompat.getColor(context, R.color.black_text))
            viewHolder.itemTextView.setTextColor(Color.WHITE)
        }

        return view
    }


    private class ViewHolder(view: View) {
        val itemTextView: TextView = view.findViewById(R.id.txtItem)
    }
}