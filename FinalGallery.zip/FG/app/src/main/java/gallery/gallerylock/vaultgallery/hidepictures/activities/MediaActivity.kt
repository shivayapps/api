package gallery.gallerylock.vaultgallery.hidepictures.activities

import android.os.Bundle
import android.view.View
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityMediaBinding
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences


class MediaActivity : BaseActivity() {


    lateinit var preferences: Preferences
    lateinit var binding: ActivityMediaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityMediaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initView()
        intListener()
    }



    private fun initView() {

        binding.loutNoData.visibility=View.VISIBLE
        binding.loutToolbar.icMenu.visibility=View.GONE

    }

    private fun intListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this) {
                if(it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

}