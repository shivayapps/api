package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogSetAsWallpapaerBinding

class SetWallpaperDialog(val updateListener: (type: Int) -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogSetAsWallpapaerBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogSetAsWallpapaerBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }


    private fun intView() {
        bindingDialog.btnLockScreen.setOnClickListener {
            dismiss()
            updateListener(1)

        }
        bindingDialog.btnHomeScreen.setOnClickListener {
            dismiss()
            updateListener(2)

        }
        bindingDialog.btnBoth.setOnClickListener {
            dismiss()
            updateListener(3)

        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}