package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Point
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.core.widget.addTextChangedListener
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogResizePointBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.toast
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences

class ResizePointDialog(
    var mContext: Activity,
    var size: Point,
    val callback: (newSize: Point) -> Unit
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogResizePointBinding
    var preferences: Preferences = Preferences(mContext)
    var type = ""
    var currentWidth = 0
    var currentHeight = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogResizePointBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {

        bindingDialog.edtWidth.setText("${size.x}")
        bindingDialog.edtHeight.setText("${size.y}")
        currentWidth = size.x
        currentHeight = size.y
        val ratio: Float = currentWidth / currentHeight.toFloat()
        Log.e(
            "ResizeTAG",
            "currentWidth-> $currentWidth  currentHeight-> $currentHeight ratio-> $ratio"
        )

        bindingDialog.edtWidth.requestFocus()
        bindingDialog.edtWidth.addTextChangedListener {
            if (bindingDialog.edtWidth.hasFocus()) {
                var width = getViewValue(bindingDialog.edtWidth)
                Log.e("ResizeTAG", "edtW addTextChanged width-> $width")
                if (width > currentWidth) {
                    bindingDialog.edtWidth.setText(currentWidth.toString())
                    width = currentWidth
                    Log.e("ResizeTAG", "edtW addTextChanged if width-> $width")
                }
                Log.e("ResizeTAG", "edtW addTextChanged Height-> ${(width / ratio).toInt()}")
                bindingDialog.edtHeight.setText((width / ratio).toInt().toString())
            }
        }

        bindingDialog.edtHeight.addTextChangedListener {
            if (bindingDialog.edtHeight.hasFocus()) {
                var height = getViewValue(bindingDialog.edtHeight)
                Log.e("ResizeTAG", "edtH addTextChanged height-> $height")
                if (height > currentHeight) {
                    bindingDialog.edtHeight.setText(currentHeight.toString())
                    height = currentHeight
                    Log.e("ResizeTAG", "edtH addTextChanged if height-> $height")
                }

                Log.e("ResizeTAG", "edtH addTextChanged width-> ${(height * ratio).toInt()}")
                bindingDialog.edtWidth.setText((height * ratio).toInt().toString())
            }
        }
    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnResize.setOnClickListener {
            val width = getViewValue(bindingDialog.edtWidth)
            val height = getViewValue(bindingDialog.edtHeight)
                if ((width <= 0 || height <= 0)) {
                    mContext.toast(getString(R.string.validation_resolution))
                    return@setOnClickListener
                }

            val newSize = Point(width, height)
            callback.invoke(newSize)

        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }


    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}

