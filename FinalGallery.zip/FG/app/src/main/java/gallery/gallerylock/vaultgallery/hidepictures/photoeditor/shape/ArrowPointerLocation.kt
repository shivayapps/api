package gallery.gallerylock.vaultgallery.hidepictures.photoeditor.shape

enum class ArrowPointerLocation { START, END, BOTH }