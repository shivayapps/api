package gallery.gallerylock.vaultgallery.hidepictures.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import gallery.gallerylock.vaultgallery.hidepictures.R;


public class ScaleView extends View {
    private int mWidth;
    private int mHeight;
    private int mCenterX;
    private int mCenterY;
    private int radius;
    private int padding;
    private float currentAngle;
    private double initAngle;
    private Path mArcPath;
    private Paint mArcPaint;
    private Paint mScaleLinePaint;
    private TextPaint mScaleTextPaint;
    private TextPaint mSelectedTextPaint;
    private Paint mCurrentSelectValuePaint;
    private Paint mIndicatorPaint;
    private Paint mMaskPaint;
    private SelectScaleListener selectScaleListener;
    private String mScaleUnit;
    private float mEvenyScaleValue;
    private int mScaleNumber;
    private int mScaleSpace;
    private int mScaleMin;
    private int mDrawLineSpace;
    private int mDrawTextSpace;
    private int mArcLineColor;
    private int mScaleLineColor;
    private int mIndicatorColor;
    private int mScaleTextColor;
    private int mSelectTextColor;
    private int mScaleMaxLength;
    private int eachScalePix;
    private int mSlidingMoveX;
    private int totalX;
    private int mDownX;
    private boolean isArc;
    private int currentValue;

    public ScaleView(Context context) {
        this(context, (AttributeSet)null);
    }

    public ScaleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.padding = 10;
        this.currentAngle = 0.0F;
        this.mScaleUnit = "单位";
        this.mEvenyScaleValue = 1.0F;
        this.mScaleNumber = 30;
        this.mScaleSpace = 1;
        this.mScaleMin = 200;
        this.mDrawLineSpace = 1;
        this.mDrawTextSpace = 5;
        this.mArcLineColor = -65536;
        this.mScaleLineColor = -16776961;
        this.mIndicatorColor = -16711936;
        this.mScaleTextColor = -16777216;
        this.mSelectTextColor = -16777216;
        this.mScaleMaxLength = 100;
        this.eachScalePix = 15;
        this.mSlidingMoveX = 0;
        this.totalX = 0;
        this.isArc = false;
        this.currentValue = 0;
        this.setClickable(true);
        this.initAttr(context, attrs);
        this.initPath();
        this.initPaint();
    }

    private void initAttr(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.ScaleView);
        int shape = typedArray.getInt(R.styleable.ScaleView_shape, 0);
        if (shape == 0) {
            this.isArc = true;
        } else {
            this.isArc = false;
        }

        this.mScaleUnit = typedArray.getString(R.styleable.ScaleView_scaleUnit);
        if (TextUtils.isEmpty(this.mScaleUnit)) {
            this.mScaleUnit = "";
        }

        this.mEvenyScaleValue = typedArray.getFloat(R.styleable.ScaleView_everyScaleValue, 1.0F);
        this.mScaleNumber = typedArray.getInt(R.styleable.ScaleView_scaleNum, 30);
        this.mScaleSpace = typedArray.getInt(R.styleable.ScaleView_scaleSpace, 1);
        this.mScaleMin = typedArray.getInt(R.styleable.ScaleView_scaleMin, 30);
        this.mDrawLineSpace = typedArray.getInt(R.styleable.ScaleView_drawLineSpace, 1);
        this.mDrawTextSpace = typedArray.getInt(R.styleable.ScaleView_drawTextSpace, 5);
        this.mArcLineColor = typedArray.getColor(R.styleable.ScaleView_arcLineColor, -65536);
        this.mScaleLineColor = typedArray.getColor(R.styleable.ScaleView_scaleLineColor, -65536);
        this.mIndicatorColor = typedArray.getColor(R.styleable.ScaleView_indicatorColor, -16711936);
        this.mScaleTextColor = typedArray.getColor(R.styleable.ScaleView_scaleTextColor, -16777216);
        this.mSelectTextColor = typedArray.getColor(R.styleable.ScaleView_selectTextColor, -16777216);
        this.mScaleLineColor = typedArray.getColor(R.styleable.ScaleView_scaleLineColor, Color.parseColor("#666666"));
        this.mScaleTextColor = typedArray.getColor(R.styleable.ScaleView_scaleTextColor, Color.parseColor("#666666"));
        this.mIndicatorColor = typedArray.getColor(R.styleable.ScaleView_indicatorColor, Color.parseColor("#ff9933"));
        this.mScaleMaxLength = typedArray.getInt(R.styleable.ScaleView_scaleMaxLength, 100);
    }

    private void initPaint() {
        this.mArcPaint = new Paint(1);
        this.mArcPaint.setColor(this.mArcLineColor);
        this.mArcPaint.setStyle(Style.STROKE);
        this.mArcPaint.setStrokeWidth(18.0F);
        this.mScaleLinePaint = new Paint(1);
        this.mScaleLinePaint.setColor(this.mScaleLineColor);
        this.mScaleLinePaint.setStrokeCap(Cap.ROUND);
        this.mScaleLinePaint.setStyle(Style.STROKE);
        this.mScaleTextPaint = new TextPaint(1);
        this.mScaleTextPaint.setColor(this.mScaleTextColor);
        this.mScaleTextPaint.setTypeface(Typeface.SANS_SERIF);
        this.mScaleTextPaint.setTextSize(20.0F);
        this.mSelectedTextPaint = new TextPaint(1);
        this.mSelectedTextPaint.setTypeface(Typeface.SERIF);
        this.mSelectedTextPaint.setColor(this.mSelectTextColor);
        this.mSelectedTextPaint.setTextSize(50.0F);
        this.mIndicatorPaint = new Paint();
        this.mIndicatorPaint.setFlags(1);
        this.mIndicatorPaint.setStrokeCap(Cap.ROUND);
        this.mIndicatorPaint.setColor(this.mIndicatorColor);
        this.mIndicatorPaint.setStrokeWidth(18.0F);
        this.mMaskPaint = new Paint();
        this.mMaskPaint.setFlags(1);
        this.mScaleLinePaint = new Paint();
        this.mScaleLinePaint.setAntiAlias(true);
        this.mScaleLinePaint.setStyle(Style.STROKE);
        this.mScaleLinePaint.setStrokeWidth(2.0F);
        this.mScaleLinePaint.setColor(this.mScaleLineColor);
        this.mCurrentSelectValuePaint = new Paint();
        this.mCurrentSelectValuePaint.setAntiAlias(true);
        this.mCurrentSelectValuePaint.setTextSize(30.0F);
        this.mCurrentSelectValuePaint.setColor(this.mSelectTextColor);
        this.mCurrentSelectValuePaint.setTextAlign(Align.CENTER);
        this.mIndicatorPaint = new Paint();
        this.mIndicatorPaint.setAntiAlias(true);
        this.mIndicatorPaint.setColor(this.mIndicatorColor);
    }

    private void initPath() {
        this.mArcPath = new Path();
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        this.mWidth = this.getMeasuredWidth();
        this.mHeight = this.getMeasuredHeight();
        if (this.isArc) {
            this.mCenterX = this.mWidth / 2;
            this.mCenterY = 0;
            this.radius = Math.min(this.mWidth / 2 - this.padding, this.mHeight / 2 - this.padding);
        } else {
            this.mCenterY = this.getMeasuredHeight() / 2;
            this.mCenterX = this.getMeasuredWidth() / 2;
        }

    }

    protected void onDraw(Canvas canvas) {
        if (this.isArc) {
            this.drawArc(canvas);
            this.drawScale(canvas);
            this.drawSelectedScale(canvas);
            this.drawIndicator(canvas);
            this.drawMask(canvas);
        } else {
            this.drawCurrentScale(canvas);
            this.drawNum(canvas);
            this.drawMask(canvas);
        }

    }

    private void drawMask(Canvas canvas) {
        LinearGradient mLeftLinearGradient;
        LinearGradient rightLinearGradient;
        if (this.isArc) {
            mLeftLinearGradient = new LinearGradient(0.0F, 0.0F, (float)(this.mCenterX - 100), 150.0F, -1, 0, TileMode.CLAMP);
            this.mMaskPaint.setShader(mLeftLinearGradient);
            canvas.drawPath(this.mArcPath, this.mMaskPaint);
            rightLinearGradient = new LinearGradient((float)this.mWidth, 0.0F, (float)(this.mCenterX + 100), 150.0F, -1, 0, TileMode.CLAMP);
            this.mMaskPaint.setShader(rightLinearGradient);
            canvas.drawPath(this.mArcPath, this.mMaskPaint);
            canvas.drawPath(this.mArcPath, this.mArcPaint);
        } else {
            this.mMaskPaint.setStrokeWidth((float)this.mHeight);
            mLeftLinearGradient = new LinearGradient(0.0F, (float)this.mCenterY, 100.0F, (float)this.mCenterY, Color.parseColor("#01000000"), Color.parseColor("#11000000"), TileMode.CLAMP);
            this.mMaskPaint.setShader(mLeftLinearGradient);
            canvas.drawLine(0.0F, (float)this.mCenterY, (float)this.mCenterX, (float)this.mCenterY, this.mMaskPaint);
            rightLinearGradient = new LinearGradient((float)(this.mWidth - 100), (float)this.mCenterY, (float)this.mWidth, (float)this.mCenterY, Color.parseColor("#11000000"), Color.parseColor("#01000000"), TileMode.CLAMP);
            this.mMaskPaint.setShader(rightLinearGradient);
            canvas.drawLine((float)this.mCenterX, (float)this.mCenterY, (float)this.mWidth, (float)this.mCenterY, this.mMaskPaint);
        }

    }

    private void drawIndicator(Canvas canvas) {
        PathMeasure mPathMeasure = new PathMeasure();
        mPathMeasure.setPath(this.mArcPath, false);
        float[] tan = new float[2];
        float[] pos = new float[2];
        mPathMeasure.getPosTan(mPathMeasure.getLength() * 0.5F, pos, tan);
        canvas.save();
        double angle = this.calcArcAngle(Math.atan2((double)tan[1], (double)tan[0])) + 90.0;
        canvas.rotate((float)angle, pos[0], pos[1]);
        canvas.drawLine(pos[0], pos[1], pos[0] + 80.0F, pos[1], this.mIndicatorPaint);
        Path linePath = new Path();
        linePath.moveTo(pos[0] + 80.0F, pos[1] - 20.0F);
        linePath.lineTo(pos[0] + 80.0F + 20.0F, pos[1]);
        linePath.lineTo(pos[0] + 80.0F, pos[1] + 20.0F);
        canvas.drawPath(linePath, this.mIndicatorPaint);
        canvas.restore();
    }

    private void drawSelectedScale(Canvas canvas) {
        int selectedScale = Math.round(this.currentAngle + (float)this.mScaleMin + (float)(this.mScaleNumber / 2 * this.mScaleSpace));
        if (this.selectScaleListener != null) {
            this.selectScaleListener.selectScale(selectedScale);
        }

        String selectedScaleText = selectedScale + this.mScaleUnit;
        float selectedScaleTextLength = this.mSelectedTextPaint.measureText(selectedScaleText, 0, selectedScaleText.length());
        canvas.drawText(selectedScaleText, (float)this.mCenterX - selectedScaleTextLength / 2.0F, (float)(this.mCenterY + 100), this.mSelectedTextPaint);
    }

    private void drawScale(Canvas canvas) {
        PathMeasure mPathMeasure = new PathMeasure();
        mPathMeasure.setPath(this.mArcPath, false);
        float[] pos = new float[2];
        float[] tan = new float[2];

        for(int i = 1; i <= this.mScaleNumber; ++i) {
            float percentage = (float)i / (float)this.mScaleNumber;
            mPathMeasure.getPosTan(mPathMeasure.getLength() * percentage, pos, tan);
            double atan2 = Math.atan2((double)tan[1], (double)tan[0]);
            double angle = this.calcArcAngle(atan2) + 90.0;
            int scale = Math.round(this.currentAngle + (float)this.mScaleMin + (float)(i * this.mScaleSpace));
            if (scale >= this.mScaleMin && scale % this.mDrawLineSpace == 0) {
                float startX = pos[0];
                float startY = pos[1];
                float endX = 0.0F;
                float endY = pos[1];
                if (scale % this.mDrawTextSpace == 0) {
                    endX = pos[0] + 80.0F;
                    this.mScaleLinePaint.setStrokeWidth(15.0F);
                    this.mScaleLinePaint.setColor(this.mScaleLineColor);
                    if (this.currentAngle >= (float)(-(this.mScaleNumber / 2) * this.mScaleSpace)) {
                        canvas.save();
                        canvas.rotate((float)(angle + 90.0), pos[0], pos[1]);
                        String mScaleText = scale + this.mScaleUnit;
                        float scaleTextLength = this.mScaleTextPaint.measureText(mScaleText, 0, mScaleText.length());
                        canvas.drawText(mScaleText, pos[0] - scaleTextLength / 2.0F, pos[1] - 130.0F, this.mScaleTextPaint);
                        canvas.restore();
                    }
                } else if (scale % this.mDrawLineSpace == 0) {
                    this.mScaleLinePaint.setColor(this.mScaleTextColor);
                    this.mScaleLinePaint.setStrokeWidth(10.0F);
                    endX = pos[0] + 50.0F;
                }

                canvas.save();
                canvas.rotate((float)angle, pos[0], pos[1]);
                canvas.drawLine(startX, startY, endX, endY, this.mScaleLinePaint);
                canvas.restore();
            }
        }

    }

    private void drawArc(Canvas canvas) {
        int top = -this.radius;
        int bottom = this.radius;
        int left = this.mCenterX - this.radius;
        int right = this.mCenterX + this.radius;
        this.mArcPath.reset();
        this.mArcPath.addArc(new RectF((float)left, (float)top, (float)right, (float)bottom), 0.0F, 180.0F);
        canvas.drawPath(this.mArcPath, this.mArcPaint);
    }

    private void drawNum(Canvas canvas) {
        this.mScaleTextPaint.setStrokeWidth(2.0F);
        this.mScaleTextPaint.setColor(this.mScaleTextColor);
        this.mScaleTextPaint.setTextAlign(Align.CENTER);

        for(int i = 0; i < this.mWidth; ++i) {
            int top = this.mCenterY + 10;
            if ((-this.totalX + i) % (this.eachScalePix * this.mDrawTextSpace) == 0) {
                top += 30;
                if (-this.totalX + i >= 0 && -this.totalX + i <= this.mScaleMaxLength * this.eachScalePix) {
                    canvas.drawText((-this.totalX + i) / this.eachScalePix + this.mScaleMin + "", (float)i, (float)(top + 20), this.mScaleTextPaint);
                }
            }

            if ((-this.totalX + i) % this.eachScalePix == 0 && -this.totalX + i >= 0 && -this.totalX + i <= this.mScaleMaxLength * this.eachScalePix) {
                canvas.drawLine((float)i, (float)this.mCenterY, (float)i, (float)top, this.mScaleLinePaint);
            }
        }

    }

    private void drawCurrentScale(Canvas canvas) {
        this.currentValue = (-this.totalX + this.mCenterX) / this.eachScalePix + this.mScaleMin;
        if (this.selectScaleListener != null) {
            this.selectScaleListener.selectScale(this.currentValue);
        }

        RectF roundRectF = new RectF();
        roundRectF.left = (float)(this.mCenterX - 3);
        roundRectF.right = (float)(this.mCenterX + 3);
        roundRectF.top = (float)this.mCenterY;
        roundRectF.bottom = (float)(this.mCenterY + 50);
        canvas.drawRoundRect(roundRectF, 6.0F, 6.0F, this.mIndicatorPaint);
        String currentScaleText = this.currentValue + "";
        canvas.drawText(currentScaleText + this.mScaleUnit, (float)this.mCenterX, (float)(this.mCenterY - 10), this.mCurrentSelectValuePaint);
    }

    public boolean onTouchEvent(MotionEvent event) {
        float mTouchX;
        float mTouchY;
        switch (event.getAction()) {
            case 0:
                if (this.isArc) {
                    mTouchX = event.getX();
                    mTouchY = event.getY();
                    this.initAngle = this.computeAngle(mTouchX, mTouchY);
                    if (mTouchX > (float)this.mCenterX) {
                        this.initAngle = 180.0 - this.initAngle;
                    }
                } else {
                    this.mDownX = (int)event.getX();
                }
            case 1:
            default:
                break;
            case 2:
                if (this.isArc) {
                    mTouchX = event.getX();
                    mTouchY = event.getY();
                    if (this.isTouch(mTouchX, mTouchY)) {
                        double moveAngle = this.computeAngle(mTouchX, mTouchY);
                        if (mTouchX > (float)this.mCenterX) {
                            moveAngle = 180.0 - moveAngle;
                        }

                        double tempAngle = moveAngle - this.initAngle;
                        long addValue = Math.round(tempAngle * (double)this.mEvenyScaleValue);
                        this.currentAngle += (float)addValue;
                        if (this.currentAngle >= (float)(-(this.mScaleNumber / 2) * this.mScaleSpace)) {
                            this.invalidate();
                        } else {
                            this.currentAngle -= (float)addValue;
                        }

                        this.initAngle = moveAngle;
                        return true;
                    }
                } else {
                    this.mSlidingMoveX = (int)(event.getX() - (float)this.mDownX);
                    this.totalX += this.mSlidingMoveX;
                    if (this.mSlidingMoveX < 0) {
                        if (-this.totalX + this.mCenterX > this.mScaleMaxLength * this.eachScalePix) {
                            this.totalX -= this.mSlidingMoveX;
                            return true;
                        }

                        this.invalidate();
                    } else {
                        if (this.totalX - this.mCenterX > 0) {
                            this.totalX -= this.mSlidingMoveX;
                            return true;
                        }

                        this.invalidate();
                    }

                    this.mDownX = (int)event.getX();
                }
        }

        return super.onTouchEvent(event);
    }

    private double computeAngle(float touchX, float touchY) {
        double atan2 = Math.atan2((double)touchY, (double)touchX);
        double taperedEdge = Math.sqrt(Math.pow((double)(touchX - (float)this.mCenterX), 2.0) + Math.pow((double)(touchY - (float)this.mCenterY), 2.0));
        double sin = (double)(touchY - (float)this.mCenterY) / taperedEdge;
        double asin = Math.asin(sin);
        double calcArcAngle = this.calcArcAngle(asin);
        return calcArcAngle;
    }

    private double calcArcAngle(double arc) {
        double angle = arc * 180.0 / Math.PI;
        return angle;
    }

    private boolean isTouch(float touchX, float touchY) {
        float x = touchX - (float)this.mCenterX;
        float y = touchY - (float)this.mCenterY;
        return Math.pow((double)x, 2.0) + Math.pow((double)y, 2.0) < Math.pow((double)this.radius, 2.0);
    }

    public void setSelectScaleListener(SelectScaleListener listener) {
        this.selectScaleListener = listener;
    }

    public void setScaleUnit(String scaleUnit) {
        this.mScaleUnit = scaleUnit;
    }

    public void setEvenyScaleValue(float everyScaleValue) {
        this.mEvenyScaleValue = everyScaleValue;
    }

    public void setScaleNum(int scaleNum) {
        this.mScaleNumber = scaleNum;
    }

    public void setScaleMin(int mScaleMin) {
        this.mScaleMin = mScaleMin;
    }

    public void setDrawLineSpace(int drawLineSpace) {
        this.mScaleNumber = drawLineSpace;
        this.invalidate();
    }

    public void setDrawTextSpace(int drawTextSpace) {
        this.mScaleNumber = drawTextSpace;
        this.invalidate();
    }

    private void setArcLineColor(int color) {
        this.mArcLineColor = color;
        this.invalidate();
    }

    private void setScaleLineColor(int color) {
        this.mScaleLineColor = color;
        this.invalidate();
    }

    private void setIndicatorColor(int color) {
        this.mIndicatorColor = color;
        this.invalidate();
    }

    private void setScaleTextColor(int color) {
        this.mScaleTextColor = color;
        this.invalidate();
    }

    private void setSelectTextColor(int color) {
        this.mSelectTextColor = color;
        this.invalidate();
    }

    public void setmScaleMaxLength(int mScaleMaxLength) {
        this.mScaleMaxLength = mScaleMaxLength;
        this.invalidate();
    }

    public void setShape2Arc(boolean isArc) {
        this.isArc = isArc;
        this.invalidate();
    }

    public interface SelectScaleListener {
        void selectScale(int var1);
    }
}
