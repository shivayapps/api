package gallery.gallerylock.vaultgallery.hidepictures.activities

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.adapter.DirsAdapter
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityDirsBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.filepicker.model.DialogConfigs
import gallery.gallerylock.vaultgallery.hidepictures.filepicker.model.DialogProperties
import gallery.gallerylock.vaultgallery.hidepictures.filepicker.view.FilePickerDialog
import gallery.gallerylock.vaultgallery.hidepictures.utils.AdCache
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences


class DirsActivity : BaseActivity() {

    var dirType = Constant.TYPE_EXCLUDED
    lateinit var preferences: Preferences
    lateinit var adapter: DirsAdapter

    lateinit var binding: ActivityDirsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if(preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityDirsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()

        initView()
    }

    private fun initView() {

        if (intent.hasExtra("dirType")) {
            dirType = intent.getStringExtra("dirType") ?: Constant.TYPE_EXCLUDED
        }

        when (dirType) {
            Constant.TYPE_EXCLUDED -> {
                binding.txtTitle.text = getString(R.string.exclude_folders)
            }

            else -> {
                binding.txtTitle.text = getString(R.string.include_folders)
            }
        }

        getData()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }

        intListener()
    }

    var isAdLoaded = false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {

        if (!isAdLoaded) {
            val isFirstSession = preferences.splashCounter == 1
            val adId = getString(R.string.b_dirsActivity)
            BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd, binding.llAdPlace, adId,
                AdCache.dirsAdView,
                { isLoaded,adView, message ->
                    mAdView=adView
                    AdCache.dirsAdView=adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
//            onBackPressedDispatcher.onBackPressed()
        }
        binding.icAdd.setOnClickListener {
            pickFolder()
        }
    }

    override fun onBackPressed() {
        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this@DirsActivity) {
                if (it) preferences.isNeedInterAd = false
                setResult(Activity.RESULT_OK)
                finish()
            }
        } else {
            setResult(Activity.RESULT_OK)
            finish()
//            super.onBackPressed()
        }
//        super.onBackPressed()
//        onBackPressedDispatcher.onBackPressed()
    }

    private fun pickFolder() {
        val title = getString(R.string.folder_title)
        val properties = DialogProperties(true)
        properties.selectionType = DialogConfigs.DIR_SELECT
        properties.selectionMode = DialogConfigs.MULTI_MODE

        val dialog = FilePickerDialog(this@DirsActivity, properties)
        dialog.setTitle(title)
        dialog.setDialogSelectionListener { files ->
            addDirList(files)
            getData()
        }
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    private fun pickFile() {

        val title = getString(R.string.file_title)
        val extensions = arrayOf(".gif", ".jpeg", ".jpg", ".png")
        val properties = DialogProperties(true)
        properties.extensions = extensions
        properties.selectionMode = DialogConfigs.MULTI_MODE
        val dialog = FilePickerDialog(this@DirsActivity, properties)
        dialog.setTitle(title)
        dialog.setDialogSelectionListener {
            ////                String filePath = files[0];
            //                val filePath = StringBuilder()
            //                for (path in files) {
            //                    filePath.append("\n").append(path)
            //                }
            ////                tvFile.setText(filePath.toString())
        }
        dialog.show()
    }

    var dirList = ArrayList<String>()
    private fun getData() {
        preferences.refreshMedia = true
        binding.swipeRefreshLayout.isRefreshing = true
        dirList = when (dirType) {
            Constant.TYPE_EXCLUDED -> preferences.getExcludeList()
            else -> preferences.getIncludeList()
        }

        binding.swipeRefreshLayout.isRefreshing = false
        adapter = DirsAdapter(this@DirsActivity,
            dirList,
            clickListener = {
                removeDirList(dirList[it])
                adapter.notifyItemRemoved(it)
                getData()
            })
        binding.recyclerView.adapter = adapter
        setEmptyData()

    }

    private fun setEmptyData() {
        if (dirList.size != 0) {
            binding.recyclerView.visibility = View.VISIBLE
//            binding.loutToolbar.icMenu.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.llBottom.beVisible()
        } else {
            binding.recyclerView.visibility = View.GONE
//            binding.loutToolbar.icMenu.visibility = View.INVISIBLE
            binding.loutNoData.visibility = View.VISIBLE
            binding.llBottom.beGone()
        }

    }

    private fun addDirList(filePath: Array<String>) {
//        val dirList: ArrayList<String> = ArrayList()

        dirList.clear()
        dirList.addAll(
            when (dirType) {
                Constant.TYPE_EXCLUDED -> preferences.getExcludeList()
                else -> preferences.getIncludeList()
            }
        )

        for (path in filePath) {
            dirList.add(path)

            if (!dirList.contains(path)) {
                dirList.add(0, path)
            }
        }

        preferences.refreshMedia = true
        when (dirType) {
            Constant.TYPE_EXCLUDED -> preferences.setExcludeList(dirList)
            else -> preferences.setIncludeList(dirList)
        }
        setEmptyData()
//        EventBus.getDefault().post(UpdateFavoriteEvent(path, true))

    }

    private fun removeDirList(filePath: String) {
//        val dirList: ArrayList<String> = ArrayList()
        dirList.clear()
        dirList.addAll(
            when (dirType) {
                Constant.TYPE_EXCLUDED -> preferences.getExcludeList()
                else -> preferences.getIncludeList()
            }
        )

        dirList.remove(filePath)
        when (dirType) {
            Constant.TYPE_EXCLUDED -> preferences.setExcludeList(dirList)
            else -> preferences.setIncludeList(dirList)
        }
        setEmptyData()

    }

}