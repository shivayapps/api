package gallery.gallerylock.vaultgallery.hidepictures.edit.model

enum class FilterName {
    BRIGHTNESS,
    CONTRAST,
    SATURATION,
    SHARPEN,
    VIGNETTE
}