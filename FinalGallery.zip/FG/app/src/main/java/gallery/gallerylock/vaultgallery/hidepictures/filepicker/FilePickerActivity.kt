package gallery.gallerylock.vaultgallery.hidepictures.filepicker

import android.app.Activity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import gallery.gallerylock.vaultgallery.hidepictures.adapter.DirsAdapter
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityFilePickerBinding
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences


class FilePickerActivity : BaseActivity() {

    lateinit var preferences: Preferences
    lateinit var adapter: DirsAdapter

    lateinit var binding: ActivityFilePickerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilePickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initView()
    }

    private fun initView() {
        preferences = Preferences(this)

        getData()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }

        intListener()
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
//            onBackPressedDispatcher.onBackPressed()
        }

    }

    override fun onBackPressed() {
//        super.onBackPressed()
//        onBackPressedDispatcher.onBackPressed()
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun getData() {



    }

}