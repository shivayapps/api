package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
//import com.example.mycallstate.preferences.PrefCalls
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogHomeMenuBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisible
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisibleIf
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences

class HomeMenuDialog(var currentFragment: Int, val clickListener: (type: Int) -> Unit) :
    BottomSheetDialogFragment() {

    lateinit var binding: DialogHomeMenuBinding
    lateinit var preferences: Preferences
//    lateinit var adsPref: PrefCalls
    var isShowGrid = false
    var gridCount = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogHomeMenuBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())
//        adsPref = PrefCalls(requireActivity())
        isShowGrid = preferences.getShowGrid()
        gridCount = preferences.getGridCount()
        selectedGrid = gridCount

        if(currentFragment==0) {
            binding.btnCreateAlbum.beVisible()
            binding.btnGroup.beGone()

            binding.llMainOperation.beVisible()
        } else if(currentFragment==1) {
            binding.btnCreateAlbum.beGone()

            binding.llMainOperation.beVisible()
        } else if(currentFragment==2) {

            binding.llMainOperation.beGone()
        }
//        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)

//        binding.btnCreateAlbum.visibility = if (isShowAlbumTab) View.VISIBLE else View.GONE
//        binding.btnGroup.visibility = if (isShowAlbumTab) View.GONE else View.VISIBLE


//        binding.btnChangeViewType.visibility =  if (isShowAlbumTab) View.VISIBLE else View.GONE

        intListener()
        setView()
        setColumnView()

    }

    var selectedGrid = -1
    private fun intListener() {
        binding.btnSortBy.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        binding.btnGroup.setOnClickListener {
            dismiss()
            clickListener(9)
        }
        binding.btnFilterMedia.setOnClickListener {
            dismiss()
            clickListener(2)
        }
//        binding.btnChangeViewType.setOnClickListener {
//            dismiss()
//            clickListener(2)
//        }
        binding.btnList.setOnClickListener {
            if (isShowGrid) {
                isShowGrid = false
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener()
                clickListener(21)
                dismiss()
            } else dismiss()
        }
        binding.btnGrid.setOnClickListener {
            if (!isShowGrid) {
                isShowGrid = true
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener()
                clickListener(22)
                dismiss()
            } else dismiss()
        }

        binding.btnCreateAlbum.setOnClickListener {
            dismiss()
            clickListener(3)
        }
        binding.btnDisplayedColumns.setOnClickListener {
            dismiss()
            clickListener(4)
        }

        binding.btnRecycleBin.setOnClickListener {
            dismiss()
            clickListener(5)
        }
        binding.btnPrivateMedia.setOnClickListener {
            dismiss()
            clickListener(10)
        }
        binding.btnFamilyApps.setOnClickListener {
            dismiss()
            clickListener(6)
        }
        binding.btnFeedback.setOnClickListener {
//            val intent = Intent(activity, FeedbackActivity::class.java)
//            startActivity(intent)
            dismiss()
            clickListener(7)
        }
        binding.btnSetting.setOnClickListener {
            dismiss()
            clickListener(8)
        }
    }

    private fun setView() {
        if (currentFragment==0) {
            if (isShowGrid) {
                binding.btnGrid.visibility = View.GONE
                binding.btnList.visibility = View.VISIBLE
                binding.btnDisplayedColumns.visibility = View.GONE
            } else {
                binding.btnGrid.visibility = View.VISIBLE
                binding.btnList.visibility = View.GONE
                binding.btnDisplayedColumns.visibility = View.GONE
            }
        } else {
            binding.btnGrid.visibility = View.GONE
            binding.btnList.visibility = View.GONE
        }
    }

    private fun setColumnView() {
        when (selectedGrid) {
        }
    }


    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}