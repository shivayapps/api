package gallery.gallerylock.vaultgallery.hidepictures.edit.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ItemColorBinding

class ColorAdapter(
    var context: Context,
    val clickListener: (color: Int) -> Unit
) :
    RecyclerView.Adapter<ColorAdapter.ViewHolder>() {
    var colorList: List<Int> = getDefaultColors()
    var selectPos = 0

    fun getDefaultColors(): List<Int> {
        val colorPickerColors = java.util.ArrayList<Int>()
        colorPickerColors.add(ContextCompat.getColor((context), R.color.white_color))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.black_color))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_1))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_2))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_3))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_4))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_5))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_6))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_7))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_8))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_9))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_10))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_11))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_12))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_13))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_14))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_15))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_16))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_17))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_18))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_19))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_20))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_21))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_22))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_23))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_24))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_25))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_26))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_27))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_28))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_29))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_30))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_31))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_32))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_33))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_34))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_35))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_36))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_37))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_38))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_39))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_40))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_41))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_42))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_43))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_44))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_45))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_46))
        colorPickerColors.add(ContextCompat.getColor((context), R.color.color_picker_47))

        return colorPickerColors
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemColorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return colorList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.binding.viewSelect.visibility =
            if (selectPos == position) View.VISIBLE else View.GONE

        holder.binding.cardView.setBackgroundColor(colorList[position])
        holder.binding.viewStroke.visibility =
            if (position == 0 || position == 1) View.VISIBLE else View.GONE

        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            clickListener(colorList[position])
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemColorBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}