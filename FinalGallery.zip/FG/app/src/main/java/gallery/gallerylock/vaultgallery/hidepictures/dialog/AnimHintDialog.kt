package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogAnimHintBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisibleIf

class AnimHintDialog(
    var title: String,
    var resId: Int,
    val updateListener: (btnClicked:Int,isDontShowChecked:Boolean) -> Unit,
    var showCheckbox: Boolean?=true,
) : DialogFragment() {

    override fun onResume() {
        super.onResume()
        dialog!!.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        val window = dialog.window
        val attributes = window?.attributes
//        attributes?.gravity = Gravity.BOTTOM
        window?.attributes = attributes
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return dialog
    }

    lateinit var bindingDialog: DialogAnimHintBinding
    var isDontShowChecked: Boolean=false
//    var preferences: Preferences = Preferences(mContext)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogAnimHintBinding.inflate(layoutInflater, container, false)
        intView()
        intListener()
        return bindingDialog.root
    }


    private fun intView() {
        bindingDialog.tvtitle.text=title
        bindingDialog.ivHint.setImageResource(resId)
        bindingDialog.cbCheck.beVisibleIf(showCheckbox!!)
    }

    private fun intListener() {
        bindingDialog.cbCheck.setOnCheckedChangeListener { buttonView, isChecked ->
            this.isDontShowChecked=isChecked
        }

        bindingDialog.btnCancel.setOnClickListener {
            updateListener.invoke(0,isDontShowChecked)
            dismiss()
        }

        bindingDialog.btnPositive.setOnClickListener {
            updateListener.invoke(1,isDontShowChecked)
            dismiss()
        }
    }


//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

