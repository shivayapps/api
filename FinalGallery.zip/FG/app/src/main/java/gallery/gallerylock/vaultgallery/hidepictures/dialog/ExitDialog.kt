package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.material.bottomsheet.BottomSheetDialog
//import com.example.customview.AppOpenManager
//import com.example.customview.adconfig.NativeAdHelper.mMainNative
//import com.example.customview.adconfig.NativeAdHelper.showMainNativeAd
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogExitBinding

class ExitDialog(
    val mNativeAd: NativeAd?,
//    val bottomSheetListener: BottomSheetDismissListener
    val clickListener: (isExit: Boolean) -> Unit
) : BottomSheetDialogFragment() {

    lateinit var binding: DialogExitBinding
    lateinit var mAdmobNative: AdmobNative
    var isExitDialogOpen=false


//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//        dialog?.setOnKeyListener { _, keyCode, event ->
//            Log.e("ExitDialog", "keyCode:$keyCode, event:${event.action}")
//            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
//                bottomSheetListener.onClickListener(true)
////                dialog?.onBackPressed()
//                true
//            } else {
//                false
//            }
//        }
//    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = DialogExitBinding.inflate(layoutInflater)
        AdsConfig.isSystemDialogOpen=true
        binding.btnExit.setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }
        isExitDialogOpen=true
        loadNativeAd()
        return binding.root
    }


    override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
        Handler(Looper.getMainLooper()).postDelayed({
            isExitDialogOpen=false
        },500)
    }
    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        Handler(Looper.getMainLooper()).postDelayed({
            isExitDialogOpen=false
        },500)
    }

    private fun loadNativeAd() {
        mAdmobNative=AdmobNative()
        mAdmobNative.showNativeAd(requireActivity(),binding.nativeTemplate,mNativeAd,getString(R.string.native_exit))
//        NativeAdHelper(requireActivity(), binding.nativeTemplate, NativeLayoutType.NativeBig).loadAd();
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}