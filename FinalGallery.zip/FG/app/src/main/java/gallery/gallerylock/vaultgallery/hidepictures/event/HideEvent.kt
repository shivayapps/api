package gallery.gallerylock.vaultgallery.hidepictures.event

data class HideEvent(var isUpdate: Boolean = false)
