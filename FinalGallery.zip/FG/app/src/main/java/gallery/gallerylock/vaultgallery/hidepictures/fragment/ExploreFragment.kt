package gallery.gallerylock.vaultgallery.hidepictures.fragment

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import gallery.gallerylock.vaultgallery.hidepictures.GalleryApp
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.FeedbackActivity
import gallery.gallerylock.vaultgallery.hidepictures.activities.HomeActivity
import gallery.gallerylock.vaultgallery.hidepictures.activities.RecentlyDeleteActivity
import gallery.gallerylock.vaultgallery.hidepictures.recover.RecoverMediaActivity

import gallery.gallerylock.vaultgallery.hidepictures.activities.exploremap.MapExploreActivity
import gallery.gallerylock.vaultgallery.hidepictures.database.AppDatabase
import gallery.gallerylock.vaultgallery.hidepictures.database.LocationEntity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.FragmentExploreBinding
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGoneIf
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisibleIf
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.model.PlaceData
import gallery.gallerylock.vaultgallery.hidepictures.secret.activity.LockActivity
import gallery.gallerylock.vaultgallery.hidepictures.secret.activity.PrivateActivity
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.io.IOException
import java.util.Locale


class ExploreFragment : Fragment() {

    private var googleMap: GoogleMap? = null
    var dataBase: AppDatabase?=null
    var preferences: Preferences?=null
    var mActivity: Activity?=null

    var isMarkerAdded = false
    var isMapLoaded = false
    var albumList: ArrayList<PlaceData> = ArrayList()

    lateinit var binding: FragmentExploreBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentExploreBinding.inflate(layoutInflater, container, false)
        if (isAdded && !isDetached) {
            initView()

            binding?.map!!.onCreate(savedInstanceState)

            binding?.map!!.getMapAsync { map ->
//                map.uiSettings.setAllGesturesEnabled(false)
                isMapLoaded=true
                googleMap = map
//            googleMap?.isMyLocationEnabled = true
                googleMap?.setOnMarkerClickListener { marker ->
                    val intent=Intent(mActivity, MapExploreActivity::class.java)
                    intent.putExtra("pos",0)
                    startActivity(intent)
                    true
                }
            }
        }
        return binding?.root!!
    }


    @SuppressLint("CheckResult")
    private fun initData() {

        dataBase?.dataDao()!!.getLocationLiveEntityList()
            .observe(requireActivity()) { places: List<LocationEntity> ->
                sortImage(places)
            }

        Observable.fromCallable {
            getAllImagesFromGallery()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                Log.e("XXPermissions", "getAllImagesFromGallery:::getImageOnMap.001")
            }
            .subscribe { _: Boolean? ->
                Log.e("XXPermissions", "getAllImagesFromGallery:::getImageOnMap.002")
            }
    }

    private fun mapPlaces() {
//        if (albumList.isNotEmpty()) {
//
//            if(albumList.size>0) {
//                Glide.with(mActivity?.applicationContext!!)
//                    .load(albumList[0].pictureData[0].filePath)
//                    .placeholder(R.drawable.ic_image_placeholder)
//                    .into(binding?.image1!!)
//            }
//
//            if(albumList.size>1) {
//                Glide.with(mActivity?.applicationContext!!)
//                    .load(albumList[1].pictureData[0].filePath)
//                    .placeholder(R.drawable.ic_image_placeholder)
//                    .into(binding?.image2!!)
//            }
//
//            if(albumList.size>2) {
//                Glide.with(mActivity?.applicationContext!!)
//                    .load(albumList[2].pictureData[0].filePath)
//                    .placeholder(R.drawable.ic_image_placeholder)
//                    .into(binding?.image3!!)
//            }
//            if(albumList.size>3) {
//                Glide.with(mActivity?.applicationContext!!)
//                    .load(albumList[3].pictureData[0].filePath)
//                    .placeholder(R.drawable.ic_image_placeholder)
//                    .into(binding?.image4!!)
//            }
//
//        }

    }

    private fun initView() {
        if(isAdded) {

            if(mActivity==null) mActivity = requireActivity() as HomeActivity
            preferences = GalleryApp.preferences
            dataBase = AppDatabase.getInstance(mActivity!!)

            initData()

            binding?.mapFull!!.setOnClickListener {
                val intent=Intent(mActivity, MapExploreActivity::class.java)
                intent.putExtra("pos",0)
                startActivity(intent)
//            startActivity(Intent(activity, MapActivity::class.java))
            }
//            binding?.cardPeople!!.setOnClickListener {
//
//                val intent=Intent(mActivity, MapExploreActivity::class.java)
//                intent.putExtra("pos",1)
//                startActivity(intent)
//            }

            binding?.llHidden!!.setOnClickListener {
                val intent=Intent(mActivity, LockActivity::class.java)

                lockActivityResultLauncher.launch(intent)
            }


            binding?.llRecover!!.setOnClickListener {
                val intent=Intent(mActivity, RecoverMediaActivity::class.java)
                startActivity(intent)
//            MailUtil.sendEmail("snb.developer1@gmail.com","testing_subject","testing body message")
            }

            binding?.llRecycle!!.setOnClickListener {
                startActivity(Intent(mActivity, RecentlyDeleteActivity::class.java))
            }
            binding?.mCVSuggestion!!.setOnClickListener {
                startActivity(Intent(mActivity, FeedbackActivity::class.java))
            }
        }
    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val intent=Intent(mActivity, PrivateActivity::class.java)
//            startActivity(intent)
            privateActivityResultLauncher.launch(intent)
        }
    }
    var privateActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
//        if (result.resultCode == AppCompatActivity.RESULT_OK) {
//            val intent=Intent(mActivity, PrivateActivity::class.java)
//            startActivity(intent)

            Constant.isReCreateHomeSS = true
            val intent = mActivity?.intent
            mActivity?.finish()
            mActivity?.overridePendingTransition(0, 0)
            startActivity(intent!!)
            mActivity?.overridePendingTransition(0, 0)
            Constant.isChangeLanguage = false
//        }
    }

    override fun onResume() {
        super.onResume()
        binding?.map!!.onResume()
        binding?.llHidden!!.beGoneIf(preferences?.hideVault!!)

        val countRecycle = dataBase!!.dataDao().getCountDelete()
        binding?.txtRecycleCount!!.text="$countRecycle"
    }

    override fun onStart() {
        super.onStart()
//        handler.post(showInfo)
    }

    override fun onStop() {
        super.onStop()
//        handler.removeCallbacks(showInfo)
    }

    override fun onDestroy() {
        super.onDestroy()
        binding?.map!!.onDestroy()
//        handler.removeCallbacks(showInfo)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        binding?.map!!.onLowMemory()
    }

    public fun getImageOnMap() {
        Log.e("XXPermissions", "getImageOnMap:::albumWisePictures:${albumList.size}")
        if(isMapLoaded) {

            if (albumList != null && albumList.size > 0 && !isMarkerAdded) {
                albumList.take(1).forEach { album ->
                    addMarker(album)
                }

                val lat = albumList[0].lati.toDouble()
                val lng = albumList[0].long.toDouble()

                if (lat != null && lng != null) {
                    val location = LatLng(lat, lng)
                    googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(location,7f));
                }
            }
        }
    }

    public fun sortImage(placeList: List<LocationEntity>) {
        Log.e("XXPermissions", "sortImage:::placeList.${placeList.size}")
//        binding?.llPlaces!!.beVisibleIf(placeList.size>0)

        placeList.forEach { data ->

            val strKey = data.title

            var imagesData1: ArrayList<PictureData> = ArrayList()

            val file = File(data.path)
            if(file.exists()) {
                val pictureData = PictureData(
                    file.path,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in albumList.indices) {
                    if (albumList[i].place == strKey) {
                        albumList[i].pictureData.add(pictureData)
                    }
                }

                if (albumList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(pictureData)
                    val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    albumList.add(placeData)
                }
            }
            else {
                dataBase?.dataDao()!!.deleteLocationEntity(data)
            }

        }

        mapPlaces()
    }

    private fun addMarker(album: PlaceData) {
        isMarkerAdded = true
        val lat = album.lati.toDouble()
        val lng = album.long.toDouble()
        if (lat != null && lng != null) {
            val location = LatLng(lat, lng)

            Log.e("XXPermissions", "getImageOnMap:::addMarker==>lat:${lat}, lng:${lng}")

            val marker = googleMap?.addMarker(
                MarkerOptions()
                    .position(location)
                    .anchor(0.5f,0.5f)
                    .icon(
                        BitmapDescriptorFactory.fromBitmap(
                            getMarkerBitmapFromView(album.pictureData.firstOrNull()!!.filePath,album.pictureData.size)
                        )
                    )
            )

            marker?.tag = album.place
        }
    }


    private fun getMarkerBitmapFromView(photoPath: String,size:Int): Bitmap {
        val customMarkerView: View =
            (requireContext().getSystemService(AppCompatActivity.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.custom_marker,
                null
            )
        val markerImageView = customMarkerView.findViewById<View>(R.id.profile_image) as ImageView
        val markerCounter = customMarkerView.findViewById<View>(R.id.txtCount) as TextView
        markerCounter.text="$size"

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
//        val bitmap = BitmapFactory.decodeFile(photoPath)
        markerImageView.setImageBitmap(bitmap)

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        customMarkerView.layout(
            0,
            0,
            customMarkerView.measuredWidth,
            customMarkerView.measuredHeight
        )
        //customMarkerView.buildDrawingCache()
        val returnedBitmap = Bitmap.createBitmap(
            customMarkerView.measuredWidth, customMarkerView.measuredHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = customMarkerView.background
        drawable?.draw(canvas)
        customMarkerView.draw(canvas)
        return returnedBitmap
    }

    private fun getAllImagesFromGallery() {
        Log.e("XXPermissions", "getAllImagesFromGallery")
//        val projection = arrayOf(
//            MediaStore.Images.Media._ID,
//            MediaStore.Images.Media.DATA,
//            MediaStore.MediaColumns.TITLE,
//            MediaStore.Images.Media.SIZE
//        )
        val projection = arrayOf(
            MediaStore.Images.Media.DATA,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
        )

        val orderBy = MediaStore.MediaColumns.DATE_MODIFIED
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val cursor: Cursor = requireContext().contentResolver.query(
            uri,
            projection,
            null,
            null,
            "$orderBy DESC"
        )!!

        val pathIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        albumList.clear()

        while (cursor.moveToNext()) {
            val filePath = cursor.getString(pathIndex)
            var latLong = FloatArray(2)

            val entity = dataBase?.dataDao()!!.getLocationEntity(filePath)

            if (entity == null) {
                try {
//                    val inputStream: InputStream = requireContext().contentResolver.openInputStream(photoUri) ?: continue
                    val exifInterface = ExifInterface(filePath)
                    exifInterface.getLatLong(latLong)
                    Log.e("XXPermissions", "getLatLong:${latLong[0]},${latLong[0]}")
//                    inputStream.close()
                } catch (e: IOException) {
                    Log.e("XXPermissions", "IOException:$e")
                } catch (e: UnsupportedOperationException) {
                    Log.e("XXPermissions", "UnsupportedOperationException:$e")
                }

                if (latLong[0] != 0f && latLong[1] != 0f) {

                var latLongToAddressString = ""
                    latLongToAddressString = latLongToAddressString(
                        latLong[0],
                        latLong[1]
                    )

                    dataBase?.dataDao()?.insertLocationEntity(
                        LocationEntity(
                            0,
                            latLongToAddressString,
                            filePath,
                            latLong[0],
                            latLong[1]
                        )
                    )
                    Log.i(
                        "XXPermissions", "004.latLongToAddressString：" + latLongToAddressString
                    )
                }
            }
        }
        cursor.close()
    }

    private fun latLongToAddressString(latitude: Float, longitude: Float): String {
        var addressString = ""
        if(isAdded){
            val geocoder = Geocoder(mActivity!!, Locale.getDefault())
            try {
                val addresses: List<Address>? =
                    geocoder.getFromLocation(latitude.toDouble(), longitude.toDouble(), 1)
                if (addresses != null) {
                    val returnedAddress: Address = addresses[0]
                    val strReturnedAddress = StringBuilder("")

                    Log.w(
                        "XXPermissions",
                        "addressline:::==================================================="
                    )
                    Log.w("XXPermissions", "addressline:::adminArea==>:${returnedAddress.adminArea}")
                    Log.w(
                        "XXPermissions",
                        "addressline:::featureName==>:${returnedAddress.featureName}"
                    )
                    Log.w("XXPermissions", "addressline:::locality==>:${returnedAddress.locality}")
                    Log.w(
                        "XXPermissions",
                        "addressline:::subLocality==>:${returnedAddress.subLocality}"
                    )
                    Log.w(
                        "XXPermissions",
                        "addressline:::countryName==>:${returnedAddress.countryName}"
                    )
                    Log.w(
                        "XXPermissions",
                        "addressline:::subAdminArea==>:${returnedAddress.subAdminArea}"
                    )
                    Log.w("XXPermissions", "addressline:::premises==>:${returnedAddress.premises}")


//                for (i in 0..returnedAddress.maxAddressLineIndex) {
//                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n")
//                }

                    if (returnedAddress.subLocality != null) {
                        strReturnedAddress.append(returnedAddress.subLocality)
                    } else if (returnedAddress.locality != null) {
                        strReturnedAddress.append(returnedAddress.locality)
                    }

                    addressString = strReturnedAddress.toString()
                }
            } catch (e: Exception) {
                Log.e("printStackTrace","printStackTrace:$e")
            }
        }
        return addressString
    }
}