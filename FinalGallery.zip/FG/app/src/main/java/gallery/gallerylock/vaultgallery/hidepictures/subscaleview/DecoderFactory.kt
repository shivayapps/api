package gallery.gallerylock.vaultgallery.hidepictures.subscaleview

interface DecoderFactory<T> {
    fun make(): T
}
