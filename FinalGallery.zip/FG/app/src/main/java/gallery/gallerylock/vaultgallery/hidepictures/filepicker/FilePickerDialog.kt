package gallery.gallerylock.vaultgallery.hidepictures.filepicker

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogFilePickerBinding
import gallery.gallerylock.vaultgallery.hidepictures.filepicker.controller.DialogSelectionListener
import gallery.gallerylock.vaultgallery.hidepictures.filepicker.model.DialogProperties
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences

class FilePickerDialog(
    val properties: DialogProperties,
    val callbacks: () -> DialogSelectionListener
) :
    DialogFragment() {

    lateinit var bindingDialog: DialogFilePickerBinding
    lateinit var preferences: Preferences

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setStyle(STYLE_NORMAL, R.style.FullScreenDialog)
//    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogFilePickerBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        preferences = Preferences(requireActivity())

        intListener()



    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
    }

}