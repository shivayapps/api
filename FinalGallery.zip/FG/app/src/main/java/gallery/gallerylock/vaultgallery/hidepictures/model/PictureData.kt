package gallery.gallerylock.vaultgallery.hidepictures.model

import android.os.Parcel
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey

//@Entity(tableName = "pictureData")
data class PictureData(
    var filePath: String,
    var fileName: String,
    var folderName: String= "",
    var date: Long,
    var dateTaken: Long,
    var fileSize: Long,
    var isVideo: Boolean = false,
    var videoDuration: Long = 0,
    var bucketPath: String = "",
    var isSelected: Boolean = false,
    var isCheckboxVisible: Boolean = false,
    var isFavorite: Boolean = false,
    var isPrivate: Boolean = false,
    var restorePath: String = "",
    @PrimaryKey(autoGenerate = true)
    var idDataBase: Long = 0L
):Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readLong(),
        parcel.readLong(),
        parcel.readLong(),
        parcel.readByte() != 0.toByte(),
        parcel.readLong(),
        parcel.readString()!!,
        parcel.readByte() != 0.toByte(),
        parcel.readByte() != 0.toByte(),
        parcel.readByte() != 0.toByte(),
        parcel.readByte() != 0.toByte(),
        parcel.readString()!!,
        parcel.readLong()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(filePath)
        parcel.writeString(fileName)
        parcel.writeString(folderName)
        parcel.writeLong(date)
        parcel.writeLong(dateTaken)
        parcel.writeLong(fileSize)
        parcel.writeByte(if (isVideo) 1 else 0)
        parcel.writeLong(videoDuration)
        parcel.writeString(bucketPath)
        parcel.writeByte(if (isSelected) 1 else 0)
        parcel.writeByte(if (isCheckboxVisible) 1 else 0)
        parcel.writeByte(if (isFavorite) 1 else 0)
        parcel.writeByte(if (isPrivate) 1 else 0)
        parcel.writeString(restorePath)
        parcel.writeLong(idDataBase)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<PictureData> {
        override fun createFromParcel(parcel: Parcel): PictureData {
            return PictureData(parcel)
        }

        override fun newArray(size: Int): Array<PictureData?> {
            return arrayOfNulls(size)
        }
    }
}