package gallery.gallerylock.vaultgallery.hidepictures.edit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.base.BaseActivity
import gallery.gallerylock.vaultgallery.hidepictures.databinding.ActivityCropBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ProgressDialog
import gallery.gallerylock.vaultgallery.hidepictures.edit.adapter.CropOptionAdapter
import gallery.gallerylock.vaultgallery.hidepictures.edit.model.EditData
import gallery.gallerylock.vaultgallery.hidepictures.extension.updateStatusBarColor
import gallery.gallerylock.vaultgallery.hidepictures.utils.AdCache
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences


import java.io.File


class CropActivity : BaseActivity() {

    lateinit var binding: ActivityCropBinding
    var imagePath = ""
    var saveImageName = ""
    lateinit var adapter: CropOptionAdapter
    var optionList: ArrayList<EditData> = ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCropBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateStatusBarColor(Color.parseColor("#131624"))

        intView()
        loadBanner()
    }

    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBanner() {
//        val isFirstSession= Preferences(this).splashCounter==1
//        val adId=getString(R.string.b_editActivity)
//        BannerAdHelper.showBanner(this, binding.layoutBanner.mFLAd,binding.llAdPlace,adId,
//            AdCache.editAdView,{ isLoaded, adView, message ->
//                mAdView=adView
//                AdCache.editAdView=adView
//            isAdLoaded=isLoaded
//        })
    }
    private fun intView() {


        imagePath = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_PATH) ?: ""
        saveImageName = intent.getStringExtra(Constant.EXTRA_EDIT_IMAGE_NAME) ?: ""
        binding.txtTitle.text = getString(R.string.Crop)
        intListener()

        val imageUri = FileProvider.getUriForFile(
            this, "$packageName.provider",
            File(imagePath)
        )
        binding.cropView.setFixedAspectRatio(false)
        binding.cropView.setImageUriAsync(imageUri)

        setAdapter()
    }

    private fun setAdapter() {
        getOptionList()
        adapter = CropOptionAdapter(this, optionList, clickListener = {
            setOption(it)

        })
        binding.recyclerView.adapter = adapter
    }


    private fun intListener() {
        binding.icBack.setOnClickListener { onBackPressed() }
        binding.ivDone.setOnClickListener {
//            binding.cropView.croppedImageAsync(Bitmap.CompressFormat.PNG)
//            binding.cropView.croppedImageAsync()
            val bitmap = binding.cropView.croppedImage
            croppedSaved(bitmap!!)
        }
        binding.cropView.setOnCropImageCompleteListener { view, result ->
            if (result.error == null && result.bitmap != null) {
                val bitmap = result.bitmap!!
                croppedSaved(bitmap)
            } else
                Toast.makeText(this, getString(R.string.image_editing_failed), Toast.LENGTH_SHORT)
                    .show()
        }
    }

    private fun croppedSaved(bitmap: Bitmap) {
        val progressDialog = ProgressDialog(
            this@CropActivity,
            0,
            0,
            getString(R.string.saving),
            ""
        )
        progressDialog.show(supportFragmentManager, progressDialog.tag)
        Thread {
            val imagePath = saveEditImage(bitmap, saveImageName)
            runOnUiThread {
                if (imagePath != null) {
                    val intent = Intent()
                    intent.putExtra(Constant.EXTRA_EDIT_SAVE_IMAGE, imagePath)
                    setResult(RESULT_OK, intent)

                }
                progressDialog.dismiss()
                finish()
            }
        }.start()

    }

    private fun setOption(pos: Int) {
        when (optionList[pos].name) {
            getString(R.string.Rotate) -> {
                binding.cropView.rotateImage(90)
            }

            getString(R.string.Horizontal) -> {
                binding.cropView.flipImageHorizontally()
            }

            getString(R.string.Vertical) -> {
                binding.cropView.flipImageVertically()
            }

            getString(R.string.None) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_FREE)
            }

            getString(R.string.Center) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_CENTER)
            }

            getString(R.string.crop_1_1) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_1_1)
            }

            getString(R.string.crop_3_4) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_3_4)
            }

            getString(R.string.crop_4_3) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_4_3)
            }

            getString(R.string.crop_9_16) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_9_16)
            }

            getString(R.string.crop_2_3) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_2_3)
            }

            getString(R.string.crop_3_2) -> {
                updateAspectRatio(Constant.ASPECT_RATIO_3_2)
            }
        }
    }

    private fun updateAspectRatio(aspectRatio: Int) {
        binding.cropView.apply {
            when (aspectRatio) {
                Constant.ASPECT_RATIO_FREE -> {
                    setFixedAspectRatio(false)
                }

                Constant.ASPECT_RATIO_CENTER -> {
                    setFixedAspectRatio(false)
                    setCenterMoveEnabled(true)
                }

                else -> {
                    val newAspectRatio = when (aspectRatio) {
                        Constant.ASPECT_RATIO_1_1 -> Pair(1f, 1f)
                        Constant.ASPECT_RATIO_3_4 -> Pair(3f, 4f)
                        Constant.ASPECT_RATIO_4_3 -> Pair(4f, 3f)
                        Constant.ASPECT_RATIO_9_16 -> Pair(9f, 16f)
                        Constant.ASPECT_RATIO_2_3 -> Pair(2f, 3f)
                        Constant.ASPECT_RATIO_3_2 -> Pair(3f, 2f)
                        else -> Pair(1f, 1f)
                    }
                    setAspectRatio(newAspectRatio.first.toInt(), newAspectRatio.second.toInt())
                }
            }
        }

    }


    private fun getOptionList() {
        optionList.add(
            EditData(
                getString(R.string.Horizontal),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_horizontal),
                false
            )
        )
        optionList.add(
            EditData(
                getString(R.string.Vertical),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_vertical),
                false
            )
        )
        optionList.add(
            EditData(
                getString(R.string.Rotate),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_rotate),
                false
            )
        )
        optionList.add(
            EditData(
                getString(R.string.None),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_none)
            )
        )

        optionList.add(
            EditData(
                getString(R.string.crop_1_1),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_1_1)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.crop_3_4),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_3_4)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.crop_4_3),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_4_3)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.crop_9_16),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_9_16)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.crop_2_3),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_2_3)
            )
        )
        optionList.add(
            EditData(
                getString(R.string.crop_3_2),
                ContextCompat.getDrawable(this, R.drawable.ic_crop_3_2)
            )
        )
    }
}