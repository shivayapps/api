package gallery.gallerylock.vaultgallery.hidepictures.fragment

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.format.DateFormat
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.doOnPreDraw
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import gallery.gallerylock.vaultgallery.hidepictures.BuildConfig
import gallery.gallerylock.vaultgallery.hidepictures.GalleryApp
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.activities.HomeActivity
import gallery.gallerylock.vaultgallery.hidepictures.activities.SetWallpaperActivity

import gallery.gallerylock.vaultgallery.hidepictures.adapter.PictureAdapter
import gallery.gallerylock.vaultgallery.hidepictures.customview.MyGridLayoutManager
import gallery.gallerylock.vaultgallery.hidepictures.customview.MyRecyclerView
import gallery.gallerylock.vaultgallery.hidepictures.database.AppDatabase
import gallery.gallerylock.vaultgallery.hidepictures.databinding.FragmentPhotosBinding
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ConfirmationDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.CreateAlbumDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.DeleteDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.DetailsDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ProgressDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.RenameDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.ResizeDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.SelectAlbumFullDialog
import gallery.gallerylock.vaultgallery.hidepictures.dialog.BatchFolderRenameDialog
import gallery.gallerylock.vaultgallery.hidepictures.event.CopyMoveEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.DeleteEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.DisplayDeleteEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.RenameEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.RestoreDataEvent
import gallery.gallerylock.vaultgallery.hidepictures.event.UpdateFavoriteEvent
import gallery.gallerylock.vaultgallery.hidepictures.extension.areDigitsOnly
import gallery.gallerylock.vaultgallery.hidepictures.extension.beGone
import gallery.gallerylock.vaultgallery.hidepictures.extension.beVisibleIf
import gallery.gallerylock.vaultgallery.hidepictures.extension.getFilenameExtension
import gallery.gallerylock.vaultgallery.hidepictures.extension.getFinalUriFromPath
import gallery.gallerylock.vaultgallery.hidepictures.extension.getParentFolder
import gallery.gallerylock.vaultgallery.hidepictures.extension.getUriMimeType
import gallery.gallerylock.vaultgallery.hidepictures.extension.isApng
import gallery.gallerylock.vaultgallery.hidepictures.extension.isGif
import gallery.gallerylock.vaultgallery.hidepictures.extension.isImageFast
import gallery.gallerylock.vaultgallery.hidepictures.extension.isPng
import gallery.gallerylock.vaultgallery.hidepictures.extension.isPortrait
import gallery.gallerylock.vaultgallery.hidepictures.extension.isSvg
import gallery.gallerylock.vaultgallery.hidepictures.extension.isVideoFast
import gallery.gallerylock.vaultgallery.hidepictures.extension.openEditorIntent
import gallery.gallerylock.vaultgallery.hidepictures.extension.openPath
import gallery.gallerylock.vaultgallery.hidepictures.extension.showErrorToast
import gallery.gallerylock.vaultgallery.hidepictures.extension.toast
import gallery.gallerylock.vaultgallery.hidepictures.model.AlbumData
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant

//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_BY_DATE_TAKEN_DAILY
//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_BY_DATE_TAKEN_MONTHLY
//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_BY_EXTENSION
//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_BY_FILE_TYPE
//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_BY_FOLDER
//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_BY_LAST_MODIFIED_DAILY
//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_BY_LAST_MODIFIED_MONTHLY
//import gallery.gallerylock.vaultgallery.hidepictures.utils.Constant.GROUP_SHOW_FILE_COUNT
import gallery.gallerylock.vaultgallery.hidepictures.utils.MAX_COLUMN_COUNT_PICTURE
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_GIFS
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_IMAGES
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_PORTRAITS
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_RAWS
//import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_SVGS
import gallery.gallerylock.vaultgallery.hidepictures.utils.TYPE_VIDEOS
import gallery.gallerylock.vaultgallery.hidepictures.utils.Utils
import gallery.gallerylock.vaultgallery.hidepictures.utils.ensureBackgroundThread
import gallery.gallerylock.vaultgallery.hidepictures.utils.photoExtensions
import gallery.gallerylock.vaultgallery.hidepictures.utils.rawExtensions
import gallery.gallerylock.vaultgallery.hidepictures.utils.videoExtensions
import gallery.gallerylock.vaultgallery.hidepictures.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import vi.imagestopdf.CreatePDFListener
import vi.imagestopdf.PDFEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Collections
import java.util.Locale
import kotlin.math.max
import kotlin.math.min


class PhotosFragment : Fragment() {

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        (mActivity as HomeActivity).longClickListener(isShowSelection, selected, isAllSelect)
    }

    fun selectAlbum() {
        (mActivity as HomeActivity).getAlbumListForSelect()
    }

    var mActivity: AppCompatActivity?=null
    var preferences: Preferences?=null

    var allList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()
    var dummyPictures = ArrayList<Any>()
    var pictureAdapter: PictureAdapter? = null

    private var lastLongPressedItem = -1
    var selectedItem = 0
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null


    var isEmpty=false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    lateinit var binding: FragmentPhotosBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentPhotosBinding.inflate(layoutInflater, container, false)
        if (isAdded && !isDetached) {
            initView()
        }
        return binding.root
    }


    private fun initView() {
        if(isAdded) {

//            if(mActivity==null)
                mActivity = requireActivity() as HomeActivity
//        preferences = Preferences(mActivity!!)
            preferences = GalleryApp.preferences

            setRvLayoutManager()
            getData()
            binding.swipeRefreshLayout.setOnRefreshListener {
                if (binding.swipeRefreshLayout.isEnabled)
                    getData()
                else
                    binding.swipeRefreshLayout.isRefreshing = false
            }
            binding.ivScrollTop.setOnClickListener {
//            binding.pictureRecycler.smoothScrollToPosition(0)
                binding.pictureRecycler.scrollToPosition(0)
                binding.ivScrollTop.beGone()
//            binding.pictureRecycler.smoothScrollBy()
            }
            binding.root.doOnPreDraw {
//            val footerHeight = binding.mCVSuggestion.height
//            binding.pictureRecycler.updatePadding(bottom = footerHeight)

                binding.pictureRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
//                    val range = recyclerView.computeVerticalScrollRange()
//                    val extent = recyclerView.computeVerticalScrollExtent()
//                    val offset = recyclerView.computeVerticalScrollOffset()
//                    val threshHold = range - footerHeight
//                    val currentScroll = extent + offset
//                    val excess = currentScroll - threshHold

                        var firstPositon =
                            (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
//                    var lastPositon =
//                        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findLastVisibleItemPosition()
                        binding.ivScrollTop.beVisibleIf(firstPositon > 3)

//                    if (excess > 0) {
//                        val translationY =
//                            ((-1) * (footerHeight * (excess.toFloat() / footerHeight.toFloat()))) + 150
//                        binding.mCVSuggestion.animate()
//                            .translationY(translationY)
//                            .alpha(1.0f)
//                            .setListener(object : AnimatorListenerAdapter() {
//                                override fun onAnimationEnd(animation: Animator) {
//                                    super.onAnimationEnd(animation)
//                                    binding.mCVSuggestion.beVisible()
//                                }
//                            });
//                    } else {
//                        val translationY =
//                            ((-1) * (footerHeight * (excess.toFloat() / footerHeight.toFloat())) + 150)
//                        binding.mCVSuggestion.animate()
//                            .translationY(translationY)
//                            .alpha(0.0f)
//                            .setListener(object : AnimatorListenerAdapter() {
//                                override fun onAnimationEnd(animation: Animator) {
//                                    super.onAnimationEnd(animation)
//                                    binding.mCVSuggestion.beGone()
//                                }
//                            });
//                    }

//                    binding.mCVSuggestion.translationY = translationY


                    }
                })
            }

//        binding.pictureRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
//            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
//                super.onScrollStateChanged(recyclerView, newState)
//
//                var firstPositon = (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
//                var lastPositon = (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findLastVisibleItemPosition()
//                Log.e("RecyclerViewScrollTag", "firstPositon:$firstPositon, lastPositon:$lastPositon")
//
//                val range = recyclerView.computeVerticalScrollRange()
//                val extent = recyclerView.computeVerticalScrollExtent()
//                val offset = recyclerView.computeVerticalScrollOffset()
//                val threshHold = range - footerHeight
//                val currentScroll = extent + offset
//                val excess = currentScroll - threshHold
//
//                binding.mCVSuggestion.translationY = if (excess > 0) {
//                    ((-1) * (footerHeight * (excess.toFloat() / footerHeight.toFloat()))) + 150
//                } else {
//                    ((-1) * (footerHeight * (excess.toFloat() / footerHeight.toFloat())) + 150)
//                }
//
//                binding.ivScrollTop.beVisibleIf(firstPositon>3)
//
////                when (newState) {
////                    RecyclerView.SCROLL_STATE_IDLE -> {
////                        // The RecyclerView is not currently scrolling
////                        // Add your code to handle this state
////                        Log.e("RecyclerViewScrollTag", "List is not scrolling")
//////                        setSwipeRefreshEnabled(true)
////                        binding.ivScrollTop.beGone()
////                    }
////
////                    RecyclerView.SCROLL_STATE_DRAGGING -> {
////                        // The RecyclerView is currently being dragged by user
////                        // Add your code to handle this state
////                        setSwipeRefreshEnabled(false)
////                        binding.ivScrollTop.beVisible()
////                        Log.e("RecyclerViewScrollTag", "List is scroll")
////                    }
////
////                    RecyclerView.SCROLL_STATE_SETTLING -> {
////                        binding.ivScrollTop.beGone()
////                        // The RecyclerView is currently settling into a final position
////                        // Add your code to handle this state
//////                        setSwipeRefreshEnabled(true)
////                        Log.e("RecyclerViewScrollTag", "List is settling into a final position")
////                    }
////                }
//            }
//        })
        }
    }

    fun setList() {

        try {

//            if(isAdded) {

            binding.swipeRefreshLayout.isEnabled = true
//        binding.swipeRefreshLayout.isRefreshing = true
            dummyPictures.clear()
//        if (isSearch) activity.runOnUiThread { notifyAdapter() }

            val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
//        var format = SimpleDateFormat("dd MMM yyyy")
            var format = SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)

//        val currentGrouping = context.config.getFolderGrouping(pathToCheck)
            val currentGrouping = preferences?.getGroupBy()!!
            val groupOrder = preferences?.getGroupOrderBy()!!

            format = when (currentGrouping) {
                Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
//                SimpleDateFormat("dd MMM yyyy")
                    SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)
                }

                Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
//                SimpleDateFormat("dd MMM yyyy")
                    SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)
                }

                Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
                Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
                else -> SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)
            }

            if (allList.size != 0) {
                for (pictureData in allList) {
//                val strKey = format.format(pictureData.date)
                    var strKey = format.format(pictureData.date)

                    when (currentGrouping) {
                        Constant.GROUP_BY_NONE -> strKey = ""
                        Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
                            strKey = format.format(getDayStartTS(pictureData.date, false))
                        }

                        Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
                            strKey = format.format(getDayStartTS(pictureData.dateTaken, false))
                        }

                        Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> {
                            strKey = format.format(getDayStartTS(pictureData.date, true))
                        }

                        Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> {
                            strKey = format.format(getDayStartTS(pictureData.dateTaken, true))
                        }

                        Constant.GROUP_BY_EXTENSION -> {
                            strKey = pictureData.fileName.getFilenameExtension()
                                .lowercase(Locale.getDefault())

                        }

                        Constant.GROUP_BY_FOLDER -> {
//                            strKey = pictureData.bucketPath
//                        strKey = pictureData.filePath.getParentPath().getFilenameFromPath().lowercase(Locale.getDefault())
                            strKey = pictureData.filePath.getParentFolder()
                                .lowercase(Locale.getDefault())
                        }

                        Constant.GROUP_BY_FILE_TYPE -> {
                            strKey = getFileTypeString(pictureData.fileName)
                        }

                        else -> {
                            strKey = format.format(getDayStartTS(pictureData.dateTaken, false))
                        }
                    }

                    var imagesData1: ArrayList<PictureData> = ArrayList()

                    if (strKey.isNotEmpty() && dateWisePictures.containsKey(strKey)) {
                        val list: ArrayList<PictureData>? = dateWisePictures[strKey]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    if (strKey.isNotEmpty()) dateWisePictures[strKey] = imagesData1
                }


                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                if (groupOrder == Constant.ORDER_DESCENDING) {
                    listKeys.reverse()
                }

                if (listKeys.size == 0) {
//                pictures.addAll(allList)
                    dummyPictures.addAll(allList)
                }
                for (i in listKeys.indices) {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
//                    pictures.add(bucketData)
//                    pictures.addAll(imagesData)
                        dummyPictures.add(bucketData)
                        dummyPictures.addAll(imagesData)
                    }
                }
            }
            binding.swipeRefreshLayout.isRefreshing = false
//            }
        } catch (e: Exception) {

        }

//        pictures.clear()
//        activity.runOnUiThread { notifyAdapter() }
    }

    fun setData() {

        if (isAdded) {
            Log.e("gettingListPhoto", "Data is show")
            isUpadteList = false
            binding.swipeRefreshLayout.isRefreshing = false

//        binding.pictureRecycler.suppressLayout(true)
            binding.pictureRecycler.recycledViewPool.clear()
            pictures.clear()
            pictures.addAll(dummyPictures)

            enableScroll()

            if (pictureAdapter != null) notifyAdapter() else initAdapter()
//        RxBus.getInstance().post(CountShowEvent())
            setEmptyData()
        }

    }

    private fun initZoomListener() {
        val isGridShow = preferences?.getShowGrid()!!
        if (isGridShow) {
            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_PICTURE) {
                        increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }


    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.pictureRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {

        binding.pictureRecycler.setupDragListener(dragListener)
//        binding.pictureRecycler.setupDragListener(object : MyRecyclerView.MyDragListener {
//            override fun selectItem(position: Int) {
//                toggleItemSelection(true, position, true)
//            }
//
//            override fun selectRange(
//                initialSelection: Int,
//                lastDraggedIndex: Int,
//                minReached: Int,
//                maxReached: Int
//            ) {
//                selectItemRange(
//                    initialSelection,
//                    Math.max(0, lastDraggedIndex),
//                    Math.max(0, minReached),
//                    maxReached
//                )
//                if (minReached != maxReached) {
//                    lastLongPressedItem = -1
//                }
//            }
//        })
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        if (select && pictures[pos] is AlbumData) {
            return
        }

        if (pictures[pos] is PictureData) {

            if (select) {
                (pictures[pos] as PictureData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                (pictures[pos] as PictureData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
            }
        }
        pictureAdapter?.notifyItemChanged(pos)
        setSelectedFile()

    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences?.getGridCount()!!
        if (selectedGrid > 2) {
            preferences?.setGridCount(selectedGrid - 1)
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences?.getGridCount()!!
        if (selectedGrid < MAX_COLUMN_COUNT_PICTURE) {
            preferences?.setGridCount(selectedGrid + 1)
        }
        setColumnView()
    }

    private fun setColumnView() {
        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount = preferences?.getGridCount()!!
        pictureAdapter?.apply {
            notifyItemRangeChanged(0, pictures.size)
        }
        setRvLayoutManager()
    }

    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            isEmpty=false
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            isEmpty=true
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun initAdapter() {
        setRvLayoutManager()
//        preferences?.saveObjectList(pictures)
        pictureAdapter = PictureAdapter(mActivity!!, pictures,
            clickListener = {
                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    if (pictureData.isCheckboxVisible) {
                        pictureData.isSelected = !pictureData.isSelected
                        pictureAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    } else {
                        val dataList = ArrayList<PictureData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is PictureData) {
                                dataList.add(pictures[i] as PictureData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition= displayPos
//                        val intent = Intent(activity, ImageViewerActivity::class.java)
                        if(Constant.displayImageList.size>0) {
                            val intent = Intent(mActivity!!, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            startActivity(intent)
                        }
                        selectAlbum()
                    }
                }
            }, longClickListener = {
//            binding.swipeRefreshLayout.isRefreshing = false
//            binding.swipeRefreshLayout.isEnabled = false
                lastLongPressedItem = it
                binding.pictureRecycler.setDragSelectActive(it)
                lastLongPressedItem = if (lastLongPressedItem == -1) {
                    it
                } else {
                    val min = min(lastLongPressedItem, it)
                    val max = max(lastLongPressedItem, it)
                    for (i in min..max) {
                        toggleItemSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is PictureData) {
                                val model = pictures[i] as PictureData
                                model.isCheckboxVisible = true
                            }
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }

            }, headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is PictureData) {
                            val model = pictures[pos] as PictureData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedFile()
                }
            })


        binding.pictureRecycler.adapter = pictureAdapter
//        val primaryColor = resources.getColor(R.color.color_primary)
//        binding.mediaFastscroller.updateColors(primaryColor)
//        binding.mediaFastscroller.handleDrawable=ColorDrawable(primaryColor)
//        binding.mediaFastscroller.popupTextView.setTextColor(primaryColor)
//        binding.mediaFastscroller.popupTextView.background.mutate().setColorFilter(primaryColor, PorterDuff.Mode.SRC_IN)


        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)

//        val snapHelper: SnapHelper = LinearSnapHelper()
//        snapHelper.attachToRecyclerView(binding.pictureRecycler)
    }

    fun setRvLayoutManager() {
        val gridCount = preferences?.getGridCount()!!
//        val gridLayoutManager = GridLayoutManager(getActivity(), gridCount, RecyclerView.VERTICAL, false)
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = gridCount
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
//        binding.pictureRecycler.layoutManager = gridLayoutManager
//        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//            override fun getSpanSize(position: Int): Int {
//                if (position >= 0 && position < pictures.size) {
//                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
//                        gridCount
//                    } else 1
//                } else {
//                    return 1
//                }
//            }
//        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }


        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
        selectedItem = selected
    }

    public fun setSwipeRefreshEnabled(isEnabled: Boolean) {
        binding.swipeRefreshLayout.isEnabled = isEnabled
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if(!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${pictures.size} ")
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                    Log.e("", "setClose==>> PictureData selection false")
                }
        }
//        pictures=dummyPictures
        binding.swipeRefreshLayout.isEnabled = true
//        setRvLayoutManager()
        notifyAdapter()
        setRvLayoutManager()
        getData()
        selectedItem = 0
    }


    fun pdfImages() {
        if (selectedItem == 0) {
            mActivity?.toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {

                val uris = ArrayList<File>()
                for (i in pictures.indices) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
//                            val uri = FileProvider.getUriForFile(
//                                mActivity!!,
//                                mActivity?.packageName + ".provider",
//                                File(model.filePath)
//                            )
                            uris.add(File(model.filePath))
                        }
                    }
                }
                mActivity?.runOnUiThread {
                    var filename = System.currentTimeMillis().toString()
                    val quality = 80
                    PDFEngine.getInstance().createPDF(activity, uris, object : CreatePDFListener {
                        override fun onPDFGenerated(pdfFile: File?, numOfImages: Int) {

                            if (pdfFile != null) {
                                if (pdfFile.exists()) {
                                    try {
                                        MediaScannerConnection.scanFile(
                                            mActivity, arrayOf(pdfFile.absolutePath),
                                            null, null
                                        )
                                    } catch (e: Exception) {
                                    }
                                    Log.d("TAG", "onPDFGenerated:  Pdf file -->" + pdfFile!!.absolutePath)
                                    Log.d("TAG", "onPDFGenerated:  numberofPages -->" + numOfImages)
                                    mActivity?.toast("Your pdf is saved at ${pdfFile.absolutePath}")

                                    mActivity?.openPath(pdfFile.absolutePath, true)
                                }
                            }
                        }
                    }, filename, false, quality, true)
//                    Utils.shareFilesList(mActivity!!, uris)
                }
            }
        }
    //        (activity as BaseActivity).showProgress(activity.getString(R.string.please_wait))

    }

    fun shareImages() {
        if (selectedItem == 0) {
            mActivity?.toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {

                val uris = ArrayList<Uri>()
                for (i in pictures.indices) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            val uri = FileProvider.getUriForFile(
                                mActivity!!,
                                mActivity?.packageName + ".provider",
                                File(model.filePath)
                            )
                            uris.add(uri)
                        }
                    }
                }
                mActivity?.runOnUiThread {
                    Utils.shareFilesList(mActivity!!, uris)
                }
            }
        }

    }

    fun setHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                mActivity!!,
                mActivity?.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = mActivity?.let {
                ConfirmationDialog(
                    it,
                    getString(R.string.Private),
                    getString(R.string.hide_msg),
                    getString(R.string.hide),
                    positiveBtnClickListener = {
                        hidePhoto()
                    })
            }
            hideDialog?.show(childFragmentManager, hideDialog.tag)
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {

            mActivity?.toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog = mActivity?.let {
                DeleteDialog(
                    it,
                    btnClickListener = {
                        deletePhoto(it)
                    })
            }
            deleteDialog?.show(childFragmentManager, deleteDialog.tag)
        }
    }

    fun getSelected(): ArrayList<PictureData> {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
//                        favList.add(model.filePath)
                    }
                }
        }
        return selectImage
    }

    fun setFavorite(isFavorite: Boolean) {

        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences?.getFavoriteList()!!)

        for (i in pictures.indices) {
//            if (pictures[i] != null)
            if (pictures[i] is PictureData) {
                val model: PictureData = pictures[i] as PictureData
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath)) favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath)) favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences?.setFavoriteList(favList)
//        preferences?.refreshMedia=true
        setCloseToolbar()
        (mActivity as HomeActivity).updateData()
    }


    fun setAs() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        ensureBackgroundThread {
            val newUri =
                mActivity?.getFinalUriFromPath(pictureData.filePath, BuildConfig.APPLICATION_ID)
                    ?: return@ensureBackgroundThread
            Intent().apply {
                action = Intent.ACTION_ATTACH_DATA
                setDataAndType(newUri, mActivity?.getUriMimeType(pictureData.filePath, newUri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(this, getString(R.string.set_as))

                try {
                    startActivityForResult(chooser, 101)
                } catch (e: ActivityNotFoundException) {
                    mActivity?.toast(R.string.no_app_found)
                } catch (e: Exception) {
                    mActivity?.showErrorToast(e)
                }
            }
        }

    }

    fun setWallpaper() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]
        val intent=Intent(mActivity!!, SetWallpaperActivity::class.java)
            .putExtra(
                Constant.EXTRA_WALL_PAPER,
                pictureData.filePath
            )
        intentLauncher.launch(intent)
    }

    var intentLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
//            if (preferences?.refreshMedia!!) {
//
//            }
        }

    fun showResizeDialog() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val resizeDialog =
            ResizeDialog(
                mActivity!!,
                pictureData,
                updateImageListener = {path->
                    val file = File(path)
                    pictures.add(0, PictureData(path, file.name, file.parent!!, file.lastModified(), file.lastModified(), file.length()))
                })
        resizeDialog.show(parentFragmentManager, resizeDialog.tag)
    }

    fun showRenameDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        val pictureData = selectImage.get(0)

        val renameDialog =
            RenameDialog(
                mActivity!!,
                pictureData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    val file = File(renamePath)
                    notifyAdapter()
//                    pagerAdapter.notifyDataSetChanged()
                })
        renameDialog.show(parentFragmentManager, renameDialog.tag)
    }

    fun showBatchRenameDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        val albumData = selectImage.filter { it.isSelected }
        val paths: ArrayList<String> = ArrayList()
        paths.addAll(albumData.map { it.filePath })

        val renameDialog =
            BatchFolderRenameDialog(
                mActivity!!,
                true,
                paths,
                updateImageListener = {
                    preferences?.scanMedia=true
                    preferences?.refreshMedia=true
                    setCloseToolbar()
                })
        renameDialog.show(parentFragmentManager, renameDialog.tag)
    }


    fun showDetailsDialog() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val detailsDialog =
            DetailsDialog(selectImage[0], false)
        detailsDialog.show(childFragmentManager, detailsDialog.tag)
    }

    fun openEditor() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val path = selectImage[0].filePath
        val newPath = path.removePrefix("file://")
        mActivity?.openEditorIntent(newPath)
    }

    fun showAddAlbumDialog(albumList: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {

            mActivity?.toast(getString(R.string.PleaseSelectImage))
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            val selectAlbum: ArrayList<AlbumData> = ArrayList()

            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }

            val addAlbumDialog =
                mActivity?.let {
                    SelectAlbumFullDialog(
                        it,
                        albumList,
                        selectAlbum,
                        isCopy,
                        selectPathListener = { selectPath ->
                            setCopyMove(isCopy, selectPath, selectImage)
                        },
                        createAlbumListener = {
                            val createDialog = CreateAlbumDialog(mActivity!!, createPathListener = {
                                setCopyMove(isCopy, it, selectImage)
                            })
                            createDialog.show(childFragmentManager, createDialog.tag)
                        })
                }
            addAlbumDialog?.show(childFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        if (isCopy)
            Utils.copyFiles(
                mActivity!!,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    mActivity?.toast(getString(R.string.copy_successfully))
                    selectedItem = 0

                    preferences?.refreshMedia = true
                    preferences?.scanMedia = true
                    Handler(Looper.getMainLooper()).postDelayed({
                        setCloseToolbar()
                    }, 500)
//                    longClickListener(false, 0, false)
//                    setCloseToolbar()
                })
        else
            Utils.moveFiles(
                mActivity!!,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    mActivity?.toast(getString(R.string.move_successfully))
                    selectedItem = 0

                    preferences?.refreshMedia = true
                    preferences?.scanMedia = true
                    Handler(Looper.getMainLooper()).postDelayed({
                        setCloseToolbar()
                    }, 500)
//                    longClickListener(false, 0, false)
//                    setCloseToolbar()
                })

    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils.hideFiles(mActivity!!, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                getActivity(),
                getString(R.string.hide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
        })
    }


    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            mActivity!!,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(childFragmentManager,progressDialog.tag)

        preferences?.refreshMedia = true
        preferences?.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(mActivity!!)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    if (model.isSelected) {
//                        activity.runOnUiThread {
//                            bindingDialog.txtTitle.text = model.fileName
//                        }

                        val isDelete =
                            Utils.deleteFile(mActivity!!, model.filePath, dataBase, isPermanent)
                        if (isDelete) {
                            deleteList.add(model.filePath)
                            mActivity?.runOnUiThread {
                                progressDialog.setProgress(deleteList.size,selectedItem)
//                                bindingDialog.txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                bindingDialog.progressBar.progress = deleteList.size
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                } else if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                mActivity?.runOnUiThread {
//                    if (dialog.isShowing)
                        progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                mActivity?.runOnUiThread {
//                    if (dialog.isShowing)
                        progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(0, deleteList))
        selectedItem = 0
        notifyAdapter()
//        enableScroll()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()

        mActivity?.toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
    }


    public fun getData() {
        if (!isAdded) return
        allList.clear()
//        pictures.clear()
        dummyPictures.clear()
//        activity.runOnUiThread { if (pictureAdapter != null) pictureAdapter!!.notifyDataSetChanged() }
        disableScroll()
        isUpadteList = true
        binding.swipeRefreshLayout.isRefreshing = true

        Glide.get(mActivity!!).clearMemory()

        CoroutineScope(Dispatchers.IO).launch {
            Observable.fromCallable {
                Glide.get(mActivity!!).clearDiskCache()
                getImages()
                true
            }.subscribeOn(Schedulers.io())
                .doOnError { throwable: Throwable? ->
                    Log.e("gettingListPhoto", "getData:" + throwable)
                    mActivity?.runOnUiThread {
                        setFilterData()
                    }
                }
                .subscribe { result: Boolean? ->
                    mActivity?.runOnUiThread {
                        setFilterData()
                    }
                }
        }
    }

    private fun disableScroll() {
//        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }


    private fun getFindCount() {
//        var imageCount = 0
//        var videoCount = 0
//
//        try {
//            if (allList.size != 0) {
//                val videoList = allList.filter { it.isVideo }
//                val imageList = allList.filter { !it.isVideo }
//
//                if (videoList.isNotEmpty())
//                    videoCount = videoList.size
//
//                if (imageList.isNotEmpty())
//                    imageCount = imageList.size
//            }
//        } catch (e: Exception) {
//
//        }
//        imageVideoCount(imageCount, videoCount)
    }

    var isUpadteList = false
    fun setFilterData() {
        if (isAdded) {

            isUpadteList = true
            disableScroll()
            binding.swipeRefreshLayout.isRefreshing = true
            GlobalScope.launch(Dispatchers.IO) {
                setFilter()
                setList()
                mActivity?.runOnUiThread {
                    setData()
                    getFindCount()
                }
            }

//        Observable.fromCallable {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread { setData() }
//            }
        }
    }

    private fun setFilter() {
        Log.e("", "imageVideo size==>> " + allList.size)
        val sortType = preferences?.getSortType("frag_1")
        val sortOrder = preferences?.getSortOrder("frag_1")

        try {

            Collections.sort(allList, Comparator { p1, p2 ->
                if (sortType == Constant.SORT_NAME) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileName.compareTo(p2.fileName, true)
                    else
                        p2.fileName.compareTo(p1.fileName, true)
                } else if (sortType == Constant.SORT_PATH) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.filePath.compareTo(p2.filePath, true)
                    else
                        p2.filePath.compareTo(p1.filePath, true)
                } else if (sortType == Constant.SORT_SIZE) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize)
                    else
                        p2.fileSize.compareTo(p1.fileSize)
                } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.date.compareTo(p2.date)
                    else
                        p2.date.compareTo(p1.date)
                } else if (sortType == Constant.SORT_DATE_TAKEN) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.dateTaken.compareTo(p2.dateTaken)
                    else
                        p2.dateTaken.compareTo(p1.dateTaken)
                } else
                    p2.date.compareTo(p1.date)
            })
        }catch (e:Exception){}

    }


    private fun getFileTypeString(fileName: String): String {
        Log.e("getFileTypeString", "getFileTypeString.001:$fileName")
//        Log.e("getFileTypeString","getFileTypeString.002:${fileName.toInt()}")
        var stringId = R.string.images
        if (fileName.isImageFast() || fileName.isApng() || fileName.isPng()) stringId =
            R.string.images
        else if (fileName.isVideoFast()) stringId = R.string.videos
        else if (fileName.isPortrait()) stringId = R.string.portraits
        else if (fileName.isSvg()) stringId = R.string.svgs
        else if (fileName.isGif()) stringId = R.string.gifs

        return requireContext().getString(stringId)
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

//    private fun getFormattedKey(
//        key: String,
//        grouping: Int,
//        today: String,
//        yesterday: String,
//        count: Int
//    ): String {
//        var result = when {
//
//            grouping and Constant.GROUP_BY_LAST_MODIFIED_DAILY != 0 || grouping and Constant.GROUP_BY_DATE_TAKEN_DAILY != 0 -> getFinalDate(
//                formatDate(key, true),
//                today,
//                yesterday
//            )
//
//            grouping and Constant.GROUP_BY_LAST_MODIFIED_MONTHLY != 0 || grouping and Constant.GROUP_BY_DATE_TAKEN_MONTHLY != 0 -> formatDate(
//                key,
//                false
//            )
//
//            grouping and Constant.GROUP_BY_FILE_TYPE != 0 -> getFileTypeString(key)
//            grouping and Constant.GROUP_BY_EXTENSION != 0 -> key.uppercase(Locale.getDefault())
////            grouping and Constant.GROUP_BY_FOLDER != 0 -> requireContext().humanizePath(key)
//            grouping and Constant.GROUP_BY_FOLDER != 0 -> getString(R.string.internal)
//            else -> key
//        }
//
//        if (result.isEmpty()) {
//            result = requireContext().getString(R.string.unknown)
//        }
//
//        return if (grouping and Constant.GROUP_SHOW_FILE_COUNT != 0) {
//            "$result ($count)"
//        } else {
//            result
//        }
//    }


    private fun formatDate(timestamp: String, showDay: Boolean): String {
        return if (timestamp.areDigitsOnly()) {
            val cal = Calendar.getInstance(Locale.ENGLISH)
            cal.timeInMillis = timestamp.toLong()
//            val format = if (showDay) context.config.dateFormat else "MMMM yyyy"

            val format = preferences?.dateFormat
//            val format = if (showDay) "dd MMM yyyy" else "MMMM yyyy"

            DateFormat.format(format, cal).toString()
        } else {
            ""
        }
    }

    private fun getFinalDate(date: String, today: String, yesterday: String): String {
        return when (date) {
            today -> requireContext().getString(R.string.today)
            yesterday -> requireContext().getString(R.string.yesterday)
            else -> date
        }
    }


    private fun notifyAdapter() {
        //        binding.pictureRecycler.suppressLayout(true)
        if (pictureAdapter != null)
            pictureAdapter?.notifyDataSetChanged()
//binding.pictureRecycler.post { pictureAdapter?.notifyDataSetChanged() }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }

    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {
        if (event.path.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val pictureData: PictureData = picture as PictureData
                        if (pictureData.filePath == event.path) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (pictureData in allList) {
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }

        }
        if (event.unFavoriteList.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (favPath in event.unFavoriteList) {
                    for (picture in pictures) {
                        if (picture is PictureData) {
                            val pictureData: PictureData = picture as PictureData
                            if (pictureData.filePath == favPath) {
                                pictureData.isFavorite = event.isFavorite
                                break
                            }
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (favPath in event.unFavoriteList) {
                    for (pictureData in allList) {
                        if (pictureData.filePath == favPath) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }


        }
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in filterList) {
//                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
//                        filterList.remove(pictureData)
//                        break
//                    }
//                }
//            }
            for (path in deleteList) {
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }


            getFindCount()
        }
    }


    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun restoreEvent(event: RestoreDataEvent) {

        if (event.restoreList.isNotEmpty()) {
//            if (pictures.isNotEmpty()) {
            val list: ArrayList<String> = ArrayList()
            val imageList: ArrayList<String> = ArrayList()
            val favList = preferences?.getFavoriteList()!!

            for (restoreData in event.restoreList) {
                list.add(restoreData.deletedPath)
                imageList.add(restoreData.path)
            }

            updateDeleteImageData(list)
            deleteMainList(list)

            for (i in imageList.indices) {
                val file1 = File(imageList[i])
                if (file1.exists()) {
                    val pictureData = PictureData(
                        file1.path,
                        file1.name,
                        file1.parentFile.name,
                        file1.lastModified(),
                        file1.lastModified(),
                        file1.length()
                    )
                    pictureData.isFavorite = favList.contains(file1.path)
                    if (Utils.isVideoFile(file1.path)) {
                        pictureData.isVideo = true
                    }
                    allList.add(pictureData)
                }
            }
            setFilterData()
            getFindCount()
        }

    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            pictureAdapter?.notifyDataSetChanged()

            if (allList.isNotEmpty()) {
//                for (pictureData in allBackList) {
//                    if (pictureData.filePath == event.oldPath) {
//                        pictureData.filePath = event.renamePath
//                        pictureData.fileName = File(event.renamePath).name
//                        pictureData.fileSize = File(event.renamePath).length()
//                        break
//                    }
//                }

                for (pictureData in allList) {
                    if (pictureData.filePath == event.oldPath) {
                        pictureData.filePath = event.renamePath
                        pictureData.fileName = File(event.renamePath).name
                        pictureData.fileSize = File(event.renamePath).length()
                        break
                    }
                }

            }
        }

    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            val favList = preferences?.getFavoriteList()!!
            val file = File(event.albumPath)

            if (event.deleteList.isNotEmpty())
                if (pictures.isNotEmpty()) {
                    deleteMainList(event.deleteList)
                }

            if (file.exists()) {
                for (i in imageList.indices) {
                    val file1 = File(imageList[i])
                    if (file1.exists()) {
                        val pictureData = PictureData(
                            file1.path,
                            file1.name,
                            file1.parentFile.name,
                            file1.lastModified(),
                            file1.lastModified(),
                            file1.length()
                        )
                        pictureData.isFavorite = favList.contains(file1.path)
                        if (Utils.isVideoFile(file1.path)) {
                            pictureData.isVideo = true
                        }
                        if (!isUpadteList) {
                            allList.add(pictureData)

                        }
                    }
                }
                if (!isUpadteList) {
                    setFilterData()
                    getFindCount()
                }
            }
        }
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

//    fun setSearch(searchText: String) {
//        val strSearch = searchText.lowercase(Locale.getDefault())
//        if (isSearch) isStopSearch = true
//
//        Observable.fromCallable<Boolean> {
//            isSearch = true
//            allList.clear()
//            if (strSearch.isEmpty()) {
//                allList.addAll(allBackList)
//            } else {
//                var list = allBackList.filter {
//                    it.fileName.lowercase(Locale.getDefault()).contains(strSearch)
//                }
//
//                if (!isStopSearch) {
//                    if (!list.isNullOrEmpty())
//                        allList.addAll(list)
//                }
//            }
//            if (!isStopSearch) setList()
//
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { throwable: Throwable? ->
//                activity.runOnUiThread {
//                    isSearch = false
//                    isStopSearch = false
//                    setData()
//                }
//            }
//            .subscribe { result: Boolean? ->
//                activity.runOnUiThread {
//                    isStopSearch = false
//                    isSearch = false
//                    setData()
//                }
//            }
//    }

//    private fun getImages() {
//        Log.e("gettingListPhoto", "getImages")
//        val mCursor: Cursor?
//        val folderList: MutableList<String> = ArrayList<String>()
////        folderList.addAll(preferencesManager.getExcludeFolderList())
//        val favList: ArrayList<String> = ArrayList()
//        favList.addAll(preferences?.getFavoriteList())
//        var mediaType = "image/*"
//
//        val projection = arrayOf(
//            MediaStore.MediaColumns.DATA,
//            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
//            MediaStore.MediaColumns.DATE_MODIFIED,
//            MediaStore.MediaColumns.DATE_TAKEN,
//            MediaStore.MediaColumns.DISPLAY_NAME,
//            MediaStore.MediaColumns.SIZE
//        )
//
//        val selection = "${MediaStore.MediaColumns.MIME_TYPE}=?"
//        val selectionArgs = arrayOf(mediaType)
//
//        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
//        } else {
//            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
//        }
//
//        activity.contentResolver.query(
//            uri,
//            projection,
//            selection,
//            selectionArgs,
//            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
//        )?.use { cursor ->
//            val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
//            val bucketColumn =
//                cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
//            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
//            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
//            val dateTakenColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
//            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
////            try {
//            while (cursor.moveToNext()) {
//                val path = cursor.getString(pathColumn)
//                val bucketName = cursor.getString(bucketColumn)
//                val title = cursor.getString(nameColumn)
//                var d = cursor.getLong(dateColumn)
//                var dt = cursor.getLong(dateTakenColumn)
//                val fileSizeLength = cursor.getLong(sizeColumn)
//
//
//                var bucketPath = ""
//                bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
//
//                if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
//                    d *= 1000
//                    dt *= 1000
//                    if (dt == 0L)
//                        dt = d
//
//                    val pictureData =
//                        PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
//                    pictureData.isFavorite = favList.contains(path)
//                    allList.add(pictureData)
//                    allBackList.add(pictureData)
//                }
//            }
//        }
////        } catch (e: Exception) {
////            Log.e("printStackTrace","printStackTrace:$e")
////        }
//
//    }

    private fun getImages() {
        Log.e("contentResolver.001", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences?.getFavoriteList()!!)

        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences?.getExcludeList()!!)

        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )

            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

//            val uri = MediaStore.Files.getContentUri("external")

            val filterMedia = preferences?.getFilterMedia()!!
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = mActivity?.contentResolver?.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
//                Log.e("contentResolver.001", "getImages.mCursor.count::${mCursor.count}")
                mCursor.moveToFirst()
                val photoDataArrayList: ArrayList<PictureData> = ArrayList<PictureData>()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    val fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))


                    var excluded = false
                    excluded = excludeList.any { bucketPath.startsWith(it) }

//                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty() && !excluded && File(path).exists()) {
                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty() && !excluded) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        val pictureData =
                            PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                        pictureData.isFavorite = favList.contains(path)
                        allList.add(pictureData)

                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            } else Log.e("contentResolver.001", "getImages.mCursor.null::")
        } catch (e: Exception) {
            Log.e("contentResolver.001", "getImages.Exception::$e")
            Log.e("printStackTrace","printStackTrace:$e")
        }
        getVideos()
    }
    private fun getVideos() {
        Log.e("contentResolver.001", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

//        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
//        val uri = MediaStore.Files.getContentUri("external")

//        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )

//        val uri= if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//            android.provider.MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
//        } else
//            android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
//
//        val projection = arrayOf(
//            MediaStore.Video.VideoColumns.DATA,
//            MediaStore.Video.Media.DISPLAY_NAME,
//            MediaStore.Video.VideoColumns.SIZE,
//            MediaStore.Video.VideoColumns.DURATION,
//            MediaStore.Video.VideoColumns.DATE_MODIFIED,
//            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
//        )

        val folderList: MutableList<String> = ArrayList<String>()
//        folderList.addAll(preferencesManager.getExcludeFolderList())

        val excludeList: ArrayList<String> = ArrayList()
        excludeList.addAll(preferences?.getExcludeList()!!)

        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences?.getFavoriteList()!!)
        try {
            val filterMedia = preferences?.getFilterMedia()!!
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            val cursor = mActivity?.contentResolver?.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
//            val cursor = activity.contentResolver.query(
//                uri,
//                projection,
//                selection,
//                selectionArgs,
//                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
//            )

            if (cursor != null) {
//                Log.e("contentResolver.001", "getVideos.mCursor.count::${cursor.count}")
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var excluded = false
                    excluded = excludeList.any { bucketPath.startsWith(it) }

//                    if (!folderList.contains(bucketPath)&& !excluded && File(path).exists()) {
                    if (!folderList.contains(bucketPath)&& !excluded) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        val fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))

                        dt *= 1000
                        if (dt == 0L)
                            dt = d

//                        Log.e("contentResolver.001", "getVideos path:$path, title:$title, bucketName:$bucketName, d:$d, dt:$dt, fileSizeLength:$fileSizeLength, duration:$duration")
                        val pictureData = PictureData(
                            path,
                            title,
                            bucketName,
                            d,
                            dt,
                            fileSizeLength,
                            true,
                            cursor.getLong(duration)
                        )
                        pictureData.isFavorite = favList.contains(path)
                        pictureData.isVideo = true
                        allList.add(pictureData)

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            } else
                Log.e("contentResolver.001", "getVideos.mCursor.null::")
        } catch (exp: java.lang.Exception) {
            Log.e("contentResolver.001", "Exception.getVideos::$exp")
            exp.printStackTrace()
        }
    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                args.add("%$it")
//            }
//        }
//
//        if (filterMedia and TYPE_SVGS != 0) {
//            args.add("%.svg")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            args.add("%.jpg")
//            args.add("%.jpeg")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }


        return args
    }

}