package gallery.gallerylock.vaultgallery.hidepictures.calendardaterangepicker.customviews

class InvalidDateException(message: String) : IllegalArgumentException(message)
