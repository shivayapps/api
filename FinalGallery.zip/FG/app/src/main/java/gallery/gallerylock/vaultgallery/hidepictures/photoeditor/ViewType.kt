package gallery.gallerylock.vaultgallery.hidepictures.photoeditor


enum class ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}