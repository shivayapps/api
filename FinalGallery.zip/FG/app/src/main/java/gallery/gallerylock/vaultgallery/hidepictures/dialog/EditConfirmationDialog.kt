package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogConfirmationBinding
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogEditConfirmationBinding

class EditConfirmationDialog(
    var mContext: Context,
    val btnClickListener: (action:Int,isDontShowChecked:Boolean) -> Unit,
) : BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogEditConfirmationBinding
    var isDontShowChecked: Boolean=false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogEditConfirmationBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        bindingDialog.cbCheck.setOnCheckedChangeListener { buttonView, isChecked ->
            this.isDontShowChecked=isChecked
        }
        bindingDialog.btnReplace.setOnClickListener {
            btnClickListener.invoke(0,isDontShowChecked)
            dismiss()
        }
        bindingDialog.btnCopy.setOnClickListener {
            btnClickListener.invoke(1,isDontShowChecked)
            dismiss()
        }
        bindingDialog.btnCancel.setOnClickListener { dismiss() }


    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}