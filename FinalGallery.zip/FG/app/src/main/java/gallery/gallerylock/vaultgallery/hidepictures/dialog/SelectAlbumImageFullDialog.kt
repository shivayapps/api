package gallery.gallerylock.vaultgallery.hidepictures.dialog

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import gallery.gallerylock.vaultgallery.hidepictures.R
import gallery.gallerylock.vaultgallery.hidepictures.adapter.PictureAdapter
import gallery.gallerylock.vaultgallery.hidepictures.databinding.DialogAddAlbumFullBinding
import gallery.gallerylock.vaultgallery.hidepictures.model.PictureData
import gallery.gallerylock.vaultgallery.hidepictures.utils.Preferences

class SelectAlbumImageFullDialog(
    var mContext: Activity,
    var albumDataList: ArrayList<PictureData>,
    val selectPathListener: (path: String) -> Unit,
    val createAlbumListener: () -> Unit
) : DialogFragment() {

    lateinit var binding: DialogAddAlbumFullBinding
    lateinit var albumAdapter: PictureAdapter
//    var albumList: ArrayList<PictureData> = ArrayList()
    var albumList: ArrayList<Any> = ArrayList()
    var selectPos = 0
    var preferences: Preferences = Preferences(mContext)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.FullScreenDialog)
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            val width = ViewGroup.LayoutParams.MATCH_PARENT
            val height = ViewGroup.LayoutParams.MATCH_PARENT
            dialog.window!!.setLayout(width, height)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        super.onCreateView(inflater, container, savedInstanceState)
        binding = DialogAddAlbumFullBinding.inflate(layoutInflater, container, false)

        intView()

        return binding.root
    }

    private fun intView() {

        binding.txtTitle.text = mContext.getString(R.string.select_cover_image)

//        val newAlbum=preferences.getLastAlBumCreated()
//        if(newAlbum.isNotEmpty()) {
//            albumList.add(AlbumData(newAlbum.getFilenameFromPath(),folderPath=newAlbum, isCustomAlbum = true))
//        }
//        albumList.addAll(albumList.size, albumDataList.filter { it.isVideo==false })

        albumList.addAll(albumList.size, albumDataList)

        initAdapter()
        initListener()
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener { dismiss() }
        binding.btnDone.setOnClickListener { dismiss() }
    }

    private fun initAdapter() {
        albumAdapter = PictureAdapter(mContext, albumList, clickListener = {
            if (albumList[it] is PictureData) {
                selectPos = it
                val albumData = albumList[selectPos]
                dismiss()
                selectPathListener((albumData as PictureData).filePath)
            }

        }, longClickListener = {
            if (albumList[it] is PictureData) {}
        },headerSelectListener = {

        })
        val gridLayoutManager = GridLayoutManager(mContext, 3, RecyclerView.VERTICAL, false)
        binding.albumRecycler.layoutManager = gridLayoutManager
        binding.albumRecycler.adapter = albumAdapter
    }

}
