package com.video.aimagic.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {

    private static final String PREF_NAME = "app_prefs";
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public PrefManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    // Save String
    public void putString(String key, String value) {
        editor.putString(key, value);
        editor.apply(); // async & safe
    }

    // Get String
    public String getString(String key) {
        return sharedPreferences.getString(key, "");
    }

    // Get String with default value
    public String getString(String key, String defaultValue) {
        return sharedPreferences.getString(key, defaultValue);
    }

    // Remove key
    public void remove(String key) {
        editor.remove(key);
        editor.apply();
    }

    // Clear all
    public void clear() {
        editor.clear();
        editor.apply();
    }
}
