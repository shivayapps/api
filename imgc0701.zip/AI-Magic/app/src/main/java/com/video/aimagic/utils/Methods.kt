package com.video.aimagic.utils

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import com.adconfig.AdsConfig
import com.video.aimagic.R
import com.video.aimagic.commonscreen.screen.FeedbackDialog
import com.video.aimagic.commonscreen.screen.RatingDialog
import com.video.aimagic.utils.appconfig.getAllDeviceInfo
import java.util.Locale
import java.util.TimeZone

object Methods {

    val emailTo = "ahyansamiapps@gmail.com"

    fun rateApp(context: Context) {
        val uri = Uri.parse("market://details?id=${context.packageName}")
        val goToMarket = Intent(Intent.ACTION_VIEW, uri)
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        try {
            context.startActivity(goToMarket)
        } catch (e: ActivityNotFoundException) {
            context.startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/details?id=${context.packageName}")
                )
            )
        }
    }

    fun toastComingSoon(context: Context) {
        Toast.makeText(
            context,
            "Coming Soon",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun feedBackSupport(context: Context, feebBackText: String) {
        val emailText = feebBackText + "\n" + context.getAllDeviceInfo()
        val emailIntent = Intent(Intent.ACTION_SEND_MULTIPLE)
        emailIntent.type = "message/rfc822"
        emailIntent.setPackage("com.google.android.gm")
        emailIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(emailTo))
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name))
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailText)
        val uris = ArrayList<Uri>()
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        context.startActivity(Intent.createChooser(emailIntent, "Send mail..."))
    }


    fun showRatingDialog(context: Context) {
        val ratingDialog = RatingDialog(context)
        ratingDialog.show()
    }

    fun showFeedbackDialog(context: Context) {
        val feedbackDialog = FeedbackDialog(context)
        feedbackDialog.show()
    }

    fun requestBook(context: Context, tag: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$emailTo")
            when (tag) {
                "Book" -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens request")
                "feedback" -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens app Feedback")
                else -> putExtra(Intent.EXTRA_SUBJECT, "Empire Lens app Feedback")
            }
        }
        if (context.packageManager != null) startActivity(context, intent, null)
    }

    fun openLink(link: String, context: Context) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
    }


}