package com.video.aimagic.aienhancer.api.post;

import java.io.File;

public  class EnhanceRequest {
    private String templateId;
    private String appName;
    private String countryCode;
    private String platform;
    private String fcmToken;
    private String firebaseAppCheck;
    private File sourceImage;

    // Getters and setters
    public String getTemplateId() { return templateId; }
    public void setTemplateId(String templateId) { this.templateId = templateId; }

    public String getAppName() { return appName; }
    public void setAppName(String appName) { this.appName = appName; }

    public String getCountryCode() { return countryCode; }
    public void setCountryCode(String countryCode) { this.countryCode = countryCode; }

    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }

    public String getFcmToken() { return fcmToken; }
    public void setFcmToken(String fcmToken) { this.fcmToken = fcmToken; }

    public String getFirebaseAppCheck() { return firebaseAppCheck; }
    public void setFirebaseAppCheck(String firebaseAppCheck) { this.firebaseAppCheck = firebaseAppCheck; }

    public File getSourceImage() { return sourceImage; }
    public void setSourceImage(File sourceImage) { this.sourceImage = sourceImage; }

    // Builder pattern methods
    public EnhanceRequest withTemplateId(String templateId) {
        this.templateId = templateId;
        return this;
    }

    public EnhanceRequest withAppName(String appName) {
        this.appName = appName;
        return this;
    }

    public EnhanceRequest withCountryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    public EnhanceRequest withPlatform(String platform) {
        this.platform = platform;
        return this;
    }

    public EnhanceRequest withFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
        return this;
    }

    public EnhanceRequest withFirebaseAppCheck(String firebaseAppCheck) {
        this.firebaseAppCheck = firebaseAppCheck;
        return this;
    }

    public EnhanceRequest withSourceImage(File sourceImage) {
        this.sourceImage = sourceImage;
        return this;
    }
}
