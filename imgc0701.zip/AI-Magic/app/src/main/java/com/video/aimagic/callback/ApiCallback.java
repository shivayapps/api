package com.video.aimagic.callback;


public interface ApiCallback {
    void onSuccess(String response);

    void onError(String errorMessage);
}
