package com.video.aimagic.commonscreen.data

data class DrawableItem(
    val drawableRes: Int
)
