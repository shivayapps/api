package com.video.aimagic.transformation.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.video.aimagic.databinding.ItemCharacterBinding;
import com.video.aimagic.databinding.ItemCharacterSeeAllBinding;
import com.video.aimagic.transformation.models.TransformationCharacterItem;
import com.video.aimagic.transformation.screens.TransformationSeeAllScreen;

import java.util.List;

public class TransformationCharacterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final List<TransformationCharacterItem> transformationCharacterItems;
    private final Context context;
    private OnItemClickListener listener;

    private static final int TYPE_REGULAR = 0;
    private static final int TYPE_SEE_ALL = 1;

    public TransformationCharacterAdapter(Context context, List<TransformationCharacterItem> transformationCharacterItems) {
        this.context = context;
        this.transformationCharacterItems = transformationCharacterItems;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        return context instanceof TransformationSeeAllScreen ? TYPE_SEE_ALL : TYPE_REGULAR;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        if (viewType == TYPE_SEE_ALL) {
            ItemCharacterSeeAllBinding binding = ItemCharacterSeeAllBinding.inflate(inflater, parent, false);
            return new SeeAllViewHolder(binding);
        } else {
            ItemCharacterBinding binding = ItemCharacterBinding.inflate(inflater, parent, false);
            return new RegularViewHolder(binding);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        TransformationCharacterItem item = transformationCharacterItems.get(position);

        if (holder instanceof RegularViewHolder) {
            ((RegularViewHolder) holder).bind(item, listener);
        } else if (holder instanceof SeeAllViewHolder) {
            ((SeeAllViewHolder) holder).bind(item, listener);
        }
    }

    @Override
    public int getItemCount() {
        return transformationCharacterItems.size();
    }

    public interface OnItemClickListener {
        void onItemClick(TransformationCharacterItem item, String imageUrl);
    }

    class RegularViewHolder extends RecyclerView.ViewHolder {
        private final ItemCharacterBinding binding;

        RegularViewHolder(ItemCharacterBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(TransformationCharacterItem item, OnItemClickListener listener) {
            if (item.model.cat_name_localised != null && item.model.cat_name_localised.containsKey("en")) {
                binding.nameTextView.setText(item.model.cat_name_localised.get("en"));
            } else {
                binding.nameTextView.setText(item.subCategory);
            }

            Glide.with(context)
                    .load(item.model.output_url)
                    .into(binding.imageView);

            binding.cardView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onItemClick(item, item.model.output_url);
                }
            });
        }
    }

    class SeeAllViewHolder extends RecyclerView.ViewHolder {
        private final ItemCharacterSeeAllBinding binding;

        SeeAllViewHolder(ItemCharacterSeeAllBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(TransformationCharacterItem item, OnItemClickListener listener) {
            if (item.model.cat_name_localised != null && item.model.cat_name_localised.containsKey("en")) {
                binding.nameTextView.setText(item.model.cat_name_localised.get("en"));
            } else {
                binding.nameTextView.setText(item.subCategory);
            }

            Glide.with(context)
                    .load(item.model.output_url)
                    .into(binding.imageView);

            binding.cardView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onItemClick(item, item.model.output_url);
                }
            });
        }
    }
}