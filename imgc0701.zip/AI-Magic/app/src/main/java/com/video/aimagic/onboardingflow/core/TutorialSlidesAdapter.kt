package com.video.aimagic.onboardingflow.core

import android.media.MediaPlayer
import android.net.Uri
import android.util.SparseArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.video.aimagic.R
import com.video.aimagic.databinding.CustomOnboardingPageItemBinding
import com.video.aimagic.onboardingflow.dataset.CustomOnBoardingPage

class TutorialSlidesAdapter : RecyclerView.Adapter<TutorialSlidesAdapter.SlideViewHolder>() {

    private val tutorialContentList = CustomOnBoardingPage.entries.toTypedArray()
    private val viewHolderCache = SparseArray<SlideViewHolder>()
    private var parentRecyclerView: RecyclerView? = null
    private var activeSlidePosition = 0

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        parentRecyclerView = recyclerView
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        parentRecyclerView = null
        stopAllMediaPlayback()
    }

    override fun onCreateViewHolder(container: ViewGroup, viewType: Int): SlideViewHolder {
        val inflater = LayoutInflater.from(container.context)
        val viewBinding = CustomOnboardingPageItemBinding.inflate(inflater, container, false)
        return SlideViewHolder(viewBinding, this)
    }

    override fun onBindViewHolder(holder: SlideViewHolder, position: Int) {
        holder.displayContent(tutorialContentList[position])
        viewHolderCache.put(position, holder)
        val adId=holder.itemView.context.getString(R.string.native_ad);
        NativeAdHelper(
            holder.itemView.context,
            holder.viewBinding.adsLayout,
            holder.viewBinding.adsLayout,
            NativeLayoutType.NativeBig,
            adId
        ) { isLoaded ->

        }.loadAd()
    }

    override fun onViewAttachedToWindow(holder: SlideViewHolder) {
        super.onViewAttachedToWindow(holder)
        if (holder.adapterPosition == activeSlidePosition) {
            holder.beginMediaPlayback()
        }
    }

    override fun onViewDetachedFromWindow(holder: SlideViewHolder) {
        super.onViewDetachedFromWindow(holder)
        if (holder.adapterPosition != activeSlidePosition) {
            holder.stopMediaPlayback()
        }
    }

    override fun getItemCount(): Int = tutorialContentList.size

    fun getCachedViewHolder(index: Int): SlideViewHolder? {
        return viewHolderCache[index] ?: parentRecyclerView?.findViewHolderForAdapterPosition(index) as? SlideViewHolder
    }

    fun updateActiveSlide(index: Int) {
        if (activeSlidePosition != index) {
            getCachedViewHolder(activeSlidePosition)?.stopMediaPlayback()
            activeSlidePosition = index
            getCachedViewHolder(activeSlidePosition)?.beginMediaPlayback()
        }
    }

    fun pauseActiveMedia() {
        getCachedViewHolder(activeSlidePosition)?.pauseMediaPlayback()
    }

    fun stopAllMediaPlayback() {
        for (i in 0 until viewHolderCache.size()) {
            viewHolderCache.valueAt(i).stopMediaPlayback()
        }
    }

    class SlideViewHolder(
        val viewBinding: CustomOnboardingPageItemBinding,
        private val hostAdapter: TutorialSlidesAdapter
    ) : RecyclerView.ViewHolder(viewBinding.root) {

        private var mediaController: MediaPlayer? = null
        private var isMediaReady = false
        private var currentMediaResource: Int = 0

        fun displayContent(content: CustomOnBoardingPage) {
            viewBinding.subTitleTv.text = viewBinding.root.context.getString(content.titleResId)
            viewBinding.subTitleTv.text = viewBinding.root.context.getString(content.subtitleResId)
            viewBinding.descTV.text = viewBinding.root.context.getString(content.descriptionResId)

            when (content.contentType) {
                CustomOnBoardingPage.ContentType.IMAGE -> {
                    viewBinding.img.visibility = View.VISIBLE
                    viewBinding.videoView.visibility = View.GONE
                    viewBinding.img.setImageResource(content.imageResId)
                }

                CustomOnBoardingPage.ContentType.VIDEO -> {
                    viewBinding.img.visibility = View.GONE
                    viewBinding.videoView.visibility = View.VISIBLE
                    currentMediaResource = content.videoResId
                    initializeVideoPlayer()
                }
            }
        }

        private fun initializeVideoPlayer() {
            if (currentMediaResource == 0) return

            isMediaReady = false
            val mediaUri = Uri.parse("android.resource://${viewBinding.root.context.packageName}/$currentMediaResource")

            viewBinding.videoView.setVideoURI(mediaUri)
            viewBinding.videoView.setOnPreparedListener { player ->
                mediaController = player
                player.isLooping = true
                player.setVolume(0f, 0f)
                isMediaReady = true
                if (adapterPosition == hostAdapter.activeSlidePosition) {
                    beginMediaPlayback()
                }
            }
            viewBinding.videoView.setOnCompletionListener { player ->
                player.start()
            }
            viewBinding.videoView.setOnErrorListener { _, _, _ -> false }
        }

        fun beginMediaPlayback() {
            if (viewBinding.videoView.visibility == View.VISIBLE &&
                isMediaReady &&
                adapterPosition == hostAdapter.activeSlidePosition) {
                viewBinding.videoView.start()
            }
        }

        fun pauseMediaPlayback() {
            if (viewBinding.videoView.visibility == View.VISIBLE &&
                viewBinding.videoView.isPlaying) {
                viewBinding.videoView.pause()
            }
        }

        fun stopMediaPlayback() {
            if (viewBinding.videoView.visibility == View.VISIBLE) {
                viewBinding.videoView.stopPlayback()
                mediaController?.release()
                mediaController = null
                isMediaReady = false
            }
        }
    }
}