package com.adconfig.adsutil

import android.content.Context
import android.content.SharedPreferences

class AdsParameters(context: Context) {

    private val ADS_PARAMETERS = "ADS_PARAMETERS"

    private val preferences: SharedPreferences =
        context.getSharedPreferences(ADS_PARAMETERS, Context.MODE_PRIVATE)
    var isTest = false

    var adWidth: Int
        get() = preferences.getInt("adWidth", 280)
        set(value) = preferences.edit().putInt("adWidth", value).apply()
    var adHeight: Int
        get() = preferences.getInt("adHeight", 280)
        set(value) = preferences.edit().putInt("adHeight", value).apply()

//    var callNativeId: String?
//        get() = preferences.getString("call_native_id", "")
//        set(value) = preferences.edit().putString("call_native_id", value).apply()
//    var callBannerId: String?
//        get() = preferences.getString("call_banner_id", "")
//        set(value) = preferences.edit().putString("call_banner_id", value).apply()

//    var callAdType: String?
//        get() = preferences.getString("call_ad_type", "native")
//        set(value) = preferences.edit().putString("call_ad_type", value).apply()

}