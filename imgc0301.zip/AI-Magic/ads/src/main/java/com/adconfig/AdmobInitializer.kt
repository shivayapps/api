package com.adconfig

import android.content.Context
import android.util.Log
import androidx.annotation.Keep
import androidx.startup.Initializer
import com.google.android.gms.ads.MobileAds

@Keep
class AdmobInitializer : Initializer<Unit> {
    override fun create(context: Context) {
        try {
            MobileAds.initialize(context.applicationContext,{
                Log.d("MobileAds", "onInitializationComplete.Initializer")
            })
        } catch (e:Exception) {
        }
    }

    override fun dependencies(): MutableList<Class<out Initializer<*>>> {
        return mutableListOf()
    }
}
