package com.adconfig.adsutil

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.LoadingDialog
import com.adconfig.adsutil.utils.SmUtils.isConnected
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.databinding.ActivityInterLoadingBinding
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

import java.util.Timer
import kotlin.concurrent.timerTask

class InterLoadingActivity : AppCompatActivity() {
    var isAdShow = false
    lateinit var adsParameters: AdsParameters
    var TAG = "ADCONFIG_InterLoading"
    private var loadingDialog: LoadingDialog? = null

    private lateinit var binding: ActivityInterLoadingBinding
    var interAdId = "ca-app-pub-6124133406945075/2523538822"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInterLoadingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (!isConnected(this)) {
            safeFinish(Activity.RESULT_CANCELED)
            return
        }
        interAdId = intent.getStringExtra("interAdId") ?: "ca-app-pub-6124133406945075/2523538822"
        val loadingMessage = intent.getStringExtra("loadingMessage") ?: "Loading Ads"
        val showDialog = intent.getBooleanExtra("showDialog", false)

        adsParameters = AdsParameters(this@InterLoadingActivity)
        binding.tvLoading.text = loadingMessage

        if (showDialog) {
            loadingDialog=LoadingDialog(this, loadingMessage)
            loadingDialog?.setCancelable(false)
            loadingDialog?.show()

            binding.llMain.visibility = View.GONE
            binding.llRoot.setBackgroundColor(Color.TRANSPARENT)
        } else {
            binding.llMain.visibility = View.VISIBLE
        }

        startAdsTimer()
        showInterstitialAd({
            if (it) {
                safeFinish(Activity.RESULT_OK)
            } else {
                safeFinish(Activity.RESULT_CANCELED)
            }
            finish()
        })
    }

    private fun showInterstitialAd(onAdShow: (isShow: Boolean) -> Unit = {}) {
        Log.d("LoadAd", "loadInterAd.001:$interAdId")
        InterstitialAd.load(
            applicationContext,
            interAdId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    onAdShow.invoke(false)
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
//                    timer?.cancel()
                    if (!isDestroyed || !isFinishing) {
                        interstitialAd.fullScreenContentCallback =
                            object : FullScreenContentCallback() {
                                override fun onAdShowedFullScreenContent() {
                                    Log.d(TAG, "showInterstitialAd.onAdShowedFullScreenContent")
                                }

                                override fun onAdDismissedFullScreenContent() {
                                    Log.d(TAG, "showInterstitialAd.onAdDismissedFullScreenContent")
                                    onAdShow.invoke(true)
                                }

                                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                                    Log.d(
                                        TAG,
                                        "showInterstitialAd.onAdFailedToShowFullScreenContent"
                                    )
                                    onAdShow.invoke(false)
                                }
                            }
                        interstitialAd.show(this@InterLoadingActivity)
                    }
                }
            }
        )
    }


    private var timer: Timer? = null
    fun startAdsTimer() {
        val timeOut = 10000L
        timer?.cancel()
        timer = Timer()
        timer?.schedule(timerTask {
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                loadingDialog?.dismiss()
                loadingDialog = null
                isAdShow = true
                timer?.cancel()

                if (!isAdShow) finish()
                finish()
            }
        }, timeOut, timeOut)
    }

    override fun onPause() {
        super.onPause()
        if (!isAnyAdShowing && !isFinishing) {
            safeFinish(Activity.RESULT_CANCELED)
        }
    }
    private fun safeFinish(result: Int) {
        if (!isDestroyed && !isFinishing) {
            loadingDialog?.dismiss()
            loadingDialog = null
            timer?.cancel()
            setResult(result)
            finish()
        }
    }

}