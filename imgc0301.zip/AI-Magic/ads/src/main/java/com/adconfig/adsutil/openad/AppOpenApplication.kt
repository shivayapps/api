package com.adconfig.adsutil.openad


import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.util.Log
import android.webkit.WebView
import androidx.annotation.Keep
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.OpenAdHelper.loadOpenAd
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.adsutil.utils.isAppForeground
import com.adconfig.adsutil.utils.isInterstitialAdShow
import com.google.android.gms.ads.AdActivity
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Keep
open class AppOpenApplication : MultiDexApplication(), DefaultLifecycleObserver {

    private val TAG: String = "ADCONFIG_Application"

    // variable to track pause event time
    private var isPause: Boolean = false
    private var mLastPauseTime: Long = 0
    private val mMinPauseDuration = 100

    private var mOpenAdManager: OpenAdManager? = null

//    private val mTestDeviceIds: ArrayList<String> = ArrayList()

    @Keep
    interface AppLifecycleListener {
        fun onResumeApp(fCurrentActivity: Activity): Boolean
        fun onAppOpenCreatedEvent(fCurrentActivity: Activity)
        fun onAppOpenShownEvent(fCurrentActivity: Activity)
        fun onAppOpenFailedEvent(fCurrentActivity: Activity)
    }

    var mAppLifecycleListener: AppLifecycleListener? = null

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    override fun onCreate() {
        super<MultiDexApplication>.onCreate()
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)

        mOpenAdManager = OpenAdManager(this@AppOpenApplication)

    }

    fun setAppLifecycleListener(fAppLifecycleListener: AppLifecycleListener) {
        this.mAppLifecycleListener = fAppLifecycleListener
    }
    fun initMobileAds() {
        setMobileAds()
    }

    private fun setMobileAds() {
        CoroutineScope(Dispatchers.IO).launch {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val processName = getProcessName(applicationContext)
                if (processName != null && packageName != processName) {
                    try {
                        WebView.setDataDirectorySuffix(processName)
                    } catch (e: Exception) {
                        Log.i(TAG, "WebView Exception:$e")
                    }
                    MobileAds.initialize(applicationContext) {
                        Log.d("MobileAds", "onInitializationComplete.1")
                    }
                } else {
                    MobileAds.initialize(applicationContext) {
                        Log.d("MobileAds", "onInitializationComplete.2")
                    }
                }
            } else {
                MobileAds.initialize(applicationContext) {
                    Log.d("MobileAds", "onInitializationComplete.3")
                }
            }
        }
    }

    private fun getProcessName(context: Context?): String? {
        if (context == null) return null

        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val runningProcesses = manager?.runningAppProcesses ?: return ""

        for (processInfo in runningProcesses) {
            if (processInfo.pid == Process.myPid()) {
                return processInfo.processName
            }
        }
        return ""
    }

    /*@SuppressLint("HardwareIds")
    private fun getAdsTestDeviceId(): String {
        return try {
            val androidId: String = Settings.Secure.getString(this.contentResolver, Settings.Secure.ANDROID_ID)
            val md5Data = customMD5(androidId)
            val deviceId = md5Data?.uppercase(java.util.Locale.ENGLISH) ?: "null"
            println("getDeviceId: $deviceId")
            deviceId
        } catch (e: Exception) {
            e.toString()
        }
    }

    private fun customMD5(md5: String): String? {
        try {
            val md = MessageDigest.getInstance("MD5")
            val array = md.digest(md5.toByteArray())
            val sb = StringBuffer()
            for (i in array.indices) {
                sb.append(Integer.toHexString(array[i].toInt() and 0xFF or 0x100).substring(1, 3))
            }
            return sb.toString()
        } catch (e: NoSuchAlgorithmException) {
        }
        return null
    }*/

    //<editor-fold desc="For Application Lifecycle">
    override fun onPause(owner: LifecycleOwner) {
        super.onPause(owner)
        Log.i(TAG, "onPause: ")
        mLastPauseTime = SystemClock.elapsedRealtime()
        isPause = true

    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        Log.i(TAG, "onStart: onAppForegrounded: ")
        isAppForeground = true
    }

    override fun onStop(owner: LifecycleOwner) {
        super.onStop(owner)
        Log.i(TAG, "onStop: onAppBackgrounded: ")

        if (SystemClock.elapsedRealtime() - mLastPauseTime < mMinPauseDuration) {
            Log.i(TAG, "onStop: Reset Pause Flag")
            if (isPause) {
                isPause = false
            }
        }
        if (isAppForeground && !OpenAdHelper.isAdAvailable()) {
            mOpenAdManager?.let {
                it.mCurrentActivity?.let {act->
                    mAppLifecycleListener?.let { lListener ->
                        Handler(Looper.getMainLooper()).postDelayed({
                            if(!act.isDestroyed && !act.isFinishing){
                                if (lListener.onResumeApp(act)) {
                                    loadOpenAd(act, onAdLoad = {
                                    }, onAdFailed = {
                                        lListener.onAppOpenFailedEvent(act)
                                    }, onAdShow = {
                                        lListener.onAppOpenShownEvent(act)
                                    })
                                }
                            }
                        }, 500)
                    }
                }
            }
        }
        isAppForeground = false
    }

    override fun onResume(owner: LifecycleOwner) {
        super.onResume(owner)
        Log.i(TAG, "onResume")
        mAppLifecycleListener?.let { lListener ->
            mOpenAdManager?.let { lOpenAdManager ->
                Log.i(TAG, "onResume, isAppForeground${isAppForeground},isPause-${isPause}")
//                if (isAppForeground && !isPause) {
                if (isAppForeground) {
                    lOpenAdManager.mCurrentActivity?.let { fCurrentActivity ->
                        if (fCurrentActivity !is AdActivity) {
                            if (isAnyAdShowing) {
                                isAnyAdShowing = false
                            } else {
                                if (!isInterstitialAdShow) {
                                    if (lListener.onResumeApp(fCurrentActivity)) {
                                        Log.i(TAG, "onResume 007")
                                        lOpenAdManager.showOpenAd()
                                    }
                                }
                            }
                        }
                    }
                }

                if (isPause) {
                    isPause = false
                }
            }
        }
    }
}