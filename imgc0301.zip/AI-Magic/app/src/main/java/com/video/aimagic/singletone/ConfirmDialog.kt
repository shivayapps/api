package com.video.aimagic.singletone

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity

import com.bumptech.glide.Glide
import com.video.aimagic.databinding.DialogConfirmBinding

class ConfirmDialog(
    val activity: Activity,
    val clickListener: (isSave: Boolean) -> Unit
) : Dialog(activity) {

    lateinit var binding: DialogConfirmBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        window?.setGravity(Gravity.BOTTOM)

        binding = DialogConfirmBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        binding.btnCancel.setOnClickListener {
            dismiss()
            clickListener.invoke(false)
        }
        binding.btnOK.setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }
        setCancelable(false)
        setCanceledOnTouchOutside(false)
    }

}