package com.video.aimagic.facedance.api.get;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.VideoView;

import com.video.aimagic.callback.ResponseCallBack;
import com.video.aimagic.callback.VideoResponseCallback;

import java.io.File;

public class FaceDanceDownloadVideoAndPlay {

    private final String TAG = "FaceDanceDownloadVideoAndPlay";
    private static FaceDanceDownloadVideoAndPlay instance;
    private Context context;
    private transient String requestId;
    private Handler mainHandler;


    private MediaPlayer mediaPlayer;
    private boolean isMuted = true;   // default mute

    public void mute() {
        isMuted = true;
        applyMute();
    }

    public void unMute() {
        isMuted = false;
        applyMute();
    }

    public void toggleMute() {
        isMuted = !isMuted;
        applyMute();
    }

    public boolean isMuted() {
        return isMuted;
    }

    private void applyMute() {
        if (mediaPlayer == null) return;

        float volume = isMuted ? 0f : 1f;
        mediaPlayer.setVolume(volume, volume);
    }
    private FaceDanceDownloadVideoAndPlay(Context context) {
        this.context = context.getApplicationContext();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public static synchronized FaceDanceDownloadVideoAndPlay getInstance(Context context) {
        if (instance == null) {
            instance = new FaceDanceDownloadVideoAndPlay(context);
        }
        return instance;
    }

    public void makeRequest(String appName, String videoId, ProgressBar loadingProgressBar,
                            ProgressBar progressBar, VideoView videoView, ResponseCallBack responseCallBack) {
        if (context == null) {
            System.out.println("Error: Context is null");
            return;
        }

        showLoading(true, loadingProgressBar, progressBar, videoView);

        FaceDanceVideoApiClient.getInstance().downloadVideo(context, appName, videoId, loadingProgressBar,
                progressBar, videoView,
                new VideoResponseCallback() {
                    @Override
                    public void onSuccess(File videoFile) {
                        Log.d(TAG, "onSuccess:===========> " + videoFile.getPath());
                        // Run on UI thread
                        mainHandler.post(() -> {
                            responseCallBack.onSuccess(videoFile.getPath());
                            playVideoFromFile(context, videoFile, loadingProgressBar, progressBar, videoView);
                        });
                    }

                    @Override
                    public void onProgress(int progress) {
                        // Run on UI thread
                        mainHandler.post(() -> {
                            progressBar.setProgress(progress);
                        });
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Log.d(TAG, "onError:===========> " + errorMessage);


                        // Run on UI thread
                        mainHandler.post(() -> {
                            responseCallBack.onError(errorMessage);
                            showToastOnUiThread("Error downloading video: " + errorMessage);
                            showLoading(false, loadingProgressBar, progressBar, videoView);
                        });
                    }
                });
    }

    private void playVideoFromFile(Context context, File videoFile, ProgressBar loadingProgressBar,
                                   ProgressBar progressBar, VideoView videoView) {
        try {
            // Ensure we're on the main thread
            if (Looper.myLooper() != Looper.getMainLooper()) {
                mainHandler.post(() -> playVideoFromFile(context, videoFile, loadingProgressBar, progressBar, videoView));
                return;
            }

            showLoading(false, loadingProgressBar, progressBar, videoView);

            // Use FileProvider for better security and compatibility
            Uri videoUri = Uri.fromFile(videoFile);

            // Reset the VideoView first
            videoView.stopPlayback();
            videoView.setVideoURI(null);

            // Set up the VideoView properly
            videoView.setVideoURI(videoUri);
            videoView.requestFocus();

            videoView.setOnPreparedListener(mp -> {
                mediaPlayer=mp;
                Log.d("VideoPlayer", "Video prepared - starting playback");
                progressBar.setVisibility(View.GONE);
                loadingProgressBar.setVisibility(View.GONE);
                videoView.start();

                // Optional: Set up looping if needed
                mp.setLooping(true);
            });

            videoView.setOnErrorListener((mp, what, extra) -> {
                Log.e("VideoPlayer", "Error playing video - what: " + what + ", extra: " + extra);
                showToastOnUiThread("Error playing video. Code: " + what);
                progressBar.setVisibility(View.GONE);
                loadingProgressBar.setVisibility(View.GONE);
                return true; // indicates we handled the error
            });

            videoView.setOnCompletionListener(mp -> {
                Log.d("VideoPlayer", "Video completed");
                // Optional: Restart video or show completion message
            });

            // Add info listener for debugging
            videoView.setOnInfoListener((mp, what, extra) -> {
                switch (what) {
                    case android.media.MediaPlayer.MEDIA_INFO_BUFFERING_START:
                        Log.d("VideoPlayer", "Buffering started");
                        break;
                    case android.media.MediaPlayer.MEDIA_INFO_BUFFERING_END:
                        Log.d("VideoPlayer", "Buffering ended");
                        break;
                    case android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START:
                        Log.d("VideoPlayer", "Rendering started");
                        break;
                }
                return false;
            });

        } catch (Exception e) {
            Log.e("VideoPlayer", "Error playing video: " + e.getMessage(), e);
            showToastOnUiThread("Error playing video: " + e.getMessage());
            showLoading(false, loadingProgressBar, progressBar, videoView);
        }
    }

    private void showLoading(boolean show, ProgressBar loadingProgressBar,
                             ProgressBar progressBar, VideoView videoView) {
        // This method should only be called from UI thread
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> showLoading(show, loadingProgressBar, progressBar, videoView));
            return;
        }

        loadingProgressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        videoView.setVisibility(show ? View.GONE : View.VISIBLE);

        if (!show) {
            progressBar.setProgress(0);
        }
    }

    private void showToastOnUiThread(final String message) {
        if (context != null) {
            mainHandler.post(() -> Toast.makeText(context, message, Toast.LENGTH_LONG).show());
        }
    }

    public void setContext(Context context) {
        this.context = context.getApplicationContext();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }
}