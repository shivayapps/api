package com.video.aimagic.facedance;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.video.aimagic.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FaceDanceVideoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_REGULAR = 0;
    private static final int TYPE_SEE_ALL = 1;
    private Context mContext;
    private List<FaceDanceModel> mVideoItems;

    public FaceDanceVideoAdapter(Context context, List<FaceDanceModel> videoItems) {
        this.mContext = context;
        this.mVideoItems = videoItems;
    }

    @Override
    public int getItemViewType(int position) {
        return mContext instanceof FaceDanceSeeAllScreen ? TYPE_SEE_ALL : TYPE_REGULAR;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        if (viewType == TYPE_SEE_ALL) {
            View view = inflater.inflate(R.layout.item_video_see_all, parent, false);
            return new SeeAllViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_video, parent, false);
            return new RegularViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        FaceDanceModel currentItem = mVideoItems.get(position);
        String videoUrl = currentItem.getUrl();
        String displayName = getDisplayName(currentItem.getNameMap());

        if (holder instanceof RegularViewHolder) {
            RegularViewHolder regularHolder = (RegularViewHolder) holder;
            regularHolder.videoTitle.setText(displayName);

            Glide.with(mContext)
                    .load(videoUrl)
                    .apply(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.DATA))
                    .into(regularHolder.thumbnailImage);

            regularHolder.videoCard.setOnClickListener(v -> {
                handleItemClick(currentItem, position);
            });
        } else if (holder instanceof SeeAllViewHolder) {
            SeeAllViewHolder seeAllHolder = (SeeAllViewHolder) holder;
            seeAllHolder.videoTitle.setText(displayName);

            Glide.with(mContext)
                    .load(videoUrl)
                    .apply(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.DATA))
                    .into(seeAllHolder.thumbnailImage);

            seeAllHolder.videoCard.setOnClickListener(v -> {
                handleItemClick(currentItem, position);
            });
        }
    }

    private String getDisplayName(Map<String, String> nameMap) {
        if (nameMap != null && !nameMap.isEmpty()) {
            String localizedName = nameMap.get("en");
            return localizedName != null ? localizedName : "Unnamed - No Name Found";
        }
        return "Unnamed - Empty NameMap";
    }

    private void handleItemClick(FaceDanceModel item, int position) {
        VideoDataHandler dataManager = VideoDataHandler.getInstance();
        dataManager.setVideoUrl(item.getUrl());
        dataManager.setVideoName(getDisplayName(item.getNameMap()));
        dataManager.setCurrentPosition(position);

        ArrayList<String> urlList = new ArrayList<>();
        ArrayList<String> userTypes = new ArrayList<>();
        ArrayList<Map<String, String>> nameMaps = new ArrayList<>();

        for (FaceDanceModel faceDanceModel : mVideoItems) {
            urlList.add(faceDanceModel.getUrl());
            userTypes.add(faceDanceModel.getUserType());
            nameMaps.add(faceDanceModel.getNameMap());
        }

        dataManager.setVideoList(urlList);
        dataManager.setUrlLists(urlList);
        dataManager.setUserTypeList(userTypes);

        Intent intent = new Intent(mContext, FaceDanceUploadImageScreen.class);
        /* intent.putStringArrayListExtra("IMAGE_URLS", urlList);
        intent.putStringArrayListExtra("USER_TYPES", userTypes);
        intent.putExtra("IMAGE_NAMES", nameMaps);
        intent.putExtra("CURRENT_POSITION", position);*/
        mContext.startActivity(intent);
    }

    private String getGifFromResources(Context context, int resourceId) {
        try {
            InputStream inputStream = context.getResources().openRawResource(resourceId);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            String jsonContent = new String(buffer, StandardCharsets.UTF_8);
            JSONObject jsonObject = new JSONObject(jsonContent);
            return jsonObject.getString("gifUrl");

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return mVideoItems.size();
    }

    public static class RegularViewHolder extends RecyclerView.ViewHolder {
        ImageView thumbnailImage;
        CardView videoCard;
        TextView videoTitle;

        public RegularViewHolder(View itemView) {
            super(itemView);
            thumbnailImage = itemView.findViewById(R.id.thumbnailImage);
            videoCard = itemView.findViewById(R.id.videoCard);
            videoTitle = itemView.findViewById(R.id.videoTitle);
        }
    }

    public static class SeeAllViewHolder extends RecyclerView.ViewHolder {
        ImageView thumbnailImage;
        CardView videoCard;
        TextView videoTitle;

        public SeeAllViewHolder(View itemView) {
            super(itemView);
            thumbnailImage = itemView.findViewById(R.id.thumbnailImage);
            videoCard = itemView.findViewById(R.id.videoCard);
            videoTitle = itemView.findViewById(R.id.videoTitle);
        }
    }
}