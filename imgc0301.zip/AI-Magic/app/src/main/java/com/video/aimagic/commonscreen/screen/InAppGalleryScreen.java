package com.video.aimagic.commonscreen.screen;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.video.aimagic.databinding.ActivityInAppGalleryScreenBinding;
import com.video.aimagic.commonscreen.commonadapter.GalleryAdapter;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class InAppGalleryScreen extends AppCompatActivity implements GalleryAdapter.OnItemClickListener {
    private static final int REQUEST_PERMISSIONS = 100;
    private static final int REQUEST_CAMERA = 101;
    private static final int REQUEST_GALLERY = 102;
    private static final int REQUEST_CROP = 103;

    private ActivityInAppGalleryScreenBinding binding;
    private GalleryAdapter adapter;
    private String currentPhotoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInAppGalleryScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());

        setupRecyclerView();
        checkPermissions();

        binding.onBackButton.setOnClickListener(v -> finish());
    }

    private void setupRecyclerView() {
        adapter = new GalleryAdapter(this, new ArrayList<>(), this);
        binding.galleryRecyclerview.setAdapter(adapter);
    }

    private void checkPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.CAMERA);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toArray(new String[0]), REQUEST_PERMISSIONS);
        } else {
            loadImages();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                loadImages();
            } else {
                Toast.makeText(this, "Permissions are required to use this feature", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void loadImages() {
        List<String> images = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Storage permission required", Toast.LENGTH_SHORT).show();
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Storage permission required", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        String[] projection = {MediaStore.Images.Media.DATA};
        String sortOrder = MediaStore.Images.Media.DATE_ADDED + " DESC";

        try (Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
        )) {
            if (cursor != null) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                while (cursor.moveToNext()) {
                    String imagePath = cursor.getString(columnIndex);
                    images.add(imagePath);
                }
            }
        } catch (SecurityException e) {
            Log.e("InAppGalleryScreen", "Permission error loading images: " + e.getMessage());
            Toast.makeText(this, "Cannot access images without permission", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("InAppGalleryScreen", "Error loading images: " + e.getMessage());
        }

        adapter.updateImages(images);
    }

    @Override
    public void onCameraClick() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
            return;
        }

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                ex.printStackTrace();
                Toast.makeText(this, "Error creating image file", Toast.LENGTH_SHORT).show();
                return;
            }

            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_CAMERA);
            }
        }
    }

    @Override
    public void onGalleryClick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Intent intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_GALLERY);
        } else {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, REQUEST_GALLERY);
        }
    }

    @Override
    public void onImageClick(String imagePath) {
        navigateToCropScreen(imagePath);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir
        );

        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("InAppGalleryScreen", "onActivityResult: " + requestCode + ", result: " + resultCode);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                if (currentPhotoPath != null) {
                    navigateToCropScreen(currentPhotoPath);
                }
            } else if (requestCode == REQUEST_GALLERY && data != null) {
                Uri selectedImage = data.getData();
                String[] filePathColumn = {MediaStore.Images.Media.DATA};

                Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                    String imagePath = cursor.getString(columnIndex);
                    cursor.close();
                    navigateToCropScreen(imagePath);
                } else {
                    // If we can't get the file path, use the URI directly
                    PhotoUploadManager manager = PhotoUploadManager.getInstance();
                    manager.setImageUri(selectedImage);
                    Intent intent = new Intent(this, CropScreen.class);
                    intent.putExtra("IMAGE_URI", selectedImage);
                    startActivityForResult(intent, REQUEST_CROP);
                }
            } else if (requestCode == REQUEST_CROP) {
                // Crop completed successfully - finish this activity
                PhotoUploadManager manager = PhotoUploadManager.getInstance();
                Uri croppedImageUri = null;

                if (data != null && data.hasExtra("CROPPED_IMAGE_URI")) {
                    String croppedUriString = data.getStringExtra("CROPPED_IMAGE_URI");
                    croppedImageUri = Uri.parse(croppedUriString);
                    manager.notifyPhotoUploaded(croppedUriString);
                    Log.d("InAppGalleryScreen", "Got cropped URI from intent: " + croppedImageUri);
                }

                if (croppedImageUri == null) {
                    croppedImageUri = manager.getCurrentImageUri();
                    Log.d("InAppGalleryScreen", "Using manager's URI: " + croppedImageUri);
                }

                if (croppedImageUri != null) {
                    Log.d("InAppGalleryScreen", "Notifying upload with URI: " + croppedImageUri);
                } else {
                    Log.e("InAppGalleryScreen", "No cropped image URI available");
                }

                // Finish the gallery activity only after successful crop
                setResult(RESULT_OK);
                finish();
            }
        } else if (resultCode == RESULT_CANCELED) {
            // User cancelled the crop - stay in gallery
            Log.d("InAppGalleryScreen", "Crop was cancelled, staying in gallery");

        } else {
            Log.d("InAppGalleryScreen", "Result not OK: " + resultCode);
        }
    }

    private void navigateToCropScreen(String imagePath) {
        PhotoUploadManager.getInstance().setImageUri(Uri.fromFile(new File(imagePath)));
        Intent intent = new Intent(this, CropScreen.class);
        Uri imageUri = Uri.fromFile(new File(imagePath));
        intent.putExtra("IMAGE_URI", imageUri);
        startActivityForResult(intent, REQUEST_CROP);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}