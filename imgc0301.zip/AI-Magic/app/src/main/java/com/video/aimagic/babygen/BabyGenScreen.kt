package com.video.aimagic.babygen

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.google.android.material.tabs.TabLayout
import com.video.aimagic.R
import com.video.aimagic.databinding.ActivityBabyGenScreenBinding
import com.video.aimagic.extension.applySystemBarInsets

class BabyGenScreen : AppCompatActivity() {
    private lateinit var binding: ActivityBabyGenScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBabyGenScreenBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.root.applySystemBarInsets()
        setUpTab()
    }

    private fun setUpTab() {
        binding.onBackButton.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
        arrayOf("Boy", "Girl").forEachIndexed { i, title ->
            val tab = binding.tabLay.newTab()
            val customView =
                LayoutInflater.from(this).inflate(R.layout.new_custom_tab_layout_new_new, null)

            customView.findViewById<TextView>(R.id.tabText).text = title
            customView.findViewById<ImageView>(R.id.tabIcon).setImageResource(
                if (i == 0) R.drawable.baby_boy else R.drawable.baby_girl
            )

            tab.customView = customView
            binding.tabLay.addTab(tab)
        }

        binding.tabviewpager.adapter = AiBabyFragmentLoder(supportFragmentManager, lifecycle)

        binding.tabLay.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                binding.tabviewpager.currentItem = tab.position
                tab.customView?.isSelected = true
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {
                tab.customView?.isSelected = false
            }

            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        binding.tabviewpager.registerOnPageChangeCallback(object : OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                binding.tabLay.selectTab(binding.tabLay.getTabAt(position))
            }
        })
    }
}