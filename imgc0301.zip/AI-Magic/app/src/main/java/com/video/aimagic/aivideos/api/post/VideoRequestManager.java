package com.video.aimagic.aivideos.api.post;


import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.adconfig.adsutil.utils.SmUtils;
import com.video.aimagic.R;
import com.video.aimagic.aivideos.EffectModel;
import com.video.aimagic.aivideos.api.MediaConversionHandler;
import com.video.aimagic.callback.ResponseCallBack;
import com.video.aimagic.commonscreen.screen.CommonResultScreen;
import com.video.aimagic.singletone.CustomDialogManager;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import kotlin.Pair;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class VideoRequestManager {

    private String TAG = "VideoRequestManager";
    private static VideoRequestManager sharedInstance;
    private final MediaConversionHandler conversionService;
    private ResponseCallBack responseCallBack;

    // Private constructor for singleton
    private VideoRequestManager(ResponseCallBack responseCallBack) {
        conversionService = MediaConversionHandler.getSharedInstance();
        this.responseCallBack = responseCallBack;
    }

    // Singleton instance getter
    public static synchronized VideoRequestManager getSharedInstance(ResponseCallBack apiCallback) {
        if (sharedInstance == null) {
            sharedInstance = new VideoRequestManager(apiCallback);
        }
        return sharedInstance;
    }

    private void handleError(String errorMessage) {
        System.err.println("VideoRequestManager Error: " + errorMessage);
        // You can add additional error handling logic here
    }

    public void executeVideoConversionRequest(Activity context) {
        try {
            String animationName = EffectModel.instance.effect_name;
            String accountType = "free";

            // Create video parameters
            Map<String, String> conversionParams = MediaConversionHandler.generateDefaultParams(
                    animationName,
                    accountType
            );

            if (conversionParams == null) {
                handleError("Failed to create video parameters");
                return;
            }

            // Prepare headers
            String appVerificationToken = "eyJraWQiOiJYcEhKU0EiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxOjM5ODIzMDg3ODg2MzphbmRyb2lkOjQwNjIxYzNjNzI4YTc4OGI4ZDBlZmEiLCJhdWQiOlsicHJvamVjdHNcLzM5ODIzMDg3ODg2MyIsInByb2plY3RzXC9mYWNlLXN3YXAtbWFnaWMtYzU4ZGQiXSwicHJvdmlkZXIiOiJkZWJ1ZyIsImlzcyI6Imh0dHBzOlwvXC9maXJlYmFzZWFwcGNoZWNrLmdvb2dsZWFwaXMuY29tXC8zOTgyMzA4Nzg4NjMiLCJleHAiOjE3MTQzODIxMjAsImlhdCI6MTcxNDM3ODUyMCwianRpIjoia3M3TXB2Yk1Qcmx6VFpVY04xcDRFTEhzVTZLZ05iLVAwQ3VONXY4TUZ5NCJ9.NHI10JR5S8Ut_uEdDFz44KIERlZKnTlDw3bPc6CuAQUvFdwtqyLr73i0AcAw5F9YBE4bC-1cNHbt2gmJw3ZRo_uYHcL3rLBWpW_eaoUCLXhj58b7WVh8Bvd9aRavBnC3ZwTo79jxO-pqCW--moESVt1hR4FDgAEEOsI_7CYbv50EZ15O12ndFv_FGUg1VxxfEbk79lrN4Gfo6WhPmTZLhJQL0_wzZ4tHdFh54wjQqoHO2dWfpbh0kdw23j7DFvEB6jxgbTgSxvufL8RwRGdGZ8duY_Cf6LzRwOYMmH6_AClaoHL9wycfKTxDDUwk_L_8xnEIfehmvD5b3PJSSgnAVtzD5ACTMW0L_M6DxeG1O0pJS9P58df_GCo0trNuuTUIIE0p5Ij2lKBuNwa8-cV60iiEID9v_uC9kur9GB6o6DsLSVTrWHK_7966OIi8scV1EP9Aup3cPxkGZZk2SNsLUKUvgEGoTT0DtySgVcqUpr77qnyNg01tEg9li_XA5XeG";
            String pushNotificationToken = "f0FmZMczSOGuy1OWbjIANh:APA91bHEbepPVgX6-z3Da86MJjRfQY5EVvfWNDRtFf74dVJ3T3kx5JZYDyLA7iIWAOuRHLNOTCvnmwdb7hN1EcAJiOt5yQ6JNxnfTivePaM419_2nVVolbEm_NlzWGGzxpXqjuGV-fMN";

            if (appVerificationToken == null || appVerificationToken.isEmpty() ||
                    pushNotificationToken == null || pushNotificationToken.isEmpty()) {
                handleError("Tokens are null or empty");
                return;
            }

            Map<String, String> requestHeaders = MediaConversionHandler.generateDefaultHeaders(
                    appVerificationToken,
                    pushNotificationToken
            );
            if (requestHeaders == null) {
                handleError("Failed to create headers");
                return;
            }

            // Get image file
            File sourceImage;

          /*  if (commonUtils.isIndivisualImageSelectedToUpload()) {
                String individualImagePath = commonUtils.getIndividualImagePath();
                if (individualImagePath == null || individualImagePath.isEmpty()) {
                    handleError("Individual image path is null or empty");
                    return;
                }
                sourceImage = new File(individualImagePath);
            } else {
                String commonImagePath = commonUtils.getIndivualCommonImagePath();
                if (commonImagePath == null || commonImagePath.isEmpty()) {
                    handleError("Common image path is null or empty");
                    return;
                }
                sourceImage = new File(commonImagePath);
            }*/


            String commonImagePath = PhotoUploadManager.getInstance().getCurrentImageUriStringPath();
            if (commonImagePath == null || commonImagePath.isEmpty()) {
                handleError("Common image path is null or empty");
                return;
            }
            sourceImage = new File(commonImagePath);


            if (!sourceImage.exists()) {
                handleError("Image file does not exist");
                return;
            }

            if (conversionService == null) {
                handleError("MediaConversionHandler instance is null");
                return;
            }

            ;
            // Execute the request
            conversionService.transformImageToVideo(
                    sourceImage,
                    conversionParams,
                    requestHeaders,
                    new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            ((Activity) context).runOnUiThread(() -> {
                                Toast.makeText(context, "Request failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                e.printStackTrace();
                                responseCallBack.onError(e.getMessage());
                            });
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            try {
                                if (response.isSuccessful()) {
                                    if (response.body() != null) {
                                        String responseContent = response.body().string();
                                        System.out.println("Success! Response: " + responseContent);
                                        try {
                                            JSONObject jsonResponse = new JSONObject(responseContent);
                                            String requestIdFromResponse = jsonResponse.optString("request_id", "default_id");

                                            final String numericRequestId = requestIdFromResponse.replaceAll("[^\\d.]", "").trim();

                                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    //Toast.makeText(context, "Success! Response: " + responseContent, Toast.LENGTH_SHORT).show();

                                                    Log.d(TAG, "response:===========> " + response);
                                                    //showToastOnUiThread(context, "Upload " + "successful: " + numericRequestId);
                                                    processToNextScreen(context, numericRequestId);
                                                }
                                            }, 20000);

                                        } catch (JSONException e) {
                                            Log.e(TAG, "Error parsing JSON response: " + e.getMessage());
                                            final String fallbackId = String.valueOf(System.currentTimeMillis());
                                            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Log.d(TAG, "response:===========> " + response);
                                                    noServerDialog(context);
                                                }
                                            }, 10000);
                                        }
                                    } else {
                                        noServerDialog(context);
                                        ((Activity) context).runOnUiThread(() -> {
                                            System.err.println("Response body is null");
                                            Toast.makeText(context, "Response body is null: ", Toast.LENGTH_SHORT).show();
                                        });
                                    }
                                } else {
                                    noServerDialog(context);
                                    ((Activity) context).runOnUiThread(() -> {
                                        System.err.println("Request failed with code: " + response.code());
                                        try {
                                            if (response.body() != null) {
                                                System.err.println("Response: " + response.body().string());
                                            }
                                        } catch (IOException e) {
                                            Log.e(TAG, "Error IOException: " + e.getMessage());
                                            e.printStackTrace();
                                        }
                                    });
                                }
                            } catch (Exception e) {
                                ((Activity) context).runOnUiThread(() -> {
                                    noServerDialog(context);
                                });
                            }
                        }
                    }
            );
        } catch (Exception e) {
            noServerDialog(context);
        }


    }

    private void showToastOnUiThread(Activity context, final String message) {
        if (context != null) {
            noServerDialog(context);
        }
    }

    private void noServerDialog(Activity context) {
        if (context != null) {
            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Log.e("showNoServer", "004");
                    CustomDialogManager.getInstance().showDialog(
                            context,
                            "No Server",
                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
                            "Got it",
                            R.drawable.ic_brush,
                            new CustomDialogManager.DialogButtonClickListener() {
                                @Override
                                public void onButtonClicked() {
                                    responseCallBack.onSuccess("");
                                    //((Activity) context).finish();
                                }
                            }
                    );
                }
            });
        }

    }

    @SuppressWarnings("unchecked")
    private void processToNextScreen(Activity context, String requestId) {
        Log.d(TAG, "Generate face swap button clicked");
        if (SmUtils.INSTANCE.isConnected(context)) {
            responseCallBack.onSuccess(requestId);
            StartActivityGlobally.navigateToActivityWithFeature(
                    context,
                    CommonResultScreen.class,
                    new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
                    new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_COUPLE)
            );
        } else {
            Toast.makeText(context, "Please connect to internet.", Toast.LENGTH_SHORT).show();
        }
        //((Activity)context).finish();

    }
}