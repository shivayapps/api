package com.video.aimagic.backgroundchanger;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.adconfig.adsutil.utils.SmUtils;
import com.bumptech.glide.Glide;
import com.video.aimagic.databinding.ActivityBackgroundChangeScreenBinding;
import com.video.aimagic.commonscreen.screen.CommonProcessing;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.appconfig.AppConfig;
import com.video.aimagic.utils.appconfig.StartActivityGlobally;

import kotlin.Pair;

public class BackgroundChangeScreen extends AppCompatActivity implements PhotoUploadManager.PhotoUploadCallback {
    private static final String UPLOAD_BG_REMOVE = "change_background";
    private static final String TAG = "BackgroundChangeScreen";
    private PhotoUploadManager photoUploadManager;
    private ActivityBackgroundChangeScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize view binding
        binding = ActivityBackgroundChangeScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        photoUploadManager = PhotoUploadManager.getInstance();
        Log.d(TAG, "Activity created, PhotoUploadManager instance: " + photoUploadManager);
        setupClickListeners();


    }

    private void setupClickListeners() {
        // Back button
        binding.buttonBack.setOnClickListener(v -> finish());

        // Upload button
        binding.uploadSIngleScreen.setOnClickListener(v -> {
            Log.d(TAG, "Upload button clicked");
            photoUploadManager.startPhotoUpload(
                    BackgroundChangeScreen.this,
                    AppConfig.FEATURE_CHANGE_BG,
                    UPLOAD_BG_REMOVE
            );
        });


        binding.buttonEnhance.setOnClickListener(v -> {
            if (binding.singleImageView.getDrawable() != null) {
                removeBG();
            }
        });
    }


    @SuppressWarnings("unchecked")
    private void removeBG() {
        if(SmUtils.INSTANCE.isConnected(this)) {
            Log.d(TAG, "Generate face swap button clicked");
            StartActivityGlobally.navigateToActivityWithFeature(
                    BackgroundChangeScreen.this,
                    CommonProcessing.class,
                    new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_CHANGE_BG)
            );
        }else {
            Toast.makeText(this,"Please connect to internet.",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Setting callback to this activity");
        // Set callback when activity resumes
        photoUploadManager.setCallback(this);

        // Check if we already have an image URI from a previous upload
        Uri existingUri = photoUploadManager.getCurrentImageUri();
        String uploadType = photoUploadManager.getCurrentUploadType();
        String feature = photoUploadManager.getCurrentFeature();

        if (existingUri != null && UPLOAD_BG_REMOVE.equals(uploadType) && AppConfig.FEATURE_CHANGE_BG.equals(feature)) {
            Log.d(TAG, "Found existing image URI: " + existingUri);
            onPhotoUploaded(existingUri, feature, uploadType);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Removing callback");
        // Remove callback when activity pauses
        if (photoUploadManager.getCallback() == this) {
            photoUploadManager.setCallback(null);
        }
    }

    @Override
    public void onPhotoUploaded(Uri imageUri, String feature, String uploadType) {
        Log.d(TAG, "onPhotoUploaded called - URI: " + imageUri + ", Feature: " + feature + ", Type: " + uploadType);

        if (UPLOAD_BG_REMOVE.equals(uploadType) && AppConfig.FEATURE_CHANGE_BG.equals(feature)) {
            runOnUiThread(() -> {
                Log.d(TAG, "Loading image into ImageView: " + imageUri);
                try {
                    Glide.with(this)
                            .load(imageUri.getPath())
                            .centerCrop()
                            .into(binding.singleImageView);
                    Log.d(TAG, "Glide image load attempted");
                } catch (Exception e) {
                    Log.e(TAG, "Error loading image with Glide: " + e.getMessage());
                    e.printStackTrace();
                }
            });
        } else {
            Log.d(TAG, "Upload type or feature mismatch. Expected: " + UPLOAD_BG_REMOVE + "/" + AppConfig.FEATURE_CHANGE_BG +
                    ", Got: " + uploadType + "/" + feature);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
        Log.d(TAG, "Activity destroyed");
    }

}