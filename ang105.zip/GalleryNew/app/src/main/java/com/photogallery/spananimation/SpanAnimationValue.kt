package com.photogallery.spananimation

import android.graphics.Bitmap
import android.view.View

internal class SpanAnimationValue(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val spanSize: Int,
    val spanIndex: Int,
    val spanGroupIndex: Int,
    val bitmap: Bitmap?,
    val viewType: Int,
    val canRecycle: Boolean,
    val layoutPosition: Int
) {
    val width = right - left
    val height = bottom - top

    var child: View? = null
        private set

    val isCalculated = bitmap == null

    fun attachChild(child: View) {
        require(!isCalculated) { "计算值child为null" }
        require(this.child == null) { "child只能被赋值一次" }
        this.child = child
    }

    fun recycle() {
        if (canRecycle) bitmap?.recycle()
    }
}