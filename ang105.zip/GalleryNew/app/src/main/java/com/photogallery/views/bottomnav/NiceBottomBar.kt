package com.photogallery.views.bottomnav

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.view.MotionEvent
import android.annotation.SuppressLint
import android.animation.ArgbEvaluator
import android.content.res.XmlResourceParser
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.photogallery.R
import com.photogallery.views.bottomnav.Constants.DEFAULT_TEXT_COLOR
import com.photogallery.views.bottomnav.Constants.DEFAULT_TEXT_COLOR_ACTIVE
import com.photogallery.views.bottomnav.Constants.WHITE_COLOR_HEX
import com.photogallery.views.bottomnav.BottomBarItem
import kotlin.math.abs

class NiceBottomBar : View {

    public interface OnItemListener {
        fun onItemLongClick(pos: Int)
        fun onItemReselect(pos: Int)
        fun onItemSelect(pos: Int)
    }

    private var barBackgroundColor = Color.parseColor(WHITE_COLOR_HEX)

    private var itemIconSize = d2p(18f)
    private var itemIconMargin = d2p(3f)
    private var itemTextColor = Color.parseColor(DEFAULT_TEXT_COLOR)
    private var itemTextColorActive = Color.parseColor(DEFAULT_TEXT_COLOR_ACTIVE)
    private var itemTextSize = d2p(11.0f)
    private var itemBadgeColor = itemTextColorActive
    private var itemFontFamily = 0
    private var activeItem = 0
//    private var capsuleAlpha = 0f
//    private var capsuleScale = 1f

    private var currentActiveItemColor = itemTextColorActive

    private var longPressTime = 500
    private val titleSideMargins = d2p(12f)

    private var items = listOf<BottomBarItem>()

    private var onItemSelectedListener: OnItemListener? = null

    var onItemSelected: (Int) -> Unit = {}
    var onItemReselected: (Int) -> Unit = {}
    var onItemLongClick: (Int) -> Unit = {}

//    private val paintIndicator = Paint().apply {
//        isAntiAlias = true
//        style = Paint.Style.STROKE
//        strokeWidth = 10f
//        color = barIndicatorColor
//        strokeCap = Paint.Cap.ROUND
//    }

    private val paintText = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = itemTextColor
        textSize = itemTextSize
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val paintBadge = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
        color = itemBadgeColor
        strokeWidth = 4f
    }

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        val typedArray = context.theme.obtainStyledAttributes(attrs, R.styleable.NiceBottomBar, 0, 0)
        barBackgroundColor = typedArray.getColor(R.styleable.NiceBottomBar_backgroundColor, this.barBackgroundColor)
//        barIndicatorColor = typedArray.getColor(R.styleable.NiceBottomBar_indicatorColor, this.barIndicatorColor)
//        barIndicatorWidth = typedArray.getDimension(R.styleable.NiceBottomBar_indicatorWidth, this.barIndicatorWidth)
//        barIndicatorEnabled = typedArray.getBoolean(R.styleable.NiceBottomBar_indicatorEnabled, this.barIndicatorEnabled)
        itemTextColor = typedArray.getColor(R.styleable.NiceBottomBar_textColor, this.itemTextColor)
        itemTextColorActive = typedArray.getColor(R.styleable.NiceBottomBar_textColorActive, this.itemTextColorActive)
        currentActiveItemColor = typedArray.getColor(R.styleable.NiceBottomBar_textColorActive, this.itemTextColorActive)
        itemTextSize = typedArray.getDimension(R.styleable.NiceBottomBar_textSize, this.itemTextSize)
        itemIconSize = typedArray.getDimension(R.styleable.NiceBottomBar_iconSize, this.itemIconSize)
        itemIconMargin = typedArray.getDimension(R.styleable.NiceBottomBar_iconMargin, this.itemIconMargin)
        activeItem = typedArray.getInt(R.styleable.NiceBottomBar_activeItem, this.activeItem)
//        barIndicatorInterpolator = typedArray.getInt(R.styleable.NiceBottomBar_indicatorInterpolator, this.barIndicatorInterpolator)
//        barIndicatorGravity = typedArray.getInt(R.styleable.NiceBottomBar_indicatorGravity, this.barIndicatorGravity)
        itemBadgeColor = typedArray.getColor(R.styleable.NiceBottomBar_badgeColor, this.itemBadgeColor)
        itemFontFamily = typedArray.getResourceId(R.styleable.NiceBottomBar_itemFontFamily, this.itemFontFamily)
//        items = BottomBarParser(context, typedArray.getResourceId(R.styleable.NiceBottomBar_menu, 0)).parse()
        items = parse(typedArray.getResourceId(R.styleable.NiceBottomBar_menu, 0))
        typedArray.recycle()

        setBackgroundColor(barBackgroundColor)

        // Update default attribute values
//        paintIndicator.color = barIndicatorColor
        paintText.color = itemTextColor
        paintText.textSize = itemTextSize
        paintBadge.color = itemBadgeColor

        if (itemFontFamily != 0)
            paintText.typeface = ResourcesCompat.getFont(context, itemFontFamily)
    }


    fun parse(menu: Int): List<BottomBarItem> {
        val parser: XmlResourceParser = context.resources.getXml(menu)
        val items: MutableList<BottomBarItem> = mutableListOf()
        var eventType: Int?

        do {
            eventType = parser.next()

            if (eventType == XmlResourceParser.START_TAG && parser.name == Constants.ITEM_TAG)
                items.add(getTabConfig(parser))

        } while (eventType != XmlResourceParser.END_DOCUMENT)

        return items.toList()
    }

    private fun getTabConfig1(parser: XmlResourceParser): BottomBarItem {
        val attributeCount = parser.attributeCount
        var itemText: String? = null
        var itemDrawable: Drawable? = null

        for (i in 0 until attributeCount)
            when (parser.getAttributeName(i)) {
                Constants.ICON_ATTRIBUTE -> itemDrawable =
                    ContextCompat.getDrawable(context, parser.getAttributeResourceValue(i, 0))

                Constants.TITLE_ATTRIBUTE -> {
                    itemText = try {
                        context.getString(parser.getAttributeResourceValue(i, 0))
                    } catch (e: Exception) {
                        parser.getAttributeValue(i)
                    }
                }
            }

        return BottomBarItem(itemText!!, itemDrawable!!, itemDrawable!!)
    }

    private fun getTabConfig(parser: XmlResourceParser): BottomBarItem {
        val attributeCount = parser.attributeCount
        var itemText: String? = null
        var iconDrawable: Drawable? = null
        var activeDrawable: Drawable? = null

        for (i in 0 until attributeCount) {
            when (parser.getAttributeName(i)) {
                Constants.ICON_ATTRIBUTE -> {
                    val resId = parser.getAttributeResourceValue(i, 0)
                    val drawable = ContextCompat.getDrawable(context, resId)

                    if (drawable is StateListDrawable) {
                        val tempCheckedState = intArrayOf(android.R.attr.state_checked)
                        val tempUncheckedState = intArrayOf(-android.R.attr.state_checked)

                        drawable.state = tempCheckedState
                        activeDrawable = drawable.current?.mutate()

                        drawable.state = tempUncheckedState
                        iconDrawable = drawable.current?.mutate()
                    } else {
                        iconDrawable = drawable?.mutate()
                        activeDrawable = drawable?.mutate()
                    }
                }

                Constants.TITLE_ATTRIBUTE -> {
                    itemText = try {
                        context.getString(parser.getAttributeResourceValue(i, 0))
                    } catch (e: Exception) {
                        parser.getAttributeValue(i)
                    }
                }
            }
        }

        return BottomBarItem(
            title = itemText ?: "",
            icon = iconDrawable ?: error("Missing icon"),
            activeIcon = activeDrawable ?: iconDrawable!!
        )
    }


//    private fun getTabConfig(parser: XmlResourceParser): BottomBarItem {
//        val attributeCount = parser.attributeCount
//        var itemText: String? = null
//        var iconDrawable: Drawable? = null
//
//        for (i in 0 until attributeCount) {
//            when (parser.getAttributeName(i)) {
//                Constants.TITLE_ATTRIBUTE -> {
//                    itemText = try {
//                        context.getString(parser.getAttributeResourceValue(i, 0))
//                    } catch (e: Exception) {
//                        parser.getAttributeValue(i)
//                    }
//                }
//                Constants.ICON_ATTRIBUTE -> {
//                    val drawableResId = parser.getAttributeResourceValue(i, 0)
//                    val stateListDrawable = ContextCompat.getDrawable(context, drawableResId)
//
//                    if (stateListDrawable is StateListDrawable) {
//                        val active = getDrawableForState(stateListDrawable, intArrayOf(android.R.attr.state_checked))
//                            ?: stateListDrawable
//                        val inactive = getDrawableForState(stateListDrawable, intArrayOf(-android.R.attr.state_checked))
//                            ?: stateListDrawable
//
//                        return BottomBarItem(
//                            title = itemText ?: "",
//                            icon = inactive.mutate(),
//                            activeIcon = active.mutate()
//                        )
//                    } else {
//                        iconDrawable = stateListDrawable
//                    }
//                }
//            }
//        }
//
//        // Fallback if not a selector
//        return BottomBarItem(
//            title = itemText!!,
//            icon = iconDrawable!!.mutate(),
//            activeIcon = iconDrawable.mutate()
//        )
//    }

    private fun getDrawableForState(drawable: StateListDrawable, state: IntArray): Drawable? {
        try {
            val stateDrawable = StateListDrawable::class.java.getDeclaredField("mStateListState")
            stateDrawable.isAccessible = true
            val constantState = stateDrawable.get(drawable)

            val getChildrenMethod = constantState.javaClass.getDeclaredMethod("getChildren")
            getChildrenMethod.isAccessible = true
            val children = getChildrenMethod.invoke(constantState) as Array<Drawable>

            val getStateSetsMethod = constantState.javaClass.getDeclaredMethod("getStateSets")
            getStateSetsMethod.isAccessible = true
            val stateSets = getStateSetsMethod.invoke(constantState) as Array<IntArray>

            for (i in stateSets.indices) {
                if (stateSets[i].contentEquals(state)) {
                    return children[i]
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }


    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        var lastX = 0f
        val itemWidth = width / items.size

        for (item in items) {
            // Prevent text overflow by shortening the item title
            var shorted = false
            while (paintText.measureText(item.title) > (itemWidth - titleSideMargins)) {
                item.title = item.title.dropLast(1)
                shorted = true
            }

            // Add ellipsis character to item text if it is shorted
            if (shorted) {
                item.title = item.title.dropLast(1)
                item.title += "…"
            }

            item.rect = RectF(lastX, 0f, itemWidth + lastX, height.toFloat())
            lastX += itemWidth
        }

        // Set initial active item
        setActiveItem(activeItem)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val textHeight = (paintText.descent() + paintText.ascent()) / 2

        // Push the item components from the top a bit if the indicator is at the top
//        val additionalTopMargin = if (barIndicatorGravity == 1) 0f else 10f
        val additionalTopMargin = 10f

        for ((i, item) in items.withIndex()) {

            val iconToDraw = if (i == activeItem) item.activeIcon else item.icon

            iconToDraw.mutate()
            iconToDraw.setBounds(
                item.rect.centerX().toInt() - itemIconSize.toInt() / 2,
                height / 2 - itemIconSize.toInt() - itemIconMargin.toInt() / 2 + additionalTopMargin.toInt(),
                item.rect.centerX().toInt() + itemIconSize.toInt() / 2,
                height / 2 - itemIconMargin.toInt() / 2 + additionalTopMargin.toInt()
            )

            DrawableCompat.setTint(iconToDraw, if (i == activeItem) currentActiveItemColor else itemTextColor)


            iconToDraw.draw(canvas)

            // Draw item title
            this.paintText.color = if (i == activeItem) currentActiveItemColor else itemTextColor
            canvas.drawText(
                item.title, item.rect.centerX(),
                item.rect.centerY() - textHeight + itemIconSize / 2 + (this.itemIconMargin / 2) + additionalTopMargin, paintText
            )

            // Draw item badge
            if (item.badgeSize > 0)
                drawBadge(canvas, item)

            // Draw capsule background behind active icon
//            if (i == activeItem) {
////                val capsuleWidth = (itemIconSize + d2p(16f)) * capsuleScale
////                val capsuleHeight = (itemIconSize + d2p(8f)) * capsuleScale
//                val capsuleWidth = itemIconSize * 2.3f * capsuleScale
//                val capsuleHeight = itemIconSize * 1.2f * capsuleScale
//
//                val verticalPadding = d2p(3f) // You can adjust this value
//
//                val capsuleRect = RectF(
//                    item.rect.centerX() - capsuleWidth / 2,
//                    height / 2 - itemIconSize - itemIconMargin / 2 + additionalTopMargin - verticalPadding,
//                    item.rect.centerX() + capsuleWidth / 2,
//                    height / 2 - itemIconMargin / 2 + additionalTopMargin + verticalPadding
//                )
//
//                val capsulePaint = Paint().apply {
//                    isAntiAlias = true
//                    style = Paint.Style.FILL
//                    color = currentActiveItemColor
//                    alpha = (255 * 0.3f * capsuleAlpha).toInt()  // Animate 30% opacity
//                }
//
//                canvas.drawRoundRect(capsuleRect, capsuleHeight / 2, capsuleHeight / 2, capsulePaint)
//            }


        }

        // Draw indicator
//        if (barIndicatorEnabled)
//            canvas.drawLine(indicatorLocation - barIndicatorWidth/2, (if (barIndicatorGravity == 1) height - 5.0f else 5f),
//                indicatorLocation + barIndicatorWidth/2, (if (barIndicatorGravity == 1) height - 5.0f else 5f), paintIndicator)
    }

    // Handle item clicks
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP && abs(event.downTime - event.eventTime) < longPressTime)
            for ((i, item) in items.withIndex())
                if (item.rect.contains(event.x, event.y))
                    if (i != this.activeItem) {
                        setActiveItem(i)
                        onItemSelected(i)
                        onItemSelectedListener?.onItemSelect(i)
                    } else {
                        onItemReselected(i)
                        onItemSelectedListener?.onItemReselect(i)
                    }

        if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_UP)
            if (abs(event.downTime - event.eventTime) > longPressTime)
                for ((i, item) in items.withIndex())
                    if (item.rect.contains(event.x, event.y)) {
                        onItemLongClick(i)
                        onItemSelectedListener?.onItemLongClick(i)
                    }

        return true
    }

    // Draw item badge
    private fun drawBadge(canvas: Canvas, item: BottomBarItem) {
        paintBadge.style = Paint.Style.FILL
        paintBadge.color = itemTextColorActive

        canvas.drawCircle(
            item.rect.centerX() + itemIconSize / 2 - 4,
            (height / 2).toFloat() - itemIconSize - itemIconMargin / 2 + 10, item.badgeSize, paintBadge
        )

        paintBadge.style = Paint.Style.STROKE
        paintBadge.color = barBackgroundColor

        canvas.drawCircle(
            item.rect.centerX() + itemIconSize / 2 - 4,
            (height / 2).toFloat() - itemIconSize - itemIconMargin / 2 + 10, item.badgeSize, paintBadge
        )
    }

    // Add item badge
    fun setBadge(pos: Int) {
        if (pos > 0 && pos < items.size && items[pos].badgeSize == 0f) {
            val animator = ValueAnimator.ofFloat(0f, 15f)
            animator.duration = 100
            animator.addUpdateListener { animation ->
                items[pos].badgeSize = animation.animatedValue as Float
                invalidate()
            }
            animator.start()
        }
    }

    // Remove item badge
    fun removeBadge(pos: Int) {
        if (pos > 0 && pos < items.size && items[pos].badgeSize > 0f) {
            val animator = ValueAnimator.ofFloat(items[pos].badgeSize, 0f)
            animator.duration = 100
            animator.addUpdateListener { animation ->
                items[pos].badgeSize = animation.animatedValue as Float
                invalidate()
            }
            animator.start()
        }
    }

    fun getActiveItem(): Int {
        return activeItem
    }

    fun setActiveItem(pos: Int) {
        activeItem = pos
        // Removed setItemColors()// — no animation needed
        animateCapsule()
        //onItemSelectedListener?.onItemSelect(pos)
        invalidate()
    }

//    fun setActiveItem(pos: Int) {
//        activeItem = pos
//        setItemColors()
//        animateCapsule()
//        invalidate()
//    }


    private fun animateCapsule() {
//        val animator = ValueAnimator.ofFloat(0f, 1f)
//        animator.duration = 200
//        animator.interpolator = DecelerateInterpolator()
//        animator.addUpdateListener {
//            capsuleAlpha = it.animatedValue as Float
//            capsuleScale = 0.8f + 0.2f * capsuleAlpha  // Slight pop scale effect
//            invalidate()
//        }
//        animator.start()
    }


    // Apply transition animation to item color
    private fun setItemColors() {
        val animator = ValueAnimator.ofObject(ArgbEvaluator(), itemTextColor, itemTextColorActive)
        animator.addUpdateListener { currentActiveItemColor = it.animatedValue as Int }
        animator.start()
    }

    private fun d2p(dp: Float): Float {
        return resources.displayMetrics.densityDpi.toFloat() / 160.toFloat() * dp
    }

    fun setOnItemSelectedListener(listener: OnItemListener) {
        this.onItemSelectedListener = listener
    }

//    fun setOnItemReselectedListener(listener: OnItemReselectedListener) {
//        this.onItemReselectedListener = listener
//    }
//
//    fun setOnItemLongClickListener(listener: OnItemLongClickListener) {
//        this.onItemLongClickListener = listener
//    }
}