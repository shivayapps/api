package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.content.Context.LAYOUT_INFLATER_SERVICE
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager

import com.photogallery.databinding.DialogPdfOptionBinding
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.Preferences


class PdfOptionDialog(var mContext: Context, val clickListener: (type: Int) -> Unit) {

    lateinit var bindingDialog: DialogPdfOptionBinding
    lateinit var popupWindow: PopupWindowHelper
    fun show(anchorView: View) {
        val layoutInflater = mContext.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        bindingDialog = DialogPdfOptionBinding.inflate(layoutInflater)
        popupWindow = PopupWindowHelper(bindingDialog.root)

        popupWindow.showPopup(mContext, anchorView)
        intView()
    }

    fun dismiss() {
        popupWindow.dismiss()
    }

    private fun intView() {
        intListener()
        setView()
    }

    private fun setView() {

    }

    private fun intListener() {
        bindingDialog.btnShare.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        bindingDialog.btnPrint.setOnClickListener {
            dismiss()
            clickListener(2)
        }
        bindingDialog.btnDelete.setOnClickListener {
            dismiss()
            clickListener(3)
        }
    }

}