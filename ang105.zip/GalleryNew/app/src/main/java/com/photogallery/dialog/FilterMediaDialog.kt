package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogFilterMediaBinding
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.getDefaultFileFilter

class FilterMediaDialog(
    val activity: Activity,
    val updateListener: () -> Unit
) : Dialog(activity) {

    lateinit var bindingDialog: DialogFilterMediaBinding
    lateinit var preferences: Preferences
    var filterMedia = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogFilterMediaBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        AdsConfig.isSystemDialogOpen = true
//        isExitDialogOpen = true
        intView()
    }

    private fun intView() {
        preferences = Preferences(activity)
        filterMedia = preferences.getFilterMedia()

        intListener()
        bindingDialog.cbImages.isChecked = filterMedia and TYPE_IMAGES != 0
        bindingDialog.cbVideos.isChecked = filterMedia and TYPE_VIDEOS != 0
        bindingDialog.cbGif.isChecked = filterMedia and TYPE_GIFS != 0
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {

            var result = 0
            if (bindingDialog.cbImages.isChecked)
                result += TYPE_IMAGES
            if (bindingDialog.cbVideos.isChecked)
                result += TYPE_VIDEOS
            if (bindingDialog.cbGif.isChecked)
                result += TYPE_GIFS
//            if (bindingDialog.cbRaw.isChecked)
//                result += TYPE_RAWS
//            if (bindingDialog.cbSvgs.isChecked)
//                result += TYPE_SVGS
//            if (bindingDialog.cbPortraits.isChecked)
//                result += TYPE_PORTRAITS


            if (result == 0) {
                result = getDefaultFileFilter()
            }

            if (filterMedia != result) {
                preferences.setFilterMedia(result)
                updateListener.invoke()
            }
            dismiss()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}