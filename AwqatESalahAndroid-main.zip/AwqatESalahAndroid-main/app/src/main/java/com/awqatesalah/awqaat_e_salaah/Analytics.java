package com.awqatesalah.awqaat_e_salaah;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;

import com.google.firebase.analytics.FirebaseAnalytics;

public class Analytics {

    static public String PAGE_HOME_PAGE = "page_home";
    static public String PAGE_SEARCH_RESULTS = "page_search_results";
    static public String PAGE_MASJID_DETAILS = "page_masjid_details";
    static public String PAGE_MASJID_MAP = "page_masjid_map";
    static public String PAGE_BAYAAN_WEEKLY= "page_bayaan_weekly";
    static public String PAGE_BAYAAN_JUMUAH= "page_bayaan_jumuah";
    static public String PAGE_BAYAAN_OTHER= "page_bayaan_other";
    static public String PAGE_ACCOUNTS_DASHBOARD= "page_account_dashboard";
    static public String PAGE_ADMIN_MASJID_LIST= "page_admins_masjid_list";
    static public String PAGE_ADMIN_MASJID_DETAILS= "page_admins_masjid_details";
    static public String PAGE_ADMIN_PROFILE= "page_admins_profile";
    static public String PAGE_ADD_NEW_MASJID= "page_add_new_masjid";
    static public String PAGE_ADD_MASJID_LOCATION= "page_add_masjid_location";
    static public String PAGE_TAQEEEM= "page_taqweem";
    static public String PAGE_TAQEEEM_NOTES= "page_taqweem_notes";
    static public String PAGE_FAVOURITES= "page_favorites";
    static public String PAGE_NOTIFICATIONS_LIST= "page_notifications_list";
    static public String PAGE_NOTIFICATION_DETAILS= "page_notification_details";
    static public String PAGE_FEEDBACK= "page_feedback";
    static public String PAGE_HELP= "page_help";
    static public String PAGE_CONTACT_US= "page_contact_us";
    static public String PAGE_ABOUT_US= "page_about_us";
    static public String PAGE_PRIVACY= "page_privacy";
    static public String PAGE_TERMS= "page_terms";


    private FirebaseAnalytics mFirebaseAnalytics;

    @SuppressLint("MissingPermission")
    public Analytics(Context context){
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(context);
    }

    public void screenViewEvent(String screenName){
        mFirebaseAnalytics.logEvent(screenName,null);
    }

    //---------------------HOME-----------------------//

    public void logAreaWishSearchEvent(String areaName,String areaId){
        Bundle bundle = new Bundle();
        bundle.putString("areaName", areaName);
        bundle.putString("areaId", areaId);
        mFirebaseAnalytics.logEvent("area_wise_search", bundle);
    }

    public void logNearBySearchEvent(double latitude,double longitude){
        Bundle bundle = new Bundle();
        bundle.putDouble("latitude", latitude);
        bundle.putDouble("longitude", longitude);
        mFirebaseAnalytics.logEvent("nearby_search", bundle);
    }

    //---------------------Masjid List-----------------------//

    public void logMasjidSortByNameEvent(String namaazName){
        Bundle bundle = new Bundle();
        bundle.putString("namaazName", namaazName);
        mFirebaseAnalytics.logEvent("masjids_sort_by_namaaz", bundle);
    }

    public void logMasjidFilterClickEvent(){
        mFirebaseAnalytics.logEvent("masjids_filter_click", null);
    }

    public void logMasjidsFilterApplyEvent(String areaName,String namaazTime){
        Bundle bundle = new Bundle();
        bundle.putString("areaName", areaName);
        bundle.putString("namaazTime", namaazTime);
        mFirebaseAnalytics.logEvent("masjids_apply_filter", bundle);
    }

    public void logMasjidsSearchBarButtonClickEvent(){
        mFirebaseAnalytics.logEvent("masjids_search_bar_button_click", null);
    }

    public void logMasjidsItemLocationClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_item_see_location", null);
    }

    public void logMasjidsItemAddFavEvent(){
        mFirebaseAnalytics.logEvent("masjid_item_add_favorite", null);
    }

    public void logMasjidsItemRemoveFavEvent(){
        mFirebaseAnalytics.logEvent("masjid_item_remove_favorite", null);
    }

    //---------------------Masjid Details-----------------------//

    public void logMasjidDetailsSuggestTimeEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_suggest_time_click", null);
    }

    public void logMasjidDetailsSendSuggestionEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_send_suggestion", null);
    }

    public void logMasjidDetailsBecomeAdminClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_become_admin_click", null);
    }

    public void logMasjidDetailsBecomeAdminReqEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_send_become_admin_request", null);
    }

    public void logMasjidDetailsAddressClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_address_click", null);
    }

    public void logMasjidDetailsWebsiteClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_website_click", null);
    }

    public void logMasjidDetailsContactNoClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_contact_no_click", null);
    }

    //CAN'T DO IT BECAUSE OF LAYOUT (AS PLUS ICON CLICK CAN'T BE OVERRIDEN)
    public void logMasjidDetailsPlusIconClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_plus_click", null);
    }

    public void logMasjidDetailsPLusIconShareClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_plus_share_click", null);
    }

    public void logMasjidDetailsPLusIconLocationClickEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_plus_location_click", null);
    }

    //THIS FEATURE HAS NOT YET IMPLEMENTED
    public void logMasjidDetailsAddFavEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_add_favorite", null);
    }

    //THIS FEATURE HAS NOT YET IMPLEMENTED
    public void logMasjidDetailsRemoveFavEvent(){
        mFirebaseAnalytics.logEvent("masjid_details_remove_favorite", null);
    }

    //---------------------BAYAAN-----------------------//

    public void logBayaanAreaSelectEvent(String areaName,String areaId){
        Bundle bundle = new Bundle();
        bundle.putString("areaName", areaName);
        bundle.putString("areaId", areaId);
        mFirebaseAnalytics.logEvent("bayaan_area_click", bundle);
    }


    //---------------------ADMIN ACCOUNT DASHBOARD-----------------------//

    public void logMasjidAdminTimeUpdatedEvent(){
        mFirebaseAnalytics.logEvent("masjidadmin_time_updated", null);
    }

    public void logMasjidAdminAddNewMasjidEvent(String areaName,String areaId){
        Bundle bundle = new Bundle();
        bundle.putString("areaName", areaName);
        bundle.putString("areaId", areaId);
        mFirebaseAnalytics.logEvent("masjidadmin_add_new_masjid", bundle);
    }

    public void logMasjidAdminUpdateProfileEvent(){
        mFirebaseAnalytics.logEvent("masjidadmin_update_profile", null);
    }

    //THIS FEATURE IS NOT IMPLEMENTED
    public void logMasjidAdminDeleteAccountClickEvent(){
        mFirebaseAnalytics.logEvent("masjidadmin_delete_account_click", null);
    }

    //THIS FEATURE IS NOT IMPLEMENTED
    public void logMasjidAdminDeleteAccountYesEvent(){
        mFirebaseAnalytics.logEvent("masjidadmin_delete_account_yes", null);
    }

    //THIS FEATURE IS NOT IMPLEMENTED
    public void logMasjidAdminDeleteAccountNoEvent(){
        mFirebaseAnalytics.logEvent("masjidadmin_delete_account_no", null);
    }

    public void logMasjidAdminAddNewLocationEvent(){
        mFirebaseAnalytics.logEvent("masjidadmin_add_new_location", null);
    }

    //---------------------TAQWEEM-----------------------//

    public void logTaqweemMaslakChangeEvent(String maslakName){
        Bundle bundle = new Bundle();
        bundle.putString("maslakName", maslakName);
        mFirebaseAnalytics.logEvent("taqweem_maslak_change", bundle);
    }

    public void logTaqweemRefreshClickEvent(){
        mFirebaseAnalytics.logEvent("taqweem_refresh_click", null);
    }

    public void logTaqweemNotesClickEvent(){
        mFirebaseAnalytics.logEvent("taqweem_notes_click", null);
    }

    //---------------------FEEDBACK-----------------------//

    public void logFeedbackSendEvent(){
        mFirebaseAnalytics.logEvent("send_feedback", null);
    }

    //---------------------LOGOUT-----------------------//

    public void logLogoutDrawerPressEvent(){
        mFirebaseAnalytics.logEvent("logout_press", null);
    }

    public void logLogoutDialogYesEvent(){
        mFirebaseAnalytics.logEvent("logout_yes", null);
    }

    public void logLogoutDialogNoEvent(){
        mFirebaseAnalytics.logEvent("logout_no", null);
    }

    //---------------------NAV BAR ITEMS-----------------------//

    public void logNavBarLocationClickEvent(){
        mFirebaseAnalytics.logEvent("navbar_location", null);
    }

    public void logNavBarNotificationsClickEvent(){
        mFirebaseAnalytics.logEvent("navbar_notifications", null);
    }

    public void logNavBarShareClickEvent(){
        mFirebaseAnalytics.logEvent("navbar_share", null);
    }

    //---------------------DRAWER-----------------------//
    public void logDrawerShareEvent(){
        mFirebaseAnalytics.logEvent("drawer_share", null);
    }
}
