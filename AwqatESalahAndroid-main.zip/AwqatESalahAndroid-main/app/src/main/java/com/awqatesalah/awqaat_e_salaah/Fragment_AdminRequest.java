package com.awqatesalah.awqaat_e_salaah;

/**
 * Created by root on 29/12/16.
 */

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.rengwuxian.materialedittext.MaterialEditText;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/21/2016.
 */
public class Fragment_AdminRequest extends GATrackingFragment {
    private FancyButton send;
    private MaterialEditText message;
    private SpotsDialog dialog;
    MySharedPrefrences sharedPrefrences;
    String masjidAdminID;
    String masjidID;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.fragment_adminrequest, container, false);
        send = (FancyButton) view.findViewById(R.id.send);
        message = (MaterialEditText) view.findViewById(R.id.message);
       dialog = new SpotsDialog(getActivity(),R.style.main);
        dialog.setCancelable(false);
        sharedPrefrences = new MySharedPrefrences(getActivity());
        masjidAdminID = sharedPrefrences.getData("MasjidAdminID");

        if(getArguments()!=null)
        {
            message.setText(getArguments().getString("message").toString());
            masjidID = getArguments().getString("masjidID");
        }

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Admin Request");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsBecomeAdminReqEvent();

                if (!message.getText().toString().equals("")) {
                    dialog.show();
                    CallRetroApi feedback_api = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                    Call<Update_Response> call = feedback_api.newBecomeAdminRequest(StaticFunction.getValue("}6Hq64@>6p5>:?#6BF6DE"),masjidAdminID, masjidID, getValue(message));
                    call.enqueue(new Callback<Update_Response>() {
                        @Override
                        public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                            if (response.body().getSuccess().toString().equals("true")) {
                                Log.d("admin_request_response", response.body().getMessage());
                                new MaterialDialog.Builder(getActivity()).title("Admin Request Done")
                                        .content("We have received your request and we will respond you soon").positiveText("Jazakallah").show();
                                //getAlldata
                                View view = getActivity().getCurrentFocus();
                                if (view != null) {
                                    InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                }
                                message.setText("");
                                dialog.dismiss();
                                getActivity().getFragmentManager().popBackStack();

                            } else {
                                dialog.dismiss();
                                new MaterialDialog.Builder(getActivity()).title("Error")
                                        .content(response.body().getMessage()).positiveText("Try Again").show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Update_Response> call, Throwable t) {
                            StaticFunction.NoConnectionDialog(getActivity());
                            dialog.dismiss();
                        }
                    });
                } else {
                    if (message.getText().toString().equals("")) {
                        message.setError("Please write something to us");
                    }
                }
            }
        });


        return view;
    }
    public String getValue(EditText text)
    {
        return text.getText().toString().trim();
    }
}
