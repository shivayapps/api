package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.database.DataSetObserver;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Adapters.ChatAdapter;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.ChatMessage;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Chat_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Register_Response;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Fragment_Chat extends GATrackingFragment {
    String MasjidAdminID = "";
    MyTimerTask myTimerTask;
    ProgressBar progressBar;
    private EditText messageET;
    private ListView messagesContainer;
    ;
    private FancyButton sendBtn;
    private ChatAdapter adapter;
    private ArrayList<ChatMessage> chatHistory = new ArrayList<ChatMessage>();
    private View view=null;
    Timer myTimer;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.chat_fragment,container,false);

        MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());
        shared.saveMessageCount(0);
        MasjidAdminID =(shared.getData("MasjidAdminID").toString());
        initControls();
        startTimer();
        adapter = new ChatAdapter(getActivity(), chatHistory);
        messagesContainer.setAdapter(adapter);

        return view;
    }

    private void startTimer() {
        myTimer = new Timer();
        myTimerTask= new MyTimerTask();
        myTimer.scheduleAtFixedRate(myTimerTask, 0, 15000);

    }

    private void cancelTimer(){
        myTimer.cancel();
        myTimerTask.cancel();
    }



    private void initControls() {
        messagesContainer = (ListView) view.findViewById(R.id.messagesContainer);
        messageET = (EditText) view.findViewById(R.id.messageEdit);
        sendBtn = (FancyButton) view.findViewById(R.id.chatSendButton);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);

        messagesContainer.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        RelativeLayout container = (RelativeLayout) view.findViewById(R.id.container);
        getToolbar();
        // loadDummyHistory();

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageText = messageET.getText().toString();
                if (TextUtils.isEmpty(messageText)) {
                    return;
                }
                Log.d("Chat","Msgs Sending");

                cancelTimer();
                ChatMessage chatMessage = new ChatMessage("122",true,messageText,DateFormat.getDateTimeInstance().format(new Date()),"BYMe");
                /*chatMessage.setId(122);//dummy
                chatMessage.setMessage(messageText);
                chatMessage.setDate(DateFormat.getDateTimeInstance().format(new Date()));
                chatMessage.setMe(true);*/

                CallRetroApi call_register = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                Call<Register_Response> call1 = call_register.sendmessage(StaticFunction.getValue("$6?5|6DD286"), MasjidAdminID, messageText);

                call1.enqueue(new Callback<Register_Response>() {
                    @Override
                    public void onResponse(Call<Register_Response> call, Response<Register_Response> response) {
                        startTimer();
                        Log.d("Chat","Msgs Sending Response");

                        if(response.body().getSuccess().equals("true")) {
                            Log.d("chat_response", response.body().getMessage());
                        }
                        else
                        {
                            new MaterialDialog.Builder(getActivity()).title("Error")
                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Register_Response> call, Throwable t) {
                        startTimer();
                        if(!t.getMessage().equals("timeout")) {
                            StaticFunction.NoConnectionDialog(getActivity());
                        }else{
                            Log.d("Chat","Msgs Sending Response Timeout");

                        }
                    }
                });
                messageET.setText("");

                displayMessage(chatMessage);
            }
        });
    }

    public void displayMessage(ChatMessage message) {
        adapter.add(message);
        adapter.notifyDataSetChanged();

        adapter.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                messagesContainer.setSelection(adapter.getCount() - 1);
            }
        });
    }

  /* private void scroll() {
        messagesContainer.setSelection(chatHistory.size());
    }*/

    private void loadDummyHistory(){




       /* ChatMessage msg1 = new ChatMessage();
        msg1.setId(2);
        msg1.setMe(false);
        msg1.setMessage("How r u doing???");
        msg1.setDate(DateFormat.getDateTimeInstance().format(new Date()));
        chatHistory.add(msg1);*/


        CallRetroApi call_register = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
        Call<Chat_Response> call1 = call_register.getMess(StaticFunction.getValue("v6E|6DD286Du@C|2D;:5p5>:?"), MasjidAdminID);

        call1.enqueue(new Callback<Chat_Response>() {
            @Override
            public void onResponse(Call<Chat_Response> call, Response<Chat_Response> response) {
                if(response!=null && response.body()!=null) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("DONE", response.body().getMessage());
                        chatHistory.clear();
                        chatHistory.add(new ChatMessage("12314", false, "Assalamulaikum,keep your message here,we will contact you soon", "5 September,2016", "Admin"));
                        for (int i = 0; i < response.body().getResultData().length; i++) {

               /*         msg3.setId(Long.parseLong(response.body().getResultData()[i].getMessageID()));
                        msg3.setMe(false);
                        msg3.setMessage(response.body().getResultData()[i].getMessage());
                        msg3.setDate(response.body().getResultData()[i].getAddedOn());*/
                            chatHistory.add(new ChatMessage(response.body().getResultData()[i].getMessageID(), false, response.body().getResultData()[i].getMessage(), response.body().getResultData()[i].getAddedOn(), response.body().getResultData()[i].getSentBy()));

                        }
                        adapter.notifyDataSetChanged();

                   /* for(int i=0; i<chatHistory.size(); i++) {
                        ChatMessage message = chatHistory.get(i);
                        displayMessage(message);
                    }*/
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                    }
                }else{
                    StaticFunction.NoConnectionDialog(getActivity());
                }

            }

            @Override
            public void onFailure(Call<Chat_Response> call, Throwable t) {
                StaticFunction.NoConnectionDialog(getActivity());
            }
        });




    }

    @Override
    public void onPause() {
        super.onPause();
        myTimerTask.cancel();
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Admin Chat");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private class MyTimerTask extends TimerTask {
        @Override
        public void run() {
            //get and send location information
            Log.d("Chat","Getting msgs");
            CallRetroApi call_register = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
            Call<Chat_Response> call1 = call_register.getMess(StaticFunction.getValue("v6E|6DD286Du@C|2D;:5p5>:?")
                    ,MasjidAdminID);

            call1.enqueue(new Callback<Chat_Response>() {
                @Override
                public void onResponse(Call<Chat_Response> call, Response<Chat_Response> response) {
                    progressBar.setVisibility(View.GONE);
                    Log.d("Chat","Msgs get successfull");

                    if(response!=null && response.body()!=null) {

                        if (response.body().getSuccess().equals("true")) {
                            Log.d("DONE", response.body().getMessage());
                            chatHistory.clear();
                            for (int i = 0; i < response.body().getResultData().length; i++) {
               /*         msg3.setId(Long.parseLong(response.body().getResultData()[i].getMessageID()));
                        msg3.setMe(false);
                        msg3.setMessage(response.body().getResultData()[i].getMessage());
                        msg3.setDate(response.body().getResultData()[i].getAddedOn());*/
                                chatHistory.add(new ChatMessage(response.body().getResultData()[i].getMessageID(), false, response.body().getResultData()[i].getMessage(), response.body().getResultData()[i].getAddedOn(), response.body().getResultData()[i].getSentBy()));

                            }
                            adapter.notifyDataSetChanged();
                            messagesContainer.setSelection(adapter.getCount() - 1);
                   /* for(int i=0; i<chatHistory.size(); i++) {
                        ChatMessage message = chatHistory.get(i);
                        displayMessage(message);
                    }*/
                        } else {
                            new MaterialDialog.Builder(getActivity()).title("Error")
                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                        }
                    }else{

                        StaticFunction.NoConnectionDialog(getActivity());
                    }

                }

                @Override
                public void onFailure(Call<Chat_Response> call, Throwable t) {
                    progressBar.setVisibility(View.GONE);
                    if(!t.getMessage().equals("timeout")) {
                        StaticFunction.NoConnectionDialog(getActivity());
                    }else{
                        Log.d("Chat","msg receiving timeout");
                    }
                }
            });
        }
    }
}
