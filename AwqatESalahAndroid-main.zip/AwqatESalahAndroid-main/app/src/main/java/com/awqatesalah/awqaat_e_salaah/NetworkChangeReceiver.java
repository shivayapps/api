package com.awqatesalah.awqaat_e_salaah;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.Search.Models.SuggestTimeResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 11/13/2016.
 */
public class NetworkChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, final Intent intent) {

        String status = NetworkUtil.getConnectivityStatusString(context);

        if(status.equals("Wifi enabled"))
        {
            //do the pending Transitions Here
            getPendingSuggestion(context);
            getPendingUpdates(context);

        }else if(status.equals("Mobile data enabled"))
        {
            //do the pending Transitions Here
            getPendingSuggestion(context);
            getPendingUpdates(context);
        }

    }

    private void getPendingUpdates(final Context context) {
        String count="0";
        final DBHelper dbHelper = new DBHelper(context);
        dbHelper.openDB();
        Cursor cursor = dbHelper.getPendingAdminUpdate("pending");
        if(cursor.getCount()>0)
        {
            for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
                CallRetroApi get = new RetroFitServiceGenerator(context).createServiceNoCache(CallRetroApi.class);
                final String masjid_id=cursor.getString(cursor.getColumnIndex(DBHelper.MASJID_ID));
                final String adminId=cursor.getString(cursor.getColumnIndex(DBHelper.ADMIN_USER_ID));
                String fajr = cursor.getString(cursor.getColumnIndex(DBHelper.FAJR));
                String isha = cursor.getString(cursor.getColumnIndex(DBHelper.ISHA));
                String zuhr = cursor.getString(cursor.getColumnIndex(DBHelper.ZUHR));
                String asr = cursor.getString(cursor.getColumnIndex(DBHelper.ASR));
                String maghrib = cursor.getString(cursor.getColumnIndex(DBHelper.MAGHRIB));
                String jumuah = cursor.getString(cursor.getColumnIndex(DBHelper.JUMUAH));
                String eid = cursor.getString(cursor.getColumnIndex(DBHelper.EID));
                String lastupdate =  cursor.getString(cursor.getColumnIndex(DBHelper.LASTUPDATED));

                Call<Update_Response> call1 = get.Update_Time(StaticFunction.getValue("&A52E6|2D;:5%:>:?8D"), adminId, masjid_id, "", "", "", "", "", "", fajr, zuhr, asr, maghrib, isha, jumuah,eid, lastupdate);

                call1.enqueue(new Callback<Update_Response>() {
                    @Override
                    public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                        if (response.body().getSuccess().equals("true")) {
                            Log.d("offline_time_response", response.body().getMessage());
                            Toast.makeText(context,"Time Updated Succesfully",Toast.LENGTH_LONG);
                            long resultupdate = dbHelper.Adminupdate_status(Integer.parseInt(masjid_id),"accepted");
                            if(resultupdate==1)
                            {
                                Toast.makeText(context,"Status Updated",Toast.LENGTH_LONG);
                            }
                        }
                        else {

                        }
                    }

                    @Override
                    public void onFailure(Call<Update_Response> call, Throwable t) {

                    }
                });
            }
        }
        else
        {
            dbHelper.closeDB();
        }

    }

    public  void getPendingSuggestion(final Context context)
    {
        MySharedPrefrences sharedPrefrences = MySharedPrefrences.getInstance(context);
        String masjidAdminID = sharedPrefrences.getData("MasjidAdminID");
        String count="0";
        final DBHelper dbHelper = new DBHelper(context);
        dbHelper.openDB();
        Cursor cursor = dbHelper.getPendingSuggestion("pending");
        if(cursor.getCount()>0)
        {
            for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){

                CallRetroApi get = new RetroFitServiceGenerator(context).createServiceNoCache(CallRetroApi.class);
                final String masjid_id=cursor.getString(cursor.getColumnIndex(DBHelper.MASJID_ID));
                String name = cursor.getString(cursor.getColumnIndex(DBHelper.SUGGESTER_NAME));
                String number = cursor.getString(cursor.getColumnIndex(DBHelper.SUGGESTER_NUMBER));
                String fajr = cursor.getString(cursor.getColumnIndex(DBHelper.FAJR));
                String isha = cursor.getString(cursor.getColumnIndex(DBHelper.ISHA));
                String zuhr = cursor.getString(cursor.getColumnIndex(DBHelper.ZUHR));
                String asr = cursor.getString(cursor.getColumnIndex(DBHelper.ASR));
                String maghrib = cursor.getString(cursor.getColumnIndex(DBHelper.MAGHRIB));
                String jumuah = cursor.getString(cursor.getColumnIndex(DBHelper.JUMUAH));
                String eid = cursor.getString(cursor.getColumnIndex(DBHelper.EID));
                String lastupdate =  cursor.getString(cursor.getColumnIndex(DBHelper.LASTUPDATED));

                Call<SuggestTimeResponse> call1 = get.suggest_Time(StaticFunction.getValue("$F886DE%:>6"),masjidAdminID, masjid_id, "", "", "", "", "", "", fajr, zuhr, asr, maghrib, isha, jumuah, eid,name + " " + lastupdate, number);

                call1.enqueue(new Callback<SuggestTimeResponse>() {
                    @Override
                    public void onResponse(Call<SuggestTimeResponse> call, Response<SuggestTimeResponse> response) {
                        if (response.body().getSuccess().equals("true")) {
                            Log.d("offline_time_response", response.body().getMessage());
                            Toast.makeText(context,"Time Suggested Succesfully",Toast.LENGTH_LONG);
                            long resultupdate = dbHelper.update_status(Integer.parseInt(masjid_id),"accepted");
                            if(resultupdate==1)
                            {
                                Toast.makeText(context,"Status Updated",Toast.LENGTH_LONG);
                            }
                        }
                        else {

                            }
                    }

                    @Override
                    public void onFailure(Call<SuggestTimeResponse> call, Throwable t) {

                    }
                });
            }
        }
       else
        {
            dbHelper.closeDB();
        }

    }

}