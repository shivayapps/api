package com.awqatesalah.awqaat_e_salaah.Bayaan.Model;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Other_Jumuah_Model {
    private String content;

    public Other_Jumuah_Model(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
