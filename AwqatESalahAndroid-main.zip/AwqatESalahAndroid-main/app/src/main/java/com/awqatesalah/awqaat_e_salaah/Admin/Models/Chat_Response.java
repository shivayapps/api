package com.awqatesalah.awqaat_e_salaah.Admin.Models;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Chat_Response
{
    private ResultData[] ResultData;

    private String Count;

    private String Message;

    private String Success;

    public ResultData[] getResultData ()
    {
        return ResultData;
    }

    public void setResultData (ResultData[] ResultData)
    {
        this.ResultData = ResultData;
    }

    public String getCount ()
    {
        return Count;
    }

    public void setCount (String Count)
    {
        this.Count = Count;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }

    public String getSuccess ()
    {
        return Success;
    }

    public void setSuccess (String Success)
    {
        this.Success = Success;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ResultData = "+ResultData+", Count = "+Count+", Message = "+Message+", Success = "+Success+"]";
    }
    public class ResultData
    {
        private String AddedOn;

        private String Message;

        private String MessageID;

        private String IsRead;

        private String SentBy;

        private String MasjidAdminID;

        public String getAddedOn ()
        {
            return AddedOn;
        }

        public void setAddedOn (String AddedOn)
        {
            this.AddedOn = AddedOn;
        }

        public String getMessage ()
        {
            return Message;
        }

        public void setMessage (String Message)
        {
            this.Message = Message;
        }

        public String getMessageID ()
        {
            return MessageID;
        }

        public void setMessageID (String MessageID)
        {
            this.MessageID = MessageID;
        }

        public String getIsRead ()
        {
            return IsRead;
        }

        public void setIsRead (String IsRead)
        {
            this.IsRead = IsRead;
        }

        public String getSentBy ()
        {
            return SentBy;
        }

        public void setSentBy (String SentBy)
        {
            this.SentBy = SentBy;
        }

        public String getMasjidAdminID ()
        {
            return MasjidAdminID;
        }

        public void setMasjidAdminID (String MasjidAdminID)
        {
            this.MasjidAdminID = MasjidAdminID;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [AddedOn = "+AddedOn+", Message = "+Message+", MessageID = "+MessageID+", IsRead = "+IsRead+", SentBy = "+SentBy+", MasjidAdminID = "+MasjidAdminID+"]";
        }
    }

}