package com.awqatesalah.awqaat_e_salaah;

import android.app.DialogFragment;

/**
 * Created by Abubakker on 12/7/2016.
 */
public class GATrackingDialog extends DialogFragment {
    @Override
    public void onResume() {
        super.onResume();
        //MyApplication singleton = new MyApplication();
        //singleton.trackScreenView(getClass().getSimpleName());

    }
}
