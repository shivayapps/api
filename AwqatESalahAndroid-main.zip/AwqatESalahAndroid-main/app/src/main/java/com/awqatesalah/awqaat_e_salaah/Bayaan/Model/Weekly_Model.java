package com.awqatesalah.awqaat_e_salaah.Bayaan.Model;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Weekly_Model {
    private String MuftiName;
    private String Tareef;
    private String Address;
    private String Day;
    private String URL;

    public String getMuftiName() {
        return MuftiName;
    }

    public void setMuftiName(String muftiName) {
        MuftiName = muftiName;
    }

    public String getTareef() {
        return Tareef;
    }

    public void setTareef(String tareef) {
        Tareef = tareef;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getDay() {
        return Day;
    }

    public void setDay(String day) {
        Day = day;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public Weekly_Model(String muftiName, String tareef, String address, String day, String URL) {
        MuftiName = muftiName;
        Tareef = tareef;
        Address = address;
        Day = day;
        this.URL = URL;
    }
}
