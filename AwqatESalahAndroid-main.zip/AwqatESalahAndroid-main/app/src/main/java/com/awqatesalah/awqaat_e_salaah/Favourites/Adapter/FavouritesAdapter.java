package com.awqatesalah.awqaat_e_salaah.Favourites.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableRow;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.DBHelper;
import com.awqatesalah.awqaat_e_salaah.Favourites.Fragment.Fragment_Fravourites;
import com.awqatesalah.awqaat_e_salaah.Favourites.Model.Favourites_Model;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;

import java.util.List;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;

/**
 * Created by Abubakker on 8/25/2016.
 */
public class FavouritesAdapter extends RecyclerView.Adapter<FavouritesAdapter.ContactViewHolder> {

    AlertDialog dialog;
    private List<Favourites_Model> contactList;
    private Context mcontext;
    private DBHelper dbhelper;
    private int masjid_id;
    public FavouritesAdapter(List<Favourites_Model> contactList,Context context1) {
        this.contactList = contactList;
        this.mcontext=context1;


    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }

    @Override
    public void onBindViewHolder(final ContactViewHolder contactViewHolder, final int i) {
        final Favourites_Model ci = contactList.get(i);
        contactViewHolder.title.setText(ci.getMasjidname().toString());
        contactViewHolder.address.setText(ci.getAddress().toString());
        contactViewHolder.lastUpdate.setText("Last updated :"+ci.getLastUpdated().toString());
        contactViewHolder.fajr.setText(ci.getFajr().toString());
        contactViewHolder.zuhr.setText(ci.getZuhr().toString());
        contactViewHolder.asr.setText(ci.getAsr().toString());
        contactViewHolder.maghrib.setText(ci.getMaghrib().toString());
        contactViewHolder.isha.setText(ci.getIsha().toString());
        contactViewHolder.jumuah.setText(ci.getJumuah().toString());
        dbhelper = new DBHelper(mcontext);
        dialog = new SpotsDialog(mcontext, R.style.main);

        StaticFunction.displayEidTime(contactViewHolder.eid_row,contactViewHolder.eid,mcontext);


        contactViewHolder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new MaterialDialog.Builder(mcontext).title("Delete Favourites").negativeText("No").onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        dbhelper.openDB();
                        dbhelper.deleteFavLocal(ci.getMasjid_ID());
                        dbhelper.closeDB();
                        notifyDataSetChanged();
                        MainActivity.updateFavouritesItemInDrawer(mcontext);
                        FragmentManager fragmentManager =((Activity) mcontext).getFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager
                                .beginTransaction();
                        Fragment_Fravourites frag = new Fragment_Fravourites();
                        fragmentTransaction.replace(R.id.container_fragment, frag);
                        fragmentTransaction.commit();
                    }
                })
                        .content("Do you want to delete ?").positiveText("Yes").show();


            }
        });

        contactViewHolder.refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  dialog.show();
                dialog.setCancelable(false);
                CallRetroApi get = new RetroFitServiceGenerator(mcontext).createService(CallRetroApi.class);
                Call<Refresh_Response> call1 = get.refreshtime(StaticFunction.getValue("v6E|2D;:5qJ|2D;:5xs"), contactList.get(i).getMasjid_ID().toString());

                    call1.enqueue(new Callback<Refresh_Response>() {
                        @Override
                        public void onResponse(Call<Refresh_Response> call, Response<Refresh_Response> response) {
                            if (response.body().getSuccess().equals("true")) {
                                Log.d("Refresh_Favourites", response.body().toString());
                                contactViewHolder.title.setText(response.body().getResultData().getMasjidName().toString());
                                contactViewHolder.address.setText(response.body().getResultData().getAddress().toString());
                                contactViewHolder.lastUpdate.setText(response.body().getResultData().getTimeModifiedOn().toString());
                                contactViewHolder.fajr.setText(response.body().getResultData().getJamaatFajr().toString());
                                contactViewHolder.zuhr.setText(response.body().getResultData().getJamaatZohar().toString());
                                contactViewHolder.asr.setText(response.body().getResultData().getJamaatAsr().toString());
                                contactViewHolder.maghrib.setText(response.body().getResultData().getJamaatMagrib().toString());
                                contactViewHolder.isha.setText(response.body().getResultData().getJamaatIsha().toString());
                                contactViewHolder.jumuah.setText(response.body().getResultData().getKhutbaJumma().toString());
                                contactViewHolder.eid.setText(response.body().getResultData().getJamaatEid().toString());
                               // progress.hide();

                                new MaterialDialog.Builder(mcontext).title(response.body().getResultData().getMasjidName().toString() +" Time")
                                        .content("Successfully Refreshed").positiveText("Ok").show();
                                dbhelper.openDB();
                                long resultUpdate =  dbhelper.update(Integer.parseInt(response.body().getResultData().getMasjidID()),
                                        Integer.parseInt(response.body().getResultData().getMasjidAdminID()),
                                        response.body().getResultData().getMasjidName(),
                                        response.body().getResultData().getAddress(),
                                        response.body().getResultData().getJamaatFajr(),
                                        response.body().getResultData().getJamaatZohar(),
                                        response.body().getResultData().getJamaatAsr(),
                                        response.body().getResultData().getJamaatMagrib()
                                        ,response.body().getResultData().getJamaatIsha(),
                                        response.body().getResultData().getJamaatEid(),
                                        response.body().getResultData().getKhutbaJumma(),
                                        response.body().getResultData().getTimeModifiedOn());
                                if(resultUpdate == 1){
                                    Toast.makeText(mcontext, "Offline saved", Toast.LENGTH_SHORT).show();
                                }
                                dbhelper.closeDB();
                                dialog.dismiss();
                            } else {
                                new MaterialDialog.Builder(mcontext).title("Error")
                                        .content(response.body().getMessage()).positiveText("Try Again").show();
                               // progress.hide();
                                dialog.dismiss();
                            }
                        }



                        @Override
                        public void onFailure(Call<Refresh_Response> call, Throwable t) {
                            StaticFunction.NoConnectionDialog(mcontext);
                            dialog.dismiss();
                        }
                    });
*/
                }
        });


    }

    @Override
    public ContactViewHolder onCreateViewHolder(ViewGroup viewGroup, final int i) {
        final View itemView = LayoutInflater.
                from(viewGroup.getContext()).
                inflate(R.layout.favourites_cardview, viewGroup, false);


        return new ContactViewHolder(itemView);
    }
    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        protected TextView title;
        protected TextView address;
        protected TextView lastUpdate;
        protected TextView fajr;
        protected TextView asr;
        protected TextView zuhr;
        protected TextView maghrib;
        protected TextView isha;
        protected TextView jumuah;
        protected TextView eid;
        protected FancyButton delete;
        protected FancyButton refresh;
        protected TableRow eid_row;


        public ContactViewHolder(View v) {
            super(v);
            title =  (TextView) v.findViewById(R.id.Masjid_Title);
            address = (TextView)  v.findViewById(R.id.Masjid_Address);
            lastUpdate = (TextView)  v.findViewById(R.id.LastUpdated);
            fajr = (TextView)  v.findViewById(R.id.Fajr);
            zuhr = (TextView)  v.findViewById(R.id.Zuhr);
            asr = (TextView)  v.findViewById(R.id.Asr);
            maghrib = (TextView)  v.findViewById(R.id.Maghrib);
            isha = (TextView)  v.findViewById(R.id.Isha);
            jumuah = (TextView)  v.findViewById(R.id.Jumuah);
            eid = (TextView)  v.findViewById(R.id.UEid);
            eid_row = (TableRow)  v.findViewById(R.id.eid_row);
            delete = (FancyButton)  v.findViewById(R.id.delete);
            refresh = (FancyButton)  v.findViewById(R.id.refresh_time);


        }
    }

}