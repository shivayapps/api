package com.awqatesalah.awqaat_e_salaah.Search.Fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_Register;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.Search.Adapters.CustomComparator;
import com.awqatesalah.awqaat_e_salaah.Search.Adapters.ListAdapter;
import com.awqatesalah.awqaat_e_salaah.Search.Models.LessDetailedListSorting_Model;
import com.awqatesalah.awqaat_e_salaah.Search.Models.ListByArea_Response;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.awqatesalah.awqaat_e_salaah.util.ui.UIUtils;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetSequence;
import com.miguelcatalan.materialsearchview.MaterialSearchView;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import dmax.dialog.SpotsDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.view.View.OnClickListener;
import static android.view.View.VISIBLE;

/**
 * Created by Abubakker on 8/25/2016.
 */
@SuppressWarnings("unchecked")
public class Fragment_MasjidList extends GATrackingFragment {


    AlertDialog dialog;
    SharedPreferences getPrefs;
    MaterialEditText area, timefilter;
    ArrayList<Date> testlist = new ArrayList<Date>();
    private LinkedList<LessDetailedListSorting_Model> list = new LinkedList<>();
    private ListAdapter listAdpter;
    private String mhour, minu, hou;
    private int mh;
    private TextView timeSetTextView;
    private TextView filtertext;
    private TextView cleartext;
    private ListByArea_Response area_response = new ListByArea_Response();
    private Spinner spinner;
    private Spinner sortOrderSpinner;
    private FrameLayout filtercontainer, clearcontainer;
    private ImageButton filterBut, clearBut;
    private ViewGroup contain;
    private Boolean firstTime= true;
    MySharedPrefrences sharedPrefrences;

    SpotsDialog sortingDialog;

    ProgressBar progressBar;

    public static List<LessDetailedListSorting_Model> sortByLocations(List<LessDetailedListSorting_Model> locations, final String myLatitude, final String myLongitude) {
        Comparator comp = new Comparator<LessDetailedListSorting_Model>() {
            @Override

            public int compare(LessDetailedListSorting_Model o, LessDetailedListSorting_Model o2) {
                int aDist = (int) distance(Double.parseDouble(o.getLatitude()), Double.parseDouble(o.getLongitude()), Double.parseDouble(myLatitude), Double.parseDouble(myLongitude));
                int bDist = (int) distance(Double.parseDouble(o2.getLatitude()), Double.parseDouble(o2.getLongitude()), Double.parseDouble(myLatitude), Double.parseDouble(myLongitude));
                return aDist - bDist;
            }
        };


        Collections.sort(locations, comp);
        return locations;
    }

    static double distance(double fromLat, double fromLon, double toLat, double toLon) {
        double radius = 6378137;   // approximate Earth radius, *in meters*
        double deltaLat = toLat - fromLat;
        double deltaLon = toLon - fromLon;
        double angle = 2 * Math.asin(Math.sqrt(
                Math.pow(Math.sin(deltaLat / 2), 2) +
                        Math.cos(fromLat) * Math.cos(toLat) *
                                Math.pow(Math.sin(deltaLon / 2), 2)));
        return radius * angle;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_SEARCH_RESULTS);

        setHasOptionsMenu(true);
        try {
            MainActivity.searchView.setVisibility(VISIBLE);
        } catch (Exception e) {

        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.less_detail_masjid_cardview, container, false);
        contain = container;
        final FastScrollRecyclerView recList = (FastScrollRecyclerView) view.findViewById(R.id.recycler);
        // final RecyclerViewEmptySupport recList = (RecyclerViewEmptySupport) view.findViewById(R.id.recyclerview);
        filtercontainer = (FrameLayout) view.findViewById(R.id.filter_container);
        clearcontainer = (FrameLayout) view.findViewById(R.id.clear_container);
        filterBut = (ImageButton) view.findViewById(R.id.filter);
        clearBut = (ImageButton) view.findViewById(R.id.clear);
        filtertext = (TextView) view.findViewById(R.id.filtertext);
        cleartext = (TextView) view.findViewById(R.id.cleartext);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        // progress = (AVLoadingIndicatorView) view.findViewById(R.id.avi1);
        // recList.setEmptyView(view.findViewById(R.id.list_empty1));
        recList.setHasFixedSize(true);
        getToolbar();
        dialog = new SpotsDialog(getActivity(), R.style.MasjidList);
        dialog.setCancelable(false);

        sortingDialog = new SpotsDialog(getActivity(), R.style.main);

        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recList.setLayoutManager(llm);
        //recList.addItemDecoration(new DividerItemDecoration(getActivity()));
       /* recList.setOnScrollListener(new HidingScrollListener() {
            @Override
            public void onHide() {
                hideViews();
            }
            @Override
            public void onShow() {
                showViews();
            }
        });*/
        //fragment.getView().setFocusableInTouchMode(true);
        //fragment.getView().requestFocus();

        MainActivity.updateFavouritesItemInDrawer(getActivity());


        getPrefs = PreferenceManager
                .getDefaultSharedPreferences(getActivity());


        filtertext.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                    //Analytics Event
                    new Analytics(getActivity()).logMasjidFilterClickEvent();

                    MaterialDialog dialog = new MaterialDialog.Builder(getActivity())
                            .title("FILTER")
                            .customView(R.layout.dialog_filter, true)
                            .positiveText("Search")
                            .negativeText("cancel")
                            .onPositive(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                    //Analytics Event
                                    new Analytics(getActivity()).logMasjidsFilterApplyEvent(area.getText().toString(),timefilter.getText().toString());

                                    Toast.makeText(getActivity(), area.getText().toString() + "  " + timefilter.getText().toString(), Toast.LENGTH_LONG).show();
                                    if (list.size() > 0 ) {
                                        filtercontainer.setVisibility(View.GONE);
                                        clearcontainer.setVisibility(View.VISIBLE);
                                        final LinkedList<LessDetailedListSorting_Model> filteredModelList = filterByTime(list, area.getText().toString(), timefilter.getText().toString());
                                        if(listAdpter!=null) {
                                            listAdpter.setData((LinkedList<LessDetailedListSorting_Model>) filteredModelList);
                                        }
                                    }
                                }
                            }).build();
                    dialog.show();
                    area = (MaterialEditText) dialog.getCustomView().findViewById(R.id.area_name);
                    timefilter = (MaterialEditText) dialog.getCustomView().findViewById(R.id.time);


                    timefilter.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            TimeSet(timefilter);
                        }
                    });
            }
        });

        cleartext.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                filtercontainer.setVisibility(View.VISIBLE);
                clearcontainer.setVisibility(View.GONE);
                if(listAdpter!=null) {
                    listAdpter.setData(list);
                }
            }
        });


        MainActivity.searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //Do some magic
                if (list.size() > 0) {
                    final LinkedList<LessDetailedListSorting_Model> filteredModelList = filter(list, newText);
                    if(listAdpter!=null) {
                        listAdpter.setData((LinkedList<LessDetailedListSorting_Model>) filteredModelList);
                    }
                }
                return false;
            }
        });

        sharedPrefrences = new MySharedPrefrences(getActivity());


        MainActivity.searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {
                //Do some magic
                //Analytics Event
                new Analytics(getActivity()).logMasjidsSearchBarButtonClickEvent();
            }

            @Override
            public void onSearchViewClosed() {


                //Do some magic
            }
        });
        spinner = (Spinner) view.findViewById(R.id.sortby);
        ArrayList<String> list1 = new ArrayList<>();
        list1.add("Sort By");
        list1.add("Fajr");
        list1.add("Zuhr");
        list1.add("Asr");
        list1.add("Maghrib");
        list1.add("Isha");
        list1.add("Jumuah");
      /*  SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(),R.layout.spinneritem,list1);
        spinner.setAdapter(adapter);*/

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(), R.layout.spinneritem, list1
        );
        spinner.setAdapter(spinnerArrayAdapter);

        sortOrderSpinner = (Spinner) view.findViewById(R.id.sortorder);
        ArrayList<String> list2 = new ArrayList<>();
        list2.add("Earliest to Latest");
        list2.add("Latest to Earliest");

        ArrayAdapter<String> spinnerArrayAdapter2 = new ArrayAdapter<String>(
                getActivity(), R.layout.spinneritem, list2
        );
        sortOrderSpinner.setAdapter(spinnerArrayAdapter2);

        dialog.show();


        sortOrderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==1){
                    if(spinner.getSelectedItemPosition()!=0) {
                        showSortingLoader();
                        //progressBar.setVisibility(View.VISIBLE);

                        ExecutorService executor = Executors.newSingleThreadExecutor();
                        Handler handler = new Handler(Looper.getMainLooper());
                        executor.execute(new Runnable() {
                            @Override
                            public void run() {
                                //Background work here
                                // Perform sorting operation
                                Collections.sort(list, Collections.reverseOrder());
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        //UI Thread work here
                                        // Update UI on main thread after sorting is done
                                        recList.setAdapter(listAdpter);
                                        dismissSortingLoader();

                                        //progressBar.setVisibility(View.GONE);
                                    }
                                });
                            }
                        });
                    }
                }
                if(position==0){
                    if(spinner.getSelectedItemPosition()!=0) {
                        showSortingLoader();

                        ExecutorService executor = Executors.newSingleThreadExecutor();
                        Handler handler = new Handler(Looper.getMainLooper());
                        executor.execute(new Runnable() {
                            @Override
                            public void run() {
                                //Background work here
                                // Perform sorting operation
                                Collections.sort(list);
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        //UI Thread work here
                                        // Update UI on main thread after sorting is done
                                        recList.setAdapter(listAdpter);
                                        dismissSortingLoader();
                                    }
                                });
                            }
                        });
                    }
                }
                listAdpter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                sortOrderSpinner.setSelection(0);

                String time;
                if (position == 0) {
                    if(!firstTime) {
                        showSortingLoader();
                        list.clear();
                        for (int i = 0; i < area_response.getResultData().length; i++) {
                            AddToList(area_response, i, "");
                        }
                        listAdpter = new ListAdapter(list, "", getActivity(), getFragmentManager());

                        ExecutorService executor = Executors.newSingleThreadExecutor();
                        Handler handler = new Handler(Looper.getMainLooper());
                        executor.execute(new Runnable() {
                            @Override
                            public void run() {
                                //Background work here
                                // Perform sorting operation
                                Collections.sort(list, new LessDetailedListSorting_Model());
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        //UI Thread work here
                                        // Update UI on main thread after sorting is done
                                        recList.setAdapter(listAdpter);
                                        dismissSortingLoader();
                                    }
                                });
                            }
                        });
                    }
                }
                if (position == 1) {
                    showSortingLoader();

                    //Analytics Event
                    new Analytics(getActivity()).logMasjidSortByNameEvent("Fajr");

                    firstTime=false;
                    list.clear();
                    for (int i = 0; i < area_response.getResultData().length; i++) {
                        time = area_response.getResultData()[i].getJamaatFajr().replace("PM", "AM");
                        ;
                        if (time.equals("") || time.equals("-") || time.equals("--:--") ||  time.equals("00:00")) {
                            continue;
                        }
                        AddToList(area_response, i, time);
                    }

                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(new Runnable() {
                        @Override
                        public void run() {
                            //Background work here
                            // Perform sorting operation
                            Collections.sort(list);
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //UI Thread work here
                                    // Update UI on main thread after sorting is done
                                    listAdpter = new ListAdapter(list, "Fajr", getActivity(), getFragmentManager());
                                    recList.setAdapter(listAdpter);
                                    dismissSortingLoader();
                                }
                            });
                        }
                    });
                }
                if (position == 2) {
                    showSortingLoader();

                    //Analytics Event
                    new Analytics(getActivity()).logMasjidSortByNameEvent("Zuhr");

                    firstTime=false;
                    list.clear();
                    for (int i = 0; i < area_response.getResultData().length; i++) {
                        time = area_response.getResultData()[i].getJamaatZohar().replace("AM", "PM");
                        ;
                        if (time.equals("")|| time.equals("-") || time.equals("--:--") ||  time.equals("00:00")) {
                            continue;
                        }
                        AddToList(area_response, i, time);
                    }

                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(new Runnable() {
                        @Override
                        public void run() {
                            //Background work here
                            // Perform sorting operation
                            Collections.sort(list);
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //UI Thread work here
                                    // Update UI on main thread after sorting is done
                                    listAdpter = new ListAdapter(list, "Zuhr", getActivity(), getFragmentManager());
                                    recList.setAdapter(listAdpter);
                                    dismissSortingLoader();
                                }
                            });
                        }
                    });

                }
                if (position == 3) {
                    showSortingLoader();

                    //Analytics Event
                    new Analytics(getActivity()).logMasjidSortByNameEvent("Asr");

                    firstTime=false;
                    list.clear();
                    for (int i = 0; i < area_response.getResultData().length; i++) {
                        time = area_response.getResultData()[i].getJamaatAsr().replace("AM", "PM");
                        ;
                        if (time.equals("") || time.equals("-") || time.equals("--:--") ||  time.equals("00:00")) {
                            continue;
                        }
                        AddToList(area_response, i, time);
                    }

                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(new Runnable() {
                        @Override
                        public void run() {
                            //Background work here
                            // Perform sorting operation
                            Collections.sort(list);
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //UI Thread work here
                                    // Update UI on main thread after sorting is done
                                    listAdpter = new ListAdapter(list, "Asr", getActivity(), getFragmentManager());
                                    recList.setAdapter(listAdpter);
                                    dismissSortingLoader();
                                }
                            });
                        }
                    });


                }
                if (position == 4) {
                    showSortingLoader();

                    //Analytics Event
                    new Analytics(getActivity()).logMasjidSortByNameEvent("Maghrib");

                    firstTime=false;
                    list.clear();
                    for (int i = 0; i < area_response.getResultData().length; i++) {
                        time = area_response.getResultData()[i].getJamaatMagrib().replace("AM", "PM");
                        ;
                        if (time.equals("")|| time.equals("-") || time.equals("--:--") ||  time.equals("00:00")) {
                            continue;
                        }
                        AddToList(area_response, i, time);
                    }

                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(new Runnable() {
                        @Override
                        public void run() {
                            //Background work here
                            // Perform sorting operation
                            Collections.sort(list);
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //UI Thread work here
                                    // Update UI on main thread after sorting is done
                                    listAdpter = new ListAdapter(list, "Maghrib", getActivity(), getFragmentManager());
                                    recList.setAdapter(listAdpter);
                                    dismissSortingLoader();
                                }
                            });
                        }
                    });

                }
                if (position == 5) {
                    showSortingLoader();

                    //Analytics Event
                    new Analytics(getActivity()).logMasjidSortByNameEvent("Isha");

                    firstTime=false;
                    list.clear();
                    for (int i = 0; i < area_response.getResultData().length; i++) {
                        time = area_response.getResultData()[i].getJamaatIsha().replace("AM", "PM");
                        ;
                        if (time.equals("")|| time.equals("-") || time.equals("--:--") ||  time.equals("00:00")) {
                            continue;
                        }
                        AddToList(area_response, i, time);
                    }

                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(new Runnable() {
                        @Override
                        public void run() {
                            //Background work here
                            // Perform sorting operation
                            Collections.sort(list);
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //UI Thread work here
                                    // Update UI on main thread after sorting is done
                                    listAdpter = new ListAdapter(list, "Isha", getActivity(), getFragmentManager());
                                    listAdpter.notifyDataSetChanged();
                                    recList.setAdapter(listAdpter);
                                    dismissSortingLoader();
                                }
                            });
                        }
                    });

                }
                if (position == 6) {
                    showSortingLoader();

                    //Analytics Event
                    new Analytics(getActivity()).logMasjidSortByNameEvent("Jumuah");

                    firstTime=false;
                    list.clear();
                    for (int i = 0; i < area_response.getResultData().length; i++) {
                        time = area_response.getResultData()[i].getKhutbaJumma().replace("AM", "PM");
                        if (time.equals("") || time.equals("-") || time.equals("--:--") ||  time.equals("00:00")) {
                            continue;
                        }
                        AddToList(area_response, i, time);
                    }

                    ExecutorService executor = Executors.newSingleThreadExecutor();
                    Handler handler = new Handler(Looper.getMainLooper());
                    executor.execute(new Runnable() {
                        @Override
                        public void run() {
                            //Background work here
                            // Perform sorting operation
                            Collections.sort(list);
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //UI Thread work here
                                    // Update UI on main thread after sorting is done
                                    listAdpter = new ListAdapter(list, "Jumuah", getActivity(), getFragmentManager());
                                    recList.setAdapter(listAdpter);
                                    dismissSortingLoader();
                                }
                            });
                        }
                    });

                }
               /* if(position==5)
                {
                    list.clear();
                    for(int i=0;i<area_response.getResultData().length;i++)
                    {
                        String time = area_response.getResultData()[i].getKhutbaJumma();
                        list.add(new LessDetailedListSorting_Model(area_response.getResultData()[i].getMasjidName(),area_response.getResultData()[i].getAddress(),getTimeFormatted(time)));
                    }
                    Collections.sort(list);
                    listAdpter = new ListAdapter(list,"Zuhr");
                    listAdpter.notifyDataSetChanged();
                    recList.setAdapter(listAdpter);


                }*/

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        if (getArguments() != null) {
            if (!getArguments().getString("cityid", "0").equals("0")) {
                if (list != null && area_response != null) {
                    if (list.size() < 1) {
                        getMasjidByCity(view, recList);
                    } else {
                        dialog.dismiss();
                        listAdpter = new ListAdapter(list, "", getActivity(), getFragmentManager());
                        recList.setAdapter(listAdpter);
                    }
                }
            } else {
                getNearByMasjid(view, recList, getArguments().getString("latitude", "0"), getArguments().getString("longitude", "0"));

            }
        }



       /* ItemClickSupport.addTo(recList)
                .setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
                    @Override
                    public void onItemClicked(RecyclerView recyclerView, int position, View v) {

                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        Fragment_CompleteMasjidDetails updateTime = new Fragment_CompleteMasjidDetails();
                        Bundle bundle= new Bundle();
                        bundle.putString("MasjidName",area_response.getResultData()[position].getMasjidName());
                        bundle.putString("Address",area_response.getResultData()[position].getAddress());
                        bundle.putString("LastUpdated",area_response.getResultData()[position].getTimeModifiedOn());
                        bundle.putString("Fajr",area_response.getResultData()[position].getJamaatFajr());
                        bundle.putString("Zuhr",area_response.getResultData()[position].getJamaatZohar());
                        bundle.putString("Asr",area_response.getResultData()[position].getJamaatAsr());
                        bundle.putString("Maghrib",area_response.getResultData()[position].getJamaatMagrib());
                        bundle.putString("Isha",area_response.getResultData()[position].getJamaatIsha());
                        bundle.putString("Jumuah",area_response.getResultData()[position].getKhutbaJumma());
                        bundle.putString("Masjid_ID",area_response.getResultData()[position].getMasjidID());
                        bundle.putString("Username",area_response.getResultData()[position].getMasjidAdminID());
                        bundle.putString("latitude",area_response.getResultData()[position].getLatitude());
                        bundle.putString("longitude",area_response.getResultData()[position].getLongitude());
                        updateTime.setArguments(bundle);
                        ft.replace(R.id.container_fragment, updateTime);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                });
*/

        return view;
    }

    private void AddToList(ListByArea_Response area_response, int i, String time) {
        String LastUpdated, Fajr, Zuhr, Asr, Maghrib, Isha, Jumuah,Eid, longitude, latitude, Masjid_ID, Username, preadded, website, contactno, enquiry;
        LastUpdated = area_response.getResultData()[i].getTimeModifiedOn();
        Fajr = area_response.getResultData()[i].getJamaatFajr().toUpperCase().replace("PM", "AM");
        Zuhr = area_response.getResultData()[i].getJamaatZohar().replace("AM", "PM");
        Asr = area_response.getResultData()[i].getJamaatAsr().replace("AM", "PM");
        Maghrib = area_response.getResultData()[i].getJamaatMagrib().replace("AM", "PM");
        Isha = area_response.getResultData()[i].getJamaatIsha().replace("AM", "PM");
        Jumuah = area_response.getResultData()[i].getKhutbaJumma().replace("AM", "PM");
        Eid = area_response.getResultData()[i].getJamaatEid().replace("AM", "PM");
        longitude = area_response.getResultData()[i].getLongitude();
        latitude = area_response.getResultData()[i].getLatitude();
        Masjid_ID = area_response.getResultData()[i].getMasjidID();
        Username = area_response.getResultData()[i].getMasjidAdminID();
        preadded = area_response.getResultData()[i].getIsPreAddedMasjid();
        website = area_response.getResultData()[i].getWebsite();
        contactno = area_response.getResultData()[i].getContactNo();
        enquiry = area_response.getResultData()[i].getEnquiry();

        list.add(new LessDetailedListSorting_Model(area_response.getResultData()[i].getMasjidName(), area_response.getResultData()[i].getAddress(), LastUpdated, time, Fajr, Zuhr, Asr, Maghrib, Isha, Jumuah,Eid, longitude, latitude, Masjid_ID, Username, preadded, website, contactno, enquiry));
    }

    private void getNearByMasjid(final View view, final RecyclerView recList, final String latitude, final String longitude) {
        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        Call<ListByArea_Response> call1 = get.nearby(StaticFunction.getValue("v6E}62CqJ|2D;:5D"), latitude, longitude);
        call1.enqueue(new Callback<ListByArea_Response>() {
            @Override
            public void onResponse(Call<ListByArea_Response> call, Response<ListByArea_Response> response) {
                if (response.body() != null) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("Masjid_List_Response", response.body().toString());
                        list.clear();
                        spinner.setVisibility(VISIBLE);
                        sortOrderSpinner.setVisibility(VISIBLE);
                        for (int i = 0; i < response.body().getResultData().length; i++) {
                            list.add(new LessDetailedListSorting_Model(response.body().getResultData()[i].getMasjidName(), response.body().getResultData()[i].getAddress(), response.body().getResultData()[i].getTimeModifiedOn(), response.body().getResultData()[i].getJamaatIsha(), response.body().getResultData()[i].getJamaatFajr()
                                    , response.body().getResultData()[i].getJamaatZohar(),
                                    response.body().getResultData()[i].getJamaatAsr(),
                                    response.body().getResultData()[i].getJamaatMagrib(),
                                    response.body().getResultData()[i].getJamaatIsha(),
                                    response.body().getResultData()[i].getKhutbaJumma(),
                                    response.body().getResultData()[i].getJamaatEid(),
                                    response.body().getResultData()[i].getLongitude(),
                                    response.body().getResultData()[i].getLatitude(),
                                    response.body().getResultData()[i].getMasjidID(),
                                    response.body().getResultData()[i].getMasjidAdminID(),
                                    response.body().getResultData()[i].getIsPreAddedMasjid()
                                    , response.body().getResultData()[i].getWebsite()
                                    , response.body().getResultData()[i].getContactNo()
                                    , response.body().getResultData()[i].getEnquiry()

                            ));
                        }
                        area_response = response.body();

                        sortByLocations(list, latitude, longitude);
                         listAdpter = new ListAdapter(list, "", getActivity(), getFragmentManager());
                         recList.setAdapter(listAdpter);

                        dialog.dismiss();
                    } else {

                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                        dialog.dismiss();

                    }
                } else {
                    StaticFunction.NoConnectionDialog(getActivity());
                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<ListByArea_Response> call, Throwable t) {

                try {
                    if (!StaticFunction.isOnline(getActivity())) {
                        new MaterialDialog.Builder(getActivity()).title("Internet Error")
                                .content("You dont have INTERNET CONNECTION").positiveText("Ok").show();
                    } else {
                        if (latitude.equals("0.0") && longitude.equals("0.0")) {
                            new MaterialDialog.Builder(getActivity()).title("Location error")
                                    .content("Enable to fetch your location")
                                    .positiveText("Try again")
                                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                                        @Override
                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                            getActivity().getFragmentManager().popBackStack();
                                        }
                                    }).show();
                        } else {
                            new MaterialDialog.Builder(getActivity()).title("No Masjid found")
                                    .content("No registrered masjid found near your location")
                                    .positiveText("Register")
                                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                                        @Override
                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                            FragmentManager fm = getFragmentManager();
                                            FragmentTransaction ft = fm.beginTransaction();
                                            Fragment_Register register = new Fragment_Register();
                                            ft.replace(R.id.container_fragment, register);
                                            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                                            ft.addToBackStack(null);
                                            ft.commit();

                                        }
                                    }).negativeText("Cancel")
                                    .onNegative(new MaterialDialog.SingleButtonCallback() {
                                        @Override
                                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                            getActivity().getFragmentManager().popBackStack();
                                        }
                                    }).show();
                        }
                    }

                } catch (Exception e) {

                }
                dialog.dismiss();
                ;
            }
        });
    }

   /* private void hideViews() {
       MainActivity.toolbar.animate().translationY(-MainActivity.toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(2));
    }

    private void showViews() {
        MainActivity.toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(2));
    }*/

    private void getMasjidByCity(final View view, final RecyclerView recList) {

        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        HashMap<String, String> param = new HashMap<>();
        param.put("AreaID", getArguments().getString("cityid", "0"));
        Call<ListByArea_Response> call1 = get.getListByArea(StaticFunction.getValue("v6E|2D;:5DqJpC62xs"), param);

        call1.enqueue(new Callback<ListByArea_Response>() {
            @Override
            public void onResponse(Call<ListByArea_Response> call, Response<ListByArea_Response> response) {
                if (response.body() != null) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("AREA_List_Response", response.body().toString());
                        list.clear();
                        spinner.setVisibility(VISIBLE);
                        sortOrderSpinner.setVisibility(VISIBLE);
                        for (int i = 0; i < response.body().getResultData().length; i++) {
                            list.add(new LessDetailedListSorting_Model(
                                    response.body().getResultData()[i].getMasjidName(),
                                    response.body().getResultData()[i].getAddress(),
                                    response.body().getResultData()[i].getTimeModifiedOn(),
                                    response.body().getResultData()[i].getJamaatIsha(),
                                    response.body().getResultData()[i].getJamaatFajr().replace("PM", "AM")
                                    , response.body().getResultData()[i].getJamaatZohar().replace("AM", "PM"),
                                    response.body().getResultData()[i].getJamaatAsr().replace("AM", "PM"),
                                    response.body().getResultData()[i].getJamaatMagrib().replace("AM", "PM"),
                                    response.body().getResultData()[i].getJamaatIsha().replace("AM", "PM"),
                                    response.body().getResultData()[i].getKhutbaJumma().replace("AM", "PM"),
                                    response.body().getResultData()[i].getJamaatEid().replace("AM", "PM"),
                                    response.body().getResultData()[i].getLongitude(),
                                    response.body().getResultData()[i].getLatitude(),
                                    response.body().getResultData()[i].getMasjidID(),
                                    response.body().getResultData()[i].getMasjidAdminID()
                                    , response.body().getResultData()[i].getIsPreAddedMasjid()
                                    , response.body().getResultData()[i].getWebsite()
                                    , response.body().getResultData()[i].getContactNo()
                                    , response.body().getResultData()[i].getEnquiry()
                            ));
                        }
                        area_response = response.body();




                        listAdpter = new ListAdapter(list, "", getActivity(), getFragmentManager());
                        Collections.sort(list, new LessDetailedListSorting_Model());
                        recList.setAdapter(listAdpter);


                        if (getPrefs.getString("firsttimemasjidlist", "yes").equals("yes")) {
                            getPrefs.edit().putString("firsttimemasjidlist", "no").apply();
                            getTutorial(view, recList,getActivity());
                            sharedPrefrences.setFavouritesAndLocationTutorialShown();

                        }else{
                            final MySharedPrefrences sharedPrefrences = new MySharedPrefrences(getActivity());
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    if(!sharedPrefrences.getFavouritesAndLocationTutorialShown()) {
                                        View view = UIUtils.getFirstVisibleItem(recList);
                                        getTutorialLocationFavourites(view, getActivity());
                                        sharedPrefrences.setFavouritesAndLocationTutorialShown();
                                    }

                                }
                            },1000);
                        }

                        dialog.dismiss();
                    } else {
                        filtercontainer.setVisibility(View.GONE);
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                        dialog.dismiss();

                    }
                } else {

                    filtercontainer.setVisibility(View.GONE);
                    new MaterialDialog.Builder(getActivity()).title("Internet Error")
                            .content("You dont have INTERNET CONNECTION").positiveText("Ok").show();
                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<ListByArea_Response> call, Throwable t) {

                try {
                    filtercontainer.setVisibility(View.GONE);
                    if (!StaticFunction.isOnline(getActivity())) {
                        new MaterialDialog.Builder(getActivity()).title("Internet Error")
                                .content("You dont have INTERNET CONNECTION").positiveText("Ok").show();
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("No Masjid Found")
                                .content("No Masjid are registered in this area").positiveText("Register")
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        FragmentManager fm = getFragmentManager();
                                        FragmentTransaction ft = fm.beginTransaction();
                                        Fragment_Register register = new Fragment_Register();
                                        ft.replace(R.id.container_fragment, register);
                                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                                        ft.addToBackStack(null);
                                        ft.commit();

                                    }
                                }).negativeText("Cancel")
                                .onNegative(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        getActivity().getFragmentManager().popBackStack();
                                    }
                                }).show();
                    }

                } catch (Exception e) {

                }
                dialog.dismiss();
                ;
            }
        });
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Masjid");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public void onPause() {
        super.onPause();

    }

    private LinkedList<LessDetailedListSorting_Model> filter(LinkedList<LessDetailedListSorting_Model> models, String query) {
        query = query.toLowerCase();
        final LinkedList<LessDetailedListSorting_Model> filteredModelList = new LinkedList<>();
        if (query.equals("") | query.isEmpty()) {
            filteredModelList.addAll(models);
            return filteredModelList;
        }
        for (LessDetailedListSorting_Model model : models) {
            final String masjidname = model.getMasjidName().toLowerCase().replaceAll("[^A-Za-z0-9]","").trim();
            final String masjidname2 = model.getMasjidName().toLowerCase();
            final String address = model.getMasjidAddress().replaceAll("[^A-Za-z0-9]","").toLowerCase();

            String regex = "\\d{4}-\\d{2}-\\d{2}";
            // if (!query.matches(regex)) {
            if (masjidname.contains(query.replaceAll(" ","").trim()) || masjidname2.contains(query.replaceAll(" ","").trim())
                    || address.contains(query.replaceAll(" ","").trim())) {
                filteredModelList.add(model);
            }
        }
        return filteredModelList;
    }

    private LinkedList<LessDetailedListSorting_Model> filterByTime(LinkedList<LessDetailedListSorting_Model> models, String queryarea, String querytime) {
        queryarea = queryarea.replaceAll(" ","").toLowerCase();
        final LinkedList<LessDetailedListSorting_Model> filteredModelList = new LinkedList<>();
        for (LessDetailedListSorting_Model model : models) {
            final String address = model.getMasjidAddress().replaceAll("[^A-Za-z0-9]","").toLowerCase();
            final String fajr = model.getFajr();
            final String zuhr = model.getZuhr();
            final String asr = model.getAsr();
            final String isha = model.getIsha();
            final String jumuah = model.getJumuah();

            String regex = "\\d{4}-\\d{2}-\\d{2}";

            //IF ONLY AREA FOUND
            if (!queryarea.equals("") && querytime.equals(""))
                if (address.toLowerCase().contains(queryarea.toLowerCase())) {
                    filteredModelList.add(model);
                }

            //IF BOTH FOUND
            if (!queryarea.equals("") && !querytime.equals(""))
                if (address.toLowerCase().contains(queryarea.toLowerCase()) && ((zuhr.contains(querytime)) || (asr.contains(querytime)) ||
                        (isha.contains(querytime)) || (jumuah.contains(querytime)) || (fajr.contains(querytime)))) {
                    filteredModelList.add(model);
                }


            //IF ONLY TIME FOUND
            if (queryarea.equals("") && !querytime.equals(""))
                if (((zuhr.contains(querytime)) || (asr.contains(querytime)) ||
                        (isha.contains(querytime)) || (jumuah.contains(querytime)) || (fajr.contains(querytime)))) {
                    filteredModelList.add(model);
                }
        }
        return filteredModelList;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.getItem(0).setVisible(true);
        menu.getItem(3).setVisible(false);
        menu.getItem(2).setVisible(false);
    }

    public void TimeSet(final TextView t) {
        // TODO Auto-generated method stub
        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        int minute = mcurrentTime.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        timeSetTextView = t;
        mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                StaticFunction.setNamazTime(selectedHour,selectedMinute, timeSetTextView,t);
            }
        }, hour, minute, false);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }

    private void getTutorial(View view, final View recyclerview, final Activity context) {
        new TapTargetSequence(context)
                .targets(
                        TapTarget.forView(view.findViewById(R.id.filter_container), "Now you can filter using namaz time or area")
                                .dimColor(android.R.color.black)
                                .outerCircleColor(R.color.colorPrimary)
                                .targetCircleColor(android.R.color.black)
                                .transparentTarget(true),
                        TapTarget.forView(view.findViewById(R.id.sortby), "You can now sort namaz time from earliest to last")
                                .dimColor(android.R.color.black)
                                .outerCircleColor(R.color.colorPrimary)
                                .targetCircleColor(android.R.color.black)
                                .transparentTarget(true)).listener(new TapTargetSequence.Listener() {
            @Override
            public void onSequenceFinish() {
                if(recyclerview!=null){

                    getTutorialLocationFavourites(recyclerview,context);
                }
            }

            @Override
            public void onSequenceCanceled(TapTarget lastTarget) {

            }
        }).start();
    }

    private void getTutorialLocationFavourites(View view, Activity context) {
        new TapTargetSequence(context)
                .targets(
                        TapTarget.forView(view.findViewById(R.id.location_container), "See the location of Masjid")
                                .dimColor(android.R.color.black)
                                .outerCircleColor(R.color.colorPrimary)
                                .targetCircleColor(android.R.color.black)
                                .transparentTarget(true),
                        TapTarget.forView(view.findViewById(R.id.add_to_favourites), "Add masjid to favourites for easy access")
                                .dimColor(android.R.color.black)
                                .outerCircleColor(R.color.colorPrimary)
                                .targetCircleColor(android.R.color.black)
                                .transparentTarget(true)).start();
    }

    public void showSortingLoader() {
        sortingDialog.show();
        //progressBar.setVisibility(VISIBLE);
    };
    public void dismissSortingLoader() {
        sortingDialog.dismiss();
        //progressBar.setVisibility(View.GONE);
    };

}
