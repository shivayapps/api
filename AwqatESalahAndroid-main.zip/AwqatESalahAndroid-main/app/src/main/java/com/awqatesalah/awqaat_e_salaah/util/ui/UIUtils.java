package com.awqatesalah.awqaat_e_salaah.util.ui;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * Created by root on 26/1/18.
 */

public class UIUtils {
    public static View getFirstVisibleItem(RecyclerView recyclerView) {
        View view = null;
        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
        if(layoutManager instanceof LinearLayoutManager) {
            int index = ((LinearLayoutManager) layoutManager).findFirstCompletelyVisibleItemPosition();
            view = layoutManager.findViewByPosition(index);
        }
        return view;
    }
}