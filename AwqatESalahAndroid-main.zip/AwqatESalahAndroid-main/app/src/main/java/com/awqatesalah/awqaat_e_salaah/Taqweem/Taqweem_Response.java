package com.awqatesalah.awqaat_e_salaah.Taqweem;

/**
 * Created by Abubakker on 8/31/2016.
 */
public class Taqweem_Response
{
    private ResultData ResultData;

    private String Message;

    private String Success;

    public ResultData getResultData ()
    {
        return ResultData;
    }

    public void setResultData (ResultData ResultData)
    {
        this.ResultData = ResultData;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }

    public String getSuccess ()
    {
        return Success;
    }

    public void setSuccess (String Success)
    {
        this.Success = Success;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ResultData = "+ResultData+", Message = "+Message+", Success = "+Success+"]";
    }
    public class ResultData
    {
        private String Fajr;

        private String HijriDate;

        private String Isha;

        private String Asr;

        private String EnglishDate;

        private String TuleEAftab;

        private String Dhuhr;

        private String Maghrib;

        private String Sunrise;

        private String Sunset;

        public String getSunset() {
            return Sunset;
        }

        public void setSunset(String sunset) {
            Sunset = sunset;
        }

        public String getFajr() {
            return Fajr;
        }

        public void setFajr(String fajr) {
            Fajr = fajr;
        }

        public String getHijriDate() {
            return HijriDate;
        }

        public void setHijriDate(String hijriDate) {
            HijriDate = hijriDate;
        }

        public String getIsha() {
            return Isha;
        }

        public void setIsha(String isha) {
            Isha = isha;
        }

        public String getAsr() {
            return Asr;
        }

        public void setAsr(String asr) {
            Asr = asr;
        }

        public String getEnglishDate() {
            return EnglishDate;
        }

        public void setEnglishDate(String englishDate) {
            EnglishDate = englishDate;
        }

        public String getTuleEAftab() {
            return TuleEAftab;
        }

        public void setTuleEAftab(String tuleEAftab) {
            TuleEAftab = tuleEAftab;
        }

        public String getDhuhr() {
            return Dhuhr;
        }

        public void setDhuhr(String dhuhr) {
            Dhuhr = dhuhr;
        }

        public String getMaghrib() {
            return Maghrib;
        }

        public void setMaghrib(String maghrib) {
            Maghrib = maghrib;
        }

        public String getSunrise() {
            return Sunrise;
        }

        public void setSunrise(String sunrise) {
            Sunrise = sunrise;
        }


    }
}