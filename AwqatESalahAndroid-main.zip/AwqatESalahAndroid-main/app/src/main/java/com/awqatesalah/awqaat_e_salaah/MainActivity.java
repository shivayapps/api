package com.awqatesalah.awqaat_e_salaah;

import android.Manifest;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_Admin;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_GetAllMasjidsByAdmin;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_Login;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Bayaan.Fragment.MainFragmentBayaan;
import com.awqatesalah.awqaat_e_salaah.Contact_Us.Fragment_ContactUs;
import com.awqatesalah.awqaat_e_salaah.Contact_Us.Help;
import com.awqatesalah.awqaat_e_salaah.Favourites.Fragment.Fragment_Fravourites;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Fragments.Fragment_Notification;
import com.awqatesalah.awqaat_e_salaah.Search.Fragments.Fragment_MasjidSearch;
import com.awqatesalah.awqaat_e_salaah.Taqweem.Fragment_Taqweem;
import com.awqatesalah.awqaat_e_salaah.TermsCondition.Fragments.MainFragmentTnc;
import com.awqatesalah.awqaat_e_salaah.util.CheckAppUpdateGooglePlay;
import com.awqatesalah.awqaat_e_salaah.util.DrawerLocker;
import com.awqatesalah.awqaat_e_salaah.util.font.TypeFaceCommonUtils;
import com.awqatesalah.awqaat_e_salaah.util.font.TypefaceUtil;
//import com.facebook.accountkit.AccountKit;
import com.google.firebase.messaging.FirebaseMessaging;
import com.miguelcatalan.materialsearchview.MaterialSearchView;
import com.mikepenz.actionitembadge.library.ActionItemBadge;
import com.mikepenz.materialdrawer.AccountHeader;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.holder.BadgeStyle;
import com.mikepenz.materialdrawer.holder.StringHolder;
import com.mikepenz.materialdrawer.interfaces.ICrossfader;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.ProfileDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends BaseActivity implements Fragment_Notification.OnNotificationOpenListener, DrawerLocker {
    private static final int REQUESTPERMISSION = 456;
    private static final int PERMISSION_REQUEST_CODE = 1;
    public static Drawer result;
    public static Toolbar toolbar;
    public static MaterialSearchView searchView;
    private static int SELECTEDITEM = 0;
    AccountHeader headerResult;
    ICrossfader crossFader;
    MenuItem notificationCount;
    int badgeCount = 2;
    MySharedPrefrences shared;
    SharedPreferences getPrefs;

    TextView versionName;
    BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            makeNotificationCountProper(shared);

            result.updateItem(new PrimaryDrawerItem().withName("Notification").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(6).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.noti)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withBadge(String.valueOf(shared.getNotificationCount()))
                    .withBadgeStyle(new BadgeStyle().withTextColor(Color.WHITE).withColorRes(R.color.md_red_600))
            );

            ActionItemBadge.update(MainActivity.this, notificationCount, getResources().getDrawable(R.drawable.ic_notifications_24dp), ActionItemBadge.BadgeStyles.RED, shared.getNotificationCount());

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR_OVERLAY);
        setContentView(R.layout.activity_main);
        FirebaseMessaging.getInstance().subscribeToTopic("awqatesalah_android");

        //oveerrding deafult fonts
        TypefaceUtil.overrideFont(getApplicationContext(), "SERIF", TypeFaceCommonUtils.getCommonFont()); // font from assets: "assets/fonts/Roboto-Regular.ttf

        //App Force Update Check
        new CheckAppUpdateGooglePlay(MainActivity.this).checkUpdate();

        searchView = (MaterialSearchView) findViewById(R.id.search_view);
        searchView.setHint("Enter Masjid name or Area");

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Awqat-e-Salah");

        //checkPermissions();


        //
        supportStartPostponedEnterTransition();

        shared = MySharedPrefrences.getInstance(MainActivity.this);
        getPrefs = PreferenceManager
                .getDefaultSharedPreferences(MainActivity.this);

        if (shared.getCountry() == -1 || shared.getState() == -1) {
            StaticFunction.removeFromCache(StaticFunction.getBaseValue(BuildConfig.BASE_URL) + StaticFunction.getValue("v6Ew:;C:s2E6"), MainActivity.this);
            //getPrefs.edit().putString("city", "null").apply();
            //MyApplication.allAreas = null;
            //MyApplication.date_response = null;
            Dialog_Country country = new Dialog_Country();
            country.show(getSupportFragmentManager(), "country");
        }


        makeNotificationCountProper(shared);


        directIntentFromNotification();


        Log.d("SHARED", shared.getData("Username").toString());
        if (!shared.getData("Username").toString().equals("null")) {
            buildHeader(shared.getData("Name"), savedInstanceState);
        } else {
            buildHeader("Guest User", savedInstanceState);
        }


        result = new DrawerBuilder()
                .withActivity(this)
                .withToolbar(toolbar)
                //.withHeaderHeight(DimenHolder.fromDp(170))
                .withTranslucentNavigationBar(true)
//provide the custom crossfadeDrawerLaoyout
                .withHasStableIds(true)
//define the width to the width of our smaller view
                .withDrawerWidthDp(250)
                .withHeaderDivider(true)
                .withActionBarDrawerToggle(true)
                .withInnerShadow(false)
                .withSliderBackgroundColor(Color.TRANSPARENT)
//generate the MiniDrawer which is used for the smaller view
                .withSelectedItem(SELECTEDITEM)
                .withFooter(R.layout.drawer_footer)
                .addDrawerItems(
                        new PrimaryDrawerItem().withName("Masjid").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(1).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.masjidfilled)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        //new PrimaryDrawerItem().withName("Qibla Compass").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(15).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.bayaanfilled)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Bayaan").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(2).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.bayaanfilled)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Account").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(3).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.adminfilled)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Taqweem").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(4).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.clockfilled)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Favourites").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(5).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.favouritesfilled)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)).withBadgeStyle(new BadgeStyle().withTextColor(Color.WHITE).withColorRes(R.color.md_red_600)),

                        new PrimaryDrawerItem().withName("Notification").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(6).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.noti)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withBadge(String.valueOf(shared.getNotificationCount())).withBadgeStyle(new BadgeStyle().withTextColor(Color.WHITE).withColorRes(R.color.md_red_600)).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Share").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(12).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.share)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Feedback").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(7).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.suggest)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Help").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(8).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.ic_how_to_use)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Contact Us").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(9).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.call)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Terms & Privacy").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(10).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.ic_info)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this)),
                        new PrimaryDrawerItem().withName("Logout").withTextColor(getResources().getColor(R.color.drawer_text_colour)).withSelectedIconColor(getResources().getColor(R.color.md_white_1000)).withIdentifier(11).withSelectable(true).withSelectedTextColor(getResources().getColor(R.color.md_white_1000)).withSelectedColor(getResources().getColor(R.color.colorPrimary)).withIcon(getResources().getDrawable(R.drawable.logout)).withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour)).withIconTintingEnabled(true).withTypeface(TypeFaceCommonUtils.getMontserratLight(this))
                )
                .withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
                    @Override
                    public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                        FragmentManager fragmentManager = getFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager
                                .beginTransaction();
                        if (drawerItem.getIdentifier() == 15) {
                           /* Intent intent = new Intent(MainActivity.this, CompassActivity.class);
                            intent.putExtra(Constants.TOOLBAR_TITLE_COLOR, R.color.colorPrimary);
                            intent.putExtra(Constants.TOOLBAR_BG_COLOR, R.color.colorPrimary);
                            intent.putExtra(Constants.TOOLBAR_TITLE, "Qibla Compass");		// Toolbar Title// Toolbar Title color// Toolbar Title color
                            intent.putExtra(Constants.COMPASS_BG_COLOR, "#FFFFFF");		// Compass background color
                            intent.putExtra(Constants.ANGLE_TEXT_COLOR, "#000000");
                            startActivity(intent);*/
                        }
                            if (drawerItem.getIdentifier() == 12) {

                            //Analytics Event
                            new Analytics(MainActivity.this).logDrawerShareEvent();

                            Intent sendIntent = new Intent();
                            sendIntent.setAction(Intent.ACTION_SEND);
                            sendIntent.putExtra(Intent.EXTRA_TEXT,shared.getShareApp());
                            sendIntent.setType("text/plain");
                            startActivity(sendIntent);
                            result.closeDrawer();
                        }
                        if (drawerItem.getIdentifier() == 8) {
                            getFragment(fragmentManager, fragmentTransaction, new Help(), true);
                        }
                        if (drawerItem.getIdentifier() == 11) {

                            //Analytics Event
                            new Analytics(MainActivity.this).logLogoutDrawerPressEvent();

                            if (!shared.getData("Username").toString().equals("null")) {
                                getSupportActionBar().show();
                                if (fragmentManager.getBackStackEntryCount() > 0) {
                                    for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
                                        fragmentManager.popBackStack();
                                    }
                                }
                                result.closeDrawer();
                                new MaterialDialog.Builder(MainActivity.this).title("LOGOUT")
                                        .content("Do You want to logout ?").negativeText("No").positiveText("Yes").onNegative(new MaterialDialog.SingleButtonCallback() {
                                            @Override
                                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                                dialog.dismiss();
                                                //Analytics Event
                                                new Analytics(MainActivity.this).logLogoutDialogNoEvent();
                                            }
                                        }).onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull final MaterialDialog dialog, @NonNull DialogAction which) {
                                        if (StaticFunction.isOnline(MainActivity.this)) {

                                            //Analytics Event
                                            new Analytics(MainActivity.this).logLogoutDialogYesEvent();

                                            CallRetroApi logoutCall = new RetroFitServiceGenerator(MainActivity.this).createService(CallRetroApi.class);

                                            Call<Update_Response> call1 = logoutCall.logout(StaticFunction.getValue("p5>:?{@8@FE"), shared.getData("MasjidAdminID").toString());
                                            call1.enqueue(new Callback<Update_Response>() {
                                                @Override
                                                public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                                                    Log.d("logout_response", response.body().getMessage());
                                                    ArrayList<String> unreadIds = shared.getUnreadNotificationIds();
                                                    int count = shared.getNotificationCount();
                                                    shared.ClearAllData();
                                                    //Actually saving it , not actually deleting it
                                                    shared.deleteReadNotificationId(unreadIds);
                                                    shared.saveNotificationCount(count);
                                                    dialog.dismiss();
                                                    //AccountKit.logOut();
                                                    Intent intent = new Intent(getApplicationContext(), SplashScreen.class);
                                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                    startActivity(intent);
                                                    finish();

                                                }

                                                @Override
                                                public void onFailure(Call<Update_Response> call, Throwable t) {

                                                }
                                            });

                                        } else {
                                            Toast.makeText(MainActivity.this, "Internet Connection Required", Toast.LENGTH_LONG).show();

                                        }

                                    }
                                }).show();

                            } else {
                                Toast.makeText(MainActivity.this, "Sorry you cannot perform this Action,Login first", Toast.LENGTH_LONG).show();
                                result.closeDrawer();
                            }
                        }
                        if (drawerItem.getIdentifier() == 9) {
                            getFragment(fragmentManager, fragmentTransaction, new Fragment_ContactUs(), true);
                        }
                        if (drawerItem.getIdentifier() == 7) {
                            getFragment(fragmentManager, fragmentTransaction, new Fragment_FeedBack(), true);
                        }
                        if (drawerItem.getIdentifier() == 6) {
                            getFragment(fragmentManager, fragmentTransaction, new Fragment_Notification(), true);
                        }
                        if (drawerItem.getIdentifier() == 4) {
                            getFragment(fragmentManager, fragmentTransaction, new Fragment_Taqweem(), true);
                        }
                        if (drawerItem.getIdentifier() == 5) {
                            getFragment(fragmentManager, fragmentTransaction, new Fragment_Fravourites(), true);
                        }
                        if (drawerItem.getIdentifier() == 1) {
                            getFragment(fragmentManager, fragmentTransaction, new Fragment_MasjidSearch(), true);
                        }
                        if (drawerItem.getIdentifier() == 2) {
                            getSupportFragment(fragmentManager, new MainFragmentBayaan());
                        }
                        if (drawerItem.getIdentifier() == 10) {
                            getSupportFragment(fragmentManager, new MainFragmentTnc());
                        }
                        if (drawerItem.getIdentifier() == 3) {
                            getSupportActionBar().show();
                            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                                getSupportFragmentManager().popBackStack();
                            }

                            if (fragmentManager.getBackStackEntryCount() > 0) {
                                for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
                                    fragmentManager.popBackStack();
                                }
                            }
                            if (shared.getData("Username").toString().equals("null")) {
                                Fragment_Login frag = new Fragment_Login();
                                fragmentTransaction.replace(R.id.container_fragment, frag);
                                fragmentTransaction.commit();
                            } else {
                                Fragment_Admin admin = new Fragment_Admin();
                                Bundle bundle = new Bundle();
                                bundle.putString("FromLogin", "No");
                                admin.setArguments(bundle);
                                fragmentTransaction.replace(R.id.container_fragment, admin);
                                //fragmentTransaction.addToBackStack("admin");
                                fragmentTransaction.commit();
                            }
                            result.closeDrawer();
                        }
                        return true;
                    }
                })
                .withOnDrawerNavigationListener(new Drawer.OnDrawerNavigationListener() {
                    @Override
                    public boolean onNavigationClickListener(View clickedView) {
                        getFragmentManager().popBackStack();
                        return true;
                    }
                })
                .withAccountHeader(headerResult)
                .withSavedInstance(savedInstanceState)
                .build();


        //initializing favourites count
        updateFavouritesItemInDrawer(MainActivity.this);

        checkNotificationPermission();
    }

    private void getSupportFragment(FragmentManager fragmentManager, androidx.fragment.app.Fragment frag) {


        if (fragmentManager.getBackStackEntryCount() > 0) {
            for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
                fragmentManager.popBackStack();
            }
        }
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container_fragment, frag, "rageComicList")
                .commit();
        result.closeDrawer();
    }

    private void directIntentFromNotification() {
        if (getIntent().getStringExtra("OpenNotif") != null) {
            getCompleteNewFragmentWithBundle(new Fragment_Notification());
            SELECTEDITEM = 6;
        } else if (getIntent().getStringExtra("OpenMessage") != null && shared.getData("MasjidAdminID") != null) {
            getCompleteNewFragmentWithBundle(new Fragment_Admin());
            SELECTEDITEM = 3;
        } else if (getIntent().getStringExtra("LocationSuggestion") != null && shared.getData("MasjidAdminID") != null) {
            Fragment_Admin masjidsByAdmin = new Fragment_Admin();
            Bundle bundle1 = new Bundle();
            bundle1.putString("MasjidId", getIntent().getStringExtra("id"));
            bundle1.putString("isLocationSuggestion", "yes");
            masjidsByAdmin.setArguments(bundle1);
            getCompleteNewFragmentWithBundle(masjidsByAdmin);
            SELECTEDITEM = 3;
        }else if (getIntent().getStringExtra("OpenUpdate") != null && shared.getData("MasjidAdminID") != null) {
            Fragment_GetAllMasjidsByAdmin masjidsByAdmin = new Fragment_GetAllMasjidsByAdmin();
            Bundle bundle1 = new Bundle();
            bundle1.putString("AdminID", shared.getData("MasjidAdminID"));
            bundle1.putString("fromHome", "yes");
            masjidsByAdmin.setArguments(bundle1);
            getCompleteNewFragmentWithBundle(masjidsByAdmin);
            SELECTEDITEM = 3;
        } else if(getIntent().getStringExtra("OpenFav") != null){
            Fragment_Fravourites fragment_fravourites = new Fragment_Fravourites();
            Bundle bundle1 = new Bundle();
            bundle1.putString("MasjidId", getIntent().getStringExtra("id"));
            fragment_fravourites.setArguments(bundle1);
            getCompleteNewFragmentWithBundle(fragment_fravourites);
            SELECTEDITEM = 5;
        }else {
            getCompleteNewFragmentWithBundle(new Fragment_MasjidSearch());
            SELECTEDITEM = 0;
        }
    }

    private void buildHeader(String name, Bundle savedInstanceState) {
        headerResult = new AccountHeaderBuilder()
                .withActivity(this)
                .addProfiles(
                        new ProfileDrawerItem()
                                .withName(name)
                                .withSelectedColor(getResources().getColor(R.color.md_black_1000))
                                .withDisabledTextColor(getResources()
                                        .getColor(R.color.color2))
                                .withTextColor(getResources()
                                        .getColor(R.color.color2))
                                .withIcon(getResources().getDrawable(R.mipmap.ic_launcher))
                )
                .withTypeface(TypeFaceCommonUtils.getMontserratLight(this))
                // .withHeaderBackground(R.color.black)
                .withCurrentProfileHiddenInList(true)
                .withSelectionListEnabled(false)
                .withDividerBelowHeader(true)
                .withAlternativeProfileHeaderSwitching(false)
                .withSavedInstance(savedInstanceState)
                .withTextColor(getResources().getColor(R.color.md_black_1000))
                .build();

        //headerResult.getView().findViewById(R.id.material_drawer_account_header_name).setVisibility(View.INVISIBLE);

    }

    private void getCompleteNewFragmentWithBundle(Fragment frag) {
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager
                .beginTransaction();
        fragmentTransaction.replace(R.id.container_fragment, frag);
        fragmentTransaction.commit();
    }

    private void getFragment(FragmentManager fragmentManager, FragmentTransaction fragmentTransaction, Fragment frag, boolean showActionBar) {

        if (showActionBar) {
            getSupportActionBar().show();
        }


        if (fragmentManager.getBackStackEntryCount() > 0) {
            for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
                fragmentManager.popBackStack();
            }
        }
        fragmentTransaction.replace(R.id.container_fragment, frag);
        fragmentTransaction.commit();

        result.closeDrawer();
    }

    private void makeNotificationCountProper(MySharedPrefrences shared) {
        if (shared.getUnreadNotificationIds() != null) {
            if (shared.getUnreadNotificationIds().size() < 1) {
                shared.saveNotificationCount(0);
            } else {
                shared.saveNotificationCount(shared.getUnreadNotificationIds().size());
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.registerReceiver(mMessageReceiver, new IntentFilter("notification_listener"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        this.unregisterReceiver(mMessageReceiver);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        //add the values which need to be saved from the drawer to the bundle
        outState = result.saveInstanceState(outState);
        //add the values which need to be saved from the accountHeader to the bundle
        outState = headerResult.saveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        item.setVisible(false);
        searchView.closeSearch();

        menu.getItem(3).setVisible(true);
        notificationCount = menu.findItem(R.id.item_samplebadge);

        if (badgeCount > 0) {
            ActionItemBadge.update(this, notificationCount, getResources().getDrawable(R.drawable.ic_notifications_24dp), ActionItemBadge.BadgeStyles.RED, shared.getNotificationCount());
        } else {
            ActionItemBadge.hide(menu.findItem(R.id.item_samplebadge));
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_share:
                //Analytics Event
                new Analytics(MainActivity.this).logNavBarShareClickEvent();

                // do something based on first item click
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,shared.getShareApp());
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
                break;
            case R.id.item_samplebadge:
                //Analytics Event
                new Analytics(MainActivity.this).logNavBarNotificationsClickEvent();

                getCompleteNewFragmentWithBundle(new Fragment_Notification());
                result.setSelection(6);
                break;
            case R.id.action_location:
                if (StaticFunction.isOnline(MainActivity.this)) {
                    //Analytics Event
                    new Analytics(MainActivity.this).logNavBarLocationClickEvent();

                    StaticFunction.removeFromCache(StaticFunction.getBaseValue(BuildConfig.BASE_URL) + StaticFunction.getValue("v6Ew:;C:s2E6"), MainActivity.this);
                    //getPrefs.edit().putString("city", "null").apply();
                    //MyApplication.allAreas = null;
                   // MyApplication.date_response = null;
                    Dialog_Country country = new Dialog_Country();
                    country.show(getSupportFragmentManager(), "country");
                } else {
                    Toast.makeText(MainActivity.this, "Internet connection needed", Toast.LENGTH_LONG).show();
                }
                break;


        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        //handle the back press :D close the drawer first and if the drawer is closed close the activity
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        }

        if (result != null && result.isDrawerOpen()) {
            result.closeDrawer();
        } else {

            super.onBackPressed();
        }
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION);
        if (result == PackageManager.PERMISSION_GRANTED) {

            return true;

        } else {

            return false;

        }
    }

    private void requestPermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION)) {

            Toast.makeText(MainActivity.this, "GPS permission allows us to access location data. Please allow in App Settings for additional functionality.", Toast.LENGTH_LONG).show();

        } else {

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_CODE);
        }
    }

    private void checkPermissions() {
        String[] permissions = {
                "android.permission.ACCESS_NETWORK_STATE",
                "android.permission.ACCESS_COARSE_LOCATION",
                "android.permission.ACCESS_FINE_LOCATION",
                "android.permission.WRITE_EXTERNAL_STORAGE",
                "android.permission.READ_EXTERNAL_STORAGE",
                "android.permission.CALL_PHONE",
        };

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED |
                    checkSelfPermission(android.Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED |
                    checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED |
                    checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED |
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED |
                    checkSelfPermission(android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED
                    ) {
                requestPermissions(permissions, REQUESTPERMISSION);
            }
        }
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(MainActivity.this,Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 110);
                }
            }
        }
    }



    @Override
    public void UpdateUI() {

        makeNotificationCountProper(shared);

        result.updateItem(new PrimaryDrawerItem()
                .withName("Notification")
                .withTextColor(getResources().getColor(R.color.drawer_text_colour))
                .withSelectedIconColor(getResources().getColor(R.color.md_white_1000))
                .withIdentifier(6)
                .withSelectable(true)
                .withSelectedTextColor(getResources().getColor(R.color.md_white_1000))
                .withSelectedColor(getResources().getColor(R.color.colorPrimary))
                .withIcon(getResources().getDrawable(R.drawable.noti))
                .withIconTintingEnabled(true).withIconColor(getResources().getColor(R.color.drawer_text_colour))
                .withIconTintingEnabled(true)
                .withBadge(String.valueOf(shared.getNotificationCount()))
                .withBadgeStyle(new BadgeStyle().withTextColor(Color.WHITE).withColorRes(R.color.md_red_600))
        );

        ActionItemBadge.update(this, notificationCount, getResources().getDrawable(R.drawable.ic_notifications_24dp), ActionItemBadge.BadgeStyles.RED, shared.getNotificationCount());

    }

    public static void updateFavouritesItemInDrawer(Context context) {
        int Count = 0;
        DBHelper dbHelper = new DBHelper(context);
        dbHelper.openDB();
        Cursor cursor = dbHelper.getAllFavLocal();
        Count = cursor.getCount();
        dbHelper.closeDB();

        result.updateBadge(5,new StringHolder(Count+""));
    }


    @Override
    public void setDrawerEnabled(boolean enabled) {
        int lockMode = enabled ? DrawerLayout.LOCK_MODE_UNLOCKED :
                DrawerLayout.LOCK_MODE_LOCKED_CLOSED;
        MainActivity.result.getDrawerLayout().setDrawerLockMode(lockMode);
    }
}

