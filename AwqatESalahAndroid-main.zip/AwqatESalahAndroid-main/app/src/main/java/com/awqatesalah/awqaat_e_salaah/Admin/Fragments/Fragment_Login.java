package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Login_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Fragment_ForgotPassword;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.google.firebase.messaging.FirebaseMessaging;
import com.rengwuxian.materialedittext.MaterialEditText;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/21/2016.
 */
public class Fragment_Login extends GATrackingFragment {
    private FancyButton register,Login;
    private MaterialEditText username,password;
    private SpotsDialog dialog;
    private TextView forget_password_textview;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        register = (FancyButton) view.findViewById(R.id.Register);
        Login = (FancyButton) view.findViewById(R.id.LogIn);
        username = (MaterialEditText) view.findViewById(R.id.username);
        password = (MaterialEditText) view.findViewById(R.id.password);
        forget_password_textview = (TextView) view.findViewById(R.id.forget_password_textview);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Awqat-e-Salah");

        dialog = new SpotsDialog(getActivity(),R.style.main);
        dialog.setCancelable(false);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_Register register = new Fragment_Register();
                ft.replace(R.id.container_fragment, register);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();


            }
        });


        forget_password_textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "I have Forget my Id password please give me new";
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Bundle bundle = new Bundle();
                bundle.putString("message",message );
                Fragment_ForgotPassword registerFinal = new Fragment_ForgotPassword();
                registerFinal.setArguments(bundle);
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });

            Login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (username.getText().toString().length() >= 6 && password.getText().toString().length() >= 5) {
                        dialog.show();


                        CallRetroApi login_api = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                        Call<Login_Response> call = login_api.login(StaticFunction.getValue("p5>:?{@8:?"), getValue(username), getValue(password));
                        call.enqueue(new Callback<Login_Response>() {
                            @Override
                            public void onResponse(Call<Login_Response> call, Response<Login_Response> response) {
                                if (response.body().getSuccess().toString().equals("true")) {
                                    Log.d("logged_in", response.body().getMessage());
                                    //getAlldata
                                    dialog.dismiss();
                                    View view = getActivity().getCurrentFocus();
                                    if (view != null) {
                                        InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                    }
                                    MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());
                                    shared.saveData("Username", response.body().getResultData().getUsername());
                                    shared.saveData("Number", response.body().getResultData().getMobileNumber());
                                    shared.saveData("Name", response.body().getResultData().getAdminName());
                                    shared.saveData("MasjidAdminID", response.body().getResultData().getMasjidAdminID());
                                    shared.saveData("LastModified", response.body().getResultData().getModifiedOn());
                                    shared.saveData("Unread_Count", response.body().getResultData().getUnreadMessagesCount());

                                    CallRetroApi registerId = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);

                                    FirebaseMessaging.getInstance().getToken().addOnSuccessListener(firebaseToken -> {
                                        Call<Update_Response> call1 = registerId.registerDeviceID(StaticFunction.getValue("$2G6p5>:?s6G:46"), response.body().getResultData().getMasjidAdminID(),firebaseToken, "Android");
                                        call1.enqueue(new Callback<Update_Response>() {
                                            @Override
                                            public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                                                FragmentManager fm = getFragmentManager();
                                                FragmentTransaction ft = fm.beginTransaction();
                                                Fragment_Admin admin = new Fragment_Admin();
                                                Bundle bundle = new Bundle();
                                                bundle.putString("FromLogin", "Yes");
                                                admin.setArguments(bundle);
                                                ft.replace(R.id.container_fragment, admin);
                                                // ft.addToBackStack("admin");
                                                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);

                                                ft.commit();
                                            }

                                            @Override
                                            public void onFailure(Call<Update_Response> call, Throwable t) {

                                            }
                                        });
                                    });

                                } else {
                                    dialog.dismiss();
                                    new MaterialDialog.Builder(getActivity()).title("Error")
                                            .content(response.body().getMessage()).positiveText("Try Again").show();
                                }
                            }

                            @Override
                            public void onFailure(Call<Login_Response> call, Throwable t) {
                                StaticFunction.NoConnectionDialog(getActivity());
                                dialog.dismiss();
                            }
                        });
                    } else {
                        if (username.getText().toString().length() < 6) {
                            username.setError("Username should be atleast 6 characters");
                        }
                        if (password.getText().toString().length() < 5) {
                            password.setError("Password should be atleast 5 characters");
                        }
                    }
                }
            });


        return view;
    }
    public String getValue(EditText text)
    {
        return text.getText().toString().trim();
    }
}
