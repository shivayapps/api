package com.awqatesalah.awqaat_e_salaah.Bayaan.Adapter;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.Bayaan.Model.Weekly_Model;
import com.awqatesalah.awqaat_e_salaah.R;

import java.util.List;

/**
 * Created by Abubakker on 8/28/2016.
 */

public class RecyclerViewAdapterWeekly extends RecyclerView.Adapter<RecyclerViewAdapterWeekly.ContactViewHolder>  {
    private List<Weekly_Model> list;

    public RecyclerViewAdapterWeekly(List<Weekly_Model> contactList) {
        this.list = contactList;
    }

    @Override
    public RecyclerViewAdapterWeekly.ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View itemView = LayoutInflater.
                from(parent.getContext()).
                inflate(R.layout.cardview_weekly, parent, false);


        return new ContactViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerViewAdapterWeekly.ContactViewHolder holder, int position) {
        Weekly_Model ci = list.get(position);
        holder.Muftiname.setText(ci.getMuftiName());
        holder.address.setText(ci.getAddress());
        holder.tareef.setText(ci.getTareef());
        holder.day.setText(ci.getDay());
        holder.url.setText(ci.getURL());

    }

    @Override
    public int getItemCount() {
        return  list.size();
    }

    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        protected TextView Muftiname;
        protected TextView tareef;
        protected TextView address;
        protected TextView day;
        protected TextView url;


        public ContactViewHolder(View v) {
            super(v);
            Muftiname =  (TextView) v.findViewById(R.id.Muftiname);
            address = (TextView)  v.findViewById(R.id.address);
            tareef = (TextView)  v.findViewById(R.id.tareef);
            day = (TextView)  v.findViewById(R.id.day);
            url = (TextView)  v.findViewById(R.id.url);

        }
    }
}
