///*
//package com.awqatesalah.awqaat_e_salaah.Search.Fragments;
//
//import android.app.Fragment;
//import android.app.TimePickerDialog;
//import android.database.Cursor;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//
//import android.support.v7.app.AppCompatActivity;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TableRow;
//import android.widget.TextView;
//import android.widget.TimePicker;
//import android.widget.Toast;
//
//import com.afollestad.materialdialogs.MaterialDialog;
//import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
//import com.awqatesalah.awqaat_e_salaah.DBHelper;
//import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
//import com.awqatesalah.awqaat_e_salaah.MainActivity;
//import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
//import com.awqatesalah.awqaat_e_salaah.R;
//import com.awqatesalah.awqaat_e_salaah.StaticFunction;
//import com.rengwuxian.materialedittext.MaterialEditText;
//
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//
//import mehdi.sakout.fancybuttons.FancyButton;
//import retrofit2.Call;
//import retrofit2.Callback;
//
//import retrofit2.Response;
//import retrofit2.Retrofit;
//import retrofit2.converter.gson.GsonConverterFactory;
//
//*/
///**
// * Created by Abubakker on 8/26/2016.
// *//*
//
//public class Fragment_Dialog extends Fragment {
//
//
//
//    public Fragment_Dialog(){}
//    private MaterialEditText name,number;
//    private String mhour,minu,hou;
//    private int mh;
//    private TextView fajredit, zuhredit, asredit, maghribedit, ishaedit, jummahedit;
//    private FancyButton changetime;
//    private TextView masjidname;
//    private Retrofit retrofit;
//    private TextView t1;
//    private DBHelper dbHelper;
//    TableRow row;
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        final View view = inflater.inflate(R.layout.dialog_fragment,container,false);
//
//        getToolbar();
//        fajredit = (TextView) view.findViewById(R.id.Fajr);
//        zuhredit = (TextView) view.findViewById(R.id.Zuhr);
//        asredit = (TextView) view.findViewById(R.id.Asr);
//        maghribedit = (TextView) view.findViewById(R.id.Maghrib);
//        ishaedit = (TextView) view.findViewById(R.id.Isha);
//        jummahedit = (TextView) view.findViewById(R.id.Jumuah);
//        changetime = (FancyButton) view.findViewById(R.id.refresh_time);
//        masjidname = (TextView) view.findViewById(R.id.Masjid_Title);
//        name= (MaterialEditText) view.findViewById(R.id.personame);
//        number= (MaterialEditText) view.findViewById(R.id.number);
//        final MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());
//        fajredit.setOnClickListener(onClickListener);
//        zuhredit.setOnClickListener(onClickListener);
//        asredit.setOnClickListener(onClickListener);
//        maghribedit.setOnClickListener(onClickListener);
//        ishaedit.setOnClickListener(onClickListener);
//        jummahedit.setOnClickListener(onClickListener);
//        row= (TableRow) view.findViewById(R.id.row);
//
//        //Set Values
//        setAllText();
//
//
//
//        retrofit = new Retrofit.Builder()
//                .baseUrl(StaticFunction.getValue("9EEAi^^HHH]2HB2E6D2=29]4@>"))
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();
//
//
//        changetime.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(!getValue(name).equals("") && getValue(number).length()==10 && !getValue(fajredit).equals("") && !getValue(zuhredit).equals("") && !getValue(asredit).equals("") && !getValue(maghribedit).equals("") && !getValue(ishaedit).equals(""))
//                {
//                    if(StaticFunction.isOnline(getActivity())) {
//                        Log.d("Values", getValue("Masjid_ID") + " " + getValue(fajredit) + " " + getValue(ishaedit) + name.getText().toString().trim() + number.getText().toString().trim());
//                        CallRetroApi get = retrofit.create(CallRetroApi.class);
//                        Call<Update_Response> call1 = get.suggest_Time(StaticFunction.getValue("^p!x0pHB2Et$2=2900'`0_^$F886DE%:>6"),getValue("Masjid_ID"), "", "", "", "", "", "", getValue(fajredit), getValue(zuhredit), getValue(asredit), getValue(maghribedit), getValue(ishaedit), getValue(jummahedit), name.getText().toString().trim(), number.getText().toString().trim());
//
//                        call1.enqueue(new Callback<Update_Response>() {
//                            @Override
//                            public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
//                                if (response.body().getSuccess().equals("true")) {
//                                    new MaterialDialog.Builder(getActivity()).title("Suggestion Done Successfully")
//                                            .content("Note : The time will be updated in 12 hours if it is found correct").positiveText("Jazakallah").show();
//                                    getFragmentManager().popBackStack();
//                                } else {
//                                    new MaterialDialog.Builder(getActivity()).title("Error")
//                                            .content(response.body().getMessage()).positiveText("Try Again").show();
//                                }
//                            }
//
//                            @Override
//                            public void onFailure(Call<Update_Response> call, Throwable t) {
//                                StaticFunction.NoConnectionDialog(getActivity());
//                            }
//                        });
//                    }
//                    else {
//                        dbHelper = new DBHelper(getActivity());
//                        dbHelper.openDB();
//                        Cursor cursor = dbHelper.getSuggestionFlag(Integer.parseInt(getValue("Masjid_ID")));
//
//                        if(cursor.getCount()>0) {
//                            DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
//                            String date = df.format(Calendar.getInstance().getTime());
//                            long resultUpdate =   dbHelper.update_suggestion(Integer.parseInt(getValue("Masjid_ID")), getValue(fajredit), getValue(zuhredit), getValue(asredit),
//                                getValue(maghribedit), getValue(ishaedit),
//                                getValue(jummahedit), name.getText().toString().trim(), number.getText().toString().trim(),"pending",date.toString());
//                            if(resultUpdate == 1){
//                                Toast.makeText(getActivity(), "Offline Suggestion Updated", Toast.LENGTH_SHORT).show();
//                            }
//                            dbHelper.closeDB();
//                        }
//                        else
//                        {
//                            DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
//                            String date = df.format(Calendar.getInstance().getTime());
//                            long resultInsert = dbHelper.insert_suggestion(Integer.parseInt(getValue("Masjid_ID")), getValue(fajredit), getValue(zuhredit), getValue(asredit), getValue(maghribedit), getValue(ishaedit), getValue(jummahedit), name.getText().toString().trim(), number.getText().toString().trim(),"pending",date.toString());
//                            if(resultInsert == -1){
//                                Toast.makeText(getActivity(), "Some error occurred while inserting", Toast.LENGTH_SHORT).show();
//                            } else {
//                                Toast.makeText(getActivity(), "Added to Suggestion", Toast.LENGTH_SHORT).show();
//                            }
//                            dbHelper.closeDB();
//                        }
//
//
//                    }
//                }
//                else
//                {
//                    if (name.getText().toString().equals("")) {
//                        name.setError("Name Cannot be empty");
//                    }
//                    else if (number.length() > 10 || number.length() <10) {
//                        number.setError("Number should be of 10 digits");
//                    }
//                    else {
//                        new MaterialDialog.Builder(getActivity()).title("Error")
//                                .content("Insert All Namaz time").positiveText("Try Again").show();
//                    }
//                }
//            }
//        });
//        return view;
//    }
//
//    private void setAllText() {
//        masjidname.setText(getValue("MasjidName"));
//        fajredit.setText(getValue("Fajr"));
//        zuhredit.setText(getValue("Zuhr"));
//        asredit.setText(getValue("Asr"));
//        maghribedit.setText(getValue("Maghrib"));
//        ishaedit.setText(getValue("Isha"));
//        if (getValue("Jumuah").equals("") || getValue("Jumuah").equals("-") ) {
//            row.setVisibility(View.GONE);
//        }
//        else
//        {
//            jummahedit.setText(getValue("Jumuah"));
//        }
//    }
//
//    private void getToolbar() {
//
//            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Suggestion");
//            MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
//            ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//
//    }
//
//    private String getValue(String key) {
//        return getArguments().getString(key, "-");
//    }
//    private String getValue(TextView key)
//    {
//        return key.getText().toString().trim();
//    }
//    private View.OnClickListener onClickListener = new View.OnClickListener() {
//
//        @Override
//        public void onClick(View v) {
//            // TODO Auto-generated method stub
//            switch(v.getId()){
//                case R.id.Fajr:
//                    //DO something
//                    TimeSet(fajredit);
//                    break;
//                case R.id.Zuhr:
//                    //DO something
//                    TimeSet(zuhredit);
//                    break;
//                case R.id.Asr:
//                    //DO something
//                    TimeSet(asredit);
//                    break;
//                case R.id.Maghrib:
//                    //DO something
//                    TimeSet(maghribedit);
//                    break;
//                case R.id.Isha:
//                    //DO something
//                    TimeSet(ishaedit);
//                    break;
//                case R.id.Jumuah:
//                    //DO something
//                    TimeSet(jummahedit);
//                    break;
//            }
//
//        }
//    };
//
//    public void TimeSet(TextView t)
//    {
//        // TODO Auto-generated method stub
//        Calendar mcurrentTime = Calendar.getInstance();
//        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
//        int minute = mcurrentTime.get(Calendar.MINUTE);
//        TimePickerDialog mTimePicker;
//        t1 = t;
//        mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
//            @Override
//            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
//
//                mhour = "" +selectedHour;
//                minu = "" + selectedMinute;
//                if(selectedHour < 10)
//                {
//                    mhour = "0" + selectedHour;
//                }
//                if(selectedMinute < 10)
//                {
//                    minu = "0" + selectedMinute;
//                }
//
//
//                if(selectedHour > 12)
//                {
//                    mh =(selectedHour-12);
//                    if(mh < 10)
//                    {
//                        hou = "0" + mh;
//                    }
//                    t1.setText( hou + ":" + minu + " PM" );
//                }
//                else if(selectedHour==12)
//                {
//                    t1.setText( mhour + ":" + minu + " PM" );
//                }
//                else
//                {
//                    t1.setText( mhour + ":" + minu + " AM");
//                }
//            }
//        }, hour, minute, false);//Yes 24 hour time
//        mTimePicker.setTitle("Select Time");
//        mTimePicker.show();
//    }
//}
//*/
