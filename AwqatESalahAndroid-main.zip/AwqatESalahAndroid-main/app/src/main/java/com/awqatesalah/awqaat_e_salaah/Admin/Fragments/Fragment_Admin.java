package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.Admin.Adapters.AdminGridApapter;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.AdminGridModel;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;

import java.util.ArrayList;

import mehdi.sakout.fancybuttons.FancyButton;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class Fragment_Admin extends GATrackingFragment {

    private FancyButton masjids,messsages,profile,changepasword,updatejumuah,updateother;
    private TextView badge;
    ArrayList<AdminGridModel> list = new ArrayList<>();
    MySharedPrefrences shared;
    AdminGridApapter adminGridApapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_ACCOUNTS_DASHBOARD);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view =inflater.inflate(R.layout.fragment_admin,container,false);
        shared = MySharedPrefrences.getInstance(getActivity());

    getToolbar();

        final RecyclerView recList = (RecyclerView) view.findViewById(R.id.recyclerview_masjidsByadmin);
        recList.setHasFixedSize(true);
        GridLayoutManager llm = new GridLayoutManager(getActivity(),2);
         recList.setLayoutManager(llm);
        FragmentManager fm = getFragmentManager();

        list.clear();
        if(shared.getData("Username").equals("salmangajiwala")) {
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminmasjid), "Your Masjids"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.msg), "Message"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminprofile), "Profile"));
            //list.add(new AdminGridModel(getResources().getDrawable(R.drawable.changepassword), "Change Password"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminmasjid), "Add new Masjid"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminmasjid), "Add Location"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.updatebayaan), "Jumuah Update"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.updatebayaan), "Other Update"));
        }else{
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminmasjid), "Your Masjids"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.msg), "Message"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminprofile), "Profile"));
            //list.add(new AdminGridModel(getResources().getDrawable(R.drawable.changepassword), "Change Password"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminmasjid), "Add new Masjid"));
            list.add(new AdminGridModel(getResources().getDrawable(R.drawable.adminmasjid), "Add Location"));

        }
        adminGridApapter = new AdminGridApapter(list,fm,shared,getActivity());
        recList.setAdapter(adminGridApapter);

        //Open Location Suggestion PopUp
        if (getArguments() != null) {
            if (getArguments().getString("isLocationSuggestion", "no").equals("yes")) {
                FragmentTransaction ft = fm.beginTransaction();
                if(fm.getBackStackEntryCount()>0) {
                    for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                        fm.popBackStack();
                    }
                }
                Fragment_UpdateMasjidLocation fragment_updateMasjidLocation = new Fragment_UpdateMasjidLocation();
                Bundle bundle1 = new Bundle();
                bundle1.putString("MasjidId", getArguments().getString("MasjidId"));
                fragment_updateMasjidLocation.setArguments(bundle1);
                fragment_updateMasjidLocation.show(ft, "location");
            }
        }



        //}
        /*masjids = (FancyButton) view.findViewById(R.id.Masjid_Registered);
        messsages = (FancyButton) view.findViewById(R.id.chat);
        profile = (FancyButton) view.findViewById(R.id.Profile);
        changepasword = (FancyButton) view.findViewById(R.id.change_password);
        updatejumuah = (FancyButton) view.findViewById(R.id.jumuah_bayaan);
        updateother = (FancyButton) view.findViewById(R.id.other_bayaan);
        badge = (TextView) view.findViewById(R.id.badge_notification_1);
        shared = MySharedPrefrences.getInstance(getActivity());

        badge.setText(String.valueOf(shared.getMessageCount()));
*/


/*

        masjids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_GetAllMasjidsByAdmin registerFinal = new Fragment_GetAllMasjidsByAdmin();
                Bundle bundle =new Bundle();
                bundle.putString("AdminID",shared.getData("MasjidAdminID"));
                registerFinal.setArguments(bundle);
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });

*/

      /*  messsages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_Chat registerFinal = new Fragment_Chat();
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_Profile registerFinal = new Fragment_Profile();
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });

        changepasword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_ChangePassword registerFinal = new Fragment_ChangePassword();
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();

            }
        });
        if(shared.getData("Username").equals("salmangajiwala")) {
            updatejumuah.setVisibility(View.VISIBLE);
            updateother.setVisibility(View.VISIBLE);
            updatejumuah.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    Fragment_UpdateJumuah registerFinal = new Fragment_UpdateJumuah();
                    ft.replace(R.id.container_fragment, registerFinal);
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            updateother.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    Fragment_UpdateOther registerFinal = new Fragment_UpdateOther();
                    ft.replace(R.id.container_fragment, registerFinal);
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
        }
*/
        return view;

    }

 /*   private void getToolbar(String status) {
        if(status=="No") {
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Admin");
            MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);
            ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        else
        {
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Admin");
            MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
            ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

    }*/
 private void getToolbar() {
     ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Account");
     ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
     ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
     MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);

 }
}
