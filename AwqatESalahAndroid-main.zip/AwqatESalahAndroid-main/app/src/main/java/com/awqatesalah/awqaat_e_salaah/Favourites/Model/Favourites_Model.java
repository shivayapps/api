package com.awqatesalah.awqaat_e_salaah.Favourites.Model;

/**
 * Created by Abubakker on 8/25/2016.
 */
public class Favourites_Model {
    private String Masjidname;
    private String Address;
    private String LastUpdated;
    private String Fajr;
    private String Zuhr;
    private String Asr;
    private String Maghrib;
    private String Isha;
    private String Jumuah;
    private String Eid;
    private String Masjid_ID;

    public String getMasjid_ID() {
        return Masjid_ID;
    }

    public void setMasjid_ID(String masjid_ID) {
        Masjid_ID = masjid_ID;
    }

    public Favourites_Model(String id,String masjidname, String address, String lastUpdated, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah,String eid) {
        Masjidname = masjidname;
        Address = address;
        LastUpdated = lastUpdated;
        Fajr = fajr;
        Zuhr = zuhr;
        Asr = asr;
        Maghrib = maghrib;
        Isha = isha;
        Jumuah = jumuah;
        Eid = eid;
        Masjid_ID=id;

    }

    public String getMasjidname() {
        return Masjidname;
    }

    public void setMasjidname(String masjidname) {
        Masjidname = masjidname;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getLastUpdated() {
        return LastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        LastUpdated = lastUpdated;
    }

    public String getFajr() {
        return Fajr;
    }

    public void setFajr(String fajr) {
        Fajr = fajr;
    }

    public String getZuhr() {
        return Zuhr;
    }

    public void setZuhr(String zuhr) {
        Zuhr = zuhr;
    }

    public String getAsr() {
        return Asr;
    }

    public void setAsr(String asr) {
        Asr = asr;
    }

    public String getMaghrib() {
        return Maghrib;
    }

    public void setMaghrib(String maghrib) {
        Maghrib = maghrib;
    }

    public String getIsha() {
        return Isha;
    }

    public void setIsha(String isha) {
        Isha = isha;
    }

    public String getJumuah() {
        return Jumuah;
    }

    public void setJumuah(String jumuah) {
        Jumuah = jumuah;
    }
}
