package com.awqatesalah.awqaat_e_salaah;

import androidx.fragment.app.Fragment;


/**
 * Created by Abubakker on 12/7/2016.
 */
public class GATrackingSupportFragment extends Fragment {
    @Override
    public void onResume() {
        super.onResume();
        //MyApplication singleton = new MyApplication();
        //singleton.trackScreenView(getClass().getSimpleName());

    }
}

