package com.awqatesalah.awqaat_e_salaah.Bayaan.Fragment;

import android.app.AlertDialog;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Register_Response;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.HashMap;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 9/4/2016.
 */
public class Fragment_UpdateJumuah extends GATrackingFragment {
    AlertDialog dialog;
    SearchableSpinner spinner;
    private EditText text;
    private FancyButton update;
    private GetAllAreas_Response area_response;
    private ArrayList<String> areaList = new ArrayList<>();
    private String CityID;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.updatejumuah,container,false);
        text = (EditText) view.findViewById(R.id.jumuah_bayaan);
        spinner = (SearchableSpinner) view.findViewById(R.id.spinner);
        dialog = new SpotsDialog(getActivity(), R.style.main);
        dialog.show();
        dialog.setCancelable(false);
        spinner.setTitle("Select City");
        update = (FancyButton) view.findViewById(R.id.jumuah_button_update);
        getToolbar();
        getData();
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                CityID = area_response.getResultData()[position].getAreaID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(CityID!=null) {
                    CallRetroApi api = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                    Call<Register_Response> call = api.jumuah(StaticFunction.getValue("&A52E6yF>>2q2J22?"), text.getText().toString(), CityID);
                call.enqueue(new Callback<Register_Response>() {
                    @Override
                    public void onResponse(Call<Register_Response> call, Response<Register_Response> response) {
                        if(response.body().getSuccess().toString().equals("true"))
                        {
                            Log.d("update_jumuah_response", response.body().toString());

                            //getAlldata

                            new MaterialDialog.Builder(getActivity()).title("Awqat-e-Salah")
                                    .content("Jumuah Bayaan Updated").positiveText("Done").show();
                        }
                        else
                        {

                            new MaterialDialog.Builder(getActivity()).title("Error")
                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Register_Response> call, Throwable t) {
                        StaticFunction.NoConnectionDialog(getActivity());

                    }
                });
            }
            else
            {
                Toast.makeText(getActivity(),"Please select the city",Toast.LENGTH_LONG).show();
            }
            }
        });

        return view;
    }

    private void getData() {
        if (areaList.isEmpty()) {
            CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
            MySharedPrefrences sharedPrefrences = MySharedPrefrences.getInstance(getActivity());
            HashMap<String, Integer> param = new HashMap<>();
            param.put("CityID", sharedPrefrences.getState());
            Call<GetAllAreas_Response> call1 = get.areaByCity(StaticFunction.getValue("v6Ep==pC62DqJr:EJxs"), param);

            call1.enqueue(new Callback<GetAllAreas_Response>() {
                @Override
                public void onResponse(Call<GetAllAreas_Response> call, Response<GetAllAreas_Response> response) {
                    if (response.body() != null) {
                        if (response.body().getSuccess().equals("true")) {
                            Log.d("Jumuah_bayaan_response", response.body().toString());

                            area_response = response.body();
                            for (int i = 0; i < response.body().getResultData().length; i++) {
                                areaList.add(response.body().getResultData()[i].getAreaName());
                            }

                            dialog.dismiss();
                            //  progress.hide();
                            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(),R.layout.spinneritem,areaList);
                            spinner.setAdapter(adapter);
                           /* if(!getPrefs.getString("city","null").equals("null")){
                                spinner.setSelectedIndex(Integer.parseInt(getPrefs.getString("city","null")));
                                cityID = area_response.getResultData()[Integer.parseInt(getPrefs.getString("city","null"))].getAreaID();
                            }*/
                        } else {
                            new MaterialDialog.Builder(getActivity()).title("Error")
                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                            dialog.dismiss();
                            //  progress.hide();
                        }
                    } else {
                        StaticFunction.NoConnectionDialog(getActivity());
                        dialog.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<GetAllAreas_Response> call, Throwable t) {
                    try {
                        StaticFunction.NoConnectionDialog(getActivity());
                    } catch (Exception e) {

                    }
                    dialog.dismiss();
                    //  progress.hide();
                }
            });

        } else {
            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(),R.layout.spinneritem,areaList);
            spinner.setAdapter(adapter);
            dialog.dismiss();
            // progress.hide();
        }
    }
    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Jumuah Bayaan");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
