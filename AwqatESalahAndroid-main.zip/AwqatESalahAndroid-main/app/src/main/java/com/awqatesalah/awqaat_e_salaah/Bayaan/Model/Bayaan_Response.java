package com.awqatesalah.awqaat_e_salaah.Bayaan.Model;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Bayaan_Response
{
    private ResultData[] ResultData;

    private String Success;

    private String Message;


    public ResultData[] getResultData ()
    {
        return ResultData;
    }

    public void setResultData (ResultData[] ResultData)
    {
        this.ResultData = ResultData;
    }

    public String getSuccess ()
    {
        return Success;
    }

    public void setSuccess (String Success)
    {
        this.Success = Success;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }

    @Override
    public String toString()
    {
        return  "ClassPojo [ResultData = "+ResultData+", Message = "+Message+", Success = "+Success+"]";
    }
    public class ResultData
    {
        private String AddedOn;

        private String MuftiName;

        private String BayaanID;

        private String Address;

        private String URL;

        private String Day;

        private String Tareef;

        public String getAddedOn ()
        {
            return AddedOn;
        }

        public void setAddedOn (String AddedOn)
        {
            this.AddedOn = AddedOn;
        }

        public String getMuftiName ()
        {
            return MuftiName;
        }

        public void setMuftiName (String MuftiName)
        {
            this.MuftiName = MuftiName;
        }

        public String getBayaanID ()
        {
            return BayaanID;
        }

        public void setBayaanID (String BayaanID)
        {
            this.BayaanID = BayaanID;
        }

        public String getAddress ()
        {
            return Address;
        }

        public void setAddress (String Address)
        {
            this.Address = Address;
        }

        public String getURL ()
        {
            return URL;
        }

        public void setURL (String URL)
        {
            this.URL = URL;
        }

        public String getDay ()
        {
            return Day;
        }

        public void setDay (String Day)
        {
            this.Day = Day;
        }

        public String getTareef ()
        {
            return Tareef;
        }

        public void setTareef (String Tareef)
        {
            this.Tareef = Tareef;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [AddedOn = "+AddedOn+", MuftiName = "+MuftiName+", BayaanID = "+BayaanID+", Address = "+Address+", URL = "+URL+", Day = "+Day+", Tareef = "+Tareef+"]";
        }
    }
}