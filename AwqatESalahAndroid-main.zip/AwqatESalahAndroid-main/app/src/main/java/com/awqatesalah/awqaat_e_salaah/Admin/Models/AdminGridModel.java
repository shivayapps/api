package com.awqatesalah.awqaat_e_salaah.Admin.Models;

import android.graphics.drawable.Drawable;
import android.widget.TextView;

/**
 * Created by root on 24/2/17.
 */
public class AdminGridModel {
    public Drawable image;
    public String title;


    public AdminGridModel(Drawable image, String title) {
        this.image = image;
        this.title = title;

    }
}
