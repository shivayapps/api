package com.awqatesalah.awqaat_e_salaah;

import android.app.DialogFragment;
import android.app.Fragment;



/**
 * Created by Abubakker on 12/7/2016.
 */
public class GATrackingFragment extends Fragment{
    @Override
    public void onResume() {
        super.onResume();
        //MyApplication singleton = new MyApplication();
        //singleton.trackScreenView(getClass().getSimpleName());

    }
}

