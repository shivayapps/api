package com.awqatesalah.awqaat_e_salaah.TermsCondition.Models;

/**
 * Created by Abubakker on 12/30/2016.
 */
public class TnCModel {
    public String Description;

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public TnCModel(String description) {
        Description = description;
    }
}
