package com.awqatesalah.awqaat_e_salaah.Taqweem;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.IdRes;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.CallbackLocationFetchingActivity;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.awqatesalah.awqaat_e_salaah.TrackGPS;

import java.util.List;
import java.util.Locale;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/31/2016.
 */
public class Fragment_Taqweem extends Fragment {
    private static final int REQUESTPERMISSION = 4567;
    private static int REQUEST_CODE = 1;
    String latitude ;
    String longitude;
     MySharedPrefrences shared;
    AlertDialog dialog;
    int schoolType = 1;
    private TextView subah, tulu, zawal, asr, gurub, isha, islamicdate, englishdate, city, taqweem_name;
    private FancyButton refreshtime, note_taqweem;
    private TrackGPS gps;
    private RadioGroup radioGroup;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_TAQEEEM);

    }

    @Nullable
    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.taqweem, container, false);
        subah = (TextView) view.findViewById(R.id.subah);
        taqweem_name = (TextView) view.findViewById(R.id.taqweem_name);
        tulu = (TextView) view.findViewById(R.id.tulu);
        asr = (TextView) view.findViewById(R.id.asr);
        gurub = (TextView) view.findViewById(R.id.gurub);
        isha = (TextView) view.findViewById(R.id.isha);
        islamicdate = (TextView) view.findViewById(R.id.islamic);
        refreshtime = (FancyButton) view.findViewById(R.id.refresh_time);
        note_taqweem = (FancyButton) view.findViewById(R.id.note_taqweem);
        zawal = (TextView) view.findViewById(R.id.zawal);
        city = (TextView) view.findViewById(R.id.city);
        radioGroup = (RadioGroup) view.findViewById(R.id.taqweem_type);
        englishdate = (TextView) view.findViewById(R.id.english);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Taqweem");
        shared = MySharedPrefrences.getInstance(getActivity());
        dialog = new SpotsDialog(getActivity(), R.style.main);
        dialog.setCancelable(false);
        checkPermissions();


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (checkedId == R.id.shaafi_radio) {
                    //Analytics Event
                    new Analytics(getActivity()).logTaqweemMaslakChangeEvent("shaafi");

                    schoolType = 0;
                    shared.saveSchoolType(0);
                    Intent intent = new Intent(getActivity(), CallbackLocationFetchingActivity.class);
                    startActivityForResult(intent, REQUEST_CODE);
                }
                if (checkedId == R.id.hanfi_radio) {
                    //Analytics Event
                    new Analytics(getActivity()).logTaqweemMaslakChangeEvent("hanfi");

                    schoolType = 1;
                    shared.saveSchoolType(1);
                    Intent intent = new Intent(getActivity(), CallbackLocationFetchingActivity.class);
                    startActivityForResult(intent, REQUEST_CODE);
                }
            }
        });

        initializeValues();

        if (shared.getSchoolType() == 1) {
            schoolType = 1;
            radioGroup.check(R.id.hanfi_radio);
            taqweem_name.setText("Hanfi Maslak");
        } else {
            schoolType = 0;
            radioGroup.check(R.id.shaafi_radio);
            taqweem_name.setText("Shaafi Maslak");
        }

        note_taqweem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Analytics
                new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_TAQEEEM_NOTES);
                //Analytics Event
                new Analytics(getActivity()).logTaqweemNotesClickEvent();

                new MaterialDialog.Builder(getActivity()).customView(R.layout.taqweem_notes, true).show();
            }
        });
        refreshtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Analytics Event
                new Analytics(getActivity()).logTaqweemRefreshClickEvent();

                /*gps = new TrackGPS(getActivity());


                if (gps.canGetLocation()) {


                    longitude = String.valueOf(gps.getLongitude());
                    latitude = String.valueOf(gps.getLatitude());
                    if(!latitude.equals("0.0") && !longitude.equals("0.0") && latitude!=null && longitude!=null) {
                        getTaqweem(longitude, latitude, shared, dialog);
                    }else
                    {
                        longitude = String.valueOf(gps.getLongitude());
                        latitude = String.valueOf(gps.getLatitude());
                        Toast.makeText(getActivity(),"Some Error occurred  in getting your location , try again",Toast.LENGTH_LONG).show();
                    }
                } else {

                    gps.showSettingsAlert();
                    //getFromLocation();
                }*/
                Intent intent = new Intent(getActivity(), CallbackLocationFetchingActivity.class);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });

        return view;
    }

    private void initializeValues() {
        try {
                Intent intent = new Intent(getActivity(), CallbackLocationFetchingActivity.class);
                startActivityForResult(intent, REQUEST_CODE);

        }
        catch (Exception e) {

        }
    }

    @Override
    public void onResume() {
        super.onResume();

        /*Intent intent = new Intent(getActivity(),CallbackLocationFetchingActivity.class);
        startActivityForResult(intent,REQUEST_CODE);*/
        /*if(shared!=null && dialog!=null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(StaticFunction.getValue("9EEAi^^HHH]2HB2E6D2=29]4@>"))
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            gps = new TrackGPS(getActivity());


            if (gps.canGetLocation()) {


                longitude = String.valueOf(gps.getLongitude());
                latitude = String.valueOf(gps.getLatitude());
                if (!latitude.equals("0.0") && !longitude.equals("0.0") && latitude != null && longitude != null) {
                    getTaqweem(longitude, latitude, shared, dialog);
                } else {
                    longitude = String.valueOf(gps.getLongitude());
                    latitude = String.valueOf(gps.getLatitude());
                    Toast.makeText(getActivity(), "Some Error occurred  in getting your location , try again", Toast.LENGTH_LONG).show();
                }
            } else {

                gps.showSettingsAlert();
                //getFromLocation();
            }
        }*/
    }

    private void getTaqweem(final String longitude, final String latitude, final MySharedPrefrences shared, final AlertDialog dialog, final int schoolType) {
        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
        Call<Taqweem_Response> call1 = get.taqweem(StaticFunction.getValue("v6E%2BH66>"), longitude, latitude, schoolType, shared.getState(), Integer.parseInt(shared.getAreaID()),StaticFunction.getFormatedDate());
        dialog.show();
        call1.enqueue(new Callback<Taqweem_Response>() {
            @Override
            public void onResponse(Call<Taqweem_Response> call, Response<Taqweem_Response> response) {
                if(response.body().getSuccess().equals("true")) {
                    Log.d("taqweem_response", response.body().toString());
                    subah.setText(response.body().getResultData().getFajr());
                    zawal.setText(response.body().getResultData().getDhuhr());
                    asr.setText(response.body().getResultData().getAsr());
                    gurub.setText(response.body().getResultData().getSunset());
                    isha.setText(response.body().getResultData().getIsha());
                    islamicdate.setText(response.body().getResultData().getHijriDate());
                    tulu.setText(response.body().getResultData().getSunrise());
                    englishdate.setText(response.body().getResultData().getEnglishDate());

                    if (schoolType == 1) {
                        taqweem_name.setText("Hanfi Maslak");
                    } else {
                        taqweem_name.setText("Shaafi Maslak");
                    }


                    shared.saveData("subah",subah.getText().toString());
                    shared.saveData("zawal",zawal.getText().toString());
                    shared.saveData("asr",asr.getText().toString());
                    shared.saveData("gurub",gurub.getText().toString());
                    shared.saveData("isha",isha.getText().toString());
                    shared.saveData("islamicdate",islamicdate.getText().toString());
                    shared.saveData("tulu",tulu.getText().toString());
                    shared.saveData("englishdate",englishdate.getText().toString());
                    setCity(latitude,longitude,city);
                    Toast.makeText(getActivity(),"Taqweem refresh done",Toast.LENGTH_LONG).show();

                    dialog.dismiss();
                }
                else
                {
                    dialog.dismiss();
                    new MaterialDialog.Builder(getActivity()).title("Error")
                            .content(response.body().getMessage()).positiveText("Try Again").show();
                }
            }

            @Override
            public void onFailure(Call<Taqweem_Response> call, Throwable t) {
                dialog.dismiss();
                StaticFunction.NoConnectionDialog(getActivity());
            }
        });

    }

    public void setCity(String latitude,String longitude,TextView city) {
        Geocoder geocoder = new Geocoder(getActivity(), Locale.ENGLISH);
        if (geocoder != null) {
            try {
                /**
                 * Geocoder.getFromLocation - Returns an array of Addresses
                 * that are known to describe the area immediately surrounding the given latitude and longitude.
                 */
                Log.d("Getting Address", "");
                List<Address> addresses = geocoder.getFromLocation(Double.parseDouble(latitude), Double.parseDouble(longitude), 1);
                Log.d("LOCATION", addresses.get(0).toString());
                Log.d("State", addresses.get(0).getAdminArea());
                if (addresses.get(0) != null && addresses.get(0).getLocality() != null) {
                    city.setText(addresses.get(0).getLocality().toString());
                    shared.saveData("taqweem_city", city.getText().toString());
                }
            } catch (Exception e) {
                //e.printStackTrace();
                Log.e("CAtched", "Impossible to connect to Geocoder", e);
            }
        }
    }
    private void checkPermissions() {
        String[] permissions = {
                "android.permission.ACCESS_NETWORK_STATE",
                "android.permission.ACCESS_COARSE_LOCATION",
                "android.permission.ACCESS_FINE_LOCATION",
        };

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED |
                    getActivity().checkSelfPermission(android.Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED |
                    getActivity().checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    ) {
                requestPermissions(permissions, REQUESTPERMISSION);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Bundle bundle1 = data.getExtras();
                Double latitude = bundle1.getDouble("latitude");
                Double longitude = bundle1.getDouble("longitude");

                if (latitude != null && longitude != null && latitude != 0.0 && longitude != 0.0) {
                    getTaqweem(String.valueOf(longitude), String.valueOf(latitude), shared, dialog, schoolType);
                }
            }

        }
    }
}
