package com.awqatesalah.awqaat_e_salaah.TermsCondition.Models;

/**
 * Created by Abubakker on 12/30/2016.
 */
public class TnC_Response {

    public String Success ;
    public String Message;
    public ResultDataTC ResultData;

    public String getSuccess() {
        return Success;
    }

    public void setSuccess(String success) {
        Success = success;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public ResultDataTC getResultData() {
        return ResultData;
    }

    public void setResultData(ResultDataTC resultData) {
        ResultData = resultData;
    }

    public class ResultDataTC{
        public String Title;
        public String Description;

        public String getDescription() {
            return Description;
        }

        public void setDescription(String description) {
            Description = description;
        }

        public String getTitle() {
            return Title;
        }

        public void setTitle(String title) {
            Title = title;
        }
    }

}

