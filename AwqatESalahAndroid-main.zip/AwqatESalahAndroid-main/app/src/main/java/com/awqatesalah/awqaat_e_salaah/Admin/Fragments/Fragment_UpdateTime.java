package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.database.Cursor;
import android.graphics.Paint;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.BuildConfig;
import com.awqatesalah.awqaat_e_salaah.DBHelper;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;
import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class Fragment_UpdateTime extends GATrackingFragment {
    private String mhour,minu,hou;
    private int mh;
    private TextView ufajredit,uzuhredit,uasredit,umaghribedit,uishaedit,ujummahedit;
    private FancyButton update;
    private TextView umasjidname;
    private TextView t1;
    private DBHelper dbHelper;

    @BindView(R.id.eid_row)
    TableRow eid_row;

    @BindView(R.id.UEid)
    TextView UEid;

    @BindView(R.id.fajrCancel)
    ImageView fajrCancel;

    @BindView(R.id.asrCancel)
    ImageView asrCancel;

    @BindView(R.id.zuhrCancel)
    ImageView zuhrCancel;

    @BindView(R.id.maghribCancel)
    ImageView maghribCancel;

    @BindView(R.id.ishaCancel)
    ImageView ishaCancel;

    @BindView(R.id.jumuahCancel)
    ImageView jumuahCancel;

    @BindView(R.id.eidCancel)
    ImageView eidCancel;

    private View.OnClickListener onClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            switch (v.getId()) {
                case R.id.UFajr:
                    //DO something
                    TimeSet(ufajredit);
                    break;
                case R.id.UZuhr:
                    //DO something
                    TimeSet(uzuhredit);
                    break;
                case R.id.UAsr:
                    //DO something
                    TimeSet(uasredit);
                    break;
                case R.id.UMaghrib:
                    //DO something
                    TimeSet(umaghribedit);
                    break;
                case R.id.UIsha:
                    //DO something
                    TimeSet(uishaedit);
                    break;
                case R.id.UJumuah:
                    //DO something
                    TimeSet(ujummahedit);
                    break;
                case R.id.UEid:
                    //DO something
                    TimeSet(UEid);
                    break;
            }

        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_ADMIN_MASJID_DETAILS);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.update_time,container,false);
        ButterKnife.bind(this,view);
        StaticFunction.displayUpdateEidTime(eid_row,getActivity());

        getToolbar();
        ufajredit = (TextView) view.findViewById(R.id.UFajr);
        uzuhredit = (TextView) view.findViewById(R.id.UZuhr);
        uasredit = (TextView) view.findViewById(R.id.UAsr);
        umaghribedit = (TextView) view.findViewById(R.id.UMaghrib);
        uishaedit = (TextView) view.findViewById(R.id.UIsha);
        ujummahedit = (TextView) view.findViewById(R.id.UJumuah);
        update = (FancyButton) view.findViewById(R.id.Update);

        umasjidname =(TextView) view.findViewById(R.id.Umasjidname);

        ufajredit.setOnClickListener(onClickListener);
        uzuhredit.setOnClickListener(onClickListener);
        uasredit.setOnClickListener(onClickListener);
        umaghribedit.setOnClickListener(onClickListener);
        uishaedit.setOnClickListener(onClickListener);
        ujummahedit.setOnClickListener(onClickListener);
        UEid.setOnClickListener(onClickListener);

        umasjidname.setPaintFlags(umasjidname.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        umasjidname.setText(getValue("Update_Masjid_Name"));
        ufajredit.setText(getValue("Update_Fajr"));
        uzuhredit.setText(getValue("Update_Zuhr"));
        uasredit.setText(getValue("Update_Asr"));
        umaghribedit.setText(getValue("Update_Maghrib"));
        uishaedit.setText(getValue("Update_Isha"));
        ujummahedit.setText(getValue("Update_Jumuah"));
        UEid.setText(getValue("Update_Eid"));

        final AlertDialog dialog =new SpotsDialog(getActivity(), R.style.Update);
        dialog.setCancelable(false);

update.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        dialog.show();
        if(StaticFunction.isOnline(getActivity())) {

            //Analytics Event
            new Analytics(getActivity()).logMasjidAdminTimeUpdatedEvent();

            CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
            DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            String date = df.format(Calendar.getInstance().getTime());
            Call<Update_Response> call1 = get.Update_Time(StaticFunction.getValue("&A52E6|2D;:5%:>:?8D"), getValue("MasjidAdminID"), getValue("MasjidID"), "", "", "", "", "", "", getValue(ufajredit), getValue(uzuhredit), getValue(uasredit), getValue(umaghribedit), getValue(uishaedit), getValue(ujummahedit), getValue(UEid), date);

            call1.enqueue(new Callback<Update_Response>() {
                @Override
                public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("update_time_response", response.body().getMessage());
                        new MaterialDialog.Builder(getActivity()).title("Update Done")
                                .content(response.body().getMessage()).positiveText("Jazakallah").show();

                        try {
                            StaticFunction.removeFromCache(StaticFunction.getBaseValue(BuildConfig.BASE_URL) + StaticFunction.getValue("v6E|2D;:5Du@C|2D;:5p5>:?") + "?MasjidAdminId=" + getValue("masjidadminid"), getActivity());
                        }catch (Exception e){

                        }
                        dialog.dismiss();
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                        dialog.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<Update_Response> call, Throwable t) {
                    StaticFunction.NoConnectionDialog(getActivity());
                    dialog.dismiss();
                }
            });
        }else
        {
            {
                dialog.dismiss();
                dbHelper = new DBHelper(getActivity());
                dbHelper.openDB();
                Cursor cursor = dbHelper.getAdminUpdateFlag(Integer.parseInt(getValue("MasjidID")));

                if(cursor.getCount()>0) {
                    DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                    String date = df.format(Calendar.getInstance().getTime());
                    long resultUpdate =   dbHelper.update_update(Integer.parseInt(getValue("MasjidID")), getValue(ufajredit), getValue(uzuhredit), getValue(uasredit),
                            getValue(umaghribedit), getValue(uishaedit),
                            getValue(ujummahedit),getValue(UEid),"pending",date.toString());
                    if(resultUpdate == 1){
                        new MaterialDialog.Builder(getActivity()).title("Update Done")
                                .content("Note : Your Update will be reach us automatically when you switch on the internet").positiveText("Jazakallah").show();

                    }
                    dbHelper.closeDB();
                }
                else
                {
                    DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                    String date = df.format(Calendar.getInstance().getTime());
                    long resultInsert = dbHelper.insert_Update(Integer.parseInt(getValue("MasjidAdminID")),Integer.parseInt(getValue("MasjidID")), getValue(ufajredit), getValue(uzuhredit), getValue(uasredit), getValue(umaghribedit), getValue(uishaedit), getValue(ujummahedit),getValue(UEid),"pending",date.toString());
                    if(resultInsert == -1){
                        Toast.makeText(getActivity(), "Some error occurred while inserting", Toast.LENGTH_SHORT).show();
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Update Done")
                                .content("Note : Your Update will be reach us automatically when you switch on the internet").positiveText("Jazakallah").show();
                    }
                    dbHelper.closeDB();
                }


            }
        }
    }
});
        fajrCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ufajredit.setText("-");
            }
        });
        zuhrCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uzuhredit.setText("-");
            }
        });
        asrCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uasredit.setText("-");
            }
        });
        maghribCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                umaghribedit.setText("-");
            }
        });
        ishaCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uishaedit.setText("-");
            }
        });
        jumuahCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ujummahedit.setText("-");
            }
        });
        eidCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UEid.setText("-");
            }
        });


        return view;
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Masjids");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private String getValue(String key)
    {
        return getArguments().getString(key,"-");
    }

    private String getValue(TextView key)
    {
        return key.getText().toString().trim();
    }

    public void TimeSet(final TextView t)
    {
        int hour;
        int minute;
        // TODO Auto-generated method stub
        if (!t.getText().equals("-") && !t.getText().equals("--:--") && !t.getText().equals("")) {
            Boolean isTimePM = t.getText().toString().contains("PM");
            String[] time = t.getText().toString().replace("AM", "").replace("PM", "").trim().replaceAll("\\p{Z}", "").split(":");
            hour = Integer.parseInt(time[0]);
            minute = Integer.parseInt(time[1]);

            if(isTimePM){
                hour = hour+12;
            }

        } else {
            Calendar mcurrentTime = Calendar.getInstance();
            hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            minute = mcurrentTime.get(Calendar.MINUTE);
        }
        TimePickerDialog mTimePicker;
        t1 = t;
        mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                StaticFunction.setNamazTime(selectedHour,selectedMinute,t1,t);

            }
        }, hour, minute, false);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }



}
