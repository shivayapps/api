package com.awqatesalah.awqaat_e_salaah.Admin.Models;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class MasjidByAdmin_Model {
    private String Masjid_Name;
    private String Masjid_Address;
    private String Status;

    public MasjidByAdmin_Model(String masjid_Name, String masjid_Address, String status) {
        Masjid_Name = masjid_Name;
        Status = status;
        Masjid_Address = masjid_Address;
    }

    public String getMasjid_Name() {
        return Masjid_Name;
    }

    public void setMasjid_Name(String masjid_Name) {
        Masjid_Name = masjid_Name;
    }

    public String getMasjid_Address() {
        return Masjid_Address;
    }

    public void setMasjid_Address(String masjid_Address) {
        Masjid_Address = masjid_Address;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}
