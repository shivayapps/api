package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.SpinnerAdapter;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Register_Response;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/25/2016.
 */
public class Fragment_AddMasjid extends GATrackingFragment {

    private MaterialEditText masjidname,address;
    private FancyButton add_masjid;
    private SearchableSpinner area;
    private String AreaID="";
    private String areaName="";
    private TextView fajredit,zuhredit,asredit,maghribedit,ishaedit,jummahedit;
    private String mhour,minu,hou;
    private int mh;
    private ArrayList<String> areaList = new ArrayList<>();
    private TextView t1;
    private CheckBox isPerformend;
    private TableRow row;
    private GetAllAreas_Response area_response;
    SpotsDialog dialog;
    private View.OnClickListener onClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            switch (v.getId()) {
                case R.id.addFajr:
                    //DO something
                    TimeSet(fajredit);
                    break;
                case R.id.addZuhr:
                    //DO something
                    TimeSet(zuhredit);
                    break;
                case R.id.addAsr:
                    //DO something
                    TimeSet(asredit);
                    break;
                case R.id.addMaghrib:
                    //DO something
                    TimeSet(maghribedit);
                    break;
                case R.id.addIsha:
                    //DO something
                    TimeSet(ishaedit);
                    break;
                case R.id.addJumuah:
                    //DO something
                    TimeSet(jummahedit);
                    break;
            }

        }
    };

    @Override
    public void onPause() {
        super.onPause();
        android.app.Fragment searchableSpinnerDialog = getFragmentManager().findFragmentByTag("TAG");

        if (searchableSpinnerDialog != null && searchableSpinnerDialog.isAdded()) {
            getFragmentManager().beginTransaction().remove(searchableSpinnerDialog).commit();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_ADD_NEW_MASJID);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.add_masjid,container,false);
        getToolbar();

        masjidname = (MaterialEditText) view.findViewById(R.id.addMasjidName);
        address = (MaterialEditText) view.findViewById(R.id.addAddress);
        fajredit = (TextView) view.findViewById(R.id.addFajr);
        zuhredit = (TextView) view.findViewById(R.id.addZuhr);
        asredit = (TextView) view.findViewById(R.id.addAsr);
        maghribedit = (TextView) view.findViewById(R.id.addMaghrib);
        ishaedit = (TextView) view.findViewById(R.id.addIsha);
        jummahedit = (TextView) view.findViewById(R.id.addJumuah);
        add_masjid = (FancyButton) view.findViewById(R.id.add_masjid);
        isPerformend = (CheckBox) view.findViewById(R.id.addisPerformed);
        row = (TableRow) view.findViewById(R.id.row);
        area = (SearchableSpinner) view.findViewById(R.id.addArea);
        area.setTitle("Select City");
        dialog = new SpotsDialog(getActivity(), R.style.main);
        dialog.setCancelable(false);

        MySharedPrefrences sharedPrefrences = MySharedPrefrences.getInstance(getActivity());

        if(area_response==null) {
            CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
            HashMap<String, Integer> param = new HashMap<>();
            param.put("CityID", sharedPrefrences.getState());
            Call<GetAllAreas_Response> call1 = get.areaByCity(StaticFunction.getValue("v6Ep==pC62DqJr:EJxs"), param);
            call1.enqueue(new Callback<GetAllAreas_Response>() {
                @Override
                public void onResponse(Call<GetAllAreas_Response> call, Response<GetAllAreas_Response> response) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("area_response", response.body().toString());

                        for (int i = 0; i < response.body().getResultData().length; i++) {
                            areaList.add(response.body().getResultData()[i].getAreaName());
                        }
                        area_response = response.body();
                        try {
                            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, areaList);
                            area.setAdapter(adapter);
                        }catch (Exception e){

                        }
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                    }
                }

                @Override
                public void onFailure(Call<GetAllAreas_Response> call, Throwable t) {
                    StaticFunction.NoConnectionDialog(getActivity());
                }
            });

        }
        else
        {
            for (int i = 0; i < area_response.getResultData().length; i++) {
                areaList.add(area_response.getResultData()[i].getAreaName());
            }
            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(),R.layout.spinneritem,areaList);
            area.setAdapter(adapter);

        }

        area.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                AreaID = area_response.getResultData()[position].getAreaID();
                areaName = area_response.getResultData()[position].getAreaName();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        isPerformend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isPerformend.isChecked())
                {
                    row.setVisibility(View.VISIBLE);
                }
                else
                {
                    row.setVisibility(View.GONE);
                }
            }
        });


        fajredit.setOnClickListener(onClickListener);
        zuhredit.setOnClickListener(onClickListener);
        asredit.setOnClickListener(onClickListener);
        maghribedit.setOnClickListener(onClickListener);
        ishaedit.setOnClickListener(onClickListener);
        jummahedit.setOnClickListener(onClickListener);

        MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());
        final String MasjidAdminID =(shared.getData("MasjidAdminID").toString());


        add_masjid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidAdminAddNewMasjidEvent(areaName,AreaID);

                if (!getValue(masjidname).equals("") && !getValue(address).equals("")&& !AreaID.equals("") && !getValue(fajredit).equals("") && !getValue(zuhredit).equals("") && !getValue(asredit).equals("") && !getValue(maghribedit).equals("") && !getValue(ishaedit).equals("")) {

                    //if Jumuah is Performed
                    if(isPerformend.isChecked() && getValue(jummahedit).equals("")){
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content("Jumuah time cannot be empty if it is performed. Please select Jumuah time").positiveText("Try Again").show();
                        return;
                    }
                    dialog.show();
                    CallRetroApi call_update = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                    Call<Register_Response> call = call_update.add_masjid(StaticFunction.getValue("p55}6H|2D;:5"), MasjidAdminID, getValue(masjidname), getValue(address), AreaID, getValue(fajredit), getValue(zuhredit), getValue(asredit), getValue(maghribedit), getValue(ishaedit), getValue(jummahedit));

                    call.enqueue(new Callback<Register_Response>() {
                        @Override
                        public void onResponse(Call<Register_Response> call, Response<Register_Response> response) {
                            if (response.body().getSuccess().equals("true")) {
                               dialog.dismiss();
                                Log.d("masjid_added_response", response.body().getMessage());
                                new MaterialDialog.Builder(getActivity())
                                        .content(response.body().getMessage()).positiveText("DONE").show();
                                View view = getActivity().getCurrentFocus();
                                if (view != null) {
                                    InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                }
                                //getFragmentManager().popBackStack("admin", FragmentManager.POP_BACK_STACK_INCLUSIVE);
                                getFragmentManager().popBackStack();
                            } else {
                               dialog.dismiss();
                                new MaterialDialog.Builder(getActivity()).title("Error")
                                        .content(response.body().getMessage()).positiveText("Try Again").show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Register_Response> call, Throwable t) {
                            StaticFunction.NoConnectionDialog(getActivity());
                            dialog.dismiss();

                        }
                    });
                }
                else
                {
                   dialog.dismiss();
                    if (masjidname.getText().toString().equals("")) {
                        masjidname.setError("Masjid Name Cannot be empty");
                    }
                    if (address.getText().toString().equals("")) {
                        address.setError("Address Cannot be empty");
                    }
                    if (AreaID.equals("")) {
                        Toast.makeText(getActivity(),"Select Area",Toast.LENGTH_LONG).show();
                    }
                    new MaterialDialog.Builder(getActivity()).title("Error")
                            .content("Insert All Namaz time").positiveText("Try Again").show();
                }
            }
        });


        return view;
    }

    private String getValue(String key)
    {
        return getArguments().getString(key,"-");
    }


    private String getValue(TextView key)
    {
        return key.getText().toString().trim();
    }

    public void TimeSet(final TextView t)
    {
        int hour;
        int minute;
        // TODO Auto-generated method stub
        if (!t.getText().equals("-") && !t.getText().equals("--:--") && !t.getText().equals("")) {
            Boolean isTimePM = t.getText().toString().contains("PM");
            String[] time = t.getText().toString().replace("AM", "").replace("PM", "").trim().replaceAll("\\p{Z}", "").split(":");
            hour = Integer.parseInt(time[0]);
            minute = Integer.parseInt(time[1]);

            if(isTimePM){
                hour = hour+12;
            }
        } else {
            Calendar mcurrentTime = Calendar.getInstance();
            hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            minute = mcurrentTime.get(Calendar.MINUTE);
        }
        TimePickerDialog mTimePicker;
        t1 = t;
        mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                StaticFunction.setNamazTime(selectedHour,selectedMinute,t1,t);
            }
        }, hour, minute, false);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Add Masjids");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
