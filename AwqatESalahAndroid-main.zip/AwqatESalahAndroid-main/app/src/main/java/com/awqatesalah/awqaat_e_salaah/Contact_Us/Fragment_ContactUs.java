package com.awqatesalah.awqaat_e_salaah.Contact_Us;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Abubakker on 9/4/2016.
 */
public class Fragment_ContactUs extends GATrackingFragment {
    //private TextView number_india,number_newzealand;
    @BindView(R.id.contact_us_webview)
    WebView contact_us_webview;

    MySharedPrefrences mySharedPrefrences;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_CONTACT_US);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        setHasOptionsMenu(true);
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.contactus_webview,container,false);
        ButterKnife.bind(this,view);
        mySharedPrefrences = new MySharedPrefrences(getActivity());
        String finalResult = mySharedPrefrences.getContactUs();
        contact_us_webview.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("tel"))
                {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                }  else if (url.startsWith("mailto")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    view.getContext().startActivity(intent);
                }  else if (url.startsWith("http") == false) {
                    url = "http://" + url;
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    view.getContext().startActivity(intent);
                } else{
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    view.getContext().startActivity(intent);
                }

                return true;

            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

                String url = request.getUrl().toString();
                if (url.startsWith("tel"))
                {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                }  else if (url.startsWith("mailto")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    view.getContext().startActivity(intent);
                }  else if (url.startsWith("http") == false) {
                    url = "http://" + url;
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    view.getContext().startActivity(intent);
                } else{
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    view.getContext().startActivity(intent);
                }



                return true;

            }

        });
        contact_us_webview.loadData(finalResult, "text/html", null);
       // number_india = (TextView) view.findViewById(R.id.number_india);
       // number_newzealand = (TextView) view.findViewById(R.id.number_newzealand);
        getToolbar();

        /*number_india.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                // TODO Auto-generated method stub
                Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:+918200650400"));
                startActivity(intent);
            }
        });
        number_newzealand.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:+64212665719"));
                startActivity(intent);
            }
        });*/
        return view;
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Contact Us");
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.getItem(2).setVisible(false);
    }
}
