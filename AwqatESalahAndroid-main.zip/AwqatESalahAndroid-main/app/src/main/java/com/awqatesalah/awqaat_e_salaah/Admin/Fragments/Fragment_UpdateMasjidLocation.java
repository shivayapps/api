package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Adapters.AdminMasjids;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetMasjidByAdmin_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.CallbackLocationFetchingActivity;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.HashMap;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by root on 19/5/17.
 */

public class Fragment_UpdateMasjidLocation extends DialogFragment implements OnMapReadyCallback {


    private static int REQUEST_CODE = 1;
    GoogleMap mGoogleMap;
    SearchableSpinner spinner;
    String MasjidID = null;
    GetMasjidByAdmin_Response masjidByAdmin_response;
    Double longitude;
    MapFragment mapFragment;
    AlertDialog dialog;
    private AdminMasjids adminMasjids;
    private ArrayList<String> list = new ArrayList<>();
    private FancyButton location_button_update;
    private double mLatitude = 0.0;
    private double mLongitude = 0.0;

    String selectedMasjidId = null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_ADD_MASJID_LOCATION);

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        View view = getActivity().getLayoutInflater().inflate(R.layout.masjid_location_update_layout, new LinearLayout(getActivity()), false);

        final Dialog builder = new Dialog(getActivity());
        builder.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        builder.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //builder.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        builder.setContentView(view);
        builder.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);


        spinner = (SearchableSpinner) builder.findViewById(R.id.spinner);
        location_button_update = (FancyButton) builder.findViewById(R.id.location_button_update);


        spinner.setTitle("Select Masjid");
        dialog = new SpotsDialog(getActivity(), R.style.main);
        dialog.setCancelable(false);


        if (getArguments() != null) {
            if (getArguments().getString("MasjidId", null)!=null) {
                selectedMasjidId = getArguments().getString("MasjidId", null);
            }
        }



        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                MasjidID = masjidByAdmin_response.getResultData()[position].getMasjidID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        Intent intent = new Intent(getActivity(), CallbackLocationFetchingActivity.class);
        startActivityForResult(intent, REQUEST_CODE);

        mapFragment = (MapFragment) getFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        final MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());

        getData(shared);

        location_button_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidAdminAddNewLocationEvent();

                if (MasjidID != null) {
                    if (mLatitude != 0.0 && mLongitude != 0.00) {
                        postDataToServer(shared.getData("MasjidAdminID"), MasjidID, mLatitude, mLongitude);
                    } else {
                        Toast.makeText(getActivity(), "Unable to find your location", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Please select Masjid", Toast.LENGTH_LONG).show();
                }

            }
        });
        return builder;

    }

    private void postDataToServer(String masjidAdminID, String masjidID, double mLatitude, double mLongitude) {
        dialog.show();

        CallRetroApi api = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
        ;
        Call<Update_Response> call = api.updateMasjidLocation(StaticFunction.getValue("&A52E6|2D;:5{@42E:@?"), masjidAdminID, masjidID, mLatitude, mLongitude, "Android");
        call.enqueue(new Callback<Update_Response>() {
            @Override
            public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                if (response.body().getSuccess().toString().equals("true")) {
                    Log.d("Masjid_Location_Done", response.body().toString());

                    new MaterialDialog.Builder(getActivity()).title("Awqat-e-Salah")
                            .content("Masjid Location Updated").positiveText("Done")
                            .show();
                    dialog.dismiss();
                    dismiss();

                } else {

                    new MaterialDialog.Builder(getActivity()).title("Error")
                            .content(response.body().getMessage()).positiveText("Try Again").show();

                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<Update_Response> call, Throwable t) {
                StaticFunction.NoConnectionDialog(getActivity());

                dialog.dismiss();

            }
        });
    }

    private void getData(MySharedPrefrences shared) {


        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        HashMap<String, String> param = new HashMap<>();
        param.put("MasjidAdminId", shared.getData("MasjidAdminID"));
        Call<GetMasjidByAdmin_Response> call1 = get.getAdminMasjid(StaticFunction.getValue("v6E|2D;:5Du@C|2D;:5p5>:?"), param);

        call1.enqueue(new Callback<GetMasjidByAdmin_Response>() {
            @Override
            public void onResponse(Call<GetMasjidByAdmin_Response> call, Response<GetMasjidByAdmin_Response> response) {
                if (response != null) {
                    if (response.body() != null) {
                        if (response.body().getSuccess().equals("true")) {

                            masjidByAdmin_response = response.body();
                            Log.d("Admin_Masjid_List", response.body().toString());
                            list.clear();
                            for (int i = 0; i < response.body().getResultData().length; i++) {
                                list.add(response.body().getResultData()[i].getMasjidName());
                            }

                            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, list);
                            spinner.setAdapter(adapter);

                            //To select Direct Masjid For Location Suggestion Masjid Reminder NOtifications
                            if(selectedMasjidId!=null){
                                for(int i=0;i<response.body().getResultData().length;i++){
                                    if(selectedMasjidId.equals(response.body().getResultData()[i].getMasjidID())){
                                        spinner.setSelection(i);
                                    }
                                }
                            }
                        } else {
                            new MaterialDialog.Builder(getActivity()).title("Error")
                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                        }
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content("Something went wrong").positiveText("ok").show();
                    }
                } else {
                    StaticFunction.NoConnectionDialog(getActivity());
                }
            }


            @Override
            public void onFailure(Call<GetMasjidByAdmin_Response> call, Throwable t) {
                StaticFunction.NoConnectionDialog(getActivity());
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Bundle bundle = data.getExtras();
                mLatitude = bundle.getDouble("latitude");
                mLongitude = bundle.getDouble("longitude");
                Log.d("", "");

                if (mGoogleMap != null) {
                    setUpMap(mLatitude, mLongitude);
                }
            }

        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mGoogleMap = googleMap;
    }

    private void setUpMap(Double lat, Double longitude) {
        mGoogleMap.addMarker(new MarkerOptions().position(new LatLng(lat, longitude)).title("MasjidName"));
        // here is marker Adding code
        mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, longitude), 15));
        // Zoom in, animating the camera.
        mGoogleMap.animateCamera(CameraUpdateFactory.zoomIn());
        // Zoom out to zoom level 10, animating with a duration of 2 seconds.
        mGoogleMap.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        MapFragment f = (MapFragment) getFragmentManager()
                .findFragmentById(R.id.map);
        if (f != null)
            getFragmentManager().beginTransaction().remove(f).commit();
    }
}
