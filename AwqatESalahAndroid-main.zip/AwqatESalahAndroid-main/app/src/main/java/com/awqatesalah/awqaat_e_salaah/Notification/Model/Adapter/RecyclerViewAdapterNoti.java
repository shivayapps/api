package com.awqatesalah.awqaat_e_salaah.Notification.Model.Adapter;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Fragments.Fragment_Notification;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Fragments.Fragment_NotificationDetails;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Models.Notification_Model;
import com.awqatesalah.awqaat_e_salaah.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Abubakker on 8/28/2016.
 */

public class RecyclerViewAdapterNoti extends RecyclerView.Adapter<RecyclerViewAdapterNoti.ContactViewHolder> {
    private List<Notification_Model> list;
    private FragmentManager manager;
    private MySharedPrefrences sharedPrefrences;
    private Fragment_Notification.OnNotificationOpenListener callBack;

    public RecyclerViewAdapterNoti(List<Notification_Model> contactList, FragmentManager manager, MySharedPrefrences sharedPrefrences, Fragment_Notification.OnNotificationOpenListener callBack) {
        this.list = contactList;
        this.manager = manager;
        this.sharedPrefrences = sharedPrefrences;
        this.callBack = callBack;
    }

    @Override
    public RecyclerViewAdapterNoti.ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View itemView = LayoutInflater.
                from(parent.getContext()).
                inflate(R.layout.notification_cardview, parent, false);


        return new ContactViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecyclerViewAdapterNoti.ContactViewHolder holder, int position) {
        final Notification_Model ci = list.get(position);
        holder.title.setText(ci.getTitle());
        holder.date.setText(ci.getDate());

        switch (ci.getType()){
            case "Other":
                holder.image.setImageResource(R.drawable.othernoti);
                break;
            case "Event":
                holder.image.setImageResource(R.drawable.eventnoti);
                break;
            case "Chaand":
                holder.image.setImageResource(R.drawable.chandnoti);
                break;
            case "AppUpdate":
                holder.image.setImageResource(R.drawable.appupdate);
                break;
            case "NewMasjid":
                holder.image.setImageResource(R.drawable.newmasjidnoti);
                break;
            default :
                holder.image.setImageResource(R.drawable.othernoti);
                break;
        }

        if (checkUnreadId(sharedPrefrences, ci.getNotificationID())) {
            holder.title.setTextColor(Color.BLACK);
            holder.date.setTextColor(Color.BLACK);
            holder.badge.setVisibility(View.VISIBLE);
        } else {
            holder.title.setTextColor(Color.GRAY);
            holder.date.setTextColor(Color.GRAY);
            holder.badge.setVisibility(View.GONE);
        }

        holder.card_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteUnreadId(sharedPrefrences, ci.getNotificationID());
                if (callBack != null) {
                    callBack.UpdateUI();
                }
                FragmentManager fm = manager;
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_NotificationDetails updateTime = new Fragment_NotificationDetails();
                Bundle bundle = new Bundle();
                bundle.putString("Title", ci.getTitle());
                bundle.putString("Details", ci.getDetails());
                bundle.putString("Added", ci.getDate());
                updateTime.setArguments(bundle);
                ft.replace(R.id.container_fragment, updateTime);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        protected TextView title, badge;
        protected TextView date;
        protected ImageView image;
        protected CardView card_container;


        public ContactViewHolder(View v) {
            super(v);
            title = (TextView) v.findViewById(R.id.title);
            badge = (TextView) v.findViewById(R.id.badge_notification_1);
            date = (TextView) v.findViewById(R.id.date);
            image = (ImageView) v.findViewById(R.id.imageView);
            card_container = (CardView) v.findViewById(R.id.card_container);


        }
    }

    public Boolean checkUnreadId(MySharedPrefrences pref, String id) {
        ArrayList<String> listOfIds = pref.getUnreadNotificationIds();
        for (int i = 0; i < listOfIds.size(); i++) {
            if (listOfIds.get(i).equals(id)) {
                return true;
            }
        }
        return false;
    }

    public void deleteUnreadId(MySharedPrefrences pref, String id) {
        ArrayList<String> listOfIds = pref.getUnreadNotificationIds();
        for (int i = 0; i < listOfIds.size(); i++) {
            if (listOfIds.get(i).equals(id)) {
                listOfIds.remove(i);

                if (pref.getNotificationCount() > 0) {
                    pref.saveNotificationCount(pref.getNotificationCount() - 1);
                } else {
                    pref.saveNotificationCount(0);
                }
            }
        }
        pref.deleteReadNotificationId(listOfIds);
    }

}
