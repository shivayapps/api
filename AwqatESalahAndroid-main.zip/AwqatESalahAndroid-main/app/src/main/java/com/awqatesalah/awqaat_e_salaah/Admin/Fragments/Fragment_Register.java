package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.HashMap;

import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/21/2016.
 */
public class Fragment_Register extends GATrackingFragment {
    private FancyButton forward;
    private MaterialEditText Username, Password, Name, Number, Address, MasjidName;
    private String SUsername = "", SPassword = "", SName = "", SNumber = "", SAddress = "", SMasjidName = "", SCity, SArea = "";
    private SearchableSpinner City, Area;
    private ArrayList<String> areaList = new ArrayList<>();
    private GetAllAreas_Response area_response;

    @Override
    public void onPause() {
        super.onPause();
        android.app.Fragment searchableSpinnerDialog = getFragmentManager().findFragmentByTag("TAG");

        if (searchableSpinnerDialog != null && searchableSpinnerDialog.isAdded()) {
            getFragmentManager().beginTransaction().remove(searchableSpinnerDialog).commit();
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_preregister, container, false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Register");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        forward = (FancyButton) view.findViewById(R.id.preregister);
        Username = (MaterialEditText) view.findViewById(R.id.Username);
        Password = (MaterialEditText) view.findViewById(R.id.Password);
        Name = (MaterialEditText) view.findViewById(R.id.Name);
        Number = (MaterialEditText) view.findViewById(R.id.Number);
        Address = (MaterialEditText) view.findViewById(R.id.Address);
        MasjidName = (MaterialEditText) view.findViewById(R.id.MasjidName);


        //City = (MaterialSpinner) view.findViewById(R.id.City);
        Area = (SearchableSpinner) view.findViewById(R.id.Area);
        Area.setTitle("Select City");

        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        MySharedPrefrences sharedPrefrences = MySharedPrefrences.getInstance(getActivity());
        HashMap<String, Integer> param = new HashMap<>();
        param.put("CityID", sharedPrefrences.getState());
        Call<GetAllAreas_Response> call1 = get.areaByCity(StaticFunction.getValue("v6Ep==pC62DqJr:EJxs"), param);
        call1.enqueue(new Callback<GetAllAreas_Response>() {
            @Override
            public void onResponse(Call<GetAllAreas_Response> call, Response<GetAllAreas_Response> response) {
                if (response.body().getSuccess().equals("true")) {
                    Log.d("area_response", response.body().getMessage());
                    for (int i = 0; i < response.body().getResultData().length; i++) {
                        areaList.add(response.body().getResultData()[i].getAreaName());
                    }
                    area_response = response.body();
                    SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, areaList);
                    Area.setAdapter(adapter);
                } else {
                    new MaterialDialog.Builder(getActivity()).title("Error")
                            .content(response.body().getMessage()).positiveText("Try Again").show();
                }
            }

            @Override
            public void onFailure(Call<GetAllAreas_Response> call, Throwable t) {
                StaticFunction.NoConnectionDialog(getActivity());
            }
        });

        Area.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SArea = area_response.getResultData()[position].getAreaID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SUsername = getValue(Username);
                SMasjidName = getValue(MasjidName);
                SAddress = getValue(Address);
                SNumber = getValue(Number);
                SPassword = getValue(Password);
                SName = getValue(Name);
                if (SUsername.length() >= 6 && SPassword.length() >= 5 && SMasjidName.length()>=6 && !SAddress.equals("") && StaticFunction.numberValidation(SNumber) && SName.length() >= 6 && !SArea.equals("")) {
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    Fragment_Register_Final registerFinal = new Fragment_Register_Final();
                    Bundle bundle = new Bundle();
                    bundle.putString("username", SUsername);
                    bundle.putString("address", SAddress);
                    bundle.putString("masjidname", SMasjidName);
                    bundle.putString("password", SPassword);
                    bundle.putString("name", SName);
                    bundle.putString("number", SNumber);
                    bundle.putString("city", "surat");
                    bundle.putString("area", SArea);
                    registerFinal.setArguments(bundle);
                    ft.replace(R.id.container_fragment, registerFinal);
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.addToBackStack(null);
                    ft.commit();
                } else {
                    if (SUsername.length() < 6) {
                        Username.setError("Username should be atleast 6 characters");
                    }
                    if (SPassword.length() < 5) {
                        Password.setError("Password should be atleast 5 characters");
                    }
                    if (SAddress.equals("")) {
                        Address.setError("Address Cannot be empty");
                    }
                    if (SName.length() < 6) {
                        Name.setError("Name should be atleast 6 characters");
                    }
                    if (SMasjidName.length() < 6) {
                        MasjidName.setError("Masjid Name should be atleast 6 characters");
                    }
                    if (SArea.equals("")) {
                        Toast.makeText(getActivity(), "Select Area", Toast.LENGTH_LONG).show();
                    }
                    if (!StaticFunction.numberValidation(SNumber)) {
                        Number.setError("Number should be of 9 to 13 digits");
                    }

                }
            }
        });


        return view;
    }

    public String getValue(EditText text) {
        return text.getText().toString().trim();
    }
}
