package com.awqatesalah.awqaat_e_salaah;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import androidx.appcompat.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Login_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.Search.Models.GetAllCountryResponse;
import com.awqatesalah.awqaat_e_salaah.Search.Models.ResponseCities;
import com.google.firebase.messaging.FirebaseMessaging;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by root on 1/10/16.
 */
public class BottomSheetRegister extends BottomSheetDialogFragment {

    @BindView(R.id.countries)
    SearchableSpinner spinner_country;
    @BindView(R.id.states)
    SearchableSpinner spinner_states;
    @BindView(R.id.areas)
    SearchableSpinner spinner_areas;

    @BindView(R.id.btn_register)
    FancyButton btn_register;

    @BindView(R.id.admin_number)
    MaterialEditText admin_number;

    @BindView(R.id.admin_name)
    MaterialEditText admin_name;

    int CountryID = -1;
    int StateID = -1;
    int areaID = -1;

    GetAllCountryResponse allCountryResponse;
    ResponseCities[] responseCities;
    GetAllAreas_Response.ResultDataArea[] getAllAreas_responses;
    private MySharedPrefrences shared;

    String mobileNumber=null;
    String countryCode=null;

    SpotsDialog loaderDialog;
    SpotsDialog loaderDialogArea;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final Dialog dialog = new Dialog(getActivity(), R.style.MyDialogTheme);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        dialog.setContentView(R.layout.bottom_sheet_register_layout);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        setCancelable(false);

        ButterKnife.bind(this, dialog);

        shared = MySharedPrefrences.getInstance(getContext());


        loaderDialog = new SpotsDialog(dialog.getContext(), R.style.RegisterLoader);
        loaderDialog.setCancelable(false);


        loaderDialogArea = new SpotsDialog(dialog.getContext(), R.style.AreaLoader);
        loaderDialogArea.setCancelable(false);


        spinner_states.setTitle("Select State");
        spinner_country.setTitle("Select Country");
        spinner_areas.setTitle("Select Area");

        if(getArguments()!=null){
            mobileNumber = getArguments().getString("mobileNumber");
            countryCode = getArguments().getString("countryCode");
            admin_number.setText(countryCode+mobileNumber);
        }

       try{
           InputMethodManager inputMethodManager = (InputMethodManager)  getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
           inputMethodManager.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
       }catch (Exception e){

       }

        getCountriesAndState();


        spinner_country.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                CountryID = allCountryResponse.getResultData()[position].getCountryID();
                responseCities = allCountryResponse.getResultData()[position].getCities();


                ArrayList<String> states = new ArrayList<String>();

                for (int i = 0; i < responseCities.length; i++) {
                    states.add(responseCities[i].getCityName());
                }

                SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, states);
                spinner_states.setAdapter(adapter);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinner_states.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                StateID =  responseCities[position].getCityID();
                getAreas(StateID);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinner_areas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                areaID = Integer.parseInt(getAllAreas_responses[position].getAreaID());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CountryID != -1 && StateID != -1 && areaID!=-1 &&mobileNumber!=null && countryCode!=null && admin_name.getText().length()>2) {
                    shared.saveState(StateID);
                    shared.saveCountry(CountryID);
                    loaderDialog.show();
                    register(countryCode,mobileNumber,admin_name.getText().toString(),areaID);
                }else{
                    if(mobileNumber==null){
                        Toast.makeText(getContext(),"Mobile number cannot be empty",Toast.LENGTH_LONG).show();
                        return;
                    }
                    if(countryCode==null){
                        Toast.makeText(getContext(),"Country Code cannot be empty",Toast.LENGTH_LONG).show();
                        return;
                    }
                    if(admin_name.getText().length()<3){
                        Toast.makeText(getContext(),"Name should be atleast 3 characters",Toast.LENGTH_LONG).show();
                        return;
                    }
                    if(areaID == -1){
                        Toast.makeText(getContext(),"Please select area",Toast.LENGTH_LONG).show();
                        return;
                    }
                }
            }
        });


        return dialog;
    }

    private void register(String countryCode, String phoneNumberString,String name,Integer area) {
            CallRetroApi login_api = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
            Call<Login_Response> call = login_api.registerWithNumber(StaticFunction.getValue("p5>:?#68:DEC2E:@?(:E9|@3:=6"), countryCode, phoneNumberString, name, area);
            call.enqueue(new Callback<Login_Response>() {
                @Override
                public void onResponse(Call<Login_Response> call, Response<Login_Response> response) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("logged_in", response.body().getMessage());
                        //getAlldata

                        MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());
                        shared.saveData("Username", response.body().getResultData().getUsername());
                        shared.saveData("Number", response.body().getResultData().getMobileNumber());
                        shared.saveData("Name", response.body().getResultData().getAdminName());
                        shared.saveData("MasjidAdminID", response.body().getResultData().getMasjidAdminID());
                        shared.saveData("LastModified", response.body().getResultData().getModifiedOn());
                        shared.saveData("Unread_Count", response.body().getResultData().getUnreadMessagesCount());

                        MySharedPrefrences.getInstance(getActivity()).setisRegistrationComplete(true);

                        //Registering Notification Token
                        CallRetroApi registerId = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(firebaseToken -> {
                            Call<Update_Response> call1 = registerId.registerDeviceID(StaticFunction.getValue("$2G6p5>:?s6G:46"), response.body().getResultData().getMasjidAdminID(), firebaseToken, "Android");
                            call1.enqueue(new Callback<Update_Response>() {
                                @Override
                                public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                                    //Login & Notification token successfull

                                    loaderDialog.dismiss();
                                    Intent intentToMain = new Intent(getContext(), MainActivity.class);
                                    intentToMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    startActivity(intentToMain);
                                    try {
                                        getActivity().finish();
                                    } catch (Exception e) {

                                    }
                                    //dismiss();
                                }

                                @Override
                                public void onFailure(Call<Update_Response> call, Throwable t) {
                                    Log.d("", "");
                                }
                            });
                        });

                    } else {
                        loaderDialog.dismiss();
                        Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<Login_Response> call, Throwable t) {
                    StaticFunction.NoConnectionDialog(getActivity());
                    loaderDialog.dismiss();
                }
            });
    }

    private void getCountriesAndState() {
        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        Call<GetAllCountryResponse> call1 = get.countries(StaticFunction.getValue("v6Ep==r@F?EC:6D"));

        call1.enqueue(new Callback<GetAllCountryResponse>() {
            @Override
            public void onResponse(Call<GetAllCountryResponse> call, Response<GetAllCountryResponse> response) {
                if (response.body() != null) {
                    if (response.body().getSuccess().equals("true")) {

                        allCountryResponse = response.body();

                        Log.d("countries_response", response.body().getMessage());

                        ArrayList<String> countries = new ArrayList<String>();
                        for (int i = 0; i < response.body().getResultData().length; i++) {
                            countries.add(response.body().getResultData()[i].getCountryName());
                        }
                        SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, countries);
                        spinner_country.setAdapter(adapter);

                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();

                        //  progress.hide();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllCountryResponse> call, Throwable t) {
                try {
                    if (StaticFunction.isOnline(getActivity())) {
                        new MaterialDialog.Builder(getContext()).title("Something went wrong")
                                .content("please Try Again After Sometime").positiveText("Try Again")
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        getActivity().finish();
                                    }
                                })
                                .negativeText("Close")
                                .show();
                    } else {
                        new MaterialDialog.Builder(getContext()).title("Internet Error")
                                .content("You dont have INTERNET CONNECTION").onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                getActivity().finish();
                            }
                        }).positiveText("Ok").show();
                    }

                } catch (Exception e) {

                }
                //  progress.hide();
            }
        });

    }


    private void getAreas(final Integer cityID) {
        loaderDialogArea.show();
        HashMap<String, Integer> param = new HashMap<>();
        param.put("CityID",cityID);
        CallRetroApi service = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        Call<GetAllAreas_Response> call1 = service.areaByCity(StaticFunction.getValue("v6Ep==pC62DqJr:EJxs"), param);

        call1.enqueue(new Callback<GetAllAreas_Response>() {
            @Override
            public void onResponse(Call<GetAllAreas_Response> call, Response<GetAllAreas_Response> response) {
                if (response.body() != null) {
                    Log.d("Area_response", response.body().toString());
                    if (response.body().getSuccess().equals("true")) {
                        loaderDialogArea.dismiss();
                        getAllAreas_responses = response.body().getResultData();
                        ArrayList<String> areaList = new ArrayList<>();

                        for (int i = 0; i < getAllAreas_responses.length; i++) {
                            areaList.add(response.body().getResultData()[i].getAreaName());
                        }

                        SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, areaList);
                        spinner_areas.setAdapter(adapter);

                    } else {
                         loaderDialogArea.dismiss();
                        //  progress.hide();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllAreas_Response> call, Throwable t) {
                loaderDialogArea.dismiss();
                //  progress.hide();
            }
        });

    }
}

