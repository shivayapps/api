package com.awqatesalah.awqaat_e_salaah;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.rengwuxian.materialedittext.MaterialEditText;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by root on 8/6/17.
 */

public class Fragment_ForgotPassword  extends GATrackingFragment {
    private FancyButton send;
    private MaterialEditText username,number,message;
    private SpotsDialog dialog;
    MySharedPrefrences sharedPrefrences;
    String masjidAdminID;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.fragment_forgotpass, container, false);
        send = (FancyButton) view.findViewById(R.id.send);
        username = (MaterialEditText) view.findViewById(R.id.username);
        number = (MaterialEditText) view.findViewById(R.id.number);
        message = (MaterialEditText) view.findViewById(R.id.message);
        dialog = new SpotsDialog(getActivity(),R.style.main);
        dialog.setCancelable(false);
        sharedPrefrences = new MySharedPrefrences(getActivity());
        masjidAdminID = sharedPrefrences.getData("MasjidAdminID");
        if(getArguments()!=null)
        {
            message.setText(getArguments().getString("message").toString());
        }

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Forget Id Password Request");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().length() > 3 && StaticFunction.numberValidation(number.getText().toString()) && !message.getText().toString().equals("")) {
                    dialog.show();
                    CallRetroApi feedback_api = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                    Call<Update_Response> call = feedback_api.feedback(StaticFunction.getValue("v:G6u665324<"),masjidAdminID,getValue(username), getValue(number), getValue(message));
                    call.enqueue(new Callback<Update_Response>() {
                        @Override
                        public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                            if (response.body().getSuccess().toString().equals("true")) {
                                Log.d("admin_request_response", response.body().getMessage());
                                new MaterialDialog.Builder(getActivity()).title("Forgot Password request Done")
                                        .content("We have received your request and we will respond you soon").positiveText("Jazakallah").show();
                                //getAlldata
                                View view = getActivity().getCurrentFocus();
                                if (view != null) {
                                    InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                }
                                username.setText("");
                                number.setText("");
                                message.setText("");
                                dialog.dismiss();

                            } else {
                                dialog.dismiss();
                                new MaterialDialog.Builder(getActivity()).title("Error")
                                        .content(response.body().getMessage()).positiveText("Try Again").show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Update_Response> call, Throwable t) {
                            StaticFunction.NoConnectionDialog(getActivity());
                            dialog.dismiss();
                        }
                    });
                } else {
                    if (username.getText().toString().length() < 3) {
                        username.setError("Name should be atleast 3 characters");
                    }
                    if (!StaticFunction.numberValidation(number.getText().toString())) {
                        number.setError("Number should be of 9 to 13 digits");
                    }
                    if (message.getText().toString().equals("")) {
                        message.setError("Please write something to us");
                    }
                }
            }
        });


        return view;
    }
    public String getValue(EditText text)
    {
        return text.getText().toString().trim();
    }
}