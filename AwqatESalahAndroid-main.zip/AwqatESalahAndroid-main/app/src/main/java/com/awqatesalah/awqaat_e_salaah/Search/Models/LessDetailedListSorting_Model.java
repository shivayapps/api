package com.awqatesalah.awqaat_e_salaah.Search.Models;

import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Abubakker on 8/25/2016.
 */
public class LessDetailedListSorting_Model  implements Comparable<LessDetailedListSorting_Model>,Comparator<LessDetailedListSorting_Model>{
    private String MasjidName;
    private String MasjidAddress;
    private String LastUpdated;
    private String Time;
    private String Fajr;
    private String Zuhr;
    private String Asr;
    private String Maghrib;
    private String Isha;
    private String Jumuah;
    private String Eid;
    private String longitude;
    private String latitude;
    private String Masjid_ID;
    private String MasjidAdminID;
    private String isPreAddedMasjid;
    private String Website;
    private String ContactNo;
    private String Enquiry;

    public LessDetailedListSorting_Model() {
    }

    public LessDetailedListSorting_Model(String masjidName, String masjidAddress, String lastUpdated, String time, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah,String eid, String longitude, String latitude, String masjid_ID, String masjidAdminID, String isPreAddedMasjid, String website, String contactNo, String enquiry) {
        MasjidName = masjidName;
        MasjidAddress = masjidAddress;
        LastUpdated = lastUpdated;
        Time = time;
        Fajr = fajr;
        Zuhr = zuhr;
        Asr = asr;
        Maghrib = maghrib;
        Isha = isha;
        Jumuah = jumuah;
        this.longitude = longitude;
        this.latitude = latitude;
        Masjid_ID = masjid_ID;
        MasjidAdminID = masjidAdminID;
        this.isPreAddedMasjid = isPreAddedMasjid;
        Website = website;
        ContactNo = contactNo;
        Enquiry = enquiry;
        this.Eid = eid;
    }

    public String getEid() {
        return Eid;
    }

    public void setEid(String eid) {
        Eid = eid;
    }

    public String getWebsite() {
        return Website;
    }

    public void setWebsite(String website) {
        Website = website;
    }

    public String getContactNo() {
        return ContactNo;
    }

    public void setContactNo(String contactNo) {
        ContactNo = contactNo;
    }

    public String getEnquiry() {
        return Enquiry;
    }

    public void setEnquiry(String enquiry) {
        Enquiry = enquiry;
    }

    public String getIsPreAddedMasjid() {
        return isPreAddedMasjid;
    }

    public void setIsPreAddedMasjid(String isPreAddedMasjid) {
        this.isPreAddedMasjid = isPreAddedMasjid;
    }

    public String getLastUpdated() {
        return LastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        LastUpdated = lastUpdated;
    }

    public String getMasjidAdminID() {
        return MasjidAdminID;
    }

    public void setMasjidAdminID(String masjidAdminID) {
        MasjidAdminID = masjidAdminID;
    }

    public String getMasjid_ID() {
        return Masjid_ID;
    }

    public void setMasjid_ID(String masjid_ID) {
        Masjid_ID = masjid_ID;
    }

    public String getJumuah() {
        return Jumuah;
    }

    public void setJumuah(String jumuah) {
        Jumuah = jumuah;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getIsha() {
        return Isha;
    }

    public void setIsha(String isha) {
        Isha = isha;
    }

    public String getMaghrib() {
        return Maghrib;
    }

    public void setMaghrib(String maghrib) {
        Maghrib = maghrib;
    }

    public String getZuhr() {
        return Zuhr;
    }

    public void setZuhr(String zuhr) {
        Zuhr = zuhr;
    }

    public String getAsr() {
        return Asr;
    }

    public void setAsr(String asr) {
        Asr = asr;
    }

    public String getFajr() {
        return Fajr;
    }

    public void setFajr(String fajr) {
        Fajr = fajr;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getMasjidName() {
        return MasjidName;
    }

    public void setMasjidName(String masjidName) {
        MasjidName = masjidName;
    }

    public String getMasjidAddress() {
        return MasjidAddress;
    }

    public void setMasjidAddress(String masjidAddress) {
        MasjidAddress = masjidAddress;
    }


    public int compareTo(LessDetailedListSorting_Model c) {
        /*if(this.getTime()!=null && c.getTime()!=null && getDate(this.getTime())!=null && getDate(c.getTime())!=null) {
            return getDate(this.getTime()).compareTo(getDate(c.getTime()));
        }else{
            return 0;
        }*/
        Date left =  null;
        Date right = null;
        //Why "\\p{Z}" was used
        //https://stackoverflow.com/questions/77074714/simpledateformat-giving-error-for-the-same-input-for-time/77074747#77074747
        if (getDate(this.getTime().replaceAll("\\p{Z}", " ")) != null) {
            left = getDate(this.getTime().replaceAll("\\p{Z}", " "));
        }
        if (getDate(c.getTime().replaceAll("\\p{Z}", " ")) != null) {
            right = getDate(c.getTime().replaceAll("\\p{Z}", " "));
        }
        if (left == null && right == null) {
            return 0;
        } else if (left == null) {
            return -1;
        } else if (right == null) {
            return 1;
        }
        return left.compareTo(right);
    }

    public Date getDate(String startDateString){
        DateFormat df = new SimpleDateFormat("hh:mm aa", Locale.US);
        Date startDate = null;
        try {
            Log.d("NOT EXCEPTION", startDateString);
            startDate = df.parse(startDateString);
        } catch (ParseException e) {
            Log.d("EXCEPTION", startDateString);
            e.printStackTrace();
        }
        return startDate;
    }


    @Override
    public int compare(LessDetailedListSorting_Model o1, LessDetailedListSorting_Model o2) {
        Log.d("Print data", o1.getMasjidName() + " and " + o2.getMasjidName());
        return o1.getMasjidName().toUpperCase().compareTo(o2.getMasjidName().toUpperCase());
    }
}
