package com.awqatesalah.awqaat_e_salaah.util;

public interface DrawerLocker {
    public void setDrawerEnabled(boolean enabled);
}
