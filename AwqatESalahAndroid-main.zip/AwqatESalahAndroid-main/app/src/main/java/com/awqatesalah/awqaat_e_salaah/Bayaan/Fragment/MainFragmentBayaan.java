package com.awqatesalah.awqaat_e_salaah.Bayaan.Fragment;

/**
 * Created by Abubakker on 8/28/2016.
 */

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.annotation.Nullable;

import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.SpinnerAdapter;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MyApplication;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetSequence;
import com.gigamole.navigationtabbar.ntb.NavigationTabBar;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.HashMap;

import dmax.dialog.SpotsDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by GIGAMOLE on 28.03.2016.
 *

        import android.app.Activity;
        import android.graphics.Color;
        import android.os.Bundle;
        import android.support.design.widget.CollapsingToolbarLayout;
        import android.support.design.widget.CoordinatorLayout;
        import android.support.design.widget.Snackbar;
        import android.support.v4.view.PagerAdapter;
        import android.support.v4.view.ViewPager;
        import android.support.v7.widget.LinearLayoutManager;
        import android.support.v7.widget.RecyclerView;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.TextView;

        import com.gigamole.navigationtabbar.ntb.NavigationTabBar;

        import java.util.ArrayList;
        import java.util.Random;

/**
 * Created by GIGAMOLE on 28.03.2016.
 */
public class MainFragmentBayaan extends Fragment {
    AlertDialog dialog;
    SearchableSpinner spinner;
    SharedPreferences getPrefs;
    private GetAllAreas_Response area_response;
    private ArrayList<String> areaList = new ArrayList<>();
    private ImageButton bar;
    private View view=null;
    private String CityID="";
    MySharedPrefrences sharedPrefrences;

    @Override
    public void onPause() {
        super.onPause();
        Fragment searchableSpinnerDialog = getFragmentManager().findFragmentByTag("TAG");

        if (searchableSpinnerDialog != null && searchableSpinnerDialog.isAdded()) {
            getFragmentManager().beginTransaction().remove(searchableSpinnerDialog).commit();
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
     view = inflater.inflate(R.layout.activity_horizontal_coordinator_ntb,container,false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
        initUI();
        spinner = (SearchableSpinner) view.findViewById(R.id.spinner);
        MainActivity.searchView.setVisibility(View.GONE);
        dialog = new SpotsDialog(getActivity(), R.style.main);
        dialog.show();
        dialog.setCancelable(false);
        spinner.setTitle("Select City");
        if (MyApplication.allAreas!=null) {
            areaList.clear();
            setAreaData(MyApplication.allAreas,spinner,getPrefs,view);
            dialog.dismiss();
        }else {
            getData();
        }
        getPrefs = PreferenceManager
                .getDefaultSharedPreferences(getActivity());
        if(getPrefs.getString("firsttimebayaan","yes").equals("yes")) {
            getPrefs.edit().putString("firsttimebayaan", "no").apply();
            getTutorial(view,getActivity());
        }

        sharedPrefrences = MySharedPrefrences.getInstance(getActivity());

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String cityName = area_response.getResultData()[position].getAreaName();
                CityID = area_response.getResultData()[position].getAreaID();
                //Analytics Event
                new Analytics(getActivity()).logBayaanAreaSelectEvent(cityName,CityID);
                initUI();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return  view;
    }
    private void setAreaData(Response<GetAllAreas_Response> response, SearchableSpinner spinner, SharedPreferences getPrefs, View view) {
        area_response = response.body();
        for (int i = 0; i < response.body().getResultData().length; i++) {
            MainFragmentBayaan.this.areaList.add(response.body().getResultData()[i].getAreaName());
        }

        //  progress.hide();
        SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(),R.layout.spinneritem,areaList);
        spinner.setAdapter(adapter);
        setAreaID();
    }

    private void getData() {
        if (areaList.isEmpty()) {
            CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
            final MySharedPrefrences sharedPrefrences = MySharedPrefrences.getInstance(getActivity());
            HashMap<String, Integer> param = new HashMap<>();
            param.put("CityID", sharedPrefrences.getState());
            Call<GetAllAreas_Response> call1 = get.areaByCity(StaticFunction.getValue("v6Ep==pC62DqJr:EJxs"), param);

            call1.enqueue(new Callback<GetAllAreas_Response>() {
                @Override
                public void onResponse(Call<GetAllAreas_Response> call, Response<GetAllAreas_Response> response) {
                    if (response.body() != null) {
                        if (response.body().getSuccess().equals("true")) {
                            Log.d("Area_response", response.body().toString());

                            area_response = response.body();
                            for (int i = 0; i < response.body().getResultData().length; i++) {
                                areaList.add(response.body().getResultData()[i].getAreaName());
                            }

                            dialog.dismiss();
                            //  progress.hide();
                            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(),R.layout.spinneritem,areaList);
                            spinner.setAdapter(adapter);

                            setAreaID();

                        } else {
                            new MaterialDialog.Builder(getActivity()).title("Error")
                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                            dialog.dismiss();
                            //  progress.hide();
                        }
                    } else {
                        StaticFunction.NoConnectionDialog(getActivity());
                        dialog.dismiss();
                    }
                }

                @Override
                public void onFailure(Call<GetAllAreas_Response> call, Throwable t) {
                    try {
                        StaticFunction.NoConnectionDialog(getActivity());
                    } catch (Exception e) {

                    }
                    dialog.dismiss();
                    //  progress.hide();
                }
            });

        } else {
            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(),R.layout.spinneritem,areaList);
            spinner.setAdapter(adapter);
            setAreaID();
            dialog.dismiss();
            // progress.hide();
        }
    }

    private void setAreaID() {
        sharedPrefrences = new MySharedPrefrences(getContext());
        if(!sharedPrefrences.getAreaID().equals("0")){
            for(int i=0;i<area_response.getResultData().length;i++){
                if(area_response.getResultData()[i].getAreaID().equals(sharedPrefrences.getAreaID())){
                    spinner.setSelection(i);
                }
            }
        }

    }

    private void initUI() {
        ViewPagerAdapter adapter;
        final ViewPager viewPager = (ViewPager) view.findViewById(R.id.vp_horizontal_ntb);
        bar = (ImageButton) view.findViewById(R.id.bar);
        adapter = new ViewPagerAdapter(getActivity().getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(3);


        final String[] colors = getResources().getStringArray(R.array.default_preview);

        final NavigationTabBar navigationTabBar = (NavigationTabBar) view.findViewById(R.id.ntb_horizontal);
        final ArrayList<NavigationTabBar.Model> models = new ArrayList<>();
        models.add(
                new NavigationTabBar.Model.Builder(
                        getResources().getDrawable(R.drawable.bayaan),
                        Color.parseColor("#FF4081"))
                        .title("Weekly")
                        .build()
        );
        models.add(
                new NavigationTabBar.Model.Builder(
                        getResources().getDrawable(R.drawable.bayaan),
                        Color.parseColor("#FF4081"))
                        .title("Jumuah")
                        .build()
        );
        models.add(
                new NavigationTabBar.Model.Builder(
                        getResources().getDrawable(R.drawable.bayaan),
                        Color.parseColor("#FF4081"))
                        .title("Other")
                        .build()
        );


        navigationTabBar.setModels(models);
        navigationTabBar.setViewPager(viewPager, 0);

        //IMPORTANT: ENABLE SCROLL BEHAVIOUR IN COORDINATOR LAYOUT
        navigationTabBar.setBehaviorEnabled(true);


        navigationTabBar.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(final int position, final float positionOffset, final int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(final int position) {

            }

            @Override
            public void onPageScrollStateChanged(final int state) {

            }
        });

        final CoordinatorLayout coordinatorLayout = (CoordinatorLayout) view.findViewById(R.id.parent);


        final CollapsingToolbarLayout collapsingToolbarLayout =
                (CollapsingToolbarLayout) view.findViewById(R.id.toolbar);
        collapsingToolbarLayout.setExpandedTitleColor(Color.parseColor("#009F90AF"));
        collapsingToolbarLayout.setCollapsedTitleTextColor(Color.parseColor("#EFBDEB"));

        bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.result.openDrawer();
            }
        });
    }

    private void getTutorial(View view, Activity context) {
        new TapTargetSequence(context)
                .targets(
                        TapTarget.forView(view.findViewById(R.id.spinner), "you can search Bayaan citywise \nNote: for now we have bayaan details for only surat, we will get all bayaan update soon")
                                .dimColor(android.R.color.black)
                                .outerCircleColor(R.color.colorPrimary)
                                .targetCircleColor(android.R.color.black)
                                .transparentTarget(true)).start();
    }

    class ViewPagerAdapter extends FragmentStatePagerAdapter {


        public ViewPagerAdapter(FragmentManager manager) {
            super(manager,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public Fragment getItem(int position) {

            if (position == 0) {
                Fragment_Weekly frag = new Fragment_Weekly();
                Bundle bundle = new Bundle();
                bundle.putString("cityid",CityID);
                frag.setArguments(bundle);
                return  frag;
            }
            if (position == 1) {
                Fragment_Jumuah frag = new Fragment_Jumuah();
                Bundle bundle = new Bundle();
                bundle.putString("cityid",CityID);
                frag.setArguments(bundle);
                return  frag;
            }
            else {
                Fragment_Other frag = new Fragment_Other();
                Bundle bundle = new Bundle();
                bundle.putString("cityid",CityID);
                frag.setArguments(bundle);
                return  frag;
            }

        }

        @Override
        public int getCount() {
            return 3;
        }


        @Override
        public CharSequence getPageTitle(int position) {

            // return null to display only the icon
            return null;
        }

    }


}
