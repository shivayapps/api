package com.awqatesalah.awqaat_e_salaah;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by Abubakker on 8/29/2016.
 */
public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private String TAG = "FCM Service";

    final String MESSAGE_CHANNEL_ID = "awqat_e_salah_message";
    final String MESSAGE_CHANNEL_NAME = "Message";

    final String GENERAL_CHANNEL_NAME= "General";
    final String GENERAL_CHANNEL_ID = "awqat_e_salah_general";

    final String FAVOURITE_MASJID_CHANNEL_ID = "awqat_e_salah_fav_masjid";
    final String FAVOURITE_MASJID_CHANNEL_NAME = "Favourite Masjid Time Update";

    final String TIME_UPDATE_CHANNEL_ID="awqat_e_salah_time_update";
    final String TIME_UPDATE_CHANNEL_NAME="Time Update Reminder";

    /**
     * Method checks if the app is in background or not
     */
    /*public static boolean isAppIsInBackground(Context context) {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(context.getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(context.getPackageName())) {
                isInBackground = false;
            }
        }

        return isInBackground;
    }*/

    static void updateMyActivity(Context context, String message) {


        Intent intent = new Intent("notification_listener");

        //send broadcast
        context.sendBroadcast(intent);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // TODO: Handle FCM messages here.
        // If the application is in the foreground handle both data and notification messages here.
        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "From: " + remoteMessage.getFrom());
            Log.d(TAG, "Notification Message Body: " + remoteMessage.getNotification().getBody());
            sendNotification("Awqat-e-Salah",remoteMessage.getNotification().getBody(),"Notification",null);
          //  sendNotification(remoteMessage.getNotification().getBody());
        }
        final MySharedPrefrences shared = MySharedPrefrences.getInstance(this);


        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.e(TAG, "Data Payload: " + remoteMessage.getData().toString());

            try {
               // JSONObject json = new JSONObject(remoteMessage.getData().toString());
                Gson gson = new Gson();
                Map data = remoteMessage.getData();
                handleDataMessage(data,shared);
            } catch (Exception e) {
                Log.e(TAG, "Exception: " + e.getMessage());
            }
        }

        try {
            StaticFunction.removeFromCache(StaticFunction.getBaseValue(BuildConfig.BASE_URL)+StaticFunction.getValue("v6E}@E:7:42E:@?D"), this);
        }catch (Exception e){

        }
    }

    private void sendNotification(String title,String messageBody,String type,String masjidID) {
        int id = NotificationID.getID();
        String Channel_name;
        String Channel_id;
        Intent intent = new Intent(this, MainActivity.class);

        if(type!=null) {
            if (type.equals("Message")) {
                intent.putExtra("OpenMessage", "yes");
                Channel_id = MESSAGE_CHANNEL_ID;
                Channel_name = MESSAGE_CHANNEL_NAME;
            } else if (type.equals("TimeUpdate")) {
                intent.putExtra("OpenUpdate", "yes");
                Channel_id = TIME_UPDATE_CHANNEL_ID;
                Channel_name = TIME_UPDATE_CHANNEL_NAME;
            } else if (type.equals("FavoriteMasjidUpdate")) {
                intent.putExtra("OpenFav", "yes");
                intent.putExtra("id", masjidID);
                Channel_id = FAVOURITE_MASJID_CHANNEL_ID;
                Channel_name = FAVOURITE_MASJID_CHANNEL_NAME;

                //Because for this notification type Yahya is sending Body in title and title in Body so I am reversing it here
                String showingTitle = title;
                String showingMessage = messageBody;
                title = showingMessage;
                messageBody = showingTitle;

            } else if (type.equals("LocationSuggestion")) {
                intent.putExtra("LocationSuggestion", "yes");
                intent.putExtra("id", masjidID);
                Channel_id = MESSAGE_CHANNEL_ID;
                Channel_name = MESSAGE_CHANNEL_NAME;
            } else if (type.equals("TermsUpdated")) {
                intent.putExtra("OpenNotif", "yes");
                Channel_id = GENERAL_CHANNEL_ID;
                Channel_name = GENERAL_CHANNEL_NAME;
            } else {
                intent.putExtra("OpenNotif", "yes");
                Channel_id = GENERAL_CHANNEL_ID;
                Channel_name = GENERAL_CHANNEL_NAME;
            }
        }else{
            intent.putExtra("OpenNotif", "yes");
            Channel_id = GENERAL_CHANNEL_ID;
            Channel_name = GENERAL_CHANNEL_NAME;
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,id, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        //OREO CHANGES
        createNotificationChannel(notificationManager, Channel_id,Channel_name);

        Bitmap bm = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);

        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(bm)
                .setContentTitle(title)
                .setContentText(messageBody)
                .setAutoCancel(true)
                //OREO CHANGES
                .setChannelId(Channel_id)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(messageBody))
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        if(Build.VERSION.SDK_INT <=25){
            notificationBuilder
                    .setPriority(Notification.PRIORITY_HIGH);
        }else {
            notificationBuilder
                    .setPriority(NotificationManager.IMPORTANCE_HIGH);
        }



        notificationManager.notify(id, notificationBuilder.build());
    }

    private void createNotificationChannel(NotificationManager notificationManager, String GENERAL_CHANNEL_ID,String channelName) {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String description = "";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(GENERAL_CHANNEL_ID, channelName, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            notificationManager.createNotificationChannel(channel);
        }
    }

    public static class NotificationID {
        private final static AtomicInteger c = new AtomicInteger(0);

        public static int getID() {
            return c.incrementAndGet();
        }
    }

    private void handleDataMessage(Map json, MySharedPrefrences shared) {
       // Log.e(TAG, "push json: " + json.toString());

        try {
            //JSONObject data = json.getJSONObject("data");

            String title = (String) json.get("title");
            String message = (String) json.get("body");
            String type = (String) json.get("type");
            String masjidID = (String) json.get("masjidID");

            try{
            if(type.equals("Notification"))
            {
                String id = (String) json.get("notificationID");
                shared.saveUnreadNotificationIds(id);
                shared.saveNotificationCount(shared.getNotificationCount()+1);
                updateMyActivity(this,"");
            }

            if(type.equals("Message"))
            {
                shared.saveMessageCount(shared.getMessageCount()+1);
                updateMyActivity(this,"");
            }
            }catch (Exception e){

            }
          /*  boolean isBackground = data.getBoolean("is_background");
            String imageUrl = data.getString("image");
            String timestamp = data.getString("timestamp");
            JSONObject payload = data.getJSONObject("payload");*/

            Log.e(TAG, "title: " + title);
            Log.e(TAG, "message: " + message);
            /*Log.e(TAG, "isBackground: " + isBackground);
            Log.e(TAG, "payload: " + payload.toString());
            Log.e(TAG, "imageUrl: " + imageUrl);
            Log.e(TAG, "timestamp: " + timestamp);*/

            sendNotification(title,message,type,masjidID);
            /*if (!isAppIsInBackground(getApplicationContext())) {
                // app is in foreground, broadcast the push message
                sendNotification(title,message);
            } else {
                // app is in background, show the notification in notification tray
                Intent resultIntent = new Intent(getApplicationContext(), MainActivity.class);
                resultIntent.putExtra("OpenNotif","yes");
            }*/
        } catch (Exception e) {
            Log.e(TAG, "Exception: " + e.getMessage());
        }
    }
}