package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.app.FragmentManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TimePicker;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Register_Response;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;

import java.util.ArrayList;
import java.util.Calendar;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/21/2016.
 */
public class Fragment_Register_Final extends GATrackingFragment{
    ArrayList<String> areas = new ArrayList<>();
    private String mhour,minu,hou;
    private int mh;
    private TextView fajredit,zuhredit,asredit,maghribedit,ishaedit,jummahedit;
    private FancyButton Register;
    private TextView masjidname;
    private TextView t1;
    private CheckBox isPerformend;
    private TableRow row;
    private GoogleMap map;
    private MapFragment mapF;
    SpotsDialog dialog;

    private View.OnClickListener onClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            switch (v.getId()) {
                case R.id.Fajr:
                    //DO something
                    TimeSet(fajredit);
                    break;
                case R.id.Zuhr:
                    //DO something
                    TimeSet(zuhredit);
                    break;
                case R.id.Asr:
                    //DO something
                    TimeSet(asredit);
                    break;
                case R.id.Maghrib:
                    //DO something
                    TimeSet(maghribedit);
                    break;
                case R.id.Isha:
                    //DO something
                    TimeSet(ishaedit);
                    break;
                case R.id.Jumuah:
                    //DO something
                    TimeSet(jummahedit);
                    break;
            }

        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register,container,false);
        fajredit = (TextView) view.findViewById(R.id.Fajr);
        zuhredit = (TextView) view.findViewById(R.id.Zuhr);
        asredit = (TextView) view.findViewById(R.id.Asr);
        maghribedit = (TextView) view.findViewById(R.id.Maghrib);
        ishaedit = (TextView) view.findViewById(R.id.Isha);
        jummahedit = (TextView) view.findViewById(R.id.Jumuah);
        Register = (FancyButton) view.findViewById(R.id.register_final);
        isPerformend = (CheckBox) view.findViewById(R.id.isPerformed);
        row = (TableRow) view.findViewById(R.id.row);
        dialog = new SpotsDialog(getActivity(), R.style.main);
        dialog.setCancelable(false);

      /* mapF = getMapFragment();
        mapF.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(final GoogleMap googleMap) {
               googleMap.setMyLocationEnabled(true);
                googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

                    @Override
                    public void onMapClick(LatLng latLng) {

                        // Creating a marker
                        MarkerOptions markerOptions = new MarkerOptions();

                        // Setting the position for the marker
                        markerOptions.position(latLng);

                        // Setting the title for the marker.
                        // This will be displayed on taping the marker
                        markerOptions.title(latLng.latitude + " : " + latLng.longitude);

                        // Clears the previously touched position
                        googleMap.clear();

                        // Animating to the touched position
                        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));

                        // Placing a marker on the touched position
                        googleMap.addMarker(markerOptions);
                    }
                });
            }
        });*/


        isPerformend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isPerformend.isChecked())
                {
                    row.setVisibility(View.VISIBLE);
                }
                else
                {
                    row.setVisibility(View.GONE);
                }
            }
        });

        masjidname =(TextView) view.findViewById(R.id.textView3);

        fajredit.setOnClickListener(onClickListener);
        zuhredit.setOnClickListener(onClickListener);
        asredit.setOnClickListener(onClickListener);
        maghribedit.setOnClickListener(onClickListener);
        ishaedit.setOnClickListener(onClickListener);
        jummahedit.setOnClickListener(onClickListener);

        masjidname.setPaintFlags(masjidname.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        masjidname.setText(getArguments().getString("masjidname"));

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!getValue(fajredit).equals("") && !getValue(zuhredit).equals("") && !getValue(asredit).equals("") && !getValue(maghribedit).equals("") && !getValue(ishaedit).equals("")) {
                    CallRetroApi call_register = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                    Call<Register_Response> call1 = call_register.Register(StaticFunction.getValue("p5>:?#68:DEC2E:@?"), getValue("name"), getValue("username"), getValue("password"), getValue("number"), getValue("masjidname"), getValue("address"), getValue("area"), fajredit.getText().toString(), zuhredit.getText().toString(), asredit.getText().toString(), maghribedit.getText().toString(), ishaedit.getText().toString(), jummahedit.getText().toString());
                    dialog.show();
                    call1.enqueue(new Callback<Register_Response>() {
                        @Override
                        public void onResponse(Call<Register_Response> call, Response<Register_Response> response) {
                            if (response.body().getSuccess().equals("true")) {
                                dialog.dismiss();
                                Log.d("register_response", response.body().toString());
                                View view = getActivity().getCurrentFocus();
                                if (view != null) {
                                    InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                }
                                new MaterialDialog.Builder(getActivity()).title("Your Registration is Done ! Your masjid will be approved in 24 hours")
                                        .content(response.body().getMessage()).positiveText("Welcome").show();
                                getActivity().getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                            } else {
                                dialog.dismiss();
                                new MaterialDialog.Builder(getActivity()).title("Error")
                                        .content(response.body().getMessage()).positiveText("Try Again").show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Register_Response> call, Throwable t) {
                            dialog.dismiss();
                            StaticFunction.NoConnectionDialog(getActivity());
                        }
                    });
                }
                else
                {
                    dialog.dismiss();
                    new MaterialDialog.Builder(getActivity()).title("Error")
                            .content("Insert All Namaz time").positiveText("Try Again").show();
                }
            }


        });


                return view;





    }

    private MapFragment getMapFragment() {
        FragmentManager fm = null;

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            fm = getFragmentManager();
        } else {
            fm = getChildFragmentManager();
        }

        return (MapFragment) fm.findFragmentById(R.id.map);
    }

    private String getValue(String key)
    {
        return getArguments().getString(key);
    }

    public void TimeSet(final TextView t)
    {
        int hour;
        int minute;
        // TODO Auto-generated method stub
        if (!t.getText().equals("-") && !t.getText().equals("--:--") && !t.getText().equals("")) {
            Boolean isTimePM = t.getText().toString().contains("PM");
            String[] time = t.getText().toString().replace("AM", "").replace("PM", "").trim().replaceAll("\\p{Z}", "").split(":");
            hour = Integer.parseInt(time[0]);
            minute = Integer.parseInt(time[1]);

            if(isTimePM){
                hour = hour+12;
            }

        } else {
            Calendar mcurrentTime = Calendar.getInstance();
            hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            minute = mcurrentTime.get(Calendar.MINUTE);
        }
        TimePickerDialog mTimePicker;
        t1 = t;
        mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                StaticFunction.setNamazTime(selectedHour,selectedMinute,t1,t);
            }
        }, hour, minute, false);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }
    public String getValue(TextView text)
    {
        return text.getText().toString().trim();
    }


}
