package com.awqatesalah.awqaat_e_salaah.Interface;

import com.awqatesalah.awqaat_e_salaah.Admin.Models.Chat_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetMasjidByAdmin_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Login_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Register_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Bayaan.Model.Bayaan_Response;
import com.awqatesalah.awqaat_e_salaah.Bayaan.Model.Jumuah_Response;
import com.awqatesalah.awqaat_e_salaah.Bayaan.Model.Other_Response;
import com.awqatesalah.awqaat_e_salaah.Favourites.Model.FavouriteResponse;
import com.awqatesalah.awqaat_e_salaah.Favourites.Model.Refresh_Response;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Models.Notification_Response;
import com.awqatesalah.awqaat_e_salaah.Search.Models.Date_Response;
import com.awqatesalah.awqaat_e_salaah.Search.Models.GetAllCountryResponse;
import com.awqatesalah.awqaat_e_salaah.Search.Models.ListByArea_Response;
import com.awqatesalah.awqaat_e_salaah.Search.Models.ResponseCommonDetails;
import com.awqatesalah.awqaat_e_salaah.Search.Models.SuggestTimeResponse;
import com.awqatesalah.awqaat_e_salaah.Taqweem.Taqweem_Response;
import com.awqatesalah.awqaat_e_salaah.TermsCondition.Models.TnC_Response;

import java.util.HashMap;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;
import retrofit2.http.Url;

/**
 * Created by Abubakker on 8/21/2016.
 */
public interface CallRetroApi {


    @GET
    Call<ResponseCommonDetails> getCommonDetails(@Url String url);


    @GET
    Call<GetAllAreas_Response> area(@Url String url);


    @GET
    Call<GetAllAreas_Response> areaByCity(@Url String url, @QueryMap HashMap<String, Integer> id);

    @GET
    Call<GetAllCountryResponse> countries(@Url String url);


    @GET
    Call<Date_Response> date(@Url String url,  @QueryMap HashMap<String, String> date);

    @FormUrlEncoded

    @POST
    Call<ListByArea_Response> nearby(@Url String url,@Field("Latitude") String latitude,@Field("Longitude") String longitude);


   @FormUrlEncoded
   @POST
    Call<Bayaan_Response> bayaan(@Url String url,@Field("AreaID")String id);


   @FormUrlEncoded
   @POST
    Call<Other_Response> otherbayaan(@Url String url,@Field("AreaID")String id);


    @FormUrlEncoded
    @POST
    Call<Jumuah_Response> jumuahbayaan(@Url String url,@Field("AreaID")String id);


    @GET
    Call<Notification_Response> noti(@Url String url);

    @GET
    Call<FavouriteResponse> getFavourites(@Url String url,
                                          @QueryMap HashMap<String, String> MasjidAdminID);

    @FormUrlEncoded
    @POST
    Call<Taqweem_Response> taqweem(@Url String url, @Field("longitude") String longitude, @Field("latitude") String latitude, @Field("School") int type, @Field("CityID") int city, @Field("AreaID") int area, @Field("EnglishDate") String englishDate);

    @FormUrlEncoded
    @POST
    Call<Refresh_Response> refreshtime(@Url String url,@Field("MasjidID") String id);

    @FormUrlEncoded
    @POST
    Call<TnC_Response> tnc(@Url String url,@Field("Title") String title);





    @Multipart
    @POST
    Call<Update_Response> uploadSuggestionImage(@Url String url,@Part MultipartBody.Part file, @Part("MasjidID") RequestBody name, @Part("PersonName") RequestBody personname, @Part("MobileNumber") RequestBody number);


    @FormUrlEncoded

    @POST
    Call<Register_Response> sendmessage(@Url String url,@Field("MasjidAdminId") String id,@Field("Message") String message);

    @FormUrlEncoded
    @POST
    Call<Update_Response> updateMasjidLocation(@Url String url, @Field("MasjidAdminId") String id, @Field("MasjidID") String masjidID, @Field("Latitude") Double latitude, @Field("Longitude") Double longitude,@Field("AddedFrom") String platform);


    @FormUrlEncoded

    @POST
    Call<Update_Response> registerDeviceID(@Url String url,@Field("MasjidAdminId") String id, @Field("DeviceId") String deviceId, @Field("DeviceType") String devicetype );

    @FormUrlEncoded
 @POST
    Call<Login_Response> login(@Url String url,@Field("Username") String email, @Field("Password") String pwd);

    @FormUrlEncoded
    @POST
    Call<Login_Response> loginWithNumber(@Url String url,@Field("CountryCode") String CountryCode, @Field("MobileNumber") String MobileNumber,@Field("MasjidAdminID") String MasjidAdminID);

@FormUrlEncoded
    @POST
    Call<Login_Response> registerWithNumber(@Url String url,@Field("CountryCode") String CountryCode, @Field("MobileNumber") String MobileNumber,@Field("AdminName") String name,@Field("AreaID") Integer area);


    @FormUrlEncoded
    @POST
    Call<Update_Response> logout(@Url String url,@Field("MasjidAdminId") String id);



    @FormUrlEncoded

    @POST
    Call<Update_Response> feedback(@Url String url,@Field("MasjidAdminId") String id,@Field("PersonName") String name, @Field("MobileNumber") String number, @Field("Message") String message);

    @FormUrlEncoded

    @POST
    Call<Update_Response> newBecomeAdminRequest(@Url String url,@Field("MasjidAdminId") String id, @Field("MasjidID") String masjidId, @Field("Message") String message);


    @GET
    Call<GetMasjidByAdmin_Response> getAdminMasjid(@Url String url,@QueryMap HashMap<String,String> id);


    @FormUrlEncoded

    @POST
    Call<Chat_Response> getMess(@Url String url,@Field("MasjidAdminId") String id);

    @FormUrlEncoded

    @POST
    Call<Register_Response> jumuah(@Url String url,@Field("JummaBayaan") String id,@Field("AreaID") String areaid);

    @FormUrlEncoded

    @POST
    Call<Register_Response> other(@Url String url,@Field("OtherBayaan") String id,@Field("AreaID") String areaid);




   @GET
   Call<ListByArea_Response> getListByArea(@Url String url,@QueryMap HashMap<String,String> id);

    @FormUrlEncoded

    @POST
    Call<Register_Response> changePassword(@Url String url,@Field("MasjidAdminId") String id,@Field("OldPassword") String OldPassword,@Field("NewPassword") String NewPassword);

    @FormUrlEncoded

    @POST
    Call<Register_Response> updateProfile(@Url String url,@Field("MasjidAdminId") String id,@Field("AdminName") String AdminName,@Field("PhoneNumber") String PhoneNumber);


    @FormUrlEncoded
    @POST
    Call<Register_Response> Register(@Url String url,@Field("AdminName") String AdminName, @Field("Username") String Username, @Field("Password") String Password, @Field("MobileNumber") String email, @Field("MasjidName") String MasjidName, @Field("Address") String Address, @Field("AreaID") String AreaID, @Field("JamaatFajr") String JamaatFajr, @Field("JamaatZohar") String JamaatZohar, @Field("JamaatAsr") String JamaatAsr, @Field("JamaatMagrib") String JamaatMagrib, @Field("JamaatIsha") String JamaatIsha, @Field("KhutbaJumma") String KhutbaJumma);

    @FormUrlEncoded

    @POST
    Call<Update_Response> Update_Time(@Url String url,@Field("MasjidAdminID") String AdminID, @Field("MasjidID") String masjidid,@Field("AzaanFajr") String AzaanFajr, @Field("AzaanZohar") String AzaanZohar, @Field("AzaanAsr") String AzaanAsr, @Field("AzaanMagrib") String AzaanMagrib, @Field("AzaanIsha") String AzaanIsha, @Field("AzaanJumma") String AzaanJumma, @Field("JamaatFajr") String JamaatFajr, @Field("JamaatZohar") String JamaatZohar, @Field("JamaatAsr") String JamaatAsr, @Field("JamaatMagrib") String JamaatMagrib, @Field("JamaatIsha") String JamaatIsha, @Field("KhutbaJumma") String KhutbaJumma, @Field("JamaatEid") String jamaatEid,@Field("UpdateTime") String updatetime);

    @FormUrlEncoded

    @POST
    Call<Register_Response> add_masjid(@Url String url,@Field("MasjidAdminID") String AdminID, @Field("MasjidName") String masjidname,@Field("Address") String address, @Field("AreaID") String areaid,@Field("JamaatFajr") String JamaatFajr, @Field("JamaatZohar") String JamaatZohar, @Field("JamaatAsr") String JamaatAsr, @Field("JamaatMagrib") String JamaatMagrib, @Field("JamaatIsha") String JamaatIsha, @Field("KhutbaJumma") String KhutbaJumma);

    @FormUrlEncoded

    @POST
    Call<SuggestTimeResponse> suggest_Time(@Url String url, @Field("MasjidAdminID") String AdminID, @Field("MasjidID") String masjidid, @Field("AzaanFajr") String AzaanFajr, @Field("AzaanZohar") String AzaanZohar, @Field("AzaanAsr") String AzaanAsr, @Field("AzaanMagrib") String AzaanMagrib, @Field("AzaanIsha") String AzaanIsha, @Field("AzaanJumma") String AzaanJumma, @Field("JamaatFajr") String JamaatFajr, @Field("JamaatZohar") String JamaatZohar, @Field("JamaatAsr") String JamaatAsr, @Field("JamaatMagrib") String JamaatMagrib, @Field("JamaatIsha") String JamaatIsha, @Field("KhutbaJumma") String KhutbaJumma, @Field("JamaatEid") String jamaatEid, @Field("PersonName") String name, @Field("MobileNumber") String number);


    @FormUrlEncoded
    @POST
    Call<FavouriteResponse> addToFavourites(@Url String url,
                                            @Field("MasjidID") String MasjidID,
                                            @Field("MasjidAdminID")String MasjidAdminID,
                                            @Field("NotifyViaPush")Integer notify);

    @FormUrlEncoded
    @POST
    Call<FavouriteResponse> removeFavourites(@Url String url,
                                          @Field("MasjidID") String MasjidID,
                                          @Field("MasjidAdminID")String MasjidAdminID);

    @FormUrlEncoded
    @POST
    Call<FavouriteResponse> setLocalAddedFavouritesToServer(@Url String url,
                                                         @Field("MasjidIDs") String MasjidIDs,
                                                         @Field("MasjidAdminID")String MasjidAdminID);


    @FormUrlEncoded
    @POST
    Call<Update_Response> deleteAccount(@Url String url,@Field("MasjidAdminId") String id);

}
