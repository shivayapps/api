package com.awqatesalah.awqaat_e_salaah.Notification.Model.Models;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Notification_Response {

        private ResultData[] ResultData;

        private String Count;

        private String Message;

        private String Success;

        public ResultData[] getResultData ()
        {
            return ResultData;
        }

        public void setResultData (ResultData[] ResultData)
        {
            this.ResultData = ResultData;
        }

        public String getCount ()
        {
            return Count;
        }

        public void setCount (String Count)
        {
            this.Count = Count;
        }

        public String getMessage ()
        {
            return Message;
        }

        public void setMessage (String Message)
        {
            this.Message = Message;
        }

        public String getSuccess ()
        {
            return Success;
        }

        public void setSuccess (String Success)
        {
            this.Success = Success;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [ResultData = "+ResultData+", Count = "+Count+", Message = "+Message+", Success = "+Success+"]";
        }

    public class ResultData
    {
        private String AddedOn;

        private String NotificationID;

        private String Details;

        private String Type;

        private String Title;

        public String getAddedOn ()
        {
            return AddedOn;
        }

        public void setAddedOn (String AddedOn)
        {
            this.AddedOn = AddedOn;
        }

        public String getNotificationID ()
        {
            return NotificationID;
        }

        public void setNotificationID (String NotificationID)
        {
            this.NotificationID = NotificationID;
        }

        public String getDetails ()
        {
            return Details;
        }

        public void setDetails (String Details)
        {
            this.Details = Details;
        }

        public String getType ()
        {
            return Type;
        }

        public void setType (String Type)
        {
            this.Type = Type;
        }

        public String getTitle ()
        {
            return Title;
        }

        public void setTitle (String Title)
        {
            this.Title = Title;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [AddedOn = "+AddedOn+", NotificationID = "+NotificationID+", Details = "+Details+", Type = "+Type+", Title = "+Title+"]";
        }
    }
    }

