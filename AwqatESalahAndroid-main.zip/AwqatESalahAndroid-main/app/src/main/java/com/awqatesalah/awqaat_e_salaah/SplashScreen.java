package com.awqatesalah.awqaat_e_salaah;

/**
 * Created by Abubakker on 9/6/2016.
 */

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Login_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.util.CheckAppUpdateGooglePlay;
import com.awqatesalah.awqaat_e_salaah.util.animators.CustomAnimations;
import com.awqatesalah.awqaat_e_salaah.util.font.TypeFaceCommonUtils;
import com.awqatesalah.awqaat_e_salaah.util.font.TypefaceUtil;
import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.IdpResponse;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/*import com.facebook.accountkit.Account;
import com.facebook.accountkit.AccountKit;
import com.facebook.accountkit.AccountKitCallback;
import com.facebook.accountkit.AccountKitError;
import com.facebook.accountkit.PhoneNumber;
import com.facebook.accountkit.ui.AccountKitActivity;
import com.facebook.accountkit.ui.AccountKitConfiguration;
import com.facebook.accountkit.ui.LoginType;
import com.facebook.accountkit.AccountKitLoginResult;
import com.google.firebase.iid.FirebaseInstanceId;*/

public class SplashScreen extends AppCompatActivity {

    public static int APP_REQUEST_CODE = 99;


    @BindView(R.id.awqatesalah_heading)
    TextView awqatesalah_heading;

    @BindView(R.id.awqatesalah_subheading)
    TextView awqatesalah_subheading;

    @BindView(R.id.background_image_view)
    ImageView background_image_view;

    @BindView(R.id.btn_login)
    FancyButton btn_login;

    @BindView(R.id.main_container)
    RelativeLayout main_container;

    MySharedPrefrences sharedPreferences;

    SpotsDialog loaderDialog;

    boolean isUserLoggedIn = false;

    String MasjidAdminID = "0";

    List<AuthUI.IdpConfig> providers;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startingpage);
        ButterKnife.bind(this);

        checkNotificationPermission();

        final SharedPreferences getPrefs = PreferenceManager
                .getDefaultSharedPreferences(getBaseContext());
        AppShare share = new AppShare(SplashScreen.this, getPrefs);
        share.InitializeCount();

        providers = Arrays.asList(
                new AuthUI.IdpConfig.PhoneBuilder().build());


        loaderDialog = new SpotsDialog(SplashScreen.this, R.style.LoginLoader);
        loaderDialog.setCancelable(false);

        //oveerrding deafult fonts
        TypefaceUtil.overrideFont(getApplicationContext(), "SERIF", TypeFaceCommonUtils.getCommonFont()); // font from assets: "assets/fonts/Roboto-Regular.ttf


        //Animations
        // splash_logo.setAnimation(new CustomAnimations(this).setZoomOutAnimation());
        awqatesalah_heading.setAnimation(new CustomAnimations(this).setZoomOutAnimation());
        awqatesalah_subheading.setAnimation(new CustomAnimations(this).Scale());
        btn_login.setAnimation(new CustomAnimations(this).setZoomOutAnimation());

        sharedPreferences = MySharedPrefrences.getInstance(SplashScreen.this);
        getAreas();

        /*if(sharedPreferences.getData("Username").toString().equals("null")){
            btn_login.setVisibility(View.VISIBLE);
            btn_login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    phoneLogin();
                }
            });


        }else{
            //User is Logged in
            btn_login.setVisibility(View.GONE);


            Handler handler = new Handler();
            Runnable r = new Runnable() {
                public void run() {
                    //User is not logged in
                    isUserLoggedIn = true;
                    intentToHome();
                }
            };
            handler.postDelayed(r, 2000);
        }*/

        btn_login.setVisibility(View.GONE);
        //User is Logged in
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if(user!=null){
            if((!MySharedPrefrences.getInstance(SplashScreen.this).getData("Username").toString().equals("null") && MySharedPrefrences.getInstance(SplashScreen.this).isRegistrationComplete())){
                intentToHome();
            }else{
                MySharedPrefrences.getInstance(SplashScreen.this).ClearAllData();
                FirebaseAuth.getInstance().signOut();
                btn_login.setVisibility(View.VISIBLE);
                btn_login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        phoneLogin();
                    }
                });
            }
        }else{
            MySharedPrefrences.getInstance(SplashScreen.this).ClearAllData();
            FirebaseAuth.getInstance().signOut();
            btn_login.setVisibility(View.VISIBLE);
            btn_login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    phoneLogin();
                }
            });
        }
        /*if((!MySharedPrefrences.getInstance(SplashScreen.this).getData("Username").toString().equals("null") && MySharedPrefrences.getInstance(SplashScreen.this).isRegistrationComplete())){
            intentToHome();
        }else{
            MySharedPrefrences.getInstance(SplashScreen.this).ClearAllData();
            FirebaseAuth.getInstance().signOut();
            btn_login.setVisibility(View.VISIBLE);
            btn_login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    phoneLogin();
                }
            });
        }*/
        /*AccountKit.getCurrentAccount(new AccountKitCallback<Account>() {
            @Override
            public void onSuccess(final Account account) {
                // Get Account Kit ID
                if((!MySharedPrefrences.getInstance(SplashScreen.this).getData("Username").toString().equals("null") && MySharedPrefrences.getInstance(SplashScreen.this).isRegistrationComplete())){
                    intentToHome();
                }else{
                    MySharedPrefrences.getInstance(SplashScreen.this).ClearAllData();
                    AccountKit.logOut();
                    btn_login.setVisibility(View.VISIBLE);
                    btn_login.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            phoneLogin();
                        }
                    });
                }
            }

            @Override
            public void onError(final AccountKitError error) {
                // Handle Error
                if((!MySharedPrefrences.getInstance(SplashScreen.this).getData("Username").toString().equals("null") && MySharedPrefrences.getInstance(SplashScreen.this).isRegistrationComplete())){
                    intentToHome();
                }else{
                    MySharedPrefrences.getInstance(SplashScreen.this).ClearAllData();
                    AccountKit.logOut();
                    btn_login.setVisibility(View.VISIBLE);
                    btn_login.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            phoneLogin();
                        }
                    });
                }

            }
        });
*/

        //App Force Update Check
        new CheckAppUpdateGooglePlay(SplashScreen.this).checkUpdate();

        //POST APP OPEN
        if(new MySharedPrefrences(SplashScreen.this).getData("MasjidAdminID")!=null &&
                !new MySharedPrefrences(SplashScreen.this).getData("MasjidAdminID").equals("null")) {
            postAppOpenDetails(new MySharedPrefrences(SplashScreen.this).getData("MasjidAdminID"));
        }
    }

    private void getAreas() {
        HashMap<String, Integer> param = new HashMap<>();
        param.put("CityID", sharedPreferences.getState());
        CallRetroApi service = new RetroFitServiceGenerator(SplashScreen.this).createService(CallRetroApi.class);
        Call<GetAllAreas_Response> call1 = service.areaByCity(StaticFunction.getValue("v6Ep==pC62DqJr:EJxs"), param);
        call1.enqueue(new Callback<GetAllAreas_Response>() {
            @Override
            public void onResponse(Call<GetAllAreas_Response> call, Response<GetAllAreas_Response> response) {
                if (response.body() != null) {
                    Log.d("Area_response", response.body().toString());
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("DONE", response.body().getMessage());
                        Log.d("Response", response.body().toString());
                        MyApplication.allAreas = response;
                        sharedPreferences.saveAllCities(response.body());
                    } else {
                        //  progress.hide();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllAreas_Response> call, Throwable t) {

                //  progress.hide();
            }
        });

    }


    void postAppOpenDetails(String masjidAdminID){
        CallRetroApi registerId = new RetroFitServiceGenerator(SplashScreen.this).createServiceNoCache(CallRetroApi.class);
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(firebaseToken -> {
            Call<Update_Response> call1 = registerId.registerDeviceID(StaticFunction.getValue("$2G6p5>:?s6G:46"), masjidAdminID, firebaseToken, "Android");
            call1.enqueue(new Callback<Update_Response>() {
                @Override
                public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                    if (response.body() != null) {
                        if (response.body().getSuccess().equals("true")) {
                            Log.d("post_app_open_details", response.body().toString());
                        }
                    }
                }

                @Override
                public void onFailure(Call<Update_Response> call, Throwable t) {
                    //     StaticFunction.NoConnectionDialog(getActivity());
                }
            });
        });
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(SplashScreen.this,Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
                    ActivityCompat.requestPermissions(SplashScreen.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 110);
                }
            }
        }
    }

    private void intentToHome() {
        isUserLoggedIn = true;
        Intent intent = new Intent(SplashScreen.this, MainActivity.class);
        startActivity(intent);

    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        //finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(isUserLoggedIn) {
            finish();
        }
    }

    public void phoneLogin() {
        /*final Intent intent = new Intent(SplashScreen.this, AccountKitActivity.class);
        AccountKitConfiguration.AccountKitConfigurationBuilder configurationBuilder =
                new AccountKitConfiguration.AccountKitConfigurationBuilder(
                        LoginType.PHONE,
                        AccountKitActivity.ResponseType.TOKEN); // or .ResponseType.TOKEN
        // ... perform additional configuration ...
        intent.putExtra(
                AccountKitActivity.ACCOUNT_KIT_ACTIVITY_CONFIGURATION,
                configurationBuilder.build());
        startActivityForResult(intent, APP_REQUEST_CODE);*/
        startActivityForResult(
                AuthUI.getInstance()
                        .createSignInIntentBuilder()
                        .setAvailableProviders(providers)
                        .build(),
                APP_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(
            final int requestCode,
            final int resultCode,
            final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String toastMessage;
        loaderDialog.show();
        if (requestCode == APP_REQUEST_CODE) {
            IdpResponse response = IdpResponse.fromResultIntent(data);

            if (resultCode == RESULT_OK) {
                // Successfully signed in
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                try {
                    Phonenumber.PhoneNumber numberProto = phoneUtil.parse(user.getPhoneNumber(), "");
                    login(""+numberProto.getCountryCode(),numberProto.getNationalNumber()+"");
                    //This prints "Country code: 91"
                } catch (NumberParseException e) {
                    loaderDialog.dismiss();
                    Toast.makeText(SplashScreen.this,"Something Went Wrong",Toast.LENGTH_LONG).show();
                    System.err.println("NumberParseException was thrown: " + e.toString());
                }

                //login(,FirebaseAuth.getInstance().getCurrentUser().getPhoneNumber());
                // ...
            } else {
                // Sign in failed. If response is null the user canceled the
                // sign-in flow using the back button. Otherwise check
                // response.getError().getErrorCode() and handle the error.
                // ...
                loaderDialog.dismiss();
                if(response!=null) {
                    toastMessage = response.getError().getMessage();
                    Toast.makeText(SplashScreen.this, toastMessage, Toast.LENGTH_LONG).show();
                }
            }
        }


       /* if (requestCode == APP_REQUEST_CODE) { // confirm that this response matches your request

            AccountKitLoginResult loginResult = data.getParcelableExtra(AccountKitLoginResult.RESULT_KEY);
            String toastMessage;
            if (loginResult.getError() != null) {
                toastMessage = loginResult.getError().getErrorType().getMessage();
                Toast.makeText(SplashScreen.this,toastMessage,Toast.LENGTH_LONG).show();
            } else if (loginResult.wasCancelled()) {
                toastMessage = "Login Cancelled";
            } else {
                if (loginResult.getAccessToken() != null) {
                    toastMessage = "Success:" + loginResult.getAccessToken().getAccountId();
                } else {
                    toastMessage = String.format(
                            "Success:%s...",
                            loginResult.getAuthorizationCode().substring(0,10));
                }

                // If you have an authorization code, retrieve it from
                // loginResult.getAuthorizationCode()
                // and pass it to your server and exchange it for an access token.

                // Success! Start your next activity...
                loaderDialog.show();
                AccountKit.getCurrentAccount(new AccountKitCallback<Account>() {
                    @Override
                    public void onSuccess(final Account account) {
                        // Get Account Kit ID
                        String accountKitId = account.getId();
                        // Get phone number
                        PhoneNumber phoneNumber = account.getPhoneNumber();
                        if (phoneNumber != null) {
                            String phoneNumberString = account.getPhoneNumber().getPhoneNumber();
                            String countryCode = account.getPhoneNumber().getCountryCode();
                            login(countryCode,phoneNumberString);
                        }



                    }

                    @Override
                    public void onError(final AccountKitError error) {
                        // Handle Error
                        loaderDialog.dismiss();

                        Toast.makeText(
                                SplashScreen.this,
                                error.getUserFacingMessage(),
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });
                //intentToHome();

            }
        }*/
    }

    private void login(final String countryCode, final String phoneNumberString) {
            if(!sharedPreferences.getData("MasjidAdminID").equals("null") && !sharedPreferences.getData("MasjidAdminID").equals("")){
                MasjidAdminID = sharedPreferences.getData("MasjidAdminID");
            }
            CallRetroApi login_api = new RetroFitServiceGenerator(SplashScreen.this).createServiceNoCache(CallRetroApi.class);
            Call<Login_Response> call = login_api.loginWithNumber(StaticFunction.getValue("p5>:?{@8:?(:E9|@3:=6"), countryCode, phoneNumberString,MasjidAdminID);
            call.enqueue(new Callback<Login_Response>() {
                @Override
                public void onResponse(Call<Login_Response> call, Response<Login_Response> response) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("logged_in", response.body().getMessage());
                        //getAlldata

                        MySharedPrefrences shared = MySharedPrefrences.getInstance(SplashScreen.this);
                        shared.saveData("Username", response.body().getResultData().getUsername());
                        shared.saveData("Number", response.body().getResultData().getMobileNumber());
                        shared.saveData("Name", response.body().getResultData().getAdminName());
                        shared.saveData("MasjidAdminID", response.body().getResultData().getMasjidAdminID());
                        shared.saveData("LastModified", response.body().getResultData().getModifiedOn());
                        shared.saveData("Unread_Count", response.body().getResultData().getUnreadMessagesCount());

                        //Registering Notification Token
                        CallRetroApi registerId = new RetroFitServiceGenerator(SplashScreen.this).createServiceNoCache(CallRetroApi.class);
                        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(firebaseToken -> {
                            Call<Update_Response> call1 = registerId.registerDeviceID(StaticFunction.getValue("$2G6p5>:?s6G:46"), response.body().getResultData().getMasjidAdminID(), firebaseToken, "Android");
                            call1.enqueue(new Callback<Update_Response>() {
                                @Override
                                public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                                    //Login & Notification token successfull
                                    //loaderDialog.dismiss();
                                    intentToHome();
                                }

                                @Override
                                public void onFailure(Call<Update_Response> call, Throwable t) {
                                    loaderDialog.dismiss();
                                }
                            });
                        });

                    } else {
                        MySharedPrefrences.getInstance(SplashScreen.this).setisRegistrationComplete(false);
                        //Open Registration
                        BottomSheetRegister bottomSheetRegister = new BottomSheetRegister();
                        Bundle bundle = new Bundle();
                        bundle.putString("mobileNumber",phoneNumberString);
                        bundle.putString("countryCode",countryCode);
                        bottomSheetRegister.setArguments(bundle);
                        bottomSheetRegister.setCancelable(false);
                        bottomSheetRegister.show(getSupportFragmentManager(), "bottom_sheet_regitser");
                        loaderDialog.dismiss();

                    }
                }

                @Override
                public void onFailure(Call<Login_Response> call, Throwable t) {
                    StaticFunction.NoConnectionDialog(SplashScreen.this);
                    loaderDialog.dismiss();
                }
            });
    }
}
