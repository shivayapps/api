package com.awqatesalah.awqaat_e_salaah.Search.Models;

/**
 * Created by root on 3/6/18.
 */

public class ResponseCommonDetails {
    private ResultData ResultData;

    private String Message;


    private String Success;

    public ResultData getResultData() {
        return ResultData;
    }

    public void setResultData(ResultData ResultData) {
        this.ResultData = ResultData;
    }




    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }


    public String getSuccess() {
        return Success;
    }

    public void setSuccess(String Success) {
        this.Success = Success;
    }

    @Override
    public String toString() {
        return "ClassPojo [ResultData = " + ResultData +  "]";
    }

    public class ResultData
    {
        private ContactUs ContactUs;

        private Help Help;

        private ShareApp ShareApp;

        private ShowEidTime ShowEidTime;

        private ShowEidTime UpdateEidTime;

        private MessagesMobileNumber MessagesMobileNumber;

        public ResponseCommonDetails.ResultData.ShowEidTime getUpdateEidTime() {
            return UpdateEidTime;
        }

        public void setUpdateEidTime(ResponseCommonDetails.ResultData.ShowEidTime updateEidTime) {
            UpdateEidTime = updateEidTime;
        }

        public ContactUs getContactUs ()
        {
            return ContactUs;
        }

        public void setContactUs (ContactUs ContactUs)
        {
            this.ContactUs = ContactUs;
        }

        public Help getHelp ()
        {
            return Help;
        }

        public void setHelp (Help Help)
        {
            this.Help = Help;
        }

        public ShareApp getShareApp ()
        {
            return ShareApp;
        }

        public void setShareApp (ShareApp ShareApp)
        {
            this.ShareApp = ShareApp;
        }

        public ShowEidTime getShowEidTime ()
        {
            return ShowEidTime;
        }

        public void setShowEidTime (ShowEidTime ShowEidTime)
        {
            this.ShowEidTime = ShowEidTime;
        }

        public MessagesMobileNumber getMessagesMobileNumber ()
        {
            return MessagesMobileNumber;
        }

        public void setMessagesMobileNumber (MessagesMobileNumber messagesMobileNumber)
        {
            this.MessagesMobileNumber = messagesMobileNumber;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [ContactUs = "+ContactUs+", Help = "+Help+", ShareApp = "+ShareApp+", ShowEidTime = "+ShowEidTime+",MessagesMobileNumber = "+MessagesMobileNumber+"]";
        }

        public class ShareApp
        {
            private String ModifiedOn;

            private String Description;

            private String Title;

            public String getModifiedOn ()
            {
                return ModifiedOn;
            }

            public void setModifiedOn (String ModifiedOn)
            {
                this.ModifiedOn = ModifiedOn;
            }

            public String getDescription ()
            {
                return Description;
            }

            public void setDescription (String Description)
            {
                this.Description = Description;
            }

            public String getTitle ()
            {
                return Title;
            }

            public void setTitle (String Title)
            {
                this.Title = Title;
            }

            @Override
            public String toString()
            {
                return "ClassPojo [ModifiedOn = "+ModifiedOn+", Description = "+Description+", Title = "+Title+"]";
            }
        }



        public class ContactUs
        {
            private String ModifiedOn;

            private String Description;

            private String Title;

            public String getModifiedOn ()
            {
                return ModifiedOn;
            }

            public void setModifiedOn (String ModifiedOn)
            {
                this.ModifiedOn = ModifiedOn;
            }

            public String getDescription ()
            {
                return Description;
            }

            public void setDescription (String Description)
            {
                this.Description = Description;
            }

            public String getTitle ()
            {
                return Title;
            }

            public void setTitle (String Title)
            {
                this.Title = Title;
            }

            @Override
            public String toString()
            {
                return "ClassPojo [ModifiedOn = "+ModifiedOn+", Description = "+Description+", Title = "+Title+"]";
            }
        }



        public class Help
        {
            private String ModifiedOn;

            private String Description;

            private String Title;

            public String getModifiedOn ()
            {
                return ModifiedOn;
            }

            public void setModifiedOn (String ModifiedOn)
            {
                this.ModifiedOn = ModifiedOn;
            }

            public String getDescription ()
            {
                return Description;
            }

            public void setDescription (String Description)
            {
                this.Description = Description;
            }

            public String getTitle ()
            {
                return Title;
            }

            public void setTitle (String Title)
            {
                this.Title = Title;
            }

            @Override
            public String toString()
            {
                return "ClassPojo [ModifiedOn = "+ModifiedOn+", Description = "+Description+", Title = "+Title+"]";
            }
        }



        public class ShowEidTime
        {
            private String ModifiedOn;

            private String Description;

            private String Title;

            public String getModifiedOn ()
            {
                return ModifiedOn;
            }

            public void setModifiedOn (String ModifiedOn)
            {
                this.ModifiedOn = ModifiedOn;
            }

            public String getDescription ()
            {
                return Description;
            }

            public void setDescription (String Description)
            {
                this.Description = Description;
            }

            public String getTitle ()
            {
                return Title;
            }

            public void setTitle (String Title)
            {
                this.Title = Title;
            }

            @Override
            public String toString()
            {
                return "ClassPojo [ModifiedOn = "+ModifiedOn+", Description = "+Description+", Title = "+Title+"]";
            }
        }

        public class UpdateEidTime
        {
            private String ModifiedOn;

            private String Description;

            private String Title;

            public String getModifiedOn ()
            {
                return ModifiedOn;
            }

            public void setModifiedOn (String ModifiedOn)
            {
                this.ModifiedOn = ModifiedOn;
            }

            public String getDescription ()
            {
                return Description;
            }

            public void setDescription (String Description)
            {
                this.Description = Description;
            }

            public String getTitle ()
            {
                return Title;
            }

            public void setTitle (String Title)
            {
                this.Title = Title;
            }

            @Override
            public String toString()
            {
                return "ClassPojo [ModifiedOn = "+ModifiedOn+", Description = "+Description+", Title = "+Title+"]";
            }
        }

        public class MessagesMobileNumber
        {
            private String ModifiedOn;

            private String Description;

            private String Title;

            public String getModifiedOn ()
            {
                return ModifiedOn;
            }

            public void setModifiedOn (String ModifiedOn)
            {
                this.ModifiedOn = ModifiedOn;
            }

            public String getDescription ()
            {
                return Description;
            }

            public void setDescription (String Description)
            {
                this.Description = Description;
            }

            public String getTitle ()
            {
                return Title;
            }

            public void setTitle (String Title)
            {
                this.Title = Title;
            }

            @Override
            public String toString()
            {
                return "ClassPojo [ModifiedOn = "+ModifiedOn+", Description = "+Description+", Title = "+Title+"]";
            }
        }




    }

}
