package com.awqatesalah.awqaat_e_salaah.Search.Adapters;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.DBHelper;
import com.awqatesalah.awqaat_e_salaah.Favourites.Fragment.Fragment_Fravourites;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.Search.Fragments.Fragment_New_Dialog;
import com.awqatesalah.awqaat_e_salaah.Search.Models.LessDetailedListSorting_Model;
import com.awqatesalah.awqaat_e_salaah.Search.Models.SuggestTimeResponse;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.google.gson.Gson;
import com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView;
import com.truizlop.fabreveallayout.FABRevealLayout;
import com.truizlop.fabreveallayout.OnRevealChangeListener;

import java.util.LinkedList;


/**
 * Created by Abubakker on 8/23/2016.
 */
public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ContactViewHolder>  implements FastScrollRecyclerView.SectionedAdapter{

    private LinkedList<LessDetailedListSorting_Model> list;
    private LinkedList<LessDetailedListSorting_Model> originalList;
    private String Namaz;
    private Context mContext;
    private FragmentManager fragment;
    MySharedPrefrences sharedPrefrences;
    Boolean isTutorialShown=false;
    Boolean isFromFavouritesPage =false;

    public ListAdapter(LinkedList<LessDetailedListSorting_Model> contactList,String namaz,Context context,FragmentManager fragment) {
        this.list = contactList;
        this.originalList = contactList;
        Namaz =namaz;
        mContext=context;
        this.fragment=fragment;
        sharedPrefrences = new MySharedPrefrences(mContext);
    }

    public void setIsFromFavouritesPage(Boolean value){
        this.isFromFavouritesPage = value;
    }

    public void setData(LinkedList<LessDetailedListSorting_Model> filteredModelList) {
        this.list=filteredModelList;
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void onBindViewHolder(final ContactViewHolder contactViewHolder, final int i) {
        LessDetailedListSorting_Model ci = list.get(i);
        contactViewHolder.title.setText(ci.getMasjidName().toString().toUpperCase());
        contactViewHolder.address.setText(ci.getMasjidAddress().trim());

        if(Namaz.equals(""))
        {
            contactViewHolder.time.setVisibility(View.GONE);
            contactViewHolder.namaz.setVisibility(View.GONE);
        }
        else if(Namaz.equals("Fajr"))
        {
            contactViewHolder.cardview.setVisibility(View.VISIBLE);
            contactViewHolder.time.setVisibility(View.VISIBLE);
            contactViewHolder.namaz.setVisibility(View.VISIBLE);
            contactViewHolder.time.setText((ci.getTime().toUpperCase().replace("PM","AM")));
            contactViewHolder.namaz.setText(Namaz);
        }
        else {
            contactViewHolder.cardview.setVisibility(View.VISIBLE);
            contactViewHolder.time.setVisibility(View.VISIBLE);
            contactViewHolder.namaz.setVisibility(View.VISIBLE);
            contactViewHolder.time.setText((ci.getTime().toUpperCase().replace("AM","PM")));
            contactViewHolder.namaz.setText(Namaz);
        }


        if (list.get(i).getLastUpdated() != null && !list.get(i).getLastUpdated().equals("")) {
            contactViewHolder.last_updated.setVisibility(View.VISIBLE);
            contactViewHolder.last_updated.setText("Updated On " + list.get(i).getLastUpdated());
        } else {
            contactViewHolder.last_updated.setVisibility(View.GONE);
        }


        if(list.get(i).getIsPreAddedMasjid().equals("true")){
            contactViewHolder.admin_indicator_container.setBackgroundColor(ContextCompat.getColor(mContext,R.color.md_red_500));
            contactViewHolder.masjid_admin_info.setText("This masjid has no admin");
        }else{
            contactViewHolder.admin_indicator_container.setBackgroundColor(ContextCompat.getColor(mContext,R.color.md_green_500));
            contactViewHolder.masjid_admin_info.setText("This masjid has admin");
        }
        contactViewHolder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = ((Activity) mContext).getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                final Fragment_New_Dialog dialog =new Fragment_New_Dialog();
                Bundle bundle= new Bundle();
                bundle.putString("MasjidName",list.get(i).getMasjidName());
                bundle.putString("Address",list.get(i).getMasjidAddress());
                bundle.putString("LastUpdated",list.get(i).getLastUpdated());
                bundle.putString("Fajr",list.get(i).getFajr().toUpperCase().replace("PM","AM"));
                bundle.putString("Zuhr",list.get(i).getZuhr().toUpperCase().replace("AM","PM"));
                bundle.putString("Asr",list.get(i).getAsr().toUpperCase().replace("AM","PM"));
                bundle.putString("Maghrib",list.get(i).getMaghrib().toUpperCase().replace("AM","PM"));
                bundle.putString("Isha",list.get(i).getIsha().toUpperCase().replace("AM","PM"));
                bundle.putString("Jumuah",list.get(i).getJumuah().toUpperCase().replace("AM","PM"));
                bundle.putString("JamaatEid",list.get(i).getEid().toUpperCase().replace("AM","PM"));
                bundle.putString("Masjid_ID",list.get(i).getMasjid_ID());
                bundle.putString("Username", list.get(i).getMasjidAdminID());
                bundle.putString("latitude",list.get(i).getLatitude());
                bundle.putString("longitude",list.get(i).getLongitude());
                bundle.putString("isPreAdded",list.get(i).getIsPreAddedMasjid());
                bundle.putString("website", list.get(i).getWebsite());
                bundle.putString("contactNo", list.get(i).getContactNo());
                bundle.putString("enquiry", list.get(i).getEnquiry());
                bundle.putString("data", new Gson().toJson(originalList));
                bundle.putInt("position", i);
                dialog.setArguments(bundle);
                dialog.setDismissListener(new Fragment_New_Dialog.Listener() {
                    @Override
                    public void onDismiss(SuggestTimeResponse response,int position) {
                        //returnBlue(image);
                        Log.d("On Dismiss Data", "data");
                        if(response!=null) {
                            list.get(position).setFajr(response.getResultData().getJamaatFajr().toUpperCase().replace("PM","AM"));
                            list.get(position).setZuhr(response.getResultData().getJamaatZohar().toUpperCase().replace("PM","AM"));
                            list.get(position).setAsr(response.getResultData().getJamaatAsr().toUpperCase().replace("PM","AM"));
                            list.get(position).setMaghrib(response.getResultData().getJamaatMagrib().toUpperCase().replace("PM","AM"));
                            list.get(position).setIsha(response.getResultData().getJamaatIsha().toUpperCase().replace("PM","AM"));
                            list.get(position).setJumuah(response.getResultData().getKhutbaJumma().toUpperCase().replace("PM","AM"));
                            list.get(position).setEid(response.getResultData().getJamaatEid().toUpperCase().replace("PM","AM"));
                            notifyItemChanged(position);
                        }

                    }
                });
                dialog.show(fragment,"dialog");

            }
        });


        //Addded in new Version
        final DBHelper dbHelper = new DBHelper(mContext);
        dbHelper.openDB();
        final Cursor cursor = dbHelper.getFavouritesFlagServer(Integer.parseInt(list.get(i).getMasjid_ID()));
        final int Count = cursor.getCount();
        dbHelper.closeDB();

        if(Count>0){
            contactViewHolder.add_to_fav.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_star_filled, 0, 0, 0);
            contactViewHolder.add_to_fav.setText(mContext.getText(R.string.remove_favourites));
        }else{
            contactViewHolder.add_to_fav.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_star_empty, 0, 0, 0);
            contactViewHolder.add_to_fav.setText(mContext.getText(R.string.add_to_favourites));
        }


        contactViewHolder.location_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(mContext).logMasjidsItemLocationClickEvent();

                StaticFunction.IntentToLocationActivity(mContext,
                        list.get(i).getLatitude(),
                        list.get(i).getLongitude(),
                        list.get(i).getMasjidName(),new Gson().toJson(originalList));
            }
        });

        contactViewHolder.favourites_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment_Fravourites fragment_fravourites = new Fragment_Fravourites();
                final DBHelper dbHelper = new DBHelper(mContext);
                dbHelper.openDB();

                if(Count>0){
                    //dbHelper.delete(list.get(i).getMasjid_ID());
                     //Toast.makeText(mContext, "Removed From Favourites", Toast.LENGTH_SHORT).show();
                    fragment_fravourites.removeFavourite(list.get(i).getMasjid_ID(),new MySharedPrefrences(mContext).getData("MasjidAdminID"),mContext);
                    fragment_fravourites.setAddRemoveListener(new Fragment_Fravourites.OnAddRemoveListener() {
                        @Override
                        public void onAddListener() {

                        }

                        @Override
                        public void onRemoveListener() {

                            //Analytics Event
                            new Analytics(mContext).logMasjidsItemRemoveFavEvent();

                            contactViewHolder.add_to_fav.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_star_empty, 0, 0, 0);
                            contactViewHolder.add_to_fav.setText(mContext.getText(R.string.add_to_favourites));
                            MainActivity.updateFavouritesItemInDrawer(mContext);
                            if(isFromFavouritesPage){
                                list.remove(i);
                                notifyDataSetChanged();
                            }else{
                                notifyItemChanged(i);
                            }

                        }
                    });

                }else{
                    fragment_fravourites.addToFavourite(list.get(i).getMasjid_ID(),new MySharedPrefrences(mContext).getData("MasjidAdminID"),mContext);
                    fragment_fravourites.setAddRemoveListener(new Fragment_Fravourites.OnAddRemoveListener() {
                        @Override
                        public void onAddListener() {

                            //Analytics Event
                            new Analytics(mContext).logMasjidsItemAddFavEvent();

                            MainActivity.updateFavouritesItemInDrawer(mContext);
                            notifyItemChanged(i);
                            contactViewHolder.add_to_fav.setCompoundDrawablesWithIntrinsicBounds( R.drawable.ic_star_filled, 0, 0, 0);
                            contactViewHolder.add_to_fav.setText(mContext.getText(R.string.remove_favourites));

                        }

                        @Override
                        public void onRemoveListener() {


                        }
                    });
                }

                dbHelper.closeDB();


            }
        });

    }

    private void appearBluePair() {
        final Fragment_New_Dialog dialog =new Fragment_New_Dialog();
        dialog.setDismissListener(new Fragment_New_Dialog.Listener() {
            @Override
            public void onDismiss(SuggestTimeResponse response,int position) {
                Log.d("On Dismiss Data", "data");

                //returnBlue(image);
            }
        });
        dialog.show(fragment,"dialog");
    }

    void returnBlue(ImageButton image){
    /*    image.setVisibility(View.VISIBLE);
        ArcAnimator arcAnimator = ArcAnimator.createArcAnimator(image, startBlueX,
                startBlueY, 90, Side.LEFT)
                .setDuration(500);
        arcAnimator.start();*/

    }

    @Override
    public ContactViewHolder onCreateViewHolder(ViewGroup viewGroup, final int i) {
        final View itemView = LayoutInflater.
                from(viewGroup.getContext()).
                inflate(R.layout.cradview_masjidlist, viewGroup, false);


        return new ContactViewHolder(itemView);
    }

    private void configureFABReveal(FABRevealLayout fabRevealLayout) {
        fabRevealLayout.setOnRevealChangeListener(new OnRevealChangeListener() {
            @Override
            public void onMainViewAppeared(FABRevealLayout fabRevealLayout, View mainView) {}

            @Override
            public void onSecondaryViewAppeared(final FABRevealLayout fabRevealLayout, View secondaryView) {
                prepareBackTransition(fabRevealLayout);
            }
        });
    }

    private void prepareBackTransition(final FABRevealLayout fabRevealLayout) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                fabRevealLayout.revealMainView();
            }
        }, 2000);
    }

    @NonNull
    @Override
    public String getSectionName(int position) {
        if(Namaz.equals("")){
        LessDetailedListSorting_Model ci = list.get(position);
        return ci.getMasjidName().substring(0,1).toUpperCase();
        }else{
            LessDetailedListSorting_Model ci = list.get(position);
            switch(Namaz) {
                case "Fajr":
                    return  ci.getFajr().toString();
                case "Zuhr":
                    return ci.getZuhr().toString();
                case "Asr":
                    return ci.getAsr().toString();
                case "Maghrib":
                    return ci.getMaghrib().toString();
                case "Isha":
                    return ci.getIsha().toString();
                case "Jumuah":
                    return ci.getJumuah().toString();
                default:
                    return ci.getMasjidName().substring(0,1).toUpperCase();

            }
        }
    }


    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        protected TextView title;
        protected TextView address;
        protected TextView time;
        protected TextView namaz;
        protected TextView last_updated;
        private CardView cardview;
        private  CardView container;
        private LinearLayout admin_indicator_container;
        private LinearLayout location_container;
        private LinearLayout favourites_container;
        private TextView masjid_admin_info;
        private TextView see_location;
        private TextView add_to_fav;

        public ContactViewHolder(View v) {
            super(v);
            title =  (TextView) v.findViewById(R.id.Masjid_Title);
            address = (TextView)  v.findViewById(R.id.Masjid_Address);
            time = (TextView)  v.findViewById(R.id.time);
            namaz = (TextView)  v.findViewById(R.id.Namaz);
            last_updated = (TextView) v.findViewById(R.id.masjid_last_updated);
            cardview = (CardView) v.findViewById(R.id.sortedNamazCard);
            container = (CardView) v.findViewById(R.id.card);
            admin_indicator_container = (LinearLayout) v.findViewById(R.id.admin_indicator_container);
            location_container = (LinearLayout) v.findViewById(R.id.location_container);
            favourites_container = (LinearLayout) v.findViewById(R.id.favourites_container);
            masjid_admin_info = (TextView) v.findViewById(R.id.masjid_admin_info);
            see_location = (TextView) v.findViewById(R.id.see_location);
            add_to_fav = (TextView) v.findViewById(R.id.add_to_favourites);
        }
    }


}