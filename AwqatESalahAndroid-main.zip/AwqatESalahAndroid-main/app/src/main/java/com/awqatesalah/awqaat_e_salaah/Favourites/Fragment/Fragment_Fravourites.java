package com.awqatesalah.awqaat_e_salaah.Favourites.Fragment;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.DBHelper;
import com.awqatesalah.awqaat_e_salaah.DividerItemDecoration;
import com.awqatesalah.awqaat_e_salaah.Favourites.Model.FavouriteResponse;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RecyclerViewEmptySupport;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.Search.Adapters.ListAdapter;
import com.awqatesalah.awqaat_e_salaah.Search.Fragments.Fragment_New_Dialog;
import com.awqatesalah.awqaat_e_salaah.Search.Models.LessDetailedListSorting_Model;
import com.awqatesalah.awqaat_e_salaah.Search.Models.SuggestTimeResponse;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.google.gson.Gson;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;

import dmax.dialog.SpotsDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by Abubakker on 8/25/2016.
 */
public class Fragment_Fravourites extends GATrackingFragment {
    //private ArrayList<Favourites_Model> list = new ArrayList<>();
    //private FavouritesAdapter adapter;
    private DBHelper dbHelper;
    private Retrofit retrofit;
    RecyclerViewEmptySupport recList;
    private LinkedList<LessDetailedListSorting_Model> list = new LinkedList<>();
    String MasjidID="";
    LinearLayoutManager linearLayoutManager;

    private ListAdapter listAdpter;
    public interface OnAddRemoveListener{
        void onAddListener();
        void onRemoveListener();
    }

    public void setAddRemoveListener(OnAddRemoveListener onAddRemoveListener){
        this.onAddRemoveListener = onAddRemoveListener;
    }

    OnAddRemoveListener onAddRemoveListener;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_FAVOURITES);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view=inflater.inflate(R.layout.fragment_favourites,container,false);
        recList = (RecyclerViewEmptySupport) view.findViewById(R.id.recyclerview);
        recList.setEmptyView(view.findViewById(R.id.list_empty1));
        recList.setHasFixedSize(true);
        getToolbar();
        linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recList.setLayoutManager(linearLayoutManager);
        recList.addItemDecoration(new DividerItemDecoration(getActivity()));
        dbHelper = new DBHelper(getActivity());

        onStart();

        getFavourites(new MySharedPrefrences(getActivity()).getData("MasjidAdminID"),getActivity());

        if(getArguments()!=null){
            if(getArguments().getString("MasjidId")!=null){
                MasjidID = getArguments().getString("MasjidId");
            }
        }

        return view;
    }



    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Favourites");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        if(MainActivity.result.getActionBarDrawerToggle().isDrawerIndicatorEnabled()==false) {
            MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);
        }
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);

    }

    @Override
    public void onStart() {
        super.onStart();
        dbHelper.openDB();
    }

    @Override
    public void onStop() {
        super.onStop();
        dbHelper.closeDB();
    }


    public void getFavourites(String masjidAdminID, final Context context) {
        final SpotsDialog loaderDialog;
        loaderDialog = new SpotsDialog(context,R.style.GettingFavouriteLoader);
        loaderDialog.show();
        CallRetroApi addFavourites = new RetroFitServiceGenerator(context).createService(CallRetroApi.class);
        HashMap<String, String> param = new HashMap<>();
        param.put("MasjidAdminId",masjidAdminID);
        Call<FavouriteResponse> call = addFavourites.getFavourites(StaticFunction.getValue("v6Eu2G@C:E6|2D;:5"), param);
        call.enqueue(new Callback<FavouriteResponse>() {
            @Override
            public void onResponse(Call<FavouriteResponse> call, Response<FavouriteResponse> response) {
                loaderDialog.dismiss();
                if(response.body()!=null){
                    if (response.body().getSuccess().equals("true")) {

                        if(dbHelper!=null) {
                            dbHelper.openDB();
                            dbHelper.clearFav();
                        }
                        for(int i=0;i<response.body().getResultData().length;i++){
                            if(dbHelper!=null){
                                dbHelper.openDB();
                                dbHelper.insertFavLocal(
                                        Integer.parseInt(response.body().getResultData()[i].getMasjidID()),
                                        Integer.parseInt(response.body().getResultData()[i].getMasjidAdminID()),
                                        response.body().getResultData()[i].getMasjidName(),
                                        response.body().getResultData()[i].getAddress(),
                                        response.body().getResultData()[i].getJamaatFajr(),
                                        response.body().getResultData()[i].getJamaatZohar(),
                                        response.body().getResultData()[i].getJamaatAsr(),
                                        response.body().getResultData()[i].getJamaatMagrib(),
                                        response.body().getResultData()[i].getJamaatIsha(),
                                        response.body().getResultData()[i].getKhutbaJumma(),
                                        response.body().getResultData()[i].getJamaatEid(),
                                        response.body().getResultData()[i].getTimeModifiedOn()
                                );

                                list.add(new LessDetailedListSorting_Model(
                                        response.body().getResultData()[i].getMasjidName(),
                                        response.body().getResultData()[i].getAddress(),
                                        response.body().getResultData()[i].getTimeModifiedOn(),
                                        response.body().getResultData()[i].getJamaatIsha(),
                                        response.body().getResultData()[i].getJamaatFajr().replace("PM", "AM")
                                        , response.body().getResultData()[i].getJamaatZohar().replace("AM", "PM"),
                                        response.body().getResultData()[i].getJamaatAsr().replace("AM", "PM"),
                                        response.body().getResultData()[i].getJamaatMagrib().replace("AM", "PM"),
                                        response.body().getResultData()[i].getJamaatIsha().replace("AM", "PM"),
                                        response.body().getResultData()[i].getKhutbaJumma().replace("AM", "PM"),
                                        response.body().getResultData()[i].getJamaatEid().replace("AM", "PM"),
                                        response.body().getResultData()[i].getLongitude(),
                                        response.body().getResultData()[i].getLatitude(),
                                        response.body().getResultData()[i].getMasjidID(),
                                        response.body().getResultData()[i].getMasjidAdminID()
                                        , response.body().getResultData()[i].getIsPreAddedMasjid()
                                        , response.body().getResultData()[i].getWebsite()
                                        , response.body().getResultData()[i].getContactNo()
                                        , response.body().getResultData()[i].getEnquiry()
                                ));

                            }
                        }
                        Collections.reverse(list);
                        listAdpter = new ListAdapter(list,"",getActivity(),getFragmentManager());
                        listAdpter.setIsFromFavouritesPage(true);
                        recList.setAdapter(listAdpter);

                        // IF FROM NOTIFICATION
                        if(MasjidID!=null && !MasjidID.equals("")){
                            for(int i=0;i<list.size();i++){
                                if(MasjidID.equals(list.get(i).getMasjid_ID())){
                                    //Scroll to this position
                                    //linearLayoutManager.scrollToPosition(i);
                                    //Instead of Scrolling to position open the dialog itself
                                    FragmentManager fm = getActivity().getFragmentManager();
                                    FragmentTransaction ft = fm.beginTransaction();
                                    final Fragment_New_Dialog dialog =new Fragment_New_Dialog();
                                    Bundle bundle= new Bundle();
                                    bundle.putString("MasjidName",list.get(i).getMasjidName());
                                    bundle.putString("Address",list.get(i).getMasjidAddress());
                                    bundle.putString("LastUpdated",list.get(i).getLastUpdated());
                                    bundle.putString("Fajr",list.get(i).getFajr().toUpperCase().replace("PM","AM"));
                                    bundle.putString("Zuhr",list.get(i).getZuhr().toUpperCase().replace("AM","PM"));
                                    bundle.putString("Asr",list.get(i).getAsr().toUpperCase().replace("AM","PM"));
                                    bundle.putString("Maghrib",list.get(i).getMaghrib().toUpperCase().replace("AM","PM"));
                                    bundle.putString("Isha",list.get(i).getIsha().toUpperCase().replace("AM","PM"));
                                    bundle.putString("Jumuah",list.get(i).getJumuah().toUpperCase().replace("AM","PM"));
                                    bundle.putString("JamaatEid",list.get(i).getEid().toUpperCase().replace("AM","PM"));
                                    bundle.putString("Masjid_ID",list.get(i).getMasjid_ID());
                                    bundle.putString("Username", list.get(i).getMasjidAdminID());
                                    bundle.putString("latitude",list.get(i).getLatitude());
                                    bundle.putString("longitude",list.get(i).getLongitude());
                                    bundle.putString("isPreAdded",list.get(i).getIsPreAddedMasjid());
                                    bundle.putString("website", list.get(i).getWebsite());
                                    bundle.putString("contactNo", list.get(i).getContactNo());
                                    bundle.putString("enquiry", list.get(i).getEnquiry());
                                    bundle.putString("data", new Gson().toJson(list));
                                    bundle.putInt("position", i);
                                    dialog.setArguments(bundle);
                                    dialog.setDismissListener(new Fragment_New_Dialog.Listener() {
                                        @Override
                                        public void onDismiss(SuggestTimeResponse response, int position) {
                                            //returnBlue(image);
                                            Log.d("On Dismiss Data", "data");
                                            if(response!=null) {
                                                list.get(position).setFajr(response.getResultData().getJamaatFajr().toUpperCase().replace("PM","AM"));
                                                list.get(position).setZuhr(response.getResultData().getJamaatZohar().toUpperCase().replace("PM","AM"));
                                                list.get(position).setAsr(response.getResultData().getJamaatAsr().toUpperCase().replace("PM","AM"));
                                                list.get(position).setMaghrib(response.getResultData().getJamaatMagrib().toUpperCase().replace("PM","AM"));
                                                list.get(position).setIsha(response.getResultData().getJamaatIsha().toUpperCase().replace("PM","AM"));
                                                list.get(position).setJumuah(response.getResultData().getKhutbaJumma().toUpperCase().replace("PM","AM"));
                                                list.get(position).setEid(response.getResultData().getJamaatEid().toUpperCase().replace("PM","AM"));
                                                listAdpter.notifyItemChanged(position);
                                            }

                                        }
                                    });
                                    dialog.show(getFragmentManager(),"dialog");

                                }
                            }
                        }


                        MainActivity.updateFavouritesItemInDrawer(context);

                    } else {
                        //Open Registration
                        Toast.makeText(context,response.body().getMessage(),Toast.LENGTH_LONG).show();
                    }
                } else {
                    if(getActivity()!=null) {
                        StaticFunction.NoConnectionDialog(getActivity());
                    }
                }
            }

            @Override
            public void onFailure(Call<FavouriteResponse> call, Throwable t) {
                StaticFunction.NoConnectionDialog(context);
                Toast.makeText(context,"Error getting favourites",Toast.LENGTH_LONG).show();
                loaderDialog.dismiss();
            }
        });
    }


    public void setFavouritesToServer(final String MasjidID, final String MasjidAdminID, final Context context) {
        dbHelper = new DBHelper(context);
        final SpotsDialog loaderDialog;
        loaderDialog = new SpotsDialog(context,R.style.SettingFavouriteLoader);
        loaderDialog.show();
        CallRetroApi addFavourites = new RetroFitServiceGenerator(context).createServiceNoCache(CallRetroApi.class);
        Call<FavouriteResponse> call = addFavourites.setLocalAddedFavouritesToServer(StaticFunction.getValue("$6Eu2G@C:E6|2D;:5D"), MasjidID, MasjidAdminID);
        call.enqueue(new Callback<FavouriteResponse>() {
            @Override
            public void onResponse(Call<FavouriteResponse> call, Response<FavouriteResponse> response) {
                loaderDialog.dismiss();
                if (response.body().getSuccess().equals("true")) {

                    //DELETE LOCAL
                    if(dbHelper!=null){
                        dbHelper.openDB();
                        dbHelper.deleteOldFavouritesTable();
                    }

                    //Get Favourites
                    //getFavourites(new MySharedPrefrences(context).getData("MasjidAdminID"),context,renderList);

                } else {
                    //Open Registration
                    Toast.makeText(context,response.body().getMessage(),Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<FavouriteResponse> call, Throwable t) {
                StaticFunction.NoConnectionDialog(context);
                Toast.makeText(context,"Error setting favourites",Toast.LENGTH_LONG).show();
                loaderDialog.dismiss();
            }
        });
    }

    public void addToFavourite(final String MasjidID, final String MasjidAdminID, final Context context) {
        dbHelper = new DBHelper(context);
        final SpotsDialog loaderDialog;
        loaderDialog = new SpotsDialog(context,R.style.AddFavouriteLoader);
        loaderDialog.show();
        CallRetroApi addFavourites = new RetroFitServiceGenerator(context).createServiceNoCache(CallRetroApi.class);
        Call<FavouriteResponse> call = addFavourites.addToFavourites(StaticFunction.getValue("p55u2G@C:E6|2D;:5"), MasjidID, MasjidAdminID,0);
        call.enqueue(new Callback<FavouriteResponse>() {
            @Override
            public void onResponse(Call<FavouriteResponse> call, Response<FavouriteResponse> response) {
                loaderDialog.dismiss();
                if (response.body().getSuccess().equals("true")) {
                    for(int i=0;i<response.body().getResultData().length;i++) {
                        if (response.body().getResultData()[i].getMasjidID().equals(MasjidID)) {
                            if (dbHelper != null) {
                                dbHelper.openDB();
                                long resultInsert = dbHelper.insertFavLocal(
                                        Integer.parseInt(response.body().getResultData()[i].getMasjidID()),
                                        Integer.parseInt(response.body().getResultData()[i].getMasjidAdminID()),
                                        response.body().getResultData()[i].getMasjidName(),
                                        response.body().getResultData()[i].getAddress(),
                                        response.body().getResultData()[i].getJamaatFajr(),
                                        response.body().getResultData()[i].getJamaatZohar(),
                                        response.body().getResultData()[i].getJamaatAsr(),
                                        response.body().getResultData()[i].getJamaatMagrib(),
                                        response.body().getResultData()[i].getJamaatIsha(),
                                        response.body().getResultData()[i].getKhutbaJumma(),
                                        response.body().getResultData()[i].getJamaatEid(),
                                        response.body().getResultData()[i].getTimeModifiedOn()
                                );

                                if (resultInsert == -1) {
                                    Toast.makeText(context, "Some error occurred while inserting", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(context, "Added to Favourites", Toast.LENGTH_SHORT).show();
                                }
                                dbHelper.closeDB();

                                if(onAddRemoveListener!=null){
                                    onAddRemoveListener.onAddListener();
                                }
                            }
                        }
                    }

                    //dismissListener.onDismiss();
                    MainActivity.updateFavouritesItemInDrawer(context);
                } else {
                    //Open Registration
                    Toast.makeText(context,response.body().getMessage(),Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<FavouriteResponse> call, Throwable t) {
                StaticFunction.NoConnectionDialog(context);
                Toast.makeText(context,"Error adding favourites",Toast.LENGTH_LONG).show();
                loaderDialog.dismiss();
            }
        });
    }

    public void removeFavourite(final String MasjidID, final String MasjidAdminID, final Context context) {
        dbHelper = new DBHelper(context);
        final SpotsDialog loaderDialog;
        loaderDialog = new SpotsDialog(context,R.style.removeFavouriteLoader);
        loaderDialog.show();
        CallRetroApi removeFav = new RetroFitServiceGenerator(context).createServiceNoCache(CallRetroApi.class);
        Call<FavouriteResponse> call = removeFav.removeFavourites(StaticFunction.getValue("#6>@G6u2G@C:E6|2D;:5"), MasjidID, MasjidAdminID);
        call.enqueue(new Callback<FavouriteResponse>() {
            @Override
            public void onResponse(Call<FavouriteResponse> call, Response<FavouriteResponse> response) {
                loaderDialog.dismiss();
                if (response.body().getSuccess().equals("true")) {
                    dbHelper.openDB();
                    dbHelper.deleteFavLocal(MasjidID);
                    dbHelper.closeDB();
                    Toast.makeText(context, "Removed From Favourites", Toast.LENGTH_SHORT).show();
                    //dismissListener.onDismiss();
                    MainActivity.updateFavouritesItemInDrawer(context);

                    if(onAddRemoveListener!=null){
                        onAddRemoveListener.onRemoveListener();
                    }

                } else {
                    //Open Registration
                    Toast.makeText(context,response.body().getMessage(),Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onFailure(Call<FavouriteResponse> call, Throwable t) {
                StaticFunction.NoConnectionDialog(context);
                Toast.makeText(context,"Error removing favourites",Toast.LENGTH_LONG).show();

                loaderDialog.dismiss();
            }
        });
    }


}
