package com.awqatesalah.awqaat_e_salaah;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import android.widget.Toast;

/**
 * Created by Abubakker on 12/5/2016.
 */

public class BaseActivity extends AppCompatActivity {
    boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int nightModeFlags =
                getResources().getConfiguration().uiMode &
                        Configuration.UI_MODE_NIGHT_MASK;
        switch (nightModeFlags) {
            case Configuration.UI_MODE_NIGHT_YES:
                //Toast.makeText(this,"NIght Mode Enabled",Toast.LENGTH_LONG).show();
                setTheme(R.style.MyDarkTheme);

                break;

            case Configuration.UI_MODE_NIGHT_NO:
                //Toast.makeText(this,"NIght Mode Disabled",Toast.LENGTH_LONG).show();
                setTheme(R.style.AppTheme);

                break;

            case Configuration.UI_MODE_NIGHT_UNDEFINED:
                //Toast.makeText(this,"NIght Mode Disbaled",Toast.LENGTH_LONG).show();
                setTheme(R.style.AppTheme);

                break;
        }


    }

    @Override
    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() > 0) {
           getFragmentManager().popBackStackImmediate();
       } else {
            if (doubleBackToExitPressedOnce) {
                finish();
                //super.onBackPressed();

            } else {
                if(MainActivity.result!=null){
                    if(MainActivity.result.getCurrentSelectedPosition()!=1){
                         MainActivity.result.setSelection(1,true);
                    }
                }
                this.doubleBackToExitPressedOnce = true;
                try {
                    Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
/*
                    if (Activity_Home.tabs != null) {
                        Activity_Home.tabs.setVisibility(View.VISIBLE);
                    }
*/

                } catch (Exception e) {

                }
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            }
        }
    }
}

