package com.awqatesalah.awqaat_e_salaah.TermsCondition.Adapters;

import androidx.recyclerview.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.TermsCondition.Models.TnCModel;

import java.util.List;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class RecyclerViewAdapterTnc extends RecyclerView.Adapter<RecyclerViewAdapterTnc.ContactViewHolder> {
    private List<TnCModel> list;

    public RecyclerViewAdapterTnc(List<TnCModel> contactList) {
        this.list = contactList;
    }

    @Override
    public RecyclerViewAdapterTnc.ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View itemView = LayoutInflater.
                from(parent.getContext()).
                inflate(R.layout.cardview_other, parent, false);


        return new ContactViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ContactViewHolder holder, int position) {
        TnCModel ci = list.get(position);
        String message = ci.getDescription();
        message = message.replace("\r\n", "<br /> <br />");
        message = message.replace("\n \n", "<br /> <br />");
        Spanned result;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {

            result = Html.fromHtml(message, Html.FROM_HTML_MODE_LEGACY);

        } else {

            result = Html.fromHtml(message);

        }

        holder.content.setText(result);

    }


    @Override
    public int getItemCount() {
        return 1;
    }


    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        protected TextView content;



        public ContactViewHolder(View v) {
            super(v);
            content =  (TextView) v.findViewById(R.id.content);


        }
    }
}
