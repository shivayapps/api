package com.awqatesalah.awqaat_e_salaah;

import android.app.Application;

import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Search.Models.Date_Response;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Logger;
import com.google.android.gms.analytics.Tracker;

import androidx.appcompat.app.AppCompatDelegate;
import retrofit2.Response;

/**
 * Created by Abubakker on 12/7/2016.
 */
public class MyApplication extends Application{
    private static MyApplication ourInstance = new MyApplication();
    public static Response<Date_Response> date_response;
    public static Response<GetAllAreas_Response> allAreas;
    public static MyApplication getInstance() {
        return ourInstance;
    }

    public MyApplication() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ourInstance=this;
        //AnalyticsTrackers.initialize(this);
        //AnalyticsTrackers.getInstance().get(AnalyticsTrackers.Target.APP);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
    }

    public void trackScreenView(String screenName) {
        if(Fragment_ClassName.ScreenName(screenName)!="") {
            Tracker t = getGoogleAnalyticsTracker();

       /* getResources().getString(R.)*/
            // Set screen name.
            t.setScreenName(Fragment_ClassName.ScreenName(screenName));
            // Send a screen view.
            t.send(new HitBuilders.AppViewBuilder().build());
            GoogleAnalytics.getInstance(this).getLogger().setLogLevel(Logger.LogLevel.VERBOSE);
            GoogleAnalytics.getInstance(this).dispatchLocalHits();
        }
    }
    public synchronized Tracker getGoogleAnalyticsTracker() {
        AnalyticsTrackers analyticsTrackers = AnalyticsTrackers.getInstance();
        return analyticsTrackers.get(AnalyticsTrackers.Target.APP);
    }
}
