package com.awqatesalah.awqaat_e_salaah.Search.Models;


/**
 * Created by root on 29/12/16.
 */
public class Date_Response {
    private String Success;
    public ResultDataDate ResultData;
    private String Message;

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public ResultDataDate getResultData() {
        return ResultData;
    }

    public void setResultData(ResultDataDate resultData) {
        this.ResultData = resultData;
    }

    public String getSuccess() {
        return Success;
    }

    public void setSuccess(String success) {
        Success = success;
    }


    public  class ResultDataDate {
        private String HijriDate;
        private String EnglishDate;

        public String getEnglishDate() {
            return EnglishDate;
        }

        public void setEnglishDate(String englishDate) {
            EnglishDate = englishDate;
        }

        public String getHijriDate() {
            return HijriDate;
        }

        public void setHijriDate(String hijriDate) {
            HijriDate = hijriDate;
        }
    }

}
