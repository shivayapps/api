package com.awqatesalah.awqaat_e_salaah.Admin.Adapters;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.Admin.Models.MasjidByAdmin_Model;
import com.awqatesalah.awqaat_e_salaah.R;

import java.util.List;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class AdminMasjids extends RecyclerView.Adapter<AdminMasjids.ContactViewHolder> {

    private List<MasjidByAdmin_Model> contactList;

    public AdminMasjids(List<MasjidByAdmin_Model> contactList) {
        this.contactList = contactList;
    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }

    @Override
    public void onBindViewHolder(ContactViewHolder contactViewHolder, int i) {
        MasjidByAdmin_Model ci = contactList.get(i);
        contactViewHolder.title.setText(ci.getMasjid_Name());
        contactViewHolder.address.setText(ci.getMasjid_Address());
        if(ci.getStatus().equals("true")) {
            contactViewHolder.status.setText("APPROVED");
        }
        else
        {
            contactViewHolder.status.setText("PENDING");
        }


    }

    @Override
    public ContactViewHolder onCreateViewHolder(ViewGroup viewGroup, final int i) {
        final View itemView = LayoutInflater.
                from(viewGroup.getContext()).
                inflate(R.layout.masjidbyadmin_cardview, viewGroup, false);


        return new ContactViewHolder(itemView);
    }
    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        protected TextView title;
        protected TextView address;
        protected TextView status;


        public ContactViewHolder(View v) {
            super(v);
            title =  (TextView) v.findViewById(R.id.Masjid_Title);
            address = (TextView)  v.findViewById(R.id.Masjid_Address);
            status = (TextView)  v.findViewById(R.id.Status);

        }
    }

}