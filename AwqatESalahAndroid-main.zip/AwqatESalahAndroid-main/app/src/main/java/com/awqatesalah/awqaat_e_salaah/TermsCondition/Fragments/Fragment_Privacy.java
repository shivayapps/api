package com.awqatesalah.awqaat_e_salaah.TermsCondition.Fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingSupportFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RecyclerViewEmptySupport;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.Search.Adapters.ListAdapter;
import com.awqatesalah.awqaat_e_salaah.Search.Models.ListByArea_Response;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.awqatesalah.awqaat_e_salaah.TermsCondition.Adapters.RecyclerViewAdapterTnc;
import com.awqatesalah.awqaat_e_salaah.TermsCondition.Models.TnCModel;
import com.awqatesalah.awqaat_e_salaah.TermsCondition.Models.TnC_Response;

import java.util.ArrayList;
import java.util.List;

import dmax.dialog.SpotsDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Fragment_Privacy extends GATrackingSupportFragment {

    private List<TnCModel> list = new ArrayList<>();
    private ListAdapter listAdpter;
    private ListByArea_Response area_response= new ListByArea_Response();

    @Override
    public void onResume() {
        super.onResume();

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_PRIVACY);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.tncfragment,container,false);
        final RecyclerViewEmptySupport recList = (RecyclerViewEmptySupport) view.findViewById(R.id.rv);
        // progress = (AVLoadingIndicatorView) view.findViewById(R.id.avi1);
        recList.setEmptyView(view.findViewById(R.id.list_empty1));
        recList.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recList.setLayoutManager(llm);
        //  recList.addItemDecoration(new DividerItemDecoration(getActivity()));
        final AlertDialog dialog =new SpotsDialog(getActivity(), R.style.main);
        dialog.show();
        dialog.setCancelable(false);

        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        Call<TnC_Response> call1 = get.tnc(StaticFunction.getValue("v6Er|$"), "Privacy");

        call1.enqueue(new Callback<TnC_Response>() {
            @Override
            public void onResponse(Call<TnC_Response> call, Response<TnC_Response> response) {
                if (response.body() != null) {
                    if(response.body().getSuccess().equals("true")) {
                        Log.d("Privacy_data_response", response.body().toString());
                        list.clear();
                        list.add(new TnCModel(response.body().getResultData().getDescription()));
                        RecyclerViewAdapterTnc adapterWeekly = new RecyclerViewAdapterTnc(list);
                        recList.setAdapter(adapterWeekly);
                        dialog.dismiss();
                    }
                    else
                    {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                        dialog.dismiss();
                    }
                }
                else
                {
                    if(getActivity()!=null) {
                        StaticFunction.NoConnectionDialog(getActivity());
                    }
                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<TnC_Response> call, Throwable t) {
                //   StaticFunction.NoConnectionDialog(getActivity());
                dialog.dismiss();
            }
        });
        return view;
    }
}
