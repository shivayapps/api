package com.awqatesalah.awqaat_e_salaah;

/**
 * Created by root on 29/12/16.
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.rengwuxian.materialedittext.MaterialEditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/21/2016.
 */
public class Fragment_FeedBack extends GATrackingFragment {
    SharedPreferences getPrefs;
    private FancyButton send;
   // private MaterialEditText username,number,message;
    MaterialEditText message;
    private SpotsDialog dialog;
    MySharedPrefrences sharedPrefrences;
    String masjidAdminID;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_FEEDBACK);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.fragment_feedback, container, false);
        send = (FancyButton) view.findViewById(R.id.send);
        //username = (MaterialEditText) view.findViewById(R.id.username);
        //number = (MaterialEditText) view.findViewById(R.id.number);
        message = (MaterialEditText) view.findViewById(R.id.message);
        sharedPrefrences = new MySharedPrefrences(getActivity());
        masjidAdminID = sharedPrefrences.getData("MasjidAdminID");
       dialog = new SpotsDialog(getActivity(),R.style.main);
        dialog.setCancelable(false);
        getPrefs = PreferenceManager
                .getDefaultSharedPreferences(getActivity());
        if(getPrefs.getString("firsttimefeedback","yes").equals("yes")) {
            getPrefs.edit().putString("firsttimefeedback", "no").apply();
        }

        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Awqat-e-Salah");

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Analytics Event
                new Analytics(getActivity()).logFeedbackSendEvent();

                if (!message.getText().toString().equals("")) {
                    dialog.show();
                    CallRetroApi feedback_api = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                    Call<Update_Response> call = feedback_api.feedback(StaticFunction.getValue("v:G6u665324<"),masjidAdminID,sharedPrefrences.getData("Name"),sharedPrefrences.getData("Number"), getValue(message));
                    call.enqueue(new Callback<Update_Response>() {
                        @Override
                        public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                            if (response.body().getSuccess().toString().equals("true")) {
                                Log.d("feed_back_response", response.body().getMessage());
                                new MaterialDialog.Builder(getActivity()).title("Feedback Done")
                                        .content(response.body().getMessage()).positiveText("Jazakallah").show();
                                //getAlldata
                                View view = getActivity().getCurrentFocus();
                                if (view != null) {
                                    InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                }
                                //username.setText("");
                                //number.setText("");
                                message.setText("");
                                dialog.dismiss();

                            } else {
                                dialog.dismiss();
                                new MaterialDialog.Builder(getActivity()).title("Error")
                                        .content(response.body().getMessage()).positiveText("Try Again").show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Update_Response> call, Throwable t) {
                            StaticFunction.NoConnectionDialog(getActivity());
                            dialog.dismiss();
                        }
                    });
                } else {
                 /*   if (username.getText().toString().length() < 6) {
                        username.setError("Name should be atleast 6 characters");
                    }
                    if (!StaticFunction.numberValidation(number.getText().toString())) {
                        number.setError("Number should be of 9 to 13 digits");
                    }*/
                    if (message.getText().toString().equals("")) {
                        message.setError("Please write something to us");
                    }
                }
            }
        });


        return view;
    }
    public String getValue(EditText text)
    {
        return text.getText().toString().trim();
    }
}
