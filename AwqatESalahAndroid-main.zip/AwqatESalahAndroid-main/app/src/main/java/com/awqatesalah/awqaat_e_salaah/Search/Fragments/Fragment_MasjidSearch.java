package com.awqatesalah.awqaat_e_salaah.Search.Fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.AppShare;
import com.awqatesalah.awqaat_e_salaah.CallbackLocationFetchingActivity;
import com.awqatesalah.awqaat_e_salaah.Contact_Us.Fragment_ContactUs;
import com.awqatesalah.awqaat_e_salaah.DBHelper;
import com.awqatesalah.awqaat_e_salaah.Favourites.Fragment.Fragment_Fravourites;
import com.awqatesalah.awqaat_e_salaah.Favourites.Model.Favourites_Model;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MyApplication;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.Search.Models.Date_Response;
import com.awqatesalah.awqaat_e_salaah.Search.Models.ResponseCommonDetails;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.awqatesalah.awqaat_e_salaah.TrackGPS;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetSequence;
import com.github.javiersantos.appupdater.AppUpdater;
import com.github.javiersantos.appupdater.enums.UpdateFrom;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;
import java.util.HashMap;

import dmax.dialog.SpotsDialog;
import hotchemi.android.rate.AppRate;
import hotchemi.android.rate.OnClickButtonListener;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/25/2016.
 */
public class Fragment_MasjidSearch extends GATrackingFragment {
    private static final String CACHE_CONTROL = "Cache-Control";
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 1000;
    // Location updates intervals in sec
    private static int UPDATE_INTERVAL = 10000; // 10 sec
    private static int FATEST_INTERVAL = 5000; // 5 sec
    private static int DISPLACEMENT = 10; // 10 meters
    private static int REQUEST_CODE = 1;
    SpotsDialog locdialog;
    String latitude;
    String longitude;
    AlertDialog dialog;
    MySharedPrefrences sharedPrefrences;
    SearchableSpinner spinner;
    SharedPreferences getPrefs;
    private FancyButton search;
    //private AVLoadingIndicatorView progress;
    private ArrayList<String> areaList = new ArrayList<>();
    private String cityID = "null";
    private String cityName = "null";
    private Context context;
    private FancyButton nearby;
    private Boolean gps_enabled;
    private TrackGPS gps;
    private CardView card2;
    private TextView englishyear,englishdate,englishmonth;
    private TextView hijriyear, hijridate, hijrimonth, header_textview;
    private Location mLastLocation;
    // Google client to interact with Google API
    private GoogleApiClient mGoogleApiClient;
    // boolean flag to toggle periodic location updates
    private boolean mRequestingLocationUpdates = false;
    private LocationRequest mLocationRequest;
    private GetAllAreas_Response area_response;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(context).screenViewEvent(Analytics.PAGE_HOME_PAGE);

    }

    @Override
    public void onPause() {
        super.onPause();
        android.app.Fragment searchableSpinnerDialog = getFragmentManager().findFragmentByTag("TAG");

        if (searchableSpinnerDialog != null && searchableSpinnerDialog.isAdded()) {
            getFragmentManager().beginTransaction().remove(searchableSpinnerDialog).commit();
        }
    }
    @Nullable
    @Override


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        context = getActivity();
        if (container != null) {
            container.removeAllViews();
        }
        final View view = inflater.inflate(R.layout.masjid_search, container, false);
        getToolbar();
        getPrefs = PreferenceManager
                .getDefaultSharedPreferences(getActivity());
        spinner = (SearchableSpinner) view.findViewById(R.id.spinner);
        search = (FancyButton) view.findViewById(R.id.Search_Button);
        nearby = (FancyButton) view.findViewById(R.id.nearby);
        // progress = (AVLoadingIndicatorView) view.findViewById(R.id.avi11);
        hijridate = (TextView) view.findViewById(R.id.hijridate);
        hijriyear = (TextView) view.findViewById(R.id.hijriyear);
        hijrimonth = (TextView) view.findViewById(R.id.hijrimonth);
        header_textview = (TextView) view.findViewById(R.id.header_textview);
        englishdate = (TextView) view.findViewById(R.id.englishdate);
        englishyear = (TextView) view.findViewById(R.id.englishyear);
        englishmonth = (TextView) view.findViewById(R.id.englishmonth);
        card2 = (CardView) view.findViewById(R.id.card2);


        sharedPrefrences = MySharedPrefrences.getInstance(getActivity());

        //Get Locally Saved Cities
        GetAllAreas_Response allCityResponse;
        allCityResponse = sharedPrefrences.getAllCities();

        // spinner.setText("Select City");
        dialog = new SpotsDialog(context, R.style.main);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cityName = area_response.getResultData()[position].getAreaName();
                cityID = area_response.getResultData()[position].getAreaID();
                getPrefs.edit().putString("city", String.valueOf(position)).apply();
                sharedPrefrences.saveAreaID(cityID);
                getDate(cityID);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinner.setTitle("Select City");

        setCommonDetailsLocally();

        //CHECKS FOR UPDATE IN PLAY STORE
        new AppUpdater(getActivity()).setUpdateFrom(UpdateFrom.GOOGLE_PLAY).showEvery(5).start();


        //DISPLAYS RATING DIALOG
        AppRate.with(getActivity())
                .setInstallDays(0) // default 10, 0 means install day.
                .setLaunchTimes(3) // default 10
                .setRemindInterval(1) // default 1
                .setShowLaterButton(true) // default true
                .setDebug(false) // default false
                .setOnClickButtonListener(new OnClickButtonListener() { // callback listener.
                    @Override
                    public void onClickButton(int which) {
                        Log.d(MainActivity.class.getName(), Integer.toString(which));
                    }
                })
                .monitor();

        // Show a dialog if meets conditions
        AppRate.showRateDialogIfMeetsConditions(getActivity());



        //DISPLAYS SHARE DIALOG

        AppShare share = new AppShare(getActivity(),getPrefs);
        share.setLaunchDialog();


        header_textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_ContactUs registerFinal = new Fragment_ContactUs();
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });

        nearby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), CallbackLocationFetchingActivity.class);
                startActivityForResult(intent, REQUEST_CODE);

               /* gps = new TrackGPS(getActivity());


                if(gps.canGetLocation()){


                    longitude = String.valueOf(gps.getLongitude());
                    latitude = String.valueOf(gps .getLatitude());
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    Bundle bundle = new Bundle();
                    bundle.putString("latitude", String.valueOf(latitude));
                    bundle.putString("longitude", String.valueOf(longitude));
                    Fragment_MasjidList registerFinal = new Fragment_MasjidList();
                    registerFinal.setArguments(bundle);
                    ft.replace(R.id.container_fragment, registerFinal);

                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.addToBackStack(null);
                    ft.commit();
                }
                else
                {

                    gps.showSettingsAlert();
                    //getFromLocation();
                }*/




            }
        });


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(context).logAreaWishSearchEvent(cityName,cityID);

                if (cityID != null) {
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    Bundle bundle = new Bundle();
                    bundle.putString("cityid", cityID);
                    Fragment_MasjidList registerFinal = new Fragment_MasjidList();
                    registerFinal.setArguments(bundle);
                    ft.replace(R.id.container_fragment, registerFinal);
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.addToBackStack(null);
                    ft.commit();
                }
            }
        });

        if (sharedPrefrences.getState() != -1) {

            if (getPrefs.getString("whatsnew4.2.2", "yes").equals("yes")) {
                getPrefs.edit().putString("whatsnew4.2.2", "no").apply();
                new MaterialDialog.Builder(getActivity())
                        .positiveText("Welcome")
                        .customView(R.layout.whatsnew_version4, true)
                        .show();

            }



            if (MyApplication.date_response != null) {
                setData(MyApplication.date_response);
            } else {
                Log.d("Data NOT Found", "In Singleton");
                getDate(cityID);
            }


            if (MyApplication.allAreas != null) {
                areaList.clear();
                setAreaData(MyApplication.allAreas, spinner, getPrefs, view);
            } else if(allCityResponse!=null){
                Response<GetAllAreas_Response> cityResponse = Response.success(allCityResponse);
                MyApplication.allAreas = cityResponse;
                areaList.clear();
                setAreaData(MyApplication.allAreas, spinner, getPrefs, view);
            }else {
                Log.d("Data NOT Found", "In Singleton");
                getAreas(spinner, getPrefs, view);
                //spinner.setItems(areaList);

                // progress.hide();
            }
        }


        //Removing Local Favourites from Server and Posting to Server
        makeFavouritesBackWardCompatible();


        return view;
    }

    private void makeFavouritesBackWardCompatible() {
        DBHelper dbHelper = new DBHelper(context);
        dbHelper.openDB();
        ArrayList<Favourites_Model> list = new ArrayList<>();

        //THIS WILL GIVE OLDER FAVOURITES TABLE FOR BACKWARD COMPATIBILITY
        Cursor cursor = dbHelper.getAllRecords();
        if(cursor!=null && cursor.getCount()>0)
        {
            for(cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()){
                list.add(new Favourites_Model(cursor.getString(cursor.getColumnIndex(DBHelper.ID)),cursor.getString(cursor.getColumnIndex(DBHelper.MASJID_NAME)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.ADDRESS)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.LASTUPDATED)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.FAJR)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.ZUHR)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.ASR)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.MAGHRIB)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.ISHA)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.JUMUAH)),
                        cursor.getString(cursor.getColumnIndex(DBHelper.EID))));
            }
            StringBuilder stringBuilder = new StringBuilder();
            for(int i=0;i<list.size();i++){
                stringBuilder.append(list.get(i).getMasjid_ID());
                if(i<list.size()-1){
                    stringBuilder.append(",");
                }
            }
            Fragment_Fravourites fragment_fravourites = new Fragment_Fravourites();
            fragment_fravourites.setFavouritesToServer(stringBuilder.toString(),new MySharedPrefrences(getActivity()).getData("MasjidAdminID"),getActivity());

        }
        dbHelper.closeDB();

    }

    private void setCommonDetailsLocally() {

        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
        Call<ResponseCommonDetails> call1 = get.getCommonDetails(StaticFunction.getValue("v6Er@>>@?s6E2:=D"));
        call1.enqueue(new Callback<ResponseCommonDetails>() {
            @Override
            public void onResponse(Call<ResponseCommonDetails> call, Response<ResponseCommonDetails> response) {
                if (response!=null && response.body()!=null && response.body().getResultData()!=null) {
                    sharedPrefrences.saveContactUs(response.body().getResultData().getContactUs().getDescription());
                    sharedPrefrences.saveShareApp(response.body().getResultData().getShareApp().getDescription());
                    sharedPrefrences.saveHelp(response.body().getResultData().getHelp().getDescription());
                    sharedPrefrences.setShowEidNamazTime(response.body().getResultData().getShowEidTime().getDescription());
                    sharedPrefrences.setUpdateEidNamazTime(response.body().getResultData().getUpdateEidTime().getDescription());
                    sharedPrefrences.saveAdminChatWhatsappNumber(response.body().getResultData().getMessagesMobileNumber().getDescription());
                } else {

                }
            }

            @Override
            public void onFailure(Call<ResponseCommonDetails> call, Throwable t) {
                StaticFunction.NoConnectionDialog(getActivity());
            }
        });

    }

    private void getAreas(final SearchableSpinner spinner, final SharedPreferences getPrefs, final View view) {
        HashMap<String, Integer> param = new HashMap<>();
        param.put("CityID", sharedPrefrences.getState());
        CallRetroApi service = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        Call<GetAllAreas_Response> call1 = service.areaByCity(StaticFunction.getValue("v6Ep==pC62DqJr:EJxs"), param);
        dialog.show();
        areaList.clear();
        dialog.setCancelable(false);
        call1.enqueue(new Callback<GetAllAreas_Response>() {
            @Override
            public void onResponse(Call<GetAllAreas_Response> call, Response<GetAllAreas_Response> response) {
                if (response.body() != null) {
                    Log.d("Area_response", response.body().toString());
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("DONE", response.body().getMessage());
                        Log.d("Response", response.body().toString());
                        MyApplication.allAreas = response;
                        sharedPrefrences.saveAllCities(response.body());
                        dialog.dismiss();
                       setAreaData(response,spinner,getPrefs,view);
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                        dialog.dismiss();
                        //  progress.hide();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllAreas_Response> call, Throwable t) {
                try {
                    if(StaticFunction.isOnline(getActivity())) {
                        new MaterialDialog.Builder(context).title("Something went wrong")
                                .content("please Try Again After Sometime").positiveText("Try Again")
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        getAreas(spinner,getPrefs,view);
                                    }
                                })
                                .negativeText("Close")
                                .show();
                    }
                    else
                    {
                        new MaterialDialog.Builder(context).title("Internet Error")
                                .content("You dont have INTERNET CONNECTION").positiveText("Ok").show();
                    }

                } catch (Exception e) {

                }
                dialog.dismiss();
                //  progress.hide();
            }
        });

    }

    private void setAreaData(Response<GetAllAreas_Response> response, SearchableSpinner spinner, SharedPreferences getPrefs, View view) {
        area_response = response.body();
        for (int i = 0; i < response.body().getResultData().length; i++) {
            Fragment_MasjidSearch.this.areaList.add(response.body().getResultData()[i].getAreaName());
        }

        //  progress.hide();
        try {
            SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, areaList);
            spinner.setAdapter(adapter);
        }catch (Exception e){

        }


        if(getPrefs.getString("firsttimesearch","yes").equals("yes")) {
            getPrefs.edit().putString("firsttimesearch", "no").apply();
            getTutorial(view,getActivity());
        }


        if(!getPrefs.getString("city","null").equals("null")){
            spinner.setSelection(Integer.parseInt(getPrefs.getString("city","null")));
            cityID = area_response.getResultData()[Integer.parseInt(getPrefs.getString("city","null"))].getAreaID();
        }
    }

    private void getTutorial(View view, Activity context) {
        new TapTargetSequence(context)
                .targets(
                        TapTarget.forView(view.findViewById(R.id.nearby), "Now you can search masjids near you \n Note : Location and Internet required")
                                .dimColor(android.R.color.black)
                                .outerCircleColor(R.color.colorPrimary)
                                .targetCircleColor(android.R.color.black)
                                .transparentTarget(true),
                        TapTarget.forView(view.findViewById(R.id.spinner), "Now Awqat e Salah covers entire Gujarat(India) & New Zealand,  you can search masjids citywise")
                                .dimColor(android.R.color.black)
                                .outerCircleColor(R.color.colorPrimary)
                                .targetCircleColor(android.R.color.black)
                                .transparentTarget(true)).start();
    }

    private void getDate(String areaID) {
        HashMap<String, String> param = new HashMap<>();
       //param.put("AreaID", String.valueOf(sharedPrefrences.getState()));
        param.put("AreaID", areaID);
        param.put("EnglishDate", StaticFunction.getFormatedDate());
        CallRetroApi service = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
        Call<Date_Response> call1 = service.date(StaticFunction.getValue("v6Ew:;C:s2E6"),param);
       // card2.setVisibility(View.GONE);
        call1.enqueue(new Callback<Date_Response>() {
            @Override
            public void onResponse(Call<Date_Response> call, Response<Date_Response> response) {
                if (response.body() != null) {
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("date_response", response.body().toString());
                        MyApplication.date_response = response;
                        setData(response);
                    } else {
                        card2.setVisibility(View.GONE);

                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();

                    }
                } else {
                    StaticFunction.NoConnectionDialog(getActivity());

                }
            }

            @Override
            public void onFailure(Call<Date_Response> call, Throwable t) {
                try {
                    card2.setVisibility(View.GONE);
                    StaticFunction.NoConnectionDialog(getActivity());
                } catch (Exception e) {

                }

            }
        });

    }

    private void setData(Response<Date_Response> response) {
       /* this.card2.animate()
                .translationY(this.card2.getHeight())
                .alpha(0.0f)
                .setDuration(300)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        Fragment_MasjidSearch.this.card2.setVisibility(View.VISIBLE);
                    }
                });*/
        Log.d("DONE", response.body().getMessage());
        Log.d("Response", response.body().toString());
        String[] monthhijri = new String[]{"Muharram","Safar","Rabiul Awwal","Rabiul Aakhir","Jumadal Ula"
                ,"Jumadal Ukhra","Rajab","Shaaban","Ramadan"
                ,"Shawwal","Zul Qadah","Zuh Hijjah"};

        String[] monthenglish = new String[]{"January","February","March","April","May"
                ,"June","July","August","September"
                ,"October","November","December"};
        String[] hijri = response.body().getResultData().getHijriDate().split("-");
        String[] english = response.body().getResultData().getEnglishDate().split("-");
        if(hijri.length>0) {
            hijridate.setText(hijri[0]);
            hijrimonth.setText(monthhijri[Integer.parseInt(hijri[1]) - 1]);
            hijriyear.setText(hijri[2]);
        }

        englishdate.setText(english[0]);
        englishmonth.setText(monthenglish[Integer.parseInt(english[1])-1]);
        englishyear.setText(english[2]);

    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Awqat-e-Salah");
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);

    }

    @Override
    public void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    @Override
    public void onResume() {
        super.onResume();


    }

    /*@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 0) {
            switch (requestCode) {
                case 1:
                    getGoogleApi();
                    break;
            }
        }
    }*/

    private void getFromLocation() {

        LocationManager lm = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        gps_enabled = false;
        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
        }

        if (!gps_enabled) {
            // notify user
            new MaterialDialog.Builder(getActivity()).title("Location Required")
                    .content("Do you want to enable your location ?").positiveText("Yes").negativeText("No")
                    .onPositive(new MaterialDialog.SingleButtonCallback() {
                        @Override
                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                            startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), 1);
                        }
                    }).show();

        } else {
            Log.d("SEEsadad", "");

            //getGoogleApi();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Bundle bundle1 = data.getExtras();
                Double latitude = bundle1.getDouble("latitude");
                Double longitude = bundle1.getDouble("longitude");

                if (latitude != null && longitude != null && latitude != 0.0 && longitude != 0.0) {
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    Bundle bundle = new Bundle();

                    bundle.putString("latitude", String.valueOf(latitude));
                    bundle.putString("longitude", String.valueOf(longitude));

                   //  bundle.putString("latitude", "-36.8763160");
                   // bundle.putString("longitude", "174.6293640");

                    //Analytics Event
                    new Analytics(context).logNearBySearchEvent(latitude,longitude);


                    Fragment_MasjidList registerFinal = new Fragment_MasjidList();
                    registerFinal.setArguments(bundle);
                    ft.replace(R.id.container_fragment, registerFinal);

                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.addToBackStack(null);
                    ft.commit();
                }
            }

        }
    }



}
