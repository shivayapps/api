package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Register_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.SplashScreen;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.ArrayList;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by Abubakker on 8/24/2016.
 */
public class Fragment_Profile extends GATrackingFragment {
    private MaterialEditText pname,pusername,pnuber;
    private FancyButton profile_update;
    private String masjidAdminID;
    private SpotsDialog dialog;

    private TextView delete_account;

    MySharedPrefrences shared;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        shared = MySharedPrefrences.getInstance(getActivity());

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_ADMIN_PROFILE);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
       View view= inflater.inflate(R.layout.admin_profile,container,false);
        pname = (MaterialEditText) view.findViewById(R.id.profile_name);
        pnuber = (MaterialEditText) view.findViewById(R.id.profile_number);
        pusername = (MaterialEditText) view.findViewById(R.id.profile_username);
        profile_update = (FancyButton) view.findViewById(R.id.Profile_Update);
        delete_account = (TextView) view.findViewById(R.id.delete_account);

        getToolbar();
        final MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());
        pname.setText(shared.getData("Name").toString());
        pnuber.setText(shared.getData("Number").toString());
        pusername.setText(shared.getData("Username").toString());
        masjidAdminID=((shared.getData("MasjidAdminID").toString()));
        dialog  = new SpotsDialog(getActivity(),R.style.main);
        dialog.setCancelable(false);

        delete_account.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                new MaterialDialog.Builder(getActivity()).title("Delete your account?").titleColor(Color.RED)
                        .content("All your linked data including Name, Mobile Number, etc. will be permanently deleted.\n" +
                                "If you wish to use the services of Awqat-e-Salah in future, you will have to register with us again.").positiveText("Yes")
                        .negativeText("No")
                        .onNegative(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                            }
                        })
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog1, @NonNull DialogAction which) {
                                dialog.show();
                                CallRetroApi service = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                                Call<Update_Response> call = service.deleteAccount(StaticFunction.getValue("s6=6E6|2D;:5p5>:?!C@7:=6"), masjidAdminID);
                                call.enqueue(new Callback<Update_Response>() {
                                    @Override
                                    public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                                        if (response.body().getSuccess().equals("true")) {
                                            Log.d("delete_account", response.body().toString());
                                            ArrayList<String> unreadIds = shared.getUnreadNotificationIds();
                                            int count = shared.getNotificationCount();
                                            shared.ClearAllData();
                                            //Actually saving it , not actually deleting it
                                            shared.deleteReadNotificationId(unreadIds);
                                            shared.saveNotificationCount(count);
                                            dialog.dismiss();
                                            //AccountKit.logOut();
                                            Intent intent = new Intent(getActivity(), SplashScreen.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
                                            getActivity().finish();
                                        } else {
                                            dialog.dismiss();
                                            new MaterialDialog.Builder(getActivity()).title("Error")
                                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<Update_Response> call, Throwable t) {
                                        StaticFunction.NoConnectionDialog(getActivity());
                                        dialog.dismiss();
                                    }
                                });
                            }
                        }).show();
            }
        });

        profile_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Analytics Event
                new Analytics(getActivity()).logMasjidAdminUpdateProfileEvent();

                if(!pname.getText().toString().matches("") && pnuber.getText().toString().length()==10) {
                    dialog.show();
                    CallRetroApi call_update = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                    Call<Register_Response> call = call_update.updateProfile(StaticFunction.getValue("&A52E6|2D;:5p5>:?!C@7:=6"), masjidAdminID, getValue(pname), getValue(pnuber));

                    call.enqueue(new Callback<Register_Response>() {
                        @Override
                        public void onResponse(Call<Register_Response> call, Response<Register_Response> response) {
                            if (response.body().getSuccess().equals("true")) {
                                Log.d("profile_response", response.body().getMessage());
                                new MaterialDialog.Builder(getActivity())
                                        .content(response.body().getMessage()).positiveText("DONE").show();
                                shared.saveData("Name", getValue(pname));
                                shared.saveData("Number", getValue(pnuber));
                                dialog.dismiss();
                                View view = getActivity().getCurrentFocus();
                                if (view != null) {
                                    InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                }
                                getFragmentManager().popBackStack();
                            } else {
                                dialog.dismiss();
                                new MaterialDialog.Builder(getActivity()).title("Error")
                                        .content(response.body().getMessage()).positiveText("Try Again").show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Register_Response> call, Throwable t) {
                            StaticFunction.NoConnectionDialog(getActivity());
                            dialog.dismiss();
                        }
                    });
                }
                else
                {
                    if(pname.getText().toString().matches(""))
                    {
                        pname.setError("Name Cannot be Empty");
                    }
                    if(pnuber.getText().length() >10 || pnuber.getText().length() <10)
                    {
                        pnuber.setError("PhoneNumber SHould  be 10 digits");
                    }
                }
            }
        });


        return view;
    }

    private String getValue(EditText name) {
        return name.getText().toString().trim();
    }
    private String getValue(String key)
    {
        return getArguments().getString(key,"-");
    }
    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Profile");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


}
