package com.awqatesalah.awqaat_e_salaah.Favourites.Model;

/**
 * Created by root on 26/6/19.
 */

public class FavouriteResponse {
    public ResultData[] ResultData;

    private String Message;

    private String Count;

    private String Success;

    public ResultData[] getResultData ()
    {
        return ResultData;
    }

    public void setResultData (ResultData[] ResultData)
    {
        this.ResultData = ResultData;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }


    public String getCount ()
    {
        return Count;
    }

    public void setCount (String Count)
    {
        this.Count = Count;
    }


    public String getSuccess ()
    {
        return Success;
    }

    public void setSuccess (String Success)
    {
        this.Success = Success;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ResultData = "+ResultData+", Message = "+Message+",Count = "+Count+", Success = "+Success+"]";
    }

    public class ResultData
    {
        private String MasjidName;

        private String Address;

        private String Website;

        private String Latitude;

        private String MasjidModifiedOn;

        private String MasjidAdminID;

        private String JamaatFajr;

        private String IsApproved;

        private String AreaName;

        private String JamaatMagrib;

        private String ContactNo;

        private String Enquiry;

        private String AddedOn;

        private String IsJummaMasjid;

        private String TimeModifiedOn;

        private String MasjidName2;

        private String AreaID;

        private String KhutbaJumma;

        private String Longitude;

        private String JamaatIsha;

        private String JamaatAsr;

        private String JamaatEid;

        private String IsPreAddedMasjid;

        private String MasjidID;

        private String JamaatZohar;

        public String getMasjidName ()
        {
            return MasjidName;
        }

        public void setMasjidName (String MasjidName)
        {
            this.MasjidName = MasjidName;
        }

        public String getAddress ()
        {
            return Address;
        }

        public void setAddress (String Address)
        {
            this.Address = Address;
        }

        public String getWebsite ()
        {
            return Website;
        }

        public void setWebsite (String Website)
        {
            this.Website = Website;
        }

        public String getLatitude ()
        {
            return Latitude;
        }

        public void setLatitude (String Latitude)
        {
            this.Latitude = Latitude;
        }

        public String getMasjidModifiedOn ()
        {
            return MasjidModifiedOn;
        }

        public void setMasjidModifiedOn (String MasjidModifiedOn)
        {
            this.MasjidModifiedOn = MasjidModifiedOn;
        }

        public String getMasjidAdminID ()
        {
            return MasjidAdminID;
        }

        public void setMasjidAdminID (String MasjidAdminID)
        {
            this.MasjidAdminID = MasjidAdminID;
        }

        public String getJamaatFajr ()
        {
            return JamaatFajr;
        }

        public void setJamaatFajr (String JamaatFajr)
        {
            this.JamaatFajr = JamaatFajr;
        }

        public String getIsApproved ()
        {
            return IsApproved;
        }

        public void setIsApproved (String IsApproved)
        {
            this.IsApproved = IsApproved;
        }

        public String getAreaName ()
        {
            return AreaName;
        }

        public void setAreaName (String AreaName)
        {
            this.AreaName = AreaName;
        }

        public String getJamaatMagrib ()
        {
            return JamaatMagrib;
        }

        public void setJamaatMagrib (String JamaatMagrib)
        {
            this.JamaatMagrib = JamaatMagrib;
        }

        public String getContactNo ()
        {
            return ContactNo;
        }

        public void setContactNo (String ContactNo)
        {
            this.ContactNo = ContactNo;
        }

        public String getEnquiry ()
        {
            return Enquiry;
        }

        public void setEnquiry (String Enquiry)
        {
            this.Enquiry = Enquiry;
        }

        public String getAddedOn ()
        {
            return AddedOn;
        }

        public void setAddedOn (String AddedOn)
        {
            this.AddedOn = AddedOn;
        }

        public String getIsJummaMasjid ()
        {
            return IsJummaMasjid;
        }

        public void setIsJummaMasjid (String IsJummaMasjid)
        {
            this.IsJummaMasjid = IsJummaMasjid;
        }

        public String getTimeModifiedOn ()
        {
            return TimeModifiedOn;
        }

        public void setTimeModifiedOn (String TimeModifiedOn)
        {
            this.TimeModifiedOn = TimeModifiedOn;
        }

        public String getMasjidName2 ()
        {
            return MasjidName2;
        }

        public void setMasjidName2 (String MasjidName2)
        {
            this.MasjidName2 = MasjidName2;
        }

        public String getAreaID ()
        {
            return AreaID;
        }

        public void setAreaID (String AreaID)
        {
            this.AreaID = AreaID;
        }

        public String getKhutbaJumma ()
        {
            return KhutbaJumma;
        }

        public void setKhutbaJumma (String KhutbaJumma)
        {
            this.KhutbaJumma = KhutbaJumma;
        }

        public String getLongitude ()
        {
            return Longitude;
        }

        public void setLongitude (String Longitude)
        {
            this.Longitude = Longitude;
        }

        public String getJamaatIsha ()
        {
            return JamaatIsha;
        }

        public void setJamaatIsha (String JamaatIsha)
        {
            this.JamaatIsha = JamaatIsha;
        }

        public String getJamaatAsr ()
        {
            return JamaatAsr;
        }

        public void setJamaatAsr (String JamaatAsr)
        {
            this.JamaatAsr = JamaatAsr;
        }

        public String getJamaatEid ()
        {
            return JamaatEid;
        }

        public void setJamaatEid (String JamaatEid)
        {
            this.JamaatEid = JamaatEid;
        }

        public String getIsPreAddedMasjid ()
        {
            return IsPreAddedMasjid;
        }

        public void setIsPreAddedMasjid (String IsPreAddedMasjid)
        {
            this.IsPreAddedMasjid = IsPreAddedMasjid;
        }

        public String getMasjidID ()
        {
            return MasjidID;
        }

        public void setMasjidID (String MasjidID)
        {
            this.MasjidID = MasjidID;
        }

        public String getJamaatZohar ()
        {
            return JamaatZohar;
        }

        public void setJamaatZohar (String JamaatZohar)
        {
            this.JamaatZohar = JamaatZohar;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [MasjidName = "+MasjidName+", Address = "+Address+", Website = "+Website+", Latitude = "+Latitude+", MasjidModifiedOn = "+MasjidModifiedOn+", MasjidAdminID = "+MasjidAdminID+", JamaatFajr = "+JamaatFajr+", IsApproved = "+IsApproved+", AreaName = "+AreaName+", JamaatMagrib = "+JamaatMagrib+", ContactNo = "+ContactNo+", Enquiry = "+Enquiry+", AddedOn = "+AddedOn+", IsJummaMasjid = "+IsJummaMasjid+", TimeModifiedOn = "+TimeModifiedOn+", MasjidName2 = "+MasjidName2+", AreaID = "+AreaID+", KhutbaJumma = "+KhutbaJumma+", Longitude = "+Longitude+", JamaatIsha = "+JamaatIsha+", JamaatAsr = "+JamaatAsr+", JamaatEid = "+JamaatEid+", IsPreAddedMasjid = "+IsPreAddedMasjid+", MasjidID = "+MasjidID+", JamaatZohar = "+JamaatZohar+"]";
        }
    }
}
