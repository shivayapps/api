package com.awqatesalah.awqaat_e_salaah.Search.Adapters;

import android.util.Log;

import com.awqatesalah.awqaat_e_salaah.Search.Models.LessDetailedListSorting_Model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

/**
 * Created by root on 28/2/17.
 */
public class CustomComparator implements Comparator<LessDetailedListSorting_Model> {
    @Override
    public int compare(LessDetailedListSorting_Model o1, LessDetailedListSorting_Model o2) {
        if (o1.getTime() != null && o2.getTime() != null && getDate(o1.getTime().replaceAll("\\p{Z}", " ")) != null && getDate(o2.getTime().replaceAll("\\p{Z}", " ")) != null) {
            Log.d("--",o1.getMasjidName());
            Log.d("--",o2.getMasjidName());
            Log.d("--",o1.getTime());
            Log.d("--",o2.getTime());
            return getDate(o1.getTime().replaceAll("\\p{Z}", " ").toUpperCase()).compareTo(getDate(o2.getTime().replaceAll("\\p{Z}", " ").toUpperCase()));
        }
        else {
            Log.d("--",o1.getMasjidName());
            return 0;
        }
    }
    public Date getDate(String startDateString){
        DateFormat df = new SimpleDateFormat("hh:mm a", Locale.US);
        Date startDate = null;
        try {
            startDate = df.parse(startDateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return startDate;
    }

}
