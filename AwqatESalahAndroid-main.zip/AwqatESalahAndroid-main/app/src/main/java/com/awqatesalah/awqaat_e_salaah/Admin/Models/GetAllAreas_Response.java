package com.awqatesalah.awqaat_e_salaah.Admin.Models;

/**
 * Created by Abubakker on 8/22/2016.
 */
public class GetAllAreas_Response
{
    public ResultDataArea[] ResultData;

    public String Count;


    public String Message;

    public String Success;

    public ResultDataArea[] getResultData ()
    {
        return ResultData;
    }

    public void setResultData (ResultDataArea[] ResultData)
    {
        this.ResultData = ResultData;
    }

    public String getCount ()
    {
        return Count;
    }

    public void setCount (String Count)
    {
        this.Count = Count;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }


    public String getSuccess ()
    {
        return Success;
    }

    public void setSuccess (String Success)
    {
        this.Success = Success;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ResultData = "+ResultData+", Count = "+Count+", Message = "+Message+", Success = "+Success+"]";
    }
    public class ResultDataArea
    {
        public String CityID;

        public String AreaID;

        public String AreaName;

        public String getCityID ()
        {
            return CityID;
        }

        public void setCityID (String CityID)
        {
            this.CityID = CityID;
        }

        public String getAreaID ()
        {
            return AreaID;
        }

        public void setAreaID (String AreaID)
        {
            this.AreaID = AreaID;
        }

        public String getAreaName ()
        {
            return AreaName;
        }

        public void setAreaName (String AreaName)
        {
            this.AreaName = AreaName;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [CityID = "+CityID+", AreaID = "+AreaID+", AreaName = "+AreaName+"]";
        }
    }
}
