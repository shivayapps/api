package com.awqatesalah.awqaat_e_salaah.util;

import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;

import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.OnFailureListener;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.google.android.play.core.tasks.Task;

public class CheckAppUpdateGooglePlay {

    Context context;
    private int MY_REQUEST_CODE =0;

    public CheckAppUpdateGooglePlay(Context context){
       this.context = context;
    }

    // Creates instance of the manager.
    AppUpdateManager appUpdateManager;
    // Returns an intent object that you use to check for an update.
    Task<AppUpdateInfo> appUpdateInfoTask;

// Checks that the platform will allow the specified type of update.
    public void checkUpdate(){
        appUpdateManager = AppUpdateManagerFactory.create(context);
        appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            System.out.println("App Update Check");
            System.out.println(appUpdateInfo.updateAvailability() );
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                // Request the update.
                try {
                    appUpdateManager.startUpdateFlowForResult(
                            // Pass the intent that is returned by 'getAppUpdateInfo()'.
                            appUpdateInfo,
                            // Or 'AppUpdateType.FLEXIBLE' for flexible updates.
                            AppUpdateType.IMMEDIATE,
                            // The current activity making the update request.
                            ((Activity)context),
                            // Include a request code to later monitor this update request.
                            MY_REQUEST_CODE);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                    ((Activity)context).finish();
                }

            }
        });
        appUpdateInfoTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(Exception e) {
                System.out.println("App Update Check");
                System.out.println(e.getMessage());
            }
        });
    }
}
