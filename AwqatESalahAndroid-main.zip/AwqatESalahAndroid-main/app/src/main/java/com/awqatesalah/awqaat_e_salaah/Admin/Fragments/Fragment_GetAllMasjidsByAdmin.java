package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import androidx.annotation.Nullable;

import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Adapters.AdminMasjids;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetMasjidByAdmin_Response;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.MasjidByAdmin_Model;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.ItemClickSupport;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dmax.dialog.SpotsDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class Fragment_GetAllMasjidsByAdmin extends GATrackingFragment {
    private AdminMasjids adminMasjids;
    private FloatingActionButton add_masjid_ref;
    private List<MasjidByAdmin_Model> list = new ArrayList<>();
    MySharedPrefrences shared;
    GetMasjidByAdmin_Response[] adapt = {new GetMasjidByAdmin_Response()};
    RecyclerView recList;
    AlertDialog dialog;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_ADMIN_MASJID_LIST);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.registeredmasjid_by_admin_fragment, container, false);
        getToolbar();
        recList = (RecyclerView) view.findViewById(R.id.recyclerview_masjidsByadmin);
        add_masjid_ref = (FloatingActionButton) view.findViewById(R.id.add_masjid_ref);
        dialog = new SpotsDialog(getActivity(), R.style.main);
        dialog.setCancelable(false);
        recList.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recList.setLayoutManager(llm);


        if (getArguments() != null) {
            if (getArguments().getString("fromHome", "no").equals("yes")) {
                setToolbar();
            }
        }


        shared = MySharedPrefrences.getInstance(getActivity());
        dialog.show();


        ItemClickSupport.addTo(recList)
                .setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
                    @Override
                    public void onItemClicked(RecyclerView recyclerView, int position, View v) {
                        Log.d("MasjidName", adapt[0].getResultData()[position].getMasjidName());
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        Fragment_UpdateTime updateTime = new Fragment_UpdateTime();
                        Bundle bundle = new Bundle();
                        bundle.putString("MasjidAdminID", adapt[0].getResultData()[position].getMasjidAdminID());
                        bundle.putString("MasjidID", adapt[0].getResultData()[position].getMasjidID());
                        bundle.putString("Update_Masjid_Name", adapt[0].getResultData()[position].getMasjidName());
                        bundle.putString("Update_Fajr", adapt[0].getResultData()[position].getJamaatFajr());
                        bundle.putString("Update_Zuhr", adapt[0].getResultData()[position].getJamaatZohar());
                        bundle.putString("Update_Asr", adapt[0].getResultData()[position].getJamaatAsr());
                        bundle.putString("Update_Maghrib", adapt[0].getResultData()[position].getJamaatMagrib());
                        bundle.putString("Update_Isha", adapt[0].getResultData()[position].getJamaatIsha());
                        bundle.putString("Update_Jumuah", adapt[0].getResultData()[position].getKhutbaJumma());
                        bundle.putString("Update_Eid", adapt[0].getResultData()[position].getJamaatEid());
                        bundle.putString("masjidadminid", adapt[0].getResultData()[position].getMasjidAdminID());
                        updateTime.setArguments(bundle);
                        ft.replace(R.id.container_fragment, updateTime);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                });


        add_masjid_ref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Fragment_AddMasjid registerFinal = new Fragment_AddMasjid();
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });


        return view;
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Masjids");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void setToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Masjids");
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);
    }

    @Override
    public void onResume() {
        super.onResume();

        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
        HashMap<String, String> param = new HashMap<>();
        param.put("MasjidAdminId", shared.getData("MasjidAdminID"));
        Call<GetMasjidByAdmin_Response> call1 = get.getAdminMasjid(StaticFunction.getValue("v6E|2D;:5Du@C|2D;:5p5>:?"), param);

        call1.enqueue(new Callback<GetMasjidByAdmin_Response>() {
            @Override
            public void onResponse(Call<GetMasjidByAdmin_Response> call, Response<GetMasjidByAdmin_Response> response) {
                if (response != null) {
                    if (response.body() != null) {
                        if (response.body().getSuccess().equals("true")) {
                            Log.d("masjid_admin_response", response.body().getMessage());
                            list.clear();
                            for (int i = 0; i < response.body().getResultData().length; i++) {
                                list.add(new MasjidByAdmin_Model(response.body().getResultData()[i].getMasjidName(), response.body().getResultData()[i].getAddress(), response.body().getResultData()[i].getIsApproved()));
                            }
                            adapt[0] = response.body();
                            adminMasjids = new AdminMasjids(list);
                            recList.setAdapter(adminMasjids);
                            dialog.dismiss();
                        } else {
                            new MaterialDialog.Builder(getActivity()).title("Error")
                                    .content(response.body().getMessage()).positiveText("Try Again").show();
                            dialog.dismiss();
                        }
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content("Something went wrong").positiveText("ok").show();
                        dialog.dismiss();
                    }
                } else {
                    StaticFunction.NoConnectionDialog(getActivity());
                    dialog.dismiss();
                }
            }


            @Override
            public void onFailure(Call<GetMasjidByAdmin_Response> call, Throwable t) {
                StaticFunction.NoConnectionDialog(getActivity());
                dialog.dismiss();
            }
        });

    }
}
