package com.awqatesalah.awqaat_e_salaah.Admin.Models;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class GetMasjidByAdmin_Response
{
    private ResultData[] ResultData;

    private String Count;

    private String Message;

    private String Success;

    public ResultData[] getResultData ()
    {
        return ResultData;
    }

    public void setResultData (ResultData[] ResultData)
    {
        this.ResultData = ResultData;
    }

    public String getCount ()
    {
        return Count;
    }

    public void setCount (String Count)
    {
        this.Count = Count;
    }

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }

    public String getSuccess ()
    {
        return Success;
    }

    public void setSuccess (String Success)
    {
        this.Success = Success;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ResultData = "+ResultData+", Count = "+Count+", Message = "+Message+", Success = "+Success+"]";
    }
    public class ResultData
    {
        private String JamaatAsr;

        private String AzaanAsr;

        private String JamaatZohar;

        private String AzaanJumma;

        private String KhutbaJumma;

        private String MasjidName;

        private String AzaanMagrib;

        private String MasjidName2;

        private String AreaName;

        private String Latitude;

        private String MasjidModifiedOn;

        private String AreaID;

        private String IsJummaMasjid;

        private String IsApproved;

        private String AzaanZohar;

        private String AddedOn;

        private String JamaatFajr;

        private String JamaatIsha;

        private String AzaanIsha;

        private String Address;

        private String AzaanFajr;

        private String MasjidID;

        private String TimeModifiedOn;

        private String Longitude;

        private String JamaatMagrib;

        private String JamaatEid;

        private String MasjidAdminID;

        public String getJamaatEid() {
            return JamaatEid;
        }

        public void setJamaatEid(String jamaatEid) {
            JamaatEid = jamaatEid;
        }

        public String getJamaatAsr ()
        {
            return JamaatAsr;
        }

        public void setJamaatAsr (String JamaatAsr)
        {
            this.JamaatAsr = JamaatAsr;
        }

        public String getAzaanAsr ()
        {
            return AzaanAsr;
        }

        public void setAzaanAsr (String AzaanAsr)
        {
            this.AzaanAsr = AzaanAsr;
        }

        public String getJamaatZohar ()
        {
            return JamaatZohar;
        }

        public void setJamaatZohar (String JamaatZohar)
        {
            this.JamaatZohar = JamaatZohar;
        }

        public String getAzaanJumma ()
        {
            return AzaanJumma;
        }

        public void setAzaanJumma (String AzaanJumma)
        {
            this.AzaanJumma = AzaanJumma;
        }

        public String getKhutbaJumma ()
        {
            return KhutbaJumma;
        }

        public void setKhutbaJumma (String KhutbaJumma)
        {
            this.KhutbaJumma = KhutbaJumma;
        }

        public String getMasjidName ()
        {
            return MasjidName;
        }

        public void setMasjidName (String MasjidName)
        {
            this.MasjidName = MasjidName;
        }

        public String getAzaanMagrib ()
        {
            return AzaanMagrib;
        }

        public void setAzaanMagrib (String AzaanMagrib)
        {
            this.AzaanMagrib = AzaanMagrib;
        }

        public String getMasjidName2 ()
        {
            return MasjidName2;
        }

        public void setMasjidName2 (String MasjidName2)
        {
            this.MasjidName2 = MasjidName2;
        }

        public String getAreaName ()
        {
            return AreaName;
        }

        public void setAreaName (String AreaName)
        {
            this.AreaName = AreaName;
        }

        public String getLatitude ()
        {
            return Latitude;
        }

        public void setLatitude (String Latitude)
        {
            this.Latitude = Latitude;
        }

        public String getMasjidModifiedOn ()
        {
            return MasjidModifiedOn;
        }

        public void setMasjidModifiedOn (String MasjidModifiedOn)
        {
            this.MasjidModifiedOn = MasjidModifiedOn;
        }

        public String getAreaID ()
        {
            return AreaID;
        }

        public void setAreaID (String AreaID)
        {
            this.AreaID = AreaID;
        }

        public String getIsJummaMasjid ()
        {
            return IsJummaMasjid;
        }

        public void setIsJummaMasjid (String IsJummaMasjid)
        {
            this.IsJummaMasjid = IsJummaMasjid;
        }

        public String getIsApproved ()
        {
            return IsApproved;
        }

        public void setIsApproved (String IsApproved)
        {
            this.IsApproved = IsApproved;
        }

        public String getAzaanZohar ()
        {
            return AzaanZohar;
        }

        public void setAzaanZohar (String AzaanZohar)
        {
            this.AzaanZohar = AzaanZohar;
        }

        public String getAddedOn ()
        {
            return AddedOn;
        }

        public void setAddedOn (String AddedOn)
        {
            this.AddedOn = AddedOn;
        }

        public String getJamaatFajr ()
        {
            return JamaatFajr;
        }

        public void setJamaatFajr (String JamaatFajr)
        {
            this.JamaatFajr = JamaatFajr;
        }

        public String getJamaatIsha ()
        {
            return JamaatIsha;
        }

        public void setJamaatIsha (String JamaatIsha)
        {
            this.JamaatIsha = JamaatIsha;
        }

        public String getAzaanIsha ()
        {
            return AzaanIsha;
        }

        public void setAzaanIsha (String AzaanIsha)
        {
            this.AzaanIsha = AzaanIsha;
        }

        public String getAddress ()
        {
            return Address;
        }

        public void setAddress (String Address)
        {
            this.Address = Address;
        }

        public String getAzaanFajr ()
        {
            return AzaanFajr;
        }

        public void setAzaanFajr (String AzaanFajr)
        {
            this.AzaanFajr = AzaanFajr;
        }

        public String getMasjidID ()
        {
            return MasjidID;
        }

        public void setMasjidID (String MasjidID)
        {
            this.MasjidID = MasjidID;
        }

        public String getTimeModifiedOn ()
        {
            return TimeModifiedOn;
        }

        public void setTimeModifiedOn (String TimeModifiedOn)
        {
            this.TimeModifiedOn = TimeModifiedOn;
        }

        public String getLongitude ()
        {
            return Longitude;
        }

        public void setLongitude (String Longitude)
        {
            this.Longitude = Longitude;
        }

        public String getJamaatMagrib ()
        {
            return JamaatMagrib;
        }

        public void setJamaatMagrib (String JamaatMagrib)
        {
            this.JamaatMagrib = JamaatMagrib;
        }

        public String getMasjidAdminID ()
        {
            return MasjidAdminID;
        }

        public void setMasjidAdminID (String MasjidAdminID)
        {
            this.MasjidAdminID = MasjidAdminID;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [JamaatAsr = "+JamaatAsr+", AzaanAsr = "+AzaanAsr+", JamaatZohar = "+JamaatZohar+", AzaanJumma = "+AzaanJumma+", KhutbaJumma = "+KhutbaJumma+", MasjidName = "+MasjidName+", AzaanMagrib = "+AzaanMagrib+", MasjidName2 = "+MasjidName2+", AreaName = "+AreaName+", Latitude = "+Latitude+", MasjidModifiedOn = "+MasjidModifiedOn+", AreaID = "+AreaID+", IsJummaMasjid = "+IsJummaMasjid+", IsApproved = "+IsApproved+", AzaanZohar = "+AzaanZohar+", AddedOn = "+AddedOn+", JamaatFajr = "+JamaatFajr+", JamaatIsha = "+JamaatIsha+", AzaanIsha = "+AzaanIsha+", Address = "+Address+", AzaanFajr = "+AzaanFajr+", MasjidID = "+MasjidID+", TimeModifiedOn = "+TimeModifiedOn+", Longitude = "+Longitude+", JamaatMagrib = "+JamaatMagrib+", MasjidAdminID = "+MasjidAdminID+"]";
        }
    }
}
