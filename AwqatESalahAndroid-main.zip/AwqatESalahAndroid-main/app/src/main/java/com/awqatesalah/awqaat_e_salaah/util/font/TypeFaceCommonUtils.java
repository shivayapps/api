package com.awqatesalah.awqaat_e_salaah.util.font;

import android.content.Context;
import android.graphics.Typeface;
import android.widget.TextView;

/**
 * Created by root on 11/1/18.
 */

public class TypeFaceCommonUtils {


    //Common accross all Layouts
    public static String getCommonFont(){
        return "montserrat_light.otf";
    }

    //Drawer Layout Fonts
    public static Typeface getDrawerFonts(Context context){
        Typeface tf = Typeface.createFromAsset(context.getAssets(),
                "montserrat_light.otf");
        return tf;
    }

    public static Typeface getDrawerFontsBold(Context context){
        Typeface tf = Typeface.createFromAsset(context.getAssets(),
                "montserrat_medium.otf");
        return tf;
    }


    public static void setRobotoRegular(TextView tv, Context context) {
        Typeface tf = Typeface.createFromAsset(context.getAssets(),
                "roboto_regular.ttf");
        tv.setTypeface(tf);
    }

    public static Typeface getRobotoRegular(Context context) {
        Typeface tf = Typeface.createFromAsset(context.getAssets(),
                "roboto_regular.ttf");
        return tf;
    }

    public static Typeface getMontserratLight(Context context) {
        Typeface tf = Typeface.createFromAsset(context.getAssets(),
                "montserrat_light.otf");
        return tf;
    }

    public static void setMontserratLight(TextView tv, Context context) {
        Typeface tf = Typeface.createFromAsset(context.getAssets(),
                "montserrat_light.otf");
        tv.setTypeface(tf);
    }
}
