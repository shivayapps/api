package com.awqatesalah.awqaat_e_salaah.Search.Models;

/**
 * Created by root on 21/5/17.
 */

public class ResponseCities {
    private int CityID;

    private String CityName;

    public int getCityID() {
        return CityID;
    }

    public void setCityID(int cityID) {
        CityID = cityID;
    }

    public String getCityName() {
        return CityName;
    }

    public void setCityName(String CityName) {
        this.CityName = CityName;
    }

    @Override
    public String toString() {
        return "ClassPojo [CityID = " + CityID + ", CityName = " + CityName + "]";
    }
}
