package com.awqatesalah.awqaat_e_salaah.Bayaan.Adapter;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.Bayaan.Model.Other_Jumuah_Model;
import com.awqatesalah.awqaat_e_salaah.R;

import java.util.List;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class RecyclerViewAdapterOther extends RecyclerView.Adapter<RecyclerViewAdapterOther.ContactViewHolder> {
    private List<Other_Jumuah_Model> list;

    public RecyclerViewAdapterOther(List<Other_Jumuah_Model> contactList) {
        this.list = contactList;
    }

    @Override
    public RecyclerViewAdapterOther.ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View itemView = LayoutInflater.
                from(parent.getContext()).
                inflate(R.layout.cardview_other, parent, false);


        return new ContactViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ContactViewHolder holder, int position) {
        Other_Jumuah_Model ci = list.get(position);
        holder.content.setText(ci.getContent());

    }


    @Override
    public int getItemCount() {
        return 1;
    }


    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        protected TextView content;



        public ContactViewHolder(View v) {
            super(v);
            content =  (TextView) v.findViewById(R.id.content);


        }
    }
}
