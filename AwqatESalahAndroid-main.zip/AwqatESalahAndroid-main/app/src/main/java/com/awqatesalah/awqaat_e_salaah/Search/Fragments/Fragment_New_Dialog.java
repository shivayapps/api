package com.awqatesalah.awqaat_e_salaah.Search.Fragments;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.preference.PreferenceManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.widget.AppCompatCheckBox;

import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.androidadvance.topsnackbar.TSnackbar;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_GetAllMasjidsByAdmin;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Update_Response;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.CallbackLocationFetchingActivity;
import com.awqatesalah.awqaat_e_salaah.DBHelper;
import com.awqatesalah.awqaat_e_salaah.Fragment_AdminRequest;
import com.awqatesalah.awqaat_e_salaah.GATrackingDialog;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MakePhotoActivity;
import com.awqatesalah.awqaat_e_salaah.MapsActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.Search.Models.SuggestTimeResponse;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.dynamitechetan.flowinggradient.FlowingGradientClass;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetView;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;
import com.truizlop.fabreveallayout.FABRevealLayout;
import com.truizlop.fabreveallayout.OnRevealChangeListener;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import dmax.dialog.SpotsDialog;
import io.codetail.animation.SupportAnimator;
import io.codetail.animation.ViewAnimationUtils;
import mehdi.sakout.fancybuttons.FancyButton;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 11/15/2016.
 */
public class Fragment_New_Dialog extends GATrackingDialog {

    //for suggestion checking if any time change than only suggest
    Boolean isAnyTimeChanged = false;

    final static AccelerateInterpolator ACCELERATE = new AccelerateInterpolator();
    final static DecelerateInterpolator DECELERATE = new DecelerateInterpolator();
    SharedPreferences getPrefs;
    File f = null;
    int endBlueX;
    int endBlueY;
    MySharedPrefrences shared;
    private TextView fajredit, zuhredit, asredit, maghribedit, ishaedit, jummahedit;
    private TextView masjidname, address, lastUpdated, shimmer, masjid_phone_number, masjid_website, masjid_enquiry;
    private TextView awqatesalah;
    private Listener dismissListener;
    private DBHelper dbHelper;
    //private MaterialEditText name, number;
    private TableRow row;
    private GoogleMap map;
    private String mhour, minu, hou;
    private int mh;
    private TextView t1;
    private MapFragment mapF;
    private ImageButton transition_close;
    //private AppCompatCheckBox favourites;
    private ImageButton btn_close_suggest;
    private ImageButton close_all_buttons;
    private LinearLayout dialog_header_layout;
    private View view;

    @BindView(R.id.eid_row)
    TableRow eid_row;

    @BindView(R.id.UEid)
    TextView UEid;

    String masjidAdminID;

    SuggestTimeResponse suggestTimeResponse = null;
    //Previous Masjid list position of what masjid is opened
    int position;

    private View.OnClickListener onClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            switch (v.getId()) {
                case R.id.Fajr:
                    //DO something
                    TimeSet(fajredit);
                    break;
                case R.id.Zuhr:
                    //DO something
                    TimeSet(zuhredit);
                    break;
                case R.id.Asr:
                    //DO something
                    TimeSet(asredit);
                    break;
                case R.id.Maghrib:
                    //DO something
                    TimeSet(maghribedit);
                    break;
                case R.id.Isha:
                    //DO something
                    TimeSet(ishaedit);
                    break;
                case R.id.Jumuah:
                    //DO something
                    TimeSet(jummahedit);
                    break;
                case R.id.UEid:
                    //DO something
                    TimeSet(UEid);
                    break;
            }
        }
    };

    public static File store(Bitmap bm, String fileName) {
        final String dirPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Screenshots";
        File dir = new File(dirPath);
        if (!dir.exists())
            dir.mkdirs();
        File file = new File(dirPath, fileName);
        try {
            FileOutputStream fOut = new FileOutputStream(file);
            bm.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
            fOut.flush();
            fOut.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return file;
    }

    public void setDismissListener(Listener dismissListener) {
        this.dismissListener = dismissListener;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (f != null) {
            f.delete();
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_MASJID_DETAILS);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        if (view == null) {
            view = getActivity().getLayoutInflater().inflate(R.layout.new_dialog_layout, new LinearLayout(getActivity()), false);
        }
        ButterKnife.bind(this,view);
        StaticFunction.displayEidTime(eid_row,UEid,getActivity());
        shared = MySharedPrefrences.getInstance(getActivity());
        masjidAdminID = shared.getData("MasjidAdminID");
        // Retrieve layout elements
        // Build dialog
        final Dialog builder = new Dialog(getActivity(), R.style.DialogFragment);
        builder.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        builder.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        builder.requestWindowFeature(Window.FEATURE_NO_TITLE);
        //builder.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        builder.setContentView(view);
        builder.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        // setCancelable(false);

        final View finalView = view;

        builder.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

                    endBlueX = finalView.getRight() / 2;
                    endBlueY = (int) (finalView.getBottom() * 0.8f);
                    float finalRadius = Math.max(finalView.getWidth(), finalView.getHeight()) * 1.5f;
                    SupportAnimator animator = ViewAnimationUtils.createCircularReveal(finalView, endBlueX, endBlueY, 24 / 2f,
                            finalRadius);
                    animator.setDuration(500);
                    animator.setInterpolator(ACCELERATE);
                    animator.start();

                    animator.addListener(new SupportAnimator.AnimatorListener() {
                        @Override
                        public void onAnimationStart() {

                        }

                        @Override
                        public void onAnimationEnd() {
                            getPrefs = PreferenceManager
                                    .getDefaultSharedPreferences(getActivity());
                            if (getPrefs.getString("firsttimenewdialog", "yes").equals("yes")) {
                                getPrefs.edit().putString("firsttimenewdialog", "no").apply();
                                getTutorial(view, builder);
                            }

                        }

                        @Override
                        public void onAnimationCancel() {

                        }

                        @Override
                        public void onAnimationRepeat() {

                        }
                    });


                } else if (Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT) {
                    getPrefs = PreferenceManager
                            .getDefaultSharedPreferences(getActivity());
                    if (getPrefs.getString("firsttimenewdialog", "yes").equals("yes")) {
                        getPrefs.edit().putString("firsttimenewdialog", "no").apply();
                        getTutorial(view, builder);
                    }

                } else {
                    getPrefs = PreferenceManager
                            .getDefaultSharedPreferences(getActivity());
                    if (getPrefs.getString("firsttimenewdialog", "yes").equals("yes")) {
                        getPrefs.edit().putString("firsttimenewdialog", "no").apply();
                    }
                }
            }
        });


        final RelativeLayout layout = (RelativeLayout) view.findViewById(R.id.relative);
        final LinearLayout buttons = (LinearLayout) view.findViewById(R.id.container_buttons);
        final LinearLayout details = (LinearLayout) view.findViewById(R.id.container_details);
        dialog_header_layout = (LinearLayout) view.findViewById(R.id.dialog_header_layout);
        FancyButton suggest_Done = (FancyButton) view.findViewById(R.id.suggest_done);
        ImageButton share = (ImageButton) view.findViewById(R.id.btn_share);
        ImageButton location = (ImageButton) view.findViewById(R.id.btn_location);
        final ImageView transition = (ImageView) view.findViewById(R.id.transition_blue);
        final ShimmerTextView shimmer = (ShimmerTextView) view.findViewById(R.id.shimmer_tv);
        final ShimmerTextView suggest_time = (ShimmerTextView) view.findViewById(R.id.suggest_time);
        final ShimmerTextView become_admin = (ShimmerTextView) view.findViewById(R.id.become_admin);
        btn_close_suggest = (ImageButton) view.findViewById(R.id.close_suggest_dialog);
        close_all_buttons = (ImageButton) view.findViewById(R.id.close_all_buttons);
        final TSnackbar snackbar = TSnackbar.make(layout, "if you find any time incorrect,click on the time to change it and suggest it", TSnackbar.LENGTH_INDEFINITE);
        View snackbarView = snackbar.getView();
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);


        //favourites = (AppCompatCheckBox) view.findViewById(R.id.addtofavourites);
        fajredit = (TextView) view.findViewById(R.id.Fajr);
        zuhredit = (TextView) view.findViewById(R.id.Zuhr);
        asredit = (TextView) view.findViewById(R.id.Asr);
        maghribedit = (TextView) view.findViewById(R.id.Maghrib);
        ishaedit = (TextView) view.findViewById(R.id.Isha);
        jummahedit = (TextView) view.findViewById(R.id.Jumuah);
        masjidname = (TextView) view.findViewById(R.id.Masjid_Title);
        address = (TextView) view.findViewById(R.id.Masjid_Address);
        lastUpdated = (TextView) view.findViewById(R.id.LastUpdated);
        masjid_enquiry = (TextView) view.findViewById(R.id.masjid_enquiry);
        masjid_phone_number = (TextView) view.findViewById(R.id.masjid_phone_number);
        masjid_website = (TextView) view.findViewById(R.id.masjid_website);
        awqatesalah = (TextView) view.findViewById(R.id.awqatesalah);
        dbHelper = new DBHelper(getActivity());
        row = (TableRow) view.findViewById(R.id.row);
        fajredit.setOnClickListener(onClickListener);
        zuhredit.setOnClickListener(onClickListener);
        asredit.setOnClickListener(onClickListener);
        maghribedit.setOnClickListener(onClickListener);
        ishaedit.setOnClickListener(onClickListener);
        jummahedit.setOnClickListener(onClickListener);
        UEid.setOnClickListener(onClickListener);
        final AlertDialog dialog = new SpotsDialog(getActivity(), R.style.Suggestion);
        dialog.setCancelable(false);

        if (getValue("isPreAdded").equals("true")) {
            shimmer.setText("This masjid has no admin.");
            become_admin.setVisibility(View.VISIBLE);
        } else if (dateDiff(getValue("LastUpdated"))) {
            shimmer.setText("Admin of this masjid is not updating time for this masjid.");
            become_admin.setVisibility(View.VISIBLE);
        } else {
            shimmer.setText("If you find any time incorrect, you can Suggest the correct time");
            become_admin.setVisibility(View.GONE);
        }

        Shimmer shimmer1 = new Shimmer();
        shimmer1.start(shimmer);
        shimmer1.start(suggest_time);
        shimmer1.start(become_admin);
        //Set Values


        if (!getValue("website").equals("-") && !getValue("website").equals("")) {
            masjid_website.setText(getValue("website"));
        } else {
            masjid_website.setVisibility(View.GONE);
        }

        position = getArguments().getInt("position", 0);

        masjid_website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsWebsiteClickEvent();
            }
        });

        if (!getValue("contactNo").equals("-") && !getValue("contactNo").equals("")) {
            masjid_phone_number.setText(getValue("contactNo"));
        } else {
            masjid_phone_number.setVisibility(View.GONE);
        }

        masjid_phone_number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsContactNoClickEvent();

                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + masjid_phone_number.getText().toString()));
                startActivity(intent);
            }
        });


        if (!getValue("enquiry").equals("-") && !getValue("enquiry").equals("")) {
            masjid_enquiry.setText(getValue("enquiry"));
        } else {
            masjid_enquiry.setVisibility(View.GONE);
        }

        if (masjidAdminID.equals(getValue("Username"))) {
            shimmer.setText("You are admin of this masjid.");
            suggest_time.setText(getString(R.string.update_time));
        } else {
            suggest_time.setText(getString(R.string.suggest_time));
        }


        become_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsBecomeAdminClickEvent();

                getDialog().dismiss();
                String message = "I want to become admin of " + getValue("MasjidName").toString().toUpperCase() + "\nAddress : " + getValue("Address");
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                Bundle bundle = new Bundle();
                bundle.putString("message", message);
                bundle.putString("masjidID", getValue("Masjid_ID"));
                Fragment_AdminRequest registerFinal = new Fragment_AdminRequest();
                registerFinal.setArguments(bundle);
                ft.replace(R.id.container_fragment, registerFinal);
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                ft.addToBackStack(null);
                ft.commit();
            }
        });



        if (!getValue("latitude").equals("")  && !getValue("longitude").equals("")) {
            address.setPaintFlags(address.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        }

        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsAddressClickEvent();
                
                StaticFunction.IntentToLocationActivity(getActivity(),
                        getValue("latitude"),
                        getValue("longitude"),
                        getValue("MasjidName"),
                        getValue("data"));
            }
        });

        setAllText();

        DisableAllText();


        //setting things

        dbHelper.openDB();
        Cursor cursor = dbHelper.getFavouritesFlagServer(Integer.parseInt(getValue("Masjid_ID")));
        if (cursor.getCount() > 0) {
            //favourites.setChecked(true);
        }



       /* btn_suggest_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (getActivity().checkSelfPermission(Manifest.permission.CAMERA)
                            != PackageManager.PERMISSION_GRANTED) {

                        requestPermissions(new String[]{Manifest.permission.CAMERA},
                                11);
                    }else{
                        Intent intent = new Intent(getActivity(), MakePhotoActivity.class);
                        startActivityForResult(intent, 123);
                    }
                }else {
                    Intent intent = new Intent(getActivity(), MakePhotoActivity.class);
                    startActivityForResult(intent, 123);
                }
            }
        });*/


        /*favourites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment_Fravourites fragment_fravourites = new Fragment_Fravourites();
                if (favourites.isChecked()) {
                    fragment_fravourites.addToFavourite(getValue("Masjid_ID"),shared.getData("MasjidAdminID"),getActivity());
                } else {
                    fragment_fravourites.removeFavourite(getValue("Masjid_ID"),shared.getData("MasjidAdminID"),getActivity());
                }
            }
        });*/


        FlowingGradientClass grad = new FlowingGradientClass();
        grad.setBackgroundResource(R.drawable.translate)
                .onRelativeLayout(layout)
                .setTransitionDuration(4000)
                .start();
        final FABRevealLayout fabRevealLayout = (FABRevealLayout) view.findViewById(R.id.fab_reveal_layout);
        // configureFABReveal(fabRevealLayout);
        suggest_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsSuggestTimeEvent();

                StaticFunction.displayEidTime(eid_row,UEid,getActivity());
                if (suggest_time.getText().equals(getString(R.string.suggest_time))) {
                    //Hiding Image Suggestion
                    /*new MaterialDialog.Builder(getActivity())
                            .title("Suggestion")
                            .content(Html.fromHtml(getString(R.string.suggestion)))
                            .items(R.array.suggestionchoice)
                            .itemsCallbackSingleChoice(0, new MaterialDialog.ListCallbackSingleChoice() {
                                @Override
                                public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                                    switch (which) {
                                        case 0:

                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                if (getActivity().checkSelfPermission(Manifest.permission.CAMERA)
                                                        != PackageManager.PERMISSION_GRANTED) {

                                                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                                                            11);
                                                } else {
                                                    Intent intent = new Intent(getActivity(), MakePhotoActivity.class);
                                                    startActivityForResult(intent, 123);
                                                }
                                            } else {
                                                Intent intent = new Intent(getActivity(), MakePhotoActivity.class);
                                                startActivityForResult(intent, 123);
                                            }
                                            break;
                                        case 1:

                                            fabRevealLayout.revealSecondaryView();
                                            //suggest.performClick();
                                            EnableAllText();
                                            buttons.setBackgroundResource(0);
                                            buttons.setVisibility(View.GONE);
                                            details.setVisibility(View.VISIBLE);
                                            //Snackbar.make(view,"Click on the time To change it",Snackbar.LENGTH_LONG).show();
                                            snackbar.show();
                                            break;

                                    }

                                    return true;
                                }
                            })
                            .positiveText("Ok")
                            .show();*/
                    fabRevealLayout.revealSecondaryView();
                    //suggest.performClick();
                    EnableAllText();
                    buttons.setBackgroundResource(0);
                    buttons.setVisibility(View.GONE);
                    details.setVisibility(View.VISIBLE);
                    //Snackbar.make(view,"Click on the time To change it",Snackbar.LENGTH_LONG).show();
                    snackbar.show();
                } else {
                    dismiss();
                    Fragment_GetAllMasjidsByAdmin masjidsByAdmin = new Fragment_GetAllMasjidsByAdmin();
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("AdminID", masjidAdminID);
                    bundle1.putString("fromHome", "yes");
                    masjidsByAdmin.setArguments(bundle1);
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager
                            .beginTransaction();
                    if (fragmentManager.getBackStackEntryCount() > 0) {
                        for (int i = 0; i < fragmentManager.getBackStackEntryCount(); ++i) {
                            fragmentManager.popBackStack();
                        }
                    }
                    fragmentTransaction.replace(R.id.container_fragment, masjidsByAdmin);
                    fragmentTransaction.commit();
                }
            }
        });
        close_all_buttons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAllText();
                DisableAllText();
                buttons.setVisibility(View.VISIBLE);
                details.setVisibility(View.GONE);
                fabRevealLayout.revealMainView();
            }
        });

        btn_close_suggest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setAllText();
                DisableAllText();
                buttons.setVisibility(View.VISIBLE);
                details.setVisibility(View.GONE);
                fabRevealLayout.revealMainView();
                snackbar.dismiss();
                dialog.dismiss();


                if (view != null) {
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
            }
        });
       /* suggest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EnableAllText();
                buttons.setBackgroundResource(0);
                buttons.setVisibility(View.GONE);
                details.setVisibility(View.VISIBLE);
                //Snackbar.make(view,"Click on the time To change it",Snackbar.LENGTH_LONG).show();
                snackbar.show();
            }
        });*/

        suggest_Done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsSendSuggestionEvent();

                if (isAnyTimeChanged) {
                    snackbar.dismiss();

                    if (!getValue(fajredit).equals("") && !getValue(zuhredit).equals("") && !getValue(asredit).equals("") && !getValue(maghribedit).equals("") && !getValue(ishaedit).equals("")) {
                        if (StaticFunction.isOnline(getActivity())) {
                            CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                            Call<SuggestTimeResponse> call1 = get.suggest_Time(StaticFunction.getValue("$F886DE%:>6"),masjidAdminID,getValue("Masjid_ID"), "", "", "", "", "", "", getValue(fajredit), getValue(zuhredit), getValue(asredit), getValue(maghribedit), getValue(ishaedit), getValue(jummahedit), getValue(UEid), shared.getData("Name"), shared.getData("Number").trim());
                            dialog.show();
                            call1.enqueue(new Callback<SuggestTimeResponse>() {
                                @Override
                                public void onResponse(Call<SuggestTimeResponse> call, Response<SuggestTimeResponse> response) {
                                    if (response.body().getSuccess().equals("true")) {
                                        Log.d("Post_Suggest_Done", response.body().toString());
                                        new MaterialDialog.Builder(getActivity()).title("Suggestion Done Successfully")
                                                .content("Note : "+response.body().getMessage()).positiveText("Jazakallah").show();
                                        setAllText();
                                        DisableAllText();
                                        buttons.setVisibility(View.VISIBLE);
                                        details.setVisibility(View.GONE);
                                        fabRevealLayout.revealMainView();
                                        dialog.dismiss();

                                        isAnyTimeChanged = false;

                                        if(response.body().getResultData()!=null){
                                            suggestTimeResponse = response.body();
                                            fajredit.setText(response.body().getResultData().getJamaatFajr().toUpperCase().replace("PM","AM"));
                                            zuhredit.setText(response.body().getResultData().getJamaatZohar().toUpperCase().replace("PM","AM"));
                                            asredit.setText(response.body().getResultData().getJamaatAsr().toUpperCase().replace("PM","AM"));
                                            maghribedit.setText(response.body().getResultData().getJamaatMagrib().toUpperCase().replace("PM","AM"));
                                            ishaedit.setText(response.body().getResultData().getJamaatIsha().toUpperCase().replace("PM","AM"));
                                            jummahedit.setText(response.body().getResultData().getKhutbaJumma().toUpperCase().replace("PM","AM"));
                                            UEid.setText(response.body().getResultData().getJamaatEid().toUpperCase().replace("PM","AM"));
                                        }
                                    } else {
                                        dialog.dismiss();
                                        new MaterialDialog.Builder(getActivity()).title("Error")
                                                .content(response.body().getMessage()).positiveText("Try Again").show();
                                    }
                                }

                                @Override
                                public void onFailure(Call<SuggestTimeResponse> call, Throwable t) {
                                    StaticFunction.NoConnectionDialog(getActivity());
                                    dialog.dismiss();
                                }
                            });
                        } else {
                            dbHelper = new DBHelper(getActivity());
                            dbHelper.openDB();
                            Cursor cursor = dbHelper.getSuggestionFlag(Integer.parseInt(getValue("Masjid_ID")));

                            if (cursor.getCount() > 0) {
                                DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
                                String date = df.format(Calendar.getInstance().getTime());
                                long resultUpdate = dbHelper.update_suggestion(Integer.parseInt(getValue("Masjid_ID")), getValue(fajredit), getValue(zuhredit), getValue(asredit),
                                        getValue(maghribedit), getValue(ishaedit),
                                        getValue(jummahedit),getValue(UEid), shared.getData("Name"), shared.getData("Number").trim(), "pending", date.toString());
                                if (resultUpdate == 1) {
                                    new MaterialDialog.Builder(getActivity()).title("Suggestion Done Successfully")
                                            .content("Note : Your suggestion will be reach us automatically when you switch on the internet.").positiveText("Jazakallah").show();
                                    setAllText();
                                    DisableAllText();
                                    buttons.setVisibility(View.VISIBLE);
                                    details.setVisibility(View.GONE);
                                    fabRevealLayout.revealMainView();
                                }
                                dbHelper.closeDB();
                            } else {
                                DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
                                String date = df.format(Calendar.getInstance().getTime());
                                long resultInsert = dbHelper.insert_suggestion(Integer.parseInt(getValue("Masjid_ID")), getValue(fajredit), getValue(zuhredit), getValue(asredit), getValue(maghribedit), getValue(ishaedit), getValue(jummahedit),getValue(UEid), shared.getData("Name"), shared.getData("Number").trim(), "pending", date.toString());
                                if (resultInsert == -1) {
                                    Toast.makeText(getActivity(), "Some error occurred while inserting", Toast.LENGTH_SHORT).show();
                                } else {
                                    new MaterialDialog.Builder(getActivity()).title("Suggestion Done Successfully")
                                            .content("Note : Your suggestion will be reach us automatically when you switch on the internet.").positiveText("Jazakallah").show();
                                    setAllText();
                                    DisableAllText();
                                    buttons.setVisibility(View.VISIBLE);
                                    details.setVisibility(View.GONE);
                                    fabRevealLayout.revealMainView();
                                }

                                dbHelper.closeDB();
                            }


                        }
                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content("Insert All Namaz time").positiveText("Try Again").show();
                    }

                } else {
                    //If user trying to suggest without changing any time
                    Toast.makeText(getActivity(), R.string.suggest_error_text, Toast.LENGTH_LONG).show();
                }

            }

        });

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsPLusIconLocationClickEvent();

                StaticFunction.IntentToLocationActivity(getActivity(),
                        getValue("latitude"),
                        getValue("longitude"),
                        getValue("MasjidName"), getValue("data"));

            }
        });

        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsAddressClickEvent();

                StaticFunction.IntentToLocationActivity(getActivity(),
                        getValue("latitude"),
                        getValue("longitude"),
                        getValue("MasjidName"), getValue("data"));
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Analytics Event
                new Analytics(getActivity()).logMasjidDetailsPLusIconShareClickEvent();

                dialog_header_layout.setVisibility(View.INVISIBLE);
                fabRevealLayout.revealMainView();
                // favourites.setVisibility(View.GONE);
                transition.setVisibility(View.GONE);
                awqatesalah.setVisibility(View.VISIBLE);
                Handler handler = new Handler();
                Runnable r = new Runnable() {
                    public void run() {
                        Bitmap bm = getScreenshot();
                        //f = store(bm, getValue(masjidname).toString().replace("-", "").replace(" ", "") + System.currentTimeMillis() + ".jpg");
                        //favourites.setVisibility(View.VISIBLE);
                        transition.setVisibility(View.VISIBLE);
                        awqatesalah.setVisibility(View.GONE);
                        dialog_header_layout.setVisibility(View.VISIBLE);
                        shareImage(bm,getValue(masjidname).toString().replace("-", "").replace(" ", "") + System.currentTimeMillis() + ".jpg");
                        /*if (f != null) {
                            shareImage(bm);
                        }*/
                    }
                };
                handler.postDelayed(r, 2000);


            }
        });


        final View finalView1 = view;
        transition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    float finalRadius = Math.max(finalView1.getWidth(), finalView1.getHeight()) * 1.5f;
                    SupportAnimator animator = ViewAnimationUtils.createCircularReveal(finalView1, endBlueX, endBlueY,
                            finalRadius, 24 / 2f);
                    animator.setDuration(500);
                    animator.setInterpolator(DECELERATE);
                    animator.addListener(new SupportAnimator.AnimatorListener() {
                        @Override
                        public void onAnimationStart() {

                        }

                        @Override
                        public void onAnimationEnd() {
                            if (dismissListener != null) {
                                dismissListener.onDismiss(suggestTimeResponse,position);
                                dismiss();
                            }
                        }

                        @Override
                        public void onAnimationCancel() {

                        }

                        @Override
                        public void onAnimationRepeat() {

                        }
                    });
                    animator.start();
                } else {
                    if (dismissListener != null) {
                        dismissListener.onDismiss(suggestTimeResponse,position);
                        dismiss();
                    }
                }
            }
        });

        builder.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));
        return builder;
    }

    private void EnableAllText() {
        jummahedit.setClickable(true);
        fajredit.setClickable(true);
        zuhredit.setClickable(true);
        asredit.setClickable(true);
        maghribedit.setClickable(true);
        ishaedit.setClickable(true);
        UEid.setClickable(true);
    }

    private void DisableAllText() {
        jummahedit.setClickable(false);
        fajredit.setClickable(false);
        zuhredit.setClickable(false);
        asredit.setClickable(false);
        maghribedit.setClickable(false);
        ishaedit.setClickable(false);
        UEid.setClickable(false);

    }

    private void setAllText() {
        masjidname.setText(getValue("MasjidName").toString().toUpperCase());
        address.setText(getValue("Address").toString().trim());
        lastUpdated.setText("Last Updated On : " + getValue("LastUpdated"));
        fajredit.setText(getValue("Fajr"));
        zuhredit.setText(getValue("Zuhr"));
        asredit.setText(getValue("Asr"));
        maghribedit.setText(getValue("Maghrib"));
        ishaedit.setText(getValue("Isha"));
        if (getValue("Jumuah").equals("") || getValue("Jumuah").equals("-")) {
            row.setVisibility(View.GONE);
        } else {
            jummahedit.setText(getValue("Jumuah"));
        }
        if (getValue("isPreAdded").equals("true")) {
            row.setVisibility(View.VISIBLE);
            jummahedit.setText(getValue("Jumuah"));
        }

        if (getValue("JamaatEid").equals("") || getValue("JamaatEid").equals("-")) {
            eid_row.setVisibility(View.GONE);
        } else {
            UEid.setText(getValue("JamaatEid"));
        }

    }

    private Bitmap getScreenshot() {
        //  View screenView = view.getRootView();
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);

        return bitmap;
    }

    private String getValue(TextView key) {
        return key.getText().toString().trim();
    }

    public void shareImage(Bitmap bitmap,String fileName) {
        Uri contentUri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentUri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        } else {
            contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        }

        ContentResolver contentResolver = getActivity().getContentResolver();
        ContentValues newImageDetails = new ContentValues();
        newImageDetails.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        Uri imageContentUri = contentResolver.insert(contentUri, newImageDetails);

        try (ParcelFileDescriptor fileDescriptor =
                     contentResolver.openFileDescriptor(imageContentUri, "w", null)) {
            FileDescriptor fd = fileDescriptor.getFileDescriptor();
            OutputStream outputStream = null;
            outputStream = new FileOutputStream(fd);
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(outputStream);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, bufferedOutputStream);
            bufferedOutputStream.flush();
            bufferedOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(getActivity(),"Error sharing time",Toast.LENGTH_SHORT).show();
            Log.e("", "Error saving bitmap", e);
        }

        /*Uri bmpUri;
        if (Build.VERSION.SDK_INT >= 24) {
            bmpUri = FileProvider.getUriForFile(getActivity(), getActivity().getApplicationContext().getPackageName() + ".provider", file);
        } else {
            bmpUri = Uri.fromFile(file);
        }*/

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.setPackage("com.whatsapp");
        shareIntent.putExtra(Intent.EXTRA_TEXT,shared.getShareApp());

        if (imageContentUri != null) {
            shareIntent.putExtra(Intent.EXTRA_STREAM, imageContentUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            shareIntent.setType("image/*");
        }

        try {
            startActivity(shareIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            ex.printStackTrace();
        }
    }
   /* @Override
    protected boolean isActionBarBlurred() {
        return true;
    }

    @Override
    protected float getDownScaleFactor() {
        // Allow to customize the down scale factor.
        return 5;
    }

    @Override
    protected int getBlurRadius() {
        // Allow to customize the blur radius factor.
        return 4;
    }*/

    private void configureFABReveal(FABRevealLayout fabRevealLayout) {
        fabRevealLayout.setOnRevealChangeListener(new OnRevealChangeListener() {
            @Override
            public void onMainViewAppeared(FABRevealLayout fabRevealLayout, View mainView) {

            }

            @Override
            public void onSecondaryViewAppeared(final FABRevealLayout fabRevealLayout, View secondaryView) {
                prepareBackTransition(fabRevealLayout);
            }
        });
    }

    private void prepareBackTransition(final FABRevealLayout fabRevealLayout) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                fabRevealLayout.revealMainView();
            }
        }, 2000);
    }

    private MapFragment getMapFragment() {
        FragmentManager fm = null;

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            fm = getFragmentManager();
        } else {
            fm = getChildFragmentManager();
        }

        return (MapFragment) fm.findFragmentById(R.id.map);
    }

    private String getValue(String key) {
        return getArguments().getString(key, "-");
    }

    @Override
    public void onStart() {
        super.onStart();
        dbHelper.openDB();
    }

    @Override
    public void onStop() {
        super.onStop();
        dbHelper.closeDB();
    }

    private void getTutorial(View view, Dialog context) {
        TapTargetView.showFor(context,
                TapTarget.forView(context.getWindow().findViewById(R.id.fab), "From here you can :\n Add to Favourites \n Share time \n See location")
                        .cancelable(false)
                        .outerCircleColor(R.color.colorPrimary)
                        .tintTarget(false)
                , new TapTargetView.Listener() {
                    @Override
                    public void onTargetClick(TapTargetView view) {
                        super.onTargetClick(view);

                    }
                });
    }

    public void TimeSet(final TextView t) {
        int hour;
        int minute;
        // TODO Auto-generated method stub
        if (!t.getText().equals("-") && !t.getText().equals("--:--") && !t.getText().equals("")) {
            Boolean isTimePM = t.getText().toString().contains("PM");
            String[] time = t.getText().toString().replace("AM", "").replace("PM", "").trim().replaceAll("\\p{Z}", "").split(":");
            hour = Integer.parseInt(time[0]);
            minute = Integer.parseInt(time[1]);

            if(isTimePM){
                hour = hour+12;
            }

        } else {
            Calendar mcurrentTime = Calendar.getInstance();
            hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            minute = mcurrentTime.get(Calendar.MINUTE);
        }
        TimePickerDialog mTimePicker;
        t1 = t;
        mTimePicker = new TimePickerDialog(getActivity(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                StaticFunction.setNamazTime(selectedHour, selectedMinute, t1, t);
                isAnyTimeChanged = true;
            }
        }, hour, minute, false);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        dismissListener.onDismiss(suggestTimeResponse,position);
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123 && resultCode == Activity.RESULT_OK) {
            String path = data.getStringExtra("response");

            //  Toast.makeText(getActivity(),path,Toast.LENGTH_LONG).show();

            final SpotsDialog dialog = new SpotsDialog(getActivity(), R.style.UploadImage);

            dialog.setCancelable(false);
            dialog.show();
            final File file = new File(path);

            RequestBody reqFile = RequestBody.create(MediaType.parse("image/*"), file);
            MultipartBody.Part body = MultipartBody.Part.createFormData("ImageFile", file.getName(), reqFile);
            RequestBody id = RequestBody.create(MediaType.parse("text/plain"), getValue("Masjid_ID"));
            RequestBody personName = RequestBody.create(MediaType.parse("text/plain"), shared.getData("Name")+"-"+masjidAdminID);
            RequestBody personNumber = RequestBody.create(MediaType.parse("text/plain"), shared.getData("Number"));


            CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
            Call<Update_Response> call1 = get.uploadSuggestionImage(StaticFunction.getValue("$F886DE%:>6':2x>286"), body, id, personName, personNumber);
            call1.enqueue(new Callback<Update_Response>() {
                @Override
                public void onResponse(Call<Update_Response> call, Response<Update_Response> response) {
                    dialog.dismiss();
                    if (response.body().getSuccess().equals("true")) {
                        Log.d("Post_Suggest_Image", response.body().getMessage());
                        new MaterialDialog.Builder(getActivity()).title("Suggestion Done Successfully")
                                .content("Note : The time will be updated in 12 hours if it is found correct").positiveText("Jazakallah").show();

                        if (file != null) {
                            file.delete();
                        }

                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();
                    }
                }

                @Override
                public void onFailure(Call<Update_Response> call, Throwable t) {
                    dialog.dismiss();
                    StaticFunction.NoConnectionDialog(getActivity());
                }
            });
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 11) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Now user should be able to use camera
                Intent intent = new Intent(getActivity(), MakePhotoActivity.class);
                startActivityForResult(intent, 123);
            } else {
                Toast.makeText(getActivity(), "Please grant the permission to perform this feature", Toast.LENGTH_LONG).show();
            }
        }
    }

    public Boolean dateDiff(String date) {
        {
            if (!date.equals("-")) {
                Date dt2 = new Date();
                String startDateString = date;
                DateFormat df = new SimpleDateFormat("EEE,dd MMM yyyy,hh:mm a", Locale.US);
                Date dt1 = null;
                try {
                    dt1 = df.parse(startDateString);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (dt1 == null) {
                    return false;
                }
                long diff = dt2.getTime() - dt1.getTime();
                long diffSeconds = diff / 1000 % 60;
                long diffMinutes = diff / (60 * 1000) % 60;
                long diffHours = diff / (60 * 60 * 1000);
                int diffInDays = (int) ((dt2.getTime() - dt1.getTime()) / (1000 * 60 * 60 * 24));

                if (diffInDays > 25) {
                    System.err.println("Difference in number of days (2) : " + diffInDays);
                    return true;
                }
            }
            return false;
        }
    }

    public interface Listener {
        void onDismiss(SuggestTimeResponse response,int position);
    }



}
