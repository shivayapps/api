package com.awqatesalah.awqaat_e_salaah.Admin.Adapters;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_AddMasjid;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_GetAllMasjidsByAdmin;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_Profile;
import com.awqatesalah.awqaat_e_salaah.Admin.Fragments.Fragment_UpdateMasjidLocation;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.AdminGridModel;
import com.awqatesalah.awqaat_e_salaah.Bayaan.Fragment.Fragment_UpdateJumuah;
import com.awqatesalah.awqaat_e_salaah.Bayaan.Fragment.Fragment_UpdateOther;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;

import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Created by root on 24/2/17.
 */
public class AdminGridApapter extends RecyclerView.Adapter<AdminGridApapter.ContactViewHolder> {

    private ArrayList<AdminGridModel> List;
    private MySharedPrefrences shared;
    private FragmentManager fm;

    Activity activity;
    public AdminGridApapter(ArrayList<AdminGridModel> List, FragmentManager fm, MySharedPrefrences shared, Activity activity) {
        this.List = List;
        this.shared=shared;
        this.fm=fm;
        this.activity=activity;
    }

    @Override
    public int getItemCount() {
        return List.size();
    }

    @Override
    public void onBindViewHolder(ContactViewHolder contactViewHolder, final int i) {
        contactViewHolder.title.setText(List.get(i).title);
        contactViewHolder.image.setImageDrawable(List.get(i).image);
        contactViewHolder.badge.setVisibility(View.GONE);
        /*contactViewHolder.badge.setText(String.valueOf(shared.getMessageCount()));
        if (List.get(i).title.equals("Message")) {
            contactViewHolder.badge.setVisibility(View.VISIBLE);
        }
        else

        {
            contactViewHolder.badge.setVisibility(View.GONE);

        }*/

        if (List.get(i).title.equals("Add new Masjid")) {
            contactViewHolder.addmasjid.setVisibility(View.VISIBLE);
        }
        else

        {
            contactViewHolder.addmasjid.setVisibility(View.GONE);

        }



        contactViewHolder.main_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft = fm.beginTransaction();
                if(fm.getBackStackEntryCount()>0) {
                    for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                        fm.popBackStack();
                    }
                }
                switch (i){

                    case 0:
                        Fragment_GetAllMasjidsByAdmin registerFinal = new Fragment_GetAllMasjidsByAdmin();
                        Bundle bundle =new Bundle();
                        bundle.putString("AdminID",shared.getData("MasjidAdminID"));
                        registerFinal.setArguments(bundle);
                        ft.replace(R.id.container_fragment, registerFinal);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                    case 1:
                        String adminChatNumber  = shared.getAdminChatWhatsappNumber();
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse("whatsapp://send?phone="+ adminChatNumber +"&text=" /*+ URLEncoder.encode("Message\n", "UTF-8")*/));
                            activity.startActivity(i);
                        } catch (Exception e){
                            Toast.makeText(activity, "Whatsapp not installed!", Toast.LENGTH_LONG).show();
                        }
                        /*Fragment_Chat chat = new Fragment_Chat();
                        ft.replace(R.id.container_fragment, chat);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();*/
                        break;
                    case 2:

                        Fragment_Profile fragment_profile = new Fragment_Profile();
                        ft.replace(R.id.container_fragment, fragment_profile);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                    case 3:

                        Fragment_AddMasjid addMasjid = new Fragment_AddMasjid();
                        ft.replace(R.id.container_fragment, addMasjid);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                    case 4:

                        Fragment_UpdateMasjidLocation fragment_updateMasjidLocation = new Fragment_UpdateMasjidLocation();
                        fragment_updateMasjidLocation.show(ft, "location");
                        break;
                    case 5:

                        Fragment_UpdateJumuah jumuah = new Fragment_UpdateJumuah();
                        ft.replace(R.id.container_fragment, jumuah);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                        break;

                    case 6:

                        Fragment_UpdateOther other = new Fragment_UpdateOther();
                        ft.replace(R.id.container_fragment, other);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                        break;
                }
            }
        });

    }




@Override
public ContactViewHolder onCreateViewHolder(ViewGroup viewGroup, final int i) {
final View itemView = LayoutInflater.
        from(viewGroup.getContext()).
        inflate(R.layout.admin_item, viewGroup, false);
        return new ContactViewHolder(itemView);
        }
public static class ContactViewHolder extends RecyclerView.ViewHolder {
    protected TextView title;
    protected ImageView image;
    protected TextView badge;
    protected TextView addmasjid;
    protected LinearLayout main_container;


    public ContactViewHolder(View v) {
        super(v);
        title =  (TextView) v.findViewById(R.id.title);
        image = (ImageView)  v.findViewById(R.id.item_img);
        badge = (TextView)  v.findViewById(R.id.badge);
        addmasjid = (TextView)  v.findViewById(R.id.addmasjid);
        main_container = (LinearLayout)  v.findViewById(R.id.main_container);

    }
}

}