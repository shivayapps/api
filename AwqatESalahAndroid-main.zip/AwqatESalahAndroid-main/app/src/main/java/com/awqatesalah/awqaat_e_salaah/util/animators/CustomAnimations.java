package com.awqatesalah.awqaat_e_salaah.util.animators;

import android.content.Context;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.awqatesalah.awqaat_e_salaah.R;

/**
 * Created by root on 18/1/18.
 */

public class CustomAnimations {

    Context context;

    public CustomAnimations(Context context) {
        this.context = context;
    }

    public Animation setZoomOutAnimation(){
        return AnimationUtils.loadAnimation(context, R.anim.zoomout_fast);
    }

    public Animation transalteRightToLeft(){
        return AnimationUtils.loadAnimation(context, R.anim.translate_right_to_left);

    }



    public Animation transalteLeftToRight(){
        return AnimationUtils.loadAnimation(context, R.anim.translate_left_to_right);

    }

    public Animation fadeIN(){
        return AnimationUtils.loadAnimation(context, R.anim.fade_in);

    }

    public Animation Scale(){
        return AnimationUtils.loadAnimation(context, R.anim.scale);

    }

}

