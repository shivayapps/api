package com.awqatesalah.awqaat_e_salaah.Admin.Models;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class Update_Response
{


    private String Message;

    private String Success;

    public String getMessage ()
    {
        return Message;
    }

    public void setMessage (String Message)
    {
        this.Message = Message;
    }

    public String getSuccess ()
    {
        return Success;
    }

    public void setSuccess (String Success)
    {
        this.Success = Success;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ Message = "+Message+",  Success = "+Success+"]";
    }
}