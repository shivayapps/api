package com.awqatesalah.awqaat_e_salaah;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Created by Abubakker on 12/21/2016.
 */
public class Native extends AppCompatActivity{

    static {
        System.loadLibrary("myjni"); // "myjni.dll" in Windows, "libmyjni.so" in Unixes
    }
   // public native String getMessage();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
