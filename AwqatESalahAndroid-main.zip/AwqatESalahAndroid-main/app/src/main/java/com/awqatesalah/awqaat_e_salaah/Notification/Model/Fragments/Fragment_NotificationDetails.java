package com.awqatesalah.awqaat_e_salaah.Notification.Model.Fragments;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.util.DrawerLocker;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Fragment_NotificationDetails extends GATrackingFragment {
    private TextView title,details,date;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_NOTIFICATION_DETAILS);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.detailnotifragment,container,false);
        title = (TextView) view.findViewById(R.id.title);
        details = (TextView) view.findViewById(R.id.details);
        details.setMovementMethod(LinkMovementMethod.getInstance());
        Linkify.addLinks(details, Linkify.ALL);


        date = (TextView) view.findViewById(R.id.date);
        getToolbar();

        title.setText(getValue("Title"));
        details.setText(Html.fromHtml(getValue("Details")));
        date.setText(getValue("Added"));

        ((DrawerLocker) getActivity()).setDrawerEnabled(false);

        return view;
    }
    private String getValue(String key)
    {
        return getArguments().getString(key);
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Notification Details");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public void onStop() {
        super.onStop();
        ((DrawerLocker) getActivity()).setDrawerEnabled(true);
    }
}
