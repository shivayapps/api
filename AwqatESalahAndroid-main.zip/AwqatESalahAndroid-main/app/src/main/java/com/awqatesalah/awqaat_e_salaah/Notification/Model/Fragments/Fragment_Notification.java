package com.awqatesalah.awqaat_e_salaah.Notification.Model.Fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Analytics;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Adapter.RecyclerViewAdapterNoti;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Models.Notification_Model;
import com.awqatesalah.awqaat_e_salaah.Notification.Model.Models.Notification_Response;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RecyclerViewEmptySupport;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dmax.dialog.SpotsDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Fragment_Notification extends GATrackingFragment {
    OnNotificationOpenListener callBack;
    MySharedPrefrences shared;
    private List<Notification_Model> list = new ArrayList<>();
    private RecyclerViewAdapterNoti listAdpter;
    private Notification_Response notification_response;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            callBack = (OnNotificationOpenListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Analytics
        new Analytics(getActivity()).screenViewEvent(Analytics.PAGE_NOTIFICATIONS_LIST);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container != null) {
            container.removeAllViews();
        }
        View view = inflater.inflate(R.layout.notificationfragment,container,false);
        final RecyclerViewEmptySupport recList = (RecyclerViewEmptySupport) view.findViewById(R.id.rv);
        // progress = (AVLoadingIndicatorView) view.findViewById(R.id.avi1);
        recList.setEmptyView(view.findViewById(R.id.list_empty1));
        getToolbar();
        recList.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recList.setLayoutManager(llm);
        shared = MySharedPrefrences.getInstance(getActivity());
       /* shared.saveNotificationCount(0);
        callBack.UpdateUI();*/
      //  recList.addItemDecoration(new DividerItemDecoration(getActivity()));
        final AlertDialog dialog =new SpotsDialog(getActivity(), R.style.main);
        dialog.show();
        dialog.setCancelable(false);

        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        Call<Notification_Response> call1 = get.noti(StaticFunction.getValue("v6E}@E:7:42E:@?D"));

        call1.enqueue(new Callback<Notification_Response>() {
            @Override
            public void onResponse(Call<Notification_Response> call, Response<Notification_Response> response) {
                if (response.body() != null) {
                    if(response.body().getSuccess().equals("true")) {
                        Log.d("notification_response", response.body().toString());
                    notification_response = response.body();
                    list.clear();
                    for(int i=0;i<response.body().getResultData().length;i++) {
                        list.add(new Notification_Model(response.body().getResultData()[i].getTitle(),response.body().getResultData()[i].getAddedOn(),response.body().getResultData()[i].getType(),response.body().getResultData()[i].getDetails(),response.body().getResultData()[i].getNotificationID()));
                        System.out.println(list.get(i).getNotificationID());
                    }
                    Collections.sort(list);
                    for(int i=0;i<list.size();i++){
                        System.out.println(list.get(i).getNotificationID());
                    }
                    RecyclerViewAdapterNoti adapterWeekly = new RecyclerViewAdapterNoti(list,getFragmentManager(),shared,callBack);
                    recList.setAdapter(adapterWeekly);
                   dialog.dismiss();
                }
                else
                {
                    new MaterialDialog.Builder(getActivity()).title("Error")
                            .content(response.body().getMessage()).positiveText("Try Again").show();
                  dialog.dismiss();
                }
                }
                else
                {
                    new MaterialDialog.Builder(getActivity()).title("Error")
                            .content("Some Error Occured").positiveText("Try Again").show();
                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(Call<Notification_Response> call, Throwable t) {
                StaticFunction.NoConnectionDialog(getActivity());
               dialog.dismiss();
            }
        });
        /*ItemClickSupport.addTo(recList)
                .setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
                    @Override
                    public void onItemClicked(RecyclerView recyclerView, int position, View v) {

                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        Fragment_NotificationDetails updateTime = new Fragment_NotificationDetails();
                        Bundle bundle= new Bundle();
                        bundle.putString("Title",notification_response.getResultData()[position].getTitle());
                        bundle.putString("Details",notification_response.getResultData()[position].getDetails());
                        bundle.putString("Added",notification_response.getResultData()[position].getAddedOn());
                        updateTime.setArguments(bundle);
                        ft.replace(R.id.container_fragment, updateTime);
                        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                });*/
        return view;
    }

    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Notification");
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(false);
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(true);

    }

    public interface OnNotificationOpenListener {
        public void UpdateUI();
    }
}
