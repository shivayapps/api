//package com.awqatesalah.awqaat_e_salaah.Search.Fragments;
//
//import android.app.*;
//import android.database.Cursor;
//import android.os.Build;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v7.app.AppCompatActivity;
//import android.support.v7.widget.AppCompatCheckBox;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.FrameLayout;
//import android.widget.TableRow;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.awqatesalah.awqaat_e_salaah.DBHelper;
//import com.awqatesalah.awqaat_e_salaah.MainActivity;
//import com.awqatesalah.awqaat_e_salaah.R;
//import com.google.android.gms.maps.CameraUpdateFactory;
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.MapFragment;
//import com.google.android.gms.maps.OnMapReadyCallback;
//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.maps.model.MarkerOptions;
//
//import mehdi.sakout.fancybuttons.FancyButton;
//
///**
// * Created by Abubakker on 8/25/2016.
// */
//public class Fragment_CompleteMasjidDetails extends Fragment {
//    private TextView fajredit, zuhredit, asredit, maghribedit, ishaedit, jummahedit;
//    private FancyButton changetime;
//    private TextView masjidname, address, lastUpdated;
//    private AppCompatCheckBox favourites;
//    private DBHelper dbHelper;
//    private GoogleMap map;
//    private MapFragment mapF;
//    private TableRow row;
//    private View view;
//    private FrameLayout frame;
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        if(view==null) {
//            view = inflater.inflate(R.layout.all_details_masjid, container, false);
//        }
//        getToolbar();
//        fajredit = (TextView) view.findViewById(R.id.Fajr);
//        zuhredit = (TextView) view.findViewById(R.id.Zuhr);
//        asredit = (TextView) view.findViewById(R.id.Asr);
//        maghribedit = (TextView) view.findViewById(R.id.Maghrib);
//        ishaedit = (TextView) view.findViewById(R.id.Isha);
//        jummahedit = (TextView) view.findViewById(R.id.Jumuah);
//        changetime = (FancyButton) view.findViewById(R.id.change_time);
//        masjidname = (TextView) view.findViewById(R.id.Masjid_Title);
//        address = (TextView) view.findViewById(R.id.Masjid_Address);
//        lastUpdated = (TextView) view.findViewById(R.id.LastUpdated);
//        favourites = (AppCompatCheckBox) view.findViewById(R.id.addtofavourites);
//        dbHelper = new DBHelper(getActivity());
//        row = (TableRow) view.findViewById(R.id.row);
//        frame = (FrameLayout) view.findViewById(R.id.frame);
//
//
//
//        if(getValue("latitude")!="" && getValue("longitude")!="") {
//            final Double latitude = Double.parseDouble(getValue("latitude"));
//            final Double longitude = Double.parseDouble(getValue("longitude"));
//
//                mapF = getMapFragment();
//            if(mapF!=null) {
//                frame.setVisibility(View.VISIBLE);
//                mapF.getMapAsync(new OnMapReadyCallback() {
//                    @Override
//                    public void onMapReady(final GoogleMap googleMap) {
//                        map = googleMap;
//                        MarkerOptions markerOptions = new MarkerOptions();
//
//                        Log.d("value", getValue("latitude"));
//                        Log.d("value", getValue("longitude"));
//                        // Setting the position for the marker
//
//                        markerOptions.position(new LatLng(latitude, longitude)).title(getValue("MasjidName"));
//
//                        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 12.0f));
//
//                        // Placing a marker on the touched position
//                        googleMap.addMarker(markerOptions);
//
//                        // googleMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(getValue("latitude")),(Double.parseDouble(getValue("longitude"))))).title(getValue("MasjidName")));
//
//                    }
//                });
//            }
//        }
//
//        masjidname.setText(getValue("MasjidName").toString().toUpperCase());
//        address.setText(getValue("Address"));
//       lastUpdated.setText("Last Updated On : " + getValue("LastUpdated"));
//        fajredit.setText(getValue("Fajr"));
//        zuhredit.setText(getValue("Zuhr"));
//        asredit.setText(getValue("Asr"));
//        maghribedit.setText(getValue("Maghrib"));
//        ishaedit.setText(getValue("Isha"));
//        if (getValue("Jumuah").equals("") || getValue("Jumuah").equals("-") ) {
//            row.setVisibility(View.GONE);
//        }
//        else
//        {
//            jummahedit.setText(getValue("Jumuah"));
//        }
//        dbHelper.openDB();
//        Cursor cursor = dbHelper.getFavouritesFlag(Integer.parseInt(getValue("Masjid_ID")));
//        if(cursor.getCount()>0)
//        {
//            favourites.setChecked(true);
//        }
//
//        favourites.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (favourites.isChecked()) {
//                    long resultInsert = dbHelper.insert(Integer.parseInt(getValue("Masjid_ID")),Integer.parseInt(getValue("Username")),getValue("MasjidName"),getValue("Address"),
//                            getValue("Fajr"), getValue("Zuhr"),  getValue("Asr"), getValue("Maghrib"),getValue("Isha"), getValue("Jumuah"), getValue("LastUpdated"));
//                    if(resultInsert == -1){
//                        Toast.makeText(getActivity(), "Some error occurred while inserting", Toast.LENGTH_SHORT).show();
//                    } else {
//                        Toast.makeText(getActivity(), "Added to Favourites", Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    dbHelper.delete(getValue("Masjid_ID"));
//                    Toast.makeText(getActivity(), "Removed From Favourites", Toast.LENGTH_SHORT).show();
//
//                }
//            }
//        });
//
//        changetime.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                FragmentManager fm = getFragmentManager();
//                FragmentTransaction ft = fm.beginTransaction();
//                Fragment_Dialog updateTime = new Fragment_Dialog();
//                Bundle bundle= new Bundle();
//                bundle.putString("MasjidName",getValue("MasjidName"));
//                bundle.putString("Fajr",getValue("Fajr"));
//                bundle.putString("Zuhr",getValue("Zuhr"));
//                bundle.putString("Asr",getValue("Asr"));
//                bundle.putString("Maghrib",getValue("Maghrib"));
//                bundle.putString("Isha",getValue("Isha"));
//                bundle.putString("Jumuah",getValue("Jumuah"));
//                bundle.putString("Masjid_ID",getValue("Masjid_ID"));
//                updateTime.setArguments(bundle);
//                ft.replace(R.id.container_fragment, updateTime);
//                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
//                ft.addToBackStack(null);
//                ft.commit();
//
//            }
//        });
//
//        return view;
//    }
//
//    private void getToolbar() {
//        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Masjid Details");
//        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
//        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//    }
//
//    private String getValue(String key) {
//        return getArguments().getString(key, "-");
//    }
//    private MapFragment getMapFragment() {
//        FragmentManager fm = null;
//
//        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
//            fm = getFragmentManager();
//        } else {
//            fm = getChildFragmentManager();
//        }
//
//        return (MapFragment) fm.findFragmentById(R.id.map);
//    }
//
//
//
//    @Override
//    public void onStart() {
//        super.onStart();
//        dbHelper.openDB();
//    }
//
//    @Override
//    public void onStop() {
//        super.onStop();
//        dbHelper.closeDB();
//    }
//    @Override
//    public void onDestroyView() {
//        super.onDestroyView();
//        MapFragment f = (MapFragment) getFragmentManager()
//                .findFragmentById(R.id.map);
//        if (f != null)
//
//            getFragmentManager().beginTransaction().remove(f).commit();
//    }
//}