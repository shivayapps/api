package com.awqatesalah.awqaat_e_salaah;

/**
 * Created by Abubakker on 12/7/2016.
 */
public class Fragment_ClassName {

    public static String ScreenName(String name)
    {
        String screenName;
        switch (name)
        {
            //Search

            case "Fragment_MasjidSearch":
                screenName="Android/Masjid/Search";
                return screenName;

            case "Fragment_MasjidList":
                screenName="Android/Masjid/CompleteList";
                return screenName;

            case "Fragment_New_Dialog":
                screenName="Android/Masjid/DialogDetail";
                return screenName;

            //notification

            case "Fragment_Notification":
                screenName="Android/Notification/List";
                return screenName;

            case "Fragment_NotificationDetails":
                screenName="Android/Notification/Details";
                return screenName;


            //Favourites
            case "Fragment_Fravourites":
                screenName="Android/Favourites";
                return screenName;

            //Contact_Us
            case "Fragment_ContactUs":
                screenName="Android/ContactUs";
                return screenName;

            case "Help":
                screenName="Android/Help";
                return screenName;

            //Bayaan
            case "Fragment_UpdateJumuah":
                screenName="Android/Bayaan/Jumuah_Update";
                return screenName;

            case "Fragment_UpdateOther":
                screenName="Android/Bayaan/Other_Update";
                return screenName;

            case "Fragment_Weekly":
                screenName="Android/Bayaan/Weekly_List";
                return screenName;

            case "Fragment_Other":
                screenName="Android/Bayaan/Other_List";
                return screenName;

            case "Fragment_Jumuah":
                screenName="Android/Bayaan/Jumuah_List";
                return screenName;


            //Admin

            case "Fragment_AddMasjid":
                screenName="Android/Admin/Add_New_Masjid";
                return screenName;

            case "Fragment_Admin":
                screenName="Android/Admin/Main";
                return screenName;

            case "Fragment_ChangePassword":
                screenName="Android/Admin/ChangePassword";
                return screenName;

            case "Fragment_Chat":
                screenName="Android/Admin/Chat";
                return screenName;

            case "Fragment_GetAllMasjidsByAdmin":
                screenName="Android/Admin/Get_Masjid_By_Admin_List";
                return screenName;

            case "Fragment_Login":
                screenName="Android/Admin/Login";
                return screenName;

            case "Fragment_Profile":
                screenName="Android/Admin/Profile";
                return screenName;

            case "Fragment_Register":
                screenName="Android/Admin/Register_First_Page";
                return screenName;

            case "Fragment_Register_Final":
                screenName="Android/Admin/Register_Final_Page";
                return screenName;

            case "Fragment_UpdateTime":
                screenName="Android/Admin/Update_Time";
                return screenName;

            //

            case "Fragment_FeedBack":
                screenName="Android/Other/Feedback";
                return screenName;

            case "Fragment_AdminRequest":
                screenName="Android/Other/AdminRequest";
                return screenName;


        }
        return "";
    }

}
