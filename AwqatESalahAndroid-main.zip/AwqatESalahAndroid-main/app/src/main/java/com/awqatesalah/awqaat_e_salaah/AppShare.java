package com.awqatesalah.awqaat_e_salaah;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;


/**
 * Created by root on 29/12/16.
 */
public class AppShare {

    SharedPreferences getPrefs;
    private Context context;
    public AppShare(Context context,SharedPreferences getPrefs) {
        this.context = context;
        this.getPrefs= getPrefs;
    }

    @SuppressLint("NewApi")
    static AlertDialog.Builder getDialogBuilder(Context context) {
        return new AlertDialog.Builder(context);

    }

    public  void InitializeCount(){
        int add = getPrefs.getInt("count",0)+1;
        getPrefs.edit().putInt("count",add).apply();
    }

    public void setLaunchDialog(){
        //Set Count For Each Launch
        int count = getPrefs.getInt("count",0);

        //Check first if sharedialog is allowed to show

        if(getPrefs.getString("sharedialogshow","yes").equals("yes")) {
            if ((count % 7 )== 0 && count > 6) {
               /* new MaterialDialog.Builder(context).title("App Share")
                        .content("Please Share this Application with more people and Become a part of this Noble Cause").positiveText("Share now")
                        .stackingBehavior(StackingBehavior.ADAPTIVE)
                        .negativeText("Never").neutralText("later")
                        .onNegative(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                getPrefs.edit().putString("sharedialogshow", "no").apply();
                            }
                        })
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                getPrefs.edit().putString("sharedialogshow", "no").apply();
                            }
                        })
                        .onNeutral(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                            }
                        }).show();*/
                AlertDialog.Builder builder = getDialogBuilder(context);
                builder.setTitle("App Share");
                builder.setMessage("Please Share This Application and be a part of good cause");
                builder.setCancelable(true);
                builder.setPositiveButton("Share now", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getPrefs.edit().putString("sharedialogshow", "no").apply();
                        Intent sendIntent = new Intent();
                        sendIntent.setAction(Intent.ACTION_SEND);
                        sendIntent.putExtra(Intent.EXTRA_TEXT,
                                "AWQAT E SALAH \nWorld's 1st application to show the jamaat time of Masjids , Now For whole Gujarat(India) and New Zealand. \nBe a part of good cause." +
                                        "Download it from here : https://play.google.com/store/apps/details?id=com.awqatesalah.awqaat_e_salaah");
                        sendIntent.setType("text/plain");
                        context.startActivity(sendIntent);
                    }
                });
                builder.setNegativeButton("Never", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getPrefs.edit().putString("sharedialogshow", "no").apply();

                    }
                });
                builder.setNeutralButton("Remind Later", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        InitializeCount();
                    }
                });
                builder.create();
                builder.show();

            }
        }
    }

}
