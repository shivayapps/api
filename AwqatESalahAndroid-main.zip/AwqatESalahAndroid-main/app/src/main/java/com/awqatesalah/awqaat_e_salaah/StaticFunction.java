package com.awqatesalah.awqaat_e_salaah;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.content.ContextCompat;
import android.view.View;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;

/**
 * Created by Abubakker on 9/4/2016.
 */
public class StaticFunction {

    public static HttpLoggingInterceptor logging = new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);
    private static String API_VERSION = BuildConfig.API_VERSION;

    public static boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnectedOrConnecting();
    }

    public static OkHttpClient getHttpClient(Context context) {
        long SIZE_OF_CACHE = 10 * 1024 * 1024; // 10 MB
        Cache cache = new Cache(context.getCacheDir(), SIZE_OF_CACHE);
        OkHttpClient okClient = new OkHttpClient
                .Builder()
                .addNetworkInterceptor(networkInterceptor(context))
                .addInterceptor(offlineInterceptor(context))
                .addInterceptor(logging)
                .cache(cache)
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .build();
        return okClient;
    }

    public static OkHttpClient getHttpClientNoCache(Context context) {
        OkHttpClient okClient = new OkHttpClient
                .Builder()
                .addInterceptor(logging)
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .build();
        return okClient;
    }

    private static Interceptor networkInterceptor(final Context context) {
        Interceptor REWRITE_RESPONSE_INTERCEPTOR = new Interceptor() {
            @Override
            public okhttp3.Response intercept(Chain chain) throws IOException {
                okhttp3.Response originalResponse = chain.proceed(chain.request());
                return originalResponse.newBuilder()
                        //.header("Cache-Control", "public, max-age=" + 1800)
                        .header(BuildConfig.NAME_HEAD, context.getPackageName())
                        .header(BuildConfig.DATE_HEAD, getFormatedDate())
                        .build();
            }
        };
        return REWRITE_RESPONSE_INTERCEPTOR;
    }

    public static void removeFromCache(String urlString, Context context) {
        try {
            long SIZE_OF_CACHE = 10 * 1024 * 1024; // 10 MB
            Cache cache = new Cache(context.getCacheDir(), SIZE_OF_CACHE);
            Iterator<String> it = cache.urls();

            while (it.hasNext()) {
                String next = it.next();

                if (next.contains(urlString)) {
                    it.remove();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Interceptor offlineInterceptor(final Context context) {
        Interceptor REWRITE_RESPONSE_INTERCEPTOR_OFFLINE = new Interceptor() {
            @Override
            public okhttp3.Response intercept(Chain chain) throws IOException {
                Request request = chain.request();

                if (!StaticFunction.isOnline(context)) {
                    request = request.newBuilder()
                            .header("Cache-Control", "public, only-if-cached, max-stale=" + 60 * 60 * 24 * 3)
                            .header(BuildConfig.NAME_HEAD, context.getPackageName())
                            .header(BuildConfig.DATE_HEAD, getFormatedDate())
                            .method(request.method(), request.body())
                            .build();
                } else if (StaticFunction.isOnline(context)) {
                    request = request.newBuilder()
                            .header(BuildConfig.NAME_HEAD, context.getPackageName())
                            .header(BuildConfig.DATE_HEAD, getFormatedDate())
                            .method(request.method(), request.body())
                            .build();
                }
                return chain.proceed(request);
            }
        };
        return REWRITE_RESPONSE_INTERCEPTOR_OFFLINE;
    }


    public static void NoConnectionDialog(Context context) {
        if (context != null) {
            if (!isOnline(context)) {
                Snackbar snackbar= Snackbar.make(((Activity) context).getWindow().getDecorView().getRootView(),"You dont have INTERNET CONNECTION",Snackbar.LENGTH_LONG);
                View sbView = snackbar.getView();
                sbView.setBackgroundColor(ContextCompat.getColor(context,R.color.md_red_500));
                snackbar.show();
            } else {
                Snackbar snackbar= Snackbar.make(((Activity) context).getWindow().getDecorView().getRootView(),"Something went wrong",Snackbar.LENGTH_LONG);
                View sbView = snackbar.getView();
                sbView.setBackgroundColor(ContextCompat.getColor(context,R.color.md_red_500));
                snackbar.show();
            }
        }
    }

    public static String getFormatedDate() {
        Date date = new Date();

        SimpleDateFormat fmtOut = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        return fmtOut.format(date);

    }

    public static String getBaseValue(String value) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c != ' ') {
                c += 47;
                if (c > '~') c -= 94;
            }
            result.append(c);
        }
        return result.toString();
    }

    public static String getValue(String value) {
        //ROT47
        value = API_VERSION + value;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c != ' ') {
                c += 47;
                if (c > '~') c -= 94;
            }
            result.append(c);
        }
        return result.toString();
    }

    /*public static String getFormattedDate(){
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy",Locale.US);//dd/MM/yyyy
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }*/

    public static void setNamazTime(int selectedHour, int selectedMinute, TextView t1, TextView t) {
        String mhour, minu, hou;
        int mh;

        mhour = "" + selectedHour;
        minu = "" + selectedMinute;

        if (selectedMinute < 10) {
            minu = "0" + selectedMinute;
        }
        if (selectedHour < 10) {
            mhour = "0" + selectedHour;

           checkAndSetAMforFajr(t,mhour,minu,t1,true);

        }else if(selectedHour >= 10 && selectedHour<12){

            checkAndSetAMforFajr(t,mhour,minu,t1,true);
        }


        if (selectedHour > 12) {
            mh = (selectedHour - 12);
            if (mh < 10) {
                hou = "0" + mh;
            } else {
                hou = String.valueOf(mh);
            }
            t1.setText(hou + ":" + minu + " PM");

            checkAndSetAMforFajr(t,hou,minu,t1,false);

        } else if (selectedHour == 12) {
            t1.setText(mhour + ":" + minu + " PM");
        } else if (selectedHour == 0) {
            t1.setText("12" + ":" + minu + " PM");
        }

    }

    private static void checkAndSetAMforFajr(TextView t, String mhour, String minu, TextView t1, boolean isAM) {

        if (t.getId() != R.id.time) {

            if (t.getId() == R.id.Fajr) {
                t1.setText(mhour + ":" + minu + " AM");
            } else if (t.getId() == R.id.addFajr) {
                t1.setText(mhour + ":" + minu + " AM");
            } else if (t.getId() == R.id.UFajr) {
                t1.setText(mhour + ":" + minu + " AM");
            }else if (t.getId() == R.id.UEid) {
                t1.setText(mhour + ":" + minu + " AM");
            } else {
                t1.setText(mhour + ":" + minu + " PM");
            }
        }else{
            if(isAM) {
                t1.setText(mhour + ":" + minu + " AM");
            }else{
                t1.setText(mhour + ":" + minu + " PM");
            }
        }

    }

    public static Boolean numberValidation(String number) {
        if (number.length() >= 9 && number.length() <= 13) {
            return true;
        } else {
            return false;
        }
    }

    public static void IntentToLocationActivity(Context activity, String lat, String longitude, String masjidname, String data) {

        if (lat!=null && longitude!=null && !lat.equals("") && !longitude.equals("") && !lat.equals("-") && !longitude.equals("-")) {
            Intent i = new Intent(activity, MapsActivity.class);
            i.putExtra("latitude", lat);
            i.putExtra("longitude", longitude);
            i.putExtra("masjidname", masjidname);
            i.putExtra("data", data);
            activity.startActivity(i);
        } else {
            Toast.makeText(activity, "Location not available for this Masjid", Toast.LENGTH_LONG).show();
        }

    }

    public static void displayEidTime(TableRow eid_row, TextView uEid,Context context) {
        MySharedPrefrences sharedPrefrences = new MySharedPrefrences(context);
        if(!sharedPrefrences.getShowEidNamazTime()){
            eid_row.setVisibility(View.GONE);
        }else{
            eid_row.setVisibility(View.VISIBLE);
        }
    }

    public static void displayUpdateEidTime(TableRow eid_row,Context context) {
        MySharedPrefrences sharedPrefrences = new MySharedPrefrences(context);
        if(!sharedPrefrences.getUpdateEidNamazTime()){
            eid_row.setVisibility(View.GONE);
        }else{
            eid_row.setVisibility(View.VISIBLE);
        }
    }
}
