package com.awqatesalah.awqaat_e_salaah;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.CacheControl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.awqatesalah.awqaat_e_salaah.StaticFunction.logging;


/**
 * Created by ubuntu on 19/3/17.
 */

public class RetroFitServiceGenerator {

    private static Context context;
    private Retrofit.Builder builder =
            new Retrofit.Builder()
                    .baseUrl(StaticFunction.getBaseValue(BuildConfig.BASE_URL))
                    //.baseUrl("http://demo.awqatesalah.com")
                    .addConverterFactory(GsonConverterFactory.create());
    private Retrofit retrofit = builder.build();
    private OkHttpClient.Builder httpClient =
            new OkHttpClient.Builder();

    public RetroFitServiceGenerator(Context context) {
        this.context = context;
    }

    public <S> S createService(
            Class<S> serviceClass) {
        builder.client(StaticFunction.getHttpClient(context));
        retrofit = builder.build();
        return retrofit.create(serviceClass);
    }

    public <S> S createServiceNoCache(
            Class<S> serviceClass) {
        builder.client(StaticFunction.getHttpClientNoCache(context));
        retrofit = builder.build();
        return retrofit.create(serviceClass);
    }

    public void backgroundThreadShortToast(final Context context,
                                           final String msg) {
        if (context != null && msg != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {

                @Override
                public void run() {
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();

                }
            });
        }
    }


    public Interceptor provideErrorInterceptor() {
        return new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Response response = chain.proceed(chain.request());

                if (!response.isSuccessful()) {

                    backgroundThreadShortToast(context, "Status : " + response.code() + " Msg: " + response.message());


                } else {

                }


                return response;
            }
        };
    }



    public Interceptor provideOfflineCacheInterceptor(final Integer minutes) {
        return new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request request = chain.request();


//                if ( !AdeptAndroid.hasNetwork() )
//                {
                CacheControl cacheControl = new CacheControl.Builder()
                        .maxStale(minutes, TimeUnit.MINUTES)
                        .build();

                request = request.newBuilder()
                        .cacheControl(cacheControl)
                        .build();
//                }

                return chain.proceed(request);
            }
        };
    }

}