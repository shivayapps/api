package com.awqatesalah.awqaat_e_salaah.Admin.Fragments;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Admin.Models.Register_Response;
import com.awqatesalah.awqaat_e_salaah.GATrackingFragment;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.MainActivity;
import com.awqatesalah.awqaat_e_salaah.MySharedPrefrences;
import com.awqatesalah.awqaat_e_salaah.R;
import com.awqatesalah.awqaat_e_salaah.RetroFitServiceGenerator;
import com.awqatesalah.awqaat_e_salaah.StaticFunction;
import com.rengwuxian.materialedittext.MaterialEditText;

import dmax.dialog.SpotsDialog;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Abubakker on 8/24/2016.
 */
public class Fragment_ChangePassword extends GATrackingFragment {

    private MaterialEditText oldpass,newpass,confirmpass;
    private FancyButton changepass;
    private String masjidAdminID;
    private SpotsDialog dialog;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.admin_change_password,container,false);
        oldpass = (MaterialEditText) view.findViewById(R.id.old_password);
        newpass = (MaterialEditText) view.findViewById(R.id.new_password);
        confirmpass = (MaterialEditText) view.findViewById(R.id.confirm_password);
        changepass = (FancyButton) view.findViewById(R.id.CHANGE_PASSWORD);

        getToolbar();
        MySharedPrefrences shared = MySharedPrefrences.getInstance(getActivity());
        masjidAdminID=((shared.getData("MasjidAdminID").toString()));
        dialog  = new SpotsDialog(getActivity(),R.style.main);
        dialog.setCancelable(false);

        changepass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!oldpass.getText().toString().matches("") && !newpass.getText().toString().matches("") && newpass.getText().length()>5 && !confirmpass.getText().toString().matches("")) {

                    if(newpass.getText().toString().matches(confirmpass.getText().toString())) {
                        dialog.show();
                        CallRetroApi service = new RetroFitServiceGenerator(getActivity()).createServiceNoCache(CallRetroApi.class);
                        Call<Register_Response> call = service.changePassword(StaticFunction.getValue("r92?86!2DDH@C5"), masjidAdminID, getValue(oldpass), getValue(newpass));
                        call.enqueue(new Callback<Register_Response>() {
                            @Override
                            public void onResponse(Call<Register_Response> call, Response<Register_Response> response) {
                                if (response.body().getSuccess().equals("true")) {
                                    Log.d("chapassword_response", response.body().toString());

                                    new MaterialDialog.Builder(getActivity())
                                            .content(response.body().getMessage()).positiveText("Done").show();
                                    dialog.dismiss();
                                    View view = getActivity().getCurrentFocus();
                                    if (view != null) {
                                        InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                                    }
                                    getFragmentManager().popBackStack();
                                } else {
                                    dialog.dismiss();
                                    new MaterialDialog.Builder(getActivity()).title("Error")
                                            .content(response.body().getMessage()).positiveText("Try Again").show();
                                }
                            }

                            @Override
                            public void onFailure(Call<Register_Response> call, Throwable t) {
                                StaticFunction.NoConnectionDialog(getActivity());
                                dialog.dismiss();
                            }
                        });
                    }
                    else
                    {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content("Password does not Match").positiveText("Try Again").show();
                    }
                }
                else
                {
                    if(oldpass.getText().toString().matches(""))
                    {
                        oldpass.setError("Password Cannot be Empty");
                    }
                    if(newpass.getText().length()<4)
                    {
                        newpass.setError("Password should be atleast 6 character");
                    }
                }
            }


        });


        return view;
    }

    private String getValue(EditText name) {
        return name.getText().toString().trim();
    }
    private String getValue(String key)
    {
        return getArguments().getString(key,"-");
    }
    private void getToolbar() {
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Change Password");
        MainActivity.result.getActionBarDrawerToggle().setDrawerIndicatorEnabled(false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


}
