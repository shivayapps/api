package com.awqatesalah.awqaat_e_salaah;

import android.content.Context;
import android.content.SharedPreferences;

import com.awqatesalah.awqaat_e_salaah.Admin.Models.GetAllAreas_Response;
import com.awqatesalah.awqaat_e_salaah.Search.Models.LessDetailedListSorting_Model;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import retrofit2.Response;

/**
 * Created by Abubakker on 8/23/2016.
 */
public class MySharedPrefrences {
    private static MySharedPrefrences yourPreference;
    private SharedPreferences sharedPreferences;

    public MySharedPrefrences(Context context) {
        sharedPreferences = context.getSharedPreferences("AwqatESalah", Context.MODE_PRIVATE);
    }

    public static MySharedPrefrences getInstance(Context context) {
        if (yourPreference == null) {
            yourPreference = new MySharedPrefrences(context);
        }
        return yourPreference;
    }


    public void setisRegistrationComplete(Boolean value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putBoolean("registration_complete", value);
        prefsEditor.commit();
    }

    public Boolean isRegistrationComplete() {
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean("registration_complete", true);
        }
        return true;
    }


    public void saveData(String key,String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor .putString(key, value);
        prefsEditor.commit();
    }

    public void deleteData(String key,String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor .remove(key);
        prefsEditor.commit();
    }

    public String getData(String key) {
        if (sharedPreferences!= null) {
            return sharedPreferences.getString(key,"null");
        }
        return "";
    }

    public void ClearAllData()
    {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.clear();
        prefsEditor.commit();
    }

    public int getNotificationCount() {
        if (sharedPreferences!= null) {
            return Integer.parseInt(sharedPreferences.getString("NotificationCount","0"));
        }
        return 0;
    }

    public void saveNotificationCount(int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor .putString("NotificationCount", String.valueOf(value));
        prefsEditor.commit();
    }


    public int getMessageCount() {
        if (sharedPreferences!= null) {
            return Integer.parseInt(sharedPreferences.getString("MessageCount","0"));
        }
        return 0;
    }

    public void saveMessageCount(int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor .putString("MessageCount", String.valueOf(value));
        prefsEditor.commit();
    }


    public void saveUnreadNotificationIds(String value) {
        Set<String> set = new HashSet<String>();
        if(getUnreadNotificationIds().size()>0) {
            set.addAll(getUnreadNotificationIds());
        }
        set.add(value);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor .putStringSet("UnreadNotificationIds", set);
        prefsEditor.commit();
    }

    public ArrayList<String> getUnreadNotificationIds(){
        ArrayList<String> list = new ArrayList<>();
        if (sharedPreferences!= null && sharedPreferences.getStringSet("UnreadNotificationIds",null)!=null) {
            list.addAll(sharedPreferences.getStringSet("UnreadNotificationIds",null));
            return list;
        }
        return list;
    }

    public void saveAllCities(GetAllAreas_Response cityResponse){
        Gson gson = new Gson();
        String cityResponseJson = gson.toJson(cityResponse);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("all_cities",cityResponseJson);
        prefsEditor.commit();
    }

    public GetAllAreas_Response getAllCities(){
        Gson gson = new Gson();
        if (sharedPreferences != null) {
            String jsonString = sharedPreferences.getString("all_cities",null);
            if(jsonString!=null){
                Type gsonType = new TypeToken<GetAllAreas_Response>(){}.getType();
                return gson.fromJson(jsonString,gsonType);
            }
            else {
                return null;
            }
        }
        return null;
    }


    public void deleteReadNotificationId(ArrayList<String> value){
        Set<String> set = new HashSet<String>();
        set.addAll(value);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor .putStringSet("UnreadNotificationIds", set);
        prefsEditor.commit();
    }

    public void saveState(int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putInt("StateID", value);
        prefsEditor.commit();
    }

    public void saveCountry(int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putInt("CountryID", value);
        prefsEditor.commit();
    }

    public int getCountry() {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt("CountryID", -1);
        }
        return -1;
    }

    public void saveSchoolType(int value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putInt("schoolType", value);
        prefsEditor.commit();
    }

    public int getSchoolType() {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt("schoolType", 1);
        }
        return -1;
    }

    public int getState() {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt("StateID", -1);
        }
        return -1;
    }

    public void setFavouritesAndLocationTutorialShown() {
        if (sharedPreferences != null) {
            sharedPreferences.edit().putBoolean("fav_loc_tut",true).apply();
        }
    }

    public Boolean getFavouritesAndLocationTutorialShown(){
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean("fav_loc_tut",false);
        }

        return true;
    }

    public void saveAreaID(String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("area_id", value);
        prefsEditor.commit();
    }

    public String getAreaID() {
        if (sharedPreferences != null) {
            return sharedPreferences.getString("area_id", "0");
        }
        return "";
    }

    public void saveHelp(String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("help_text", value);
        prefsEditor.commit();
    }

    public String getHelp() {
        if (sharedPreferences != null) {
            return sharedPreferences.getString("help_text", "");
        }
        return "";
    }

    public void saveContactUs(String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("contact_us", value);
        prefsEditor.commit();
    }

    public String getContactUs() {
        if (sharedPreferences != null) {
            return sharedPreferences.getString("contact_us", "");
        }
        return "";
    }

    public void saveShareApp(String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("share_app", value);
        prefsEditor.commit();
    }

    public String getShareApp() {
        if (sharedPreferences != null) {
            return sharedPreferences.getString("share_app", "");
        }
        return "";
    }

    public void saveAdminChatWhatsappNumber(String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("admin_chat_mobile", value);
        prefsEditor.commit();
    }

    public String getAdminChatWhatsappNumber() {
        if (sharedPreferences != null) {
            return sharedPreferences.getString("admin_chat_mobile", "");
        }
        return "";
    }

    public void setShowEidNamazTime(String value) {
        if (sharedPreferences != null) {
            if(value.toLowerCase().equals("yes")){
                sharedPreferences.edit().putBoolean("eid_name_time",true).apply();
            }else{
                sharedPreferences.edit().putBoolean("eid_name_time",false).apply();

            }
        }
    }

    public Boolean getShowEidNamazTime(){
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean("eid_name_time",false);
        }

        return true;
    }


    public void setUpdateEidNamazTime(String value) {
        if (sharedPreferences != null) {
            if(value.toLowerCase().equals("yes")){
                sharedPreferences.edit().putBoolean("update_eid_name_time",true).apply();
            }else{
                sharedPreferences.edit().putBoolean("update_eid_name_time",false).apply();

            }
        }
    }

    public Boolean getUpdateEidNamazTime(){
        if (sharedPreferences != null) {
            return sharedPreferences.getBoolean("update_eid_name_time",false);
        }

        return true;
    }


}


  /*  /// call it
    YourPreference yourPrefrence = YourPreference.getInstance(context);
yourPreference.saveData(YOUR_KEY,YOUR_VALUE);

        String value = yourPreference.getData(YOUR_KEY);




        }
*/