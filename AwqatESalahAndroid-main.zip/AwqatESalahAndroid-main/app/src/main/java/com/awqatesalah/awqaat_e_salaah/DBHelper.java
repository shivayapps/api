package com.awqatesalah.awqaat_e_salaah;

/**
 * Created by Abubakker on 8/25/2016.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by root on 23/8/16.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String DBNAME = "favuorites.db";
    private static final int VERSION = 6;
    //This table is discarded after favourites is moved to server
    public static final String FAVOURITE = "favourite";
    //We will use this table for saving local favourites now
    public static final String FAVOURITE_SERVER = "favourite_server";
    public static final String TABLE_NAME_SUGGESTION = "suggestion";
    public static final String TABLE_NAME_UPDATE = "updateoffline";
    public static final String MASJID_ID = "masjid_id";
    public static final String ID = "_id";
    public static final String ADMIN_USER_ID = "usernameid";
    public static final String SUGGESTER_NAME = "suggestername";
    public static final String SUGGESTER_NUMBER = "suggesternumber";
    public static final String MASJID_NAME = "masjidname";
    public static final String ADDRESS = "address";
    public static final String FAJR = "fajr";
    public static final String ZUHR = "zuhr";
    public static final String ASR = "asr";
    public static final String MAGHRIB = "maghrib";
    public static final String ISHA = "isha";
    public static final String JUMUAH = "jumuah";
    public static final String EID = "eid";
    public static final String STATUS = "status";
    public static final String LASTUPDATED = "lastupdated";

    public static String queryTable;
    public static String queryTable2;
    public static String queryTable3;
    public static String queryTableFav;
    private SQLiteDatabase myDB;



    public DBHelper(Context context) {
        super(context, DBNAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        queryTable = "CREATE TABLE IF NOT EXISTS " + FAVOURITE +
                " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ADMIN_USER_ID + " INTEGER NOT NULL, " +
                MASJID_NAME + " TEXT NOT NULL, " +
                ADDRESS + " TEXT NOT NULL, " +
                FAJR + " TEXT NOT NULL, " +
                ZUHR + " TEXT NOT NULL, " +
                ASR + " TEXT NOT NULL, " +
                MAGHRIB + " TEXT NOT NULL, " +
                ISHA + " TEXT NOT NULL, " +
                EID + " TEXT NOT NULL DEFAULT '', " +
                JUMUAH + " TEXT NOT NULL, " +
                LASTUPDATED + " TEXT NOT NULL " +
                ")";

        db.execSQL(queryTable);

        queryTableFav = "CREATE TABLE IF NOT EXISTS " + FAVOURITE_SERVER +
                " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ADMIN_USER_ID + " INTEGER NOT NULL, " +
                MASJID_NAME + " TEXT NOT NULL, " +
                ADDRESS + " TEXT NOT NULL, " +
                FAJR + " TEXT NOT NULL, " +
                ZUHR + " TEXT NOT NULL, " +
                ASR + " TEXT NOT NULL, " +
                MAGHRIB + " TEXT NOT NULL, " +
                ISHA + " TEXT NOT NULL, " +
                EID + " TEXT NOT NULL DEFAULT '', " +
                JUMUAH + " TEXT NOT NULL, " +
                LASTUPDATED + " TEXT NOT NULL " +
                ")";

        db.execSQL(queryTableFav);

        queryTable2 = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME_SUGGESTION +
                " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                MASJID_ID + " INTEGER NOT NULL, " +
                SUGGESTER_NAME + " TEXT NOT NULL, " +
                SUGGESTER_NUMBER + " TEXT NOT NULL, " +
                FAJR + " TEXT NOT NULL, " +
                ZUHR + " TEXT NOT NULL, " +
                ASR + " TEXT NOT NULL, " +
                MAGHRIB + " TEXT NOT NULL, " +
                ISHA + " TEXT NOT NULL, " +
                JUMUAH + " TEXT NOT NULL, " +
                EID + " TEXT NOT NULL DEFAULT '', " +
                STATUS + " TEXT NOT NULL, " +
                LASTUPDATED + " TEXT NOT NULL " +
                ")";

        db.execSQL(queryTable2);

        queryTable3 = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME_UPDATE +
                " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ADMIN_USER_ID + " INTEGER NOT NULL, " +
                MASJID_ID + " INTEGER NOT NULL, " +
                FAJR + " TEXT NOT NULL, " +
                ZUHR + " TEXT NOT NULL, " +
                ASR + " TEXT NOT NULL, " +
                MAGHRIB + " TEXT NOT NULL, " +
                ISHA + " TEXT NOT NULL, " +
                JUMUAH + " TEXT NOT NULL, " +
                EID + " TEXT NOT NULL DEFAULT '', " +
                STATUS + " TEXT NOT NULL, " +
                LASTUPDATED + " TEXT NOT NULL " +
                ")";

        db.execSQL(queryTable3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


        queryTableFav = "CREATE TABLE IF NOT EXISTS " + FAVOURITE_SERVER +
                " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ADMIN_USER_ID + " INTEGER NOT NULL, " +
                MASJID_NAME + " TEXT NOT NULL, " +
                ADDRESS + " TEXT NOT NULL, " +
                FAJR + " TEXT NOT NULL, " +
                ZUHR + " TEXT NOT NULL, " +
                ASR + " TEXT NOT NULL, " +
                MAGHRIB + " TEXT NOT NULL, " +
                ISHA + " TEXT NOT NULL, " +
                EID + " TEXT NOT NULL DEFAULT '', " +
                JUMUAH + " TEXT NOT NULL, " +
                LASTUPDATED + " TEXT NOT NULL " +
                ")";

        db.execSQL(queryTableFav);


        /*queryTable2 = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME_SUGGESTION +
                " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                MASJID_ID + " INTEGER NOT NULL, " +
                SUGGESTER_NAME + " TEXT NOT NULL, " +
                SUGGESTER_NUMBER + " TEXT NOT NULL, " +
                FAJR + " TEXT NOT NULL, " +
                ZUHR + " TEXT NOT NULL, " +
                ASR + " TEXT NOT NULL, " +
                MAGHRIB + " TEXT NOT NULL, " +
                ISHA + " TEXT NOT NULL, " +
                JUMUAH + " TEXT NOT NULL, " +
                STATUS + " TEXT NOT NULL, " +
                LASTUPDATED + " TEXT NOT NULL " +
                ")";

        db.execSQL(queryTable2);

        queryTable3 = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME_UPDATE +
                " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ADMIN_USER_ID + " INTEGER NOT NULL, " +
                MASJID_ID + " INTEGER NOT NULL, " +
                FAJR + " TEXT NOT NULL, " +
                ZUHR + " TEXT NOT NULL, " +
                ASR + " TEXT NOT NULL, " +
                MAGHRIB + " TEXT NOT NULL, " +
                ISHA + " TEXT NOT NULL, " +
                JUMUAH + " TEXT NOT NULL, " +
                STATUS + " TEXT NOT NULL, " +
                LASTUPDATED + " TEXT NOT NULL " +
                ")";

        db.execSQL(queryTable3);*/
      /*  switch(newVersion) {
            case 3:
                db.execSQL(queryTable2);
                // we want both updates, so no break statement here...
        }*/
       /* if (newVersion > oldVersion) {
            db.execSQL("ALTER TABLE favourite ADD COLUMN eid TEXT DEFAULT ''");
        }
        if (newVersion > oldVersion) {
            db.execSQL("ALTER TABLE suggestion ADD COLUMN eid TEXT DEFAULT ''");
        }
        if (newVersion > oldVersion) {
            db.execSQL("ALTER TABLE updateoffline ADD COLUMN eid TEXT DEFAULT ''");
        }*/
    }

    public void openDB() {
        myDB = getWritableDatabase();
    }

    public void closeDB() {
        if (myDB != null && myDB.isOpen()) {
            myDB.close();
        }
    }

    //Offline UPDATE

    public long insert_Update(int admin, int masjidid, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah, String eid, String status, String lastupdated) {
        ContentValues values = new ContentValues();
        values.put(ADMIN_USER_ID, admin);
        values.put(MASJID_ID, masjidid);
        values.put(FAJR, fajr);
        values.put(ZUHR, zuhr);
        values.put(ASR, asr);
        values.put(MAGHRIB, maghrib);
        values.put(ISHA, isha);
        values.put(JUMUAH, jumuah);
        values.put(EID, eid);
        values.put(STATUS, status);
        values.put(LASTUPDATED, lastupdated);

        return myDB.insert(TABLE_NAME_UPDATE, null, values);
    }

    public long update_update(int masjid, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah, String eid, String status, String lastupdated) {
        ContentValues values = new ContentValues();

        values.put(FAJR, fajr);
        values.put(ZUHR, zuhr);
        values.put(ASR, asr);
        values.put(MAGHRIB, maghrib);
        values.put(ISHA, isha);
        values.put(JUMUAH, jumuah);
        values.put(EID, eid);
        values.put(STATUS, status);
        values.put(LASTUPDATED, lastupdated);

        String where = MASJID_ID + " = " + masjid;

        return myDB.update(TABLE_NAME_UPDATE, values, where, null);
    }

    public Cursor getAdminUpdateFlag(int id) {

        // myDB.query(FAVOURITE, null, null, null, null, null, null);
        String where = " where " + MASJID_ID + " = " + id;
        String query = "SELECT * FROM " + TABLE_NAME_UPDATE + where;
        return myDB.rawQuery(query, null);

    }

    public Cursor getPendingAdminUpdate(String status) {

        // myDB.query(FAVOURITE, null, null, null, null, null, null);
        String where = " where " + STATUS + " = " + "'pending'";
        String query = "SELECT * FROM " + TABLE_NAME_UPDATE + where;
        return myDB.rawQuery(query, null);

    }

    public long Adminupdate_status(int admin, String status) {
        ContentValues values = new ContentValues();
        // values.put(ADDRESS, address);
        values.put(STATUS, status);
        String where = MASJID_ID + " = " + admin;
        return myDB.update(TABLE_NAME_UPDATE, values, where, null);
    }


    ////Offline SUGGESTION


    public long insert_suggestion(int admin, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah, String eid, String suggestionname, String suggesternumber, String status, String lastupdated) {
        ContentValues values = new ContentValues();
        //if(id != -1)
        // values.put(ID, id);
        values.put(MASJID_ID, admin);
        values.put(SUGGESTER_NAME, suggestionname);
        values.put(SUGGESTER_NUMBER, suggesternumber);
        values.put(FAJR, fajr);
        values.put(ZUHR, zuhr);
        values.put(ASR, asr);
        values.put(MAGHRIB, maghrib);
        values.put(ISHA, isha);
        values.put(JUMUAH, jumuah);
        values.put(EID, eid);
        values.put(STATUS, status);
        values.put(LASTUPDATED, lastupdated);

        return myDB.insert(TABLE_NAME_SUGGESTION, null, values);
    }

    public long update_suggestion(int admin, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah, String eid, String name, String number, String status, String lastupdated) {
        ContentValues values = new ContentValues();

        // values.put(ADDRESS, address);
        values.put(FAJR, fajr);
        values.put(ZUHR, zuhr);
        values.put(ASR, asr);
        values.put(MAGHRIB, maghrib);
        values.put(ISHA, isha);
        values.put(JUMUAH, jumuah);
        values.put(EID, eid);
        values.put(STATUS, status);
        values.put(SUGGESTER_NAME, name);
        values.put(SUGGESTER_NUMBER, number);
        values.put(LASTUPDATED, lastupdated);

        String where = MASJID_ID + " = " + admin;

        return myDB.update(TABLE_NAME_SUGGESTION, values, where, null);
    }

    public Cursor getAllRecordsSuggestion() {

        // myDB.query(FAVOURITE, null, null, null, null, null, null);

        String query = "SELECT * FROM " + TABLE_NAME_SUGGESTION;
        return myDB.rawQuery(query, null);

    }

    public Cursor getSuggestionFlag(int id) {

        // myDB.query(FAVOURITE, null, null, null, null, null, null);
        String where = " where " + MASJID_ID + " = " + id;
        String query = "SELECT * FROM " + TABLE_NAME_SUGGESTION + where;
        return myDB.rawQuery(query, null);

    }

    public Cursor getPendingSuggestion(String status) {

        // myDB.query(FAVOURITE, null, null, null, null, null, null);
        String where = " where " + STATUS + " = " + "'pending'";
        String query = "SELECT * FROM " + TABLE_NAME_SUGGESTION + where;
        return myDB.rawQuery(query, null);

    }

    public long update_status(int admin, String status) {
        ContentValues values = new ContentValues();
        // values.put(ADDRESS, address);
        values.put(STATUS, status);
        String where = MASJID_ID + " = " + admin;
        return myDB.update(TABLE_NAME_SUGGESTION, values, where, null);
    }


    //FAVOURITES


    public Cursor getAllRecords() {
        // myDB.query(FAVOURITE, null, null, null, null, null, null);

        try{
            String query = "SELECT * FROM " + FAVOURITE;
            return myDB.rawQuery(query, null);
        }catch (Exception e){
            return null;
        }

    }

    public void deleteOldFavouritesTable(){
        myDB.execSQL("DROP TABLE IF EXISTS '" + FAVOURITE + "'");;
    }



    //FAVOURITES FROM SERVER


    public long insertFavLocal(int id, int admin, String masjidname, String address, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah, String eid, String lastupdated) {
        ContentValues values = new ContentValues();
        if (id != -1)
            values.put(ID, id);
        values.put(ADMIN_USER_ID, admin);
        values.put(MASJID_NAME, masjidname);
        values.put(ADDRESS, address);
        values.put(FAJR, fajr);
        values.put(ZUHR, zuhr);
        values.put(ASR, asr);
        values.put(MAGHRIB, maghrib);
        values.put(ISHA, isha);
        values.put(JUMUAH, jumuah);
        values.put(EID, eid);
        values.put(LASTUPDATED, lastupdated);



        return myDB.insert(FAVOURITE_SERVER, null, values);
    }

    public long updateFavLocal(int id, int admin, String masjidname, String address, String fajr, String zuhr, String asr, String maghrib, String isha, String jumuah, String eid, String lastupdated) {
        ContentValues values = new ContentValues();

        values.put(ADDRESS, address);
        values.put(FAJR, fajr);
        values.put(ZUHR, zuhr);
        values.put(ASR, asr);
        values.put(MAGHRIB, maghrib);
        values.put(ISHA, isha);
        values.put(JUMUAH, jumuah);
        values.put(EID, eid);
        values.put(LASTUPDATED, lastupdated);

        String where = ADMIN_USER_ID + " = " + admin;

        return myDB.update(FAVOURITE_SERVER, values, where, null);
    }


    public long deleteFavLocal(String id) {
        String where = ID + " = " + id;

        return myDB.delete(FAVOURITE_SERVER, where, null);
    }


    public Cursor getAllFavLocal() {

        // myDB.query(FAVOURITE, null, null, null, null, null, null);

        String query = "SELECT * FROM " + FAVOURITE_SERVER;
        return myDB.rawQuery(query, null);

    }

    public Cursor getFavouritesFlagServer(int id) {

        // myDB.query(FAVOURITE, null, null, null, null, null, null);
        String where = " where " + ID + " = " + id;
        String query = "SELECT * FROM " + FAVOURITE_SERVER + where;
        return myDB.rawQuery(query, null);

    }

    public int clearFav(){
        return  myDB.delete(FAVOURITE_SERVER,null,null);
    }


}


