package com.awqatesalah.awqaat_e_salaah.Bayaan.Model;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Other_Response {

        private ResultData ResultData;

        private String Message;

        private String Success;

        public ResultData getResultData ()
        {
            return ResultData;
        }

        public void setResultData (ResultData ResultData)
        {
            this.ResultData = ResultData;
        }

        public String getMessage ()
        {
            return Message;
        }

        public void setMessage (String Message)
        {
            this.Message = Message;
        }

        public String getSuccess ()
        {
            return Success;
        }

        public void setSuccess (String Success)
        {
            this.Success = Success;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [ResultData = "+ResultData+", Message = "+Message+", Success = "+Success+"]";
        }

    public class ResultData
    {
        private String ModifiedOn;

        private String OtherBayaan;

        public String getModifiedOn ()
        {
            return ModifiedOn;
        }

        public void setModifiedOn (String ModifiedOn)
        {
            this.ModifiedOn = ModifiedOn;
        }

        public String getOtherBayaan ()
        {
            return OtherBayaan;
        }

        public void setOtherBayaan (String OtherBayaan)
        {
            this.OtherBayaan = OtherBayaan;
        }

        @Override
        public String toString()
        {
            return "ClassPojo [ModifiedOn = "+ModifiedOn+", OtherBayaan = "+OtherBayaan+"]";
        }
    }


}

