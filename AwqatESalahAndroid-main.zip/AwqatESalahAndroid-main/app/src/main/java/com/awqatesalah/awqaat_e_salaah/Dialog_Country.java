package com.awqatesalah.awqaat_e_salaah;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.SpinnerAdapter;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.awqatesalah.awqaat_e_salaah.Interface.CallRetroApi;
import com.awqatesalah.awqaat_e_salaah.Search.Models.GetAllCountryResponse;
import com.awqatesalah.awqaat_e_salaah.Search.Models.ResponseCities;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import mehdi.sakout.fancybuttons.FancyButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by root on 1/10/16.
 */
public class Dialog_Country extends DialogFragment {

    @BindView(R.id.countries)
    SearchableSpinner spinner_country;
    @BindView(R.id.states)
    SearchableSpinner spinner_states;
    @BindView(R.id.submit_country)
    FancyButton submit_country;

    int CountryID = -1;
    int StateID = -1;
    GetAllCountryResponse allCountryResponse;
    ResponseCities[] responseCities;
    private MySharedPrefrences shared;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final Dialog dialog = new Dialog(getActivity(), R.style.MyDialogTheme);
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        dialog.setContentView(R.layout.dialog_country_layout);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        shared = MySharedPrefrences.getInstance(getContext());

        if (shared.getCountry() == -1 || shared.getState() == -1) {
            setCancelable(false);
        }

        ButterKnife.bind(this, dialog);




        spinner_states.setTitle("Select State");
        spinner_country.setTitle("Select Country");


        getCountriesAndState();


        spinner_country.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                CountryID = allCountryResponse.getResultData()[position].getCountryID();
                responseCities = allCountryResponse.getResultData()[position].getCities();


                ArrayList<String> states = new ArrayList<String>();
                ArrayList<Integer> stateIdList = new ArrayList<Integer>();

                for (int i = 0; i < responseCities.length; i++) {
                    states.add(responseCities[i].getCityName());
                }

                for (int i = 0; i < responseCities.length; i++) {
                    stateIdList.add(responseCities[i].getCityID());
                }

                SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, states);
                spinner_states.setAdapter(adapter);

                if(shared.getState()!=-1){
                    for(int i=0;i<stateIdList.size();i++){
                        if(shared.getState() == stateIdList.get(i)){
                            spinner_states.setSelection(i);
                        }
                    }
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinner_states.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                StateID = responseCities[position].getCityID();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        submit_country.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CountryID != -1 && StateID != -1) {
                    PreferenceManager
                            .getDefaultSharedPreferences(getActivity()).edit().putString("city", "null").apply();
                    shared.saveState(StateID);
                    shared.saveCountry(CountryID);
                    MyApplication.allAreas = null;
                    shared.saveAllCities(null);
                    MyApplication.date_response = null;
                    Intent intentToMain = new Intent(getContext(), MainActivity.class);
                    intentToMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intentToMain);
                    dismiss();
                    getActivity().finish();
                }
            }
        });


        return dialog;
    }

    private void getCountriesAndState() {
        CallRetroApi get = new RetroFitServiceGenerator(getActivity()).createService(CallRetroApi.class);
        Call<GetAllCountryResponse> call1 = get.countries(StaticFunction.getValue("v6Ep==r@F?EC:6D"));

        call1.enqueue(new Callback<GetAllCountryResponse>() {
            @Override
            public void onResponse(Call<GetAllCountryResponse> call, Response<GetAllCountryResponse> response) {
                if (response.body() != null) {
                    if (response.body().getSuccess().equals("true")) {

                        allCountryResponse = response.body();

                        Log.d("countries_response", response.body().getMessage());

                        ArrayList<String> countries = new ArrayList<String>();
                        ArrayList<Integer> countryID = new ArrayList<Integer>();
                        for (int i = 0; i < response.body().getResultData().length; i++) {
                            countries.add(response.body().getResultData()[i].getCountryName());
                        }

                        for (int i = 0; i < response.body().getResultData().length; i++) {
                            countryID.add(response.body().getResultData()[i].getCountryID());
                        }

                        SpinnerAdapter adapter = new com.awqatesalah.awqaat_e_salaah.Search.Adapters.SpinnerAdapter(getActivity(), R.layout.spinneritem, countries);
                        spinner_country.setAdapter(adapter);

                        if(shared.getCountry()!=-1){
                            for(int i=0;i<countries.size();i++){
                                if(shared.getCountry() == countryID.get(i)){
                                    spinner_country.setSelection(i);
                                }
                            }
                        }

                    } else {
                        new MaterialDialog.Builder(getActivity()).title("Error")
                                .content(response.body().getMessage()).positiveText("Try Again").show();

                        //  progress.hide();
                    }
                }
            }

            @Override
            public void onFailure(Call<GetAllCountryResponse> call, Throwable t) {
                try {
                    if (StaticFunction.isOnline(getActivity())) {
                        new MaterialDialog.Builder(getContext()).title("Something went wrong")
                                .content("please Try Again After Sometime").positiveText("Try Again")
                                .onPositive(new MaterialDialog.SingleButtonCallback() {
                                    @Override
                                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                        getActivity().finish();
                                    }
                                })
                                .negativeText("Close")
                                .show();
                    } else {
                        new MaterialDialog.Builder(getContext()).title("Internet Error")
                                .content("You dont have INTERNET CONNECTION").onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                getActivity().finish();
                            }
                        }).positiveText("Ok").show();
                    }

                } catch (Exception e) {

                }
                //  progress.hide();
            }
        });

    }


}

