package com.awqatesalah.awqaat_e_salaah.Notification.Model.Models;

import android.util.Log;

import com.awqatesalah.awqaat_e_salaah.Search.Models.LessDetailedListSorting_Model;

import java.util.Comparator;

/**
 * Created by Abubakker on 8/28/2016.
 */
public class Notification_Model implements Comparable<Notification_Model>{
    private String Count;
    private String Details;
    private String Type;
    private String Title;
    private String Date;
    private String NotificationID;

    public String getNotificationID() {
        return NotificationID;
    }

    public void setNotificationID(String notificationID) {
        NotificationID = notificationID;
    }

    public String getCount() {
        return Count;
    }

    public void setCount(String count) {
        Count = count;
    }

    public String getDetails() {
        return Details;
    }

    public void setDetails(String details) {
        Details = details;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public Notification_Model(){

    }

    public Notification_Model(String title, String date, String type, String details, String NotificationID) {
        Type = type;
        Title = title;
        Date = date;
        Details = details;
        this.NotificationID=NotificationID;
    }


    @Override
    public int compareTo(Notification_Model notification_model) {
        if (Integer.parseInt(NotificationID) < Integer.parseInt(notification_model.NotificationID)) {
            return 1;
        }
        else if (Integer.parseInt(NotificationID) > Integer.parseInt(notification_model.NotificationID)) {
            return -1;
        }
        else {
            return 0;
        }
    }
}
