package com.awqatesalah.awqaat_e_salaah.Search.Models;

/**
 * Created by root on 21/5/17.
 */

public class GetAllCountryResponse {
    String Success;
    ResultData[] ResultData;
    String Message;

    public String getSuccess() {
        return Success;
    }

    public void setSuccess(String success) {
        Success = success;
    }

    public GetAllCountryResponse.ResultData[] getResultData() {
        return ResultData;
    }

    public void setResultData(GetAllCountryResponse.ResultData[] resultData) {
        ResultData = resultData;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public class ResultData {
        private ResponseCities[] Cities;

        private String CountryName;

        private int CountryID;

        public ResponseCities[] getCities() {
            return Cities;
        }

        public void setCities(ResponseCities[] ResponseCities) {
            this.Cities = ResponseCities;
        }

        public String getCountryName() {
            return CountryName;
        }

        public void setCountryName(String CountryName) {
            this.CountryName = CountryName;
        }

        public int getCountryID() {
            return CountryID;
        }

        public void setCountryID(int countryID) {
            CountryID = countryID;
        }

        @Override
        public String toString() {
            return "ClassPojo [Cities = " + Cities + ", CountryName = " + CountryName + ", CountryID = " + CountryID + "]";
        }

    }
}
