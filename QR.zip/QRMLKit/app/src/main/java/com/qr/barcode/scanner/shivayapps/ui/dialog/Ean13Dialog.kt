package com.qr.barcode.scanner.shivayapps.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.qr.barcode.scanner.shivayapps.databinding.TextInputDialogLayoutBinding

import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.databinding.Ean13InputDialogLayoutBinding
import com.qr.barcode.scanner.shivayapps.models.barcode.BarcodeDetails
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Format
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Type


class Ean13Dialog() :
    BottomSheetDialogFragment() {

    var updateListener: ((value: Bundle) -> Unit)? = null

    lateinit var bindingDialog: Ean13InputDialogLayoutBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = Ean13InputDialogLayoutBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        intListener()

    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOk.setOnClickListener {
            val content = bindingDialog.outlinedEan13Field.text.toString()
            if (isValidEAN13(content)) {
                val barcodeDetails =
                    BarcodeDetails(
                        format = Format.EAN_13,
                        type = Type.TYPE_UNKNOWN,
                        timeStamp = null,
                        rawValue = content
                    )
                val bundle = Bundle().apply {
                    putParcelable("barcodeDetails", barcodeDetails)
                }
                updateListener?.invoke(bundle)
            } else Toast.makeText(
                requireContext(),
                "Please enter valid input",
                Toast.LENGTH_SHORT
            ).show()
            dismiss()
        }
    }
    private fun isValidEAN13(ean: String): Boolean {
        if (ean.length != 13) return false
        var sum = 0
        for (i in 0 until 12) {
            val digit = ean[i].toString().toInt()
            sum += if (i % 2 == 0) digit else digit * 3
        }
        val checkDigit = (10 - sum % 10) % 10
        return checkDigit == ean[12].toString().toInt()
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}