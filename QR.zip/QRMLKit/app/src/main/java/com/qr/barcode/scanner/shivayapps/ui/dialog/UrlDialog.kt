package com.qr.barcode.scanner.shivayapps.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.qr.barcode.scanner.shivayapps.databinding.TextInputDialogLayoutBinding

import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.databinding.UrlInputDialogLayoutBinding
import com.qr.barcode.scanner.shivayapps.models.barcode.BarcodeDetails
import com.qr.barcode.scanner.shivayapps.models.barcode.data.Url
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Format
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Type


class UrlDialog() :
    BottomSheetDialogFragment() {

    var updateListener: ((value: Bundle) -> Unit)? = null

    lateinit var bindingDialog: UrlInputDialogLayoutBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = UrlInputDialogLayoutBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        intListener()

    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOk.setOnClickListener {
            val content = bindingDialog.outlinedUrlField.text.toString()

            if (content.startsWith("http://") || content.startsWith("https://")) {
                val barcodeDetails = BarcodeDetails(
                    format = Format.QR_CODE,
                    type = Type.TYPE_URL,
                    null,
                    rawValue = content,
                    url = Url(null, content)
                )
                val bundle = Bundle().apply {
                    putParcelable("barcodeDetails", barcodeDetails)
                }
                updateListener?.invoke(bundle)
            } else Toast.makeText(
                requireContext(),
                "Url must start with http:// or https://",
                Toast.LENGTH_SHORT
            ).show()
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}