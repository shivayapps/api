package com.qr.barcode.scanner.shivayapps.application

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.qr.barcode.scanner.shivayapps.R
import dagger.hilt.android.HiltAndroidApp

/*
 * Copyright 2023 Yatik
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@HiltAndroidApp
class BarcodeDataApplication : AppOpenApplication(),AppOpenApplication.AppLifecycleListener {

    override fun onCreate() {
        super.onCreate()

        val AdmobAppOpenId = getString(R.string.admob_open)
        AdsConfig.builder()
            .isEnableAds(true)
            .isEnableOpenAds(true)
            .setTestDeviceId("0")
            .setAdmobAppOpenId(AdmobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()
    }
    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {

    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {

    }
}