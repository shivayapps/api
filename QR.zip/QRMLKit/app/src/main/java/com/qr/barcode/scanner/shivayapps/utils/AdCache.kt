package com.qr.barcode.scanner.shivayapps.utils

import com.google.android.gms.ads.AdView

object AdCache {
    var bannerDetail: AdView? = null
}
