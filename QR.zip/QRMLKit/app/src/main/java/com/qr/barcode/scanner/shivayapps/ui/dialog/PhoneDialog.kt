package com.qr.barcode.scanner.shivayapps.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.qr.barcode.scanner.shivayapps.databinding.TextInputDialogLayoutBinding

import com.qr.barcode.scanner.shivayapps.R
import com.qr.barcode.scanner.shivayapps.databinding.PhoneInputDialogLayoutBinding
import com.qr.barcode.scanner.shivayapps.models.barcode.BarcodeDetails
import com.qr.barcode.scanner.shivayapps.models.barcode.data.Phone
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Format
import com.qr.barcode.scanner.shivayapps.models.barcode.metadata.Type


class PhoneDialog() :
    BottomSheetDialogFragment() {

    var updateListener: ((value: Bundle) -> Unit)? = null

    lateinit var bindingDialog: PhoneInputDialogLayoutBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = PhoneInputDialogLayoutBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {
        intListener()

    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOk.setOnClickListener {
            val content = bindingDialog.outlinedPhoneField.text.toString()
            if (content.isNotEmpty()) {
                val barcodeDetails = BarcodeDetails(
                    format = Format.QR_CODE,
                    type = Type.TYPE_PHONE,
                    null,
                    rawValue = "tel:$content",
                    phone = Phone(null, content, null)
                )
                val bundle = Bundle().apply {
                    putParcelable("barcodeDetails", barcodeDetails)
                }
                updateListener?.invoke(bundle)
            } else Toast.makeText(
                requireContext(),
                "Please enter valid number",
                Toast.LENGTH_SHORT
            ).show()
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}