package com.jaredrummler.android.colorpicker;

import android.graphics.Color;

public class Constants {
    public static boolean isSelectedBottom1=false;
    public static boolean isSelectedBottom2=false;

    public static int mainColor1= Color.parseColor("#EBEBEB");
    public static int mainColor2= Color.parseColor("#EBEBEB");
    public static int selectedColor1;
    public static int selectedColor2;
}
