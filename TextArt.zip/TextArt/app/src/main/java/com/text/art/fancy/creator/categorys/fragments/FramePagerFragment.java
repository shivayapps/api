package com.text.art.fancy.creator.categorys.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper;
import com.text.art.fancy.creator.R;
import com.text.art.fancy.creator.ads.RewardVideoAds;
import com.text.art.fancy.creator.categorys.adepter.CakeLiveAdapter;
import com.text.art.fancy.creator.categorys.adepter.FramesLiveAdapter;
import com.text.art.fancy.creator.categorys.callbacks.OnRewardEarn;
import com.text.art.fancy.creator.categorys.dialog.WatchVideoDialog;
import com.text.art.fancy.creator.categorys.model.CakeModel;
import com.text.art.fancy.creator.categorys.model.FrameModel;
import com.text.art.fancy.creator.categorys.model.ImageItem;
import com.text.art.fancy.creator.categorys.parameter.CategoryParametersItem;
import com.text.art.fancy.creator.categorys.sqlite_database.AdsPrefs;
import com.text.art.fancy.creator.categorys.sqlite_database.DBHelper;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdCallback;
import com.text.art.fancy.creator.categorys.FramesCategorySheet;

import java.util.ArrayList;
import java.util.List;

public class FramePagerFragment extends Fragment {
    private static final String TAG = "CardPagerFragment";
    private Activity mActivity;
    private ArrayList<ImageItem> mList;
    private ArrayList<CategoryParametersItem> mParamList;
    private ArrayList<FrameModel> mTempList;
    private ArrayList<CakeModel> mTempCakeList;
    private DBHelper dbHelper;
    private FramesLiveAdapter mCardLiveAdapter;
    private CakeLiveAdapter mCakeLiveAdapter;
    private OnRewardEarn mOnRewardEarn;
    private RecyclerView mRecyclerView;
    private ProgressBar mProgressBar1;

    private String mType;

    public static boolean isAdShow = false;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mOnRewardEarn = ((FramesCategorySheet) getParentFragment());
    }

    public FramePagerFragment(List<ImageItem> imageItems, String mType) {
        mList = new ArrayList();
        mList.addAll(imageItems);
        mTempList = new ArrayList<>();
        this.mType = mType;
    }

    public FramePagerFragment(List<CategoryParametersItem> imageItems, boolean param) {
        mParamList = new ArrayList();
        mParamList.addAll(imageItems);
        mTempCakeList = new ArrayList<>();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sticker_view_pager, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        mActivity = getActivity();

        dbHelper = new DBHelper(mActivity);

        mRecyclerView = view.findViewById(R.id.recyclerViewCard);
        mProgressBar1 = view.findViewById(R.id.progressBar1);

        mRecyclerView.setVisibility(View.VISIBLE);

        main();
    }

    private void main() {
        FramesLiveAdapter.OnItemSelectedListner onItemSelectedListner = new FramesLiveAdapter.OnItemSelectedListner() {
            @Override
            public void onItemClick(int position, FrameModel imagesIte) {

                if (imagesIte.isLocked()) {
                    if (NetworkHelper.isOnline(mActivity)) {

                        if (RewardVideoAds.Companion.getInstence() != null && RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity) != null) {
                            RewardedAd rewardedAd = RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity);
                            showAdDialog(position, rewardedAd, imagesIte.isAdCount());
                        } else {
                            Toast.makeText(mActivity, getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getActivity(), "Please check internet connection.", Toast.LENGTH_SHORT).show();
                    }

                } else if (imagesIte.isPremium()) {
                    if (getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog") != null) {
                        Log.d(TAG, "onUserEarnedReward: 2");
                        ((FramesCategorySheet) getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog")).dismiss();
                    }
                } else {
                    if (NetworkHelper.isOnline(mActivity)) {
                        if (mOnRewardEarn != null) {
                            mOnRewardEarn.onRewardEarn(imagesIte.getImageItem());
                        }
                        if (getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog") != null) {
                            Log.d(TAG, "onUserEarnedReward: 3");
                            ((FramesCategorySheet) getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog")).dismiss();
                        }
                    } else {
                        Toast.makeText(mActivity, "Please check internet connection", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        };

        CakeLiveAdapter.OnItemSelectedListner onItemSelectedListnerCake = new CakeLiveAdapter.OnItemSelectedListner() {
            @Override
            public void onItemClick(int position, CakeModel imagesIte) {
                if (imagesIte.isLocked()) {
                    if (NetworkHelper.isOnline(mActivity)) {

                        if (RewardVideoAds.Companion.getInstence() != null && RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity) != null) {
                            RewardedAd rewardedAd = RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity);
                            showAdDialog(position, rewardedAd, imagesIte.isAdCount());
                        } else {
                            Toast.makeText(getActivity(), getResources().getString(R.string.try_again_later), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(mActivity, "Please check internet connection.", Toast.LENGTH_SHORT).show();
                    }

                } else if (imagesIte.isPremium()) {
                    if (getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog") != null) {
                        Log.d(TAG, "onUserEarnedReward: 4");
                        ((FramesCategorySheet) getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog")).dismiss();
                    }
                } else {
                    if (NetworkHelper.isOnline(mActivity)) {
                        if (mOnRewardEarn != null) {
                            mOnRewardEarn.onRewardEarn(imagesIte.getImageItem());
                        }
                        if (getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog") != null) {
                            Log.d(TAG, "onUserEarnedReward: 5");
                            ((FramesCategorySheet) getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog")).dismiss();
                        }
                    } else {
                        Toast.makeText(mActivity, "Please check internet connection", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        };

        GridLayoutManager manager = new GridLayoutManager(getActivity(), 3);
        mRecyclerView.setLayoutManager(manager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... voids) {

                ArrayList<FrameModel> mWallpaperList = new ArrayList<>();

                try {
                    if (AdsPrefs.getBoolean(getActivity(), AdsPrefs.IS_SUBSCRIBED, false)) {
                        if (mList != null) {
                            mTempList.addAll(mWallpaperList);
                        }
                    } else {
                        if (mList != null) {
                            for (int i = 0; i < mList.size(); i++) {
                                Pair<Boolean, Integer> pair = dbHelper.isExist(mList.get(i).getImage());
                                if (pair.first) {
                                    mTempList.add(new FrameModel(
                                            mList.get(i),
                                            false,
                                            pair.second != 0,
                                            pair.second == 0,
                                            pair.second
                                    ));
                                } else {
                                    mTempList.add(new FrameModel(
                                            mList.get(i),
                                            false,
                                            mList.get(i).getIs_premium() != 0,
                                            false,
                                            numberOfAd(mList.get(i).getCoins())
                                    ));
                                }

                            }
                        } else {
                            for (int i = 0; i < mParamList.size(); i++) {
                                Pair<Boolean, Integer> pair = dbHelper.isExist(mParamList.get(i).getImage());
                                if (pair.first) {
                                    mTempCakeList.add(new CakeModel(
                                            mParamList.get(i),
                                            false,
                                            pair.second != 0,
                                            pair.second == 0,
                                            pair.second
                                    ));
                                } else {
                                    mTempCakeList.add(new CakeModel(
                                            mParamList.get(i),
                                            false,
                                            mParamList.get(i).getIs_premium() != 0,
                                            false,
                                            numberOfAd(mParamList.get(i).getCoins())
                                    ));
                                }
                            }
                        }
                    }
                } catch (Exception ex) {
                    ex.getStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                mProgressBar1.setVisibility(View.GONE);
                if (mList != null) {
                    mCardLiveAdapter = new FramesLiveAdapter(mTempList, getActivity(), onItemSelectedListner);
                    mRecyclerView.setAdapter(mCardLiveAdapter);
                } else {
                    mCakeLiveAdapter = new CakeLiveAdapter(mTempCakeList, mActivity, onItemSelectedListnerCake);
                    mRecyclerView.setAdapter(mCakeLiveAdapter);
                }
            }
        }.execute();

    }

    private int numberOfAd(int coin) {
        if (coin < 5)
            return 1;
        else
            return (int) Math.round(coin / 10.0);
    }

    private void showAdDialog(int position, RewardedAd gameOverRewardedAd, int numberOfAd) {
        String s = getResources().getString(R.string.do_you_want_watch_video);
        if (mList != null && mType == "Card") {
            s = getResources().getString(R.string.do_you_want_watch_video_card);
        } else {
            s = getResources().getString(R.string.do_you_want_watch_video_cake);
        }
        WatchVideoDialog bottomSheetFragment = new WatchVideoDialog(getResources().getString(R.string.watch_video), s, getResources().getString(R.string.watch_ad), "CANCEL", R.drawable.ic_video, new WatchVideoDialog.OnButtonClickListener() {
            @Override
            public void onPositive(WatchVideoDialog bottomSheetDialo) {
                bottomSheetDialo.dismiss();
                showAdReward(position, gameOverRewardedAd, numberOfAd);
            }

            @Override
            public void onNegative(WatchVideoDialog bottomSheetDialog) {
                bottomSheetDialog.dismiss();
            }
        });
        bottomSheetFragment.show(getChildFragmentManager(), "dialog");

    }

    public void showAdReward(int position, RewardedAd gameOverRewardedAd, int numberOfAd) {
        isAdShow = true;
        if (gameOverRewardedAd.isLoaded()) {
            RewardedAdCallback adCallback = new RewardedAdCallback() {
                @Override
                public void onRewardedAdOpened() {
                    // Ad opened.
                    isAdShow = true;
                }

                @Override
                public void onRewardedAdClosed() {
                    // Ad closed.
                    assert RewardVideoAds.Companion.getInstence() != null;
                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity);
                    isAdShow = false;
                }

                @Override
                public void onUserEarnedReward(@NonNull RewardItem reward) {
                    // User earned reward.
                    if (mList != null) {
                        Log.d(TAG, "onUserEarnedReward: as " + numberOfAd);
                        int count = numberOfAd;
                        if (!dbHelper.isExist(mList.get(position).getImage()).first) {
                            dbHelper.insertPath(mList.get(position).getImage(), --count);
                        } else {
                            dbHelper.updateCount(mList.get(position).getImage(), --count);
                        }

                        if (mTempList != null) {
                            if (numberOfAd > 1) {
                                mTempList.get(position).setFree(false);
                                mTempList.get(position).setLocked(true);
                                mTempList.get(position).setAdCount(count--);
                                mCardLiveAdapter.notifyItemChanged(position);
                            } else {
                                mTempList.get(position).setFree(true);
                                mTempList.get(position).setLocked(false);
                                mTempList.get(position).setAdCount(0);
                                if (NetworkHelper.isOnline(mActivity)) {
                                    if (mOnRewardEarn != null) {
                                        mOnRewardEarn.onRewardEarn(mList.get(position));
                                    }
                                    if (getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog") != null) {
                                        Log.d(TAG, "onUserEarnedReward: 1");
                                        ((FramesCategorySheet) getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog")).dismiss();
                                    }
                                } else {
                                    Toast.makeText(mActivity, "Please check internet connection", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }

                    } else {
                        int count = numberOfAd;
                        if (!dbHelper.isExist(mParamList.get(position).getImage()).first) {
                            dbHelper.insertPath(mParamList.get(position).getImage(), --count);
                        } else {
                            dbHelper.updateCount(mParamList.get(position).getImage(), --count);
                        }

                        if (mTempCakeList != null) {
                            if (numberOfAd > 1) {
                                mTempCakeList.get(position).setFree(false);
                                mTempCakeList.get(position).setLocked(true);
                                mTempCakeList.get(position).setAdCount(count--);
                                mCakeLiveAdapter.notifyItemChanged(position);
                            } else {
                                mTempCakeList.get(position).setFree(true);
                                mTempCakeList.get(position).setLocked(false);
                                mTempCakeList.get(position).setAdCount(0);
                                if (NetworkHelper.isOnline(mActivity)) {
                                    if (mOnRewardEarn != null) {
                                        mOnRewardEarn.onRewardEarn(mParamList.get(position));
                                    }

                                    if (getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog") != null) {
                                        Log.d(TAG, "onUserEarnedReward: 1");
                                        ((FramesCategorySheet) getParentFragment().getFragmentManager().findFragmentByTag("Card_Category_Dialog")).dismiss();
                                    }
                                } else {
                                    Toast.makeText(mActivity, "Please check internet connection", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }
                    }
                    isAdShow = false;
                    assert RewardVideoAds.Companion.getInstence() != null;
                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity);
                }

                @Override
                public void onRewardedAdFailedToShow(int errorCode) {
                    // Ad failed to display.
                    isAdShow = false;
                    assert RewardVideoAds.Companion.getInstence() != null;
                    RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity);
                    Toast.makeText(getActivity(), "Please try again later.", Toast.LENGTH_SHORT).show();
                }
            };
            gameOverRewardedAd.show(getActivity(), adCallback);
        } else {
            isAdShow = false;
            assert RewardVideoAds.Companion.getInstence() != null;
            RewardVideoAds.Companion.getInstence().loadVideoAdMain(mActivity);
            Toast.makeText(getActivity(), "Please try again later.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }
}
