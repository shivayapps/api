package com.text.art.fancy.creator.adepter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.text.art.fancy.creator.R;

import java.util.ArrayList;

public class PageAdepter extends RecyclerView.Adapter<PageAdepter.ViewHolder> {

    private ArrayList<String> IMAGES;
    private Context context;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        VideoView video;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.imgPageShow);
            video = itemView.findViewById(R.id.videoPageShow);
        }
    }

    public PageAdepter(ArrayList<String> IMAGES, Context context) {
        this.IMAGES = IMAGES;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_page, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.setIsRecyclable(false);
        if (IMAGES.get(position).contains("/Pictures/TextArt/")) {
            holder.video.setVisibility(View.GONE);
            holder.image.setVisibility(View.VISIBLE);
            Glide.with(context).load(IMAGES.get(position)).into(holder.image);
            Log.d("TAG", "instantiateItem: Image");
        } else {
            Log.d("TAG", "instantiateItem: Video");
            holder.image.setVisibility(View.GONE);
            holder.video.setVisibility(View.VISIBLE);
            holder.video.setVideoPath(IMAGES.get(position));
            holder.video.setOnPreparedListener(mp -> mp.setLooping(true));
            holder.video.start();
        }
    }

    @Override
    public int getItemCount() {
        return IMAGES.size();
    }
}