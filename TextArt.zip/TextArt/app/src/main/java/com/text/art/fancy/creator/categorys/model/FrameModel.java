package com.text.art.fancy.creator.categorys.model;

public class FrameModel {

    private ImageItem imageItem;
    private boolean isPremium;
    private boolean isLocked;
    private boolean isFree;
    private int adCount;

    public FrameModel(ImageItem imageItem, boolean isPremium, boolean isLocked, boolean isFree, int adCount) {
        this.imageItem = imageItem;
        this.isPremium = isPremium;
        this.isLocked = isLocked;
        this.isFree = isFree;
        this.adCount = adCount;
    }

    public ImageItem getImageItem() {
        return imageItem;
    }

    public void setImageItem(ImageItem imageItem) {
        this.imageItem = imageItem;
    }

    public boolean isPremium() {
        return isPremium;
    }

    public void setPremium(boolean premium) {
        isPremium = premium;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    public boolean isFree() {
        return isFree;
    }

    public void setFree(boolean free) {
        isFree = free;
    }

    public int isAdCount() {
        return adCount;
    }

    public void setAdCount(int adCount) {
        this.adCount = adCount;
    }
}
