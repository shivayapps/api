package com.text.art.fancy.creator.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import com.text.art.fancy.creator.model.ImageModel
import com.text.art.fancy.creator.model.PhotoModel
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.TextArtApplication
import com.text.art.fancy.creator.activitys.FullMyPhotoActivity
import com.text.art.fancy.creator.activitys.MyPhotoActivity
import com.text.art.fancy.creator.adepter.PhotoAdepter
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAdListener
import kotlinx.android.synthetic.main.fragment_photo.*
import java.io.File

class PhotoFragment : Fragment(){

    val TAG = "PhotoFragment"

    var mImageAdepter: PhotoAdepter? = null
    var mArrayList: ArrayList<ImageModel>? = null
    var mPhotoList: ArrayList<PhotoModel>? = null

    private lateinit var startNew: () -> Unit

    private var isInterstitialAdLoaded = false

    companion object {
        val arr = ArrayList<Int>()
        var isShowCheckBox: Boolean = false
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_photo, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvPhotoSelect.layoutManager = GridLayoutManager(context!!, 3)
        rvPhotoSelect.itemAnimator = DefaultItemAnimator()

        mArrayList = ArrayList()

        mArrayList = arguments?.getSerializable("list") as ArrayList<ImageModel>?
        mPhotoList = arguments?.getSerializable("fulllist") as ArrayList<PhotoModel>?

        val isSelectedShow = arguments?.getBoolean("isShow", false)

        mImageAdepter = PhotoAdepter(context!!, mArrayList!!, {
            openActivity(mArrayList!![it].path)
        }, {
            mImageAdepter?.isSelectShow = true
            isShowCheckBox = true
            mImageAdepter?.notifyDataSetChanged()
            (activity as MyPhotoActivity).actionShow(true)
        }, {

        }, isSelectedShow!!, true)


        loadInterstialAdFb()
        rvPhotoSelect.adapter = mImageAdepter
    }

    override fun onStart() {
        super.onStart()
        if (FullMyPhotoActivity.isDelete1) {
            FullMyPhotoActivity.isDelete1 = false
            (mArrayList!!.filter {
                File(it.path).exists()
            } as ArrayList<ImageModel>).apply {
                mArrayList!!.clear()
                mArrayList!!.addAll(this)
            }

            mImageAdepter?.notifyDataSetChanged()

            if (mArrayList == null || mArrayList!!.isEmpty()) {
                activity?.onBackPressed()
            }

        }
    }

    private fun loadInterstialAdFb() {
        if (TextArtApplication.instance!!.mInterstitialAdfb1!!.isAdLoaded) {
        } else {
            Log.d(TAG, "loadInterstialAdFb: ")
            //TextArtApplication.instance!!.mInterstitialAdfb1!!.setAdListener(null)
            TextArtApplication.instance!!.mInterstitialAdfb1 = null
            TextArtApplication.instance!!.LoadAdsFb1()
            /*TextArtApplication.instance!!.mInterstitialAdfb1!!.setAdListener(object : InterstitialAdListener {
                override fun onError(ad: Ad, adError: AdError) {}
                override fun onAdLoaded(ad: Ad) {
                    Log.e(TAG, "onAdLoaded: ")
                }

                override fun onAdClicked(ad: Ad) {
                    Log.e(TAG, "onAdClicked: ")
                }

                override fun onLoggingImpression(ad: Ad) {}
                override fun onInterstitialDisplayed(ad: Ad) {
                    Log.d(TAG, "onInterstitialDisplayed: ")
                }

                override fun onInterstitialDismissed(ad: Ad) {
                    Log.d(TAG, "onInterstitialDismissed: ")
                }
            })*/

            val interstitialAdListener = object : InterstitialAdListener {
                override fun onInterstitialDisplayed(ad: Ad?) {
                    Log.d(TAG, "onInterstitialDisplayed: ")
                }
                override fun onInterstitialDismissed(ad: Ad?) {
                    Log.d(TAG, "onInterstitialDismissed: ")
                }
                override fun onError(ad: Ad?, adError: AdError) {}
                override fun onAdLoaded(ad: Ad?) {
                    Log.e(TAG, "onAdLoaded: ")
                }
                override fun onAdClicked(ad: Ad?) {
                    Log.e(TAG, "onAdClicked: ")
                }
                override fun onLoggingImpression(ad: Ad?) {}
            }

            TextArtApplication.instance!!.mInterstitialAdfb!!.loadAd(TextArtApplication.instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build())

        }
    }

    private fun openActivity(path: String) {
        startNew = {
            context?.let {

                startActivity(Intent(it, FullMyPhotoActivity::class.java).apply {
                    putExtra("type", "view")
                    putExtra("list", mPhotoList)
                    putExtra("image", path)
                })
            }
        }
        if (TextArtApplication.instance!!.requestNewInterstitialfb1()) {
            /*TextArtApplication.instance!!.mInterstitialAdfb1!!.setAdListener(object : InterstitialAdListener {
                override fun onError(ad: Ad, adError: AdError) {
                    startNew()
                }

                override fun onAdLoaded(ad: Ad) {
                    Log.e("TAG", "--> onAdLoaded")
                }

                override fun onAdClicked(ad: Ad) {
                    Log.e("TAG", "--> onAdClicked")
                }

                override fun onLoggingImpression(ad: Ad) {
                    Log.e("TAG", "--> onLoggingImpression")
                }

                override fun onInterstitialDisplayed(ad: Ad) {
                    Log.e("TAG", "--> onInterstitialDisplayed")
                }

                override fun onInterstitialDismissed(ad: Ad) {
                    loadInterstialAdFb()
                    startNew()
                }
            })*/

            val interstitialAdListener = object : InterstitialAdListener {
                override fun onInterstitialDisplayed(ad: Ad?) {
                    Log.e("TAG", "--> onInterstitialDisplayed")
                }
                override fun onInterstitialDismissed(ad: Ad?) {
                    loadInterstialAdFb()
                    startNew()
                }
                override fun onError(ad: Ad?, adError: AdError) {
                    startNew()
                }
                override fun onAdLoaded(ad: Ad?) {
                    Log.e("TAG", "--> onAdLoaded")
                }
                override fun onAdClicked(ad: Ad?) {
                    Log.e("TAG", "--> onAdClicked")
                }
                override fun onLoggingImpression(ad: Ad?) {
                    Log.e("TAG", "--> onLoggingImpression")
                }
            }

            TextArtApplication.instance!!.mInterstitialAdfb!!.loadAd(TextArtApplication.instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build())

        } else {
            startNew()
        }

    }

    fun selectAll(select: Boolean) {
        if (mArrayList != null) {
            mArrayList!!.mapNotNull {
                it.isSelect = select

            }
            mImageAdepter?.notifyDataSetChanged()
        }
    }


    fun delete(): Boolean {
        if (mArrayList != null) {
            (mArrayList!!.filter {
                if (it.isSelect)
                    !File(it.path).delete()
                else
                    true
            } as ArrayList<ImageModel>).apply {
                mArrayList!!.clear()
                mArrayList!!.addAll(this)
            }

            mImageAdepter?.isSelectShow = false
            isShowCheckBox = false
            if (mArrayList!!.isEmpty())
                return true

            mImageAdepter?.notifyDataSetChanged()

        }

        return false
    }
}