package com.text.art.fancy.creator.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.text.art.fancy.creator.model.ImageModel
import com.text.art.fancy.creator.model.PhotoModel
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.TextArtApplication
import com.text.art.fancy.creator.activitys.FullMyPhotoActivity
import com.text.art.fancy.creator.activitys.MyPhotoActivity
import com.text.art.fancy.creator.adepter.PhotoAdepter
import kotlinx.android.synthetic.main.fragment_photo.*
import java.io.File

class PhotoFragment : Fragment(){

    val TAG = "PhotoFragment"

    var mImageAdepter: PhotoAdepter? = null
    var mArrayList: ArrayList<ImageModel>? = null
    var mPhotoList: ArrayList<PhotoModel>? = null

    private lateinit var startNew: () -> Unit

    private var isInterstitialAdLoaded = false

    companion object {
        val arr = ArrayList<Int>()
        var isShowCheckBox: Boolean = false
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_photo, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvPhotoSelect.layoutManager = GridLayoutManager(context!!, 3)
        rvPhotoSelect.itemAnimator = DefaultItemAnimator()

        mArrayList = ArrayList()

        mArrayList = arguments?.getSerializable("list") as ArrayList<ImageModel>?
        mPhotoList = arguments?.getSerializable("fulllist") as ArrayList<PhotoModel>?

        val isSelectedShow = arguments?.getBoolean("isShow", false)

        mImageAdepter = PhotoAdepter(context!!, mArrayList!!, {
            openActivity(mArrayList!![it].path)
        }, {
            mImageAdepter?.isSelectShow = true
            isShowCheckBox = true
            mImageAdepter?.notifyDataSetChanged()
            (activity as MyPhotoActivity).actionShow(true)
        }, {

        }, isSelectedShow!!, true)

        rvPhotoSelect.adapter = mImageAdepter
    }

    override fun onStart() {
        super.onStart()
        if (FullMyPhotoActivity.isDelete1) {
            FullMyPhotoActivity.isDelete1 = false
            (mArrayList!!.filter {
                File(it.path).exists()
            } as ArrayList<ImageModel>).apply {
                mArrayList!!.clear()
                mArrayList!!.addAll(this)
            }

            mImageAdepter?.notifyDataSetChanged()

            if (mArrayList == null || mArrayList!!.isEmpty()) {
                activity?.onBackPressed()
            }

        }
    }

    private fun openActivity(path: String) {
        startNew = {
            context?.let {

                startActivity(Intent(it, FullMyPhotoActivity::class.java).apply {
                    putExtra("type", "view")
                    putExtra("list", mPhotoList)
                    putExtra("image", path)
                })
            }
        }
        activity!!.isShowInterstitialAd() {
            startNew()
        }

    }

    fun selectAll(select: Boolean) {
        if (mArrayList != null) {
            mArrayList!!.mapNotNull {
                it.isSelect = select

            }
            mImageAdepter?.notifyDataSetChanged()
        }
    }


    fun delete(): Boolean {
        if (mArrayList != null) {
            (mArrayList!!.filter {
                if (it.isSelect)
                    !File(it.path).delete()
                else
                    true
            } as ArrayList<ImageModel>).apply {
                mArrayList!!.clear()
                mArrayList!!.addAll(this)
            }

            mImageAdepter?.isSelectShow = false
            isShowCheckBox = false
            if (mArrayList!!.isEmpty())
                return true

            mImageAdepter?.notifyDataSetChanged()

        }

        return false
    }
}