package com.text.art.fancy.creator.newapi.data

class ApiHelper(private val apiService: ApiService) {

    suspend fun getTemplates() = apiService.getTemplate()

    suspend fun getCategory(
        categoryId: Int,
        subCategoryId: Int?,
        limit: Int,
        page: Int
    ) = apiService.getCategoryData(categoryId, subCategoryId, limit, page, 11)

//    suspend fun getFontStyle(limit: Int, page: Int) = apiService.getFontStyle(limit, page)

}