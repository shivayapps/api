package com.text.art.fancy.creator.newapi.manager

import android.content.Context
import com.scottyab.aescrypt.AESCrypt
import com.text.art.fancy.creator.utils.NativeHelper
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(context: Context) : Interceptor {
    private val sessionManager = SessionManager(context)

    override fun intercept(chain: Interceptor.Chain): Response {
        val requestBuilder = chain.request().newBuilder()

        //TODO CHANGE BASEURL
        // If token has been saved, add it to the request
        sessionManager.fetchAuthToken()?.let {
//            requestBuilder.addHeader("Authorization", AESCrypt.decrypt(NativeHelper().getBaseUrl(), it))
            requestBuilder.addHeader("Authorization", AESCrypt.decrypt(NativeHelper().getTestUrl(), it))
        }

        return chain.proceed(requestBuilder.build())
    }

//    override fun intercept(chain: Interceptor.Chain): Response? {
//        val response: Response ?= null
//        return try {
//            val requestBuilder = chain.request().newBuilder()
//
//            //TODO CHANGE BASEURL
//            // If token has been saved, add it to the request
//            sessionManager.fetchAuthToken()?.let {
////            requestBuilder.addHeader("Authorization", AESCrypt.decrypt(NativeHelper().getBaseUrl(), it))
//                requestBuilder.addHeader("Authorization", AESCrypt.decrypt(NativeHelper().getTestUrl(), it))
//            }
//
//            chain.proceed(requestBuilder.build())
//        }catch (e: Exception){
//            null
//        }
//    }
}