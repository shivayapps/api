package com.text.art.fancy.creator.model.creation

class GalleryImagePathModel(val path: String)