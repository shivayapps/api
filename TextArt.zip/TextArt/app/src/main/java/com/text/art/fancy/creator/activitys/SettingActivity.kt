package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.utils.*
import kotlinx.android.synthetic.main.activity_setting.*
import org.jsoup.Jsoup

class SettingActivity : AppCompatActivity() {

    private var mContext: Context? = null
    private var mConstraintLayout: ConstraintLayout? = null
    private var imgBtnBack: ImageView? = null
    private var mTVSubscribe: TextView? = null
    private var alertDialog: AlertDialog? = null
    private var mySharedPreferences: MySharedPreferences? = null
    private var mFormat: String? = null
    lateinit var toolbar: LinearLayout
    lateinit var mIVSubsriptionArrow: ImageView
    var isSubScribe: Boolean = false
    private var currentVersion: String? = null
    private lateinit var clInsta: CardView
    private lateinit var clRate: CardView
    private var lastClickTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        val display: Display = windowManager.defaultDisplay
        val width: Int = display.width
        val height: Int = display.height

        if (width == 1080 && height == 1776) {
            setContentView(R.layout.activity_setting_ore)
        }else{
            setContentView(R.layout.activity_setting)
        }
        mContext = this
        mainLayout.invalidate();
        try { toolbar.setPadding(0, getStatusbarHeight(), 0, 0) } catch (e: Exception) { }
        isSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        hideSystemUI()

        initView()

        if (isSubScribe) {
            clSubscription!!.isEnabled = false
        }

        initListener()
        initAction()

    }

    private fun isNetworkConnected(): Boolean {
        var cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        return cm.getActiveNetworkInfo() != null && cm!!.getActiveNetworkInfo()!!.isConnected()
    }

    override fun onResume() {
        super.onResume()
        isSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        if (isSubScribe) {
            findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
            try {
                mTVSubscribe!!.text = "You are a PRO User"
                clSubscription!!.isEnabled = false
                animationView?.visibility = View.INVISIBLE
                textView13?.visibility = View.INVISIBLE
                textView14?.visibility = View.INVISIBLE
                textView15?.visibility = View.INVISIBLE
                mIVSubsriptionArrow.visibility = View.GONE
                uptodates.visibility = View.VISIBLE
            } catch (e: Exception) {
            }
//            mIVSubsriptionArrow.setImageResource(R.drawable.ic_black_save)
        } else {
            try {
                if (isNetworkConnected()){
                    val display: Display = windowManager.defaultDisplay
                    val width: Int = display.width
                    val height: Int = display.height

                    if ((width == 1080 && height == 1776) || !isMobile()) {
                        findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
                    }else{
                        findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.VISIBLE
                        NativeAdvancedModelHelper(this@SettingActivity).loadNativeAdvancedAd(NativeAdsSize.Medium,findViewById(R.id.fl_adplaceholder))
                    }
                }else{
                    findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
                }
            } catch (e: Exception) {
            }
            mTVSubscribe!!.text = "Subscription (PRO)"
        }
    }

    private fun initAction() {

        try {
            currentVersion = packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }

        mySharedPreferences =
            MySharedPreferences(this)
        mFormat = mySharedPreferences!!.format
        if (mFormat.equals("jpg", ignoreCase = true)) {
            rbJpg.isChecked = true
        } else
            rbPng.isChecked = true

        if (!isSubScribe) {
            mTVSubscribe!!.text = "Upgrade to PRO"
//            try {
//                animationView.visibility = View.GONE
//                interstitial = InterstitialAdHelper.instance?.load(mContext!!, object : InterstitialAdHelper.onInterstitialAdListener {
//                    override fun onLoad() {
//                        isInterstitialAdLoaded = true
//                        isSubScribe = MySharedPreferences(this@SettingActivity).isSubscribe
//                        if (isSubScribe) {
//                            animationView.visibility = View.INVISIBLE
//                        } else {
//                            animationView.visibility = View.VISIBLE
//                        }
//                    }
//
//                    override fun onFailed() {
//                        isInterstitialAdLoaded = false
//                        //interstitial = InterstitialAdHelper.instance?.load(mContext!!, this)
//                    }
//
//                    override fun onClosed() {
//                        isInterstitialAdLoaded = false
//                        interstitial = InterstitialAdHelper.instance?.load(mContext!!, this)
//                        animationView?.visibility = View.GONE
//                    }
//
//                })
//
//                animationView.setOnClickListener {
//                    if (interstitial != null && isInterstitialAdLoaded) {
//                        interstitial?.show()
//                    }
//                }
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
        } else {
            try {
                animationView.visibility = View.GONE
                uptodates.visibility = View.VISIBLE
                mIVSubsriptionArrow.visibility = View.GONE
                textView13?.visibility = View.INVISIBLE
                textView14?.visibility = View.INVISIBLE
                textView15?.visibility = View.INVISIBLE
                mTVSubscribe!!.text = "You are a PRO User"
            } catch (e: Exception) {
            }
        }


    }

    private fun initListener() {
        imgBtnBack!!.setOnClickListener { v: View? -> finish() }

        rbJpg.setOnClickListener {

            if (!rbJpg.isChecked) {
                return@setOnClickListener
            }

            rbJpg.isChecked = true
            if (rbPng.isChecked) {
                rbPng.isChecked = false
            }

            mySharedPreferences!!.format = rbJpg.tag.toString().toLowerCase()
            mFormat = rbJpg.tag.toString().toLowerCase()
        }

        rbPng.setOnClickListener {

            if (!rbPng.isChecked) {
                return@setOnClickListener
            }

            rbPng.isChecked = true
            if (rbJpg.isChecked) {
                rbJpg.isChecked = false
            }

            mySharedPreferences!!.format = rbPng.tag.toString().toLowerCase()
            mFormat = rbPng.tag.toString().toLowerCase()
        }

        llJpg.setOnClickListener {

            if (rbJpg.isChecked) {
                return@setOnClickListener
            }

            rbJpg.isChecked = !rbJpg.isChecked
            if (rbPng.isChecked) {
                rbPng.isChecked = false
            }
            mySharedPreferences!!.format = rbJpg.tag.toString().toLowerCase()
            mFormat = rbJpg.tag.toString().toLowerCase()
        }

        llpng.setOnClickListener {
            if (rbPng.isChecked) {
                return@setOnClickListener
            }
            rbPng.isChecked = !rbPng.isChecked
            if (rbJpg.isChecked) {
                rbJpg.isChecked = false
            }

            mySharedPreferences!!.format = rbPng.tag.toString().toLowerCase()
            mFormat = rbPng.tag.toString().toLowerCase()
        }

        clSubscription.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }

        clInsta.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            redirectInstaAccount()
        }

        clMoreApp.setOnClickListener {
//            if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return@setOnClickListener
//            lastClickTime = SystemClock.elapsedRealtime()
//            startActivity(Intent(this, MoreAppActivity::class.java))
        }

        clShare.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            shareApp()
        }

        clRate.setOnClickListener {
            redirectInstaAccount()
        }

        clRateUs.setOnClickListener {
//            val rateDialog = RateDialogFragment(packageName)
//            rateDialog.show(supportFragmentManager, "dialog")
        }

        imgBtngift.setOnClickListener {
            newFacebookIntent()
        }
    }

    fun redirectInstaAccount() {

        val uri = Uri.parse("https://www.instagram.com/thetextart/")
        val likeIng = Intent(Intent.ACTION_VIEW, uri)
        likeIng.setPackage("com.instagram.android")
        try {
            startActivity(likeIng)
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/thetextart/")
                )
            )
        }
    }

    fun newFacebookIntent() {

        val uri = Uri.parse("fb://page/109017714568008")
        val likeIng = Intent(Intent.ACTION_VIEW, uri)
        likeIng.setPackage("com.facebook.katana")
        likeIng.data = uri
        try {
            startActivity(likeIng)
        } catch (e: Exception) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.facebook.com/thetextart")
                )
            )
        }
    }

    private fun shareApp() {
        try {
            val shareIntent =
                Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Text Art")
            var shareMessage = "\nGo with TextArt and make beautiful text image.\n\n"
            shareMessage =
                shareMessage + "https://play.google.com/store/apps/details?id=" + packageName + "\n\n"
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
            startActivity(Intent.createChooser(shareIntent, "choose one"))
        } catch (e: java.lang.Exception) { //e.toString();
        }
    }

    override fun onStart() {
        super.onStart()
        if (isSubScribe) {
            try {
                mTVSubscribe!!.text = "You are a Pro User"
                clSubscription!!.isEnabled = false
                uptodates.visibility = View.VISIBLE
                mIVSubsriptionArrow.visibility = View.GONE
                textView13?.visibility = View.INVISIBLE
                textView14?.visibility = View.INVISIBLE
                textView15?.visibility = View.INVISIBLE
            } catch (e: Exception) {
            }
        } else {
            mTVSubscribe!!.text = "Upgrade to PRO"
        }
        Log.e("s", "onStart: ")
        if (isOnline()) {
            GetVersionCode().execute()
        } else {
            textView11.text = "No Internet Connection"
        }
    }

    private fun initView() {
        imgBtnBack = findViewById(R.id.imgBtnBack)
        mTVSubscribe = findViewById(R.id.mTVSubscribe)
        mConstraintLayout = findViewById(R.id.ctFormat)
        toolbar = findViewById(R.id.mTermsToolbar)
        mIVSubsriptionArrow = findViewById(R.id.mIVSubsriptionArrow)
        clInsta = findViewById(R.id.clInsta)
        clRate = findViewById(R.id.clRate)
    }

    private fun showFormatDialog() {
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        //then we will inflate the custom alert dialog xml that we created
        val dialogView =
            LayoutInflater.from(this).inflate(R.layout.layout_format_dialog, viewGroup, false)
        //Now we need an AlertDialog.Builder object
        val builder = AlertDialog.Builder(this)
        val txtNo = dialogView.findViewById<TextView>(R.id.txtCancel)
        val radioGroup = dialogView.findViewById<RadioGroup>(R.id.radioGroup)
        if (mFormat == "jpg") (dialogView.findViewById<View>(R.id.rbJpg) as RadioButton).isChecked =
            true else (dialogView.findViewById<View>(R.id.rbPng) as RadioButton).isChecked = true
        radioGroup.setOnCheckedChangeListener { group: RadioGroup?, checkedId: Int ->
            val radioButton = dialogView.findViewById<RadioButton>(checkedId)
            mySharedPreferences!!.format = radioButton.text.toString().toLowerCase()
            mFormat = radioButton.text.toString().toLowerCase()
        }
        txtNo.setOnClickListener { v: View? -> alertDialog!!.dismiss() }
        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView)
        builder.setCancelable(true)
        //finally creating the alert dialog and displaying it
        alertDialog = builder.create()
        alertDialog!!.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        if (!isFinishing) alertDialog!!.show()
    }

    inner class GetVersionCode : AsyncTask<Unit?, String?, String?>() {

        override fun doInBackground(vararg units: Unit?): String? {
            var newVersion: String? = null
            return try {
                newVersion =
                    Jsoup.connect("https://play.google.com/store/apps/details?id=$packageName&hl=it")
                        .timeout(30000)
                        .userAgent("Mozilla/5.0 (Windows; U; WindowsNT 5.1; en-US; rv1.8.1.6) Gecko/20070725 Firefox/2.0.0.6")
                        .referrer("http://www.google.com")
                        .get()
                        .select(".hAyfc .htlgb")[7]
                        .ownText()
                newVersion
            } catch (e: Exception) {
                newVersion
            }
        }

        @SuppressLint("SetTextI18n")
        override fun onPostExecute(onlineVersion: String?) {
            super.onPostExecute(onlineVersion)
            if (onlineVersion != null && !onlineVersion.isEmpty()) {
                if (currentVersion != onlineVersion) {
                    checkForUpdate.visibility = View.VISIBLE
                    textView11.text = "Newer version available"
                    clCheckForUpdate.setOnClickListener {
                        if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return@setOnClickListener
                        lastClickTime = SystemClock.elapsedRealtime()
                        try {
                            startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("market://details?id=$packageName")
                                )
                            )
                        } catch (e: Exception) { }
                    }
                } else {
                    uptodate.visibility = View.VISIBLE
                    textView11.text = "Your version is up to date."
                }
            } else {
                uptodate.visibility = View.VISIBLE
                textView11.text = "Your version is up to date."
            }
            Log.d(
                "update",
                "Current version " + currentVersion + "playstore version " + onlineVersion
            )
        }


    }
}