package com.text.art.fancy.creator.adepter

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.HomeActivity.Companion.fontList
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.utils.click
import java.nio.file.Files.list
import java.util.ArrayList
import java.util.Collections.list

class GenerateNameAdapter(
    private val context: Context,
    private val dataList: ArrayList<String>,
    private val action: OnItemClick
): RecyclerView.Adapter<GenerateNameAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(context).inflate(R.layout.rv_generate_name_list, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        try {
            holder.txtValue.typeface = Typeface.createFromAsset(context.assets, "${Constants.FontFolder}/${fontList[position]}")
        } catch (e: Exception) { holder.txtValue.typeface = Typeface.createFromAsset(context.assets, "fonts/Default.ttf") }
        holder.txtValue.text = dataList[position]
        Log.d("GenerateNameAdapter", "initData: rv ${dataList[position]}")
        holder.imgCopy.click {
            action.onItemClick(position, dataList[position])
        }
        holder.imgEdit.click {
            action.openEditLayout(position, dataList[position])
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }


    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var txtValue: TextView = itemView.findViewById(R.id.txtValue)
        var imgCopy: ImageView = itemView.findViewById(R.id.imgCopy)
        var imgEdit: ImageView = itemView.findViewById(R.id.imgEdit)
    }

    interface OnItemClick {
        fun onItemClick(position: Int, text: String)
        fun openEditLayout(position: Int, text: String)
    }

}

