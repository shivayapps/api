package com.text.art.fancy.creator.model

import android.content.res.AssetFileDescriptor
import android.net.Uri
import java.io.File

data class LottieMusic(val musicName: String, val musicPath: String, val musicDuration: Int, val musicSize: Float)
