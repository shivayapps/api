package com.text.art.fancy.creator.activitys

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.*
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.text.art.fancy.creator.lottievideorendering.utils.JsonUtils
import com.text.art.fancy.creator.R

import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.interfaces.broadcastReceivers
import com.text.art.fancy.creator.model.LogoData
import com.text.art.fancy.creator.newapi.data.ApiHelper
import com.text.art.fancy.creator.newapi.data.MainRepository
import com.text.art.fancy.creator.newapi.data.RetrofitBuilder.apiServiceNew
import com.text.art.fancy.creator.newapi.model.DataItem
import com.text.art.fancy.creator.receivers.ConnectionReceiver
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.utils.*
//import com.github.demono.AutoScrollViewPager
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.coroutines.*
import org.jetbrains.anko.backgroundDrawable
import retrofit2.Call
import retrofit2.Callback
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : AppCompatActivity(), broadcastReceivers {

    private var isConnected = false
//    private var adsLayout: ConstraintLayout? = null
//    private var premiumUser: ConstraintLayout? = null
//    private var imgSetting: ImageView? = null
//    private var premiumUserImg: ImageView? = null

//    private lateinit var mAnimation: ConstraintLayout
//    private lateinit var mCreation: ConstraintLayout
//    private lateinit var imgGenerateName: ImageView
//    private lateinit var imgGenerateLogo: ImageView

    private var isClose = false
    private var isMyCreation = false

    private var nativeExitDialog: BottomSheetDialog? = null

    private var sharedPreferences: SharedPreferences? = null
    private var isBack = false
    private var isStart = ""
    private var mIsSubScribe: Boolean = false
    //private var exitDialogFragment: ExitDialogFragment? = null
    private var dataImage: ArrayList<Int>? = ArrayList()
    private var currentVersion: String? = null
//    private var viewPagers: AutoScrollViewPager? = null
    private var dialog: Dialog? = null
    private var dialogExit: Dialog? = null
    private var mBgDrawable: Drawable? = null
    private var lastClickTime = 0L
    private var adFailToLoad = false

    //TODO Network Receiver
    var intentFilter: IntentFilter? = null
    var networkReceiver: ConnectionReceiver? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        networkReceiver = ConnectionReceiver(this)
        intentFilter = IntentFilter("com.text.art.fancy.creator")

        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        Log.e(TAG, "onCreate: $mIsSubScribe")
//        viewPagers = findViewById(R.id.viewPagers)

        /*FirebaseInstallations.getInstance().id.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                Log.d("Installations", "Installation ID: " + task.result)
            } else {
                Log.d("Installations", "Unable to get Installation ID")
            }
        }*/

        //TODO Make Test Crash
        /*Button(this).also { btn ->
            val testCrash = "Test Crash For ${BuildConfig.VERSION_NAME}"
            btn.text = testCrash
            btn.setOnClickListener { throw RuntimeException(testCrash) }
            addContentView(btn, ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        }*/
        bindCallbacks()
        bindAction()

        hideSystemUI()
        initListener()
        initView()
        initData()
        initAction()
        setBGExitDialog()
        setAutoScrollAds()
        newExitDialog()


        if (mIsSubScribe) {
            premiumUserImg!!.show()
            adsLayout!!.hide()
            cardOfflineSlide!!.hide()
//            viewPagers!!.hide()
        }
    }

    private fun loadNewApiData() {
        lifecycleScope.launch {
            withContext(Dispatchers.IO){
                if (allCategory.isEmpty()){
                    callHomeApi(this@HomeActivity)
                }
            }
        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun loadData() {
        GlobalScope.launch {
            withContext(Dispatchers.IO) {
                val apiInterface = APIClient.getClient().create(APIInterface::class.java)
                val call = apiInterface.parameterList
                call.enqueue(object : Callback<Response> {
                    override fun onResponse(
                        call: Call<Response>,
                        response: retrofit2.Response<Response>,
                    ) {
                        if (response.isSuccessful && response.body()?.parameters != null) {
                            response.body()!!.parameters.filterIndexed { _, parametersItem ->
                                if (parametersItem.name == "Background" || parametersItem.id == 439) {
                                    BGActivity.bgAllArray.clear()
                                    parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                        BGActivity.bgAllArray.add(categoryParametersItem)
                                        true
                                    }
                                    BGActivity.isBGDataLoaded = true
                                }
                                if (parametersItem.name == "Sticker" || parametersItem.id == 449) {
                                    StickerActivity.stickerAllArray.clear()
                                    parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                        StickerActivity.stickerAllArray.add(categoryParametersItem)
                                        true
                                    }
                                    StickerActivity.isStickerDataLoaded = true
                                }
                                if (parametersItem.name == "Frames" || parametersItem.id == 451) {
                                    FrameActivity.frameAllArray.clear()
                                    parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                        FrameActivity.frameAllArray.add(categoryParametersItem)
                                        true
                                    }
                                    FrameActivity.isFrameDataLoaded = true
                                }
                                if (parametersItem.name == "Combo" || parametersItem.id == 785) {
                                    ComboActivity.comboArray.clear()
                                    parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                        ComboActivity.comboArray.add(categoryParametersItem)
                                        true
                                    }
                                    ComboActivity.isComboDataLoaded = true
                                }
                                /*if (parametersItem.name == "Logo" || parametersItem.id == 801){
                                    GenerateLogoActivity.logoAllArray.clear()
                                    parametersItem.categoryParameters.filterIndexed { _, allChild ->
                                        Log.d(TAG, "onResponse: LOGO $allChild")
                                        GenerateLogoActivity.logoAllArray.add(Logo(allChild.thumbImage, allChild.image, allChild.name))
                                        true
                                    }
                                }*/
                                if (parametersItem.name == "Animation" || parametersItem.id == 770) {
                                    AddAnimationActivity.animationAllArray.clear()
                                    parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                        AddAnimationActivity.animationAllArray.add(
                                            categoryParametersItem)
                                        true
                                    }
                                    AddAnimationActivity.isAnimDataLoaded = true
                                }
                                true
                            }
                        } else {
                            BGActivity.isBGDataLoaded = false
                            StickerActivity.isStickerDataLoaded = false
                            FrameActivity.isFrameDataLoaded = false
                            ComboActivity.isComboDataLoaded = false
                            AddAnimationActivity.isAnimDataLoaded = false
                        }
                    }

                    override fun onFailure(call: Call<Response>, t: Throwable) {
                        BGActivity.isBGDataLoaded = false
                        StickerActivity.isStickerDataLoaded = false
                        FrameActivity.isFrameDataLoaded = false
                        ComboActivity.isComboDataLoaded = false
                        AddAnimationActivity.isAnimDataLoaded = false
                    }
                })
            }
        }

        if (MySharedPref(this).lastDownloadDate!!.isEmpty() ||
            SimpleDateFormat("ddMMyyyy").format(Date()) > MySharedPref(this).lastDownloadDate!!
        ) {
            MySharedPref(this).lastDownloadDate = SimpleDateFormat("ddMMyyyy").format(Date()).toString()
            //TODO Download File From Server
            Log.d(TAG, "loadData: DATA TODAY DATE Empty Download Started")
        }

//        JsonUtils.getLogoData(this@HomeActivity, "logo.json", logoCategory, logoArray)
        Log.d(TAG, "loadData: size of all Logo data ${logoArray.size}")
    }

    private fun initData() {
        fontList = assets.list(Constants.FontFolder)!!
    }

    private fun setMoreOrSetting() {
        if (mIsSubScribe) {
            try {
                clAnimation?.tag = "Setting"
//                textView20.text = "Setting"
//                imageView14.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_setting))
            } catch (e: Exception) { }
        } else {
            try {
                clAnimation?.tag = "Setting"
//                textView20.text = "More"
//                imageView14.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.shopping_bag))
            } catch (e: Exception) {
            }
        }
    }

    private fun setAutoScrollAds() {
        dataImage!!.clear()
        dataImage!!.add(R.drawable.name_photo_offline)
        dataImage!!.add(R.drawable.kriadl_offline_ads)

//        val mAdapter =
//            MyAdapter(dataImage!!, this)
//        viewPagers!!.adapter = mAdapter
//        viewPagers!!.startAutoScroll()
    }

//    override fun bannerClicked(adsType: Int) {
//        if (adsType == 0) {
//            try {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("market://details?id=com.name.photo.birthday.cake.quotes.frame.editor")
//                    ), 100
//                )
//            } catch (anfe: ActivityNotFoundException) {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("https://play.google.com/store/apps/details?id=com.name.photo.birthday.cake.quotes.frame.editor")
//                    ), 100
//                )
//            }
//        } else {
//            try {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("market://details?id=com.graphic.design.digital.businessadsmaker")
//                    ), 100
//                )
//            } catch (anfe: ActivityNotFoundException) {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("https://play.google.com/store/apps/details?id=com.graphic.design.digital.businessadsmaker")
//                    ), 100
//                )
//            }
//        }

//    }

    private fun setBGExitDialog() {
        BitmapBlurTask().execute()
    }

    inner class BitmapBlurTask : AsyncTask<Void?, Void?, Void?>() {
        override fun doInBackground(vararg p0: Void?): Void? {
            Log.d(TAG, "doInBackground: ")
            Glide.with(this@HomeActivity).asBitmap().load(R.drawable.ic_dashbord_new)
                .into(object : CustomTarget<Bitmap?>() {

                    override fun onLoadCleared(placeholder: Drawable?) {}

                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap?>?,
                    ) {
//                        val bmp: Bitmap = BlurBuilder.blur(this@HomeActivity, resource)
//                        Helper.mDrawable = BitmapDrawable(resources, bmp)
//                        mBgDrawable = BitmapDrawable(resources, bmp)
                    }
                })

            Log.d(TAG, "doInBackground: ")
            return null
        }
    }

    /*private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }*/

    fun redirectInstaAccount() {
        val uri = Uri.parse("https://www.instagram.com/thetextart/")
        val likeIng = Intent(Intent.ACTION_VIEW, uri)
        likeIng.setPackage("com.instagram.android")
        try {
            startActivity(likeIng)
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/thetextart/")
                )
            )
        }
    }

    private fun initAction() {
        //Glide.with(context).load(R.drawable.ic_shape).placeholder(R.drawable.ic_shape).into(imageView12)

        if (!mIsSubScribe) {
            sharedPreferences = getSharedPreferences("data", Context.MODE_PRIVATE)

            cardOfflineSlide.visibility = View.GONE
//            viewPagers!!.visibility = View.VISIBLE


            /*if (AdsHelper.isTest) {
                getString(R.string.fb_native1)
            }else{
                ReferenceClass().getKeys("f_n1")
            }*/

//            cardOfflineSlide.visibility = View.VISIBLE
//            setAutoScrollAds()
//            loadNativeSh()
//            FacebookNativeAdvancehelper.loadNative(this, native_ad_container, id) {
//                if (it == 1) {
//                    NativeAdvanceHelper.loadLargeAd(this, fl_adplaceholder) {
//                        if (it == 0) {
//                            cardOfflineSlide.visibility = View.VISIBLE
//                            viewPagers!!.visibility = View.GONE
//                        }
//                    }
//                } else {
//                    cardOfflineSlide.visibility = View.VISIBLE
//                    viewPagers!!.visibility = View.GONE
//                }
//            }

        } else {
//            native_ad_container.visibility = View.GONE
//            cardOfflineSlide.visibility = View.GONE
//            viewPagers!!.visibility = View.GONE
        }


        try {
            currentVersion = packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        }
        //GetVersionCode().execute()
    }

    private fun isNetworkConnected(): Boolean {
        var cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        return cm.activeNetworkInfo != null && cm!!.activeNetworkInfo!!.isConnected
    }

    private fun loadNativeSh() {

        if (isOnline()) {
            try {
                findViewById<FrameLayout>(R.id.fl_adplaceholder).show()
                NativeAdvancedModelHelper(this@HomeActivity).loadNativeAdvancedAd(NativeAdsSize.Big,findViewById(R.id.fl_adplaceholder))
            } catch (e: Exception) {
            }
        } else {
            findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
            cardOfflineSlide.visibility = View.GONE
//            viewPagers!!.visibility = View.VISIBLE
        }

    }

    private fun initListener() {
        clCreate.setOnClickListener {

            if (SystemClock.elapsedRealtime() - lastClickTime < 500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()

            isStart = "Start"
            if (checkForPermission()) {
                startActivity(Intent(this@HomeActivity, AddTextActivity1::class.java))
            } else {
                requestPermissions()
            }
        }
        clCreation.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()

            isStart = "Creation"
            if (checkForPermission()) {
                openMyCreation()
            } else {
                requestPermissions()
            }
        }
        clAnimation.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()


            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.M){
                showToast("You're device is not compactible with animation")
                return@setOnClickListener
            }

            isStart = "Animation"
            if (checkForPermission())
                openAnimation()
            else
                requestPermissions()
        }
        imgSetting!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            if (clAnimation.tag == "Setting") {
                startActivity(Intent(this@HomeActivity, SettingActivity::class.java))
            } else {
                startActivity(Intent(this, SettingActivity::class.java))
            }
        }
        imgGenerateName.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            startActivity(Intent(this, GenerateNameActivity::class.java))
        }
        imgGenerateLogo.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()

            isStart = "Logo"
            if (checkForPermission()) {
                openGenerateLogo()
            } else {
                requestPermissions()
            }
        }
    }

    private fun openGenerateLogo() {
        if (isOnline()) {
            runBlocking {
                val job = launch {
                    logoCategory.clear()
                    logoArray.clear()
                    JsonUtils.getLogoData(this@HomeActivity, "logo.json", logoCategory, logoArray)
                }
                job.invokeOnCompletion {
                    startActivity(Intent(this@HomeActivity, GenerateLogoActivity::class.java))
                }
            }
        } else
            showToast(resources.getString(R.string.no_internet_connection))
    }

    private fun openAnimation() {
        val it = Intent(this@HomeActivity, AddAnimationActivity::class.java)
        startActivity(it)
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ),
            1001
        )
    }

    override fun onStart() {
        super.onStart()
        isBack = false
        registerReceiver(networkReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
        if (nativeExitDialog != null){
            nativeExitDialog?.dismiss()
        }
    }

    private fun openMyCreation() {
        isMyCreation = true
        isClose = false
        if (mIsSubScribe) {
            val it = Intent(this@HomeActivity, MyCreationMixActivity::class.java)
            startActivity(it)
        } else {
            isShowInterstitialAd() {
                val it = Intent(this@HomeActivity, MyCreationMixActivity::class.java)
                startActivity(it)
            }
        }
    }

    @SuppressLint("ObsoleteSdkInt", "InlinedApi")
    private fun exitDialog() {

//        dialog = Dialog(this@HomeActivity,R.style.DialogTheme)
//        dialog!!.setContentView(R.layout.activity_exit)
//        dialog!!.setCancelable(false)
//
//        dialog!!.window!!.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
//                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            dialog!!.window!!.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            dialog!!.window!!.statusBarColor = Color.TRANSPARENT
//        }
//
//        dialog!!.setOnKeyListener { _, keyCode, _ ->
//            if (keyCode == KeyEvent.KEYCODE_BACK) {
//                dialog!!.dismiss()
//            }
//            false
//        }
//
//        if (InternetConnection.checkConnection(this) && !mIsSubScribe){
//            setAdsInDialog()
//        }else{
//            noAdsAvilableForExitDialog()
//        }
//
//        dialog!!.findViewById<TextView>(R.id.btnPositive).setOnClickListener {
//            startActivity(Intent(this@HomeActivity, ExitScreen::class.java))
////            finishAffinity()
//        }
//        dialog!!.findViewById<TextView>(R.id.btnNagative).setOnClickListener {
//            loadNativeSh()
//            dialog!!.dismiss()
//        }
//        dialog!!.findViewById<TextView>(R.id.btnPositiveNoAds).setOnClickListener {
//            startActivity(Intent(this@HomeActivity, ExitScreen::class.java))
//        }
//        dialog!!.findViewById<TextView>(R.id.btnNagativeNoAds).setOnClickListener {
//            loadNativeSh()
//            dialog!!.dismiss()
//        }
//
//        dialog!!.show()

//        exitDialogFragment = ExitDialogFragment(object : ExitDialogFragment.OnButtonClickListener {
//            override fun onPositive(exitDialogFragment: ExitDialogFragment?) {
//                exitDialogFragment?.dismiss()
//                if (isInterstitialAdLoaded && !mIsSubScribe && isOnline()) {
//                    Constants.isAdsShow = true
//                    interstitial!!.show()
//                } else {
                    startActivity(Intent(this@HomeActivity, ExitScreen::class.java))
//                }
//            }
//
//            override fun onNegative(exitDialogFragment: ExitDialogFragment?) {
//                exitDialogFragment?.dismiss()
//            }
//
//            override fun onDismiss() {
//                exitDialogFragment?.dismiss()
//            }
//
//        }, mIsSubScribe)
//        exitDialogFragment!!.isCancelable = false
//
//        exitDialogFragment!!.show(supportFragmentManager, "ExitDialog")

    }

//    private fun setAdsInDialog() {
//        try {
//            dialog!!.findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.VISIBLE
//            loadOfflineNativeAdvanceBigExitScreen(this,
//                dialog!!.findViewById<FrameLayout>(R.id.fl_adplaceholder)) {
//                try {
//                    if (it == 1) {
//                        dialog!!.findViewById<ConstraintLayout>(R.id.ads).visibility = View.VISIBLE
//                        dialog!!.findViewById<ConstraintLayout>(R.id.noAds).visibility = View.GONE
//                        dialog!!.findViewById<ConstraintLayout>(R.id.cardOfflineSlide).visibility =
//                            View.VISIBLE
//                    } else {
//                        noAdsAvilableForExitDialog()
//                    }
//                } catch (e: Exception) {
//                }
//            }
//        } catch (e: Exception) {
//        }
//    }

    private fun noAdsAvilableForExitDialog() {
        dialog!!.findViewById<ConstraintLayout>(R.id.exitScreenMain).backgroundDrawable =
            mBgDrawable
        dialog!!.findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
        dialog!!.findViewById<CardView>(R.id.cardOfflineSlide).visibility = View.GONE
        dialog!!.findViewById<ConstraintLayout>(R.id.ads).visibility = View.GONE
        dialog!!.findViewById<ConstraintLayout>(R.id.noAds).visibility = View.VISIBLE
    }

    private fun closeApp() {
        Handler(Looper.getMainLooper()).postDelayed({
            isClose = true
            exitDialog()
        }, 500)

//        if (mIsSubScribe) {
//
//        } else {
//            if (isInterstitialAdLoaded) {
//                Constants.isAdsShow = true
//                interstitial!!.show()
//            } else {
//                exitDialog()
//            }
//        }
    }

    private fun initView() {
//        mStart = findViewById(R.id.clCreate)
//        mCreation = findViewById(R.id.clCreation)
//        mAnimation = findViewById(R.id.clAnimation)
//        adsLayout = findViewById(R.id.adsLayout)
//        premiumUser = findViewById(R.id.premiumUser)
//        imgSetting = findViewById(R.id.imgSetting)
//        imgGenerateName = findViewById(R.id.imgGenerateName)
//        imgGenerateLogo = findViewById(R.id.imgGenerateLogo)
//        premiumUserImg = findViewById(R.id.premiumUserImg)
        //mRateUp = findViewById(R.id.ctRateUp);
    }

    protected fun getStatusBarHeight(context: Context): Int {
        var result = 0
        val resourceId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = context.resources.getDimensionPixelSize(resourceId)
        }
        return result
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }

    override fun onDestroy() {
//        NativeAdvanceHelper.onDestroy()
        super.onDestroy()
    }

    public override fun onPause() {
        if (dialog != null && dialog!!.isShowing) {
            dialog!!.dismiss()
        }
        super.onPause()
    }

    public override fun onResume() {
        super.onResume()
        registerReceiver(networkReceiver, intentFilter)
        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
//        setMoreOrSetting()

        Log.d(TAG, "onResume: $mIsSubScribe")
        if (!mIsSubScribe) {
            try {
//                newExitDialog()

//                loadNativeSh()
            } catch (e: Exception) { }

        } else {
            findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
            try {
                adsLayout!!.visibility = View.GONE
                cardOfflineSlide.visibility = View.GONE
//                viewPagers!!.visibility = View.GONE
                premiumUser!!.visibility = View.VISIBLE

            } catch (e: Exception) {
            }
        }

        /*if (mIsSubScribe){
            cardOfflineSlide.visibility = View.GONE
            viewPagers!!.visibility = View.GONE
            premiumUserImg!!.visibility = View.VISIBLE
        }*/

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray,
    ) {
        when (requestCode) {
            1001 -> {
                if (grantResults.isNotEmpty()) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            when (isStart) {
                                "Start" -> startActivity(Intent(this@HomeActivity,
                                    AddTextActivity1::class.java))
                                "Creation" -> openMyCreation()
                                "Animation" -> openAnimation()
                                "Logo" -> openGenerateLogo()
                            }
                        }, 200)
                    } else {
                        val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                            this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                        if (!showRationale) {
                            val builder = android.app.AlertDialog.Builder(this)
                            builder.setTitle("Permission Required")
                            builder.setMessage("Storage Permission are required to save Image into External Storage")
                            builder.setPositiveButton("OK") { dialog, _ ->
                                dialog.dismiss()
                                //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                                startInstalledAppDetailsActivity(this@HomeActivity)
                            }
                            builder.setNegativeButton("Cancel") { dialog, which -> dialog.dismiss() }
                            builder.create().show()
                            // user also CHECKED "never ask again"
                            // you can either enable some fall back,
                            // disable features of your app
                            // or open another dialog explaining
                            // again the permission and directing to
                            // the app setting
                        }
                    }
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    var doubleBackToExitPressedOnce = false

    override fun onBackPressed() {
        if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return
        lastClickTime = SystemClock.elapsedRealtime()

//        if (mIsSubScribe){
////            closeApp()
////            setExitDialog()
//        }else{
//            newExitDialog()
//            nativeExitDialog?.show()
//        }

        Log.d(TAG, "onBackPressed: nativeExitDialog ${nativeExitDialog?.isShowing}")
        newExitDialog()
        nativeExitDialog?.show()
        Log.d(TAG, "onBackPressed: nativeExitDialog After ${nativeExitDialog?.isShowing}")

//        exitDialog()

//        if (doubleBackToExitPressedOnce) {
////            super.onBackPressed()
//            finishAffinity()
//            return
//        }
//
//        doubleBackToExitPressedOnce = true
//        Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show()
//
//        Handler(Looper.getMainLooper()).postDelayed({ doubleBackToExitPressedOnce = false }, 2000)

    }

    private fun setExitDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setMessage("Are you sure you want to exit?")
            ?.setPositiveButton("YES"
            ) { _, _ ->
                finishAffinity()
            }
            ?.setNegativeButton("DISCARD"){ dialog, _ ->
                dialog.dismiss()
            }
            ?.setCancelable(false)

        dialogExit = builder.show().apply {
            this.window?.setGravity(Gravity.BOTTOM)
            this.window?.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun newExitDialog() {
        nativeExitDialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_dialog, null)

        val btnClose = view.findViewById<TextView>(R.id.idBtnDismiss)
        val frameAdsLayouts = view.findViewById<FrameLayout>(R.id.frameAdsLayouts)
        val viewOffline = view.findViewById<ConstraintLayout>(R.id.viewOffline)
        val viewOnline = view.findViewById<ConstraintLayout>(R.id.viewOnline)
        val btnPositive = view.findViewById<TextView>(R.id.btnPositive)
        val btnNegative = view.findViewById<TextView>(R.id.btnNegative)

        btnPositive.click {
            finishAffinity()
        }
        btnNegative.click {
            nativeExitDialog?.dismiss()
        }

        btnClose.setOnClickListener {
            nativeExitDialog!!.dismiss()
            finishAffinity()
        }

        if (isOnline() && !mIsSubScribe){
            NativeAdvancedModelHelper(this@HomeActivity).loadNativeAdvancedAd(NativeAdsSize.Medium,frameAdsLayouts)
        }else{
            viewOffline.show()
            viewOnline.hide()
        }

        nativeExitDialog!!.setCancelable(true)
        nativeExitDialog!!.setContentView(view)

        nativeExitDialog?.setOnKeyListener { dialog, keyCode, _ ->
            if ((keyCode ==  android.view.KeyEvent.KEYCODE_BACK)) {
                loadNativeSh()
                dialog.dismiss()
                return@setOnKeyListener true
            }
            else
                return@setOnKeyListener false
        }

        nativeExitDialog?.setOnDismissListener {
            loadNativeSh()
            it?.dismiss()
        }

    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(networkReceiver)
    }

    override fun onNetworkChanged(state: Boolean?) {
        if (isOnline()) {
            loadNativeSh()
        }else {
            cardOfflineSlide.hide()
//            viewPagers?.show()
            if (nativeExitDialog != null){
                nativeExitDialog?.dismiss()
            }
        }
    }

    fun bindCallbacks() {
        val connectionLiveData = ConnectionLiveData(this)
        connectionLiveData.observe(this) { isConnected ->
            isConnected?.let {
                this.isConnected = it
                if (it) {
                    if (!isOnline()) {
                        //Please connect internet
                    }else{
                        loadNewApiData()
                    }
                } else {
                    //Please connect internet
                }
            }
        }
    }

    fun bindAction() {

    }

    companion object {
        private const val TAG = "HomeActivity"
        lateinit var fontList: Array<String>
        var logoCategory = arrayListOf<String>()
        var logoArray = arrayListOf<LogoData>()
        var allCategory = arrayListOf<DataItem>()

        suspend fun callHomeApi(context: Context){
            val mainRepository = MainRepository(ApiHelper(apiServiceNew(context)))
            allCategory.clear()
            mainRepository.getTemplates()?.data?.filterIndexed { _, dataItem ->
                dataItem?.let {
                    allCategory.add(it)
                }
                true
            }
        }
    }
}