package com.text.art.fancy.creator.widgets.trimMusic

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.FrameLayout
import com.text.art.fancy.creator.R
import kotlinx.android.synthetic.main.dialog_crop_music.view.*
import kotlin.math.ceil
import kotlin.math.round

class WaveView : FrameLayout {

    companion object{
        var leftX = -1f
        var rightX = 0f
        var leftbottomX = 0f
        var rightbottomX = 0f
    }

    private var multiTouch: MultiTouchListener? = null
    private var multiTouch1: MultiTouchListener? = null

    private var mWidth = 0f
    private var limtX = 0f
    private var mTotalDuration: Long = 0L
    var model: MusicModel? = null

    var action: (String, Int) -> Unit = { _, _ ->

    }

    constructor(context: Context) : super(context) {
        initView()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        initView()
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        initView()
    }

    /*@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes) {
        initView()
    }*/

    private fun initView() {

    }

    private fun updateTouch() {
        multiTouch =
            MultiTouchListener(rightView, this, mTotalDuration, mWaveVisualizer) { ac, _ ->
                val diff = mWidth

                val diffValue = (leftView.x + leftView.width) - limtX

                model!!.startTime =
                    ceil(((diffValue * mTotalDuration) / diff).toLong() / 1000.toFloat()).toInt() * 1000.toLong()
                action(
                    ac,
                    ceil(((diffValue * mTotalDuration) / diff).toLong() / 1000.toFloat()).toInt() * 1000
                )

            }
        multiTouch?.leftBottomView = leftBottomView
        multiTouch?.rightBottomView = rightBottomView

        multiTouch1 =
            MultiTouchListener(leftView, this, mTotalDuration, mWaveVisualizer) { ac, _ ->
                val diff = mWidth
                val diffValue = rightView.x - limtX

                model!!.endTime = round(((diffValue * mTotalDuration) / diff).toLong() / 1000.toFloat()).toInt() * 1000.toLong()
                action(
                    ac,
                    model!!.startTime.toInt()
                )
            }
        multiTouch1?.leftBottomView = leftBottomView
        multiTouch1?.rightBottomView = rightBottomView

        leftView.setOnTouchListener(multiTouch)
        rightView.setOnTouchListener(multiTouch1)

    }

    fun setTotalDuration(pro: Float) {
        mTotalDuration = pro.toLong()
        multiTouch?.duration = mTotalDuration
        multiTouch1?.duration = mTotalDuration
        post {
            if (leftX == -1f) {
                leftX = leftView.x
                rightX = rightView.x
                leftbottomX = leftBottomView.x
                rightbottomX = rightBottomView.x
            }

            mWidth = rightView.x - (leftView.x + leftView.width)
            limtX = (leftView.x + leftView.width)
            updateTouch()
        }
        //mStickerView?.setTotalDuration(pro)
    }

    fun reset() {
        if(leftX != -1f) {
            var marginParams = MarginLayoutParams(leftView.layoutParams)
            marginParams.setMargins(leftX.toInt(), 0, 0, 0)
            val layoutParams = LayoutParams(marginParams)
            leftView.layoutParams = layoutParams

            marginParams = MarginLayoutParams(rightView.layoutParams)
            marginParams.setMargins(
                rightX.toInt(),
                context.resources.getDimension(R.dimen._50sdp).toInt() + context.resources.getDimension(R.dimen._20sdp).toInt(),
                0,
                0
            )

            marginParams.marginStart = rightX.toInt()
            val layoutParams1 = LayoutParams(marginParams)
            layoutParams1.gravity = Gravity.BOTTOM
            rightView.layoutParams = layoutParams1

            var params = rightBottomView.layoutParams as MarginLayoutParams
            params.setMargins(
                rightbottomX.toInt(),
                context.resources.getDimension(R.dimen._20sdp).toInt(),
                0,
                0
            )
            params.marginStart = rightbottomX.toInt()
            rightBottomView.layoutParams = LayoutParams(params)

            params = leftBottomView.layoutParams as MarginLayoutParams
            params.setMargins(
                leftbottomX.toInt(),
                context.resources.getDimension(R.dimen._20sdp).toInt(),
                0,
                0
            )
            params.marginStart = leftbottomX.toInt()
            leftBottomView.layoutParams = LayoutParams(params)

        }
    }


    fun setAudioSessionId(audioSessionId: Int) {
        mWaveVisualizer?.setAudioSessionId(audioSessionId)
    }

    fun release() {
        mWaveVisualizer?.release()
        leftbottomX = -1f
        rightbottomX = -1f
        rightX = -1f
        leftX = -1f
    }
}