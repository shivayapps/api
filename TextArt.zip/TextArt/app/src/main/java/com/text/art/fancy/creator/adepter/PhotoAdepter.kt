package com.text.art.fancy.creator.adepter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.text.art.fancy.creator.model.ImageModel
import com.text.art.fancy.creator.R
import kotlinx.android.synthetic.main.my_photo_adapter.view.*

class PhotoAdepter(
        private val mContext: Context,
        private val mList: ArrayList<ImageModel>,
        private val action: (Int) -> Unit,
        private val actionLong: () -> Unit,
        private val refersh: (Boolean) -> Unit,
         var isSelectShow: Boolean = false,
        private var isPhotoInFragment: Boolean = false
) : RecyclerView.Adapter<PhotoAdepter.MyViewHolder>() {


    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return if (!isPhotoInFragment)
            MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.my_photo_adapter, parent, false))
        else
            MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.row_image_item, parent, false))
    }

    override fun getItemCount(): Int = mList.size

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        Glide.with(mContext).load(mList[position].path).into(holder.itemView.myphotos_image!!)
        holder.itemView.myphotos_image?.setOnClickListener {
            if (!isSelectShow)
                action(position)
            else {
                holder.itemView.cbSelect.isChecked = !holder.itemView.cbSelect.isChecked
                mList[position].isSelect = holder.itemView.cbSelect.isChecked
                checkSelection()
            }
        }

        if (mList[position].isSelect) {
            holder.itemView.cbSelect.isChecked = mList[position].isSelect
        } else {
            holder.itemView.cbSelect.isChecked = false
        }

        holder.itemView.cbSelect.setOnClickListener {
            holder.itemView.cbSelect.isChecked = holder.itemView.cbSelect.isChecked
            mList[position].isSelect = holder.itemView.cbSelect.isChecked
            checkSelection()
        }

        if (isSelectShow)
            holder.itemView.cbSelect?.visibility = View.VISIBLE
        else
            holder.itemView.cbSelect?.visibility = View.GONE

        holder.itemView.myphotos_image?.setOnLongClickListener {
            mList[position].isSelect = true
            actionLong()
            isSelectShow = true
            holder.itemView.cbSelect?.visibility = View.VISIBLE
            true
        }
    }

    private fun checkSelection() {
        if (mList.filter { it.isSelect }.size == mList.size) {
            refersh(true)
        } else {
            refersh(false)
        }
    }
}