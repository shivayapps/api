package com.text.art.fancy.creator.adepter

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.shapes.Shape
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.text.art.fancy.creator.R
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.image_row.view.*
import java.util.*

class ImageAdepter : RecyclerView.Adapter<ImageAdepter.ImageViewHolder> {
    private var mContext: Context
    private var mList: ArrayList<Any>
    private var mListener: (Int) -> Unit
    private var height = 0

    var mCurrentPosition = 0

    constructor(mContext: Context, mList: ArrayList<Any>, mListener: (Int) -> Unit) {
        this.mContext = mContext
        this.mList = mList
        this.mListener = mListener
    }

    constructor(mContext: Context, mList: ArrayList<Any>, height: Int, mListener: (Int) -> Unit) {
        this.mContext = mContext
        this.mList = mList
        this.mListener = mListener
        this.height = height
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        return ImageViewHolder(LayoutInflater.from(mContext).inflate(R.layout.image_row, parent, false))
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        /* if (position == 0) {
            holder.img.setImageResource(R.drawable.ic_add_black_24dp);
            holder.img.setPadding(5,5,5,5);
        } else {*/
        /*if (height != 0) {
            holder.img.layoutParams.height = height
            holder.img.layoutParams.width = height
            holder.img.requestLayout()
        }*/
        holder.itemView.imgSelect.visibility = View.GONE
        holder.itemView.imgSelect.clearColorFilter()
        if (mCurrentPosition == position) {
            holder.itemView.imgSelect.visibility = View.VISIBLE
        }

        if (mList[position] is String) {
            Glide.with(mContext).load(mList[position]).into(holder.img)
            //holder.img.setImageBitmap((Bitmap) mList.get(position));
        } else {
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.OVAL
            //shape.setStroke(1, Color.WHITE)
            if (mList[position] as Int == Color.WHITE) {
                holder.itemView.imgSelect.setColorFilter(Color.BLACK)
            }
            shape.setColor(mList[position] as Int)
            holder.img.background = shape
        }
        //}
        holder.img.setOnClickListener {
            notifyItemChanged(mCurrentPosition)
            mListener(position)
            mCurrentPosition = position
            notifyItemChanged(mCurrentPosition)

        }
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    inner class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img: CircleImageView = itemView.findViewById(R.id.imgShow)

    }
}