package com.text.art.fancy.creator.ads

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.View
import android.widget.*
import com.text.art.fancy.creator.R
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks
import com.google.android.gms.ads.formats.MediaView
import com.google.android.gms.ads.formats.UnifiedNativeAd
import com.google.android.gms.ads.formats.UnifiedNativeAdView
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.scribble.animation.maker.video.effect.myadslibrary.utils.InternetConnection

object NativeAdvanceHelper {
    var TAG = "Ads_123"
    var nativeAd: UnifiedNativeAd? = null
    var miAdNumber = 1
    // 1. Add container in xml+
/* add this dependency in app level gradle
     * implementation 'com.google.android.gms:play-services-ads:17.2.1'
     * */
/* Add this style in styles.xml

      <style name="AppTheme.AdAttribution">
        <item name="android:layout_width">wrap_content</item>
        <item name="android:layout_height">wrap_content</item>
        <item name="android:layout_gravity">left</item>
        <item name="android:textColor">#FFFFFF</item>
        <item name="android:textSize">12sp</item>
        <item name="android:text">@string/ad_attribution</item>
        <item name="android:background">@color/colorPrimaryDark</item>
        <item name="android:width">20dp</item>
        <item name="android:height">20dp</item>
    </style>

   */
/* <FrameLayout
    android:id="@+id/fl_adplaceholder"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_centerInParent="true" />*/
// 2. Add in onCreate() method
//   NativeAdvanceHelper.loadAd(mContext, (FrameLayout) findViewById(R.id.fl_adplaceholder));
// 3. Add in onDestroy() method
//       NativeAdvanceHelper.onDestroy();
    /**
     * Creates a request for a new native ad based on the boolean parameters and calls the
     * corresponding "populate" method when one is successfully returned.
     */
    fun loadAd(
        mContext: Context,
        frameLayout: FrameLayout
    ) { /*if (!Share.isNeedToAdShow(mContext)){
            return;
        }*/
        try {
            if (!InternetConnection.checkConnection(mContext))
                return

            val interstialAdId = AppIDs().getGoogleNative()
            Log.d("InterstitialAds Native", "$interstialAdId")

            val builder: AdLoader.Builder =  AdLoader.Builder(mContext, interstialAdId)
            builder.forUnifiedNativeAd { unifiedNativeAd: UnifiedNativeAd ->
                if (nativeAd != null) {
                    nativeAd!!.destroy()
                }
                nativeAd = unifiedNativeAd
                val adView =
                    (mContext as Activity).layoutInflater.inflate(
                        R.layout.layout_native_ad, null
                    ) as UnifiedNativeAdView
                populateUnifiedNativeAdView(unifiedNativeAd, adView)
                frameLayout.removeAllViews()
                frameLayout.addView(adView)
            }
            val adLoader =
                builder.withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(errorCode: Int) {
                        Log.i(
                            TAG,
                            "on Native AdFailedToLoad: $miAdNumber  errorCode: $errorCode"
                        )
                        if (miAdNumber == 1) {
                            miAdNumber++
                        } else if (miAdNumber == 2) {
                            miAdNumber = 0
                        } else {
                            miAdNumber = 1
                        }
                        loadAd(mContext, frameLayout)
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.i(
                            TAG,
                            "on Native AdLoaded: $miAdNumber"
                        )
                        miAdNumber = 1
                    }
                }).build()
            adLoader.loadAd(AdRequest.Builder().build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadLargeAd(
        mContext: Context,
        frameLayout: FrameLayout,
        listener : (Int) -> Unit
    ) { /*if (!Share.isNeedToAdShow(mContext)){
            return;
        }*/
//check Internet
        try {
            if (!InternetConnection.checkConnection(mContext)) return
            val interstialAdId = AppIDs().getGoogleNative()
            Log.d("InterstitialAds Native", "${interstialAdId}")

            val builder: AdLoader.Builder =  AdLoader.Builder(mContext, interstialAdId)
            builder.forUnifiedNativeAd { unifiedNativeAd: UnifiedNativeAd ->
                if (nativeAd != null) {
                    nativeAd!!.destroy()
                }
                nativeAd = unifiedNativeAd
                val adView =
                    (mContext as Activity).layoutInflater.inflate(
                        R.layout.layout_native_ad, null
                    ) as UnifiedNativeAdView
                populateUnifiedNativeAdViewLarge(unifiedNativeAd, adView)
                frameLayout.removeAllViews()
                frameLayout.addView(adView)
            }
            val adLoader =
                builder.withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(errorCode: Int) {
                        Log.i(
                            TAG,
                            "on Native AdFailedToLoad: $miAdNumber  errorCode: $errorCode"
                        )
                        if (miAdNumber == 1) {
                            miAdNumber++
                        } else if (miAdNumber == 2) {
                            miAdNumber = 0
                        } else {
                            miAdNumber = 1
                        }
                        listener(1)
                        //loadAd(mContext, frameLayout)
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.i(
                            TAG,
                            "on Native AdLoaded: $miAdNumber"
                        )
                        listener(0)
                        miAdNumber = 1
                    }
                }).build()
            adLoader.loadAd(AdRequest.Builder().build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    fun loadNativeSmall(context: Context, template: TemplateView,liveView : View? = null){
        val s = AppIDs.instnace?.getGoogleNative()
        val adLoader = AdLoader.Builder(context, s)
            .forNativeAd {
                // Show the ad.
                template.visibility = View.VISIBLE
                liveView?.visibility = View.VISIBLE

                val styles =
                    NativeTemplateStyle.Builder().withMainBackgroundColor(ColorDrawable(Color.WHITE))
                        .withCallToActionTypefaceColor(Color.WHITE)
                        .withCallToActionTextSize(context.resources.getDimension(R.dimen._4ssp)).build()

                template.setStyles(styles)
                template.setNativeAd(it)

            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    // Handle the failure by logging, altering the UI, and so on.
                    Log.d(TAG, "onAdFailedToLoad: ${adError.message}")
                    try {
                        template.visibility = View.GONE
                        liveView?.visibility = View.GONE
                    } catch (e: Exception) {
                    }
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    // Methods in the NativeAdOptions.Builder class can be
                    // used here to specify individual options settings.
                    .build()
            )
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun loadAdSmall(
        mContext: Activity,
        frameLayout: FrameLayout
    ) { //        AdLoader.Builder builder = new AdLoader.Builder(this, ADMOB_AD_UNIT_ID);
/*if (!Share.isNeedToAdShow(mContext)){
            return;
        }*/
//check Internet
        try {
            if (!InternetConnection.checkConnection(mContext)) return
            val interstialAdId = AppIDs().getGoogleNative()
            Log.d("InterstitialAds Native", "${interstialAdId}")

            val builder: AdLoader.Builder =  AdLoader.Builder(mContext, interstialAdId)
            builder.forUnifiedNativeAd { unifiedNativeAd: UnifiedNativeAd ->
                if (nativeAd != null) {
                    nativeAd!!.destroy()
                }
                nativeAd = unifiedNativeAd
                val adView =
                    mContext.layoutInflater.inflate(
                        R.layout.layout_native_small, null
                    ) as UnifiedNativeAdView
                populateUnifiedNativeAdView(unifiedNativeAd, adView)
                frameLayout.removeAllViews()
                frameLayout.addView(adView)
            }
            val adLoader =
                builder.withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(errorCode: Int) {
                        Log.i(
                            TAG,
                            "on Native AdFailedToLoad: $miAdNumber  errorCode: $errorCode"
                        )
                        if (miAdNumber == 1) {
                            miAdNumber++
                        } else if (miAdNumber == 2) {
                            miAdNumber = 0
                        } else {
                            miAdNumber = 1
                        }
                        loadAdSmall(mContext, frameLayout)
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.i(
                            TAG,
                            "on Native AdLoaded: $miAdNumber"
                        )
                        miAdNumber = 1
                    }
                }).build()
            adLoader.loadAd(AdRequest.Builder().build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Populates a [UnifiedNativeAdView] object with data from a given
     * [UnifiedNativeAd].
     *
     * @param nativeAd the object containing the ad's assets
     * @param adView   the view to be populated
     */
    private fun populateUnifiedNativeAdView(
        nativeAd: UnifiedNativeAd,
        adView: UnifiedNativeAdView
    ) {
        try {
            val mediaView: MediaView = adView.findViewById(
                R.id.ad_media
            )
            val mainImageView = adView.findViewById<ImageView>(
                R.id.ad_image
            )
            val vc = nativeAd.videoController
            vc.setVideoLifecycleCallbacks(object : VideoLifecycleCallbacks() {
                override fun onVideoEnd() {
                    super.onVideoEnd()
                }
            })
            if (vc.hasVideoContent()) {
                adView.mediaView = mediaView
                mainImageView.visibility = View.GONE
            } else {
                adView.imageView = mainImageView
                mediaView.visibility = View.GONE
                val images =
                    nativeAd.images
                if (images.size != 0) {
                    mainImageView.setImageDrawable(images[0].drawable)
                }
            }
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.bodyView = adView.findViewById(R.id.ad_body)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_app_icon)
            (adView.headlineView as TextView).text = nativeAd.headline
            (adView.bodyView as TextView).text = nativeAd.body
            (adView.callToActionView as Button).text = nativeAd.callToAction
            if (nativeAd.icon == null) {
                adView.iconView.visibility = View.GONE
            } else {
                (adView.iconView as ImageView).setImageDrawable(
                    nativeAd.icon.drawable
                )
                adView.iconView.visibility = View.VISIBLE
            }
            adView.setNativeAd(nativeAd)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun populateUnifiedNativeAdViewLarge( nativeAd: UnifiedNativeAd,
                                                  adView: UnifiedNativeAdView
    ) {
        try {
            val mediaView: MediaView = adView.findViewById(
                R.id.ad_media
            )
            val mainImageView = adView.findViewById<ImageView>(
                R.id.ad_image
            )
            val vc = nativeAd.videoController
            vc.setVideoLifecycleCallbacks(object : VideoLifecycleCallbacks() {
                override fun onVideoEnd() {
                    super.onVideoEnd()
                }
            })
            if (vc.hasVideoContent()) {
                adView.mediaView = mediaView
                mainImageView.visibility = View.GONE
            } else {
                adView.imageView = mainImageView
                mediaView.visibility = View.GONE
                val images =
                    nativeAd.images
                if (images.size != 0) {
                    mainImageView.setImageDrawable(images[0].drawable)
                }
            }
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.bodyView = adView.findViewById(R.id.ad_body)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_app_icon)
            (adView.headlineView as TextView).text = nativeAd.headline
            (adView.bodyView as TextView).text = nativeAd.body
            (adView.callToActionView as Button).text = nativeAd.callToAction
            if (nativeAd.icon == null) {
                adView.iconView.visibility = View.GONE
            } else {
                (adView.iconView as ImageView).setImageDrawable(
                    nativeAd.icon.drawable
                )
                adView.iconView.visibility = View.VISIBLE
            }
            adView.setNativeAd(nativeAd)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /*private fun populateUnifiedNativeAdViewLarge(
        nativeAd: UnifiedNativeAd,
        adView: UnifiedNativeAdView
    ) { // Set the media view. Media content will be automatically populated in the media view once
// adView.setNativeAd() is called.
        try {

            val mediaView: MediaView = adView.findViewById(
                R.id.ad_media
            )
            adView.mediaView = mediaView
            // Set other ad assets.
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.bodyView = adView.findViewById(R.id.ad_body)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_app_icon)
            adView.priceView = adView.findViewById(R.id.ad_price)
            adView.starRatingView = adView.findViewById(R.id.ad_stars)
            adView.storeView = adView.findViewById(R.id.ad_store)
            adView.advertiserView = adView.findViewById(R.id.ad_advertiser)
            // The headline is guaranteed to be in every UnifiedNativeAd.
            (adView.headlineView as TextView).text = nativeAd.headline
            // These assets aren't guaranteed to be in every UnifiedNativeAd, so it's important to
// check before trying to display them.
            if (nativeAd.body == null) {
                adView.bodyView.visibility = View.INVISIBLE
            } else {
                adView.bodyView.visibility = View.VISIBLE
                (adView.bodyView as TextView).text = nativeAd.body
            }
            if (nativeAd.callToAction == null) {
                adView.callToActionView.visibility = View.INVISIBLE
            } else {
                adView.callToActionView.visibility = View.VISIBLE
                (adView.callToActionView as Button).text = nativeAd.callToAction
            }
            if (nativeAd.icon == null) {
                adView.iconView.visibility = View.GONE
            } else {
                (adView.iconView as ImageView).setImageDrawable(
                    nativeAd.icon.drawable
                )
                adView.iconView.visibility = View.VISIBLE
            }
            if (nativeAd.price == null) {
                adView.priceView.visibility = View.INVISIBLE
            } else {
                adView.priceView.visibility = View.VISIBLE
                (adView.priceView as TextView).text = nativeAd.price
            }
            if (nativeAd.store == null) {
                adView.storeView.visibility = View.INVISIBLE
            } else {
                adView.storeView.visibility = View.VISIBLE
                (adView.storeView as TextView).text = nativeAd.store
            }
            if (nativeAd.starRating == null) {
                adView.starRatingView.visibility = View.INVISIBLE
            } else {
                (adView.starRatingView as RatingBar).rating = nativeAd.starRating.toFloat()
                adView.starRatingView.visibility = View.VISIBLE
            }
            if (nativeAd.advertiser == null) {
                adView.advertiserView.visibility = View.INVISIBLE
            } else {
                (adView.advertiserView as TextView).text = nativeAd.advertiser
                adView.advertiserView.visibility = View.VISIBLE
            }
            // This method tells the Google Mobile Ads SDK that you have finished populating your
// native ad view with this native ad. The SDK will populate the adView's MediaView
// with the media content from this native ad.
            adView.setNativeAd(nativeAd)
            // Get the video controller for the ad. One will always be provided, even if the ad doesn't
// have a video asset.
            val vc = nativeAd.videoController
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }*/

    fun onDestroy() {
        if (nativeAd != null) {
            nativeAd!!.destroy()
        }
    }
}
