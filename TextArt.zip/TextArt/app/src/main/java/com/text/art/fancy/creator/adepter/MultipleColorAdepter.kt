package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.AddTextActivity1

class MultipleColorAdepter(
    var context: Context,
    var imgList: ArrayList<Int>,
    var multiColorList: ArrayList<ArrayList<Int>>,
    var listener: OnClickMultiColorListener
) : RecyclerView.Adapter<MultipleColorAdepter.MyViewHolder>() {

    interface OnClickMultiColorListener{
        fun onClickMulti(position: Int)
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtMultiColorText = itemView.findViewById<ImageView>(R.id.txtMultiColorText)
        val ViewSelectionMultiple = itemView.findViewById<ImageView>(R.id.ViewSelectionMultiple)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.multicolorlist,parent,false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return multiColorList.size
    }

    @SuppressLint("ResourceType")
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.txtMultiColorText.setImageResource(imgList[position])

        if (multiColorPosition == position) {
            holder.ViewSelectionMultiple.visibility = View.VISIBLE
            holder.ViewSelectionMultiple.setImageResource(R.drawable.black_border)
        }else{
            holder.ViewSelectionMultiple.visibility = View.INVISIBLE
        }

        holder.itemView.setOnClickListener {
            listener.onClickMulti(position)
        }
    }

    fun clickMultiColor(pos: Int){
        Log.d("TAG", "clickMultiColor: call Here")
        multiColorPosition = pos
        listener.onClickMulti(pos)
    }

    companion object{
        var multiColorPosition = -1
    }

}