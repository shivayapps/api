package com.text.art.fancy.creator.categorys.callbacks;


import com.text.art.fancy.creator.categorys.model.ImageItem;
import com.text.art.fancy.creator.categorys.parameter.CategoryParametersItem;

public interface OnRewardEarn {

    void onRewardEarn(ImageItem imageItem);

    void onRewardEarn(CategoryParametersItem imageItem);

}
