package com.text.art.fancy.creator.categorys.dialog;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.text.art.fancy.creator.R;


public class WatchVideoDialog extends DialogFragment {

    private String mTitle;
    private String mMessage, positive, negative;
    private OnButtonClickListener mListener;
    private Dialog bottomSheetDialog;
    private int titleImagel;

    public WatchVideoDialog() {

    }

    public WatchVideoDialog(String mTitle, String mMessage, String positive1, String negative1, int titleImage, OnButtonClickListener mListener) {
        this.mTitle = mTitle;
        this.mMessage = mMessage;
        this.positive = positive1;
        this.negative = negative1;
        this.mListener = mListener;
        this.titleImagel = titleImage;
    }

    public interface OnButtonClickListener {
        void onPositive(WatchVideoDialog watchVideoDialog);

        void onNegative(WatchVideoDialog watchVideoDialog);
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.materialButton);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_watch_video, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvTitle = view.findViewById(R.id.txtTitle);
        TextView tvMessgae = view.findViewById(R.id.txtMessage);


        tvMessgae.setText(mMessage);
        tvTitle.setText(mTitle);

        ((ImageView) view.findViewById(R.id.iv_dialog_logo)).setImageDrawable(getActivity().getResources().getDrawable(titleImagel));

        ((Button) view.findViewById(R.id.btnPositive)).setText(positive);
        ((Button) view.findViewById(R.id.btnNagative)).setText(negative);

        view.findViewById(R.id.btnPositive).setOnClickListener(v -> {
            mListener.onPositive(this);
        });

        view.findViewById(R.id.btnNagative).setOnClickListener(v -> {
            dismiss();
            mListener.onNegative(this);
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        bottomSheetDialog = getDialog();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        width -= width / 8;
        bottomSheetDialog.getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
    }
}