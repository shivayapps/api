package com.text.art.fancy.creator.roomdb.draft


import androidx.room.*

@Dao
interface DraftDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addDraft(draft: Draft)

    @Update
    suspend fun updateDraft(draft: Draft)

    @Query("DELETE FROM Draft WHERE preview = :path")
    fun deleteDraftRecord(path: String)

    @Query("DELETE FROM Draft WHERE id = :id")
    fun deleteDraft(id: Int)

    @Query("SELECT * FROM Draft WHERE id = :id")
    fun findDraft(id: Int?): Draft?

    @Query("SELECT * from Draft ORDER BY id DESC")
    fun readAllDraft(): List<Draft>?

    @Query("SELECT COUNT(id) FROM Draft")
    fun getCount(): Int

    @Query("SELECT preview from Draft WHERE id = :id")
    fun getOldDraftPreview(id: Int?): String

    @Query("SELECT id from Draft WHERE preview = :preview")
    fun findPreview(preview: String?): Int
}