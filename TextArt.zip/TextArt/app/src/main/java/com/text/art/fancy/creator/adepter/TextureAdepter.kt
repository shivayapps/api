package com.text.art.fancy.creator.adepter

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.comman.Constants
import kotlinx.android.synthetic.main.row_background_item.view.*

class TextureAdepter(
    private val mContext : Context,
    private val mList : ArrayList<Any>,
    private var mListVal : ArrayList<String> ,
    private val action : (Int) -> Unit
) : RecyclerView.Adapter<TextureAdepter.BackgroundHolder>() {

//    var previousPosition = -1
//    var currentPosition = -1

    inner class BackgroundHolder(itemView : View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BackgroundHolder =
        BackgroundHolder(LayoutInflater.from(mContext).inflate(R.layout.row_background_item,parent,false))

    override fun getItemCount(): Int = mList.size

    override fun onBindViewHolder(holder: BackgroundHolder, position: Int) {

        with (holder.itemView) {
            val item = mList[position]
            when {
                mListVal[position] == "1" -> {
                    imgLockPremium.visibility = View.GONE
                    imgLockPattern.visibility = View.VISIBLE
                }
                mListVal[position] == "2" -> {
                    imgLockPremium.visibility = View.VISIBLE
                    imgLockPattern.visibility = View.GONE
                }
                else -> {
                    imgLockPattern.visibility = View.GONE
                    imgLockPremium.visibility = View.GONE
                }
            }
            if (patternPosition == position ) {
                imgClick.visibility=View.VISIBLE
            }else{
                imgClick.visibility=View.GONE
            }
            Glide.with(mContext).load(item).override(50).into(object : CustomTarget<Drawable>(){
                 override fun onLoadCleared(placeholder: Drawable?) {}

                 override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                     imgBackground.setImageDrawable(resource)
                 }
            })
            imgBackground.setOnClickListener {
//                if (previousPosition == -1) {
//                    previousPosition = position
//                }else{
//                    Log.d("TAG", "onResourceReady: previousTexturePosition ${Constants.previousTexturePosition}")
//                    previousPosition = currentPosition
//                }
//                currentPosition = position
                if (mListVal[position] == "0") {
                    patternPosition = position
                }
                action(position)
            }

        }

    }

    companion object{
        var patternPosition = -1
    }

}