package com.text.art.fancy.creator.widgets.frameLayout

const val INVALID_RESOURCE_ID = -1
const val MAX_ALPHA = 255