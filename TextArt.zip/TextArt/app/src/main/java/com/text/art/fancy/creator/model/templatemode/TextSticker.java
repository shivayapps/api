package com.text.art.fancy.creator.model.templatemode;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TextSticker {

    @SerializedName("text")
    @Expose
    private String text;
    @SerializedName("fontName")
    @Expose
    private String fontName;
    @SerializedName("color")
    @Expose
    private String color;
    @SerializedName("gradientColor")
    @Expose
    private String gradientColor;
    @SerializedName("rotate")
    @Expose
    private Integer rotate;
    @SerializedName("w")
    @Expose
    private Double w;
    @SerializedName("h")
    @Expose
    private Double h;
    @SerializedName("x")
    @Expose
    private Double x;
    @SerializedName("y")
    @Expose
    private Double y;

    public String getGradientColor() {
        return gradientColor;
    }

    public void setGradientColor(String gradientColor) {
        this.gradientColor = gradientColor;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getFontName() {
        return fontName;
    }

    public void setFontName(String fontName) {
        this.fontName = fontName;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getRotate() {
        return rotate;
    }

    public void setRotate(Integer rotate) {
        this.rotate = rotate;
    }

    public Double getW() {
        return w;
    }

    public void setW(Double w) {
        this.w = w;
    }

    public Double getH() {
        return h;
    }

    public void setH(Double h) {
        this.h = h;
    }

    public Double getX() {
        return x;
    }

    public void setX(Double x) {
        this.x = x;
    }

    public Double getY() {
        return y;
    }

    public void setY(Double y) {
        this.y = y;
    }

}