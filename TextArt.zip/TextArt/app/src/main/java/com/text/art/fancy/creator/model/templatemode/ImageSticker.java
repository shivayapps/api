package com.text.art.fancy.creator.model.templatemode;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ImageSticker {

@SerializedName("icon")
@Expose
private String icon;
@SerializedName("rotate")
@Expose
private Double rotate;
@SerializedName("w")
@Expose
private Double w;
@SerializedName("h")
@Expose
private Double h;
@SerializedName("x")
@Expose
private Double x;
@SerializedName("y")
@Expose
private Double y;

public String getIcon() {
return icon;
}

public void setIcon(String icon) {
this.icon = icon;
}

public Double getRotate() {
return rotate;
}

public void setRotate(Double rotate) {
this.rotate = rotate;
}

public Double getW() {
return w;
}

public void setW(Double w) {
this.w = w;
}

public Double getH() {
return h;
}

public void setH(Double h) {
this.h = h;
}

public Double getX() {
return x;
}

public void setX(Double x) {
this.x = x;
}

public Double getY() {
return y;
}

public void setY(Double y) {
this.y = y;
}

}