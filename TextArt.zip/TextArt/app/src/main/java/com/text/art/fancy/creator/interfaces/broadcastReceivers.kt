package com.text.art.fancy.creator.interfaces

interface broadcastReceivers {
    fun onNetworkChanged(state: Boolean?)
}