package com.text.art.fancy.creator.lottievideorendering.utils

import android.annotation.SuppressLint
import android.content.Context
import android.os.Looper
import android.util.Log
import com.airbnb.lottie.LottieComposition
import com.text.art.fancy.creator.model.*
import org.json.JSONException
import org.json.JSONObject
import java.io.*
import java.nio.charset.Charset


object JsonUtils {
    private var TAG = "JsonUtils"

    @SuppressLint("RestrictedApi")
    fun getJsonData(
        context: Context,
        lottieFile: String,
        composition: LottieComposition,
        lottieJson: ArrayList<LottieData>,
        isFirstTime: Boolean,
    ) {

        lottieJson.clear()

        var textList = ArrayList<TextItem?>()
        var imageList = ArrayList<ImageItem?>()

        var width : Int?=null
        var height: Int?=null

        try {
            val jsonObject = JSONObject(readFromCache(context, lottieFile)) //JSON FILE READING
            val jsonLayerArray = jsonObject.getJSONArray("layers")
            var detectUniqueText = ""
            var mIsFirstData = true

            width = jsonObject.get("w") as Int?
            height = jsonObject.get("h") as Int?

            if (isFirstTime){
                android.os.Handler(Looper.getMainLooper()).postDelayed( {

                    for (i in 0 until jsonLayerArray.length()) {

                        //Getting JSON [LAYER] object from LAYERS Array
                        val jsonLayerObject = jsonLayerArray.getJSONObject(i)
                        val layerType = composition.layers[i].layerType.toString() // LAYER TYPE

                        if (layerType == "IMAGE") {
                            //Getting refID of Image Layer and Storing in that Object
                            val refId = jsonLayerObject.get("refId")
                            val correspondingBitmap = composition.images[refId.toString()]!!.bitmap
                            Log.d(TAG, "refId: ${refId}")
                            Log.d(TAG, "Composition.images.size: ${composition.images.size}")
                            Log.d(TAG, "Composition.images.size has Bitmap: ${composition.images.get(refId)!!.hasBitmap()}")
                            Log.d(TAG, "Composition.images Bitmap: $correspondingBitmap")
                            imageList.add(ImageItem(refId.toString(), correspondingBitmap))
                        }

                    }
//                    isFirstTime = false
                }, 7000)
            }



            for (i in 0 until jsonLayerArray.length()) {

                //Getting JSON [LAYER] object from LAYERS Array
                val jsonLayerObject = jsonLayerArray.getJSONObject(i)
                val layerType = composition.layers[i].layerType.toString() // LAYER TYPE

                if (!isFirstTime){
                    if (layerType == "IMAGE") {
                        //Getting refID of Image Layer and Storing in that Object
                        val refId = jsonLayerObject.get("refId")
                        val correspondingBitmap = composition.images[refId.toString()]!!.bitmap
                        Log.d(TAG, "refId: ${refId}")
                        Log.d(TAG, "Composition.images.size: ${composition.images.size}")
                        Log.d(TAG, "Composition.images.size has Bitmap: ${composition.images.get(refId)!!.hasBitmap()}")
                        Log.d(TAG, "Composition.images Bitmap: $correspondingBitmap")
                        imageList.add(ImageItem(refId.toString(), correspondingBitmap))
                    }
                }

                if (layerType == "TEXT") {
                    val sJsonObject =
                        jsonLayerObject.getJSONObject("t").getJSONObject("d").getJSONArray("k")
                            .getJSONObject(0).getJSONObject("s")

                    val textId = sJsonObject.getString("t")
                    if (mIsFirstData){

                        textList.add(TextItem(textId, null,textId.length))
                        mIsFirstData = false
                        detectUniqueText = textId
                    }else{
                        if (detectUniqueText != textId){
                            textList.add(TextItem(textId, null,textId.length))
                        }
                        detectUniqueText = textId
                    }

                }
            }

        } catch (e: JSONException) {
            e.printStackTrace()
        }

        lottieJson.add(LottieData(width,height,Layertype(imageList,textList)))

        Log.d(TAG, "getJsonData: $lottieJson")
    }

    fun getLogoData(
        context: Context,
        lottieFile: String,
        logoCategory: ArrayList<String>,
        logoJson: ArrayList<LogoData>,
    ){
        try {
            val jsonObject = JSONObject(readFromAssets(context = context, lottieFile = lottieFile)) //JSON FILE READING
            val category = jsonObject.names()

            for (cat in 0 until category.length()) {
                logoCategory.add(category[cat].toString())
                val jsonLogoArray = jsonObject.getJSONArray(category[cat].toString())
                for (i in 0 until jsonLogoArray.length()) {
                    val jsonObj = jsonLogoArray.getJSONObject(i)
                    val colorObj = jsonLogoArray.getJSONObject(i).getJSONObject("color")
                    logoJson.add(LogoData(
                        jsonObj.getInt   ("id"),
                        jsonObj.getString("logo"),
                        jsonObj.getString("tag"),
                        jsonObj.getDouble("verticalBias"),
                        jsonObj.getDouble("x"),
                        jsonObj.getDouble("y"),
                        jsonObj.getInt   ("rotation"),
                        jsonObj.getInt   ("stroke"),
                        jsonObj.getString("font-family"),
                        Color(
                            colorObj.getString("text"),
                            colorObj.getString("border"),
                            colorObj.getString("bg")
                        )
                    ))

                    /*Log.d(TAG, "getLogoData: Id is   ${jsonObj.getInt("id")}")
                    Log.d(TAG, "getLogoData: Logo is ${jsonObj.getString("logo")}")
                    Log.d(TAG, "getLogoData: Tag is  ${jsonObj.getString("tag")}")
                    Log.d(TAG, "getLogoData: vB is   ${jsonObj.getDouble("verticalBias")}")
                    Log.d(TAG, "getLogoData: x is    ${jsonObj.getDouble("x")}")
                    Log.d(TAG, "getLogoData: y is    ${jsonObj.getDouble("y")}")
                    Log.d(TAG, "getLogoData: F-F is  ${jsonObj.getString("font-family")}")
                    Log.d(TAG, "getLogoData: text is ${colorObj.getString("text")}")
                    Log.d(TAG, "getLogoData: border is${colorObj.getString("border")}")
                    Log.d(TAG, "getLogoData: bg is   ${colorObj.getString("bg")}")
                    Log.d(TAG, "getLogoData: =======================================")*/
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
            Log.d(TAG, "getLogoData: Error ${e.printStackTrace()}")
        }


    }

    private fun readFromCache(context: Context, lottieFile: String): String? {
        var strJson = ""
        val jsonPath = "${context.cacheDir}/$lottieFile"
        if(File(jsonPath).exists()){
            try {
                val f = File("${context.cacheDir}/$lottieFile")
                if (!f.exists())
                    return null
                val `is` = FileInputStream(f)
                val size: Int = `is`.available()
                val buffer = ByteArray(size)
                `is`.read(buffer)
                `is`.close()
                strJson = String(buffer)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        return strJson
    }

    private fun readFromAssets(context: Context, lottieFile: String): String? {
        val jsonString = try {
            val `is` = context.assets.open(lottieFile)
            val size = `is`.available()
            val buffer = ByteArray(size)
            `is`.read(buffer)
            `is`.close()
            String(buffer, Charset.forName("UTF-8"))
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        }
        return jsonString
    }
}