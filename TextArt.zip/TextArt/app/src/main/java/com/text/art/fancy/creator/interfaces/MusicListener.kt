package com.text.art.fancy.creator.interfaces

import android.net.Uri
import com.text.art.fancy.creator.adepter.LottieMusicAdapter

interface MusicListener {
//    fun onMusicClick(pos: Int, musicUri: Uri?=null, trimMusic: String ?= null, trimMusicName: String ?= null)
    fun onMusicClick(from:LottieMusicAdapter.MusicType, pos: Int, musicUri: Uri?=null, trimMusic: String ?= null, trimMusicName: String ?= null)
}