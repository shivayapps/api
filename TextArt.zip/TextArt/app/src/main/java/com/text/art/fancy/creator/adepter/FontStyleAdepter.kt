package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

import com.airbnb.lottie.LottieAnimationView

import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.AddTextActivity1
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.comman.Constants.downloadedFont
import com.text.art.fancy.creator.utils.isOnline
import java.lang.Exception


class FontStyleAdepter(
    var addTextActivity1: AddTextActivity1,
    var mFontList: ArrayList<String>,
    var mFontVal: ArrayList<String>,
    var mPrimeFontVal: ArrayList<String>,
    var isDownloadedOrNot: ArrayList<String>,
    var fontThumbImg: ArrayList<String>,
    var fontInterface: setOnItemClickListenerFont
) : RecyclerView.Adapter<FontStyleAdepter.MyViewHolder>() {

    val TAG = "FontStyleAdepter"

    interface setOnItemClickListenerFont {
        fun OnItemClickedFont(position: Int, myholder: MyViewHolder)
        fun OnItemClickedFont(position: Int)
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var parentLayout: RelativeLayout = itemView.findViewById(R.id.parentLayout)
        var selectLayout: CardView = itemView.findViewById(R.id.selectLayout)
//        var mProgressBar: ProgressBar = itemView.findViewById(R.id.mProgressbar)
//        var mProgressBar: CircularProgressIndicator = itemView.findViewById(R.id.mProgressbar)
        val txtFont: TextView = itemView.findViewById(R.id.txtFont)
        val imgMoreAPI: LottieAnimationView = itemView.findViewById(R.id.imgMoreAPI)
        val selctedViewImg: ImageView = itemView.findViewById(R.id.viewSelectFont)
        val mFontLock: ImageView = itemView.findViewById(R.id.mFontLock)
        val mFontPrime: ImageView = itemView.findViewById(R.id.mFontPrime)
        val mDownloadBtn: ImageView = itemView.findViewById(R.id.viewDownload)
        val txtFontThumb: ImageView = itemView.findViewById(R.id.txtFontThumb)
        val mDownloadText = itemView.findViewById<TextView>(R.id.mTVDownload)!!
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val view =
            LayoutInflater.from(addTextActivity1).inflate(R.layout.font_item_text, parent, false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mFontList.size
    }

    @SuppressLint("CheckResult")
    override fun onBindViewHolder(myholder: MyViewHolder, i: Int) {
        myholder.setIsRecyclable(false)
        if (mPrimeFontVal[i] == "1") {
            myholder.mFontPrime.visibility = View.VISIBLE
        } else {
            myholder.mFontPrime.visibility = View.INVISIBLE
        }
        myholder.imgMoreAPI.visibility = View.GONE

        if (mFontVal[i] == "1") {
            myholder.mFontLock.visibility = View.VISIBLE
        } else {
            myholder.mFontLock.visibility = View.INVISIBLE
        }
        myholder.mDownloadBtn.visibility = View.GONE

        myholder.itemView.setOnClickListener {
            if (isDownloadedOrNot[i] == "1"){
                //Font is downloaded Perform Action
                fontInterface.OnItemClickedFont(i, myholder)
            }else{
                //Font Is Not Downloaded
                if (addTextActivity1.isOnline()) {
                    fontInterface.OnItemClickedFont(i, myholder)
                } else {
                    Toast.makeText(addTextActivity1, "Please check internet connection.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }
            fontPosition = i
        }


        myholder.txtFont.visibility = View.VISIBLE
        myholder.imgMoreAPI.visibility = View.GONE
        var typeface: Typeface? = null

            if (mFontList[i].contains("${Constants.FontFolder}")) {
                try {
                    typeface = Typeface.createFromAsset(
                        addTextActivity1.applicationContext.assets,
                        mFontList[i]
                    )
                }catch (e: Exception){}
            } else {
                if (isDownloadedOrNot[i] == "1"){
                    myholder.txtFontThumb.visibility = View.GONE
                    myholder.txtFont.visibility = View.VISIBLE
                    var dFontPath = "${addTextActivity1.cacheDir}/$downloadedFont/${mFontList[i]}"
                    try {
                        typeface = Typeface.createFromFile(dFontPath)
                    } catch (e: Exception) { }
                }else{
                    myholder.txtFont.visibility = View.GONE
                    val requestOptions = RequestOptions()
                    requestOptions.diskCacheStrategy(DiskCacheStrategy.ALL)
                    myholder.txtFontThumb.visibility = View.VISIBLE
                    Glide.with(addTextActivity1).load(fontThumbImg[i]).apply(requestOptions).into(myholder.txtFontThumb)
                }
            }
        if (typeface != null)
            myholder.txtFont.typeface = typeface

        Log.d(TAG, "onBindViewHolder: fontPosition $fontPosition")
        if (fontPosition == i && myholder.mFontLock.visibility == View.INVISIBLE && myholder.mFontPrime.visibility == View.INVISIBLE) {
            myholder.selctedViewImg.visibility = View.VISIBLE
        } else {
            myholder.selctedViewImg.visibility = View.INVISIBLE
        }

    }

    fun clickFontStyle(pos: Int?=null){
        fontInterface.OnItemClickedFont(pos!!)
    }

    companion object{
        var fontPosition = -1
    }

}