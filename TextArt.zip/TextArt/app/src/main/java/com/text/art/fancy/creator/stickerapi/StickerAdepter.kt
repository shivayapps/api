package com.text.art.fancy.creator.stickerapi

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.text.art.fancy.creator.stickerapi.StickerDataFragment.Companion.newInstance
import com.text.art.fancy.creator.newapi.model.SubCategory

class StickerAdepter(
    mFragment: FragmentActivity,
    private val categoryList: ArrayList<SubCategory>,
    val total: Int
) : FragmentStateAdapter(mFragment) {

    override fun getItemCount(): Int {
        return total
    }

    override fun createFragment(position: Int): Fragment {
        return newInstance(categoryList[position].id ?: 0)
    }

}