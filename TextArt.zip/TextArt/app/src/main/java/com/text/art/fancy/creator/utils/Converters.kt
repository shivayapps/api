package com.text.art.fancy.creator.utils

import androidx.room.TypeConverter
import com.google.gson.Gson
import sticker.view.dixitgabani.model.StickerModel

class Converters {

    @TypeConverter
    public fun listToJsonString(value: List<StickerModel>?): String = Gson().toJson(value)

    @TypeConverter
    public fun jsonStringToList(value: String) = Gson().fromJson(value, Array<StickerModel>::class.java).toList()
}