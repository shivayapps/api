package com.text.art.fancy.creator.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import java.io.Serializable

data class LogoData(

	@field:SerializedName("id")
	val id: Int? = null,

	@field:SerializedName("logo")
	val logo: String? = null,

	@field:SerializedName("tag")
	val tag: String,

	@field:SerializedName("verticalBias")
	val verticalBias: Double,

	@field:SerializedName("x")
	val x: Double,

	@field:SerializedName("y")
	val y: Double,

	@field:SerializedName("rotation")
	val rotation: Int,

	@field:SerializedName("stroke")
	val stroke: Int,

	@field:SerializedName("font-family")
	val fontFamily: String,

	@field:SerializedName("color")
	val color: Color

) : Serializable

data class Color(

	@field:SerializedName("text")
	val text: String = "#FFFFFF",

	@field:SerializedName("border")
	val border: String,

	@field:SerializedName("bg")
	val bg: String

) : Serializable
