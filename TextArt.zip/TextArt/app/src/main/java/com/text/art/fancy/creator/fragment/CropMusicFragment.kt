package com.text.art.fancy.creator.fragment

import android.Manifest
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.*
import android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.fragment.app.DialogFragment
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.EditAnimationActivity.Companion.lottieDuration
import com.text.art.fancy.creator.adepter.LottieMusicAdapter
import com.text.art.fancy.creator.adepter.LottieMusicAdapter.Companion.selectedAudioPosition
import com.text.art.fancy.creator.adepter.LottieMusicAdapter.Companion.selectedMusicPosition
import com.text.art.fancy.creator.interfaces.MusicListener
import com.text.art.fancy.creator.utils.*
import com.text.art.fancy.creator.widgets.AudioPlayer
import com.text.art.fancy.creator.widgets.trimMusic.MusicModel
import com.text.art.fancy.creator.widgets.trimMusic.MusicUitlis
import com.text.art.fancy.creator.widgets.trimMusic.SoundFile
import com.text.art.fancy.creator.widgets.trimMusic.WaveView
import com.google.android.material.slider.RangeSlider
import kotlinx.android.synthetic.main.dialog_crop_music.*
import org.jetbrains.anko.support.v4.runOnUiThread
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.round

class CropMusicFragment : DialogFragment() {

    private lateinit var musicIcon: ImageView
    private lateinit var btnCancel: ImageView
    private lateinit var txtMusicName: TextView
    private lateinit var txtDuration: TextView
    private lateinit var btnTrim: TextView
    private lateinit var rightBottomView: View
    private lateinit var leftBottomView: View
    private lateinit var progressLine: View

    private lateinit var seekTrim: RangeSlider
    private lateinit var wave: WaveView
    private var mUri: Uri? = null
    private var isPlaying: Boolean = false
    private var isInProgress = true
    private var musicName = "Music"
    private var musicPosition = -1
    private var mPermissionGranted = false
    private var isBackEnable = false
    private var mAudioPlayer: AudioPlayer? = null
    private var mSoundFile: SoundFile? = null
    private var mThread: Thread? = null
    private var mHandler: Handler? = null
    private var stopAudio: Handler? = null
    private var mRunning: Runnable? = null
    private var audioRunning: Runnable? = null
    private var mModel: MusicModel? = null
    private lateinit var musicListener: MusicListener
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.DialogFragmentTheme)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.dialog_crop_music, container, false)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.requestFeature(FLAG_HARDWARE_ACCELERATED)
        isCancelable = false
        return view
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        musicListener = activity as MusicListener
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        seekTrim = view.findViewById(R.id.seekTrim)
        wave = view.findViewById(R.id.wave)
        btnTrim = view.findViewById(R.id.btnTrim)
        txtMusicName = view.findViewById(R.id.txtMusicName)
        txtDuration = view.findViewById(R.id.txtDuration)
        musicIcon = view.findViewById(R.id.musicIcon)
        btnCancel = view.findViewById(R.id.btnCancel)
        rightBottomView = view.findViewById(R.id.rightBottomView)
        leftBottomView = view.findViewById(R.id.leftBottomView)
        progressLine = view.findViewById(R.id.progressLine)
        stopAudio = Handler((Looper.getMainLooper()))
        setDialog()
        setUpAnimation()
        setupClickListeners()
    }

    private fun setDialog() {
        progressDialog = ProgressDialog(requireContext(), R.style.ProgressDialogStyle)
        progressDialog.setMessage("Please wait...")
        progressDialog.setCancelable(false)
    }

    private fun setUpAnimation() {
        val rotation = AnimationUtils.loadAnimation(requireContext(), R.anim.anim_round)
        rotation.fillAfter = true
        musicIcon.startAnimation(rotation)
    }

    override fun onStart() {
        super.onStart()
//        if (requireContext().isMobile()){
//            dialog?.window?.setLayout(
//                (requireActivity().displayWidth() * 0.9).toInt(),
//                WindowManager.LayoutParams.WRAP_CONTENT
//            )
//        }else{
//            dialog?.window?.setLayout(
//                (requireActivity().displayWidth() * 0.8).toInt(),
//                WindowManager.LayoutParams.WRAP_CONTENT
//            )
//        }
    }

    @SuppressLint("SetTextI18n, RestrictedApi")
    private fun setupClickListeners() {
        seekTrim.addOnSliderTouchListener(object : RangeSlider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: RangeSlider) {

            }

            override fun onStopTrackingTouch(slider: RangeSlider) {
                mModel?.let {
                    it.startTime = slider.valueFrom.toLong()
                    it.endTime = slider.valueTo.toLong()
                }

                //TODO New Try
//                mHandler?.postDelayed(mRunning!!, 0)
//                mAudioPlayer?.play(requireContext(), mUri!!) {
//                    isPlaying = true
//                    mModel?.let {
//                        mAudioPlayer?.seekTo(mModel!!.startTime.toInt())
//                    }
//                }
//                val audioSessionId: Int = mAudioPlayer!!.audioSessionId
//                if (audioSessionId != -1) wave.setAudioSessionId(audioSessionId)
            }
        })
        btnTrim.click {
            val duration = ((mModel!!.endTime / 1000) - (mModel!!.startTime / 1000) + 0.5).toInt()
            val totalDuration = (lottieDuration/1000).toInt()
            Log.d(TAG, "setupClickListeners: total duration $duration lottieDuration $totalDuration")
            if (duration < totalDuration){
                when (totalDuration) {
                    in 0..60 -> {
                        showToast("Please Trim Atleast $totalDuration Seconds Music")
                    }
                    else -> {
                        val rem = totalDuration % 60
                        if (rem < 10)
                            showToast("Please Trim Atleast ${((totalDuration % 3600)/60)} Minutes 0$rem Seconds Music")
                        else
                            showToast("Please Trim Atleast ${((totalDuration % 3600)/60)} Minutes $rem Seconds Music")
                    }
                }
                return@click
            }

            btnTrim.disabled()
            if (mAudioPlayer!!.isPlaying()) {
                mAudioPlayer!!.pause()
                audioRunning?.let {
                    stopAudio?.removeCallbacks(it)
                }
                mRunning?.let {
                    mHandler?.removeCallbacks(it)
                }
            }

            if (mSoundFile == null) {
                //TODO Manage Code HERE
//                showToast("Please Wait..!!!")
                btnTrim.enabled()
                return@click
            }

            MusicUitlis.setSoundFile(mSoundFile!!)

            val startFrame: Int = MusicUitlis.secondsToFrames(mModel!!.startTime.toDouble() / 1000)
            val endFrame: Int = MusicUitlis.secondsToFrames(mModel!!.endTime.toDouble() / 1000 - 0.04)

            //Save the sound file in a background thread
            val mSaveSoundFileThread: Thread = object : Thread() {
                override fun run() {
                    // Try AAC first.
                    val file = makeRingtoneFile()
                    val outFile = File(file)
                    try {
                        // Write the new file
                        var isSeek = false
                        runOnUiThread {
                            if (seekTrim.visibility == View.VISIBLE){
                                isSeek = true
                            }
                        }
                        if (isSeek){
                            Log.d(TAG, "run: seekTrim $isSeek start ${seekTrim.valueFrom} end ${seekTrim.valueTo} diff ${seekTrim.valueTo - seekTrim.valueFrom}")
                            mSoundFile!!.WriteFile(outFile, seekTrim.valueFrom, seekTrim.valueTo - seekTrim.valueFrom)
                        }else{
                            Log.d(TAG, "run: seekTrim $isSeek start $startFrame end $endFrame diff ${endFrame - startFrame}")
                            mSoundFile!!.WriteFile(outFile, startFrame, endFrame - startFrame)
                        }
                    } catch (e: Exception) {
                        // log the error and try to create a .wav file instead
                        if (outFile.exists()) {
                            outFile.delete()
                        }
                        e.printStackTrace()
                    }
                    progressDialog.dismiss()
                    Handler(Looper.getMainLooper()).postDelayed({
                        btnTrim.enabled()
                        Log.d(TAG, "run: path of trim outFile is $outFile")
                        musicListener.onMusicClick(LottieMusicAdapter.MusicType.FILE, musicPosition,null, outFile.absolutePath, musicName)
                        dialog?.dismiss()
                    },0)
                }
            }
            progressDialog.show()
            mSaveSoundFileThread.start()
        }
        btnCancel.click {
            Log.d(TAG, "setupClickListeners: selectedMusicPosition $selectedMusicPosition")
            if (selectedMusicPosition != -1){
                musicListener.onMusicClick(LottieMusicAdapter.MusicType.OFFLINE, selectedMusicPosition)
            }else if (selectedAudioPosition != -1){
                musicListener.onMusicClick(LottieMusicAdapter.MusicType.FILE, -1,null,null)
            }
            mThread?.interrupt()
            dismiss()
        }
        if (requireArguments().getString("musicUri") != ""){
            arguments?.getString("musicUri")?.let {
                arguments?.getInt("musicPosition")?.let { pos -> musicPosition = pos }
                mUri = it.toUri()
                mModel = MusicModel(FileUtils.getReadablePathFromUri(requireContext(), it.toUri())!!)
                musicName = FileUtils.getFileName(requireContext(),
                    it.toUri()).replace(".mp3","")
                    .replace("-"," ")
                    .replace("_"," ")
                txtMusicName.text = musicName

                getMediaDuration(File(FileUtils.getReadablePathFromUri(requireContext(), it.toUri())!!)).also { duration ->
                    when (duration) {
                        in 0..60 -> {
                            txtDuration.text = "$duration Seconds"
                        }
                        else -> {
                            val rem = duration % 60
                            txtDuration.text = if (rem < 10)
                                "${((duration % 3600)/60).toInt()} Minutes 0$rem Seconds"
                            else
                                "${((duration % 3600)/60).toInt()} Minutes $rem Seconds"
//                            txtDuration.text = "${TimeUnit.MILLISECONDS.toMinutes(it)}.${TimeUnit.MILLISECONDS.toSeconds(it)} Seconds"
                        }
                    }
                }
                startMusic()
            }
        }else{
            showToast("Invalid Music File")
            dismiss()
        }
    }

    private fun makeRingtoneFile(): String {

//        val ldirPath = "${requireActivity().getExternalFilesDir(null)}/music/"
        val ldirPath = "${requireActivity().cacheDir}/TrimMusic/"

        if (!File(ldirPath).exists()) {
            File(ldirPath).mkdirs()
        }

        val filename = "${System.currentTimeMillis()}.wav"
        val file = File(ldirPath, filename)

        if (file.exists()) {
            file.delete()
        }

        file.createNewFile()

        return file.absolutePath
    }

    @SuppressLint("SetTextI18n")
    private fun loadFile(uri: Uri) {
        runOnUiThread {
            btnTrim.disabled()
            leftView.disabled()
            rightView.disabled()
            btnTrim.text = "Please Wait 0%"
        }
        mSoundFile = null
        Log.d(TAG, "loadFile: fileUri Is $uri")
        try {
            mSoundFile = SoundFile.create(
                FileUtils.getPath(requireContext(), uri)) {

                runOnUiThread {
                    round(it * 100).toInt().let { progress ->
                        Log.d(TAG, "loadFile: soundFile progress $progress")
                        if (progress >= 97) {
                            enableTrim()
                            isInProgress = false
                        }else {
                            if (isInProgress)
                                btnTrim.text = "Please Wait $progress%"
                        }
                    }
                }

                //TODO: Wood (Remove When Issue Solved)
                Handler(Looper.getMainLooper()).postDelayed({
                     try {
                         if (!(btnTrim.text.equals("Trim & Save")) && !isInProgress){
                             enableTrim()
                         }else{
//                             Handler(Looper.getMainLooper()).postDelayed({
//                                 try {
//                                     if (isInProgress){
//                                         isInProgress = false
//                                         enableTrim()
//                                     }
//                                 } catch (e: Exception) { }
//                             },10000)
                         }
                     } catch (e: Exception) { }
                },7000)

                Log.d(TAG, "loadFile: soundFile $it")
                !mThread!!.isInterrupted
            }
        } catch (e: Exception) {
            runOnUiThread {
                showToast("Audio file is corrupted.")
                dialog?.dismiss()
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun enableTrim() {
        leftView.enabled()
        rightView.enabled()
        btnTrim.enabled()
        btnTrim.text = "Trim & Save"
    }

    private fun startMusic() {
        checkPermissions()
        wave.reset()
        if (mAudioPlayer != null) {
            mAudioPlayer!!.release()
            mRunning?.let {
                mHandler?.removeCallbacks(mRunning!!)
            }
        }

        var title = FileUtils.getFileName(requireContext(), mUri)
        mAudioPlayer = AudioPlayer()
        mAudioPlayer?.actionComplete = {}

        mUri?.let {
            mThread = Thread {
                loadFile(mUri!!)
            }
            mThread?.start()

            mAudioPlayer?.play(requireContext(), it) {
                isPlaying = true
                if (!requireActivity().isFinishing) {
                    updateUI()
                    isBackEnable = true
                }
            }
            val audioSessionId: Int = mAudioPlayer!!.audioSessionId
            if (audioSessionId != -1) wave.setAudioSessionId(audioSessionId)
        }
    }

    fun setRange(from: Float, to: Float) {
        seekTrim.valueFrom = 0F
        seekTrim.valueTo = to
        seekTrim.valueFrom = from
    }

    private fun updateUI() {
        wave.model = mModel
        wave.setTotalDuration(mAudioPlayer!!.getDuration().toFloat())
        mModel?.let {
//            setRange(it.startTime.toFloat(), it.endTime.toFloat())
        }

        music_trim_tv_start_time.text = getTime(mModel!!.startTime.toInt())
        music_trim_tv_end_time.text = getTime(mAudioPlayer!!.getDuration())
        music_trim_tv_diff.text = getTime(mAudioPlayer!!.getDuration())

        mModel!!.endTime = mAudioPlayer!!.getDuration().toLong()

        mRunning = Runnable {
            music_trim_tv_diff.text = getTime(mAudioPlayer!!.getCurrentDuration())
            val total = rightBottomView.x - (leftBottomView.x + leftBottomView.width)
            val progress = (total * (mAudioPlayer!!.getCurrentDuration() - mModel!!.startTime)) / (mModel!!.endTime - mModel!!.startTime)
            progressLine.x = progress + (leftBottomView.x + leftBottomView.width)
//            progressLine.hide()
            Log.d(TAG, "updateUI: progressLine.x -> ${progressLine.x}")
            if (mAudioPlayer!!.getCurrentDuration() > mModel!!.endTime) {
                mAudioPlayer!!.pause()
                mAudioPlayer!!.seekTo(0)
                mHandler?.removeCallbacks(mRunning!!)
                progressLine.x = rightBottomView.x
                return@Runnable
            }

            if (isPlaying) {
                mHandler?.postDelayed(mRunning!!, 100)
            }

        }
        mHandler?.postDelayed(mRunning!!, 100)


        audioRunning = Runnable {
            Log.d(TAG, "updateUI: audioRunning Runnable")
            mAudioPlayer?.pause()
        }

        wave.action = { s, v ->
            Log.d(TAG, "updateUI: value s $s v $v ")
            if (mModel!!.startTime.toInt() < 0) {
                mModel!!.startTime = 0
            }
            if (mModel!!.endTime.toInt() > mAudioPlayer!!.getDuration()) {
                mModel!!.endTime = mAudioPlayer!!.getDuration().toLong()
            }
            music_trim_tv_start_time.text = getTime(mModel!!.startTime.toInt())
            music_trim_tv_end_time.text = getTime(mModel!!.endTime.toInt())
            Log.d(TAG, "updateUI: value start ${getTime(mModel!!.startTime.toInt())} endTime ${getTime(mModel!!.endTime.toInt())} ")
            when (s) {
                "down" -> {
                    if (mAudioPlayer!!.isPlaying()) {
                        mAudioPlayer!!.pause()
                        isPlaying = false
                        mHandler?.removeCallbacks(mRunning!!)
                    }
                }
                "move" -> {
                    music_trim_tv_diff.text =
                        getTime((mModel!!.endTime - mModel!!.startTime).toInt())
                }
                "up"  -> {
                    Log.d(TAG, "updateUI: mAudioPlayer!!.isPlaying() ${mAudioPlayer!!.isPlaying()}")
                    Log.d(TAG, "updateUI: v $v")
                    Log.d(TAG, "updateUI: audioRunning UP")
//                    if (!mAudioPlayer!!.isPlaying()) {
//                        isPlaying = true
//                        mAudioPlayer?.seekTo(v)
//                        mAudioPlayer!!.start()
//                        mHandler?.postDelayed(mRunning!!, 0)
//                    }

                    //TODO New Try
                    mHandler?.postDelayed(mRunning!!, 0)
                    mAudioPlayer?.play(requireContext(), mUri!!) {
                        isPlaying = true
                        mModel?.let {
                            mAudioPlayer?.seekTo(mModel!!.startTime.toInt())
                        }

                        audioRunning?.let {
                            Log.d(TAG, "updateUI: audioRunning audioRunning")
                            val duration = ((mModel!!.endTime / 1000) - (mModel!!.startTime / 1000) + 0.5).toInt()
                            stopAudio?.removeCallbacks(it)
                            stopAudio?.postDelayed(it, (duration * 1000).toLong())
                            Log.d(TAG, "updateUI: audioRunning audioRunning ${(duration * 1000).toLong()}")
                        }
                    }
                    val audioSessionId: Int = mAudioPlayer!!.audioSessionId
                    if (audioSessionId != -1) wave.setAudioSessionId(audioSessionId)
                }
            }
        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun getTime(progress: Int): String {
        return SimpleDateFormat("HH:mm:ss").apply { timeZone = TimeZone.getTimeZone("GMT+0") }
            .format(progress)
    }

    override fun onStop() {
        super.onStop()
        stopPlayingAudio()
    }

    private fun stopPlayingAudio() {
        if (mAudioPlayer != null) {
            mAudioPlayer?.pause()
            mRunning?.let {
                mHandler?.removeCallbacks(it)
            }
        }
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mPermissionGranted = true
        } else {
            isBackEnable = true
            mPermissionGranted = false
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                3000
            )
        }
    }

    override fun onDestroy() {
        wave.release()
        mAudioPlayer?.release()
        mThread?.interrupt()
        mRunning?.let {
            mHandler?.removeCallbacks(it)
        }
        mSoundFile = null
        super.onDestroy()
    }

    companion object{
        val TAG = "CropMusicFragment"
        @JvmStatic
        fun newInstance(pos: Int, musicUri: String): CropMusicFragment {
            val args = Bundle()
            args.putInt("musicPosition", pos)
            args.putString("musicUri", musicUri)
            val f = CropMusicFragment()
            f.arguments = args
            return f
        }
    }
}