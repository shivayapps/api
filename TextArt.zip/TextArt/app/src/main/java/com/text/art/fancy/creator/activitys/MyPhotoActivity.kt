package com.text.art.fancy.creator.activitys

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentTransaction
import com.text.art.fancy.creator.BuildConfig
import com.text.art.fancy.creator.model.ImageModel
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.ads.OfflineNativeAdvancedHelper
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.dialog.DiscardDialogFragment
import com.text.art.fancy.creator.fragment.CreationFragment
import com.text.art.fancy.creator.fragment.PhotoFragment
import com.text.art.fancy.creator.interfaces.broadcastReceivers
import com.text.art.fancy.creator.receivers.ConnectionReceiver
import com.text.art.fancy.creator.utils.MySharedPref
import com.text.art.fancy.creator.utils.getStatusbarHeight
import com.text.art.fancy.creator.utils.hideSystemUI
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.google.android.gms.ads.LoadAdError
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import kotlinx.android.synthetic.main.activity_my_photo.*
import java.io.File

class MyPhotoActivity : AppCompatActivity(), View.OnClickListener, broadcastReceivers {
    private var back_image: ImageView? = null
    private var is_closed = false
    private var mContext: Context? = null
    lateinit var mMyToolbar: LinearLayout
    lateinit var creationMainLayout: ConstraintLayout
    private var newFragment: CreationFragment? = null
    lateinit var FlOfflineAds: ConstraintLayout
    private var mPhotoFragment: PhotoFragment? = null
    private var mPosition: Int = -1
    var mIsSubScribe: Boolean = false
    private var dialogSave: DiscardDialogFragment? = null

    //Network Receiver
    var networkReceiver: ConnectionReceiver? = null
    var intentFilter: IntentFilter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_photo)
        mContext = this@MyPhotoActivity

        networkReceiver = ConnectionReceiver(this)
        intentFilter = IntentFilter("com.text.art.fancy.creator")

        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe

        creationMainLayout = findViewById(R.id.creationMainLayout)

        creationMainLayout.invalidate();
        try {
            mMyToolbar.setPadding(0, getStatusbarHeight(), 0, 0)
            hideSystemUI()
        } catch (e: Exception) { }


        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            startActivity(
                Intent(
                    this@MyPhotoActivity,
                    HomeActivity::class.java
                ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
            finish()
        }
        // NativeAdvanceHelperfb.loadNativeAdFb(this, findViewById<View>(R.id.native_ad_container) as NativeAdLayout, this)
        // interstitial = InterstitialAdHelper.instance?.load(this, this)

        initView()
        initListener()
        initAction()

        if (mIsSubScribe) {
            FlOfflineAds.visibility = View.GONE
        } else {
            try {
                setAndLoadInterstitialAds()
            } catch (e: Exception) { }
            if (MySharedPref(this).getAdsClicked()) {
                FlOfflineAds.visibility = View.GONE

                if (isNetworkConnected()){
                    findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.VISIBLE
                    OfflineNativeAdvancedHelper.loadOfflineNativeAdvance(this,findViewById(R.id.fl_adplaceholder)){}
                }else{
                    OfflineNativeAdvancedHelper.loadOfflineNativeAdvance(this,findViewById(R.id.fl_adplaceholder)){}
                    findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
                }
//                NativeAdvanceHelper.loadAdSmall(this, findViewById(R.id.fl_adplaceholder));
            }
        }
    }

    private fun isNetworkConnected(): Boolean {
        var cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        return cm.getActiveNetworkInfo() != null && cm!!.getActiveNetworkInfo()!!.isConnected()
    }

    val actionClick: (Int, ArrayList<ImageModel>, Boolean) -> Unit = { position, list, show ->
        if (mPhotoFragment == null) {
            mPosition = position
            Log.d(TAG, "actionClick")
            mPhotoFragment = PhotoFragment()
            mPhotoFragment!!.arguments = Bundle().apply {
                putSerializable("list", list)
                putBoolean("isShow", show)
                putSerializable("fulllist", newFragment!!.getList())
            }
            val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
            transaction.add(R.id.fragment_container, mPhotoFragment!!)
            transaction.addToBackStack(null)
            transaction.commit()
        }
    }

    private fun initAction() {
        if (checkPermission()) {
            addFragments()
        } else {
            ActivityCompat.requestPermissions(
                this@MyPhotoActivity,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                Constants.WRITE_EXTERNAL_STORAGE_CODE
            )
        }
    }

    private fun addFragments() {
        newFragment = CreationFragment()
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        transaction.add(R.id.fragment_container, newFragment!!)
        transaction.commit()
    }

    private fun initListener() {
        animationView?.setOnClickListener(this)

        ivSend.setOnClickListener {
            val mArrayList = newFragment?.mPhotoList
            val files: ArrayList<Uri> = ArrayList()
            mArrayList?.forEach {
                it.strings!!.forEach {
                    if (it.isSelect) {
                        val uri = FileProvider.getUriForFile(
                            mContext!!,
                            BuildConfig.APPLICATION_ID + ".provider",
                            File(it.path)
                        )
                        files.add(uri)
                    }
                }
            }

            if (files.isNotEmpty()) {
                val intent =
                    Intent(Intent.ACTION_SEND_MULTIPLE)
                intent.type = "image/*"
                intent.putExtra(Intent.EXTRA_SUBJECT, "TextArt")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    "https://play.google.com/store/apps/details?id=${mContext?.packageName}"
                )
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, files)
                mContext?.startActivity(Intent.createChooser(intent, "Share Image"))
            } else {
                Toast.makeText(this, "No Image Selected", Toast.LENGTH_SHORT).show()
            }

        }
        ivDelete.setOnClickListener {
            val mArrayList = newFragment?.mPhotoList
            var files: ArrayList<Uri> = ArrayList()
            mArrayList?.forEach {
                it.strings!!.forEach {
                    if (it.isSelect) {
                        val uri = FileProvider.getUriForFile(
                            mContext!!,
                            BuildConfig.APPLICATION_ID + ".provider",
                            File(it.path)
                        )
                        files.add(uri)
                    }
                }
            }
            if (files.isNotEmpty()) {
                dialogSave = DiscardDialogFragment(
                    "Delete",
                    resources.getString(R.string.deleteSentence),
                    R.drawable.ic_dialog_delete,
                    "Cancel",
                    "Delete"
                )
                { s, discardDialogFragment ->
                    if (s == "ok") {
                        supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                        discardDialogFragment.dismiss()
                        if (mPhotoFragment != null) {
                            if (mPhotoFragment?.delete()!!) {
                                onBackPressed()
                            }
                        } else {
                            newFragment?.delete()
                        }
                        ivSelectAll.visibility = View.GONE
                        controlLayout.visibility = View.GONE
                        ivDelete.visibility = View.GONE
                        if (!mIsSubScribe && mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
                            animationView?.visibility = View.VISIBLE
                        }
                    } else {
                        supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                        discardDialogFragment.dismiss()
                    }
                }
                dialogSave!!.isCancelable = false
                dialogSave!!.show(supportFragmentManager, "dialog")
            } else {
                Toast.makeText(this, "No Image Selected", Toast.LENGTH_SHORT).show()
            }

        }
        ivClose.setOnClickListener {
            onBackPressed()
        }

        ivSelectAll.setOnClickListener {
            if (mPhotoFragment != null) {
                mPhotoFragment?.selectAll(ivSelectAll.tag == "unselect")
            } else {
                newFragment?.selectAll(ivSelectAll.tag == "unselect")
            }
            if (ivSelectAll.tag == "unselect") {
                ivSelectAll.tag = "select"
            } else {
                ivSelectAll.tag = "unselect"
            }
        }
    }


    var mInterstitialAd: InterstitialAd? = null
    private fun setAndLoadInterstitialAds() {
        mInterstitialAd = InterstitialAd(this)
        val interstialAdId = AppIDs().getGoogleInterstitial(0)
        Log.d("InterstitialAds", "${interstialAdId}")
        mInterstitialAd!!.adUnitId = interstialAdId
        mInterstitialAd!!.loadAd(AdRequest.Builder().build())
        mInterstitialAd!!.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
//                if (!isLongClicked) {
                if ((ivDelete.visibility == View.GONE || ivDelete.visibility == View.INVISIBLE) && !mIsSubScribe) {
                    animationView!!.visibility = View.VISIBLE
                } else {
                    animationView!!.visibility = View.INVISIBLE
                }

                is_closed = true
                Log.d("InterstitialAds", "onAdLoaded")

//                }
            }

            override fun onAdImpression() {
                super.onAdImpression()
                Log.d("InterstitialAds", "onAdImpression")

            }

            override fun onAdLeftApplication() {
                super.onAdLeftApplication()
                Log.d("InterstitialAds", "onAdLeftApplication")

            }

            override fun onAdClicked() {
                super.onAdClicked()
                Log.d("InterstitialAds", "onAdClicked")

            }

            override fun onAdFailedToLoad(p0: LoadAdError?) {
                super.onAdFailedToLoad(p0)
                animationView!!.visibility = View.GONE
                Log.d("InterstitialAds", "LoadAdError")
            }

            override fun onAdClosed() {
                super.onAdClosed()
                animationView!!.visibility = View.GONE
                mInterstitialAd!!.loadAd(AdRequest.Builder().build())
            }

            override fun onAdOpened() {
                super.onAdOpened()
            }
        }
        /*if (mInterstitialAd != null) {
            animationView?.visibility = View.VISIBLE
        }*/
    }

    private fun initView() {

        back_image = findViewById<View>(R.id.imgBtnBack) as ImageView
        FlOfflineAds = findViewById<ConstraintLayout>(R.id.FlOfflineAds)
        mMyToolbar = findViewById(R.id.mMyToolbar)

        FlOfflineAds!!.setOnClickListener(this)
        back_image!!.setOnClickListener(this)
    }

    private fun checkPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == Constants.WRITE_EXTERNAL_STORAGE_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                addFragments()
                //                loadNativeAds();
            } else {
                val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                )
                if (!showRationale) {
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Permission Required")
                    builder.setMessage("Storage Permission are required to save Image into External Storage")
                    builder.setPositiveButton("OK") { dialog, which ->
                        dialog.dismiss()
                        //ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.WRITE_EXTERNAL_STORAGE_CODE);
                        startInstalledAppDetailsActivity(this@MyPhotoActivity)
                    }
                    builder.setNegativeButton("Cancel") { dialog, which -> dialog.dismiss() }
                    builder.create().show()
                    // user also CHECKED "never ask again"
                    // you can either enable some fall back,
                    // disable features of your app
                    // or open another dialog explaining
                    // again the permission and directing to
                    // the app setting
                }
                //JNPPermission.requestPermission(this, apPermission, 10);
            }
        }
    }

    val actionShow: (Boolean) -> Unit = {
        ivSelectAll.visibility = if (it) View.GONE else View.GONE
        controlLayout.visibility = if (it) View.GONE else View.GONE
        ivDelete.visibility = if (it) View.VISIBLE else View.GONE
        try {
            animationView.visibility =
                if (it) View.GONE else if (!mIsSubScribe && mInterstitialAd!!.isLoaded) {
                    View.VISIBLE
                } else View.GONE
        } catch (e: Exception) {
        }
    }

    private fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1212) {
            if (MySharedPref(this).getAdsClicked()) {
                FlOfflineAds.visibility = View.GONE
                OfflineNativeAdvancedHelper.loadOfflineNativeAdvance(this,findViewById(R.id.fl_adplaceholder)){}

            }
        }

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.imgBtnBack -> onBackPressed()
            R.id.FlOfflineAds -> {
                try {
                    MySharedPref(this).setAdsClicked("adsClickOrNot", true)
                } catch (e: Exception) {
                }
                try {
                    startActivityForResult(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=com.graphic.design.digital.businessadsmaker")
                        ), 1212
                    )
                } catch (anfe: ActivityNotFoundException) {
                    startActivityForResult(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://play.google.com/store/apps/details?id=com.graphic.design.digital.businessadsmaker")
                        ), 1212
                    )
                }
            }
            R.id.animationView -> {
                is_closed = false
//                animationView?.visibility = View.GONE
                Log.e(TAG, "initListener: loadedddd")
                if (mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
                    mInterstitialAd!!.show()
                }
//                val uri = Uri.parse("https://www.instagram.com/thetextart/")
//                val likeIng = Intent(Intent.ACTION_VIEW, uri)
//                likeIng.setPackage("com.instagram.android")
//                try {
//                    startActivity(likeIng)
//                } catch (e: ActivityNotFoundException) {
//                    startActivity(
//                        Intent(
//                            Intent.ACTION_VIEW,
//                            Uri.parse("https://www.instagram.com/thetextart/")
//                        )
//                    )
//                }
            }
            else -> {
            }
        }
    }

    private fun onClick() {

    }


    override fun onBackPressed() {
        ivDelete.visibility = View.INVISIBLE
        /*if (!mIsSubScribe) {
            animationView?.visibility = View.VISIBLE
        }*/
        if (mPhotoFragment == null) {
            newFragment?.onBackPres!!()
        } else {
            supportFragmentManager.beginTransaction().remove(mPhotoFragment!!).commit()
            mPosition = newFragment?.refresh!!(mPosition, PhotoFragment.isShowCheckBox)
            mPhotoFragment = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

//    override fun onLoad() {
//        Log.d(TAG, "onLoad")
//        if (!mIsSubScribe && (ivDelete.visibility == View.GONE || ivDelete.visibility == View.INVISIBLE)) {
//            isInterstitialAdLoaded = true
//            animationView?.visibility = View.VISIBLE
//        } else {
//            isInterstitialAdLoaded = false
//            animationView?.visibility = View.INVISIBLE
//        }
//    }
//
//    override fun onFailed() {
//        isInterstitialAdLoaded = false
//        // interstitial = InterstitialAdHelper.instance?.load(this, this)
//    }
//
//    override fun onClosed() {
//        isInterstitialAdLoaded = false
//        animationView?.visibility = View.GONE
////        interstitial = InterstitialAdHelper.instance?.load(this, this)
//    }

    override fun onResume() {
        super.onResume()
        if (mIsSubScribe) {
            animationView?.visibility = View.INVISIBLE
        }
        if (dialogSave!=null){
            if (dialogSave!!.isShowing()){
                try {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                    dialogSave!!.dismiss()
                } catch (e: Exception) { }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(networkReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(networkReceiver)
    }


    companion object {
        private const val TAG = "MyPhotoActivity"
    }

    override fun onNetworkChanged(state: Boolean?) {
        if (state!!){
            mInterstitialAd = null
            setAndLoadInterstitialAds()
        }
    }
}