package com.text.art.fancy.creator.viewModel

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.*
import com.text.art.fancy.creator.comman.Constants.MusicFolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.text.art.fancy.creator.model.LottieMusic

import com.text.art.fancy.creator.utils.CopyAssets
import com.text.art.fancy.creator.utils.getMediaDuration
import java.io.File

class OfflineMusicViewModel(application: Application) : AndroidViewModel(application) {

    val offlineMusicList : LiveData<ArrayList<LottieMusic>> = MutableLiveData()

    init {
        offlineMusicList as MutableLiveData
        viewModelScope.launch {
            offlineMusicList.value = getOfflineMusicData()
        }
    }

    @SuppressLint("SdCardPath")
    private suspend fun getOfflineMusicData():ArrayList<LottieMusic>{
        return withContext(Dispatchers.IO){
            val list = arrayListOf<LottieMusic>()
            val job = launch {
                CopyAssets.copyAssets(getApplication() as Context, MusicFolder)
            }
            job.invokeOnCompletion {
                (getApplication() as Context).assets.list("OfflineMusic")?.let {
                    for (audio in it){
                        val musicPath = "${(getApplication() as Context).cacheDir}/$MusicFolder/$audio"
                        if (!audio.contains("Mute")){
                            list.add(LottieMusic(
                                audio,
                                musicPath,
                                getMediaDuration(File(musicPath)).toInt(),
                                ((File(musicPath)).length()/1024).toFloat())
                            )
                        }
                    }
                }

            }
            list
        }
    }
}