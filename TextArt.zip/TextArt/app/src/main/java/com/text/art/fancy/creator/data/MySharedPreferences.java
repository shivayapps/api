package com.text.art.fancy.creator.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;

public class MySharedPreferences {

    private SharedPreferences mPreferences;
    private SharedPreferences.Editor editor;

    public MySharedPreferences(Context context){
        mPreferences = context.getSharedPreferences("MySetting",Context.MODE_PRIVATE);
        editor = mPreferences.edit();
    }

    public void setFormat(String format){
        editor.putString("format",format);
        editor.commit();
    }

    public void setVisitPlay() {
        editor.putString("visit_review_play", "visit_play");
        editor.commit();
    }

    public String getVisit(){
        return mPreferences.getString("visit_review_play", null);
    }

    public void setCount(int count){
        editor.putInt("count", count);
        editor.commit();
    }

    public int getCount(){
        return mPreferences.getInt("count",0);
    }

    public void setPremiumCount(int count){
        editor.putInt("premiumCount", count);
        editor.commit();
    }

    public int getPremiumCount(){
        return mPreferences.getInt("premiumCount",0);
    }

    public String getFormat(){
        return mPreferences.getString("format","jpg");
    }

    public void setIsFont(Boolean isFont){
        editor.putBoolean("isFont",isFont);
        editor.commit();
    }
    public Boolean getIsFont(){
        return mPreferences.getBoolean("isFont",true);
    }

    public void setIsNewFont(Boolean isNewFont){
        editor.putBoolean("isNewFont",isNewFont);
        editor.commit();
    }
    public Boolean getIsNewFont(){
        return mPreferences.getBoolean("isNewFont",true);
    }


    public void setIsNewPattern(Boolean isNewPattern){
        editor.putBoolean("isNewPattern",isNewPattern);
        editor.commit();
    }
    public Boolean getIsNewPattern(){
        return mPreferences.getBoolean("isNewPattern",true);
    }


    public void setIsNewFrame(Boolean isNewFrame){
        editor.putBoolean("isNewFrame",isNewFrame);
        editor.commit();
    }
    public Boolean getIsNewFrame(){
        return mPreferences.getBoolean("isNewFrame",true);
    }


    public void setIsSetFrame(Boolean isSetFrame){
        editor.putBoolean("isFrame",isSetFrame);
        editor.commit();
    }
    public Boolean getIsSetFrame(){
        return mPreferences.getBoolean("isFrame",true);
    }

    public void setIsPattern(Boolean isPattern){
        editor.putBoolean("isPattern",isPattern);
        editor.commit();
    }
    public Boolean getIsPattern(){
        return mPreferences.getBoolean("isPattern",true);
    }

    public void setIsSubscribe(Boolean isSubscribe){
        editor.putBoolean("isSubscribe",isSubscribe);
        editor.commit();
    }

    public Boolean getIsSubscribe(){
        return mPreferences.getBoolean("isSubscribe",false);
    }

    public void setOfflineAds(Boolean isSubscribe){
        editor.putBoolean("setOfflineAds",isSubscribe);
        editor.commit();
    }

    public Boolean getOfflineAds(){
        return mPreferences.getBoolean("setOfflineAds",true);
    }

    public void isDatabaseClear(Boolean isPattern){
        editor.putBoolean("isDatabaseClear",isPattern);
        editor.commit();
    }
    public Boolean getDatabaseClear(){
        return mPreferences.getBoolean("isDatabaseClear",false);
    }
}
