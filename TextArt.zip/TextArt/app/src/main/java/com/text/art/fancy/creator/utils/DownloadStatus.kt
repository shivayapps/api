package com.text.art.fancy.creator.utils

import java.io.Serializable

data class DownloadStatus(
     var mPercentage : Int,
     var status : Status
) : Serializable{

    enum class Status {
        //Download status running
        RUNNING,

        //Download status Complete
        COMPLETE
    }
}