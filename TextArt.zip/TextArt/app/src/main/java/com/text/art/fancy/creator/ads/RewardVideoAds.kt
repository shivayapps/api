package com.text.art.fancy.creator.ads

import android.content.Context
import android.util.Log
import com.text.art.fancy.creator.R
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs

class RewardVideoAds {

    val TAG = "Ads_123"

    companion object {

        var rewardedAd: RewardedAd? = null
        var rewardedAd1: RewardedAd? = null

        var instence: RewardVideoAds? = null
            get() {
                if (field == null) {
                    field = RewardVideoAds()
                }
                return field
            }
    }

    /*fun loadVideoAdMain(context: Context): RewardedAd? {
        var reward: RewardedAd? = null
        if (rewardedAd != null && rewardedAd?.isLoaded!!) {
            // return rewardedAd!!
            reward = rewardedAd!!
        } else {
            loadRewardVideoAd(context)
        }
        if (rewardedAd1 != null && rewardedAd1?.isLoaded!!) {
            //return rewardedAd1!!
            reward = rewardedAd1!!
        } else {
            loadRewardVideoAd1(context)
        }
        return reward
    }*/

    fun loadVideoAdMain(context: Context): RewardedAd? {
        var reward: RewardedAd? = null
        if (rewardedAd != null) {
            reward = rewardedAd!!
        } else {
            loadRewardVideoAd(context)
        }
        if (rewardedAd1 != null) {
            reward = rewardedAd1!!
        } else {
            loadRewardVideoAd1(context)
        }
        return reward
    }


    fun loadRewardVideoAd(context: Context) {
        if (rewardedAd != null && rewardedAd?.isLoaded!!) {
            return
        }

        val interstialAdId = AppIDs().getGoogleRewardVideo()
        Log.d("InterstitialAds Reward", "${interstialAdId}")

        rewardedAd = RewardedAd(
                context,
                interstialAdId
        )
        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
            override fun onRewardedAdLoaded() {
                Log.d("onRewardedAdLoaded", "Ad Loaded 0")
            }

            override fun onRewardedAdFailedToLoad(errorCode: Int) {
                // loadRewardVideoAd(context)
                Log.d("onAdFailedToLoad", "Ad Reward Failed To Load $errorCode")
            }
        }
        rewardedAd?.loadAd(AdRequest.Builder().build(), adLoadCallback)
    }

    fun loadRewardVideoAd1(context: Context) {
        if (rewardedAd1 != null && rewardedAd1?.isLoaded!!) {
            return
        }

        val interstialAdId = AppIDs().getGoogleRewardVideo()
        rewardedAd1 = RewardedAd(
                context,
                interstialAdId
        )
        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
            override fun onRewardedAdLoaded() {
                Log.d("onRewardedAdLoaded", "Ad Loaded")
            }

            override fun onRewardedAdFailedToLoad(errorCode: Int) {
                //  loadRewardVideoAd1(context)
                Log.d("onAdFailedToLoad", "Ad Reward Failed to Load 1 $errorCode")
            }
        }
        rewardedAd1?.loadAd(AdRequest.Builder().build(), adLoadCallback)
    }
}