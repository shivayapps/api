package com.text.art.fancy.creator.roomdb.draft

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
import sticker.view.dixitgabani.model.StickerModel

@Parcelize
@Entity(tableName = "Draft") //User Entity represents a table within the database.
data class Draft(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val date: String,
    val time: String,
    val preview: String,
    val stickerList: String,
    val combo: String,
    val watermark: Boolean = true
): Parcelable