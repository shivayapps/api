package com.text.art.fancy.creator.widgets.trimMusic

data class MusicModel(
    var path : String,
    var startTime : Long = 0,
    var endTime : Long = 0
){
    var isSelect = false
}