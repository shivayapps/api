package com.text.art.fancy.creator.lottieaudiorendering.data;

import androidx.annotation.NonNull;

public class GenericTrackFormat extends MediaTrackFormat {

    public GenericTrackFormat(int index, @NonNull String mimeType) {
        super(index, mimeType);
    }
}
