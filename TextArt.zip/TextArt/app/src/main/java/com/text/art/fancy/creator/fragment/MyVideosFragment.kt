package com.text.art.fancy.creator.fragment

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.*
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.model.creation.PhotoModelCreation
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.FullMyPhotoActivity
import com.text.art.fancy.creator.activitys.HomeActivity
import com.text.art.fancy.creator.adepter.MyPhotosAdapter
import com.text.art.fancy.creator.interfaces.OnLongClickPressedMyCreation
import com.text.art.fancy.creator.utils.isValidVideoFile
import com.text.art.fancy.creator.utils.showToast
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.collections.ArrayList

class MyVideosFragment : Fragment() {

    private var mRecyclerMyVideos: RecyclerView? = null
    private var progressBar1: ProgressBar? = null

    private var clickedItem = 0
    private var NUMBER_OF_DATES = 0
    private var dateCount = 0

    private var mOnLongClickPressedMyCreation: OnLongClickPressedMyCreation? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val view1: View = inflater.inflate(R.layout.fragment_my_videos, container, false)
        mOnLongClickPressedMyCreation = context as OnLongClickPressedMyCreation

        initView(view1)

        /*//1. OLD
        LoadAllVideoTask().execute()*/

        //New
        var executor = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())
        executor.execute {
            getVideos()
            handler.post{
                if (myPhotosAdapter != null) {
                    myPhotosAdapter!!.notifyDataSetChanged()
                }
                if (mPhotoList!!.size == 0) {
                    progressBar1!!.visibility = View.GONE
                    mRecyclerMyVideos!!.visibility = View.GONE
                    mConstraintVideoNotFound!!.visibility = View.VISIBLE
                } else {
                    activity?.let {
                        setDataToAdapter()
                        Handler(Looper.getMainLooper()).postDelayed({
                            progressBar1!!.visibility = View.GONE
                            mRecyclerMyVideos!!.visibility = View.VISIBLE
                            mConstraintVideoNotFound!!.visibility = View.GONE
                        }, 1000)
                    }
                }
            }
        }

        return view1
    }

    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            startActivity(Intent(context, HomeActivity::class.java))
            requireActivity().finish()
        }
    }

    private fun initView(view: View) {
        mRecyclerMyVideos = view.findViewById(R.id.recyclerMyVideos)
        mConstraintVideoNotFound = view.findViewById(R.id.constraintImagesNotFound)
        progressBar1 = view.findViewById(R.id.progressBar1)
    }

    private fun getVideos() {
        NUMBER_OF_DATES = 0
        dateCount = 0
        clickedItem = 0
        mPhotoList.clear()
//        val file = File(
//            Environment.getExternalStoragePublicDirectory(
//                Environment.DIRECTORY_PICTURES + "/" + "TextArt_Videos"
//            ).toString()
//        )
        val file = File(
            Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_MOVIES + "/" + "TextArt"
            ).toString()
        )
        var pos = 1
        if (file.isDirectory) {
            val allFiles = file.listFiles { pathname ->
                pathname.path.endsWith(".mp4")
            }

            val files = arrayListOf<File>()
            for (i in allFiles.indices){
                if (isValidVideoFile(requireContext(), allFiles[i].absolutePath)){
                    files.add(allFiles[i])
                }
            }

            if (files.isNotEmpty()) {
                var temp: File
                for (i in files.indices) {
                    for (j in i + 1 until files.size) {
                        if (files[i].lastModified() < files[j].lastModified()) {
                            temp = files[i]
                            files[i] = files[j]
                            files[j] = temp
                        }
                    }
                }
                val lastModDate = Date(files[0].lastModified())
                val dateFormat = SimpleDateFormat("dd MMM yyyy")
                NUMBER_OF_DATES += 1

                mPhotoList.add(
                    0,
                    PhotoModelCreation(
                        "",
                        dateFormat.format(lastModDate),
                        NUMBER_OF_DATES,
                        true,
                        false,
                        null,
                        false,
                        false
                    )
                )


                mPhotoList.add(
                    pos,
                    PhotoModelCreation(
                        files[0].absolutePath,
                        dateFormat.format(lastModDate),
                        NUMBER_OF_DATES,
                        false,
                        false,
                        null,
                        false,
                        false
                    )
                )
                for (i in 0 until files.size - 1) {
                    pos++
                    val nextDate = Date(files[i + 1].lastModified())
                    var current = Date(files[i].lastModified())
                    Log.d(
                        "8792343212123",
                        "getPhotos: " + dateFormat.format(current) + "  " + files[i].absolutePath
                    )
                    if (dateFormat.format(current) != dateFormat.format(nextDate)) {
                        current = nextDate
                        NUMBER_OF_DATES += 1


                        mPhotoList.add(
                            pos,
                            PhotoModelCreation(
                                "",
                                dateFormat.format(nextDate),
                                NUMBER_OF_DATES,
                                true,
                                false,
                                null,
                                false,
                                false
                            )
                        )
                        pos++
                    }



                    mPhotoList.add(
                        pos,
                        PhotoModelCreation(
                            files[i + 1].absolutePath,
                            dateFormat.format(current),
                            NUMBER_OF_DATES,
                            false,
                            false,
                            null,
                            false,
                            false
                        )
                    )

                    Log.d("mycreationsda", "getPhotos: Images " + files[i + 1].absolutePath)
                }
            }

            /*if (files.isNotEmpty()) {
                var temp: File
                for (i in files.indices) {
                    for (j in i + 1 until files.size) {
                        if (files[i].lastModified() < files[j].lastModified()) {
                            temp = files[i]
                            files[i] = files[j]
                            files[j] = temp
                        }
                    }
                }
                val lastModDate = Date(files[0].lastModified())
                val dateFormat = SimpleDateFormat("dd MMM yyyy")
                NUMBER_OF_DATES += 1


                mPhotoList.add(
                    0,
                    PhotoModelCreation(
                        "",
                        dateFormat.format(lastModDate),
                        NUMBER_OF_DATES,
                        true,
                        false,
                        null,
                        false,
                        false
                    )
                )


                mPhotoList.add(
                    pos,
                    PhotoModelCreation(
                        files[0].absolutePath,
                        dateFormat.format(lastModDate),
                        NUMBER_OF_DATES,
                        false,
                        false,
                        null,
                        false,
                        false
                    )
                )
                for (i in 0 until files.size - 1) {
                    pos++
                    val nextDate = Date(files[i + 1].lastModified())
                    var current = Date(files[i].lastModified())
                    Log.d(
                        "8792343212123",
                        "getPhotos: " + dateFormat.format(current) + "  " + files[i].absolutePath
                    )
                    if (dateFormat.format(current) != dateFormat.format(nextDate)) {
                        current = nextDate
                        NUMBER_OF_DATES += 1


                        mPhotoList.add(
                            pos,
                            PhotoModelCreation(
                                "",
                                dateFormat.format(nextDate),
                                NUMBER_OF_DATES,
                                true,
                                false,
                                null,
                                false,
                                false
                            )
                        )
                        pos++
                    }



                    mPhotoList.add(
                        pos,
                        PhotoModelCreation(
                            files[i + 1].absolutePath,
                            dateFormat.format(current),
                            NUMBER_OF_DATES,
                            false,
                            false,
                            null,
                            false,
                            false
                        )
                    )

                    Log.d("mycreationsda", "getPhotos: Images " + files[i + 1].absolutePath)
                }
            }*/
        }
    }

    private fun setDataToAdapter() {
        myPhotosAdapter = MyPhotosAdapter(requireActivity(), mPhotoList!!,
            object : MyPhotosAdapter.OnClickImage {
                override fun onClick(i: Int) {
                    val path: String = mPhotoList[i].path!!
                    dateCount = mPhotoList!![i].date_count
                    clickedItem = i - dateCount + 1
                    Log.d("TAG", "onClick: $path")
                    if (path != "") {
                        if (isValidVideoFile(requireContext(), path)){
                            context?.let {
                                startActivity(Intent(it, FullMyPhotoActivity::class.java).apply {
                                    putExtra("type", "view")
                                    putExtra("image", path)
                                    putExtra("from", "video")
                                })
                            }
                        }else{
                            showToast("Video file is corrupted.")
                        }
                    }
                }

                override fun onLongClick() {
                    openMenu()
                }
            })
        val layoutManager = GridLayoutManager(activity, 3)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(i: Int): Int {
                return when (myPhotosAdapter!!.getItemViewType(i)) {
                    MyPhotosAdapter.SHOW_DATE -> 3
                    MyPhotosAdapter.SHOW_ADS -> 3
                    MyPhotosAdapter.SHOW_IMAGE -> 1
                    else -> 1
                }
            }
        }
        //    myphotos.addItemDecoration(new GridSpacingItemDecoration(3,10,true));
        mRecyclerMyVideos!!.layoutManager = layoutManager
        mRecyclerMyVideos!!.adapter = myPhotosAdapter
    }

    private fun openMenu() {
        mOnLongClickPressedMyCreation!!.isLongClickPressed(true)
    }

    inner class LoadAllVideoTask : AsyncTask<Void, Void, Void>() {
        override fun doInBackground(vararg p0: Void?): Void? {
            getVideos()
            return null
        }

        override fun onPostExecute(result: Void?) {
            super.onPostExecute(result)
            if (myPhotosAdapter != null) {
                myPhotosAdapter!!.notifyDataSetChanged()
            }
            if (mPhotoList!!.size == 0) {
                progressBar1!!.visibility = View.GONE
                mRecyclerMyVideos!!.visibility = View.GONE
                mConstraintVideoNotFound!!.visibility = View.VISIBLE
            } else {
                activity?.let {
                    setDataToAdapter()
                    Handler(Looper.getMainLooper()).postDelayed({
                        progressBar1!!.visibility = View.GONE
                        mRecyclerMyVideos!!.visibility = View.VISIBLE
                        mConstraintVideoNotFound!!.visibility = View.GONE
                    }, 1000)
                }

            }
        }

    }

    companion object {
        var myPhotosAdapter: MyPhotosAdapter? = null
        var mConstraintVideoNotFound: ConstraintLayout? = null
        val mPhotoList: ArrayList<PhotoModelCreation> = ArrayList()
    }

    override fun onPause() {
        super.onPause()
    }
}