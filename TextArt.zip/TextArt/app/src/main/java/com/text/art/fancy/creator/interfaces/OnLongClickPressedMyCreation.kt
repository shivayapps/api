package com.text.art.fancy.creator.interfaces

interface OnLongClickPressedMyCreation {
    fun isLongClickPressed(isVisible:Boolean)
}