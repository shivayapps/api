package com.text.art.fancy.creator.model.creation



class PhotoModelCreation {
    var path: String? = null
    var date: String? = null
    var date_count = 0
    var isHeader = false
    var isShowAds = false
    var unifiedNativeAd: String? = null
    var isDelete:Boolean = false
    var isVisible:Boolean = false
    var isImage:Boolean? = null

    constructor() {}

    constructor(path: String?, date: String?, date_count: Int, isHeader: Boolean, isShowAds: Boolean, unifiedNativeAd: String?, isDelete: Boolean, isImage: Boolean) {
        this.path = path
        this.date = date
        this.date_count = date_count
        this.isHeader = isHeader
        this.isShowAds = isShowAds
        this.unifiedNativeAd = unifiedNativeAd
        this.isDelete = isDelete
        this.isImage = isImage
    }

}