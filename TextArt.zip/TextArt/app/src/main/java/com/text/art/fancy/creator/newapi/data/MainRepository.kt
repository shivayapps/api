package com.text.art.fancy.creator.newapi.data

import com.text.art.fancy.creator.newapi.data.ApiHelper

class MainRepository(private val mApiHelper: ApiHelper) {

    suspend fun getTemplates() = mApiHelper.getTemplates()
    suspend fun getCategory(categoryId : Int, subCategoryId : Int?, limit : Int = 18 , page : Int) = mApiHelper.getCategory(categoryId,subCategoryId,limit,page)
//    suspend fun getFontStyle(limit: Int, page: Int) = mApiHelper.getFontStyle(limit, page)

}