package com.text.art.fancy.creator.model

import android.graphics.Bitmap

data class LottieData(
	val width : Int?=null,
	val height : Int?=null,
	val layertype: Layertype? = null
)

data class Layertype(
	val image: ArrayList<ImageItem?>? = null,
	val text: ArrayList<TextItem?>? = null
)

data class TextItem(
	val textID: String? = null,
	val textValue: String? = null,
	val maxSize: Int? = null
)

data class ImageItem(
	val imageID: String? = null,
	val imageValue: Bitmap? = null
)

