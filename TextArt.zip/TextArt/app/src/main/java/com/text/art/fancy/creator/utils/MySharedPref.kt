package com.text.art.fancy.creator.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri

@SuppressLint("CommitPrefEdits")
class MySharedPref(context: Context?) {
    var context: Context? = null
    var sharedPreferences: SharedPreferences
    var editor: SharedPreferences.Editor

    var image: String?
        get() = sharedPreferences.getString("image", null)
        set(image) {
            editor.putString("image", image)
            editor.commit()
        }

    var language: String?
        get() = sharedPreferences.getString("language", "English")
        set(language) {
            editor.putString("language", language)
            editor.commit()
        }

    var lastDownloadDate: String?
        get() = sharedPreferences.getString("logoJson", "")
        set(lastDownload) {
            editor.putString("logoJson", lastDownload)
            editor.commit()
        }

    fun setScaleType(scale: String?) {
        editor.putString("scale", scale)
        editor.commit()
    }
    fun setAdsCount(int: Int?) {
        editor.putInt("isAdsCount", int!!)
        editor.apply()
    }

    fun getAdsCount(): Int {
        return sharedPreferences.getInt("isAdsCount", 0)
    }

    fun setBoyPosition(int: Int) {
        editor.putInt("boyPos", int)
        editor.apply()
    }

    fun getBoyPosition(): Int {
        return sharedPreferences.getInt("boyPos", 0)
    }

    fun setGirlPosition(int: Int) {
        editor.putInt("girlPos", int)
        editor.apply()
    }

    fun getGirlPosition(): Int {
        return sharedPreferences.getInt("girlPos", 0)
    }

    fun setJokerPosition(int: Int) {
        editor.putInt("jokerPos", int)
        editor.apply()
    }

    fun getJokerPosition(): Int {
        return sharedPreferences.getInt("jokerPos", 0)
    }

    fun needToshowLanguage(): Boolean {
        return sharedPreferences.getBoolean("SHOW_LANGUAGE", true)
    }

    fun getRateShown(): Boolean {
        return sharedPreferences.getBoolean("rateClickOrNot", false)
    }

    fun getAdsClicked(): Boolean {
        return sharedPreferences.getBoolean("adsClickOrNot", false)
    }

    fun getAdsCreationClicked(): Boolean {
        return sharedPreferences.getBoolean("getAdsCreationClicked", false)
    }

    fun noNeedToShowLanguage() {
        editor.putBoolean("SHOW_LANGUAGE", false)
        editor.commit()
    }
    fun setApiAdsCount(int: Int?) {
        editor.putInt("setApiAdsCount", int!!)
        editor.apply()
    }

    fun setRateShown(id: String, b: Boolean) {
        editor.putBoolean(id, b)
        editor.commit()
    }

    fun getApiAdsCount(): Int {
        return sharedPreferences.getInt("setApiAdsCount", 0)
    }
    val scale: String?
        get() = sharedPreferences.getString("scale", "fill")

    var vibration: Boolean
        get() = sharedPreferences.getBoolean("vibrate", true)
        set(onOff) {
            editor.putBoolean("vibrate", onOff)
            editor.commit()
        }

    var count: Int
        get() = sharedPreferences.getInt("count", 0)
        set(count) {
            editor.putInt("count", count)
            editor.commit()
        }

    var uri: String?
        get() = sharedPreferences.getString("image", null)
        set(image) {
            editor.putString("image", image)
            editor.commit()
        }


    fun setIsFirstNotification() {
        editor.putBoolean("isFirst", false)
        editor.commit()
    }

    fun setImagePath(string: String) {
        editor.putString("galleyImage", string)
        editor.commit()
    }

    val galleyImage: String?
        get() = sharedPreferences.getString("galleyImage", null)

    val isFirstNotification: Boolean
        get() = sharedPreferences.getBoolean("isFirst", true)

    fun setFirstAlarm() {
        editor.putBoolean("isFirstAlarm", false)
        editor.commit()
    }

    fun setVisitPlay() {
        editor.putString("visit_play", "visit_play")
        editor.commit()
    }

    val visitPlay: String?
        get() = sharedPreferences.getString("visit_play", null)

    var countExist: Int
        get() = sharedPreferences.getInt("count_exist", 0)
        set(count) {
            editor.putInt("count_exist", count)
            editor.commit()
        }

    var countCreated: Int
        get() = sharedPreferences.getInt("count_created", 0)
        set(count) {
            editor.putInt("count_created", count)
            editor.commit()
        }

    val firstAlarm: Boolean
        get() = sharedPreferences.getBoolean("isFirstAlarm", true)

    fun setDoNotAsk() {
        editor.putString("do_not_ask", "do_not_ask")
        editor.commit()
    }

    val doNotAsk: String?
        get() = sharedPreferences.getString("do_not_ask", null)

    val scaleType: Any?
        get() = sharedPreferences.getString("scale_type", "fill")

    fun storeEventWallpaperPosition(mPosition: Int) {
        editor.putInt("position", mPosition)
        editor.commit()
    }

    val position: Int
        get() = sharedPreferences.getInt("position", 0)

    fun isAlarmSet(id: Int): Boolean {
        return sharedPreferences.getBoolean(id.toString(), false)
    }

    fun setAlarm(id: Int, b: Boolean) {
        editor.putBoolean(id.toString(), b)
        editor.commit()
    }
    fun isDatabaseClear(id: Int): Boolean {
        return sharedPreferences.getBoolean(id.toString(), false)
    }

    fun setDatabaseClear(id: Int, b: Boolean) {
        editor.putBoolean(id.toString(), b)
        editor.commit()
    }

    fun setAdsClicked(id: String, b: Boolean) {
        editor.putBoolean(id, b)
        editor.commit()
    }
    fun setAdsCreationClicked(id: String, b: Boolean) {
        editor.putBoolean(id, b)
        editor.commit()
    }

    var alarmId: Int
        get() = sharedPreferences.getInt("ALARM_ID", -1)
        set(id) {
            editor.putInt("ALARM_ID", id)
            editor.commit()
        }

    fun removeAlarm(id: Int) {
        editor.remove(id.toString())
        editor.commit()
    }

    fun setDisplayWidth(i: Int) {
        editor.putInt("displaywidth", i)
        editor.commit()
    }

    fun setDisplayHeight(i: Int) {
        editor.putInt("displayheight", i)
        editor.commit()
    }

    val deviceWidth: Int
        get() = sharedPreferences.getInt("displaywidth", 1080)

    val deviceHeight: Int
        get() = sharedPreferences.getInt("displayheight", 1920)

    companion object {
        private const val TAG = "MySharedPref"
        var ADS_REMOVED = "AdsRemoved"
    }

    init {
        this.context = context
        sharedPreferences = context!!.getSharedPreferences("my_pref", Context.MODE_PRIVATE)
        editor = sharedPreferences.edit()
    }
}