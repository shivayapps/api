package com.text.art.fancy.creator.activitys

import android.animation.Animator
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.text.Editable
import android.util.Log
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.fragment.app.FragmentContainerView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.*
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.text.art.fancy.creator.lottieaudiorendering.data.*
import com.text.art.fancy.creator.lottieaudiorendering.utils.TransformationUtil
import com.text.art.fancy.creator.lottievideorendering.utils.JsonUtils
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.adepter.*
import com.text.art.fancy.creator.adepter.LottieMusicAdapter.Companion.selectedAudioPosition
import com.text.art.fancy.creator.adepter.LottieMusicAdapter.Companion.selectedMusicPosition
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.comman.Constants.MusicFolder
import com.text.art.fancy.creator.fragment.CropMusicFragment
import com.text.art.fancy.creator.fragment.SelectMusicFragment
import com.text.art.fancy.creator.fragment.SelectMusicFragment.Companion.isAdBtnClick
import com.text.art.fancy.creator.interfaces.MusicListener
import com.text.art.fancy.creator.model.LottieData
import com.text.art.fancy.creator.utils.*
import com.text.art.fancy.creator.viewModel.OfflineMusicViewModel
import com.text.art.fancy.creator.lottievideorendering.VideoCreator
import com.text.art.fancy.creator.lottievideorendering.VideoCreator.Companion.progressDialog

import com.linkedin.android.litr.MediaTransformer
import com.linkedin.android.litr.utils.MediaFormatUtils
import com.linkedin.android.litr.utils.TranscoderUtils
import com.vasu.image.video.pickrandom.galleryapp.VasuImagePicker
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.*


class EditAnimationActivity : AppCompatActivity(), LottieChangeListener, ImageChangeListener,
    MusicListener {

    private val TAG = "EditAnimationActivity"
    private val CHANGE_IMAGE_CODE = 102

    private lateinit var addTextToolbar: Toolbar
    private lateinit var context: EditAnimationActivity
    private lateinit var container: FragmentContainerView
    private lateinit var btnback: ImageView
    private lateinit var btnVolume: ImageView
    private lateinit var btnSave: ImageView
    private lateinit var imgText: ImageView
    private lateinit var txtText: TextView
    private lateinit var imgImage: ImageView
    private lateinit var txtImage: TextView
    private lateinit var imgMusic: ImageView
    private lateinit var txtMusic: TextView
    private lateinit var txtMusicName: TextView
    private lateinit var btnDefault: CardView
    private lateinit var btnFromFile: CardView
    private lateinit var btnTextList: ConstraintLayout
    private lateinit var btnImgList: ConstraintLayout
    private lateinit var btnMusicList: ConstraintLayout
    private lateinit var noImageLayerFound: ConstraintLayout
    private lateinit var editImageView: ConstraintLayout
    private lateinit var editMusicView: ConstraintLayout
    private lateinit var lottieView: LottieAnimationView
    private lateinit var rvText: RecyclerView
    private lateinit var rvImage: RecyclerView
    private lateinit var progressBar: ProgressBar

    private lateinit var lottieFile: String
    private lateinit var fontFile: String
    private lateinit var jsonPath: String
    private lateinit var fontPath: String
    private lateinit var bitmapList: ArrayList<Bitmap>
    private lateinit var videoCreator: VideoCreator

    private lateinit var composition: LottieResult<LottieComposition>
    private lateinit var lottieLayers: ArrayList<LottieData>
    private lateinit var textDelegate: TextDelegate
    private lateinit var textAdapter : LottieEditTextAdapter
    private lateinit var imageAdapter : LottieEditImageAdapter
    private lateinit var currentImageRefID : String
//    private var haveAudioPermission = false
    private var musicUriFromFile: Uri ?= null
    private var isCropDialogOpen = false
    private var isImageLoaded = false
    private var isImageLayerAvilable = false

    private val EDIT_TEXT = "Edit Text"
    private val EDIT_IMG = "Edit Img"
    private val EDIT_MUSIC = "Edit MUSIC"
    private var selectedLayer = EDIT_TEXT

    private var lastClickTime = 0L

    private lateinit var dialog: Dialog
    private val lottieDrawable = LottieDrawable()
    private var DEFAULT_VIDEO_WIDTH = 1080f
    private var DEFAULT_VIDEO_HEIGHT = 1080f

    //TODO Music
    private lateinit var offlineMusicData : OfflineMusicViewModel
    private var mediaTransformer: MediaTransformer ?= null
    private lateinit var sourceVideo: SourceMedia
    private lateinit var sourceAudio: SourceMedia
    private lateinit var transformationState: TransformationState
    private lateinit var transformationPresenter: TransformationPresenter
    private var targetMedia: TargetMedia =
        TargetMedia()
    private var mp: MediaPlayer ?= null
    private var isInBackground = false
    private val KEY_ROTATION = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) MediaFormat.KEY_ROTATION else "rotation-degrees"
    private val PICK_MEDIA = 42


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_animation)
        context = this@EditAnimationActivity

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        try {
            addTextToolbar.setPadding(0, getStatusbarHeight(), 0, 0)
            hideSystemUI()
        } catch (e: Exception) { }

        initViews()
        buildDialog()
        if (intent.hasExtra("fileName")) {
            setSelectedJSONToLottieView()
        }else{
            showToast("Try again later")
            finish()
        }
    }

    private fun buildDialog() {
        //TODO OnBackPress Dialog
        dialog = Dialog(this)

        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_exit)

        val btnPositive = dialog.findViewById<TextView>(R.id.btnPositive)
        val btnNegative = dialog.findViewById<TextView>(R.id.btnNegative)
        val btnClose = dialog.findViewById<ImageView>(R.id.btnClose)

        btnClose.click {
            dialog.dismiss()
            Log.d(TAG, "manageMusic 1")
            manageMusic(isFromUser = false) //btnClose
        }
        btnPositive.click {
            dialog.dismiss()
            Log.d(TAG, "manageMusic 1")
            manageMusic(isFromUser = false) //btnPositive
        }

        btnNegative.click {
            mp?.release()
            mp = null
            dialog.dismiss()
            finish()
        }

        dialog.window!!.setLayout(
            (displayWidth() * 0.92).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun setSelectedJSONToLottieView() {
        lottieFile = intent.getStringExtra("fileName")!!
        jsonPath = "$cacheDir/$lottieFile"
        fontFile = lottieFile.replace(".json",".ttf")
        fontPath = "$cacheDir/$fontFile"
        Log.d(TAG, "File Name : jsonPath : $jsonPath")
        Log.d(TAG, "File Name : fontFile : $fontFile")
        Log.d(TAG, "File Name : lottieFile : $lottieFile")
        if (File(cacheDir, lottieFile).exists()){
            if (File(cacheDir, fontFile).exists()){
                lottieView.setFontAssetDelegate(object : FontAssetDelegate() {
                    override fun fetchFont(fontFamily: String): Typeface {
                        return Typeface.createFromFile(fontPath)
                    }
                })
            }else{
                lottieView.setFontAssetDelegate(object : FontAssetDelegate() {
                    override fun fetchFont(fontFamily: String): Typeface {
                    return Typeface.createFromAsset(assets,"fonts/Default.ttf")
                    }
                })
            }

            initData()
            initClicks()
            initActions()
        }
    }

    private fun initData() {
        loadOfflineMusicData()
        //TODO Initialize Variables
        mediaTransformer = MediaTransformer(this)
        mediaTransformer?.let{
            sourceVideo =
                SourceMedia()
            sourceAudio =
                SourceMedia()
            transformationState =
                TransformationState()
            transformationPresenter =
                TransformationPresenter(
                    context,
                    it
                )
        }

        lottieLayers = ArrayList()
        TextDelegate(lottieView)

        //Getting Lottie File
        if (lottieFile.isNullOrEmpty()) {
            Toast.makeText(this, "Animation Loading Error", Toast.LENGTH_SHORT).show()
        }
        bitmapList = ArrayList()

        val jsonStr = readFromFile(File(jsonPath))

        lottieView.apply {
            setAnimationFromJson(jsonStr,"${System.currentTimeMillis()}")
            loop(true)
            playAnimation()
            this.addAnimatorListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {}
                override fun onAnimationEnd(animation: Animator) {}
                override fun onAnimationCancel(animation: Animator) {}
                override fun onAnimationRepeat(animation: Animator) {
                    val fragmentOpen = supportFragmentManager.findFragmentByTag("musicFragment")
                    val dialogOpen = supportFragmentManager.findFragmentByTag(CropMusicFragment.TAG)
                    if (dialogOpen != null && dialogOpen.isAdded){
                        Log.d(TAG, "onAnimationRepeat: dialogOpen")
                    }else if (fragmentOpen != null && fragmentOpen.isAdded){
                        Log.d(TAG, "onAnimationRepeat: fragmentOpen")
                    }else if (!dialog.isShowing && !isAdBtnClick && !isInBackground) {
                        Log.d(TAG, "onAnimationRepeat 2")
                        Log.d(TAG, "manageMusic 2")
                        manageMusic(isFromUser = false) //onAnimationRepeat
                    }
                }
            })

            Log.d(TAG, "initData: LottieAnimation Frame ${lottieView.duration}")

        }
    }

    private fun loadOfflineMusicData() {
        offlineMusicData = ViewModelProvider(this)[OfflineMusicViewModel::class.java]
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun initClicks() {

        textDelegate = TextDelegate(lottieView)
        lottieView.setTextDelegate(textDelegate)

        lottieView.addLottieOnCompositionLoadedListener {
            onCompositionLoaded(it,true)
        }

        GlobalScope.launch(Dispatchers.IO) {
            composition = LottieCompositionFactory.fromJsonStringSync(readFromFile(File(jsonPath)),"cacheKey")
            lottieDrawable.composition = composition.value
            composition.value?.duration?.let { lottieDuration = it }
        }

        btnVolume.click{
            when(btnVolume.tag){
                "vol" -> {
                    btnVolume.tag = "none"
                    btnVolume.setImageResource(R.drawable.ic_mute)
                    mp?.pause()
                }
                "none" -> {
                    btnVolume.tag = "vol"
                    btnVolume.setImageResource(R.drawable.ic_volume)
                    Log.d(TAG, "manageMusic 3")
                    manageMusic(isFromUser = false) //"none"
                }
            }
        }

        btnTextList.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 300) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            selectedLayer = EDIT_TEXT
            setSelection(txtText, imgText)

            noImageLayerFound.hide()
            progressBar.hide()
            editMusicView.hide()
            editImageView.hide()
            rvText.show()
        }
        btnImgList.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 300) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            selectedLayer = EDIT_IMG
            hideKeyboard()
            setSelection(txtImage, imgImage)
            rvText.hide()
            editMusicView.hide()
            editImageView.show()

            if (isImageLoaded){
                progressBar.hide()
                editImageView.show()
                if (isImageLayerAvilable && selectedLayer == EDIT_IMG){
                    noImageLayerFound.hide()
                }else{
                    noImageLayerFound.show()
                }
            }else{
                progressBar.show()
                editImageView.hide()
                Handler(Looper.getMainLooper()).postDelayed({
                    if (lottieLayers[0].layertype!!.image!!.size > 0){
                        progressBar.hide()
                        isImageLoaded = true
                        isImageLayerAvilable = true
                        if (selectedLayer == EDIT_IMG){
                            btnImgList.performClick()
                        }
                    }else{
                        isImageLoaded = true
                        isImageLayerAvilable = false
                        if (selectedLayer == EDIT_IMG){
                            noImageLayerFound.show()
                            btnImgList.performClick()
                        }
                    }
                },7000)
            }
        }
        btnMusicList.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 300) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            selectedLayer = EDIT_MUSIC
            hideKeyboard()
            setSelection(txtMusic, imgMusic)

            noImageLayerFound.hide()
            progressBar.hide()
            rvText.hide()
            editImageView.hide()

            if (selectedMusicPosition == -1 && musicUriFromFile == null) {
                val musicFragment = SelectMusicFragment.newInstance("")
                with(container) {
                    isClickable = true
                    supportFragmentManager.beginTransaction()
                        .setCustomAnimations(R.anim.anim_slide_up, R.anim.anim_slide_down)
                        .add(id, musicFragment, "musicFragment")
                        .commit()
                }
            }else{
                editMusicView.show()
            }
        }

        btnDefault.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 500) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            stopPlaying()
            val musicFragment = SelectMusicFragment.newInstance("Default")
            with(container) {
                isClickable = true
                supportFragmentManager.beginTransaction()
                    .setCustomAnimations(R.anim.anim_slide_up, R.anim.anim_slide_down)
                    .add(id, musicFragment, "musicFragment")
                    .commitAllowingStateLoss()
            }
        }
        btnFromFile.click {
            /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkPermissions()
            }
            if (!haveAudioPermission) return@click*/
            if (SystemClock.elapsedRealtime() - lastClickTime < 500) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            stopPlaying()
            val musicFragment = SelectMusicFragment.newInstance("File")
            with(container) {
                isClickable = true
                supportFragmentManager.beginTransaction()
                    .setCustomAnimations(R.anim.anim_slide_up, R.anim.anim_slide_down)
                    .add(id, musicFragment, "musicFragment")
                    .commitAllowingStateLoss()
            }
        }

        btnback.setOnClickListener {
            onBackPressed()
        }

        btnSave.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            var isContainText = false
            for (i in 0 until rvText.childCount) {
                val child = rvText.getChildAt(i).findViewById<EditText>(R.id.lottieEditText)
                try {
                    if ((child is EditText && child.text.trim().toString().isNotEmpty())) {
                        isContainText = true
                        break
                    }else {
                        isContainText = false
                    }
                }catch (e: TypeCastException){ } catch (e: Exception){}
            }
            if (!isContainText){
                showToast("Please enter text")
                return@setOnClickListener
            }

            rvText.hide()
            editImageView.hide()
            editMusicView.hide()

            hideKeyboard()
            lottieView.frame = 0
            stopPlaying()

            isInBackground = true
            Log.d(TAG, "initClicks: Source Audio ${sourceAudio.uri}")

            //TODO Set Audio File To Muxer
            videoCreator.createVideo(containsAudio = true) {
                Log.d(TAG, "video Update :-> Started Adding Music.")
                addMusicToVideo(it)
            }

            //TODO Original With AndWithout Audio Save Video
            /*if (sourceAudio.uri != null && btnVolume.tag == "vol"){
                //TODO Set Audio File To Muxer
                videoCreator.createVideo(containsAudio = true) {
                    Log.d(TAG, "video Update :-> Started Adding Music.")
                    addMusicToVideo(it)
                }
            }else{
                Log.d(TAG, "video Update :-> Audio File Is Not Exist.")
                Log.d(TAG, "video Update :-> Started Making Video Without Music.")
                //TODO Generate Simple Video
                videoCreator.createVideo { file ->
                    Intent(context, ShareVideoActivity::class.java).also {
                        it.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        it.putExtra("videoPath", file.absolutePath)
                        startActivity(it)
                    }
                }
            }*/
        }
    }

    private fun setSelection(txtView: TextView, imgView: ImageView) {
        imgMusic.setColorFilter(ContextCompat.getColor(this,R.color.black))
        txtMusic.setTextColor(ContextCompat.getColor(this,R.color.black))
        imgImage.setColorFilter(ContextCompat.getColor(this, R.color.black))
        txtImage.setTextColor(ContextCompat.getColor(this,R.color.black))
        imgText.setColorFilter(ContextCompat.getColor(this, R.color.black))
        txtText.setTextColor(ContextCompat.getColor(this,R.color.black))
        txtView.setTextColor(ContextCompat.getColor(this,R.color.colorPrimary))
        imgView.setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary))
    }

    /*@RequiresApi(Build.VERSION_CODES.M)
    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            haveAudioPermission = true
        } else {
            haveAudioPermission = false
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                3000)
        }
    }*/

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        /*when (requestCode) {
            3000 -> {
                haveAudioPermission = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            }
            else ->
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
        if (haveAudioPermission){
            btnFromFile.performClick()
        }else{
            val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.RECORD_AUDIO)
            if (!showRationale)
                showToast("Permission Is Required To Show Waves Of Music.")
        }*/
    }

    private fun addMusicToVideo(file: File) {
        //TODO Set Video File To Muxer
        updateSourceMedia(sourceVideo, file.absolutePath.toUri())

        //TODO: Wood (Remove When Issue Solved)
        if (btnVolume.tag == "none"){
            updateSourceMedia(sourceAudio, "$cacheDir/$MusicFolder/Z_Mute.mp3".toUri())
        }else if(selectedMusicPosition != -1){
            offlineMusicData.offlineMusicList.value?.let {
                updateSourceMedia(sourceAudio, it[selectedMusicPosition].musicPath.toUri())
            }
        }else if (selectedAudioPosition != -1){
            musicUriFromFile?.let { updateSourceMedia(sourceAudio, it) }
        }

        val targetFile = File(getTargetFileDirectory(), "TextArt_${TransformationUtil.getDisplayName(context, file.path.toUri())}.mp4")
        targetMedia.setTargetFile(targetFile)
        Log.d(TAG, "onVideoCompleted: path file is -> ${file.absolutePath}")
        Log.d(TAG, "onVideoCompleted: path targetFile is -> $targetFile")

        //TODO Generating Final OUTPUT
        if (transformationState.state != TransformationState.STATE_RUNNING){
            transformationPresenter.muxVideoAndAudio(sourceVideo, sourceAudio, targetMedia, transformationState)
            Log.d(TAG, "video Update :-> Muxing Process Started.")
        }else{
            showToast(getString(R.string.something_went_wrong))
            finish()
        }

    }

    private fun readFromFile(file:File): String? {
        var ret = ""
        try {
            val inputStream = FileInputStream(file)
            if (inputStream != null) {
                val inputStreamReader = InputStreamReader(inputStream)
                val bufferedReader = BufferedReader(inputStreamReader)
                var receiveString: String? = ""
                val stringBuilder = StringBuilder()
                while (bufferedReader.readLine().also { receiveString = it } != null) {
                    stringBuilder.append(receiveString)
                }
                inputStream.close()
                ret = stringBuilder.toString()
            }
        } catch (e: FileNotFoundException) {
            Log.e(TAG, "File not found: $e")
        } catch (e: IOException) {
            Log.e(TAG, "Can not read file: $e")
        }
        return ret
    }

    private fun setRecyclerView(isTextReset: Boolean) {
//        lottieLayers[0].layertype!!.image!!.reverse()
//        lottieLayers[0].layertype!!.text!!.reverse()
        for(i in lottieLayers[0].layertype!!.text!!){
            Log.d(TAG, "setRecyclerView: data $i")
        }
        if (isTextReset){
            textAdapter = LottieEditTextAdapter(lottieLayers,this)
            rvText.layoutManager = LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL,false)
            rvText.adapter = textAdapter
        }

        imageAdapter = LottieEditImageAdapter(lottieLayers,this)
        rvImage.layoutManager = GridLayoutManager(this,3,
            GridLayoutManager.VERTICAL,false)
        rvImage.adapter = imageAdapter
    }

    private fun initActions() {
        selectedAudioPosition = -1
        selectedMusicPosition = 0
        offlineMusicData.offlineMusicList.observe(this){ data ->
            updateSourceMedia(sourceAudio, data[0].musicPath.toUri())
            playAudio("$cacheDir/${MusicFolder}/${data[0].musicName}")
            txtMusicName.text = data[0].musicName.replace(".mp3","")
            Log.d(TAG, "manageMusic 4")
            manageMusic(isFromUser = false) //Default Play First
        }
    }

    private fun initViews() {
        container = findViewById(R.id.container)
        btnback = findViewById(R.id.imgBtnBack)
        btnVolume = findViewById(R.id.btnVolume)
        btnSave = findViewById(R.id.imgBtnSave)
        imgText = findViewById(R.id.imgText)
        txtText = findViewById(R.id.txtText)
        imgImage = findViewById(R.id.imgImage)
        txtMusic = findViewById(R.id.txtMusic)
        txtMusicName = findViewById(R.id.txtMusicName)
        btnDefault = findViewById(R.id.btnDefault)
        btnFromFile = findViewById(R.id.btnFromFile)
        imgMusic = findViewById(R.id.imgMusic)
        noImageLayerFound = findViewById(R.id.noImageLayerFound)
        editImageView = findViewById(R.id.editImageView)
        editMusicView = findViewById(R.id.editMusicView)
        txtImage = findViewById(R.id.txtImage)
        addTextToolbar = findViewById(R.id.addTextToolbar)
        btnTextList = findViewById(R.id.btnTextList)
        btnImgList = findViewById(R.id.btnImgList)
        btnMusicList = findViewById(R.id.btnMusicList)
        lottieView = findViewById(R.id.mainLottieEditView)
        rvText = findViewById(R.id.rvText)
        rvImage = findViewById(R.id.rvImage)
        progressBar = findViewById(R.id.mProgressBar)
        mp = MediaPlayer()
    }

    override fun textChange(textID: String, s: Editable) {
        textDelegate.setText(textID,s.toString())
    }

    override fun onImageChange(refId: String) {
        if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return
        lastClickTime = SystemClock.elapsedRealtime()
        currentImageRefID = refId
        chooseImageFromGallery()
    }

    private fun chooseImageFromGallery() {
        VasuImagePicker.ActivityBuilder(this)
            .setFolderMode(true)
            .setFolderTitle("Gallery")
            .setMultipleMode(false)
            .setImageCount(1)
            .setMaxSize(10)
            .setBackgroundColor("#FFFFFF")
            .setToolbarColor("#FFFFFF")
            .setToolbarTextColor("#000000")
            .setToolbarIconColor("#000000")
            .setStatusBarColor("#FFFFFF")
            .setProgressBarColor("#50b1ed")
            .setAlwaysShowDoneButton(true)
            .setRequestCode(CHANGE_IMAGE_CODE)
            .setKeepScreenOn(true)
            .start()
    }

    private fun pickImage(reqestCode: Int) {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent, reqestCode)
    }

    fun onCompositionLoaded(lottieComposition: LottieComposition, isTextReset: Boolean){ lottieComposition?:return

        if (lottieComposition.images.any{(_,asset)->!asset.hasBitmap()}){
            lottieView.setImageAssetDelegate { it.bitmap }
        }
        Log.d(TAG, "initViews: Normal Height ${lottieView.height} " + "Width ${lottieView.width}")
        Log.d(TAG, "initViews: layoutParams Height ${lottieView.layoutParams.height} " + "Width ${lottieView.layoutParams.width}")

        JsonUtils.getJsonData(context, lottieFile, lottieComposition, lottieLayers,true)
        setRecyclerView(isTextReset)

        DEFAULT_VIDEO_WIDTH = lottieLayers[0].width!!.toFloat() //1080
        DEFAULT_VIDEO_HEIGHT = lottieLayers[0].height!!.toFloat() //1920

        videoCreator = VideoCreator(lottieDrawable, DEFAULT_VIDEO_WIDTH, DEFAULT_VIDEO_HEIGHT,
            context, lottieView)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CHANGE_IMAGE_CODE && data != null && resultCode == RESULT_OK){
            val imagePath = data.getStringExtra("EXTRA_SELECTED_URI")
            if (imagePath == "") {
                return
            }
            Glide.with(context)
                .load(Uri.parse(imagePath))
                .into(object : CustomTarget<Drawable>() {
                    override fun onResourceReady(
                        resource: Drawable,
                        transition: Transition<in Drawable>?,
                    ) {
                        val bitmap = (resource as BitmapDrawable).bitmap
//                        val scaledBitmap = Bitmap.createScaledBitmap(bitmap,1080,1080,false)
                        val sizeBitmap = lottieView.composition!!.images[currentImageRefID]
                        val scaledBitmap = Bitmap.createScaledBitmap(bitmap,
                            sizeBitmap!!.width.toInt(), sizeBitmap.height.toInt(),false)
                        lottieView.updateBitmap(currentImageRefID,scaledBitmap)
                        lottieView.addLottieOnCompositionLoadedListener {
                            try {
                                onCompositionLoaded(it,false)
                                JsonUtils.getJsonData(context, lottieFile, it, lottieLayers,false)
                            }catch (e: IOException) { }
                        }
                        imageAdapter = LottieEditImageAdapter(lottieLayers,context)
                        rvImage.adapter = imageAdapter
                        rvImage.invalidate()
                    }

                    override fun onLoadFailed(errorDrawable: Drawable?) {
                        super.onLoadFailed(errorDrawable)
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {}
                })

//            val imageUri: Uri = data.data!!
//            val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, imageUri)
            /*if (bitmap!=null){
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap,1080,1080,false)
                lottieView.updateBitmap(currentImageRefID,scaledBitmap)
                lottieView.addLottieOnCompositionLoadedListener {
                    try {
                        onCompositionLoaded(it)
                        JsonUtils.getJsonData(this, lottieFile, it, lottieLayers)
                    }catch (e: IOException) {
                    }
                }
                imageAdapter = LottieEditImageAdapter(this,lottieLayers,this)
                rvImage.adapter = imageAdapter
                rvImage.invalidate()
            }else{
                showToast("Selected image is corrupted")
            }*/
        }

        /*if (requestCode==CHANGE_IMAGE_CODE&&resultCode== RESULT_OK&&data!=null){
            val imageUri: Uri = data.data!!
            val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, imageUri)
            if (bitmap!=null){
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap,1080,1080,false)
                lottieView.updateBitmap(currentImageRefID,scaledBitmap)
                lottieView.addLottieOnCompositionLoadedListener {
                    try {
                        onCompositionLoaded(it)
                        JsonUtils.getJsonData(this, lottieFile, it, lottieLayers)
                    }catch (e: IOException) {
                    }
                }
                imageAdapter = LottieEditImageAdapter(this,lottieLayers,this)
                rvImage.adapter = imageAdapter
                rvImage.invalidate()
            }else{
                showToast("Selected image is corrupted")
            }
        }*/
    }

    override fun onBackPressed() {
//        if (SystemClock.elapsedRealtime() - lastClickTime < 500) return
//        lastClickTime = SystemClock.elapsedRealtime()

        Log.d(TAG, "onBackPressed: 1. onBackPressed")
        val fragmentOpen = supportFragmentManager.findFragmentByTag("musicFragment")
        val dialogOpen = supportFragmentManager.findFragmentByTag(CropMusicFragment.TAG)
        if (fragmentOpen != null && fragmentOpen.isAdded) {
            Log.d(TAG, "onBackPressed: 1. fragmentOpen")
//            supportFragmentManager.beginTransaction()
//                .setCustomAnimations(
//                R.anim.anim_slide_up,
//                R.anim.anim_slide_down
//            ).remove(fragmentOpen).commit()
            supportFragmentManager.beginTransaction().remove(fragmentOpen).commit()
            container.isClickable = false
            if (selectedMusicPosition != -1 || musicUriFromFile != null){
                editMusicView.show()
            }else{
                editMusicView.hide()
            }

            if (!isCropDialogOpen){
                Log.d(TAG, "manageMusic 6")
                manageMusic(isFromUser = false) //onBackPressed
            }
            /*Handler(Looper.getMainLooper()).postDelayed({
                Log.d(TAG, "onBackPressed: Try ${dialogOpen != null} isAdded ${dialogOpen?.isVisible}")
                if (dialogOpen != null && dialogOpen.isVisible){
                    Log.d(TAG, "manageMusic 6")
                    manageMusic(isFromUser = false) //onBackPressed
                }
            },100)*/
        } else {
            Log.d(TAG, "onBackPressed: 1. else")
            if (!dialog.isShowing) {
                mp?.pause()
                dialog.show()
            }
        }
    }

    private fun updateSourceMedia(sourceMedia: SourceMedia, uri: Uri) {
        Log.d(TAG, "updateSourceMedia: Media Uri Is -> $uri")
        sourceMedia.uri = uri
        sourceMedia.size = TranscoderUtils.getSize(this, uri)
//        sourceMedia.duration = getMediaDuration(uri) / 1000f
        sourceMedia.duration = getMediaDuration(File(uri.toString())) / 1000f
        try {
            val mediaExtractor = MediaExtractor()
            mediaExtractor.setDataSource(this, uri, null)
            sourceMedia.tracks = java.util.ArrayList(mediaExtractor.trackCount)
            for (track in 0 until mediaExtractor.trackCount) {
                val mediaFormat = mediaExtractor.getTrackFormat(track)
                val mimeType = mediaFormat.getString(MediaFormat.KEY_MIME) ?: continue
                Log.d(TAG, "updateSourceMedia: Media mimeType Is -> $mimeType")
                when {
                    mimeType.startsWith("video") -> {
                        val videoTrack =
                            VideoTrackFormat(
                                track,
                                mimeType
                            )
                        videoTrack.width = getInt(mediaFormat, MediaFormat.KEY_WIDTH)
                        videoTrack.height = getInt(mediaFormat, MediaFormat.KEY_HEIGHT)
                        videoTrack.duration = getLong(mediaFormat, MediaFormat.KEY_DURATION)
                        videoTrack.frameRate = MediaFormatUtils.getFrameRate(mediaFormat, -1).toInt()
                        videoTrack.keyFrameInterval = MediaFormatUtils.getIFrameInterval(mediaFormat, -1).toInt()
                        videoTrack.rotation = getInt(mediaFormat, KEY_ROTATION, 0)
                        videoTrack.bitrate = getInt(mediaFormat, MediaFormat.KEY_BIT_RATE)
                        sourceMedia.tracks.add(videoTrack)
                    }
                    mimeType.startsWith("audio") -> {
                        val audioTrack =
                            AudioTrackFormat(
                                track,
                                mimeType
                            )
                        audioTrack.channelCount = getInt(mediaFormat, MediaFormat.KEY_CHANNEL_COUNT)
                        audioTrack.samplingRate = getInt(mediaFormat, MediaFormat.KEY_SAMPLE_RATE)
                        audioTrack.duration = getLong(mediaFormat, MediaFormat.KEY_DURATION)
                        audioTrack.bitrate = getInt(mediaFormat, MediaFormat.KEY_BIT_RATE)
                        sourceMedia.tracks.add(audioTrack)
                    }
                    else -> {
                        sourceMedia.tracks.add(
                            GenericTrackFormat(
                                track,
                                mimeType
                            )
                        )
                    }
                }
            }
        } catch (ex: IOException) {
            Log.e(TAG, "Failed to extract sourceMedia", ex)
        }
        sourceMedia.notifyChange()
    }

    private fun getInt(mediaFormat: MediaFormat, key: String): Int {
        return getInt(mediaFormat, key, -1)
    }

    private fun getInt(mediaFormat: MediaFormat, key: String, defaultValue: Int): Int {
        return if (mediaFormat.containsKey(key)) {
            mediaFormat.getInteger(key)
        } else defaultValue
    }

    private fun getLong(mediaFormat: MediaFormat, key: String): Long {
        return if (mediaFormat.containsKey(key)) {
            mediaFormat.getLong(key)
        } else -1
    }

    private fun playAudio(musicPath: String) {
        if(btnVolume.tag == "vol"){
             mp?.let {
                 it.reset()
                 it.setDataSource(musicPath)
                 it.prepare()
                 it.start()
                 lottieView.progress = 0f
             }
        }

    }

    private fun playAudio(musicPath: Uri, isFromUser: Boolean = true) {
        try {
            if(btnVolume.tag == "vol"){
                 mp?.let {
                     it.reset()
                     it.setDataSource(this, musicPath)
                     it.prepare()
                     it.start()
                     lottieView.progress = 0f
                 }
            }
        } catch (e: Exception) {
            if (isFromUser)
                showToast("Audio File Is Corrupted..!!!")
        }
    }

    override fun onResume() {
        super.onResume()
        when(selectedLayer){
            EDIT_TEXT  -> rvText.show()
            EDIT_IMG   -> editImageView.show()
            EDIT_MUSIC -> editMusicView.show()
        }
        val dialogOpen = supportFragmentManager.findFragmentByTag(CropMusicFragment.TAG)
        if (dialogOpen != null && dialogOpen.isAdded){
            isInBackground = false
            Log.d(TAG, "onResume: dialogOpen")
            return
        }
        val fragmentOpen = supportFragmentManager.findFragmentByTag("musicFragment")
        if (fragmentOpen != null && fragmentOpen.isAdded) {
            Log.d(TAG, "onResume: fragmentOpen")
            return
        }
        isInBackground = false
        if (progressDialog?.isShowing != true){
            Log.d(TAG, "manageMusic 5")
            manageMusic(isFromUser = false) //onResume
        }
        Log.d(TAG, "onResume: isInBackground $isInBackground")
    }

    override fun onPause() {
        super.onPause()
        stopPlaying()

        if (::dialog.isInitialized && dialog.isShowing) dialog.dismiss()
        isInBackground = true
    }

    private fun manageMusic(isFromUser: Boolean = true) {
        Log.d(TAG, "manageMusic: selectedMusicPosition -> $selectedMusicPosition")
        if (selectedMusicPosition != -1) {
            offlineMusicData.offlineMusicList.value?.let {
                playAudio("$cacheDir/$MusicFolder/${it[selectedMusicPosition].musicName}")
            }
        } else {
            musicUriFromFile?.let { playAudio(it, isFromUser) }
        }
    }

    private fun stopPlaying(): Boolean {
        return try {
            mp?.stop()
            true
        }catch (e: Exception){
            false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        deleteDirectory("$cacheDir/Videos")
        deleteDirectory("$cacheDir/TrimMusic")
        lottieDuration = 0F
        mp?.release()
        mp = null
        mediaTransformer?.release()
    }

    override fun onMusicClick(from:LottieMusicAdapter.MusicType, pos: Int, musicUri: Uri?, trimMusic: String?, trimMusicName: String?) {
        if(btnVolume.tag == "none") {
            btnVolume.tag = "vol"
            btnVolume.setImageResource(R.drawable.ic_volume)
        }

        if (from == LottieMusicAdapter.MusicType.OFFLINE){
            //TODO Offline Music
            if(pos != -1){
                offlineMusicData.offlineMusicList.value?.let {
                    updateSourceMedia(sourceAudio, it[pos].musicPath.toUri())
                    playAudio("$cacheDir/${MusicFolder}/${it[pos].musicName}")
                    txtMusicName.text = it[pos].musicName.replace(".mp3","")
                }
            }
        }else{
            when {
                //TODO Music From File
                musicUri != null -> {
                    stopPlaying()
                    CropMusicFragment.newInstance(pos, musicUri.toString()).show(supportFragmentManager, CropMusicFragment.TAG)
                    isCropDialogOpen = true
                    Log.d(CropMusicFragment.TAG, "onMusicClick: Music Uri Is From File-> $musicUri")
                }
                //TODO Trim Output Music From File
                trimMusic != null -> {
                    Log.d(TAG, "onMusicClick: Music Uri Is From File Trim-> ${trimMusic.toUri()}")
                    isCropDialogOpen = false
                    selectedMusicPosition = -1
                    selectedAudioPosition = pos
                    musicUriFromFile = trimMusic.toUri()
                    updateSourceMedia(sourceAudio, trimMusic.toUri())
                    if (!isInBackground){
                        playAudio(File(trimMusic).toUri())
                    }
                    txtMusicName.text = trimMusicName
                }
                else -> {
                    Log.d(TAG, "manageMusic 6")
                    manageMusic(isFromUser = false) //onMusicClick From File else
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        Log.d(TAG, "onSaveInstanceState: Before")
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstanceState: After")
    }

    companion object{
        var lottieDuration = 0F
    }

}