package com.text.art.fancy.creator.stickerapi;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.text.art.fancy.creator.activitys.StickerActivity;
import com.text.art.fancy.creator.categorys.ParametersItemAllChilds;
import com.text.art.fancy.creator.stickerapi.StickerDataFragment;

import java.util.ArrayList;

public class StickerPagerAdepter extends FragmentStatePagerAdapter {

    private final ArrayList<ParametersItemAllChilds> mParamList;
    private final boolean mIsSub;
    private final StickerActivity actionBottomDialogFragment;


    public StickerPagerAdepter(@NonNull FragmentManager fm, ArrayList<ParametersItemAllChilds> mParamList, boolean isSub, StickerActivity actionBottomDialogFragment) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        this.mParamList = mParamList;
        this.mIsSub = isSub;
        this.actionBottomDialogFragment = actionBottomDialogFragment;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
//        return new StickerDataFragment(position, actionBottomDialogFragment);
        return StickerDataFragment.newInstance(position);
    }

    @Override
    public int getCount() {
        return mParamList.size();
    }

}
