package com.text.art.fancy.creator.categorys.parameter

import com.google.gson.annotations.SerializedName

data class FontResponse(

    @SerializedName("ResponseCode")
    var responseCode: String? = null,

    @SerializedName("data")
    var data: List<DataItem?>? = null,

    @SerializedName("ResponseMessage")
    var responseMessage: String? = null
)

data class AllChildsItem(

    @SerializedName("new_id")
    var newId: Int? = null,

    @SerializedName("images")
    var images: List<ImagesItem?>? = null,

    @SerializedName("parent_id")
    var parentId: Int? = null,

    @SerializedName("name")
    var name: String? = null,

    @SerializedName("icon")
    var icon: Any? = null,

    @SerializedName("all_childs")
    var allChilds: List<Any?>? = null,

    @SerializedName("description")
    var description: Any? = null,

    @SerializedName("id")
    var id: Int? = null,

    @SerializedName("position")
    var position: Int? = null,

    @SerializedName("category_parameters")
    var categoryParameters: List<Any?>? = null
)

data class ImagesItem(

    @SerializedName("zip")
    var zip: String? = null,

    @SerializedName("image")
    var image: String? = null,

    @SerializedName("keywords")
    var keywords: List<Any?>? = null,

    @SerializedName("thumb_image")
    var thumbImage: String? = null,

    @SerializedName("coins")
    var coins: Int? = null,

    @SerializedName("video")
    var video: String? = null,

    @SerializedName("is_premium")
    var isPremium: Int? = null,

    @SerializedName("category_id")
    var categoryId: Int? = null,

    @SerializedName("size")
    var size: String? = null,

    @SerializedName("new_category_id")
    var newCategoryId: Int? = null,

    @SerializedName("name")
    var name: String? = null,

    @SerializedName("id")
    var id: Int? = null,

    @SerializedName("audio")
    var audio: String? = null,

    @SerializedName("position")
    var position: Int? = null
)

data class DataItem(

    @SerializedName("new_id")
    var newId: Int? = null,

    @SerializedName("images")
    var images: List<ImagesItem?>? = null,

    @SerializedName("parent_id")
    var parentId: Int? = null,

    @SerializedName("name")
    var name: String? = null,

    @SerializedName("icon")
    var icon: Any? = null,

    @SerializedName("all_childs")
    var allChilds: List<AllChildsItem?>? = null,

    @SerializedName("description")
    var description: Any? = null,

    @SerializedName("id")
    var id: Int? = null,

    @SerializedName("position")
    var position: Int? = null,

    @SerializedName("category_parameters")
    var categoryParameters: List<Any?>? = null
)
