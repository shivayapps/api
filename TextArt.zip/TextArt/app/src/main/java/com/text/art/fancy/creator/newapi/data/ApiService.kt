package com.text.art.fancy.creator.newapi.data


import com.text.art.fancy.creator.newapi.category.CategoryResponse
import com.text.art.fancy.creator.newapi.model.DataResponse
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {

//    @FormUrlEncoded
//    @POST("category_event_home_new")
//    suspend fun getData(
//        @Field("category_id") categoryId: Int,
//        @Field("app_id") appId: Int = 11
//    ): Response?
//
//    @FormUrlEncoded
//    @POST("category_event_home_new")
//    suspend fun getDataChild(
//        @Field("category_id") categoryId: Int,
//        @Field("app_id") appId: Int = 11,
//        @Field("child_id") child_id: Int
//    ): Response?

    @FormUrlEncoded
    @POST("home_category_images")
    suspend fun getTemplate(
        @Field("app_id") appId: Int = 11
    ): DataResponse?


    @FormUrlEncoded
    @POST("category_images_new")
    suspend fun getCategoryData(
        @Field("category_id") categoryId: Int,
        @Field("sub_category_id") subCategoryId: Int?,
        @Field("limit") limit: Int,
        @Field("page") page: Int,
        @Field("app_id") appId: Int = 11,
        @Field("image_type") imageType: String = "image"
    ): CategoryResponse?


//    @FormUrlEncoded
//    @POST("font_new")
//    suspend fun getFontStyle(
//        @Field("limit") limit: Int,
//        @Field("page") page: Int,
//        @Field("app_id") appId: Int = 11
//    ): GraphicsCategoryResponse?


}