package com.text.art.fancy.creator.activitys

import android.R.attr.tag
import android.annotation.SuppressLint
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.HomeActivity.Companion.fontList
import com.text.art.fancy.creator.adepter.EditNameAdapter
import com.text.art.fancy.creator.adepter.GenerateNameAdapter
import com.text.art.fancy.creator.adepter.SpinnerAdapter
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.utils.*


class GenerateNameActivity : AppCompatActivity(){

    private var TAG = "GenerateNameActivity"

    private lateinit var txtGenerateName: EditText
    private lateinit var txtEditName: EditText
    private lateinit var imgBoy: ImageView
    private lateinit var imgGirl: ImageView
    private lateinit var imgJoker: ImageView
    private lateinit var imgCopy: ImageView
    private lateinit var leftSpinner: Spinner
    private lateinit var rightSpinner: Spinner
    private lateinit var progressNameList: ProgressBar
    private lateinit var recyclerName: RecyclerView
    private lateinit var recyclerIcon: RecyclerView
    private lateinit var layoutEdit: ConstraintLayout
    private lateinit var layoutAddMore: ConstraintLayout

    //Data Variable
    private var boyNameList = arrayListOf<String>()
    private var girlNameList = arrayListOf<String>()
    private var jokerNameList = arrayListOf<String>()
    private var leftSpinnerList = arrayListOf<String>()
    private var rightSpinnerList = arrayListOf<String>()
    private var recyclerDataList = arrayListOf<String>()
    private var recyclerIconList = arrayListOf<String>()

    //Variables
    private var userName = "TextArt"
    private var leftPos  = 0
    private var rightPos = 0
    private var boyPos = 0
    private var girlPos = 0
    private var jokerPos = 0
    private var lastClickTime = 0L

    //Adapters
    private lateinit var leftAdapter: SpinnerAdapter
    private lateinit var rightAdapter: SpinnerAdapter
    private lateinit var recyclerNameAdapter: GenerateNameAdapter
    private lateinit var recyclerEditNameAdapter: EditNameAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generate_name)
        hideSystemUI()

        initViews()
        initData()
        initAdapter()
        initListener()
        initViewAction()
    }

    private fun initAdapter() {
        //init Spinner Adapter
        leftAdapter = SpinnerAdapter(this, leftSpinnerList)
        leftSpinner.adapter = leftAdapter
        rightAdapter = SpinnerAdapter(this, rightSpinnerList)
        rightSpinner.adapter = rightAdapter

        //init Recycler Adapter
        recyclerNameAdapter = GenerateNameAdapter(this, recyclerDataList,
            object : GenerateNameAdapter.OnItemClick{
                override fun onItemClick(position: Int, text: String) {
                    copyToClipboard(text)
                }

                override fun openEditLayout(position: Int   , text: String) {
                    hideKeyboard()
                    try {
                        txtEditName.typeface = Typeface.createFromAsset(assets, "${Constants.FontFolder}/${fontList[position]}")
                    } catch (e: Exception) { txtEditName.typeface = Typeface.createFromAsset(assets, "fonts/Default.ttf") }
                    txtEditName.setText(text)
                    layoutEdit.hide()
                    layoutAddMore.show()
                }
            })
        recyclerName.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false)
        recyclerName.adapter = recyclerNameAdapter

        recyclerEditNameAdapter = EditNameAdapter(recyclerIconList,
            object : EditNameAdapter.OnItemClick{
                override fun onItemClick(text: String) {
                    if (txtEditName.text.length < 30) {
                        val sb = StringBuilder(txtEditName.text.toString())
                        val selection = txtEditName.selectionStart
                        sb.insert(selection, text)
                        txtEditName.setText(sb.toString())
                        txtEditName.setSelection(selection + text.length)
                    }
                }
            })
        val gridLayoutManager = GridLayoutManager(this, 6)
        gridLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerIcon.layoutManager = gridLayoutManager
        recyclerIcon.adapter = recyclerEditNameAdapter

        progressNameList.hide()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initListener() {
        txtGenerateName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                progressNameList.show()
                userName = s.toString()
                invalidateList(s.toString())
            }
        })

        leftSpinner.setOnTouchListener { _, _ ->
            hideKeyboard()
            txtGenerateName.clearFocus()
            rightSpinner.clearFocus()
            false
        }
        rightSpinner.setOnTouchListener { _, _ ->
            hideKeyboard()
            txtGenerateName.clearFocus()
            leftSpinner.clearFocus()
            false
        }

        leftSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                leftSpinner.clearFocus()
                leftPos = position
                invalidateList(userName)
            }

            override fun onNothingSelected(p0: AdapterView<*>?) { leftSpinner.clearFocus() }
        }

        rightSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                rightPos = position
                invalidateList(userName)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) { rightSpinner.clearFocus() }

        }

    }

    @SuppressLint("NotifyDataSetChanged")
    private fun invalidateList(newText: String) {
        Log.d(TAG, "invalidateList: $newText")
        val newName = "${leftSpinnerList[leftPos]} $newText ${rightSpinnerList[rightPos]}"

        recyclerDataList.clear()
        for (i in fontList.indices){
            recyclerDataList.add(newName)
        }
        if (!recyclerDataList.isNullOrEmpty()){
            recyclerNameAdapter.notifyDataSetChanged()
        }
        progressNameList.hide()
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun initViewAction() {
        imgBoy.click {
            txtGenerateName.setText(boyNameList[boyPos])
            boyPos++
            if (boyPos >= boyNameList.size)
                boyPos = 0
            txtGenerateName.clearFocus()
            hideKeyboard()
        }
        imgGirl.click {
            txtGenerateName.setText(girlNameList[girlPos])
            girlPos++
            if (girlPos >= girlNameList.size)
                girlPos = 0
            txtGenerateName.clearFocus()
            hideKeyboard()
        }
        imgJoker.click {
            txtGenerateName.setText(jokerNameList[jokerPos])
            jokerPos++
            if (jokerPos >= jokerNameList.size)
                jokerPos = 0
            txtGenerateName.clearFocus()
            hideKeyboard()
        }
        imgCopy.click {
            hideKeyboard()
            copyToClipboard(txtEditName.text.toString())
        }
    }

    /*private fun convertStringToUTF8(s: String): String? {
        var out: String? = null
        out = try {
            String(s.toByteArray(charset("UTF-8")), charset("ISO-8859-1"))
        } catch (e: UnsupportedEncodingException) {
            return null
        }
        return out
    }*/

    private fun initViews() {
        txtGenerateName = findViewById(R.id.txtGenerateName)
        txtEditName = findViewById(R.id.txtEditName)
        imgBoy = findViewById(R.id.imgBoy)
        imgGirl = findViewById(R.id.imgGirl)
        imgJoker = findViewById(R.id.imgJoker)
        imgCopy = findViewById(R.id.imgCopy)
        leftSpinner = findViewById(R.id.leftSpinner)
        rightSpinner = findViewById(R.id.rightSpinner)
        progressNameList = findViewById(R.id.progressNameList)
        recyclerName = findViewById(R.id.nameList)
        recyclerIcon = findViewById(R.id.iconList)
        layoutEdit = findViewById(R.id.layoutEdit)
        layoutAddMore = findViewById(R.id.layoutAddMore)

//        leftSpinner.isFocusableInTouchMode = true
    }

    override fun onBackPressed() {
        if (layoutAddMore.visibility == View.VISIBLE){
            layoutAddMore.hide()
            layoutEdit.show()
            return
        }
        super.onBackPressed()
    }

    private fun initData() {
        boyPos = MySharedPref(this).getBoyPosition()
        girlPos = MySharedPref(this).getGirlPosition()
        jokerPos = MySharedPref(this).getJokerPosition()
        txtGenerateName.setText(userName)
//        txtGenerateName.clearFocus()
        progressNameList.show()

        //\u01A9 \u01A9
        leftSpinnerList.add("×͜× ")
        leftSpinnerList.add("亗 ")
        leftSpinnerList.add("★ ")
        leftSpinnerList.add("☆ ")
        leftSpinnerList.add("☬ ")
        leftSpinnerList.add("❅ ")
        leftSpinnerList.add("Ϟ ")
        leftSpinnerList.add("ண ")
        leftSpinnerList.add("෴ ")
        leftSpinnerList.add("『 ")
        leftSpinnerList.add("■ ")
        leftSpinnerList.add("□ ")
        leftSpinnerList.add("● ")
        leftSpinnerList.add("○ ")
        leftSpinnerList.add(" ❂")
        leftSpinnerList.add("༂ ")
        leftSpinnerList.add("ཌ ")
        leftSpinnerList.add("\uD83D\uDC09 ")
        leftSpinnerList.add("\uF8FF ")
        leftSpinnerList.add("༒☬ ")
        leftSpinnerList.add("༒〠 ")
        leftSpinnerList.add("ʘ͜ʖʘ ")
        leftSpinnerList.add("乂● ")
        leftSpinnerList.add("ミ★ ")
        leftSpinnerList.add("ᶦᶰᵈ✿࿐ ")
        leftSpinnerList.add("༒♤ ")
        leftSpinnerList.add(".༒❦ ")
        leftSpinnerList.add("《♧♤ ")
        leftSpinnerList.add("*★* ")
        leftSpinnerList.add("\uD80C\uDE88\uD808\uDD9C ")
        leftSpinnerList.add("█▇▆▅▄▂ ")
        leftSpinnerList.add("(^_-) ")
        leftSpinnerList.add("★彡[ ")
        leftSpinnerList.add("︻═̷̿╦╤── ")
        leftSpinnerList.add("▄︻︼┱─── ")
        leftSpinnerList.add("▄︻̷̿┻̿═━一 ")

        rightSpinnerList.add(" ×͜×")
        rightSpinnerList.add(" 亗")
        rightSpinnerList.add(" ★")
        rightSpinnerList.add(" ☆")
        rightSpinnerList.add(" ☬")
        rightSpinnerList.add(" ❅")
        rightSpinnerList.add(" Ϟ")
        rightSpinnerList.add(" ண")
        rightSpinnerList.add(" ෴")
        rightSpinnerList.add(" 』")
        rightSpinnerList.add(" ■")
        rightSpinnerList.add(" □")
        rightSpinnerList.add(" ●")
        rightSpinnerList.add(" ○")
        rightSpinnerList.add(" ❂")
        rightSpinnerList.add(" ༂")
        rightSpinnerList.add(" ད")
        rightSpinnerList.add(" \uD83D\uDC09")
        rightSpinnerList.add(" \uF8FF")
        rightSpinnerList.add(" ☬༒")
        rightSpinnerList.add(" 〠༒")
        rightSpinnerList.add(" ʘʖ͜ʘ")
        rightSpinnerList.add(" 乂●")
        rightSpinnerList.add(" ★彡")
        rightSpinnerList.add(" ࿐✿ᶦᶰᵈ")
        rightSpinnerList.add(" ♤༒")
        rightSpinnerList.add(" ❦༒.")
        rightSpinnerList.add(" ♤♧》")
        rightSpinnerList.add(" *★*")
        rightSpinnerList.add(" \uD808\uDD9C\uD80C\uDE89")
        rightSpinnerList.add(" ▂▄▅▆▇█")
        rightSpinnerList.add(" (^_-)")
        rightSpinnerList.add(" ]彡★")
        rightSpinnerList.add(" ──╤╦═̷̿︻")
        rightSpinnerList.add(" ───┱︼︻▄")
        rightSpinnerList.add(" 一━═̷̿┻︻̿▄")

        recyclerIconList.add("☣")
        recyclerIconList.add("©")
        recyclerIconList.add("®")
        recyclerIconList.add("™")
        recyclerIconList.add("℠")
        recyclerIconList.add("℗")
        recyclerIconList.add("☊")
        recyclerIconList.add("☏")
        recyclerIconList.add("⌨")
        recyclerIconList.add("✄")
        recyclerIconList.add("✆")
        recyclerIconList.add("✇")
        recyclerIconList.add("✈")
        recyclerIconList.add("✉")
        recyclerIconList.add("✪")
        recyclerIconList.add("✦")
        recyclerIconList.add("✢")
        recyclerIconList.add("✤")
        recyclerIconList.add("✥")
        recyclerIconList.add("\$")
        recyclerIconList.add("【")
        recyclerIconList.add("】")
        recyclerIconList.add("〘")
        recyclerIconList.add("〙")
        recyclerIconList.add("♛")
        recyclerIconList.add("♝")
        recyclerIconList.add("♚")
        recyclerIconList.add("♞")
        recyclerIconList.add("♠")
        recyclerIconList.add("♤")
        recyclerIconList.add("♣")
        recyclerIconList.add("♢")
        recyclerIconList.add("༄")
        recyclerIconList.add("ঔ")
        recyclerIconList.add("❅")
        recyclerIconList.add("\u1764")
        recyclerIconList.add("\u16DF")
        recyclerIconList.add("➣")
        recyclerIconList.add("\u21A3")
        recyclerIconList.add("\u21A2")
        recyclerIconList.add("\u27A5")
        recyclerIconList.add("\u27A6")
        recyclerIconList.add("\u27B8")
//        recyclerIconList.add("\u2B91")
//        recyclerIconList.add("\u2B90")
        recyclerIconList.add("๏̯͡๏")
        recyclerIconList.add("\u0F06")
        recyclerIconList.add("웃")
        recyclerIconList.add("♀")
        recyclerIconList.add("♂")
        recyclerIconList.add("✰")
        recyclerIconList.add("☻")
        recyclerIconList.add("⇌")
        recyclerIconList.add("☯")
        recyclerIconList.add("࿐")
        recyclerIconList.add("☿")
        recyclerIconList.add("Ѿ")
        recyclerIconList.add("ꪜ")
        recyclerIconList.add("\u29D4")
        recyclerIconList.add("\u29D5")
        recyclerIconList.add("\u2AF7")
        recyclerIconList.add("\u2AF8")
        recyclerIconList.add("〠")
        recyclerIconList.add("ℜ")
        recyclerIconList.add("๖")
        recyclerIconList.add("❦")
        recyclerIconList.add("ヅ")
        recyclerIconList.add("ツ")
        recyclerIconList.add("シ")
        recyclerIconList.add("웃")
        recyclerIconList.add("유")
        recyclerIconList.add("ü")
        recyclerIconList.add("Ü")
        recyclerIconList.add("㋛")
        recyclerIconList.add("ꐦ")
        recyclerIconList.add("乂")
//        recyclerIconList.add("ℓ")
        recyclerIconList.add("ᬊᬁ")
        recyclerIconList.add("ꃼ")
        recyclerIconList.add("☃")
        recyclerIconList.add("☢")
        recyclerIconList.add("☠")
        recyclerIconList.add("⚔️")
        recyclerIconList.add("ꔪ")
        recyclerIconList.add("\uD83D\uDC3C")
        recyclerIconList.add("✿")
        recyclerIconList.add("֎")
        recyclerIconList.add("◤")
        recyclerIconList.add("◢")
        recyclerIconList.add("⍣")
        recyclerIconList.add("⍤")
        recyclerIconList.add("⚣")
        recyclerIconList.add("⌘")
        recyclerIconList.add("⌖")
        recyclerIconList.add("⌦")
        recyclerIconList.add("⍺")
        recyclerIconList.add("\u06DD")
        recyclerIconList.add("\uF8FF")
        recyclerIconList.add("༒")
        recyclerIconList.add("꧂")
        recyclerIconList.add("\u03A8")
        recyclerIconList.add("×͜×")
        recyclerIconList.add("亗")
        recyclerIconList.add("★")
        recyclerIconList.add("☬")
        recyclerIconList.add("❅")
        recyclerIconList.add("Ϟ")
        recyclerIconList.add("ண")
        recyclerIconList.add("෴")
        recyclerIconList.add("『")
        recyclerIconList.add("༂")
        recyclerIconList.add("〄")
        recyclerIconList.add("β")
        recyclerIconList.add("δ")
        recyclerIconList.add("㊏")
        recyclerIconList.add("Σ")
        recyclerIconList.add("☪")
        recyclerIconList.add("༺")
        recyclerIconList.add("༻")
        recyclerIconList.add("❥")
        recyclerIconList.add("ཌ")
        recyclerIconList.add("ད")
        recyclerIconList.add("ཞ")
        recyclerIconList.add("ཧ")
        recyclerIconList.add("ꕥ")
        recyclerIconList.add("╰⊱")
        recyclerIconList.add("⊱╮")
        recyclerIconList.add("❁")
        recyclerIconList.add("Ø")
        recyclerIconList.add("❖")
        recyclerIconList.add("☼")
        recyclerIconList.add("\uD81A\uDCD8")
        recyclerIconList.add("♀")
        recyclerIconList.add("ひ")
        recyclerIconList.add("乡")
        recyclerIconList.add("々")
        recyclerIconList.add("〩")
        recyclerIconList.add("卍")
        recyclerIconList.add("๛")
        recyclerIconList.add("✴")
        recyclerIconList.add("\u0604")
//        recyclerIconList.add("\uD83D\uDC93")
//        recyclerIconList.add("❤️️")
//        recyclerIconList.add("\uD83D\uDC94")

        //NameList
//        boyNameList.add("\uD835\uDE70\uD835\uDE7B\uD835\uDE7E\uD835\uDE7D\uD835\uDE74ㅤ\uD835\uDE71\uD835\uDE7E\uD835\uDE88")
        boyNameList.add("ᏢⱤᏆƝᏣᎬ")
        boyNameList.add("K R I S H")
        boyNameList.add("Soren")
        boyNameList.add("Atticus")
        boyNameList.add("Felix")
        boyNameList.add("Milo")
        boyNameList.add("Silas")
        boyNameList.add("Kai")
        boyNameList.add("Rowan")
        boyNameList.add("Finn")
        boyNameList.add("Ezra")
        boyNameList.add("Oscar")
        boyNameList.add("Jude")
        boyNameList.add("Theo")
        boyNameList.add("Jasper")
        boyNameList.add("August")
        boyNameList.add("Hugo")
        boyNameList.add("Atlas")
        boyNameList.add("Oliver")
        boyNameList.add("Asher")
        boyNameList.add("Cassius")
        boyNameList.add("Otto")
        boyNameList.add("Miles")
        boyNameList.add("Emmett")
        boyNameList.add("Nico")
        boyNameList.add("Sebastian")
        boyNameList.add("Nathaniel")
        boyNameList.add("Noah")
        boyNameList.add("Owen")
        boyNameList.add("Caspian")
        boyNameList.add("Elliot")
        boyNameList.add("Otis")
        boyNameList.add("Magnus")
        boyNameList.add("Caleb")
        boyNameList.add("Everett")
        boyNameList.add("Ronan")
        boyNameList.add("Ethan")
        boyNameList.add("James")
        boyNameList.add("Levi")
        boyNameList.add("Gideon")
        boyNameList.add("Max")
        boyNameList.add("Henry")
        boyNameList.add("Arthur")
        boyNameList.add("Callum")
        boyNameList.add("Cyrus")
        boyNameList.add("Leo")
        boyNameList.add("Tobias")
        boyNameList.add("Rory")
        boyNameList.add("River")
        boyNameList.add("Zachary")
        boyNameList.add("Ellis")
        boyNameList.add("Luca")
        boyNameList.add("Thomas")
        boyNameList.add("Orion")
        boyNameList.add("Lucas")
        boyNameList.add("Remy")
        boyNameList.add("Archer")
        boyNameList.add("Cassian")
        boyNameList.add("Alexander")
        boyNameList.add("Phoenix")
        boyNameList.add("Ambrose")
        boyNameList.add("Lucian")
        boyNameList.add("Bodhi")
        boyNameList.add("Louis")
        boyNameList.add("Rhys")
        boyNameList.add("Keiran")
        boyNameList.add("Julian")
        boyNameList.add("Lachlan")
        boyNameList.add("Roman")
        boyNameList.add("Alistair")
        boyNameList.add("Sawyer")
        boyNameList.add("Elio")
        boyNameList.add("Wyatt")
        boyNameList.add("Charlie")
        boyNameList.add("Jack")
        boyNameList.add("Simon")
        boyNameList.add("Elias")
        boyNameList.add("Liam")
        boyNameList.add("Enzo")
        boyNameList.add("Evander")
        boyNameList.add("Aurelius")
        boyNameList.add("Isaac")
        boyNameList.add("Xavier")
        boyNameList.add("Mateo")
        boyNameList.add("Emrys")
        boyNameList.add("Cosmo")
        boyNameList.add("Micah")
        boyNameList.add("Archie")
        boyNameList.add("Jhon")
        boyNameList.add("Dominic")
        boyNameList.add("Jayden")
        boyNameList.add("Kit")
        boyNameList.add("Hudson")
        boyNameList.add("Knox")
        boyNameList.add("Wesley")
        boyNameList.add("Beau")
        boyNameList.add("Gabriel")
        boyNameList.add("Vincent")
        boyNameList.add("Flynn")
        boyNameList.add("Graham")

        girlNameList.add("Luna")
        girlNameList.add("Aurelia")
        girlNameList.add("Ottilie")
        girlNameList.add("Eloise")
        girlNameList.add("Ophelia")
        girlNameList.add("Isla")
        girlNameList.add("Iris")
        girlNameList.add("Freya")
        girlNameList.add("Alice")
        girlNameList.add("Hazel")
        girlNameList.add("Aurora")
        girlNameList.add("Eleanor")
        girlNameList.add("Violet")
        girlNameList.add("Clara")
        girlNameList.add("Elodie")
        girlNameList.add("Ivy")
        girlNameList.add("Genevieve")
        girlNameList.add("Esme")
        girlNameList.add("Charlotte")
        girlNameList.add("Mabel")
        girlNameList.add("Evelyn")
        girlNameList.add("Lucy")
        girlNameList.add("Adelaide")
        girlNameList.add("Amelia")
        girlNameList.add("Josephine")
        girlNameList.add("Ava")
        girlNameList.add("Nora")
        girlNameList.add("Clementine")
        girlNameList.add("Cora")
        girlNameList.add("Stella")
        girlNameList.add("Rose")
        girlNameList.add("Astrid")
        girlNameList.add("Romy")
        girlNameList.add("Daphne")
        girlNameList.add("Evangeline")
        girlNameList.add("Beatrice")
        girlNameList.add("Wren")
        girlNameList.add("Lyra")
        girlNameList.add("Phoebe")
        girlNameList.add("Elsie")
        girlNameList.add("Maisie")
        girlNameList.add("Imogen")
        girlNameList.add("Penelope")
        girlNameList.add("Juniper")
        girlNameList.add("Ada")
        girlNameList.add("Arabella")
        girlNameList.add("Poppy")
        girlNameList.add("Grace")
        girlNameList.add("Willow")
        girlNameList.add("Cordelia")
        girlNameList.add("Matilda")
        girlNameList.add("Anastasia")
        girlNameList.add("Adeline")
        girlNameList.add("Mae")
        girlNameList.add("Thea")
        girlNameList.add("Olivia")
        girlNameList.add("Florence")
        girlNameList.add("Eliza")
        girlNameList.add("Nove")
        girlNameList.add("Seraphina")
        girlNameList.add("Sadie")
        girlNameList.add("Willa")
        girlNameList.add("Arwen")
        girlNameList.add("Lily")
        girlNameList.add("Margot")
        girlNameList.add("Edith")
        girlNameList.add("Daisy")
        girlNameList.add("Chloe")
        girlNameList.add("Lilith")
        girlNameList.add("Ruby")
        girlNameList.add("Lola")
        girlNameList.add("Cecilia")
        girlNameList.add("Celeste")
        girlNameList.add("Jane")
        girlNameList.add("Olive")
        girlNameList.add("Athena")
        girlNameList.add("Sage")
        girlNameList.add("Emma")
        girlNameList.add("Claire")
        girlNameList.add("Lydia")
        girlNameList.add("Sienna")
        girlNameList.add("Elena")
        girlNameList.add("Elizabeth")
        girlNameList.add("Esther")
        girlNameList.add("Ellie")
        girlNameList.add("Audrey")
        girlNameList.add("Evie")
        girlNameList.add("Sloane")
        girlNameList.add("Mia")
        girlNameList.add("Millie")
        girlNameList.add("Eva")
        girlNameList.add("Flora")
        girlNameList.add("Persephone")
        girlNameList.add("Maya")
        girlNameList.add("Harper")
        girlNameList.add("Margaret")
        girlNameList.add("Scarlett")
        girlNameList.add("Saoirse")
        girlNameList.add("Eden")

        jokerNameList.add("World")
        jokerNameList.add("World1")
        jokerNameList.add("World2")
        jokerNameList.add("World3")
        jokerNameList.add("World4")
        jokerNameList.add("World5")
        jokerNameList.add("World6")
        jokerNameList.add("World7")
        jokerNameList.add("World8")
        jokerNameList.add("World9")
        jokerNameList.add("World0")
        jokerNameList.add("World11")
        jokerNameList.add("World12")
        jokerNameList.add("World13")
        jokerNameList.add("World14")

    }

    override fun onDestroy() {
        super.onDestroy()
        MySharedPref(this).setBoyPosition(boyPos)
        MySharedPref(this).setGirlPosition(girlPos)
        MySharedPref(this).setJokerPosition(jokerPos)
    }

}