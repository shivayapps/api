package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.text.art.fancy.creator.fragment.MyDraftFragment
import com.text.art.fancy.creator.fragment.MyImagesFragment
import com.text.art.fancy.creator.fragment.MyVideosFragment

@SuppressLint("WrongConstant")
class TabAdapter(mFragment: FragmentActivity, var total: Int) :
    FragmentStateAdapter(mFragment) {

    override fun getItemCount(): Int {
        return total
    }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> MyImagesFragment()
            1 -> MyVideosFragment()
            2 -> MyDraftFragment()
            else -> MyImagesFragment()
        }
    }

}