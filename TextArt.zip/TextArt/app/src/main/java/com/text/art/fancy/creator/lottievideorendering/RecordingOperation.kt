package com.text.art.fancy.creator.lottievideorendering

class RecordingOperation(
    private val recorder: Recorder,
    private val frameCreator: FrameCreator,
    private val progressListener: ProgressListener,
    private val listener: () -> Unit
) {

  fun start() {
      while (isRecording()) {
          recorder.nextFrame(frameCreator.generateFrame())
          progressListener.getProgress(frameCreator.progress())
      }
      recorder.end()
      listener()
  }

  private fun isRecording() = !frameCreator.hasEnded()
}

interface ProgressListener{
    fun getProgress(int: Int)
}