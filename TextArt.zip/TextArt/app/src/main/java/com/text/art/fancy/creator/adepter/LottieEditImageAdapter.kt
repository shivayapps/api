package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.text.art.fancy.creator.model.LottieData
import com.text.art.fancy.creator.R

class LottieEditImageAdapter(
    private var mLottieDataList: ArrayList<LottieData>,
    private var imageChangeListener: ImageChangeListener
) : RecyclerView.Adapter<LottieEditImageAdapter.MyHolder>() {

    class MyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val image: ImageView = itemView.findViewById(R.id.lottieEditImage)
        val changeImg: ConstraintLayout = itemView.findViewById(R.id.changeImg)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyHolder {
        return MyHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_lottieeditimage,parent,false))
    }

    @SuppressLint("CheckResult")
    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        with(holder){
            val editableBitmap = mLottieDataList[0].layertype!!.image!![position]!!.imageValue
            val refID = mLottieDataList[0].layertype!!.image!![position]!!.imageID

            Glide.with(itemView.context).asBitmap().load(editableBitmap)
                .override(500)
                .addListener(object : RequestListener<Bitmap>{
                    override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Bitmap>?, isFirstResource: Boolean): Boolean {
                        Log.d("TAG", "onResourceReady: ${e.toString()}")
                        return true
                    }

                    override fun onResourceReady(resource: Bitmap?, model: Any?, target: Target<Bitmap>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                        image.setImageBitmap(resource)
                        Log.d("TAG", "onResourceReady: $resource")
                        return true
                    }
                }).into(image)

            image.setOnClickListener {
                imageChangeListener.onImageChange(refID!!)
            }
        }

    }

    override fun getItemCount(): Int {
        return mLottieDataList[0].layertype!!.image!!.size
    }
}

interface ImageChangeListener{
    fun onImageChange(refId:String)
}