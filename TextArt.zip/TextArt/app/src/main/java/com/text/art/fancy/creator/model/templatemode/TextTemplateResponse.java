package com.text.art.fancy.creator.model.templatemode;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TextTemplateResponse {

@SerializedName("tempId")
@Expose
private String tempId;
@SerializedName("image")
@Expose
private String image;
@SerializedName("width")
@Expose
private Integer width;
@SerializedName("height")
@Expose
private Integer height;
@SerializedName("ratio")
@Expose
private String ratio;
@SerializedName("textSticker")
@Expose
private List<TextSticker> textSticker = null;
@SerializedName("imageSticker")
@Expose
private List<ImageSticker> imageSticker = null;

public String getTempId() {
return tempId;
}

public void setTempId(String tempId) {
this.tempId = tempId;
}

public String getImage() {
return image;
}

public void setImage(String image) {
this.image = image;
}

public Integer getWidth() {
return width;
}

public void setWidth(Integer width) {
this.width = width;
}

public Integer getHeight() {
return height;
}

public void setHeight(Integer height) {
this.height = height;
}

public String getRatio() {
return ratio;
}

public void setRatio(String ratio) {
this.ratio = ratio;
}

public List<TextSticker> getTextSticker() {
return textSticker;
}

public void setTextSticker(List<TextSticker> textSticker) {
this.textSticker = textSticker;
}

public List<ImageSticker> getImageSticker() {
return imageSticker;
}

public void setImageSticker(List<ImageSticker> imageSticker) {
this.imageSticker = imageSticker;
}

}