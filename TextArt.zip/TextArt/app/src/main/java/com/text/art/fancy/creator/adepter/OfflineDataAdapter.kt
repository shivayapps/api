package com.text.art.fancy.creator.adepter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.utils.show
import kotlinx.android.synthetic.main.row_background_item.view.*

class OfflineDataAdapter(
    private val offlineDataList: ArrayList<Int>?,
    private val onItemClick:(Int) -> Unit,
    private val offlineCombo: Array<IntArray>? = null
): RecyclerView.Adapter<OfflineDataAdapter.OfflineDataHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OfflineDataHolder {
        return OfflineDataHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_offline_data, parent, false))
    }

    override fun onBindViewHolder(holder: OfflineDataHolder, position: Int) {
        with(holder){
            setIsRecyclable(false)
            if (offlineDataList == null){
                //TODO Manage Combo Here
                offlineCombo!![0][position].let { background ->
                    if (background != 0)
                        Glide.with(holder.itemView).load(background).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(imgBgView)
                    else
                        imgNone.show()
                }
                offlineCombo[1][position].let { frame ->
                    Glide.with(holder.itemView).load(frame).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(imgFrameView)
                }
            }else{
                //TODO Manage Background And Frame Here
                offlineDataList[position].let { value ->
                    if (value != 0)
                        Glide.with(holder.itemView).load(value).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(imgBgView)
                    else
                        imgNone.show()
                }
            }
            itemView.setOnClickListener {
                onItemClick(position)
            }

            if (offlinePosition == position && offlinePosition != 0)
                imgSelection.visibility=View.VISIBLE
            else
                imgSelection.visibility=View.GONE
        }
    }

    override fun getItemCount(): Int {
        return if (offlineDataList.isNullOrEmpty()){
            offlineCombo?.get(0)?.size ?: 0
        }else{
            offlineDataList.size
        }
//        return offlineList?.size ?: 0
    }

    inner class OfflineDataHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imgNone = itemView.findViewById<ImageView>(R.id.imgNone)
        val imgBgView = itemView.findViewById<ImageView>(R.id.imgBackground)
        val imgFrameView = itemView.findViewById<ImageView>(R.id.imgFrame)
        val imgSelection = itemView.findViewById<ImageView>(R.id.imgSelection)
    }

    companion object{
        var offlinePosition = -1
    }
}