package com.text.art.fancy.creator.comman

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.widget.ImageView
import kotlin.math.roundToInt

@SuppressLint("AppCompatCustomView")
class CustomImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : androidx.appcompat.widget.AppCompatImageView(context, attrs) {
    // some other necessary things
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val width = measuredWidth

        //force a 16:9 aspect ratio
        val height = (width * .5625f).roundToInt()
        setMeasuredDimension(width, height)
    }
}