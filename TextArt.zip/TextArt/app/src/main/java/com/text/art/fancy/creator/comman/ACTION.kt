package com.text.art.fancy.creator.comman

object ACTION {
    //TODO STICKER OPERATION
    const val ManageSticker       = "MANAGE_STICKER"
    const val ChangePosition      = "CHANGE_POSITION"
    const val ResizeSticker       = "RESIZE_STICKER"
    const val RotateSticker       = "ROTATE_STICKER"
    const val ChangeText          = "CHANGE_TEXT"
//    const val DoubleTap           = "DOUBLE_TAP"
//    const val ChangeWidth         = "CHANGE_WIDTH"

    //TODO STICKER VALUE OPERATION
    const val ChangeFont          = "CHANGE_FONT"
    const val ChangeSingleColor   = "CHANGE_SINGLE_COLOR"
    const val ChangeGradientColor = "CHANGE_GRADIENT_COLOR"
    const val ChangeMultipleColor = "CHANGE_MULTIPLE_COLOR"
    const val ChangePattern       = "CHANGE_PATTERN"
    const val ShadowSpace         = "SHADOW_SPACE"
    const val ShadowOpacity       = "SHADOW_OPACITY"
    const val SetCurve            = "SET_CURVE"
    const val Change3Dx           = "CHANGE_3Dx"
    const val Change3Dy           = "CHANGE_3Dy"
    const val ChangeBold          = "CHANGE_BOLD"
    const val ChangeItalic        = "CHANGE_ITALIC"
    const val ChangeUnderline     = "CHANGE_UNDERLINE"
    const val ChangeAA            = "CHANGE_AA"
    const val ChangeGlowColor     = "CHANGE_GLOW_COLOR"
    const val ChangeGlowProgress  = "CHANGE_GLOW_PROGRESS"
    const val ChangeBGColor       = "CHANGE_BG_COLOR"
    const val ChangeBG            = "CHANGE_BG"
    const val ChangeBGNone        = "CHANGE_BG_NONE"
    const val ChangeFrame         = "CHANGE_FRAME"
    const val ChangeFrameNone     = "CHANGE_FRAME_NONE"
    const val ChangeCombo         = "CHANGE_COMBO"
    const val ChangeComboNone     = "CHANGE_COMBO_NONE"
}