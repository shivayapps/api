package com.text.art.fancy.creator.adepter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.text.art.fancy.creator.R;
import com.text.art.fancy.creator.activitys.HomeActivity;
import com.github.demono.adapter.InfinitePagerAdapter;
import com.text.art.fancy.creator.activitys.HomeActivity;

import java.util.ArrayList;

public class MyAdapter extends InfinitePagerAdapter {

    private ArrayList<Integer> data;
    private HomeActivity mContext;
    private String adsType;

    public MyAdapter(ArrayList<Integer> data, HomeActivity context) {
        this.data = data;
        this.mContext = context;
    }

    public interface bannerClick {
        void bannerClicked(int s);
    }

    @Override
    public int getItemCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public View getItemView(int position, View convertView, ViewGroup container) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.slide_adapter, container, false);
        Glide.with(mContext).load(data.get(position)).into(((ImageView) view.findViewById(R.id.imgBNanner)));
        ((ImageView) view.findViewById(R.id.imgBNanner)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.bannerClicked(position);
            }
        });
        return view;
    }
}