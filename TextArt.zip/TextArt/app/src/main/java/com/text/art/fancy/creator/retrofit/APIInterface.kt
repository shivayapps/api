package com.text.art.fancy.creator.retrofit

import retrofit2.http.GET
import com.text.art.fancy.creator.categorys.parameter.FontResponse
import com.text.art.fancy.creator.categorys.parameter.Response
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface APIInterface {
//    @get:GET("application/170")
    @get:GET("parameterList.json")
    val parameterList: Call<Response>

    @get:GET("application/170")
    val fonts: Call<FontResponse>

    @FormUrlEncoded
    @POST("application_new")
    suspend fun getData(
        @Field("category_id") categoryId: Int,
        @Field("app_id") appId: Int = 11
    ): Response?

    @FormUrlEncoded
    @POST("application_new")
    suspend fun getDataChild(
        @Field("category_id") categoryId: Int,
        @Field("app_id") appId: Int = 11,
        @Field("child_id") child_id: Int
    ): Response?

    @FormUrlEncoded
    @POST("category_event_home_new")
    suspend fun getHomeData(
        @Field("category_id") categoryId: Int,
        @Field("app_id") appId: Int = 11
    ): Response?

    @FormUrlEncoded
    @POST("category_event_home_new")
    suspend fun getHomeDataChild(
        @Field("category_id") categoryId: Int,
        @Field("app_id") appId: Int = 11,
        @Field("child_id") child_id: Int
    ): Response?

}