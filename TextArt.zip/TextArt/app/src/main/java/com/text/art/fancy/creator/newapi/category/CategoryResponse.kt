package com.text.art.fancy.creator.newapi.category

import com.text.art.fancy.creator.newapi.category.CategoryItem
import com.google.gson.annotations.SerializedName

data class CategoryResponse(
    @SerializedName("ResponseCode")
    val responseCode: String? = null,

    @SerializedName("data")
    val data: List<CategoryItem?>? = null,

    @SerializedName("ResponseMessage")
    val responseMessage: String? = null,

    @SerializedName("total_page")
    val totalPage: Int? = null

)
