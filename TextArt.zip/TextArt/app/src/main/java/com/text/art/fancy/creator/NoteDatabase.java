package com.text.art.fancy.creator;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

//@Database(entities = { ParametersItemAllChilds.class, CategoryParametersItem.class }, version = 1)
public abstract class NoteDatabase extends RoomDatabase {

    public abstract AllDataDao getNoteDao();

    private static NoteDatabase noteDB;

    public static NoteDatabase getInstance(Context context) {
        if (null == noteDB) {
            noteDB = buildDatabaseInstance(context);
        }
        return noteDB;
    }

    private static NoteDatabase buildDatabaseInstance(Context context) {
        return Room.databaseBuilder(context,
                NoteDatabase.class,
                "TextArtDatabase")
                .allowMainThreadQueries().build();
    }

    public void cleanUp(){
        noteDB = null;
    }

}
