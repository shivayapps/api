package com.text.art.fancy.creator.fragment

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.AddTextActivity1
import com.text.art.fancy.creator.model.creation.PhotoModelCreation
import com.text.art.fancy.creator.model.ImageModel
import com.text.art.fancy.creator.activitys.HomeActivity
import com.text.art.fancy.creator.adepter.MyDraftAdapter
import com.text.art.fancy.creator.adepter.MyPhotosAdapter
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.comman.Constants.isDraftUpdate
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.interfaces.OnLongClickPressedMyCreation
import com.text.art.fancy.creator.roomdb.draft.Draft
import com.text.art.fancy.creator.roomdb.draft.DraftDatabase
import com.text.art.fancy.creator.utils.hide
import com.text.art.fancy.creator.utils.show
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.Executors
import kotlin.collections.ArrayList
import kotlin.properties.Delegates

class MyDraftFragment : Fragment() {
    private var TAG: String = "MyDraftFragment"

    private var recyclerMyDraft: RecyclerView?=null
    private var progressBar: ProgressBar?=null

    private var clickedItem = 0
    private var NUMBER_OF_DATES = 0
    private var dateCount = 0
    private var mIsSubScribe by Delegates.notNull<Boolean>()

    private var mOnLongClickPressedMyCreation: OnLongClickPressedMyCreation?=null
    private var lastClickTime = 0L
    private var isFirstTime = true

    private var newList = arrayListOf<Draft>()
    private lateinit var db: DraftDatabase

    @SuppressLint("NotifyDataSetChanged")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_my_draft, container, false)
        db = DraftDatabase.getInstance(requireContext())
        mOnLongClickPressedMyCreation = context as OnLongClickPressedMyCreation
        mIsSubScribe = MySharedPreferences(
            requireContext()
        ).isSubscribe
        initView(view)
//        setDraftToRecyclerView()
        return view
    }

    private fun setDraftToRecyclerView() {
        val executor = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())
        executor.execute {
            getDraft()
            handler.post {
                Log.d(TAG, "getDraft: Draft is getting mDraftList size ${mDraftList.size}")
                if (myDraftAdapter != null) {
                    myDraftAdapter?.notifyDataSetChanged()
                }
                if (mDraftList.size == 0) {
                    progressBar?.hide()
                    recyclerMyDraft?.hide()
                    mConstraintDraftNotFound?.show()
                } else {
                    activity?.let {
                        setDataToAdapter()
                        Handler(Looper.getMainLooper()).postDelayed({
                            progressBar?.hide()
                            recyclerMyDraft?.show()
                            mConstraintDraftNotFound?.hide()
                        }, 1000)
                    }
                }
            }
        }
    }

    private fun initView(view:View){
        recyclerMyDraft = view.findViewById(R.id.recyclerMyPhotos)
        progressBar = view.findViewById(R.id.progressDraft)
        mConstraintDraftNotFound = view.findViewById(R.id.constraintImagesNotFound)
    }

    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(context, HomeActivity::class.java))
            requireActivity().finish()
        }
//        if (allDraft?.size != db.draftDao().getCount() && isFirstTime){
        if (isFirstTime){
            isFirstTime = false
            setDraftToRecyclerView()
        }else if (isDraftUpdate){
            isDraftUpdate = false
            setDraftToRecyclerView()
        }
    }

    //TODO Show All At Once
    @SuppressLint("SimpleDateFormat")
    private fun getDraft() {
        Log.d(TAG, "getDraft: Draft is getting")
        NUMBER_OF_DATES = 0
        dateCount = 0
        clickedItem = 0
        newList.clear()
        mDraftList.clear()
        val allDraft = db.draftDao().readAllDraft()
        Log.d(TAG, "getDraft: Draft is getting allDraft size ${allDraft?.size}")

        allDraft?.let {
            val dateFormat = SimpleDateFormat("dd MMM yyyy")
            NUMBER_OF_DATES += 1
            for (i in it.indices) {
//                val current = Date(it[i].date)
                val current = Date(it[i].date.toLong())
                mDraftList.add(i, PhotoModelCreation(it[i].preview, dateFormat.format(current), NUMBER_OF_DATES, false, false, null, false, true))
//                mDraftList.add(i, PhotoModelCreation(it[i].preview, it[i].date, NUMBER_OF_DATES, false, false, null, false, true))
            }
        }
    }

    //TODO Show Date Wise
//    @SuppressLint("SimpleDateFormat")
//    private fun getDraft() {
//        NUMBER_OF_DATES = 0
//        dateCount = 0
//        clickedItem = 0
//        newList.clear()
//        mDraftList.clear()
//        val allDraft = db.draftDao().readAllDraft()
//
//        if (allDraft?.size != 0) {
//            allDraft?.let {
//                for (draft in it) {
//                    newList.add(draft)
//                }
//                var temp: Draft
//                for (i in newList.indices) {
//                    for (j in i + 1 until newList.size) {
//                        if (newList[i].time < newList[j].time) {
//                            temp = newList[i]
//                            newList[i] = newList[j]
//                            newList[j] = temp
//                        }
//                    }
//                }
//
//                var pos = 1
//                val lastModDate = Date(newList[0].date)
//                val dateFormat = SimpleDateFormat("dd MMM yyyy")
//                Log.d(TAG,
//                    "getDraft: data lastModDate ${dateFormat.format(lastModDate)} date ${newList[0].date}")
//                NUMBER_OF_DATES += 1
//                mDraftList.add(0,
//                    PhotoModelCreation("",
//                        dateFormat.format(lastModDate),
//                        NUMBER_OF_DATES,
//                        true,
//                        false,
//                        null,
//                        false,
//                        true))
//                mDraftList.add(pos,
//                    PhotoModelCreation(newList[0].preview,
//                        dateFormat.format(lastModDate),
//                        NUMBER_OF_DATES,
//                        false,
//                        false,
//                        null,
//                        false,
//                        true))
//                for (i in 0 until newList.size - 1) {
//                    pos++
//                    val nextDate = Date(newList[i + 1].date)
//                    var current = Date(newList[i].date)
//
//                    if (dateFormat.format(current) != dateFormat.format(nextDate)) {
//                        current = nextDate
//                        NUMBER_OF_DATES += 1
//                        mDraftList.add(pos,
//                            PhotoModelCreation("",
//                                dateFormat.format(nextDate),
//                                NUMBER_OF_DATES,
//                                true,
//                                false,
//                                null,
//                                false,
//                                true))
//                        pos++
//                    }
//                    mDraftList.add(pos,
//                        PhotoModelCreation(newList[i + 1].preview,
//                            dateFormat.format(current),
//                            NUMBER_OF_DATES,
//                            false,
//                            false,
//                            null,
//                            false,
//                            true))
//                }
//            }
//
//        }
//
//    }

    private fun setDataToAdapter() {
        myDraftAdapter = MyDraftAdapter(requireActivity(), mDraftList,
            object : MyDraftAdapter.OnClickDraft {
            override fun onClick(i: String) {
                if (SystemClock.elapsedRealtime() - lastClickTime < 3000) return
                lastClickTime = SystemClock.elapsedRealtime()

                lifecycleScope.launch {
                    var data: Int ?= null
                    launch {
                        data = db.draftDao().findPreview(i)
                    }.invokeOnCompletion {
                        context?.let {
                            startActivity(Intent(it, AddTextActivity1::class.java).apply {
                                putExtra("mode", Constants.DRAFT)
                                putExtra("position", data)
                            })
                        }
                    }
                }
            }
            override fun onLongClick() {
                openMenu()
            }
        })
        val layoutManager = GridLayoutManager(activity, 3)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(i: Int): Int {
                return when (myDraftAdapter!!.getItemViewType(i)) {
                    MyPhotosAdapter.SHOW_DATE -> 3
                    MyPhotosAdapter.SHOW_ADS -> 3
                    MyPhotosAdapter.SHOW_IMAGE -> 1
                    else -> 1
                }
            }
        }
        //    myphotos.addItemDecoration(new GridSpacingItemDecoration(3,10,true));
        recyclerMyDraft!!.layoutManager = layoutManager
        recyclerMyDraft!!.adapter = myDraftAdapter
    }

    private fun openMenu() {
        mOnLongClickPressedMyCreation!!.isLongClickPressed(true)
    }

    fun delete(): Boolean {
        if (mDraftList != null) {
            (mDraftList.filter {
                if (it.isVisible)
                    !File(it.path).delete()
                else
                    true
            } as ArrayList<ImageModel>).apply {
                mDraftList.clear()
            }

            PhotoFragment.isShowCheckBox = false
            if (mDraftList.isEmpty())
                return true

            myDraftAdapter?.notifyDataSetChanged()

        }

        return false
    }

    companion object{
        @SuppressLint("StaticFieldLeak")
        var myDraftAdapter: MyDraftAdapter? = null
        var mConstraintDraftNotFound: ConstraintLayout?=null
        val mDraftList: ArrayList<PhotoModelCreation> = ArrayList()
    }
}