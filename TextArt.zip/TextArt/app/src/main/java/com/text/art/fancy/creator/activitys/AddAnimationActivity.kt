package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.*
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.viewpager.widget.ViewPager
import com.text.art.fancy.creator.lottieapi.AnimationDataFragment
import com.text.art.fancy.creator.lottieapi.AnimationPagerAdapter
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.categorys.ParametersItemAllChilds
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.database.DBHelper
import com.text.art.fancy.creator.fragment.VideoProgressDialogFragment
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.utils.*
import com.downloader.OnDownloadListener
import com.downloader.PRDownloader
import com.downloader.Status
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.frame_api_activity.*
import retrofit2.Call
import retrofit2.Callback
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class AddAnimationActivity : AppCompatActivity(), AnimationDataFragment.ItemClickListener {

    private var isSubScribe: Boolean = false
    private var receiver: AddAnimationActivity.Receiver? = null
    lateinit var addTextToolbar: Toolbar
    private lateinit var materialTabLayout: TabLayout
    private lateinit var viewPagerCard: ViewPager
    private lateinit var constMain: ConstraintLayout
    private lateinit var noInternetConnection: ConstraintLayout
    private lateinit var constraintProgressLayout: ConstraintLayout
    private lateinit var btnback: ImageView
    private lateinit var btnSave: ImageView
    private lateinit var btnPremium: ImageView
    private lateinit var btnShare: ImageView
    private lateinit var txtRetry: TextView
    private var mPosition: Int? = null
    private var mDBHelper : DBHelper? = null
    private var mIsFirstTime = true
    private var isDataLoaded = false
    private var isPremiumDataLoaded = false
    private var lastClickTime = 0L
    private var mProgressDialog =
        VideoProgressDialogFragment()
    private var downloadTask = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_animation)
        mDBHelper = DBHelper(this@AddAnimationActivity)
        isSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        try {
            receiver = Receiver()
            registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
        } catch (e: Exception) { }

        try {
            addTextToolbar.setPadding(0, getStatusbarHeight(), 0, 0)
            hideSystemUI()
        } catch (e: Exception) { }
//        initData()
        initViews()
        initActions()

    }

    private fun initActions() {
        btnback.setOnClickListener {
            onBackPressed()
        }
        btnSave.setOnClickListener {
        }
        btnPremium.setOnClickListener {
            resultLauncher.launch(Intent(this@AddAnimationActivity, SubscriptionActivity::class.java))
        }

        btnShare.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            shareApp()
        }

        txtRetry.setOnClickListener {
            checkInternetConnectionAndSetView()
        }

//        setDemoRecycler()

    }

    private fun shareApp() {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Text Art")
            var shareMessage = "\nGo with TextArt and make beautiful text image.\n\n"
            shareMessage =
                shareMessage + "https://play.google.com/store/apps/details?id=" + packageName + "\n\n"
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
            startActivity(Intent.createChooser(shareIntent, "choose one"))
        } catch (e: java.lang.Exception) { //e.toString();
        }
    }

    private fun setData() {
        constraintProgressLayout.hide()
        constraintOffline.hide()
        constMain.show()

        val fontPagerAdepter = AnimationPagerAdapter(
            supportFragmentManager,
            animationAllArray,
            isSubScribe,
            this@AddAnimationActivity
        )

        viewPagerCard.adapter = fontPagerAdepter
        materialTabLayout.setupWithViewPager(viewPagerCard)
        animationAllArray.filterIndexed { index, categoryParametersItem ->
            if (categoryParametersItem.name != "") {
                val view1 =
                    LayoutInflater.from(this@AddAnimationActivity)
                        .inflate(R.layout.rv_tab, null)
                materialTabLayout.getTabAt(index)!!.customView = view1
                val textView = view1.findViewById<TextView>(R.id.textTab)
                textView.text = categoryParametersItem.name
                if (index == 0) {
                    Constants.selectedAnimation = textView.text.toString()
                    textView.setTextColor(Color.WHITE)
                } else {
                    textView.setTextColor(Color.BLACK)
                }
            }
            true
        }
        materialTabLayout.setOnTabSelectedListener(object :
            TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                mPosition = tab.position
                try {
                    tab.customView!!.findViewById<TextView>(R.id.textTab)
                        .setTextColor(Color.WHITE)
                    Constants.selectedAnimation = "${materialTabLayout.getTabAt(tab.position)!!.customView!!.findViewById<TextView>(R.id.textTab).text}"
                } catch (e: Exception) { }
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {
                mPosition = tab.position
                try {
                    tab.customView!!.findViewById<TextView>(R.id.textTab)
                        .setTextColor(Color.BLACK)
                } catch (e: Exception) { }
            }

            override fun onTabReselected(tab: TabLayout.Tab) {
                mPosition = tab.position
                try {
                    tab.customView!!.findViewById<TextView>(R.id.textTab)
                        .setTextColor(Color.WHITE)
                } catch (e: Exception) { }

            }
        })
    }

    private fun callAnimationApi() {
        constraintProgressLayout.visibility = View.VISIBLE

        if (isAnimDataLoaded){
            setData()
        }else{
            val apiInterface = APIClient.getClient().create(APIInterface::class.java)
            val call = apiInterface.parameterList
            call!!.enqueue(object : Callback<Response?> {
                override fun onResponse(
                    call: Call<Response?>,
                    response: retrofit2.Response<Response?>
                ) {
                    if (response.isSuccessful && response.body()!!.parameters != null){
                        response.body()!!.parameters.filterIndexed { _, parametersItem ->
                            if (parametersItem.name == "Animation" || parametersItem.id == 770) {
                                animationAllArray.clear()
                                parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                    animationAllArray.add(categoryParametersItem)
                                    true
                                }
                            }
                            isAnimDataLoaded = true
                            setData()
                            true
                        }
                        isDataLoaded = true
                    }else{
                        showToast(resources.getString(R.string.try_again_later))
                        finish()
                    }
                }

                override fun onFailure(call: Call<Response?>, t: Throwable) {
                    showToast(resources.getString(R.string.try_again_later))
                    finish()
                }
            })
        }


    }

    override fun onBackPressed() {
        if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return
        lastClickTime = SystemClock.elapsedRealtime()
        super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        try {
            isSubScribe = MySharedPreferences(
                this
            ).isSubscribe
            if (isSubScribe) {
                btnPremium.visibility = View.GONE
                btnShare.visibility = View.VISIBLE
                if (!isPremiumDataLoaded) {
                    if(isOnline()){
                        isPremiumDataLoaded = true
                        callAnimationApi()
                    }else{
                        showToast("Please check internet connection")
                    }
                }
            }else{
                btnShare.visibility = View.GONE
                btnPremium.visibility = View.VISIBLE
            }
        } catch (e: Exception) { }
    }

    override fun onPause() {
        super.onPause()
        try {
            if (mProgressDialog.isVisible && mProgressDialog != null) {
                PRDownloader.cancel(downloadTask)
                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                mProgressDialog.dismiss()
            }
        }catch (e: Exception){}
    }

    companion object {
        private const val TAG = "AddAnimationActivity"
        var isAdsIsFree = false
        var isAnimDataLoaded = false
        var animationAllArray: ArrayList<ParametersItemAllChilds> = ArrayList()
    }

    private fun initViews() {
        btnback = findViewById(R.id.imgBtnBack)
        btnSave = findViewById(R.id.imgBtnSave)
        btnPremium = findViewById(R.id.btnPremium)
        btnShare = findViewById(R.id.btnShare)
        txtRetry = findViewById(R.id.txtRetry)
        addTextToolbar = findViewById(R.id.addTextToolbar)
        materialTabLayout = findViewById(R.id.materialTabLayout)
        viewPagerCard = findViewById(R.id.viewPagerCard)
        constMain = findViewById(R.id.constMain)
        noInternetConnection = findViewById(R.id.constraintOffline)
        constraintProgressLayout = findViewById(R.id.constraintProgressLayout)
    }

    private fun checkInternetConnectionAndSetView() {
        if (isOnline()) {
            constMain.visibility = View.VISIBLE
            noInternetConnection.visibility = View.GONE
            if (!isDataLoaded){
                callAnimationApi()
            }
        } else {
            try {
                if (mProgressDialog.isVisible && downloadTask!=null) {
                    PRDownloader.cancel(downloadTask)
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                    mProgressDialog.dismiss()
                }

                constMain.visibility = View.GONE
                noInternetConnection.visibility = View.VISIBLE
                if (!mIsFirstTime){
                    showToast("Please check internet connection")
                }else{
                    mIsFirstTime = false
                }

            } catch (e: Exception) {
            }
        }
    }

    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            checkInternetConnectionAndSetView()
        }
    }

    override fun onAnimationItemClick(id: Int, fileName: String, zipUrl: String) {
        if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return
        lastClickTime = SystemClock.elapsedRealtime()
        Constants.animId = id
        if (File("$cacheDir/$fileName").exists()){
            openJsonFileEditing(fileName)
        }else{
            try {
                mProgressDialog.isCancelable = false
                mProgressDialog.show(supportFragmentManager, "dialog")
                downloadFontZipFile(zipUrl, fileName)
            } catch (e: Exception) { }
        }
    }

    private fun downloadFontZipFile(zipUrl: String, fileName: String){
        var path = cacheDir.toString() + File.separator
        var fileName = "$fileName.zip"

        val downloadId = PRDownloader.download(
            zipUrl,
            path,
            fileName
        )
            .build()
            .setOnStartOrResumeListener {}
            .setOnPauseListener {}
            .setOnCancelListener {}
            .setOnProgressListener {}
            .start(object : OnDownloadListener {
                override fun onDownloadComplete() {
                    Log.e(TAG, "STATUS: onDownloadComplete")
                    try {
                        unzip(
                            File("$cacheDir/$fileName"),
                            File(cacheDir.toString() + File.separator ),
                            fileName
                        )
                        val deleted = File("$path$fileName").canonicalFile.delete()
                        if (!deleted){
                            File("$path$fileName").canonicalFile.delete()
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }

                override fun onError(error: com.downloader.Error) {
                    Log.e(TAG, "onError: Download ${error.responseCode}")
                }

            })
        val status: Status = PRDownloader.getStatus(downloadId)
        downloadTask = downloadId
    }

    @Throws(IOException::class)
    fun unzip(zipFile: File?, targetDirectory: File, fileName: String) {
        val zis = ZipInputStream(
            BufferedInputStream(FileInputStream(zipFile))
        )
        try {
            Log.d(TAG, "onDownloadComplete unzip ")
            var ze: ZipEntry
            var count: Int
            val buffer = ByteArray(8192)
            while ((zis.nextEntry.also { ze = it }) != null) {
                val file = File(targetDirectory, ze.name)
                val dir = if (ze.isDirectory) file else file.parentFile
                if ((dir != null) && !dir.isDirectory && !dir.mkdirs()) throw FileNotFoundException(
                    "Failed to ensure directory: " +
                            dir.absolutePath
                )
                if (ze.isDirectory) continue
                val fout = FileOutputStream(file)
                try {
                    while ((zis.read(buffer).also { count = it }) != -1) fout.write(
                        buffer,
                        0,
                        count
                    )
                } finally {
                    fout.close()
                }
            }
        } catch (e: Exception) {
        } finally {
            zis.close()
            try {
                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                mProgressDialog.dismiss()
            }catch (e: java.lang.Exception){ }
            val newFileName = fileName.replace(".zip","")
            if (File("$cacheDir/$newFileName").exists()){
                openJsonFileEditing(newFileName)
            }else if (File("$cacheDir/$fileName").exists()){
                openJsonFileEditing(fileName)
            }
        }
    }

    private fun openJsonFileEditing(fileName: String) {
        val intent = Intent(this, EditAnimationActivity::class.java)
        intent.putExtra("fileName",fileName)
        startActivity(intent)
    }

    val resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            if(MySharedPreferences(this).isSubscribe){
                isSubScribe = true
                callAnimationApi()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1111 && resultCode == 1144) {
            isSubScribe = try {
                MySharedPreferences(this).isSubscribe
            } catch (e: Exception) {
                false
            }
            if (isSubScribe)
                callAnimationApi()
        }
    }

    override fun onStop() {
        super.onStop()
//        finish()
    }

    fun onBackClick(view: View) {

    }

}