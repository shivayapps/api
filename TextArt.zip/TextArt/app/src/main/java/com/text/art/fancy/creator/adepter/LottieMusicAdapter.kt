package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.model.LottieMusic
import com.text.art.fancy.creator.utils.show
import kotlinx.android.synthetic.main.row_background_item.view.*
import java.text.DecimalFormat
import kotlin.math.round

class LottieMusicAdapter(
    private val offlineMusicList: ArrayList<LottieMusic>?,
    private val from:MusicType,
    private val onItemClick:(Int) -> Unit
): RecyclerView.Adapter<LottieMusicAdapter.OfflineDataHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OfflineDataHolder {
        return OfflineDataHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_lottieeditmusic, parent, false))
    }

    @SuppressLint("SetTextI18n", "NotifyDataSetChanged")
    override fun onBindViewHolder(holder: OfflineDataHolder, position: Int) {
        with(holder){
            setIsRecyclable(false)

            txtMusicName.text = offlineMusicList?.get(position)!!.musicName.replace(".mp3","")
            offlineMusicList[position].musicDuration.also {
                when (it) {
                    in 0..60 -> {
                        txtDuration.text = "Duration : ${offlineMusicList[position].musicDuration} Seconds"
                    }
                    else -> {
                        txtDuration.text = "Duration : ${(offlineMusicList[position].musicDuration % 3600) / 60} Minutes"
                    }
                }
            }
            offlineMusicList[position].musicSize.also {
                when (it.toInt()) {
                    in 0..1024 -> {
                        txtSize.text = it.toString() + "KB"
                    }
                    else -> {
                        txtSize.text = round(it/1024).toString() + "MB"
                    }
                }
            }

            itemView.setOnClickListener {
                if (MusicType.OFFLINE == from){
                    selectedMusicPosition = position
                }
                onItemClick(position)
                notifyDataSetChanged()
            }
            when(from){
                MusicType.FILE->{
                    if (selectedAudioPosition == position) {
                        imgMusicView.setColorFilter(ContextCompat.getColor(holder.itemView.context, R.color.colorPrimary), android.graphics.PorterDuff.Mode.SRC_IN)
                        txtMusicName.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.colorPrimary))
                    }
                    else {
                        imgMusicView.setColorFilter(ContextCompat.getColor(holder.itemView.context, R.color.lightGrey), android.graphics.PorterDuff.Mode.SRC_IN)
                        txtMusicName.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.black))
                    }
                }
                MusicType.OFFLINE->{
                    if (selectedMusicPosition == position) {
                        imgMusicView.setColorFilter(ContextCompat.getColor(holder.itemView.context, R.color.colorPrimary), android.graphics.PorterDuff.Mode.SRC_IN)
                        txtMusicName.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.colorPrimary))
                    }
                    else {
                        imgMusicView.setColorFilter(ContextCompat.getColor(holder.itemView.context, R.color.lightGrey), android.graphics.PorterDuff.Mode.SRC_IN)
                        txtMusicName.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.black))
                    }
                }
            }

        }
    }

    fun onMusicClick(position: Int){
        onItemClick(position)
    }

    override fun getItemCount(): Int {
        return offlineMusicList?.size ?: 0
    }

    inner class OfflineDataHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val txtMusicName = itemView.findViewById<TextView>(R.id.txtMusicName)
        val txtDuration = itemView.findViewById<TextView>(R.id.txtDuration)
        val txtSize = itemView.findViewById<TextView>(R.id.txtSize)
        val viewSelection = itemView.findViewById<ImageView>(R.id.viewSelection)
        val imgMusicView = itemView.findViewById<ImageView>(R.id.imgMusicView)
    }

    enum class MusicType{
        FILE,
        OFFLINE
    }

    companion object{
        var selectedMusicPosition = -1 //TODO For Offline Music
        var selectedAudioPosition = -1 //TODO For Audio From File
    }
}