package com.text.art.fancy.creator.adepter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.utils.click
import java.util.ArrayList

class EditNameAdapter(
    private val dataList: ArrayList<String>,
    private val action: OnItemClick
): RecyclerView.Adapter<EditNameAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_icon_list, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.icon.text = dataList[position]
        holder.icon.click {
            action.onItemClick(dataList[position])
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }


    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var icon: TextView = itemView.findViewById(R.id.iconItem)
    }

    interface OnItemClick {
        fun onItemClick(text: String)
    }
}

