package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.*
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.stickerapi.StickerAdepter
import com.text.art.fancy.creator.stickerapi.StickerDataFragment
import com.text.art.fancy.creator.categorys.ParametersItemAllChilds
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.newapi.model.SubCategory
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.utils.*
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.sticker_api.constainMain
import kotlinx.android.synthetic.main.sticker_api.constraintOffline
import kotlinx.android.synthetic.main.sticker_api.constraintProgressLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import java.util.*
import kotlin.properties.Delegates

class StickerActivity : AppCompatActivity(), StickerDataFragment.ItemClickListener {

    private var isConnected = false
    private var meterialTabLayout: TabLayout? = null
    private var icBack: ImageView? = null
    private var btnPremium: ImageView? = null
    private var btnHeaderText: TextView? = null
    private var imageShare: ImageView? = null
    private var viewPagerCard: ViewPager2? = null
    private var mTermsToolbar: ConstraintLayout? = null
    var mIsSubScribe: Boolean = false
    private var receiver: Receiver? = null
    var selectedURL: String = ""
    var mySharedPref: MySharedPref? = null
    private var mIsDataLoaded = false
    private var lastClickTime = 0L

    private var total by Delegates.notNull<Int>()
    private var categoryList = arrayListOf<SubCategory>()


    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (isOnline()) {
//                constraintOffline.visibility = View.GONE
//                if (isStickerDataLoaded){
//                    constainMain.visibility = View.VISIBLE
//                    setData()
//                }else{
////                    callStickerApi()
//                    callNewStickerApi()
//                }
                if (categoryList.size == 0){
                    callNewStickerApi()
                }else{
                    setNewData()
                }
            } else {
                constainMain.hide()
                constraintOffline.show()
                finish()
            }
        }
    }

    private fun callNewStickerApi() {
        constraintProgressLayout.show()
        lifecycleScope.launch{
            withContext(Dispatchers.IO){
                if (HomeActivity.allCategory.isEmpty()){
                    HomeActivity.callHomeApi(this@StickerActivity)
                }
                for (category in HomeActivity.allCategory){
                    if (category.name.equals(TAG, ignoreCase = true)){
                        category.subCategory?.let {
                            withContext(Dispatchers.Main){
                                categoryId = category.id!!
                                total = it.size
                                for ((i, subCategory) in it.withIndex()){
                                    categoryList.add(subCategory)
                                    withContext(Dispatchers.Main){
                                        meterialTabLayout!!.addTab(meterialTabLayout!!.newTab().setText(subCategory.name))
                                        val view1 = LayoutInflater.from(this@StickerActivity).inflate(R.layout.rv_tab, null)
                                        meterialTabLayout!!.getTabAt(i)!!.customView = view1
                                        val textView = view1.findViewById<TextView>(R.id.textTab)
                                        textView.text = subCategory.name
                                        if (i == 0) {
                                            Constants.selectedSticker = textView.text.toString()
                                            textView.setTextColor(Color.WHITE)
                                        } else {
                                            textView.setTextColor(Color.BLACK)
                                        }
                                    }

                                }
                            }
                        }
                        withContext(Dispatchers.Main){
                            setNewData()
                        }
                        break
                    }
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sticker_api)

        try {
            receiver = Receiver()
            registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
        } catch (e: Exception) { }

        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        mySharedPref = MySharedPref(this@StickerActivity)
        if (!mIsSubScribe) {
            NativeAdvancedModelHelper(this@StickerActivity).loadNativeAdvancedAd(NativeAdsSize.Medium,findViewById(R.id.my_template))
        }
        hideSystemUI()
        mTermsToolbar = findViewById<ConstraintLayout>(R.id.mTermsToolbar)
        meterialTabLayout = findViewById<TabLayout>(R.id.meterialTabLayout)
        btnHeaderText = findViewById<TextView>(R.id.btnHeaderText)
        btnPremium = findViewById<ImageView>(R.id.btnPremium)
        imageShare = findViewById<ImageView>(R.id.imageShare)
        icBack = findViewById<ImageView>(R.id.icBack)
        viewPagerCard = findViewById<ViewPager2>(R.id.viewPagerCard)
        try {
            btnHeaderText!!.text = "Sticker"
        } catch (e: Exception) { }
        if (mIsSubScribe) {
            imageShare!!.visibility = View.VISIBLE
            btnPremium!!.visibility = View.GONE
        } else {
            imageShare!!.visibility = View.GONE
            btnPremium!!.visibility = View.VISIBLE
        }

        icBack!!.setOnClickListener {
            try {
                onBackPressed()
            } catch (e: Exception) {
            }
        }
        btnPremium!!.setOnClickListener {
            startActivityForResult(Intent(this, SubscriptionActivity::class.java), 1000)
        }
        imageShare!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            try {
                val shareIntent = Intent(Intent.ACTION_SEND)
                shareIntent.type = "text/plain"
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Text Art")
                var shareMessage = "\nGo with TextArt and make beautiful text image.\n\n"
                shareMessage =
                    shareMessage + "https://play.google.com/store/apps/details?id=" + packageName + "\n\n"
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivity(Intent.createChooser(shareIntent, "choose one"))
            } catch (e: java.lang.Exception) { }
        }

        bindCallbacks()
        bindAction()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1000 && resultCode == 1144) {
            mIsSubScribe = try {
                MySharedPreferences(this).isSubscribe
            } catch (e: Exception) {
                false
            }
            if (mIsSubScribe) {
                callNewStickerApi()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            mIsSubScribe = MySharedPreferences(
                this
            ).isSubscribe
            if (mIsSubScribe) {
                btnPremium?.visibility = View.GONE
                imageShare?.visibility = View.VISIBLE
                findViewById<FrameLayout>(R.id.my_template).visibility = View.GONE
            } else {
                btnPremium?.visibility = View.VISIBLE
                imageShare?.visibility = View.GONE
            }
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        categoryList.clear()
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) { }
    }

    private fun setData() {
        constraintProgressLayout.hide()
        constraintOffline.hide()
        constainMain.show()

//        val fontPagerAdepter = StickerPagerAdepter(
//            supportFragmentManager,
//            stickerAllArray,
//            mIsSubScribe,
//            this@StickerActivity
//        )
//        viewPagerCard!!.adapter = fontPagerAdepter
//        meterialTabLayout!!.setupWithViewPager(viewPagerCard)
//        stickerAllArray.filterIndexed { index, categoryParametersItem ->
//            if (categoryParametersItem.name != "") {
//                val view1 =
//                    LayoutInflater.from(this@StickerActivity)
//                        .inflate(R.layout.rv_tab, null)
//                meterialTabLayout!!.getTabAt(index)!!.customView = view1
//                val textView = view1.findViewById<TextView>(R.id.textTab)
//                textView.text = categoryParametersItem.name
//                if (index == 0) {
//                    textView.setTextColor(Color.WHITE)
//                    Constants.selectedSticker = textView.text.toString()
//                } else {
//                    textView.setTextColor(Color.BLACK)
//                }
//            }
//            true
//        }
//
//        meterialTabLayout!!.setOnTabSelectedListener(object :
//            TabLayout.OnTabSelectedListener {
//            override fun onTabSelected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.WHITE)
//                    Constants.selectedSticker = "${meterialTabLayout!!.getTabAt(tab.position)!!.customView!!.findViewById<TextView>(R.id.textTab).text}"
//                } catch (e: Exception) { }
//            }
//
//            override fun onTabUnselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.BLACK)
//                } catch (e: Exception) { }
//            }
//
//            override fun onTabReselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.WHITE)
//                } catch (e: Exception) { }
//
//            }
//        })
//        isStickerDataLoaded = true
//        viewPagerCard!!.currentItem = mPosition
    }

    private fun setNewData() {
        constraintProgressLayout.hide()
        constraintOffline.hide()
        constainMain.show()

        val stickerAdapter = StickerAdepter(this, categoryList, total)
        viewPagerCard?.offscreenPageLimit = ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT
        viewPagerCard?.adapter = stickerAdapter

        meterialTabLayout?.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                with(tab?.position!!){
                    viewPagerCard?.currentItem = this
                    tab.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.WHITE)
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                tab?.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.BLACK)
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }

        })

        viewPagerCard?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

            override fun onPageSelected(position: Int) {
                meterialTabLayout?.selectTab(meterialTabLayout?.getTabAt(position))
            }

            override fun onPageScrollStateChanged(state: Int) {}

        })

    }

    private fun callStickerApi() {
        constraintProgressLayout.visibility = View.VISIBLE

        val apiInterface = APIClient.getClient().create(APIInterface::class.java)
        val call = apiInterface.parameterList
        call.enqueue(object : Callback<Response> {
            override fun onResponse(
                call: Call<Response>,
                response: retrofit2.Response<Response>
            ) {
                if (response.isSuccessful && response.body()!!.parameters != null){
                    response.body()!!.parameters.filterIndexed { _, parametersItem ->
                        if (parametersItem.name == "Sticker" || parametersItem.id == 449) {
                            stickerAllArray.clear()
                            parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                stickerAllArray.add(categoryParametersItem)
                                true
                            }
                        }
                        isStickerDataLoaded = true
                        setData()
                        true
                    }
                }else{
                    showToast("Please try again latter")
                    finish()
                }

            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                showToast("Please try again latter")
                finish()
            }
        })
    }

    companion object {
        private const val TAG = "Sticker"
        var isAdsIsFree = false
        var isStickerDataLoaded = false
        var mPosition = 0
//        var stickerAllArray: ArrayList<ParametersItemAllChilds> = ArrayList()
        var categoryId by Delegates.notNull<Int>()
        var stickerAllArray: ArrayList<ParametersItemAllChilds> = ArrayList()
    }

    override fun onStickerItemClick(string: String, id: Int) {
        selectedURL = string
        if (mySharedPref?.getApiAdsCount() == 2 && !mIsSubScribe && isAdsIsFree) {
            mySharedPref?.setApiAdsCount(0)
            isShowInterstitialAd() {
                Handler(Looper.getMainLooper()).postDelayed({
                    Constants.stickerId = id
                    Log.d(TAG, "onStickerItemClick: ${Constants.selectedSticker}_$id")
                    val intent = Intent()
                    intent.putExtra("sticker", selectedURL)
                    setResult(1010, intent)
                    finish()
                }, 500)
            }
        } else {
            if (mySharedPref?.getApiAdsCount()!! > 2) {
                mySharedPref?.setApiAdsCount(0)
            }
            mySharedPref?.setApiAdsCount(mySharedPref?.getApiAdsCount()!! + 1)
            Handler(Looper.getMainLooper()).postDelayed({
                Constants.stickerId = id
                Log.d(TAG, "onStickerItemClick: ${Constants.selectedSticker}_$id")
                val intent = Intent()
                intent.putExtra("sticker", selectedURL)
                setResult(1010, intent)
                finish()
            }, 500)
        }

    }


    fun bindCallbacks() {

    }

    fun bindAction() {
        val connectionLiveData = ConnectionLiveData(this)
        connectionLiveData.observe(this) { isConnected ->
            isConnected?.let {
                this.isConnected = it
                if (it) {
                    if (!isOnline()) {
                        showToast("Please connect internet")
                        finish()
                    }
                } else {
                    showToast("Please connect internet")
                    finish()
                }
            }
        }
    }

}