package com.text.art.fancy.creator.newapi.model

import com.google.gson.annotations.SerializedName

data class DataItem(
    @SerializedName("id")
    var id: Int? = null,

    @SerializedName("name")
    var name: String? = null,

    @SerializedName("icon")
    var icon: String? = null,

    @SerializedName("images")
    var images: List<Image>? = null,

    @SerializedName("videos")
    var videos: List<Image>? = null,

    @SerializedName("sub_category")
    var subCategory: List<SubCategory>? = null
)