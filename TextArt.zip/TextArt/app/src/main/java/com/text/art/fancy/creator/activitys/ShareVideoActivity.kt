package com.text.art.fancy.creator.activitys

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.adepter.LottieMusicAdapter
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.utils.getStatusbarHeight
import com.text.art.fancy.creator.utils.hideSystemUI
import com.text.art.fancy.creator.utils.showToast
import java.io.File

class ShareVideoActivity : AppCompatActivity() {

    private var mIsSubScribe: Boolean = false
    lateinit var addTextToolbar: Toolbar
    private lateinit var btnBack: ImageView
    private lateinit var btnShare: ImageView
    private lateinit var btnHome: ImageView
    private lateinit var btnPlay: ImageView
    private lateinit var btnStop: ImageView
    private lateinit var videoPath: String
    private lateinit var videoView: VideoView
    private lateinit var videoViewFrame: FrameLayout
    private var stopPosition = 0
    private var lastClickTime = 0L
    private val TAG = "ShareVideoActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_share_video)

        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        try {
            addTextToolbar.setPadding(0, getStatusbarHeight(), 0, 0)
            hideSystemUI()
        } catch (e: Exception) { }
        initViews()
        checkSelfGivenPermission()

    }

    private fun checkSelfGivenPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ){
            initAction()
        }else{
            openPermissionRequestDialog()
        }
    }

    private fun openPermissionRequestDialog() {
        val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        if (!showRationale) {
            val builder = android.app.AlertDialog.Builder(this)
            builder.setTitle("Permission Required")
            builder.setMessage("Storage Permission are required to save Image into External Storage")
            builder.setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                startInstalledAppDetailsActivity(this@ShareVideoActivity)
            }
            builder.setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            builder.create().show()
        }
    }

    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    private fun initAction() {
        if (intent.hasExtra("videoPath")){
            videoPath = intent.getStringExtra("videoPath")!!
            if (videoPath.isNotEmpty() && File(videoPath).exists()){
                Log.d(TAG, "initAction: videoPath is $videoPath")
                videoView.setOnPreparedListener { mp -> mp.isLooping = true }
                videoView.apply {
                    val uri = Uri.parse(videoPath)
                    //setVideoURI(uri)
                    setVideoPath(videoPath)
                    requestFocus()
                    start()
                }
            }else{

            }
        }else{
            showToast("Failed to generate video")
            finish()
        }

        btnBack.setOnClickListener {
            onBackPressed()
        }

        btnShare.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()

            startActivity(Intent.createChooser(
                Intent().setAction(Intent.ACTION_SEND)
                    .setType("video/*")
                    .setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    .putExtra(Intent.EXTRA_STREAM,
                        getVideoContentUri(File(videoPath))), "Share File Using!"))
        }

        btnHome.setOnClickListener {
            startActivity(Intent(this@ShareVideoActivity, HomeActivity::class.java))
            finish()
        }

        videoViewFrame.setOnClickListener {
            if (videoView.isPlaying){
                if (btnStop.visibility == View.GONE){
                    btnStop.visibility = View.VISIBLE
                    Handler(Looper.getMainLooper()).postDelayed({
                        btnStop.visibility = View.GONE
                    },1000)
                }else{
                    btnStop.visibility = View.GONE
                }
            }else{
                if (btnPlay.visibility == View.GONE){
                    btnPlay.visibility = View.VISIBLE
                    Handler(Looper.getMainLooper()).postDelayed({
                        btnPlay.visibility = View.GONE
                    },1000)
                }else{
                    btnPlay.visibility = View.GONE
                }
            }
        }

        btnStop.setOnClickListener {
            btnStop.visibility = View.GONE
            btnPlay.visibility = View.VISIBLE
            videoView.pause()
            Handler(Looper.getMainLooper()).postDelayed({
                btnPlay.visibility = View.GONE
            },1000)
        }
        btnPlay.setOnClickListener {
            btnPlay.visibility = View.GONE
            btnStop.visibility = View.VISIBLE
            videoView.start()
            Handler(Looper.getMainLooper()).postDelayed({
                btnStop.visibility = View.GONE
            },1000)
        }

    }

    @SuppressLint("Range")
    fun getVideoContentUri(videoFile: File): Uri? {
        var uri: Uri? = null
        val filePath = videoFile.absolutePath
        val cursor = this@ShareVideoActivity.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Video.Media._ID),
            MediaStore.Video.Media.DATA + "=? ",
            arrayOf(filePath), null)

        if (cursor != null && cursor.moveToFirst()) {
            val id = cursor.getInt(cursor
                .getColumnIndex(MediaStore.MediaColumns._ID))
            val baseUri = Uri.parse("content://media/external/video/media")
            uri = Uri.withAppendedPath(baseUri, "" + id)
        } else if (videoFile.exists()) {
            val values = ContentValues()
            values.put(MediaStore.Video.Media.DATA, filePath)
            uri = this@ShareVideoActivity.contentResolver.insert(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        }
        cursor!!.close()
        return uri
    }

    private fun initViews() {
        addTextToolbar = findViewById(R.id.addTextToolbar)
        videoViewFrame = findViewById(R.id.videoViewFrame)
        videoView = findViewById(R.id.videoView)
        btnBack = findViewById(R.id.imgBtnBack)
        btnShare = findViewById(R.id.shareVideo)
        btnHome = findViewById(R.id.imgBtnHome)
        btnPlay = findViewById(R.id.btnPlay)
        btnStop = findViewById(R.id.btnStop)
    }

    override fun onPause() {
        super.onPause()
        stopPosition = videoView.currentPosition
        videoView.pause()
    }

    override fun onResume() {
        super.onResume()
        videoView.seekTo(stopPosition)
        videoView.start()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }

}