package com.text.art.fancy.creator.model

class GradientTextColorModel(var colors:String)