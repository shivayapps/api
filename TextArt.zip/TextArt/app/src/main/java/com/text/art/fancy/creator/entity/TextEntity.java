package com.text.art.fancy.creator.entity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.Log;

import com.text.art.fancy.creator.model.TextLayer;
import com.text.art.fancy.creator.R;
import com.text.art.fancy.creator.utils.FontProvider;

import static java.lang.Math.abs;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.toRadians;

public class TextEntity extends MotionEntity {

    private static final String TAG = "TextEntity";

    private static final float CIRCLE_LIMIT = 359.9999f;

    private final TextPaint textPaint;
    private final FontProvider fontProvider;
    private final Context context;

    private int color = Color.TRANSPARENT;

    @Nullable
    private Bitmap bitmap, oBitmap, mMutableBitmap;

    private int angle = 0;

    private int widthText;

    public boolean isCruve = false;

    private int mLineCount;

    private Canvas mCanvas;

    private Layout.Alignment alignment = Layout.Alignment.ALIGN_CENTER;

    private StaticLayout sl;

    private Drawable drawable;

    private int mLastwidth,mCurrentWidth, mLastLength;

    private float mTextSize,mAddTextSize;

    private boolean isCreateOne = false ;


    public TextEntity(@NonNull TextLayer textLayer,
                      @IntRange(from = 1) int canvasWidth,
                      @IntRange(from = 1) int canvasHeight,
                      @NonNull FontProvider fontProvider, Context context) {
        super(textLayer, canvasWidth, canvasHeight, context);
        this.fontProvider = fontProvider;

        this.context = context;

        this.textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);

        updateEntity(false);
//        oBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.tiles3);
    }

    public void setBackgroundImage(Bitmap image) {
        oBitmap = image;//BitmapFactory.decodeResource(context.getResources(), R.drawable.tile1);

    }

    public void setBackgroundColor(int color) {
        oBitmap = null;
        this.color = color;//BitmapFactory.decodeResource(context.getResources(), R.drawable.tile1);

    }

    public void setAngle(int angle) {
        this.angle = angle;
    }

    private void updateEntity(boolean moveToPreviousCenter) {
        if(!isCreateOne ){
            mTextSize = (getLayer().getFont().getSize() * canvasWidth);
            isCreateOne = true;
        }
        mCurrentWidth = canvasWidth;
        // save previous center
        PointF oldCenter = absoluteCenter();
        //this.bitmap = newBmp;
      /*  if (drawable != null) {
            drawable = null;
        }*/
        createBitmap(getLayer(), bitmap);

        // Log.d(TAG, "updateEntity: "+newBmp.getWidth() + " = "+newBmp.getHeight());

        // recycle previous bitmap (if not reused) as soon as possible
        //if (bitmap != null && bitmap != newBmp && !bitmap.isRecycled()) {
        //    bitmap.recycle();
        // }


        // newBmp = null;
        //this.mCloseBitmap = closeBmp;

        float width = drawable.getIntrinsicWidth();
        float height = drawable.getIntrinsicHeight();


        @SuppressWarnings("UnnecessaryLocalVariable")
        float widthAspect = 1.0F * canvasWidth / width;
        //float heightAspect = 1.0F * canvasHeight / height;

        // for text we always match text width with parent width
        this.holyScale = widthAspect;//Math.min(widthAspect, heightAspect);

        // initial position of the entity
        srcPoints[0] = 0;
        srcPoints[1] = 0;
        srcPoints[2] = width;
        srcPoints[3] = 0;
        srcPoints[4] = width;
        srcPoints[5] = height;
        srcPoints[6] = 0;
        srcPoints[7] = height;
        srcPoints[8] = 0;

        if (moveToPreviousCenter) {
            // move to previous center
            moveCenterTo(oldCenter);
        }
    }

    public void setMultiColor(int color1, int color2) {
        LinearGradient linearGradient = new LinearGradient(0, 0, 0, getHeight(), new int[]{color1, color2}, new float[]{0, 1}, Shader.TileMode.REPEAT);
        textPaint.setShader(linearGradient);
    }

    public void setMultiColorWithPosition(int color1, int color2, int position) {
        LinearGradient linearGradient = new LinearGradient(0, 0, 0, position, new int[]{color1, color2}, new float[]{0, 1}, Shader.TileMode.REPEAT);
        textPaint.setShader(linearGradient);
    }

    public Rect getRectBound() {
        Rect bounds = new Rect();
        textPaint.getTextBounds(getLayer().getText(), 0, getLayer().getText().length(), bounds);
        return bounds;
    }

    public void setShadowColor(int color) {
        textPaint.setShader(null);
        textPaint.setShadowLayer(10, 0, 0, color);
    }

    public void setBorder() {

    }

    public void setAlignment(Layout.Alignment alignment) {
        this.alignment = alignment;
    }


    /**
     * If reuseBmp is not null, and size of the new bitmap matches the size of the reuseBmp,
     * new bitmap won't be created, reuseBmp it will be reused instead
     *
     * @param textLayer text to draw
     * @param reuseBmp  the bitmap that will be reused
     * @return bitmap with the text
     */
    @NonNull
    private void createBitmap(@NonNull TextLayer textLayer, @Nullable Bitmap reuseBmp) {

        int boundsWidth = canvasWidth;

        // init params - size, color, typeface
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(mTextSize);
        textPaint.setColor(textLayer.getFont().getColor());
        textPaint.setTypeface(fontProvider.getTypeface(textLayer.getFont().getTypeface()));
        textPaint.setTextAlign(Paint.Align.LEFT);
        Rect result = new Rect();
        textPaint.getTextBounds(textLayer.getText(), 0, textLayer.getText().length(), result);

        Log.d(TAG, "createBitmap: " + (int) Math.ceil(result.width()));
        Log.d(TAG, "createBitmap: GET " + getTextWidth(textLayer));

        if(!isCruve) {

            if (drawable != null && (drawable.getIntrinsicWidth() >= canvasWidth || drawable.getIntrinsicHeight() >= canvasHeight)) {
                mTextSize -= 0.5;
                textPaint.setTextSize(mTextSize);
            }
            Log.d(TAG, "createBitmap: line " + mLastLength + " = " + textLayer.getText().length());
            if (mLastLength > textLayer.getText().length()) {

                mTextSize += 0.5;
                if (mTextSize >= (textLayer.getFont().getSize() * canvasWidth)) {
                    mTextSize = (textLayer.getFont().getSize() * canvasWidth);
                }
                textPaint.setTextSize(mTextSize);
                mLastLength = textLayer.getText().length() - 1;
            }
        }

        widthText = getTextWidth(textLayer) + ((int) textPaint.getTextSize() * 2);
        //widthText = Math.max(widthText, mLastwidth);
        int height = (int) (canvasHeight/1.4f);
        if (widthText == 0 || widthText > canvasWidth) {
            widthText = canvasWidth;
        }

        /*BoringLayout.Metrics boringMetrics=BoringLayout.isBoring(getLayer().getText(), textPaint);
        BoringLayout boringLayout=new BoringLayout(getLayer().getText(), textPaint, 0, Layout.Alignment.ALIGN_CENTER,
                0.0f, 0.0f, boringMetrics, false);*/


        // drawing text guide : http://ivankocijan.xyz/android-drawing-multiline-text-on-canvas/
        // Static layout which will be drawn on canvas
        // Log.d(TAG, "createBitmap: " + isCruve);

        if (isCruve) {

            while (mCurrentWidth <= result.width()){
                mTextSize -= 2.5;
                textPaint.setTextSize(mTextSize);
                textPaint.getTextBounds(textLayer.getText(), 0, textLayer.getText().length(), result);
            }

            Log.d(TAG, "createBitmap: w "+result.width());
            /*if(mLastLength > textLayer.getText().length()){
                Log.d(TAG, "createBitmap: w1 "+result.width());
                mTextSize += .2f;
                textPaint.setTextSize(mTextSize);
                textPaint.getTextBounds(textLayer.getText(), 0, textLayer.getText().length(), result);
                if(result.width() >= mCurrentWidth){
                    mLastLength = textLayer.getText().length() - 1;
                }
            }*/
            sl = new StaticLayout("", // - text which will be drawn
                    textPaint,
                    canvasWidth, // - width of the layout
                    alignment, // - layout alignment
                    1, // 1 - text spacing multiply
                    1, // 1 - text spacing add
                    true); // true - include padding
        } else {
            sl = new StaticLayout(textLayer.getText(), // - text which will be drawn
                    textPaint,
                    widthText, // - width of the layout
                    alignment, // - layout alignment
                    1, // 1 - text spacing multiply
                    1, // 1 - text spacing add
                    true); // true - include padding

            if (sl != null) {
                // Log.d(TAG, "createBitmap: line count " + sl.getLineCount());
                mLineCount = sl.getLineCount();
            }
        }
        // calculate height for the entity, min - Limits.MIN_BITMAP_HEIGHT
        int boundsHeight = sl.getHeight();


        // create bitmap not smaller than TextLayer.Limits.MIN_BITMAP_HEIGHT
        int bmpHeight = (int) (canvasHeight * Math.max(TextLayer.Limits.MIN_BITMAP_HEIGHT, 1.0F * boundsHeight / canvasHeight));

        // create bitmap where text will be drawn
        Bitmap bmp;
       /* if(oBitmap != null)
            mMutableBitmap = oBitmap.copy(oBitmap.getConfig(), true);*/

        if (reuseBmp != null && reuseBmp.getWidth() == widthText && reuseBmp.getHeight() == bmpHeight) {
            // if previous bitmap exists, and it's width/height is the same - reuse it
            bmp = reuseBmp;
            bmp.eraseColor(Color.TRANSPARENT); // erase color when reusing
            /*if (oBitmap != null) {
                mMutableBitmap = Bitmap.createScaledBitmap(mMutableBitmap, boundsWidth, bmpHeight, false);
            }else{

            }*/
        } else {

            if (height == 0)
                height = bmpHeight;

            if (isCruve)
                bmp = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888);
            else
                bmp = Bitmap.createBitmap(widthText, bmpHeight, Bitmap.Config.ARGB_8888);
           /* bmp.eraseColor(color);

            if (oBitmap != null)
                mMutableBitmap = Bitmap.createScaledBitmap(mMutableBitmap, boundsWidth, bmpHeight, false);*/
        }

        Log.d(TAG, "textChanged: textEntity" + bmp.getWidth());

        Canvas canvas = null;
       /* if (oBitmap != null)
            canvas = new Canvas(mMutableBitmap);
        else*/
        canvas = new Canvas(bmp);
        //  canvas.drawBitmap(bmp,0,0,new Paint());
        canvas.save();

        // move text to center if bitmap is bigger that text
        if (boundsHeight < bmpHeight) {
            //calculate Y coordinate - In this case we want to draw the text in the
            //center of the canvas so we move Y coordinate to center.
            float textYCoordinate = (bmpHeight - boundsHeight) / 2;
            canvas.translate(0, textYCoordinate);

        }

        Log.d(TAG, "createBitmap: drawble" + getWidth() + " = " + getHeight() + " = " + mTextSize + " = " + canvasWidth + " = " + canvasHeight);
        if (isCruve) {

            //textPaint.setTextSize(getLayer().getFont().getSize()*(getWidth()*2));
            textPaint.setTextAlign(Paint.Align.CENTER);
            Rect bounds = new Rect();
            textPaint.getTextBounds(textLayer.getText(), 0, textLayer.getText().length(), bounds);

            RectF drawTextOval = new RectF();
            Path drawTextPath;
            Matrix mDrawnMatrix = new Matrix();
            Log.d(TAG, "createBitmap: r " + angle);
            if (angle >= 0) {

                float rIn = bounds.width() / 6.3f, rOut = (bounds.width() * 1.1f);
                int cx = getWidth() / 2, cy = (getHeight() / 2) + angle;

                Path midway = new Path();
                float r = rIn + angle;


           /* if (rIn < angle) {
                r = rIn;
            }*/

                RectF segment = new RectF(cx - r, cy - r, cx + r, cy + r);

                midway.addArc(segment, -270, 360);

                midway.computeBounds(segment, true);
                mDrawnMatrix.postRotate(0,
                        (segment.right + segment.left) / 2,
                        (segment.bottom + segment.top) / 2);
                //midway.transform(mDrawnMatrix);
                canvas.drawTextOnPath(textLayer.getText(), midway, 0, 0, textPaint);

            }
            if (angle < 0) {
                Log.d(TAG, "createBitmap: 1 "+angle);
                angle = abs(angle);
                angle = (int) (getWidth() * 2.5f) - angle;
                Log.d(TAG, "createBitmap: 2 "+angle);
                float rIn = bounds.width() / 6.3f, rOut = (bounds.width() * 1.1f);
                int cx = getWidth() / 2, cy = (getHeight() / 2) - angle;

                Path midway = new Path();
                float r = rIn + angle;

           /* if (rIn < angle) {
                r = rIn;
            }*/

                RectF segment = new RectF(cx - r, cy - r, cx + r, cy + r);

                midway.addArc(segment, 270, -360);

                midway.computeBounds(segment, true);
                mDrawnMatrix.postRotate(0,
                        (segment.right + segment.left) / 2,
                        (segment.bottom + segment.top) / 2);
                //midway.transform(mDrawnMatrix);
                //canvas.drawPath(midway,new Paint());
                canvas.drawTextOnPath(textLayer.getText(), midway, 0, textLayer.getFont().getSize() * canvasWidth / 2.4f, textPaint);
            }


            //  float f11 = this.textPaint.measureText(getLayer().getText()) + (((float) (getLayer().getText().length() - 1)) * 0);
            //  Double abs = (double) ((f11 * 360.0f) / ((float) Math.abs(290)));
            //  f11 = (float) (abs / 3.141592653589793d);

            // Path path = new Path();
            //  Log.d(TAG, "drawContent: "+bounds.width() + " = " + oRight*0.95f);
            // RectF oval = new RectF(100, 100, 300, 300);
            //RectF oval = new RectF(centerX-(getWidth()/2),centerY-(getHeight()/2),(centerX+textPaint.measureText("Abc ABc")*1f/2),(centerY+textPaint.measureText("Abc ABc")*1f/2));
            //add Arc in Path with start angle -180 and sweep angle 200
            // path.addArc(oval, 270, -360);
            //path.addCircle(200,200,200, Path.Direction.CW);
            //canvas.drawPath(path,new Paint());
            //canvas.drawPath(path,new Paint());
            //canvas.drawTextOnPath(getLayer().getText(), path, 0, 0, textPaint);
        }

        //draws static layout on canvas
        sl.draw(canvas);

      /*  textPaint.setStyle(Paint.Style.STROKE);
        textPaint.setStyle(Paint.Style.STROKE);
        textPaint.setStrokeJoin(Paint.Join.ROUND);
        textPaint.setStrokeWidth(8);
        textPaint.setColor(Color.BLACK);
        StaticLayout sl1 = new StaticLayout(textLayer.getText(), // - text which will be drawn
                textPaint,
                widthText, // - width of the layout
                alignment, // - layout alignment
                1, // 1 - text spacing multiply
                1, // 1 - text spacing add
                true); // true - include padding
        sl1.draw(canvas);*/
        canvas.restore();

        /*if(oBitmap != null)
            return mMutableBitmap;
        else*/
        if (drawable != null) {
            drawable = null;
        }

        drawable = new BitmapDrawable(context.getResources(), bmp);
        if (widthText > mLastwidth) mLastwidth = widthText;
        //bmp.recycle();
        bmp = null;
        //return bmp;
        mLastLength = textLayer.getText().length();
    }

    private int getTextWidth(TextLayer textLayer) {
        if (textLayer.getText().length() != 0) {
            Paint textPaint = new Paint();
            Rect bounds = new Rect();
            textPaint.setTextSize(textLayer.getFont().getSize() * canvasHeight);
            /*if(mTypeface != null){
                textPaint.setTypeface(mTypeface);
            }*/
            String buttonText = textLayer.getText();
            textPaint.getTextBounds(buttonText, 0, buttonText.length(), bounds);

            if (bounds.width() > canvasWidth) {
                TextPaint longTextPaint = new TextPaint();
                longTextPaint.setTextSize(textLayer.getFont().getSize() * canvasHeight);
               /* if(mTypeface != null){
                    longTextPaint.setTypeface(mTypeface);
                }*/
                StaticLayout staticLayout = new StaticLayout(textLayer.getText(), longTextPaint, getWidth(),
                        Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
                int textLineCount = (int) Math.ceil(staticLayout.getHeight() / bounds.height());
                Log.d(TAG, "getTextWidth: " + textLineCount);
                int multiLineTextWidth = getWidth();
                while ((int) Math.ceil(staticLayout.getHeight() / bounds.height()) == textLineCount && multiLineTextWidth > 1) {
                    multiLineTextWidth--;
                    staticLayout = new StaticLayout(textLayer.getText(), longTextPaint, multiLineTextWidth,
                            Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
                }
                return (int) (multiLineTextWidth);
            } else {
                return (int) (bounds.width());
            }
        } else {
            return 0;
        }
    }

    @Override
    @NonNull
    public TextLayer getLayer() {
        return (TextLayer) layer;
    }

    @Override
    protected void drawContent(@NonNull Canvas canvas, @Nullable Paint drawingPaint, @Nullable Paint deletePaint) {
        mCanvas = canvas;

        canvas.save();
        canvas.concat(matrix);
        drawable.setFilterBitmap(true);//抗锯齿
        drawable.setBounds(new Rect(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight()));
        drawable.setAlpha(255);
        drawable.draw(canvas);
        canvas.restore();

        if (bitmap != null) {

            //Log.d(TAG, "drawContent: "+left+" = "+top +" = " +right+" = "+bottom);

            //canvas.drawBitmap(bitmap, matrix, drawingPaint);

            //   canvas.drawBitmap();


            // canvas.drawTextOnPath("HELLO WORLD", midway, 0, 0, textPaint);

           /* float f11 = this.textPaint.measureText("Hello World World") + (((float) ("Hello World World".length() - 1)) * 0);
            Double abs = (double) ((f11 * 360.0f) / ((float) Math.abs(290)));
            f11 = (float) (abs / 3.141592653589793d);

            Path path = new Path();
            Log.d(TAG, "drawContent: "+bounds.width() + " = " + oRight*0.95f);
            RectF oval = new RectF(100,100,100+f11,100+f11);
            //RectF oval = new RectF(centerX-(getWidth()/2),centerY-(getHeight()/2),(centerX+textPaint.measureText("Abc ABc")*1f/2),(centerY+textPaint.measureText("Abc ABc")*1f/2));
            //add Arc in Path with start angle -180 and sweep angle 200
            path.addArc(oval, angle, 359);
            //path.addCircle(200,200,200, Path.Direction.CW);
            canvas.drawPath(path,new Paint());
            //canvas.drawPath(path,new Paint());
            canvas.drawTextOnPath("Hello World World", path, 50, 0, textPaint);*/


        }
    }

    public void drawArcSegment(Canvas canvas, float cx, float cy, float rInn, float rOut, float startAngle,
                               float sweepAngle, Paint fill, Paint stroke) {
        if (sweepAngle > CIRCLE_LIMIT) {
            sweepAngle = CIRCLE_LIMIT;
        }
        if (sweepAngle < -CIRCLE_LIMIT) {
            sweepAngle = -CIRCLE_LIMIT;
        }

        RectF outerRect = new RectF(cx - rOut, cy - rOut, cx + rOut, cy + rOut);
        RectF innerRect = new RectF(cx - rInn, cy - rInn, cx + rInn, cy + rInn);

        Path segmentPath = new Path();
        double start = toRadians(startAngle);
        segmentPath.moveTo((float) (cx + rInn * cos(start)), (float) (cy + rInn * sin(start)));
        segmentPath.lineTo((float) (cx + rOut * cos(start)), (float) (cy + rOut * sin(start)));
        segmentPath.arcTo(outerRect, startAngle, sweepAngle);
        double end = toRadians(startAngle + sweepAngle);
        segmentPath.lineTo((float) (cx + rInn * cos(end)), (float) (cy + rInn * sin(end)));
        segmentPath.arcTo(innerRect, startAngle + sweepAngle, -sweepAngle);
        if (fill != null) {
            canvas.drawPath(segmentPath, fill);
        }
        if (stroke != null) {
            canvas.drawPath(segmentPath, stroke);
        }
    }


    public Path drawCurvedArrow(int x1, int y1, int x2, int y2, int curveRadius, int color, int lineWidth, Canvas canvas) {

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(lineWidth);
        paint.setColor(ContextCompat.getColor(context, color));

        final Path path = new Path();
        int midX = x1 + ((x2 - x1) / 2);
        int midY = y1 + ((y2 - y1) / 2);
        float xDiff = midX - x1;
        float yDiff = midY - y1;
        double angle = (Math.atan2(yDiff, xDiff) * (180 / Math.PI)) - 90;
        double angleRadians = toRadians(angle);
        float pointX = (float) (midX + curveRadius * cos(angleRadians));
        float pointY = (float) (midY + curveRadius * sin(angleRadians));

        path.moveTo(x1, y1);
        path.cubicTo(x1, y1, pointX, pointY, x2, y2);
        canvas.drawPath(path, paint);
        return path;

    }


    @Override
    public int getWidth() {
        return drawable != null ? drawable.getIntrinsicWidth() : 0;
    }

    @Override
    public int getHeight() {
        return drawable != null ? drawable.getIntrinsicHeight() : 0;
    }

    public void updateEntity() {
        updateEntity(true);
    }

    @Override
    public void release() {
        if (bitmap != null && !bitmap.isRecycled()) {
            bitmap = null;
        }
    }


}
