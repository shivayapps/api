package com.text.art.fancy.creator.model

import sticker.view.dixitgabani.autofit.AutofitLayout

data class Sticker(
    val sticker: AutofitLayout,
    val type: String,
    var isLock: Boolean = false,
    var mainText: String = "",
    var shadow: Int = 0,
    var blur: Int = 0,
    var textColor: Int = -1,
    var tintColor: Int = -1,
    var bgColor: Int = -1,
    var changedSize: Int = 0,
    var shadowOpacity: Int = 0,
    var latterSpacing: Int = 0,
    var lineSpacing: Int = 0,
    var rX: Int = 0,
    var rY: Int = 0,
    var font: Int = -1,
    var textOpacity: Int = 0,
    var curve: Int = 0,
    var isPattern: Boolean = false,
    var isGradient: Boolean = false,
    var isMultiColor: Boolean = false,
    var isBold: Boolean = false,
    var isItalic: Boolean = false,
    var isUnderline: Boolean = false
)
