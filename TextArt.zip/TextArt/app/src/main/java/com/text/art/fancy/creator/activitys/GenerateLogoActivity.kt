package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.*
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.HomeActivity.Companion.logoArray
import com.text.art.fancy.creator.adepter.EditLogoAdapter
import com.text.art.fancy.creator.adepter.LogoCategoryAdapter
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.model.LogoData
import com.text.art.fancy.creator.utils.click
import com.text.art.fancy.creator.utils.hideSystemUI
import com.text.art.fancy.creator.utils.showToast
import kotlinx.android.synthetic.main.activity_generate_logo.*


class GenerateLogoActivity : AppCompatActivity() {

    private lateinit var txtGenerateLogo: EditText
    private lateinit var btnGenerateLogo: Button
    private lateinit var recyclerLogo: RecyclerView
    private lateinit var recyclerLogoCategory: RecyclerView
    private lateinit var touchGesture: ConstraintLayout
    private lateinit var seekStock: SeekBar

    //Adapters
    private lateinit var recyclerLogoAdapter: EditLogoAdapter
    private lateinit var recyclerCategoryAdapter: LogoCategoryAdapter

    //Variables
    private var lastClickTime = 0L
    private var logoName = "TEXTART"

    val filteredArray = arrayListOf<LogoData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generate_logo)
        hideSystemUI()

//        val policy: StrictMode.ThreadPolicy = StrictMode.ThreadPolicy.Builder().permitAll().build()
//        StrictMode.setThreadPolicy(policy)

        initViews()
        initData()
        initAdapter()
        initListener()
        initViewAction()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun initViewAction() {
        btnGenerateLogo.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            if (TextUtils.isEmpty(txtGenerateLogo.text)){
                showToast("Please enter logo name.")
                return@click
            }else{
                logoName = txtGenerateLogo.text.toString()
                recyclerLogoAdapter.logoText = logoName
                recyclerLogoAdapter.notifyDataSetChanged()
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initListener() {
        seekStock.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {}

            override fun onStartTrackingTouch(p0: SeekBar?) {}

            @SuppressLint("NotifyDataSetChanged")
            override fun onStopTrackingTouch(seek: SeekBar?) {
                recyclerLogoAdapter.borderSize = seek!!.progress.toFloat()
                recyclerLogoAdapter.notifyDataSetChanged()
            }

        })

        /*try {
            recyclerLogo.setOnTouchListener(object : OnSwipeTouchListener(this@GenerateLogoActivity){

                override fun onSwipeRight() {
//                    showToast("onSwipeRight")
                    if (Constants.CategoryPosition != 0){
                        Constants.CategoryPosition--
                        recyclerCategoryAdapter.changeItem(Constants.CategoryPosition)
                    }
                    super.onSwipeRight()
                }

                override fun onSwipeLeft() {
//                    showToast("onSwipeLeft")
                    if (Constants.CategoryPosition != logoArray.size) {
                        Constants.CategoryPosition++
                        recyclerCategoryAdapter.changeItem(Constants.CategoryPosition)
                    }
                    super.onSwipeLeft()
                }

                override fun onSwipeTop() {
//                    showToast("onSwipeTop")
                    super.onSwipeTop()
                }

                override fun onSwipeBottom() {
//                    showToast("onSwipeBottom")
                    super.onSwipeBottom()
                }
            })
        } catch (e: Exception) { }*/

        /*txtGenerateLogo.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(s: Editable?) {

            }
        })*/

    }

    private fun initAdapter() {
        recyclerLogoAdapter = EditLogoAdapter(this, logoArray,
            object : EditLogoAdapter.OnItemClick{
            override fun onItemClick(position: Int, logoText: String) {
                if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return
                lastClickTime = SystemClock.elapsedRealtime()
                Intent(this@GenerateLogoActivity, AddTextActivity1::class.java).also {
                    if (Constants.CategoryPosition == 0){
                        it.putExtra("LOGO", logoArray[position])
                    }else{
                        it.putExtra("LOGO", filteredArray[position])
                    }
                    it.putExtra("TEXT", logoText)
                    startActivity(it)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                }
            }
        })
        val layoutManager = GridLayoutManager(this, 2)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
//        val layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
//        recyclerLogo.setHasFixedSize(true)
        recyclerLogo.itemAnimator = DefaultItemAnimator()
        recyclerLogo.layoutManager = layoutManager
        recyclerLogo.adapter = recyclerLogoAdapter

        Constants.CategoryPosition = 0 //Default Not Select Item
        HomeActivity.logoCategory.add(0,"ALL")
        recyclerCategoryAdapter = LogoCategoryAdapter(this, HomeActivity.logoCategory,
            object : LogoCategoryAdapter.OnItemClick{
            @SuppressLint("NotifyDataSetChanged")
            override fun onItemClick(position: Int, category: String) {
                if (category.equals("ALL", ignoreCase = true)){
                    recyclerLogoAdapter.updateList(logoArray)
                }else{
                    filteredArray.clear()
                    for (d in logoArray) {
                        if (d.tag == category) {
                            filteredArray.add(d)
                        }
                    }
                    recyclerLogoAdapter.updateList(filteredArray)
                }
                recyclerCategoryAdapter.notifyDataSetChanged()
            }
        })
        recyclerLogoCategory.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
//        recyclerLogoCategory.setHasFixedSize(true)
        recyclerLogoCategory.itemAnimator = DefaultItemAnimator()
        recyclerLogoCategory.adapter = recyclerCategoryAdapter
    }

    @SuppressLint("SetTextI18n")
    private fun initData() {
        txtGenerateLogo.setText("TEXTART")
    }

    private fun initViews() {
        txtGenerateLogo = findViewById(R.id.txtGenerateLogo)
        btnGenerateLogo = findViewById(R.id.btnGenerateLogo)
        recyclerLogo = findViewById(R.id.logoList)
        recyclerLogoCategory = findViewById(R.id.logoCategory)
        touchGesture = findViewById(R.id.touchGesture)
        seekStock = findViewById(R.id.seekStock)
    }

    companion object{
        private val TAG = "GenerateLogoActivity"
    }

}