package com.text.art.fancy.creator.categorys.parameter;

import com.text.art.fancy.creator.categorys.ParametersItemAllChilds;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ParametersItem{

	@SerializedName("name")
	private String name;

	@SerializedName("id")
	private int id;

	@SerializedName("images")
	private List<CategoryParametersItem> categoryParameters;

	@SerializedName("all_childs")
	private List<ParametersItemAllChilds> all_childs;

	@SerializedName("icon")
	private String icon;

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public void setCategoryParameters(List<CategoryParametersItem> categoryParameters){
		this.categoryParameters = categoryParameters;
	}

	public List<ParametersItemAllChilds> getAll_childs() {
		return all_childs;
	}

	public void setAll_childs(List<ParametersItemAllChilds> all_childs) {
		this.all_childs = all_childs;
	}

	public List<CategoryParametersItem> getCategoryParameters(){
		return categoryParameters;
	}

	@Override
 	public String toString(){
		return 
			"ParametersItem{" + 
			"name = '" + name + '\'' + 
			",id = '" + id + '\'' + 
			",category_parameters = '" + categoryParameters + '\'' + 
			"}";
		}
}