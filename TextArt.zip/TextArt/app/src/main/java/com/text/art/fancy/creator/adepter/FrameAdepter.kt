package com.text.art.fancy.creator.adepter

import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.AddTextActivity1
import com.text.art.fancy.creator.comman.Constants
import kotlinx.android.synthetic.main.row_background_item.view.*

class FrameAdepter(
        var addTextActivity1: AddTextActivity1,
        var frameListImg: ArrayList<String>,
        var frameValList: ArrayList<String>,
        var frameInterface : onClickFrameListener
    ) : RecyclerView.Adapter<FrameAdepter.MyViewHolder>() {

    interface onClickFrameListener{
        public fun OnClickFrame(frame : Int){
        }
    }
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mImgFrame = itemView.findViewById<ImageView>(R.id.imgFrame)
        val mImgPreview = itemView.findViewById<ImageView>(R.id.imgPreview)
        val mImgView = itemView.findViewById<ImageView>(R.id.viewSelectFrame)
        val viewLockFrame = itemView.findViewById<ImageView>(R.id.viewLockFrame)
        val viewLockPremium = itemView.findViewById<ImageView>(R.id.imgLockPremium)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FrameAdepter.MyViewHolder {
        val view = LayoutInflater.from(addTextActivity1).inflate(R.layout.list_of_frame,parent,false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return frameListImg.size
    }

    override fun onBindViewHolder(holder: FrameAdepter.MyViewHolder, position: Int) {
        Log.d("CSACSDSD", ": ${frameListImg[position]}  ${frameValList[position]}")
        Glide.with(addTextActivity1).load(frameListImg[position]).into(holder.mImgFrame)

        if (frameValList[position] == "1"){
            holder.viewLockPremium.visibility = View.GONE
            holder.viewLockFrame.visibility = View.VISIBLE
        }else  if (frameValList[position] == "2"){
            holder.viewLockPremium.visibility = View.VISIBLE
            holder.viewLockFrame.visibility = View.GONE
        }else{
            holder.viewLockFrame.visibility = View.GONE
            holder.viewLockPremium.visibility = View.GONE
        }
        if (position == 0){
            holder.mImgFrame.setPadding(25,25,25,25)
        }
        else{
            holder.mImgFrame.setPadding(0,0,0,0)
        }
        holder.itemView.setOnClickListener {
            frameInterface.OnClickFrame(position)
        }


    }


}