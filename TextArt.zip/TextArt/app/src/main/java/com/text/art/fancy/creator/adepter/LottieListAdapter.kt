package com.text.art.fancy.creator.adepter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.adepter.LottieListAdapter.MyHolder

class LottieListAdapter(
    var lottieList: ArrayList<String>,
    val onClickView: (String) -> Unit
) : RecyclerView.Adapter<MyHolder>() {

    class MyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val lottieview = itemView.findViewById<LottieAnimationView>(R.id.recyclerLottieList)
        val mainCard = itemView.findViewById<CardView>(R.id.recyclerCard)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        return MyHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_lottielist,parent,false))
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        with(holder){
            Log.d("TAG", "onBindViewHolder: ${lottieList[position]}")
            lottieview.setAnimation(lottieList[position])
            lottieview.loop(true)
            lottieview.playAnimation()
            mainCard.setOnClickListener {
                onClickView(lottieList[position])
            }
        }
    }

    override fun getItemCount(): Int {
        return lottieList.size
    }
}