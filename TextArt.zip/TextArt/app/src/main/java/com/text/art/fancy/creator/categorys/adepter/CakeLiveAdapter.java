package com.text.art.fancy.creator.categorys.adepter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.text.art.fancy.creator.R;
import com.text.art.fancy.creator.categorys.model.CakeModel;

import java.util.ArrayList;

//import com.pip.camera.art.filter.photo.effect.editor.R;
//import com.pip.camera.art.filter.photo.effect.editor.model.CakeModel;
//import com.pip.camera.art.filter.photo.effect.editor.sqlite_database.DBHelper;

public class CakeLiveAdapter extends RecyclerView.Adapter<CakeLiveAdapter.MyViewholder> {

    private ArrayList<CakeModel> mForegroundList;
    private Context mContext;
    private OnItemSelectedListner onItemSelectedListner;

    public CakeLiveAdapter(ArrayList<CakeModel> mForegroundList, Context mContext , OnItemSelectedListner onItemSelectedListner ) {
        this.mForegroundList = mForegroundList;
        this.mContext = mContext;
        this.onItemSelectedListner = onItemSelectedListner;
    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewholder(LayoutInflater.from(mContext).inflate(R.layout.rv_stickers_live, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {
        holder.progressContent.setVisibility(View.VISIBLE);
        holder.imgForeground.setVisibility(View.GONE);
        holder.layoutLock.setVisibility(View.GONE);



        Glide.with(mContext).load(mForegroundList.get(position).getImageItem().getImage()).into(new CustomTarget<Drawable>() {
            @Override
            public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                holder.imgForeground.setImageDrawable(resource);
                holder.imgForeground.setVisibility(View.VISIBLE);
                holder.progressContent.setVisibility(View.GONE);

                if (mForegroundList.get(position).isLocked()){
                    holder.layoutLock.setVisibility(View.VISIBLE);
                    holder.layoutPremium.setVisibility(View.GONE);
                    holder.tvAdCount.setVisibility(View.VISIBLE);
                    if (mForegroundList.get(position).isAdCount() > 1) {
                        holder.tvAdCount.setText(String.valueOf(mForegroundList.get(position).isAdCount()));
                    } else {
                        holder.tvAdCount.setVisibility(View.GONE);
                    }
                }else if (mForegroundList.get(position).isPremium()){
                    holder.layoutLock.setVisibility(View.GONE);
                    holder.layoutPremium.setVisibility(View.VISIBLE);
                }else {
                    holder.layoutLock.setVisibility(View.GONE);
                    holder.layoutPremium.setVisibility(View.GONE);
                }
            }

            @Override
            public void onLoadCleared(@Nullable Drawable placeholder) {
                holder.imgForeground.setVisibility(View.VISIBLE);
                holder.progressContent.setVisibility(View.GONE);
            }
        });

        holder.imgForeground.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemSelectedListner.onItemClick(position,mForegroundList.get(position));
            }
        });


    }

    public interface OnItemSelectedListner {
        void onItemClick(int position, CakeModel imagesItem);
    }

    @Override
    public int getItemCount() {
        return mForegroundList.size();
    }

    class MyViewholder extends RecyclerView.ViewHolder {
        ImageView imgForeground,imgBack;
        ProgressBar progressContent;
        ConstraintLayout layoutLock;
        RelativeLayout layoutPremium;
        TextView tvAdCount;

        public MyViewholder(@NonNull View itemView) {
            super(itemView);
            imgForeground = itemView.findViewById(R.id.imgForeground);
            imgBack = itemView.findViewById(R.id.imgBack);
            progressContent = itemView.findViewById(R.id.progressContent);
            layoutLock = itemView.findViewById(R.id.layoutLock);
            layoutPremium = itemView.findViewById(R.id.layoutPremium);
            tvAdCount = itemView.findViewById(R.id.tvAdCount);
        }
    }
}
