package com.text.art.fancy.creator.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DBHelper(mContext: Context) : SQLiteOpenHelper(mContext, mDBName, null, 13) {

    private val TAG = "DBHelper"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBFontStyle (ID INTEGER PRIMARY KEY, $Col2 TEXT,$Col3 TEXT,$Col4 TEXT,$Col5 TEXT,$Col6 TEXT,$Col7 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBProFontStyle (ID INTEGER PRIMARY KEY, $Col2 TEXT,$Col3 TEXT,$Col4 TEXT,$Col5 TEXT,$Col6 TEXT,$Col7 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenFontStyle (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenFrame (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenPattern (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenBG (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenCombo (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenAnim (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenSticker (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBOpenFrames (ID INTEGER PRIMARY KEY,$Col2 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBFrame (ID INTEGER PRIMARY KEY AUTOINCREMENT, $Col2 TEXT,$Col3 TEXT)")
        db?.execSQL("CREATE TABLE IF NOT EXISTS $mTBPattern (ID INTEGER PRIMARY KEY AUTOINCREMENT, $Col2 TEXT,$Col3 TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $mTBFontStyle")
        db?.execSQL("DROP TABLE IF EXISTS $mTBProFontStyle")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenFontStyle")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenFrame")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenPattern")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenBG")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenCombo")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenAnim")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenSticker")
        db?.execSQL("DROP TABLE IF EXISTS $mTBOpenFrames")
        db?.execSQL("DROP TABLE IF EXISTS $mTBFrame")
        db?.execSQL("DROP TABLE IF EXISTS $mTBPattern")
        onCreate(db)
    }

    fun insertProFontData(id: Int, name: String, flag: String, prime: String, isDownloaded: Int, path: String, thumb: String?=null) {
        val db = this.writableDatabase
        val cValues = ContentValues()
        cValues.put("ID", id)
        cValues.put(Col2, name)
        cValues.put(Col3, flag)
        cValues.put(Col4, prime)
        cValues.put(Col5, isDownloaded)
        cValues.put(Col6, path)
        cValues.put(Col7, thumb)
        db.insert(mTBProFontStyle, null, cValues)
//        db.close()
    }

    fun deleteFontData() {
        val db = this.writableDatabase
        return db.execSQL("delete from $mTBFontStyle")
    }

    val allProFontData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBProFontStyle", null)
        }

    fun insertData(id: Int, name: String, flag: String, prime: String, isDownloaded: Int, path: String, thumb: String?=null) {
        val db = this.writableDatabase
        val cValues = ContentValues()
        cValues.put(Col1, id)
        cValues.put(Col2, name)
        cValues.put(Col3, flag)
        cValues.put(Col4, prime)
        cValues.put(Col5, isDownloaded)
        cValues.put(Col6, path)
        cValues.put(Col7, thumb)
        db.insert(mTBFontStyle, null, cValues)
        db.close()
    }

    fun insertOpenFontData(id: Int, name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
        cValues.put(Col1, id)
        cValues.put(Col2, name)
        db.insert(mTBOpenFontStyle, null, cValues)
        db.close()
    }

    val allOpenFontData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenFontStyle", null)
        }

    fun insertOpenPatternData(id: Int, name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
        cValues.put(Col1, id)
        cValues.put(Col2, name)
        db.insert(mTBOpenPattern, null, cValues)
        db.close()
    }

    fun insertOpenBgData(id: Int, name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
//        cValues.put(Col1, id)
        cValues.put(Col2, name)
        db.insert(mTBOpenBG, null, cValues)
        Log.d(TAG, "insertOpenBgData: TBL_NANE: $mTBOpenBG cVal2: ${cValues.get(Col2)} val $name")
        db.close()
    }

    fun insertOpenComboData(id: Int, name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
//        cValues.put(Col1, id)
        cValues.put(Col2, name)
        db.insert(mTBOpenCombo, null, cValues)
        db.close()
    }

    fun insertOpenAnimData(id: Int, name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
//        cValues.put(Col1, id)
        cValues.put(Col2, name)
        db.insert(mTBOpenAnim, null, cValues)
        db.close()
    }

    fun insertOpenStickerData(id: Int, name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
//        cValues.put(Col1, id)
        cValues.put(Col2, name)
        db.insert(mTBOpenSticker, null, cValues)
        db.close()
    }

    fun insertOpenFramerData(id: Int, name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
//        cValues.put(Col1, id)
        cValues.put(Col2, name)
        db.insert(mTBOpenFrames, null, cValues)
        db.close()
    }

    val allOpenPatternData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenPattern", null)
        }
    val allOpenBGData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenBG", null)
        }
    val allOpenComboData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenCombo", null)
        }
    val allOpenAnimData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenAnim", null)
        }
    val allOpenStickerData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenSticker", null)
        }
    val allOpenFramerData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenFrames", null)
        }

    fun insertOpenFrameData(name: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
        cValues.put(Col2, name)
        db.insert(mTBOpenFrame, null, cValues)
        db.close()
    }

    val allOpenFrameData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBOpenFrame", null)
        }

    fun updateData(id: Int, flag: String, prime: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(Col1, id)
        contentValues.put(Col3, flag)
        contentValues.put(Col4, prime)
        db.update(mTBFontStyle, contentValues, "ID = ?", arrayOf(id.toString()))
        db.close()
        return true
    }

    fun updateDownloadedFontData(id: Int, isDownloaded: Int, path: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(Col1, id)
        contentValues.put(Col5, isDownloaded)
        contentValues.put(Col6, path)
        db.update(mTBFontStyle, contentValues, "ID = ?", arrayOf(id.toString()))
        db.update(mTBProFontStyle, contentValues, "ID = ?", arrayOf(id.toString()))
        db.close()
        return true
    }

    val allData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBFontStyle", null)
        }

    val allProData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBProFontStyle", null)
        }

    fun deleteFrameData() {
        val db = this.writableDatabase
        return db.execSQL("delete from $mTBFrame")
    }

    fun insertFrameData(name: String, flag: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
        cValues.put(Col2, name)
        cValues.put(Col3, flag)
        db.insert(mTBFrame, null, cValues)
        db.close()
    }

    fun updateFrameData(id: String, flag: String):
            Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(Col1, id)
        contentValues.put(Col3, flag)
        db.update(mTBFrame, contentValues, "ID = ?", arrayOf(id))
        db.close()
        return true
    }

    val allFrameData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBFrame", null)
        }

    fun deletePatternData() {
        val db = this.writableDatabase
        return db.execSQL("delete from $mTBPattern")
    }

    fun insertPatternData(name: String, flag: String) {
        val db = this.writableDatabase
        val cValues = ContentValues()
        cValues.put(Col2, name)
        cValues.put(Col3, flag)
        db.insert(mTBPattern, null, cValues)
        db.close()
    }

    fun updatePatternData(id: String, flag: String):
            Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(Col1, id)
        contentValues.put(Col3, flag)
        db.update(mTBPattern, contentValues, "ID = ?", arrayOf(id))
        db.close()
        return true
    }

    val allPatternData: Cursor
        get() {
            val db = this.writableDatabase
            return db.rawQuery("SELECT * FROM $mTBPattern", null)
        }

    companion object {
        const val mDBName = "fontStyle.db"

        const val mTBProFontStyle = "prime_font_style"

        const val mTBOpenFontStyle = "open_font_style"
        const val mTBOpenPattern = "open_sticker_style"
        const val mTBOpenFrame = "open_frame_style"
        const val mTBOpenBG = "open_bg_style"
        const val mTBOpenCombo = "open_combo_style"
        const val mTBOpenAnim = "open_anim_style"
        const val mTBOpenSticker = "open_sticker_api_style"
        const val mTBOpenFrames = "open_frame_api_style"

        const val mTBFontStyle = "font_style"
        const val mTBFrame = "frame"
        const val mTBPattern = "pattern"

        const val Col1 = "ID"
        const val Col2 = "NAME"
        const val Col3 = "FLAG_VAL"
        const val Col4 = "PRIME_VAL"
        const val Col5 = "IS_DOWNLOADED"
        const val Col6 = "PATH"
        const val Col7 = "THUMB"
    }
}