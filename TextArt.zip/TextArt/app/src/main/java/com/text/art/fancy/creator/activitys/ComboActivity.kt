package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.*
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.text.art.fancy.creator.comboapi.ComboAdapter
import com.text.art.fancy.creator.comboapi.ComboDataFragment
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.categorys.ParametersItemAllChilds
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.newapi.model.SubCategory
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.utils.*
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.activity_combo.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import java.util.ArrayList
import kotlin.properties.Delegates

class ComboActivity : AppCompatActivity(), ComboDataFragment.ItemClickListener {

    private var isConnected = false
    private var receiver: Receiver? = null
    var mIsSubScribe: Boolean = false
    private lateinit var selectedBG: String
    private lateinit var selectedFrame: String
    private lateinit var icBack:ImageView

    private lateinit var btnNone: ImageView
    private lateinit var mySharedPref: MySharedPref
    private var lastClickTime = 0L
    private var selectedURL = ""

    private var total = 0
    private var categoryList = arrayListOf<SubCategory>()


    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (isOnline()) {
                constraintOffline.hide()
//                if (isComboDataLoaded){
//                    constainMain.visibility = View.VISIBLE
//                    setData()
//                }else{
//                    callNewComboApi()
//                }
                Log.d(TAG, "Combo onReceive: categoryList.size ${categoryList.size}")
                if (categoryList.size == 0){
                    callNewComboApi()
                }else{
                    setNewData()
                }
            } else {
                constainMain.hide()
                constraintOffline.show()
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_combo)
        hideSystemUI()
        initView()
        mySharedPref = MySharedPref(this@ComboActivity)
        try {
            receiver = Receiver()
            registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
        } catch (e: Exception) { }
        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        if (!mIsSubScribe) {
            NativeAdvancedModelHelper(this@ComboActivity).loadNativeAdvancedAd(NativeAdsSize.Medium,findViewById(R.id.my_template))
        }else{
            findViewById<FrameLayout>(R.id.my_template).hide()
        }

        initViewListener()

        bindCallbacks()
        bindAction()
    }

    private fun initViewListener() {
        icBack.setOnClickListener {
            onBackPressed()
        }
        btnNone.setOnClickListener {
            onComboItemClick(0,"","")
        }
    }

    private fun initView() {
        icBack = findViewById(R.id.icBack)
        btnNone = findViewById(R.id.btnNone)
    }

    private fun setData() {
        constraintProgressLayout.hide()
        constraintOffline.hide()
        constainMain.show()

//        val comboAdepter = ComboPagerAdepter(
//            supportFragmentManager,
//            comboArray,
//            mIsSubScribe,
//            this@ComboActivity
//        )
//        viewPagerCard!!.adapter = comboAdepter
//        meterialTabLayout!!.setupWithViewPager(viewPagerCard)
//        comboArray.filterIndexed { index, categoryParametersItem ->
//            if (categoryParametersItem.name != "") {
//                val view1 = LayoutInflater.from(this@ComboActivity).inflate(R.layout.rv_tab, null)
//                meterialTabLayout!!.getTabAt(index)!!.customView = view1
//                val textView = view1.findViewById<TextView>(R.id.textTab)
//                textView.text = categoryParametersItem.name
//                if (index == 0) {
//                    Constants.selectedCombo = textView.text.toString()
//                    textView.setTextColor(Color.WHITE)
//                } else {
//                    textView.setTextColor(Color.BLACK)
//                }
//            }
//            true
//        }
//        meterialTabLayout!!.setOnTabSelectedListener(object :
//            TabLayout.OnTabSelectedListener {
//            override fun onTabSelected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.WHITE)
//                    Constants.selectedCombo = "${meterialTabLayout!!.getTabAt(tab.position)!!.customView!!.findViewById<TextView>(R.id.textTab).text}"
//                } catch (e: Exception) { }
//            }
//
//            override fun onTabUnselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.BLACK)
//                } catch (e: Exception) { }
//            }
//
//            override fun onTabReselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.WHITE)
//                } catch (e: Exception) { }
//
//            }
//        })
//        isComboDataLoaded = true
//        viewPagerCard!!.currentItem = mPosition
    }

    private fun setNewData() {
        constraintProgressLayout.hide()
        constraintOffline.hide()
        constainMain.show()

        val comboAdapter = ComboAdapter(this, categoryList, total)
        viewPagerCard?.offscreenPageLimit = ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT
        viewPagerCard?.adapter = comboAdapter

        meterialTabLayout?.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                with(tab?.position!!){
                    viewPagerCard?.currentItem = this
                    tab.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.WHITE)
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                tab?.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.BLACK)
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }

        })

        viewPagerCard?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

            override fun onPageSelected(position: Int) {
                meterialTabLayout?.selectTab(meterialTabLayout?.getTabAt(position))
            }

            override fun onPageScrollStateChanged(state: Int) {}

        })
    }

    private fun callComboApi() {
        constraintProgressLayout.visibility = View.VISIBLE

        val apiInterface = APIClient.getClient().create(APIInterface::class.java)
        val call = apiInterface.parameterList
        call.enqueue(object : Callback<Response> {
            override fun onResponse(
                call: Call<Response>,
                response: retrofit2.Response<Response>
            ) {
                if (response.isSuccessful && response.body()!!.parameters != null){
                    response.body()!!.parameters.filterIndexed { index, parametersItem ->
                        if (parametersItem.name == "Combo" || parametersItem.id == 785) {
                            comboArray.clear()
                            parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                comboArray.add(categoryParametersItem)
                                true
                            }
                        }
                        isComboDataLoaded = true
                        setData()
                        true
                    }
                }else{
                    showToast("Please try again latter")
                    finish()
                }
            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                showToast(resources.getString(R.string.try_again_later))
                finish()
            }
        })
    }

    private fun callNewComboApi() {
        constraintProgressLayout.show()
        lifecycleScope.launch{
            withContext(Dispatchers.IO){
                if (HomeActivity.allCategory.isEmpty()){
                    HomeActivity.callHomeApi(this@ComboActivity)
                }
                for (category in HomeActivity.allCategory){
                    if (category.name.equals(TAG, ignoreCase = true)){
                        category.subCategory?.let {
                            withContext(Dispatchers.Main){
                                categoryId = category.id!!
                                Log.d(TAG, "loadNextPage: API Combo categoryId $categoryId")
                                total = it.size
                                for ((i, subCategory) in it.withIndex()){
                                    categoryList.add(subCategory)
                                    withContext(Dispatchers.Main){
                                        meterialTabLayout!!.addTab(meterialTabLayout!!.newTab().setText(subCategory.name))
                                        val view1 = LayoutInflater.from(this@ComboActivity).inflate(R.layout.rv_tab, null)
                                        meterialTabLayout!!.getTabAt(i)!!.customView = view1
                                        val textView = view1.findViewById<TextView>(R.id.textTab)
                                        textView.text = subCategory.name
                                        if (i == 0) {
                                            Constants.selectedBg = textView.text.toString()
                                            textView.setTextColor(Color.WHITE)
                                        } else {
                                            textView.setTextColor(Color.BLACK)
                                        }
                                    }
                                }
                            }
                        }
                        withContext(Dispatchers.Main){
                            setNewData()
                        }
                        break
                    }
                }
            }
        }
    }


    companion object {
        private const val TAG = "Combo"
        var isAdsIsFree = false
        var isComboDataLoaded = false
        var mPosition = 0
        var categoryId by Delegates.notNull<Int>()
        var comboArray: ArrayList<ParametersItemAllChilds> = ArrayList()
    }

    override fun onResume() {
        super.onResume()
        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        if (!mIsSubScribe){
//            if (mIsSubScribe != MySharedPreferences(this).isSubscribe){
//                mIsSubScribe = MySharedPreferences(this).isSubscribe
//                callComboApi()
//            }
        }else{
            findViewById<FrameLayout>(R.id.my_template).hide()
        }
    }

    override fun onComboItemClick(id: Int, bg: String, frame: String) {
        if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
        lastClickTime = SystemClock.elapsedRealtime()

        Constants.comboId = id
        selectedBG = bg
        selectedFrame = frame

        if (mySharedPref.getApiAdsCount() == 2 && !mIsSubScribe && isAdsIsFree) {
            mySharedPref.setApiAdsCount(0)
            isShowInterstitialAd(){
                Handler(Looper.getMainLooper()).postDelayed({
//            Constants.comboId = id
                    Log.d(TAG, "onComboItemClick: ${Constants.selectedCombo}_${Constants.comboId}")
                    var intent = Intent()
                    intent.putExtra("bgImagePath", selectedBG)
                    intent.putExtra("frameImagePath", selectedFrame)
                    setResult(Activity.RESULT_OK,intent)
                    finish()
                }, 50)
            }
        }else{
            if (mySharedPref.getApiAdsCount() > 2) {
                mySharedPref.setApiAdsCount(0)
            }
            mySharedPref.setApiAdsCount(mySharedPref.getApiAdsCount() + 1)
            Log.d(TAG, "onComboItemClick : bgPath $bg")
            Log.d(TAG, "onComboItemClick : framePath $frame")
            Handler(Looper.getMainLooper()).postDelayed({
                Log.d(TAG, "onComboItemClick: ${Constants.selectedCombo}_$id")
//                showToast("${Constants.selectedCombo}_$id")
                var intent = Intent()
                intent.putExtra("bgImagePath", bg)
                intent.putExtra("frameImagePath", frame)
                setResult(Activity.RESULT_OK,intent)
                finish()
            }, 50)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        categoryList.clear()
    }

    fun bindCallbacks() {

    }

    fun bindAction() {
        val connectionLiveData = ConnectionLiveData(this)
        connectionLiveData.observe(this) { isConnected ->
            isConnected?.let {
                this.isConnected = it
                if (it) {
                    if (!isOnline()) {
                        showToast("Please connect internet")
                        finish()
                    }
                } else {
                    showToast("Please connect internet")
                    finish()
                }
            }
        }
    }

}