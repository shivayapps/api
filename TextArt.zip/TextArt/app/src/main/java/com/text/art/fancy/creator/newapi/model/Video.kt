package com.text.art.fancy.creator.newapi.model

import com.google.gson.annotations.SerializedName

data class Video(
    @SerializedName("id")
    var id: Int? = null,

    @SerializedName("category_new_id")
    var categoryNewId: Int? = null,

    @SerializedName("thumb_image")
    var thumbImage: String? = null,

    @SerializedName("size")
    var size: String? = null
)