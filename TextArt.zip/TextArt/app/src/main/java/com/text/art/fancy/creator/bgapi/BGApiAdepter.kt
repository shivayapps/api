package com.text.art.fancy.creator.BackgroundApi

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.newapi.category.CategoryItem
import org.jetbrains.anko.padding

class BGApiAdepter(
    var mContext: Context,
    var imageItems: ArrayList<CategoryItem>?,
    var onItemClickBG: OnItemClickBG,
) : RecyclerView.Adapter<BGApiAdepter.MyViewHolder>() {

    interface OnItemClickBG {
        fun onItemClickBG(position: Int, string: String)
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgBackground: ImageView = itemView.findViewById(R.id.imgBackground)
        //val imgPreview: ImageView = itemView.findViewById(R.id.imgPreview)
        val imgLock: ImageView = itemView.findViewById(R.id.imgLock)
        val imgLockPremium: ImageView = itemView.findViewById(R.id.imgLockPremium)
        val mProgressBar: ProgressBar = itemView.findViewById(R.id.mProgressBar)
        val isLoaded: TextView = itemView.findViewById(R.id.isLoadedData)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext)
            .inflate(R.layout.rv_api_item, parent, false))
    }


    override fun getItemCount(): Int {
        return imageItems?.size ?: 0
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MyViewHolder, @SuppressLint("RecyclerView") i: Int) {
        with(holder) {

            imgBackground.setOnLongClickListener { true }
            imgBackground.padding = 0
            imgBackground.visibility = View.VISIBLE
            imgLockPremium.visibility = View.GONE
            imgLock.visibility = View.GONE

            Glide.with(mContext)
                .load(imageItems!![i].image).override(400)
                .listener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: com.bumptech.glide.request.target.Target<Drawable>?,
                        isFirstResource: Boolean,
                    ): Boolean {
                        isLoaded.text = "No"
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: com.bumptech.glide.request.target.Target<Drawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean,
                    ): Boolean {
                        isLoaded.text = "Yes"
                        if (imageItems!![i].isPremium == 1) {
                            imgLockPremium.visibility = View.VISIBLE
                        } else if (imageItems!![i].coin == 10) {
                            imgLock.visibility = View.VISIBLE
                        }
                        return false
                    }
                }).into(imgBackground)
            imgBackground.setOnClickListener {
                if (isLoaded.text == "Yes") {
                    onItemClickBG.onItemClickBG(i, imageItems!![i].image!!)
                } else {
                    Toast.makeText(mContext, "Please wait", Toast.LENGTH_SHORT).show()
                }
            }
        }

    }

}