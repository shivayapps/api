package com.text.art.fancy.creator.activitys

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PorterDuff
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.TextArtApplication
import com.text.art.fancy.creator.ads.InterstitialAdHelper
import com.text.art.fancy.creator.ads.InterstitialAdHelper.onInterstitialAdListener
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAdListener
import com.google.android.gms.ads.InterstitialAd
import com.vasu.image.video.pickrandom.galleryapp.model.Config
import com.vasu.image.video.pickrandom.galleryapp.model.Image
//import com.vasu.image.video.pickrandom.galleryapp.
//import com.image.gallery.imagepicker.model.Config
//import com.image.gallery.imagepicker.model.Image
//import com.image.gallery.imagepicker.ui.imagepicker.ImagePicker
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator
import com.nostra13.universalimageloader.core.ImageLoader
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration
import com.nostra13.universalimageloader.core.assist.QueueProcessingType
import com.yalantis.ucrop.view.CropImageView
import kotlinx.android.synthetic.main.activity_crop.*
import java.io.File
import java.io.IOException
import java.util.*

class CropActivity : AppCompatActivity()/*, OnSetImageUriCompleteListener, OnCropImageCompleteListener*/, onInterstitialAdListener {
    /**
     * The crop image view library widget used in the activity
     */
    //var mCropImageView: CropImageView? = null
    /**
     * Persist URI image to crop URI if specific permissions are required
     */
    private  var mCropImageUri: Uri? = null
    /**
     * the options that were set for the crop image
     */
    //private var mOptions: CropImageOptions? = null
    private var mBtnBack: ImageButton? = null
    private var mBtnCrop: ImageButton? = null
    private var mContext: Context? = null
    private var images = ArrayList<Image>()
    override fun onLoad() {
        isInterstitialAdLoaded = true
    }

    override fun onFailed() {
        isInterstitialAdLoaded = false
        //interstitial = InterstitialAdHelper.instance?.load(mContext!!, this)
    }

    override fun onClosed() {
        isInterstitialAdLoaded = false
        interstitial = InterstitialAdHelper.instance?.load(mContext!!, this)
       /* if (CropImage.isReadExternalStoragePermissionsRequired(this, mCropImageUri!!)) { // request permissions and handle the result in onRequestPermissionsResult()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                        CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE)
            }
        } else { // no permissions required or already grunted, can start crop image activity
            mCropImageView!!.setImageUriAsync(mCropImageUri)
        }*/
    }

    private var isInterstitialAdLoaded = false
    private var interstitial: InterstitialAd? = null
    @SuppressLint("NewApi")
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop)
        mContext = this@CropActivity
        //TODO fb Interstial
        loadInterstialAdFb()
        //TODO Google interstial
//        interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
/*new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    String path = new ScalingUtilities().convertBitmapToFile(mContext, BitmapFactory.decodeResource(getResources(), R.drawable.ic_bg));
                    BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), new ScalingUtilities().compressImage(mContext, path));
                    runOnUiThread(() -> {
                        findViewById(R.id.mainLayout).setBackground(bitmapDrawable);
                    });

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        }.execute();*/
/*ImageLoader imageLoader = ImageLoader.getInstance();
        initImageLoader(mContext);

        imageLoader.displayImage("drawable://"+R.drawable.ic_bg, ((ImageView)findViewById(R.id.imgBg)));*/
  /*      mCropImageView = findViewById(R.id.mCropImageView)
        mBtnBack = findViewById(R.id.imgBtnBack)
        mBtnCrop = findViewById(R.id.imgBtnSave)
        val bundle = intent.getBundleExtra(CropImage.CROP_IMAGE_EXTRA_BUNDLE)
        mCropImageUri = bundle.getParcelable(CropImage.CROP_IMAGE_EXTRA_SOURCE)
        mOptions = bundle.getParcelable(CropImage.CROP_IMAGE_EXTRA_OPTIONS)
        if (mCropImageView != null) {
        }
        if (savedInstanceState == null) {
            if (mCropImageUri == null || mCropImageUri == Uri.EMPTY) {
                if (CropImage.isExplicitCameraPermissionRequired(this)) { // request permissions and handle the result in onRequestPermissionsResult()
                    requestPermissions(arrayOf(Manifest.permission.CAMERA),
                            CropImage.CAMERA_CAPTURE_PERMISSIONS_REQUEST_CODE)
                } else { //CropImage.startPickImageActivity(this);
                    start()
                }
            } else if (CropImage.isReadExternalStoragePermissionsRequired(this, mCropImageUri!!)) { // request permissions and handle the result in onRequestPermissionsResult()
                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                        CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE)
            } else { // no permissions required or already grunted, can start crop image activity
                mCropImageView!!.setImageUriAsync(mCropImageUri)
            }
        }
        val actionBar = supportActionBar
        if (actionBar != null) {
            val title = if (mOptions != null && mOptions!!.activityTitle != null && mOptions!!.activityTitle.length > 0) mOptions!!.activityTitle else resources.getString(com.example.cropview.R.string.crop_image_activity_title)
            actionBar.title = title
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        mBtnBack!!.setOnClickListener { v: View? -> finish() }
        mBtnCrop!!.setOnClickListener{ v: View? -> cropImage() }*/
    }

//    private fun start() {
//        ImagePicker.with(this)
//                .setFolderMode(true)
//                .setFolderTitle("Gallery")
//                .setMultipleMode(false)
//                .setImageCount(1)
//                .setSelectedImages(images)
//                .setMaxSize(10)
//                .setBackgroundColor("#ffffff")
//                .setAlwaysShowDoneButton(true)
//                .setRequestCode(100)
//                .setKeepScreenOn(true)
//                .start()
//    }

    fun initImageLoader(context: Context?) { // This configuration tuning is custom. You can tune every option, you may tune some of them,
// or you can create default configuration by the
//  ImageLoaderConfiguration.createDefault(this);
// method.
//
        val config = ImageLoaderConfiguration.Builder(context)
        config.threadPriority(Thread.NORM_PRIORITY - 2)
        config.denyCacheImageMultipleSizesInMemory()
        config.diskCacheFileNameGenerator(Md5FileNameGenerator())
        config.diskCacheSize(50 * 1024 * 1024) // 50 MiB
        config.tasksProcessingOrder(QueueProcessingType.LIFO)
        config.writeDebugLogs() // Remove for release app
        // Initialize ImageLoader with configuration.
        ImageLoader.getInstance().init(config.build())
    }

    override fun onStart() {
        super.onStart()
        /*mCropImageView!!.setOnSetImageUriCompleteListener(this)
        mCropImageView!!.setOnCropImageCompleteListener(this)*/
    }

    override fun onStop() {
        super.onStop()
        /*mCropImageView!!.setOnSetImageUriCompleteListener(null)
        mCropImageView!!.setOnCropImageCompleteListener(null)*/
    }

    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(com.example.cropview.R.menu.crop_image_menu, menu);

        if (!mOptions.allowRotation) {
            menu.removeItem(com.example.cropview.R.id.crop_image_menu_rotate_left);
            menu.removeItem(com.example.cropview.R.id.crop_image_menu_rotate_right);
        } else if (mOptions.allowCounterRotation) {
            menu.findItem(com.example.cropview.R.id.crop_image_menu_rotate_left).setVisible(true);
        }

        if (!mOptions.allowFlipping) {
            menu.removeItem(com.example.cropview.R.id.crop_image_menu_flip);
        }

        if (mOptions.cropMenuCropButtonTitle != null) {
            menu.findItem(com.example.cropview.R.id.crop_image_menu_crop).setTitle(mOptions.cropMenuCropButtonTitle);
        }

        Drawable cropIcon = null;
        try {
            if (mOptions.cropMenuCropButtonIcon != 0) {
                cropIcon = ContextCompat.getDrawable(this, mOptions.cropMenuCropButtonIcon);
                menu.findItem(com.example.cropview.R.id.crop_image_menu_crop).setIcon(cropIcon);
            }
        } catch (Exception e) {
            Log.w("AIC", "Failed to read menu crop drawable", e);
        }

        if (mOptions.activityMenuIconColor != 0) {
            updateMenuItemIconColor(
                    menu, com.example.cropview.R.id.crop_image_menu_rotate_left, mOptions.activityMenuIconColor);
            updateMenuItemIconColor(
                    menu, com.example.cropview.R.id.crop_image_menu_rotate_right, mOptions.activityMenuIconColor);
            updateMenuItemIconColor(menu, com.example.cropview.R.id.crop_image_menu_flip, mOptions.activityMenuIconColor);
            if (cropIcon != null) {
                updateMenuItemIconColor(menu, com.example.cropview.R.id.crop_image_menu_crop, mOptions.activityMenuIconColor);
            }
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == com.example.cropview.R.id.crop_image_menu_crop) {
            cropImage();
            return true;
        }
        if (item.getItemId() == com.example.cropview.R.id.crop_image_menu_rotate_left) {
            rotateImage(-mOptions.rotationDegrees);
            return true;
        }
        if (item.getItemId() == com.example.cropview.R.id.crop_image_menu_rotate_right) {
            rotateImage(mOptions.rotationDegrees);
            return true;
        }
        if (item.getItemId() == com.example.cropview.R.id.crop_image_menu_flip_horizontally) {
            mCropImageView.flipImageHorizontally();
            return true;
        }
        if (item.getItemId() == com.example.cropview.R.id.crop_image_menu_flip_vertically) {
            mCropImageView.flipImageVertically();
            return true;
        }
        if (item.getItemId() == android.R.id.home) {
            setResultCancel();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }*/
    override fun onBackPressed() {
        super.onBackPressed()
        //setResultCancel()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { //        if (requestCode == Config.RC_PICK_IMAGES && resultCode == RESULT_OK && data != null) {
//            images = data.getParcelableArrayListExtra(Config.EXTRA_IMAGES);
//            Glide.with(CropActivity.this).load(images.get(0).getPath()).into((ImageView) findViewById(R.id.mCropImageView));
//
//        }
        Log.d(TAG, "onActivityResult: $resultCode")
        if (requestCode == Config.RC_PICK_IMAGES) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                images = data.getParcelableArrayListExtra(Config.EXTRA_IMAGES)!!
                try {
                    val bitmap = BitmapFactory.decodeFile(images[0].path)
                    Log.d("TAG", "onActivityResult: $bitmap")
                    if (bitmap == null) {
                        Toast.makeText(mContext, "Invalid Image Please choose other image", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                mCropImageUri = getImageContentUri(this, File(images[0].path)) //CropImage.getPickImageResultUri(this, data);
                // For API >= 23 we need to check specifically that we have permissions to read external
// storage.
                if (!TextArtApplication.instance!!.requestNewInterstitialfb()) {
                    if (isInterstitialAdLoaded) {
                        interstitial!!.show()
                    } else {
                        /*if (CropImage.isReadExternalStoragePermissionsRequired(this, mCropImageUri!!)) { // request permissions and handle the result in onRequestPermissionsResult()
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                                        CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE)
                            }
                        } else { // no permissions required or already grunted, can start crop image activity
                            mCropImageView!!.setImageUriAsync(mCropImageUri)
                        }*/
                    }
                }else{
                    if(TextArtApplication.instance!!.mInterstitialAdfb != null) {
                        /*TextArtApplication.instance!!.mInterstitialAdfb!!.setAdListener(object : InterstitialAdListener {
                            override fun onError(ad: Ad, adError: AdError) {
                                interstitial = InterstitialAdHelper.instance?.load(this@CropActivity, this@CropActivity)
                            }

                            override fun onAdLoaded(ad: Ad) {}
                            override fun onInterstitialDisplayed(p0: Ad?) {
                            }

                            override fun onAdClicked(ad: Ad) {}
                            override fun onLoggingImpression(ad: Ad) {}
                            override fun onInterstitialDismissed(ad: Ad) {
                                Log.d(TAG, "onInterstitialDismissed")
                                *//*if (CropImage.isReadExternalStoragePermissionsRequired(this@CropActivity, mCropImageUri!!)) { // request permissions and handle the result in onRequestPermissionsResult()
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                                                CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE)
                                    }
                                } else { // no permissions required or already grunted, can start crop image activity
                                    mCropImageView!!.setImageUriAsync(mCropImageUri)
                                }*//*
                            }
                        })*/

                        val interstitialAdListener = object : InterstitialAdListener {
                            override fun onInterstitialDisplayed(ad: Ad?) {}
                            override fun onInterstitialDismissed(ad: Ad?) {
                                Log.d(TAG, "onInterstitialDismissed")
                                /*if (CropImage.isReadExternalStoragePermissionsRequired(this@CropActivity, mCropImageUri!!)) { // request permissions and handle the result in onRequestPermissionsResult()
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                                                CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE)
                                    }
                                } else { // no permissions required or already grunted, can start crop image activity
                                    mCropImageView!!.setImageUriAsync(mCropImageUri)
                                }*/
                            }
                            override fun onError(ad: Ad?, adError: AdError) {
                                interstitial = InterstitialAdHelper.instance?.load(this@CropActivity, this@CropActivity)
                            }
                            override fun onAdLoaded(ad: Ad?) {}
                            override fun onAdClicked(ad: Ad?) {}
                            override fun onLoggingImpression(ad: Ad?) {}
                        }

                        TextArtApplication.instance!!.mInterstitialAdfb!!.loadAd(TextArtApplication.instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build())
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.d(TAG, "onActivityResult: ")
                //setResultCancel()
            }
            //            Intent intent = new Intent(EditActivity.this,CropActivity.class);
//            startActivity(intent);
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
        // handle result of pick image chooser
        /*if (requestCode == CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE) {
        }*/
    }

    override fun onRequestPermissionsResult(
            requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
       /* if (requestCode == CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE) {
            if (mCropImageUri != null && grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) { // required permissions granted, start crop image activity
                mCropImageView!!.setImageUriAsync(mCropImageUri)
            } else {
                Toast.makeText(this, com.example.cropview.R.string.crop_image_activity_no_permissions, Toast.LENGTH_LONG).show()
                setResultCancel()
            }
        }
        if (requestCode == CropImage.CAMERA_CAPTURE_PERMISSIONS_REQUEST_CODE) { // Irrespective of whether camera permission was given or not, we show the picker
// The picker will not add the camera intent if permission is not available
            CropImage.startPickImageActivity(this)
        }*/
    }

    /*override fun onSetImageUriComplete(view: CropImageView, uri: Uri, error: Exception?) {
        if (error == null) {
            if (mOptions!!.initialCropWindowRectangle != null) {
                mCropImageView!!.cropRect = mOptions!!.initialCropWindowRectangle
            }
            if (mOptions!!.initialRotation > -1) {
                mCropImageView!!.rotatedDegrees = mOptions!!.initialRotation
            }
        } else {
            setResult(null, error, 1)
        }
    }

    override fun onCropImageComplete(view: CropImageView, result: CropResult) {
        setResult(result.uri, result.error, result.sampleSize)
    }
    // region: Private methods
    *//**
     * Execute crop image and save the result tou output uri.
     *//*
    protected fun cropImage() {
        if (mOptions!!.noOutputImage) {
            setResult(null, null, 1)
        } else {
            val outputUri = outputUri
            mCropImageView!!.saveCroppedImageAsync(
                    outputUri,
                    mOptions!!.outputCompressFormat,
                    mOptions!!.outputCompressQuality,
                    mOptions!!.outputRequestWidth,
                    mOptions!!.outputRequestHeight,
                    mOptions!!.outputRequestSizeOptions)
        }
    }

    *//**
     * Rotate the image in the crop image view.
     *//*
    protected fun rotateImage(degrees: Int) {
        mCropImageView!!.rotateImage(degrees)
    }

    *//**
     * Get Android uri to save the cropped image into.<br></br>
     * Use the given in options or create a temp file.
     *//*
    protected val outputUri: Uri?
        protected get() {
            var outputUri = mOptions!!.outputUri
            if (outputUri == null || outputUri == Uri.EMPTY) {
                outputUri = try {
                    val ext = if (mOptions!!.outputCompressFormat == Bitmap.CompressFormat.JPEG) ".jpg" else if (mOptions!!.outputCompressFormat == Bitmap.CompressFormat.PNG) ".png" else ".webp"
                    Uri.fromFile(File.createTempFile("cropped", ext, cacheDir))
                } catch (e: IOException) {
                    throw RuntimeException("Failed to create temp file for output image", e)
                }
            }
            return outputUri
        }

    *//**
     * Result with cropped image data or error if failed.
     *//*
    protected fun setResult(uri: Uri?, error: Exception?, sampleSize: Int) {
        val resultCode = if (error == null) Activity.RESULT_OK else CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE
        setResult(resultCode, getResultIntent(uri, error, sampleSize))
        finish()
    }

    *//**
     * Cancel of cropping activity.
     *//*
    protected fun setResultCancel() {
        Log.d(TAG, "setResultCancel: ")
        setResult(Activity.RESULT_CANCELED)
        finish()
    }

    *//**
     * Get intent instance to be used for the result of this activity.
     *//*
    protected fun getResultIntent(uri: Uri?, error: Exception?, sampleSize: Int): Intent {
        val result = CropImage.ActivityResult(
                mCropImageView!!.imageUri,
                uri,
                error,
                mCropImageView!!.cropPoints,
                mCropImageView!!.cropRect,
                mCropImageView!!.rotatedDegrees,
                mCropImageView!!.wholeImageRect,
                sampleSize)
        val intent = Intent()
        intent.putExtras(getIntent())
        intent.putExtra(CropImage.CROP_IMAGE_EXTRA_RESULT, result)
        return intent
    }*/

    /**
     * Update the color of a specific menu item to the given color.
     */
    private fun updateMenuItemIconColor(menu: Menu, itemId: Int, color: Int) {
        val menuItem = menu.findItem(itemId)
        if (menuItem != null) {
            val menuItemIcon = menuItem.icon
            if (menuItemIcon != null) {
                try {
                    menuItemIcon.mutate()
                    menuItemIcon.setColorFilter(color, PorterDuff.Mode.SRC_ATOP)
                    menuItem.icon = menuItemIcon
                } catch (e: Exception) {
                    Log.w("AIC", "Failed to update menu item color", e)
                }
            }
        }
    }

    //TODO fbAds
    private fun loadInterstialAdFb() {
        if (TextArtApplication.instance!!.mInterstitialAdfb!!.isAdLoaded) {
        } else {
            //TextArtApplication.instance!!.mInterstitialAdfb!!.setAdListener(null)
            TextArtApplication.instance!!.mInterstitialAdfb = null
            TextArtApplication.instance!!.LoadAdsFb()
            /*TextArtApplication.instance!!.mInterstitialAdfb!!.setAdListener(object : InterstitialAdListener {
                override fun onError(ad: Ad, adError: AdError) {
                    interstitial = InterstitialAdHelper.instance?.load(this@CropActivity, this@CropActivity)
                }

                override fun onAdLoaded(ad: Ad) {}
                override fun onInterstitialDisplayed(p0: Ad?) {
                }

                override fun onAdClicked(ad: Ad) {}
                override fun onLoggingImpression(ad: Ad) {}
                override fun onInterstitialDismissed(ad: Ad) {
                    Log.d(TAG,"onInterstitialDismissed")
                   *//* if (CropImage.isReadExternalStoragePermissionsRequired(this@CropActivity, mCropImageUri!!)) { // request permissions and handle the result in onRequestPermissionsResult()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                                    CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE)
                        }
                    } else { // no permissions required or already grunted, can start crop image activity
                        mCropImageView!!.setImageUriAsync(mCropImageUri)
                    }*//*
                }
            })*/

            val interstitialAdListener = object : InterstitialAdListener {
                override fun onInterstitialDisplayed(ad: Ad?) {}
                override fun onInterstitialDismissed(ad: Ad?) {
                    Log.d(TAG,"onInterstitialDismissed")
                    /* if (CropImage.isReadExternalStoragePermissionsRequired(this@CropActivity, mCropImageUri!!)) { // request permissions and handle the result in onRequestPermissionsResult()
                         if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                             requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                                     CropImage.PICK_IMAGE_PERMISSIONS_REQUEST_CODE)
                         }
                     } else { // no permissions required or already grunted, can start crop image activity
                         mCropImageView!!.setImageUriAsync(mCropImageUri)
                     }*/
                }
                override fun onError(ad: Ad?, adError: AdError) {
                    interstitial = InterstitialAdHelper.instance?.load(this@CropActivity, this@CropActivity)
                }
                override fun onAdLoaded(ad: Ad?) {}
                override fun onAdClicked(ad: Ad?) {}
                override fun onLoggingImpression(ad: Ad?) {}
            }

            TextArtApplication.instance!!.mInterstitialAdfb!!.loadAd(TextArtApplication.instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build())
        }
    }

    companion object {
        private const val TAG = "CropActivity"
        @SuppressLint("Range")
        fun getImageContentUri(context: Context, imageFile: File): Uri? {
            val filePath = imageFile.absolutePath
            val cursor = context.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                    MediaStore.Images.Media.DATA + "=? ", arrayOf(filePath), null)
            return if (cursor != null && cursor.moveToFirst()) {
                val id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID))
                cursor.close()
                Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + id)
            } else {
                if (imageFile.exists()) {
                    val values = ContentValues()
                    values.put(MediaStore.Images.Media.DATA, filePath)
                    context.contentResolver.insert(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                } else {
                    null
                }
            }
        }
    }
}