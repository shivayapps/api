package com.text.art.fancy.creator.categorys.parameter;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Response{

	@SerializedName("ResponseCode")
	private String responseCode;

	@SerializedName("ResponseMessage")
	private String responseMessage;

	@SerializedName("data")
	private List<ParametersItem> parameters;

	public void setResponseCode(String responseCode){
		this.responseCode = responseCode;
	}

	public String getResponseCode(){
		return responseCode;
	}

	public void setResponseMessage(String responseMessage){
		this.responseMessage = responseMessage;
	}

	public String getResponseMessage(){
		return responseMessage;
	}

	public void setParameters(List<ParametersItem> parameters){
		this.parameters = parameters;
	}

	public List<ParametersItem> getParameters(){
		return parameters;
	}

	@Override
 	public String toString(){
		return 
			"Response{" + 
			"responseCode = '" + responseCode + '\'' + 
			",responseMessage = '" + responseMessage + '\'' +
			",parameters = '" + parameters + '\'' + 
			"}";
		}
}