package com.text.art.fancy.creator.lottieaudiorendering.data;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.text.art.fancy.creator.lottieaudiorendering.data.SharedMediaStoragePublisher;
import com.text.art.fancy.creator.lottieaudiorendering.utils.TrackMetadataUtil;
import com.text.art.fancy.creator.activitys.ShareVideoActivity;
import com.text.art.fancy.creator.lottievideorendering.VideoCreator;
import com.linkedin.android.litr.TransformationListener;
import com.linkedin.android.litr.analytics.TrackTransformationInfo;

import java.io.File;
import java.util.List;
import java.util.Objects;

public class MediaTransformationListener implements TransformationListener {

    private final Context context;
    private final String requestId;
    private final TransformationState transformationState;
    private final SharedMediaStoragePublisher publisher;
    private final TargetMedia targetMedia;

    public MediaTransformationListener(@NonNull Context context,
                                       @NonNull String requestId,
                                       @NonNull TransformationState transformationState,
                                       @NonNull TargetMedia targetMedia) {
        this(context, requestId, transformationState, targetMedia, new SharedMediaStoragePublisher(context));
    }

    @VisibleForTesting
    MediaTransformationListener(@NonNull Context context,
                                @NonNull String requestId,
                                @NonNull TransformationState transformationState,
                                @NonNull TargetMedia targetMedia,
                                @NonNull SharedMediaStoragePublisher publisher) {
        this.context = context;
        this.requestId = requestId;
        this.transformationState = transformationState;
        this.targetMedia = targetMedia;
        this.publisher = publisher;
    }

    @Override
    public void onStarted(@NonNull String id) {
        if (TextUtils.equals(requestId, id)) {
            transformationState.setState(TransformationState.STATE_RUNNING);
        }
    }

    @Override
    public void onProgress(@NonNull String id, float progress) {
        if (TextUtils.equals(requestId, id)) {
            transformationState.setProgress((int) (progress * TransformationState.MAX_PROGRESS));
        }
    }

    @Override
    public void onCompleted(@NonNull String id, @Nullable List<TrackTransformationInfo> trackTransformationInfos) {
        if (TextUtils.equals(requestId, id)) {
            transformationState.setState(TransformationState.STATE_COMPLETED);
            transformationState.setProgress(TransformationState.MAX_PROGRESS);
            Objects.requireNonNull(VideoCreator.Companion.getProgressDialog()).dismiss();
            transformationState.setStats(TrackMetadataUtil.printTransformationStats(context, trackTransformationInfos));
            Log.d("TAG", "publish Video To Internal Storage: filePath Is -> "+targetMedia.targetFile);

            Log.d("TAG", "video Update :-> Before Publish targetFile -> "+targetMedia.targetFile);
            Log.d("TAG", "video Update :-> Before Publish isAndroidQ -> "+!SharedMediaStoragePublisher.Companion.isAndroidQ());
            publisher.publish(targetMedia.targetFile,
                !SharedMediaStoragePublisher.Companion.isAndroidQ(),
                (file, contentUri) -> {
                    targetMedia.setContentUri(contentUri);
                    Log.d("TAG", "video Update :-> file is exist -> "+file.exists());
                    Log.d("TAG", "video Update :-> contentUri is -> "+contentUri);
                    Intent intent = new Intent(context, ShareVideoActivity.class);
                    intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION & Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    intent.setDataAndType(contentUri, context.getContentResolver().getType(contentUri));

                    //TODO: Wood (Remove When Issue Solved)
//                    if (SharedMediaStoragePublisher.Companion.isAndroidQ()){
                    if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q){
                        try {
                            //TODO Remove Duplicate COPY
                            File newFile = new File(file.getAbsolutePath().replace(" (1).mp4", ".mp4"));
                            if (newFile.exists()){
                                newFile.delete();
                            }
                        } catch (Exception e) { e.printStackTrace(); }
                        intent.putExtra("videoPath", file.getAbsolutePath().replace(".mp4", " (1).mp4"));
                    }else {
                        intent.putExtra("videoPath", file.getAbsolutePath());
                    }
                    context.startActivity(intent);
                }
            );
        }
    }

    @Override
    public void onCancelled(@NonNull String id, @Nullable List<TrackTransformationInfo> trackTransformationInfos) {
        if (TextUtils.equals(requestId, id)) {
            transformationState.setState(TransformationState.STATE_CANCELLED);
            transformationState.setStats(TrackMetadataUtil.printTransformationStats(context, trackTransformationInfos));
        }
    }

    @Override
    public void onError(@NonNull String id,
                        @Nullable Throwable cause,
                        @Nullable List<TrackTransformationInfo> trackTransformationInfos) {
        if (TextUtils.equals(requestId, id)) {
            transformationState.setState(TransformationState.STATE_ERROR);
            transformationState.setStats(TrackMetadataUtil.printTransformationStats(context, trackTransformationInfos));
        }
    }

}
