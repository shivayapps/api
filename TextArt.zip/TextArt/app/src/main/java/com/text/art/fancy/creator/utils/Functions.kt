package com.text.art.fancy.creator.utils

import android.Manifest
import android.R
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Context.CLIPBOARD_SERVICE
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.media.MediaMetadataRetriever.METADATA_KEY_DURATION
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.telephony.TelephonyManager
import android.text.ClipboardManager
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.ColorInt
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.AndroidViewModel
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.text.art.fancy.creator.TextArtApplication
import com.text.art.fancy.creator.widgets.frameLayout.INVALID_RESOURCE_ID
import com.text.art.fancy.creator.widgets.frameLayout.MAX_ALPHA
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

var context: Context? = TextArtApplication.instance?.baseContext
    get() = field
    set(value) { field = value }
val displayMetrics = DisplayMetrics()

fun Context.showToast(msg:String, duration:Int = Toast.LENGTH_SHORT) = Toast.makeText(this,msg,duration).show()
fun Fragment.showToast(msg:String, duration:Int = Toast.LENGTH_SHORT) = Toast.makeText(requireContext(),msg,duration).show()

fun View.show() = run{ this.visibility = View.VISIBLE }
fun View.invisible() = run{ this.visibility = View.INVISIBLE }
fun View.hide() = run{ this.visibility = View.GONE }
fun View.isVisible(): Boolean = run {
    return this.visibility == View.VISIBLE
}

fun View.setOpacity(opacity: Float) = run { this.alpha = opacity }

fun View.enabled() = run { this.isEnabled = true }
fun View.disabled() = run { this.isEnabled = false }

/** @return true if Device is Mobile else false */
fun Context.isMobile(): Boolean = run {
    val manager = this.getSystemService(AppCompatActivity.TELEPHONY_SERVICE) as TelephonyManager
    return manager.phoneType != TelephonyManager.PHONE_TYPE_NONE
}

/** Hide Keyboard if Keyboard is visible */
fun Activity.hideKeyboard() = run {
    val view = this.findViewById<View>(R.id.content)
    if (view != null) {
        val imm = this.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }
}

@SuppressLint("ObsoleteSdkInt", "InlinedApi")
fun Activity.hideSystemUI() = run {
    window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        window.statusBarColor = Color.TRANSPARENT
    }
}

@SuppressLint("ObsoleteSdkInt", "InlinedApi")
fun Activity.setStatusBarColor(color: Int) = run {
//    window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
//            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
//    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//        window.statusBarColor = color
//    }
    val window: Window = window
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
    window.statusBarColor = color
}

const val ASSET_PATH = "file:///android_asset"

fun View.click(action:() -> Unit) = run {

    this.setOnClickListener {
        action()
    }
}

fun View?.removeView() {
    this ?: return
    val parentView = parent as? ViewGroup ?: return
    parentView.removeView(this)
}

fun Activity.isOnline(): Boolean = run {
    return NetworkHelper.isOnline(this)
}
fun Fragment.isOnline(): Boolean = run {
    return NetworkHelper.isOnline(requireContext())
}
fun Context.isOnline(): Boolean = run {
    return NetworkHelper.isOnline(this)
}

fun Activity.displayWidth(): Int = run {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        val windowMetrics: WindowMetrics = this.windowManager.currentWindowMetrics
        val insets = windowMetrics.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars())
        windowMetrics.bounds.width() - insets.left - insets.right
    } else {
        this.windowManager.defaultDisplay.getMetrics(displayMetrics)
        displayMetrics.widthPixels
    }
}
fun Activity.displayHeight(): Int = run {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        val windowMetrics: WindowMetrics = this.windowManager.currentWindowMetrics
        val insets = windowMetrics.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars())
        windowMetrics.bounds.height() - insets.top - insets.bottom
    } else {
        this.windowManager.defaultDisplay.getMetrics(displayMetrics)
        displayMetrics.heightPixels
    }
}

@SuppressLint("ObsoleteSdkInt")
fun Activity.copyToClipboard(textToCopy: CharSequence) = run {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.text = textToCopy
    } else {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = ClipData.newPlainText("TextArt", textToCopy)
        clipboard.setPrimaryClip(clip)
    }
    showToast("Copied!")
}

val Number.toPx get() = TypedValue.applyDimension(
    TypedValue.COMPLEX_UNIT_DIP,
    this.toFloat(),
    Resources.getSystem().displayMetrics)

fun Activity.deleteDirectory(dirPath: String) = run {
    try{
        val file = File(dirPath)
        if (file.exists()) {
            val deleteCmd = "rm -r $dirPath"
            val runtime = Runtime.getRuntime()
            try { runtime.exec(deleteCmd) } catch (e: IOException) { }
        }
    }catch (e: Exception){}
}

fun Activity.checkForPermission(): Boolean = run {
    return ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.READ_EXTERNAL_STORAGE
    ) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
}

fun File.doDelete(dir: File) : Boolean = kotlin.run {
    if (dir.isDirectory) {
        val children = dir.list()
        for (i in children!!.indices) {
            val success = doDelete(File(dir, children[i]))
            if (!success) {
                return false
            }
        }
    }
// The directory is now empty so delete it
    return dir.delete()
}

fun Activity.getStatusbarHeight(): Int {
    var result = 0
    try {
        result = 0
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = resources.getDimensionPixelSize(resourceId)
        }
    } catch (e: Exception) { }
    return result
}

fun getAudioTimeDuration(audio: File): Long{
    return if (audio.exists()){
        val metaRetriever = MediaMetadataRetriever()
        metaRetriever.setDataSource(audio.absolutePath)
        val duration = metaRetriever.extractMetadata(METADATA_KEY_DURATION)
        val dur = duration!!.toLong()
        val seconds = (dur % 60000 / 1000)
        metaRetriever.release()
        seconds
    }else{
        0
    }
}

fun getMediaDuration(audio: File): Long {
    if (!audio.exists()) return 0
    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(context, Uri.parse(audio.absolutePath))
        val duration = retriever.extractMetadata(METADATA_KEY_DURATION)
        retriever.release()
        duration?.toLongOrNull()?.div(1000) ?: 0
    }catch (e: Exception){ 0 }

//    return duration?.toLongOrNull() ?: 0
}

fun getBaseContext(any:Any): Context {
    return when (any) {
        is Activity -> {
            any
        }
        is Fragment -> {
            any.requireContext()
        }
        is AndroidViewModel -> {
            any.getApplication() as Context
        }
        else -> {
            any as Context
        }
    }
}

fun isValidVideoFile(context: Context, path: String): Boolean {
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, Uri.parse(path))
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
        return false
    }
    val hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
    return "yes" == hasVideo
}

fun isValidAudioFile(context: Context, path: String): Boolean {
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, Uri.parse(path))
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
        return false
    }
    val hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
    return "yes" == hasAudio
}

fun getTargetFileDirectory(): File {
//    val targetDirectory = File(
//        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
//            .toString() + File.separator
//                + "TextArt_Videos"
//    )
    val targetDirectory = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            .toString() + File.separator
                + "TextArt"
    )
    if (!targetDirectory.exists()) {
        targetDirectory.mkdirs()
    }
    return targetDirectory
}

//region NULL
internal inline fun <T, R> T?.runIfNotNull(block: T.() -> R): R? = this?.block()

//endregion
//region VIEW

@Suppress("DEPRECATION")
internal fun View.setBackgroundCompat(drawable: Drawable) = when {
    hasMinimumSdk(Build.VERSION_CODES.JELLY_BEAN) -> background = drawable
    else -> setBackgroundDrawable(drawable)
}

//endregion
//region CONTEXT
internal fun Context?.isTablet() = !this?.isMobile()!!
internal fun Context?.isInPortrait() = this?.resources?.configuration?.orientation == Configuration.ORIENTATION_PORTRAIT

internal fun Context.getAttrId(attrId: Int): Int {
    TypedValue().run {
        return when {
            !theme.resolveAttribute(attrId, this, true) -> INVALID_RESOURCE_ID
            else -> resourceId
        }
    }
}

fun hasMinimumSdk(minimumSdk: Int) = Build.VERSION.SDK_INT >= minimumSdk
fun hasMaximumSdk(maximumSdk: Int) = Build.VERSION.SDK_INT <= maximumSdk

@ColorInt
fun calculateColor(@ColorInt to: Int, ratio: Float): Int {
    val alpha = (MAX_ALPHA - (MAX_ALPHA * ratio)).toInt()
    return Color.argb(alpha, Color.red(to), Color.green(to), Color.blue(to))
}
//endregion

@SuppressLint("SimpleDateFormat")
fun getCurrentDate(): String{
    return SimpleDateFormat("dd/MM/yyyy").format(Date()).toString()
}@SuppressLint("SimpleDateFormat")
fun getCurrentTime(): String{
    return SimpleDateFormat("HH:mm:ss").format(Date()).toString()
}
@SuppressLint("SimpleDateFormat")
fun getCurrentDateAndTime(): Date{
//    return SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Date()).toString()
    return Calendar.getInstance().time
}