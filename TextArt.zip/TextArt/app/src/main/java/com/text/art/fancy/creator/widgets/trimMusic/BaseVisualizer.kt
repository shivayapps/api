package com.text.art.fancy.creator.widgets.trimMusic

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Color
import android.graphics.Paint
import android.media.audiofx.Visualizer
import android.media.audiofx.Visualizer.OnDataCaptureListener
import android.util.AttributeSet
import android.view.View
import androidx.annotation.Nullable
import androidx.core.content.ContextCompat
import com.text.art.fancy.creator.R

abstract class BaseVisualizer : View {

    protected var mRawAudioBytes: ByteArray? = null
    protected var mPaint: Paint? = null
    protected var mBlurPaint: Paint? = null
    protected var mVisualizer: Visualizer? = null
    protected var mColor: Int = Color.RED
    protected var mPaintStyle: PaintStyle = PaintStyle.OUTLINE
    protected var mPositionGravity: PositionGravity = PositionGravity.BOTTOM
    protected var mStrokeWidth: Float = 4f
    protected var mDensity: Float = 0.25f
    protected var mAnimSpeed: AnimSpeed = AnimSpeed.FAST
    protected var isVisualizationEnabled = true


    enum class PaintStyle {
        OUTLINE,
        FILL
    }

    enum class PositionGravity {
        TOP, BOTTOM
    }

    enum class AnimSpeed {
        SLOW, MEDIUM, FAST
    }


    constructor(context: Context) : super(context) {
        init(context, null)
        init()
    }

    constructor(
        context: Context,
        @Nullable attrs: AttributeSet?
    ) : super(context, attrs) {
        init(context, attrs)
        init()
    }

    constructor(
        context: Context,
        @Nullable attrs: AttributeSet?,
        defStyleAttr: Int
    ) : super(context, attrs, defStyleAttr) {
        init(context, attrs)
        init()
    }

    private fun init(
        context: Context,
        attrs: AttributeSet?
    ) {

        setLayerType(LAYER_TYPE_SOFTWARE,null)

        //get the attributes specified in attrs.xml using the name we included
        val typedArray = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.BaseVisualizer, 0, 0
        )
        if (typedArray != null && typedArray.length() > 0) {
            try {
                //get the text and colors specified using the names in attrs.xml
                mDensity = typedArray.getFloat(
                    R.styleable.BaseVisualizer_avDensity,
                    0.25f
                )
                mColor = typedArray.getColor(
                    R.styleable.BaseVisualizer_avColor,
                    ContextCompat.getColor(context,R.color.colorPrimary)
                )
                mStrokeWidth = typedArray.getDimension(
                    R.styleable.BaseVisualizer_avWidth,
                    context.resources.getDimension(R.dimen._1sdp)
                )
                /*var paintType =
                    typedArray.getString(R.styleable.BaseVisualizer_avType)

                if (paintType != null && paintType != "")
                    mPaintStyle = if (paintType.toLowerCase() == "outline") PaintStyle.OUTLINE else PaintStyle.FILL
                val gravityType = typedArray.getString(R.styleable.BaseVisualizer_avGravity)
                if (gravityType != null && gravityType != "")
                    mPositionGravity = if (gravityType.toLowerCase() == "top") PositionGravity.TOP else PositionGravity.BOTTOM
                val speedType = typedArray.getString(R.styleable.BaseVisualizer_avSpeed)
                if (speedType != null && speedType != "") {
                    mAnimSpeed = AnimSpeed.MEDIUM
                    if (speedType.toLowerCase() == "slow")
                        mAnimSpeed = AnimSpeed.SLOW
                    else if (speedType.toLowerCase() == "fast")
                        mAnimSpeed = AnimSpeed.FAST
                }*/
            } finally {
                typedArray.recycle()
            }
        }
        mPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        mPaint!!.color = mColor
        mPaint!!.strokeWidth = mStrokeWidth

        if (mPaintStyle === PaintStyle.FILL)
            mPaint!!.style = Paint.Style.FILL
        else {
            mPaint!!.style = Paint.Style.STROKE
        }

        mBlurPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        mBlurPaint!!.color = mColor
        mBlurPaint!!.strokeWidth = mStrokeWidth + context.resources.getDimension(R.dimen._2sdp)
        mBlurPaint?.maskFilter = BlurMaskFilter(12f,BlurMaskFilter.Blur.NORMAL)
        if (mPaintStyle === PaintStyle.FILL)
            mBlurPaint!!.style = Paint.Style.FILL
        else {
            mBlurPaint!!.style = Paint.Style.STROKE
        }
    }

    /**
     * Set color to visualizer with color resource id.
     *
     * @param color color resource id.
     */
    fun setColor(color: Int) {
        mColor = color
        mPaint!!.color = mColor
    }

    /**
     * Set the density of the visualizer
     *
     * @param density density for visualization
     */
    fun setDensity(density: Float) {
        //TODO: Check dynamic density change, may cause crash
        synchronized(this) {
            mDensity = density
            init()
        }
    }

    /**
     * Sets the paint style of the visualizer
     *
     * @param paintStyle style of the visualizer.
     */
    fun setPaintStyle(paintStyle: PaintStyle) {
        mPaintStyle = paintStyle
        mPaint!!.style =
            if (paintStyle === PaintStyle.FILL) Paint.Style.FILL else Paint.Style.STROKE
    }

    /**
     * Sets the position of the Visualization[PositionGravity]
     *
     * @param positionGravity position of the Visualization
     */
    fun setPositionGravity(positionGravity: PositionGravity) {
        mPositionGravity = positionGravity
    }

    /**
     * Sets the Animation speed of the visualization[AnimSpeed]
     *
     * @param animSpeed speed of the animation
     */
    open fun setAnimationSpeed(animSpeed: AnimSpeed) {
        mAnimSpeed = animSpeed
    }

    /**
     * Sets the width of the outline [PaintStyle]
     *
     * @param width style of the visualizer.
     */
    fun setStrokeWidth(width: Float) {
        mStrokeWidth = width
        mPaint!!.strokeWidth = width
    }

    /**
     * Sets the audio bytes to be visualized form [Visualizer] or other sources
     *
     * @param bytes of the raw bytes of music
     */
    fun setRawAudioBytes(bytes: ByteArray) {
        mRawAudioBytes = bytes
        this.invalidate()
    }

    /**
     * Sets the audio session id for the currently playing audio
     *
     * @param audioSessionId of the media to be visualised
     */
    fun setAudioSessionId(audioSessionId: Int) {
        try {
            if (mVisualizer != null) release()
            mVisualizer = Visualizer(audioSessionId)
            mVisualizer!!.captureSize = Visualizer.getCaptureSizeRange()[1]
            mVisualizer!!.setDataCaptureListener(object : OnDataCaptureListener {
                override fun onWaveFormDataCapture(
                    visualizer: Visualizer, bytes: ByteArray,
                    samplingRate: Int
                ) {
                    mRawAudioBytes = bytes
                    invalidate()
                }

                override fun onFftDataCapture(
                    visualizer: Visualizer, bytes: ByteArray,
                    samplingRate: Int
                ) {
                }
            }, Visualizer.getMaxCaptureRate() / 2, true, false)
            mVisualizer!!.enabled = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Releases the visualizer
     */
    fun release() {
        if (mVisualizer != null) mVisualizer!!.release()
    }

    /**
     * Enable Visualization
     */
    fun show() {
        isVisualizationEnabled = true
    }

    /**
     * Disable Visualization
     */
    fun hide() {
        isVisualizationEnabled = false
    }

    protected abstract fun init()
}