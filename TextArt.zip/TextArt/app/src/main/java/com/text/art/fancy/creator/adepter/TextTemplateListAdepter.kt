package com.text.art.fancy.creator.adepter

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.text.art.fancy.creator.model.templatemode.TextTemplateResponse
import com.text.art.fancy.creator.R
import kotlinx.android.synthetic.main.rv_text_template_item.view.*

class TextTemplateListAdepter(
    private val mContext: Context,
    private val mList: ArrayList<TextTemplateResponse>,
    private val action: (Int) -> Unit
) : RecyclerView.Adapter<TextTemplateListAdepter.AddTextHolder>() {
    private var selectePosition = -1
    private var selectePositionLast = -1

    inner class AddTextHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AddTextHolder =
            AddTextHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_text_template_item, parent, false))

    override fun getItemCount(): Int = mList.size

    override fun onBindViewHolder(holder: AddTextHolder, position: Int) {


        with(holder.itemView) {

            val item = mList[position].image

            if (selectePosition == position) {
                imgThumbTextTemplate.borderColor = Color.WHITE
            } else {
                imgThumbTextTemplate.borderColor = ContextCompat.getColor(mContext, R.color.colorBackground1)
            }

            Glide.with(mContext).load(item).override(600).into(object : CustomTarget<Drawable>() {
                override fun onLoadCleared(placeholder: Drawable?) {
                }

                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    imgThumbTextTemplate.background = resource
                }
            })

            this.setOnClickListener {
                action(position)
                selectePositionLast = selectePosition
                selectePosition = position
                notifyItemChanged(selectePositionLast)
                notifyItemChanged(selectePosition)
            }
        }
    }

    fun resetPositionOfTextItem() {
        selectePosition = -1
        notifyDataSetChanged()
    }

}