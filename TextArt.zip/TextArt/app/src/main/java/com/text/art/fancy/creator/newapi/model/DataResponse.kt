package com.text.art.fancy.creator.newapi.model

import com.text.art.fancy.creator.newapi.model.DataItem
import com.google.gson.annotations.SerializedName

data class DataResponse(
    @SerializedName("ResponseCode")
	val responseCode: String? = null,

    @SerializedName("data")
	val data: List<DataItem?>? = null,

    @SerializedName("ResponseMessage")
	val responseMessage: String? = null
)

