package com.text.art.fancy.creator.handler;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

/*public class ExampleNotificationReceivedHandler implements OneSignal.OSRemoteNotificationReceivedHandler {
    *//*@Override
    public void notificationReceived(OSNotification notification) {
        JSONObject data = notification.payload.additionalData;
        String notificationID = notification.payload.notificationID;
        String title = notification.payload.title;
        String body = notification.payload.body;
        String smallIcon = notification.payload.smallIcon;
        String largeIcon = notification.payload.largeIcon;
        String bigPicture = notification.payload.bigPicture;
        String smallIconAccentColor = notification.payload.smallIconAccentColor;
        String sound = notification.payload.sound;
        String ledColor = notification.payload.ledColor;
        int lockScreenVisibility = notification.payload.lockScreenVisibility;
        String groupKey = notification.payload.groupKey;
        String groupMessage = notification.payload.groupMessage;
        String fromProjectNumber = notification.payload.fromProjectNumber;
        String rawPayload = notification.payload.rawPayload;

        String customKey;

        Log.i("OneSignalExample", "NotificationID received: " + notificationID);

        if (data != null) {
            customKey = data.optString("customkey", null);
            if (customKey != null)
                Log.i("OneSignalExample", "customkey set with value: " + customKey);
        }
    }*//*

    @Override
    public void remoteNotificationReceived(Context context, OSNotificationReceivedEvent notification) {
        JSONObject data = notification.getNotification().getAdditionalData();
        String notificationID = notification.getNotification().getNotificationId();
        String title = notification.getNotification().getTitle();
        String body = notification.getNotification().getBody();
        String smallIcon = notification.getNotification().getSmallIcon();
        String largeIcon = notification.getNotification().getLargeIcon();
        String bigPicture = notification.getNotification().getBigPicture();
        String smallIconAccentColor = notification.getNotification().getSmallIconAccentColor();
        String sound = notification.getNotification().getSound();
        String ledColor = notification.getNotification().getLedColor();
        int lockScreenVisibility = notification.getNotification().getLockScreenVisibility();
        String groupKey = notification.getNotification().getGroupKey();
        String groupMessage = notification.getNotification().getGroupMessage();
        String fromProjectNumber = notification.getNotification().getFromProjectNumber();
        String rawPayload = notification.getNotification().getRawPayload();

        String customKey;

        Log.i("OneSignalExample", "NotificationID received: " + notificationID);

        if (data != null) {
            customKey = data.optString("customkey", null);
            if (customKey != null)
                Log.i("OneSignalExample", "customkey set with value: " + customKey);
        }
    }
}*/

public class ExampleNotificationReceivedHandler {
    /*@Override
    public void notificationReceived(OSNotification notification) {
        JSONObject data = notification.payload.additionalData;
        String notificationID = notification.payload.notificationID;
        String title = notification.payload.title;
        String body = notification.payload.body;
        String smallIcon = notification.payload.smallIcon;
        String largeIcon = notification.payload.largeIcon;
        String bigPicture = notification.payload.bigPicture;
        String smallIconAccentColor = notification.payload.smallIconAccentColor;
        String sound = notification.payload.sound;
        String ledColor = notification.payload.ledColor;
        int lockScreenVisibility = notification.payload.lockScreenVisibility;
        String groupKey = notification.payload.groupKey;
        String groupMessage = notification.payload.groupMessage;
        String fromProjectNumber = notification.payload.fromProjectNumber;
        String rawPayload = notification.payload.rawPayload;

        String customKey;

        Log.i("OneSignalExample", "NotificationID received: " + notificationID);

        if (data != null) {
            customKey = data.optString("customkey", null);
            if (customKey != null)
                Log.i("OneSignalExample", "customkey set with value: " + customKey);
        }
    }*/

   /* @Override
    public void remoteNotificationReceived(Context context, OSNotificationReceivedEvent notification) {
        JSONObject data = notification.getNotification().getAdditionalData();
        String notificationID = notification.getNotification().getNotificationId();
        String title = notification.getNotification().getTitle();
        String body = notification.getNotification().getBody();
        String smallIcon = notification.getNotification().getSmallIcon();
        String largeIcon = notification.getNotification().getLargeIcon();
        String bigPicture = notification.getNotification().getBigPicture();
        String smallIconAccentColor = notification.getNotification().getSmallIconAccentColor();
        String sound = notification.getNotification().getSound();
        String ledColor = notification.getNotification().getLedColor();
        int lockScreenVisibility = notification.getNotification().getLockScreenVisibility();
        String groupKey = notification.getNotification().getGroupKey();
        String groupMessage = notification.getNotification().getGroupMessage();
        String fromProjectNumber = notification.getNotification().getFromProjectNumber();
        String rawPayload = notification.getNotification().getRawPayload();

        String customKey;

        Log.i("OneSignalExample", "NotificationID received: " + notificationID);

        if (data != null) {
            customKey = data.optString("customkey", null);
            if (customKey != null)
                Log.i("OneSignalExample", "customkey set with value: " + customKey);
        }
    }*/
}