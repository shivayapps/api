package com.text.art.fancy.creator.model

import java.io.Serializable
import kotlin.collections.ArrayList

data class PhotoModel(
        var path: String = "",
        var date: String = "",
        var isHeader: Boolean = false,
        var strings: ArrayList<ImageModel>? = ArrayList(),
        var isSelect: Boolean = false) : Serializable

