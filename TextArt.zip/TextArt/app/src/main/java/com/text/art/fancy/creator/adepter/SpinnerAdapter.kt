package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.text.art.fancy.creator.R

class SpinnerAdapter(val applicationContext: Context, val dataList: ArrayList<String>) : BaseAdapter() {

    val context = applicationContext
    val inflate: LayoutInflater = LayoutInflater.from(applicationContext)

    override fun getCount(): Int {
        return dataList.size
    }

    override fun getItem(i: Int): Any? {
        return null
    }

    override fun getItemId(i: Int): Long {
        return 0
    }

    @SuppressLint("ViewHolder", "InflateParams")
    override fun getView(i: Int, view: View?, viewGroup: ViewGroup?): View? {
        return inflate.inflate(R.layout.spinner_symbol, null).apply {
            (this.findViewById<View>(R.id.spinnerItem) as TextView).text = dataList[i]
        }
    }

}