package com.text.art.fancy.creator.comboapi

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.app.ads.helper.RewardVideoHelper.isShowRewardVideoAd
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.ComboActivity
import com.text.art.fancy.creator.activitys.SubscriptionActivity
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.database.DBHelper
import com.text.art.fancy.creator.dialog.WatchAdDialogFragment
import com.text.art.fancy.creator.newapi.category.CategoryItem
import com.text.art.fancy.creator.newapi.data.ApiHelper
import com.text.art.fancy.creator.newapi.data.MainRepository
import com.text.art.fancy.creator.newapi.data.RetrofitBuilder
import com.text.art.fancy.creator.utils.hide
import com.text.art.fancy.creator.utils.isOnline
import com.text.art.fancy.creator.utils.show

import kotlinx.coroutines.*

class ComboDataFragment : Fragment() {

    var llInternetConnection: LinearLayout? = null
    var llNodataFound: LinearLayout? = null
    var progressBar1: ProgressBar? = null
    var pbLoading: ProgressBar? = null
    var recyclerViewCard: RecyclerView? = null
    var dbHelper: DBHelper? = null
    var isDismiss: Boolean = false
    var isRewardEarn: Boolean = false
    var watchAdDialog:WatchAdDialogFragment? = null
    var isSubscription: Boolean = false
    var myFilterArray = arrayListOf<CategoryItem>()
    lateinit var actionBottomDialogFragment: ComboActivity
    var param: Int? = null
    private var lastClickTime: Long = 0
    private var comboAdapter : ComboApiAdepter ?= null
    private lateinit var mainRepository: MainRepository

    private var loading = true
    private var pastVisiblesItems = 0
    private var visibleItemCount = 0
    private var totalItemCount = 0
    private var currentPage = 1
    private var totalPage = 1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_bg_data, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dbHelper = DBHelper(requireContext())
        isSubscription = try {
            MySharedPreferences(
                requireContext()
            ).isSubscribe
        } catch (e: Exception) {
            false
        }
        param = requireArguments().getInt("param")
        recyclerViewCard = view.findViewById(R.id.recyclerViewCard)
        progressBar1 = view.findViewById(R.id.progressBar1)
        pbLoading = view.findViewById(R.id.pbLoading)
        llInternetConnection = view.findViewById(R.id.llInternetConnection)
        llNodataFound = view.findViewById(R.id.llNodataFound)
//        loadData()
        if (isOnline()){
            loadNewApiData()
        }
    }

    private fun loadNewApiData() {
        if (isDismiss) return
        progressBar1?.show()
        myFilterArray.clear()

        mainRepository = MainRepository(ApiHelper(RetrofitBuilder.apiServiceNew(requireActivity())))
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                loadNextPage(currentPage)
            }
            withContext(Dispatchers.Main) {
                //TODO SetRecyclerView
                val gridLayoutManager = GridLayoutManager(requireContext(), 3)
                gridLayoutManager.orientation = LinearLayoutManager.VERTICAL
                recyclerViewCard!!.layoutManager = gridLayoutManager
                recyclerViewCard?.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                    @SuppressLint("NotifyDataSetChanged")
                    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                        if (dy > 0) {
                            visibleItemCount = gridLayoutManager.childCount
                            totalItemCount = gridLayoutManager.itemCount
                            pastVisiblesItems = gridLayoutManager.findFirstVisibleItemPosition()
                            if (currentPage < totalPage) {
                                if (loading) {
                                    if (visibleItemCount + pastVisiblesItems >= totalItemCount) {
                                        currentPage++
                                        loadNextPage(currentPage)
                                    }
                                }
                            }
                        }
                    }
                })

                comboAdapter = ComboApiAdepter(requireContext(), myFilterArray,
                    object : ComboApiAdepter.OnItemClickCombo {
                        override fun onItemClickCombo(position: Int, bg: String, frame: String) {
                            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return
                            lastClickTime = SystemClock.elapsedRealtime()
                            if (myFilterArray[position].isPremium == 1) {
                                ComboActivity.isAdsIsFree = false
                                startActivityForResult(
                                    Intent(
                                        requireContext(),
                                        SubscriptionActivity::class.java
                                    ), 1000
                                )
                            } else if (myFilterArray[position].coin == 10) {
                                ComboActivity.isAdsIsFree = false
                                if (isOnline()) {
                                    showAdDialog(position)
                                } else {
                                    Toast.makeText(activity,
                                        "Please check internet connection.",
                                        Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                ComboActivity.isAdsIsFree = true
                                actionBottomDialogFragment.onComboItemClick(
                                    param!!,
                                    bg,
                                    frame
                                )
                            }
                        }
                    }
                )

                recyclerViewCard!!.adapter = comboAdapter
                recyclerViewCard?.show()
                llInternetConnection?.hide()
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun loadNextPage(currentPage: Int) {
        lifecycleScope.launch {
            if (currentPage != 1){
                withContext(Dispatchers.Main){
                    pbLoading?.show()
                    recyclerViewCard?.invalidate()
                }
            }
            loading = false
            Log.d(TAG, "loadNextPage: API Combo id $param")
            mainRepository.getCategory(ComboActivity.categoryId, param, page = currentPage)?.let {
                withContext(Dispatchers.IO){
                    it.data?.let { responce ->
                        it.totalPage?.let { total -> totalPage = total }
                        val mComboOpen = DBHelper(actionBottomDialogFragment).allOpenComboData
                        for (combo in responce){
                            combo?.let { file ->
                                val categoryParametersItem = CategoryItem()
                                if (file.isPremium == 1 && !isSubscription) {
                                    categoryParametersItem.isPremium = 1
                                } else {
                                    categoryParametersItem.isPremium = 0
                                }
                                if (file.coin == 10 && !isSubscription) {
                                    categoryParametersItem.coin = 10
                                } else {
                                    categoryParametersItem.coin = 0
                                }
                                categoryParametersItem.image = file.image
                                categoryParametersItem.thumbImage = file.thumbImage
                                try {
                                    if (!isSubscription) {
                                        mComboOpen.moveToFirst()
                                        if (mComboOpen.getString(1) == file.image) {
                                            categoryParametersItem.coin = 0
                                        }
                                        while (mComboOpen.moveToNext()) {
                                            if (mComboOpen.getString(1) == file.image) {
                                                categoryParametersItem.coin = 0
                                                break
                                            }
                                        }
                                    }
                                } catch (e: Exception) {}
                                myFilterArray.add(categoryParametersItem)
                                true
                            }
                        }
                    }
                }
            }
        }.invokeOnCompletion {
            comboAdapter?.notifyDataSetChanged()
            loading = true
            progressBar1?.hide()
            pbLoading?.hide()
            recyclerViewCard?.invalidate()
        }
    }

    override fun onResume() {
        super.onResume()
    }

    private fun loadData() {
        if (isDismiss) return
//        if (ComboActivity.comboArray.isNullOrEmpty()){
//            Handler(Looper.getMainLooper()).postDelayed({loadData()},3000)
//        }else {
//            myFilterArray = arrayListOf()
//            val gridLayoutManager = GridLayoutManager(requireContext(), 3)
//            gridLayoutManager.orientation = LinearLayoutManager.VERTICAL
//            recyclerViewCard!!.layoutManager = gridLayoutManager
//            if (ComboActivity.comboArray[param!!].categoryParameters.size != 0) {
//                var mOpenCombo: Cursor? = null
//
//                GlobalScope.launch {
//                    withContext(Dispatchers.IO) {
//                        //TODO #1
//                        mOpenCombo = DBHelper(actionBottomDialogFragment).allOpenComboData
////                        mOpenCombo = DBHelper(actionBottomDialogFragment).allOpenBGData
//                    }
//
//                    withContext(Dispatchers.IO) {
//                        ComboActivity.comboArray[param!!].categoryParameters!!.filterIndexed { _, file ->
//                            val categoryParametersItem = CategoryParametersItem()
//                            if (file.is_premium == 1 && !isSubscription) {
//                                categoryParametersItem.is_premium = 1
//                            } else {
//                                categoryParametersItem.is_premium = 0
//                            }
//                            if (file.coins == 10 && !isSubscription) {
//                                categoryParametersItem.coins = 10
//                            } else {
//                                categoryParametersItem.coins = 0
//                            }
//                            Log.d(TAG, "loadData: val ${categoryParametersItem.coins}")
//                            Log.d(TAG, "loadData: val ${categoryParametersItem.is_premium}")
//                            categoryParametersItem.image = file.image
//                            categoryParametersItem.thumbImage = file.thumbImage
//
////                            try {
//                                if (!isSubscription) {
//                                    Log.d(TAG, "showAdReward: img Total count ${mOpenCombo!!.count}")
//                                    if (mOpenCombo!!.count != 0) {
//                                        mOpenCombo!!.moveToFirst()
//                                        if (mOpenCombo!!.getString(1) == file.image) {
//                                            categoryParametersItem.coins = 0
//                                        }
//                                        while (mOpenCombo!!.moveToNext()) {
//                                            if (mOpenCombo!!.getString(1) == file.image) {
//                                                Log.d(TAG, "showAdReward: img database: ${mOpenCombo!!.getString(1)}")
//                                                categoryParametersItem.coins = 0
////                                            break
//                                            }
//                                        }
//                                    }
//                                }
////                            } catch (e: Exception) { }
//
//                            myFilterArray.add(categoryParametersItem)
//                            true
//                        }
//                    }
//                    withContext(Dispatchers.Main) {
//                        val comboAdapter = ComboApiAdepter(
//                            actionBottomDialogFragment,
//                            myFilterArray,
//                            object : ComboApiAdepter.OnItemClickCombo {
//                                override fun onItemClickCombo(
//                                    position: Int,
//                                    bg: String,
//                                    frame: String
//                                ) {
//                                    if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return
//                                    lastClickTime = SystemClock.elapsedRealtime()
//                                    if (myFilterArray!![position].is_premium == 1) {
//                                        ComboActivity.isAdsIsFree = false
//                                        startActivityForResult(
//                                            Intent(
//                                                requireContext(),
//                                                SubscriptionActivity::class.java
//                                            ), 1000
//                                        )
//                                    } else if (myFilterArray!![position].coins == 10) {
//                                        ComboActivity.isAdsIsFree = false
//                                        if (isOnline()) {
//                                            if (RewardedAdHelper.instence != null && RewardedAdHelper.instence!!.loadRewardedAd(
//                                                    requireContext()
//                                                ) != null
//                                            ) {
//                                                showAdDialog(position)
//                                            } else {
//                                                Toast.makeText(requireContext(), resources.getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
//                                            }
//                                        } else {
//                                            Toast.makeText(activity, "Please check internet connection.", Toast.LENGTH_SHORT).show()
//                                        }
//                                    } else {
//                                        ComboActivity.isAdsIsFree = true
//                                        actionBottomDialogFragment.onComboItemClick(ComboActivity.comboArray[param!!].categoryParameters!![position].id, bg, frame)
//                                    }
//                                }
//
//                            })
//
//                        recyclerViewCard!!.adapter = comboAdapter
//                        recyclerViewCard!!.visibility = View.VISIBLE
//                        progressBar1!!.visibility = View.GONE
//                        llInternetConnection!!.visibility = View.GONE
//
//                    }
//                }
//
//            } else {
//                if (isOnline()) {
//                    llInternetConnection!!.visibility = View.GONE
//                    llNodataFound!!.visibility = View.VISIBLE
//                    recyclerViewCard!!.visibility = View.GONE
//                    progressBar1!!.visibility = View.GONE
//                } else {
//                    llInternetConnection!!.visibility = View.VISIBLE
//                    llNodataFound!!.visibility = View.GONE
//                    recyclerViewCard!!.visibility = View.GONE
//                    progressBar1!!.visibility = View.GONE
//                }
//            }
//        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d(TAG, "onActivityResult: $requestCode $resultCode $isSubscription")
        if (requestCode == 1000 && resultCode == 1144) {
            isSubscription = try {
                MySharedPreferences(
                    actionBottomDialogFragment
                ).isSubscribe
            } catch (e: Exception) { false }
            Log.d(TAG, "onActivityResult: $isSubscription")
            if (isSubscription) {
                loadData()
            }
        }
    }

    private fun showAdDialog(position: Int) {
        watchAdDialog = WatchAdDialogFragment(
            "Unlock Combo",
            "Get PRO",
            "To Access All Combos",
            R.drawable.ic_dialog_background,
            "Watch Video Ad",
            "To Use This Combo"
        )
        { s, discardDialogFragment ->
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@WatchAdDialogFragment
            lastClickTime = SystemClock.elapsedRealtime()
            when (s) {
                "subscribe" -> {
                    discardDialogFragment.dismiss()
                    startActivityForResult(
                        Intent(
                            requireContext(),
                            SubscriptionActivity::class.java
                        ), 1000
                    )
                }
                "watchAd" -> {
                    discardDialogFragment.dismiss()
                    ComboActivity.isAdsIsFree = false
                    showAdReward(position)
                }
                else -> {
                    discardDialogFragment.dismiss()
                }
            }
        }
        watchAdDialog!!.isCancelable = false
        watchAdDialog!!.show(childFragmentManager, "dialog_fragment")

    }

    fun showAdReward(position: Int) {

        activity!!.isShowRewardVideoAd(
            onStartToLoadRewardVideoAd = {

            },
            onUserEarnedReward = {
                dbHelper!!.insertOpenComboData(position, myFilterArray[position].image!!)
//                dbHelper!!.insertOpenBgData(position, myFilterArray!![position].image)
                actionBottomDialogFragment.onComboItemClick(
                    param!!,
                    myFilterArray[position].image!!,
                    myFilterArray[position].thumbImage!!
                )

            },
            onAdLoaded = {

            }
        )

    }

//    fun showAdReward(position: Int, gameOverRewardedAd: RewardedAd, numberOfAd: Int) {
//        if (gameOverRewardedAd.isLoaded) {
//            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
//                override fun onRewardedAdOpened() {
//                    // Ad opened.
//                }
//
//                override fun onRewardedAdClosed() {
//                    // Ad closed.
//                    instence!!.loadVideoAdMain(requireContext())
//                    if (isRewardEarn){
//                        isRewardEarn=false
//                        actionBottomDialogFragment.onComboItemClick(
//                            ComboActivity.comboArray[param!!].categoryParameters[position].id,
//                            ComboActivity.comboArray[param!!].categoryParameters[position].image,
//                            ComboActivity.comboArray[param!!].categoryParameters[position].thumbImage
//                        )
//                    }
//                }
//
//                override fun onUserEarnedReward(reward: RewardItem) {
//                    // User earned reward.
//                    try {
//                        isRewardEarn=true
//                        dbHelper!!.insertOpenComboData(position, myFilterArray[position].image!!)
////                        Constants.typeface = Typeface.createFromFile(parametersItemAllChild[param].categoryParameters!![position].fontsPath)
//                    } catch (e: Exception) {
//                    }
//
//                    instence!!.loadVideoAdMain(requireContext())
//                }
//
//                override fun onRewardedAdFailedToShow(errorCode: Int) {
//                    // Ad failed to display.
//                    instence!!.loadVideoAdMain(requireContext())
//                }
//            }
//            gameOverRewardedAd.show(activity, adCallback)
//        } else {
//            instence!!.loadVideoAdMain(requireContext())
//        }
//    }

    interface ItemClickListener {
        fun onComboItemClick(id: Int,bg: String,frame: String)
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        actionBottomDialogFragment = activity as ComboActivity
    }

    override fun onPause() {
        super.onPause()

        //TODO For Can not perform this action after onSaveInstanceState
        try {
            if (watchAdDialog!=null && watchAdDialog!!.isShowing()){
                watchAdDialog!!.dismiss()
            }
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        isDismiss = true
    }

    companion object {
        private const val TAG = "ComboDataFragment"

        @JvmStatic
        fun newInstance(param: Int): Fragment {
            val args = Bundle()
            args.putInt("param", param)
            val f = ComboDataFragment()
            f.arguments = args
            return f
        }

    }
}