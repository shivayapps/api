package com.text.art.fancy.creator.utils

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.vasundhara.vision.subscription.ui.BaseSubActivity

abstract class BaseActivity : BaseSubActivity() {

    var TAGG = this::class.simpleName

    //Context Object to access child class
    protected lateinit var mContext: Context

    //Activity Object to access child class
    protected lateinit var mActivity: Activity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mContext = this
        mActivity = this@BaseActivity
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)

        TAGG = this::class.simpleName
        bindCallbacks()
        bindAction()
    }


    public fun checkStatus(): Boolean {
        try {
            return NetworkHelper.isOnline(this)
        } catch (e: NoSuchMethodException) {
            e.printStackTrace()
            return true
        } catch (e: NullWifiConfigurationException) {
            e.printStackTrace()
            return true
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }


    /**
     * this method use to initialize call backs
     */
    abstract fun bindCallbacks()

    /**
     * this method call after bind Action
     * to perform action
     */
    abstract fun bindAction()


}