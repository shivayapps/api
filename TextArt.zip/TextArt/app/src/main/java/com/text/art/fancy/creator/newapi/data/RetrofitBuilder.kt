package com.text.art.fancy.creator.newapi.data

import android.content.Context
import com.text.art.fancy.creator.newapi.manager.AuthInterceptor
import com.text.art.fancy.creator.newapi.manager.SessionManager
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.helper.NativeHelper
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitBuilder {

    private fun getRetrofit(context: Context): Retrofit {

        //TODO CHANGE BASEURL
         val sessionManager = SessionManager(context)
//        sessionManager.saveAuthToken(NativeHelper().getBaseUrl())
        sessionManager.saveAuthToken(NativeHelper().getTestUrl())

        return Retrofit.Builder()
//                .baseUrl(NativeHelper().getBaseUrl())
                .baseUrl(NativeHelper().getTestUrl())
            .addConverterFactory(GsonConverterFactory.create())
            .client(okhttpClient(context))
            .build() //Doesn't require the adapter
    }

    private fun okhttpClient(context: Context): OkHttpClient {
        val sessionManager = SessionManager(context)

        return OkHttpClient.Builder()
            .readTimeout(60, TimeUnit.SECONDS)
            .connectTimeout(60, TimeUnit.SECONDS)
            .sslSocketFactory(sessionManager.getSSLSocketFactory()!!)
            .hostnameVerifier { hostname, session ->
                return@hostnameVerifier true
            }
            .addInterceptor(AuthInterceptor(context))
            .build()
    }

    fun apiServiceNew(context: Context): ApiService = getRetrofit(context).create(ApiService::class.java)
}
