package com.text.art.fancy.creator.newapi.interfaces

interface OnConnectionTimeoutListener {
    fun onConnectionTimeout()
}