package com.text.art.fancy.creator.categorys

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import biz.laenger.android.vpbs.BottomSheetUtils
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.SimpleColorFilter
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.ads.RewardVideoAds.Companion.instence
import com.text.art.fancy.creator.categorys.adepter.FrameCategoryPagerAdepter
import com.text.art.fancy.creator.categorys.callbacks.OnRewardEarn
import com.text.art.fancy.creator.categorys.fragments.FramePagerFragment
import com.text.art.fancy.creator.categorys.model.DataItem
import com.text.art.fancy.creator.categorys.model.FrameModel
import com.text.art.fancy.creator.categorys.model.ImageItem
import com.text.art.fancy.creator.categorys.parameter.CategoryParametersItem
import com.text.art.fancy.creator.categorys.parameter.ParametersItem
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.categorys.sqlite_database.AdsPrefs
import com.text.art.fancy.creator.categorys.sqlite_database.DBHelper
import com.text.art.fancy.creator.dialog.bottomsheet.SuperBottomSheetDialog
import com.text.art.fancy.creator.dialog.bottomsheet.SuperBottomSheetFragment
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdCallback
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.tabs.TabLayout
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import retrofit2.Call
import retrofit2.Callback
import java.lang.reflect.InvocationTargetException
import java.util.*
import kotlin.jvm.Throws

class FramesCategorySheet : SuperBottomSheetFragment,
    OnRewardEarn {
    private var progressBar: ProgressBar? = null
    private var mForegroundList: ArrayList<DataItem>? = null
    private var mForegroundParaList: ArrayList<ParametersItem>? = null
    private var mDataParaList: ArrayList<ParametersItem>? = null
    private var apiInterface: APIInterface? = null
    private var imageItem: ImageItem? = null
    private var imageItem1: CategoryParametersItem? = null
    private var onItemSelected: OnItemSelected? = null
    private var icBack: ImageView? = null
    private var btnShare: ImageView? = null
    private var tattoo_new_gift: LottieAnimationView? = null
    private var btnAd: ImageView? = null
    private var mViewPagerCard: ViewPager? = null
    private var mViewpagertab: TabLayout? = null
    private var dbHelper: DBHelper? = null
    private var adLayout: RelativeLayout? = null
    private val mTempForgroundList: ArrayList<FrameModel>? = null
    private var mActivity: Activity? = null
    private var isAdShow = false
    private var mType: String? = null
    private var mCakeType = 0
    private var mPosition = 0

    constructor() {
    }

    constructor(mForegroundList: ArrayList<DataItem>?, onItemSelected: OnItemSelected?, type: String?, cakeType: Int) {
        this.mForegroundList = mForegroundList
        this.onItemSelected = onItemSelected
        mType = type
        mCakeType = cakeType
    }

    constructor(mForegroundList: ArrayList<ParametersItem>?, onItemSelected: OnItemSelected?, cakeType: Int) {
        this.onItemSelected = onItemSelected
        this.mDataParaList = mForegroundList
        this.mForegroundParaList = mForegroundList
        mType = "Stickers"
        mCakeType = cakeType
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState)
        val view = inflater.inflate(R.layout.fragment_sticker_category_sheet, container, false)
        dialog!!.setOnShowListener { dialog ->
            val d = dialog as SuperBottomSheetDialog
            val coordinatorLayout = d.findViewById<View>(R.id.coordinator) as CoordinatorLayout?
            val bottomSheet = coordinatorLayout!!.findViewById<FrameLayout>(R.id.super_bottom_sheet)
            val touch_outside = coordinatorLayout.findViewById<View>(R.id.touch_outside)
            val behavior: BottomSheetBehavior<*> = BottomSheetBehavior.from(bottomSheet)
            behavior.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
                override fun onStateChanged(bottomSheet: View, newState: Int) {
                    if (newState == BottomSheetBehavior.STATE_EXPANDED) {
                        try {
                            behavior.setPeekHeight(getPeekHeight())
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                override fun onSlide(bottomSheet: View, slideOffset: Float) {
                    Log.d(TAG, "onSlide: $slideOffset")
                }
            })
            try {
                val valueAnimator = ValueAnimator.ofInt(getPeekHeight(), resources.displayMetrics.heightPixels)
                valueAnimator.interpolator = LinearInterpolator()
                valueAnimator.addUpdateListener { animation -> behavior.peekHeight = animation.animatedValue as Int }
                valueAnimator.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        //
                        try {
                            setStatusBarColor(0f)
                            setCornerRadius(0f)
                            behavior.setState(BottomSheetBehavior.STATE_EXPANDED)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                })
                valueAnimator.duration = 800
                valueAnimator.start()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return view
    }
    var mInterstitialAd: InterstitialAd? = null
    private fun setAndLoadInterstitialAds() {
        val interstialAdId = AppIDs().getGoogleInterstitial(0)
        Log.d("InterstitialAds", interstialAdId)
        mInterstitialAd = InterstitialAd(mActivity)
        //var adsId = AppIDs.instnace!!.getGoogleInterstitial()
        mInterstitialAd!!.adUnitId = interstialAdId
        mInterstitialAd!!.loadAd(AdRequest.Builder().build())
        mInterstitialAd!!.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
                tattoo_new_gift!!.visibility = View.VISIBLE
            }

            override fun onAdImpression() {
                super.onAdImpression()
                Log.d("InterstitialAds", "onAdImpression")

            }

            override fun onAdLeftApplication() {
                super.onAdLeftApplication()
                Log.d("InterstitialAds", "onAdLeftApplication")

            }

            override fun onAdClicked() {
                super.onAdClicked()
                Log.d("InterstitialAds", "onAdClicked")

            }

            override fun onAdFailedToLoad(p0: LoadAdError?) {
                super.onAdFailedToLoad(p0)
                Log.d("InterstitialAds", "LoadAdError")

            }

            override fun onAdClosed() {
                super.onAdClosed()
                tattoo_new_gift!!.visibility = View.GONE
                mInterstitialAd!!.loadAd(AdRequest.Builder().build())

            }

            override fun onAdOpened() {
                super.onAdOpened()
            }
        }
    }

    val statusBarHeight: Int
        get() {
            var result = 0
            val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
            if (resourceId > 0) {
                result = resources.getDimensionPixelSize(resourceId)
            }
            return result
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mActivity = activity
        dbHelper =
            DBHelper(
                activity
            )
        btnAd = view.findViewById(R.id.btnAd)
        icBack = view.findViewById(R.id.icBack)
        btnShare = view.findViewById(R.id.btnShare)
        tattoo_new_gift = view.findViewById(R.id.tattoo_new_gift)
        adLayout = view.findViewById(R.id.adLayout)
        mViewPagerCard = view.findViewById(R.id.viewPagerCard)
        mViewpagertab = view.findViewById(R.id.meterialTabLayout)
        progressBar = view.findViewById(R.id.progressBar)
        try {
            progressBar!!.indeterminateDrawable.colorFilter = SimpleColorFilter(ContextCompat.getColor(requireActivity(), R.color.white))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (!AdsPrefs.getBoolean(activity, AdsPrefs.IS_SUBSCRIBED, false)) {
            if (instence != null) {
                instence!!.loadVideoAdMain(mActivity!!)
//                loadInterstialAd()
            }
        } else {
        }
        icBack!!.setOnClickListener { dismiss() }
        tattoo_new_gift!!.setOnClickListener {
            if (mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
                mInterstitialAd!!.show()
            }
        }
        btnAd!!.setOnClickListener {
            dismiss()
        }
        btnShare!!.setOnClickListener(View.OnClickListener { shareOwnApp() })

        if (mForegroundParaList != null && mForegroundParaList!!.size > 0) {
            progressBar!!.visibility = View.GONE
            setupViewPager()
        }
        try {
            setAndLoadInterstitialAds()
        } catch (e: Exception) {

        }
    }

    private fun setupViewPager() {
        mViewPagerCard!!.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                mPosition = position
                //Constants.mSelectTattooCategoryposition = position
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        for (i in mForegroundParaList!!.indices) {
            mViewpagertab!!.addTab(mViewpagertab!!.newTab().setText(getCategoryName(i)))
        }
        val cardCategoryPagerAdepter =
            FrameCategoryPagerAdepter(
                childFragmentManager,
                null,
                mForegroundParaList,
                mType
            )
        mViewPagerCard!!.adapter = cardCategoryPagerAdepter
        mViewpagertab!!.setupWithViewPager(mViewPagerCard)

        try {
            if (mForegroundList != null) {
                for (i in mForegroundList!!.indices) {
                    try {
                        val view1 = LayoutInflater.from(activity).inflate(R.layout.rv_tab, null)
                        mViewpagertab!!.getTabAt(i)!!.customView = view1
                        val textView = view1.findViewById<TextView>(R.id.textTab)
                        textView.text = getCategoryName(i)
                        Log.d(TAG, "setupViewPager: " + textView.text)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } else {
                for (i in mForegroundParaList!!.indices) {
                    try {
                        val view1 = LayoutInflater.from(activity).inflate(R.layout.rv_tab, null)
                        mViewpagertab!!.getTabAt(i)!!.customView = view1
                        val textView = view1.findViewById<TextView>(R.id.textTab)
                        textView.text = getCategoryName(i)
                        Log.d(TAG, "setupViewPager: " + textView.text)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        BottomSheetUtils.setupViewPager(mViewPagerCard)
    }

    private fun getCategoryName(position: Int): String {
        return try {
            if (mForegroundList != null) {
                val arr = mForegroundList!![position].name/*.split("_".toRegex()).toTypedArray()*/
                arr
                /*if (arr.size > 0) {
                    arr[arr.size - 1]
                } else {
                    arr[0]
                }*/
            } else {
                val arr = mForegroundParaList!![position].name/*.split("_".toRegex()).toTypedArray()*/
                arr
                /*if (arr.size > 0) {
                    arr[arr.size - 1]
                } else {
                    arr[0]
                }*/
            }
        } catch (e: Exception) {
            e.printStackTrace()
            "Default"
        }
    }

    private fun shareOwnApp() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Photo PIP")
        var shareMessage = "\nGo with Text Art and Make Someone's day very special....\n\n"
        shareMessage += "https://play.google.com/store/apps/details?id=${requireContext().packageName}"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, resources.getString(R.string.choose_one)))
    }

    private fun showAd() {
        /*Log.d("dfsfsdf", "clicked")
        if (App.instance!!.requestNewInterstitial()) {
            App.instance!!.mInterstitialAd!!.adListener = object : AdListener() {
                override fun onAdClosed() {
                    super.onAdClosed()
                    loadInterstialAd()
                    Log.d("dfsfsdf", "onAdClosed")
                }

                override fun onAdFailedToLoad(i: Int) {
                    super.onAdFailedToLoad(i)
                    Log.d("dfsfsdf", "onAdFailedToLoad")

                }

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    Log.d("dfsfsdf", "onAdLoaded")
                }
            }
        } else {
            Log.d("dfsfsdf", "try again")
            Toast.makeText(activity, "Try again later.", Toast.LENGTH_SHORT).show()
        }*/
    }

    private fun setData() {
        if (mForegroundParaList != null && mForegroundParaList!!.size > 0) {
            progressBar!!.visibility = View.GONE
            setupViewPager()
        } else {
            try {
                mForegroundParaList = ArrayList()
                mDataParaList = ArrayList()
                checkStatus()
            } catch (e: InvocationTargetException) {
                e.printStackTrace()
            } catch (e: NoSuchMethodException) {
                e.printStackTrace()
            } catch (e: ApiNotSupportedException) {
                e.printStackTrace()
            } catch (e: NoSuchFieldException) {
                e.printStackTrace()
            } catch (e: IllegalAccessException) {
                e.printStackTrace()
            } catch (e: NullWifiConfigurationException) {
                e.printStackTrace()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (!FramePagerFragment.isAdShow) {
            dismiss()
        }
    }

    override fun onCancel(dialog: DialogInterface) {
        super.onCancel(dialog)
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (imageItem != null && mCakeType == NAME_ON_CAKE) {
            onItemSelected!!.onItemSelected(imageItem)
        } else if (imageItem1 != null) {
            onItemSelected!!.onItemSelected(imageItem1)
        }
        onItemSelected!!.dismiss()
    }

    fun showAdReward(position: Int, gameOverRewardedAd: RewardedAd) {
        isAdShow = true
        if (gameOverRewardedAd.isLoaded) {
            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
                override fun onRewardedAdOpened() {
                    // Ad opened.
                    isAdShow = true
                }

                override fun onRewardedAdClosed() {
                    // Ad closed.
                    if (instence != null) {
                        instence!!.loadVideoAdMain(mActivity!!)
                    }
                    isAdShow = false
                }

                override fun onUserEarnedReward(reward: RewardItem) {
                    // User earned reward.
                    dbHelper!!.insertPath(mForegroundList!![mPosition].image[position].image)
                    if (mTempForgroundList != null) {
                        mTempForgroundList[position].isFree = true
                        mTempForgroundList[position].isLocked = false
                    }
                    if (mCakeType == NAME_ON_CAKE) {
                        imageItem = mForegroundList!![mPosition].image[position]
                    } else {
                        imageItem1 = mForegroundParaList!![mPosition].categoryParameters[position]
                    }
                    isAdShow = false
                    dismiss()
                    if (instence != null) {
                        instence!!.loadVideoAdMain(mActivity!!)
                    }
                }

                override fun onRewardedAdFailedToShow(errorCode: Int) {
                    // Ad failed to display.
                    isAdShow = false
                    if (instence != null) {
                        instence!!.loadVideoAdMain(mActivity!!)
                    }
                    Toast.makeText(activity, "Please try again later.", Toast.LENGTH_SHORT).show()
                }
            }
            gameOverRewardedAd.show(activity, adCallback)
        } else {
            isAdShow = false
            if (instence != null) {
                instence!!.loadVideoAdMain(mActivity!!)
            }
            Toast.makeText(activity, "Please try again later.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRewardEarn(imageItem: ImageItem) {
        this.imageItem = imageItem
        Log.d("qwerty222","121212")
    }

    override fun onRewardEarn(imageItem: CategoryParametersItem) {
        imageItem1 = imageItem
        Log.d("qwerty222","131313")
    }

    interface OnItemSelected {
        fun onItemSelected(imagesItem: ImageItem?)
        fun onItemSelected(imagesItem: CategoryParametersItem?)
        fun dismiss()
    }

    private fun dpToPx(dp: Int): Int {
        val r = resources
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }

    @Throws(InvocationTargetException::class, NoSuchMethodException::class, ApiNotSupportedException::class, NoSuchFieldException::class, IllegalAccessException::class, NullWifiConfigurationException::class)
    private fun checkStatus() {
        try {
            if (!NetworkHelper.isOnline(requireActivity())) {
                Log.i("789412312332", "You are offline")
                progressBar!!.visibility = View.GONE
                Toast.makeText(activity, resources.getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                dismiss()
            } else {
                if (NetworkHelper.isWifiConnected(activity)) {
                    val proxy = WifiConfiguration(activity)
                    if (proxy.isProxySetted) {
                        progressBar!!.visibility = View.GONE
                        Toast.makeText(activity, resources.getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                        dismiss()
                        return
                    }
                }
                if (NetworkHelper.isVpnRunning()) {
                    Log.d("789412312332", "checkStatus: VPN Activated")
                    progressBar!!.visibility = View.GONE
                    Toast.makeText(activity, resources.getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show()
                    dismiss()
                    return
                }
                callParamAPI()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun callParamAPI() {
        apiInterface = APIClient.getClient()!!.create(APIInterface::class.java)
        val call = apiInterface!!.parameterList
        call.enqueue(object : Callback<Response> {
            override fun onResponse(call: Call<Response>, response: retrofit2.Response<Response>) {
                Log.d("789412312331", "onResponse: " + response.body())
                if (isAdded) {
                    val model = response.body()
                    if (mDataParaList == null) {
                        mDataParaList = ArrayList()
                        mForegroundParaList = ArrayList()
                    }
                    mDataParaList!!.clear()
                    mForegroundParaList!!.clear()
                    if (model != null && model.parameters != null) {
                        mDataParaList!!.addAll(model.parameters)
                        updateUI()
                    } else {
                        Toast.makeText(activity, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                        dismiss()
                        Objects.requireNonNull(activity)!!.runOnUiThread {
                            progressBar!!.visibility = View.GONE
                        }
                    }
                }
            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                dismiss()
            }
        })
    }

    fun createAndLoadRewardedAd(adUnitId: String?): RewardedAd {
        val rewardedAd = RewardedAd(activity, adUnitId)
        val adLoadCallback: RewardedAdLoadCallback = object : RewardedAdLoadCallback() {
            override fun onRewardedAdLoaded() {
                // Ad successfully loaded.
            }

            override fun onRewardedAdFailedToLoad(errorCode: Int) {
                // Ad failed to load.
            }
        }
        rewardedAd.loadAd(AdRequest.Builder().build(), adLoadCallback)
        return rewardedAd
    }

    private fun loadInterstialAd() {
        /*App.instance!!.mInterstitialAd!!.adListener = null
        App.instance!!.mInterstitialAd = null
        App.instance!!.ins_adRequest = null
        App.instance!!.LoadAds()
        App.instance!!.mInterstitialAd!!.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
            }

            override fun onAdClosed() {
                super.onAdClosed()
            }

            override fun onAdFailedToLoad(i: Int) {
                super.onAdFailedToLoad(i)
                loadInterstialAd()
            }
        }*/
    }

    private fun updateUI() {
        for (i in mDataParaList!!.indices) {
            if (mDataParaList!![i].name != "TattooPhoto" && mDataParaList!![i].name.startsWith("TattooPhoto")) {
                val imageItems = mDataParaList!![i].categoryParameters
                if (imageItems == null || imageItems != null && imageItems.size <= 0) continue
//                Collections.shuffle(imageItems)
                mDataParaList!![i].categoryParameters = imageItems
                mForegroundParaList!!.add(mDataParaList!![i])
            }
        }
        setData()
    }

    companion object {
        private const val TAG = "CardCategorySheet"
        const val NAME_ON_CAKE = 0
        const val PHOTO_ON_CAKE = 1
        const val TEXTART = 2
    }

}