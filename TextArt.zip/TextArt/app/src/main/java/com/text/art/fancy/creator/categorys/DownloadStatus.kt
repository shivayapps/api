package com.tattoo.body.name.girls.boys.photo.editor.categorys

import java.io.Serializable

data class DownloadStatus(
     var mPercentage : Int,
     var status : Status
) : Serializable{

    enum class Status {
        //Download status running
        RUNNING,

        //Download status Complete
        COMPLETE
    }
}