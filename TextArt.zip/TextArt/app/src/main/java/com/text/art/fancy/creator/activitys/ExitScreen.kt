package com.text.art.fancy.creator.activitys

import android.os.*
import androidx.appcompat.app.AppCompatActivity
import com.text.art.fancy.creator.R

class ExitScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.exit_activity)
        Handler(Looper.getMainLooper()).postDelayed({
           finishAffinity()
        }, 1500)

    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }

}