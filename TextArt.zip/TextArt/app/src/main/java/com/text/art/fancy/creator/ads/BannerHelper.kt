package com.text.art.fancy.creator.ads

import android.util.Log
import android.view.View
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.ads.AdsHelper.isTest
import com.text.art.fancy.creator.ads.AdsHelper.requestId
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdView
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs

object BannerHelper {
    /**
     * TODO:  How to implement banner ad
     */
// 1. Add in xml
/* <com.google.android.gms.ads.AdView
    android:id="@+id/ad_view"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_alignParentBottom="true"
    android:layout_centerHorizontal="true"
    android:visibility="gone"
    ads:adSize="BANNER"
    ads:adUnitId="@string/banner_ad_id" />

    // 2. Add following methods in activity

    // Called when leaving the activity
    @Override
    public void onPause() {
        BannerHelper.onPause();
        super.onPause();
    }

    // Called when returning to the activity
    @Override
    public void onResume() {
        super.onResume();
        BannerHelper.onResume();
    }

    // Called before the activity is destroyed
    @Override
    public void onDestroy() {
        BannerHelper.onDestroy();
        super.onDestroy();
    }

    // 3. Load Banner Ad in onCreate()
    if (Share.isNeedToAdShow(mContext)) {
            BannerHelper.load((AdView) findViewById(R.id.ad_view));
    }
    */
    var adView: AdView? = null
    private const val TAG = "Ads_Ads"
    fun load(adVieww: AdView?) {
        try {
            val interstialAdId = AppIDs().getGoogleBanner()
            Log.d("InterstitialAds banner", "${interstialAdId}")

            adVieww?.adUnitId = interstialAdId
            adView = adVieww
            adView!!.adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.i(TAG, "onAdLoaded: Banner")
                    adView!!.visibility = View.VISIBLE
                }

                override fun onAdFailedToLoad(errorCode: Int) {
                    Log.i(
                        TAG,
                        "onAdFailedToLoad: Banner, Ad failed to load : $errorCode"
                    )
                    adView!!.loadAd(requestId)
                }
            }
            adView!!.loadAd(requestId)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Called when leaving the activity
     */
    fun onPause() {
        if (adView != null) {
            adView!!.pause()
        }
    }

    /**
     * Called when returning to the activity
     */
    fun onResume() {
        if (adView != null) {
            adView!!.resume()
        }
    }

    /**
     * Called before the activity is destroyed
     */
    fun onDestroy() {
        if (adView != null) {
            adView!!.destroy()
        }
    }
}
