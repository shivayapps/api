package com.text.art.fancy.creator.ads

import android.content.Context
import android.util.Log
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.ads.AdsHelper.isTest
import com.text.art.fancy.creator.ads.AdsHelper.requestId
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.scribble.animation.maker.video.effect.myadslibrary.utils.InternetConnection

class InterstitialAdHelper {
    private val TAG = "Ads_Ads"

    fun load(
        mContext: Context,
        adListener: onInterstitialAdListener?
    ): InterstitialAd? {

        try {
            if (!InternetConnection.checkConnection(mContext)) return null

            val interstitial = InterstitialAd(mContext)

            val interstialAdId = AppIDs().getGoogleInterstitial(0)

            interstitial.adUnitId = interstialAdId
            interstitial.loadAd(AdRequest.Builder().build())

            interstitial.adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.i(TAG, "onAdLoaded: InterstitialAd${interstitial.adUnitId}")

                    adListener?.onLoad()
                    // Code to be executed when an ad finishes loading.
                }

                override fun onAdFailedToLoad(errorCode: Int) {
                    Log.i(
                        TAG,
                        "onAdFailedToLoad: InterstitialAd, Ad failed to load : $errorCode"
                    )
                    adListener?.onFailed()
                    // Code to be executed when an ad request fails.
                }

                override fun onAdOpened() {
                    Log.i(TAG, "onAdOpened: InterstitialAd")
                    // Code to be executed when the ad is displayed.
                }

                override fun onAdLeftApplication() {
                    Log.i(TAG, "onAdLeftApplication: InterstitialAd")
                    // Code to be executed when the user has left the app.
                }

                override fun onAdClosed() {
                    Log.i(TAG, "onAdClosed: InterstitialAd")
                    adListener?.onClosed()
                    // Code to be executed when the interstitial ad is closed.
                }
            }
            return interstitial
        } catch (e: Exception) {
            Log.e(TAG, "load: $e")
        }
        return null
    }

    interface onInterstitialAdListener {
        fun onLoad()
        fun onFailed()
        fun onClosed()
    }

    companion object {
        // InterstitialAdHelper
/*

   // implement in your activity/fragment
            implements InterstitialAdHelper.onInterstitialAdListener

   // declare global variable
            private boolean isInterstitialAdLoaded = false;
            private InterstitialAd interstitial;


   // add/replace implemented methods

    @Override
    public void onLoad() {
        isInterstitialAdLoaded = true;
    }

    @Override
    public void onFailed() {
        isInterstitialAdLoaded = false;
        interstitial = InterstitialAdHelper.getInstance().load(mContext, this);
    }

    @Override
    public void onClosed() {
        isInterstitialAdLoaded = false;
        interstitial = InterstitialAdHelper.getInstance().load(mContext, this);

        // perform your action

    }

    //  load ad in oncreate method
            interstitial = InterstitialAdHelper.getInstance().load(mContext, this);


    // check if ad is loaded or not while want to show

    if (Share.isNeedToAdShow(mContext)) {
           if (isInterstitialAdLoaded) {
               interstitial.show();
           } else {
              // perform your action
           }
     }

    */
        var instance: InterstitialAdHelper? = null
            get() {
                if (field == null) {
                    synchronized(InterstitialAdHelper::class.java) {
                        if (field == null) {
                            field = InterstitialAdHelper()
                        }
                    }
                }
                return field
            }
            private set

    }
}
