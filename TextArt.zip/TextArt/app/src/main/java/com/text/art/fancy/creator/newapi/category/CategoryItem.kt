package com.text.art.fancy.creator.newapi.category

import com.text.art.fancy.creator.newapi.category.CategoryNew
import com.google.gson.annotations.SerializedName

data class CategoryItem(
    @SerializedName("id")
    var id: Int? = null,

    @SerializedName("category_new_id")
    var categoryNewId: Int? = null,

    @SerializedName("sub_category_new_id")
    var subCategoryNewId: Int? = null,

    @SerializedName("name")
    var name: String? = null,

    @SerializedName("size")
    var size: String? = null,

    @SerializedName("coin")
    var coin: Int? = null,

    @SerializedName("image_keywords")
    var imageKeywords: String? = null,

    @SerializedName("image")
    var image: String? = null,

    @SerializedName("thumb_image")
    var thumbImage: String? = null,

    @SerializedName("zip")
    var zip: String? = null,

    @SerializedName("video")
    var video: Any? = null,

    @SerializedName("audio")
    var audio: Any? = null,

    @SerializedName("position")
    var position: Int? = null,

    @SerializedName("is_premium")
    var isPremium: Int? = null,

    @SerializedName("is_image_video")
    var isImageVideo: Int? = null,

    @SerializedName("category_new")
    var categoryNew: CategoryNew? = null
)
