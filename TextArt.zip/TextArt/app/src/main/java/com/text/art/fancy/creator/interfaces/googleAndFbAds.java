package com.text.art.fancy.creator.interfaces;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;

public interface googleAndFbAds
{
    public void Ads(Ad ad, AdError adError);

    public void Adsnativesmall(Ad ad, AdError adError);

}
