package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.*
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.database.DBHelper
import com.text.art.fancy.creator.utils.*
import com.vasundhara.vision.subscription.constants.Constants.BASIC_SKU
import com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SIX_SKU
import com.vasundhara.vision.subscription.constants.Constants.PREMIUM_SKU
import com.vasundhara.vision.subscription.ui.BaseSubscriptionActivity
import kotlinx.android.synthetic.main.activity_subscription_new.*

class SubscriptionActivity : BaseSubscriptionActivity() {

    private var TAG = "SubscriptionActivity"
    lateinit var mSubscriptionToolbar: ConstraintLayout
    lateinit var mSubscriptionMainLayout: ConstraintLayout
    lateinit var imgBtnBack: ImageButton
    lateinit var mTVTermsCondition: TextView
    lateinit var mTVPrivacy: TextView
    lateinit var mB1Month: TextView
    lateinit var mBSubscription: TextView
    lateinit var mCL1Month: ConstraintLayout
    lateinit var mCL12Month: ConstraintLayout
    internal var dbHelper: DBHelper = DBHelper(this)
    private var lastClickTime = 0L

    var mGetString: HashMap<String, String> = HashMap()

    var mSelectedKey = PREMIUM_SKU

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (displayHeight() == 1776){ //TODO -> Manage Not Responsive Device [10Ore]
            setContentView(R.layout.activity_subscription_new_10ore)
        }else{
            setContentView(R.layout.activity_subscription_new)
        }

        initView()
        initListener()
        mSubscriptionMainLayout.invalidate()
//        try { mSubscriptionToolbar.setPadding(0, getStatusbarHeight(), 0, 0) } catch (e: Exception) { }
//        hideSystemUI()
        setStatusBarColor(ContextCompat.getColor(this,R.color.premiumTop))

        liveDataPriceMicro.observe(this, Observer {
            try {
//                val x = ((it[BASIC_SKU]!! / 1000000)).toInt()
//                val y = ((it[PREMIUM_SKU]!! / 1000000)).toInt()
//                val z = ((it[PREMIUM_SIX_SKU]!! / 1000000)).toInt()
                val x = 150
                val y = 350
                val z = 2800

                val save1m = (4 * x) - y
                val save1y = (48 * x) - z
                val per3Month = (save1m * 100) / (4 * x)
                val per1Year = (save1y * 100) / (48 * x)

                txt12PercentageOff.text = " Save $per1Year%"
                txt6PercentageOff.text  = " Save $per3Month%"

                txtINRPermonth.text = "${currencyCode.value} $x"
                txtINRPermonthCli.text = "${currencyCode.value} $x"

                txtInrPerMonth.text = "${currencyCode.value} $y"
                txtInrPerMonthClick.text = "${currencyCode.value} $y"

                txtInrPerMonths.text = "${currencyCode.value} ${(z)/12}"
                txtInrPerMonthsClick.text = "${currencyCode.value} ${(z)/12}"

                Log.d("Companion.TAG", "Subscription Price: BASIC_SKU $x")
                Log.d("Companion.TAG", "Subscription Price: PREMIUM_SIX $y")
                Log.d("Companion.TAG", "Subscription Price: PREMIUM_SKU $z")
                Log.d("Companion.TAG", "Subscription Price: per3Month $per3Month")
                Log.d("Companion.TAG", "Subscription Price: per1Year $per1Year")

            } catch (e: Exception) { }
        })

        liveDataPrice.observe(this, Observer {
            mB1MonthClick.text = it[BASIC_SKU]!!.replace("₹","₹ ").replace(".00","")
            mB6MonthClick.text = it[PREMIUM_SIX_SKU]!!.replace("₹","₹ ").replace(".00","")
            mB12MonthsClick.text = it[PREMIUM_SKU]!!.replace("₹","₹ ").replace(".00","")
            mB6Months.text = it[PREMIUM_SKU]
            mB1Month.text = it[BASIC_SKU]!!
            mB6Month.text = it[PREMIUM_SIX_SKU]

            Log.d(TAG, "onCreate: $")

            try {
                val x = ((it[BASIC_SKU]!!.toInt() / 1000000))
                val z = ((it[PREMIUM_SKU]!!.toInt() / 1000000))
                val y = ((it[PREMIUM_SIX_SKU]!!.toInt() / 1000000))

                val save1m = (4 * x) - y
                val save1y = (48 * x) - z
                val per3Month = (save1m * 100) / (4 * x)
                val per1Year = (save1y * 100) / (48 * x)

                txt12PercentageOff.text = " Save $per1Year%"
                txt6PercentageOff.text  = " Save $per3Month%"

                txtINRPermonth.text = "${currencyCode.value} $x"
                txtINRPermonthCli.text = "${currencyCode.value} $x"

                txtInrPerMonth.text = "${currencyCode.value} $y"
                txtInrPerMonthClick.text = "${currencyCode.value} $y"

                txtInrPerMonths.text = "${currencyCode.value} ${(z)/12}"
                txtInrPerMonthsClick.text = "${currencyCode.value} ${(z)/12}"

                Log.d("Companion.TAG", "Subscription Price: BASIC_SKU $x")
                Log.d("Companion.TAG", "Subscription Price: PREMIUM_SIX $y")
                Log.d("Companion.TAG", "Subscription Price: PREMIUM_SKU $z")
                Log.d("Companion.TAG", "Subscription Price: per3Month $per3Month")
                Log.d("Companion.TAG", "Subscription Price: per1Year $per1Year")

            } catch (e: Exception) { }

//            try {
//                txtINRPermonth.text = (subscriptionManager.getString(
//                    PreferencesKeys.CURRENCY_CODE,"INR") + " " + (((subscriptionManager.getLong(
//                    PreferencesKeys.MONTH_PRICE_MICRO,
//                    350000000
//                )) / 1000000))).toString()
//                txtINRPermonthCli.text = (subscriptionManager.getString(
//                    PreferencesKeys.CURRENCY_CODE,
//                    "INR"
//                ) + " " + (((subscriptionManager.getLong(
//                    PreferencesKeys.MONTH_PRICE_MICRO,
//                    350000000
//                )) / 1000000))).toString()
//            } catch (e: Exception) {
//                Log.d("txtInrPerMonthsClick", "txtInrPerMonthsClick: ${e.message}")
//            }
//            try {
//                txtInrPerMonthsClick.text = (subscriptionManager.getString(
//                    PreferencesKeys.CURRENCY_CODE,
//                    "INR"
//                ) + " " + (((subscriptionManager.getLong(
//                    PreferencesKeys.YEAR_PRICE_MICRO,
//                    1800000000
//                )) / 1000000) / 12)).toString()
//                txtInrPerMonths.text = (subscriptionManager.getString(
//                    PreferencesKeys.CURRENCY_CODE,
//                    "INR"
//                ) + " " + (((subscriptionManager.getLong(
//                    PreferencesKeys.YEAR_PRICE_MICRO,
//                    1800000000
//                )) / 1000000) / 12))
//                txt12PercentageOff.text = "Save" + " " + ((((subscriptionManager.getLong(
//                    PreferencesKeys.YEAR_PRICE_MICRO,
//                    1800000000
//                ) / 1000000) / 12) * 100).toInt() / (subscriptionManager.getLong(
//                    PreferencesKeys.MONTH_PRICE_MICRO,
//                    350000000
//                ) / 1000000).toInt()) + "%"
//            } catch (e: Exception) {
//                Log.d("txtInrPerMonthsClick", "txtInrPerMonthsClick: ${e.message}")
//            }
//            try {
//                txtInrPerMonth.text = (subscriptionManager.getString(
//                    PreferencesKeys.CURRENCY_CODE,
//                    "INR"
//                ) + " " + ((subscriptionManager.getLong(
//                    PreferencesKeys.MONTH_PRICE_MICRO,
//                    300000000
//                ) / 1000000) / 6)).toString()
//                txtInrPerMonthClick.text = (subscriptionManager.getString(
//                    PreferencesKeys.CURRENCY_CODE,
//                    "INR"
//                ) + " " + ((subscriptionManager.getLong(
//                    PreferencesKeys.YSIX_PRICE_MICRO,
//                    300000000
//                ) / 1000000) / 6)).toString()
//                txt6PercentageOff.text = "Save" + " " + ((((subscriptionManager.getLong(
//                    PreferencesKeys.YSIX_PRICE_MICRO,
//                    300000000
//                ) / 1000000) / 12) * 100).toInt() / (subscriptionManager.getLong(
//                    PreferencesKeys.MONTH_PRICE_MICRO,
//                    350000000
//                ) / 1000000).toInt()) + "%"
//            } catch (e: Exception) {
//                Log.d("txtInrPerMonthsClick", "txtInrPerMonthsClick: ${e.message}")
//            }
        })

        liveDataPeriod.observe(this, Observer {
            mGetString = it
        })
//        mCL12Month.performClick()
        set12Month()
    }

    override fun onPurchases(orderId: String, str: String, purchaseState: Int) {
        Log.e(TAG, "onPurchases: subscription orderId $orderId str $str")
        setSubscription()
        if (!com.text.art.fancy.creator.comman.Constants.buyFromAddTextActivity){
            setResult(1144)
        }
        finish()
    }

    private fun getTrial(trial: String): String? {
        return try {
            val size = trial.length
            val period = trial.substring(1, size - 1)
            val str = trial.substring(size - 1, size)
            Log.d(TAG, "getTrial: ${size} $period - $str")
            when (str) {
                "D"  -> "$period Days Free Trial"
                "M"  -> "$period Month Free Trial"
                "Y"  -> "$period Year Free Trial"
                else -> "$period Days Free Trial"
            }
        } catch (e: Exception) {
            "3 Days Free Trial"
        }
    }

    override fun onBackPressed() {
//        setSubscription()
//        if (!com.text.art.fancy.creator.comman.Constants.buyFromAddTextActivity){
//            setResult(1144)
//        }
        finish()
    }

    fun initView() {
        mSubscriptionMainLayout = findViewById(R.id.mSubscriptionMainLayout)
        mSubscriptionToolbar = findViewById(R.id.mSubscriptionToolbar)
        mBSubscription = findViewById(R.id.mBSubscription)
        imgBtnBack = findViewById(R.id.imgBtnBack)
        mB1Month = findViewById(R.id.mB1Month)
        mCL12Month = findViewById(R.id.mCL12Months)
        mCL1Month = findViewById(R.id.mCL1Month)
        mTVPrivacy = findViewById(R.id.mTVPrivacy)
        mTVTermsCondition = findViewById(R.id.mTVTermsCondition)
    }

    fun initListener() {
        imgBtnBack.setOnClickListener { v: View? -> finish() }

        mTVTermsCondition.setOnClickListener { }
        mTVPrivacy.setOnClickListener { }

        mTVTermsCondition.setOnClickListener {
            startActivity(
                Intent(
                    this@SubscriptionActivity,
                    TermsConditionActivity::class.java
                )
            )
        }
        mTVPrivacy.setOnClickListener {
            startActivity(
                Intent(
                    this@SubscriptionActivity,
                    PrivacyPolicyActivity::class.java
                )
            )
        }

        mCL1MonthClick.setOnClickListener {
            set1Month()
            mGetString[BASIC_SKU]?.let {
//                mTVTrail.text = getTrial(it)
            }
            mSelectedKey = BASIC_SKU
        }

        mCL1Month.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            set1Month()
            mGetString[BASIC_SKU]?.let {
//                mTVTrail.text = getTrial(it)
            }
            mSelectedKey = BASIC_SKU
            Handler(Looper.getMainLooper()).postDelayed({
//                mBSubscription.performClick()
                onWeekPlan()
            },50)
//            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/account/subscriptions?sku=$mSelectedKey&package=$packageName")))
        }

        mCL6Month.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            set6Month()
            mGetString[PREMIUM_SIX_SKU]?.let {
//                mTVTrail.text = getTrial(it)
            }
            mSelectedKey = PREMIUM_SIX_SKU
            Handler(Looper.getMainLooper()).postDelayed({
//                mBSubscription.performClick()
                onMonthPlan()
            },50)
        }

        mCL12Month.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1500) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            set12Month()
            mGetString[PREMIUM_SKU]?.let {
//                mTVTrail.text = getTrial(it)
            }
            mSelectedKey = PREMIUM_SKU
            Handler(Looper.getMainLooper()).postDelayed({
//                mBSubscription.performClick()
                onYearPlan()
            },50)
        }

        mBSubscription.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            Log.e(TAG, "initListener: clicked")
            if (mSelectedKey == PREMIUM_SKU) {
                onYearPlan()
                Log.i(TAG, "initListener: $mSelectedKey")
            } else if (mSelectedKey == PREMIUM_SIX_SKU) {
                onMonthPlan()
                Log.i(TAG, "initListener: $mSelectedKey")
            } else {
                onWeekPlan()
                Log.i(TAG, "initListener: $mSelectedKey")
            }
        }
    }


    fun setSubscription() {
        MySharedPreferences(this).isSubscribe = true
        val mFrameCounter = DBHelper(this).allFrameData.count
        for (i in 0..mFrameCounter) {
            DBHelper(this).updateFrameData(i.toString(), "0")
        }
        val mPatternCounter = DBHelper(this).allPatternData.count
        for (i in 0..mPatternCounter) {
            DBHelper(this).updatePatternData(i.toString(), "0")
        }
        val resultIntent = Intent()
        resultIntent.putExtra("isSubScribe", true)
        setResult(Activity.RESULT_OK,resultIntent)

    }

    fun set1Month() {
//        mB1Month.setTextColor(resources.getColor(R.color.white))
//        mB1Month.background = resources.getDrawable(R.drawable.bg_unlock_btn)
//        mCL1Month.background = resources.getDrawable(R.drawable.ic_select_sub_bg)
//        mB12Month.setTextColor(resources.getColor(R.color.black))
//        mB12Month.background = resources.getDrawable(R.drawable.bg_white_dialog_save)
//        mCL12Month.background = resources.getDrawable(R.drawable.ic_unselect_sub)
        mCL1MonthClick.visibility = View.VISIBLE
        mCL1Month.visibility = View.GONE
        mCL6MonthClick.visibility = View.GONE
        mCL6Month.visibility = View.VISIBLE
        mCL12MonthsClick.visibility = View.GONE
        mCL12Months.visibility = View.VISIBLE
//        imgSlabel.visibility = View.GONE
//        img12Off.visibility = View.GONE
        txt6PercentageOff.visibility = View.GONE
        txt12PercentageOff.visibility = View.GONE

    }

    fun set6Month() {
//        mB1Month.setTextColor(resources.getColor(R.color.white))
//        mB1Month.background = resources.getDrawable(R.drawable.bg_unlock_btn)
//        mCL1Month.background = resources.getDrawable(R.drawable.ic_select_sub_bg)
//        mB12Month.setTextColor(resources.getColor(R.color.black))
//        mB12Month.background = resources.getDrawable(R.drawable.bg_white_dialog_save)
//        mCL12Month.background = resources.getDrawable(R.drawable.ic_unselect_sub)
        mCL1MonthClick.visibility = View.GONE
        mCL1Month.visibility = View.VISIBLE
        mCL6MonthClick.visibility = View.VISIBLE
        mCL6Month.visibility = View.GONE
        mCL12MonthsClick.visibility = View.GONE
//        imgSlabel.visibility = View.VISIBLE
//        img12Off.visibility = View.GONE
        mCL12Months.visibility = View.VISIBLE
        txt6PercentageOff.visibility = View.VISIBLE
        txt12PercentageOff.visibility = View.GONE
    }

    fun set12Month() {

        mCL1MonthClick.visibility = View.GONE
        mCL1Month.visibility = View.VISIBLE
        mCL6MonthClick.visibility = View.GONE
        mCL6Month.visibility = View.VISIBLE
        mCL12MonthsClick.visibility = View.VISIBLE
        mCL12Months.visibility = View.GONE
        txt6PercentageOff.visibility = View.GONE
        txt12PercentageOff.visibility = View.VISIBLE
//        imgSlabel.visibility = View.GONE
//        img12Off.visibility = View.VISIBLE
//        mB12Month.setTextColor(resources.getColor(R.color.white))
//        mB12Month.background = resources.getDrawable(R.drawable.bg_unlock_btn)
//        mCL12Month.background = resources.getDrawable(R.drawable.ic_select_sub_bg)
//        mB1Month.setTextColor(resources.getColor(R.color.black))
//        mB1Month.background = resources.getDrawable(R.drawable.bg_white_dialog_save)
//        mCL1Month.background = resources.getDrawable(R.drawable.ic_unselect_sub)
    }
}