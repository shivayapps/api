package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.text.art.fancy.creator.bgapi.BGAdapter
import com.text.art.fancy.creator.bgapi.BGtDataFragment
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.HomeActivity.Companion.allCategory

import com.text.art.fancy.creator.categorys.ParametersItemAllChilds
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.newapi.model.SubCategory
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.utils.*
import com.google.android.material.tabs.TabLayout
import com.jaredrummler.android.colorpicker.ColorPickerDialog
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener
import com.vasu.image.video.pickrandom.galleryapp.VasuImagePicker
import kotlinx.android.synthetic.main.bottom_sheet.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import java.util.*
import kotlin.properties.Delegates

class BGActivity : AppCompatActivity(), BGtDataFragment.ItemClickListener {

    private var isConnected = false
    private val PICK_IMAGE_CODE = 102
    private var meterialTabLayout: TabLayout? = null
    private var icBack: ImageView? = null
    private var btnNone: ImageView? = null
    private var txtGallery: ConstraintLayout? = null
    private lateinit var constraintOffline: ConstraintLayout
    private lateinit var progressBar: ProgressBar
    private var btnHeaderText: TextView? = null
    private var txtColor: ConstraintLayout? = null
    private var imageShare: ImageView? = null
//    private var viewPagerCard: ViewPager? = null
    private var viewPagerCard: ViewPager2? = null
    private var mTermsToolbar: ConstraintLayout? = null
    var mIsSubScribe: Boolean = false
    var selectedURL: String = ""

    private var receiver: Receiver? = null
    var mySharedPref: MySharedPref? = null


    private var categoryList = arrayListOf<SubCategory>()
    private var total by Delegates.notNull<Int>()


    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (isOnline()) {
//                constraintOffline.hide()
//                if (isBGDataLoaded){
//                    setData()
//                }else{
////                    callBGApi()
//                    callNewBGApi()
//                }
                Log.d(TAG, "onReceive: data size ${categoryList.size}")
                if (categoryList.size == 0){
                    Log.d(TAG, "onReceive: data size categoryList.size == 0")
                    callNewBGApi()
                }else{
                    setNewData()
                }
            } else {
                constainMain.hide()
                constraintOffline.show()
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.bottom_sheet)
        /*Thread.setDefaultUncaughtExceptionHandler { paramThread, paramThrowable ->
            Log.d(TAG, "onCreate: Error MainThread $paramThread $paramThrowable")
            exitProcess(2)
        }*/

        //init Receiver
        try {
            receiver = Receiver()
            registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
        } catch (e: Exception) { }

        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        mySharedPref = MySharedPref(this@BGActivity)
        hideSystemUI()
        mTermsToolbar = findViewById<ConstraintLayout>(R.id.mTermsToolbar)
        meterialTabLayout = findViewById<TabLayout>(R.id.meterialTabLayout)
        btnHeaderText = findViewById<TextView>(R.id.btnHeaderText)
        btnNone = findViewById<ImageView>(R.id.btnNone)
        imageShare = findViewById<ImageView>(R.id.imageShare)
        txtGallery = findViewById<ConstraintLayout>(R.id.txtGallery)
        constraintOffline = findViewById<ConstraintLayout>(R.id.constraintOffline)
        progressBar = findViewById<ProgressBar>(R.id.progressBar)
        txtColor = findViewById<ConstraintLayout>(R.id.txtColor)
        icBack = findViewById<ImageView>(R.id.icBack)
        viewPagerCard = findViewById<ViewPager2>(R.id.viewPagerCard)
        try {
            btnHeaderText!!.text = "Background"
        } catch (e: Exception) { }
        if (!mIsSubScribe) {
//            NativeAdvanceHelper.loadNativeSmall(this, findViewById(R.id.my_template));
            NativeAdvancedModelHelper(this@BGActivity).loadNativeAdvancedAd(NativeAdsSize.Medium,findViewById(R.id.my_template))
        }

        viewPagerCard?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }
            override fun onPageSelected(position: Int) {

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

        bindCallbacks()
        bindAction()
        /*viewPagerCard!!.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                    position: Int,
                    positionOffset: Float,
                    positionOffsetPixels: Int
            ) {
                mPosition = position
                Log.d(TAG, "onPageScrolled: $position")
            }

            override fun onPageSelected(position: Int) {
                Log.d(TAG, "onPageSelected: $position")
            }

            override fun onPageScrollStateChanged(state: Int) {
                Log.d(TAG, "onPageScrollStateChanged: $state")
            }
        })*/
        icBack!!.setOnClickListener {
            try {
                onBackPressed()
            } catch (e: Exception) {
            }
        }
        txtGallery!!.setOnClickListener {
            choosePatternImageFromGallery()
        }
        txtColor!!.setOnClickListener {
            val colorPickerDialog =
                ColorPickerDialog.newBuilder().setDialogType(ColorPickerDialog.TYPE_PRESETS)
                    .setAllowPresets(false)
                    .setDialogId(0)
                    .setShowAlphaSlider(true)
                    .setColor(Constants.mSelectedColorPos)
                    .create()

            colorPickerDialog!!.setColorPickerDialogListener(object : ColorPickerDialogListener {
                override fun onColorSelected(dialogId: Int, color: Int) {
                    Constants.mSelectedColorPos = color
                    val intent = Intent()
                    intent.putExtra("colorPicker", color)
                    setResult(2221, intent)
                    finish()
                }

                override fun onDialogDismissed(dialogId: Int) {}

            })
            colorPickerDialog.show(supportFragmentManager, "ColorPicker")

        }
        btnNone!!.setOnClickListener {
            Constants.mSelectedColorPos = -1
            onBGItemClick("", 0)
//            onBGItemClick("", 0)
            //startActivity(Intent(this, SubscriptionActivity::class.java))
        }
        imageShare!!.setOnClickListener {
            try {
                val shareIntent =
                        Intent(Intent.ACTION_SEND)
                shareIntent.type = "text/plain"
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Text Art")
                var shareMessage = "\nGo with TextArt and make beautiful text image.\n\n"
                shareMessage =
                        shareMessage + "https://play.google.com/store/apps/details?id=" + packageName + "\n\n"
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivity(Intent.createChooser(shareIntent, "choose one"))
            } catch (e: java.lang.Exception) { //e.toString();
            }
        }
//        callBGApi()

    }

    private fun choosePatternImageFromGallery() {

        /*ImagePicker.with(this, 3)
                .setFolderMode(true)
                .setFolderTitle("Gallery")
                .setMultipleMode(false)
                .setImageCount(1)
                .setMaxSize(10)
                .setBackgroundColor("#FFFFFF")
                .setToolbarColor("#0D4A57")
                .setAlwaysShowDoneButton(true)
                .setRequestCode(5252)
                .setKeepScreenOn(true)
                .start()*/

        VasuImagePicker.ActivityBuilder(this)
            .setFolderMode(true)
            .setFolderTitle("Gallery")
            .setMultipleMode(false)
            .setImageCount(1)
            .setMaxSize(10)
            .setBackgroundColor("#FFFFFF")
            .setToolbarColor("#FFFFFF")
            .setToolbarTextColor("#000000")
            .setToolbarIconColor("#000000")
            .setStatusBarColor("#FFFFFF")
            .setProgressBarColor("#50b1ed")
            .setAlwaysShowDoneButton(true)
            .setRequestCode(PICK_IMAGE_CODE)
            .setKeepScreenOn(true)
            .start()

    }

    override fun onDestroy() {
        super.onDestroy()
        categoryList.clear()
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_CODE && data != null && resultCode == RESULT_OK) {
            val imagePath = data.getStringExtra("EXTRA_SELECTED_URI")
            if (imagePath == "") {
                return
            }

            if (!mIsSubScribe) {
                isShowInterstitialAd() {
                    Log.d(TAG, "onActivityResult: load")
                    onBGItemClick(Uri.parse(imagePath).toString(), 0)
                }
            } else {
                Log.d(TAG, "onActivityResult: fail")
                onBGItemClick(Uri.parse(imagePath).toString(), 0)
//              bgAllArray[param].categoryParameters!![position].id
            }

        }
    }

    override fun onResume() {
        super.onResume()
        try {
            mIsSubScribe = MySharedPreferences(
                this
            ).isSubscribe
            if (mIsSubScribe) {
                findViewById<FrameLayout>(R.id.my_template).visibility = View.GONE
            }
        } catch (e: Exception) {
        }
    }

    private fun setData() {
        progressBar.hide()
        constraintOffline.hide()
        constainMain.show()

//        val fontPagerAdepter = BGPagerAdepter(
//            supportFragmentManager,
//            bgAllArray,
//            mIsSubScribe,
//            this@BGActivity
//        )
//        viewPagerCard!!.adapter = fontPagerAdepter
//        meterialTabLayout!!.setupWithViewPager(viewPagerCard)
//        bgAllArray.filterIndexed { index, categoryParametersItem ->
//            if (categoryParametersItem.name != "") {
//                try {
//                    val view1 = LayoutInflater.from(this@BGActivity).inflate(R.layout.rv_tab, null)
//                    meterialTabLayout!!.getTabAt(index)!!.customView = view1
//                    val textView = view1.findViewById<TextView>(R.id.textTab)
//                    textView.text = categoryParametersItem.name
//                    if (index == 0) {
//                        Constants.selectedBg = textView.text.toString()
//                        textView.setTextColor(Color.WHITE)
//                    } else {
//                        textView.setTextColor(Color.BLACK)
//                    }
//                } catch (e: Exception) { }
//            }
//            true
//        }
//        isBGDataLoaded = true
//
//        meterialTabLayout!!.setOnTabSelectedListener(object :
//            TabLayout.OnTabSelectedListener {
//            override fun onTabSelected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                tab.customView!!.findViewById<TextView>(R.id.textTab)
//                    .setTextColor(Color.WHITE)
//                Constants.selectedBg = "${meterialTabLayout!!.getTabAt(tab.position)!!.customView!!.findViewById<TextView>(R.id.textTab).text}"
//            }
//
//            override fun onTabUnselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                tab.customView!!.findViewById<TextView>(R.id.textTab).setTextColor(Color.BLACK)
//            }
//
//            override fun onTabReselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                tab.customView!!.findViewById<TextView>(R.id.textTab)
//                    .setTextColor(Color.WHITE)
//            }
//        })
//
//        viewPagerCard!!.currentItem = mPosition
    }

    private fun setNewData() {
        Log.d(TAG, "onReceive: data setNewData()")
        progressBar.hide()
        constraintOffline.hide()
        constainMain.show()

        val bgAdapter = BGAdapter(this, categoryList, total)
        viewPagerCard?.offscreenPageLimit = ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT
        viewPagerCard?.adapter = bgAdapter

        meterialTabLayout?.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                with(tab?.position!!){
                    viewPagerCard?.currentItem = this
                    tab.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.WHITE)
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                tab?.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.BLACK)
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }

        })

        viewPagerCard?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

            override fun onPageSelected(position: Int) {
                meterialTabLayout?.selectTab(meterialTabLayout?.getTabAt(position))
            }

            override fun onPageScrollStateChanged(state: Int) {}

        })

    }

    private fun callNewBGApi() {
        Log.d(TAG, "onReceive: data callNewBGApi()")
        progressBar.show()
        lifecycleScope.launch{
            withContext(Dispatchers.IO){
                if (allCategory.isEmpty()){
                    HomeActivity.callHomeApi(this@BGActivity)
                }
                Log.d(TAG, "onReceive: data Dispatchers.IO allCategory ${allCategory.size}")
                for (category in allCategory){
                    if (category.name.equals(TAG, ignoreCase = true)){
                        category.subCategory?.let {
                            withContext(Dispatchers.Main){
                                categoryId = category.id!!
                                total = it.size
                                for ((i, subCategory) in it.withIndex()){
                                    categoryList.add(subCategory)
                                    withContext(Dispatchers.Main){
                                        meterialTabLayout!!.addTab(meterialTabLayout!!.newTab().setText(subCategory.name))
                                        val view1 = LayoutInflater.from(this@BGActivity).inflate(R.layout.rv_tab, null)
                                        meterialTabLayout!!.getTabAt(i)!!.customView = view1
                                        val textView = view1.findViewById<TextView>(R.id.textTab)
                                        textView.text = subCategory.name
                                        if (i == 0) {
                                            Constants.selectedBg = textView.text.toString()
                                            textView.setTextColor(Color.WHITE)
                                        } else {
                                            textView.setTextColor(Color.BLACK)
                                        }
                                    }
                                }
                                Log.d(TAG, "onReceive: data total $total")
                            }
                        }
                        withContext(Dispatchers.Main){
                            setNewData()
                        }
                        break
                    }
                }
            }
        }
    }

    private fun callBGApi() {
        progressBar.visibility = View.VISIBLE

        val apiInterface = APIClient.getClient().create(APIInterface::class.java)
        val call = apiInterface.parameterList
        call.enqueue(object : Callback<Response> {
            override fun onResponse(
                call: Call<Response>,
                response: retrofit2.Response<Response>
            ) {
                if (response.isSuccessful && response.body()!!.parameters != null){
                    try {
                        response.body()!!.parameters.filterIndexed { _, parametersItem ->
                            if (parametersItem.name == "Background" || parametersItem.id == 439) {
                                bgAllArray.clear()
                                parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                    bgAllArray.add(categoryParametersItem)
                                    true
                                }
                            }
                            isBGDataLoaded = true
                            setData()
                            true
                        }
                    } catch (e: Exception) { }
                }else{
                    showToast(resources.getString(R.string.try_again_later))
                    finish()
                }
            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                showToast(resources.getString(R.string.try_again_later))
                finish()
            }
        })
    }

    companion object {
        private const val TAG = "Background"
        var isAdsIsFree = false
        var isBGDataLoaded = false
        var mPosition = 0
        var categoryId by Delegates.notNull<Int>()
        var bgAllArray: ArrayList<ParametersItemAllChilds> = ArrayList()
    }

    override fun onBGItemClick(string: String, id: Int) {
        Log.d(TAG, "showAdReward: BG onBGItemClick: id $id string $string ")
        selectedURL = string
        if (mySharedPref?.getApiAdsCount() == 2 && !mIsSubScribe && isAdsIsFree) {
            mySharedPref?.setApiAdsCount(0)
        } else {
            if (mySharedPref?.getApiAdsCount()!! > 2) {
                mySharedPref?.setApiAdsCount(0)
            }
            mySharedPref?.setApiAdsCount(mySharedPref?.getApiAdsCount()!! + 1)
            Handler(Looper.getMainLooper()).postDelayed({
                Constants.bgId = id
                Log.d(TAG, "onBGItemClick: ${Constants.selectedBg}_$id")
//                showToast("${Constants.selectedBg}_$id")
                val intent = Intent()
                intent.putExtra("bgImagePath", selectedURL)
                setResult(2323, intent)
                finish()
            }, 50)
        }

    }


    fun bindCallbacks() {
        val connectionLiveData = ConnectionLiveData(this)
        connectionLiveData.observe(this) { isConnected ->
            isConnected?.let {
                this.isConnected = it
                if (it) {
                    if (!isOnline()) {
                        showToast("Please connect internet")
                        finish()
                    }
                } else {
                    showToast("Please connect internet")
                    finish()
                }
            }
        }
    }

    fun bindAction() {

    }

}