package com.text.art.fancy.creator.utils

class NativeHelper {

//    companion object{
//        init {
//            System.loadLibrary("advance-native-lib");
//        }
//    }

    fun getBaseUrl() : String {
        return "http://165.22.219.93/auto-wallpaper-changer/api/"
    }
    fun getTestUrl() : String {
        return "https://textart.kriadl.com/api/"
    }

    fun getZipUrl() : String {
        return "http://165.22.219.93/Solid%20Color%20Fonts.zip"
    }

    fun getAppBaseUrl() : String {
        return "http://165.22.219.93/auto-wallpaper-changer/api/"
    }

}