package com.text.art.fancy.creator.adepter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.model.PhotoModel
import com.text.art.fancy.creator.R
import com.google.android.gms.ads.formats.UnifiedNativeAd
import com.google.android.gms.ads.formats.UnifiedNativeAdView
import kotlinx.android.synthetic.main.my_photo_header_row.view.*
import java.util.*

class MyPhotoAdapter(
        var context: Context,
        var al_my_photos: ArrayList<PhotoModel>,
        val onClickImage: (Int,String) -> Unit,
        val onShow: (Int) -> Unit,
        val showLongClick: (() -> Unit)? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var isShowLong: Boolean = false


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        val v = LayoutInflater.from(parent.context).inflate(R.layout.my_photo_header_row, parent, false)
        v.tag = "date"
        return ViewHolder(v)
        /*  else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.my_photo_adapter, parent, false)
            view.tag = "image"
            ViewHolder(view)
        }*/
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, i: Int) {
            val holder = viewHolder as ViewHolder
            holder.itemView.txtDate?.text = al_my_photos[i].date

            if (isShowLong) {
                holder.itemView.cbSelectAllDate.visibility = View.VISIBLE
            } else {
                holder.itemView.cbSelectAllDate.visibility = View.GONE
            }

            if (al_my_photos[i].isSelect) {
                holder.itemView.cbSelectAllDate.isChecked = al_my_photos[i].isSelect
            } else {
                holder.itemView.cbSelectAllDate.isChecked = false
            }

            holder.itemView.imageView17.setOnClickListener {
                onShow(i)
            }

            holder.itemView.rvPhotoList.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
            holder.itemView.rvPhotoList.layoutManager = GridLayoutManager(context, 3)
            holder.itemView.rvPhotoList.itemAnimator = DefaultItemAnimator()
            val photoAdepter = PhotoAdepter(context, al_my_photos[i].strings!!, {
                onClickImage(i,al_my_photos[i].strings!![it].path)
            }, {

                al_my_photos[i].isSelect = al_my_photos!![i].strings!!.filter { it.isSelect }.size == al_my_photos!![i].strings!!.size

                isShowLong = true
                showLongClick?.let {
                    it()
                }
                notifyDataSetChanged()
            }, {
                Log.d(TAG, "Click $it")
                holder.itemView.cbSelectAllDate.isChecked = it
            }, isShowLong)
            holder.itemView.rvPhotoList.rvPhotoList.adapter = photoAdepter


            holder.itemView.cbSelectAllDate.setOnClickListener {
                holder.itemView.cbSelectAllDate.isChecked = holder.itemView.cbSelectAllDate.isChecked
                al_my_photos[i].isSelect = holder.itemView.cbSelectAllDate.isChecked
                al_my_photos[i].strings!!.mapNotNull {
                    it.isSelect = al_my_photos[i].isSelect
                }
                photoAdepter.notifyDataSetChanged()
            }

    }

    private fun populateNativeAdView(nativeAd: UnifiedNativeAd,
                                     adView: UnifiedNativeAdView) { // Some assets are guaranteed to be in every UnifiedNativeAd.
        (adView.headlineView as TextView).text = nativeAd.headline
        (adView.bodyView as TextView).text = nativeAd.body
        (adView.callToActionView as Button).text = nativeAd.callToAction
        // These assets aren't guaranteed to be in every UnifiedNativeAd, so it's important to
// check before trying to display them.
        val icon = nativeAd.icon
        if (icon == null) {
            adView.iconView.visibility = View.INVISIBLE
        } else {
            (adView.iconView as ImageView).setImageDrawable(icon.drawable)
            adView.iconView.visibility = View.VISIBLE
        }
        if (nativeAd.price == null) {
            adView.priceView.visibility = View.INVISIBLE
        } else {
            adView.priceView.visibility = View.VISIBLE
            (adView.priceView as TextView).text = nativeAd.price
        }
        if (nativeAd.store == null) {
            adView.storeView.visibility = View.INVISIBLE
        } else {
            adView.storeView.visibility = View.VISIBLE
            (adView.storeView as TextView).text = nativeAd.store
        }
        if (nativeAd.starRating == null) {
            adView.starRatingView.visibility = View.INVISIBLE
        } else {
            (adView.starRatingView as RatingBar).rating = nativeAd.starRating.toFloat()
            adView.starRatingView.visibility = View.VISIBLE
        }
        if (nativeAd.advertiser == null) {
            adView.advertiserView.visibility = View.INVISIBLE
        } else {
            (adView.advertiserView as TextView).text = nativeAd.advertiser
            adView.advertiserView.visibility = View.VISIBLE
        }
        // Assign native ad object to the native view.
        adView.setNativeAd(nativeAd)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    inner class NativeAdHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var frameLayout: FrameLayout

        init {
            frameLayout = itemView.findViewById(R.id.fl_adplaceholder)
        }
    }


    override fun getItemCount(): Int {
        return al_my_photos.size
    }

    interface OnClickImage {
        fun onClick(i: Int)
    }


    companion object {
        private const val TAG = "MyPhotosAdapter"
        const val SHOW_DATE = 1
        const val SHOW_IMAGE = 2
        const val SHOW_ADS = 3
    }


}