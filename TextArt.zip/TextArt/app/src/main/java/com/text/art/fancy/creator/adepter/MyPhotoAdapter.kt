package com.text.art.fancy.creator.adepter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.model.PhotoModel
import com.text.art.fancy.creator.R

import kotlinx.android.synthetic.main.my_photo_header_row.view.*
import java.util.*

class MyPhotoAdapter(
        var context: Context,
        var al_my_photos: ArrayList<PhotoModel>,
        val onClickImage: (Int,String) -> Unit,
        val onShow: (Int) -> Unit,
        val showLongClick: (() -> Unit)? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var isShowLong: Boolean = false


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        val v = LayoutInflater.from(parent.context).inflate(R.layout.my_photo_header_row, parent, false)
        v.tag = "date"
        return ViewHolder(v)
        /*  else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.my_photo_adapter, parent, false)
            view.tag = "image"
            ViewHolder(view)
        }*/
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, i: Int) {
            val holder = viewHolder as ViewHolder
            holder.itemView.txtDate?.text = al_my_photos[i].date

            if (isShowLong) {
                holder.itemView.cbSelectAllDate.visibility = View.VISIBLE
            } else {
                holder.itemView.cbSelectAllDate.visibility = View.GONE
            }

            if (al_my_photos[i].isSelect) {
                holder.itemView.cbSelectAllDate.isChecked = al_my_photos[i].isSelect
            } else {
                holder.itemView.cbSelectAllDate.isChecked = false
            }

            holder.itemView.imageView17.setOnClickListener {
                onShow(i)
            }

            holder.itemView.rvPhotoList.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
            holder.itemView.rvPhotoList.layoutManager = GridLayoutManager(context, 3)
            holder.itemView.rvPhotoList.itemAnimator = DefaultItemAnimator()
            val photoAdepter = PhotoAdepter(context, al_my_photos[i].strings!!, {
                onClickImage(i,al_my_photos[i].strings!![it].path)
            }, {

                al_my_photos[i].isSelect = al_my_photos!![i].strings!!.filter { it.isSelect }.size == al_my_photos!![i].strings!!.size

                isShowLong = true
                showLongClick?.let {
                    it()
                }
                notifyDataSetChanged()
            }, {
                Log.d(TAG, "Click $it")
                holder.itemView.cbSelectAllDate.isChecked = it
            }, isShowLong)
            holder.itemView.rvPhotoList.rvPhotoList.adapter = photoAdepter


            holder.itemView.cbSelectAllDate.setOnClickListener {
                holder.itemView.cbSelectAllDate.isChecked = holder.itemView.cbSelectAllDate.isChecked
                al_my_photos[i].isSelect = holder.itemView.cbSelectAllDate.isChecked
                al_my_photos[i].strings!!.mapNotNull {
                    it.isSelect = al_my_photos[i].isSelect
                }
                photoAdepter.notifyDataSetChanged()
            }

    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    inner class NativeAdHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var frameLayout: FrameLayout

        init {
            frameLayout = itemView.findViewById(R.id.fl_adplaceholder)
        }
    }


    override fun getItemCount(): Int {
        return al_my_photos.size
    }

    interface OnClickImage {
        fun onClick(i: Int)
    }


    companion object {
        private const val TAG = "MyPhotosAdapter"
        const val SHOW_DATE = 1
        const val SHOW_IMAGE = 2
        const val SHOW_ADS = 3
    }


}