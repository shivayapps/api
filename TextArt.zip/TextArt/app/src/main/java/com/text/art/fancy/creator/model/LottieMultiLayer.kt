package com.text.art.fancy.creator.model

data class LottieMultiLayer(var TYPE: String, var displayText: String, var layerText: String)
