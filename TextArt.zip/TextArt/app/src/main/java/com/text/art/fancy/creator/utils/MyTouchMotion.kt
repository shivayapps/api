package com.text.art.fancy.creator.utils

import android.content.Context
import android.graphics.Rect
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import com.text.art.fancy.creator.activitys.AddTextActivity1
import com.text.art.fancy.creator.activitys.AddTextActivity1.Companion.CENTER_X
import com.text.art.fancy.creator.activitys.AddTextActivity1.Companion.CENTER_X1
import com.text.art.fancy.creator.activitys.AddTextActivity1.Companion.CENTER_X2
import com.text.art.fancy.creator.activitys.AddTextActivity1.Companion.CENTER_Y
import com.text.art.fancy.creator.activitys.AddTextActivity1.Companion.CENTER_Y1
import com.text.art.fancy.creator.activitys.AddTextActivity1.Companion.CENTER_Y2
import com.text.art.fancy.creator.activitys.AddTextActivity1.Companion.mContainer
import com.text.art.fancy.creator.lottievideorendering.utils.VideoSizeHelper
import kotlin.math.max
import kotlin.math.min

public class MyTouchMotion : View.OnTouchListener {
    private var mContext: Context? = null
    var isRotateEnabled = true
    var isScaleEnabled = true
    var isTranslateEnabled = true

    var maximumScale = 10.0f
    var minimumScale = 0.5f
    var shouldClick = true
    private var tag: String? = null
    private var txtValue: String? = null
    private var type: String? = null
    var _xDelta = 0
    var _yDelta = 0
    var centerX = 0F
    var centerY = 0F
    var newX = 0F
    var newY = 0F
    var min = -50.0
    var max = 30.0
//    var min = -100.0
//    var max = 60.0
    var horizontal = false
    var vertical = false
    var horizontal1 = false
    var vertical1 = false
    var horizontal2 = false
    var vertical2 = false
    var allowChange = true

    interface CallBackCutom {
        fun onSelected()
        fun onUnSelected()
    }

    constructor() {}

    constructor(context: Context?, str: String?, txtValue: String?) {
        tag = str
        this.txtValue = txtValue
        mContext = context
    }

    constructor(
        mContext: Context?,
        tag: String?,
        txtValue: String?,
        type: String?,
        mSetTransform: SetTransform,
        centerX: Float = 0F,
        centerY: Float = 0F
    ) {
        this.mContext = mContext
        this.tag = tag
        this.txtValue = txtValue
        this.type = type
        this.centerX = centerX
        this.centerY = centerY
        MyTouchMotion.mSetTransform = mSetTransform
    }

    override fun onTouch(view: View, motionEvent: MotionEvent): Boolean {
        mDetectorMotion.onTouchEvent(view, motionEvent)
        if (!isTranslateEnabled) {
            Log.d(TAG, "onTouch: isTranslateEnabled false")
            return true
        }
        val viewRect = Rect()
        view.getGlobalVisibleRect(viewRect)
        val X = motionEvent.rawX.toInt()
        val Y = motionEvent.rawY.toInt()
        val action = motionEvent.action
        val actionMasked = motionEvent.actionMasked and action
        var i = 0
        Log.d(TAG, "onTouch: actionMasked 1212 $X $Y")
        if (actionMasked == 0) {
            shouldClick = true
            mPrevX = motionEvent.x
            mPrevY = motionEvent.y
            val lParams = view.layoutParams as ViewGroup.LayoutParams
            _xDelta = X - lParams.width
            _yDelta = Y - lParams.height
            mActivePointerId = motionEvent.getPointerId(0)
            val context = mContext
            if (context is AddTextActivity1) {
//                context.setStickerSelectedByTag(tag!!, txtValue!!)
            }
            Log.d(TAG, "onTouch: actionMasked == 0")
            val point = IntArray(2)
            view.getLocationOnScreen(point)
            val (x, y) = point
//            ((AddTextActivity1) this.mContext).invisibleeditlayouts(true);
//            ((AddTextActivity1) this.mContext).selectedViewBackground((View) null);
//            ((AddTextActivity1) this.mContext).showSelectedRecycle((View) null);

        } else if (actionMasked == 1) {
            if (shouldClick) {
                view.performClick()
            }
            mActivePointerId = -1

            /*if (type.equals("LottieSticker")){
                mSetTransform!!.setTransform(view)
            }*/
            Log.d(TAG, "onTouch: actionMasked == 1")
            Log.d(TAG, "onTouch: centerX $centerX centerY $centerY")
            isPressIcon = false
            mSetTransform!!.showGrid(horGrid = false, verGrid = false, isPointerUp = true)
//            mSetTransform!!.showGrid1(horGrid = false, verGrid = false, isPointerUp = true)
//            mSetTransform!!.showGrid2(horGrid = false, verGrid = false, isPointerUp = true)
            mSetTransform!!.stickerClicked(view.translationX,view.translationY)
        } else if (actionMasked == 2) {
            shouldClick = false
            val findPointerIndex = motionEvent.findPointerIndex(mActivePointerId)
            if (findPointerIndex != -1) {
                /*if (!viewRect.contains(
                        (motionEvent.rawX).roundToInt(),
                        (motionEvent.rawY).roundToInt()
                    )
                ) {
                    return true
                }*/

                val x = motionEvent.getX(findPointerIndex)
                val y = motionEvent.getY(findPointerIndex)
                if (!mDetectorMotion.isInProgress) {
//                    adjustTranslation(view, x - mPrevX, y - mPrevY)
                    //try
                    val centerX = VideoSizeHelper.getCenterX(mContainer, view)
                    val centerY = VideoSizeHelper.getCenterY(mContainer, view)
                    newX = x - mPrevX
                    newY = y - mPrevY
                    when {
                        (centerX in CENTER_X..CENTER_Y) && (centerY in CENTER_X..CENTER_Y) -> {
                            mSetTransform!!.showGrid(horGrid = true, verGrid = true)
                            adjustTranslation(view, 0F, 0F)
//                            newX = x - mPrevX
//                            newY = y - mPrevY
//                            horizontal = true
//                            vertical = true
                            if (newX !in min..max || newY !in min..max) {
                                Log.d(TAG, "onTouch: if newX $newX newY $newY  x$x y$y")
                                Log.d(TAG, "onTouch: if mPrevX $mPrevX mPrevY $mPrevY  x$x y$y")
                                when {
                                    horizontal -> {
                                        adjustTranslation(view, x - mPrevX, 0F)
                                        Log.d(TAG, "onTouch: adjustTranslation X ${x - mPrevX}")
                                    }
                                    vertical -> {
                                        adjustTranslation(view, 0F, y - mPrevY)
                                        Log.d(TAG, "onTouch: adjustTranslation Y ${y - mPrevY}")
                                    }
                                    else -> {
                                        adjustTranslation(view, x - mPrevX, y - mPrevY)
                                        horizontal = false
                                        vertical = false
                                    }
                                }
                            }
                        }

                        //Grid
                        centerY in CENTER_X..CENTER_Y -> {
                            mSetTransform!!.showGrid(horGrid = true, verGrid = false)
                            adjustTranslation(view, x - mPrevX, 0F)
                            horizontal = true
                            if (newY !in min..max)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)
                        }
                        centerX in CENTER_X..CENTER_Y -> {
                            mSetTransform!!.showGrid(horGrid = false, verGrid = true)
                            adjustTranslation(view, 0F, y - mPrevY)
                            vertical = true
                            if (newX !in min..max)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)

                            Log.d(TAG, "onTouch: old val f = ${x - mPrevX} new val f2 = ${y - mPrevY}")
                        }

                        //Grid1
                        (centerX in CENTER_X1..CENTER_Y1) && (centerY in CENTER_X1..CENTER_Y1) -> {
                            mSetTransform!!.showGrid1(horGrid = true, verGrid = true)
                            adjustTranslation(view, 0F, 0F)
//                            newX = x - mPrevX
//                            newY = y - mPrevY
//                            horizontal = true
//                            vertical = true
                            if (newX !in min..max || newY !in min..max) {
                                Log.d(TAG, "onTouch: if newX $newX newY $newY  x$x y$y")
                                Log.d(TAG, "onTouch: if mPrevX $mPrevX mPrevY $mPrevY  x$x y$y")
                                when {
                                    horizontal -> {
                                        adjustTranslation(view, x - mPrevX, 0F)
                                        Log.d(TAG, "onTouch: adjustTranslation X ${x - mPrevX}")
                                    }
                                    vertical -> {
                                        adjustTranslation(view, 0F, y - mPrevY)
                                        Log.d(TAG, "onTouch: adjustTranslation Y ${y - mPrevY}")
                                    }
                                    else -> {
                                        adjustTranslation(view, x - mPrevX, y - mPrevY)
                                        horizontal1 = false
                                        vertical1 = false
                                    }
                                }
                            }
                        }
                        centerY in CENTER_X1..CENTER_Y1 -> {
                            mSetTransform!!.showGrid1(horGrid = true, verGrid = false)
                            adjustTranslation(view, x - mPrevX, 0F)
                            horizontal1 = true
                            if (newY !in min..max)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)
                        }
                        centerX in CENTER_X1..CENTER_Y1 -> {
                            mSetTransform!!.showGrid1(horGrid = false, verGrid = true)
                            adjustTranslation(view, 0F, y - mPrevY)
                            vertical1 = true
                            if (newX !in min..max)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)

                            Log.d(TAG, "onTouch: old val f = ${x - mPrevX} new val f2 = ${y - mPrevY}")
                        }

                        //Grid2
                        (centerX in CENTER_X2..CENTER_Y2) && (centerY in CENTER_X2..CENTER_Y2) -> {
                            mSetTransform!!.showGrid2(horGrid = true, verGrid = true)
                            adjustTranslation(view, 0F, 0F)
//                            newX = x - mPrevX
//                            newY = y - mPrevY
//                            horizontal = true
//                            vertical = true
                            if (newX !in min..max || newY !in min..max) {
                                Log.d(TAG, "onTouch: if newX $newX newY $newY  x$x y$y")
                                Log.d(TAG, "onTouch: if mPrevX $mPrevX mPrevY $mPrevY  x$x y$y")
                                when {
                                    horizontal2 -> {
                                        adjustTranslation(view, x - mPrevX, 0F)
                                        Log.d(TAG, "onTouch: adjustTranslation X ${x - mPrevX}")
                                    }
                                    vertical2 -> {
                                        adjustTranslation(view, 0F, y - mPrevY)
                                        Log.d(TAG, "onTouch: adjustTranslation Y ${y - mPrevY}")
                                    }
                                    else -> {
                                        adjustTranslation(view, x - mPrevX, y - mPrevY)
                                        horizontal2 = false
                                        vertical2 = false
                                    }
                                }
                            }
                        }
                        centerY in CENTER_X2..CENTER_Y2 -> {
                            mSetTransform!!.showGrid2(horGrid = true, verGrid = false)
                            adjustTranslation(view, x - mPrevX, 0F)
                            horizontal2 = true
                            if (newY !in min..max)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)
                        }
                        centerX in CENTER_X2..CENTER_Y2 -> {
                            mSetTransform!!.showGrid2(horGrid = false, verGrid = true)
                            adjustTranslation(view, 0F, y - mPrevY)
                            vertical2 = true
                            if (newX !in min..max)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)

                            Log.d(TAG, "onTouch: old val f = ${x - mPrevX} new val f2 = ${y - mPrevY}")
                        }

                        else -> {
                            Log.d(TAG, "onTouch: OnTouch 1 Else")
                            /*if (horizontal && vertical){
                                when {
                                    centerX in CENTER_X..CENTER_Y -> {
                                        mSetTransform!!.showGrid(horGrid = false, verGrid = true)
                                        adjustTranslation(view, 0F, y - mPrevY)
                                        Log.d(TAG, "onTouch: OnTouch 1 Else centerX")
                                    }
                                    centerY in CENTER_X..CENTER_Y -> {
                                        mSetTransform!!.showGrid(horGrid = true, verGrid = false)
                                        adjustTranslation(view, x - mPrevX, 0F)
                                        Log.d(TAG, "onTouch: OnTouch 1 Else centerY")
                                    }
                                    else -> {
                                        mSetTransform!!.showGrid(horGrid = false, verGrid = false)
                                        adjustTranslation(view, x - mPrevX, y - mPrevY)
                                        horizontal = false
                                        vertical = false
                                        Log.d(TAG, "onTouch: OnTouch 1 Else Else")
                                    }
                                }
                            }else{
                                mSetTransform!!.showGrid(horGrid = false, verGrid = false)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)
                                horizontal = false
                                vertical = false
                                Log.d(TAG, "onTouch: OnTouch 1 Else Last One")
                            }*/

                            /*if (newX in min..max){
                                mSetTransform!!.showGrid(horGrid = false, verGrid = true)
                                adjustTranslation(view, 0F, y - mPrevY)
                            }else if (newY in min..max){
                                mSetTransform!!.showGrid(horGrid = true, verGrid = false)
                                adjustTranslation(view, x - mPrevX, 0F)
                            }else{
                                mSetTransform!!.showGrid(horGrid = false, verGrid = false)
                                adjustTranslation(view, x - mPrevX, y - mPrevY)
                                horizontal = false
                                vertical = false
                            }*/

                            mSetTransform!!.showGrid(horGrid = false, verGrid = false)
                            mSetTransform!!.showGrid1(horGrid = false, verGrid = false)
                            mSetTransform!!.showGrid2(horGrid = false, verGrid = false)
                            adjustTranslation(view, x - mPrevX, y - mPrevY)
                            horizontal  = false
                            vertical    = false
//                            horizontal1 = false
//                            vertical1   = false
//                            horizontal2 = false
//                            vertical2   = false

                        }
                    }
                    Log.d(TAG, "onTouch: newX $newX newY $newY  x$x y$y")
                    Log.d(TAG, "onTouch: mPrevX $mPrevX mPrevY $mPrevY  x$x y$y")
                    Log.d(TAG, "onTouch: x ${x - mPrevX} y ${y - mPrevY}  ")
                }

                /*if (isPressIcon) {
                    val layoutParams = view?.layoutParams as ViewGroup.LayoutParams
                    layoutParams.width = X - _xDelta
                    layoutParams.height = Y - _yDelta
                    view.layoutParams = layoutParams
                }*/
            }

        } else if (actionMasked == 3) {
            mActivePointerId = -1
            Log.d(TAG, "onTouch: actionMasked == 3")

        } else if (actionMasked == 6) {
            Log.d(TAG, "onTouch: actionMasked == 6")
            val i2 = 65280 and action shr 8
            if (motionEvent.getPointerId(i2) == mActivePointerId) {
                if (i2 == 0) {
                    i = 1
                }
                mPrevX = motionEvent.getX(i)
                mPrevY = motionEvent.getY(i)
                mActivePointerId = motionEvent.getPointerId(i)
            }
        } else {
            Log.d(TAG, "onTouch: actionMasked == else")
        }

        return true
    }

    public inner class ScaleGestureListener() : DetectorMotion.SimpleOnScaleGestureListener() {
        private var mPivotX = 0f
        private var mPivotY = 0f
        private val mPrevSpanVector: Vector4DMotion =
            Vector4DMotion()

        override fun onScaleBegin(view: View, detectorMotion: DetectorMotion): Boolean {
//            mSetTransform = MyTouchMotion.mSetTransform
            mPivotX = detectorMotion.focusX
            mPivotY = detectorMotion.focusY
            Log.d(TAG, "onTouch: onScale")
            mPrevSpanVector.set(detectorMotion.currentSpanVector)
            return true
        }

        override fun onScale(view: View, detectorMotion: DetectorMotion): Boolean {

            Log.d(TAG, "onTouch: onScale")

            val transformInfo = TransformInfo()
            transformInfo.deltaScale = if (isScaleEnabled) detectorMotion.scaleFactor else 1.0f
            var f = 0.0f
            transformInfo.deltaAngle = if (isRotateEnabled) Vector4DMotion.getAngle(mPrevSpanVector, detectorMotion.currentSpanVector) else 0.0f
            transformInfo.deltaX = if (isTranslateEnabled) detectorMotion.focusX - mPivotX else 0.0f
            if (isTranslateEnabled) {
                f = detectorMotion.focusY - mPivotY
            }
            transformInfo.deltaY = f
            transformInfo.pivotX = mPivotX
            transformInfo.pivotY = mPivotY
            transformInfo.minimumScale = minimumScale
            transformInfo.maximumScale = maximumScale
            move(view, transformInfo)
            return false
        }

        override fun onScaleEnd(view: View?, detectorMotion: DetectorMotion) {
//            super.onScaleEnd(view, detectorMotion)
            val transformInfo = TransformInfo()
            transformInfo.deltaAngle = if (isRotateEnabled) Vector4DMotion.getAngle(mPrevSpanVector, detectorMotion.currentSpanVector) else 0.0f
//            mSetTransform!!.stickerClicked(translationX, translationY, adjustAngle(view!!.rotation + transformInfo.deltaAngle), false)
        }

    }

    public class TransformInfo {
        var deltaAngle = 0f
        var deltaScale = 0f
        var deltaX = 0f
        var deltaY = 0f
        var maximumScale = 0f
        var minimumScale = 0f
        var pivotX = 0f
        var pivotY = 0f
    }

    companion object {
        private const val INVALID_POINTER_ID = -1
        var mPrevX = 0f
        var isPressIcon = false
        var mPrevY = 0f
        var translationX = 0F
        var translationY = 0F
        var mPrevXY = 0F
        var mSetTransform: SetTransform?=null

        private fun adjustAngle(f: Float): Float {
            return if (f > 180.0f) f - 360.0f else if (f < -180.0f) f + 360.0f else f
        }

        fun move(view: View, transformInfo: TransformInfo) {
            computeRenderOffset(view, transformInfo.pivotX, transformInfo.pivotY)
            adjustTranslation(view, transformInfo.deltaX, transformInfo.deltaY)
            val max = max(transformInfo.minimumScale, min(transformInfo.maximumScale, view.scaleX * transformInfo.deltaScale))
            Log.d(TAG, "adjustAngle move: $max")
            view.scaleX = max
            view.scaleY = max
            view.rotation = adjustAngle(view.rotation + transformInfo.deltaAngle)
            mPrevXY=max
        }

        fun adjustTranslation(view: View, f1: Float, f2: Float) {
            Log.d(TAG, "adjustTranslation: x=>$f1 y=>$f2")
            val fArr = floatArrayOf(f1, f2)
            view.matrix.mapVectors(fArr)
            view.translationX = view.translationX + fArr[0]
            view.translationY = view.translationY + fArr[1]
            translationX = view.translationX + fArr[0]
            translationY = view.translationY + fArr[1]
        }

        private fun computeRenderOffset(view: View, f: Float, f2: Float) {
            if (view.pivotX != f || view.pivotY != f2) {
                val fArr = floatArrayOf(0.0f, 0.0f)
                view.matrix.mapPoints(fArr)
                view.pivotX = f
                view.pivotY = f2
                val fArr2 = floatArrayOf(0.0f, 0.0f)
                view.matrix.mapPoints(fArr2)
                val f3 = fArr2[0] - fArr[0]
                val f4 = fArr2[1] - fArr[1]
                view.translationX = view.translationX - f3
                view.translationY = view.translationY - f4
            }
        }

        var mActivePointerId = -1

        var mDetectorMotion =
            DetectorMotion(MyTouchMotion().ScaleGestureListener())
        private const val TAG = "MyTouchMotion"
    }

    interface SetTransform{
        fun stickerClicked(x: Float, y: Float, rotation: Float = 0F, singleFinger: Boolean = true)
        fun showGrid(horGrid: Boolean = false, verGrid: Boolean = false, isPointerUp: Boolean = false)
        fun showGrid1(horGrid: Boolean = false, verGrid: Boolean = false, isPointerUp: Boolean = false)
        fun showGrid2(horGrid: Boolean = false, verGrid: Boolean = false, isPointerUp: Boolean = false)
    }

}