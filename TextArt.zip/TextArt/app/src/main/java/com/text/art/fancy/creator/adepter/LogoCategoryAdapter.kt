package com.text.art.fancy.creator.adepter

import android.content.Context
import android.graphics.*
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.comman.Constants
import java.util.*


class LogoCategoryAdapter(
    private val context: Context,
    private val categoryArray: ArrayList<String>,
    private val action: OnItemClick,
): RecyclerView.Adapter<LogoCategoryAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(context).inflate(R.layout.rv_logo_category, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
       with(holder){
           container.setBackgroundColor(Color.argb(255, Random().nextInt(256), Random().nextInt(256), Random().nextInt(256)))
           txtCategory.text = categoryArray[position]

           itemView.setOnClickListener {
               if (Constants.CategoryPosition != position)
                    action.onItemClick(position, categoryArray[position])
               Constants.CategoryPosition = position
           }

           if (Constants.CategoryPosition == position){
               container.setBackgroundResource(R.drawable.ic_font_boarder)
           }else{
               container.setBackgroundResource(0)
           }
       }
    }

    override fun getItemCount(): Int {
        return categoryArray.size
    }

    fun changeItem(position:Int) {
        Constants.CategoryPosition = position
        action.onItemClick(position, categoryArray[position])
    }

    interface OnItemClick {
        fun onItemClick(position: Int, category: String)
    }


    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var container: ConstraintLayout = itemView.findViewById(R.id.mainView)
        var txtCategory: TextView = itemView.findViewById(R.id.category)
    }
}

