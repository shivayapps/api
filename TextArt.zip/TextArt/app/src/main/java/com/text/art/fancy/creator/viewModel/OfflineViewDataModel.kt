package com.text.art.fancy.creator.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.text.art.fancy.creator.R

class OfflineViewDataModel: ViewModel() {

    val offlineBgList : LiveData<ArrayList<Int>> = MutableLiveData()
    val offlineFrameList : LiveData<ArrayList<Int>> = MutableLiveData()
    val offlineComboList: LiveData<Array<IntArray>> = MutableLiveData()

    init {
        offlineBgList as MutableLiveData
        offlineFrameList as MutableLiveData
        offlineComboList as MutableLiveData
        viewModelScope.launch {
            offlineBgList.value = getOfflineBgData()
            offlineFrameList.value = getOfflineFrameData()
            offlineComboList.value = getOfflineComboData()
        }
    }

    private suspend fun getOfflineComboData(): Array<IntArray> {
        return withContext(Dispatchers.IO){
            val offlineComboBg = intArrayOf(
                0,
                R.drawable.z_c_1,
                R.drawable.z_c_2,
                R.drawable.z_c_3,
                R.drawable.z_c_4,
                R.drawable.z_c_5,
                R.drawable.z_c_6,
                R.drawable.z_c_7,
                R.drawable.z_c_8,
                R.drawable.z_c_9,
                R.drawable.z_c_10,
                R.drawable.z_c_11,
                R.drawable.z_c_12,
                R.drawable.z_c_13,
                R.drawable.z_c_14,
                R.drawable.z_c_15,
                R.drawable.z_c_16,
                R.drawable.z_c_17,
                R.drawable.z_c_18,
                R.drawable.z_c_19,
                R.drawable.z_c_20,
                R.drawable.z_c_21,
                R.drawable.z_c_22,
                R.drawable.z_c_23,
                R.drawable.z_c_24,
                R.drawable.z_c_25,
                R.drawable.z_c_26,
                R.drawable.z_c_27
            )
            val offlineComboFrame = intArrayOf(
                0,
                R.drawable.z_c_01,
                R.drawable.z_c_02,
                R.drawable.z_c_03,
                R.drawable.z_c_04,
                R.drawable.z_c_05,
                R.drawable.z_c_06,
                R.drawable.z_c_07,
                R.drawable.z_c_08,
                R.drawable.z_c_09,
                R.drawable.z_c_010,
                R.drawable.z_c_011,
                R.drawable.z_c_012,
                R.drawable.z_c_013,
                R.drawable.z_c_014,
                R.drawable.z_c_015,
                R.drawable.z_c_016,
                R.drawable.z_c_017,
                R.drawable.z_c_018,
                R.drawable.z_c_019,
                R.drawable.z_c_020,
                R.drawable.z_c_021,
                R.drawable.z_c_022,
                R.drawable.z_c_023,
                R.drawable.z_c_024,
                R.drawable.z_c_025,
                R.drawable.z_c_026,
                R.drawable.z_c_027
            )
            arrayOf(offlineComboBg, offlineComboFrame)
        }
    }

    private suspend fun getOfflineBgData():ArrayList<Int>{
        return withContext(Dispatchers.IO){
            val list= arrayListOf<Int>()
            with(list){
                add(0)
                add(R.drawable.z_b_1)
                add(R.drawable.z_b_2)
                add(R.drawable.z_b_3)
                add(R.drawable.z_b_4)
                add(R.drawable.z_b_5)
                add(R.drawable.z_b_6)
                add(R.drawable.z_b_7)
                add(R.drawable.z_b_8)
                add(R.drawable.z_b_9)
                add(R.drawable.z_b_10)
                add(R.drawable.z_b_11)
                add(R.drawable.z_b_12)
                add(R.drawable.z_b_13)
                add(R.drawable.z_b_14)
                add(R.drawable.z_b_15)
                add(R.drawable.z_b_16)
                add(R.drawable.z_b_17)
                add(R.drawable.z_b_18)
                add(R.drawable.z_b_19)
                add(R.drawable.z_b_20)
                add(R.drawable.z_b_21)
                add(R.drawable.z_b_22)
                add(R.drawable.z_b_23)
                add(R.drawable.z_b_24)
                add(R.drawable.z_b_25)
                add(R.drawable.z_b_26)
                add(R.drawable.z_b_27)
            }
            list
        }
    }

    private suspend fun getOfflineFrameData():ArrayList<Int>{
        return withContext(Dispatchers.IO){
            val list= arrayListOf<Int>()
            with(list){
                add(0)
                add(R.drawable.z_f_1)
                add(R.drawable.z_f_2)
                add(R.drawable.z_f_3)
                add(R.drawable.z_f_4)
                add(R.drawable.z_f_5)
                add(R.drawable.z_f_6)
                add(R.drawable.z_f_7)
                add(R.drawable.z_f_8)
                add(R.drawable.z_f_9)
                add(R.drawable.z_f_10)
                add(R.drawable.z_f_11)
                add(R.drawable.z_f_12)
                add(R.drawable.z_f_13)
                add(R.drawable.z_f_14)
                add(R.drawable.z_f_15)
                add(R.drawable.z_f_16)
                add(R.drawable.z_f_17)
                add(R.drawable.z_f_18)
                add(R.drawable.z_f_19)
                add(R.drawable.z_f_20)
                add(R.drawable.z_f_21)
                add(R.drawable.z_f_22)
                add(R.drawable.z_f_23)
                add(R.drawable.z_f_24)
                add(R.drawable.z_f_25)
            }
            list
        }
    }
}