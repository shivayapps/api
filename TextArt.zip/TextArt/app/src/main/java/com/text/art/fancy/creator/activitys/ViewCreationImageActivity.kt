package com.text.art.fancy.creator.activitys

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager.widget.ViewPager
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.text.art.fancy.creator.model.creation.GalleryImagePathModel
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.adepter.GalleryPagerAdapter
import com.google.firebase.analytics.FirebaseAnalytics
import java.io.File
import java.util.*

class ViewCreationImageActivity : AppCompatActivity(), View.OnClickListener {
    var back_image: ImageView? = null
    var set_wallpaper: ImageView? = null
    private var position = 0
    var heart = true
    var mFolderName:String?=null
    var mFirebaseAnalytics: FirebaseAnalytics? = null
    var myBitmap: Bitmap? = null
    var url: String? = null
    private var viewpager: ViewPager? = null
    private var pathList: ArrayList<GalleryImagePathModel>? = null
    var share_fb: ImageButton? = null
    var share_insta: ImageButton? = null
    var share_whatsapp: ImageButton? = null
    var share_more: ImageButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_creation_image)
        Log.d("CreationImageActivity","Call")

        setStatusBarColor()

        position = Objects.requireNonNull(intent.extras)!!.getInt("position") -1
        mFolderName = Objects.requireNonNull(intent.extras)!!.getString("foldername")
        Log.d(TAG, "onCreate: $position")

        // myBitmap = BitmapFactory.decodeFile(url);
        findViewId()
        onClickEve()
        images
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this@ViewCreationImageActivity)
        setImages()
    }

    private fun setImages() {
        if (pathList!!.size > 0) {
            if (position > pathList!!.size - 1) {
                position = pathList!!.size - 1
            }
            viewpager!!.adapter = GalleryPagerAdapter(this@ViewCreationImageActivity, pathList!!)
            viewpager!!.currentItem = position
            url = pathList!![position].path
            myBitmap = BitmapFactory.decodeFile(url)
            viewpager!!.addOnPageChangeListener(object : OnPageChangeListener {
                override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
                override fun onPageSelected(position: Int) {
                    url = pathList!![position].path
                    Log.d(TAG, "onPageSelected: $url")
                    myBitmap = BitmapFactory.decodeFile(url)
                }

                override fun onPageScrollStateChanged(state: Int) {}
            })
        } else {
            Log.d(TAG, "finish()")
            finish()
        }
    }

    private fun setStatusBarColor() {
        val window = this.window
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimary)
        }
    }

    //Log.d(TAG, "getPhotos: pos " + SHOW_ADS);
    private val images: Unit
        private get() {
            pathList = ArrayList()
            val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+"/"+mFolderName)
            if (file.isDirectory) {
                val files = file.listFiles { pathname -> pathname.path.endsWith(".jpg") || pathname.path.endsWith(".jpeg") || pathname.path.endsWith(".png") }
                if (files.size > 0) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files[i].lastModified() < files[j].lastModified()) {
                                temp = files[i]
                                files[i] = files[j]
                                files[j] = temp
                            }
                        }
                    }
                    for (i in files.indices) {
                        pathList!!.add(GalleryImagePathModel(files[i].absolutePath))
                        Log.d(TAG, "getImages: " + files[i].absolutePath)
                    }
                    //Log.d(TAG, "getPhotos: pos " + SHOW_ADS);
                }
            }
        }

    private fun onClickEve() {
        back_image!!.setOnClickListener(this)
        set_wallpaper!!.setOnClickListener(this)
        //delete_image!!.setOnClickListener(this)
        share_fb!!.setOnClickListener(this)
        share_insta!!.setOnClickListener(this)
        share_whatsapp!!.setOnClickListener(this)
        share_more!!.setOnClickListener(this)
    }

    private fun findViewId() {
        //full_image = findViewById(R.id.full_image);
        back_image = findViewById(R.id.back_image)
        set_wallpaper = findViewById(R.id.set_wallpaper)
       // delete_image = findViewById(R.id.delete_image)
        share_fb = findViewById(R.id.share_fb)
        share_insta = findViewById(R.id.share_insta)
        share_whatsapp = findViewById(R.id.share_whatsapp)
        share_more = findViewById(R.id.share_more)
        viewpager = findViewById(R.id.viewpager)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.back_image -> onBackPressed()
            R.id.set_wallpaper -> {
                startActivity(Intent(this@ViewCreationImageActivity, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                finish()
            }
            else -> {
            }
        }
    }

    override fun onRestart() {
        super.onRestart()
        images
        setImages()
    }

    override fun onBackPressed() {
        finish()
    }

    public override fun onPause() {
        super.onPause()
    }

    public override fun onResume() {
        super.onResume()
    }

    public override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        private const val TAG = "FullMyPhoto"
    }
}