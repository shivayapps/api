package com.text.art.fancy.creator.adepter

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.text.art.fancy.creator.R
import com.github.demono.adapter.InfinitePagerAdapter

class SlideAdsAdapter(private val data: List<Int>, private val Mcontext: Context) : InfinitePagerAdapter() {
    override fun getItemCount(): Int {
        return data?.size ?: 0
    }

    override fun getItemView(position: Int, convertView: View, container: ViewGroup): View {
        val view = LayoutInflater.from(Mcontext).inflate(R.layout.slide_adapter, container, false)
        Glide.with(Mcontext).load(data[position]).into((view.findViewById<View>(R.id.imgBNanner) as ImageView))
        view.findViewById<View>(R.id.imgBNanner).setOnClickListener {
           if (position==0){
               try {
                   Mcontext.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.name.photo.birthday.cake.quotes.frame.editor")))
               } catch (anfe: ActivityNotFoundException) {
                   Mcontext.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.name.photo.birthday.cake.quotes.frame.editor")))
               }
           }else{
               try {
                   Mcontext.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.graphic.design.digital.businessadsmaker")))
               } catch (anfe: ActivityNotFoundException) {
                   Mcontext.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.graphic.design.digital.businessadsmaker")))
               }
           }
        }
        return view
    }
}