package com.text.art.fancy.creator.bgapi

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.BackgroundApi.BGApiAdepter
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.BGActivity
import com.text.art.fancy.creator.activitys.BGActivity.Companion.categoryId
import com.text.art.fancy.creator.activitys.SubscriptionActivity
import com.text.art.fancy.creator.ads.RewardVideoAds.Companion.instence
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.database.DBHelper
import com.text.art.fancy.creator.dialog.WatchAdDialogFragment
import com.text.art.fancy.creator.newapi.category.CategoryItem
import com.text.art.fancy.creator.newapi.data.ApiHelper
import com.text.art.fancy.creator.newapi.data.MainRepository
import com.text.art.fancy.creator.newapi.data.RetrofitBuilder
import com.text.art.fancy.creator.utils.hide
import com.text.art.fancy.creator.utils.isOnline
import com.text.art.fancy.creator.utils.show
import com.text.art.fancy.creator.utils.showToast
import com.crop.photo.image.resize.cut.tools.ads.RewardedAdHelper
import kotlinx.coroutines.*

class BGtDataFragment : Fragment() {

    var llInternetConnection: LinearLayout? = null
    var llNodataFound: LinearLayout? = null
    var progressBar1: ProgressBar? = null
    var pbLoading: ProgressBar? = null
    var recyclerViewCard: RecyclerView? = null
    var dbHelper: DBHelper? = null
    var isDismiss: Boolean = false
    var watchAdDialog:WatchAdDialogFragment? = null
    var isSubscription: Boolean = false
    var myFilterArray = arrayListOf<CategoryItem>()
    lateinit var actionBottomDialogFragment: BGActivity
    var param: Int? = null
    private var lastClickTime: Long = 0
    private var bgAdapter : BGApiAdepter ?= null
    private lateinit var mainRepository: MainRepository

    private var loading = true
    private var pastVisiblesItems = 0
    private var visibleItemCount = 0
    private var totalItemCount = 0
    private var currentPage = 1
    private var totalPage = 1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        return inflater.inflate(R.layout.fragment_bg_data, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dbHelper = DBHelper(requireContext())
        isSubscription = try {
            MySharedPreferences(
                requireContext()
            ).isSubscribe
        } catch (e: Exception) {
            false
        }
        param = requireArguments().getInt("param")
        Log.d(TAG, "loadNewApiData: Params id is $param")
        recyclerViewCard = view.findViewById(R.id.recyclerViewCard)
        progressBar1 = view.findViewById(R.id.progressBar1)
        pbLoading = view.findViewById(R.id.pbLoading)
        llInternetConnection = view.findViewById(R.id.llInternetConnection)
        llNodataFound = view.findViewById(R.id.llNodataFound)
//        loadData()
        if (isOnline()){
            loadNewApiData()
        }
        try {
            RewardedAdHelper.instence!!.loadRewardedAd(requireContext())
        } catch (e: Exception) { }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun loadNewApiData() {
        if (isDismiss) 
            return
        progressBar1?.show()
        myFilterArray.clear()

        mainRepository = MainRepository(ApiHelper(RetrofitBuilder.apiServiceNew(requireActivity())))
        lifecycleScope.launch { 
            withContext(Dispatchers.IO){
                loadNextPage(currentPage)
            }
            withContext(Dispatchers.Main){
                //TODO SetRecyclerView
                val gridLayoutManager = GridLayoutManager(requireContext(), 3)
                gridLayoutManager.orientation = LinearLayoutManager.VERTICAL
                recyclerViewCard!!.layoutManager = gridLayoutManager
                recyclerViewCard?.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                    @SuppressLint("NotifyDataSetChanged")
                    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                        if (dy > 0) {
                            visibleItemCount = gridLayoutManager.childCount
                            totalItemCount = gridLayoutManager.itemCount
                            pastVisiblesItems = gridLayoutManager.findFirstVisibleItemPosition()
                            if (currentPage < totalPage){
                                if (loading) {
                                    if (visibleItemCount + pastVisiblesItems >= totalItemCount) {
                                        currentPage++
                                        loadNextPage(currentPage)
                                    }
                                }
                            }
                        }
                    }
                })

                bgAdapter = BGApiAdepter(requireContext(), myFilterArray,
                    object : BGApiAdepter.OnItemClickBG {
                        override fun onItemClickBG(position: Int, string: String) {
                            if (myFilterArray[position].isPremium == 1) {
                                startActivityForResult(
                                    Intent(
                                        requireContext(),
                                        SubscriptionActivity::class.java
                                    ), 1000
                                )
                            } else if (myFilterArray[position].coin!! >= 10) {
                                if (isOnline()) {
                                    if (RewardedAdHelper.instence != null &&
                                        RewardedAdHelper.instence!!.loadRewardedAd(requireContext()) != null
                                    ) {
                                        showAdDialog(position)
                                    } else {
                                        showToast(resources.getString(R.string.try_again_later))
                                    }
                                } else {
                                    showToast("Please check internet connection.")
                                }
                            } else {
                                BGActivity.isAdsIsFree = true
                                actionBottomDialogFragment.onBGItemClick(
                                    string,
                                    param!!
                                )
                            }
                        }
                    }
                )

                recyclerViewCard!!.adapter = bgAdapter
                recyclerViewCard?.show()
                llInternetConnection?.hide()
            }
        }
        
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun loadNextPage(currentPage: Int) {
        lifecycleScope.launch {
            if (currentPage != 1){
                withContext(Dispatchers.Main){
                    pbLoading?.show()
                    recyclerViewCard?.invalidate()
                }
            }
            loading = false
            mainRepository.getCategory(categoryId, param, page = currentPage)?.let {
                withContext(Dispatchers.IO){
                    it.data?.let { responce ->
                        it.totalPage?.let { total -> totalPage = total }
                        val mFrameOpen = DBHelper(actionBottomDialogFragment).allOpenBGData
                        for (background in responce){
                            background?.let { file ->
                                Log.d(TAG, "loadNextPage: File coin -> ${file.coin}")
                                val categoryParametersItem = CategoryItem()
                                if (file.isPremium == 1 && !isSubscription) {
                                    categoryParametersItem.isPremium = 1
                                } else {
                                    categoryParametersItem.isPremium = 0
                                }
                                if (file.coin == 10 && !isSubscription) {
                                    categoryParametersItem.coin = 10
                                } else {
                                    categoryParametersItem.coin = 0
                                }
                                categoryParametersItem.image = file.image
                                categoryParametersItem.thumbImage = file.thumbImage
                                try {
                                    if (!isSubscription) {
                                        mFrameOpen.moveToFirst()
                                        if (mFrameOpen.getString(1) == file.image) {
                                            categoryParametersItem.coin = 0
                                        }
                                        while (mFrameOpen.moveToNext()) {
                                            if (mFrameOpen.getString(1) == file.image) {
                                                categoryParametersItem.coin = 0
                                                break
                                            }
                                        }
                                    }
                                } catch (e: Exception) {}
                                myFilterArray.add(categoryParametersItem)
                                true
                            }
                        }
                    }
                }
            }
        }.invokeOnCompletion {
            bgAdapter?.notifyDataSetChanged()
            loading = true
            progressBar1?.hide()
            pbLoading?.hide()
            recyclerViewCard?.invalidate()
        }
    }

    override fun onResume() {
        super.onResume()
    }

    private fun loadData() {
//        if (isDismiss) {
//            return
//        }
//        Log.d(TAG, "loadData: $param")
//        Log.d(TAG, "loadData: size ${bgAllArray.size}")
//        if (bgAllArray.isNullOrEmpty()){
//            Handler(Looper.getMainLooper()).postDelayed({loadData()},3000)
//        }else{
//            myFilterArray = arrayListOf()
//            val gridLayoutManager = GridLayoutManager(requireContext(), 3)
//            gridLayoutManager.orientation = LinearLayoutManager.VERTICAL
//            recyclerViewCard!!.layoutManager = gridLayoutManager
//            if (bgAllArray[param!!].categoryParameters.size != 0) {
//                var mFrameOpen: Cursor? = null
//
//                GlobalScope.launch {
//                    withContext(Dispatchers.IO) {
//                        mFrameOpen = DBHelper(actionBottomDialogFragment).allOpenBGData
//                    }
//
//                    withContext(Dispatchers.IO) {
//                        bgAllArray[param!!].categoryParameters!!.filterIndexed { _, file ->
//                            val categoryParametersItem = CategoryParametersItem()
//                            if (file.is_premium == 1 && !isSubscription) {
//                                categoryParametersItem.is_premium = 1
//                            } else {
//                                categoryParametersItem.is_premium = 0
//                            }
//                            if (file.coins == 10 && !isSubscription) {
//                                categoryParametersItem.coins = 10
//                            } else {
//                                categoryParametersItem.coins = 0
//                            }
//                            categoryParametersItem.image = file.image
//                            categoryParametersItem.thumbImage = file.thumbImage
//                            try {
//                                if (!isSubscription) {
//                                    mFrameOpen!!.moveToFirst()
//                                    if (mFrameOpen!!.getString(1) == file.image) {
//                                        categoryParametersItem.coins = 0
//                                    }
//                                    while (mFrameOpen!!.moveToNext()) {
//                                        if (mFrameOpen!!.getString(1) == file.image) {
//                                            categoryParametersItem.coins = 0
//                                            break
//                                        }
//                                    }
//                                }
//                            } catch (e: Exception) {
//                            }
//                            myFilterArray!!.add(categoryParametersItem)
//                            true
//                        }
//                    }
//                    withContext(Dispatchers.Main) {
//                        val newFontStyleAdepter = BGApiAdepter(
//                            actionBottomDialogFragment,
//                            myFilterArray,
//                            object : BGApiAdepter.OnItemClickBG {
//                                override fun onItemClickBG(position: Int, string: String) {
//
//                                    if (myFilterArray!![position].is_premium == 1) {
//                                        isAdsIsFree = false
//                                        startActivityForResult(
//                                            Intent(
//                                                requireContext(),
//                                                SubscriptionActivity::class.java
//                                            ), 1000
//                                        )
//                                    } else if (myFilterArray!![position].coins >= 10) {
//                                        isAdsIsFree = false
//                                        if (isOnline()) {
//                                            /*if (instence != null && instence!!.loadVideoAdMain(
//                                                    requireContext()
//                                                ) != null
//                                            ) {
//                                                val rewardedAd =
//                                                    instence!!.loadVideoAdMain(requireContext())
//                                                showAdDialog(position, rewardedAd!!, 1)
//                                            } else {
//                                                Toast.makeText(
//                                                    requireContext(),
//                                                    resources.getString(R.string.try_again_later),
//                                                    Toast.LENGTH_SHORT
//                                                ).show()
//                                            }*/
//                                            if (RewardedAdHelper.instence != null && RewardedAdHelper.instence!!.loadRewardedAd(requireContext()) != null
//                                            ) {
//                                                showAdDialog(position)
//                                            }else{
//                                                Toast.makeText(
//                                                    requireContext(),
//                                                    resources.getString(R.string.try_again_later),
//                                                    Toast.LENGTH_SHORT
//                                                ).show()
//                                            }
//                                        } else {
//                                            Toast.makeText(
//                                                activity,
//                                                "Please check internet connection.",
//                                                Toast.LENGTH_SHORT
//                                            ).show()
//                                        }
//                                    } else {
//                                        isAdsIsFree = true
//                                        actionBottomDialogFragment.onBGItemClick(
//                                            string,
//                                            bgAllArray[param!!].categoryParameters!![position].id
//                                        )
//                                    }
//                                }
//
//                            })
//
//                        recyclerViewCard!!.adapter = newFontStyleAdepter
//                        recyclerViewCard!!.visibility = View.VISIBLE
//                        progressBar1!!.visibility = View.GONE
//                        llInternetConnection!!.visibility = View.GONE
//
//                    }
//                }
//
//            } else {
//                if (isOnline()) {
//                    llInternetConnection!!.visibility = View.GONE
//                    llNodataFound!!.visibility = View.VISIBLE
//                    recyclerViewCard!!.visibility = View.GONE
//                    progressBar1!!.visibility = View.GONE
//                } else {
//                    llInternetConnection!!.visibility = View.VISIBLE
//                    llNodataFound!!.visibility = View.GONE
//                    recyclerViewCard!!.visibility = View.GONE
//                    progressBar1!!.visibility = View.GONE
//                }
//            }
//        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1000 && resultCode == 1144) {
            isSubscription = try {
                MySharedPreferences(
                    actionBottomDialogFragment
                ).isSubscribe
            } catch (e: Exception) {
                false
            }
            if (isSubscription) {
                currentPage = 1
                loadNewApiData()
            }
        }
    }


    private fun showAdDialog(position: Int) {
        watchAdDialog = WatchAdDialogFragment(
            "Unlock Background",
            "Get PRO",
            "To Access All Backgrounds",
            R.drawable.ic_dialog_background,
            "Watch Video Ad",
            "To Use This Background"
        )
        { s, discardDialogFragment ->
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@WatchAdDialogFragment
            lastClickTime = SystemClock.elapsedRealtime()
            when (s) {
                "subscribe" -> {
                    discardDialogFragment.dismiss()
                    startActivityForResult(
                        Intent(
                            requireContext(),
                            SubscriptionActivity::class.java
                        ), 1000
                    )
                }
                "watchAd" -> {
                    discardDialogFragment.dismiss()
                    BGActivity.isAdsIsFree = false
                    showAdReward(position)
                }
                else -> {
                    discardDialogFragment.dismiss()
                }
            }
        }
        watchAdDialog!!.isCancelable = false
        watchAdDialog!!.show(childFragmentManager, "dialog_fragment")

    }

    fun showAdReward(position: Int) {
        RewardedAdHelper.instence!!.showRewardedAd(requireContext(), {
            //OnUserEarnedReward
            dbHelper!!.insertOpenBgData(position, myFilterArray[position].image!!)
            actionBottomDialogFragment.onBGItemClick(
                myFilterArray[position].image!!,
                param!!
            )
            instence!!.loadVideoAdMain(requireContext())
        }, {
            //OnError
            Log.d(TAG, "showAdReward: BG OnError")
            RewardedAdHelper.instence!!.loadRewardedAd(requireContext())
        }, {
            //OnClose
            Log.d(TAG, "showAdReward: BG OnClose")
            instence!!.loadVideoAdMain(requireContext())
        }, {
            //On Pro
            Log.d(TAG, "showAdReward: BG On Pro")
            /*actionBottomDialogFragment.onAnimationItemClick(
                AddAnimationActivity.animationAllArray[param].categoryParameters!![position].id,
                AddAnimationActivity.animationAllArray[param].categoryParameters!![position].name,
                AddAnimationActivity.animationAllArray[param].categoryParameters!![position].zip,
            )*/
        }, isSubscription)
    }

    interface ItemClickListener {
        fun onBGItemClick(string: String, id: Int)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        actionBottomDialogFragment = context as BGActivity
    }

    override fun onPause() {
        super.onPause()

        //TODO For Can not perform this action after onSaveInstanceState
        try {
            if (watchAdDialog!=null && watchAdDialog!!.isShowing()){
                watchAdDialog!!.dismiss()
            }
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        isDismiss = true
    }

    companion object {
        private const val TAG = "BGtDataFragment"
        @JvmStatic
        fun newInstance(param: Int): Fragment {
            val args = Bundle()
            args.putInt("param", param)
            val f = BGtDataFragment()
            f.arguments = args
            return f
        }

    }
}