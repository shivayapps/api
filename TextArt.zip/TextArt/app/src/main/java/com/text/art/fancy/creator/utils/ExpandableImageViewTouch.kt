package com.text.art.fancy.creator.utils

import android.content.Context
import android.util.AttributeSet
import android.view.View.OnTouchListener
import it.sephiroth.android.library.imagezoom.ImageViewTouch

class ExpandableImageViewTouch : ImageViewTouch {
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyle: Int) : super(context, attrs, defStyle) {
        init()
    }

    private fun init() {
        val listener = OnTouchListener { v, event ->
            if (scale > 1f) {
                parent.requestDisallowInterceptTouchEvent(true)
            } else {
                parent.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
        setOnTouchListener(listener)
        displayType = DisplayType.FIT_TO_SCREEN
    }
}