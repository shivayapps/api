package com.crop.photo.image.resize.cut.tools.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.text.art.fancy.creator.categorys.sqlite_database.AdsPrefs
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs

class RewardedAdHelper {

    companion object {

        val TAG = "rewardedAdsHelper"
        var rewardedAd1: RewardedAd? = null
        var rewardedAd2: RewardedAd? = null
        var isRewardedAdShowing: Boolean = false

        var instence: RewardedAdHelper? = null
            get() {

                if (field == null) {
                    field = RewardedAdHelper()
                }
                return field
            }
    }

    fun loadRewardedAd(context: Context): RewardedAd? {
        var rewardedAd: RewardedAd? = null

        if (rewardedAd1 != null) {

            Log.d(TAG, "loadInterstitialAd: interstitialAd1 if")

            rewardedAd = rewardedAd1!!

        } else {

            loadRewardedAd1(context)

            Log.d(TAG, "loadInterstitialAd: interstitialAd1 else $rewardedAd1")

        }
        if (rewardedAd2 != null) {


            Log.d(TAG, "loadInterstitialAd: interstitialAd2 if")

            rewardedAd = rewardedAd2!!
        } else {


            loadRewardedAd2(context)
            Log.d(TAG, "loadInterstitialAd: interstitialAd2 else $rewardedAd2")


        }

        Log.d(TAG, "loadInterstitialAd: $rewardedAd")

        return rewardedAd
    }


    fun loadRewardedAd1(context: Context) {

        if (rewardedAd1 != null) {
            return
        }

        if (!isNetworkAvailable(context)){
            return
        }

        if (AdsPrefs.getBoolean(context, AdsPrefs.IS_SUBSCRIBED,false)) {
            return
        }


        val s = AppIDs.instnace?.getGoogleRewardVideo() ?: ""
//        val s = "ca-app-pub-3940256099942544/5224354917"
//        Log.d(TAG, "loadInterstitialAd: $s")

        RewardedAd.load(context,s, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.d(TAG, "Ad was not loaded ${adError.message}")
                rewardedAd1 = null
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
                Log.d(TAG, "Ad 1 was loaded.")
                rewardedAd1 = rewardedAd
            }
        })

    }

    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connectivityManager.activeNetworkInfo != null && connectivityManager.activeNetworkInfo!!.isConnected
    }

    fun loadRewardedAd2(context: Context) {

        if (rewardedAd2 != null) {
            return
        }

        if (AdsPrefs.getBoolean(context, AdsPrefs.IS_SUBSCRIBED,false)) {
            return
        }

        if (!isNetworkAvailable(context)){
            return
        }

        val s = AppIDs.instnace?.getGoogleRewardVideo() ?: ""
//        val s = "ca-app-pub-3940256099942544/5224354917"

        Log.d(TAG, "loadInterstitialAd2: $s")


        RewardedAd.load(context,s, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.d(TAG, "Ad was not loaded ${adError.message}")
                rewardedAd2 = null
            }

            override fun onAdLoaded(rewardedAd: RewardedAd) {
                Log.d(TAG, "Ad 2 was loaded.")
                rewardedAd2 = rewardedAd
            }
        })

    }

    fun showRewardedAd(context: Context, OnUserEarned: () -> Unit, onError: () -> Unit,onClose: () -> Unit, onPro: () -> Unit, isPro: Boolean = false) {
        val cm = context.getSystemService(AppCompatActivity.CONNECTIVITY_SERVICE) as ConnectivityManager
        var isAdClosed = true
        var isRewardEarn = false

        if (isPro) {
            onPro()
        } else {
            try {
                if (cm.activeNetworkInfo != null && cm.activeNetworkInfo!!.isConnected){
                    val mRewardedAd = loadRewardedAd(context)
                    Log.d(TAG, "showRewardedAd: $mRewardedAd")
                    if (mRewardedAd != null) {
                        mRewardedAd.fullScreenContentCallback = object : FullScreenContentCallback() {

                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                                Log.d("ViewPhotoActivity.TAG", "onClickId: onShow")

                                if(isRewardEarn){
                                    OnUserEarned()
                                }
                                if (isAdClosed) {
                                    onClose()
                                }
//                                if (isAdClosed){
//                                    onClose()
//                                }else{
//                                    OnUserEarned()
//                                }
                                isRewardedAdShowing = false
                                if (mRewardedAd == rewardedAd1) {
                                    rewardedAd1 = null
                                } else if (mRewardedAd == rewardedAd2) {
                                    rewardedAd2 = null
                                }
                                loadRewardedAd(context)
                            }

                            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                super.onAdFailedToShowFullScreenContent(p0)
                                onError()
                                Log.d("ViewPhotoActivity.TAG", "onClickId: onError null")

                                isRewardedAdShowing = false
                                if (mRewardedAd == rewardedAd1) {
                                    rewardedAd1 = null
                                } else if (mRewardedAd == rewardedAd2) {
                                    rewardedAd2 = null
                                }
                                loadRewardedAd(context)
                            }

                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                                isRewardedAdShowing = true
                            }

                        }
                        mRewardedAd.show(context as Activity, OnUserEarnedRewardListener {
                            isRewardEarn = true
                            isAdClosed = false
                            Log.d("ViewPhotoActivity.TAG", "onClickId: show")

                        })
                    } else {
                        onError()
                        Log.d("ViewPhotoActivity.TAG", "onClickId: onError null")

                        if (mRewardedAd == rewardedAd1) {
                            rewardedAd1 = null
                        } else if (mRewardedAd == rewardedAd2) {
                            rewardedAd2 = null
                        }
                        isRewardedAdShowing = false
                        loadRewardedAd(context)
                    }
                }else{
                    onError()
                }


            } catch (e: Exception) {
                e.printStackTrace()
                onError()
            }

        }


    }


}