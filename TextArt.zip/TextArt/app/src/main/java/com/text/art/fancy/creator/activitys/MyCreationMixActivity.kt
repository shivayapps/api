package com.text.art.fancy.creator.activitys

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.*
import androidx.annotation.Px
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.viewpager.widget.ViewPager
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.ScrollState
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.adepter.TabAdapter
import com.text.art.fancy.creator.ads.OfflineNativeAdvancedHelper
import com.text.art.fancy.creator.categorys.sqlite_database.AdsPrefs
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.dialog.DiscardDialogFragment
import com.text.art.fancy.creator.fragment.MyDraftFragment
import com.text.art.fancy.creator.fragment.MyImagesFragment
import com.text.art.fancy.creator.fragment.MyVideosFragment
import com.text.art.fancy.creator.interfaces.OnLongClickPressedMyCreation
import com.text.art.fancy.creator.model.creation.PhotoModelCreation
import com.text.art.fancy.creator.roomdb.draft.DraftDatabase
import com.text.art.fancy.creator.utils.*
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.google.android.material.tabs.TabLayout
import com.scribble.animation.maker.video.effect.myadslibrary.receiver.NetworkChangeReceiver
import com.scribble.animation.maker.video.effect.myadslibrary.utils.InternetConnection
import kotlinx.android.synthetic.main.activity_my_photo.*
import kotlinx.android.synthetic.main.activity_view_creation_image.*
import java.io.File

class MyCreationMixActivity : AppCompatActivity(), OnLongClickPressedMyCreation {

    private lateinit var mContext: MyCreationMixActivity
    private var TAG = "MyCreationMixActivity"

    //Widgets
    private var mBack_img: ImageView? = null
    private lateinit var btnDelete: ImageView
    private var mTabLayout: TabLayout? = null
    private var txtImages: ImageView? = null
    private var txtVideos: ImageView? = null
    private lateinit var txtDraft: ImageView
//    private var lottieAds: LottieAnimationView? = null

    private var viewPager: ViewPager2? = null
    private var btnPremium: ImageView? = null
    private var addTextToolbar: Toolbar? = null

    //Fragments
    private var myImagesFragment: MyImagesFragment? = null
    private var myVideosFragment: MyVideosFragment? = null
    private var myDraftFragment: MyDraftFragment? = null

    //Others
    private var receiver: Receiver? = null
    private var mNetworkReceiver: NetworkChangeReceiver? = null
    private var isCalled = false
    private var userDenyRequest = false
    private var dialogSave: DiscardDialogFragment? = null

    private var lastClickTime = 0L

    private lateinit var db: DraftDatabase

    //Ads
    var ins_adRequest: AdRequest? = null
    var mInterstitialAd: InterstitialAd? = null

    private val DELETE_PERMISSION_REQUEST = 30004

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_creation_mix)
        mContext = this@MyCreationMixActivity
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            startActivity(Intent(mContext, HomeActivity::class.java))
            finish()
        } else {
            db = DraftDatabase.getInstance(this)
            initView()
            initAction()
            hideSystemUI()
            initViewAction()
            initViewPager()
            viewPager!!.currentItem = 0
//            loadAds()
        }

        /*btnPremium!!.setOnClickListener {
            //Show Ad
            if (!AdsPrefs.getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
//                showAd()
            }
        }*/

        try {
            if (!AdsPrefs.getBoolean(
                    mContext,
                    AdsPrefs.IS_SUBSCRIBED,
                    false
                ) && !MySharedPref(this).getAdsClicked()
            ) {
                findViewById<FrameLayout>(R.id.fl_adplaceholder).hide()
                findViewById<View>(R.id.FlOfflineAds).show()
                findViewById<View>(R.id.FlOfflineAds).setOnClickListener { _ ->
                    MySharedPref(this).setAdsClicked("adsClickOrNot", true)
                    findViewById<View>(R.id.FlOfflineAds).hide()
//                    loadNativeAd()
                    try {
                        startActivityForResult(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("market://details?id=com.graphic.design.digital.businessadsmaker")
                            ), 1212
                        )
                    } catch (anfe: ActivityNotFoundException) {
                        startActivityForResult(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://play.google.com/store/apps/details?id=com.graphic.design.digital.businessadsmaker")
                            ), 1212
                        )
                    }
                }
            } else {
                findViewById<View>(R.id.FlOfflineAds).hide()
            }
        } catch (e: Exception) {
        } finally {
        }

    }

    private fun initAction() {
//        lottieAds!!.setOnClickListener {
//            if (mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
//                mInterstitialAd!!.show()
//            }
//        }
        btnPremium!!.setOnClickListener {
            startActivityForResult(Intent(this, SubscriptionActivity::class.java), 1111)
        }
    }


    private fun initView() {
        mBack_img = findViewById(R.id.back_image)
        btnDelete = findViewById(R.id.imgDelete)
        mTabLayout = findViewById(R.id.tabLayout)
        txtImages = findViewById(R.id.txtImages)
        txtVideos = findViewById(R.id.txtVideos)
        txtDraft = findViewById(R.id.txtDraft)
        viewPager = findViewById(R.id.viewPager)
        btnPremium = findViewById(R.id.btnPremium)
        addTextToolbar = findViewById(R.id.addTextToolbar)

        txtImages!!.setOnClickListener {
            viewPager!!.currentItem = 0
            txtImages?.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_photo_selected)
            )
            txtVideos?.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_video_unselected)
            )
            txtDraft.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_draft_unselected)
            )
        }

        txtVideos!!.setOnClickListener {
            viewPager!!.currentItem = 1
            txtImages?.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_photo_unselected)
            )
            txtVideos?.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_video_selected)
            )
            txtDraft.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_draft_unselected)
            )
        }

        txtDraft.setOnClickListener {
            viewPager?.currentItem = 2
            txtImages?.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_photo_unselected)
            )
            txtVideos?.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_video_unselected)
            )
            txtDraft.setImageDrawable(
                ContextCompat.getDrawable(this, R.drawable.ic_draft_selected)
            )
        }

        //init Receiver
        receiver = Receiver()
        mNetworkReceiver = NetworkChangeReceiver()

        if (!AdsPrefs.getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            registerReceiver(mNetworkReceiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
            registerReceiver(
                receiver,
                IntentFilter("com.text.art.fancy.creator")
            )

            object : AsyncTask<Void?, Void?, Void?>() {
                override fun doInBackground(vararg voids: Void?): Void? {
                    if (InternetConnection.checkConnection(mContext)) {
                        isCalled = true
                        runOnUiThread {
                            if (btnDelete.visibility == View.GONE) {
                                if (!isLoaded) {
//                                    loadAds()
                                } else {
//                                    mIcSubcription!!.show()
                                }
                            }
                        }
                    } else {
                        runOnUiThread {
                            if (!isLoaded) {
                                if (btnDelete.visibility == View.GONE) {
//                                    mIcSubcription!!.hide()
                                }
                            }
                        }
                    }
                    return null
                }
            }.execute()
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun initViewAction() {
        mBack_img!!.setOnClickListener {
            onBackPressed()
        }

        btnDelete.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    if (viewPager!!.currentItem == 0) {
                        //TODO Delete Images
                        if (MyImagesFragment.myPhotosAdapter!!.getTrueDeleteImageList().size == 0) {
                            Toast.makeText(
                                mContext,
                                "Please select image to delete",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            dialogSave = DiscardDialogFragment(
                                "Delete",
                                 resources.getString(R.string.deleteSentence),
                                R.drawable.ic_dialog_delete,
                                "Cancel",
                                "Delete"
                            )
                            { s, discardDialogFragment ->
                                if (s == "ok") {
                                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                                    discardDialogFragment.dismiss()
                                    Constants.currentViewPagerItem = viewPager!!.currentItem
                                    deleteData(true)
                                } else {
                                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                                    discardDialogFragment.dismiss()
                                }
                            }
                            dialogSave!!.isCancelable = false
                            dialogSave!!.show(supportFragmentManager, "dialog")
                        }
                    } 
                    else if (viewPager!!.currentItem == 1) {
                        //TODO Delete Video
                        if (MyVideosFragment.myPhotosAdapter!!.getTrueDeleteVideoList().size == 0) {
                            Toast.makeText(
                                mContext,
                                "Please select video to delete",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            dialogSave = DiscardDialogFragment(
                                "Delete",
                                resources.getString(R.string.deleteSentence),
                                R.drawable.ic_dialog_delete,
                                "Cancel",
                                "Delete"
                            )
                            { s, discardDialogFragment ->
                                if (s == "ok") {
                                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                                    discardDialogFragment.dismiss()
                                    Constants.currentViewPagerItem = viewPager!!.currentItem
                                    deleteData(false)
                                } else {
                                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                                    discardDialogFragment.dismiss()
                                }
                            }
                            dialogSave!!.isCancelable = false
                            dialogSave!!.show(supportFragmentManager, "dialog")
                        }
                    }
                    else if(viewPager!!.currentItem == 2){
                        //TODO Delete Draft
                        //TODO Delete Images
                        if (MyDraftFragment.myDraftAdapter!!.getTrueDeleteImageList().size == 0) {
                            Toast.makeText(
                                mContext,
                                "Please select image to delete",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            dialogSave = DiscardDialogFragment(
                                "Delete",
                                resources.getString(R.string.deleteDraftSentence),
                                R.drawable.ic_dialog_delete,
                                "Cancel",
                                "Delete"
                            )
                            { s, discardDialogFragment ->
                                if (s == "ok") {
                                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                                    discardDialogFragment.dismiss()
                                    Constants.currentViewPagerItem = viewPager!!.currentItem
                                    deleteData(true)
//                                    val deleteDraftList = MyDraftFragment.myDraftAdapter!!.getDeleteImageList()
//                                    Log.d(TAG, "initViewAction: deleteDraftList ${deleteDraftList.size}")
                                } else {
                                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                                    discardDialogFragment.dismiss()
                                }
                            }
                            dialogSave!!.isCancelable = false
                            dialogSave!!.show(supportFragmentManager, "dialog")
                        }
                    }
                } catch (e: Exception) { }
            },250)
        }
    }
    var mDeleteList: ArrayList<String> = ArrayList()

    private fun deleteData(containImages: Boolean) {
        val uris = arrayListOf<Uri>()
        var mDeleteFiles: ArrayList<PhotoModelCreation> = ArrayList()
        mDeleteList.clear()
        Log.d(TAG, "deleteValue: ${viewPager!!.currentItem}")
        mDeleteFiles.clear()
        try {
            when (viewPager!!.currentItem) {
                0 -> {
                    mDeleteFiles = MyImagesFragment.myPhotosAdapter!!.getDeleteImageList()
                }
                1 -> {
                    mDeleteFiles = MyVideosFragment.myPhotosAdapter!!.getDeleteVideoList()
                }
                2 -> {
                    mDeleteFiles = MyDraftFragment.myDraftAdapter!!.getDeleteImageList()
                }
            }
        } catch (e: Exception) { }
        finally {
            if (mDeleteFiles.isNullOrEmpty())
                return
        }

        for (i in mDeleteFiles.indices) {
            if (mDeleteFiles[i].isDelete && !mDeleteFiles[i].isHeader) {
                Log.d("deleteValue", "deleteImages: ${mDeleteFiles[i].path}")
                val ffile = File(mDeleteFiles[i].path!!)
                if (viewPager!!.currentItem == 2){
                    db.draftDao().deleteDraftRecord(mDeleteFiles[i].path!!)
                    ffile.delete()
                }else{
                    val result = ffile.delete()
                    if (!result && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        try {
                            var projection: Array<String>
                            var selection = ""
                            var queryUri: Uri? = null
                            if (containImages) {
                                projection = arrayOf<String>(MediaStore.Images.Media._ID)
                                selection = MediaStore.Images.Media.DATA.toString() + " = ?"
                                queryUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                            } else {
                                projection = arrayOf<String>(MediaStore.Video.Media._ID)
                                selection = MediaStore.Video.Media.DATA.toString() + " = ?"
                                queryUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            }

                            // Match on the file path
                            val selectionArgs = arrayOf<String>(ffile.absolutePath)

                            // Query for the ID of the media matching the file path
//                        val queryUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                            val contentResolver = contentResolver
                            val c: Cursor? = contentResolver.query(
                                queryUri,
                                projection,
                                selection,
                                selectionArgs,
                                null
                            )

                            if (c != null) {
                                if (c.moveToFirst()) {
                                    // We found the ID. Deleting the item via the content provider will also remove the file
                                    var id: Long = 0
                                    if (containImages) {
                                        id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                                    } else {
                                        id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                                    }

                                    val deleteUri: Uri = ContentUris.withAppendedId(queryUri, id)
                                    Log.d(TAG, "deleteImages: deleteUri $deleteUri")
                                    try {
                                        uris.add(deleteUri)
//                                    contentResolver.delete(deleteUri, null, null)
//                                    MediaStore.createDeleteRequest(requireContext().contentResolver, arrayOf(deleteUri).toList())
                                    } catch (securityException: SecurityException) {
                                        securityException.printStackTrace()
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                            val recoverableSecurityException =
                                                securityException as? RecoverableSecurityException
                                                    ?: throw securityException
                                        } else {
                                            throw securityException
                                        }
                                    }
                                } else {
                                    Log.d(TAG, "deleteImages: File not found in media store DB")
                                    // File not found in media store DB
                                }
                                c.close()
                                /*if (!mIsSubScribe && mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
                                    lottieAds?.show()
                                }*/
                                Log.d(TAG, "deleteImages: Inside IF Cursor")
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Log.d(TAG, "deleteImages: Exception : ${e.printStackTrace()}")
                        }

                    }
                    else {
                        btnDelete.hide()
                        mDeleteList.add(ffile.absolutePath)
                        MediaScannerConnection.scanFile(
                            mContext,
                            arrayOf(mDeleteFiles[i].path),
                            null
                        ) { _, _ -> }
                    }
                }
            }
        }
        Log.d(TAG, "deleteData: uris ${uris.size}")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (uris.isNotEmpty()) {
                deleteImagesD(uris)
            } else {
                initViewPager()
            }
        } else {
            initViewPager()
        }


    }

    override fun isLongClickPressed(isVisible: Boolean) {
        if (isVisible) {
            btnDelete.show()
            btnPremium!!.hide()
//            lottieAds!!.hide()
        } else {
            btnDelete.hide()
            if (!MySharedPreferences(this).isSubscribe) {
                btnPremium!!.show()
            }
            if (isOnline()) {
                if (!AdsPrefs.getBoolean(
                        mContext,
                        AdsPrefs.IS_SUBSCRIBED,
                        false
                    )
                ) {
                    if (!isLoaded) {
//                        loadAds()
                    } else {
//                        mIcSubcription!!.show()
                    }
                }
            }
        }
    }


    override fun onPause() {
        super.onPause()
        try {
            if (dialogSave != null && dialogSave!!.isShowing()) {
                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                dialogSave!!.dismiss()
                userDenyRequest = true
            }
        } catch (e: Exception) {
        }
    }

    private fun initViewPager() {
        myImagesFragment = MyImagesFragment()
        myVideosFragment = MyVideosFragment()
        myDraftFragment = MyDraftFragment()

        btnDelete.hide()
        Log.d(TAG, "initViewPager: Del Hide 1")
//        mIcSubcription!!.hide()

        viewPager!!.adapter = TabAdapter(mContext, 3)
//        viewPager!!.adapter = TabAdapter(mContext, 2)
        viewPager!!.currentItem = 0

        mTabLayout!!.addTab(mTabLayout!!.newTab().setText("Images"))
        mTabLayout!!.addTab(mTabLayout!!.newTab().setText("Videos"))
        mTabLayout!!.addTab(mTabLayout!!.newTab().setText("Draft"))

        viewPager!!.setCurrentItem(Constants.currentViewPagerItem, false)
        viewPager!!.offscreenPageLimit = ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT
        viewPager?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageScrolled(
                position: Int, positionOffset: Float,
                @Px positionOffsetPixels: Int,
            ) {
                when (viewPager?.currentItem) {
                    0 -> {
                        txtImages?.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_photo_selected)
                        )
                        txtVideos?.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_video_unselected)
                        )
                        txtDraft.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_draft_unselected)
                        )
                    }
                    1 -> {
                        txtImages?.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_photo_unselected)
                        )
                        txtVideos?.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_video_selected)
                        )
                        txtDraft.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_draft_unselected)
                        )
                    }
                    2 -> {
                        txtImages?.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_photo_unselected)
                        )
                        txtVideos?.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_video_unselected)
                        )
                        txtDraft.setImageDrawable(
                            ContextCompat.getDrawable(mContext, R.drawable.ic_draft_selected)
                        )
                    }
                }
            }

            override fun onPageSelected(position: Int) {
                try {
                    if (viewPager!!.currentItem == 0) {
                        MyImagesFragment.myPhotosAdapter!!.makeAllVisible(false)
                        txtImages?.setImageDrawable(
                            ContextCompat.getDrawable(
                                mContext,
                                R.drawable.ic_photo_selected
                            )
                        )
                        txtVideos?.setImageDrawable(
                            ContextCompat.getDrawable(
                                mContext,
                                R.drawable.ic_video_unselected
                            )
                        )

                        if (MyImagesFragment.mConstraintImagesNotFound!!.visibility == View.VISIBLE) {
                            btnDelete.hide()
                            Log.d(TAG, "initViewPager: Del Hide 4")
                            if (isOnline()) {
                                if (!AdsPrefs.getBoolean(
                                        mContext,
                                        AdsPrefs.IS_SUBSCRIBED,
                                        false
                                    )
                                ) {
                                    if (!isLoaded) {
//                                        loadAds()
                                    } else {
//                                        mIcSubcription!!.show()
                                    }
                                }
                            }
                        } else {
                            if (MyImagesFragment.myPhotosAdapter!!.getisLongCliked()) {
                                btnDelete.show()
//                                mIcSubcription!!.hide()
//                                lottieAds!!.hide()
                            } else {
                                btnDelete.hide()
                                Log.d(TAG, "initViewPager: Del Hide 5")
                                if (isOnline()) {
                                    if (!AdsPrefs.getBoolean(
                                            mContext,
                                            AdsPrefs.IS_SUBSCRIBED,
                                            false
                                        )
                                    ) {
                                        //mIcSubcription!!.show()
                                        if (!isLoaded) {
//                                            loadAds()
                                        } else {
//                                            mIcSubcription!!.show()
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (viewPager!!.currentItem == 1) {
                        MyVideosFragment.myPhotosAdapter!!.makeAllVisible(false)
                        txtVideos?.setImageDrawable(
                            ContextCompat.getDrawable(
                                mContext,
                                R.drawable.ic_video_selected
                            )
                        )
                        txtImages?.setImageDrawable(
                            ContextCompat.getDrawable(
                                mContext,
                                R.drawable.ic_photo_unselected
                            )
                        )

                        if (MyVideosFragment.mConstraintVideoNotFound!!.visibility == View.VISIBLE) {
                            btnDelete.hide()
                            Log.d(TAG, "initViewPager: Del Hide 6")
                            if (isOnline()) {
                                if (!AdsPrefs.getBoolean(
                                        mContext,
                                        AdsPrefs.IS_SUBSCRIBED,
                                        false
                                    )
                                ) {
                                    if (!isLoaded) {
//                                        loadAds()
                                    } else {
//                                        mIcSubcription!!.show()
                                    }
                                }
                            }
                        } else {
                            if (MyVideosFragment.myPhotosAdapter!!.getisLongCliked()) {
                                btnDelete.show()
//                                btnPremium!!.hide()
//                                mIcSubcription!!.hide()
//                                lottieAds!!.hide()
                            } else {
                                btnDelete.hide()
                                Log.d(TAG, "initViewPager: Del Hide 7")
                                if (isOnline()) {
                                    if (!AdsPrefs.getBoolean(
                                            mContext,
                                            AdsPrefs.IS_SUBSCRIBED,
                                            false
                                        )
                                    ) {
//                                        mIcSubcription!!.show()
                                        if (!isLoaded) {
//                                            loadAds()
                                        } else {
//                                            mIcSubcription!!.show()
                                        }
                                    }
                                }
                            }
                        }

                    }
                    else if (viewPager!!.currentItem == 2){
                        MyDraftFragment.myDraftAdapter!!.makeAllVisible(false)
                    }
                } catch (ex: Exception) { }
//                Handler(Looper.getMainLooper()).postDelayed({
                if (MySharedPreferences(
                        mContext
                    ).isSubscribe){
                    btnPremium!!.hide()
                }else{
                    btnDelete.hide()
                    Log.d(TAG, "initViewPager: Del Hide 8")
                    btnPremium!!.show()
                }
//                }, 200)
            }

            override fun onPageScrollStateChanged(@ScrollState state: Int) {}
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d(TAG, "onActivityResult: requestCode = $requestCode resultCode = $resultCode")
        if (requestCode == 1212) {
            findViewById<View>(R.id.fl_adplaceholder).show()
            OfflineNativeAdvancedHelper.loadOfflineNativeAdvanceEditScreen(
                mContext,
                findViewById(R.id.fl_adplaceholder)
            ) {
                if (it == 0){
                    findViewById<FrameLayout>(R.id.fl_adplaceholder).hide()
                }else if (it == 1){
                    findViewById<FrameLayout>(R.id.fl_adplaceholder).show()
                }
            }
        }
        if (requestCode == DELETE_PERMISSION_REQUEST && resultCode == Activity.RESULT_OK) {
            initViewPager()
            userDenyRequest = false
            if (!MySharedPreferences(this).isSubscribe) {
                btnPremium!!.show()
            } else {
                btnPremium!!.hide()
            }
            /*if (!mIsSubScribe && mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
                lottieAds?.show()
            }else{
                lottieAds?.hide()
            }*/
        } else if (requestCode == DELETE_PERMISSION_REQUEST && resultCode == Activity.RESULT_CANCELED) {
            if (mDeleteList.size > 0) initViewPager()
            userDenyRequest = true
        }
        /*else{
            btnPremium!!.hide()
//            lottieAds?.hide()
        }*/
        if (requestCode == 1111 && resultCode == 1144) {
            MySharedPreferences(this).isSubscribe = try {
                MySharedPreferences(this).isSubscribe
            } catch (e: Exception) {
                false
            }
            if (MySharedPreferences(this).isSubscribe) {
                btnPremium!!.hide()
            }
        }
        if (requestCode == 8888 && resultCode == RESULT_OK) {
            var mDeleteFiles: ArrayList<PhotoModelCreation> = ArrayList()
            if (viewPager!!.currentItem == 0) {
                mDeleteFiles = MyImagesFragment.myPhotosAdapter!!.getDeleteImageList()
            } else if (viewPager!!.currentItem == 1) {
                mDeleteFiles = MyVideosFragment.myPhotosAdapter!!.getDeleteVideoList()
            }
            for (i in mDeleteFiles.indices) {
                if (mDeleteFiles[i].isDelete && !mDeleteFiles[i].isHeader) {
                    val ffile = File(mDeleteFiles[i].path)
                    val result = ffile.delete()
                    Log.d("onActivityResult", "deleteImages: $result")
                }
            }
            if (viewPager!!.currentItem == 0) {
                MyImagesFragment.myPhotosAdapter!!.makeAllVisible(false)
            } else if (viewPager!!.currentItem == 1) {
                MyVideosFragment.myPhotosAdapter!!.makeAllVisible(false)
            }
//            Toast.makeText(mContext, "Delete successfully", Toast.LENGTH_SHORT).show()
            initViewPager()
        }
    }

    private fun loadNativeAd() {
        Log.d(TAG, "onActivityResult: loadNativeAd ${MySharedPref(this).getAdsClicked()}")
        Log.d(TAG, "onActivityResult: loadNativeAd Net conn ${isOnline()}")
        if (MySharedPref(this).getAdsClicked() && isOnline()){
            OfflineNativeAdvancedHelper.loadOfflineNativeAdvanceEditScreen(
                mContext,
                findViewById(R.id.fl_adplaceholder)
            ) {
                findViewById<View>(R.id.FlOfflineAds).hide()
                when (it) {
                0    -> findViewById<FrameLayout>(R.id.fl_adplaceholder).hide()
                1    -> findViewById<FrameLayout>(R.id.fl_adplaceholder).show()
                else -> findViewById<FrameLayout>(R.id.fl_adplaceholder).hide()
                }
            }
        }else{
            findViewById<FrameLayout>(R.id.fl_adplaceholder).hide()
            if (MySharedPref(this).getAdsClicked()){
                findViewById<View>(R.id.FlOfflineAds).hide()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun deleteImages(containImages: Boolean) {
        var uris = arrayListOf<Uri>()
        var mDeleteFiles: ArrayList<PhotoModelCreation> = ArrayList()
        Log.d(TAG, "deleteValue: ${viewPager!!.currentItem}")
        when (viewPager!!.currentItem) {
            0 -> {
                mDeleteFiles = MyImagesFragment.myPhotosAdapter!!.getDeleteImageList()
            }
            1 -> {
                mDeleteFiles = MyVideosFragment.myPhotosAdapter!!.getDeleteVideoList()
            }
        }
        for (i in mDeleteFiles.indices) {
            if (mDeleteFiles[i].isDelete && !mDeleteFiles[i].isHeader) {
                Log.d("deleteValue", "deleteImages: ${mDeleteFiles[i].path}")
                val ffile = File(mDeleteFiles[i].path)
                //if (myFile.exists()) {

                val result = ffile.delete()
                if (!result) {
                    try {
                        var projection: Array<String>
                        var selection = ""
                        var queryUri: Uri? = null
                        if (containImages) {
                            projection = arrayOf<String>(MediaStore.Images.Media._ID)
                            selection = MediaStore.Images.Media.DATA.toString() + " = ?"
                            queryUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        } else {
                            projection = arrayOf<String>(MediaStore.Video.Media._ID)
                            selection = MediaStore.Video.Media.DATA.toString() + " = ?"
                            queryUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        }

                        // Match on the file path
                        val selectionArgs = arrayOf<String>(ffile.absolutePath)

                        // Query for the ID of the media matching the file path
//                        val queryUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        val contentResolver = contentResolver
                        val c: Cursor? = contentResolver.query(
                            queryUri,
                            projection,
                            selection,
                            selectionArgs,
                            null
                        )

                        if (c != null) {
                            if (c.moveToFirst()) {
                                // We found the ID. Deleting the item via the content provider will also remove the file
                                var id: Long = 0
                                if (containImages) {
                                    id =
                                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                                } else {
                                    id =
                                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                                }

                                val deleteUri: Uri = ContentUris.withAppendedId(queryUri, id)
                                Log.d(TAG, "deleteImages: $deleteUri")
                                try {
                                    uris.add(deleteUri)
                                    //contentResolver.delete(deleteUri, null, null)
                                    //MediaStore.createDeleteRequest(requireContext().contentResolver, arrayOf(deleteUri).toList())
                                } catch (securityException: SecurityException) {
                                    securityException.printStackTrace()
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                        val recoverableSecurityException =
                                            securityException as? RecoverableSecurityException
                                                ?: throw securityException
                                    } else {
                                        throw securityException
                                    }
                                }
                            } else {
                                // File not found in media store DB
                            }
                            c.close()
                            /*if (!mIsSubScribe && mInterstitialAd != null && mInterstitialAd!!.isLoaded) {
                                lottieAds?.show()
                            }*/
                            Log.d(TAG, "deleteImages: Inside IF Cursor")
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Log.d(TAG, "deleteImages: Exception : ${e.printStackTrace()}")
                    }
                } else {
                    Log.d(TAG, "deleteImages: Outside !result (else)")
                    initViewPager()
                    try {
                        this.sendBroadcast(
                            Intent(
                                Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                                Uri.fromFile(File(ffile.absolutePath))
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }

            }
        }
        Log.d(TAG, "deleteImages: ${uris.size} public")
        if (uris.isNotEmpty()) {
            Log.d(TAG, "deleteImages: deleteImagesD ")
            deleteImagesD(uris)
            return
        }
        if (viewPager!!.currentItem == 0) {
            MyImagesFragment.myPhotosAdapter!!.makeAllVisible(false)
        } else if (viewPager!!.currentItem == 1) {
            MyVideosFragment.myPhotosAdapter!!.makeAllVisible(false)
        }
//        Toast.makeText(mContext, "Delete successfully", Toast.LENGTH_SHORT).show()
        initViewPager()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun deleteImagesD(uris: List<Uri>) {
        Log.d(TAG, "deleteImages: $uris in deleteImagesD")
        val pendingIntent = MediaStore.createDeleteRequest(this.contentResolver, uris.filter {
            this.checkUriPermission(
                it,
                Binder.getCallingPid(),
                Binder.getCallingUid(),
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            ) != PackageManager.PERMISSION_GRANTED
        })
        startIntentSenderForResult(
            pendingIntent.intentSender,
            DELETE_PERMISSION_REQUEST,
            null,
            0,
            0,
            0,
            null
        )
    }


    /*private fun showAd() {
        if (isOnline() || isLoaded) {
            if (requestNewInterstitial()) {
                mInterstitialAd!!.adListener = object : AdListener() {
                    override fun onAdClosed() {
                        super.onAdClosed()
                        loadAds()
                        Constants.isAdsShow = false
//                        mIcSubcription!!.hide()
                    }

                    override fun onAdFailedToLoad(i: Int) {
                        super.onAdFailedToLoad(i)
                        loadAds()
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        if (!AdsPrefs.getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
                            if (btnDelete.visibility != View.VISIBLE) {
//                                mIcSubcription!!.show()
                            }
                        }
                    }
                }
            } else {
                showToast("Loading...")
            }
        } else {
            showToast("no internet connection")
        }
    }*/

    override fun onBackPressed() {
        
            if (btnDelete.visibility == View.VISIBLE) {
                if (!MySharedPreferences(
                        this
                    ).isSubscribe) {
                    btnPremium!!.show()
                }
                when (viewPager!!.currentItem) {
                    0 -> {
                        isLongClickPressed(false)
                        MyImagesFragment.myPhotosAdapter?.makeAllVisible(false)
                    }
                    1 -> {
                        isLongClickPressed(false)
                        MyVideosFragment.myPhotosAdapter?.makeAllVisible(false)
                    }
                    2 -> {
                        isLongClickPressed(false)
                        MyDraftFragment.myDraftAdapter?.makeAllVisible(false)
                    }
                }
            } else {
                Constants.currentViewPagerItem = 0
                super.onBackPressed()
            }
        
    }

    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.d("myReceiver", "onReceive: ads ")
            object : AsyncTask<Void?, Void?, Void?>() {
                override fun doInBackground(vararg voids: Void?): Void? {
                    if (!AdsPrefs.getBoolean(
                            mContext,
                            AdsPrefs.IS_SUBSCRIBED,
                            false
                        )
                    ) {
                        if (InternetConnection.checkConnection(mContext)) {
                            runOnUiThread {
                                if (btnDelete.visibility == View.GONE) {
//                                    mIcSubcription!!.show()
                                    if (!isLoaded) {
//                                        loadAds()
                                    } else {
//                                        mIcSubcription!!.show()
                                    }
                                }
                            }
                        } else {
                            isCalled = false
                            runOnUiThread {
                                if (!isLoaded) {
                                    if (btnDelete.visibility == View.GONE) {
//                                        mIcSubcription!!.hide()
                                    }
                                }
                            }
                        }
                    }
                    return null
                }
            }.execute()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!AdsPrefs.getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
            unregisterReceiver(mNetworkReceiver)
            unregisterReceiver(receiver)
        }
        Constants.isSaveUpdate  = false
        Constants.isDraftUpdate = false
    }

    override fun onResume() {
        super.onResume()
        if (MySharedPreferences(this).isSubscribe) {
            btnPremium!!.hide()
            findViewById<View>(R.id.FlOfflineAds).hide()
            findViewById<View>(R.id.fl_adplaceholder).hide()
        } else {
            loadNativeAd()
            if (userDenyRequest) {
                userDenyRequest = false
                if (btnDelete.visibility == View.GONE)
                    btnPremium!!.show()
                Log.d(TAG, "onResume: btnPremium!!.hide() 1")
            } else {
                if (btnDelete.visibility == View.VISIBLE){
                    btnPremium!!.hide()
                    Log.d(TAG, "onResume: btnPremium!!.hide() 2")
                }else{
                    btnPremium!!.show()
                    Log.d(TAG, "onResume: btnPremium!!.show() 3")
                }
            }
        }
        if (Constants.isDeleteOperationPerform) {
            Constants.isDeleteOperationPerform = false
            initViewPager()
        }
    }

    //Ads
    private val isLoaded: Boolean
        get() {
            try {
                if (mInterstitialAd!!.isLoaded && mInterstitialAd != null) {
                    return true
                }
            } catch (e: Exception) {
            }
            return false
        }

    private fun requestNewInterstitial(): Boolean {
        try {
            if (mInterstitialAd!!.isLoaded) {
                mInterstitialAd!!.show()
                return true
            }
        } catch (e: Exception) {
        }
        return false
    }

    /*private fun loadAds() {
        mInterstitialAd = InterstitialAd(this)
        val interstialAdId = AppIDs().getGoogleInterstitial(0)
        Log.d("InterstitialAds", "${interstialAdId}")
        mInterstitialAd!!.adUnitId = interstialAdId
        mInterstitialAd!!.loadAd(AdRequest.Builder().build())
        mInterstitialAd!!.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
                if ((ivDelete.visibility == View.GONE || ivDelete.visibility == View.INVISIBLE) && !mIsSubScribe) {
                    lottieAds!!.show()
                } else {
                    lottieAds!!.visibility = View.INVISIBLE
                }

                Log.d("InterstitialAds", "onAdLoaded")
            }

            override fun onAdImpression() {
                super.onAdImpression()
                Log.d("InterstitialAds", "onAdImpression")
            }

            override fun onAdLeftApplication() {
                super.onAdLeftApplication()
                Log.d("InterstitialAds", "onAdLeftApplication")

            }

            override fun onAdClicked() {
                super.onAdClicked()
                Log.d("InterstitialAds", "onAdClicked")
            }

            override fun onAdFailedToLoad(p0: LoadAdError?) {
                super.onAdFailedToLoad(p0)
                lottieAds!!.hide()
                mInterstitialAd = null
                loadAds()
                Log.d("InterstitialAds", "LoadAdError")
            }

            override fun onAdClosed() {
                super.onAdClosed()
                lottieAds!!.hide()
                mInterstitialAd!!.loadAd(AdRequest.Builder().build())
            }

            override fun onAdOpened() {
                super.onAdOpened()
            }
        }

        try {
            mInterstitialAd = InterstitialAd(this)

            val interstialAdId = AppIDs().getGoogleInterstitial(0)

            mInterstitialAd!!.adUnitId = interstialAdId

            if (!AppIDs.isTest) {
                return
            }

            ins_adRequest = AdRequest.Builder().addTestDevice("1430CCBBF6C738012B76659D054E081E") //SWIPE
                    .build()
            mInterstitialAd!!.loadAd(ins_adRequest)
            mInterstitialAd!!.adListener = object : AdListener() {
                override fun onAdClosed() {
                    super.onAdClosed()
                    Constants.isAdsShow = false
                    Log.e("ADS", "onAdClosed: ")
                    mIcSubcription!!.hide()
                }

                override fun onAdFailedToLoad(i: Int) {
                    super.onAdFailedToLoad(i)
                    Log.e("ADS", "onAdFailedToLoad: ")
                }

                override fun onAdLeftApplication() {
                    super.onAdLeftApplication()
                    Log.e("ADS", "onAdLeftApplication: ")
                }

                override fun onAdOpened() {
                    super.onAdOpened()
                    Log.e("ADS", "onAdOpened: ")
                }

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    Log.e("ADS", "onAdLoaded: ")
                    if (!AdsPrefs.getBoolean(mContext, AdsPrefs.IS_SUBSCRIBED, false)) {
                        if (btnDelete.visibility != View.VISIBLE) {
                            mIcSubcription!!.show()
                        }
                    }
                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    Log.e("ADS", "onAdClicked: ")
                }

                override fun onAdImpression() {
                    super.onAdImpression()
                    Log.e("ADS", "onAdImpression: ")
                }
            }
        } catch (e: Exception) { }
    }*/



}