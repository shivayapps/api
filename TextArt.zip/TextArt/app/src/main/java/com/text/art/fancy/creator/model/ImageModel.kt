package com.text.art.fancy.creator.model

import java.io.Serializable

data class ImageModel(var path: String, var isSelect: Boolean) : Serializable
