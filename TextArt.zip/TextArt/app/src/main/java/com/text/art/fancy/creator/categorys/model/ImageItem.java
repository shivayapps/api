package com.text.art.fancy.creator.categorys.model;

import com.google.gson.annotations.SerializedName;
import com.tattoo.body.name.girls.boys.photo.editor.categorys.DownloadStatus;

import java.io.Serializable;

//import com.pip.camera.art.filter.photo.effect.editor.utils.DownloadStatus;

public class ImageItem implements Serializable {

	@SerializedName("image")
	private String image;

	@SerializedName("category_id")
	private int categoryId;

	@SerializedName("thumb_image")
	private String thumbImage;

	@SerializedName("id")
	private int id;

	@SerializedName("is_premium")
	private int is_premium;

	@SerializedName("coins")
	private int coins;

	private com.tattoo.body.name.girls.boys.photo.editor.categorys.DownloadStatus DownloadStatus;

	public void setImage(String image){
		this.image = image;
	}

	public String getImage(){
		return image;
	}

	public void setCategoryId(int categoryId){
		this.categoryId = categoryId;
	}

	public int getCategoryId(){
		return categoryId;
	}

	public void setThumbImage(String thumbImage){
		this.thumbImage = thumbImage;
	}

	public String getThumbImage(){
		return thumbImage;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public int getIs_premium() {
		return is_premium;
	}

	public void setIs_premium(int is_premium) {
		this.is_premium = is_premium;
	}

	public int getCoins() {
		return coins;
	}

	public void setCoins(int coins) {
		this.coins = coins;
	}

	public DownloadStatus getDownloadStatus() {
		return DownloadStatus;
	}

	public void setDownloadStatus(DownloadStatus downloadStatus) {
		DownloadStatus = downloadStatus;
	}

	@Override
 	public String toString(){
		return 
			"ImageItem{" + 
			" image = '" + image + '\'' +
			",category_id = '" + categoryId + '\'' +
			",thumb_image = '" + thumbImage + '\'' + 
			",id = '" + id + '\'' + 
			"}";
		}
}