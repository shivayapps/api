package com.text.art.fancy.creator.adepter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.model.LottieData
import com.text.art.fancy.creator.R

class LottieEditTextAdapter(
    private var lottieDataList: ArrayList<LottieData>,
    private var lottieChangeListener: LottieChangeListener
): RecyclerView.Adapter<LottieEditTextAdapter.MyHolder>() {

    class MyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var editText = itemView.findViewById<EditText>(R.id.lottieEditText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        return MyHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_lottieedittext,parent,false))
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        with(holder){
            val text = lottieDataList[0].layertype!!.text!![position]!!.textID
            editText.setText(text)
            editText.isVerticalScrollBarEnabled = true
            editText.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {

                }

                override fun onTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {

                }

                override fun afterTextChanged(s: Editable?) {
                    lottieChangeListener.textChange(text.toString(), s!!)
                }
            })
        }
    }

    override fun getItemCount(): Int {
        return lottieDataList[0].layertype!!.text!!.size
    }
}

interface LottieChangeListener{
    fun textChange(textID: String,s: Editable)
}