package com.text.art.fancy.creator.activitys

import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.utils.getStatusbarHeight
import com.text.art.fancy.creator.utils.hideSystemUI
import kotlinx.android.synthetic.main.activity_setting.mTermsToolbar
import kotlinx.android.synthetic.main.activity_terms_condition.*

class TermsConditionActivity : AppCompatActivity() {

    private var mTermsConditionActivity:TermsConditionActivity?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terms_condition)

        mTermsConditionActivity = this@TermsConditionActivity

        mMainTermAndCondition.invalidate();
        try {
            mTermsAndConditionToolbar.setPadding(0, getStatusbarHeight(), 0, 0)
        } catch (e: Exception) {
        }

        hideSystemUI()

        findViewById<View>(R.id.icBack).setOnClickListener { finish() }

        findViewById<View>(R.id.btnShare).setOnClickListener { onclickShare() }

    }

    private fun onclickShare() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "TextArt")
        var shareMessage = "\nGo with TextArt and Make Someone's day very special....\n\n"
        shareMessage += "https://play.google.com/store/apps/details?id=${packageName}"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, resources.getString(R.string.choose_one)))
    }
}