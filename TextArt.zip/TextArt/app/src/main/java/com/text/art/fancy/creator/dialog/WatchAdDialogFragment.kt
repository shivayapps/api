package com.text.art.fancy.creator.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.fragment.app.DialogFragment
import com.text.art.fancy.creator.R

import com.text.art.fancy.creator.data.MySharedPreferences
import kotlinx.android.synthetic.main.dialog_watch_ads.*

class WatchAdDialogFragment(
    private val txtMainTitle: String,
    private val txtProTitleName: String,
    private val txtProDescription: String,
    @DrawableRes private val resId: Int,
    private val txtAdsTitleDis: String,
    private val txtAdsDiscription: String,
    private val action: (String, WatchAdDialogFragment) -> Unit
) : DialogFragment() {

    private var bottomSheetDialog: Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NO_TITLE, R.style.materialButton)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.dialog_watch_ads, container, false)
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)
        try {
            iv_dialog_logo.setImageResource(resId)
            txtDialogTitle.text = txtMainTitle
            txtProTitle.text = txtProTitleName
            txtProDis.text = txtProDescription

            txtAdsTitle.text = txtAdsTitleDis
            txtAdsDis.text = txtAdsDiscription

            val fl_holder = view.findViewById<FrameLayout>(R.id.fl_adplaceholder)

//            if (!MySharedPreferences(context).isSubscribe) {
//                context?.let {
//                    try {
//                        val id = ReferenceClass().getKeysf("f_n2")
//                        FacebookNativeAdvancehelper.loadNative(
//                            it,
//                            fl_fb_holder,
//                            id
//                        ) { i ->
//                            if (i == 1) {
//                                activity?.let {
//                                    try {
//                                        OfflineNativeAdvancedHelper.loadOfflineNativeAdvanceBig(requireActivity(),fl_adplaceholder){}
//                                    } catch (e: Exception) {
//                                    }
////                                    NativeAdvanceHelper.loadAd(requireActivity(), fl_holder)
//                                }
//                            }
//                        }
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//                }
//            }


        } catch (e: Exception) {
            e.printStackTrace()
        }


        try {
            constraintLayout16.setOnClickListener {
//                    view.findViewById<View>(R.id.btnPositive).isEnabled = false
//                    view.findViewById<View>(R.id.btnNagative).isEnabled = false
                    action("watchAd", this@WatchAdDialogFragment)
                }
            btnPRO.setOnClickListener {
//                    view.findViewById<View>(R.id.btnNagative).isEnabled = false
//                    view.findViewById<View>(R.id.btnPositive).isEnabled = false
                    action("subscribe", this@WatchAdDialogFragment)
                }
            mCloseAds.setOnClickListener {
//                    view.findViewById<View>(R.id.btnNagative).isEnabled = false
//                    view.findViewById<View>(R.id.btnPositive).isEnabled = false
                    action("close", this@WatchAdDialogFragment)
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isShowing(): Boolean {
        return if (dialog != null)
            dialog!!.isShowing
        else
            false
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        try {
            bottomSheetDialog = dialog
            val displayMetrics = DisplayMetrics()
            requireActivity().windowManager.defaultDisplay.getMetrics(displayMetrics)
            val height = displayMetrics.heightPixels
            var width = displayMetrics.widthPixels
            width -= width / 8
            bottomSheetDialog!!.window!!.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return dialog
    }
}