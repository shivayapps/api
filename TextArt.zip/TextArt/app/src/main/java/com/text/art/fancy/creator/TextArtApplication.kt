package com.text.art.fancy.creator

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDex
import com.text.art.fancy.creator.activitys.SplashScreenActivity
import com.text.art.fancy.creator.ads.AdsHelper
import com.text.art.fancy.creator.ads.AppOpenManager
import com.text.art.fancy.creator.ads.OfflineNativeAdvancedHelper
import com.text.art.fancy.creator.ads.ReferenceClass
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.handler.ExampleNotificationReceivedHandler
import com.text.art.fancy.creator.manager.ApplicationLifecycleManager
import com.text.art.fancy.creator.utils.InternetConnection
import com.text.art.fancy.creator.utils.MySharedPref
import com.text.art.fancy.creator.utils.context
import com.facebook.ads.*
import com.google.android.gms.ads.MobileAds
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.vasundhara.vision.subscription.AppSubscription
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


class TextArtApplication : AppSubscription(), LifecycleObserver {
    var mInterstitialAdfb: InterstitialAd? = null
    var mInterstitialAdfb1: InterstitialAd? = null

    var appOpenManager: AppOpenManager? = null

    var mySharedPref: MySharedPref? = null
    private var TAG = "TextArtApplication"

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onEnteredForeground() {
        Log.d(TAG, "onEnteredForeground")
        try {
            var currentClassName = ""
            try {
                val am: ActivityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
                val taskInfo: List<ActivityManager.RunningTaskInfo> = am.getRunningTasks(1)
                currentClassName = taskInfo[0].topActivity?.className.toString()
//                currentClassName = this.javaClass.simpleName
                Log.d(TAG, "$currentClassName")
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (mySharedPref?.getAdsCount()!! == 5 && !Constants.isAdsShow && !MySharedPreferences(
                    this
                ).isSubscribe && currentClassName != "com.text.art.fancy.creator.activitys.SplashScreenActivity" &&
                currentClassName != "com.google.android.gms.ads.AdActivity" &&
                currentClassName != "com.text.art.fancy.creator.activitys.FullMyPhotoActivity" &&
                currentClassName != "com.text.art.fancy.creator.activitys.EditAnimationActivity"
            ) {
                appOpenManager?.showAdIfAvailable {
                    when (it) {
                        AppOpenManager.CallBackType.DISMISS -> {
                            appOpenManager = AppOpenManager(applicationContext)
                            mySharedPref?.setAdsCount(0)
                        }
                        AppOpenManager.CallBackType.FAILED -> {
                            if (mySharedPref?.getAdsCount()!! >= 5) {
                                mySharedPref?.setAdsCount(0)
                            }
                        }
                        AppOpenManager.CallBackType.ERROR -> {
                            if (mySharedPref?.getAdsCount()!! >= 5) {
                                mySharedPref?.setAdsCount(0)
                            }
                        }
                    }
                }
            }
            try {
                if (!appOpenManager!!.isAdAvailable()) {
                    Log.d(TAG, "onEnteredForeground: Ads Shown")
                    appOpenManager = AppOpenManager(applicationContext)
                }
            } catch (e: Exception) { }
            try {
                if (mySharedPref?.getAdsCount()!! >= 5) {
                    mySharedPref?.setAdsCount(0)
                }
            } catch (e: Exception) { }
        } catch (e: Exception) { }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    fun onEnteredBackground() {
        try {
            mySharedPref!!.setAdsCount((mySharedPref?.getAdsCount()?.plus(1)))
        } catch (e: Exception) { }
    }
    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun onDestroy() {
        try {
            OfflineNativeAdvancedHelper.onDestroy()
        } catch (e: Exception) { }
    }
    override fun attachBaseContext(base: Context?): Unit {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    @SuppressLint("PackageManagerGetSignatures")
    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this) {}
        AudienceNetworkAds.initialize(this)
        registerActivityLifecycleCallbacks(ApplicationLifecycleManager())
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        mySharedPref = MySharedPref(this@TextArtApplication)
        context = baseContext
        //OLD
        // OneSignal Initialization
        /*OneSignal.startInit(this)
            .setNotificationReceivedHandler(ExampleNotificationReceivedHandler())
            .setNotificationOpenedHandler(ExampleNotificationOpenedHandler())
            .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
            .unsubscribeWhenNotificationsAreDisabled(true)
            .init()*/

        //TODO Notification
        //NEW
        /*OneSignal.initWithContext(this)
        OneSignal.setAppId("934c33f4-8112-4e70-b4c3-55856231e06f")*/

        try {
            AdsHelper.isTest = false
            AppIDs.init(applicationContext, AppIDs.TEXT_ART, false)
        } catch (e: Exception) { }
        try {
            instance = this
            LoadAdsFb()
            LoadAdsFb1()
            // Test calling play() immediately (before TTS initialization is complete).
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                //Log.e("TAG", "KeyHash: >>>> " + Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (e: PackageManager.NameNotFoundException) {
        } catch (e: NoSuchAlgorithmException) {
        } catch (e: Exception) { }

        appOpenManager = AppOpenManager(this)

    }

    /*public static void adsGoogleBanner(Activity activity, int id) {

        boolean isNeedToShow = false;

        if (!SharedPrefs.contain(activity, SharedPrefs.IS_ADS_REMOVED)) {
            isNeedToShow = true;
        } else {
            if (!SharedPrefs.getBoolean(activity, SharedPrefs.IS_ADS_REMOVED))
                isNeedToShow = true;
            else
                isNeedToShow = false;
        }

        if (isNeedToShow) {
            try {
                final AdView mAdView = activity.findViewById(id);
                AdRequest adRequest = new AdRequest.Builder()
                        .addTestDevice("DDB94C276417D3D47927135DF4C5CDFA")
                        .build();

                mAdView.loadAd(adRequest);
                mAdView.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                    }

                    @Override
                    public void onAdFailedToLoad(int i) {
                        super.onAdFailedToLoad(i);
                        mAdView.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLeftApplication() {
                        super.onAdLeftApplication();
                    }

                    @Override
                    public void onAdOpened() {
                        super.onAdOpened();
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        mAdView.setVisibility(View.VISIBLE);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean isNeedToAdShow(Context context) {
        boolean isNeedToShow = true;

        if (!SharedPrefs.contain(context, SharedPrefs.IS_ADS_REMOVED)) {
            isNeedToShow = true;
        } else {
            if (!SharedPrefs.getBoolean(context, SharedPrefs.IS_ADS_REMOVED))
                isNeedToShow = true;

            else
                isNeedToShow = false;
        }
        return isNeedToShow;
    }*/
    fun LoadAdsFb() {
        try {
            val id = ReferenceClass().getKeysf("f_i1")/*if (AdsHelper.isTest) {
                getString(R.string.fb_interstial1)
            }else{
                ReferenceClass().getKeys("f_i1")
            }*/
            mInterstitialAdfb = InterstitialAd(this, id)
            if (InternetConnection.checkConnection(this)) {
                AdSettings.addTestDevice("ad901e97-f75f-4e97-8381-f6139372235c")
                /*mInterstitialAdfb!!.loadAd()
                mInterstitialAdfb!!.setAdListener(object : InterstitialAdListener {
                    override fun onInterstitialDisplayed(ad: Ad) { // Interstitial displayed callback
                        Log.e("TAG", "--> onInterstitialDisplayed")
                    }

                    override fun onInterstitialDismissed(ad: Ad) { // Interstitial dismissed callback
                        Log.e("TAG", "--> onInterstitialDismissed")
                    }

                    override fun onError(ad: Ad, adError: AdError) { // Ad error callback
                        Log.e("TAG", "onError --> " + adError.errorMessage)
                    }

                    override fun onAdLoaded(ad: Ad) { // Show the ad when it's done loading.
                        Log.e("TAG", "--> onAdLoaded")
                    }

                    override fun onAdClicked(ad: Ad) { // Ad clicked callback
                        Log.e("TAG", "--> onAdClicked")
                    }

                    override fun onLoggingImpression(ad: Ad) { // Ad impression logged callback
                        Log.e("TAG", "--> onLoggingImpression")
                    }
                })*/

                val interstitialAdListener = object : InterstitialAdListener {
                    override fun onInterstitialDisplayed(ad: Ad?) {
                        // Interstitial displayed callback
                        Log.e("TAG", "--> onInterstitialDisplayed")
                    }

                    override fun onInterstitialDismissed(ad: Ad?) {
                        // Interstitial dismissed callback
                        Log.e("TAG", "--> onInterstitialDismissed")
                    }

                    override fun onError(ad: Ad?, adError: AdError) {
                        // Ad error callback
                        Log.e("TAG", "onError --> " + adError.getErrorMessage())
                        //LoadAdsFb();
                    }

                    override fun onAdLoaded(ad: Ad?) {
                        // Show the ad when it's done loading.
                        Log.e("TAG", "--> onAdLoaded")
                    }

                    override fun onAdClicked(ad: Ad?) {
                        // Ad clicked callback
                        Log.e("TAG", "--> onAdClicked")
                    }

                    override fun onLoggingImpression(ad: Ad?) {
                        // Ad impression logged callback
                        Log.e("TAG", "--> onLoggingImpression")
                    }
                }

                mInterstitialAdfb!!.loadAd(
                    mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener)
                        .build()
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun LoadAdsFb1() {
        try {
            val id = ReferenceClass().getKeysf("f_i2")/*if (AdsHelper.isTest) {
                getString(R.string.fb_interstial2)
            }else{
                ReferenceClass().getKeys("f_i2")
            }*/
            mInterstitialAdfb1 = InterstitialAd(this, id)
            if (InternetConnection.checkConnection(this)) {
                AdSettings.addTestDevice("ad901e97-f75f-4e97-8381-f6139372235c")
                //mInterstitialAdfb1!!.loadAd()
                /*mInterstitialAdfb1!!.setAdListener(object : InterstitialAdListener {
                    override fun onInterstitialDisplayed(ad: Ad) { // Interstitial displayed callback
                        Log.e("TAG", "--> onInterstitialDisplayed")
                    }

                    override fun onInterstitialDismissed(ad: Ad) { // Interstitial dismissed callback
                        Log.e("TAG", "--> onInterstitialDismissed")
                    }

                    override fun onError(ad: Ad, adError: AdError) { // Ad error callback
                        Log.e("TAG", "onError --> " + adError.errorMessage)
                    }

                    override fun onAdLoaded(ad: Ad) { // Show the ad when it's done loading.
                        Log.e("TAG", "--> onAdLoaded")
                    }

                    override fun onAdClicked(ad: Ad) { // Ad clicked callback
                        Log.e("TAG", "--> onAdClicked")
                    }

                    override fun onLoggingImpression(ad: Ad) { // Ad impression logged callback
                        Log.e("TAG", "--> onLoggingImpression")
                    }
                })*/

                val interstitialAdListener = object : InterstitialAdListener {
                    override fun onInterstitialDisplayed(ad: Ad?) {
                        // Interstitial displayed callback
                        Log.e("TAG", "--> onInterstitialDisplayed")
                    }

                    override fun onInterstitialDismissed(ad: Ad?) {
                        // Interstitial dismissed callback
                        Log.e("TAG", "--> onInterstitialDismissed")
                    }

                    override fun onError(ad: Ad?, adError: AdError) {
                        // Ad error callback
                        Log.e("TAG", "onError --> " + adError.getErrorMessage())
                        //LoadAdsFb();
                    }

                    override fun onAdLoaded(ad: Ad?) {
                        // Show the ad when it's done loading.
                        Log.e("TAG", "--> onAdLoaded")
                    }

                    override fun onAdClicked(ad: Ad?) {
                        // Ad clicked callback
                        Log.e("TAG", "--> onAdClicked")
                    }

                    override fun onLoggingImpression(ad: Ad?) {
                        // Ad impression logged callback
                        Log.e("TAG", "--> onLoggingImpression")
                    }
                }

                mInterstitialAdfb!!.loadAd(
                    mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener)
                        .build()
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun requestNewInterstitialfb(): Boolean {
        try {
            if (mInterstitialAdfb!!.isAdLoaded) {
                mInterstitialAdfb!!.show()
                return true
            }
        } catch (e: Exception) { }
        return false
    }

    fun requestNewInterstitialfb1(): Boolean {
        try {
            if (mInterstitialAdfb1!!.isAdLoaded) {
                mInterstitialAdfb1!!.show()
                return true
            }
        } catch (e: Exception) {
        }
        return false
    }

    val isLoadedfnad: Boolean
        get() {
            try {
                if (mInterstitialAdfb!!.isAdLoaded && mInterstitialAdfb != null) {
                    return true
                }
            } catch (e: Exception) {
            }
            return false
        }

    //TODO Notification
    //OLD
    /*inner class ExampleNotificationOpenedHandler : OneSignal.NotificationOpenedHandler {
        // This fires when a notification is opened by tapping on it.
        override fun notificationOpened(result: OSNotificationOpenResult) {
            val actionType = result.action.type
            val data = result.notification.payload.additionalData
            val launchUrl = result.notification.payload.launchURL // update docs launchUrl
            val customKey: String?
            var openURL: String? = null
            var activityToLaunch: Any = SplashScreenActivity::class.java

            if (actionType == OSNotificationAction.ActionType.ActionTaken) {
                Log.i("OneSignalExample", "Button pressed with id: " + result.action.actionID)
                if (result.action.actionID == "id1") {
                    Log.i("OneSignalExample", "button id called: " + result.action.actionID)
                    activityToLaunch = SplashScreenActivity::class.java
                } else Log.i("OneSignalExample", "button id called: " + result.action.actionID)
            }
            val intent = Intent(applicationContext, activityToLaunch as Class<*>)

            if (data != null) {
                customKey = data.optString("redirect", null)
                //openURL = data.optString("openURL", null)
                intent.putExtra("open", customKey)
                if (customKey != null) Log.i(
                    "OneSignalExample",
                    "customkey set with value: $customKey"
                )
                //if (openURL != null) Log.i("OneSignalExample", "openURL to webview with URL value: $openURL")
            }
            if (ApplicationLifecycleManager.isAppVisible()) {
                // App is running
            } else {
                // The following can be used to open an Activity of your choice.
                // Replace - getApplicationContext() - with any Android Context.
                // Intent intent = new Intent(getApplicationContext(), YourActivity.class);
                // intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.flags =
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK
                Log.i("OneSignalExample", "openURL = $openURL")
                // startActivity(intent);
                applicationContext.startActivity(intent)
            }
            // Add the following to your AndroidManifest.xml to prevent the launching of your main Activity
            //   if you are calling startActivity above.
            *//*
          <application ...>
            <meta-data android:name="com.onesignal.NotificationOpened.DEFAULT" android:value="DISABLE" />
          </application>
       *//*
        }
    }*/

    //NEW
    /*inner class ExampleNotificationOpenedHandler : OneSignal.OSNotificationOpenedHandler {
        override fun notificationOpened(result: OSNotificationOpenedResult?) {
            val actionType = result!!.action.type
//            val data = result.notification.payload.additionalData
            val data = result.notification.additionalData
            val launchUrl = result.notification.rawPayload.lastIndex // update docs launchUrl
            val customKey: String?
            var openURL: String? = null
            var activityToLaunch: Any = SplashScreenActivity::class.java

            if (actionType == OSNotificationAction.ActionType.ActionTaken) {
                Log.i("OneSignalExample", "Button pressed with id: " + result.action.actionId)
                if (result.action.actionId == "id1") {
                    Log.i("OneSignalExample", "button id called: " + result.action.actionId)
                    activityToLaunch = SplashScreenActivity::class.java
                } else Log.i("OneSignalExample", "button id called: " + result.action.actionId)
            }
            val intent = Intent(applicationContext, activityToLaunch as Class<*>)

            if (data != null) {
                customKey = data.optString("redirect", null)
                //openURL = data.optString("openURL", null)
                intent.putExtra("open", customKey)
                if (customKey != null) Log.i(
                    "OneSignalExample",
                    "customkey set with value: $customKey"
                )
                //if (openURL != null) Log.i("OneSignalExample", "openURL to webview with URL value: $openURL")
            }
            if (ApplicationLifecycleManager.isAppVisible()) {
                // App is running
            } else {
                // The following can be used to open an Activity of your choice.
                // Replace - getApplicationContext() - with any Android Context.
                // Intent intent = new Intent(getApplicationContext(), YourActivity.class);
                // intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.flags =
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK
                Log.i("OneSignalExample", "openURL = $openURL")
                // startActivity(intent);
                applicationContext.startActivity(intent)
            }
            // Add the following to your AndroidManifest.xml to prevent the launching of your main Activity
            //   if you are calling startActivity above.
            *//*
          <application ...>
            <meta-data android:name="com.onesignal.NotificationOpened.DEFAULT" android:value="DISABLE" />
          </application>
       *//*
        }

    }*/

    companion object {
        var instance: TextArtApplication? = null
            private set
    }
}