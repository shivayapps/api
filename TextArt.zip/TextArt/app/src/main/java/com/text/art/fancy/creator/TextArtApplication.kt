package com.text.art.fancy.creator

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log

import androidx.multidex.MultiDex
import com.example.app.ads.helper.openad.AppOpenApplication
import com.text.art.fancy.creator.activitys.EditAnimationActivity
import com.text.art.fancy.creator.activitys.FullMyPhotoActivity
import com.text.art.fancy.creator.activitys.SplashScreenActivity

import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.utils.MySharedPref
import com.text.art.fancy.creator.utils.context
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


class TextArtApplication : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

//    var appOpenManager: AppOpenManager? = null

    var mySharedPref: MySharedPref? = null
    private var TAG = "TextArtApplication"

//    @OnLifecycleEvent(Lifecycle.Event.ON_START)
//    fun onEnteredForeground() {
//        Log.d(TAG, "onEnteredForeground")
//        try {
//            var currentClassName = ""
//            try {
//                val am: ActivityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
//                val taskInfo: List<ActivityManager.RunningTaskInfo> = am.getRunningTasks(1)
//                currentClassName = taskInfo[0].topActivity?.className.toString()
////                currentClassName = this.javaClass.simpleName
//                Log.d(TAG, "$currentClassName")
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//            if (mySharedPref?.getAdsCount()!! == 5 && !Constants.isAdsShow && !MySharedPreferences(
//                    this
//                ).isSubscribe && currentClassName != "com.text.art.fancy.creator.activitys.SplashScreenActivity" &&
//                currentClassName != "com.google.android.gms.ads.AdActivity" &&
//                currentClassName != "com.text.art.fancy.creator.activitys.FullMyPhotoActivity" &&
//                currentClassName != "com.text.art.fancy.creator.activitys.EditAnimationActivity"
//            ) {
//                appOpenManager?.showAdIfAvailable {
//                    when (it) {
//                        AppOpenManager.CallBackType.DISMISS -> {
//                            appOpenManager = AppOpenManager(applicationContext)
//                            mySharedPref?.setAdsCount(0)
//                        }
//                        AppOpenManager.CallBackType.FAILED -> {
//                            if (mySharedPref?.getAdsCount()!! >= 5) {
//                                mySharedPref?.setAdsCount(0)
//                            }
//                        }
//                        AppOpenManager.CallBackType.ERROR -> {
//                            if (mySharedPref?.getAdsCount()!! >= 5) {
//                                mySharedPref?.setAdsCount(0)
//                            }
//                        }
//                    }
//                }
//            }
//            try {
//                if (!appOpenManager!!.isAdAvailable()) {
//                    Log.d(TAG, "onEnteredForeground: Ads Shown")
//                    appOpenManager = AppOpenManager(applicationContext)
//                }
//            } catch (e: Exception) { }
//            try {
//                if (mySharedPref?.getAdsCount()!! >= 5) {
//                    mySharedPref?.setAdsCount(0)
//                }
//            } catch (e: Exception) { }
//        } catch (e: Exception) { }
//    }
//
//    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
//    fun onEnteredBackground() {
//        try {
//            mySharedPref!!.setAdsCount((mySharedPref?.getAdsCount()?.plus(1)))
//        } catch (e: Exception) { }
//    }
//    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
//    fun onDestroy() {
//        try {
//            OfflineNativeAdvancedHelper.onDestroy()
//        } catch (e: Exception) { }
//    }
    override fun attachBaseContext(base: Context?): Unit {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    @SuppressLint("PackageManagerGetSignatures")
    override fun onCreate() {
        super.onCreate()
//        MobileAds.initialize(this) {}
//        AudienceNetworkAds.initialize(this)
//        registerActivityLifecycleCallbacks(ApplicationLifecycleManager())

        mySharedPref = MySharedPref(this@TextArtApplication)
        context = baseContext
        //OLD
        // OneSignal Initialization
        /*OneSignal.startInit(this)
            .setNotificationReceivedHandler(ExampleNotificationReceivedHandler())
            .setNotificationOpenedHandler(ExampleNotificationOpenedHandler())
            .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
            .unsubscribeWhenNotificationsAreDisabled(true)
            .init()*/

        //TODO Notification
        //NEW
        /*OneSignal.initWithContext(this)
        OneSignal.setAppId("934c33f4-8112-4e70-b4c3-55856231e06f")*/

        try {
            instance = this
            // Test calling play() immediately (before TTS initialization is complete).
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                //Log.e("TAG", "KeyHash: >>>> " + Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (e: PackageManager.NameNotFoundException) {
        } catch (e: NoSuchAlgorithmException) {
        } catch (e: Exception) { }


    }


    companion object {
        var instance: TextArtApplication? = null
            private set
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashScreenActivity) {
            Log.e("===", "onResumeApp: ------------------- SplashScreenActivity ")
            return false
        } else if (fCurrentActivity is FullMyPhotoActivity) {
            Log.e("===", "onResumeApp: ------------------- FullMyPhotoActivity ")
            return false
        }else if (fCurrentActivity is EditAnimationActivity) {
            Log.e("===", "onResumeApp: ------------------- EditAnimationActivity ")
            return false
        } else if (fCurrentActivity.getLocalClassName().contains("SignInHubActivity")) {
            Log.e("===", "onResumeApp: ------------------- SignInHubActivity ")
            return false
        } else if (MySharedPreferences(this).isSubscribe) {
            Log.e("===", "onResumeApp: ------------------- isSubscribe ")
            return false
        } else if (fCurrentActivity.getLocalClassName().contains("AdActivity")) {
            Log.e("===", "onResumeApp: ------------------- AdActivity ")
            return false
        }
        return true
    }
}