package com.text.art.fancy.creator.lottieapi

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.BackgroundApi.AnimationApiAdepter
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.AddAnimationActivity
import com.text.art.fancy.creator.activitys.AddAnimationActivity.Companion.animationAllArray
import com.text.art.fancy.creator.activitys.SubscriptionActivity
import com.text.art.fancy.creator.categorys.parameter.CategoryParametersItem
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.database.DBHelper
import com.text.art.fancy.creator.dialog.WatchAdDialogFragment
import com.text.art.fancy.creator.utils.isOnline
import com.crop.photo.image.resize.cut.tools.ads.RewardedAdHelper
import com.google.android.gms.ads.rewarded.RewardedAd
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.ArrayList

class AnimationDataFragment() : Fragment() {
    var llInternetConnection: LinearLayout? = null
    var llNodataFound: LinearLayout? = null
    var progressBar: ProgressBar? = null
    var recyclerViewCard: RecyclerView? = null
    var dbHelper: DBHelper? = null
    var isDismiss: Boolean = false
    var isRewardEarn: Boolean = false
    var isSubscription: Boolean = false
    private var lastClickTime: Long = 0

    lateinit var actionBottomDialogFragment: AddAnimationActivity
    private var param: Int? = null

    var watchAdDialog: WatchAdDialogFragment? = null
    private var rewardedAd: RewardedAd? = null
    private var newFontStyleAdepter: AnimationApiAdepter ?= null
    var myFilterArray: ArrayList<CategoryParametersItem>? = null

    fun AnimationDataFragment() {}

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_animation_data, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dbHelper = DBHelper(requireContext())
        param = requireArguments().getInt("param")
        isSubscription = try {
            MySharedPreferences(
                requireContext()
            ).isSubscribe
        } catch (e: Exception) {
            false
        }
        recyclerViewCard = view.findViewById(R.id.recyclerViewCard)
        progressBar = view.findViewById(R.id.progressBarAnimation)
        llInternetConnection = view.findViewById(R.id.llInternetConnection)
        llNodataFound = view.findViewById(R.id.llNodataFound)
        loadData()
        try {
            RewardedAdHelper.instence!!.loadRewardedAd(requireContext())
        } catch (e: Exception) {
        }
    }

    private fun loadData() {
        if (isDismiss) {
            return
        }
        if (animationAllArray.isNullOrEmpty()){
            Handler(Looper.getMainLooper()).postDelayed({loadData()},3000)
        }else {
            myFilterArray = arrayListOf()
            val gridLayoutManager = GridLayoutManager(requireContext(), 3)
            gridLayoutManager.orientation = LinearLayoutManager.VERTICAL
            recyclerViewCard!!.layoutManager = gridLayoutManager
            if (animationAllArray[param!!].categoryParameters.size != 0) {
                var mAnimOpen: Cursor? = null

                GlobalScope.launch {
                    withContext(Dispatchers.IO) {
                        mAnimOpen = DBHelper(requireContext()).allOpenAnimData
                    }

                    withContext(Dispatchers.IO) {
                        AddAnimationActivity.animationAllArray[param!!].categoryParameters!!.filterIndexed { index, file ->
                            val categoryParametersItem =
                                CategoryParametersItem()
                            if (file.is_premium == 1 && !isSubscription) {
                                categoryParametersItem.is_premium = 1
                            } else {
                                categoryParametersItem.is_premium = 0
                            }
                            if (file.coins > 0 && !isSubscription) {
                                categoryParametersItem.coins = 10
                            } else {
                                categoryParametersItem.coins = 0
                            }
                            categoryParametersItem.thumbImage = file.thumbImage
                            categoryParametersItem.zip = file.zip
                            categoryParametersItem.name = file.name
                            try {
                                if (!isSubscription) {
                                    mAnimOpen!!.moveToFirst()
                                    if (mAnimOpen!!.getString(1) == file.thumbImage) {
                                        categoryParametersItem.coins = 0
                                    }
                                    while (mAnimOpen!!.moveToNext()) {
                                        if (mAnimOpen!!.getString(1) == file.thumbImage) {
                                            categoryParametersItem.coins = 0
                                            break
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                            }
                            myFilterArray!!.add(categoryParametersItem)
                            true
                        }
                    }
                    withContext(Dispatchers.Main) {
                        newFontStyleAdepter = AnimationApiAdepter(
                            actionBottomDialogFragment,
                            myFilterArray,
                            object : AnimationApiAdepter.setOnItemClickListenerAnimation {
                                override fun OnItemClickedAnimation(
                                    position: Int,
                                    fileName: String,
                                    zipUrl: String
                                ) {
                                    if (SystemClock.elapsedRealtime() - lastClickTime < 1000) {
                                        return
                                    }
                                    lastClickTime = SystemClock.elapsedRealtime()
                                    if (myFilterArray!![position].is_premium == 1) {
                                        AddAnimationActivity.isAdsIsFree = false
                                        startActivityForResult(
                                            Intent(
                                                requireContext(),
                                                SubscriptionActivity::class.java
                                            ), 1000
                                        )
                                    } else if (myFilterArray!![position].coins == 10) {
                                        AddAnimationActivity.isAdsIsFree = false

                                        if (isOnline()) {
                                            /*if (RewardVideoAds.instence != null && RewardVideoAds.instence!!.loadVideoAdMain(
                                                requireContext()
                                            ) != null
                                        ) {
                                            val rewardedAd =
                                                RewardVideoAds.instence!!.loadVideoAdMain(requireContext())
                                            Log.d(TAG, "showAdDialog MAIN: ${rewardedAd}")
                                            showAdDialog(position, rewardedAd!!, 1)
                                        } else {
                                            Log.d(TAG, "OnItemClickedAnimation: ${RewardVideoAds.instence}")
                                            Toast.makeText(
                                                requireContext(),
                                                resources.getString(R.string.try_again_later),
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }*/

                                            if (RewardedAdHelper.instence != null && RewardedAdHelper.instence!!.loadRewardedAd(
                                                    requireContext()
                                                ) != null
                                            ) {
                                                showAdDialog(position)
                                            }

                                        } else {
                                            Toast.makeText(
                                                activity,
                                                "Please check internet connection.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    } else {
                                        AddAnimationActivity.isAdsIsFree = true
                                        actionBottomDialogFragment.onAnimationItemClick(
                                            AddAnimationActivity.animationAllArray[param!!].categoryParameters!![position].id,
                                            fileName,
                                            zipUrl
                                        )
                                    }
                                }

                            })

                        recyclerViewCard!!.adapter = newFontStyleAdepter
                        recyclerViewCard!!.visibility = View.VISIBLE
                        progressBar!!.visibility = View.GONE
                        llInternetConnection!!.visibility = View.GONE

                    }
                }

            } else {
                if (isOnline()) {
                    llInternetConnection!!.visibility = View.GONE
                    llNodataFound!!.visibility = View.VISIBLE
                    recyclerViewCard!!.visibility = View.GONE
                    progressBar!!.visibility = View.GONE
                } else {
                    llInternetConnection!!.visibility = View.VISIBLE
                    llNodataFound!!.visibility = View.GONE
                    recyclerViewCard!!.visibility = View.GONE
                    progressBar!!.visibility = View.GONE
                }
            }
        }
    }

    private fun showAdDialog(position: Int) {
        watchAdDialog = WatchAdDialogFragment(
            "Unlock Animation", "Get PRO", "To Access All Animations",
            R.drawable.ic_dialog_video, "Watch Video Ad", "To Use This Animation"
        )
        { s, discardDialogFragment ->
            when (s) {
                "subscribe" -> {
//                    requireActivity().supportFragmentManager.beginTransaction().remove(requireActivity().supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                    startActivityForResult(
                        Intent(
                            requireContext(),
                            SubscriptionActivity::class.java
                        ), 1000
                    )
                }
                "watchAd" -> {
//                    requireActivity().supportFragmentManager.beginTransaction().remove(requireActivity().supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                    Log.d(TAG, "showAdDialog: WatchAd btn Clicked")
//                    showAdReward(position, gameOverRewardedAd, numberOfAd)
                    showRewardAd(position)
                }
                else -> {
//                    requireActivity().supportFragmentManager.beginTransaction().remove(requireActivity().supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                }
            }
        }
        watchAdDialog!!.isCancelable = false
        watchAdDialog!!.show(childFragmentManager, "dialog_fragment")

    }

    private fun showRewardAd(position: Int) {
        RewardedAdHelper.instence!!.showRewardedAd(requireContext(), {
            //OnUserEarnedReward
            try {
                isRewardEarn = true
                dbHelper!!.insertOpenAnimData(position, myFilterArray!![position].thumbImage)
                myFilterArray!![position].coins = 0
                newFontStyleAdepter?.notifyItemChanged(position)

                try {
                    Handler(Looper.getMainLooper()).postDelayed({
                        actionBottomDialogFragment.onAnimationItemClick(
                            AddAnimationActivity.animationAllArray[param!!].categoryParameters!![position].id,
                            AddAnimationActivity.animationAllArray[param!!].categoryParameters!![position].name,
                            AddAnimationActivity.animationAllArray[param!!].categoryParameters!![position].zip,
                        )
                    }, 500)
                } catch (e: Exception) {
                }
            } catch (e: Exception) {
            }
        }, {
            //OnError
            RewardedAdHelper.instence!!.loadRewardedAd(requireContext())
        }, {
            //OnClose
            AddAnimationActivity.isAdsIsFree = true
        }, {
            //On Pro
            /*requireContext().onAnimationItemClick(
                AddAnimationActivity.animationAllArray[param].categoryParameters!![position].id,
                AddAnimationActivity.animationAllArray[param].categoryParameters!![position].name,
                AddAnimationActivity.animationAllArray[param].categoryParameters!![position].zip,
            )*/
        }, isSubscription)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1000 && resultCode == 1144) {
            isSubscription = try {
                MySharedPreferences(
                    requireContext()
                ).isSubscribe
            } catch (e: Exception) {
                false
            }
            if (isSubscription) {
                loadData()
            }
        }
    }

    /*fun showAdReward(position: Int, gameOverRewardedAd: RewardedAd, numberOfAd: Int) {
        Log.d(TAG, "showAdDialog: Inside showAdReward")
        if (gameOverRewardedAd.isLoaded) {
            Log.d(TAG, "showAdDialog: ad $gameOverRewardedAd")
            val adCallback: RewardedAdCallback = object : RewardedAdCallback() {
                override fun onRewardedAdOpened() {
                    // Ad opened.
                }

                override fun onRewardedAdClosed() {
                    // Ad closed.
                    RewardVideoAds.instence!!.loadVideoAdMain(requireContext())
                    if (isRewardEarn) {
                        isRewardEarn = false
                        Log.d(TAG, "onRewardedAdClosed: ID ${AddAnimationActivity.animationAllArray[param].categoryParameters!![position].id}")
                        Log.d(TAG, "onRewardedAdClosed: name ${AddAnimationActivity.animationAllArray[param].categoryParameters!![position].name}")
                        Log.d(TAG, "onRewardedAdClosed: name ${AddAnimationActivity.animationAllArray[param].categoryParameters!![position].zip}")
                        AddAnimationActivity.isAdsIsFree = true
                        requireContext().onAnimationItemClick(
                            AddAnimationActivity.animationAllArray[param].categoryParameters!![position].id,
                            AddAnimationActivity.animationAllArray[param].categoryParameters!![position].name,
                            AddAnimationActivity.animationAllArray[param].categoryParameters!![position].zip,
                        )
                    }

                }

                override fun onUserEarnedReward(reward: RewardItem) {
                    Log.d(TAG, "onUserEarnedReward: DONE")
                    try {
                        isRewardEarn = true
                        dbHelper!!.insertOpenAnimData(position, myFilterArray!![position].thumbImage)
                        myFilterArray!![position].coins = 0
                        newFontStyleAdepter.notifyItemChanged(position)
                    } catch (e: Exception) {
                    }
                    RewardVideoAds.instence!!.loadVideoAdMain(requireContext())
                }

                override fun onRewardedAdFailedToShow(errorCode: Int) {
                    // Ad failed to display.
                    RewardVideoAds.instence!!.loadVideoAdMain(requireContext())
                }
            }
            gameOverRewardedAd.show(activity, adCallback)
        } else {
            Log.d(TAG, "showAdReward: Else loadVideoAdMain")
            RewardVideoAds.instence!!.loadVideoAdMain(requireContext())
        }
    }*/

    override fun onAttach(context: Context) {
        super.onAttach(context)
        actionBottomDialogFragment = context as AddAnimationActivity
    }

    override fun onPause() {
        super.onPause()
        if (watchAdDialog != null) {
//            requireActivity().supportFragmentManager.beginTransaction().remove(requireActivity().supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
            watchAdDialog!!.dismiss()
        }
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        isDismiss = true
    }

    interface ItemClickListener {
        fun onAnimationItemClick(id: Int, name: String, string: String)
    }

    companion object {
        private const val TAG = "AnimationDataFragment"

        @JvmStatic
        fun newInstance(param: Int): Fragment {
            val args = Bundle()
            args.putInt("param", param)
            val f = AnimationDataFragment()
            f.arguments = args
            return f
        }

    }

}

