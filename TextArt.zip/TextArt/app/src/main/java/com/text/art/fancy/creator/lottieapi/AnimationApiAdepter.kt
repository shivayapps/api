package com.text.art.fancy.creator.BackgroundApi

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.gif.GifDrawable
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.categorys.parameter.CategoryParametersItem
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.utils.hide
import com.text.art.fancy.creator.utils.show
import java.util.*

class AnimationApiAdepter(
    var AddAnimationActivity: Context,
    var imageItems: ArrayList<CategoryParametersItem>?,
    var animationInterface: setOnItemClickListenerAnimation
) : RecyclerView.Adapter<AnimationApiAdepter.MyViewHolder>() {

    interface setOnItemClickListenerAnimation {
        fun OnItemClickedAnimation(position: Int,name: String, string: String)
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgBackground: ImageView = itemView.findViewById(R.id.imgBackground)
        val imgPreview: ImageView = itemView.findViewById(R.id.imgPreview)
        val imgLock: ImageView = itemView.findViewById(R.id.imgLock)
        val imgLockPremium: ImageView = itemView.findViewById(R.id.imgLockPremium)
        val mProgressBar: ProgressBar = itemView.findViewById(R.id.mProgressBar)
        val isLoaded: TextView = itemView.findViewById(R.id.isLoadedAnimation)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnimationApiAdepter.MyViewHolder {
        val view = LayoutInflater.from(AddAnimationActivity).inflate(R.layout.sticker_anim_item, parent, false)
        return MyViewHolder(view)
    }


    override fun getItemCount(): Int {
        return imageItems!!.size
    }

    override fun onBindViewHolder(myholder: AnimationApiAdepter.MyViewHolder, @SuppressLint("RecyclerView") i: Int) {
        myholder.imgBackground.setOnLongClickListener { true }
        myholder.imgBackground.visibility = View.VISIBLE
        myholder.imgLockPremium.visibility = View.GONE
        myholder.imgLock.visibility = View.GONE
        myholder.mProgressBar.visibility = View.VISIBLE
        Glide.with(AddAnimationActivity)
            .asGif()
                .load(imageItems!![i].thumbImage)
                .listener(object : RequestListener<GifDrawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<GifDrawable>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        myholder.isLoaded.text = "No"
//                        myholder.mProgressBar.visibility = View.GONE
                        return false
                    }

                    override fun onResourceReady(
                        resource: GifDrawable?,
                        model: Any?,
                        target: Target<GifDrawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        myholder.isLoaded.text = "Yes"
                        if (imageItems!![i].is_premium == 1) {
                            myholder.imgLockPremium.visibility=View.VISIBLE
                        }else if (imageItems!![i].coins==10){
                            myholder.imgLock.show()
                        }
                        myholder.mProgressBar.hide()
                        return false
                    }

                }).into(myholder.imgBackground)

        myholder.imgBackground.setOnClickListener {
            if (myholder.isLoaded.text == "Yes"){
                animationInterface.OnItemClickedAnimation(i, imageItems!![i].name,imageItems!![i].zip)
//                Constants.FontStylePosition = i
            }else{
                Toast.makeText(AddAnimationActivity, "Please wait", Toast.LENGTH_SHORT).show()
            }
//            animationInterface.OnItemClickedAnimation(i, imageItems!![i].name,imageItems!![i].zip)
//            Constants.FontStylePosition = i
        }
    }
}