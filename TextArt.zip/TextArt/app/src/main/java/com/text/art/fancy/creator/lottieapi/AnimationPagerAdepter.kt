package com.text.art.fancy.creator.lottieapi

import android.annotation.SuppressLint
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.text.art.fancy.creator.activitys.AddAnimationActivity
import com.text.art.fancy.creator.categorys.ParametersItemAllChilds
import java.util.ArrayList

@SuppressLint("WrongConstant")
class AnimationPagerAdapter(
    fm: FragmentManager,
    private val mParamList: ArrayList<ParametersItemAllChilds>,
    private val mIsSub: Boolean,
    private val actionBottomDialogFragment: AddAnimationActivity
) :
    FragmentStatePagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    override fun getItem(position: Int): Fragment {
        return AnimationDataFragment.newInstance(position)
    }

    override fun getCount(): Int {
        return mParamList.size
    }

}