package com.text.art.fancy.creator.activitys

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.text.art.fancy.creator.frameapi.FrameAdepter
import com.text.art.fancy.creator.frameapi.FrameDataFragment
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.ads.InterstitialAdHelper
import com.text.art.fancy.creator.ads.OfflineNativeAdvancedHelper.loadOfflineNativeAdvance
import com.text.art.fancy.creator.categorys.ParametersItemAllChilds
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.newapi.model.SubCategory
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.utils.*
import com.google.android.gms.ads.InterstitialAd
import com.google.android.material.tabs.TabLayout
import com.google.firebase.analytics.FirebaseAnalytics
import kotlinx.android.synthetic.main.frame_api_activity.constainMain
import kotlinx.android.synthetic.main.frame_api_activity.constraintOffline
import kotlinx.android.synthetic.main.frame_api_activity.constraintProgressLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import java.util.*
import kotlin.properties.Delegates

class FrameActivity : BaseActivity(), FrameDataFragment.ItemClickListener,  InterstitialAdHelper.onInterstitialAdListener  {

    private var isConnected = false
    private var meterialTabLayout: TabLayout? = null
    private var icBack: ImageView? = null
    private var btnNone: ImageView? = null
    private var btnHeaderText: TextView? = null
    private var imageShare: ImageView? = null
    private var viewPagerCard: ViewPager2? = null
    private var mTermsToolbar: ConstraintLayout? = null
    var mIsSubScribe: Boolean = false
    private var receiver: Receiver? = null
    var selectedURL: String = ""
    var isAdsLoaded: Boolean = false
    var mySharedPref: MySharedPref? = null
    private var interstitial: InterstitialAd? = null
    private var mIsDataLoaded = false
    private var total by Delegates.notNull<Int>()
    private var categoryList = arrayListOf<SubCategory>()

    //Analytics Event
    @SuppressLint("MissingPermission")
    private lateinit var mFirebaseAnalytics: FirebaseAnalytics
    private var mBundle: Bundle = Bundle()

    inner class Receiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (isOnline()) {
//                constraintOffline.visibility = View.GONE
//                if (isFrameDataLoaded){
//                    constainMain.visibility = View.VISIBLE
//                    setData()
//                }else{
////                    callFrameApi()
//                    callNewFrameApi()
//                }

                if (categoryList.size == 0){
                    callNewFrameApi()
                }else{
                    setNewData()
                }
            } else {
                constainMain.hide()
                constraintOffline.show()
                finish()
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.frame_api_activity)

        try {
            receiver = Receiver()
            registerReceiver(receiver, IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"))
        } catch (e: Exception) { }

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this)
        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        mySharedPref = MySharedPref(this@FrameActivity)
        try {
            interstitial = InterstitialAdHelper.instance?.load(
                this@FrameActivity,
                this@FrameActivity
            )
        } catch (e: Exception) { }
        if (!mIsSubScribe) {
            loadOfflineNativeAdvance(this,findViewById(R.id.my_template)){}
        }
        hideSystemUI()
        mTermsToolbar = findViewById<ConstraintLayout>(R.id.mTermsToolbar)
        meterialTabLayout = findViewById<TabLayout>(R.id.meterialTabLayout)
        btnHeaderText = findViewById<TextView>(R.id.btnHeaderText)
        btnNone = findViewById<ImageView>(R.id.btnPremium)
        imageShare = findViewById<ImageView>(R.id.imageShare)
        icBack = findViewById<ImageView>(R.id.icBack)
        viewPagerCard = findViewById<ViewPager2>(R.id.viewPagerCard)
        btnHeaderText!!.text = "Frame"

//        viewPagerCard!!.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
//            override fun onPageScrolled(
//                position: Int,
//                positionOffset: Float,
//                positionOffsetPixels: Int
//            ) {
//                mPosition = position
//
//                Log.d(TAG, "onPageScrolled: $position")
//            }
//
//            override fun onPageSelected(position: Int) {
//                Log.d(TAG, "onPageSelected: $position")
//            }
//
//            override fun onPageScrollStateChanged(state: Int) {
//                Log.d(TAG, "onPageScrollStateChanged: $state")
//            }
//        })

        icBack!!.setOnClickListener {
            try { onBackPressed() } catch (e: Exception) { }
        }
        btnNone!!.setOnClickListener {
            onFrameItemClick("", 0)
//            startActivity(Intent(this, SubscriptionActivity::class.java))
        }
        imageShare!!.setOnClickListener {
            try {
                val shareIntent =
                    Intent(Intent.ACTION_SEND)
                shareIntent.type = "text/plain"
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Text Art")
                var shareMessage = "\nGo with TextArt and make beautiful text image.\n\n"
                shareMessage =
                    shareMessage + "https://play.google.com/store/apps/details?id=" + packageName + "\n\n"
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivity(Intent.createChooser(shareIntent, "choose one"))
            } catch (e: java.lang.Exception) { }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        categoryList.clear()
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        try {
            mIsSubScribe = MySharedPreferences(
                this
            ).isSubscribe
            if (mIsSubScribe) {
                findViewById<FrameLayout>(R.id.my_template).visibility = View.GONE
            }
        } catch (e: Exception) { }
    }

    private fun setData() {
//        constraintProgressLayout.hide()
//        constraintOffline.hide()
//        constainMain.show()
//
//        val fontPagerAdepter = FramePagerAdepter(
//            supportFragmentManager,
//            frameAllArray,
//            mIsSubScribe,
//            this@FrameActivity
//        )
//        viewPagerCard!!.adapter = fontPagerAdepter
//        meterialTabLayout!!.setupWithViewPager(viewPagerCard)
//        frameAllArray.filterIndexed { index, categoryParametersItem ->
//            if (categoryParametersItem.name != "") {
//                val view1 =
//                    LayoutInflater.from(this@FrameActivity)
//                        .inflate(R.layout.rv_tab, null)
//                meterialTabLayout!!.getTabAt(index)!!.customView = view1
//                val textView = view1.findViewById<TextView>(R.id.textTab)
//                textView.text = categoryParametersItem.name
//                if (index == 0) {
//                    Constants.selectedFrame = textView.text.toString()
//                    textView.setTextColor(Color.WHITE)
//                } else {
//                    textView.setTextColor(Color.BLACK)
//                }
//            }
//            true
//        }
//        meterialTabLayout!!.setOnTabSelectedListener(object :
//            TabLayout.OnTabSelectedListener {
//            override fun onTabSelected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.WHITE)
//                    Constants.selectedFrame = "${meterialTabLayout!!.getTabAt(tab.position)!!.customView!!.findViewById<TextView>(R.id.textTab).text}"
//                } catch (e: Exception) {
//                }
//            }
//
//            override fun onTabUnselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.BLACK)
//                } catch (e: Exception) {
//                }
//            }
//
//            override fun onTabReselected(tab: TabLayout.Tab) {
//                mPosition = tab.position
//                try {
//                    tab.customView!!.findViewById<TextView>(R.id.textTab)
//                        .setTextColor(Color.WHITE)
//                } catch (e: Exception) {
//                }
//
//            }
//        })
//        isFrameDataLoaded = true
//        viewPagerCard!!.currentItem = mPosition
    }

    private fun setNewData() {
        constraintProgressLayout.hide()
        constraintOffline.hide()
        constainMain.show()

        val frameAdapter = FrameAdepter(this, categoryList, total)
        viewPagerCard?.offscreenPageLimit = ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT
        viewPagerCard?.adapter = frameAdapter

        meterialTabLayout?.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                with(tab?.position!!){
                    viewPagerCard?.currentItem = this
                    tab.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.WHITE)
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                tab?.customView?.findViewById<TextView>(R.id.textTab)?.setTextColor(Color.BLACK)
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }
        })

        viewPagerCard?.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback(){
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                meterialTabLayout?.selectTab(meterialTabLayout?.getTabAt(position))
            }
            override fun onPageScrollStateChanged(state: Int) {}
        })
    }

    private fun callFrameApi() {
        constraintProgressLayout.visibility = View.VISIBLE

        val apiInterface = APIClient.getClient().create(APIInterface::class.java)
        val call = apiInterface.parameterList
        call.enqueue(object : Callback<Response> {
            override fun onResponse(
                call: Call<Response>,
                response: retrofit2.Response<Response>
            ) {
                //Log.d("789412312331", "onResponse: " + response.body()!!.parameters)
                if (response.isSuccessful && response.body()!!.parameters != null){
                    response.body()!!.parameters.filterIndexed { _ , parametersItem ->
                        if (parametersItem.name == "Frames" || parametersItem.id == 451) {
                            frameAllArray.clear()
                            parametersItem.all_childs.filterIndexed {_ , categoryParametersItem ->
                                frameAllArray.add(categoryParametersItem)
                                true
                            }
                        }
                        isFrameDataLoaded = true
                        setData()
                        true
                    }
                }else{
                    showToast("Please try again latter")
                    finish()
                }
            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                showToast("Please try again latter")
                finish()
            }
        })
    }

    private fun callNewFrameApi() {
        constraintProgressLayout.show()
        lifecycleScope.launch{
            withContext(Dispatchers.IO){
                if (HomeActivity.allCategory.isEmpty()){
                    HomeActivity.callHomeApi(this@FrameActivity)
                }
                for (category in HomeActivity.allCategory){
                    if (category.name.equals(TAG, ignoreCase = true)){
                        category.subCategory?.let {
                            withContext(Dispatchers.Main){
                                categoryId = category.id!!
                                total = it.size
                                for ((i, subCategory) in it.withIndex()){
                                    categoryList.add(subCategory)
                                    withContext(Dispatchers.Main){
                                        meterialTabLayout!!.addTab(meterialTabLayout!!.newTab().setText(subCategory.name))
                                        val view1 = LayoutInflater.from(this@FrameActivity).inflate(R.layout.rv_tab, null)
                                        meterialTabLayout!!.getTabAt(i)!!.customView = view1
                                        val textView = view1.findViewById<TextView>(R.id.textTab)
                                        textView.text = subCategory.name
                                        if (i == 0) {
                                            Constants.selectedFrame = textView.text.toString()
                                            textView.setTextColor(Color.WHITE)
                                        } else {
                                            textView.setTextColor(Color.BLACK)
                                        }
                                    }
                                }
                            }
                        }
                        withContext(Dispatchers.Main){
                            setNewData()
                        }
                        break
                    }
                }
            }
        }
    }

    companion object {
        private const val TAG = "Frames"
        var isAdsIsFree = false
        var isFrameDataLoaded = false
        var mPosition = 0
        var categoryId by Delegates.notNull<Int>()
        var frameAllArray: ArrayList<ParametersItemAllChilds> = ArrayList()
    }

    override fun onFrameItemClick(string: String, id: Int) {
        selectedURL = string
        if (mySharedPref?.getApiAdsCount() == 2 && !mIsSubScribe&& isAdsIsFree && isAdsLoaded && interstitial != null && interstitial!!.isLoaded) {
            mySharedPref?.setApiAdsCount(0)
            interstitial!!.show()
        } else {
            if (mySharedPref?.getApiAdsCount()!! > 2) {
                mySharedPref?.setApiAdsCount(0)
            }
            mySharedPref?.setApiAdsCount(mySharedPref?.getApiAdsCount()!! + 1)
            Handler(Looper.getMainLooper()).postDelayed({
                mBundle.clear()
                mBundle.putString("frame", "${Constants.selectedFrame}_$id")
                mFirebaseAnalytics.logEvent("textart_click", mBundle)
                Constants.frameId = id
//                showToast("${Constants.selectedFrame}_$id")
                Log.d(TAG, "onFrameItemClick: ${Constants.selectedFrame}_$id")
                val intent = Intent()
                intent.putExtra("frames", selectedURL)
                setResult(3030, intent)
                finish()
            }, 500)
        }
    }

    override fun onLoad() {
        isAdsLoaded = true
    }

    override fun onFailed() {}

    override fun onClosed() {
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent()
            intent.putExtra("frames", selectedURL)
            setResult(3030, intent)
            finish()
        }, 500)
    }

    override fun bindCallbacks() {

    }

    override fun bindAction() {
        val connectionLiveData = ConnectionLiveData(this)
        connectionLiveData.observe(this) { isConnected ->
            isConnected?.let {
                this.isConnected = it
                if (it) {
                    if (!checkStatus()) {
                        showToast("Please connect internet")
                        finish()
                    }
                } else {
                    showToast("Please connect internet")
                    finish()
                }
            }
        }
    }

}