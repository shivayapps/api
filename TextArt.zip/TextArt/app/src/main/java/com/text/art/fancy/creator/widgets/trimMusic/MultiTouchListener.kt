package com.text.art.fancy.creator.widgets.trimMusic

import android.annotation.SuppressLint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener
import android.view.ViewGroup
import android.view.ViewGroup.MarginLayoutParams
import android.widget.FrameLayout
import android.widget.ImageView
import com.text.art.fancy.creator.R

class MultiTouchListener(
    var button: ImageView,
    var viewGroup: ViewGroup,
    var duration: Long,
    var stickerView: WaveVisualizer?,
    val action: (String, Float) -> Unit,
) : OnTouchListener {
    private var mPrevX = 0f
    private var mPrevY = 0f
    private var mPointX = 0f

    lateinit var leftBottomView: View
    lateinit var rightBottomView: View
    private var base = button.context.resources.getDimension(R.dimen._30sdp).toInt()

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouch(view: View, event: MotionEvent): Boolean {
        val currX: Float
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                mPrevX = event.x
                mPrevY = event.y

                action("down", 0f)

                if (stickerView != null) {
                    mPointX = ((1000 * stickerView!!.width) / duration).toFloat()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                currX = event.rawX
                val marginParams = MarginLayoutParams(view.layoutParams)

                if (button.tag == "right") {
                    val limitX = (currX - mPrevX) - base
                    if ((button.x + mPointX + button.width) < limitX && (limitX + view.width) < (viewGroup.width - view.context.resources.getDimension(
                            R.dimen._10sdp
                        ))) {
                        marginParams.setMargins(limitX.toInt(), view.context.resources.getDimension(R.dimen._50sdp).toInt() + view.context.resources.getDimension(R.dimen._20sdp).toInt(), 0, 0)
                        marginParams.marginStart = limitX.toInt()
                        val layoutParams = FrameLayout.LayoutParams(marginParams)
                        layoutParams.gravity = Gravity.BOTTOM
                        view.layoutParams = layoutParams

                        val params = rightBottomView.layoutParams as MarginLayoutParams
                        params.setMargins(limitX.toInt() + rightBottomView.context.resources.getDimension(R.dimen._9sdp).toInt(), rightBottomView.context.resources.getDimension(R.dimen._20sdp).toInt(), 0, 0)
                        params.marginStart = limitX.toInt() + rightBottomView.context.resources.getDimension(R.dimen._9sdp).toInt()
                        rightBottomView.layoutParams = FrameLayout.LayoutParams(params)
                        view.post {
                            action("move", mPrevX)
                        }
                    }
                } else {
                    val limitX = (currX - mPrevX) - base
                    if ((button.x) > (limitX + mPointX + view.width) && limitX >= view.context.resources.getDimension(
                            R.dimen._10sdp
                        )) {
                        marginParams.setMargins(limitX.toInt(), 0, 0, 0)
                        val layoutParams = FrameLayout.LayoutParams(marginParams)
                        view.layoutParams = layoutParams
                        val params = leftBottomView.layoutParams as MarginLayoutParams
                        params.setMargins(limitX.toInt() + leftBottomView.context.resources.getDimension(R.dimen._9sdp).toInt(), leftBottomView.context.resources.getDimension(R.dimen._20sdp).toInt(), 0, 0)
                        params.marginStart = limitX.toInt() + leftBottomView.context.resources.getDimension(R.dimen._9sdp).toInt()
                        leftBottomView.layoutParams = FrameLayout.LayoutParams(params)
                        view.post { action("move", mPrevX) }
                    }
                }
            }

            MotionEvent.ACTION_UP -> {
                action("up", 0f)
            }
            MotionEvent.ACTION_CANCEL -> {}

        }
//        (((view.parent).parent).parent).requestDisallowInterceptTouchEvent(true)
        return true
    }

}