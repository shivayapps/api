package com.text.art.fancy.creator.newapi.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class SubCategory(

    @SerializedName("id")
    var id: Int? = null,

    @SerializedName("category_new_id")
    var categoryNewId: Int? = null,

    @SerializedName("name")
    var name: String? = null
) : Serializable