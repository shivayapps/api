package com.text.art.fancy.creator.fragment

import android.annotation.SuppressLint
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.text.art.fancy.creator.model.ImageModel
import com.text.art.fancy.creator.model.PhotoModel
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.TextArtApplication
import com.text.art.fancy.creator.activitys.*
import com.text.art.fancy.creator.adepter.MyPhotoAdapter
import com.text.art.fancy.creator.comman.Constants
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.InterstitialAdListener
import kotlinx.android.synthetic.main.fragment_creation.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class CreationFragment : Fragment() {

    val TAG = "CreationFragment"

    var mPhotoList: ArrayList<PhotoModel>? = null

    private var count = 1
    lateinit var txtCreate: TextView
    var myPhotoAdapter: MyPhotoAdapter? = null

    private lateinit var startNew: () -> Unit

    //    private var interstitial: InterstitialAd? = null
    private var isInterstitialAdLoaded = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_creation, container, false)
    }


    @SuppressLint("StaticFieldLeak")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        txtCreate = view.findViewById(R.id.txtCreate)
        mPhotoList = ArrayList()
        txtCreate.setOnClickListener {
            try {
                startActivity(Intent(requireContext(), AddTextActivity1::class.java))
            } catch (e: Exception) { }
        }
        object : AsyncTask<Unit, Unit, Unit>() {
            override fun onPreExecute() {
                super.onPreExecute()
                progressBar4.visibility = View.VISIBLE
                empty_view?.visibility = View.INVISIBLE
                txtCreate?.visibility = View.INVISIBLE
            }

            override fun doInBackground(vararg params: Unit?) {
                photos
            }

            override fun onPostExecute(result: Unit?) {
                super.onPostExecute(result)
                try {
                    progressBar4.visibility = View.GONE

                    val layoutManager = LinearLayoutManager(context)
                    recycler_saved_images?.layoutManager = layoutManager
                    recycler_saved_images?.setHasFixedSize(true)
                    recycler_saved_images?.setItemViewCacheSize(20)

                    myPhotoAdapter = MyPhotoAdapter(context!!, mPhotoList!!, { i, path ->
                        openActivity(path)
                    }, {
                        (activity as MyPhotoActivity).actionClick(it, mPhotoList!![it].strings!!, myPhotoAdapter!!.isShowLong)
                    }) {
                        PhotoFragment.isShowCheckBox = true
                        showSelectAll(true)
                    }
                    recycler_saved_images?.adapter = myPhotoAdapter
                    myPhotoAdapter!!.notifyDataSetChanged()
                    if (mPhotoList!!.isEmpty() || myPhotoAdapter == null) {
                        recycler_saved_images?.visibility = View.INVISIBLE
                        empty_view?.visibility = View.VISIBLE
                        txtCreate?.visibility = View.VISIBLE
                        //            NativeAdvanceHelper.loadAdSmall(this, (FrameLayout) findViewById(R.id.fl_adplaceholder));
                    } else {
                        recycler_saved_images?.visibility = View.VISIBLE
                        empty_view?.visibility = View.INVISIBLE
                        txtCreate?.visibility = View.INVISIBLE
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    activity?.finish()
                }
            }
        }.execute()
        loadInterstialAdFb()
    }

    fun getList(): ArrayList<PhotoModel> {
        return mPhotoList!!
    }

    private fun openActivity(path: String) {
        startNew = {
            context?.let {
                startActivity(Intent(it, FullMyPhotoActivity::class.java).apply {
                    putExtra("type", "view")
                    putExtra("list", mPhotoList)
                    putExtra("image", path)
                    Constants.showAdInSharePage = false
                })
            }
        }
        if (TextArtApplication.instance!!.requestNewInterstitialfb1()) {
            /*TextArtApplication.instance!!.mInterstitialAdfb1!!.setAdListener(object : InterstitialAdListener {
                override fun onError(ad: Ad, adError: AdError) {
                    startNew()
                }

                override fun onAdLoaded(ad: Ad) {
                    Log.e("TAG", "--> onAdLoaded")
                }

                override fun onAdClicked(ad: Ad) {
                    Log.e("TAG", "--> onAdClicked")
                }

                override fun onLoggingImpression(ad: Ad) {
                    Log.e("TAG", "--> onLoggingImpression")
                }

                override fun onInterstitialDisplayed(ad: Ad) {
                    Log.e("TAG", "--> onInterstitialDisplayed")
                }

                override fun onInterstitialDismissed(ad: Ad) {
                    loadInterstialAdFb()
                    startNew()
                }
            })*/

            val interstitialAdListener = object : InterstitialAdListener {
                override fun onInterstitialDisplayed(ad: Ad?) {
                    Log.e("TAG", "--> onInterstitialDisplayed")
                }

                override fun onInterstitialDismissed(ad: Ad?) {
                    loadInterstialAdFb()
                    startNew()
                }

                override fun onError(ad: Ad?, adError: AdError) {
                    startNew()
                }

                override fun onAdLoaded(ad: Ad?) {
                    Log.e("TAG", "--> onAdLoaded")
                }

                override fun onAdClicked(ad: Ad?) {
                    Log.e("TAG", "--> onAdClicked")
                }

                override fun onLoggingImpression(ad: Ad?) {
                    Log.e("TAG", "--> onLoggingImpression")
                }
            }

            TextArtApplication.instance!!.mInterstitialAdfb!!.loadAd(TextArtApplication.instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build())
        } else {
            if (isInterstitialAdLoaded) {
//                interstitial!!.show()
            } else {
                startNew()
            }
        }
    }

    private fun loadInterstialAdFb() {
        if (TextArtApplication.instance!!.mInterstitialAdfb1!!.isAdLoaded) {
        } else {
            Log.d(TAG, "loadInterstialAdFb: ")
            //TextArtApplication.instance!!.mInterstitialAdfb1!!.setAdListener(null)
            TextArtApplication.instance!!.mInterstitialAdfb1 = null
            TextArtApplication.instance!!.LoadAdsFb1()
            /*TextArtApplication.instance!!.mInterstitialAdfb1!!.setAdListener(object : InterstitialAdListener {
                override fun onError(ad: Ad, adError: AdError) {}
                override fun onAdLoaded(ad: Ad) {
                    Log.e(TAG, "onAdLoaded: ")
                }

                override fun onAdClicked(ad: Ad) {
                    Log.e(TAG, "onAdClicked: ")
                }

                override fun onLoggingImpression(ad: Ad) {}
                override fun onInterstitialDisplayed(ad: Ad) {
                    Log.d(TAG, "onInterstitialDisplayed: ")
                }

                override fun onInterstitialDismissed(ad: Ad) {
                    Log.d(TAG, "onInterstitialDismissed: ")
                }
            })*/

            val interstitialAdListener = object : InterstitialAdListener {
                override fun onInterstitialDisplayed(ad: Ad?) {
                    Log.d(TAG, "onInterstitialDismissed: ")
                }

                override fun onInterstitialDismissed(ad: Ad?) {
                    Log.d(TAG, "onInterstitialDisplayed: ")
                }

                override fun onError(ad: Ad?, adError: AdError) {}
                override fun onAdLoaded(ad: Ad?) {
                    Log.e(TAG, "onAdLoaded: ")
                }

                override fun onAdClicked(ad: Ad?) {
                    Log.e(TAG, "onAdClicked: ")
                }

                override fun onLoggingImpression(ad: Ad?) {}
            }

            TextArtApplication.instance!!.mInterstitialAdfb!!.loadAd(TextArtApplication.instance!!.mInterstitialAdfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build())
        }
    }

    override fun onStart() {
        super.onStart()

        if (FullMyPhotoActivity.isDelete) {
            FullMyPhotoActivity.isDelete = false
            (mPhotoList!!.filter {

                it.strings = it.strings!!.filter {
                    File(it.path).exists()
                } as ArrayList<ImageModel>

                it.strings!!.isNotEmpty()

            } as ArrayList<PhotoModel>).apply {
                mPhotoList!!.clear()
                mPhotoList!!.addAll(this)
            }

            if (mPhotoList!!.isEmpty() || myPhotoAdapter == null) {
                recycler_saved_images!!.visibility = View.INVISIBLE
                empty_view!!.visibility = View.VISIBLE
                txtCreate!!.visibility = View.VISIBLE
                //            NativeAdvanceHelper.loadAdSmall(this, (FrameLayout) findViewById(R.id.fl_adplaceholder));
            } else {
                recycler_saved_images!!.visibility = View.VISIBLE
                empty_view!!.visibility = View.INVISIBLE
                txtCreate!!.visibility = View.INVISIBLE
            }

            myPhotoAdapter?.notifyDataSetChanged()

        }
    }


    override fun onResume() {
        super.onResume()


    }

    private val photos: Unit
        private get() {
            mPhotoList!!.clear()
            val file = File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES
            ), "TextArt")
//            val file = File(Environment.getExternalStorageDirectory().path + File.separator + "TextArt")
            //var pos = 0
            if (file.isDirectory) {
                val files = file.listFiles { pathname -> pathname.path.endsWith(".jpg") || pathname.path.endsWith(".jpeg") || pathname.path.endsWith(".png") }

                if (files.isNotEmpty()) {
                    var temp: File
                    for (i in files.indices) {
                        for (j in i + 1 until files.size) {
                            if (files[i].lastModified() < files[j].lastModified()) {
                                temp = files[i]
                                files[i] = files[j]
                                files[j] = temp
                            }
                        }
                    }

                    val lastModDate = Date(files[0].lastModified())
                    val dateFormat = SimpleDateFormat("dd MMM yyyy")
                    var model = PhotoModel("", dateFormat.format(lastModDate), true, ArrayList())
                    mPhotoList!!.add(0, model)
                    model.strings?.add(ImageModel(files[0].absolutePath, false))
                    for (i in 0 until files.size - 1) {
                        //pos++
                        val nextDate = Date(files[i + 1].lastModified())
                        val current = Date(files[i].lastModified())
                        if (dateFormat.format(current) != dateFormat.format(nextDate)) {
                            count++
                            model = PhotoModel("", dateFormat.format(nextDate), true, ArrayList())
                            mPhotoList!!.add(model)
                            //pos++

                        }
                        model.strings?.add(ImageModel(files[i + 1].absolutePath, false))                        //mPhotoList!!.add(pos, PhotoModel(files[i + 1].absolutePath, dateFormat.format(current), false, false, null))
                    }

                }

            }
            if (myPhotoAdapter != null) {
                myPhotoAdapter!!.notifyDataSetChanged()
            }
        }

    val refresh: (Int, Boolean) -> Int = { it, show ->
        if (it != -1) {

            mPhotoList!!.filter { it.strings!!.isNotEmpty() }.apply {
                mPhotoList!!.clear()
                mPhotoList!!.addAll(this)
            }

            mPhotoList?.mapNotNull {
                it.isSelect = it.strings!!.filter { it.isSelect }.size == it.strings!!.size
            }

            //myPhotoAdapter?.isShowLong = false
            //myPhotoAdapter?.notifyItemChanged(it)

            myPhotoAdapter?.isShowLong = show
            myPhotoAdapter?.notifyDataSetChanged()
            showSelectAll(show)

            if (mPhotoList!!.isEmpty() || myPhotoAdapter == null) {
                recycler_saved_images!!.visibility = View.INVISIBLE
                empty_view!!.visibility = View.VISIBLE
                txtCreate!!.visibility = View.VISIBLE
                //            NativeAdvanceHelper.loadAdSmall(this, (FrameLayout) findViewById(R.id.fl_adplaceholder));
            } else {
                recycler_saved_images!!.visibility = View.VISIBLE
                empty_view!!.visibility = View.INVISIBLE
                txtCreate!!.visibility = View.INVISIBLE
            }

            -1
        } else {
            showSelectAll(false)
            /*if (!myPhotoAdapter?.isShowLong!!) {
                myPhotoAdapter?.isShowLong = show
                myPhotoAdapter?.notifyDataSetChanged()
                showSelectAll(true)
            }*/
            -1
        }
    }

    fun showSelectAll(isShow: Boolean) {
        (activity as MyPhotoActivity).actionShow(isShow)
    }

    fun selectAll(select: Boolean) {
        if (mPhotoList != null) {
            mPhotoList!!.mapNotNull {
                it.isSelect = select
                it.strings?.mapNotNull {
                    it.isSelect = select
                }
            }
            myPhotoAdapter?.notifyDataSetChanged()
        }
    }

    fun delete(): Boolean {
        if (mPhotoList != null) {
            val uris = arrayListOf<Uri>()
            Log.d("TASG", "${mPhotoList!!.size}")
            var list = mPhotoList!!.filter {

                it.strings = it.strings!!.filter {
                    val isDeleteSuccess = false
                    if (it.isSelect) {
                        val ffile = File(it.path)
                        val isDelete = File(it.path).delete()
                        if (isDelete) {
                            /*if (mPhotoList!!.isEmpty()) {
                                myPhotoAdapter?.isShowLong = false
                                myPhotoAdapter?.notifyDataSetChanged()
                                if (mPhotoList!!.isEmpty() || myPhotoAdapter == null) {
                                    recycler_saved_images!!.visibility = View.INVISIBLE
                                    empty_view!!.visibility = View.VISIBLE
                                    txtCreate!!.visibility = View.VISIBLE
                                    //            NativeAdvanceHelper.loadAdSmall(this, (FrameLayout) findViewById(R.id.fl_adplaceholder));
                                } else {
                                    recycler_saved_images!!.visibility = View.VISIBLE
                                    empty_view!!.visibility = View.INVISIBLE
                                    txtCreate!!.visibility = View.INVISIBLE
                                }
                                return true
                            }*/
                            Log.d("TASG", "${mPhotoList!!.size}")
                            myPhotoAdapter?.isShowLong = false
                            myPhotoAdapter?.al_my_photos = mPhotoList!!
                            myPhotoAdapter?.notifyDataSetChanged()
                        } else {
                            try {
                                val projection = arrayOf<String>(MediaStore.Images.Media._ID)
                                val selection: String = MediaStore.Images.Media.DATA.toString() + " = ?"
                                val selectionArgs = arrayOf<String>(ffile.getAbsolutePath())
                                val queryUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                                val contentResolver = requireContext().contentResolver
                                val c: Cursor? = contentResolver.query(queryUri, projection, selection, selectionArgs, null)
                                if (c != null) {
                                    if (c.moveToFirst()) {
                                        // We found the ID. Deleting the item via the content provider will also remove the file
                                        val id: Long = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                                        val deleteUri: Uri = ContentUris.withAppendedId(queryUri, id)
                                        try {
                                            uris.add(deleteUri)
                                        } catch (securityException: SecurityException) {
                                            securityException.printStackTrace()
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                val recoverableSecurityException =
                                                        securityException as? RecoverableSecurityException
                                                                ?: throw securityException
                                            } else {
                                                throw securityException
                                            }
                                        }
                                    } else {
                                        // File not found in media store DB
                                    }
                                    c.close()
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                        }
                        try {
                            val scanIntent =
                                    Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                            scanIntent.data = Uri.fromFile(File(it.path).absoluteFile)
                            requireContext().sendBroadcast(scanIntent)
                        } catch (e: Exception) {

                        }
                        !isDelete
                    } else
                        true

                } as ArrayList<ImageModel>

                //Log.d(TAG, "delete: ${it.date} ${it.strings!!.size}")
                //Log.d("TAGS", "${it.strings!!.size} - ${it.strings!!.isNotEmpty()}")
                it.strings!!.isNotEmpty()

            } as ArrayList<PhotoModel>


            mPhotoList?.clear()
            mPhotoList?.addAll(list)

            list = mPhotoList!!.filter {
                it.strings!!.isNotEmpty()
            } as ArrayList<PhotoModel>

            mPhotoList?.clear()
            mPhotoList?.addAll(list)

            //Log.d(TAG, "delete: ${mPhotoList!!.size}")

            if (mPhotoList!!.isEmpty()) {
                myPhotoAdapter?.isShowLong = false
                myPhotoAdapter?.notifyDataSetChanged()
                if (mPhotoList!!.isEmpty() || myPhotoAdapter == null) {
                    recycler_saved_images!!.visibility = View.INVISIBLE
                    empty_view!!.visibility = View.VISIBLE
                    txtCreate!!.visibility = View.VISIBLE
                    //            NativeAdvanceHelper.loadAdSmall(this, (FrameLayout) findViewById(R.id.fl_adplaceholder));
                } else {
                    recycler_saved_images!!.visibility = View.VISIBLE
                    empty_view!!.visibility = View.INVISIBLE
                    txtCreate!!.visibility = View.INVISIBLE
                }
            }else{
                myPhotoAdapter?.isShowLong = false
                myPhotoAdapter?.notifyDataSetChanged()
            }

            if (uris.isNotEmpty()) {
                deleteImages(uris)
            }

        }


        return false
    }

    private fun deleteImages(uris: List<Uri>) {
        val pendingIntent = MediaStore.createDeleteRequest(requireActivity().contentResolver, uris.filter {
            requireActivity().checkUriPermission(it, Binder.getCallingPid(), Binder.getCallingUid(), Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != PackageManager.PERMISSION_GRANTED
        })
        startIntentSenderForResult(pendingIntent.intentSender, 3232, null, 0, 0, 0, null)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 3232 && resultCode == Activity.RESULT_OK) {
            if (mPhotoList != null) {
                Log.d("TASG", "${mPhotoList!!.size}")
                var list = mPhotoList!!.filter {
                    it.strings = it.strings!!.filter {
                        if (it.isSelect) {
                            File(it.path).delete()

                            Log.d("TASG", "${mPhotoList!!.size}")
                            myPhotoAdapter?.isShowLong = false
                            myPhotoAdapter?.al_my_photos = mPhotoList!!
                            myPhotoAdapter?.notifyDataSetChanged()
                            try {
                                val scanIntent =
                                        Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                                scanIntent.data = Uri.fromFile(File(it.path).absoluteFile)
                                requireContext().sendBroadcast(scanIntent)
                            } catch (e: Exception) {

                            }
                            false
                        } else
                            true
                    } as ArrayList<ImageModel>

                    Log.d("TAGS", "${it.strings!!.size} - ${it.strings!!.isNotEmpty()}")
                    it.strings!!.isNotEmpty()

                } as ArrayList<PhotoModel>

                mPhotoList?.clear()
                mPhotoList?.addAll(list)

                list = mPhotoList!!.filter {
                    it.strings!!.isNotEmpty()
                } as ArrayList<PhotoModel>

                mPhotoList?.clear()
                mPhotoList?.addAll(list)

                try {
                    mPhotoList?.mapNotNull {
                        it.isSelect = false
                        it.strings?.mapNotNull {
                            it.isSelect = false
                        }
                    }
                    myPhotoAdapter!!.isShowLong = false
                    myPhotoAdapter?.notifyDataSetChanged()
                    showSelectAll(false)
                    PhotoFragment.isShowCheckBox = false

                    if (mPhotoList!!.isEmpty()) {
                        myPhotoAdapter?.isShowLong = false
                        myPhotoAdapter?.notifyDataSetChanged()
                        if (mPhotoList!!.isEmpty() || myPhotoAdapter == null) {
                            recycler_saved_images!!.visibility = View.INVISIBLE
                            empty_view!!.visibility = View.VISIBLE
                            txtCreate!!.visibility = View.VISIBLE
                            //            NativeAdvanceHelper.loadAdSmall(this, (FrameLayout) findViewById(R.id.fl_adplaceholder));
                        } else {
                            recycler_saved_images!!.visibility = View.VISIBLE
                            empty_view!!.visibility = View.INVISIBLE
                            txtCreate!!.visibility = View.INVISIBLE
                        }
                    }

                } catch (e: Exception) {
                }

            }

        } else if (requestCode == 3232 && resultCode == Activity.RESULT_CANCELED) {
            mPhotoList?.forEach {
                it.isSelect = false
                it.strings?.forEach {
                    it.isSelect = false
                }
            }
            if (myPhotoAdapter != null && myPhotoAdapter!!.isShowLong) {

                mPhotoList?.forEach {
                    it.isSelect = false
                    it.strings?.forEach {
                        it.isSelect = false
                    }
                }

                myPhotoAdapter!!.isShowLong = false
                myPhotoAdapter?.notifyDataSetChanged()
            }
        }
    }

    val onBackPres: () -> Unit = {

        try {
            if (myPhotoAdapter != null && myPhotoAdapter!!.isShowLong) {

                mPhotoList?.mapNotNull {
                    it.isSelect = false
                    it.strings?.mapNotNull {
                        it.isSelect = false
                    }
                }

                myPhotoAdapter!!.isShowLong = false
                myPhotoAdapter?.notifyDataSetChanged()

                showSelectAll(false)
                PhotoFragment.isShowCheckBox = false


            } else {
                //startActivity(Intent(context, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                activity?.finish()

            }
        } catch (e: Exception) {
            e.printStackTrace()
            activity?.finish()
        }
    }
}