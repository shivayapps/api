package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RectShape
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.comman.Constants
import kotlinx.android.synthetic.main.fackbook_native_normal.view.*
import kotlinx.android.synthetic.main.rv_gradient_text_layout.view.*

class GradientTextColorAdepter(
        private val mContext: Context,
        private val mPostion: Int,
        private val mGradientColorTextList: ArrayList<String>,
        private val action: (Int) -> Unit
) : RecyclerView.Adapter<GradientTextColorAdepter.AddTextHolder>() {
    init {
    }
    inner class AddTextHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AddTextHolder =
            AddTextHolder(LayoutInflater.from(mContext).inflate(R.layout.rv_gradient_text_layout, parent, false))

    override fun getItemCount(): Int = mGradientColorTextList.size

    @SuppressLint("ResourceType")
    override fun onBindViewHolder(holder: AddTextHolder, position: Int) {
        with(holder.itemView) {

            if (gradientPosition == position) {
                txtGradientColorText.setImageResource(R.drawable.black_border)
            } else {
                txtGradientColorText.setImageResource(0)
            }
            try {
                val split: Array<String> = mGradientColorTextList[position].split(",".toRegex()).toTypedArray()
                val color1 = split[0]
                val color2 = split[1]
                var color3 = ""

//                var shader: LinearGradient
//                if (split.size != 3) {
//                    shader = LinearGradient(0.0f, 20.0f, 0.0f, txtGradientColorText?.textSize!! + 8, intArrayOf(Color.parseColor(color1), Color.parseColor(color2)), null as FloatArray?, Shader.TileMode.CLAMP)
//                } else {
//                    color3 = split[2]
//                    shader = LinearGradient(0.0f, 20.0f, 0.0f, txtGradientColorText?.textSize!! + 8, intArrayOf(Color.parseColor(color1), Color.parseColor(color2), Color.parseColor(color3)), null as FloatArray?, Shader.TileMode.CLAMP)
//                }
//                txtGradientColorText?.paint?.shader = shader

                val gradientDrawable = GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM,
                        intArrayOf(Color.parseColor(color1),
                                Color.parseColor(color2))
                )

                //Set Gradient
                txtGradientColorText.background = gradientDrawable
            } catch (ex: Exception) {
                ex.printStackTrace()
            }

            txtGradientColorText.setOnClickListener {
                gradientPosition = position
                action(position)
                notifyDataSetChanged()
            }

        }

    }

    fun clickGradientColor(pos: Int){
        gradientPosition = pos
        action(pos)
    }

    companion object{
        var gradientPosition = -1
    }

}