package com.text.art.fancy.creator.categorys.model;


import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DataItem {

	@SerializedName("image")
	private List<ImageItem> image;

	@SerializedName("name")
	private String name;

	@SerializedName("id")
	private int id;

	public void setImage(List<ImageItem> image){
		this.image = image;
	}

	public List<ImageItem> getImage(){
		return image;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"image = '" + image + '\'' + 
			",name = '" + name + '\'' + 
			",id = '" + id + '\'' + 
			"}";
		}
}