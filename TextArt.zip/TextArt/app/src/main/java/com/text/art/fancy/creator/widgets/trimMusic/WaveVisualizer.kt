package com.text.art.fancy.creator.widgets.trimMusic

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Rect
import android.util.AttributeSet
import androidx.annotation.Nullable
import androidx.core.content.ContextCompat
import com.text.art.fancy.creator.R
import java.util.*

class WaveVisualizer : BaseVisualizer {

    private var mMaxBatchCount = 0
    private var mWavePath: Path? = null
    private var mWavePath1: Path? = null
    private var mWavePath2: Path? = null
    private var nPoints = 0
    private var mBezierPoints: Array<PointF?>? = null
    private var mBezierControlPoints1: Array<PointF?>? = null
    private var mBezierControlPoints2: Array<PointF?>? = null


    private var mBezier1Points: Array<PointF?>? = null
    private var mBezier1ControlPoints1: Array<PointF?>? = null
    private var mBezier1ControlPoints2: Array<PointF?>? = null

    private var mBezier2Points: Array<PointF?>? = null
    private var mBezier2ControlPoints1: Array<PointF?>? = null
    private var mBezier2ControlPoints2: Array<PointF?>? = null

    private lateinit var mSrcY: FloatArray
    private lateinit var mDestY: FloatArray
    private lateinit var mSrcY1: FloatArray
    private lateinit var mDestY1: FloatArray
    private lateinit var mSrcY2: FloatArray
    private lateinit var mDestY2: FloatArray
    private var mWidthOffset = 0f
    private var mClipBounds: Rect? = null
    private var nBatchCount = 0
    private var nBatchCount1 = 0
    private var nBatchCount2 = 0
    private var mRandom: Random? = null

    private var mProgress = 0

    constructor(context: Context?) : super(context!!) {}
    constructor(
        context: Context?,
        @Nullable attrs: AttributeSet?
    ) : super(context!!, attrs) {
    }

    constructor(
        context: Context?,
        @Nullable attrs: AttributeSet?,
        defStyleAttr: Int
    ) : super(context!!, attrs, defStyleAttr) {
    }

    override fun init() {
        nPoints = (WAVE_MAX_POINTS * mDensity).toInt()
        if (nPoints < WAVE_MIN_POINTS)
            nPoints = WAVE_MIN_POINTS
        mWidthOffset = -1f
        nBatchCount = 0
        nBatchCount1 = 0
        nBatchCount2 = 0
        setAnimationSpeed(mAnimSpeed)
        mRandom = Random()
        mClipBounds = Rect()
        mWavePath = Path()
        mWavePath1 = Path()
        mWavePath2 = Path()
        mSrcY = FloatArray(nPoints + 1)
        mDestY = FloatArray(nPoints + 1)
        mSrcY1 = FloatArray(nPoints + 1)
        mDestY1 = FloatArray(nPoints + 1)
        mSrcY2 = FloatArray(nPoints + 1)
        mDestY2 = FloatArray(nPoints + 1)

        //initialize mBezierPoints
        mBezierPoints = arrayOfNulls(nPoints + 1)
        mBezierControlPoints1 = arrayOfNulls(nPoints + 1)
        mBezierControlPoints2 = arrayOfNulls(nPoints + 1)

        mBezier1Points = arrayOfNulls(nPoints + 1)
        mBezier1ControlPoints1 = arrayOfNulls(nPoints + 1)
        mBezier1ControlPoints2 = arrayOfNulls(nPoints + 1)

        mBezier2Points = arrayOfNulls(nPoints + 1)
        mBezier2ControlPoints1 = arrayOfNulls(nPoints + 1)
        mBezier2ControlPoints2 = arrayOfNulls(nPoints + 1)
        for (i in mBezierPoints!!.indices) {
            mBezierPoints!![i] = PointF()
            mBezierControlPoints1!![i] = PointF()
            mBezierControlPoints2!![i] = PointF()

            mBezier1Points!![i] = PointF()
            mBezier1ControlPoints1!![i] = PointF()
            mBezier1ControlPoints2!![i] = PointF()

            mBezier2Points!![i] = PointF()
            mBezier2ControlPoints1!![i] = PointF()
            mBezier2ControlPoints2!![i] = PointF()
        }

        /*setPadding(
            resources.getDimension(R.dimen._8sdp).toInt(),
            0,
            resources.getDimension(R.dimen._8sdp).toInt(),
            0
        )*/
    }


    override fun setAnimationSpeed(animSpeed: AnimSpeed) {
        super.setAnimationSpeed(animSpeed!!)
        mMaxBatchCount = (4f - mAnimSpeed.ordinal).toInt()
    }

    fun setProgress(float: Float) {

    }

    override fun onDraw(canvas: Canvas) {
        if (mWidthOffset == -1f) {
            canvas.getClipBounds(mClipBounds)
            //mClipBounds!!.bottom -= mClipBounds!!.bottom / 3
            mWidthOffset = canvas.width / nPoints.toFloat()
            //initialize bezier points
            for (i in mBezierPoints!!.indices) {
                val posX = mClipBounds!!.left + i * mWidthOffset
                var posY: Float = if (mPositionGravity === PositionGravity.TOP)
                    mClipBounds!!.top.toFloat()
                else
                    mClipBounds!!.bottom.toFloat()
                mSrcY[i] = posY
                mDestY[i] = posY
                mSrcY1[i] = posY
                mDestY1[i] = posY
                mSrcY2[i] = posY
                mDestY2[i] = posY
                mBezierPoints!![i]!![posX] = posY
                mBezier1Points!![i]!![posX] = posY
                mBezier2Points!![i]!![posX] = posY
            }
        }

        //create the path and draw
        if (isVisualizationEnabled && mRawAudioBytes != null) {
            if (mRawAudioBytes!!.size == 0) {
                return
            }
            mWavePath!!.rewind()
            mWavePath1!!.rewind()
            mWavePath2!!.rewind()
            //find the destination bezier point for a batch
            if (nBatchCount == 0 || nBatchCount1 == 0 || nBatchCount2 == 0) {
                val randPosY = mDestY[mRandom!!.nextInt(nPoints)]
                val randPosY1 = mDestY1[mRandom!!.nextInt(nPoints)]
                val randPosY2 = mDestY2[mRandom!!.nextInt(nPoints)]
                for (i in mBezierPoints!!.indices) {
                    val x =
                        Math.ceil(((i + 1) * (mRawAudioBytes!!.size / nPoints)).toDouble()).toInt()
                    var t = 0
                    var t1 = 0
                    var t2 = 0
                    if (x < 1024) {
                        t =
                            canvas.height - (canvas.height / 3) + (Math.abs(mRawAudioBytes!![x].toInt()) + 128).toByte() * (canvas.height / 2) / 128
                        t1 =
                            canvas.height - (canvas.height / 3 ) + (Math.abs(mRawAudioBytes!![x].toInt()) + 128).toByte() * (canvas.height / 2) / 128
                        t2 =
                            canvas.height - (canvas.height / 3 ) + (Math.abs(mRawAudioBytes!![x].toInt()) + 128).toByte() * (canvas.height / 2) / 128

                    }

                    if (nBatchCount == 0) {
                        var posY: Float =
                            if (mPositionGravity === PositionGravity.TOP)
                                mClipBounds!!.bottom - t.toFloat()
                            else
                                mClipBounds!!.top + t.toFloat()
                        //change the source and destination y
                        mSrcY[i] = mDestY[i]
                        mDestY[i] = posY
                    }
                    if (nBatchCount1 == 0) {

                        var posY1: Float =
                            if (mPositionGravity === PositionGravity.TOP)
                                mClipBounds!!.bottom - t1.toFloat()
                            else
                                mClipBounds!!.top + t1.toFloat()
                        mSrcY1[i] = mDestY1[i]
                        mDestY1[i] = posY1
                    }
                    if (nBatchCount2 == 0) {
                        var posY2: Float =
                            if (mPositionGravity === PositionGravity.TOP)
                                mClipBounds!!.bottom - t2.toFloat()
                            else
                                mClipBounds!!.top + t2.toFloat()

                        mSrcY2[i] = mDestY2[i]
                        mDestY2[i] = posY2
                    }
                }
                if (nBatchCount == 0)
                    mDestY[mBezierPoints!!.size - 1] = randPosY
                if (nBatchCount1 == 0)
                    mDestY1[mBezier1Points!!.size - 1] = randPosY1
                if (nBatchCount2 == 0)
                    mDestY2[mBezier1Points!!.size - 1] = randPosY2
            }

            //increment batch count
            nBatchCount++
            nBatchCount1++
            nBatchCount2++

            //for smoothing animation
            for (i in mBezierPoints!!.indices) {
                mBezierPoints!![i]!!.y =
                    mSrcY[i] + nBatchCount.toFloat() / mMaxBatchCount * (mDestY[i] - mSrcY[i])

                mBezier1Points!![i]!!.y =
                    mSrcY1[i] + nBatchCount1.toFloat() / (mMaxBatchCount - 1) * (mDestY1[i] - mSrcY1[i])

                mBezier2Points!![i]!!.y =
                    mSrcY2[i] + nBatchCount1.toFloat() / (mMaxBatchCount + 1) * (mDestY2[i] - mSrcY2[i])
            }

            //reset the batch count
            if (nBatchCount == mMaxBatchCount) nBatchCount = 0
            if (nBatchCount1 == mMaxBatchCount - 1) nBatchCount1 = 0
            if (nBatchCount2 == mMaxBatchCount + 1) nBatchCount2 = 0

            //calculate the bezier curve control points
            for (i in 1 until mBezierPoints!!.size) {
                mBezierControlPoints1!![i]!![(mBezierPoints!![i]!!.x + mBezierPoints!![i - 1]!!.x) / 2] =
                    mBezierPoints!![i - 1]!!.y
                mBezierControlPoints2!![i]!![(mBezierPoints!![i]!!.x + mBezierPoints!![i - 1]!!.x) / 2] =
                    mBezierPoints!![i]!!.y

                mBezier1ControlPoints1!![i]!![(mBezier1Points!![i]!!.x + mBezier1Points!![i - 1]!!.x) / 2] =
                    mBezier1Points!![i - 1]!!.y
                mBezier1ControlPoints2!![i]!![(mBezier1Points!![i]!!.x + mBezier1Points!![i - 1]!!.x) / 2] =
                    mBezier1Points!![i]!!.y

                mBezier2ControlPoints1!![i]!![(mBezier2Points!![i]!!.x + mBezier2Points!![i - 1]!!.x) / 2] =
                    mBezier2Points!![i - 1]!!.y
                mBezier2ControlPoints2!![i]!![(mBezier2Points!![i]!!.x + mBezier2Points!![i - 1]!!.x) / 2] =
                    mBezier2Points!![i]!!.y
            }

            //create the path
            mWavePath!!.moveTo(mBezierPoints!![0]!!.x, mBezierPoints!![0]!!.y)
            mWavePath1!!.moveTo(mBezier1Points!![0]!!.x, mBezier1Points!![0]!!.y)
            mWavePath2!!.moveTo(mBezier2Points!![0]!!.x, mBezier2Points!![0]!!.y)
            for (i in 1 until mBezierPoints!!.size) {
                mWavePath!!.cubicTo(
                    mBezierControlPoints1!![i]!!.x, mBezierControlPoints1!![i]!!.y,
                    mBezierControlPoints2!![i]!!.x, mBezierControlPoints2!![i]!!.y,
                    mBezierPoints!![i]!!.x, mBezierPoints!![i]!!.y
                )

                mWavePath1!!.cubicTo(
                    mBezier1ControlPoints1!![i]!!.x, mBezier1ControlPoints1!![i]!!.y,
                    mBezier1ControlPoints2!![i]!!.x, mBezier1ControlPoints2!![i]!!.y,
                    mBezier1Points!![i]!!.x, mBezier1Points!![i]!!.y
                )
                mWavePath2!!.cubicTo(
                    mBezier2ControlPoints1!![i]!!.x, mBezier2ControlPoints1!![i]!!.y,
                    mBezier2ControlPoints2!![i]!!.x, mBezier2ControlPoints2!![i]!!.y,
                    mBezier2Points!![i]!!.x, mBezier2Points!![i]!!.y
                )
            }

            //add last 3 line to close the view
            //mWavePath.lineTo(mClipBounds.right, mBezierPoints[0].y);
            if (mPaintStyle === PaintStyle.FILL) {
                mWavePath!!.lineTo(mClipBounds!!.right.toFloat(), mClipBounds!!.bottom.toFloat())
                mWavePath!!.lineTo(mClipBounds!!.left.toFloat(), mClipBounds!!.bottom.toFloat())

                mWavePath1!!.lineTo(mClipBounds!!.right.toFloat(), mClipBounds!!.bottom.toFloat())
                mWavePath1!!.lineTo(mClipBounds!!.left.toFloat(), mClipBounds!!.bottom.toFloat())

                mWavePath2!!.lineTo(mClipBounds!!.right.toFloat(), mClipBounds!!.bottom.toFloat())
                mWavePath2!!.lineTo(mClipBounds!!.left.toFloat(), mClipBounds!!.bottom.toFloat())


                mWavePath!!.close()
                mWavePath1!!.close()
                mWavePath2!!.close()
            }
            mPaint?.color = ContextCompat.getColor(context, R.color.colorPrimary)
            mBlurPaint?.color = ContextCompat.getColor(context, R.color.colorPrimary)
            canvas.drawPath(mWavePath!!, mPaint!!)
            canvas.drawPath(mWavePath!!, mBlurPaint!!)

            mPaint?.color = ContextCompat.getColor(context, R.color.white)
            mBlurPaint?.color = ContextCompat.getColor(context, R.color.white)
            canvas.drawPath(mWavePath1!!, mPaint!!)
            canvas.drawPath(mWavePath1!!, mBlurPaint!!)

            mPaint?.color = ContextCompat.getColor(context, R.color.green)
            mBlurPaint?.color = ContextCompat.getColor(context, R.color.green)
            canvas.drawPath(mWavePath2!!, mPaint!!)
            canvas.drawPath(mWavePath2!!, mBlurPaint!!)
        }
        super.onDraw(canvas)
    }

    companion object {
        private const val WAVE_MAX_POINTS = 40
        private const val WAVE_MIN_POINTS = 4
    }
}