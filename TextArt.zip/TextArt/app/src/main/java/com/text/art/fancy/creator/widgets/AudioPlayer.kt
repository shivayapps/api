package com.text.art.fancy.creator.widgets

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaPlayer.OnCompletionListener
import android.net.Uri

class AudioPlayer {
    private var mMediaPlayer: MediaPlayer? = null

    private var uri: Uri? = null
    private var context: Context? = null
    private var action: (() -> Unit)? = null

    fun stop() {
        if (mMediaPlayer != null) {
            mMediaPlayer!!.release()
            mMediaPlayer = null
        }
    }

    fun play(
        c: Context?,
        rid: Uri,
        action: () -> Unit
    ) {
        this.uri = rid
        this.context = c
        this.action = action
        stop()

        try {
            if(rid.toString().contains("default_music.mp3")) {

                mMediaPlayer = MediaPlayer()
                mMediaPlayer?.setDataSource(rid.toString())
                mMediaPlayer?.setOnCompletionListener(OnCompletionListener {
                    stop()
                    actionComplete()
                })
                mMediaPlayer?.prepare()
                mMediaPlayer?.setOnPreparedListener {
                    mMediaPlayer?.start()
                }
                action()
            }else{
                mMediaPlayer = MediaPlayer.create(c, rid)
                mMediaPlayer?.setOnCompletionListener(OnCompletionListener {
                    stop()
                    actionComplete()
                })
                mMediaPlayer?.start()
                action()
            }


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getDuration(): Int = mMediaPlayer?.duration ?: 0

    fun getCurrentDuration(): Int = if (mMediaPlayer == null) 0 else mMediaPlayer!!.currentPosition

    fun isPlaying(): Boolean = if (mMediaPlayer == null) false else mMediaPlayer!!.isPlaying

    fun pause() = mMediaPlayer?.pause()

    fun seekTo(v: Int) = if (mMediaPlayer != null) mMediaPlayer!!.seekTo(v) else Unit

    fun start() =
        if (mMediaPlayer == null) play(context, uri!!, action!!) else mMediaPlayer!!.start()

    var actionComplete: () -> Unit = {

    }

    fun release() {
        if (mMediaPlayer != null && mMediaPlayer!!.isPlaying)
            mMediaPlayer?.stop()
        mMediaPlayer?.release()
        mMediaPlayer = null
    }

    val audioSessionId: Int
        get() = if (mMediaPlayer == null) -1 else mMediaPlayer!!.audioSessionId

    interface AudioPlayerEvent {
        fun onCompleted()
    }
}