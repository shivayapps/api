package com.text.art.fancy.creator.retrofit;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class APIClient {

//    static {
//        System.loadLibrary("native-lib");
//    }

    private static Retrofit retrofit = null;

    public static String getBaseURL(){
//        return "http://165.22.219.93/auto-wallpaper-changer/api/";
        return "https://raw.githubusercontent.com/shivayapps/art/main/";
    };

    public static Retrofit getClient() {
        try {
            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS);

            OkHttpClient okHttpClient = builder.build();

            if (retrofit == null) {
                retrofit = new Retrofit.Builder()
                        .baseUrl(getBaseURL())
                        .addConverterFactory(GsonConverterFactory.create())
                        .client(okHttpClient)
                        .build();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return retrofit;
    }

}
