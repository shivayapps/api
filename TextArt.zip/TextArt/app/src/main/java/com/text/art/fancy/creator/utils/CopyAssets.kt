package com.text.art.fancy.creator.utils

import android.content.Context
import android.content.res.AssetManager
import android.util.Log
import com.text.art.fancy.creator.comman.Constants
import java.io.*
import java.util.Collections.list


object CopyAssets {

    fun copyAssets(context: Context, folderName: String = "") {
        val outputFolder = if (folderName == "") {
            File(context.cacheDir.path)
        } else {
            File(context.cacheDir.path + "/$folderName")
        }
        if (!outputFolder.exists()) {
            outputFolder.mkdir()
        }

        val assetManager = context.assets
        val files: Array<out String>? = if (folderName == "") {
            context.assets.list("")
        } else {
            context.assets.list(folderName)!!
        }

        files?.let {
            for (filename in it) {

                var `in`: InputStream? = null
                var out: OutputStream? = null
                try {
                    `in` = assetManager.open("$folderName/$filename")
                    val outFile = File(outputFolder.absolutePath, filename)
                    if (!outFile.exists()) {
                        out = FileOutputStream(outFile)
                        copyFile(`in`, out)
                        Log.d("copyAssets", "copyAssets: Copying : $outFile")
                    } else {
                        Log.d("copyAssets", "copyAssets: Already Present : $outFile")
                    }
                } catch (e: IOException) {
                    Log.e("tag", "Failed to copy asset file: $filename", e)
                } finally {
                    if (`in` != null) {
                        try { `in`.close() } catch (e: IOException) { }
                    }
                    if (out != null) {
                        try { out.flush()
                            out.close()
                        } catch (e: IOException) { }
                    }
                }

            }
        }

    }

    @Throws(IOException::class)
    fun copyFile(`in`: InputStream?, out: OutputStream?) {
        val buffer = ByteArray(1024)
        var read: Int
        while (`in`!!.read(buffer).also { read = it } != -1) {
            out!!.write(buffer, 0, read)
        }
    }

    suspend fun getFontsPath(context: Context): String {
        return context.cacheDir.path + "/fonts"
    }

}
