package com.text.art.fancy.creator.adepter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.updateLayoutParams
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.model.LogoData
import com.text.art.fancy.creator.utils.*
import org.jetbrains.anko.textColor
import sticker.view.dixitgabani.autofit.AutoResizeTextView
import java.util.*
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt


class EditLogoAdapter(
    private val context: Context,
    private var logoArray: ArrayList<LogoData>,
    private val action: OnItemClick,
): RecyclerView.Adapter<EditLogoAdapter.ViewHolder>() {

    private var logoName = "TEXTART"
    private var border = 0F

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.rv_generate_logo_list, parent, false))
    }

    override fun onBindViewHolder(
        holder: ViewHolder,
        @SuppressLint("RecyclerView") position: Int,
    ) {
//        imageLoader.init(ImageLoaderConfiguration.createDefault(context)
        Log.d("Logo", "Logo view position $position")
        with(holder) {
            setIsRecyclable(true)
            val anim = AlphaAnimation(0.5f, 1.0f)
            anim.duration = 100
            itemView.startAnimation(anim)
            //val color = Color.argb(255, Random().nextInt(256), Random().nextInt(256), Random().nextInt(256))

            Glide.with(context).load(logoArray[position].logo).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(logo)

            if (logoArray[position].color.bg.contains("webp") || logoArray[position].color.bg.contains("image")) {
                Glide.with(context).asDrawable()
                    .load(logoArray[position].color.bg).override(100,100)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .into(object : CustomTarget<Drawable>() {
                        override fun onLoadCleared(placeholder: Drawable?) {}
                        override fun onResourceReady(
                            resource: Drawable,
                            transition: Transition<in Drawable>?,
                        ) {
                            container.background = resource
                            progressBar.hide()
                            txtName.show()
                            logo.show()
                        }
                    })
            } else if (logoArray[position].color.bg.contains("#")) {
                container.setBackgroundColor(Color.parseColor(logoArray[position].color.bg))
                progressBar.hide()
                txtName.show()
                logo.show()
            }

            with(txtName) {
                updateLayoutParams<ConstraintLayout.LayoutParams> {
                    this.verticalBias = logoArray[position].verticalBias.toFloat()
                }
                setStoke(Color.parseColor(logoArray[position].color.border), logoArray[position].stroke)
                rotation = (logoArray[position].rotation * -1).toFloat()
                textColor = Color.parseColor(logoArray[position].color.text)
                text = logoName
                typeface = Typeface.createFromAsset(context.assets, "tempFont/${logoArray[position].fontFamily}")
            }

            container.click {
                if (progressBar.visibility == View.VISIBLE) {
                    context.showToast("Please wait.")
                } else {
                    action.onItemClick(position, logoName)
                }
            }
        }
    }

    private fun generateBorderImage(bitmap: Bitmap, color: Int, radius: Float): Bitmap? {
        val finalBitmap = Bitmap.createBitmap(
            (bitmap.width+(border)).roundToInt(),
            (bitmap.height+(border)).roundToInt(),
            Bitmap.Config.ARGB_8888
        )

        Log.d("TAG", "generateBorderImage: W : ${finalBitmap.width} and H : ${finalBitmap.height}")
        val rect = Rect(border.roundToInt(), border.roundToInt(), bitmap.width,bitmap.height)
        val borderRect = Rect(0,0, finalBitmap.width,finalBitmap.height)
        val bgBitmap = Bitmap.createScaledBitmap(bitmap,
            (bitmap.width),
            (bitmap.height),
            false)
        var canvas = Canvas(finalBitmap)
        val filter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
        Log.d("borderRect", "generateBorderImage: borderRect : $borderRect")
        Log.d("borderRect", "generateBorderImage: border : $border")

        canvas.drawBitmap(bgBitmap, null, borderRect, Paint().apply {
            this.color = color
            this.colorFilter = filter
            this.style = Paint.Style.FILL
        })

        canvas.drawBitmap(bitmap, null, rect, null)
        return finalBitmap
    }

    override fun getItemCount(): Int {
        return logoArray.size
    }

    var logoText: String
        get() { return logoName }
        set(logoName) { this.logoName = logoName }

    var borderSize: Float
        get() { return border }
        set(border) { this.border = border }

    private fun getPrimaryColorFromImage(bitmap: Bitmap): Int {
        val newBitmap = Bitmap.createScaledBitmap(bitmap, 8, 8, true)
        var red = 0
        var green = 0
        var blue = 0
        var c = 0
        var r: Int
        var g: Int
        var b: Int
        for (y in 0 until newBitmap.height) {
            for (x in 0 until newBitmap.height) {
                val color = newBitmap.getPixel(x, y)
                r = color shr 16 and 0xFF
                g = color shr 8 and 0xFF
                b = color and 0xFF
                if (r > 200 || g > 200 || b > 200) continue
                red += r
                green += g
                blue += b
                c++
            }
        }
        newBitmap.recycle()
        if (c == 0) {
            // got a bitmap with no pixels in it
            // avoid the "divide by zero" error
            // but WHO DARES GIMME AN EMPTY BITMAP?
            return -0x1000000
        } else {
            red = max(0, min(0xFF, red / c))
            green = max(0, min(0xFF, green / c))
            blue = max(0, min(0xFF, blue / c))

            val hsv = FloatArray(3)
            Color.RGBToHSV(red, green, blue, hsv)
            hsv[2] = max(hsv[2], 0.7f)

            return 0xFF shl 24 or Color.HSVToColor(hsv) // (0xFF << 24) | (red << 16) | (green << 8) | blue;
        }
    }

    interface OnItemClick {
        fun onItemClick(position: Int, text: String)
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateList(filterArray: ArrayList<LogoData>) {
        logoArray = filterArray
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var container: ConstraintLayout = itemView.findViewById(R.id.container)
//        var bgLogo: ImageView = itemView.findViewById(R.id.bgLogo)
        var logo: ImageView = itemView.findViewById(R.id.logoThumb)
        var txtName: AutoResizeTextView = itemView.findViewById(R.id.textThumb)
        var progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
    }
}

