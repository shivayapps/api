package com.text.art.fancy.creator.activitys

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.utils.hideSystemUI
import com.github.demono.AutoScrollViewPager
import kotlinx.android.synthetic.main.offline_activity.*

class OfflineAdsActivity : AppCompatActivity(){
    private var type: String = ""
    private var countDownTimer: CountDownTimer? = null
    var dataImage: ArrayList<Int>? = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.offline_activity)
        try {
            hideSystemUI()
            if (MySharedPreferences(this).isSubscribe) {
                Handler(Looper.getMainLooper()).postDelayed({
                    if (intent.hasExtra("redirect")) {
                        type = intent.getStringExtra("redirect")!!
                    }

                }, 100)
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    if (intent.hasExtra("redirect")) {
                        type = intent.getStringExtra("redirect")!!
                    }

                }, 500)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        myTimer()
        setAutoScrollAds()
        textView26.setOnClickListener {
            countDownTimer?.cancel()
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(this@OfflineAdsActivity, HomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                intent.putExtra("redirect", type)
                startActivity(intent)
                finish()
            }, 200)
        }
    }

    private fun setAutoScrollAds() {
        dataImage!!.clear()
        var string = ""
        val mViewPager = findViewById<AutoScrollViewPager>(R.id.viewPagers)
        if (MySharedPreferences(this).offlineAds) {
            string = "namePhoto"
            MySharedPreferences(this).offlineAds = false
            dataImage!!.add(R.drawable.name_photo_offline)
        } else {
            string = "kriadl"
            MySharedPreferences(this).offlineAds = true
            dataImage!!.add(R.drawable.kriadl_offline_ads)
        }
//        val mAdapter = MyAdapter(dataImage!!, this, string)
//        mViewPager.adapter = mAdapter
//        mViewPager.startAutoScroll()
    }

    override fun onBackPressed() {
//        finish()
    }

    private fun myTimer() {
        countDownTimer = object : CountDownTimer(12000, 2000) {
            override fun onTick(millisUntilFinished: Long) {
                textView22.text = "Start In " + millisUntilFinished / 2000 + " Sec"
                if ((millisUntilFinished / 2000).toInt() == 1) {
                    countDownTimer?.cancel()
                    Handler().postDelayed({
                        val intent = Intent(this@OfflineAdsActivity, HomeActivity::class.java)
                        intent.flags =
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        intent.putExtra("redirect", type)
                        startActivity(intent)
                        finish()
                    }, 200)
                }
            }

            override fun onFinish() {
//                if (!ifClicked) {
                Handler().postDelayed({
                    val intent = Intent(this@OfflineAdsActivity, HomeActivity::class.java)
                    intent.flags =
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    intent.putExtra("redirect", type)
                    startActivity(intent)
                    finish()
                }, 200)
//                }

            }
        }
        countDownTimer?.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100) {
//            try {
//                textView22.text = "Start In " + 1+" Sec"
//            } catch (e: Exception) {
//            }

            Handler().postDelayed({
                val intent = Intent(this@OfflineAdsActivity, HomeActivity::class.java)
                intent.flags =
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                intent.putExtra("redirect", type)
                startActivity(intent)
                finish()
            }, 200)

        }
    }

//    override fun bannerClicked(adsType: String?) {
//        countDownTimer?.cancel()
//        if (adsType.equals("namePhoto", ignoreCase = true)) {
//            try {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("market://details?id=com.name.photo.birthday.cake.quotes.frame.editor")
//                    ), 100
//                )
//            } catch (anfe: ActivityNotFoundException) {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("https://play.google.com/store/apps/details?id=com.name.photo.birthday.cake.quotes.frame.editor")
//                    ), 100
//                )
//            }
//        } else {
//            try {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("market://details?id=com.graphic.design.digital.businessadsmaker")
//                    ), 100
//                )
//            } catch (anfe: ActivityNotFoundException) {
//                startActivityForResult(
//                    Intent(
//                        Intent.ACTION_VIEW,
//                        Uri.parse("https://play.google.com/store/apps/details?id=com.graphic.design.digital.businessadsmaker")
//                    ), 100
//                )
//            }
//        }
//
//    }
}