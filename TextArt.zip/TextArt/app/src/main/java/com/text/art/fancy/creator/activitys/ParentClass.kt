package com.text.art.fancy.creator.activitys

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.utils.showToast
import retrofit2.Call
import retrofit2.Callback

class ParentClass : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        callAllApi()
    }

    private fun callAllApi() {
        val apiInterface = APIClient.getClient().create(APIInterface::class.java)
        val call = apiInterface!!.parameterList
        call.enqueue(object : Callback<Response> {
            override fun onResponse(
                call: Call<Response>,
                response: retrofit2.Response<Response>
            ) {
                Log.d("789412312331", "onResponse: " + response.body()!!.parameters)
                response.body()!!.parameters.filterIndexed { index, parametersItem ->
                    if (parametersItem.name == "Background" || parametersItem.id == 439) {
                        BGActivity.bgAllArray.clear()
                        parametersItem.all_childs.filterIndexed { index, categoryParametersItem ->
                            BGActivity.bgAllArray.add(categoryParametersItem)
                            true
                        }
                    }
                    if (parametersItem.name == "Sticker" || parametersItem.id == 449) {
                        StickerActivity.stickerAllArray.clear()
                        parametersItem.all_childs.filterIndexed { index, categoryParametersItem ->
                            StickerActivity.stickerAllArray.add(categoryParametersItem)
                            true
                        }
                    }
                    if (parametersItem.name == "Frames" || parametersItem.id == 451) {
                        FrameActivity.frameAllArray.clear()
                        parametersItem.all_childs.filterIndexed { index, categoryParametersItem ->
                            FrameActivity.frameAllArray.add(categoryParametersItem)
                            true
                        }
                    }
                    true
                }

            }

            override fun onFailure(call: Call<Response>, t: Throwable) {
                showToast("Please try again latter")
                finish()
            }
        })
    }

}