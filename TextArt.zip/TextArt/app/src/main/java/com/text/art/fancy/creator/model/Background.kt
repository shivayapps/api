package com.text.art.fancy.creator.model

data class Background(
    var combo: Any ?= null,
    var background: Any ?= null,
    var frame: Any ?= null
)
