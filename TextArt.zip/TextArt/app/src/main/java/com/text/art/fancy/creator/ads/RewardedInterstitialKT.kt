package com.text.art.fancy.creator.ads

import android.app.Activity
import android.util.Log
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs


class RewardedInterstitialKT {
    var rewardedInterstitialAd: RewardedInterstitialAd? = null
    val interstialAdId = AppIDs().getGoogleInterstitialRewarded()

    fun loadAd(activity: Activity?,rewardInterstitialInterface: RewardInterstitialInterface): RewardedInterstitialAd? {

        Log.d(TAG, "RewardedInterstitialKT: ${interstialAdId}")
        RewardedInterstitialAd.load(activity!!, interstialAdId,
                AdRequest.Builder().build(), object : RewardedInterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedInterstitialAd) {
                rewardInterstitialInterface.onAdLoaded()
                rewardedInterstitialAd = ad
                rewardedInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        rewardInterstitialInterface.onAdDismissedFullScreenContent()
                    }
                    override fun onAdShowedFullScreenContent() {
                        rewardInterstitialInterface.onAdShowedFullScreenContent()
                    }

                    override fun onAdDismissedFullScreenContent() {
                        rewardInterstitialInterface.onAdDismissedFullScreenContent()
                    }
                }

            }
            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                Log.e(TAG, "onAdFailedToLoad ${loadAdError.message}")
            }
        })
        return rewardedInterstitialAd
    }

    interface RewardInterstitialInterface {
        fun onAdLoaded()
        fun onAdFailedToLoad()
        fun onAdFailedToShowFullScreenContent()
        fun onAdShowedFullScreenContent()
        fun onAdDismissedFullScreenContent()
    }
  /*
  //showAds
  RewardedInterstitialKT.instance?.rewardedInterstitialAd?.show(this, object : OnUserEarnedRewardListener {
        override fun onUserEarnedReward(p0: RewardItem) {
            Toast.makeText(this@MainActivityKT, "onUserEarnedReward", Toast.LENGTH_SHORT).show()
        }
    })
//load
    RewardedInterstitialKT.instance?.loadAd(this,object :RewardedInterstitialKT.RewardInterstitialInterface{
        override fun onAdLoaded() {
            Toast.makeText(this@MainActivityKT, "onAdLoaded", Toast.LENGTH_SHORT).show()
        }

        override fun onAdFailedToLoad() {
            Toast.makeText(this@MainActivityKT, "onAdFailedToLoad", Toast.LENGTH_SHORT).show()
        }

        override fun onAdFailedToShowFullScreenContent() {
            Toast.makeText(this@MainActivityKT, "onAdFailedToShowFullScreenContent", Toast.LENGTH_SHORT).show()

        }

        override fun onAdShowedFullScreenContent() {
            Toast.makeText(this@MainActivityKT, "onAdShowedFullScreenContent", Toast.LENGTH_SHORT).show()

        }

        override fun onAdDismissedFullScreenContent() {
            RewardedInterstitialKT.instance?.loadAd(this@MainActivityKT,this)
        }
    })*/
    companion object {
        private const val TAG = "RewardedInterstitialKT"
        var instance: RewardedInterstitialKT? = null
            get() {
                if (field == null) {
                    synchronized(RewardedInterstitialKT::class.java) {
                        if (field == null) {
                            field = RewardedInterstitialKT()
                        }
                    }
                }
                return field
            }
            private set

    }

}