package com.text.art.fancy.creator.activitys

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.RecoverableSecurityException
import android.app.WallpaperManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.Resources.NotFoundException
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.AnyRes
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.text.art.fancy.creator.BuildConfig
import com.text.art.fancy.creator.model.creation.PhotoModelCreation
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.TextArtApplication
import com.text.art.fancy.creator.adepter.PageAdepter
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.dialog.DiscardDialogFragment
import com.text.art.fancy.creator.fragment.MyImagesFragment
import com.text.art.fancy.creator.fragment.MyVideosFragment
import com.text.art.fancy.creator.utils.*
import com.willy.ratingbar.ScaleRatingBar
import kotlinx.android.synthetic.main.activity_my_photo_full.*
import java.io.File
import java.io.IOException
import java.util.*

class FullMyPhotoActivity : AppCompatActivity(), View.OnClickListener {
    var backImage: ImageView? = null
    var setWallpaper: ImageView? = null
//    var delete_image: ImageView? = null
    var ivHome: ImageView? = null
    private lateinit var fullImage: ImageView
    var url: String? = null
    var mLastClickTime: Long = 0
    var heart = true
    lateinit var toolbar: LinearLayout
    private var mContext: Context? = null

    private var sharedPreferences: SharedPreferences? = null
    private var editor: SharedPreferences.Editor? = null

    /*var share_fb: ImageButton? = null
    var share_insta: ImageButton? = null
    var share_whatsapp: ImageButton? = null*/

    var share_more: ImageView? = null
    private var alertDialog: AlertDialog? = null
    private var viewPager: ViewPager2? = null
    private var pageAdepter: PageAdepter? = null
    private var mPathList: ArrayList<String>? = null
//    private var mList: ArrayList<PhotoModel>? = null
    private var mList: ArrayList<PhotoModelCreation>? = null
    private var type: String? = null
    private var from: String? = null

    lateinit var photoFullMainLayout:ConstraintLayout
    //    FrameLayout fl_adplaceholder;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_photo_full)

        photoFullMainLayout =findViewById(R.id.photoFullMainLayout)
        sharedPreferences = getSharedPreferences("data", Context.MODE_PRIVATE)

        photoFullMainLayout.invalidate()

        mContext = this
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this@FullMyPhotoActivity, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }

        //TODO fbAds
        /*adView = AdView(this, resources.getString(R.string.fb_banner2), AdSize.BANNER_HEIGHT_50)
        val adContainer = findViewById<View>(R.id.banner_container) as LinearLayout
        adContainer.addView(adView)
        adView!!.loadAd()
        adView!!.setAdListener(object : AdListener {
            override fun onError(ad: Ad, adError: AdError) {
                Log.d("123654", "onError: " + adError.errorMessage)
                BannerHelper.load(findViewById(R.id.ad_view))
            }

            override fun onAdLoaded(ad: Ad) {
                Log.d("123654", "onAdLoaded: ")
            }

            override fun onAdClicked(ad: Ad) {
                Log.d("123654", "onAdClicked: ")
            }

            override fun onLoggingImpression(ad: Ad) {
                Log.d("123654", "onLoggingImpression: ")
            }
        })*/

        initView()
        initListener()
        url = intent.getStringExtra("image")
        type = intent.getStringExtra("type")
        from = intent.getStringExtra("from")


        try {
            toolbar.setPadding(0, getStatusbarHeight(), 0, 0)
        } catch (e: Exception) {
        }

        hideSystemUI()

        if (type != "view"){
            if (!MySharedPref(this).getRateShown()) {
            var count = sharedPreferences!!.getInt("count", 0)
            if (count % 3 == 0) {
                count = 0
                try {
                    if (!isFinishing) {
                        runOnUiThread {
                            showRateDialog()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            editor = sharedPreferences!!.edit()
            editor!!.putInt("count", count + 1)
            editor!!.commit()

        }
        }

        Log.d(TAG, "onCreate: $type")
        if (type == "view") {
            findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
            mPathList = ArrayList()
//            delete_image!!.visibility = View.VISIBLE
            ivHome!!.visibility = View.VISIBLE
            //ivViewImage.setVisibility(View.GONE);
            fullImage.hide()
            //findViewById(R.id.cardView).setVisibility(View.GONE);
//            mList = intent.getSerializableExtra("list") as ArrayList<PhotoModel>
            if (from == "image"){
                mList = MyImagesFragment.mPhotoList
            }else if (from == "video"){
                mList = MyVideosFragment.mPhotoList
            }

            if (mList != null) {
                mList!!.forEach {
                    mPathList!!.add(it.path!!)
                }

                val scrollPosition = mPathList!!.indexOf(url!!)

                viewPager?.offscreenPageLimit = ViewPager2.OFFSCREEN_PAGE_LIMIT_DEFAULT
                pageAdepter =
                    PageAdepter(
                        mPathList,
                        this
                    )
                viewPager!!.adapter = pageAdepter

                Log.d(TAG, "viewPager onStart: viewPager 1 currentItem $scrollPosition")
//                viewPager!!.currentItem = scrollPosition
            }
        } else {
            findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.VISIBLE
            try {
                NativeAdvancedModelHelper(this@FullMyPhotoActivity).loadNativeAdvancedAd(NativeAdsSize.Medium,findViewById(R.id.fl_adplaceholder))
            } catch (e: Exception) { }
            ivHome!!.visibility = View.VISIBLE
            delete_image!!.visibility = View.INVISIBLE

            fullImage.show()

            viewPager!!.visibility = View.INVISIBLE
            Glide.with(this).load(url).into(fullImage)

        }
        viewPager!!.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
//                pageAdepter?.notifyDataSetChanged()
            }
            override fun onPageSelected(position: Int) {
                url = mPathList!![position]
            }

            override fun onPageScrollStateChanged(state: Int) {
//                pageAdepter?.notifyDataSetChanged()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        if (type == "view") {
            val temp = ArrayList<String>()
            for (s in mPathList!!) {
                val file = File(s)
                if (!file.exists()) {
                    temp.add(s)
                }
            }
            mPathList!!.removeAll(temp)
            if (mPathList!!.size == 0) {
                finish()
                return
            }

            pageAdepter = PageAdepter(
                mPathList,
                this
            )
            viewPager!!.adapter = pageAdepter
            var scrollPosition = mPathList!!.indexOf(url)
            if (mPathList!!.size > 0 && mPathList!!.size <= scrollPosition) {
                scrollPosition = mPathList!!.size - 1
            }
            Log.d(TAG, "viewPager onStart: viewPager 2 currentItem $scrollPosition")
//            viewPager!!.currentItem = scrollPosition
            viewPager!!.setCurrentItem(scrollPosition, false)
        }
    }

    private fun initListener() {
        backImage!!.setOnClickListener(this)

        delete_image!!.setOnClickListener(this)

        share_more!!.setOnClickListener(this)
        ivHome!!.setOnClickListener(this)
    }

    private fun initView() {
        toolbar = findViewById(R.id.toolbar1)
        fullImage = findViewById(R.id.full_image)
        backImage = findViewById<View>(R.id.back_image) as ImageView

//        delete_image = findViewById<View>(R.id.delete_image) as ImageView

        share_more = findViewById(R.id.share_more)
        ivHome = findViewById(R.id.imgBtnHome)
        viewPager = findViewById(R.id.viewPager)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 3232 && resultCode == Activity.RESULT_OK) {
            isDelete = true
            isDelete1 = true
            var position = mPathList!!.indexOf(url)
            val delete_path = url
            val ffile = File(delete_path)
            ffile.delete()
            if (1 <= mPathList!!.size) {
                Constants.isDeleteOperationPerform = true
                position -= 1
                if (pageAdepter != null) {
                    mPathList!!.remove(url)
                    pageAdepter =
                        PageAdepter(
                            mPathList,
                            this@FullMyPhotoActivity
                        )

                    viewPager!!.adapter = pageAdepter
                    Log.d(TAG, "onClick: " + mPathList!!.size)
                    Log.d(TAG, "viewPager onStart: viewPager 3 currentItem $position")
                    viewPager!!.currentItem = position
                    if (mPathList!!.size == 0) {
                        finish()
                    } else {
                        url = mPathList!![viewPager!!.currentItem]
                    }
                }
            }
        }
    }

    private fun loadOpenAds() {

    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onClick(v: View) {
        when (v.id) {
            R.id.back_image -> onBackPressed()
            R.id.imgBtnHome -> {
                val it = Intent(this@FullMyPhotoActivity, HomeActivity::class.java)
//                it.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(it)
                finish()
            }
            R.id.share_more -> {
                if (SystemClock.elapsedRealtime() - mLastClickTime < 2000) {
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime()
                try {
                    val uri = FileProvider.getUriForFile(this@FullMyPhotoActivity, "${BuildConfig.APPLICATION_ID}.provider", File(url))
//                    val uri = Uri.parse(url.toString())
                    Log.d(TAG, "onClick: uri $uri")
                    if (uri != null) {
                        if (type == "photo" || type == "view"){
                            Log.d(TAG, "onClick: uri image = $uri")
                            Log.d(TAG, "onClick: uri contentUri = $uri")

    //                        val intent = Intent(Intent.ACTION_SEND)
    //                        intent.type = "image/*"
    //                        intent.putExtra(Intent.EXTRA_STREAM, uri)
    //                        intent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
    //                        intent.putExtra(Intent.EXTRA_SUBJECT, "Text Art")
    ////                        startActivityForResult(Intent.createChooser(intent, "Share Image"), 1111)
    //                        startActivity(intent)

                            val sendIntent: Intent = Intent().apply {
                                action = Intent.ACTION_SEND
                                type = "image/*"
                                putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
                                putExtra(Intent.EXTRA_STREAM, uri)
                                putExtra(Intent.EXTRA_SUBJECT, "Text Art")
                            }
                            val shareIntent = Intent.createChooser(sendIntent, null)
                            startActivity(shareIntent)

                        }else{
                             try {
                                 Log.d(TAG, "onClick: uri video = $uri")
                                 startActivity(Intent.createChooser(
                                     Intent().setAction(Intent.ACTION_SEND)
                                         .setType("video/*")
                                         .setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                         .putExtra(Intent.EXTRA_STREAM,
                                             Uri.parse(uri.toString())), "Share File Using!"))
                             }catch (e: Exception){}
                        }
                    }
                } catch (e: Exception) { }
            }
            R.id.delete_image -> {
                val uris = arrayListOf<Uri>()
                Log.d(TAG, "onClick: DeletedURI : $url")
                val dialogSave = DiscardDialogFragment(
                        "Delete",
                        resources.getString(R.string.deleteSentence),
                        R.drawable.ic_dialog_delete,
                        "Cancel",
                        "Delete"
                )
                { s, discardDialogFragment ->
                    if (s == "ok") {
                        supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                        discardDialogFragment.dismiss()
                        isDelete = true
                        isDelete1 = true
                        var position = mPathList!!.indexOf(url)
                        val delete_path = url
                        val ffile = File(delete_path)
                        val isDelete = ffile.delete()
                        if (isDelete && 1 <= mPathList!!.size) {
                            Constants.isDeleteOperationPerform = true
                            position -= 1
                            if (pageAdepter != null) {
                                mPathList!!.remove(url)

                                pageAdepter =
                                    PageAdepter(
                                        mPathList,
                                        this@FullMyPhotoActivity
                                    )

                                viewPager!!.adapter = pageAdepter
                                Log.d(TAG, "onClick: " + mPathList!!.size)
                                Log.d(TAG, "viewPager onStart: viewPager 4 currentItem $position")
                                viewPager!!.currentItem = position
                                if (mPathList!!.size == 0) {
                                    finish()
                                } else {
                                    url = mPathList!![viewPager!!.currentItem]
                                }
                            }
                        } else {
                            if (!isDelete) {
                                try {
                                    val projection = arrayOf<String>(MediaStore.Images.Media._ID)
                                    val selection: String = MediaStore.Images.Media.DATA.toString() + " = ?"
                                    val selectionArgs = arrayOf<String>(ffile.getAbsolutePath())
                                    val queryUri: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                                    val contentResolver = contentResolver
                                    val c: Cursor? = contentResolver.query(queryUri, projection, selection, selectionArgs, null)
                                    if (c != null) {
                                        if (c.moveToFirst()) {
                                            // We found the ID. Deleting the item via the content provider will also remove the file
                                            val id: Long = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                                            val deleteUri: Uri = ContentUris.withAppendedId(queryUri, id)
                                            try {
                                                uris.add(deleteUri)
                                                Log.d(TAG, "onPositive: ")
                                            } catch (securityException: SecurityException) {
                                                securityException.printStackTrace()
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                    val recoverableSecurityException =
                                                            securityException as? RecoverableSecurityException
                                                                    ?: throw securityException
                                                } else {
                                                    throw securityException
                                                }
                                            }
                                            Constants.isDeleteOperationPerform = true
                                        } else {
                                            // File not found in media store DB
                                        }
                                        c.close()
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }

                            }
                        }
                        if (uris.isNotEmpty())
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                deleteImages(uris)
                            }
                    } else {
                        supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                        discardDialogFragment.dismiss()
                    }
                }
                dialogSave.isCancelable = false
                dialogSave.show(supportFragmentManager, "dialog")
            }
        }
    }
    
    @RequiresApi(Build.VERSION_CODES.R)
    private fun deleteImages(uris: List<Uri>) {
        val pendingIntent = MediaStore.createDeleteRequest(contentResolver, uris.filter {
            checkUriPermission(it, Binder.getCallingPid(), Binder.getCallingUid(), Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != PackageManager.PERMISSION_GRANTED
        })
        startIntentSenderForResult(pendingIntent.intentSender, 3232, null, 0, 0, 0, null)
    }

    @SuppressLint("Range")
    fun getVideoContentUri(videoFile: File): Uri? {
        var uri: Uri? = null
        val filePath = videoFile.absolutePath
        val cursor = this@FullMyPhotoActivity.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Video.Media._ID),
            MediaStore.Video.Media.DATA + "=? ",
            arrayOf(filePath), null)

        if (cursor != null && cursor.moveToFirst()) {
            val id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID))
            val baseUri = Uri.parse("content://media/external/video/media")
            uri = Uri.withAppendedPath(baseUri, "" + id)
        } else if (videoFile.exists()) {
            val values = ContentValues()
            values.put(MediaStore.Video.Media.DATA, filePath)
            uri = this@FullMyPhotoActivity.contentResolver.insert(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        }
        cursor!!.close()
        return uri
    }

    private fun buildDialog(title: String, yes: View.OnClickListener, no: View.OnClickListener) {
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        //then we will inflate the custom alert dialog xml that we created
        val dialogView = LayoutInflater.from(this).inflate(R.layout.layout_save_dialog, viewGroup, false)
        //Now we need an AlertDialog.Builder object
        val builder = AlertDialog.Builder(this)
        val txtTitle = dialogView.findViewById<TextView>(R.id.txtTitle)
        val txtYes = dialogView.findViewById<TextView>(R.id.txtYes)
        val txtNo = dialogView.findViewById<TextView>(R.id.txtNo)
        txtTitle.text = title
        if (title == "Do you want to remove all changes?") {
            txtTitle.textSize = 18f
        }
        // NativeAdvanceHelperfb.loadAd(this, adsContainer);
        txtYes.setOnClickListener(yes)
        txtNo.setOnClickListener(no)
        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView)
        //finally creating the alert dialog and displaying it
        alertDialog = builder.create()
        alertDialog!!.window!!.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun shareOnWhatsapp() {
        try {
            var intent = packageManager.getLaunchIntentForPackage("com.whatsapp")
            if (intent != null) {
                val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", File(url))
                val sendIntent = Intent(Intent.ACTION_VIEW)
                sendIntent.type = "image/*"
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
                sendIntent.setPackage("com.whatsapp")
                sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
                sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(sendIntent)
            } else { // bring user to the market to download the app.
                // or let them choose an app?
                /*intent = Intent(Intent.ACTION_VIEW)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.data = Uri.parse("market://details?id=" + "com.whatsapp")
                startActivity(intent)*/
                Toast.makeText(mContext, "Whatsapp have not been install.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun shareInstagram() {
        try {
            var intent = packageManager.getLaunchIntentForPackage("com.instagram.android")
            if (intent != null) {
                val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", File(url))
                val sendIntent = Intent(Intent.ACTION_VIEW)
                sendIntent.type = "image/*"
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
                sendIntent.setPackage("com.instagram.android")
                sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
                sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(sendIntent)
            } else { // bring user to the market to download the app.
                // or let them choose an app?
                /*intent = Intent(Intent.ACTION_VIEW)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.data = Uri.parse("https://play.google.com/store/apps/details?id=com.instagram.android&hl=en")
                startActivity(intent)*/
                Toast.makeText(mContext, "Instagram have not been install.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun shareFacebook() {
        try {
            var intent = packageManager.getLaunchIntentForPackage("com.facebook.katana")
            if (intent != null) {
                val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", File(url))
                val sendIntent = Intent(Intent.ACTION_VIEW)
                sendIntent.type = "image/*"
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(Intent.EXTRA_STREAM, imageUri)
                sendIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=$packageName")
                sendIntent.setPackage("com.facebook.katana")
                sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(sendIntent)
            } else { // bring user to the market to download the app.
// or let them choose an app?
                /* intent = Intent(Intent.ACTION_VIEW)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.data = Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana&hl=en")
            startActivity(intent)*/
                Toast.makeText(mContext, "Facebook have not been install.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("MissingPermission")
    private fun setWallpaper() {
        val view: View? = fullImage
        val returnedBitmap = Bitmap.createBitmap(fullImage!!.width, fullImage!!.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(returnedBitmap)
        view!!.layoutParams.height = fullImage!!.height
        view.layoutParams.width = fullImage!!.width
        val bgDrawable = view.background
        if (bgDrawable != null) bgDrawable.draw(canvas) else canvas.drawColor(Color.TRANSPARENT)
        view.draw(canvas)
        val wallpaperManager = WallpaperManager.getInstance(applicationContext)
        try {
            wallpaperManager.setBitmap(returnedBitmap)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Toast.makeText(this, "Wallpaper is set Successfully!", Toast.LENGTH_SHORT).show()
    }

    private fun myPhotoClassAD() { /*if (MyApplication.getInstance().requestNewInterstitial()) {
            MyApplication.getInstance().mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    loadInterstialAd();
                    startActivity(new Intent(FullMyPhotoActivity.this, MyPhotoActivity.class));
                }

                @Override
                public void onAdFailedToLoad(int i) {
                    super.onAdFailedToLoad(i);
                    startActivity(new Intent(FullMyPhotoActivity.this, MyPhotoActivity.class));
                }

                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                }
            });

        } else {*/
//startActivity(new Intent(FullMyPhotoActivity.this, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        /*if (intent.hasExtra("isCreation")) {
            startActivity(Intent(this@FullMyPhotoActivity, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
        } else {*/
        finish()
        //}
        // }
    }

    private fun loadInterstialAd() { /*if (MyApplication.getInstance().mInterstitialAd.isLoaded()) {

        } else {
            MyApplication.getInstance().mInterstitialAd.setAdListener(null);
            MyApplication.getInstance().mInterstitialAd = null;
            MyApplication.getInstance().ins_adRequest = null;
            MyApplication.getInstance().LoadAds();
            MyApplication.getInstance().mInterstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                }

                @Override
                public void onAdFailedToLoad(int i) {
                    super.onAdFailedToLoad(i);
                    loadInterstialAd();
                }
            });
        }*/
    }

    override fun onBackPressed() {

        isShowInterstitialAd() {

            val backIntent = Intent()
            setResult(2052, backIntent)
            super.onBackPressed()
            //myPhotoClassAD()
        }
    }

    override fun onDestroy() {

        super.onDestroy()
    }

    private fun isNetworkConnected(): Boolean {
        var cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        return cm.getActiveNetworkInfo() != null && cm!!.getActiveNetworkInfo()!!.isConnected()
    }

    public override fun onResume() {
        super.onResume()
        //BannerHelper.onResume()

        /*val saveCount = MySharedPreferences(this).count

        if (saveCount >= 2 && MySharedPreferences(this).visit == null) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (!this.isFinishing && type!=null) {
                    if (type!="view"){
                        if (!Constants.isOpenRateDialog){

                            Constants.isOpenRateDialog = true
                        }else{
                            Constants.isOpenRateDialog = false
                        }
                    }
                }
            }, 2000)
        } else {
            MySharedPreferences(this).count = saveCount + 1
        }*/

        if (!MySharedPreferences(this).isSubscribe){
            if (isNetworkConnected()){
                if (Constants.showAdInSharePage!!){
                    findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.VISIBLE
                }else{
                    findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
                }
                try {
                    NativeAdvancedModelHelper(this@FullMyPhotoActivity).loadNativeAdvancedAd(NativeAdsSize.Big,findViewById(R.id.fl_adplaceholder))
                } catch (e: Exception) { }
            }else{
                findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
            }
        }else{
            findViewById<FrameLayout>(R.id.fl_adplaceholder).visibility = View.GONE
        }

    }

    override fun onPause() {
        super.onPause()
        if (alertDialog != null && alertDialog!!.isShowing){
            alertDialog!!.dismiss()
        }
    }

    private fun rateApp() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
        }catch (e: Exception){}
    }

    private fun showRateDialog() {
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_rate_app_new, viewGroup, false)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        alertDialog = builder.create()
        alertDialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        alertDialog!!.setOnCancelListener { alertDialog!!.dismiss() }

        dialogView.findViewById<ImageView>(R.id.btnClose).setOnClickListener { alertDialog!!.dismiss() }
        dialogView.findViewById<ScaleRatingBar>(R.id.ratingBar).setOnRatingChangeListener { _, rating, _ ->
            MySharedPref(this).setRateShown("rateClickOrNot", true)
            if (rating > 3) {
                Handler(Looper.getMainLooper()).postDelayed({
                    rateApp()
                    alertDialog!!.dismiss()
                }, 500)
            } else {
                Toast.makeText(this, "Thanks for giving rating.", Toast.LENGTH_SHORT).show()
                Handler(Looper.getMainLooper()).postDelayed({ alertDialog!!.dismiss() }, 500)
            }
        }
        dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener { alertDialog!!.dismiss() }
        if (!this.isFinishing) {
            alertDialog!!.show()
        }
    }

    companion object {
        private const val TAG = "FullMyPhotoActivity"

        var isDelete = false
        var isDelete1 = false


        @Throws(NotFoundException::class)
        fun getUriToResource(context: Context,
                             @AnyRes resId: Int): Uri {
            /** Return a Resources instance for your application's package.  */
            val res = context.resources
            /** return uri  */
            return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                    "://" + res.getResourcePackageName(resId)
                    + '/' + res.getResourceTypeName(resId)
                    + '/' + res.getResourceEntryName(resId))
        }
    }

}