package com.text.art.fancy.creator.ads

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.facebook.ads.*
import com.text.art.fancy.creator.R

object FacebookNativeAdvancehelper {


    private val TAG = "FB_ADS_123"

    private var nativeAd: NativeAd? = null


    fun loadNativeSmall(
            context: Context,
            nativeAdLayout: NativeAdLayout,
            id: String?,
            listener: () -> Unit
    ) {
        try {

            nativeAd = NativeAd(context, id)
            AdSettings.addTestDevice("ad901e97-f75f-4e97-8381-f6139372235c")
            /*nativeAd!!.setAdListener(object : NativeAdListener {
                override fun onMediaDownloaded(ad: Ad) { // Native ad finished downloading all assets
                    Log.e(TAG, "Native ad finished downloading all assets.")
                }

                override fun onError(ad: Ad, adError: AdError) { // Native ad failed to load
                    Log.e(TAG, "Native ad failed to load: " + adError.errorMessage)
                    listener()
                }

                override fun onAdLoaded(ad: Ad) { // Native ad is loaded and ready to be displayed
                    Log.d(TAG, "Native ad is loaded and ready to be displayed!")
                    // Race condition, load() called again before last ad was displayed
                    if (nativeAd == null || nativeAd !== ad) {
                        return
                    }
                    // Inflate Native Ad into Container
                    inflateAd(context, nativeAd!!, nativeAdLayout)
                }

                override fun onAdClicked(ad: Ad) { // Native ad clicked
                    Log.d(TAG, "Native ad clicked!")
                }

                override fun onLoggingImpression(ad: Ad) { // Native ad impression
                    Log.d(TAG, "Native ad impression logged!")
                }
            })*/

            val nativeAdListener =  object : NativeAdListener {
                override fun onAdClicked(p0: Ad?) {
                    Log.d(TAG, "Native ad clicked!")
                }

                override fun onMediaDownloaded(p0: Ad?) {
                    Log.e(TAG, "Native ad finished downloading all assets.")
                }

                override fun onError(p0: Ad?, adError: AdError?) {
                    Log.e(TAG, "Native ad failed to load: " + adError?.errorMessage)
                    listener()
                }

                override fun onAdLoaded(ad: Ad?) {
                    Log.d(TAG, "Native ad is loaded and ready to be displayed!")
                    // Race condition, load() called again before last ad was displayed
                    if (nativeAd == null || nativeAd !== ad) {
                        return
                    }
                    // Inflate Native Ad into Container
                    inflateAd(context, nativeAd!!, nativeAdLayout)
                }

                override fun onLoggingImpression(p0: Ad?) {
                    Log.d(TAG, "Native ad impression logged!")
                }
            }

            // Request an ad
            nativeAd!!.loadAd(nativeAd!!.buildLoadAdConfig().withAdListener(nativeAdListener).build())
            //nativeAd!!.loadAd()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadNative(
            context: Context,
            nativeAdLayout: NativeAdLayout,
            id: String,
            listener: (Int) -> Unit
    ) {
        try {
            nativeAd = NativeAd(context, id)
            AdSettings.addTestDevice("ad901e97-f75f-4e97-8381-f6139372235c")
            /*nativeAd?.setAdListener(
                    object : NativeAdListener {
                        override fun onMediaDownloaded(ad: Ad) { // Native ad finished downloading all assets
                            Log.e(
                                    TAG,
                                    "Native ad finished downloading all assets."
                            )
                        }

                        override fun onError(
                                ad: Ad,
                                adError: AdError
                        ) { // Native ad failed to load
                            Log.e(
                                    TAG,
                                    "Native ad failed to load: " + adError.errorMessage
                            )
                            listener(1)
                        }

                        override fun onAdLoaded(ad: Ad) { // Native ad is loaded and ready to be displayed
                            Log.d(
                                    TAG,
                                    "Native ad is loaded and ready to be displayed!"
                            )
                            // Race condition, load() called again before last ad was displayed
                            if (nativeAd == null || nativeAd != ad) {
                                return
                            }

                            if (nativeAdLayout == null) {
                                return
                            }

                            listener(0)

                            // Inflate Native Ad into Container
                            try {
                                context?.let {
                                    inflateAd(
                                            context,
                                            nativeAd!!,
                                            nativeAdLayout,
                                            LayoutInflater.from(context).inflate(
                                                    R.layout.fackbook_native_normal,
                                                    nativeAdLayout,
                                                    false
                                            ) as LinearLayout
                                    )
                                }

                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }

                        override fun onAdClicked(ad: Ad) { // Native ad clicked
                            Log.d(
                                    TAG,
                                    "Native ad clicked!"
                            )
                        }

                        override fun onLoggingImpression(ad: Ad) { // Native ad impression
                            Log.d(
                                    TAG,
                                    "Native ad impression logged!"
                            )
                        }
                    })*/

            val nativeAdListener =  object : NativeAdListener {
                override fun onAdClicked(p0: Ad?) {
                    Log.d(TAG, "Native ad clicked!")
                }

                override fun onMediaDownloaded(p0: Ad?) {
                    Log.e(TAG, "Native ad finished downloading all assets.")
                }

                override fun onError(p0: Ad?, adError: AdError?) {
                    Log.e(TAG, "Native ad failed to load: " + adError?.errorMessage)
                    listener(1)
                }

                override fun onAdLoaded(ad: Ad?) {
                    Log.d(TAG,"Native ad is loaded and ready to be displayed!")
                    // Race condition, load() called again before last ad was displayed
                    if (nativeAd == null || nativeAd != ad) {
                        return
                    }

                    if (nativeAdLayout == null) {
                        return
                    }

                    listener(0)

                    // Inflate Native Ad into Container
                    try {
                        context?.let {
                            inflateAd(
                                    context,
                                    nativeAd!!,
                                    nativeAdLayout,
                                    LayoutInflater.from(context).inflate(
                                            R.layout.fackbook_native_normal,
                                            nativeAdLayout,
                                            false
                                    ) as LinearLayout
                            )
                        }

                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                override fun onLoggingImpression(p0: Ad?) {
                    Log.d(TAG, "Native ad impression logged!")
                }
            }

            // Request an ad
            nativeAd!!.loadAd(nativeAd!!.buildLoadAdConfig().withAdListener(nativeAdListener).build())
            //nativeAd?.loadAd()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun inflateAd(
            context: Context,
            nativeAd: NativeAd,
            nativeAdLayout: NativeAdLayout,
            layout: LinearLayout
    ) {
        try {
            nativeAd.unregisterView()
            // Add the Ad view into the ad container.
            val inflater = LayoutInflater.from(context)
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            nativeAdLayout.addView(layout)
            // Add the AdOptionsView
            val adChoicesContainer =
                    layout.findViewById<LinearLayout>(R.id.ad_choices_container)
            val adOptionsView = AdOptionsView(context, nativeAd, nativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            // Create native UI using the ad metadata.
            val nativeAdIcon: MediaView = layout.findViewById(R.id.native_ad_icon)
            val nativeAdTitle =
                    layout.findViewById<TextView>(R.id.native_ad_title)
            val nativeAdMedia: MediaView = layout.findViewById(R.id.native_ad_media)
            val nativeAdSocialContext =
                    layout.findViewById<TextView>(R.id.native_ad_social_context)
            val nativeAdBody =
                    layout.findViewById<TextView>(R.id.native_ad_body)
            val sponsoredLabel =
                    layout.findViewById<TextView>(R.id.native_ad_sponsored_label)
            val nativeAdCallToAction =
                    layout.findViewById<Button>(R.id.native_ad_call_to_action)
            // Set the Text.
            nativeAdTitle.text = nativeAd.advertiserName
            nativeAdBody.text = nativeAd.adBodyText
            nativeAdSocialContext.text = nativeAd.adSocialContext
            nativeAdCallToAction.visibility =
                    if (nativeAd.hasCallToAction()) View.VISIBLE else View.INVISIBLE
            nativeAdCallToAction.text = nativeAd.adCallToAction
            sponsoredLabel.text = nativeAd.sponsoredTranslation
            // Create a list of clickable views
            val clickableViews: MutableList<View> =
                    ArrayList()
            clickableViews.add(nativeAdTitle)
            clickableViews.add(nativeAdCallToAction)
            // Register the Title and CTA button to listen for clicks.
            nativeAd.registerViewForInteraction(
                    layout,
                    nativeAdMedia,
                    nativeAdIcon,
                    clickableViews
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun inflateAd(
            context: Context,
            nativeAd: NativeAd,
            nativeAdLayout: NativeAdLayout
    ) {
        try {
            nativeAd.unregisterView()
            // Add the Ad view into the ad container.
            val inflater = LayoutInflater.from(context)
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            val adView = inflater.inflate(
                    R.layout.native_fb_ad_small,
                    nativeAdLayout,
                    false
            ) as LinearLayout
            nativeAdLayout.addView(adView)
            // Add the AdOptionsView
            val adChoicesContainer =
                    adView.findViewById<LinearLayout>(
                            R.id.ad_choices_container
                    )
            val adOptionsView = AdOptionsView(context, nativeAd, nativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            // Create native UI using the ad metadata.
            val nativeAdIcon: MediaView = adView.findViewById(R.id.native_ad_icon)
            val nativeAdTitle = adView.findViewById<TextView>(
                    R.id.native_ad_title
            )
            val nativeAdMedia: MediaView = adView.findViewById(R.id.native_ad_media)
            val nativeAdSocialContext =
                    adView.findViewById<TextView>(
                            R.id.native_ad_social_context
                    )
            val nativeAdBody = adView.findViewById<TextView>(
                    R.id.native_ad_body
            )
            val sponsoredLabel = adView.findViewById<TextView>(
                    R.id.native_ad_sponsored_label
            )
            val nativeAdCallToAction =
                    adView.findViewById<Button>(
                            R.id.native_ad_call_to_action
                    )
            // Set the Text.
            nativeAdTitle.text = nativeAd.advertiserName
            nativeAdBody.text = nativeAd.adBodyText
            nativeAdSocialContext.text = nativeAd.adSocialContext
            nativeAdCallToAction.visibility =
                    if (nativeAd.hasCallToAction()) View.VISIBLE else View.INVISIBLE
            nativeAdCallToAction.text = nativeAd.adCallToAction
            sponsoredLabel.text = nativeAd.sponsoredTranslation
            // Create a list of clickable views
            val clickableViews: MutableList<View> =
                    ArrayList()
            clickableViews.add(nativeAdTitle)
            clickableViews.add(nativeAdCallToAction)
            // Register the Title and CTA button to listen for clicks.
            nativeAd.registerViewForInteraction(
                    adView,
                    nativeAdMedia,
                    nativeAdIcon,
                    clickableViews
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun onDestroy() {
        if (nativeAd != null) {
            nativeAd!!.destroy()
        }
    }

}