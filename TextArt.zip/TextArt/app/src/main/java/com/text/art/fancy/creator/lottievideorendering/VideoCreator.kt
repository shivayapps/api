package com.text.art.fancy.creator.lottievideorendering

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.View
import androidx.core.content.FileProvider
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.text.art.fancy.creator.R

import com.text.art.fancy.creator.utils.getTargetFileDirectory
import kotlinx.coroutines.*
import java.io.File

class VideoCreator {
    private val TAG = "VideoCreator"
    private lateinit var recordingOperation: RecordingOperation
    private var lottieDrawable: LottieDrawable? = null
    private var VIDEO_WIDHT: Float? = null
    private var VIDEO_HEIGHT: Float? = null
    private var context: Context
    private lateinit var outputFile: File
    private var lottieAnimationView: LottieAnimationView
    var tStart = 0

    companion object{
        var progressDialog: ProgressDialog? = null
    }

    constructor(
        lottieDrawable: LottieDrawable?,
        VIDEO_WIDHT: Float?,
        VIDEO_HEIGHT: Float?,
        mContext: Context,
        lottieAnimationView: LottieAnimationView
    ) {
        this.lottieDrawable = lottieDrawable
        this.VIDEO_WIDHT = VIDEO_WIDHT
        this.VIDEO_HEIGHT = VIDEO_HEIGHT
        this.context = mContext
        this.lottieAnimationView = lottieAnimationView
        setProgressDialog()
        Log.d(TAG, "VIDEO_WIDHT: $VIDEO_WIDHT and VIDEO_HEIGHT : $VIDEO_HEIGHT")
    }

    private fun setProgressDialog() {
        progressDialog = ProgressDialog(context, R.style.ProgressDialogStyle).apply {
            setMessage("Please wait while we making video")
            setProgressStyle(ProgressDialog.STYLE_HORIZONTAL)
            setProgressPercentFormat(null)
            setCancelable(false)
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    fun createVideo(containsAudio: Boolean = false, listener: (File) -> Unit) {
        outputFile = if (containsAudio){
            makeFileWithAudio()
        }else{
            makeFile()
        }

        recordingOperation = RecordingOperation(Recorder(
            videoOutput = outputFile,
            width = VIDEO_WIDHT!!.toInt(),
            height = VIDEO_HEIGHT!!.toInt()
        ), FrameCreator(
            lottieDrawable = lottieDrawable!!,
            VIDEO_WIDTH_PX = VIDEO_WIDHT!!,
            VIDEO_HEIGHT_PX = VIDEO_HEIGHT!!,
            lottieAnimationView = lottieAnimationView
        ), object : ProgressListener {
            override fun getProgress(int: Int) {
                progressDialog?.let {
                    it.progress = if (containsAudio){
                        (int/2)
                    }else{
                        int
                    }
                }
            }
        }) {
            if (!containsAudio)
                progressDialog!!.dismiss()
            val tEnd = SystemClock.elapsedRealtime() - tStart
            val elapsedSeconds = tEnd / 1000.0
            Log.d(TAG, "TIME TAKEN - : $elapsedSeconds")
            GlobalScope.launch {
                withContext(Dispatchers.Main){
                    listener(outputFile)
                    lottieAnimationView.visibility = View.VISIBLE
                    lottieAnimationView.playAnimation()
                }
            }
        }

        progressDialog?.show()
        tStart = SystemClock.elapsedRealtime().toInt()
        lottieAnimationView.pauseAnimation()
        lottieAnimationView.visibility = View.GONE

        GlobalScope.launch {
            withContext(Dispatchers.IO){
                kotlin.run {
                    recordingOperation.start()
                }
            }
        }

    }

    private fun makeFile(): File {
        return File(getTargetFileDirectory(), "TextArt_${System.currentTimeMillis()}.mp4")
    }

    private fun makeFileWithAudio(): File {
        File("${context.cacheDir}${File.separator}Videos").apply {
            if (!this.exists())
                this.mkdirs()
            return File(this, "WithoutAudio_${System.currentTimeMillis()}.mp4")
        }
    }

    fun play(targetFile: File?) {
        if (targetFile != null && targetFile.exists()) {
            val playIntent = Intent(Intent.ACTION_VIEW)
            val videoUri = FileProvider.getUriForFile(
                context,
                context.packageName + ".provider",
                targetFile
            )
            playIntent.setDataAndType(videoUri, "video/*")
            playIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(playIntent)
        }
    }

}
