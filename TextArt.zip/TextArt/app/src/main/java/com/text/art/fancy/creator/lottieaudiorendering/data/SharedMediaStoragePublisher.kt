package com.text.art.fancy.creator.lottieaudiorendering.data

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import androidx.annotation.ChecksSdkIntAtLeast
import androidx.annotation.WorkerThread
import androidx.core.content.FileProvider
import com.text.art.fancy.creator.BuildConfig
import com.text.art.fancy.creator.utils.getTargetFileDirectory
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class SharedMediaStoragePublisher @JvmOverloads constructor(
    private val context: Context,
    private val executor: ExecutorService = Executors.newSingleThreadExecutor(),
    private val handler: Handler = Handler(Looper.getMainLooper())
) {

    private val resolver: ContentResolver
        get() = context.contentResolver

//    fun publish(file: File, keepOriginal: Boolean, listener: MediaPublishedListener) {
//        Log.d(TAG, "publish Video To Internal Storage: filePath Is -> $file")
//        executor.execute {
//            val contentUri = storeVideoInternal(file, keepOriginal)
//            handler.post {
//                Log.d(TAG, "publish: contentUri is $contentUri")
//                if (contentUri != null){
//                    listener.onPublished(file, contentUri)
//                }
////                else{
////                    listener.onPublished(file, Uri.fromFile(file))
////                }
//            }
//        }
//    }

    fun publish(file: File, keepOriginal: Boolean,listener: MediaPublishedListener) {
        Log.d(TAG, "publish Video To Internal Storage: filePath Is -> $file")
        executor.execute {
            val contentUri = storeVideoInternal(file, keepOriginal)
            handler.post {
                Log.d(TAG, "publish: contentUri is $contentUri")
                if (contentUri != null){
                    listener.onPublished(file, contentUri)
                }
            }
        }
    }

    @WorkerThread
    private fun storeVideoInternal(file: File, keepOriginal: Boolean): Uri? {
        Log.d(TAG, "storeVideoInternal: Video Process 1")
        if (!file.exists()) return null
        Log.d(TAG, "storeVideoInternal: Video Process 2")

        val newFileName = file.name

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.MIME_TYPE, MIME_TYPE_MPEG_4)
            put(MediaStore.Video.Media.TITLE, newFileName)
            put(MediaStore.Video.Media.DISPLAY_NAME, newFileName)
            put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis())
            if (isAndroidQ) {
                put(MediaStore.Video.Media.RELATIVE_PATH, relativePathMovies)
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val collectionUrl = if (isAndroidQ) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        var contentUri: Uri? = null

        runCatching {
            resolver.insert(collectionUrl, values)?.also { insertedUri ->
                contentUri = insertedUri
                resolver.openOutputStream(insertedUri)?.use { output ->
                    FileInputStream(file).use { input ->
                        input.copyTo(output)
                    }
                } ?: throw IOException("Failed to copy video to output stream")
            } ?: throw IOException("Failed to insert video to MediaStore")

        }.onFailure {
            Log.e(TAG, "Error copying file to MediaStore", it)
            contentUri?.let { copyFailedUri ->
                resolver.delete(copyFailedUri, null, null)
            }
        }

        if (!keepOriginal) {
            runCatching { file.delete() }.onFailure {
                Log.e(TAG, "Unable to delete original video file $file from system", it)
            }
        }

        if (isAndroidQ) {
            contentUri?.let {
                // Since we're done writing to the Uri, this tells MediaStore that other apps can use the content now.
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                runCatching {
                    resolver.update(it, values, null, null)
                }.onFailure {
                    Log.e(TAG, "Could not update MediaStore for $file", it)
                }
            }
        }

        Log.d(TAG, "storeVideoInternal: $contentUri")

        return contentUri
//        return contentUri ?: getUriForPreQ(newFileName)
    }

    private fun getUriForPreQ(fileName: String): Uri {
        val dir = getTargetFileDirectory()
        val photoFile = File(dir, fileName)
        if (photoFile.parentFile?.exists() == false) photoFile.parentFile?.mkdir()
        return FileProvider.getUriForFile(
            context,
            "${BuildConfig.APPLICATION_ID}.provider",
            photoFile
        )
    }

    interface MediaPublishedListener {
        fun onPublished(file: File, contentUri: Uri?)
    }

    companion object {
        private val TAG = SharedMediaStoragePublisher::class.qualifiedName
        private const val MIME_TYPE_MPEG_4 = "video/mp4"

        val isAndroidQ
            @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.Q)
            get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

//        private val picturesDirectory = Environment.DIRECTORY_PICTURES
        private val picturesDirectory = Environment.DIRECTORY_MOVIES
//        private val directory = "TextArt_Videos"
        private val directory = "TextArt"
        private val relativePathMovies = "${picturesDirectory}/${directory}"

    }
}