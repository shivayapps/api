package com.text.art.fancy.creator.entity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.util.Log;

import com.text.art.fancy.creator.model.Layer;
import com.text.art.fancy.creator.R;
import com.text.art.fancy.creator.utils.MathUtils;

public abstract class MotionEntity {

    private static final String TAG = "MotionEntity";

    private Context context;

    /**
     * data
     */
    @NonNull
    protected final Layer layer;

    /**
     * transformation matrix for the entity
     */
    protected final Matrix matrix = new Matrix();
    protected final Matrix matrix1 = new Matrix();
    /**
     * true - entity is selected and need to draw it's border
     * false - not selected, no need to draw it's border
     */
    private boolean isSelected;

    /**
     * maximum scale of the initial image, so that
     * the entity still fits within the parent canvas
     */
    protected float holyScale;

    /**
     * width of canvas the entity is drawn in
     */
    @IntRange(from = 0)
    protected int canvasWidth;
    /**
     * height of canvas the entity is drawn in
     */
    @IntRange(from = 0)
    protected int canvasHeight;

    /**
     * Destination points of the entity
     * 5 points. Size of array - 10; Starting upper left corner, clockwise
     * last point is the same as first to close the circle
     * NOTE: saved as a field variable in order to avoid creating array in draw()-like methods
     */
    private final float[] destPoints = new float[10]; // x0, y0, x1, y1, x2, y2, x3, y3, x0, y0
    /**
     * Initial points of the entity
     *
     * @see #destPoints
     */
    protected final float[] srcPoints = new float[10];  // x0, y0, x1, y1, x2, y2, x3, y3, x0, y0

    @NonNull
    private Paint borderPaint = new Paint();
    private Paint deleteIconPaint = new Paint();
    private Paint drawLine = new Paint();

    public float mStartX = 0, mStartY = 0, mRadius = 0, top, bottom, left, right, centerX, centerY;

    private Bitmap mBGBitmap, oBitmap;

    private float rotate;

    public MotionEntity(@NonNull Layer layer,
                        @IntRange(from = 1) int canvasWidth,
                        @IntRange(from = 1) int canvasHeight, Context context) {
        this.layer = layer;
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        this.context = context;
        drawLine.setAntiAlias(true);
        drawLine.setColor(Color.BLACK);
        drawLine.setStrokeWidth(5);
        drawLine.setStyle(Paint.Style.FILL);
        drawLine.setStrokeJoin(Paint.Join.ROUND);
        drawLine.setStrokeCap(Paint.Cap.ROUND);

//        oBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.tile1);

        //mBGBitmap = getResizedBitmap(oBitmap.copy(oBitmap.getConfig(),true),50,50);

    }

    private boolean isSelected() {
        return isSelected;
    }

    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    /**
     * S - scale matrix, R - rotate matrix, T - translate matrix,
     * L - result transformation matrix
     * <p>
     * The correct order of applying transformations is : L = S * R * T
     * <p>
     * See more info: <a href="http://gamedev.stackexchange.com/questions/29260/transform-matrix-multiplication-order">Game Dev: Transform Matrix multiplication order</a>
     * <p>
     * Preconcat works like M` = M * S, so we apply preScale -> preRotate -> preTranslate
     * the result will be the same: L = S * R * T
     * <p>
     * NOTE: postconcat (postScale, etc.) works the other way : M` = S * M, in order to use it
     * we'd need to reverse the order of applying
     * transformations : post holy scale ->  postTranslate -> postRotate -> postScale
     */
    protected void updateMatrix() {
        // init matrix to E - identity matrix
        matrix.reset();
        matrix1.reset();

        float topLeftX = layer.getX() * canvasWidth;
        float topLeftY = layer.getY() * canvasHeight;

        float bottomLeftX = layer.getX() * canvasWidth;
        float bottomLeftY = layer.getY() * canvasHeight + getHeight();

        float topRightX = layer.getX() * canvasHeight + getWidth();

        left = topLeftX;
        right = topRightX;
        top = topLeftY;
        bottom = bottomLeftY;

        Log.d(TAG, "updateMatrix: 1 " + topLeftX + " = " + getWidth() + " = " + holyScale);
        Log.d(TAG, "updateMatrix: 2 " + topLeftY + " = " + getHeight() + " = " + holyScale);

        float centerX = topLeftX + getWidth() * holyScale * 0.5F;
        float centerY = topLeftY + getHeight() * holyScale * 0.5F;

        this.centerX = centerX;
        this.centerY = centerY;

        float bottom = topLeftY + getHeight() * holyScale;
        Log.d(TAG, "updateMatrix: 3 " + topLeftX + " = " + centerX + " = " + bottomLeftX);
        Log.d(TAG, "updateMatrix: 4 " + topLeftY + " = " + centerY + " = " + bottomLeftY);

        // calculate params
        float rotationInDegree = layer.getRotationInDegrees();
        float scaleX = layer.getScale();
        float scaleY = layer.getScale();
        if (layer.isFlipped()) {
            // flip (by X-coordinate) if needed
            rotationInDegree *= -1.0F;
            scaleX *= -1.0F;
        }

        // applying transformations : L = S * R * T

        // scale
        matrix.preScale(scaleX, scaleY, centerX, centerY);


        if (layer.getRotationInDegrees() > 0 || layer.getRotationInDegrees() < 0) {
            //float scale = Math.round(Math.abs(layer.getRotationInDegrees()/100));
            //Log.d(TAG, "updateMatrix: rotate "+Math.abs(layer.getRotationInDegrees()));
            //Log.d(TAG, "updateMatrix: rotate"+(scaleX+scale) + " = "+scaleX + " = "+scaleY    );
            rotate = Math.abs(layer.getRotationInDegrees());
            if (rotate >= 90 && rotate <= 180) {
                rotate -= 180;
            } else if (rotate >= 270 && rotate <= 360) {
                rotate -= 360;
            } else if (rotate > 180 && rotate < 270) {
                rotate -= 180;
            }
            float scale = Math.abs((rotate) / 50);
            Log.d(TAG, "updateMatrix: rotate " + scale + " = " + scaleX + " = " + scaleY);
            matrix1.preScale(scaleX + scale, scaleY + scale, centerX, centerY);
        } else {
            matrix1.preScale(scaleX, scaleY, centerX, centerY);
        }


        // rotate
        matrix.preRotate(rotationInDegree, centerX, centerY);
        //matrix1.preRotate(rotationInDegree, centerX, centerY);

        // translate
        matrix.preTranslate(topLeftX, topLeftY);

        // Bitmap bitmap = Bitmap.createScaledBitmap(oBitmap, getWidth(), getWidth(), false);


        matrix1.preTranslate(topLeftX, topLeftY);

        // applying holy scale - S`, the result will be : L = S * R * T * S`
        matrix.preScale(holyScale, holyScale);
        matrix1.preScale(holyScale, holyScale);

    }

    public void fixScreen1() {

        getLayer().setScale(0.4F);
        //Log.d(TAG, "fixScreen: motion "+width + " = "+canvasHeight + " = "+bottom);
        //Log.d(TAG, "fixScreen: "+getWidth() + " = "+getLayer().getY() +  " + "+getHeight());
        //getLayer().resetLayer();
    }

    public float absoluteCenterX() {
        float topLeftX = layer.getX() * canvasWidth;
        return topLeftX + getWidth() * holyScale * 0.5F;
    }

    public float absoluteCenterY() {
        float topLeftY = layer.getY() * canvasHeight;

        return topLeftY + getHeight() * holyScale * 0.5F;
    }

    public PointF absoluteCenter() {
        float topLeftX = layer.getX() * canvasWidth;
        float topLeftY = layer.getY() * canvasHeight;

        float centerX = topLeftX + getWidth() * holyScale * 0.5F;
        float centerY = topLeftY + getHeight() * holyScale * 0.5F;

        return new PointF(centerX, centerY);
    }

    public void moveToCanvasCenter() {
        moveCenterTo(new PointF(canvasWidth * 0.5F, canvasHeight * 0.5F));
    }

    public void moveCenterTo(PointF moveToCenter) {
        PointF currentCenter = absoluteCenter();
        layer.postTranslate(1.0F * (moveToCenter.x - currentCenter.x) / canvasWidth, 1.0F * (moveToCenter.y - currentCenter.y) / canvasHeight);
    }


    private final PointF pA = new PointF();
    private final PointF pB = new PointF();
    private final PointF pC = new PointF();
    private final PointF pD = new PointF();

    /**
     * For more info:
     * <a href="http://math.stackexchange.com/questions/190111/how-to-check-if-a-point-is-inside-a-rectangle">StackOverflow: How to check point is in rectangle</a>
     * <p>NOTE: it's easier to apply the same transformation matrix (calculated before) to the original source points, rather than
     * calculate the result points ourselves
     *
     * @param point point
     * @return true if point (x, y) is inside the triangle
     */
    public boolean pointInLayerRect(PointF point) {

        updateMatrix();
        // map rect vertices
        matrix.mapPoints(destPoints, srcPoints);

        pA.x = destPoints[0];
        pA.y = destPoints[1];
        pB.x = destPoints[2];
        pB.y = destPoints[3];
        pC.x = destPoints[4];
        pC.y = destPoints[5];
        pD.x = destPoints[6];
        pD.y = destPoints[7];


        return MathUtils.pointInTriangle(point, pA, pB, pC) || MathUtils.pointInTriangle(point, pA, pD, pC);
    }

    /**
     * http://judepereira.com/blog/calculate-the-real-scale-factor-and-the-angle-of-rotation-from-an-android-matrix/
     *
     * @param canvas       Canvas to draw
     * @param drawingPaint Paint to use during drawing
     */
    public final void draw(@NonNull Canvas canvas, @Nullable Paint drawingPaint) {

        updateMatrix();

        canvas.save();

        int height = getHeight();
        int width = getWidth();


        /*if (getLayer().getRotationInDegrees() > 0 || getLayer().getRotationInDegrees() < 0) {
            //Log.d(TAG, "drawContent: "+getLayer().getRotationInDegrees());
            //width = (getHeight() > getWidth()) ? getHeight() : getWidth();
            //height = (getHeight() > getWidth()) ? getHeight() : getWidth();
            // height = getHeight();//(int) (height+Math.abs(getLayer().getRotationInDegrees()-20));
            // whdth = whdth+(int)Math.abs(getLayer().getRotationInDegrees());
        }

*/
        //matrix.postTranslate(centerX-(getWidth()/2),centerY-(getHeight()/2));

        //canvas.drawBitmap(Bitmap.createScaledBitmap(oBitmap, width, height, false), matrix1, null);


        /*    Log.d("Rect", "draw: 0 "+destPoints[0]);
        Log.d("Rect", "draw: 1 "+destPoints[1]);
        Log.d("Rect", "draw: 2 "+destPoints[2]);
        Log.d("Rect", "draw: 3 "+destPoints[3]);
        Log.d("Rect", "draw: 4 "+destPoints[4]);
        Log.d("Rect", "draw: 5 "+destPoints[5]);
        Log.d("Rect", "draw: 6 "+destPoints[6]);
        Log.d("Rect", "draw: 7 "+destPoints[7]);

        Log.d(TAG, "draw: "+(destPoints[2] - destPoints[0]));
        Log.d(TAG, "draw: "+(destPoints[5] - destPoints[1]));*/

        //canvas.drawCircle(destPoints[4],destPoints[5],10,new Paint());

        /*RectF rect = new RectF();
        matrix.mapRect(rect);
        Rect rect1 = new Rect((int)rect.left,(int)rect.top,(int)rect.right,(int)rect.bottom);*/
        // Rect rect1 = new Rect((int)destPoints[0],(int)destPoints[1],(int)destPoints[4],(int)destPoints[5]);
        //  oBitmap = getResizedBitmap(oBitmap,(int)(destPoints[2] - destPoints[0]),(int)(destPoints[5] - destPoints[1]));


        drawContent(canvas, drawingPaint, deleteIconPaint);

        if (isSelected()) {
            // get alpha from drawingPaint
            int storedAlpha = borderPaint.getAlpha();
            if (drawingPaint != null) {
                borderPaint.setAlpha(drawingPaint.getAlpha());
            }
            drawSelectedBg(canvas);
            // restore border alpha
            borderPaint.setAlpha(storedAlpha);


        }

        canvas.restore();
    }

    private void drawSelectedBg(Canvas canvas) {
        matrix.mapPoints(destPoints, srcPoints);
        //noinspection Range
        //canvas.drawLines(destPoints, 0, 8, borderPaint);
        //noinspection Range
        //canvas.drawLines(destPoints, 2, 8, borderPaint);

        mStartX = destPoints[0];
        mStartY = destPoints[1];
        mRadius = getLayer().getScale() * 30;

        if (mStartX != 0 && mStartY != 0) {
            if (getLayer().getStickerType().equals("sticker")) {
                mRadius = getLayer().getScale() * 40;
                //canvas.drawCircle(destPoints[0], destPoints[1], mRadius, deleteIconPaint);
            } else {
                mRadius = getLayer().getScale() * 25;
                //canvas.drawCircle(destPoints[0], destPoints[1], mRadius, deleteIconPaint);
            }


        }

        //canvas.drawLine(destPoints[0] - (mRadius - 12), destPoints[1] - (mRadius - 12), destPoints[0] + (mRadius - 12), destPoints[1] + (mRadius - 12), drawLine);
        // canvas.drawLine(destPoints[0] - (mRadius - 12), destPoints[1] + (mRadius - 12), destPoints[0] + (mRadius - 12), destPoints[1] - (mRadius - 12), drawLine);
    }

    public Bitmap getResizedBitmap(Bitmap bm, int newWidth, int newHeight) {
        if (newHeight > 0 && newWidth > 0) {
            int width = bm.getWidth();
            int height = bm.getHeight();
            float scaleWidth = ((float) newWidth) / width;
            float scaleHeight = ((float) newHeight) / height;
            // CREATE A MATRIX FOR THE MANIPULATION
            Matrix matrix = new Matrix();
            // RESIZE THE BIT MAP
            matrix.postScale(scaleWidth, scaleHeight);

            // "RECREATE" THE NEW BITMAP
            Bitmap resizedBitmap = Bitmap.createBitmap(
                    bm, 0, 0, width, height, matrix, false);
            bm.recycle();
            return resizedBitmap;
        /*float aspectRatio = bm.getWidth() /
                (float) bm.getHeight();
        int width = newWidth;
        int height = Math.round(width / aspectRatio);

        Bitmap yourSelectedImage = Bitmap.createScaledBitmap(
                bm, width, height, false);
        return yourSelectedImage;*/
        }
        return null;
    }

    @NonNull
    public Layer getLayer() {
        return layer;
    }

    public void setBorderPaint(@NonNull Paint borderPaint, Paint deleteIcon) {
        this.borderPaint = borderPaint;
        this.deleteIconPaint = deleteIcon;
    }

    public void setDeleteIconPaintColor(Paint deleteIcon) {
        this.deleteIconPaint = deleteIcon;
    }

    protected abstract void drawContent(@NonNull Canvas canvas, @Nullable Paint drawingPaint, @Nullable Paint deleteIconPaint);

    public abstract int getWidth();

    public abstract int getHeight();

    public void release() {
        // free resources here
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            release();
        } finally {
            //noinspection ThrowFromFinallyBlock
            super.finalize();
        }
    }
}
