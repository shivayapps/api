package com.text.art.fancy.creator;

import androidx.room.*;

@Dao
public interface AllDataDao {

//    @Query("SELECT * FROM ParametersItemAllChilds" )
//    List<ParametersItemAllChilds> getAll();
//
//    @Insert
//    void insert(ParametersItemAllChilds note);
//
//    @Update
//    void update(ParametersItemAllChilds repos);
//
//    @Delete
//    void delete(ParametersItemAllChilds note);
//
//    @Delete
//    void delete(ParametersItemAllChilds... note);
//
//    @Query("SELECT * FROM CategoryParametersItem" )
//    List<CategoryParametersItem> getAllList();

}