package com.text.art.fancy.creator.categorys.adepter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.text.art.fancy.creator.categorys.fragments.FramePagerFragment;
import com.text.art.fancy.creator.categorys.model.DataItem;
import com.text.art.fancy.creator.categorys.parameter.ParametersItem;

import java.util.ArrayList;

//import com.pip.camera.art.filter.photo.effect.editor.categorys.fragments.FramePagerFragment;
//import com.tattoo.body.name.girls.boys.photo.editor.categorys.model.ParametersItem;
//import com.pip.camera.art.filter.photo.effect.editor.model.frames.DataItem;
//import com.pip.camera.art.filter.photo.effect.editor.model.parameter.ParametersItem;


public class FrameCategoryPagerAdepter extends FragmentStatePagerAdapter {

    private ArrayList<DataItem> mList;
    private ArrayList<ParametersItem> mParamList;
    private String mType;

    public FrameCategoryPagerAdepter(@NonNull FragmentManager fm, ArrayList<DataItem> mList, ArrayList<ParametersItem> mParamList, String type) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        this.mList = mList;
        this.mParamList = mParamList;
        this.mType = type;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        if (mList != null) {
            return new FramePagerFragment(mList.get(position).getImage(), mType);
        } else {
            return new FramePagerFragment(mParamList.get(position).getCategoryParameters(), true);
        }
    }

    @Override
    public int getCount() {
        if (mList != null) {
            return mList.size();
        } else {
            return mParamList.size();
        }
    }

}
