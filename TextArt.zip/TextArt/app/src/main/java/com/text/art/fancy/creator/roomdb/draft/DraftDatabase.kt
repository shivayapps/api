package com.text.art.fancy.creator.roomdb.draft

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.db.AppDatabase

// UserDatabase represents database and contains the database holder and server the main access point for the underlying connection to your app's persisted, relational data.

@Database(
    entities = [Draft::class],
    version = 4,                // <- Database version
    exportSchema = false
)
abstract class DraftDatabase: RoomDatabase() { // <- Add 'abstract' keyword and extends RoomDatabase
    abstract fun draftDao(): DraftDao

    companion object {
        private const val name = "TextArtDB"
        private var db : DraftDatabase? = null

        fun getInstance(context : Context) : DraftDatabase {
            if(db == null) {
                db = Room.databaseBuilder(
                    context,
                    DraftDatabase::class.java,
                    name
                ).allowMainThreadQueries()
                .build()
            }
            return db!!
        }

        /*private const val name = "local_app_database"
        @Volatile
        private var INSTANCE: UserDatabase? = null
        fun getDatabase(context: Context): UserDatabase {
            val tempInstance = INSTANCE

            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context,
                    UserDatabase::class.java,
                    name
                ).build()
                INSTANCE = instance
                return instance
            }
        }*/
    }
}