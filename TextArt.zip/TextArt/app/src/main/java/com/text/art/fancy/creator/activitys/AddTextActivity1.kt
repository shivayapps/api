package com.text.art.fancy.creator.activitys

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.NonNull
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.TextArtApplication
import com.text.art.fancy.creator.activitys.HomeActivity.Companion.fontList
import com.text.art.fancy.creator.adepter.*
import com.text.art.fancy.creator.adepter.FontStyleAdepter.Companion.fontPosition
import com.text.art.fancy.creator.adepter.GradientTextColorAdepter.Companion.gradientPosition
import com.text.art.fancy.creator.adepter.MultipleColorAdepter.Companion.multiColorPosition
import com.text.art.fancy.creator.adepter.OfflineDataAdapter.Companion.offlinePosition
import com.text.art.fancy.creator.adepter.TextureAdepter.Companion.patternPosition
import com.text.art.fancy.creator.ads.InterstitialAdHelper
import com.text.art.fancy.creator.ads.OfflineNativeAdvancedHelper
import com.text.art.fancy.creator.ads.RewardVideoAds.Companion.instence
import com.text.art.fancy.creator.categorys.parameter.Response
import com.text.art.fancy.creator.comman.ACTION
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.comman.Constants.DRAFT
import com.text.art.fancy.creator.comman.Constants.FontFolder
import com.text.art.fancy.creator.comman.Constants.LOGO
import com.text.art.fancy.creator.comman.Constants.NAME
import com.text.art.fancy.creator.comman.Constants.isDraftUpdate
import com.text.art.fancy.creator.comman.Constants.downloadedFont
import com.text.art.fancy.creator.comman.Constants.isFirstTimeApplyBg
import com.text.art.fancy.creator.comman.Constants.isFirstTimeApplyCombo
import com.text.art.fancy.creator.comman.Constants.isFirstTimeApplyFrame
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.database.DBHelper
import com.text.art.fancy.creator.dialog.DiscardDialogFragment
import com.text.art.fancy.creator.dialog.WatchAdDialogFragment
import com.text.art.fancy.creator.interfaces.broadcastReceivers
import com.text.art.fancy.creator.model.Background
import com.text.art.fancy.creator.model.UndoRedo
import com.text.art.fancy.creator.receivers.ConnectionReceiver
import com.text.art.fancy.creator.retrofit.APIClient
import com.text.art.fancy.creator.retrofit.APIInterface
import com.text.art.fancy.creator.roomdb.draft.Draft
import com.text.art.fancy.creator.roomdb.draft.DraftDatabase
import com.text.art.fancy.creator.utils.*
import com.text.art.fancy.creator.viewModel.OfflineViewDataModel
import com.crop.photo.image.resize.cut.tools.ads.RewardedAdHelper
import com.downloader.OnDownloadListener
import com.downloader.PRDownloader
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.AdSettings
import com.facebook.ads.InterstitialAdListener
import com.google.android.gms.ads.InterstitialAd
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.jaredrummler.android.colorpicker.ColorPickerDialog
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener
import com.scribble.animation.maker.video.effect.myadslibrary.utils.InternetConnection
import com.vasu.image.video.pickrandom.galleryapp.VasuImagePicker
import kotlinx.android.synthetic.main.activity_add_text1.*
import kotlinx.android.synthetic.main.content_gradient_color_layout.*
import kotlinx.coroutines.*
import org.jetbrains.anko.runOnUiThread
import org.jetbrains.anko.textColor
import retrofit2.Call
import retrofit2.Callback
import sticker.view.dixitgabani.Configure.dpToPx
import sticker.view.dixitgabani.autofit.AutoResizeTextView
import sticker.view.dixitgabani.autofit.AutofitLayout
import sticker.view.dixitgabani.model.StickerModel
import sticker.view.dixitgabani.model.TYPE
import sticker.view.dixitgabani.model.TYPE.*
import java.io.*
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalTime
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import kotlin.math.roundToInt
import kotlin.properties.Delegates

class AddTextActivity1 : AppCompatActivity(), View.OnClickListener,
    InterstitialAdHelper.onInterstitialAdListener, broadcastReceivers,
    MyTouchMotion.SetTransform {

    private lateinit var context: AddTextActivity1
    private val TAG = "AddTextActivity"

    internal var dbHelper: DBHelper = DBHelper(this)
    val handler = Handler(Looper.getMainLooper())

    //TODO Widgets: ConstraintLayout
    private lateinit var cons3DText: ConstraintLayout
    private lateinit var textFunction: ConstraintLayout
    private lateinit var constraint3D: ConstraintLayout
    private lateinit var tempContainer: RelativeLayout
    private lateinit var consColorList: ConstraintLayout
    private lateinit var consCurveText: ConstraintLayout
    private lateinit var txtFontTypeAA: ConstraintLayout
    private lateinit var consShadowText: ConstraintLayout
    private lateinit var consPatternList: ConstraintLayout
    private lateinit var imgFontTypeBold: ConstraintLayout
    private lateinit var constraintColor: ConstraintLayout
    private lateinit var constraintCurve: ConstraintLayout
    private lateinit var consTextFontType: ConstraintLayout
    private lateinit var consTextFontGlow: ConstraintLayout
    private lateinit var constraintShadow: ConstraintLayout
    private lateinit var mConstraintMenuBG: ConstraintLayout
    private lateinit var addTextMainLayout: ConstraintLayout
    private lateinit var constraintPattern: ConstraintLayout
    private lateinit var consFontStyleList: ConstraintLayout
    private lateinit var imgFontTypeItalic: ConstraintLayout
    private lateinit var consTextFontStroke: ConstraintLayout
    private lateinit var constraintFontType: ConstraintLayout
    private lateinit var constraintFontGlow: ConstraintLayout
    private lateinit var constraintFontStyle: ConstraintLayout
    private lateinit var imgFontTypeUnderline: ConstraintLayout
    private lateinit var mConstraintMenuFrame: ConstraintLayout
    private lateinit var mConstraintMenuCombo: ConstraintLayout
    private lateinit var clMainOptionContainer: ConstraintLayout
    private lateinit var mConstraintMenuSticker: ConstraintLayout
    private lateinit var mConstraintMenuAddText: ConstraintLayout
    private lateinit var constraintSubLayoutColor: ConstraintLayout
    private lateinit var mConstraintSubLayoutText3d: ConstraintLayout
    private lateinit var mConstraintMenuAddAnimation: ConstraintLayout
    private lateinit var mConstraintSubLayoutTexture: ConstraintLayout
    private lateinit var constraintSubLayoutFontStyle: ConstraintLayout
    private lateinit var mConstraintSubLayoutGradient: ConstraintLayout
    private var mConstraintLayoutBG: ConstraintLayout ?= null
    private var mConstraintLayoutMenu: ConstraintLayout ?= null
    private var mConstraintFrameLayout: ConstraintLayout ?= null
    private var mConstraintLayoutAddText: ConstraintLayout ?= null
    private var mConstraintLayoutaddSticker: ConstraintLayout ?= null
    private var mConstraintSubLayoutTextCurve: ConstraintLayout ?= null
    private var mConstraintSubLayoutTextSpace: ConstraintLayout ?= null
    private var mConstraintSubLayoutTextBorder: ConstraintLayout ?= null
    private var mConstraintSubLayoutShadowColor: ConstraintLayout ?= null
    private var mConstraintSubLayoutStickerItems: ConstraintLayout ?= null
    private var mConstraintSubLayoutStickerCategoryItems: ConstraintLayout ?= null

    //TODO Widgets: IMAGEVIEW
    private lateinit var frameView: ImageView
    private lateinit var mImgBackBg: ImageView
    private lateinit var imgBtnBack: ImageView
    private lateinit var imgBtnSave: ImageView
    private lateinit var imgBtnRedo: ImageView
    private lateinit var imgBtnUndo: ImageView
    private lateinit var imgTextCase: ImageView
    private lateinit var imgShowMore: ImageView
    private lateinit var mImgBackFont: ImageView
    private lateinit var imgWaterMark: ImageView
    private lateinit var mImgBackSpace: ImageView
    private lateinit var backgroundView: ImageView
    private lateinit var mImgBackaddText: ImageView
    private lateinit var imgBtnResetCurve: ImageView
    private lateinit var imgFontGlowColor: ImageView
    private lateinit var imgWaterMarkClose: ImageView
    private lateinit var imgFontStrokeColor: ImageView
    private lateinit var mImgBackaddSticker: ImageView
    private lateinit var imgBtnResetFontType: ImageView
    private lateinit var imgBtnResetFontGlow: ImageView
    private lateinit var imgBtnResetFontStroke: ImageView
    private lateinit var mImgBackStickerItemCategory: ImageView
    //StickerGrid
    private lateinit var stickerGridVertical: ImageView
    private lateinit var stickerGridHorizontal: ImageView
    private lateinit var stickerGridVertical1: ImageView
    private lateinit var stickerGridHorizontal1: ImageView
    private lateinit var stickerGridVertical2: ImageView
    private lateinit var stickerGridHorizontal2: ImageView

    //TODO Widgets: TEXTVIEW
    private lateinit var mBgColorText: TextView
    private lateinit var tvGradientColor: TextView
    private lateinit var mMultiColorText: TextView
    private lateinit var mBackgroundText: TextView
    private lateinit var mSingleColorText: TextView
    private lateinit var mTxtSpacePercent1: TextView
    private lateinit var mTxtSpacePercent2: TextView

    //TODO Widgets: RECYCLERVIEW
    private lateinit var rvFrame: RecyclerView
    private lateinit var rvCombo: RecyclerView
    private lateinit var rvBackground: RecyclerView
    private lateinit var mRecyclerColor: RecyclerView
    private lateinit var mRecyclerFrame: RecyclerView
    private lateinit var mRecyclerBGColor: RecyclerView
    private lateinit var mRecyclerTexture: RecyclerView
    private lateinit var mRecyclerAddText: RecyclerView
    private lateinit var mRecyclerFontStyle: RecyclerView
    private lateinit var recyclerColorStyle: RecyclerView
    private lateinit var mRecyclerStickerItems: RecyclerView
    private lateinit var mRecyclerGradientColor: RecyclerView
    private lateinit var mRecyclerStickerCategory: RecyclerView

    //TODO Variables: ArrayList
    private lateinit var primeFont: ArrayList<String>
    private lateinit var frameList: ArrayList<String>
    private lateinit var mPatternList: ArrayList<Any>
    private lateinit var fontValList: ArrayList<String>
    private lateinit var fontZipPath: ArrayList<String>
    private lateinit var frameValList: ArrayList<String>
    private lateinit var fontStyleList: ArrayList<String>
    private var stickerList = arrayListOf<StickerModel>()
    private var mUndo: ArrayList<UndoRedo> = arrayListOf()
    private var mRedo: ArrayList<UndoRedo> = arrayListOf()
    private lateinit var mPatternValList: ArrayList<String>
    private lateinit var isDownloadedOrNot: ArrayList<String>
    private var multiColorList = arrayListOf<ArrayList<Int>>()
    private var fontThumbImg: ArrayList<String> = arrayListOf()
    private var mGradinetArray: ArrayList<String> = ArrayList()
    private var gradientColorList: ArrayList<String> = ArrayList()
    private var mGradinetArrayTwo: ArrayList<String> = ArrayList()
    private var mGradinetArrayCenter: ArrayList<String> = ArrayList()

    //TODO Variables: Booleans
    private var isEdit = false
    private var isState = false
    private var isFromUndo = true
    private var isFirstTime = true
    private var isGetReward = false
    private var mIsSubScribe = false
    private var isFromDiscard = false
    private var mIsOpenGallery = false
    private var isFromUndoRedo = false
    private var isStartedLoading = false
    private var isFirstTextTemplate = false
    private var isFontApiDataLoaded = false
    private var isInterstitialAdLoaded = false
    private var isFirstTimeBuySubcription = true

    //TODO Variables: Strings
    var fontVal: String? = null
    var frameVal: String? = null
    var fontName: String? = null
    var frameName: String? = null
    var patternVal: String? = null
    var primeFontVal: String? = null
    private var mPath: String? = null
    private var refId: String? = null
    private var tStickerPath: String? = null
    private var originalText = ""
    private var tBgPath = ""
    private var tFramePath = ""
    private var MODE = DEFAULT
    private var tPatterPath = ""
    private var tComboBgPath = ""
    private var tComboFramePath = ""

    //TODO Variables: Numeric
    private var index: Int? = null
    private var max = 0
    private var tBgColor = 0
    private var offlineBgPosition = -1
    private var offlineFramePosition = -1
    private var offlineComboPosition = -1
    private var lastClickTime: Long = 0
    private var draftTotal by Delegates.notNull<Int>()
    private var mSelectedTextTemplatePosition = 0
    private var stickerViewWidth by Delegates.notNull<Int>()
    private var stickerViewHeight by Delegates.notNull<Int>()

    //TODO REQ CODE
    private val PICK_IMAGE_CODE = 102
    private var TEXT_GLOW   = 1
    private var TEXT_COLOR  = 2
    private var TEXT_STROKE = 3

    //TODO Adapters
    private var textureAdepter: TextureAdepter? = null
    private var mFrameAdapter: FrameAdepter? = null
    private var fontAdapter: FontStyleAdepter? = null
    private lateinit var frameAdapter: OfflineDataAdapter
    private lateinit var comboAdapter: OfflineDataAdapter
    private lateinit var backgroundAdapter: OfflineDataAdapter
    private var multiColorAdepter: MultipleColorAdepter? = null
    private var gradientAdepter: GradientTextColorAdepter? = null
    private lateinit var mTmpHolder: FontStyleAdepter.MyViewHolder

    //TODO Fragments & Dialogs
    private lateinit var dialog: Dialog
    private var editDialog: Dialog? = null
    private var dialogSave: DiscardDialogFragment? = null
    private var colorPickerDialog: ColorPickerDialog? = null
    private lateinit var watchAdDialog: WatchAdDialogFragment
    private lateinit var dialogWaterMark: WatchAdDialogFragment
    private var progressDialog: ProgressDialog ?= null

    var patternName: Any? = null

    //TODO Network Receiver
    var intentFilter: IntentFilter? = null
    var networkReceiver: ConnectionReceiver? = null

    //TODO Widgets: LAYOUT & VIEW
    private var background = Background()
    private var bitmap: Bitmap? = null
    private var mSeek3Dx: SeekBar? = null
    private var mSeek3Dy: SeekBar? = null
    private lateinit var mSeekGlow: SeekBar
    private var mSeekSpace: SeekBar? = null
    private var mSeekCurve: SeekBar? = null
    private lateinit var mSeekStroke: SeekBar
    private var mSeekOpacity: SeekBar? = null
    private lateinit var addTextToolbar: Toolbar
    private var mProgressBar3: ProgressBar? = null
    private var fontProvider: FontProvider? = null
    private var mSeekTextSpaceSize: SeekBar? = null
    private var mStickerModel: StickerModel? = null
    private lateinit var llShowTextFun: LinearLayout
    private lateinit var stickerView: RelativeLayout
    private var interstitial: InterstitialAd? = null
    private var selectedSticker: AutofitLayout? = null
    private var mBtnMoreAPI: LottieAnimationView? = null
    private lateinit var clMainOptionView: LinearLayout
    private lateinit var rlWaterMarlClick: RelativeLayout
    private lateinit var offlineViewDataModel : OfflineViewDataModel
    private var mConstraintLayoutStickerCategory: LinearLayout? = null
    private lateinit var stickerListener: AutofitLayout.TouchEventListener

    //TODO Analytics Event
    @SuppressLint("MissingPermission")
    private var mBundle: Bundle = Bundle()
    private var mFirebaseAnalytics = FirebaseAnalytics.getInstance(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_text1)
        context = this@AddTextActivity1
        initView()
        stickerView = findViewById(R.id.dynamicStickerFrame)
        stickerView.post {
            stickerViewWidth = this.stickerView.width
            stickerViewHeight = this.stickerView.height
        }
        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        loadAds()
        try { addTextToolbar.setPadding(0, getStatusbarHeight(), 0, 0) } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            hideSystemUI()


        loadOfflineData()
        getFrameData()
        getPatternData()
        initViewAction()
        initViewListener()
        buildDialog()
        invalidateView()

    }

    private fun checkRWPermission() {
        if ((ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) &&
            (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        ) {
            finish()
        }
        /*if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(context, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }*/
    }

    private fun loadAds() {
        try { RewardedAdHelper.instence!!.loadRewardedAd(context) } catch (e: Exception) { }
        interstitial = InterstitialAdHelper.instance?.load(context, context)
        instence!!.loadVideoAdMain(context)
        if (!mIsSubScribe) {
            loadInterstitialAds()
        }
    }

    private fun invalidateView() {
        Constants.BgPositionColor = -1
        Constants.BgPosition = -1
        imgWaterMarkClose.show()
        imgWaterMark.show()
        rlWaterMarlClick.show()
        mConstraintLayoutAddText?.show()
        mRecyclerAddText.enabled()
        mConstraintMenuBG.disabled()

        MySharedPreferences(this).isSetFrame = false
        MySharedPreferences(this).isNewFrame = false
        Log.d(TAG, "stickerView: performClick 1")
        stickerView.performClick()
        addTextMainLayout.invalidate()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun loadOfflineData() {
        offlineViewDataModel = ViewModelProvider(this)[OfflineViewDataModel::class.java]
        offlineViewDataModel.offlineBgList.observe(this){ data ->
            //TODO Set Offline Background Adapter
            backgroundAdapter = OfflineDataAdapter(data, { pos ->
                if (pos == 0)
                    removeOfflineBGAndFrame()
                else {
                    setOfflineBackgroundImage(pos)
                }
            })
            val bgLayoutManager = GridLayoutManager(applicationContext, 2)
            bgLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
            rvBackground.layoutManager = bgLayoutManager
            rvBackground.adapter = backgroundAdapter
        }
        offlineViewDataModel.offlineFrameList.observe(this){ data ->
            //TODO Set Offline Frame Adapter
            frameAdapter = OfflineDataAdapter(data,{ pos ->
                if (pos == 0)
                    removeOfflineBGAndFrame()
                else
                    setOfflineFrameImage(pos)
            })
            val frameLayoutManager = GridLayoutManager(applicationContext, 2)
            frameLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
            rvFrame.layoutManager = frameLayoutManager
            rvFrame.adapter = frameAdapter
        }
        offlineViewDataModel.offlineComboList.observe(this){ data ->
            //TODO Set Offline Combo Adapter
            comboAdapter = OfflineDataAdapter(null, { pos ->
                offlinePosition = pos
                offlineComboPosition = pos
                offlineBgPosition = -1
                offlineFramePosition = -1
                comboAdapter.notifyDataSetChanged()
                if (pos == 0) removeOfflineBGAndFrame()
                else {
                    setOfflineComboImage(pos)
                }
            }, data)
            val comboLayoutManager = GridLayoutManager(applicationContext, 2)
            comboLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
            rvCombo.layoutManager = comboLayoutManager
            rvCombo.adapter = comboAdapter

            lifecycleScope.launch {
                //TODO Call When All data Is Loaded
                manageMode()
            }

        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun removeOfflineBGAndFrame() {
        when(imgShowMore.tag){
            "Background" -> {
                offlinePosition = -1
                offlineBgPosition = -1
                offlineComboPosition = -1
                background.background = -1
                backgroundAdapter.notifyDataSetChanged()
                tBgPath = ""
                backgroundView.setImageDrawable(null)

                //TODO Add Undo Redo OPERATION
                val operation = UndoRedo.Operation()
                operation.bgImage = ""
                operation.frameImage = tFramePath
                val action = UndoRedo(ACTION.ChangeBGNone, 0, operation)
                mUndo.add(action)
            }
            "Frame"      -> {
                offlinePosition = -1
                offlineFramePosition = -1
                offlineComboPosition = -1
                background.frame = -1

                frameAdapter.notifyDataSetChanged()
                tFramePath = ""
                frameView.setImageResource(0)

                //TODO Add Undo Redo OPERATION
                val operation = UndoRedo.Operation()
                operation.bgImage = tBgPath
                operation.frameImage = ""
                val action = UndoRedo(ACTION.ChangeFrameNone, 0, operation)
                mUndo.add(action)
            }
            "Combo"      -> {
                offlineBgPosition = -1
                offlineFramePosition = -1
                offlineComboPosition = -1
                background.combo = -1
                background.background = -1
                background.frame = -1
                backgroundAdapter.notifyDataSetChanged()
                frameAdapter.notifyDataSetChanged()
                tComboBgPath = ""
                tComboFramePath = ""
                backgroundView.setImageDrawable(null)
                frameView.setImageDrawable(null)

                //TODO Add Undo Redo OPERATION
                val operation = UndoRedo.Operation()
                operation.bgImage = ""
                operation.frameImage = ""
                val action = UndoRedo(ACTION.ChangeComboNone, 0, operation)
                mUndo.add(action)
            }
        }
        manageUndoRedoButton()
    }

    @SuppressLint("SimpleDateFormat")
    private fun buildDialog() {
        //TODO Sticker Edit Dialog
        editDialog = Dialog(this)
        editDialog!!.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        editDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        editDialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        editDialog!!.setCancelable(false)
        editDialog!!.setContentView(R.layout.text_edit_dialog)

        val editText = editDialog!!.findViewById<EditText>(R.id.edtTextSticker)

        editDialog!!.findViewById<Button>(R.id.btnPositive).click {
            if (TextUtils.isEmpty(editText.text.toString().trim())) {
                showToast("Please enter name")
                return@click
            }
            if (index == null){
                originalText = editText.text.toString().trim()
                addSticker(TEXT_STICKER, originalText)
                constraintFontStyle.performClick()
                handler.postDelayed({
                    editDialog!!.dismiss()
                },100)
            }else{
                index?.let { i ->
                    if (stickerList[i].isFirstTimeChangeText) {
                        //TODO Add Operation in UndoRedo
                        val operation1 = UndoRedo.Operation()
                        operation1.newText = originalText
                        operation1.mWidth = selectedSticker?.width!!
                        Log.d(TAG, "ACTION.ChangeText: First text $originalText")
                        val action1 = UndoRedo(ACTION.ChangeText, i, operation1)
                        mUndo.add(action1)
                        stickerList[i].isFirstTimeChangeText = false
                    }
                    originalText = editText.text.toString().trim()
                    selectedSticker!!.text = originalText
                    stickerList[i].mainText = originalText
                    //TODO Add Operation in UndoRedo
                    val operation = UndoRedo.Operation()
                    operation.newText = originalText
                    operation.mWidth = selectedSticker?.width!!
                    Log.d(TAG, "ACTION.ChangeText: text $originalText")
                    val action = UndoRedo(ACTION.ChangeText, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()

                    //TODO Manage AA, Aa, aa
                    when (stickerList[i].fontType) {
                        "AA" -> {
                             originalText = originalText.lowercase()
                             selectedSticker!!.text_iv.text = originalText
                        }
                        "Aa" -> {
                             originalText = originalText.uppercase()
                             selectedSticker!!.text_iv.text = originalText
                        }
                        "aa" -> {
                             originalText = toTitleCase(originalText)
                             selectedSticker!!.text_iv.text = originalText
                        }
                        else -> {
                            stickerList[i].fontType = "Default"
                            imgTextCase.setImageResource(R.drawable.ic_a1)
                            setFontTypeSelection(Constants.CASE,false)
                        }
                    }

                    //TODO Manage Bold & Italic & Underline
                    setTextFontTypeIfApplied(true)

                    //TODO Manage Color
                    if (stickerList[i].isMultiColor) {
                        Log.d(TAG, "multiColorAdepter clickMultiColor 1")
                        multiColorAdepter!!.clickMultiColor(stickerList[i].positionMultiple)
                    }

//                    if (stickerList[i].isItalic) {
//                        val spanString = SpannableString(selectedSticker!!.text.toString())
//                        if (stickerList[i].isBold) {
//                            spanString.setSpan(StyleSpan(Typeface.BOLD_ITALIC), 0, spanString.length, 0)
//                        } else {
//                            spanString.setSpan(StyleSpan(Typeface.ITALIC), 0, spanString.length, 0)
//                        }
//                        selectedSticker!!.text_iv.text = spanString
//                    }
                }
                editDialog!!.dismiss()
            }
            stickerView.invalidate()
        }
        editDialog!!.findViewById<Button>(R.id.btnNagative).click {
            if (stickerList.isNotEmpty())
                editDialog!!.dismiss()
            else{
                if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@click
                lastClickTime = SystemClock.elapsedRealtime()

                addSticker(TEXT_STICKER, "TextArt")
                imgBtnUndo.setOpacity(1F)
                handler.postDelayed({
                    editDialog!!.dismiss()
                },100)
            }
        }
        imgBtnSave.tag = "text"

        //TODO OnBackPress Dialog
        dialog = Dialog(this)
        /*dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )*/

        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_exit_add_text)
//        dialog.setContentView(R.layout.dialog_exit)

        val btnPositive = dialog.findViewById<TextView>(R.id.btnPositive) //Draft
        val btnNegative = dialog.findViewById<TextView>(R.id.btnNegative)
        val btnClose = dialog.findViewById<ImageView>(R.id.btnClose)

        btnClose.click {
            Constants.mSelectedColorPos = -1
            dialog.dismiss()
        }

        btnNegative.click {
            //TODO Finish Activity
            Constants.mSelectedColorPos = -1
            dialog.dismiss()
            if (MODE == DRAFT){
                isDraftUpdate = true
                val draftDB = DraftDatabase.getInstance(context)
                val id = intent.getIntExtra("position",0)
                File(draftDB.draftDao().getOldDraftPreview(id)).delete()
                draftDB.draftDao().deleteDraft(id)
                finish()
            }else
                finish()
        }

        btnPositive.click {
            btnPositive.disabled()

            //TODO Do Save Draft
            val bg        = ""
            val frame     = ""
            var combo     = ""
            var path      = ""
            var draftList = ""
            val hideViewList = arrayListOf<Int>()
            lifecycleScope.launch {
                withContext(Dispatchers.IO){
                    launch {
                        val item = stickerList.iterator()
                        var id = 0
                        while (item.hasNext()) {
                            val model = item.next()
                            (stickerView.findViewWithTag<AutofitLayout>(id)).let {
                                if (it.isVisible()){
                                    model.tEXT     = it.stickerType
                                    model.tEXT     = it.text
                                    model.pOS_X    = it.x
                                    model.pOS_Y    = it.y
                                    model.wIDTH    = it.layoutParams.width
                                    model.hEIGHT   = it.layoutParams.height
                                    model.rOTATION = it.rotation
                                    model.isFlipped= model.isFlipped
                                }else{
                                    hideViewList.add(id)
                                }
                            }
                            Log.d(TAG, "manageMode: sticker value isFlip ${stickerList[id].isFlipped} model ${model.isFlipped}")
                            id++
                        }
                        withContext(Dispatchers.Main){
                            path = saveImageForPreview()
                        }
                    }.invokeOnCompletion {
                        Log.d(TAG, "manageMode: BG combo Add Mode ${background.combo}")
                        Log.d(TAG, "manageMode: BG combo Add Mode ${background.background}")
                        Log.d(TAG, "manageMode: BG combo Add Mode ${background.frame}")
                        val type = object : TypeToken<Background>() {}.type
                        combo = Gson().toJson(background, type)
                    }
                }
                withContext(Dispatchers.Main){
                    //TODO Add Draft In Room Database
                    Log.d(TAG, "buildDialog: hideViewList ${hideViewList.size} stickerList ${stickerList.size}")
                    if (hideViewList.isNotEmpty()) {
                        if (stickerList.size == hideViewList.size){
                            showToast(getString(R.string.add_text))
                            btnPositive.enabled()
                            dialog.dismiss()
                            return@withContext
                        }else{
                            val item = stickerList.iterator()
                            var i = 0
                            while (item.hasNext()) {
                                item.next()
                                (stickerView.findViewWithTag<AutofitLayout>(i)).let {
                                    if (!it.isVisible()){
                                        item.remove()
                                    }
                                }
                                i++
                            }
                        }
                    }

                    val type = object : TypeToken<ArrayList<StickerModel>>() {}.type
                    draftList = Gson().toJson(stickerList, type)

                    val draftDB = DraftDatabase.getInstance(context)
                    val date = File(path).lastModified()
                    if (MODE == DRAFT){
                        isDraftUpdate = true
                        val id = intent.getIntExtra("position",0)
//                        File(draftDB.draftDao().getOldDraftPreview(id)).delete()
                        draftDB.draftDao().deleteDraft(id)
                        draftDB.draftDao().addDraft(
                            Draft(0, date.toString(), getCurrentTime(), path, draftList, combo, rlWaterMarlClick.isVisible())
                        )
                    }else{
                        draftDB.draftDao().addDraft(
                            Draft(0, date.toString(), getCurrentTime(), path, draftList, combo, rlWaterMarlClick.isVisible())
                        )
                    }
                    Log.d(TAG, "buildDialog: draftDB data is bg $bg frame $frame combo $combo")
                    dialog.dismiss()
                    finish()
                }
            }
        }

        dialog.window!!.setLayout(
            (displayWidth() * 0.92).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        /*dialog = DiscardDialogFragment(
                "Discard",
                "If you Leave this page your work\n will be unsaved!",
                R.drawable.ic_discard_dialog,
                "Discard",
                "Continue"
        )
        { s, discardDialogFragment ->
            if (s == "ok") {
                isDialogOpen = false
                discardDialogFragment.dismiss()
            } else {
                isDialogOpen = false
                discardDialogFragment.dismiss()
                finish()
//                if (isInterstitialAdLoaded && !mIsSubScribe) {
//                    isFromDiscard = true
//                    Constants.isAdsShow = true
//                    interstitial!!.show()
//                } else {
//                    finish()
//                }
            }
        }
        dialog.isCancelable = false*/

        //TODO Set progress Dialog
        progressDialog = ProgressDialog(this)
        progressDialog?.setMessage("Please wait...")
        progressDialog?.setCancelable(false)
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun loadData() {
        GlobalScope.launch {
            withContext(Dispatchers.IO){
                val apiInterface = APIClient.getClient().create(APIInterface::class.java)
                val call = apiInterface.parameterList
                call.enqueue(object : Callback<Response> {
                    override fun onResponse(
                        call: Call<Response>,
                        response: retrofit2.Response<Response>,
                    ) {
                        if (response.isSuccessful && response.body()!!.parameters != null){
                            try {
                                response.body()!!.parameters.filterIndexed { _, parametersItem ->
                                    isStartedLoading = true
                                    if (parametersItem.name == "Background" || parametersItem.id == 439) {
                                        BGActivity.bgAllArray.clear()
                                        parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                            BGActivity.bgAllArray.add(categoryParametersItem)
                                            true
                                        }
                                        BGActivity.isBGDataLoaded = true
                                    }
                                    if (parametersItem.name == "Sticker" || parametersItem.id == 449) {
                                        StickerActivity.stickerAllArray.clear()
                                        parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                            StickerActivity.stickerAllArray.add(categoryParametersItem)
                                            true
                                        }
                                        StickerActivity.isStickerDataLoaded = true
                                    }
                                    if (parametersItem.name == "Frames" || parametersItem.id == 451) {
                                        FrameActivity.frameAllArray.clear()
                                        parametersItem.all_childs.filterIndexed {_ , categoryParametersItem ->
                                            FrameActivity.frameAllArray.add(categoryParametersItem)
                                            true
                                        }
                                        FrameActivity.isFrameDataLoaded = true
                                    }
                                    if (parametersItem.name == "Combo" || parametersItem.id == 785) {
                                        ComboActivity.comboArray.clear()
                                        parametersItem.all_childs.filterIndexed { _, categoryParametersItem ->
                                            ComboActivity.comboArray.add(categoryParametersItem)
                                            true
                                        }
                                        ComboActivity.isComboDataLoaded = true
                                    }
                                    true
                                }
                            } catch (e: Exception) { }
                        }else{
                            setDataIsNotLoaded()
                        }
                    }

                    override fun onFailure(call: Call<Response>, t: Throwable) {
                        setDataIsNotLoaded()
                    }
                })
            }
        }
    }

    private fun setDataIsNotLoaded() {
        BGActivity.isBGDataLoaded = false
        FrameActivity.isFrameDataLoaded = false
        ComboActivity.isComboDataLoaded = false
        StickerActivity.isStickerDataLoaded = false
        isStartedLoading = false
    }

    private fun initView() {
        imgBtnBack = findViewById(R.id.imgBtnBack)
        imgBtnSave = findViewById(R.id.imgBtnSave)
        imgBtnRedo = findViewById(R.id.imgBtnRedo)
        imgBtnUndo = findViewById(R.id.imgBtnUndo)
        imgShowMore = findViewById(R.id.imgShowMore)
        imgWaterMarkClose = findViewById(R.id.imgWaterMarkClose)
        imgWaterMark = findViewById(R.id.imgWaterMark)
        addTextMainLayout = findViewById(R.id.addTextMainLayout)
        addTextToolbar = findViewById(R.id.addTextToolbar)
        rlWaterMarlClick = findViewById(R.id.rlWaterMarlClick)
        mConstraintMenuBG = findViewById(R.id.constraintMenuBG)
        mConstraintMenuAddText = findViewById(R.id.constraintMenuAddText)
        mConstraintMenuSticker = findViewById(R.id.constraintMenuSticker)
        mConstraintMenuFrame = findViewById(R.id.constraintMenuFrame)
        mConstraintMenuCombo = findViewById(R.id.constraintMenuCombo)
        mConstraintMenuAddAnimation = findViewById(R.id.constraintMenuAddAnimation)
        mConstraintLayoutBG = findViewById(R.id.constraintLayoutBG)
        mContainer = findViewById(R.id.container)
        tempContainer = findViewById(R.id.tempContainer)
        stickerGridVertical = findViewById(R.id.stickerGridVertical)
        stickerGridHorizontal = findViewById(R.id.stickerGridHorizontal)
        stickerGridVertical1 = findViewById(R.id.stickerGridVertical1)
        stickerGridHorizontal1 = findViewById(R.id.stickerGridHorizontal1)
        stickerGridVertical2 = findViewById(R.id.stickerGridVertical2)
        stickerGridHorizontal2 = findViewById(R.id.stickerGridHorizontal2)

        clMainOptionContainer = findViewById(R.id.clMainOptionContainer)
        backgroundView = findViewById(R.id.backgroundView)
        frameView = findViewById(R.id.frameView)
        mProgressBar3 = findViewById(R.id.progressBar3)
        mRecyclerAddText = findViewById(R.id.recyclerAddText)
        recyclerColorStyle = findViewById(R.id.recyclerColorStyle)
        rvBackground = findViewById(R.id.rvBackground)
        rvFrame = findViewById(R.id.rvFrame)
        rvCombo = findViewById(R.id.rvCombo)
        mConstraintLayoutAddText = findViewById(R.id.constraintLayoutAddText)
        mConstraintSubLayoutGradient = findViewById(R.id.contraintSubLayoutGradient)
        mRecyclerGradientColor = findViewById(R.id.recyclerGradientColor)
        mConstraintSubLayoutTexture = findViewById(R.id.constraintSubLayoutTexture)
        mRecyclerTexture = findViewById(R.id.recyclerTexture)
        mConstraintSubLayoutShadowColor = findViewById(R.id.constraintSubLayoutShadowColor)
        mConstraintSubLayoutTextBorder = findViewById(R.id.constraintSubLayoutTextBorder)
        mConstraintSubLayoutTextSpace = findViewById(R.id.constraintSubLayoutTextSpace)
        mSeekTextSpaceSize = findViewById(R.id.seekTextSpaceSize)
        mTxtSpacePercent1 = findViewById(R.id.txtSpacePercent1)
        mTxtSpacePercent2 = findViewById(R.id.txtSpacePercent2)
        mConstraintSubLayoutTextCurve = findViewById(R.id.constraintSubLayoutTextCurve)
        imgBtnResetCurve = findViewById(R.id.imgBtnReset)
        mSeekCurve = findViewById(R.id.seekTextCurve)
        mSeekGlow = findViewById(R.id.seekTextGlow)
        mSeekStroke = findViewById(R.id.seekTextStroke)
        mConstraintLayoutStickerCategory = findViewById(R.id.constraintLayoutStickerCategory)
        mRecyclerStickerCategory = findViewById(R.id.recyclerStickerCategory)
        mConstraintSubLayoutStickerItems = findViewById(R.id.constraintSubLayoutStickerItems)
        mRecyclerStickerItems = findViewById(R.id.recyclerStickerItems)
        mConstraintSubLayoutText3d = findViewById(R.id.constraintSubLayoutText3d)
        llShowTextFun = findViewById(R.id.llShowTextFun)
        textFunction = findViewById(R.id.textFunction)
        constraintFontStyle = findViewById(R.id.constraintFontStyle)
        constraintShadow = findViewById(R.id.constraintShadow)
        constraintColor = findViewById(R.id.constraintColor)
        constraintPattern = findViewById(R.id.constraintPattern)
        constraintCurve = findViewById(R.id.constraintCurve)
        constraint3D = findViewById(R.id.constraint3D)
        constraintFontType = findViewById(R.id.constraintFontType)
        constraintFontGlow = findViewById(R.id.constraintFontGlow)
        consFontStyleList = findViewById(R.id.consFontStyleList)
        consColorList = findViewById(R.id.consColorList)
        consPatternList = findViewById(R.id.consPatternList)
        consCurveText = findViewById(R.id.consCurveText)
        cons3DText = findViewById(R.id.cons3DText)
        consTextFontType = findViewById(R.id.consTextFontType)
        consTextFontGlow = findViewById(R.id.consTextFontGlow)
        consTextFontStroke = findViewById(R.id.consTextFontStroke)
        consShadowText = findViewById(R.id.consShadowText)
        imgTextCase = findViewById(R.id.imgTextCase)
        imgFontTypeBold = findViewById(R.id.imgFontTypeBold)
        imgFontTypeItalic = findViewById(R.id.imgFontTypeItalic)
        imgFontTypeUnderline = findViewById(R.id.imgFontTypeUnderline)
        txtFontTypeAA = findViewById(R.id.txtFontTypeAA)
        imgBtnResetFontType = findViewById(R.id.imgBtnResetFontType)
        imgBtnResetFontGlow = findViewById(R.id.imgBtnResetFontGlow)
        imgBtnResetFontStroke = findViewById(R.id.imgBtnResetFontStroke)
        imgFontGlowColor = findViewById(R.id.imgFontGlowColor)
        imgFontStrokeColor = findViewById(R.id.imgFontStrokeColor)
        mSeek3Dx = findViewById(R.id.seek3Dx)
        mSeek3Dy = findViewById(R.id.seek3Dy)
        mSeekOpacity = findViewById(R.id.seekOpacity)
        mSeekSpace = findViewById(R.id.seekSpace)
        clMainOptionView = findViewById(R.id.clMainOptionView)
        mImgBackBg = findViewById(R.id.imgBackbg)
        mImgBackaddText = findViewById(R.id.imgBackaddText)
        mConstraintLayoutMenu = findViewById(R.id.constraintLayoutaddMenu)
        mImgBackaddSticker = findViewById(R.id.imgBacksticker)
        mRecyclerFontStyle = findViewById(R.id.recyclerFontStyle)
        mRecyclerColor = findViewById(R.id.recyclerColor)
        constraintSubLayoutFontStyle = findViewById(R.id.contraintSubLayoutFontStyle)
        mImgBackFont = findViewById(R.id.imgBackFont)
        mImgBackSpace = findViewById(R.id.imgBackSpace)
        mConstraintLayoutaddSticker = findViewById(R.id.constraintLayoutaddSticker)
        mConstraintSubLayoutStickerCategoryItems =
            findViewById(R.id.constraintSubLayoutStickerCategoryItems)
        mImgBackStickerItemCategory = findViewById(R.id.imgBackStickerItemCategory)
        mRecyclerFrame = findViewById(R.id.recyclerFrame)
        mConstraintFrameLayout = findViewById(R.id.constraintLayoutFrame)
        constraintSubLayoutColor = findViewById(R.id.contraintSubLayoutColor)
        mSingleColorText = findViewById(R.id.tvSingleColor)
        tvGradientColor = findViewById(R.id.tvGradientColor)
        mMultiColorText = findViewById(R.id.tvMultipleColor)
        mBackgroundText = findViewById(R.id.tvBackground)
        mBgColorText = findViewById(R.id.tvColor)
        mRecyclerBGColor = findViewById(R.id.recyclerbgcolor)
    }

    @SuppressLint("NewApi", "Range", "CutPasteId")
    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private fun initViewAction() {

        networkReceiver = ConnectionReceiver(this)
        intentFilter = IntentFilter("com.text.art.fancy.creator")

        Handler(Looper.getMainLooper()).postDelayed({
            isFirstTextTemplate = true
        }, 1500)

        fontProvider =
            FontProvider(resources)

//        addShadowSticker("Text Art", null, true, null)

        loadFontStyle()
        mStickerModel = StickerModel()
        gradientColorAdapter()
        multiColorAdapter()
        loadTextTexture()
        load3DTextData()
//        loadGlowTextData()
        loadFontTextTypeData()
        try { loadFontGlowData() } catch (e: Exception) { }
        loadStrokeData()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            loadCurveTextData()
        }
//        shadowDataSet()
        imgBtnBack.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 500) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            onBackPressed()
        }
        imgBtnRedo.setOpacity(0.5F)
        imgBtnUndo.click {
            /*if (SystemClock.elapsedRealtime() - lastClickTime < 300) {
                showToast("please wait..!!!")
                return@click
            }
            lastClickTime = SystemClock.elapsedRealtime()*/
            if (mUndo.isNullOrEmpty() || mUndo.size == 0){
                imgBtnUndo.setOpacity(0.5F)
                imgBtnRedo.setOpacity(1F)
                Log.d(TAG, "stickerView: performClick 2")
                stickerView.performClick()
//                showToast("No more undo available")
            }else{
                imgBtnUndo.setOpacity(1F)
                val uSize = mUndo.size-1
                isFromUndo = true
                mUndo[uSize].also {
                    performUndoRedo(it)
                }
//                addUndo()
            }
        }
        imgBtnRedo.click {
            /*if (SystemClock.elapsedRealtime() - lastClickTime < 300) {
                showToast("please wait..!!!")
                return@click
            }
            lastClickTime = SystemClock.elapsedRealtime()*/
            if (mRedo.isNullOrEmpty() || mRedo.size == 0){
                imgBtnUndo.setOpacity(1F)
                imgBtnRedo.setOpacity(0.5F)
//                stickerView.performClick()
//                showToast("No more redo available")
            }else{
                imgBtnRedo.setOpacity(1F)
                val rSize = mRedo.size-1
                isFromUndo = false
                mRedo[rSize].also {
                    performUndoRedo(it)
                }
            }
        }

        constraintFontStyle.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            imgFontSyle!!.setColorFilter(Color.parseColor("#1379ca"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            consFontStyleList.show()
            consColorList.hide()
            consCurveText.hide()
            consPatternList.hide()
            cons3DText.hide()
            consShadowText.hide()
            consTextFontType.hide()
            consTextFontGlow.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "Font"
        }
        constraintColor.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            imgColor!!.setColorFilter(Color.parseColor("#1379ca"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txtColor.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            consColorList.show()
            consCurveText.hide()
            consFontStyleList.hide()
            cons3DText.hide()
            consPatternList.hide()
            consShadowText.hide()
            consTextFontType.hide()
            consTextFontGlow.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "Color"
        }
        constraintPattern.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            imgPattern!!.setColorFilter(Color.parseColor("#1379ca"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            consPatternList.show()
            consFontStyleList.hide()
            consColorList.hide()
            consCurveText.hide()
            cons3DText.hide()
            consShadowText.hide()
            consTextFontType.hide()
            consTextFontGlow.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "Pattern"
        }
        constraintCurve.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            if (!isFromUndoRedo) {
                index?.let { i ->
                    if (stickerList[i].isMultiColor) {
                        showToast("You can't use curve while using multiple color")
                        return@click
                    }
                    if ((stickerList[i].bold || stickerList[i].italic || stickerList[i].underline)) {
                        showToast("You can't use curve while using font type")
                        return@click
                    }
                    if (stickerList[i].isApplyStroke){
                        showToast("You can't use curve while using stroke")
                        return@click
                    }
                }
            }

            imgCurve!!.setColorFilter(Color.parseColor("#1379ca"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            consCurveText.show()
            consFontStyleList.hide()
            consPatternList.hide()
            consColorList.hide()
            cons3DText.hide()
            consShadowText.hide()
            consTextFontType.hide()
            consTextFontGlow.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "Curve"
        }
        constraint3D.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            img3D!!.setColorFilter(Color.parseColor("#1379ca"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txt3D.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            cons3DText.show()
            consCurveText.hide()
            consFontStyleList.hide()
            consPatternList.hide()
            consColorList.hide()
            consShadowText.hide()
            consTextFontType.hide()
            consTextFontGlow.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "3D"
        }
        constraintShadow.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            imgShadow!!.setColorFilter(Color.parseColor("#1379ca"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            consShadowText.show()
            cons3DText.hide()
            consCurveText.hide()
            consFontStyleList.hide()
            consPatternList.hide()
            consColorList.hide()
            consTextFontType.hide()
            consTextFontGlow.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "Shadow"
        }
        constraintFontType.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            try {
                //TODO Remove Toast Functionality
//                if (stickerList[index!!].isMultiColor) {
//                    showToast("You can't use font type while using multiple color")
//                    return@click
//                } else if (stickerList[index!!].isCurve) {
//                    showToast("You can't use font type while using curve")
//                    return@click
//                }
            } catch (e: Exception) {
                Log.d(TAG, "initViewAction: ${e.message}")
            }

            imgFontType!!.setColorFilter(Color.parseColor("#1379ca"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            consTextFontType.show()
            consShadowText.hide()
            cons3DText.hide()
            consCurveText.hide()
            consFontStyleList.hide()
            consPatternList.hide()
            consColorList.hide()
            consTextFontGlow.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "FontType"

        }
        constraintFontGlow.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            try {
                //TODO Remove Toast Functionality
//                stickerList[index!!].let {
//                    if (it.isMultiColor) {
//                        showToast("You can't use font glow while using multiple color")
//                        return@click
//                    } else if (it.isGradient) {
//                        showToast("You can't use font glow while using gradient color")
//                        return@click
//                    } else if (it.isPattern) {
//                        showToast("You can't use font glow while using pattern")
//                        return@click
//                    }
//                }
            } catch (e: Exception) {
                Log.d(TAG, "initViewAction: ${e.message}")
            }

            imgFontGlow!!.setColorFilter(Color.parseColor("#1379ca"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))
            imgFontStroke!!.setColorFilter(Color.parseColor("#000000"))

            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.black))

            consTextFontGlow.show()
            consShadowText.hide()
            cons3DText.hide()
            consCurveText.hide()
            consFontStyleList.hide()
            consPatternList.hide()
            consColorList.hide()
            consTextFontType.hide()
            consTextFontStroke.hide()

//            stickerList[index!!].lastAction = "Glow"
        }
        constraintFontStroke.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            imgFontStroke!!.setColorFilter(Color.parseColor("#1379ca"))
            imgFontGlow!!.setColorFilter(Color.parseColor("#000000"))
            imgFontSyle!!.setColorFilter(Color.parseColor("#000000"))
            imgShadow!!.setColorFilter(Color.parseColor("#000000"))
            imgColor!!.setColorFilter(Color.parseColor("#000000"))
            imgPattern!!.setColorFilter(Color.parseColor("#000000"))
            imgCurve!!.setColorFilter(Color.parseColor("#000000"))
            img3D!!.setColorFilter(Color.parseColor("#000000"))
            imgFontType!!.setColorFilter(Color.parseColor("#000000"))

            txtFontStroke.setTextColor(ContextCompat.getColor(this, R.color.colorIconSelected))
            txtFontGlow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontStyle.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtShadow.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtColor.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtPattern.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtCurve.setTextColor(ContextCompat.getColor(this, R.color.black))
            txt3D.setTextColor(ContextCompat.getColor(this, R.color.black))
            txtFontType.setTextColor(ContextCompat.getColor(this, R.color.black))

            consTextFontStroke.show()
            consTextFontGlow.hide()
            consShadowText.hide()
            cons3DText.hide()
            consCurveText.hide()
            consFontStyleList.hide()
            consPatternList.hide()
            consColorList.hide()
            consTextFontType.hide()

//            stickerList[index!!].lastAction = "Glow"
        }

        imgPatternGallery?.click {
            if (mIsOpenGallery) {
                return@click
            }
            mIsOpenGallery = true
            choosePatternImageFromGallery()
        }
        imgCustomColor?.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            imgBtnSave.disabled()
            index?.let { i ->
                openColorPickerDialog(requestCode = TEXT_COLOR, selectedColor = stickerList[i].singleColorPos)
            }
            Handler(Looper.getMainLooper()).postDelayed( {
                imgBtnSave.enabled()
            }, 500)
        }
        imgSelectCustomFont?.click {
            showToast("We are working on it")
//            if (mIsOpenGallery) {
//                return@click
//            }
//            mIsOpenGallery = true
//            pickFontFamily()
        }
        rlWaterMarlClick.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            if (instence != null && instence!!.loadVideoAdMain(context) != null) {
                Log.d(TAG, "loadTextTexture: loaded")
                dialogWaterMark = WatchAdDialogFragment(
                    "Remove Watermark",
                    "Get PRO",
                    "To Permanently Remove Watermark",
                    R.drawable.ic_dialog_remove_watermark,
                    "Watch Video Ad",
                    "To Edit Image Without Watermark"
                )
                { s, discardDialogFragment ->
                    when (s) {
                        "subscribe" -> {
                            discardDialogFragment.dismiss()
                            premiumLauncher.launch(Intent(context, SubscriptionActivity::class.java))
                            Constants.buyFromAddTextActivity = true
                        }
                        "watchAd" -> {
                            try {
                                discardDialogFragment.dismiss()
                                instence!!.loadVideoAdMain(context)
                                showAdReward(0, "WaterMark")
                                discardDialogFragment.dismiss()
                            } catch (e: Exception) {
                            }
                        }
                        else -> {
                            discardDialogFragment.dismiss()
                        }
                    }
                }
                dialogWaterMark.isCancelable = false
                dialogWaterMark.show(supportFragmentManager, "dialog_remove_watermark")
            } else {
                Log.d(TAG, "loadTextTexture: not-loaded")
                if (isOnline()) {
                    Toast.makeText(context, "Try again later...", Toast.LENGTH_SHORT)
                        .show()
                } else {
                    Toast.makeText(
                        context,
                        "Please check internet connection.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        mImgBackBg.click {
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
            clMainOptionView.show()
            mConstraintLayoutBG?.hide()
        }

        stickerView.click {
            index = null
            selectedSticker?.borderVisibility = false
            selectedSticker = null
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
            isState = false

            imgCombo.setColorFilter(Color.parseColor("#000000"))
            textViewCombo.textColor = (Color.parseColor("#000000"))
            imgSelectFrame.setColorFilter(Color.parseColor("#000000"))
            txtViewFrame.textColor = (Color.parseColor("#000000"))
            imgSelectBG.setColorFilter(Color.parseColor("#000000"))
            txtViewBG.textColor = (Color.parseColor("#000000"))

            //TODO REMOVE LOCK
            /*for (i in stickerList.indices) {
                if (stickerList[i].sTICKER!!.borderVisibility)
                    stickerList[i].sTICKER!!.borderVisibility = false
            }*/

            /*with(context.stickerView){
                for (i in 0 until childCount) {
                    (getChildAt(i) as AutofitLayout).let {
                        if (it.borderVisibility)
                            it.borderVisibility = false
                    }
                }
            }*/



            clMainOptionView.show()
            clMainOptionContainer.hide()
            mConstraintLayoutAddText?.hide()
            mRecyclerAddText.disabled()
            mConstraintSubLayoutGradient.hide()
            mConstraintSubLayoutTexture.hide()
            mConstraintSubLayoutShadowColor?.hide()
            mConstraintSubLayoutTextBorder?.hide()
            mConstraintSubLayoutTextSpace?.hide()
            mConstraintSubLayoutTextCurve?.hide()
            mConstraintSubLayoutText3d.hide()
            constraintSubLayoutFontStyle.hide()
            constraintSubLayoutColor.hide()
            mConstraintLayoutBG?.hide()
            mConstraintLayoutAddText?.hide()
            mConstraintLayoutStickerCategory?.hide()
            mConstraintFrameLayout?.hide()
            mRecyclerAddText.disabled()
            clMainOptionView.show()
            llShowTextFun.hide()
            textFunction.hide()
        }

        mImgBackaddText.click {
            mConstraintMenuBG.enabled()
            mConstraintMenuAddText.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            isState = false

            originalText = ""

            clMainOptionView.show()
            mConstraintLayoutAddText?.hide()
            mRecyclerAddText.disabled()
            mRecyclerAddText.disabled()
            mRecyclerAddText.disabled()
            mRecyclerAddText.disabled()

        }
        mImgBackaddSticker.click {

            try {
//                mStickerView!!.hideBorder()
            } catch (e: Exception) {
            }
            clMainOptionView.show()
            mConstraintLayoutStickerCategory?.hide()
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
            try {
                for (i in 0 until context.stickerView.childCount) {
                    context.stickerView.getChildAt(i)
                        .findViewById<ConstraintLayout>(R.id.ll_view1).setBackground(null as Drawable?)
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnDelete) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnFlip) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnZoom) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnEdit) as ImageView).visibility = View.INVISIBLE
                    selectedSticker = null
                    index = null
                    mConstraintMenuBG.enabled()
                    mConstraintMenuAddText.enabled()
                    mConstraintMenuSticker.enabled()
                    mConstraintMenuFrame.enabled()
                }
            } catch (e: Exception) {
            }

        }

        mImgBackStickerItemCategory.click {
            mConstraintSubLayoutStickerItems?.hide()
            mConstraintSubLayoutStickerCategoryItems?.hide()
            mConstraintLayoutaddSticker?.show()
        }

        imgShowMore.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 200) return@click
            lastClickTime = SystemClock.elapsedRealtime()
            if (isOnline()){
                when(imgShowMore.tag){
                    "Background" -> startActivityForResult(Intent(this, BGActivity::class.java), 6666)
                    "Frame"      -> startActivityForResult(Intent(this, FrameActivity::class.java), 6666)
                    "Combo"      -> comboLauncher.launch(Intent(this, ComboActivity::class.java))
                }
            }else {
                showToast("Please check internet connection.")
            }
        }

        imgBtnSave.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 500) {
                return@click
            }
            lastClickTime = SystemClock.elapsedRealtime()
            Handler(Looper.getMainLooper()).postDelayed({
//                if (::dialog.isInitialized && !dialog.isShowing) {
                    generateImageOutput()
//                }
            },200)




            /*
            GlobalScope.launch {
                withContext(Dispatchers.IO) {
                    for (i in 0 until stickerView.childCount) {
                        when (stickerView.getChildAt(i).visibility) {
                            View.GONE -> {
                                Log.d(TAG, "initViewAction: GONE")
                                if (!isChkNullOrNot) {
                                    isChkNullOrNot = false
                                }
                            }
                            View.VISIBLE -> {
                                Log.d(TAG, "initViewAction: VISIBLE")

                                isChkNullOrNot = true
                            }
                            View.INVISIBLE -> {
                                Log.d(TAG, "initViewAction: INVISIBLE")

                                if (!isChkNullOrNot) {
                                    isChkNullOrNot = false
                                }
                            }
                        }
                    }
                }
                withContext(Dispatchers.Main) {
                    Log.d(TAG, "initViewAction Main:  " + isChkNullOrNot)
                    if (isChkNullOrNot) {
                        try {
                            imgWaterMarkClose.hide()
                        } catch (e: Exception) {
                        }
                        clMainOptionView.show()
                        mConstraintMenuBG.enabled()
                        mConstraintMenuSticker.enabled()
                        mConstraintMenuFrame.enabled()
                        mConstraintMenuAddText.enabled()
                        mConstraintLayoutBG?.hide()
                        mConstraintSubLayoutGradient.hide()

                        mConstraintLayoutStickerCategory?.hide()
                        mConstraintLayoutAddText?.hide()
                        mRecyclerAddText.disabled()
                        mRecyclerAddText.disabled()
                        mConstraintMenuBG.enabled()
                        mConstraintSubLayoutShadowColor?.hide()
                        mConstraintSubLayoutText3d.hide()
                        mConstraintSubLayoutTexture.hide()
                        try {
                            for (i in 0 until context.stickerView.childCount) {
                                context.stickerView.getChildAt(i)
                                        .findViewById<ConstraintLayout>(R.id.ll_view1).background =
                                        null as Drawable?
                                (context.stickerView.getChildAt(i)
                                        .findViewById(R.id.btnDelete) as ImageView).visibility = View.INVISIBLE
                                (context.stickerView.getChildAt(i)
                                        .findViewById(R.id.btnFlip) as ImageView).visibility = View.INVISIBLE
                                (context.stickerView.getChildAt(i)
                                        .findViewById(R.id.btnZoom) as ImageView).visibility = View.INVISIBLE
                                (context.stickerView.getChildAt(i)
                                        .findViewById(R.id.btnEdit) as ImageView).visibility = View.INVISIBLE
                                selectedSticker = null
                                index!! = -1
                                mConstraintMenuBG.enabled()
                                mConstraintMenuAddText.enabled()
                                mConstraintMenuSticker.enabled()
                                mConstraintMenuFrame.enabled()
                            }
                            stickerView?.performClick()
                        } catch (e: Exception) {
                        }

                        mRecyclerAddText.disabled()
                        if (it.tag == "save") {
                            hideControlsUI(false)
                            dialogSave = DiscardDialogFragment(
                                    "Save",
                                    "Are you sure, you want to save\n this image?",
                                    R.drawable.ic_dialog_save,
                                    "Cancel",
                                    "Save"
                            )
                            { s, discardDialogFragment ->
                                if (s == "ok") {
                                    discardDialogFragment.dismiss()
                                    if (isInterstitialAdLoaded && !mIsSubScribe) {
                                        isFromDiscard = true
                                        Constants.isAdsShow = true
                                        interstitial!!.show()
                                    } else {
                                        finish()
                                    }
                                } else {
                                    discardDialogFragment.dismiss()
                                }
                            }
//                            dialogSave.isCancelable = false
                            dialogSave = DiscardDialogFragment(
                                    "Save",
                                    "Are you sure, you want to save\n this image?",
                                    R.drawable.ic_dialog_save,
                                    "Cancel",
                                    "Save"
                            )
                            { s, discardDialogFragment ->
                                if (s == "ok") {
                                    discardDialogFragment.dismiss()
                                    it.enabled()
                                    try {
                                        imgWaterMarkClose.hide()
                                    } catch (e: Exception) {
                                    }
                                    saveImage()
                                } else {

                                    discardDialogFragment.dismiss()
                                    try {
                                        imgWaterMarkClose.show()
                                    } catch (e: Exception) {
                                    }
                                    it.enabled()
                                }
                            }

                            dialogSave?.isCancelable = false
                            dialogSave?.show(supportFragmentManager, "dialog")
                            Handler(Looper.getMainLooper()).postDelayed({
                                mRecyclerAddText.enabled()
                            }, 500)
                        } else if (it.tag == "template") {
                            if (mSelectedTextTemplatePosition != 0) {
                                mSelectedTextTemplatePosition = 0
                                removeTextTemplateFragment()
                            } else {
                                showToast("Please select text template")
                                clMainOptionView.visibility = View.INVISIBLE
                                mConstraintMenuBG.disabled()
                                mConstraintMenuSticker.disabled()
                                mConstraintMenuFrame.disabled()
                                mConstraintMenuAddText.disabled()
                            }
                        } else {
                            if (Constants.stickerText != null && Constants.stickerText != "") {
                                hideKeyboard()
                                mStickerModel!!.typeface = Constants.typeface
                                mStickerModel!!.fontname = Constants.stickerTypeface
                                updateTextSticker(mStickerModel, Constants.stickerText, false)
                                onBackPressed()
                            } else {
                                if (context.stickerView.childCount!! > 0) {
                                    it.disabled()
                                    hideControlsUI(false)

                                    dialogSave = DiscardDialogFragment(
                                            "Save",
                                            "Are you sure, you want to save\n this image?",
                                            R.drawable.ic_dialog_save,
                                            "Cancel",
                                            "Save"
                                    )
                                    { s, discardDialogFragment ->
                                        if (s == "ok") {
                                            discardDialogFragment.dismiss()
                                            it.enabled()
                                            saveImage()
                                        } else {
                                            try {
                                                imgWaterMarkClose.show()
                                            } catch (e: Exception) {
                                            }
                                            discardDialogFragment.dismiss()
                                            it.enabled()
                                        }
                                    }
                                    dialogSave?.isCancelable = false

                                    dialogSave?.show(supportFragmentManager, "dialog")


                                } else {
                                    try {
                                        imgWaterMarkClose.show()
                                    } catch (e: Exception) {
                                    }
                                    showToast(getString(R.string.add_text))
                                }
                            }
                        }
                    } else {
                        try {
                            imgWaterMarkClose.show()
                        } catch (e: Exception) {
                        }
                        showToast(getString(R.string.add_text))
                        return@withContext
                    }

                }
            }
            */
        }

        imgBtnUndo.setOpacity(0.5F)

    }
    
    //TODO Call Whenever Want To Perform Undo Redo
    @SuppressLint("NotifyDataSetChanged")
    private fun performUndoRedo(it: UndoRedo) {
        Log.d(TAG, "performUndoRedo: Sticker Position ${it.position}")
        stickerView.findViewWithTag<AutofitLayout>(it.position)?.let { sticker ->
            if (sticker.visibility == View.VISIBLE){
                if (it.action != ACTION.ChangeBGNone    && it.action != ACTION.ChangeBG    &&
                    it.action != ACTION.ChangeFrameNone && it.action != ACTION.ChangeFrame &&
                    it.action != ACTION.ChangeComboNone && it.action != ACTION.ChangeCombo) {
                    Log.d(TAG, "performUndoRedo: stickerListener.onTouchDown 1")
                    stickerListener.onTouchDown(sticker)
                }else{
                    Log.d(TAG, "stickerView: performClick 10")
                    stickerView.performClick()
                }
            }
        }

        Log.d(TAG, "performUndoRedo: LastAction: ${it.action}")
        when(it.action){
            ACTION.ManageSticker       -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ManageSticker")
                stickerView.findViewWithTag<AutofitLayout>(it.position)?.let { sticker ->
                    Log.d(TAG, "stickerView: performClick 3")
                    stickerView.performClick()
                    if (sticker.visibility == View.VISIBLE){
                        sticker.hide()
                        if (mUndo.size == 1){
                            offlinePosition = -1
                            offlineBgPosition = -1
                            offlineFramePosition = -1
                            offlineComboPosition = -1
                            backgroundAdapter.notifyDataSetChanged()
                            frameAdapter.notifyDataSetChanged()
                            comboAdapter.notifyDataSetChanged()
                            backgroundView.setImageResource(0)
                            frameView.setImageResource(0)
                        }
                    }else{
                        sticker.show()
                        Log.d(TAG, "performUndoRedo: stickerListener.onTouchDown 3")
                        stickerListener.onTouchDown(sticker)
                    }
                }
            }
            ACTION.ChangePosition      -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangePosition")
                if ((it.operation.oldX == selectedSticker!!.x)
                    && it.operation.oldY == selectedSticker!!.y){
                    manageUndoRedoList()
                    /*if (isFromUndo) {
                        for(data in mUndo.reversed()){
                            if (data.action == it.action){
                                selectedSticker!!.translationX = data.operation.oldX
                                selectedSticker!!.translationY = data.operation.oldY
                                break
                            }
                        }
                    }*/
                    if (isFromUndo) {
                        imgBtnUndo.performClick()
                    }else {
                        imgBtnRedo.performClick()
                    }
                    return
                }
                selectedSticker!!.x = it.operation.oldX
                selectedSticker!!.y = it.operation.oldY
                Log.d(TAG, "performUndoRedo: ChangePosition: value x=${selectedSticker!!.translationX} y=${selectedSticker!!.translationY}")
//                showToast("From UndoRedo: x=${it.operation.oldX} y=${it.operation.oldY}")
            }
            /*ACTION.DoubleTap           -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform DoubleTap")
                if ((it.operation.scaleX == selectedSticker!!.scaleX)
                    && it.operation.scaleY == selectedSticker!!.scaleY) {
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }
                if(it.operation.scaleX == 0F){
                    selectedSticker!!.translationX = it.operation.oldX
                    selectedSticker!!.translationY = it.operation.oldY
                }else{
                    selectedSticker!!.scaleX = it.operation.scaleX
                    selectedSticker!!.scaleY = it.operation.scaleY
                    selectedSticker!!.rotation = it.operation.mRotation
                }

            }*/
            ACTION.ResizeSticker       -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ResizeSticker")
                Log.d(TAG, "performUndoRedo: ResizeSticker: Check x=${it.operation.width} y=${it.operation.height}")
                Log.d(TAG, "performUndoRedo: ResizeSticker: Check x=${selectedSticker!!.scaleX} y=${selectedSticker!!.scaleY}")

                selectedSticker?.let { sticker ->
                    if ((it.operation.width == sticker.layoutParams.width)
                        && it.operation.height == sticker.layoutParams.height) {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }

                    sticker.layoutParams.width = it.operation.width
                    sticker.layoutParams.height = it.operation.height
//                    sticker.text_iv.invalidate()
                    sticker.invalidate()
//                    sticker.performClick()
                }
//                showToast("From UndoRedo: x=${it.operation.scaleX} y=${it.operation.scaleY}")
            }
            ACTION.RotateSticker       -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform RotateSticker")
                Log.d(TAG, "addShadowSticker: ChangeWidth ChangeWidth ${it.operation.mWidth}")
                if ((it.operation.mRotation == (selectedSticker!!).rotation)) {
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }
                Log.d(TAG, "addShadowSticker: ChangeWidth ChangeWidth after${it.operation.mWidth}")
                selectedSticker!!.rotation = it.operation.mRotation
            }
            ACTION.ChangeFont          -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeFont")
                if (it.operation.fontPosition == fontPosition){
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }
                Log.d(TAG, "performUndoRedo: action font position ${it.operation.fontPosition}")
                if (it.operation.fontPosition == -1){
                    setFontTypeFace(-1, Typeface.createFromAsset(assets, "fonts/Default.ttf"))
                }else{
                    fontAdapter!!.clickFontStyle(it.operation.fontPosition)
                }
                fontAdapter!!.notifyDataSetChanged()
                Log.d(TAG, "updateSelectItem: mFontAdapter Undo Value")
            }
            ACTION.ChangeSingleColor   -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeSingleColor")
                index?.let { i ->
                    Log.d(TAG, "performUndoRedo: ACTION.ChangeSingleColor ${it.operation.singleColor} == ${stickerList[i].singleColorPos}")
                    if (isFromUndo) {
                        if (it.operation.singleColor == stickerList[i].singleColorPos && it.operation.singleColor != -1) {
//                        if (it.operation.mSingleColor == stickerList[i].getSingleColorPos()){
                            manageUndoRedoList()
                            if (isFromUndo)
                                imgBtnUndo.performClick()
                            else
                                imgBtnRedo.performClick()
                            return
                        }
                    } else {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                    if (it.operation.singleColor == -1) {
                        setTextColorFromColorPicker(Color.WHITE, isFromUndoRedo = true)
                        setTextFontTypeIfApplied()
                    } else {
                        setTextColorFromColorPicker(it.operation.singleColor, isFromUndoRedo = true)
                    }
                }
                isFromUndoRedo = false
            }
            ACTION.ChangeGradientColor -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeGradientColor")
                index?.let { i ->
                    Log.d(TAG, "performUndoRedo: ACTION.ChangeGradientColor ${it.operation.mGradientColor} == ${stickerList[i].positionGradient}")
//                    if (isFromUndo){
                        if (it.operation.mGradientColor == stickerList[i].positionGradient && it.operation.mGradientColor != -1){
                            manageUndoRedoList()
                            if (isFromUndo)
                                imgBtnUndo.performClick()
                            else
                                imgBtnRedo.performClick()
                            return
                        }
//                    }
                    if (it.operation.mGradientColor == -1){
                        gradientPosition = -1
                        gradientAdepter!!.notifyDataSetChanged()
                        setTextColorFromColorPicker(Color.WHITE, isFromUndoRedo = true)
                    }else{
                        isFromUndoRedo = true
                        gradientAdepter!!.clickGradientColor(it.operation.mGradientColor)
                        gradientAdepter!!.notifyDataSetChanged()
                    }
                }
                isFromUndoRedo = false
            }
            ACTION.ChangeMultipleColor -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeMultipleColor")
                index?.let { i ->
//                    if (isFromUndo) {
                    Log.d(TAG, "performUndoRedo: ACTION.ChangeMultipleColor ${it.operation.mMultiColor} == ${stickerList[i].positionMultiple}")
                    if (it.operation.mMultiColor == stickerList[i].positionMultiple && it.operation.mMultiColor != -1) {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
//                    }
                }

                if (it.operation.mMultiColor == -1){
                    multiColorPosition = -1
                    multiColorAdepter!!.notifyDataSetChanged()
                    setTextColorFromColorPicker(Color.WHITE, isFromUndoRedo = true)
                }else{
                    isFromUndoRedo = true
                    Log.d(TAG, "multiColorAdepter clickMultiColor 2")
                    multiColorAdepter!!.clickMultiColor(it.operation.mMultiColor)
//                    multiColorAdepter!!.notifyDataSetChanged()
                }
                isFromUndoRedo = false
            }
            ACTION.ChangePattern       -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangePattern")
                Log.d(TAG, "performUndoRedo: ACTION.ChangePattern ${it.operation.mPattern} == $patternPosition")
                if (it.operation.mPatternFromGallery){
                    //Selected From Gallery
                    if (it.operation.mPatternString == tPatterPath && isFromUndo){
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                    onPatternClick(-1, it.operation.mPatternString, isFromUndoRedo = true)
                }else{
                    //Selected From Adapter
                    if (it.operation.mPattern == patternPosition){
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                    onPatternClick(it.operation.mPattern, "", isFromUndoRedo = true)
                }
                index?.let { i -> stickerList[i].singleColorPos = -1 }
                isFromUndoRedo = false
            }
            ACTION.Change3Dx           -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform Change3Dx")
                Log.d(TAG, "onStopTrackingTouch: 3Dx ${it.operation.m3Dx}")
                val action = if (isFromUndo)
                    mUndo[mUndo.size-1].action
                else
                    mRedo[mRedo.size-1].action

                Log.d(TAG, "onStopTrackingTouch: action ${it.action} == $action")
                if (it.operation.m3Dx == mSeek3Dx?.progress) {
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }
                setText3Dx(it.operation.m3Dx)
                mSeek3Dx?.progress = it.operation.m3Dx
            }
            ACTION.Change3Dy           -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform Change3Dy")
                if (it.operation.m3Dy == mSeek3Dy?.progress) {
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }
                setText3Dy(it.operation.m3Dy)
                mSeek3Dy?.progress = it.operation.m3Dy
            }
            ACTION.ChangeBold          -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeBold")
                index?.let { i ->
                    if (it.operation.isBold == stickerList[i].bold) {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                    if (it.operation.isBold){
                        setFontTypeSelection(Constants.BOLD)
                        stickerList[i].bold = true
                    }else{
                        setFontTypeSelection(Constants.BOLD,false)
                        stickerList[i].bold = false
                    }
                    stickerList[i].isFontType = true
                    selectedSticker!!.setBoldFont()
                }
            }
            ACTION.ChangeItalic        -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeItalic")
                index?.let { i ->
                    if (it.operation.isItalic == stickerList[i].italic) {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                    if (it.operation.isItalic) {
                        setFontTypeSelection(Constants.ITALIC)
                        stickerList[i].italic = true
                    } else {
                        setFontTypeSelection(Constants.ITALIC,false)
                        stickerList[i].italic = false
                    }
                    selectedSticker!!.setItalicFont()
                    stickerList[i].isFontType = true
                }
            }
            ACTION.ChangeUnderline     -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeUnderline")
                index?.let { i ->
                    Log.d(TAG, "performUndoRedo: ACTION.ChangeUnderline ${it.operation.isUnderLine}")
                    if (it.operation.isUnderLine == stickerList[i].underline) {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                    if (it.operation.isUnderLine) {
                        setFontTypeSelection(Constants.UNDERLINE)
                        stickerList[i].underline = true
                        stickerList[i].isFontType = true
                        selectedSticker?.setUnderLine()
                    } else {
                        setFontTypeSelection(Constants.UNDERLINE, false)
                        stickerList[i].underline = false
                        selectedSticker?.removeUnderline()
                    }
//                    selectedSticker?.setUnderLineFont()
                }
            }
            ACTION.ChangeAA            -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeUnderline")
                index?.let { i ->
                    Log.d(TAG, "performUndoRedo: ACTION.ChangeAA ${it.operation.fontType} == ${stickerList[i].fontType}")
                    if (it.operation.fontType == stickerList[i].fontType) {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
//                    if (isFromUndo){
//                        when (it.operation.fontType) {
//                            "AA" -> {
//                                stickerList[i].setFontType("AA")
//                                imgTextCase.setImageResource(R.drawable.ic_a1)
//                                originalText = originalText.uppercase()
//                                selectedSticker!!.text_iv.text = originalText
//                                setFontTypeSelection(Constants.CASE)
//                            }
//                            "Aa" -> {
//                                stickerList[i].setFontType("Aa")
//                                imgTextCase.setImageResource(R.drawable.ic_a2)
//                                originalText = toTitleCase(originalText)
//                                selectedSticker!!.text_iv.text = originalText
//                                setFontTypeSelection(Constants.CASE)
//                            }
//                            "aa" -> {
//                                stickerList[i].setFontType("aa")
//                                imgTextCase.setImageResource(R.drawable.ic_a3)
//                                originalText = originalText.lowercase()
//                                selectedSticker!!.text_iv.text = originalText
//                                setFontTypeSelection(Constants.CASE)
//                            }
//                            else -> {
//                                stickerList[i].fontType = "Default"
//                                imgTextCase.setImageResource(R.drawable.ic_a1)
//                                setFontTypeSelection(Constants.CASE,false)
//                                originalText = toTitleCase(originalText)
//                                selectedSticker!!.text_iv.text = originalText
//                            }
//                        }
//                    }else{
                        when (it.operation.fontType) {
                            "AA" -> {
                                stickerList[i].fontType = "aa"
                                imgTextCase.setImageResource(R.drawable.ic_a3)
                                originalText = originalText.lowercase()
                                selectedSticker!!.text_iv.text = originalText
                                setFontTypeSelection(Constants.CASE)
                            }
                            "Aa" -> {
                                stickerList[i].fontType = "AA"
                                imgTextCase.setImageResource(R.drawable.ic_a1)
                                originalText = originalText.uppercase()
                                selectedSticker!!.text_iv.text = originalText
                                setFontTypeSelection(Constants.CASE)
                            }
                            "aa" -> {
                                stickerList[i].fontType = "Aa"
                                imgTextCase.setImageResource(R.drawable.ic_a2)
                                originalText = toTitleCase(originalText)
                                selectedSticker!!.text_iv.text = originalText
                                setFontTypeSelection(Constants.CASE)
                            }
                            else -> {
                                stickerList[i].fontType = "Default"
                                imgTextCase.setImageResource(R.drawable.ic_a1)
                                setFontTypeSelection(Constants.CASE,false)
                                originalText = toTitleCase(originalText)
                                selectedSticker!!.text_iv.text = originalText
                            }
//                        }
                    }
                    setTextFontTypeIfApplied()
                }
            }
            ACTION.ChangeGlowColor     -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeGlowColor")
                index?.let { i ->
                    Log.d(TAG, "performUndoRedo: ACTION.ChangeGlowColor ${it.operation.mGlowColor} == ${stickerList[i].glowColorPos}")
                    if (it.operation.mGlowColor == stickerList[i].glowColorPos){
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }

//                    if (it.operation.mGlowColor == 0){
                    if (it.operation.mGlowColor == -1){
                        setTextGlowColorFromColorPicker(Color.TRANSPARENT)
                    }else{
                        setTextGlowColorFromColorPicker(it.operation.mGlowColor)
                    }
                }
            }
            ACTION.ChangeGlowProgress  -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeGlowProgress")
                index?.let { i ->
                    if (it.operation.mGlowProgress == stickerList[i].glowRadius.toInt()) {
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }

                    val radius = it.operation.mGlowProgress
                    if (it.operation.mGlowProgress == 0 || stickerList[i].glowColorPos == -1) {
                        if (stickerList[i].glowColorPos != -1) {
                            selectedSticker!!.text_iv.setShadowLayer(0F, 0F, 0F, stickerList[i].glowColorPos)
                        }
                    } else {
                        selectedSticker!!.text_iv.setShadowLayer(radius.toFloat(), 0f, 0f, stickerList[i].glowColorPos)
                    }
                    Log.d(TAG, "performUndoRedo: mSeekGlow.progress 1 $radius")
                    mSeekGlow.progress = radius
                    stickerList[i].glowRadius = radius.toFloat()
                    Log.d(TAG, "performUndoRedo: mSeekGlow.progress set 2 ${stickerList[i].glowRadius}")
                }
            }
            ACTION.ShadowSpace         -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ShadowSpace")
                Log.d(TAG, "performUndoRedo: ShadowSpace ${it.operation.mShadowSpace}" )
                if (it.operation.mShadowSpace == mSeekSpace!!.progress){
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }

                mStickerModel!!.spaceProgress = 160 - it.operation.mShadowSpace
                mStickerModel!!.spaceProgress = 160 - it.operation.mShadowSpace
                Log.d(TAG, "performUndoRedo: ShadowSpace ${mStickerModel!!.spaceProgress}")
                try {
                    val flippedText = context.selectedSticker!!.findViewById(R.id.flippedText) as TextView
                    val constraintLayout = context.selectedSticker!!.findViewById(R.id.shadowLayout) as ConstraintLayout

                    val params: ViewGroup.MarginLayoutParams = constraintLayout.layoutParams as ViewGroup.MarginLayoutParams
                    if (it.operation.mShadowSpace - 110 < 0)
                        params.topMargin = 0
                    else
                        params.topMargin = it.operation.mShadowSpace - 110

                    constraintLayout.layoutParams = params
                    flippedText.invalidate()
                    stickerList[index!!].shadowSpace = it.operation.mShadowSpace
                    mSeekSpace!!.progress = it.operation.mShadowSpace

                    Log.d(TAG, "performUndoRedo: ShadowSpace marginTop ${params.topMargin}")
                    if (it.operation.mShadowSpace == 0)
                        stickerList[index!!].isFirstTimeApplyShadowSpace = true

                } catch (e: Exception) { }
                updateTextSticker(
                    mStickerModel,
                    mStickerModel!!.originalText,
                    false
                )
            }
            ACTION.ShadowOpacity       -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ShadowOpacity")
                if (it.operation.mShadowOpacity == mSeekOpacity!!.progress){
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }

                try {
                    val flippedText = context.selectedSticker!!.findViewById(R.id.flippedText) as TextView
                    val constraintLayout = context.selectedSticker!!.findViewById(R.id.shadowLayout) as ConstraintLayout
                    if (it.operation.mShadowOpacity == 0) {
                        flippedText.hide()
                        constraintLayout.hide()
                    } else {
                        flippedText.show()
                        flippedText.setOpacity(it.operation.mShadowOpacity.toFloat() / 50)
                        constraintLayout.show()
                    }
                    flippedText.invalidate()
                    stickerList[index!!].shadowOpacity = (it.operation.mShadowOpacity)
                    mSeekOpacity!!.progress = it.operation.mShadowOpacity
                    if (it.operation.mShadowOpacity == 0)
                        stickerList[index!!].isFirstTimeApplyShadowOpacity = true
                } catch (e: Exception) { }
            }
            ACTION.ChangeText          -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeText")
                Log.d(TAG, "performUndoRedo: ACTION.ChangeText ${it.operation.newText} : $originalText")
                if (it.operation.newText == originalText){
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }

                index?.let { i ->
                    originalText = it.operation.newText
                    selectedSticker?.text = originalText
                    stickerList[i].mainText = originalText
                    setTextFontTypeIfApplied()
                }
            }
            ACTION.SetCurve            -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform SetCurve")
                if (it.operation.mCurve==0){
                    /*val mX = selectedSticker!!.translationX
                    val mY = selectedSticker!!.translationY
                    imgBtnResetCurve!!.performClick()
                    selectedSticker!!.translationX = mX
                    selectedSticker!!.translationY = mY*/
//                    imgBtnResetCurve!!.performClick()
                }else{
                    setTextCurve(it.operation.mCurve)
                }
            }
            ACTION.ChangeBGColor       -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeBGColor")
                Log.d(TAG, "performUndoRedo: ACTION.ChangeBGColor ${it.operation.bgColor}  :  $tBgColor")
                if (tBgColor == it.operation.bgColor){
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }
                backgroundView.setColorFilter(0)
                backgroundView.scaleType = ImageView.ScaleType.FIT_CENTER
                /*if (it.operation.frameImage != ""){
                    setFrameImage(it.operation.frameImage)
                }else{
                    frameView.setImageResource(0)
                }*/
                Constants.mSelectedColorPos = it.operation.bgColor
                try {
                    Log.d(TAG, "stickerView: performClick 4")
                    stickerView.performClick()
                    if (it.operation.bgColor == 0){
                        tBgColor = 0
                        backgroundView.setImageResource(0)
                    }else{
                        tBgPath = ""
                        tFramePath = ""
                        tComboBgPath = ""
                        tComboFramePath = ""
                        tBgColor = it.operation.bgColor
                        bitmap = createBitmap(it.operation.bgColor, 255)
                        backgroundView.setImageBitmap(bitmap)
                        frameView.setImageResource(0)
                    }
                } catch (e: Exception) {
                    Log.d(TAG, "onActivityResult: ${e.localizedMessage}")
                }
            }
            ACTION.ChangeBGNone        -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeBGNone")
                if (isFromUndo){
                    if (tBgPath == it.operation.bgImage && it.operation.bgImageOffline == offlineBgPosition){
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                }else{
//                    manageUndoRedoList()
//                    if (isFromUndo)
//                        imgBtnUndo.performClick()
//                    else
//                        imgBtnRedo.performClick()
//                    return
                }
//                Log.d(TAG, "stickerView: performClick 5")
//                stickerView.performClick()
                tBgPath = ""
                offlinePosition = -1
                offlineBgPosition = -1
                backgroundAdapter.notifyDataSetChanged()
                backgroundView.setImageResource(0)
            }
            ACTION.ChangeBG            -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeBG")
                Log.d(TAG, "BG ACTION.ChangeBG: 1 ${it.operation.bgImage}")
                Log.d(TAG, "BG ACTION.ChangeBG: 1 tBgPath $tBgPath")
                Log.d(TAG, "BG ACTION.ChangeBG: 1 tBgPath ${it.operation.bgImageOffline}")

//                if (!isFromUndo){
                    if (tBgPath == it.operation.bgImage && it.operation.bgImageOffline == offlineBgPosition){
                        manageUndoRedoList()
                        Log.d(TAG, "BG ACTION.ChangeBG: SAME")
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
//                }
//                Log.d(TAG, "stickerView: performClick 6")
//                stickerView.performClick()
                Log.d(TAG, "BG ACTION.ChangeBG: UndoRedo ${it.operation.bgImage}")

                when {
//                    it.operation.frameImage != "" -> {
//                        Log.d(TAG, "Frame Added Here: Function 1 ")
//                        setFrameImage(it.operation.frameImage, isFromUndoRedo = true)
//                    }
                    offlineFramePosition != 0 && offlineFramePosition != -1 -> {
                        setOfflineFrameImage(offlineFramePosition, isFromUndoRedo = true)
                    }
//                    else -> {
//                        frameView.setImageResource(0)
//                    }
                }

                if (it.operation.bgImageOffline != 0){
                    setOfflineBackgroundImage(it.operation.bgImageOffline, isFromUndoRedo = true)
                }else{
                    setBackgroundImage(it.operation.bgImage, isFromUndoRedo = true)
                }

                if (!isFirstTimeApplyCombo){
                    if (isFromUndo) {
                        for(data in mUndo.reversed()){
                            if (data.action == ACTION.ChangeFrame){
                                Log.d(TAG, "Frame Added Here: Function 2")
                                setFrameImage(data.operation.frameImage, isFromUndoRedo = true)
                                break
                            }
                        }
                    }
                }
                isFromUndoRedo = false
            }
            ACTION.ChangeFrameNone     -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeFrameNone")
                Log.d(TAG, "performUndoRedo: ACTION.ChangeFrameNone tFramePath $tFramePath == ${it.operation.frameImage} ,offlineFramePosition $offlineFramePosition")
                if (isFromUndo){
                    if (tFramePath == it.operation.frameImage && it.operation.frameImageOffline == offlineFramePosition){
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                }
//                else{
//                    manageUndoRedoList()
//                    if (isFromUndo)
//                        imgBtnUndo.performClick()
//                    else
//                        imgBtnRedo.performClick()
//                    return
//                }

//                Log.d(TAG, "stickerView: performClick 7")
//                stickerView.performClick()
                tFramePath = ""
                offlinePosition = -1
                offlineFramePosition = -1
                frameAdapter.notifyDataSetChanged()
                frameView.setImageResource(0)
            }
            ACTION.ChangeFrame         -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeFrame")
                Log.d(TAG, "performUndoRedo: ChangeACTION Frame fr: ${it.operation.frameImage}")
                Log.d(TAG, "performUndoRedo: ChangeACTION Frame fr tFramePath: $tFramePath")
                Log.d(TAG, "performUndoRedo: ChangeACTION Frame fr tFramePath: ${it.operation.frameImageOffline}")

//                if (!isFromUndo){
                    if (tFramePath == it.operation.frameImage && it.operation.frameImageOffline == offlineFramePosition){
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
//                }
//                Log.d(TAG, "stickerView: performClick 8")
//                stickerView.performClick()
                Log.d(TAG, "performUndoRedo: ChangeACTION Frame bg: ${it.operation.bgImage}")
                when {
//                    it.operation.bgImage != "" -> {
//                        setBackgroundImage(it.operation.bgImage, true)
//                    }
                    offlineBgPosition != 0 && offlineBgPosition != -1 -> {
                        setOfflineBackgroundImage(offlineBgPosition, true)
                    }
//                    else -> {
//                        backgroundView.setImageResource(0)
//                    }
                }

                if (it.operation.frameImageOffline != 0){
                    setOfflineFrameImage(it.operation.frameImageOffline, isFromUndoRedo = true)
                }else{
                    setFrameImage(it.operation.frameImage, isFromUndoRedo = true)
                }

                Log.d(TAG, "Frame Added Here: Function 3")
                if (!isFirstTimeApplyCombo){
                    if (isFromUndo) {
                        for(data in mUndo.reversed()){
                            if (data.action == ACTION.ChangeBG){
                                isFromUndoRedo = true
                                Log.d(TAG, "BG Added Here: Function 3")
                                setBackgroundImage(data.operation.bgImage, true)
                                break
                            }
                        }
                    }
                }
                isFromUndoRedo = false
            }
            ACTION.ChangeComboNone     -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeComboNone")
                Log.d(TAG, "performUndoRedo: ACTION.ChangeComboNone 1 tComboBgPath $tComboBgPath, it.operation.bgImage ${it.operation.bgImage}")
                Log.d(TAG, "performUndoRedo: ACTION.ChangeComboNone 2 tComboFramePath $tComboFramePath, it.operation.frameImage ${it.operation.frameImage}")
                Log.d(TAG, "performUndoRedo: ACTION.ChangeComboNone 3 offlineComboPosition $offlineComboPosition, it.operation.bgImageOffline ${it.operation.bgImageOffline}")

                //TODO OLD
                /*if (!isFromUndo){
                    if (tComboBgPath == it.operation.bgImage && tComboFramePath == it.operation.frameImage && it.operation.bgImageOffline == offlineComboPosition){
                        manageUndoRedoList()
                        imgBtnRedo.performClick()
                        return
                    }
                }*/

                //TODO NEW TRY
                if (isFromUndo){
                    if (tComboBgPath == it.operation.bgImage && tComboFramePath == it.operation.frameImage && it.operation.bgImageOffline == offlineComboPosition){
                        manageUndoRedoList()
                        if (isFromUndo)
                            imgBtnUndo.performClick()
                        else
                            imgBtnRedo.performClick()
                        return
                    }
                }
//                else{
//                    manageUndoRedoList()
//                    if (isFromUndo)
//                        imgBtnUndo.performClick()
//                    else
//                        imgBtnRedo.performClick()
//                    return
//                }

//                Log.d(TAG, "stickerView: performClick 9")
//                stickerView.performClick()
                tComboBgPath = ""
                tComboFramePath = ""
                backgroundView.setImageResource(0)
                frameView.setImageResource(0)

                offlinePosition = -1
                offlineBgPosition = -1
                offlineFramePosition = -1
                offlineComboPosition = -1
                backgroundAdapter.notifyDataSetChanged()
                frameAdapter.notifyDataSetChanged()
                comboAdapter.notifyDataSetChanged()
            }
            ACTION.ChangeCombo         -> {
                Log.d(TAG, "Undo Redo Added ACTION.Perform ChangeCombo")
                Log.d(TAG, "performUndoRedo: ChangeACTION Combo bg: ${it.operation.bgImage}")
                Log.d(TAG, "performUndoRedo: ChangeACTION Combo fr: ${it.operation.frameImage}")
                Log.d(TAG, "performUndoRedo: ChangeACTION Combo tComboBgPath: $tComboBgPath \n tComboFramePath: $tComboFramePath")
                Log.d(TAG, "performUndoRedo: ChangeACTION Combo tComboFramePath: ${it.operation.bgImageOffline}")

                if (isFromUndo && mUndo.size == 1){
                    backgroundView.setImageResource(0)
                    frameView.setImageResource(0)
                }

                if (tComboBgPath == it.operation.bgImage && tComboFramePath == it.operation.frameImage && it.operation.bgImageOffline == offlineComboPosition){
                    manageUndoRedoList()
                    if (isFromUndo)
                        imgBtnUndo.performClick()
                    else
                        imgBtnRedo.performClick()
                    return
                }

//                Log.d(TAG, "stickerView: performClick 10")
//                stickerView.performClick()

                Log.d(TAG, "performUndoRedo: ChangeACTION Frame bg: ${it.operation.bgImage}")
                when {
                    it.operation.bgImage != "" -> {
                        setBackgroundImage(it.operation.bgImage, isFromUndoRedo = true)
                    }
                    it.operation.frameImage != "" -> {
                        setFrameImage(it.operation.frameImage, isFromUndoRedo = true)
                    }
//                    offlineBgPosition != 0 && offlineBgPosition != -1 -> {
//                        setOfflineBackgroundImage(offlineBgPosition, isFromUndoRedo = true)
//                    }
//                    offlineFramePosition != 0 && offlineFramePosition != -1 -> {
//                        setOfflineFrameImage(offlineFramePosition, isFromUndoRedo = true)
//                    }
                    else -> {
//                        backgroundView.setImageResource(0)
//                        frameView.setImageResource(0)
                    }
                }

                tComboBgPath = it.operation.bgImage
                tComboFramePath = it.operation.frameImage

                if (it.operation.bgImageOffline != 0){
                    setOfflineComboImage(it.operation.bgImageOffline, isFromUndoRedo = true)
                }else{
                    setComboImage(it.operation.bgImage,it.operation.frameImage, isFromUndoRedo = true)
                }

                Constants.isComboApply = true
                isFromUndoRedo = false
            }
        }
        manageUndoRedoList()
//        isFromUndoRedo = false
    }

    private fun manageUndoRedoList(){
        Log.d(TAG, "manageUndoRedoList: isFromUndo $isFromUndo")
        if (isFromUndo){
            addRedo()
        }else{
            addUndo()
        }
        if (isFromUndo){
            if(mUndo.isNotEmpty()) {
//                if (stickerView.getChildAt(mUndo[mUndo.size - 1].position).visibility == View.VISIBLE){
////                    setStickerSelectedByTag(mUndo[mUndo.size - 1].tag, "")
//                }
            }
        }
    }

    //TODO: Call Whenever Redo Button Click
    private fun addUndo() {
        mUndo.add(mRedo[mRedo.size-1])
        mRedo.removeAt(mRedo.size-1)
        imgBtnUndo.setOpacity(1F)
        if (mRedo.size == 0){
            imgBtnRedo.setOpacity(0.5F)
        }
//        if (mRedo.size == 0){
//            imgBtnRedo.alpha = 0.5F
//            Log.d(TAG, "addUndo: Undo1")
//        }else{
//            imgBtnRedo.alpha = 1F
//            Log.d(TAG, "addUndo: Undo2")
//        }
        Log.d(TAG, "addUndo: Undo3")
    }

    //TODO: Call Whenever Undo Button Click
    private fun addRedo() {
        mRedo.add(mUndo[mUndo.size-1])
        mUndo.removeAt(mUndo.size-1)
        imgBtnRedo.setOpacity(1F)
        if (mUndo.size == 0){
            imgBtnUndo.setOpacity(0.5F)
            Log.d(TAG, "addUndo: Redo1")
        }else{
            imgBtnUndo.setOpacity(1F)
            Log.d(TAG, "addUndo: Redo2")
        }
    }

    private fun disableAllFontOption(){
        constraintFontStyle.disabled()
        constraintShadow.disabled()
        constraintColor.disabled()
        constraintPattern.disabled()
        constraintCurve.disabled()
        constraint3D.disabled()
        constraintFontType.disabled()
        constraintFontGlow.disabled()
        imgBtnBack.disabled()
        imgBtnUndo.disabled()
        imgBtnRedo.disabled()
        imgBtnSave.disabled()
    }

    private fun enableAllFontOption(){
        constraintFontStyle.enabled()
        constraintShadow.enabled()
        constraintColor.enabled()
        constraintPattern.enabled()
        constraintCurve.enabled()
        constraint3D.enabled()
        constraintFontType.enabled()
        constraintFontGlow.enabled()
        imgBtnBack.enabled()
        imgBtnUndo.enabled()
        imgBtnRedo.enabled()
        imgBtnSave.enabled()
    }

    private fun loadStrokeData() {
        mSeekStroke.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                index?.let { i ->
                    setTextStrokeFromColorPicker(stickerList[i].strokeColor, p1)
                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })

        imgFontStrokeColor.click {
            openColorPickerDialog(requestCode = TEXT_STROKE, selectedColor = stickerList[index!!].strokeColor)
        }

        imgBtnResetFontStroke.click {
            setTextStrokeFromColorPicker(Color.TRANSPARENT,0)
            mSeekStroke.progress = 0
            stickerList[index!!].strokeColor = -1
        }
    }

    private fun loadFontGlowData() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mSeekGlow.thumb.colorFilter =
                BlendModeColorFilter(getColor(R.color.colorPrimary), BlendMode.SRC_ATOP)
        } else {
            mSeekGlow.thumb.setColorFilter(
                ContextCompat.getColor(this, R.color.colorPrimary),
                PorterDuff.Mode.MULTIPLY
            )
        }
        mSeekGlow.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser)
                    disableAllFontOption()
                index?.let { i ->
                    if (stickerList[i].glowColorPos != -1) {
                        selectedSticker!!.text_iv.setShadowLayer(progress.toFloat(), 0f, 0f, stickerList[i].glowColorPos)
                    }
                }

            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                //TODO Add Operation in UndoRedo
                Log.d(TAG, "onStopTrackingTouch: ${!isFromUndoRedo}")
//                if (!isFromUndoRedo){
                index?.let { i ->
                    stickerList[i].glowRadius = seekBar!!.progress.toFloat()
                    Log.d(TAG, "performUndoRedo: mSeekGlow.progress set 1 ${stickerList[i].glowRadius}")
                    if (stickerList[i].isFirstTimeGlowProgress){
                        Log.d(TAG, "onStopTrackingTouch: 0")
                        val operation = UndoRedo.Operation()
                        operation.mGlowProgress = 0
                        val action = UndoRedo(ACTION.ChangeGlowProgress, i, operation)
                        Log.d(TAG, "Undo Redo Added ACTION.ChangeGlowProgress 1")
                        mUndo.add(action)
                        manageUndoRedoButton()
                        stickerList[i].isFirstTimeGlowProgress = false
                    }
                    Log.d(TAG, "onStopTrackingTouch: 1")
                    val operation = UndoRedo.Operation()
                    operation.mGlowProgress = seekBar.progress
                    val action = UndoRedo(ACTION.ChangeGlowProgress, i, operation)
                    Log.d(TAG, "Undo Redo Added ACTION.ChangeGlowProgress 2")
                    mUndo.add(action)
                    manageUndoRedoButton()
                }
//                }
//                isFromUndoRedo = false
                enableAllFontOption()
            }

        })
        imgFontGlowColor.click {
            //TODO Remove Toast Functionality
//            if (stickerList[index!!].isGradient || stickerList[index!!].isPattern) {
//                showToast("You can't use text glow")
//                return@click
//            }

            openColorPickerDialog(requestCode = TEXT_GLOW, selectedColor = stickerList[index!!].glowColorPos)

        }

        imgBtnResetFontGlow.click {
            index?.let{ i ->
                stickerList[i].isGlow = false
                stickerList[i].glowColorPos = -1
                Log.d(TAG, "performUndoRedo: mSeekGlow.progress set 3 ${stickerList[i].glowRadius}")
                stickerList[i].glowRadius = 0F
                mSeekGlow.progress = 0
                selectedSticker!!.text_iv.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
                try { strokeMenu("curving") } catch (e: Exception) { }
            }
        }
    }

    @SuppressLint("CutPasteId")
    private fun loadFontTextTypeData() {
        imgFontTypeBold.click {
            index?.let { i ->
                if (stickerList[i].bold) {
                    setFontTypeSelection(Constants.BOLD,false)
                    stickerList[i].bold = false
                } else {
                    setFontTypeSelection(Constants.BOLD)
                    stickerList[i].bold = true
                }
                stickerList[i].isFontType = true
                selectedSticker!!.setBoldFont()

                //TODO Add Undo Redo OPERATION
                if(stickerList[i].isFirstTimeApplyBold){
                    val operation = UndoRedo.Operation()
                    operation.isBold = false
                    val action = UndoRedo(ACTION.ChangeBold, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()
                    stickerList[i].isFirstTimeApplyBold = false
                }
                val operation = UndoRedo.Operation()
                operation.isBold = stickerList[i].bold
                val action = UndoRedo(ACTION.ChangeBold, i, operation)
                mUndo.add(action)
                manageUndoRedoButton()

                //TODO Manage Colors
                if (stickerList[i].isMultiColor) {
                    Log.d(TAG, "multiColorAdepter clickMultiColor 3")
                    multiColorAdepter!!.clickMultiColor(stickerList[i].positionMultiple)
                }
            }
        }
        imgFontTypeItalic.click {
            originalText = originalText.trim()
            index?.let { i ->
                if (stickerList[i].italic) {
                    setFontTypeSelection(Constants.ITALIC,false)
                    stickerList[i].italic = false
                } else {
                    setFontTypeSelection(Constants.ITALIC)
                    stickerList[i].italic = true
                }
                selectedSticker!!.setItalicFont()
                stickerList[i].isFontType = true

                //TODO Add Undo Redo OPERATION
                if(stickerList[i].isFirstTimeApplyItalic){
                    val operation = UndoRedo.Operation()
                    operation.isItalic = false
                    val action = UndoRedo(ACTION.ChangeItalic, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()
                    stickerList[i].isFirstTimeApplyItalic = false
                }
                val operation = UndoRedo.Operation()
                operation.isItalic = stickerList[i].italic
                val action = UndoRedo(ACTION.ChangeItalic, i, operation)
                mUndo.add(action)
                manageUndoRedoButton()

                //TODO Manage Colors
                if (stickerList[i].isMultiColor) {
                    Log.d(TAG, "multiColorAdepter clickMultiColor 4")
                    multiColorAdepter!!.clickMultiColor(stickerList[i].positionMultiple)
                }
            }
        }
        imgFontTypeUnderline.click {
            index?.let { i ->
                if (stickerList[i].underline) {
                    setFontTypeSelection(Constants.UNDERLINE,false)
                    stickerList[i].underline = false
                } else {
                    setFontTypeSelection(Constants.UNDERLINE)
                    stickerList[i].underline = true
                    stickerList[i].isFontType = true
                }
                selectedSticker!!.setUnderLineFont()

                //TODO Add Undo Redo OPERATION
                if(stickerList[i].isFirstTimeApplyUnderLine){
                    val operation = UndoRedo.Operation()
                    operation.isUnderLine = false
                    val action = UndoRedo(ACTION.ChangeUnderline, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()
                    stickerList[i].isFirstTimeApplyUnderLine = false
                }
                val operation = UndoRedo.Operation()
                operation.isUnderLine = stickerList[i].underline
                val action = UndoRedo(ACTION.ChangeUnderline, i, operation)
                mUndo.add(action)
                manageUndoRedoButton()

                //TODO Manage Colors
                if (stickerList[i].isMultiColor) {
                    Log.d(TAG, "multiColorAdepter clickMultiColor 5")
                    multiColorAdepter!!.clickMultiColor(stickerList[i].positionMultiple)
                }

                selectedSticker!!.invalidate()
            }
        }
        txtFontTypeAA.click {
            index?.let { i ->
                if (stickerList[i].fontType == "Default") {
                    stickerList[i].fontType = "AA"
                }
                setFontTypeSelection(Constants.CASE)

                when (stickerList[i].fontType) {
                    "AA" -> {
                        stickerList[i].fontType = "Aa"
                        imgTextCase.setImageResource(R.drawable.ic_a1)
                        originalText = originalText.uppercase()
                        selectedSticker!!.text_iv.text = originalText
                        setTextFontTypeIfApplied()
                    }
                    "Aa" -> {
                         stickerList[i].fontType = "aa"
                         imgTextCase.setImageResource(R.drawable.ic_a2)
                         originalText = toTitleCase(originalText)
                         selectedSticker!!.text_iv.text = originalText
                         setTextFontTypeIfApplied()
                    }
                    "aa" -> {
                        stickerList[i].fontType = "AA"
                        imgTextCase.setImageResource(R.drawable.ic_a3)
                        originalText = originalText.lowercase()
                        selectedSticker!!.text_iv.text = originalText
                        setTextFontTypeIfApplied()
                    }
                    else -> {
                        stickerList[i].fontType = "Default"
                        imgTextCase.setImageResource(R.drawable.ic_a1)
                        setFontTypeSelection(Constants.CASE,false)
                    }
                }

                //TODO Add Undo Redo OPERATION
                if(stickerList[i].isFirstTimeApplyAA){
                    val operation = UndoRedo.Operation()
                    operation.fontType = "Default"
                    val action = UndoRedo(ACTION.ChangeAA, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()
                    stickerList[i].isFirstTimeApplyAA = false
                }
                val operation = UndoRedo.Operation()
                when(stickerList[i].fontType){
                    "AA" -> operation.fontType = "AA"
                    "Aa" -> operation.fontType = "Aa"
                    "aa" -> operation.fontType = "aa"
                    else -> operation.fontType = "Default"
                }
                val action = UndoRedo(ACTION.ChangeAA, i, operation)
                mUndo.add(action)
                manageUndoRedoButton()

                //TODO Manage Colors
                if (stickerList[i].isMultiColor) {
                    Log.d(TAG, "multiColorAdepter clickMultiColor 6")
                    multiColorAdepter!!.clickMultiColor(stickerList[i].positionMultiple)
                }
                selectedSticker!!.invalidate()
            }

            /*if (stickerList[index!!].isBold && stickerList[index!!].isItalic){
                stickerList[index!!].isBold = false
                stickerList[index!!].isItalic = false
                imgFontTypeBold.performClick()
                Log.d(TAG, "loadFontTextTypeData: BOLD ITALIC")
            }else if (stickerList[index!!].isBold){
                stickerList[index!!].isBold = false
                imgFontTypeBold.performClick()
                Log.d(TAG, "loadFontTextTypeData: BOLD")
            }else if (stickerList[index!!].isItalic){
                stickerList[index!!].isItalic = false
                imgFontTypeItalic.performClick()
                Log.d(TAG, "loadFontTextTypeData: ITALIC")
            }*/
        }
        imgBtnResetFontType.click {
            index?.let { i ->
                stickerList[i].isFontType = false
                stickerList[i].bold = false
                stickerList[i].italic = false
                stickerList[i].isBorderApply = false
                originalText = stickerList[i].originalText.toString()
                val spanString = SpannableString(originalText)
                spanString.setSpan(StyleSpan(Typeface.NORMAL), 0, spanString.length, 0)
                selectedSticker!!.text_iv.paintFlags = 0
                selectedSticker!!.text_iv.text = spanString
                val tempString = stickerList[i].originalText
                selectedSticker!!.text_iv.text = tempString
            }
        }
    }

    fun setUnderLineText() {
        try {
            val textToUnderLine = originalText.trim()
            val tvt = selectedSticker!!.text_iv.text.toString()
            var ofe = tvt.indexOf(textToUnderLine, 0)
            val underlineSpan = UnderlineSpan()
            val wordToSpan = SpannableString(selectedSticker!!.text_iv.text)
            var ofs = 0
            while (ofs < tvt.length && ofe != -1) {
                ofe = tvt.indexOf(textToUnderLine, ofs)
                if (ofe == -1) break else {
                    wordToSpan.setSpan(
                        underlineSpan,
                        ofe,
                        ofe + textToUnderLine.length,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    selectedSticker!!.text_iv.setText(wordToSpan, TextView.BufferType.SPANNABLE)
                }
                ofs = ofe + 1
            }
        } catch (e: Exception) { }
    }

    fun removeUnderlineText() {
        try {
            val ss = SpannableString(selectedSticker!!.text_iv.text.toString().trim())
            val uspans = ss.getSpans(
                0, ss.length,
                UnderlineSpan::class.java
            )
            for (us in uspans) {
                ss.removeSpan(us)
            }
            selectedSticker!!.text_iv.text = ss
        } catch (e: Exception) { }
        setTextFontTypeIfApplied()
    }

    private fun setTextFontTypeIfApplied(applyNormal: Boolean = true) {
        index?.let { i ->
            /** Bold And Italic ONLY*/
            val spanString = SpannableString(originalText)
            var isFontTypeApply = false
            if (stickerList[i].bold && stickerList[i].italic) {
                Log.d(TAG, "setTextFontTypeIfApplied: isBold isItalic")
                spanString.setSpan(StyleSpan(Typeface.BOLD_ITALIC), 0, spanString.length, 0)
                setFontTypeSelection(Constants.BOLD)
                setFontTypeSelection(Constants.ITALIC)
                isFontTypeApply = true
            }else{
                if (stickerList[i].bold) {
                    Log.d(TAG, "setTextFontTypeIfApplied: isBold")
                    spanString.setSpan(StyleSpan(Typeface.BOLD), 0, spanString.length, 0)
                    setFontTypeSelection(Constants.BOLD)
                    isFontTypeApply = true
                }else{
                    setFontTypeSelection(Constants.BOLD,false)
                }
                if (stickerList[i].italic) {
                    Log.d(TAG, "setTextFontTypeIfApplied: isItalic")
                    spanString.setSpan(StyleSpan(Typeface.ITALIC), 0, spanString.length, 0)
                    setFontTypeSelection(Constants.ITALIC)
                    isFontTypeApply = true
                }else{
                    setFontTypeSelection(Constants.ITALIC,false)
                }
            }

            if(!isFontTypeApply && applyNormal){
                Log.d(TAG, "setTextFontTypeIfApplied: applyNormal")
                spanString.setSpan(StyleSpan(Typeface.NORMAL), 0, spanString.length, 0)
            }
            selectedSticker!!.text_iv.text = spanString
        }
    }

    fun toTitleCase(string: String): String {
        var whiteSpace = true
        val builder = StringBuilder(string)
        val builderLength = builder.length
        for (i in 0 until builderLength) {
            val c = builder[i]
            if (whiteSpace) {
                if (!Character.isWhitespace(c)) {
                    builder.setCharAt(i, Character.toTitleCase(c))
                    whiteSpace = false
                }
            } else if (Character.isWhitespace(c)) {
                whiteSpace = true
            } else {
                builder.setCharAt(i, Character.toLowerCase(c))
            }
        }
        return builder.toString()
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun generateImageOutput() {
        var isChkNullOrNot = false

        GlobalScope.launch {
            withContext(Dispatchers.IO) {
                for (i in 0 until stickerView.childCount) {
                    when (stickerView.getChildAt(i).visibility) {
                        View.GONE -> {
                            Log.d(TAG, "initViewAction: GONE")
                            if (!isChkNullOrNot) {
                                isChkNullOrNot = false
                            }
                        }
                        View.VISIBLE -> {
                            Log.d(TAG, "initViewAction: VISIBLE")
                            isChkNullOrNot = true
                        }
                        View.INVISIBLE -> {
                            Log.d(TAG, "initViewAction: INVISIBLE")
                            if (!isChkNullOrNot) {
                                isChkNullOrNot = false
                            }
                        }
                    }
                }
            }
            withContext(Dispatchers.Main) {
                Log.d(TAG, "initViewAction Main:  $isChkNullOrNot")
                stickerView.performClick()
                Constants.isSaveUpdate = true
                if (isChkNullOrNot) {
                    imgWaterMarkClose.hide()
                    clMainOptionView.show()
                    mConstraintMenuBG.enabled()
                    mConstraintMenuSticker.enabled()
                    mConstraintMenuFrame.enabled()
                    mConstraintMenuAddText.enabled()
                    mConstraintLayoutBG?.hide()
                    mConstraintSubLayoutGradient.hide()

                    mConstraintLayoutStickerCategory?.hide()
                    mConstraintLayoutAddText?.hide()
                    mRecyclerAddText.disabled()
                    mRecyclerAddText.disabled()
                    mConstraintMenuBG.enabled()
                    mConstraintSubLayoutShadowColor?.hide()
                    mConstraintSubLayoutText3d.hide()
                    mConstraintSubLayoutTexture.hide()
                    try {
                        for (i in 0 until context.stickerView.childCount) {
                            selectedSticker = null
                            index = null
                            mConstraintMenuBG.enabled()
                            mConstraintMenuAddText.enabled()
                            mConstraintMenuSticker.enabled()
                            mConstraintMenuFrame.enabled()
                        }
                        Log.d(TAG, "stickerView: performClick 11")
                        stickerView.performClick()
                    } catch (e: Exception) { }

                    mRecyclerAddText.disabled()
                    if (context.stickerView.childCount > 0) {
                        imgBtnSave.disabled()
                        hideControlsUI(false)

                        dialogSave = DiscardDialogFragment(
                            "Save",
                            resources.getString(R.string.saveSentence),
                            R.drawable.ic_dialog_save,
                            "Cancel",
                            "Save"
                        )
                        { s, discardDialogFragment ->
                            if (s == "ok") {
                                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
                                discardDialogFragment.dismiss()
                                imgBtnSave.enabled()
                                saveImage()
                            } else {
                                try { imgWaterMarkClose.show() } catch (e: Exception) { }
                                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
                                discardDialogFragment.dismiss()
                                imgBtnSave.enabled()
                            }
                        }
                        dialogSave?.isCancelable = false
                        dialogSave?.show(supportFragmentManager, "dialog_save")
                    } else {
                        imgWaterMarkClose.show()
                        showToast(getString(R.string.add_text))
                    }
                } else {
                    imgWaterMarkClose.show()
                    showToast(getString(R.string.add_text))
                    return@withContext
                }
            }
        }
    }

//    @OptIn(DelicateCoroutinesApi::class)
//    private fun generateImageOutput() {
//        var isChkNullOrNot = false
//
//        GlobalScope.launch {
//            withContext(Dispatchers.IO) {
//                for (i in 0 until stickerView.childCount) {
//                    when (stickerView.getChildAt(i).visibility) {
//                        View.GONE -> {
//                            Log.d(TAG, "initViewAction: GONE")
//                            if (!isChkNullOrNot) {
//                                isChkNullOrNot = false
//                            }
//                        }
//                        View.VISIBLE -> {
//                            Log.d(TAG, "initViewAction: VISIBLE")
//                            isChkNullOrNot = true
//                        }
//                        View.INVISIBLE -> {
//                            Log.d(TAG, "initViewAction: INVISIBLE")
//                            if (!isChkNullOrNot) {
//                                isChkNullOrNot = false
//                            }
//                        }
//                    }
//                }
//            }
//            withContext(Dispatchers.Main) {
//                Log.d(TAG, "initViewAction Main:  $isChkNullOrNot")
//                stickerView.performClick()
//                Constants.isSaveUpdate = true
//                if (isChkNullOrNot) {
//                    imgWaterMarkClose.hide()
//                    clMainOptionView.show()
//                    mConstraintMenuBG.enabled()
//                    mConstraintMenuSticker.enabled()
//                    mConstraintMenuFrame.enabled()
//                    mConstraintMenuAddText.enabled()
//                    mConstraintLayoutBG?.hide()
//                    mConstraintSubLayoutGradient.hide()
//
//                    mConstraintLayoutStickerCategory?.hide()
//                    mConstraintLayoutAddText?.hide()
//                    mRecyclerAddText.disabled()
//                    mRecyclerAddText.disabled()
//                    mConstraintMenuBG.enabled()
//                    mConstraintSubLayoutShadowColor?.hide()
//                    mConstraintSubLayoutText3d.hide()
//                    mConstraintSubLayoutTexture.hide()
//                    try {
//                        for (i in 0 until context.stickerView.childCount) {
//                            selectedSticker = null
//                            index = null
//                            mConstraintMenuBG.enabled()
//                            mConstraintMenuAddText.enabled()
//                            mConstraintMenuSticker.enabled()
//                            mConstraintMenuFrame.enabled()
//                        }
//                        Log.d(TAG, "stickerView: performClick 11")
//                        stickerView.performClick()
//                    } catch (e: Exception) { }
//
//                    mRecyclerAddText.disabled()
//                    if (imgBtnSave.tag == "save") {
//                        hideControlsUI(false)
//                        dialogSave = DiscardDialogFragment(
//                            "Save",
//                            resources.getString(R.string.saveSentence),
//                            R.drawable.ic_dialog_save,
//                            "Cancel",
//                            "Save"
//                        )
//                        { s, discardDialogFragment ->
//                            if (s == "ok") {
//                                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
//                                discardDialogFragment.dismiss()
//                                if (isInterstitialAdLoaded && !mIsSubScribe) {
//                                    isFromDiscard = true
//                                    Constants.isAdsShow = true
//                                    interstitial!!.show()
//                                } else {
//                                    finish()
//                                }
//                            } else {
//                                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
//                                discardDialogFragment.dismiss()
//                            }
//                        }
//
//                        /*dialogSave = DiscardDialogFragment(
//                            "Save",
//                            resources.getString(R.string.saveSentence),
//                            R.drawable.ic_dialog_save,
//                            "Cancel",
//                            "Save"
//                        )
//                        { s, discardDialogFragment ->
//                            if (s == "ok") {
//                                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
//                                discardDialogFragment.dismiss()
//                                imgBtnSave.enabled()
//                                try { imgWaterMarkClose.hide() } catch (e: Exception) { }
//                                saveImage()
//                            } else {
//                                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
//                                discardDialogFragment.dismiss()
//                                try { imgWaterMarkClose.show() } catch (e: Exception) { }
//                                imgBtnSave.enabled()
//                            }
//                        }*/
//
////                        dialogSave?.dialog?.findViewById<ImageView>(R.id.btnClose)?.hide()
//                        dialogSave?.isCancelable = false
//                        dialogSave?.show(supportFragmentManager, "dialog_save")
//                        mRecyclerAddText.enabled()
//                    } else if (imgBtnSave.tag == "template") {
//                        if (mSelectedTextTemplatePosition != 0) {
//                            mSelectedTextTemplatePosition = 0
//                        } else {
//                            showToast("Please select text template")
//                            clMainOptionView.invisible()
//                            mConstraintMenuBG.disabled()
//                            mConstraintMenuSticker.disabled()
//                            mConstraintMenuFrame.disabled()
//                            mConstraintMenuAddText.disabled()
//                        }
//                    } else {
//                        if (Constants.stickerText != "") {
//                            hideKeyboard()
////                            mStickerModel!!.typeface = Constants.typeface
////                            mStickerModel!!.fontname = Constants.stickerTypeface
//                            updateTextSticker(mStickerModel, Constants.stickerText, false)
//                            onBackPressed()
//                        } else {
//                            if (context.stickerView.childCount > 0) {
//                                imgBtnSave.disabled()
//                                hideControlsUI(false)
//
//                                dialogSave = DiscardDialogFragment(
//                                    "Save",
//                                    resources.getString(R.string.saveSentence),
//                                    R.drawable.ic_dialog_save,
//                                    "Cancel",
//                                    "Save"
//                                )
//                                { s, discardDialogFragment ->
//                                    if (s == "ok") {
//                                        supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
//                                        discardDialogFragment.dismiss()
//                                        imgBtnSave.enabled()
//                                        saveImage()
//                                    } else {
//                                        try { imgWaterMarkClose.show() } catch (e: Exception) { }
//                                        supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
//                                        discardDialogFragment.dismiss()
//                                        imgBtnSave.enabled()
//                                    }
//                                }
//                                dialogSave?.isCancelable = false
//
//                                dialogSave?.show(supportFragmentManager, "dialog_save")
//
//                            } else {
//                                imgWaterMarkClose.show()
//                                showToast(getString(R.string.add_text))
//                            }
//                        }
//                    }
//                } else {
//                    imgWaterMarkClose.show()
//                    showToast(getString(R.string.add_text))
//                    return@withContext
//                }
//
//            }
//        }
//    }

    private fun initViewListener() {
        //TODO Manage stickerListener
        stickerListener = object : AutofitLayout.TouchEventListener {

            override fun onTouchDown(view: View?) {
                Log.d(TAG, "Sticker Event : onTouchDown TAG = ${view!!.tag} view view")
//                if (view.tag == index)
//                    return

                Log.d(TAG, "stickerView: performClick 12")
                stickerView.performClick()

                with(context.stickerView){
                    selectedSticker = view as AutofitLayout
                    index = view.tag.toString().toInt()
                    index?.let { pos ->
                        selectedSticker?.borderVisibility = true
                        originalText = selectedSticker!!.text.toString()
                        if (stickerList[pos].tYPE == TEXT_STICKER){
                            llShowTextFun.show()
                            textFunction.show()
                            updateSelectedSticker()
                        }
                    }
                }
            }

            override fun onTouchUp(view: View?) {
                Log.d(TAG, "Sticker Event : onTouchUp")
//                selectedSticker?.let { sticker ->
//                    //TODO Add Undo Redo OPERATION : Single Finger
//                    if ((sticker.x != 0F) && (sticker.y != 0F)){
//                        if (stickerList[index!!].isApplyPos) {
//                            val operation = UndoRedo.Operation()
//                            operation.oldX = (((stickerViewWidth - sticker.width) / 2).toFloat())
//                            operation.oldY = (((stickerViewHeight - sticker.height) / 2).toFloat())
//                            val action = UndoRedo(ACTION.ChangePosition, index!!, operation)
//                            Log.d(TAG, "Undo Redo Added ACTION.ChangePosition 1")
//                            mUndo.add(action)
//                            manageUndoRedoButton()
//                            stickerList[index!!].isApplyPos = false
//                        }
//                        val operation = UndoRedo.Operation()
//                        operation.oldX = sticker.x
//                        operation.oldY = sticker.y
//                        val action = UndoRedo(ACTION.ChangePosition, index!!, operation)
//                        Log.d(TAG, "Undo Redo Added ACTION.ChangePosition 2")
//                        mUndo.add(action)
//                        manageUndoRedoButton()
//                    }
//                }

            }

            override fun onTouchMove(view: View?) {
                Log.d(TAG, "Sticker Event : onTouchMove")
            }

            override fun onDelete(view: View?) {
                Log.d(TAG, "Sticker Event : onDelete")

                //TODO Add Operation in UndoRedo
                index?.let { i ->
                    val operation = UndoRedo.Operation()
                    val action = UndoRedo(ACTION.ManageSticker, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()
                    view?.hide()
                }
                Log.d(TAG, "stickerView: performClick 13")
                stickerView.performClick()
            }

            override fun onDoubleTap() {
                Log.d(TAG, "Sticker Event : onDoubleTap")
                index?.let { i ->
                    if (stickerList[i].tYPE == TEXT_STICKER)
                        onEdit(selectedSticker)
                }
            }

            override fun onEdit(view: View?) {
                Log.d(TAG, "Sticker Event : onEdit")
                index?.let { i ->
                    if (stickerList[i].tYPE == TEXT_STICKER) {
                        startEditing()
                    }
                }
            }

            override fun onFlip(view: View?) {
                Log.d(TAG, "Sticker Event : onFlip")
                index?.let { i ->
                    stickerList[i].isFlipped = !stickerList[i].isFlipped
                }
            }

            override fun onRotateDown(view: View?) {
                Log.d(TAG, "Sticker Event : onRotateDown")
            }

            override fun onRotateMove(view: View?) {
                Log.d(TAG, "Sticker Event : onRotateMove")
            }

            override fun onRotateUp(view: View?) {
                Log.d(TAG, "Sticker Event : onRotateUp")
                index?.let { pos ->
                    stickerList[pos].rOTATION = selectedSticker?.rotation!!
                }
            }

            override fun onScaleDown(view: View?) {
                Log.d(TAG, "Sticker Event : onScaleDown")
            }

            override fun onScaleMove(view: View?) {
                Log.d(TAG, "Sticker Event : onScaleMove")
                view?.let { _ ->
                    index?.let { i ->
                        if(stickerList[i].positionGradient != -1){
                            (view as AutofitLayout).setGradient(gradientColorList[stickerList[i].positionGradient].split(",".toRegex()).toTypedArray())
                        }
                    }
                }
            }

            override fun onScaleUp(view: View?) {
                Log.d(TAG, "Sticker Event : onScaleUp")
//                index?.let { i ->
//                    //TODO Add Undo Redo OPERATION
//                    val operation = UndoRedo.Operation()
//                    operation.width = view?.layoutParams?.width!!
//                    operation.height = view.layoutParams.height
//                    Log.d(TAG, "Sticker Event : W/H W :${view.layoutParams.width} H :${view.layoutParams.height}")
//                    val action = UndoRedo(ACTION.ResizeSticker, i, operation)
//                    mUndo.add(action)
//                    manageUndoRedoButton()
//                }
            }

        }

        mConstraintMenuBG.setOnClickListener(this)
        mConstraintMenuAddText.setOnClickListener(this)
        mConstraintMenuSticker.setOnClickListener(this)
        mConstraintMenuFrame.setOnClickListener(this)
        mConstraintMenuCombo.setOnClickListener(this)
        mConstraintMenuAddAnimation.setOnClickListener(this)
        mBtnMoreAPI?.setOnClickListener(this)
    }

    private fun saveImage() {
        isFromDiscard = false
        Log.d(TAG, "stickerView: performClick 14")
        stickerView.performClick()
        stickerGridHorizontal.hide()
        stickerGridVertical.hide()
        stickerGridHorizontal1.hide()
        stickerGridVertical1.hide()
        stickerGridHorizontal2.hide()
        stickerGridVertical2.hide()
        mContainer.isDrawingCacheEnabled = true
        val bitmap = Bitmap.createBitmap(backgroundView.width, backgroundView.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas((bitmap)!!)
        mContainer.draw(canvas)
        mBundle.clear()
        mBundle.putString("textart_save", "post")
        mFirebaseAnalytics.logEvent("textart_click", mBundle)

        mBundle.clear()
        mBundle.putString("save", "frame_${Constants.selectedFrame}")
        mFirebaseAnalytics.logEvent("textart_click", mBundle)

        mBundle.clear()
        mBundle.putString("save", "background_${Constants.selectedBg}")
        mFirebaseAnalytics.logEvent("textart_click", mBundle)

        mBundle.clear()
        mBundle.putString("save", "sticker_${Constants.selectedSticker}")
        mFirebaseAnalytics.logEvent("textart_click", mBundle)

        val myDir = File(
            Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES
            ), "TextArt"
        )

        if (!myDir.exists())
            myDir.mkdirs()

        val format = MySharedPreferences(
            this
        ).format
        val fName = "TextArt_${System.currentTimeMillis()}" + "." + format.lowercase()

        val file = File(myDir, fName)
        if (file.exists()) file.delete()
        mPath = "$myDir/$fName"

        saveImageToGallery(file, bitmap, format)
        notifySystemGallery(this, file)

        AdSettings.addTestDevice("ad901e97-f75f-4e97-8381-f6139372235c")
        if (mIsSubScribe) {
            val intent = Intent(context, FullMyPhotoActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            intent.putExtra("image", mPath)
            intent.putExtra("isCreation", false)
            intent.putExtra("type", "photo")
            Constants.showAdInSharePage = false
            startActivityForResult(intent, 2052)
        } else {
            if (!TextArtApplication.instance!!.requestNewInterstitialfb()) {
                if (isInterstitialAdLoaded) {
                    Constants.isAdsShow = true
                    interstitial!!.show()
                } else { // perform your action
                    val intent = Intent(context, FullMyPhotoActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    intent.putExtra("image", mPath)
                    intent.putExtra("isCreation", false)
                    intent.putExtra("type", "photo")
                    Constants.showAdInSharePage = true
                    startActivityForResult(intent, 2052)
                }
            } else {
                val interstitialAdListener = object : InterstitialAdListener {
                    override fun onInterstitialDisplayed(ad: Ad?) {
                        // Interstitial displayed callback
                        Log.d("TAG", "--> onInterstitialDisplayed")
                    }

                    override fun onInterstitialDismissed(ad: Ad?) {
                        // Interstitial dismissed callback
                        Log.d("TAG", "--> onInterstitialDismissed")
                        loadInterstitialAds()
                        val intent =
                            Intent(context, FullMyPhotoActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        intent.putExtra("image", mPath)
                        intent.putExtra("isCreation", false)
                        intent.putExtra("type", "photo")
                        startActivityForResult(intent, 2052)
                    }

                    override fun onError(ad: Ad?, adError: AdError) {
                        // Ad error callback
                        Log.d("TAG", "onError --> " + adError.getErrorMessage())
                        val intent =
                            Intent(context, FullMyPhotoActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        intent.putExtra("image", mPath)
                        intent.putExtra("isCreation", false)
                        intent.putExtra("type", "photo")
                        Constants.showAdInSharePage = true
                        startActivityForResult(intent, 2052)
                    }

                    override fun onAdLoaded(ad: Ad?) {
                        // Show the ad when it's done loading.
                        Log.d("TAG", "--> onAdLoaded")
                    }

                    override fun onAdClicked(ad: Ad?) {
                        // Ad clicked callback
                        Log.d("TAG", "--> onAdClicked")
                    }

                    override fun onLoggingImpression(ad: Ad?) {
                        // Ad impression logged callback
                        Log.d("TAG", "--> onLoggingImpression")
                    }
                }

                TextArtApplication.instance!!.mInterstitialAdfb!!.loadAd(
                    TextArtApplication.instance!!.mInterstitialAdfb!!.buildLoadAdConfig()
                        .withAdListener(interstitialAdListener).build()
                )
            }

        }
    }

    fun saveImageToGallery(file: File, bmp: Bitmap, format: String): File {
        try {
            val fos = FileOutputStream(file)
            if ((format == "jpg")) bmp.compress(
                Bitmap.CompressFormat.JPEG,
                100,
                fos
            ) else bmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
            fos.flush()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        mContainer.isDrawingCacheEnabled = false
        return file
    }

    fun notifySystemGallery(context: Context, file: File) {

        if (file.exists()) {
            try {
                val scanIntent =
                    Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                scanIntent.data = Uri.fromFile(file.absoluteFile)
                context.sendBroadcast(scanIntent)
            } catch (e: Exception) { }
            MediaScannerConnection.scanFile(
                context,
                arrayOf(Environment.getExternalStorageDirectory().toString()),
                null
            ) { _, _ ->
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(
                        Environment.getExternalStorageDirectory().toString()
                    ),
                    null
                ) { _, uri ->
                    try {
                        context.contentResolver.delete(
                            uri,
                            null, null
                        )
                        val scanIntent =
                            Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                        scanIntent.data = Uri.fromFile(file.absoluteFile)
                        context.sendBroadcast(scanIntent)
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    var centerX = 1f
    var centerY = 1f
    var startR: Float = 0f
    var startScale: Float = 1f
    var startX: Float = 0f
    var startY: Float = 0f

//    private var mCenterRotatePointer: FloatArray = FloatArray(2)
//    private var mCurrantPoint: FloatArray = FloatArray(2)
//    private var mOldDistance: Float = 0f

//    @SuppressLint("ClickableViewAccessibility", "CutPasteId")
//    fun addShadowSticker(
//        str: String?,
//        i: Drawable?,
//        lottieFile: String?,
//        isNewSticker: Boolean,
//        stickerModel: StickerModel?,
//    ) {
//        val inflate: View =
//            (getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
//                R.layout.shadow_view_child,
//                null as ViewGroup?,
//                false)
//        val textView = inflate.findViewById(R.id.realText) as AutoResizeTextView
//        val textView2 = inflate.findViewById(R.id.flippedText) as AutoResizeTextView
//        val lottieView = inflate.findViewById(R.id.lottieView) as LottieAnimationView
//        val btnDelete = inflate.findViewById(R.id.btnDelete) as ImageView
//        val btnFlip = inflate.findViewById(R.id.btnFlip) as ImageView
//        val btnZoom = inflate.findViewById(R.id.btnZoom) as ImageView
//        val imageView2 = inflate.findViewById(R.id.imgStickerN) as ImageView
//        val btnEdit = inflate.findViewById(R.id.btnEdit) as ImageView
//        val btnResizeText = inflate.findViewById(R.id.btnResizeText) as ImageView
//        val btnRotate = inflate.findViewById(R.id.btnRotate) as ImageView
//        val stickerGridVertical = inflate.findViewById(R.id.stickerGridVertical) as ImageView
//        val stickerGridHorizontal = inflate.findViewById(R.id.stickerGridHorizontal) as ImageView
//        val ll_view1 = inflate.findViewById(R.id.ll_view1) as ConstraintLayout
//        val constraintLayout = inflate.findViewById(R.id.shadowLayout) as ConstraintLayout
//        constraintLayout.hide()
////        textView.maxWidth = resources.getDimension(R.dimen._300sdp).toInt()
//
//        //Move & Rotate
////        var startA = 0f
//        var startRotation = 0.0f
//        var currentWidth = 0
//        var currentHeight = 0
//        var currentScaleX = 0F
//        var currentScaleY = 0F
//        var currentRotation = 0F
//        val rotationSpeed = 3
//        var firstRotation = 0F
//        var boolTop = true
//        var boolBottom = true
//        var x1 = 0F
//        var x2 = 0F
//        var y1 = 0F
//        var y2 = 0F
//        var previousScale = 0F
//        var savedMatrix = Matrix()
//
//        var mBool = true
//        var right = false
//        var left  = false
//        var mShowGrid = true
//
//        if (str == "" && lottieFile == null) {
//            //View : Sticker
//            textView.hide()
//            textView2.hide()
//            lottieView.hide()
//            imageView2.show()
//            imageView2.setImageDrawable(i)
//        } else if (i == null && lottieFile == null) {
//            //View : Text
//            textView.text  = str!!.trim()
//            textView2.text = str.trim()
//            if (str.length > 10){
//                textView .width = resources.getDimension(R.dimen._200sdp).toInt()
//                textView2.width = resources.getDimension(R.dimen._200sdp).toInt()
//            }else{
//                textView .width = resources.getDimension(R.dimen._150sdp).toInt()
//                textView2.width = resources.getDimension(R.dimen._150sdp).toInt()
//            }
//            originalText = "$str"
//            imageView2.hide()
//            lottieView.hide()
//            textView.show()
//        } else {
//            //View : Animation
//            textView.hide()
//            textView2.hide()
//            imageView2.hide()
//            lottieView.show()
//            lottieView.setAnimationFromJson(lottieFile)
//            originalText = lottieFile!!
//            textDelegate = TextDelegate(lottieView)
////            originalText = lottieFile!!
//        }
//
//        btnDelete.click {
//            try {
//                //TODO Add Operation in UndoRedo
//                val operation = UndoRedo.Operation()
//                val action = UndoRedo(ACTION.ManageSticker, index!!, inflate.tag.toString(),operation)
//                mUndo.add(action)
//                manageUndoRedoButton()
//
//                selectedSticker?.hide()
//                clMainOptionView.show()
//                mConstraintSubLayoutGradient.hide()
//                mConstraintSubLayoutTexture.hide()
//                mConstraintSubLayoutShadowColor?.hide()
//                mConstraintSubLayoutTextBorder?.hide()
//                mConstraintSubLayoutTextSpace?.hide()
//                mConstraintSubLayoutTextCurve?.hide()
//                mConstraintSubLayoutText3d.hide()
//                constraintSubLayoutFontStyle.hide()
//                constraintSubLayoutColor.hide()
//                mConstraintLayoutAddText?.hide()
//                mRecyclerAddText.disabled()
//                mRecyclerAddText.disabled()
//                mConstraintMenuBG.enabled()
//                mConstraintMenuAddText.enabled()
//                mConstraintMenuSticker.enabled()
//                mConstraintMenuFrame.enabled()
//                if (lottieFile != null && i == null) {
//                    isAnimAdded = false
//                    loadAllJsonInCacheDir()
//                    setLottieMultilayerAdapter()
//                }
//                setFontTypeSelection(Constants.BOLD,false)
//                setFontTypeSelection(Constants.ITALIC,false)
//                setFontTypeSelection(Constants.UNDERLINE,false)
//                setFontTypeSelection(Constants.CASE,false)
//                stickerView?.performClick()
//
//                /*loop@ for (i in 0 until stickerList!!.size) {
//                    if (stickerList!![i] == stickerList[index!!]){
//                        Log.d(TAG, "addShadowSticker: selectedStickerPo $selectStikerPo")
//                        stickerList!!.removeAt(i)
//                        return@click
//                    }
//                }*/
//
//            } catch (e: java.lang.Exception) {
//                e.printStackTrace()
//            }
//        }
//
//        btnEdit.click {
//            try {
//                if (lottieFile != null && i == null) {
//                    isAddAnimation = false
////                    startEditingAnimation()
//                    llShowAnimFun!!.show()
//                    Log.d(TAG, "addShadowSticker: LottieSticker")
//                }
//                if (str != null && i == null && lottieFile == null) {
//                    isAddText = false
//                    startEditing()
//                    Log.d(TAG, "addShadowSticker: TextSticker")
//                }
//
//            } catch (e: java.lang.Exception) {
//                e.printStackTrace()
//            }
//        }
//
//        val resizeEvent = object : ResizeStickerIcon {
//            override fun resizeIcon(i: Int, adjustResize: Boolean) {
//                val dp = intTodp(i)
////                val dp = i.toPx
////                val px = convertDpToPixel(dp.toFloat())
////                val sizeX = VideoSizeHelper.getX(mContainer as View, inflate, context)
////                val sizeY = VideoSizeHelper.getY(mContainer as View, inflate, context)
////                Log.d(TAG, "btnScaleAddSticker: sizeX $sizeX sizeY $sizeY")
//
//                Log.d(TAG, "btnScaleAddSticker: mContainer.hei ${mContainer.height} ${selectedSticker!!.height}")
//                Log.d(TAG, "btnScaleAddSticker: mContainer.scale xy ${selectedSticker!!.scaleX} ${selectedSticker!!.scaleY}")
//
////                if (2.0>selectedSticker!!.scaleX && selectedSticker!!.scaleX>1.40 ) {
//                    btnEdit.layoutParams.width = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //
//                    btnEdit.layoutParams.height = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //dp
//                    btnFlip.layoutParams.width = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //dp
//                    btnFlip.layoutParams.height = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //dp
//                    btnZoom.layoutParams.width = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //dp
//                    btnZoom.layoutParams.height = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //dp
//                    btnDelete.layoutParams.width = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //dp
//                    btnDelete.layoutParams.height = dp // ((mContainer.height / selectedSticker!!.scaleX) * 0.10).toInt() //dp
////                    btnRotate.layoutParams.width  = dp
////                    btnRotate.layoutParams.height = dp
//
//                    btnEdit.requestLayout()
//                    btnDelete.requestLayout()
//                    btnFlip.requestLayout()
//                    btnZoom.requestLayout()
////                    btnRotate.requestLayout()
////                }
//            }
//        }
//
//        fun hideAllStickerButton(){
//            btnEdit.hide()
//            btnFlip.hide()
//            btnZoom.hide()
//            btnDelete.hide()
//            btnResizeText.hide()
//            btnRotate.hide()
//        }
//        fun showAllStickerButton(){
//            btnFlip.show()
//            btnZoom.show()
//            btnDelete.show()
//            btnRotate.show()
//            if(i == null && lottieFile == null){
//                btnEdit.show()
//                btnResizeText.show()
//            }
//        }
//
//        btnZoom.setOnTouchListener { _, event ->
//            var lastScale = 30
//            try {
//                when (event.action and MotionEvent.ACTION_MASK) {
//                    MotionEvent.ACTION_DOWN -> {
//                        x1 = event.x
//                        y1 = event.y
//                        currentRotation = inflate.rotation
//                        currentScaleX   = inflate.scaleX
//                        currentScaleY   = inflate.scaleY
//
//    //                    savedMatrix.setScale(1f, 1f)
//    //                    mOldDistance = calculateDistance(mCenterRotatePointer, mCurrantPoint)
//
//                        // calculate center of image
//                        centerX = (selectedSticker?.left!! + selectedSticker?.right!!) / 2f
//                        centerY = (selectedSticker?.top!! + selectedSticker?.bottom!!) / 2f
//
//                        // recalculate coordinates of starting point
//                        startX = event.rawX - selectedSticker?.x!! + centerX
//                        startY = event.rawY - selectedSticker?.y!! + centerY
//
//                        // get starting distance and scale
//                        startR = hypot(
//                            (event.rawX - startX).toDouble(),
//                            (event.rawY - startY).toDouble()
//                        ).toFloat()
//                        startScale = selectedSticker?.scaleX!!
//
//                        //FOR ROTATION
//                        startRotation = inflate.rotation
//                        startA = Math.toDegrees(
//                            atan2(
//                                (event.rawX - startX).toDouble(),
//                                (event.rawY - startY).toDouble()
//                            )
//                        ).toFloat()
//
//                        if (stickerList[index!!].isApplyResize){
//                            //TODO Add Undo Redo OPERATION
//                            val operation = UndoRedo.Operation()
//                            operation.scaleX = selectedSticker!!.scaleX
//                            operation.scaleY = selectedSticker!!.scaleY
//                            val action = UndoRedo(ACTION.ResizeSticker, index!!, getSelectedStickerTag(),operation)
//                            mUndo.add(action)
//                            manageUndoRedoButton()
//                            stickerList[index!!].isApplyResize = false
//                        }
//
//                        hideAllStickerButton()
//                        disableAllFontOption()
//                    }
//                    MotionEvent.ACTION_UP -> {
//                        MyTouchMotion.isPressIcon = false
//                        //TODO Add Undo Redo OPERATION
//                        val operation = UndoRedo.Operation()
//                        operation.scaleX = selectedSticker!!.scaleX
//                        operation.scaleY = selectedSticker!!.scaleY
//                        val action = UndoRedo(ACTION.ResizeSticker, index!!, getSelectedStickerTag(),operation)
//                        mUndo.add(action)
//                        manageUndoRedoButton()
//                        Log.d(TAG, "performUndoRedo: ResizeSticker: x=${selectedSticker!!.scaleX} y=${selectedSticker!!.scaleY}")
//
//                        val newR = hypot(
//                            (event.rawX - startX).toDouble(),
//                            (event.rawY - startY).toDouble()
//                        ).toFloat()
//                        val newSize = startR / newR * startScale
//                        Log.d(TAG, "addShadowSticker: new Size $newSize")
//                        if (isMobile()) {
//                            when(newSize){
//                                in 0.00..1.0  ->{
//                                    lastScale = (lastScale*0.85).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                                in 1.01..1.50 ->{
//                                    lastScale = (lastScale*0.75).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                                in 1.51..2.00  ->{
//                                    lastScale = (lastScale*0.67).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                                in 2.01..2.50 ->{
//                                    lastScale = (lastScale*0.7).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                                in 2.51..3.00  ->{
//                                    lastScale = (lastScale*0.65).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                                in 3.01..3.50 ->{
//                                    lastScale = (lastScale*0.6).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                                in 3.51..4.00 ->{
//                                    lastScale = (lastScale*0.58).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                                else -> {
//                                    lastScale = (lastScale*0.58).toInt()
//                                    resizeEvent.resizeIcon(lastScale)
//                                }
//                            }
//                        }
//
//                        showAllStickerButton()
//                        enableAllFontOption()
//                    }
//                    MotionEvent.ACTION_POINTER_DOWN -> {}
//
//                    MotionEvent.ACTION_POINTER_UP -> {}
//
//                    MotionEvent.ACTION_MOVE -> {
//                        // calculate new distance
//    //                    val d = calculateDistance(mCenterRotatePointer, mCurrantPoint)
//    //                    val dis = (d / mOldDistance).toFloat()
//    //                    savedMatrix.postScale(dis, dis)
//
//                        // calculate new distance
//                        val newR = hypot(
//                            (event.rawX - startX).toDouble(),
//                            (event.rawY - startY).toDouble()
//                        ).toFloat()
//
//                        val newA =
//                            Math.toDegrees(
//                                atan2(
//                                    (event.rawX - startX).toDouble(),
//                                    (event.rawY - startY).toDouble()
//                                )
//                            ).toFloat()
//
//                        Log.d(TAG, "addShadowSticker: $newR $startR ")
//                        val newRotation = newA - startA + startRotation
//                        // set new scale
//                        val newScale = startR / newR * startScale
//    //                    inflate.scaleX = newScale
//    //                    inflate.scaleY = newScale
//    //                    inflate.rotation = newRotation
//
//                        //New Scalling
//                        x2 = event.x
//                        y2 = event.y
//                        val deltaX = x2 - x1
//                        val deltaY = y2 - y1
//                        Log.d(TAG, "btnResizeText:val x2 $x2")
//                        Log.d(TAG, "btnResizeText:val deltaX $deltaX")
//                        Log.d(TAG, "btnResizeText:val deltaY $deltaY")
//
//                        if (deltaY <= 0) {
//                            currentScaleX -= 0.04F
//                            currentScaleY -= 0.04F
//                        }else {
//                            currentScaleX += 0.04F
//                            currentScaleY += 0.04F
//                        }
//                        /*if (deltaY <= 0) {
//                            if (right){
//                                tmpInt++
//                                if (tmpInt == 10){
//                                    tmpInt = 0
//                                    right = false
//                                }
//                            }else{
//                                left = true
//                                currentScaleX -= 0.08F
//                                currentScaleY -= 0.08F
//                            }
//                        }else {
//                            if (left){
//                                tmpInt++
//                                if (tmpInt == 10){
//                                    tmpInt = 0
//                                    left = false
//                                }
//                            }else{
//                                right = true
//                                currentScaleX += 0.08F
//                                currentScaleY += 0.08F
//                            }
//                        }*/
//                        if (currentScaleX >= 0.50){
//                            inflate.scaleX = currentScaleX
//                            inflate.scaleY = currentScaleY
//                        }
//                        Log.d(TAG, "addShadowSticker: newScale=$newScale lastScale=$lastScale")
//                    }
//                }
//                Log.d(TAG, "setOnTouchListener: $_xDelta $_yDelta")
//
//                ll_view1.invalidate()
//            } catch (e: Exception) { }
//            true
//        }
//
//        btnZoom.click {
//            try {
//                MyTouchMotion.isPressIcon = true
//            } catch (e: java.lang.Exception) {
//                e.printStackTrace()
//            }
//        }
//
//        btnFlip.click {
//            try {
//                ll_view1.rotationY = ll_view1.rotationY + 180f
//            } catch (e: java.lang.Exception) {
//                e.printStackTrace()
//            }
//        }
//
//        btnResizeText.setOnTouchListener { _, event ->
//            //Try
//            try {
//                when (event.action and MotionEvent.ACTION_MASK) {
//                    MotionEvent.ACTION_DOWN -> {
//                        x1 = event.x
//                        Log.d(TAG, "addShadowSticker: 111 FirstPoint $x1")
//                        currentWidth = textView.width
//                        currentHeight = textView.height
//                        if (stickerList[index!!].isChangeWidth){
//                            //TODO Add Undo Redo OPERATION
//                            val operation = UndoRedo.Operation()
//                            operation.mWidth = (selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).width
//                            val action = UndoRedo(ACTION.ChangeWidth, index!!, getSelectedStickerTag(),operation)
//                            mUndo.add(action)
//                            manageUndoRedoButton()
//                            stickerList[index!!].isChangeWidth = false
//                            Log.d(TAG, "addShadowSticker: ChangeWidth ACTION_DOWN ${operation.mWidth}")
//                        }
//                    }
//                    MotionEvent.ACTION_UP -> {
//                        MyTouchMotion.isPressIcon = false
//                        //TODO Add Undo Redo OPERATION
//                        val operation = UndoRedo.Operation()
//                        operation.mWidth = (selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).width
//                        val action = UndoRedo(ACTION.ChangeWidth, index!!, getSelectedStickerTag(),operation)
//                        mUndo.add(action)
//                        manageUndoRedoButton()
//                        stickerList[index!!].currWidth = currentWidth
//                        Log.d(TAG, "addShadowSticker: ChangeWidth ACTION_UP ${operation.mWidth}")
//                    }
//                    MotionEvent.ACTION_POINTER_DOWN -> {}
//                    MotionEvent.ACTION_POINTER_UP -> {
//                        currentWidth = textView.width
//                    }
//                    MotionEvent.ACTION_MOVE -> {
//                        x2 = event.x
//                        val deltaX = x2 - x1
//
//                        if (!stickerList[index!!].isCurve){
//                            textView.width  = (currentWidth + deltaX.toInt())
//                            textView2.width = (currentWidth + deltaX.toInt())
//                        }
//
//                        try {
//                            strokeMenu("curving")
//                        } catch (e: Exception) { }
//                    }
//                }
//            } catch (e: Exception) { }
//
//            //Origin
//            /*when (event.action and MotionEvent.ACTION_MASK) {
//                MotionEvent.ACTION_DOWN -> {
//                    x1 = event.x
//                    currentWidth = textView.width
//                    currentHeight = textView.height
//                    if (stickerList[index!!].isChangeWidth){
//                        //TODO Add Undo Redo OPERATION
//                        val operation = UndoRedo.Operation()
//                        operation.mWidth = (selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).width
//                        val action = UndoRedo(ACTION.ChangeWidth, index!!, getSelectedStickerTag(),operation)
//                        mUndo.add(action)
//                        manageUndoRedoButton()
//                        stickerList[index!!].isChangeWidth = false
//                        Log.d(TAG, "addShadowSticker: ChangeWidth ACTION_DOWN ${operation.mWidth}")
//                    }
//                }
//                MotionEvent.ACTION_UP -> {
//                    MyTouchMotion.isPressIcon = false
//                    //TODO Add Undo Redo OPERATION
//                    val operation = UndoRedo.Operation()
//                    operation.mWidth = (selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).width
//                    val action = UndoRedo(ACTION.ChangeWidth, index!!, getSelectedStickerTag(),operation)
//                    mUndo.add(action)
//                    manageUndoRedoButton()
//                    stickerList[index!!].currWidth = currentWidth
//                    Log.d(TAG, "addShadowSticker: ChangeWidth ACTION_UP ${operation.mWidth}")
//                }
//                MotionEvent.ACTION_POINTER_DOWN -> {}
//
//                MotionEvent.ACTION_POINTER_UP -> {}
//                MotionEvent.ACTION_MOVE -> {
//                    x2 = event.x
//                    val deltaX = x2 - x1
//                    Log.d(TAG, "btnResizeText:val x2 $x2")
//                    Log.d(TAG, "btnResizeText:val deltaX $deltaX")
//
//                    if (deltaX <= 0)
//                        currentWidth -= 4
//                    else
//                        currentWidth += 4
//
//                    if (!stickerList[index!!].isCurve){
//                        textView.width  = currentWidth
//                        textView2.width = currentWidth
//                    }
//                    try {
//                        strokeMenu("curving")
//                    } catch (e: Exception) { }
//                }
//            }*/
//            true
//        }
//
//        fun showGrid(){
//            stickerGridVertical.show()
//            stickerGridHorizontal.show()
//        }
//        fun hideGrid(){
//            stickerGridVertical.hide()
//            stickerGridHorizontal.hide()
//        }
//
//        btnRotate.setOnTouchListener { _, event ->
//            try {
//                when (event.action and MotionEvent.ACTION_MASK) {
//                    MotionEvent.ACTION_DOWN -> {
//                        x1 = event.x
//                        currentRotation = inflate.rotation
//                        firstRotation   = inflate.rotation
//                        hideAllStickerButton()
//                        disableAllFontOption()
//    //                    textView.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
//    //                    textView2.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
//                        if (stickerList[index!!].isRotate){
//                            //TODO Add Undo Redo OPERATION
//                            val operation = UndoRedo.Operation()
//                            operation.mRotation = inflate.rotation
//                            val action = UndoRedo(ACTION.RotateSticker, index!!, getSelectedStickerTag(),operation)
//                            mUndo.add(action)
//                            manageUndoRedoButton()
//                            stickerList[index!!].isRotate = false
//                            Log.d(TAG, "addShadowSticker: ChangeWidth ACTION_DOWN ${inflate.rotation}")
//                        }
//                    }
//                    MotionEvent.ACTION_UP -> {
//                        MyTouchMotion.isPressIcon = false
//                        hideGrid()
//                        showAllStickerButton()
//                        enableAllFontOption()
//                        //TODO Add Undo Redo OPERATION
//                        val operation = UndoRedo.Operation()
//                        operation.mRotation = inflate.rotation
//                        val action = UndoRedo(ACTION.RotateSticker, index!!, getSelectedStickerTag(),operation)
//                        mUndo.add(action)
//                        manageUndoRedoButton()
//                        //TODO CODEHERE
//                        /*if (stickerList[index!!].isGlow){
//                            setTextGlowColorFromColorPicker(stickerList[index!!].getGlowColorPos())
//                        }*/
//                    }
//                    MotionEvent.ACTION_POINTER_DOWN -> {}
//
//                    MotionEvent.ACTION_POINTER_UP -> {}
//                    MotionEvent.ACTION_MOVE -> {
//                        x2 = event.x
//                        val deltaX = x2 - x1
//                        /*
//                        if (deltaX<=0)
//                            currentRotation += rotationSpeed
//                        else
//                            currentRotation -= rotationSpeed
//                        */
//
//                        if (deltaX<=0){
//                            if (right){
//                                tmpInt++
//                                if (tmpInt == 10){
//                                    tmpInt = 0
//                                    right = false
//                                }
//                            }else{
//                                left = true
//                                currentRotation += rotationSpeed
//                            }
//    //                        currentRotation += 3
//                        }else{
//                            if (left){
//                                tmpInt++
//                                if (tmpInt == 10){
//                                    tmpInt = 0
//                                    left = false
//                                }
//                            }else{
//                                right = true
//                                currentRotation -= rotationSpeed
//                            }
//                        }
//                        if (currentRotation in -360.00..360.00) {
//                            inflate.rotation = currentRotation
//                            //TODO Try 1
//                            /*if (deltaX>0){
//                                if (firstRotation < deltaX) {
//                                    inflate.rotation = currentRotation
//                                }
//                            }else{
//                                if (firstRotation > deltaX) {
//                                    inflate.rotation = currentRotation
//                                }
//                            }*/
//
//                            //TODO Try 2
//                            /*if (firstRotation<(currentRotation+rotationSpeed+1)){
//                                if (boolTop){
//                                    inflate.rotation = currentRotation
//                                    boolTop = false
//                                }else{
//                                    boolTop = true
//                                }
//                                Log.d(TAG, "addShadowSticker: rotation 1 $firstRotation < ${currentRotation + rotationSpeed}")
//                            }else if (firstRotation>(currentRotation-rotationSpeed+1)) {
//                                if (boolBottom){
//                                    inflate.rotation = currentRotation
//                                    boolBottom = false
//                                }else{
//                                    boolBottom = true
//                                }
//                                Log.d(TAG, "addShadowSticker: rotation 1 $firstRotation > ${currentRotation - rotationSpeed}")
//                            }*/
//
//                            //TODO Try 3
//                            /*if (currentRotation>firstRotation){
//                                if (boolTop){
//                                    inflate.rotation = currentRotation
//                                    boolTop = false
//                                }else{
//                                    boolTop = true
//                                }
//                                Log.d(TAG, "addShadowSticker: rotation 1 $firstRotation < ${currentRotation + rotationSpeed}")
//                            }else if (currentRotation<firstRotation) {
//                                if (boolBottom){
//                                    inflate.rotation = currentRotation
//                                    boolBottom = false
//                                }else{
//                                    boolBottom = true
//                                }
//                                Log.d(TAG, "addShadowSticker: rotation 1 $firstRotation > ${currentRotation - rotationSpeed}")
//                            }*/
//
//                            //TODO Try 4
//
//                        }else {
//                            currentRotation = 0F
//                            inflate.rotation = 0F
//                        }
//                        firstRotation = deltaX
//
//                        //TODO Origin
//                        /*if (deltaX<=0){
//                            if (currentRotation !in -12.00..12.00) {
//                                currentRotation += 2
//                                mShowGrid = true
//                            } else{
//                                currentRotation += 2
//                                mShowGrid = false
//                            }
//                        }else{
//                            if (currentRotation !in -12.00..12.00) {
//                                currentRotation -= 2
//                                mShowGrid = true
//                            }else{
//                                currentRotation -= 2
//                                mShowGrid = false
//                            }
//                        }
//
//                        if (mShowGrid){
//                            hideGrid()
//                            if (inflate.rotation != 0F){
//                                inflate.rotation = currentRotation
//                            }else if(currentRotation>=20){
//                                inflate.rotation = currentRotation
//                            }else if(currentRotation<=-20){
//                                inflate.rotation = currentRotation
//                            }
//                        }else{
//                            showGrid()
//                            if (currentRotation !in -12.00..-18.00 || currentRotation !in 12.00..18.00){
//                                inflate.rotation = 0F
//                            }
//                        }*/
//
//                        //TODO ShowGrid ALL
//                        /*else if(currentRotation in 75.00..105.00){
//                                showGrid()
//                                inflate.rotation = 90F
//                                Log.d(TAG, "addShadowSticker: rotation 90F")
//                            }else if(currentRotation in 155.00..195.00){
//                                showGrid()
//                                inflate.rotation = 180F
//                                Log.d(TAG, "addShadowSticker: rotation 180F")
//                            }else if(currentRotation in 255.00..285.00){
//                                showGrid()
//                                inflate.rotation = 270F
//                                Log.d(TAG, "addShadowSticker: rotation 270F")
//                            }else if(currentRotation in -105.00..-75.00){
//                                showGrid()
//                                inflate.rotation = 270F
//                                Log.d(TAG, "addShadowSticker: rotation 270F")
//                            }else if(currentRotation in -195.00..-165.00){
//                                showGrid()
//                                inflate.rotation = 180F
//                                Log.d(TAG, "addShadowSticker: rotation 180F")
//                            }else if(currentRotation in -285.00..-255.00){
//                                showGrid()
//                                inflate.rotation = 90F
//                                Log.d(TAG, "addShadowSticker: rotation 90F")
//                            }*/
//
//                        Log.d(TAG, "addShadowSticker: rotation $currentRotation")
//                        Log.d(TAG, "addShadowSticker: rotation deltaX $deltaX")
//                    }
//                }
//            } catch (e: Exception) { }
//            true
//        }
//
//        originalText = str!!
//        newStickerModel = if (!isNewSticker) {
//            stickerModel
//        } else {
//            StickerModel()
//        }
//        if (str != null) {
//            newStickerModel?.originalText = originalText
//        } else {
//            newStickerModel?.jsonText = lottieFile
//        }
//
//        val face = Typeface.createFromAsset(assets, "fonts/Default.ttf")
//        textView.typeface = face
//        textView2.typeface = face
//
//        stickerList.add(newStickerModel!!)
//
//        val centreX = mContainer.pivotX / 2
//        val centreY = mContainer.pivotY / 2
//
//        inflate.tag = "" + System.currentTimeMillis() / 100
//        if (lottieFile != null) {
//            inflate.setOnTouchListener(MyTouchMotion(this, inflate.tag.toString(), lottieFile, Constants.LOTTIE, this))
//        } else if (str != null) {
//            inflate.setOnTouchListener(MyTouchMotion(this, inflate.tag.toString(), str, Constants.TEXT, this,centreX,centreY))
//        } else if (i != null) {
//            inflate.setOnTouchListener(MyTouchMotion(this, inflate.tag.toString(), str, Constants.IMAGE, this))
//        }
//
//        val layoutParams = FrameLayout.LayoutParams(-4, -4)
//        layoutParams.gravity = Gravity.CENTER
//        inflate.layoutParams = layoutParams
//        this.stickerView.addView(inflate)
//
//        if (lottieFile != null) {
////            setStickerSelectedByTag(inflate.tag.toString(), lottieFile)
//            mLottieTag = inflate.tag.toString()
//        } else {
////            setStickerSelectedByTag(inflate.tag.toString(), "")
//        }
//
//        if (isNewSticker){
//            //TODO Add Operation in UndoRedo
//            val operation1 = UndoRedo.Operation()
//            val action1 = UndoRedo(ACTION.ManageSticker, index!!, inflate.tag.toString(),operation1)
//            mUndo.add(action1)
//            manageUndoRedoButton()
//            isFromUndoRedo = false
//        }else{
//            var pos: Int? = null
//            GlobalScope.launch {
//                withContext(Dispatchers.IO){
//                    for (data in mUndo){
//                        if (data.tag == mStickerTag){
//                            pos = data.position
//                            data.tag = inflate.tag.toString()
//                            data.position = index!!
//                        }
//                    }
//                    for (data in mRedo){
//                        if (data.tag == mStickerTag){
//                            data.tag = inflate.tag.toString()
//                            data.position = index!!
//                        }
//                    }
//                }
//            }
//        }
//
//    }

    //TODO AddSticker
    @OptIn(DelicateCoroutinesApi::class)
    private fun addSticker(stickerType: String, value: String, stickerModel: StickerModel ?= null, stickerPosition: Int ?= null) {
        Log.d(TAG, "addSticker: stickerType $stickerType, value $value, stickerModel $stickerModel")
        selectedSticker?.borderVisibility = false
        lifecycleScope.launch {
            withContext(Dispatchers.IO){
                Handler(Looper.getMainLooper()).post {
                    //TODO ADD & MANAGE MODEL HERE
                    var stickerInfo: StickerModel? = null
                    if (stickerModel == null){
                        Log.d(TAG, "addSticker: Model stickerModel $stickerInfo")
                        stickerInfo = StickerModel()
                        with(stickerInfo) {
                            if (stickerType == TEXT_STICKER) {
                                tYPE = TEXT_STICKER
                                tEXT = value
                                wIDTH = dpToPx(context, 150)
                                hEIGHT = dpToPx(context, 85)
                                mIN_W = dpToPx(context, 55)
                                mIN_H = dpToPx(context, 55)
                                tEXT_COLOR = Color.WHITE
                            } else if (stickerType == IMAGE_STICKER) {
                                tYPE = IMAGE_STICKER
                                tEXT = value
                                wIDTH = dpToPx(context, 150)
                                hEIGHT = dpToPx(context, 150)
                                mIN_W = dpToPx(context, 100)
                                mIN_H = dpToPx(context, 100)
                                tEXT_COLOR = Color.TRANSPARENT
                            }

                            pOS_X = (((stickerViewWidth - this.wIDTH) / 2).toFloat())
                            pOS_Y = (((stickerViewHeight - this.hEIGHT) / 2).toFloat())

                            fONT_NAME = ""
                            aLPHA = 255
                            sHADOW_COLOR = Color.BLACK
                            sHADOW_PROGRESS = 0
                            sHADOW_X = 0
                            sHADOW_Y = 0
                            bG_COLOR = Color.TRANSPARENT
                            bG_DRAWABLE = "0"
                            bG_ALPHA = 0
                            rOTATION = 0.0f
                            fIELD_TWO = ""
                        }
                    }else{
                        stickerInfo = stickerModel
                        Log.d(TAG, "buildDialog: StickerView addSticker type ${stickerInfo.tYPE}")
                    }

                    val sticker = if (stickerType == TEXT_STICKER)
                        AutofitLayout(context, TEXT_STICKER)
                    else
                        AutofitLayout(context, IMAGE_STICKER)

                    sticker.apply {
                        setTextInfo(stickerInfo, false)

                        if (stickerType == TEXT_STICKER) {
                            text_iv.typeface = Typeface.createFromAsset(assets, "fonts/Default.ttf")
                        } else if (stickerType == IMAGE_STICKER) {
                            addImage(value)
                        }

                        stickerView.clipToOutline = true
//                        lifecycleScope.launch {
//                            withContext(Dispatchers.Main){
//                                tag = stickerList.size
//                                stickerView.addView(this@apply)
//                            }
//                        }
//                        runOnUiThread {
                            this.tag = stickerList.size
                            stickerView.addView(this@apply)
//                        }
                        setDefaultTouchListener(true)
                        borderVisibility = true
                        setOnTouchCallbackListener(stickerListener)
                        text_iv.setOnResizeListener(object : AutoResizeTextView.OnTextResizeListener{
                            override fun onTextResize(textView: TextView?, oldSize: Float, newSize: Float) {

                            }

                            override fun onCurveResize(newWidth: Float, newHeight: Float) {
                                if (stickerInfo.mIN_W < newWidth && stickerInfo.mIN_H < newHeight) {
                                    Log.d(TAG, "onDraw: text_iv AutoFit radius ${sticker.text_iv.mRadius} seekCurve: ${mSeekCurve?.progress}")
                                    Log.d(TAG, "onDraw: text_iv AutoFit curve width ${sticker.layoutParams.width} height ${sticker.layoutParams.height}")
                                    if (mSeekCurve?.progress in 250..450) {
                                        sticker.layoutParams.width = (newHeight).toInt()
                                        sticker.layoutParams.height = (newHeight).toInt()
                                        sticker.requestLayout()
                                        sticker.invalidate()
                                    }
                                }
                            }

                        })
                    }
                    //TODO REMOVE LOCK
                    stickerList.add(StickerModel(tYPE = stickerType))

                    //TODO Add Operation in UndoRedo
                    val operation = UndoRedo.Operation()
                    val action = UndoRedo(ACTION.ManageSticker, stickerList.size-1,operation)
                    mUndo.add(action)
                    manageUndoRedoButton()
                    isFromUndoRedo = false
                    stickerView.invalidate()
                    Log.d(TAG, "stickerView: performClick 15")
                    stickerView.performClick()
                    stickerList[stickerList.size-1].apply {
//                      index = stickerList.size-1
//                      selectedSticker = sticker
                        mainText = value
                        selectedSticker?.borderVisibility = true
                    }

                    Log.d(TAG, "performUndoRedo: stickerListener.onTouchDown 4")
                    stickerListener.onTouchDown(sticker)
                    Log.d(TAG, "stickerModel: stickerModel value $stickerModel")
                    stickerModel?.let{
//                        sticker.borderVisibility = false
                        llShowTextFun.hide()
                        textFunction.hide()
                        updateSticker(it)
                    }
                }
            }
            withContext(Dispatchers.Main){
                stickerModel?.let {
                    if (stickerPosition == draftTotal) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            stickerView.performClick()
                            progressDialog?.dismiss()
//                            mUndo.clear()
//                            imgBtnUndo.setOpacity(0.5F)
                        }, 1000)
                    }
                }
            }
        }

    }

    private fun updateSticker(stickerModel: StickerModel?) {
        Log.d(TAG, "updateSticker: stickerModel $stickerModel")
        if (stickerModel != null){
            with(stickerModel) {
                Log.d(TAG, "updateSticker: stickerModel positionFont $positionFont")
                Log.d(TAG, "updateSticker: stickerModel singleColorPos $singleColorPos")
                Log.d(TAG, "updateSticker: stickerModel positionMultiple $positionMultiple")
                Log.d(TAG, "updateSticker: stickerModel val text $tEXT rotateX $rotateX rotateY $rotateY")
                Log.d(TAG, "updateSticker: stickerModel val isFlipped $isFlipped")

                if (positionFont != -1) {
                    positionFont.let { pos ->
                        if (fontStyleList[pos].contains(FontFolder)) {
                            setFontTypeFace(pos, Typeface.createFromAsset(assets, fontStyleList[pos]))
                        } else {
                            setFontTypeFace(pos, Typeface.createFromFile("$cacheDir/$downloadedFont/${fontStyleList[pos]}"))
                        }
                    }
                }
                if (singleColorPos != -1)
                    setTextColorFromColorPicker(singleColorPos)

                if (positionGradient != -1) {
                    isFromUndoRedo = true
                    gradientAdepter?.clickGradientColor(positionGradient)
                    val stk = selectedSticker
                    val pos = positionGradient
                    Handler(Looper.getMainLooper()).postDelayed({
                        stk?.setGradient(gradientColorList[pos].split(",".toRegex()).toTypedArray())
                    },5)
                }
                if (positionMultiple != -1) {
                    isFromUndoRedo = true
                    multiColorAdepter?.clickMultiColor(positionMultiple)
                    /*val stk = selectedSticker
                    val pos = positionMultiple
                    Handler(Looper.getMainLooper()).postDelayed({
                        stk?.setMulticolor(multiColorList[pos])
                    },5)*/
                }
                if (positionTexture != -1) {
                    isFromUndoRedo = true
                    onPatternClick(positionTexture, null, isFromUndoRedo = true)
                }else if (patternString != null){
                    onPatternClick(-1, patternString, isFromUndoRedo = true)
                }
                index?.let { i ->
                    if (rotateX.toInt() != 0) {
                        selectedSticker?.rotationX = rotateX
                        stickerList[i].rotateX = rotateX
                    }
                    if (rotateY.toInt() != 0) {
                        selectedSticker?.rotationY = rotateY
                        stickerList[i].rotateY = rotateY
                    }
                    if (rOTATION != 0F) {
                        selectedSticker?.rotation = rOTATION
                        stickerList[i].rOTATION = rOTATION
                    }
                    if (fontType != "Default"){
                        stickerList[i].fontType = fontType
                        when (fontType) {
                            "AA" -> {
                                originalText = tEXT.lowercase()
                                selectedSticker!!.text_iv.text = originalText
                            }
                            "Aa" -> {
                                originalText = tEXT.uppercase()
                                selectedSticker!!.text_iv.text = originalText
                            }
                            "aa" -> {
                                originalText = toTitleCase(tEXT)
                                selectedSticker!!.text_iv.text = originalText
                            }
                            else -> {
                                imgTextCase.setImageResource(R.drawable.ic_a1)
                                setFontTypeSelection(Constants.CASE,false)
                            }
                        }
                    }
                    if (bold) {
                        setFontTypeSelection(Constants.BOLD)
                        selectedSticker?.setBoldFont()
                        stickerList[i].bold = true
                    }
                    if (italic) {
                        setFontTypeSelection(Constants.ITALIC)
                        selectedSticker?.setItalicFont()
                        stickerList[i].italic = true
                    }
                    if (underline) {
                        setFontTypeSelection(Constants.UNDERLINE)
                        selectedSticker?.setUnderLineFont()
                        stickerList[i].underline = true
                    }
                    if (isGlow) {
                        stickerList[i].glowRadius = glowRadius
                        setTextGlowColorFromColorPicker(glowColorPos, glowRadius)
                    }
                    if (isFlipped){
                        selectedSticker?.text_iv?.rotationY = 180F
                        stickerList[i].isFlipped = true
                    }
                }

            }
        }
    }

    private fun manageUndoRedoButton() {
        if (mUndo.size == 0)
            imgBtnUndo.setOpacity(0.5F)
        else
            imgBtnUndo.setOpacity(1F)
        if (mRedo.size == 0)
            imgBtnRedo.setOpacity(0.5F)
        else
            imgBtnRedo.setOpacity(1F)
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun setFontTypeSelection(fontType: String, showBorder: Boolean = true) {
        val selected = ContextCompat.getDrawable(this, R.drawable.bg_selected)
        val unselected = ContextCompat.getDrawable(this, R.drawable.bg_unselected)
        if (showBorder){
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                when(fontType){
                    Constants.BOLD -> {
                        imgFontTypeBold.setBackgroundDrawable(selected)
                    }
                    Constants.ITALIC -> {
                        imgFontTypeItalic.setBackgroundDrawable(selected)
                    }
                    Constants.UNDERLINE -> {
                        imgFontTypeUnderline.setBackgroundDrawable(selected)
                    }
                    Constants.CASE -> {
                        txtFontTypeAA.setBackgroundDrawable(selected)
                    }
                }
            } else {
                when(fontType){
                    Constants.BOLD -> {
                        imgFontTypeBold.background = selected
                    }
                    Constants.ITALIC -> {
                        imgFontTypeItalic.background = selected
                    }
                    Constants.UNDERLINE -> {
                        imgFontTypeUnderline.background = selected
                    }
                    Constants.CASE -> {
                        txtFontTypeAA.background = selected
                    }
                }
            }
        }else{
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                when(fontType){
                    Constants.BOLD -> {
                        imgFontTypeBold.setBackgroundDrawable(unselected)
                    }
                    Constants.ITALIC -> {
                        imgFontTypeItalic.setBackgroundDrawable(unselected)
                    }
                    Constants.UNDERLINE -> {
                        imgFontTypeUnderline.setBackgroundDrawable(unselected)
                    }
                    Constants.CASE -> {
                        txtFontTypeAA.setBackgroundDrawable(unselected)
                    }
                }
            } else {
                when(fontType){
                    Constants.BOLD -> {
                        imgFontTypeBold.background = unselected
                    }
                    Constants.ITALIC -> {
                        imgFontTypeItalic.background = unselected
                    }
                    Constants.UNDERLINE -> {
                        imgFontTypeUnderline.background = unselected
                    }
                    Constants.CASE -> {
                        txtFontTypeAA.background = unselected
                    }
                }
            }
        }
    }

    private fun getLength(x1: Double, y1: Double, x2: Double, y2: Double): Double {
        return Math.sqrt(Math.pow(y2 - y1, 2.0) + Math.pow(x2 - x1, 2.0))
    }

    interface ResizeStickerIcon {
        fun resizeIcon(px: Int, adjustResize: Boolean = false)
    }

    fun adjustTranslation(view: View, f: Float, f2: Float) {
        val fArr = floatArrayOf(f, f2)
        view.matrix.mapVectors(fArr)
        view.translationX = view.translationX + fArr[0]
        view.translationY = view.translationY + fArr[1]
    }

//    @SuppressLint("CutPasteId")
//    fun setStickerSelectedByTag(tag: String, type: String) {
//        for (i in 0 until stickerView.childCount) {
//            if (stickerView.getChildAt(i).tag == tag) {
//                index = i
////                selectedSticker = stickerView.getChildAt(i)
//                originalText = stickerView.getChildAt(i).findViewById<TextView>(R.id.realText).text.toString()
//                stickerView.getChildAt(i).findViewById<ConstraintLayout>(R.id.ll_view1)
//                    .setBackgroundResource(R.drawable.border_textview)
//                stickerView.getChildAt(i)
//                    .findViewById<ImageView>(R.id.btnDelete).show()
//                stickerView.getChildAt(i)
//                    .findViewById<ImageView>(R.id.btnZoom).show()
//                stickerView.getChildAt(i)
//                    .findViewById<ImageView>(R.id.btnFlip).show()
//                llShowAnimFun!!.hide()
//
//                if (originalText != "") {
//                    //Text Sticker : Show Edit Button in Sticker
//                    (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnEdit)).show()
//                    (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnResizeText)).show()
//                    (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnRotate)).show()
//                    fontPosition = stickerList[index!!].positionFont
//                    Constants.shadowColorShawPrggress =
//                        stickerList[index!!].positionColorShadowProgress
//                    Constants.shadowColorShawPrggress1 =
//                        stickerList[index!!].positionColorShadowProgress1
//                    patternPosition = stickerList[index!!].positionTexture
//                    gradientPosition = stickerList[index!!].positionGradient
//                    multiColorPosition = stickerList[index!!].positionMultiple
//                    if (stickerList[index!!].fontType == "Default") {
//                        setFontTypeSelection(Constants.CASE,false)
//                        imgTextCase.setImageResource(R.drawable.ic_a1)
//                    } else {
//                        when (stickerList[index!!].fontType) {
//                            "AA" -> imgTextCase.setImageResource(R.drawable.ic_a3)
//                            "Aa" -> imgTextCase.setImageResource(R.drawable.ic_a1)
//                            "aa" -> imgTextCase.setImageResource(R.drawable.ic_a2)
//                        }
//                        setFontTypeSelection(Constants.CASE)
//                    }
//                    if (stickerList[index!!].isBold) {
//                        setFontTypeSelection(Constants.BOLD)
//                    }else{
//                        setFontTypeSelection(Constants.BOLD,false)
//                    }
//                    if (stickerList[index!!].isItalic) {
//                        setFontTypeSelection(Constants.ITALIC)
//                    }else{
//                        setFontTypeSelection(Constants.ITALIC,false)
//                    }
//                    if (stickerList[index!!].isUnderline) {
//                        setFontTypeSelection(Constants.UNDERLINE)
//                    }else{
//                        setFontTypeSelection(Constants.UNDERLINE,false)
//                    }
//                    setTextFontTypeIfApplied(false)
//                    /*try {
////                        Log.d(TAG, "setStickerSelectedByTag: ${stickerList[index!!].lastAction}")
//                        when(stickerList[index!!].lastAction){
//                            "Font"     -> {
//                                constraintFontStyle.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_LEFT)
//                            }
//                            "Shadow"   -> {
//                                constraintShadow.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_LEFT)
//                            }
//                            "Color"    -> {
//                                constraintColor.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_LEFT)
//                            }
//                            "Pattern"  -> {
//                                constraintPattern.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_LEFT)
//                            }
//                            "Curve"    -> {
//                                constraintCurve.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_LEFT)
//                            }
//                            "3D"       -> {
//                                constraint3D.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_LEFT)
//                            }
//                            "FontType" -> {
//                                constraintFontType.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
//                            }
//                            "Glow"     -> {
//                                Log.d(TAG, "setStickerSelectedByTag: inside GLOW")
//                                constraintFontGlow.performClick()
//                                mScrollShowTextFun.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
//                            }
//                            else       -> constraintFontStyle.performClick()
//                        }
//                    } catch (e: Exception) { }*/
//                } else {
//                    if (type != "") {
//                        //Lottie View Sticker : Show Edit Button in Sticker
//                        stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnFlip).hide()
//                        (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnEdit)).show()
//                        (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnResizeText)).hide()
//                        llShowAnimFun!!.show()
//                        Log.d(TAG, "setStickerSelectedByTag: LottieSticker Selected")
//                    } else {
//                        //Sticker : Don't Show Edit Button in Sticker
//                        (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnEdit)).hide()
//                        (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnResizeText)).hide()
//                        (stickerView.getChildAt(i).findViewById<ImageView>(R.id.btnRotate)).show()
//                        llShowAnimFun!!.hide()
//                    }
//                }
//                /*else {
//                    (stickerView.getChildAt(i)
//                            .findViewById<ImageView>(R.id.btnEdit) as ImageView).hide()
//                }*/
//
//                if (originalText != "") {
//                    mConstraintLayoutBG?.hide()
//                    mConstraintLayoutAddText?.hide()
//                    mRecyclerAddText.disabled()
//                    mConstraintLayoutStickerCategory?.hide()
//                    mConstraintFrameLayout?.hide()
//
//                    clMainOptionView.visibility = View.INVISIBLE
//                    mConstraintSubLayoutGradient.hide()
//                    mConstraintSubLayoutTexture.hide()
//                    mConstraintSubLayoutShadowColor?.hide()
//                    mConstraintSubLayoutTextBorder?.hide()
//                    mConstraintSubLayoutTextSpace?.hide()
//                    mConstraintSubLayoutTextCurve?.hide()
//                    mConstraintSubLayoutText3d.hide()
//                    constraintSubLayoutFontStyle.hide()
//                    constraintSubLayoutColor.hide()
//                    mConstraintLayoutAddText?.show()
//                    mRecyclerAddText.enabled()
//
//                    mConstraintMenuBG.disabled()
//                    mConstraintMenuSticker.disabled()
//                    mConstraintMenuFrame.disabled()
//                    mConstraintMenuAddText.disabled()
//                    try {
//                        clMainOptionView?.hide()
//                        if (llShowTextFun.visibility == View.GONE) {
//                            llShowTextFun.show()
////                            constraintFontStyle.performClick()
//                        }
//                    } catch (e: Exception) {
//                    }
//                    try {
//                        if (stickerList[index!!].isMultiColor && consCurveText.visibility == View.VISIBLE) {
//                            constraintFontStyle.performClick()
//                        }
//                    } catch (e: Exception) {
//                    }
//                    updateSelectedSticker()
//
//                } else {
//                    clMainOptionView.show()
//                    mConstraintSubLayoutGradient.hide()
//                    mConstraintSubLayoutTexture.hide()
//                    mConstraintSubLayoutShadowColor?.hide()
//                    mConstraintSubLayoutTextBorder?.hide()
//                    mConstraintSubLayoutTextSpace?.hide()
//                    mConstraintSubLayoutTextCurve?.hide()
//                    mConstraintSubLayoutText3d.hide()
//                    constraintSubLayoutFontStyle.hide()
//                    constraintSubLayoutColor.hide()
//                    mConstraintLayoutAddText?.hide()
//                    consCurveText?.hide()
//                    mRecyclerAddText.disabled()
//
//                    mConstraintMenuBG.enabled()
//                    mConstraintMenuAddText.enabled()
//                    mConstraintMenuSticker.enabled()
//                    mConstraintMenuFrame.enabled()
//                    clMainOptionView?.show()
//                    llShowTextFun.hide()
//                    consFontStyleList?.hide()
//                    consColorList?.hide()
//                    consPatternList?.hide()
//                    consCurveText?.hide()
//                    cons3DText?.hide()
//                    consTextFontType.hide()
//                    consTextFontGlow.hide()
//                    consTextFontStroke.hide()
//                    consShadowText?.hide()
//
//                }
//            } else {
//                stickerView.getChildAt(i)
//                    .findViewById<ConstraintLayout>(R.id.ll_view1).background = null
//                (stickerView.getChildAt(i).findViewById(R.id.btnDelete) as ImageView).visibility = View.INVISIBLE
//                (stickerView.getChildAt(i)
//                    .findViewById(R.id.btnZoom) as ImageView).visibility = View.INVISIBLE
//                (stickerView.getChildAt(i)
//                    .findViewById(R.id.btnFlip) as ImageView).visibility = View.INVISIBLE
//                (stickerView.getChildAt(i)
//                    .findViewById(R.id.btnEdit) as ImageView).visibility = View.INVISIBLE
//                (stickerView.getChildAt(i)
//                    .findViewById(R.id.btnResizeText) as ImageView).visibility = View.INVISIBLE
//                (stickerView.getChildAt(i)
//                    .findViewById(R.id.btnRotate) as ImageView).visibility = View.INVISIBLE
//            }
//        }
//
//        try {
//            strokeMenu("curving")
//        } catch (e: Exception) { }
//        mRecyclerAddText.enabled()
//        mRecyclerAddText.disabled()
//    }

    @SuppressLint("NotifyDataSetChanged")
    private fun updateSelectedSticker() {
        lifecycleScope.launch { 
            withContext(Dispatchers.Main){
                index?.let{ i ->
                    //TODO Manage Adapters
                    fontPosition = stickerList[i].positionFont
                    fontAdapter?.notifyDataSetChanged()
                    gradientPosition = stickerList[i].positionGradient
                    gradientAdepter?.notifyDataSetChanged()
                    multiColorPosition = stickerList[i].positionMultiple
                    multiColorAdepter?.notifyDataSetChanged()
                    patternPosition = stickerList[i].positionTexture
                    textureAdepter?.notifyDataSetChanged()

                    //TODO Manage Seekbars
                    Log.d(TAG, "performUndoRedo: mSeekGlow.progress 2 ${stickerList[i].glowRadius.toInt()}")
                    mSeekGlow.progress = stickerList[i].glowRadius.toInt()
                    mSeekStroke.progress = stickerList[i].storeWidth
                    mSeekSpace?.progress = stickerList[i].spaceProgress
                    mSeekOpacity?.progress = stickerList[i].shadowOpacity
                    mSeek3Dx?.progress = stickerList[i].rotateX.toInt()
                    mSeek3Dy?.progress = stickerList[i].rotateY.toInt()
                    mSeekCurve?.progress = stickerList[i].curve.toInt()

                    //TODO manage Font Type
                    Log.d(TAG, "updateSelectedSticker onTouchDown fontType ${stickerList[i].fontType}")
                    if (stickerList[i].fontType == "Default") {
                        setFontTypeSelection(Constants.CASE,false)
                        imgTextCase.setImageResource(R.drawable.ic_a1)
                    } else {
                        when (stickerList[i].fontType) {
                            "AA" -> imgTextCase.setImageResource(R.drawable.ic_a3)
                            "Aa" -> imgTextCase.setImageResource(R.drawable.ic_a1)
                            "aa" -> imgTextCase.setImageResource(R.drawable.ic_a2)
                        }
                        setFontTypeSelection(Constants.CASE)
                    }
                    Log.d(TAG, "updateSelectedSticker stickerList: bold ${stickerList[i].bold} italic ${stickerList[i].italic} underline ${stickerList[i].underline}")
                    if (stickerList[i].bold)
                        setFontTypeSelection(Constants.BOLD)
                    else
                        setFontTypeSelection(Constants.BOLD,false)
                    if (stickerList[i].italic)
                        setFontTypeSelection(Constants.ITALIC)
                    else
                        setFontTypeSelection(Constants.ITALIC,false)
                    if (stickerList[i].underline)
                        setFontTypeSelection(Constants.UNDERLINE)
                    else
                        setFontTypeSelection(Constants.UNDERLINE,false)

                    setTextFontTypeIfApplied(true)

                    //TODO Manage Colors
                    if (stickerList[i].isMultiColor) {
                        Log.d(TAG, "multiColorAdepter clickMultiColor 7")
                        selectedSticker?.setMulticolor(multiColorList[stickerList[i].positionMultiple])
//                        multiColorAdepter!!.clickMultiColor(stickerList[i].positionMultiple)
                    }

                    //TODO Manage Glow
//                    mSeekGlow.enabled()
//                    mSeekGlow.setOpacity(1F)
//                    if (stickerList[i].isPattern) {
//                        mSeekGlow.disabled()
//                        mSeekGlow.setOpacity(0.5F)
//                    }

                }
            }
        }
    }

    private fun updateTextSticker(
        stickerModel: StickerModel?,
        inputString: String?,
        isNewText: Boolean,
    ) {
        stickerModel!!.originalText = inputString
        if (stickerModel.originalText == "") {
            stickerModel.originalText = "TextArt"
        }

    }

//    private fun startEditing() {
//        if (isDialogOpen) {
//            return
//        }
//        if (mStickerModel!!.isFirstAttempt) {
//            mStickerModel!!.originalText = ""
//            mStickerModel!!.isFirstAttempt = false
//        }
//
//        editDialog = Dialog(this)
//        editDialog!!.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//        editDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
//        editDialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        editDialog!!.setCancelable(false)
//        editDialog!!.setContentView(R.layout.text_edit_dialog)
//
//        isDialogOpen = true
//        editDialog!!.show()
//
//        mBtnOK = editDialog!!.findViewById<Button>(R.id.btnPositive)
//        mBtnCancle = editDialog!!.findViewById<Button>(R.id.btnNagative)
//        edtTextSticker = editDialog!!.findViewById(R.id.edtTextSticker)
//        if (!isAddText) {
//            edtTextSticker!!.setText(originalText.trim())
//        }
//        mBtnOK?.click {
//            if (edtTextSticker!!.text.toString().trim() == "") {
//                showToast("Please enter name")
//                return@click
//            }
//
//            isTextStickerAvilable = true
//
//            Log.d(TAG, "startEditing: isAddText $isAddText")
//            if (isAddText) {
//                try {
//                    try {
////                        addShadowSticker(" ${edtTextSticker!!.text} ", null, null, true, null)
//                        addSticker(TYPE.TEXT_STICKER, " ${edtTextSticker!!.text} ", null)
//                        isTextStickerAvilable = true
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                            shadowDataSet()
//                        }
//                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                            loadCurveTextData()
//                        }
//                        onTextMenuClicked()
//                    } catch (e: Exception) { }
//                } catch (e: Exception) { }
//            } else {
//                try {
//                    if (stickerView != null) {
//
//                        val realText = stickerView.getChildAt(index!!)
//                            .findViewById<AutoResizeTextView>(R.id.realText)
//                        val flippedText = stickerView.getChildAt(index!!)
//                            .findViewById<AutoResizeTextView>(R.id.flippedText)
//                        try {
////                            originalText = " ${edtTextSticker!!.text} "
//                            originalText = "${edtTextSticker!!.text}"
//                            stickerList[index!!].originalText = originalText
//
//                            if (stickerList[index!!].isFirstTimeChangeText){
//                                //TODO Add Operation in UndoRedo
//                                val operation2 = UndoRedo.Operation()
//                                operation2.newText = (selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).text.toString()
//                                operation2.mWidth = (selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).width
//                                val action2 = UndoRedo(ACTION.ChangeText, index!!, getSelectedStickerTag(),operation2)
//                                mUndo.add(action2)
//                                stickerList[index!!].isFirstTimeChangeText = false
//                            }
//
//                            //TODO Add Operation in UndoRedo
//                            val operation = UndoRedo.Operation()
//                            operation.newText = originalText
//                            operation.mWidth = (selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).width
//                            Log.d(TAG, "ACTION.ChangeText: text $originalText width ${(selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView).width} ")
//                            val action = UndoRedo(ACTION.ChangeText, index!!, getSelectedStickerTag(),operation)
//                            mUndo.add(action)
//                            manageUndoRedoButton()
//
//                            realText.text = originalText
//                            flippedText.text = originalText
//
//                        } catch (e: Exception) { }
//
//                        try {
//                            if (stickerList[index!!].isMultiColor) {
//                                multiColorAdepter!!.clickMultiColor(stickerList[index!!].positionMultiple)
//                            }
//                        } catch (e: Exception) { }
//                        try {
//                            if (stickerList[index!!].isCurve) {
//                                stickerList[index!!].isCurve = true
//                                stickerList[index!!].angle = max / 2
//                                stickerList[index!!].angleProgress = max / 2
//                                try {
//                                    //TODO manage Curve Here
//                                    if (stickerList[index!!].angleProgress != 0) {
//                                        realText.isCurve = true
//                                        flippedText.isCurve = true
////                                        realText.resetSize(max / 2)
////                                        flippedText.resetSize(max / 2)
//                                    }
////                                    strokeMenu("curving")
//                                    Log.d("MMMMMMMMMMMM", "OnItemClicked: " + mSeekCurve!!.progress)
//                                    Log.d("MMMMMMMMMMMM", "OnItemClicked: " + stickerList[index!!].angle)
//                                } catch (e: Exception) { }
//                            }
//                        } catch (e: Exception) { }
//                        try {
//                            realText.invalidate()
//                            flippedText.invalidate()
//                        } catch (e: Exception) { }
//                    }
//                } catch (e: Exception) { }
////                setTextFontTypeIfApplied()
//                try {
//                    strokeMenu("curving")
//                }catch (e: Exception){}
//            }
//            try {
//                mStickerModel!!.spaceProgress = 0
//                mStickerModel!!.originalText = edtTextSticker!!.text.trim().toString()
//                Log.d(TAG, "startEditing: " + mStickerModel!!.originalText)
//            } catch (e: Exception) { }
//            isDialogOpen = false
//            editDialog!!.dismiss()
//        }
//
//        mBtnCancle?.click {
//            isDialogOpen = false
//            editDialog!!.cancel()
//            mConstraintMenuBG.enabled()
//            mConstraintMenuAddText.enabled()
//            mConstraintMenuSticker.enabled()
//            mConstraintMenuFrame.enabled()
//            hideControlsUI(false)
//        }
//        imgBtnSave.tag = "text"
//    }

    @SuppressLint("SetTextI18n")
    private fun startEditing() {
        val editText = editDialog!!.findViewById<EditText>(R.id.edtTextSticker)
        if (index != null)
            editText.setText(selectedSticker!!.text)
        else {
            if (stickerList.isNotEmpty())
                editText.setText("")
            else
                editText.setText("TextArt")
        }

        editText.setSelection(editText.text.toString().length)
        if (!editDialog!!.isShowing)
            editDialog!!.show()
    }

    var isGallery = true
    var isColorPick = true

    private fun choosePatternImageFromGallery() {
        VasuImagePicker.ActivityBuilder(this)
            .setFolderMode(true)
            .setFolderTitle("Gallery")
            .setMultipleMode(false)
            .setImageCount(1)
            .setMaxSize(10)
            .setBackgroundColor("#FFFFFF")
            .setToolbarColor("#FFFFFF")
            .setToolbarTextColor("#000000")
            .setToolbarIconColor("#000000")
            .setStatusBarColor("#FFFFFF")
            .setProgressBarColor("#50b1ed")
            .setAlwaysShowDoneButton(true)
            .setRequestCode(PICK_IMAGE_CODE)
            .setKeepScreenOn(true)
            .start()
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun pickFontFamily() {
        var chooseFile = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Intent(Intent.ACTION_OPEN_DOCUMENT)
        } else {
            Intent(Intent.ACTION_GET_CONTENT)
        }
        chooseFile.addCategory(Intent.CATEGORY_OPENABLE)
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O && Build.VERSION.SDK_INT != Build.VERSION_CODES.O_MR1) {
            chooseFile.type = "*/*"
            val mimetypes = arrayOf("font/ttf", "font/otf")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                chooseFile.putExtra(Intent.EXTRA_MIME_TYPES, mimetypes)
            } else {
                chooseFile.type = "font/ttf"
            }
        } else {
            chooseFile.type = "*/*"
        }
        chooseFile = Intent.createChooser(chooseFile, "Choose a file")
        startActivityForResult(chooseFile, 1001)
    }

    private fun openColorPickerDialog(requestCode: Int, selectedColor: Int = -1) {
        Log.d(TAG, "openColorPickerDialog: requestCode: $requestCode selectedColor: $selectedColor")

        colorPickerDialog =
            ColorPickerDialog.newBuilder().setDialogType(ColorPickerDialog.TYPE_PRESETS)
                .setAllowPresets(false)
                .setDialogId(0)
                .setShowAlphaSlider(true)
                .setColor(selectedColor)
                .create()

        colorPickerDialog!!.setColorPickerDialogListener(object : ColorPickerDialogListener {
            override fun onColorSelected(dialogId: Int, color: Int) {
                when (requestCode) {
                    TEXT_GLOW -> {
                        stickerList[index!!].isBorderApply = true
                        //TODO Add Operation in UndoRedo
                        if (stickerList[index!!].isFirstTimeGlow){
                            val operation = UndoRedo.Operation()
//                            operation.mGlowColor = 0
                            operation.mGlowColor = -1
                            val action = UndoRedo(ACTION.ChangeGlowColor, index!!, operation)
                            Log.d(TAG, "Undo Redo Added ACTION.ChangeGlowColor 1")
                            mUndo.add(action)
                            manageUndoRedoButton()
                            stickerList[index!!].isFirstTimeGlow = false
                        }
                        val operation = UndoRedo.Operation()
                        operation.mGlowColor = color
                        val action = UndoRedo(ACTION.ChangeGlowColor, index!!, operation)
                        Log.d(TAG, "Undo Redo Added ACTION.ChangeGlowColor 2")
                        mUndo.add(action)
                        manageUndoRedoButton()
                        isFromUndoRedo = false
                        setTextGlowColorFromColorPicker(color)
                    }
                    TEXT_COLOR -> {
                        setTextColorFromColorPicker(color)
                    }
                    TEXT_STROKE -> {
                        stickerList[index!!].strokeColor = color
                        setTextStrokeFromColorPicker(color,stickerList[index!!].storeWidth)
                    }
                }
            }

            override fun onDialogDismissed(dialogId: Int) { }
        })
        colorPickerDialog!!.show(supportFragmentManager, "ColorPicker")
    }

    private fun setTextGlowColorFromColorPicker(color: Int, r:Float ?= null) {
        index?.let { i ->
            stickerList[i].isGlow = true
            selectedSticker!!.text_iv.setShadowLayer(r ?: stickerList[i].glowRadius, 0f, 0f, color)
            if (color == Color.TRANSPARENT)
                stickerList[i].glowColorPos = -1
            else
                stickerList[i].glowColorPos = color
        }

//        val realText = context.selectedSticker!!.findViewById(R.id.realText) as AutoResizeTextView
////        val realText = stickerList[index!!].findViewById(R.id.realText) as AutoResizeTextView
//        val flippedText = context.selectedSticker!!.findViewById(R.id.flippedText) as AutoResizeTextView
////        val flippedText = stickerList[index!!].findViewById(R.id.flippedText) as AutoResizeTextView
        
//
////        stickerList[index!!].setmGlowColorPos(color)
//
//        val radius = stickerList[index!!].getGlowRadius()
//        realText.setShadowLayer(radius, 0f, 0f, color)
//        flippedText.setShadowLayer(radius, 0f, 0f, color)
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setTextColorFromColorPicker(color: Int, isFromUndoRedo: Boolean = false) {
        index?.let { i ->
            if (!isFromUndoRedo){
                //TODO Add Operation in UndoRedo
                addWhiteColorIfFirstTime()
                val operation = UndoRedo.Operation()
                operation.singleColor = color
                val action = UndoRedo(ACTION.ChangeSingleColor, i, operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeSingleColor 1")
                mUndo.add(action)
                manageUndoRedoButton()
            }

            /*if (isFromUndo){
                stickerList!![mUndo[mUndo.size-1].position].setSingleColorPos(color)
            }else{
                stickerList!![mRedo[mRedo.size-1].position].setSingleColorPos(color)
            }*/
            
            stickerList[i].singleColorPos = color
            Log.d(TAG, "setTextColorFromColorPicker: singleColorPos ${stickerList[i].singleColorPos}")
            selectedSticker!!.text_iv.paint.shader = null
            selectedSticker?.textColor = color
            stickerList[i].isGradient = false
            stickerList[i].isPattern = false
            stickerList[i].isTexture = false
            stickerList[i].isShadow = false
            stickerList[i].isSingleColor = true
            stickerList[i].isMultiColor = false
            multiColorPosition = -1
            multiColorAdepter!!.notifyDataSetChanged()
            patternPosition = -1
            textureAdepter?.notifyDataSetChanged()
            Log.d(TAG, "updateSelectItem: textureAdepter 2")
            gradientPosition = -1
            gradientAdepter?.notifyDataSetChanged()
            stickerList[i].positionTexture = -1
            stickerList[i].positionGradient = -1
            stickerList[i].positionMultiple = -1
        }
    }

    private fun setTextStrokeFromColorPicker(color: Int, stroke: Int, isFromUndoRedo: Boolean = false){
        index?.let { i ->
            stickerList[i].strokeColor = color
            stickerList[i].storeWidth = stroke
//            stickerList[i].setmStrokeColorPos(color)
            selectedSticker?.findViewById<AutoResizeTextView>(R.id.realText)!!.setStoke(color, stroke)
            selectedSticker?.findViewById<AutoResizeTextView>(R.id.flippedText)!!.setStoke(color, stroke)
        }
    }

    fun createBitmap(color: Int, value: Int): Bitmap {
        var transBitmap: Bitmap? = null
        try {
            transBitmap = Bitmap.createBitmap(
                mContainer.width,
                mContainer.height,
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(transBitmap!!)
            val paint = Paint()
            paint.alpha = value
            paint.color = color
            canvas.drawPaint(paint)
        } catch (e: Exception) {
            Log.d(TAG, "AddTextActivity1 : createBitmap: ${e.localizedMessage}")
        } finally {
            return transBitmap!!
        }
    }

    private fun shadowDataSet() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                mSeekSpace!!.thumb.colorFilter = BlendModeColorFilter(getColor(R.color.colorPrimary), BlendMode.SRC_ATOP)
                mSeekOpacity!!.thumb.colorFilter = BlendModeColorFilter(getColor(R.color.colorPrimary), BlendMode.SRC_ATOP)
            } else {
                mSeekSpace!!.thumb.setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary), PorterDuff.Mode.MULTIPLY)
                mSeekOpacity!!.thumb.setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary), PorterDuff.Mode.MULTIPLY)
            }
        } catch (e: Exception) { }

            mSeekOpacity!!.max = 50

                mSeekOpacity!!.setOnSeekBarChangeListener(object :
                    SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(
                        seekBar: SeekBar?,
                        progress: Int,
                        fromUser: Boolean,
                    ) {
//                        Log.d(TAG, "onProgressChanged: ${(progress.toFloat()) / 50}")
//                        isFromUndoRedo = false
//                        if (mSeekSpace!!.progress == 0 && mSeekSpace!!.isEnabled){
//                            try{
//                                val flippedText =
//                                    context.selectedSticker!!.findViewById(
//                                        R.id.flippedText
//                                    ) as TextView
//                                val constraintLayout =
//                                    context.selectedSticker!!.findViewById(
//                                        R.id.shadowLayout
//                                    ) as ConstraintLayout
//
//                                val params: ViewGroup.MarginLayoutParams = constraintLayout.layoutParams as ViewGroup.MarginLayoutParams
//                                params.topMargin = -35
//                                constraintLayout.layoutParams = params
//                                flippedText.invalidate()
//                                stickerList[index!!].positionSpaceProgress = progress
//                            } catch (e: Exception) { }
//                        }
//                        if (fromUser) {
//                            disableAllFontOption()
//                            mSeekSpace!!.disabled()
//                        }
//                        mStickerModel!!.opacityProgress = (progress.toFloat() / 50)
//                        if (textView != null) {
//                            updateTextSticker(
//                                mStickerModel,
//                                mStickerModel!!.originalText,
//                                false
//                            )
////                    mStickerView?.invalidate()
//                        }
//
//                        try {
//                            val flippedText =
//                                context.selectedSticker!!.findViewById(R.id.flippedText) as TextView
//                            val constraintLayout =
//                                context.selectedSticker!!.findViewById(R.id.shadowLayout) as ConstraintLayout
//                            if (progress == 0) {
//                                flippedText.hide()
//                                constraintLayout.hide()
//                            } else {
//                                flippedText.show()
//                                flippedText.setOpacity(progress.toFloat() / 50)
//                                constraintLayout.show()
//                            }
//                            flippedText.invalidate()
//
//                        } catch (e: Exception) { }

                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}

                    override fun onStopTrackingTouch(seekBar: SeekBar?) {
                        index?.let { i ->
                            stickerList[i].shadowOpacity = mSeekOpacity!!.progress

                            stickerList[i].isShadow = seekBar!!.progress != 0
                            //TODO Add Operation in UndoRedo
                            if(stickerList[i].isFirstTimeApplyShadowOpacity){
                                val operation = UndoRedo.Operation()
                                operation.mShadowOpacity = 0
                                val action = UndoRedo(ACTION.ShadowOpacity, i, operation)
                                mUndo.add(action)
                                manageUndoRedoButton()
                                stickerList[i].isFirstTimeApplyShadowOpacity = false
                            }

                            val operation = UndoRedo.Operation()
                            operation.mShadowOpacity = seekBar.progress
                            val action = UndoRedo(ACTION.ShadowOpacity, i, operation)
                            mUndo.add(action)
                            manageUndoRedoButton()
                        }

                        mSeekSpace!!.enabled()
                        enableAllFontOption()
                    }
                })

                mSeekSpace!!.max = 120
                mSeekSpace!!.setOnSeekBarChangeListener(object :
                    SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(
                        seekBar: SeekBar?,
                        progress: Int,
                        fromUser: Boolean,
                    ) {
                        selectedSticker!!.textShadowProg = progress
                        if (fromUser) {
                            disableAllFontOption()
                            mSeekOpacity!!.disabled()
                        }
                        selectedSticker!!.invalidate()

//                        mStickerModel!!.spaceProgress = 160 - progress
//                        mStickerModel!!.spaceProgress = 160 - progress
//                        try {
//                            if (progress >= 4) {
//                                val flippedText =
//                                    context.selectedSticker!!.findViewById(
//                                        R.id.flippedText
//                                    ) as TextView
//                                val constraintLayout =
//                                    context.selectedSticker!!.findViewById(
//                                        R.id.shadowLayout
//                                    ) as ConstraintLayout
//
//                                val params: ViewGroup.MarginLayoutParams =
//                                    constraintLayout.layoutParams as ViewGroup.MarginLayoutParams
////                            params.topMargin = progress - 110
//                                params.topMargin = progress - 40
//                                constraintLayout.layoutParams = params
//                                flippedText.invalidate()
//                                stickerList[index!!].positionSpaceProgress = progress
//                            }
//                            isFromUndoRedo = false
//                        } catch (e: Exception) { }
//                        if (textView != null) {
//                            updateTextSticker(
//                                mStickerModel,
//                                mStickerModel!!.originalText,
//                                false
//                            )
//                        }
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}

                    override fun onStopTrackingTouch(seekBar: SeekBar?) {
                        index?.let { i ->
                            stickerList[i].spaceProgress = 160 - mSeekSpace!!.progress

                            //TODO Add Operation in UndoRedo
                            if(stickerList[i].isFirstTimeApplyShadowSpace){
                                val operation = UndoRedo.Operation()
                                operation.mShadowSpace = 0
                                val action = UndoRedo(ACTION.ShadowSpace, i, operation)
                                mUndo.add(action)
                                manageUndoRedoButton()
                                stickerList[i].isFirstTimeApplyShadowSpace = false
                            }

                            val operation = UndoRedo.Operation()
                            operation.mShadowSpace = seekBar!!.progress
                            val action = UndoRedo(ACTION.ShadowSpace, i, operation)
                            mUndo.add(action)
                            manageUndoRedoButton()
                        }

                        mSeekOpacity!!.enabled()
                        enableAllFontOption()
                    }
                })


    }

    private fun multiColorAdapter() {
        mMultiColorText.setBackgroundResource(R.drawable.bg_unlock_btn)
        mMultiColorText.setTextColor(Color.WHITE)
        mSingleColorText.setBackgroundResource(0)
        mSingleColorText.setTextColor(Color.BLACK)
        tvGradientColor.setTextColor(Color.BLACK)
        tvGradientColor.setBackgroundResource(0)
        val multiColorImgList = arrayListOf<Int>(
            R.drawable.z_multi2_1,
            R.drawable.z_multi2_2,
            R.drawable.z_multi2_3,
            R.drawable.z_multi2_4,
            R.drawable.z_multi2_5,
            R.drawable.z_multi2_6,
            R.drawable.z_multi2_7,
            R.drawable.z_multi2_8,
            R.drawable.z_multi2_9,
            R.drawable.z_multi2_10,
            R.drawable.z_multi2_11,
            R.drawable.z_multi2_12,
            R.drawable.z_multi2_13,
            R.drawable.z_multi3_1,
            R.drawable.z_multi3_2,
            R.drawable.z_multi3_3,
            R.drawable.z_multi3_4,
            R.drawable.z_multi3_5,
            R.drawable.z_multi3_6,
            R.drawable.z_multi3_7,
            R.drawable.z_multi3_8,
            R.drawable.z_multi3_9,
            R.drawable.z_multi3_10,
            R.drawable.z_multi3_11,
            R.drawable.z_multi3_12,
            R.drawable.z_multi3_13,
            R.drawable.z_multi4_1,
            R.drawable.z_multi4_2,
            R.drawable.z_multi4_3,
            R.drawable.z_multi4_4,
            R.drawable.z_multi4_5,
            R.drawable.z_multi4_6,
            R.drawable.z_multi4_7,
            R.drawable.z_multi4_8,
            R.drawable.z_multi4_9,
            R.drawable.z_multi4_10,
            R.drawable.z_multi4_11,
            R.drawable.z_multi4_12,
            R.drawable.z_multi4_13,
            R.drawable.z_multi5_1,
            R.drawable.z_multi5_2,
            R.drawable.z_multi5_3,
            R.drawable.z_multi5_4,
            R.drawable.z_multi5_5,
            R.drawable.z_multi5_6,
            R.drawable.z_multi5_7,
            R.drawable.z_multi5_8,
            R.drawable.z_multi5_9,
            R.drawable.z_multi5_10,
            R.drawable.z_multi5_11,
            R.drawable.z_multi5_12,
            R.drawable.z_multi5_13,
            R.drawable.z_multi5_14,
            R.drawable.z_multi5_15,
            R.drawable.z_multi5_16,
            R.drawable.z_multi5_17,
            R.drawable.z_multi5_18
        )

        val multi21 = arrayListOf<Int>(
            Color.parseColor("#c79237"),
            Color.parseColor("#000000")
        )
        val multi22 = arrayListOf<Int>(
            Color.parseColor("#fde8cd"),
            Color.parseColor("#8ad0bf")
        )
        val multi23 = arrayListOf<Int>(
            Color.parseColor("#fbeeac"),
            Color.parseColor("#8ac4d0")
        )
        val multi24 = arrayListOf<Int>(
            Color.parseColor("#6553de"),
            Color.parseColor("#63c9fa")
        )
        val multi25 = arrayListOf<Int>(
            Color.parseColor("#f34d5a"),
            Color.parseColor("#fbfbfb")
        )
        val multi26 = arrayListOf<Int>(
            Color.parseColor("#49c97e"),
            Color.parseColor("#ffd959")
        )
        val multi27 = arrayListOf<Int>(
            Color.parseColor("#09c5eb"),
            Color.parseColor("#f12a72")
        )
        val multi28 = arrayListOf<Int>(
            Color.parseColor("#da41e4"),
            Color.parseColor("#41d3e4")
        )
        val multi29 = arrayListOf<Int>(
            Color.parseColor("#f67280"),
            Color.parseColor("#35477d")
        )
        val multi210 = arrayListOf<Int>(
            Color.parseColor("#ea907a"),
            Color.parseColor("#4f8a8b")
        )
        val multi211 = arrayListOf<Int>(
            Color.parseColor("#951556"),
            Color.parseColor("#e9b5d2")
        )
        val multi212 = arrayListOf<Int>(
            Color.parseColor("#ffb5b5"),
            Color.parseColor("#407088")
        )
        val multi213 = arrayListOf<Int>(
            Color.parseColor("#949cdf"),
            Color.parseColor("#a7c5eb")
        )

        val multi31 = arrayListOf<Int>(
            Color.parseColor("#d67e20"),
            Color.parseColor("#f2f0f0"),
            Color.parseColor("#1e8514")
        )
        val multi32 = arrayListOf<Int>(
            Color.parseColor("#92039a"),
            Color.parseColor("#e36611"),
            Color.parseColor("#0891d3")
        )
        val multi33 = arrayListOf<Int>(
            Color.parseColor("#02b6cd"),
            Color.parseColor("#f15a5b"),
            Color.parseColor("#faa71a")
        )
        val multi34 = arrayListOf<Int>(
            Color.parseColor("#8a73b4"),
            Color.parseColor("#02b7ce"),
            Color.parseColor("#f15b5c")
        )
        val multi35 = arrayListOf<Int>(
            Color.parseColor("#ffd300"),
            Color.parseColor("#f48ab5"),
            Color.parseColor("#71c462")
        )
        val multi36 = arrayListOf<Int>(
            Color.parseColor("#fe403e"),
            Color.parseColor("#ff852e"),
            Color.parseColor("#febf31")
        )
        val multi37 = arrayListOf<Int>(
            Color.parseColor("#d566d4"),
            Color.parseColor("#399a39"),
            Color.parseColor("#30b1e1")
        )
        val multi38 = arrayListOf<Int>(
            Color.parseColor("#ffe547"),
            Color.parseColor("#49d0ff"),
            Color.parseColor("#ff4fef")
        )
        val multi39 = arrayListOf<Int>(
            Color.parseColor("#3f3351"),
            Color.parseColor("#864879"),
            Color.parseColor("#e9a6a6")
        )
        val multi310 = arrayListOf<Int>(
            Color.parseColor("#035397"),
            Color.parseColor("#5089c6"),
            Color.parseColor("#ffaa4c")
        )
        val multi311 = arrayListOf<Int>(
            Color.parseColor("#94b49f"),
            Color.parseColor("#b4cfb0"),
            Color.parseColor("#e5e3c9")
        )
        val multi312 = arrayListOf<Int>(
            Color.parseColor("#e3bec6"),
            Color.parseColor("#efdad7"),
            Color.parseColor("#9ad0ec")
        )
        val multi313 = arrayListOf<Int>(
            Color.parseColor("#e05d5d"),
            Color.parseColor("#ffb344"),
            Color.parseColor("#00a19d")
        )

        val multi41 = arrayListOf<Int>(
            Color.parseColor("#a33cc8"),
            Color.parseColor("#ff613d"),
            Color.parseColor("#ffc43d"),
            Color.parseColor("#55cfc3")
        )
        val multi42 = arrayListOf<Int>(
            Color.parseColor("#e43137"),
            Color.parseColor("#005dd0"),
            Color.parseColor("#eeac08"),
            Color.parseColor("#7aa320")
        )
        val multi43 = arrayListOf<Int>(
            Color.parseColor("#7cf2bb"),
            Color.parseColor("#fff927"),
            Color.parseColor("#fe6383"),
            Color.parseColor("#ffac7e")
        )
        val multi44 = arrayListOf<Int>(
            Color.parseColor("#ef025e"),
            Color.parseColor("#2e45c4"),
            Color.parseColor("#ff5600"),
            Color.parseColor("#06a4ff")
        )
        val multi45 = arrayListOf<Int>(
            Color.parseColor("#0bb592"),
            Color.parseColor("#eb4d56"),
            Color.parseColor("#d3e761"),
            Color.parseColor("#c89add")
        )
        val multi46 = arrayListOf<Int>(
            Color.parseColor("#582da7"),
            Color.parseColor("#44e700"),
            Color.parseColor("#025ec0"),
            Color.parseColor("#fee500")
        )
        val multi47 = arrayListOf<Int>(
            Color.parseColor("#0262aa"),
            Color.parseColor("#00b727"),
            Color.parseColor("#cc42fa"),
            Color.parseColor("#ff8b03")
        )
        val multi48 = arrayListOf<Int>(
            Color.parseColor("#fcde29"),
            Color.parseColor("#d52d5b"),
            Color.parseColor("#0284ab"),
            Color.parseColor("#df4e38")
        )
        val multi49 = arrayListOf<Int>(
            Color.parseColor("#94b4a4"),
            Color.parseColor("#d2f5e3"),
            Color.parseColor("#e5c5b5"),
            Color.parseColor("#f4d9c6")
        )
        val multi410 = arrayListOf<Int>(
            Color.parseColor("#00334e"),
            Color.parseColor("#145374"),
            Color.parseColor("#5588a3"),
            Color.parseColor("#e8e8e8")
        )
        val multi411 = arrayListOf<Int>(
            Color.parseColor("#f7e8f6"),
            Color.parseColor("#f1c6e7"),
            Color.parseColor("#e5b0ea"),
            Color.parseColor("#bd83ce")
        )
        val multi412 = arrayListOf<Int>(
            Color.parseColor("#fb5b5a"),
            Color.parseColor("#bc4873"),
            Color.parseColor("#472b62"),
            Color.parseColor("#003f5c")
        )
        val multi413 = arrayListOf<Int>(
            Color.parseColor("#321d2f"),
            Color.parseColor("#3d2e4f"),
            Color.parseColor("#393e6f"),
            Color.parseColor("#4c5f7a")
        )

        val multi51 = arrayListOf<Int>(
            Color.parseColor("#43c7da"),
            Color.parseColor("#3fa71b"),
            Color.parseColor("#e54cdf"),
            Color.parseColor("#ffb22b"),
            Color.parseColor("#f43b38")
        )
        val multi52 = arrayListOf<Int>(
            Color.parseColor("#8cf267"),
            Color.parseColor("#fe7742"),
            Color.parseColor("#d83755"),
            Color.parseColor("#7035a2"),
            Color.parseColor("#04a0f3")
        )
        val multi53 = arrayListOf<Int>(
            Color.parseColor("#ffef00"),
            Color.parseColor("#ff8900"),
            Color.parseColor("#83f600"),
            Color.parseColor("#7035a2"),
            Color.parseColor("#0368ce")
        )
        val multi54 = arrayListOf<Int>(
            Color.parseColor("#d9e613"),
            Color.parseColor("#d098f0"),
            Color.parseColor("#2be0d5"),
            Color.parseColor("#04bae9"),
            Color.parseColor("#ff63de")
        )
        val multi55 = arrayListOf<Int>(
            Color.parseColor("#da43b5"),
            Color.parseColor("#06abec"),
            Color.parseColor("#fbdd00"),
            Color.parseColor("#e8f0f2"),
            Color.parseColor("#ff688e")
        )
        val multi56 = arrayListOf<Int>(
            Color.parseColor("#d64eff"),
            Color.parseColor("#feb41a"),
            Color.parseColor("#27d5ff"),
            Color.parseColor("#5e5e5e"),
            Color.parseColor("#90fc1c")
        )
        val multi57 = arrayListOf<Int>(
            Color.parseColor("#e8985d"),
            Color.parseColor("#ee2b5d"),
            Color.parseColor("#9a29a3"),
            Color.parseColor("#3f26f6"),
            Color.parseColor("#39c4fa")
        )
        val multi58 = arrayListOf<Int>(
            Color.parseColor("#fcca0c"),
            Color.parseColor("#2091d0"),
            Color.parseColor("#90c143"),
            Color.parseColor("#7852a3"),
            Color.parseColor("#ef8922")
        )
        val multi59 = arrayListOf<Int>(
            Color.parseColor("#9fa2cc"),
            Color.parseColor("#896c7c"),
            Color.parseColor("#7d81ba"),
            Color.parseColor("#17222b"),
            Color.parseColor("#ddac98")
        )
        val multi510 = arrayListOf<Int>(
            Color.parseColor("#4c1130"),
            Color.parseColor("#741b47"),
            Color.parseColor("#990000"),
            Color.parseColor("#ea9999"),
            Color.parseColor("#ffd966")
        )
        val multi511 = arrayListOf<Int>(
            Color.parseColor("#c7daa9"),
            Color.parseColor("#a6c578"),
            Color.parseColor("#88b04b"),
            Color.parseColor("#6b8b3a"),
            Color.parseColor("#51692c")
        )
        val multi512 = arrayListOf<Int>(
            Color.parseColor("#505a56"),
            Color.parseColor("#67787d"),
            Color.parseColor("#8aa4b3"),
            Color.parseColor("#a7c4dd"),
            Color.parseColor("#c4deff")
        )
        val multi513 = arrayListOf<Int>(
            Color.parseColor("#655f68"),
            Color.parseColor("#816b6a"),
            Color.parseColor("#a47a6a"),
            Color.parseColor("#cb9576"),
            Color.parseColor("#edb587")
        )
        val multi514 = arrayListOf<Int>(
            Color.parseColor("#ffbbbb"),
            Color.parseColor("#ffe4c0"),
            Color.parseColor("#f0ffc2"),
            Color.parseColor("#bffff0"),
            Color.parseColor("#f6dfeb")
        )
        val multi515 = arrayListOf<Int>(
            Color.parseColor("#f0eee0"),
            Color.parseColor("#fffdf1"),
            Color.parseColor("#cfdbc6"),
            Color.parseColor("#f4e1db"),
            Color.parseColor("#f6e9d3")
        )
        val multi516 = arrayListOf<Int>(
            Color.parseColor("#e4bad4"),
            Color.parseColor("#f6dfeb"),
            Color.parseColor("#edffec"),
            Color.parseColor("#caf7e3"),
            Color.parseColor("#d3eef6")
        )
        val multi517 = arrayListOf<Int>(
            Color.parseColor("#ffc1b6"),
            Color.parseColor("#ffdcb8"),
            Color.parseColor("#ffeebb"),
            Color.parseColor("#fdffbc"),
            Color.parseColor("#f1f2d6")
        )
        val multi518 = arrayListOf<Int>(
            Color.parseColor("#83a9d4"),
            Color.parseColor("#b9d7ea"),
            Color.parseColor("#d6e6f2"),
            Color.parseColor("#e6f1f9"),
            Color.parseColor("#f7fbfc")
        )
        multiColorList.clear()
        multiColorList.add(multi21)
        multiColorList.add(multi22)
        multiColorList.add(multi23)
        multiColorList.add(multi24)
        multiColorList.add(multi25)
        multiColorList.add(multi26)
        multiColorList.add(multi27)
        multiColorList.add(multi28)
        multiColorList.add(multi29)
        multiColorList.add(multi210)
        multiColorList.add(multi211)
        multiColorList.add(multi212)
        multiColorList.add(multi213)
        multiColorList.add(multi31)
        multiColorList.add(multi32)
        multiColorList.add(multi33)
        multiColorList.add(multi34)
        multiColorList.add(multi35)
        multiColorList.add(multi36)
        multiColorList.add(multi37)
        multiColorList.add(multi38)
        multiColorList.add(multi39)
        multiColorList.add(multi310)
        multiColorList.add(multi311)
        multiColorList.add(multi312)
        multiColorList.add(multi313)
        multiColorList.add(multi41)
        multiColorList.add(multi42)
        multiColorList.add(multi43)
        multiColorList.add(multi44)
        multiColorList.add(multi45)
        multiColorList.add(multi46)
        multiColorList.add(multi47)
        multiColorList.add(multi48)
        multiColorList.add(multi49)
        multiColorList.add(multi410)
        multiColorList.add(multi411)
        multiColorList.add(multi412)
        multiColorList.add(multi413)
        multiColorList.add(multi51)
        multiColorList.add(multi52)
        multiColorList.add(multi53)
        multiColorList.add(multi54)
        multiColorList.add(multi55)
        multiColorList.add(multi56)
        multiColorList.add(multi57)
        multiColorList.add(multi58)
        multiColorList.add(multi59)
        multiColorList.add(multi510)
        multiColorList.add(multi511)
        multiColorList.add(multi512)
        multiColorList.add(multi513)
        multiColorList.add(multi514)
        multiColorList.add(multi515)
        multiColorList.add(multi516)
        multiColorList.add(multi517)
        multiColorList.add(multi518)

        multiColorAdepter = MultipleColorAdepter(
            this,
            multiColorImgList,
            multiColorList,
            object : MultipleColorAdepter.OnClickMultiColorListener {
                @SuppressLint("NotifyDataSetChanged")
                override fun onClickMulti(position: Int) {
                    index?.let { i ->
                        //TODO Remove Toast Functionality
//                        if (stickerList[i].isApplyStroke){
//                            showToast("You can't use multi color while using stroke")
//                            return
//                        }
//                        if (!isFromUndoRedo){
//                            if (stickerList[i].isBold) {
//                                showToast("You can't use multiple color,\nWhen you applied bold")
//                                return
//                            }
//                            if (stickerList[i].isItalic) {
//                                showToast("You can't use multiple color,\nWhen you applied italic")
//                                return
//                            }
//                            if (stickerList[i].isUnderline) {
//                                showToast("You can't use multiple color,\nWhen you applied underline")
//                                return
//                            }
//                            if (stickerList[i].isCurve) {
//                                showToast("You can't use multiple color,\nWhen you use curve")
//                                return
//                            }
//                            if (Constants.isContainEmoji(originalText)) {
//                                showToast("You can't use multiple color,\nWhen text contains emoji")
//                                return
//                            }
//                        }

                        Log.d(TAG, "onClickMulti: tmp ${!isFromUndoRedo}")
                        if (!isFromUndoRedo) {
                            //TODO Add Operation in UndoRedo
                            addWhiteColorIfFirstTime()
                            val operation = UndoRedo.Operation()
                            operation.mMultiColor = position
                            val action = UndoRedo(ACTION.ChangeMultipleColor, i, operation)
                            Log.d(TAG, "Undo Redo Added ACTION.ChangeMultipleColor 1")
                            mUndo.add(action)
                            manageUndoRedoButton()
                        }
                        isFromUndoRedo = false

                        stickerList[i].isGradient = false
                        stickerList[i].isTexture = false
                        stickerList[i].isShadow = false
                        stickerList[i].isSingleColor = false
                        stickerList[i].singleColorPos = -1
                        patternPosition = -1
                        textureAdepter?.notifyDataSetChanged()
                        gradientPosition = -1
                        stickerList[i].positionGradient = -1
                        gradientAdepter?.notifyDataSetChanged()
                        stickerList[i].positionTexture = -1

                        stickerList[i].isMultiColor = true
                        multiColorPosition = position
                        stickerList[i].positionMultiple = position
                        multiColorAdepter?.notifyDataSetChanged()
                        if (selectedSticker?.stickerType == TYPE.TEXT_STICKER)
                            selectedSticker?.setMulticolor(multiColorList[position])
                    }
                }
            })

        val gridLayoutManager = GridLayoutManager(applicationContext, 1)
        gridLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
        recyclerGradientColor!!.layoutManager = gridLayoutManager
        recyclerGradientColor!!.adapter = multiColorAdepter

    }

    @SuppressLint("NotifyDataSetChanged")
    private fun gradientColorAdapter() {
        gradientColorList.clear()
        gradientColorList.add("#FDC928,#FFFFFF")
        gradientColorList.add("#D5B33E,#CB403C")
        gradientColorList.add("#D5B33E,#5E8915")
        gradientColorList.add("#56DC3E,#EB6561")
        gradientColorList.add("#2478FF,#E8F2FF")
        gradientColorList.add("#131CCF,#BC00E5")
        gradientColorList.add("#DF15AF,#5F236C")
        gradientColorList.add("#3FF65E,#A3FFA7")
        gradientColorList.add("#27B7F5,#D43F49")
        gradientColorList.add("#242016,#EBECE8")
        gradientColorList.add("#F90062,#B5992E")
        gradientColorList.add("#48DC3E,#EE7017")
        gradientColorList.add("#D9B23B,#FEEDA5,#D9B23B")
        gradientColorList.add("#3B2666,#B778EC")
        gradientColorList.add("#B99AE2,#F97392,#FEE4AC")
        gradientColorList.add("#D64155,#89226B")
        gradientColorList.add("#87CCD0,#6C49DB")
        gradientColorList.add("#CF2B00,#EEED36,#CF2B00")
        gradientColorList.add("#F26DF6,#1C94FF")
        gradientColorList.add("#FF9933,#FFFFFF,#008000")
        gradientColorList.add("#FD8A00,#0B6D28")
        for (i in mGradinetArray.indices) {
            if (mGradinetArrayCenter[i] == "") {
                gradientColorList.add(mGradinetArray[i] + "," + mGradinetArrayTwo[i])
            } else {
                gradientColorList.add(mGradinetArray[i] + "," + mGradinetArrayCenter[i] + "," + mGradinetArrayTwo[i])
            }
        }

        gradientAdepter = GradientTextColorAdepter(
            context,
            0,
            gradientColorList
        ) {
            index?.let { i ->
                if (stickerList[i].isApplyStroke){
                     showToast("You can't use gradient color while using stroke")
                     gradientPosition = -1
                     return@GradientTextColorAdepter
                 }

                if (!isFromUndoRedo){
                    //TODO Add Operation in UndoRedo
                    addWhiteColorIfFirstTime()
                    val operation = UndoRedo.Operation()
                    operation.mGradientColor = it
                    val action = UndoRedo(ACTION.ChangeGradientColor, i, operation)
                    Log.d(TAG, "Undo Redo Added ACTION.ChangeGradientColor 1")
                    mUndo.add(action)
                    manageUndoRedoButton()
                }

                multiColorAdepter?.notifyDataSetChanged()
                stickerList[i].isGradient = true
                stickerList[i].isShadow = false
                stickerList[i].isTexture = false
                stickerList[i].isSingleColor = false
                stickerList[i].isMultiColor = false
                stickerList[i].singleColorPos = -1

                mStickerModel!!.shadowColor = 0
                mStickerModel!!.positionGradient = it
                stickerList[i].positionGradient = it

                mStickerModel!!.storeWidth = 0

                selectedSticker!!.setGradient(gradientColorList[it].split(",".toRegex()).toTypedArray())
                selectedSticker!!.invalidate()

                stickerList[i].positionTexture = -1
                multiColorPosition = -1
                stickerList[i].positionMultiple = -1
                multiColorAdepter?.notifyDataSetChanged()
                patternPosition = -1
                textureAdepter?.notifyDataSetChanged()
                stickerList[i].positionGradient = it
            }
        }
        val gridLayoutManager = GridLayoutManager(applicationContext, 1)
        gridLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
        recyclerColorStyle.layoutManager = gridLayoutManager
        recyclerColorStyle.adapter = gradientAdepter
    }

    private fun addWhiteColorIfFirstTime() {
        index?.let { i ->
            if (stickerList[i].isAbleToAddWhiteColor){
                //TODO Add Operation in UndoRedo
                val operation = UndoRedo.Operation()
                operation.singleColor = -1
                val action = UndoRedo(ACTION.ChangeSingleColor, i, operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeSingleColor 2")
                mUndo.add(action)
                manageUndoRedoButton()
                stickerList[i].isAbleToAddWhiteColor = false
            }
        }
    }

    //Display texture walls of text
    private fun loadTextTexture() {
        getPatternData()
        textureAdepter = TextureAdepter(context, mPatternList, mPatternValList) {

            //TODO Remove Toast Functionality
//            if (stickerList[index!!].isApplyStroke){
//                showToast("You can't use pattern while using stroke")
//                return@TextureAdepter
//            }
//            if (stickerList[index!!].isGlow){
//                showToast("You can't use pattern while using glow")
//                return@TextureAdepter
//            }

            if (mPatternValList[it] == "1") {
                if (isOnline()) {
                    Log.d(TAG, "loadTextTexture: online")
                    if (RewardedAdHelper.instence != null
                        && RewardedAdHelper.instence!!.loadRewardedAd(context) != null
                    ) {
                        showAdDialog(it + 1, "Pattern")
                    } else {
                        Toast.makeText(
                            context,
                            resources.getString(R.string.try_again_later),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        context,
                        "Please check internet connection.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else if (mPatternValList[it] == "2") {
                premiumLauncher.launch(Intent(context, SubscriptionActivity::class.java))
                Constants.buyFromAddTextActivity = true
            } else {
                onPatternClick(it, null)
            }
        }
        val gridLayoutManager = GridLayoutManager(applicationContext, 2)
        gridLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
        mRecyclerTexture.layoutManager = gridLayoutManager
        mRecyclerTexture.adapter = textureAdepter
    }

    //Font Style
    private fun loadFontStyle() {
        loadFonts()
        setFontsList()
    }

    private fun addFontInData() {
        try {
            for (i in fontList.indices) {
                dbHelper.insertProFontData(
                    i,
                    "$FontFolder/" + fontList[i],
                    "0",
                    "0",
                    1,
                    "$ASSET_PATH/$FontFolder/${fontList[i]}"
                )
                if (i in 5..9) {
                    dbHelper.insertData(
                        i,
                        "$FontFolder/" + fontList[i],
                        "1",
                        "0",
                        1,
                        "$ASSET_PATH/$FontFolder/${fontList[i]}"
                    )
                } else if (i == 10 || i == 15) {
                    dbHelper.insertData(
                        i,
                        "$FontFolder/" + fontList[i],
                        "0",
                        "1",
                        1,
                        "$ASSET_PATH/$FontFolder/${fontList[i]}"
                    )
                } else {
                    dbHelper.insertData(
                        i,
                        "$FontFolder/" + fontList[i],
                        "0",
                        "0",
                        1,
                        "$ASSET_PATH/$FontFolder/${fontList[i]}"
                    )
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun addFontInDataFromApi() {
        if (InternetConnection.checkConnection(this)) {
            var apiInterface: APIInterface?
            apiInterface = APIClient.getClient()!!.create(APIInterface::class.java)
            if (apiInterface != null) {
                val call = apiInterface.parameterList
                call.enqueue(object : Callback<Response> {
                    override fun onResponse(
                        call: Call<Response>,
                        response: retrofit2.Response<Response>,
                    ) {
                        if (response.isSuccessful) {
                            var count = dbHelper.allData.count
                            var proCount = dbHelper.allProData.count
                            if (!response.body()!!.parameters.isNullOrEmpty()) {
                                response.body()!!.parameters!!.filterIndexed { _, dataItem ->
                                    if (dataItem!!.name == "Fonts" || dataItem.id == 248) {
                                        dataItem.categoryParameters!!.filterIndexed { _, imagesItem ->
//                                            val fZipPath = "$cacheDir/${Constants.downloadedFont}/${imagesItem!!.zip}"
//                                            val fileName = imagesItem.zip
                                            val thumbImg = imagesItem.thumbImage
                                            dbHelper.insertProFontData(
                                                proCount,
                                                "${imagesItem.name}.ttf",
                                                "0",
                                                "0",
                                                0,
                                                imagesItem.zip,
                                                thumbImg
                                            )
                                            proCount++
                                            if (imagesItem.is_premium == 1 && imagesItem.coins!! > 0) {
                                                dbHelper.insertData(
                                                    count,
                                                    "${imagesItem.name}.ttf",
                                                    "1",
                                                    "0",
                                                    0,
                                                    imagesItem.zip,
                                                    thumbImg
                                                )
                                                count++
                                            } else if (imagesItem.is_premium == 1 && imagesItem.coins == 0) {
                                                dbHelper.insertData(
                                                    count,
                                                    "${imagesItem.name}.ttf",
                                                    "0",
                                                    "1",
                                                    0,
                                                    imagesItem.zip,
                                                    thumbImg
                                                )
                                                count++
                                            } else if (imagesItem.is_premium == 0) {
                                                dbHelper.insertData(
                                                    count,
                                                    "${imagesItem.name}.ttf",
                                                    "0",
                                                    "0",
                                                    0,
                                                    imagesItem.zip,
                                                    thumbImg
                                                )
                                                count++
                                            }
                                            true
                                        }
                                    }
                                    getFontData(mIsSubScribe)
                                    setFontsList()
                                    true
                                }
                            }
                        } else {
                            //showToast(resources.getString(R.string.try_again_later))
                        }
                    }

                    override fun onFailure(call: Call<Response>, t: Throwable) {
                        showToast(resources.getString(R.string.try_again_later))
                    }
                })
            }
        } else {
//            Toast.makeText(this, "No internet connection!", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun downloadFontZipFile(
        url: String,
        myholder: FontStyleAdepter.MyViewHolder,
        fPosition: Int,
    ) {
        val path = cacheDir.toString() + File.separator + downloadedFont + File.separator
        val fileName = "$fPosition.zip"
        PRDownloader.download(
            url,
            path,
            fileName
        )
            .build()
            .setOnStartOrResumeListener {
            }
            .setOnPauseListener {
                myholder.itemView.enabled()
            }
            .setOnCancelListener {
                myholder.itemView.enabled()
            }
            .setOnProgressListener {
                myholder.mDownloadText.text = "${((it.currentBytes * 100) / it.totalBytes).toInt()}%"
                if (myholder.mDownloadText.text == "100%") {
                    myholder.mDownloadBtn.hide()
                    myholder.itemView.enabled()
                }
            }
            .start(object : OnDownloadListener {
                override fun onDownloadComplete() {
                    myholder.itemView.enabled()
                    try {
                        unzip(File("$path$fileName"), File(cacheDir.toString() + File.separator + downloadedFont))
                        val fontPath = "$cacheDir/$downloadedFont/${fontStyleList[fPosition]}"
                        dbHelper.updateDownloadedFontData(fPosition, 1, fontPath)
                        getFontData(mIsSubScribe)
                        setFontsList()
                        mRecyclerFontStyle.scrollToPosition(fPosition)

                        val dFontPath = "$cacheDir/$downloadedFont/${fontStyleList[fPosition]}"
                        if (File(dFontPath).exists()) {
                            stickerList[index!!].positionFont = fPosition
                            setFontTypeFace(fPosition, Typeface.createFromFile(dFontPath))
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }

                override fun onError(error: com.downloader.Error) {
                    myholder.itemView.enabled()
                }

            })
    }

    private fun getFontData(isSubscribe: Boolean) {
        val res = dbHelper.allData
        val res1 = dbHelper.allProFontData

        fontStyleList = arrayListOf()
        fontValList = arrayListOf()
        primeFont = arrayListOf()
        fontZipPath = arrayListOf()
        isDownloadedOrNot = arrayListOf()

        if (isSubscribe) {
            fontStyleList.clear()
            fontValList.clear()
            primeFont.clear()
            fontZipPath.clear()
            isDownloadedOrNot.clear()
            fontThumbImg.clear()

            while (res1.moveToNext()) {
                val fontName = res1.getString(1)
                val fontVal = res1.getString(2)
                val primeFontVal = res1.getString(3)
                val isDownloaded = res1.getString(4)
                val fontZipFilePath = res1.getString(5)
                val thumb = res1.getString(6)
                Log.d(TAG, "getFontData: Fontname Prime $fontName")
                fontStyleList.add(fontName!!)
                fontValList.add(fontVal!!)
                primeFont.add(primeFontVal!!)
                fontZipPath.add(fontZipFilePath!!)
                isDownloadedOrNot.add(isDownloaded!!)
                if (thumb.isNullOrEmpty()) {
                    fontThumbImg.add("")
                } else {
                    fontThumbImg.add(thumb)
                }
            }
            res1.close()
        } else {
            fontStyleList.clear()
            fontValList.clear()
            primeFont.clear()
            fontZipPath.clear()
            isDownloadedOrNot.clear()
            fontThumbImg.clear()

            while (res.moveToNext()) {
                val fontName = res.getString(1)
                val fontVal = res.getString(2)
                val primeFontVal = res.getString(3)
                val isDownloaded = res.getString(4)
                val fontZipFilePath = res.getString(5)
                val thumb = res.getString(6)
                Log.d(TAG, "getFontData: Fontname $fontName")
                fontStyleList.add(fontName!!)
                fontValList.add(fontVal!!)
                primeFont.add(primeFontVal!!)
                fontZipPath.add(fontZipFilePath!!)
                isDownloadedOrNot.add(isDownloaded!!)
                if (thumb.isNullOrEmpty()) {
                    fontThumbImg.add("")
                } else {
                    fontThumbImg.add(thumb)
                }
            }
            res.close()

        }

    }

    private fun getFrameData() {
        val list: Array<String>? = assets.list("framelist")
        frameList = arrayListOf()
        frameValList = arrayListOf()
        val mFrameOpen = DBHelper(this).allOpenFrameData
        list?.sort()
        list?.filterIndexed { index, s ->
            frameName = "$ASSET_PATH/framelist/$s"
            frameVal = "0"

            if (index == 0) {
                frameVal = "0"
            }
            if (index in 13..15) {
                frameVal = "1"
            }
            if (index in 3..5) {
                frameVal = "2"
            }
            if (index == 7) {
                frameVal = "2"
            }
            if (index == 9) {
                frameVal = "1"
            }
            try {
                mFrameOpen.moveToFirst()
                if (mFrameOpen.getString(1) == frameName) {
                    frameVal = "0"
                }
                while (mFrameOpen.moveToNext()) {
                    if (mFrameOpen.getString(1) == frameName) {
                        frameVal = "0"
                    }
                }
            } catch (e: Exception) {
            }
            if (mIsSubScribe) {
                frameVal = "0"
            }
            frameList.add(frameName!!)
            frameValList.add(frameVal!!)
        }
    }

    private fun getPatternData() {
        val list: Array<String>? = assets.list("textures")
        mPatternList = arrayListOf()
        mPatternValList = arrayListOf()
        val mFrameOpen = DBHelper(this).allOpenPatternData
        list?.sort()

        list?.filterIndexed { index, s ->
            patternName = "$ASSET_PATH/textures/$s"
            patternVal = "0"

            if (index in 13..15) {
                patternVal = "1"
            }
            if (index in 3..5) {
                patternVal = "2"
            }
            if (index == 7) {
                patternVal = "2"
            }
            if (index == 9) {
                patternVal = "1"
            }
            try {
                mFrameOpen.moveToFirst()
                if (mFrameOpen.getString(1) == patternName) {
                    patternVal = "0"
                }
                while (mFrameOpen.moveToNext()) {
                    if (mFrameOpen.getString(1) == patternName) {
                        patternVal = "0"
                    }
                }
            } catch (e: Exception) {
            }
            if (mIsSubScribe) {
                patternVal = "0"
            }
            mPatternList.add(patternName!!)
            mPatternValList.add(patternVal!!)
        }

    }

    private fun loadFonts() {
        var mTmp = true
        val count = dbHelper.allData.count
        if (count <= Constants.totalAssetsFont && count != 0) {
            addFontInDataFromApi()
            isFontApiDataLoaded = true
            mTmp = false
        }
        if (dbHelper.allData.count == 0 || MySharedPreferences(
                this
            ).isFont == true || MySharedPreferences(
                this
            ).isNewFont) {
            if (mTmp) {
                addFontInDataFromApi()
                isFontApiDataLoaded = true
            }
            addFontInData()
            //addFontInDataFromApi()
        }
        getFontData(mIsSubScribe)
        MySharedPreferences(this).isFont = false
        MySharedPreferences(this).isNewFont = false
        setFontsList()
    }

    private fun setFontsList() {
        val gridLayoutManager = GridLayoutManager(applicationContext, 2)
        gridLayoutManager.orientation = LinearLayoutManager.HORIZONTAL

        fontAdapter = FontStyleAdepter(
            this,
            fontStyleList,
            fontValList,
            primeFont,
            isDownloadedOrNot,
            fontThumbImg,
            object : FontStyleAdepter.setOnItemClickListenerFont {
                @SuppressLint("NotifyDataSetChanged")
                override fun OnItemClickedFont(
                    position: Int,
                    myholder: FontStyleAdepter.MyViewHolder,
                ) {
                    mTmpHolder = myholder
                    if (fontValList[position] == "1") {
                        if (isOnline()) {
                            if (RewardedAdHelper.instence != null
                                && RewardedAdHelper.instence!!.loadRewardedAd(context) != null
                            ) {
                                showAdDialog(position, "font")
                            } else {
                                Toast.makeText(context, resources.getString(R.string.try_again_later), Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            showToast("Please check internet connection.")
                            fontAdapter!!.notifyDataSetChanged()
                        }
                    } else if (primeFont[position] == "1") {
                        premiumLauncher.launch(Intent(context, SubscriptionActivity::class.java))
                        Constants.buyFromAddTextActivity = true
                        if (mIsSubScribe) {
                            if (fontStyleList[position].contains(FontFolder)) {
                                setFontTypeFace(position, Typeface.createFromAsset(assets, fontStyleList[position]))
                            } else {
                                setFontTypeFace(position, Typeface.createFromFile(fontStyleList[position]))
                            }
                            hideKeyboard()
                        }
                    } else {
                        fontPosition = position
                        if (fontStyleList[position].contains(FontFolder)) {
                            stickerList[index!!].positionFont = position
                            setFontTypeFace(position, Typeface.createFromAsset(assets, fontStyleList[position]))
                        } else {
                            val dFontPath = "$cacheDir/$downloadedFont/${fontStyleList[position]}"
                            if (File(dFontPath).exists()) {
                                selectedSticker!!.setTypeface(Typeface.createFromFile(dFontPath))
                                hideKeyboard()
                                stickerList[index!!].positionFont = position
                                setFontTypeFace(position, Typeface.createFromFile(dFontPath))
                            } else {
                                downloadFontZipFile(fontZipPath[position], myholder, position)
                            }
                        }
                        hideKeyboard()
                        fontAdapter!!.notifyDataSetChanged()
                        addFontOperationInUndoRedo(position)
                    }

                }

                @SuppressLint("NotifyDataSetChanged")
                override fun OnItemClickedFont(position: Int) {
                    index?.let { i ->
                        stickerList[i].positionFont = position
                        if (fontStyleList[position].contains(FontFolder)) {
                            setFontTypeFace(position, Typeface.createFromAsset(assets, fontStyleList[position]))
                        } else {
                            val dFontPath = "$cacheDir/$downloadedFont/${fontStyleList[position]}"
                            if (File(dFontPath).exists()) {
                                setFontTypeFace(position, Typeface.createFromFile(dFontPath))
                                hideKeyboard()
                                fontAdapter!!.notifyDataSetChanged()
//                            updateFontStyle(position)
                            }
                        }
                        hideKeyboard()
                        fontAdapter!!.notifyDataSetChanged()
//                    updateFontStyle(position)
                    }

                }
            })
        mRecyclerFontStyle.layoutManager = gridLayoutManager
        mRecyclerFontStyle.adapter = fontAdapter
    }

    private fun addFontOperationInUndoRedo(position: Int) {
        if (!isFromUndoRedo){
            index?.let { i ->
                if (stickerList[i].isFirstTimeChangeFont){
                    val operation = UndoRedo.Operation()
                    operation.typeface = selectedSticker?.getTypeface()
                    operation.fontPosition = -1
                    val action = UndoRedo(ACTION.ChangeFont, i, operation)
                    Log.d(TAG, "Undo Redo Added ACTION.ChangeFont 1")
                    mUndo.add(action)
                    manageUndoRedoButton()
                    stickerList[i].isFirstTimeChangeFont = false
                }

                //TODO Add Operation in UndoRedo
                val operation = UndoRedo.Operation()
                operation.typeface = selectedSticker?.getTypeface()
                operation.fontPosition = position
                val action = UndoRedo(ACTION.ChangeFont, i, operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeFont 2")
                mUndo.add(action)
                manageUndoRedoButton()
            }
        }
        isFromUndoRedo = false
    }

    private fun setFontTypeFace(position: Int, typeFace: Typeface){
        Log.d(TAG, "setFontTypeFace: position $position index $index typeFace $typeFace")
        index?.let { i ->
            fontPosition = position
            stickerList[i].positionFont = position
            selectedSticker?.setTypeface(typeFace)
            selectedSticker?.textView!!.typeface = typeFace
        }
    }

    /*private fun updateFontStyle(position: Int) {
        index?.let { i ->
            stickerList[i].typeface = selectedSticker?.getTypeface()
            stickerList[i].positionFont = position
            strokeMenu("curving")
        }
    }*/

    @Throws(IOException::class)
    fun unzip(zipFile: File?, targetDirectory: File) {
        val zis = ZipInputStream(
            BufferedInputStream(FileInputStream(zipFile))
        )
        try {
            var ze: ZipEntry
            var count: Int
            val buffer = ByteArray(8192)
            while ((zis.nextEntry.also { ze = it }) != null) {
                val file = File(targetDirectory, ze.name)
                val dir = if (ze.isDirectory) file else file.parentFile
                if ((dir != null) && !dir.isDirectory && !dir.mkdirs()) throw FileNotFoundException(
                    "Failed to ensure directory: " +
                            dir.absolutePath
                )
                if (ze.isDirectory) continue
                val fout = FileOutputStream(file)
                try {
                    while ((zis.read(buffer).also { count = it }) != -1) fout.write(
                        buffer,
                        0,
                        count
                    )
                } finally {
                    fout.close()
                }
            }
        } catch (e: Exception) {
        } finally {
            Constants.isStartDownloadFont = false
            zis.close()
            //loadData()
        }
    }

    private fun showAdDialog(position: Int, adapter: String) {
        if (adapter == "font") {
            Log.d(TAG, "showAdDialog: $position")
            watchAdDialog = WatchAdDialogFragment(
                "Unlock Font",
                "Get PRO",
                "To Access All Fonts",
                R.drawable.ic_dialog_font,
                "Watch Video Ad",
                "To Use This Font"
            )
            { s, discardDialogFragment ->
                if (s == "subscribe") {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                    premiumLauncher.launch(Intent(context, SubscriptionActivity::class.java))
                    Constants.buyFromAddTextActivity = true
                } else if (s == "watchAd") {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                    showAdReward(position, adapter)
                } else {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                }
            }
            watchAdDialog.isCancelable = false
        } else if (adapter == "frame") {
            watchAdDialog = WatchAdDialogFragment(
                "Unlock Frame",
                "Get PRO",
                "To Access All Frames",
                R.drawable.ic_dialog_frame,
                "Watch Video Ad",
                "To Use This Frame"
            )
            { s, discardDialogFragment ->
                if (s == "subscribe") {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                    premiumLauncher.launch(Intent(context, SubscriptionActivity::class.java))
                    Constants.buyFromAddTextActivity = true
                } else if (s == "watchAd") {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
//                    showAdReward(position, mRewardedAd, adapter)
                    showAdReward(position, adapter)
                } else {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                }
            }
            watchAdDialog.isCancelable = false
        } else if (adapter == "Pattern") {
            watchAdDialog = WatchAdDialogFragment(
                "Unlock Pattern",
                "Get PRO",
                "To Access All Patterns",
                R.drawable.ic_dialog_pattern,
                "Watch Video Ad",
                "To Use This Pattern"
            )
            { s, discardDialogFragment ->
                if (s == "subscribe") {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                    premiumLauncher.launch(Intent(context, SubscriptionActivity::class.java))
                    Constants.buyFromAddTextActivity = true
                } else if (s == "watchAd") {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                    showAdReward(position, adapter)
                } else {
                    supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                    discardDialogFragment.dismiss()
                }
            }
            watchAdDialog.isCancelable = false
        }
        try {
            watchAdDialog.show(supportFragmentManager, "dialog_fragment")
        } catch (e: Exception) { }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun showAdReward(position: Int, adapter: String) {
        RewardedAdHelper.instence!!.showRewardedAd(this, {
            //OnUserEarnedReward
            if (adapter == "font") {
                isGetReward = true
                Log.d(TAG, "onUserEarnedReward: $position")
                dbHelper.updateData(position, "0", "0")
//                mFontStylePos = position
//                mStickerModel!!.positionFont = position
                if (fontStyleList[position].contains(FontFolder)) {
                    setFontTypeFace(position, Typeface.createFromAsset(assets, fontStyleList[position]))
                } else {
                    downloadFontZipFile(fontZipPath[position], mTmpHolder, position)
                }

                hideKeyboard()
//                mStickerModel!!.typeface = Constants.typeface
//                mStickerModel!!.fontname = Constants.stickerTypeface
//                updateTextSticker(mStickerModel, mStickerModel!!.originalText, false)

                fontStyleClick()
                fontValList[position] = "0"
                mRecyclerFontStyle.scrollToPosition(position)
//                updateFontStyle(position)
                try {
                    fontPosition = position
                    //mRecyclerFontStyle!!.scrollToPosition(position)
                    fontAdapter!!.notifyDataSetChanged()
                    Log.d(TAG, "updateSelectItem: mFontAdapter 6")
                    Log.d(TAG, "Font Added Here: Function 2")
                    addFontOperationInUndoRedo(position)
                } catch (e: Exception) { }
            } else if (adapter == "frame") {
                dbHelper.insertOpenFrameData(frameList[position - 1])
                Glide.with(context).load(frameList[position - 1])
                    .into(frameView)
                onFrameClick(true)
                mRecyclerFrame.scrollToPosition(position - 1)
            } else if (adapter == "WaterMark") {
                rlWaterMarlClick.hide()
            } else if(adapter == "Pattern"){
                patternPosition = position - 1
                dbHelper.insertOpenPatternData(
                    position,
                    mPatternList[position - 1].toString()
                )
                textureClicked()
                onPatternClick(position - 1, null)
                mRecyclerTexture.scrollToPosition(position - 1)
            }
        }, {
            //OnError
            RewardedAdHelper.instence!!.loadRewardedAd(context)
        }, {
            //OnClose
            instence!!.loadVideoAdMain(this)
        }, {
            //On Pro
        }, mIsSubScribe)
    }

    private fun textureClicked() {
        isState = true
        mConstraintLayoutAddText?.hide()
        mRecyclerAddText.disabled()
        clMainOptionView.isClickable = false
        //Text Texture
        if (selectedSticker == null) {

            showToast("Please  add/select text")
            clMainOptionView.show()
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
            return
        }

        mConstraintSubLayoutGradient.hide()
        mConstraintSubLayoutTexture.show()
        mConstraintSubLayoutShadowColor?.hide()
        mConstraintSubLayoutTextBorder?.hide()
        mConstraintSubLayoutTextSpace?.hide()
        mConstraintSubLayoutTextCurve?.hide()
        mConstraintSubLayoutText3d.hide()
        constraintSubLayoutFontStyle.hide()
        constraintSubLayoutColor.hide()

        loadTextTexture()
//        mStickerView!!.invalidate()
    }

    private fun fontStyleClick() {
        mConstraintSubLayoutTexture.disabled()
        mConstraintLayoutAddText?.hide()
        mRecyclerAddText.disabled()
        clMainOptionView.isClickable = false

        isState = true
        //Font Style
        if (selectedSticker == null) {

            showToast("Please  add/select text")
            clMainOptionView.show()
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
            return
        }
        constraintSubLayoutFontStyle.show()
        mConstraintSubLayoutGradient.hide()
        mConstraintSubLayoutTexture.hide()
        mConstraintSubLayoutShadowColor?.hide()
        mConstraintSubLayoutTextBorder?.hide()
        mConstraintSubLayoutTextSpace?.hide()
        mConstraintSubLayoutTextCurve?.hide()
        mConstraintSubLayoutText3d.hide()
        constraintSubLayoutColor.hide()

        loadFontStyle()
    }

    //Manage curve text
    @RequiresApi(Build.VERSION_CODES.O)
    private fun loadCurveTextData() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                mSeekCurve!!.thumb.colorFilter =
                    BlendModeColorFilter(getColor(R.color.colorPrimary), BlendMode.SRC_ATOP)
            } else {
                mSeekCurve!!.thumb.setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary),
                    PorterDuff.Mode.MULTIPLY
                )
            }
            strokeMenu("curving")
        } catch (e: Exception) { }

        mSeekCurve?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar?,
                progress: Int,
                fromUser: Boolean,
            ) {
                Log.d(TAG, "onProgressChanged: mSeekCurve $progress")
                if (fromUser) {
                    disableAllFontOption()
                    if (progress == 0) {
                        setTextCurve(1)
                    } else {
                        setTextCurve(progress)
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                selectedSticker?.text_iv?.isCurveFromUser(false)
                index?.let { i ->
                    stickerList[i].curve = seekBar!!.progress.toFloat()
                    stickerList[i].isCurve = true
                    enableAllFontOption()
                    //TODO Add Operation in UndoRedo
                    /*
                    if (!isFromUndoRedo){
                        if (stickerList[index!!].isFirstTimeCurve){
                            val operation = UndoRedo.Operation()
                            operation.mCurve = 0
                            val action = UndoRedo(ACTION.SetCurve, index!!, getSelectedStickerTag(),operation)
                            mUndo.add(action)
                        manageUndoRedoButton()
                            stickerList[index!!].isFirstTimeCurve = false
                        }
                        val operation = UndoRedo.Operation()
                        operation.mCurve = seekBar!!.progress
                        val action = UndoRedo(ACTION.SetCurve, index!!, getSelectedStickerTag(),operation)
                        mUndo.add(action)
                        manageUndoRedoButton()
                    }
                    isFromUndoRedo = false
                    */
                }
            }
        })

        imgBtnResetCurve.click {
            index?.let { i ->
                if (!stickerList[i].isCurve) {
                    return@click
                }

                mSeekCurve!!.progress = 0
                selectedSticker!!.curve = false
                selectedSticker!!.invalidate()

                //TODO Remove Old Curved Sticker
//                Log.d(TAG, "loadCurveTextData: ${this.stickerView.getChildAt(i).tag}")
//                mStickerTag = context.stickerView.getChildAt(i).tag.toString()
//                val stickerModel = stickerList[i]
//                stickerModel.isCurve = false
//                stickerModel.isFirstTimeCurve = false
//                stickerModel.typeface = Constants.typeface
//                selectStikerPoPrevius = i
//                selectedSticker!!.hide()
//
//                        setTextSelection()
//                        strokeMenu("curving")
//                        Log.d(TAG, "loadCurveTextData: Outside ${stickerList[i].isGlow}")
//                        if(stickerList[i].isGlow){
//                            Log.d(TAG, "loadCurveTextData: Inside ${stickerList[i].getGlowColorPos()}")
//                            setTextGlowColorFromColorPicker(stickerList[i].getGlowColorPos())
//                        }
//                        setTextFontTypeIfApplied()
//                        if (stickerList[i].isUnderline){
//                            try {
//                                imgFontTypeUnderline.performClick()
//                                imgFontTypeUnderline.performClick()
//                                strokeMenu("curving")
//                            } catch (e: Exception) { } }
//                        val realText = context.selectedSticker!!.findViewById(R.id.realText) as TextView
//                        val flippedText = context.selectedSticker!!.findViewById(R.id.flippedText) as TextView
//                        if (stickerList[i].isShadow){
//                            Log.d(TAG, "loadCurveTextData: isShadow")
//                            try {
//                                val constraintLayout = context.selectedSticker!!.findViewById(R.id.shadowLayout) as ConstraintLayout
//                                val params: ViewGroup.MarginLayoutParams = constraintLayout.layoutParams as ViewGroup.MarginLayoutParams
//                                params.topMargin = stickerList[i].shadowSpace
//                                constraintLayout.layoutParams = params
//                                flippedText.invalidate()
//                                if (textView != null) {
//                                    updateTextSticker(
//                                        mStickerModel,
//                                        mStickerModel!!.originalText,
//                                        true
//                                    )
//                                }
//                                Log.d(TAG, "loadCurveTextData: isShadow Apply")
//                            } catch (e: Exception) { }
//                        }
//                        if (stickerList[i].currWidth != 0){
//                            realText.width = stickerList[i].currWidth
//                            flippedText.width = stickerList[i].currWidth
//                        }
            }
        }

    }

    private fun setTextCurve(progress: Int) {
//        try {
//            strokeMenu("")
//        }catch (e: Exception){ }
        selectedSticker!!.curve = true
        var radius = mSeekCurve!!.progress - 360
        if (radius <= 0 && radius >= -8) {
            radius = -8
        }
        selectedSticker!!.setCurve(radius)

//        index?.let { i ->
//            if (index!! != -1) {
////                val realText = stickerView.getChildAt(i).findViewById<AutoResizeTextView>(R.id.realText)
////                val flippedText = stickerView.getChildAt(i).findViewById<AutoResizeTextView>(R.id.flippedText)
//                val angle = progress - max
//                stickerList[i].angle = angle
//                stickerList[i].angleProgress = progress
//                stickerList[i].angleProgress = progress
//                if (progress != 0) {
////                    realText.isCurve = true
////                    flippedText.isCurve = true
//                    //TODO manage Curve Here
//                    if ((max / 2) > progress) {
//                    selectedSticker!!.resetSize(progress - max)
////                    flippedText.resetSize(progress - max)
//                    } else {
//                        selectedSticker!!.resetSize(progress)
////                    flippedText.resetSize(progress)
//                    }
//                }
//            }
//        }

//      updateTextSticker(mStickerModel, mStickerModel!!.originalText, false)
    }

    /*
    //Manage glow text
    private fun loadGlowTextData() {
//        strokeMenu("curving")
        val finalMax = max
        if (stickerList[index!!].isGlow) {
            mSeekGlow?.progress = stickerList[index!!].angleProgress
        } else {
            mSeekGlow?.progress = 0
        }
        mSeekGlow?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {

            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
//                realText.gravity = Gravity.CENTER or Gravity.CENTER_HORIZONTAL
//                flippedText.gravity = Gravity.CENTER or Gravity.CENTER_HORIZONTAL
                Log.d(TAG, "onProgressChanged: curving" + newStickerModel!!.isCurve)
            }
        })

        mImgBtnGlowColor?.click {

        }
    }
    */

    @SuppressLint("NewApi")
    private fun strokeMenu(text: String) {
        try {
            if (selectedSticker!!.text_iv.text != null)
            {
                mSeekCurve?.tag = "curving"

                val bounds = Rect()
                stickerView.getChildAt(index!!)
                    .findViewById<AutoResizeTextView>(R.id.realText)!!.paint.getTextBounds(
                        selectedSticker!!.text_iv.text,
                        0,
                        selectedSticker!!.text_iv.text.length,
                        bounds
                    )
                max = bounds.width() * 3
                mSeekCurve!!.max = max
                Log.d(TAG, "strokeMenu: max : $max")
            }
        } catch (e: Exception) { }
    }

    private fun load3DTextData() {
        mSeek3Dx?.max = 180
        mSeek3Dy?.max = 180
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mSeek3Dx!!.thumb.colorFilter =
                BlendModeColorFilter(getColor(R.color.colorPrimary), BlendMode.SRC_ATOP)
            mSeek3Dy!!.thumb.colorFilter =
                BlendModeColorFilter(getColor(R.color.colorPrimary), BlendMode.SRC_ATOP)
        } else {
            mSeek3Dx!!.thumb.setColorFilter(
                ContextCompat.getColor(this, R.color.colorPrimary),
                PorterDuff.Mode.MULTIPLY
            )
            mSeek3Dy!!.thumb.setColorFilter(
                ContextCompat.getColor(this, R.color.colorPrimary),
                PorterDuff.Mode.MULTIPLY
            )
        }
        try {
            if (mSeek3Dx != null) {
                mSeek3Dx?.progress = stickerList[index!!].rotateX.toInt()
            }
            if (mSeek3Dy != null) {
                mSeek3Dy?.progress = stickerList[index!!].rotateY.toInt()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mSeek3Dx?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    disableAllFontOption()
                    mSeek3Dy!!.disabled()
                    setText3Dx(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                //TODO Add Operation in UndoRedo
                index?.let { i ->
                    if (stickerList[i].isFirstTime3Dx) {
                        val operation = UndoRedo.Operation()
                        operation.m3Dx = 0
                        val action = UndoRedo(ACTION.Change3Dx, i, operation)
                        mUndo.add(action)
                        manageUndoRedoButton()
                        stickerList[index!!].isFirstTime3Dx = false
                    }
                    val operation = UndoRedo.Operation()
                    operation.m3Dx = seekBar!!.progress
                    val action = UndoRedo(ACTION.Change3Dx, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()

                    mSeek3Dy!!.enabled()
                    enableAllFontOption()
                    stickerList[i].rotateX = seekBar.progress.toFloat()
                }
            }
        })

        mSeek3Dy?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    disableAllFontOption()
                    mSeek3Dx!!.disabled()
                    setText3Dy(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                //TODO Add Operation in UndoRedo
                index?.let { i ->
                    if (stickerList[i].isFirstTime3Dy){
                        val operation = UndoRedo.Operation()
                        operation.m3Dy = 0
                        val action = UndoRedo(ACTION.Change3Dy, i, operation)
                        mUndo.add(action)
                        manageUndoRedoButton()
                        stickerList[index!!].isFirstTime3Dy = false
                    }
                    val operation = UndoRedo.Operation()
                    operation.m3Dy = seekBar!!.progress
                    val action = UndoRedo(ACTION.Change3Dy, i, operation)
                    mUndo.add(action)
                    manageUndoRedoButton()

                    mSeek3Dx!!.enabled()
                    enableAllFontOption()
                }
            }
        })
    }

    private fun setText3Dy(progress: Int) {
        index?.let { i ->
            selectedSticker?.rotationY = progress.toFloat()
            stickerList[i].rotateY = progress.toFloat()
        }
    }
    private fun setText3Dx(progress: Int) {
        index?.let { i ->
            selectedSticker?.rotationX = progress.toFloat()
            stickerList[i].rotateX = progress.toFloat()
        }
    }

    //Hide menu UI
    private fun hideControlsUI(isFromBackClicked: Boolean) {
        isEdit = false

        if (mConstraintSubLayoutGradient.visibility == View.VISIBLE) {
            mConstraintSubLayoutGradient.hide()
        } else if (mConstraintSubLayoutTexture.visibility == View.VISIBLE) {
            mConstraintSubLayoutTexture.hide()
        } else if (mConstraintSubLayoutShadowColor?.visibility == View.VISIBLE) {
            mConstraintSubLayoutShadowColor?.hide()
        } else if (mConstraintSubLayoutTextBorder?.visibility == View.VISIBLE) {
            mConstraintSubLayoutTextBorder?.hide()
        } else if (mConstraintSubLayoutTextSpace?.visibility == View.VISIBLE) {
            mConstraintSubLayoutTextSpace?.hide()
        } else if (mConstraintSubLayoutTextCurve?.visibility == View.VISIBLE) {
            mConstraintSubLayoutTextCurve?.hide()
        } else if (mConstraintSubLayoutStickerItems?.visibility == View.VISIBLE) {
            mConstraintSubLayoutStickerItems?.hide()
        } else if (mConstraintSubLayoutText3d.visibility == View.VISIBLE) {
            mConstraintSubLayoutText3d.hide()
        } else if (constraintSubLayoutColor.visibility == View.VISIBLE) {
            constraintSubLayoutColor.hide()
        } else if (constraintSubLayoutFontStyle.visibility == View.VISIBLE) {
            constraintSubLayoutFontStyle.hide()
        }

        if (isFromBackClicked) {
            if (mConstraintLayoutBG?.visibility == View.VISIBLE) {
                mImgBackBg.performClick()
            } else if (mConstraintLayoutAddText?.visibility == View.VISIBLE) {
                mImgBackaddText.performClick()
            } else if (mConstraintLayoutStickerCategory?.visibility == View.VISIBLE) {
                mImgBackaddSticker.performClick()
            } else {
                if (::dialog.isInitialized && !dialog.isShowing) {
                    dialog.show()
                }
            }
            if (imgBtnSave.tag == "template") {
                imgBtnSave.tag = "save"
            } else {
                imgBtnSave.tag = "save"
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.constraintMenuAddText -> {
                if (SystemClock.elapsedRealtime() - lastClickTime < 500) return
                lastClickTime = SystemClock.elapsedRealtime()
                removeMainOptionSelection()
                mConstraintMenuBG.disabled()
                mConstraintMenuSticker.disabled()
                mConstraintMenuFrame.disabled()
                mConstraintMenuAddText.disabled()
                clMainOptionView.show()
                Log.d(TAG, "stickerView: performClick 16")
                stickerView.performClick()
                startEditing()
            }
            R.id.constraintMenuBG -> {
                removeMainOptionSelection()
                imgSelectBG.setColorFilter(Color.parseColor("#1379CA"))
                txtViewBG.textColor = (Color.parseColor("#1379CA"))
                imgShowMore.tag = "Background"
                offlinePosition = offlineBgPosition
                clMainOptionContainer.show()
                rvFrame.hide()
                rvCombo.hide()
                rvBackground.show()
                backgroundAdapter.notifyDataSetChanged()
            }
            R.id.constraintMenuSticker -> {
                if (SystemClock.elapsedRealtime() - lastClickTime < 500) return
                lastClickTime = SystemClock.elapsedRealtime()
                removeMainOptionSelection()
                if (isOnline()) {
                    startActivityForResult(Intent(this, StickerActivity::class.java), 6666)
                    /*if (StickerActivity.stickerAllArray.size > 0) {
                        startActivityForResult(Intent(this, StickerActivity::class.java), 6666)
                    }else {
                        showToast(resources.getString(R.string.poor_connection))
                        loadDataIfNotLoaded()
                    }*/
                } else {
                    showToast("Please check internet connection.")
                }
                return
            }
            R.id.constraintMenuFrame -> {
                removeMainOptionSelection()
                imgSelectFrame.setColorFilter(Color.parseColor("#1379CA"))
                txtViewFrame.textColor = (Color.parseColor("#1379CA"))
                imgShowMore.tag = "Frame"
                offlinePosition = offlineFramePosition
                clMainOptionContainer.show()
                rvBackground.hide()
                rvCombo.hide()
                rvFrame.show()
                frameAdapter.notifyDataSetChanged()
            }
            R.id.constraintMenuCombo -> {
                removeMainOptionSelection()
                imgCombo.setColorFilter(Color.parseColor("#1379CA"))
                textViewCombo.textColor = (Color.parseColor("#1379CA"))
                imgShowMore.tag = "Combo"
                offlinePosition = offlineComboPosition
                clMainOptionContainer.show()
                rvBackground.hide()
                rvFrame.hide()
                rvCombo.show()
                comboAdapter.notifyDataSetChanged()
            }

        }
    }

    private fun removeMainOptionSelection() {
        clMainOptionContainer.hide()
        offlinePosition = -1
        imgSelectBG.setColorFilter(Color.parseColor("#000000"))
        txtViewBG.textColor = (Color.parseColor("#000000"))
        imgSelectFrame.setColorFilter(Color.parseColor("#000000"))
        txtViewFrame.textColor = (Color.parseColor("#000000"))
        imgCombo.setColorFilter(Color.parseColor("#000000"))
        textViewCombo.textColor = (Color.parseColor("#000000"))
    }

    private fun saveImageForPreview(): String {
        val fileName = "TextArt_${System.currentTimeMillis()}" + ".png"
        stickerView.performClick()
        if(mIsSubScribe){
            rlWaterMarlClick.hide()
        }
        imgWaterMarkClose.hide()
        val bitmap = Bitmap.createBitmap(backgroundView.width, backgroundView.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas((bitmap)!!)
        mContainer.draw(canvas)

        val myDir = File(context.filesDir, "DraftFile")
        if (!myDir.exists())
            myDir.mkdirs()
        val file = File(myDir, fileName)
        if (file.exists()) file.delete()

        try {
            val fos = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
            fos.flush()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        if (mIsSubScribe)
            rlWaterMarlClick.hide()

        return "$myDir/$fileName"
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun onPatternClick(it: Int, imgPath: String?, isFromUndoRedo: Boolean = false) {
        Log.d(TAG, "onActivityResult: sticker1 $imgPath")
        //TODO Add Operation in UndoRedo
        if (!isFromUndoRedo){
            addWhiteColorIfFirstTime()
            val operation = UndoRedo.Operation()
            if (it == -1){
                operation.mPatternFromGallery = true
                operation.mPatternString = imgPath!!
            }else {
                operation.mPatternFromGallery = false
                operation.mPattern = it
            }
            val action = UndoRedo(ACTION.ChangePattern, index!!, operation)
            mUndo.add(action)
            manageUndoRedoButton()
        }

//        setTextGlowColorFromColorPicker(Color.TRANSPARENT)

        gradientPosition = -1
        gradientAdepter?.notifyDataSetChanged()
        multiColorPosition = -1
        multiColorAdepter?.notifyDataSetChanged()

        index?.let { i ->
            stickerList[i].isPattern = true
            stickerList[i].isGradient = false
            stickerList[i].isShadow = false
            stickerList[i].isTexture = true
            stickerList[i].isShadow = false
            stickerList[i].isSingleColor = false
            stickerList[i].isMultiColor = false
            stickerList[i].positionGradient = -1
            stickerList[i].positionMultiple = -1
            stickerList[i].singleColorPos = -1
            stickerList[i].positionTexture = it
            patternPosition = it
        }

        if (it == -1) {
            tPatterPath = imgPath!!
            Glide.with(context).asBitmap().override(400, 400).load(imgPath)
                .into(object : CustomTarget<Bitmap>() {
                    @SuppressLint("NotifyDataSetChanged")
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?,
                    ) {
                        index?.let { i ->
                            stickerList[i].patternString = imgPath
                            selectedSticker?.setGradientBitmap(resource)
                            textureAdepter!!.notifyDataSetChanged()
                        }
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {}

                })

        } else {
            Glide.with(context).asBitmap().load(mPatternList[it])
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?,
                    ) {
                        selectedSticker?.setGradientBitmap(resource)
                        textureAdepter!!.notifyDataSetChanged()
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {}

                })
        }
    }

    private fun onFrameClick(boolean: Boolean) {
        getFrameData()
        mConstraintMenuBG.enabled()
        mConstraintMenuSticker.enabled()
        mConstraintMenuAddText.enabled()
        if (boolean) {
            clMainOptionView.visibility = View.INVISIBLE
            mConstraintLayoutBG?.hide()
            mConstraintLayoutAddText?.hide()
            mRecyclerAddText.disabled()
            mConstraintLayoutStickerCategory?.hide()
            mConstraintFrameLayout?.show()
            mConstraintMenuBG.disabled()
            mConstraintMenuSticker.disabled()
            mConstraintMenuFrame.disabled()
            mConstraintMenuAddText.disabled()
        }

        val gridLayoutManager = GridLayoutManager(applicationContext, 2)
        gridLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
        mRecyclerFrame.layoutManager = gridLayoutManager
        mFrameAdapter =
            FrameAdepter(this, frameList, frameValList, object : FrameAdepter.onClickFrameListener {
                override fun OnClickFrame(frame: Int) {
                    if (frame == 0) {
//                    Glide.with(context).load(frameList[frame]).into(frameView)
                        frameView.setImageResource(0)
                    } else {
                        if (frameValList[frame] == "1") {

                            if (isOnline()) {
                                if (RewardedAdHelper.instence != null
                                    && RewardedAdHelper.instence!!.loadRewardedAd(context) != null
                                ) {
                                    showAdDialog(frame + 1, "frame")
//                                    showAdDialog(position, rewardedAd, "font")
                                } else {
                                    Toast.makeText(
                                        context,
                                        resources.getString(R.string.try_again_later),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                                /*if (instence != null && instence!!.loadVideoAdMain(context) != null) {
                                    val rewardedAd =
                                            instence!!.loadVideoAdMain(context)
                                    showAdDialog(frame + 1, rewardedAd, "frame")
                                    try {

                                        isDialogOpen = true
                                        watchAdDialog.show(
                                                supportFragmentManager,
                                                "dialog_fragment"
                                        )
                                    } catch (e: Exception) {
                                    }

                                } else {
                                    Toast.makeText(
                                            context,
                                            resources.getString(R.string.try_again_later),
                                            Toast.LENGTH_SHORT
                                    ).show()
                                }*/
                            } else {
                                Toast.makeText(
                                    context,
                                    "Please check internet connection.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else if (frameValList[frame] == "2") {
                            premiumLauncher.launch(Intent(context, SubscriptionActivity::class.java))
                            Constants.buyFromAddTextActivity = true
                        } else {
                            Glide.with(context).load(frameList[frame])
                                .into(frameView)
                        }
                    }
                }
            })
        mRecyclerFrame.adapter = mFrameAdapter

    }

    override fun onLoad() {
        isInterstitialAdLoaded = true
    }

    override fun onFailed() {
        isInterstitialAdLoaded = false
    }

    override fun onClosed() {
        Constants.isAdsShow = false
        Handler(Looper.getMainLooper()).postDelayed({
            if (isFromDiscard) {
                finish()
            } else {
                isInterstitialAdLoaded = false
                interstitial = InterstitialAdHelper.instance?.load(context, this)
                val intent = Intent(context, FullMyPhotoActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                intent.putExtra("image", mPath)
                intent.putExtra("isCreation", false)
                intent.putExtra("type", "photo")
                Constants.showAdInSharePage = true
                startActivityForResult(intent, 2052)
            }
        }, 200)
    }

    private fun loadInterstitialAds() {
        if (!TextArtApplication.instance?.mInterstitialAdfb!!.isAdLoaded) {
            TextArtApplication.instance?.mInterstitialAdfb = null
            TextArtApplication.instance?.LoadAdsFb()
            val interstitialAdListener = object : InterstitialAdListener {
                override fun onInterstitialDisplayed(ad: Ad?) {}
                override fun onInterstitialDismissed(ad: Ad?) {
                    onBackPressed()
                }

                override fun onError(ad: Ad?, adError: AdError) {}
                override fun onAdLoaded(ad: Ad?) {}
                override fun onAdClicked(ad: Ad?) {}
                override fun onLoggingImpression(ad: Ad?) {}
            }
            TextArtApplication.instance?.mInterstitialAdfb?.loadAd(
                TextArtApplication.instance?.mInterstitialAdfb!!.buildLoadAdConfig()
                    .withAdListener(interstitialAdListener).build()
            )
        }
    }

    override fun stickerClicked(x: Float, y: Float, rotation: Float, singleFinger: Boolean) {
        /*if (singleFinger){
            //TODO Add Undo Redo OPERATION : Single Finger
            if ((x.toDouble() != 0.0) && (y.toDouble() != 0.0) && index!!!=-1){
                if (stickerList[index!!].isApplyPos) {
                    val operation = UndoRedo.Operation()
                    operation.oldX = 0F
                    operation.oldY = 0F
                    val action = UndoRedo(ACTION.ChangePosition, index!!, operation)
                    Log.d(TAG, "Undo Redo Added ACTION.ChangePosition 1")
                    mUndo.add(action)
                    manageUndoRedoButton()
                    stickerList[index!!].isApplyPos = false
                }
                val operation = UndoRedo.Operation()
                operation.oldX = x
                operation.oldY = y
                val action = UndoRedo(ACTION.ChangePosition, index!!, operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangePosition 2")
                mUndo.add(action)
                manageUndoRedoButton()
            }
        }
        Log.d(TAG, "performUndoRedo: ChangePosition: x=$x y=$y")*/
    }

    override fun showGrid(horGrid: Boolean, verGrid: Boolean, isPointerUp: Boolean) {

        stickerGridHorizontal1.show()
        stickerGridVertical1.show()
        stickerGridHorizontal2.show()
        stickerGridVertical2.show()
        if (horGrid && verGrid) {
            stickerGridVertical.show()
            stickerGridHorizontal.show()
        } else if (horGrid) {
            stickerGridHorizontal.show()
            stickerGridVertical.hide()
        } else if (verGrid) {
            stickerGridVertical.show()
            stickerGridHorizontal.hide()
        } else {
            stickerGridHorizontal.hide()
            stickerGridVertical.hide()
        }

        if (isPointerUp){
            Handler(Looper.getMainLooper()).postDelayed({
            stickerGridHorizontal.hide()
            stickerGridVertical.hide()
            stickerGridHorizontal1.hide()
            stickerGridVertical1.hide()
            stickerGridHorizontal2.hide()
            stickerGridVertical2.hide()
        },100) }

    }

    override fun showGrid1(horGrid: Boolean, verGrid: Boolean, isPointerUp: Boolean) {

        /*if (horGrid && verGrid) {
            stickerGridVertical1.show()
            stickerGridHorizontal1.show()
        } else if (horGrid) {
            stickerGridHorizontal1.show()
            stickerGridVertical1.hide()
        } else if (verGrid) {
            stickerGridVertical1.show()
            stickerGridHorizontal1.hide()
        } else {
            stickerGridHorizontal1.hide()
            stickerGridVertical1.hide()
        }

        if (isPointerUp){
            Handler(Looper.getMainLooper()).postDelayed({
                stickerGridHorizontal1.hide()
                stickerGridVertical1.hide()
            },100) }*/

    }

    override fun showGrid2(horGrid: Boolean, verGrid: Boolean, isPointerUp: Boolean) {
        /*if (horGrid && verGrid) {
            stickerGridVertical2.show()
            stickerGridHorizontal2.show()
        } else if (horGrid) {
            stickerGridHorizontal2.show()
            stickerGridVertical2.hide()
        } else if (verGrid) {
            stickerGridVertical2.show()
            stickerGridHorizontal2.hide()
        } else {
            stickerGridHorizontal2.hide()
            stickerGridVertical2.hide()
        }

        if (isPointerUp){
            Handler(Looper.getMainLooper()).postDelayed({
                stickerGridHorizontal2.hide()
                stickerGridVertical2.hide()
            },100)
        }*/
    }

    override fun onNetworkChanged(state: Boolean?) {
        Log.d(TAG, "onNetworkChanged: ${state!!}")
        if (state!!) {
            if (isFirstTime) {
                isFirstTime = false
            } else {
                val count = dbHelper.allData.count
                if (count <= Constants.totalAssetsFont && isFontApiDataLoaded) {
                    addFontInDataFromApi()
                }
            }
        } else {
            if (isFirstTime) {
                isFirstTime = false
            }
        }
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(networkReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(networkReceiver)
    }

    @SuppressLint("NotifyDataSetChanged")
    val comboLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            isFromUndoRedo = false
            Constants.isBgApply = true
            val bgPath = result.data!!.getStringExtra("bgImagePath")
            val framePath = result.data!!.getStringExtra("frameImagePath")
            Log.d(TAG, "comboLauncher : bgPath $bgPath")
            Log.d(TAG, "comboLauncher : framePath $framePath")
            /*if (bgPath == "" && framePath == "") {
                val operation = UndoRedo.Operation()
                operation.bgImage = ""
                operation.frameImage = ""
                val action = UndoRedo(ACTION.ChangeCombo, 0, "", operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo 1")
                Log.d(TAG, "Combo Added Here: 1")
                mUndo.add(action)
                backgroundView.setImageResource(0)
                frameView.setImageResource(0)
//                tComboBgPath = ""
//                Log.d(TAG, "ComboBgFrame Var tComboBgPath : null comboLauncher")
//                tComboFramePath = ""
//                Log.d(TAG, "ComboBgFrame Var tComboFramePath : null comboLauncher")
//                tBgPath = ""
//                tFramePath = ""
                return@registerForActivityResult
            }*/
            tComboBgPath = bgPath!!
            tComboFramePath = framePath!!
//            Constants.mSelectedColorPos = 0
            //Background
            setComboImage(bgPath,framePath)
            offlineComboPosition = -1
            offlinePosition = -1
            comboAdapter.notifyDataSetChanged()

            if (mUndo.size == 0){
                val operation = UndoRedo.Operation()
                operation.bgImage = ""
                operation.frameImage = ""
                val action = UndoRedo(ACTION.ChangeComboNone, 0, operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo NONE 1")
                mUndo.add(action)
            }
            manageUndoRedoButton()
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    val premiumLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            if(MySharedPreferences(this).isSubscribe){
                upgradeToPremium()
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun upgradeToPremium() {
        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe

        findViewById<FrameLayout>(R.id.fl_adplaceholder).hide()
        rlWaterMarlClick.hide()

        fontPosition = -1
        getFrameData()

        if (textureAdepter != null) {
            loadTextTexture()
        }
        if (fontAdapter != null) {
            loadFontStyle()
        }
        if (mFrameAdapter != null) {
            mFrameAdapter?.notifyDataSetChanged()
            onFrameClick(false)
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    @SuppressLint("NotifyDataSetChanged")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        Log.d(TAG, "onActivityResult: sticker $requestCode")
        when (requestCode) {
            PICK_IMAGE_CODE -> {
                mIsOpenGallery = false
                if (data != null) {
                    tPatterPath = data.getStringExtra("EXTRA_SELECTED_URI")!!
                    if (tPatterPath == "") return
                    Log.d(TAG, "onActivityResult: sticker $tPatterPath")
                    onPatternClick(-1, Uri.parse(tPatterPath).toString())
                }
            }
            1001 -> {
                mIsOpenGallery = false
                if (resultCode == Activity.RESULT_OK) {
                    data?.data?.let {
                        val filename = File(it.toString()).absolutePath
                        Log.d("TAG", "onActivityResult: ${File(it.toString()).exists()}")
                        if (!File(it.toString()).exists()) {
                            return@let
                        }
                        if (filename.isNotEmpty()) {
                            if (filename.contains(".ttf") || filename.contains(".otf")) {
//                                mFontStylePos = -1
                                mStickerModel!!.positionFont = -1
                                fontPosition = -1
                                if (File(it.toString()).exists()) {
                                    // Display font from SD
                                    setFontTypeFace(-1, Typeface.createFromFile(File(it.toString())))
                                }
                                GlobalScope.launch {
                                    withContext(Dispatchers.Main) {
                                        hideKeyboard()
                                        fontAdapter!!.notifyDataSetChanged()
                                    }
                                }

                            } else {
                                Toast.makeText(
                                    this,
                                    "This file format not supported. Please select .ttf or .otf files",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            Log.d(
                                "TAG",
                                "onActivityResult: error for getting file name $filename"
                            )
                        }
                    }

                }
            }
            6666 -> {
                when (resultCode) {
                    2323 -> {
                        val imagePath = data!!.getStringExtra("bgImagePath")
                        isFromUndoRedo = false
                        Log.d(TAG, "BG Added Here: Function 4")
                        setBackgroundImage(imagePath!!)
                        offlineBgPosition = -1
                        offlinePosition = -1
                        backgroundAdapter.notifyDataSetChanged()
                    }
                    2221 -> {
                        if (data!!.hasExtra("colorPicker")){
                            Constants.isBgApply = false //bgColor Apply
                            val bgColor = data.getIntExtra("colorPicker", Color.WHITE)
                            setBackgroundColor(bgColor)
                        }
                    }
                    1010 -> {
                        val imagePath = data!!.getStringExtra("sticker")
                        tStickerPath = data.getStringExtra("sticker")

                        if (imagePath == "") {
                            return
                        }

                        progressDialog?.show()
                        addSticker(IMAGE_STICKER, tStickerPath!!)

                        Handler(Looper.getMainLooper()).postDelayed({
                            progressDialog?.dismiss()
                        },1300)
//                        Glide.with(this).load(imagePath).into(object : CustomTarget<Drawable>() {
//                            override fun onLoadCleared(placeholder: Drawable?) {}
//
//                            override fun onResourceReady(
//                                resource: Drawable,
//                                transition: Transition<in Drawable>?,
//                            ) {
//                                addSticker(IMAGE_STICKER, tStickerPath!!)
////                                addShadowSticker("", resource, null, true, null)
//                            }
//                        })
                    }
                    3030 -> {
                        val framePath = data!!.getStringExtra("frames")
                        isFromUndoRedo = false
                        setFrameImage(framePath)
                        Log.d(TAG, "Frame Added Here: Function 4")
                        offlineFramePosition = -1
                        offlinePosition = -1
                        frameAdapter.notifyDataSetChanged()
                    }
                }
            }
            100  -> {
                if (data != null && refId != null) {
                    val selectedImage: Uri = data.data!!
                    val bg = Bitmap.createScaledBitmap(MediaStore.Images.Media.getBitmap(this.contentResolver, selectedImage), 1080, 1080, false)
                    (selectedSticker?.findViewById<LottieAnimationView>(R.id.lottieView)!!).updateBitmap(refId, bg)
                }
            }
            else -> {
                super.onActivityResult(requestCode, resultCode, data)
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setComboImage(bgPath: String?, framePath: String?, isFromUndoRedo: Boolean = false){
        Log.d(TAG, "ComboBgFrame Set Images : Combo 1 bgPath $bgPath")
        Log.d(TAG, "ComboBgFrame Set Images : Combo 2 Frame $framePath")
//        tComboBgPath = bgPath
//        tComboFramePath = framePath
        tFramePath = ""
        tBgPath = ""
        tBgColor = 0
        offlinePosition = -1
        offlineBgPosition = -1
        offlineFramePosition = -1
        offlineComboPosition = -1
        background.background = bgPath
        background.frame = framePath
        backgroundAdapter.notifyDataSetChanged()
        frameAdapter.notifyDataSetChanged()
        comboAdapter.notifyDataSetChanged()

        //TODO Set Background Of Combo
        var failedBg = false
        var failedFrame = false
        Glide.with(context).load(bgPath)
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?,
                ) {
                    Constants.isBgApply = true
                    bitmap = try {
                        (resource as BitmapDrawable).bitmap
                    } catch (e: Exception) {
                        getBitmapFromDrawable(resource)
                    }
                    var width = mContainer.width
                    var height = mContainer.height
                    val ratio = width.toFloat() / height.toFloat()
                    width = mContainer.width
                    height = (height / ratio).toInt()
                    if (height >= mContainer.height) {
                        height = mContainer.height
                    }
                    bitmap = Bitmap.createScaledBitmap(bitmap!!, width, height, true)

                    backgroundView.scaleType = ImageView.ScaleType.CENTER_CROP
                    backgroundView.setImageBitmap(bitmap)
                }

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    super.onLoadFailed(errorDrawable)
                    try {
                        tBgPath = ""
                        failedBg = true
                        backgroundView.setColorFilter(0)
                        backgroundView.setImageDrawable(null)
                    } catch (e: Exception) { }
                }

                override fun onLoadCleared(placeholder: Drawable?) {}

            })

        //TODO Set Frame Of Combo
        Glide.with(this).load(framePath)
            .into(object : CustomTarget<Drawable>() {
                override fun onLoadCleared(placeholder: Drawable?) {}

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    super.onLoadFailed(errorDrawable)
                    try {
                        tFramePath = ""
                        failedFrame = true
                        frameView.setImageResource(0)
                    } catch (e: Exception) { }
                }

                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?,
                ) {
                    frameView.setImageDrawable(resource)
                }

            })

        if (!isFromUndoRedo) {
            //TODO Add Undo Redo OPERATION
            if (isFirstTimeApplyCombo){
                if (isFirstTimeApplyBg && isFirstTimeApplyFrame) {
                    Log.d(TAG, "performUndoRedo: ChangeACTION Inside")
                    val operation = UndoRedo.Operation()
                    operation.bgImage = ""
                    operation.frameImage = ""
                    val action = UndoRedo(ACTION.ChangeComboNone, 0, operation)
                    Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo NONE 2")
                    mUndo.add(action)
                    isFirstTimeApplyBg = false
                    isFirstTimeApplyFrame = false
                }
                isFirstTimeApplyCombo = false
            }
            val operation = UndoRedo.Operation()
            operation.bgImage = bgPath!!
            operation.frameImage = framePath!!
            val action = UndoRedo(ACTION.ChangeCombo, 0, operation)
            Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo 1")
            mUndo.add(action)

            if (failedBg && failedFrame){
                val operation1 = UndoRedo.Operation()
                operation1.bgImage = ""
                operation1.frameImage = ""
                val action1 = UndoRedo(ACTION.ChangeComboNone, 0, operation1)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo NONE 3")
                mUndo.add(action1)
            }
            if (mUndo.size == 1){
                val operation2 = UndoRedo.Operation()
                operation2.bgImage = ""
                operation2.frameImage = ""
                val action2 = UndoRedo(ACTION.ChangeComboNone, 0, operation2)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo NONE 5")
                mUndo.add(action2)
            }
        }
        manageUndoRedoButton()
//        isFromUndoRedo = false
    }
    @SuppressLint("NotifyDataSetChanged")
    private fun setOfflineComboImage(position: Int, isFromUndoRedo: Boolean = false){
        Log.d(TAG, "ComboBgFrame Set Images : Combo 1 bgPath $position")
        tComboBgPath = ""
        tComboFramePath = ""
        tFramePath = ""
        tBgPath = ""
        tBgColor = 0

        offlinePosition = position
        offlineComboPosition = position
        offlineBgPosition = -1
        offlineFramePosition = -1
        background.combo = position
        background.background = null
        background.frame = null
        backgroundAdapter.notifyDataSetChanged()
        frameAdapter.notifyDataSetChanged()
        comboAdapter.notifyDataSetChanged()

        try {
            backgroundView.setImageResource(offlineViewDataModel.offlineComboList.value!![0][position])
            frameView.setImageResource(offlineViewDataModel.offlineComboList.value!![1][position])
//        } catch (e: OutOfMemoryError) {
        } catch (e: Exception) { }

        if (!isFromUndoRedo) {
            //TODO Add Undo Redo OPERATION
            if (isFirstTimeApplyCombo){
                if (isFirstTimeApplyBg && isFirstTimeApplyFrame) {
                    Log.d(TAG, "performUndoRedo: ChangeACTION Inside")
                    val operation = UndoRedo.Operation()
                    operation.bgImage = ""
                    operation.frameImage = ""
                    val action = UndoRedo(ACTION.ChangeComboNone, 0, operation)
                    Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo NONE 2")
                    mUndo.add(action)
                    isFirstTimeApplyBg = false
                    isFirstTimeApplyFrame = false
                }
                isFirstTimeApplyCombo = false
            }
            val operation = UndoRedo.Operation()
            operation.bgImageOffline = position
            operation.frameImageOffline = position
            val action = UndoRedo(ACTION.ChangeCombo, 0, operation)
            Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo 1")
            mUndo.add(action)

//            if (mUndo.size == 1){
//                val operation2 = UndoRedo.Operation()
//                operation2.bgImage = ""
//                operation2.frameImage = ""
//                val action2 = UndoRedo(ACTION.ChangeComboNone, 0, operation2)
//                Log.d(TAG, "Undo Redo Added ACTION.ChangeCombo NONE 5")
//                mUndo.add(action2)
//            }
        }
        manageUndoRedoButton()
//        isFromUndoRedo = false
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setFrameImage(framePath: String?, isFromUndoRedo: Boolean = false) {
        Log.d(TAG, "ComboBgFrame Set Images : Frame $framePath")
        Log.d(TAG, "performUndoRedo: ACTION.ChangeBG: setFrameImage ")
        tFramePath = framePath!!
        background.frame = framePath
        tComboFramePath = ""

        Log.d(TAG, "ComboBgFrame Var tComboFramePath : null setFrameImage")
        Glide.with(this).load(framePath)
            .into(object : CustomTarget<Drawable>() {
            override fun onLoadCleared(placeholder: Drawable?) {}

            override fun onLoadFailed(errorDrawable: Drawable?) {
                super.onLoadFailed(errorDrawable)
                try {
                    if (framePath == "" && !isFromUndoRedo){
                        val operation = UndoRedo.Operation()
                        operation.frameImage = ""
                        val action = UndoRedo(ACTION.ChangeFrameNone, 0, operation)
                        Log.d(TAG, "Undo Redo Added ACTION.ChangeFrame NONE 1")
                        mUndo.add(action)
                    }
                    frameView.setImageResource(0)
//                    isFromUndoRedo = false
                } catch (e: Exception) { }
            }

            override fun onResourceReady(
                resource: Drawable,
                transition: Transition<in Drawable>?,
            ) {
                frameView.setImageDrawable(resource)
                Log.d(TAG, "onResourceReady: ${!isFromUndoRedo}")
                if (!isFromUndoRedo) {
                    //TODO Add Undo Redo OPERATION
                    if (isFirstTimeApplyFrame) {
                        val operation = UndoRedo.Operation()
                        operation.bgImage = tBgPath
                        operation.frameImage = ""
                        val action = UndoRedo(ACTION.ChangeFrameNone, 0, operation)
                        Log.d(TAG, "Undo Redo Added ACTION.ChangeFrame NONE 2")
                        mUndo.add(action)
                        isFirstTimeApplyFrame = false
                    }
                    val operation = UndoRedo.Operation()
                    try {
                        if (tBgPath != ""){
                            operation.bgImage = tBgPath
                        }else{
                            if (tComboBgPath != ""){
                                operation.bgImage = tComboBgPath
                            }else{
                                operation.bgImage = ""
                            }
                        }
                    } catch (e: Exception) { }
                    operation.frameImage = framePath
                    val action = UndoRedo(ACTION.ChangeFrame, 0, operation)
                    Log.d(TAG, "Undo Redo Added ACTION.ChangeFrame 1")
                    mUndo.add(action)
//                    Handler(Looper.getMainLooper()).postDelayed({
                          manageUndoRedoButton()
//                    },500)
                    if (mUndo.size == 1){
                        val operation1 = UndoRedo.Operation()
                        operation1.frameImage = ""
                        val action1 = UndoRedo(ACTION.ChangeFrameNone, 0, operation1)
                        Log.d(TAG, "Undo Redo Added ACTION.ChangeFrame NONE 3")
                        mUndo.add(action1)
                    }
                }
//                isFromUndoRedo = false
                Log.d(TAG, "onResourceReady: setFrameImage End")
            }

        })

        offlinePosition = -1
        offlineFramePosition = -1
        frameAdapter.notifyDataSetChanged()
    }
    @SuppressLint("NotifyDataSetChanged")
    private fun setOfflineFrameImage(position: Int, isFromUndoRedo: Boolean = false) {
        Log.d(TAG, "ComboBgFrame Set Images : Frame $position")
        Log.d(TAG, "performUndoRedo: ACTION.ChangeBG: setFrameImage ")
        tFramePath = ""
        tComboFramePath = ""
        background.frame = position
        Log.d(TAG, "ComboBgFrame Var tComboFramePath : null setFrameImage")
        if (!isFromUndoRedo) {
            //TODO Add Undo Redo OPERATION
            if (isFirstTimeApplyFrame) {
                val operation = UndoRedo.Operation()
                operation.bgImage = tBgPath
                operation.frameImage = ""
                val action = UndoRedo(ACTION.ChangeFrameNone, 0, operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeFrame NONE 2")
                mUndo.add(action)
                isFirstTimeApplyFrame = false
            }

            val operation = UndoRedo.Operation()
            if (tBgPath != "") {
                operation.bgImage = tBgPath
            } else if (tComboBgPath != "") {
                operation.bgImage = tComboBgPath
            } else{
                operation.bgImage = ""
            }
            operation.frameImageOffline = position
            val action = UndoRedo(ACTION.ChangeFrame, 0, operation)
            Log.d(TAG, "Undo Redo Added ACTION.ChangeFrame 1 $position")
            mUndo.add(action)
            manageUndoRedoButton()

            /*if (mUndo.size == 1){
                val operation1 = UndoRedo.Operation()
                operation1.frameImage = ""
                val action1 = UndoRedo(ACTION.ChangeFrameNone, 0, operation1)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeFrame NONE 3")
                mUndo.add(action1)
            }*/
        }
        offlinePosition = position
        offlineFramePosition = position
        offlineComboPosition = -1
        frameAdapter.notifyDataSetChanged()
        try { frameView.setImageResource(offlineViewDataModel.offlineFrameList.value!![position]) } catch (e: Exception) { }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun setBackgroundImage(bgPath: String?, isFromUndoRedo: Boolean = false) {
        Log.d(TAG, "ComboBgFrame Set Images : Background $bgPath")
        tBgColor = 0
        tBgPath = bgPath!!
        tComboBgPath = ""
        background.background = bgPath
        Glide.with(context).load(bgPath)
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?,
                ) {
                    Constants.isBgApply = true
                    bitmap = try {
                        (resource as BitmapDrawable).bitmap
                    } catch (e: Exception) {
                        getBitmapFromDrawable(resource)
                    }
                    var width = mContainer.width
                    var height = mContainer.height
                    val ratio = width.toFloat() / height.toFloat()
                    width = mContainer.width
                    height = (height / ratio).toInt()
                    if (height >= mContainer.height) {
                        height = mContainer.height
                    }
                    if (width == 0)
                        width = 1080
                    if (height == 0)
                        height = 1080
                    bitmap = Bitmap.createScaledBitmap(bitmap!!, width, height, true)

                    backgroundView.scaleType = ImageView.ScaleType.CENTER_CROP
                    backgroundView.setImageBitmap(bitmap)

                    //TODO Add Undo Redo OPERATION
                    if (!isFromUndoRedo) {
                        if (isFirstTimeApplyBg) {
                            val operation = UndoRedo.Operation()
                            operation.bgImage = ""
                            val action = UndoRedo(ACTION.ChangeBGNone, 0, operation)
                            Log.d(TAG, "Undo Redo Added ACTION.ChangeBG NONE 1")
                            Log.d(TAG, "BG Added Here: 1")
                            mUndo.add(action)
                            isFirstTimeApplyBg = false
                        }

                        val operation = UndoRedo.Operation()
                        if (tComboFramePath != "") {
                            operation.frameImage = tComboFramePath
                        } else {
                            operation.frameImage = ""
                        }

                        operation.bgImage = bgPath
                        val action = UndoRedo(ACTION.ChangeBG, 0, operation)
                        Log.d(TAG, "Undo Redo Added ACTION.ChangeBG 1")
                        Log.d(TAG, "BG Added Here: 2")
                        Log.d(TAG, "BG ACTION.ChangeBG: Added $bgPath")
                        mUndo.add(action)

                        if (mUndo.size == 1) {
                            val operation1 = UndoRedo.Operation()
                            operation1.bgImage = ""
                            val action1 = UndoRedo(ACTION.ChangeBGNone, 0, operation1)
                            Log.d(TAG, "Undo Redo Added ACTION.ChangeBG NONE 2")
                            Log.d(TAG, "BG Added Here: 4")
                            mUndo.add(action1)
                        }
                        manageUndoRedoButton()
                    }
//                        isFromUndoRedo = false
                }

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    super.onLoadFailed(errorDrawable)

                    backgroundView.setColorFilter(0)
                    backgroundView.setImageDrawable(null)

                    //OLD
                    if (!isFromUndoRedo) {
                        if (Constants.isBgApply) {
                            val operation = UndoRedo.Operation()
                            operation.bgImage = ""
                            val action = UndoRedo(ACTION.ChangeBGNone, 0, operation)
                            Log.d(TAG, "Undo Redo Added ACTION.ChangeBG NONE 3")
                            Log.d(TAG, "BG Added Here: 3")
                            mUndo.add(action)
                        } else {
                            val operation = UndoRedo.Operation()
                            operation.bgColor = Color.TRANSPARENT
                            val action = UndoRedo(ACTION.ChangeBGColor, 0, operation)
                            Log.d(TAG, "Undo Redo Added ACTION.ChangeBGColor 3")
                            mUndo.add(action)
                        }
                        manageUndoRedoButton()
                    }
                  //isFromUndoRedo = false
                }

                override fun onLoadCleared(placeholder: Drawable?) {}

            })

        offlinePosition = -1
        offlineBgPosition = -1
        backgroundAdapter.notifyDataSetChanged()
        /*if (mUndo.size == 1){
            val operation = UndoRedo.Operation()
            operation.bgImage = ""
            val action = UndoRedo(ACTION.ChangeBG, 0, "", operation)
            Log.d(TAG, "BG Added Here: 4")
            mUndo.add(action)
        }*/
    }
    @SuppressLint("NotifyDataSetChanged")
    private fun setOfflineBackgroundImage(position: Int, isFromUndoRedo: Boolean = false) {
        Log.d(TAG, "ComboBgFrame Set Images : Background $position")
        tBgColor = 0
        tBgPath = ""
        tComboBgPath = ""
        background.background = position
        //TODO Add Undo Redo OPERATION
        if (!isFromUndoRedo) {
            if (isFirstTimeApplyBg) {
                val operation = UndoRedo.Operation()
                operation.bgImage = ""
                val action = UndoRedo(ACTION.ChangeBGNone, 0, operation)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeBG NONE 1")
                Log.d(TAG, "BG Added Here: 1")
                mUndo.add(action)
                isFirstTimeApplyBg = false
            }

            val operation = UndoRedo.Operation()
            if (tComboFramePath != "") {
                operation.frameImage = tComboFramePath
            } else {
                operation.frameImage = ""
            }

            operation.bgImageOffline = position
            val action = UndoRedo(ACTION.ChangeBG, 0, operation)
            Log.d(TAG, "BG ACTION.ChangeBG: Added $position")
            mUndo.add(action)

            /*if (mUndo.size == 1) {
                val operation1 = UndoRedo.Operation()
                operation1.bgImage = ""
                val action1 = UndoRedo(ACTION.ChangeBGNone, 0, operation1)
                Log.d(TAG, "Undo Redo Added ACTION.ChangeBG NONE 2")
                Log.d(TAG, "BG Added Here: 4")
                mUndo.add(action1)
            }*/
            manageUndoRedoButton()
        }
        offlinePosition = position
        offlineBgPosition = position
        offlineComboPosition = -1
        backgroundAdapter.notifyDataSetChanged()
        try { backgroundView.setImageResource(offlineViewDataModel.offlineBgList.value!![position]) } catch (e: Exception) { }
    }

    @NonNull
    private fun getBitmapFromDrawable(@NonNull drawable: Drawable): Bitmap? {
        val bmp = Bitmap.createBitmap(drawable.intrinsicWidth,
            drawable.intrinsicHeight,
            Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bmp
    }

    private fun setBackgroundColor(bgColor: Int, isFromUndoRedo: Boolean = false) {
        tBgColor = bgColor
        frameView.setImageResource(0)
        backgroundView.setColorFilter(0)
        backgroundView.scaleType = ImageView.ScaleType.FIT_CENTER

        tBgPath = ""
        tFramePath = ""
        tComboBgPath = ""
        tComboFramePath = ""
        bitmap = createBitmap(bgColor, 255)
        backgroundView.setImageBitmap(bitmap)
//        backgroundView.setBackgroundColor(bgColor)
        if (isFirstTimeApplyBg){
            val operation = UndoRedo.Operation()
            operation.bgColor = 0
            val action = UndoRedo(ACTION.ChangeBGColor, 0, operation)
            Log.d(TAG, "Undo Redo Added ACTION.ChangeBGColor 1")
            mUndo.add(action)
            isFirstTimeApplyBg = false
            Log.d(TAG, "isFirstTimeApplyBg Inside")
        }
        val operation = UndoRedo.Operation()
        if (tFramePath != ""){
            operation.frameImage = tFramePath
        }else {
            operation.frameImage = ""
        }
        if(tComboFramePath != ""){
            operation.frameImage = tComboFramePath
        }else{
            operation.frameImage = ""
        }
        operation.bgColor = bgColor
        val action = UndoRedo(ACTION.ChangeBGColor, 0, operation)
        Log.d(TAG, "Undo Redo Added ACTION.ChangeBGColor 2")
        mUndo.add(action)
        manageUndoRedoButton()
        val dimension = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dimension)
        Constants.BgPosition = -1
        Constants.BgPositionColor = -1
    }

    override fun onPause() {
        super.onPause()
        try {
            if (editDialog != null && editDialog!!.isShowing) {
                editDialog!!.dismiss()
            } else if (::watchAdDialog.isInitialized && watchAdDialog.isShowing()) {
                supportFragmentManager.beginTransaction()
                    .remove(supportFragmentManager.findFragmentByTag("dialog_fragment")!!).commit()
                watchAdDialog.dismiss()
            } else if (::dialogWaterMark.isInitialized && dialogWaterMark.isShowing()) {
                supportFragmentManager.beginTransaction()
                    .remove(supportFragmentManager.findFragmentByTag("dialog_remove_watermark")!!)
                    .commit()
                dialogWaterMark.dismiss()
            } else if (::dialog.isInitialized && dialog.isShowing) {
//                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog")!!).commit()
                dialog.dismiss()
            } else if (dialogSave != null && dialogSave!!.isShowing()) {
                supportFragmentManager.beginTransaction().remove(supportFragmentManager.findFragmentByTag("dialog_save")!!).commit()
                dialogSave!!.dismiss()
            }
        } catch (e: Exception) {
            Log.d(TAG, "onPause: ${e.localizedMessage}")
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onResume() {
        super.onResume()
        checkRWPermission()
//        showGrid(horGrid = false, verGrid = false, isPointerUp = true)
        Constants.buyFromAddTextActivity = false
        registerReceiver(networkReceiver, intentFilter)
        isGallery = true
        isColorPick = true
        mIsOpenGallery = false
        mIsSubScribe = MySharedPreferences(
            this
        ).isSubscribe
        if (!mIsSubScribe){
            if (isOnline()) {
                findViewById<FrameLayout>(R.id.fl_adplaceholder).show()
                val width = displayWidth()
                val height = displayHeight()
                Log.d(TAG, "onResume: $width $height")
                /*if ( height<1216 && height>1776){ //10ore or small device : Don't Show Ads
                    OfflineNativeAdvancedHelper.loadOfflineNativeAdvanceEditScreen(this, findViewById(R.id.fl_adplaceholder)) {}
                }
                if (height>1776){ //10ore or small device : Don't Show Ads
                    OfflineNativeAdvancedHelper.loadOfflineNativeAdvanceEditScreen(this, findViewById(R.id.fl_adplaceholder)) {}
                }*/
                if (isMobile() && height != 1776) {
                    OfflineNativeAdvancedHelper.loadOfflineNativeAdvanceEditScreen(
                        this,
                        findViewById(R.id.fl_adplaceholder)
                    ) {}
                }
            } else {
                findViewById<FrameLayout>(R.id.fl_adplaceholder).hide()
            }
            imgWaterMarkClose.show()
        }else{
            rlWaterMarlClick.hide()
            if (isFirstTimeBuySubcription){
                upgradeToPremium()
                isFirstTimeBuySubcription = false
            }
        }
        imgBtnSave.enabled()
        mConstraintMenuFrame.enabled()
        mConstraintMenuAddText.enabled()
        mConstraintMenuBG.enabled()
        mConstraintMenuSticker.enabled()
        /*if (editDialog != null) {
            if (editDialog!!.isShowing) {
                isDialogOpen = false
                editDialog!!.dismiss()
            }
        }

        if (dialogSave!=null){
            if (dialogSave!!.isShowing()){
                dialogSave!!.dismiss()
            }
        }*/
    }

    override fun onDestroy() {
        super.onDestroy()
        isFirstTimeApplyBg      = true
        isFirstTimeApplyFrame   = true
        isFirstTimeApplyCombo   = true
        Constants.previousTexturePosition = -1
        Constants.previousTexturePosition = -1
        isFromUndoRedo = false
        Constants.isBgApply      = false
        Constants.isComboApply   = false
        BGActivity.mPosition = 0
        StickerActivity.mPosition = 0
        FrameActivity.mPosition = 0
        ComboActivity.mPosition = 0
//        tBgPath = ""
//        tFramePath = ""
        System.gc()
    }

    override fun onBackPressed() {

        if (llShowTextFun.visibility == View.VISIBLE || clMainOptionContainer.visibility == View.VISIBLE) {
            Log.d(TAG, "stickerView: performClick 17")
            stickerView.performClick()
            return
        } else {
            if (::dialog.isInitialized && !dialog.isShowing) {
//                if (SystemClock.elapsedRealtime() - lastClickTime < 500) return
                lastClickTime = SystemClock.elapsedRealtime()
                stickerView.performClick()
                dialog.show()
            }
        }

        isState = false
        mConstraintMenuBG.enabled()
        mConstraintMenuAddText.enabled()
        mConstraintMenuSticker.enabled()
        mConstraintMenuFrame.enabled()
        if (mConstraintSubLayoutGradient.visibility == View.VISIBLE) {
            mConstraintSubLayoutGradient.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (mConstraintSubLayoutShadowColor?.visibility == View.VISIBLE) {
            mConstraintSubLayoutShadowColor?.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (mConstraintSubLayoutTexture.visibility == View.VISIBLE) {
            mConstraintSubLayoutTexture.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (mConstraintSubLayoutText3d.visibility == View.VISIBLE) {
            mConstraintSubLayoutText3d.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (mConstraintSubLayoutTextSpace?.visibility == View.VISIBLE) {
            mConstraintSubLayoutTextSpace?.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (mConstraintSubLayoutTextCurve?.visibility == View.VISIBLE) {
            mConstraintSubLayoutTextCurve?.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (constraintSubLayoutFontStyle.visibility == View.VISIBLE) {
            constraintSubLayoutFontStyle.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (constraintSubLayoutColor.visibility == View.VISIBLE) {
            constraintSubLayoutColor.hide()
            mConstraintLayoutAddText?.show()
            mRecyclerAddText.enabled()
        } else if (mConstraintLayoutAddText?.visibility == View.VISIBLE) {
            mConstraintLayoutAddText?.hide()
            mRecyclerAddText.disabled()
            clMainOptionView.show()
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
            try {
                for (i in 0 until context.stickerView.childCount) {
                    context.stickerView.getChildAt(i)
                        .findViewById<ConstraintLayout>(R.id.ll_view1)
                        .setBackground(null as Drawable?)
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnDelete) as ImageView).visibility =
                        View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnFlip) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnZoom) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnEdit) as ImageView).visibility = View.INVISIBLE
                    selectedSticker = null
                    index = null
                    mConstraintMenuBG.enabled()
                    mConstraintMenuAddText.enabled()
                    mConstraintMenuSticker.enabled()
                    mConstraintMenuFrame.enabled()
                }
            } catch (e: Exception) {
            }

        } else if (mConstraintLayoutBG?.visibility == View.VISIBLE) {
            mConstraintLayoutBG?.hide()
            clMainOptionView.show()
            try {
                for (i in 0 until context.stickerView.childCount) {
                    context.stickerView.getChildAt(i)
                        .findViewById<ConstraintLayout>(R.id.ll_view1)
                        .setBackground(null as Drawable?)
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnDelete) as ImageView).visibility =
                        View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnFlip) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnZoom) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnEdit) as ImageView).visibility = View.INVISIBLE
                    selectedSticker = null
                    index = null
                    mConstraintMenuBG.enabled()
                    mConstraintMenuAddText.enabled()
                    mConstraintMenuSticker.enabled()
                    mConstraintMenuFrame.enabled()
                }
            } catch (e: Exception) { }
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
        } else if (mConstraintSubLayoutStickerItems?.visibility == View.VISIBLE) {
            mImgBackStickerItemCategory.performClick()
        } else if (mConstraintFrameLayout?.visibility == View.VISIBLE) {
            mConstraintFrameLayout?.hide()
            clMainOptionView.show()
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
            try {
                for (i in 0 until context.stickerView.childCount) {
                    context.stickerView.getChildAt(i)
                        .findViewById<ConstraintLayout>(R.id.ll_view1)
                        .setBackground(null as Drawable?)
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnDelete) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnFlip) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnZoom) as ImageView).visibility = View.INVISIBLE
                    (context.stickerView.getChildAt(i)
                        .findViewById(R.id.btnEdit) as ImageView).visibility = View.INVISIBLE
                    selectedSticker = null
                    index = null
                    mConstraintMenuBG.enabled()
                    mConstraintMenuAddText.enabled()
                    mConstraintMenuSticker.enabled()
                    mConstraintMenuFrame.enabled()
                }
            } catch (e: Exception) { }

        } else {
            hideControlsUI(true)
            mConstraintSubLayoutStickerItems?.hide()
            clMainOptionView.show()
            mConstraintMenuBG.enabled()
            mConstraintMenuSticker.enabled()
            mConstraintMenuFrame.enabled()
            mConstraintMenuAddText.enabled()
        }
    }

    private fun createBitmapFromView(view: View, width: Int, height: Int): Bitmap {

            Log.d("main", "====width ${width} height ${height}")
            if (width > 0 && height > 0) {
                view.measure(
                    View.MeasureSpec.makeMeasureSpec(
                        width, View.MeasureSpec.EXACTLY
                    ),
                    View.MeasureSpec.makeMeasureSpec(
                        height, View.MeasureSpec.EXACTLY
                    )
                )
            }
            val viewCopy = view

            viewCopy.layout(0, 0, view.measuredWidth, view.measuredHeight)

            val bitmap = Bitmap.createBitmap(
                viewCopy.measuredWidth,
                viewCopy.measuredHeight, Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)

            /*val background = if (view.background!=null){
            view.background
        }else{
            Color.WHITE as ColorDrawable
        }*/
            val background = viewCopy.background

            background?.draw(canvas)
            viewCopy.draw(canvas)

            return bitmap
    }

    private fun generateBorderImage(bitmap: Bitmap, color: Int, border: Float): Bitmap? {
        val finalBitmap = Bitmap.createBitmap(
            (bitmap.width+(border)).roundToInt(),
            (bitmap.height+(border)).roundToInt(),
            Bitmap.Config.ARGB_8888
        )

        Log.d("TAG", "generateBorderImage: W : ${finalBitmap.width} and H : ${finalBitmap.height}")

//        val rect = Rect(0,0,finalBitmap.width,finalBitmap.height)
        val rect = Rect(border.roundToInt(), border.roundToInt(), bitmap.width,bitmap.height)
        val borderRect = Rect(0,0, finalBitmap.width,finalBitmap.height)
//        val rectF = RectF(rect)
//        val bgBitmap = Bitmap.createScaledBitmap(bitmap, bitmap.width+50, bitmap.height+50,false)
        val bgBitmap = Bitmap.createScaledBitmap(bitmap,
            (bitmap.width),
            (bitmap.height),
            false)
        val canvas = Canvas(finalBitmap)
        val filter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)

        canvas.drawBitmap(bgBitmap, null, borderRect, Paint().apply {
            this.color = color
            this.colorFilter = filter
            this.style = Paint.Style.FILL
        })

        canvas.drawBitmap(bitmap, null, rect, null)
        return finalBitmap
    }

    /** Manage All Mode Of TextArt HERE
     * 1. DRAFT   -> Draft Mode
     * 2. LOGO    -> Logo Mode
     * 3. NAME    -> NAME Mode
     * 4. DEFAULT -> D̈efault Mode
     * By Default Call Default Mode */
    private fun manageMode() {
        if (intent.hasExtra("mode")){
            MODE = when(intent.getStringExtra("mode")){
                DRAFT -> DRAFT
                LOGO  -> LOGO
                NAME  -> NAME
                else  -> DEFAULT
            }
        }

        Log.d(TAG, "manageMode: Mode $MODE")
        //TODO Manage Mode
        when (MODE) {
            DRAFT -> {
                //TODO Display Dialog First
                progressDialog?.show()

                val draftDB = DraftDatabase.getInstance(context)
                val draftPos = intent.getIntExtra("position",0)
                val draftData = draftDB.draftDao().findDraft(draftPos)

                val type = object : TypeToken<ArrayList<StickerModel>>() {}.type
                val drafts = Gson().fromJson<ArrayList<StickerModel>>(draftData?.stickerList, type)

                var isComboBgApply = true
                var isComboFrameApply = true

                //TODO manage BG, Frame &Combo
                draftData?.combo?.let { combo ->
                    Gson().fromJson<Background>(
                        combo, object : TypeToken<Background>() {}.type)
                        .apply {
                            if (this.combo != null) {
                                Log.d(TAG, "manageMode: Background this.combo is != null")
                                Log.d(TAG, "manageMode: Background this.combo      is ${this.combo}")
                                Log.d(TAG, "manageMode: Background this.background is ${this.background}")
                                Log.d(TAG, "manageMode: Background this.frame      is ${this.frame}")
                                if (this.combo is Double) {
                                    if (this.combo != -1.0) {
                                        Log.d(TAG, "manageMode: Background this.combo != -1.0")
                                        setOfflineComboImage((this.combo as Double).toInt(), isFromUndoRedo = true)
                                    }else{
                                        Log.d(TAG, "manageMode: Background this.combo = null")
//                                        backgroundView.setImageDrawable(null)
//                                        frameView.setImageDrawable(null)
//                                        context.background.combo = -1
                                    }
                                }
                            }
                            if (this.background is Double) {
                                if (this.background != -1.0) {
                                    Log.d(TAG, "manageMode: Background this.background != -1")
                                    setOfflineBackgroundImage((this.background as Double).toInt(), isFromUndoRedo = true)
                                } else {
                                    Log.d(TAG, "manageMode: Background this.background = null")
                                    backgroundView.setImageDrawable(null)
                                    context.background.background = -1
                                    isComboBgApply = false
                                }
                            } else if (this.background is String) {
                                    Log.d(TAG, "manageMode: Background this.background is String")
                                    setBackgroundImage((this.background as String), isFromUndoRedo = true)
                            }
                            if (this.frame is Double) {
                                if (this.frame != -1.0) {
                                    Log.d(TAG, "manageMode: Background this.frame != -1")
                                    setOfflineFrameImage((this.frame as Double).toInt(), isFromUndoRedo = true)
                                } else {
                                    Log.d(TAG, "manageMode: Background this.frame = null")
                                    frameView.setImageDrawable(null)
                                    context.background.frame = -1
                                    isComboFrameApply = false
                                }
                            } else if (this.frame is String) {
                                Log.d(TAG, "manageMode: Background this.frame is String")
                                setFrameImage((this.frame as String), isFromUndoRedo = true)
                            }
                            if (!isComboBgApply && !isComboFrameApply){
                                offlinePosition = -1
                                offlineComboPosition = -1
                                comboAdapter.notifyDataSetChanged()
                            }
                        }
                }

//                draftData?.combo?.let { combo ->
//                    if (combo != ""){
//                        if (combo.length > 3){
//                            setComboImage(draftData.background, draftData.frame, isFromUndoRedo = true)
//                        }else{
//                            setOfflineComboImage(combo.toInt(), isFromUndoRedo = true)
//                        }
//                    }
//                }
//                draftData?.background?.let { bg ->
//                    if (bg != ""){
//                        if (bg.length > 3){
//                            setBackgroundImage(bg, isFromUndoRedo = true)
//                        }else{
//                            setOfflineBackgroundImage(bg.toInt(), isFromUndoRedo = true)
//                        }
//                    }
//                }
//                draftData?.frame?.let { frame ->
//                    if (frame != ""){
//                        if (frame.length > 3){
//                            setFrameImage(frame, isFromUndoRedo = true)
//                        }else{
//                            setOfflineFrameImage(frame.toInt(), isFromUndoRedo = true)
//                        }
//                    }
//                }
                draftData?.watermark.let {
                    if (it == true){
                        rlWaterMarlClick.show()
                    }else{
                        rlWaterMarlClick.hide()
                    }
                }

                Log.d(TAG, "manageMode: BG combo Mode ${draftData?.combo!!}")
//                Log.d(TAG, "manageMode: BG background Mode ${draftData?.background!!}")
//                Log.d(TAG, "manageMode: BG frame Mode ${draftData?.frame!!}")
                //TODO manage STICKER
                if (drafts.isNullOrEmpty()) {
                    startEditing()
                    progressDialog?.dismiss()
                    return
                }
                lifecycleScope.launch{

                    withContext(Dispatchers.IO){
                        draftTotal = drafts.size - 1
                        for ((i, stk) in drafts.withIndex()){
                            Log.d(TAG, "buildDialog: StickerView type ${stk.tYPE}")
                            Log.d(TAG, "buildDialog: StickerView text ${stk.tEXT}")

                            val stickerInfo = StickerModel().apply {
                                stk.let { info ->
                                    if (stk.tYPE == TEXT_STICKER) {
                                        tYPE = TEXT_STICKER
                                        tEXT = info.tEXT
                                        mIN_W = dpToPx(context, 55)
                                        mIN_H = dpToPx(context, 55)
                                        textColor = Color.WHITE
                                    } else if (stk.tYPE == IMAGE_STICKER) {
                                        tYPE = IMAGE_STICKER
                                        tEXT = stk.tEXT
                                        mIN_W = dpToPx(context, 100)
                                        mIN_H = dpToPx(context, 100)
                                        textColor = Color.TRANSPARENT
                                    }

                                    Log.d(TAG, "manageMode: sticker value Mode isFlip 1. $isFlipped 2.Info ${info.isFlipped}")
                                    pOS_X = info.pOS_X
                                    pOS_Y = info.pOS_Y
                                    wIDTH = info.wIDTH
                                    hEIGHT = info.hEIGHT
                                    isFlipped = info.isFlipped

                                    aLPHA = 255
                                    sHADOW_X = 0
                                    sHADOW_Y = 0
                                    bG_ALPHA = 0
                                    fONT_NAME = ""
                                    fIELD_TWO = ""
                                    rOTATION = stk.rOTATION
                                    bG_DRAWABLE = "0"
                                    sHADOW_PROGRESS = 0
                                    shadowColor = Color.BLACK
                                    bG_COLOR = Color.TRANSPARENT

                                    //TODO Update Sticker Information For Using Draft Functionality
                                    if (stk.positionFont != -1)
                                        positionFont = stk.positionFont
                                    if (stk.singleColorPos != -1)
                                        singleColorPos = stk.singleColorPos
                                    if (stk.positionGradient != -1)
                                        positionGradient = stk.positionGradient
                                    if (stk.positionMultiple != -1)
                                        positionMultiple = stk.positionMultiple
                                    if (stk.positionTexture != -1)
                                        positionTexture = stk.positionTexture
                                    else if (stk.patternString != null)
                                        patternString = stk.patternString
                                    if (stk.rotateX.toInt() != 0)
                                        rotateX = stk.rotateX
                                    if (stk.rotateY.toInt() != 0)
                                        rotateY = stk.rotateY

                                    Log.d(TAG, "updateSelectedSticker stickerList: rotateX ${stk.rotateX} rotateY ${stk.rotateY}")
                                    Log.d(TAG, "updateSelectedSticker stickerList: stk.fontType ${stk.fontType}")

                                    if (stk.bold)
                                        bold = true
                                    if (stk.italic)
                                        italic = true
                                    if (stk.underline)
                                        underline = true
                                    if (stk.fontType != "Default")
                                        fontType = stk.fontType
                                    if (stk.isGlow) {
                                        isGlow = true
                                        glowColorPos = stk.glowColorPos
                                        glowRadius = stk.glowRadius
                                    }
                                }
                            }

                            (Dispatchers.Main){
                                addSticker(stk.tYPE!!, stk.tEXT, stickerInfo, i)
                            }
                        }
                    }
                }
            }
            LOGO  -> {

            }
            NAME  -> {

            }
            else -> { startEditing() }
        }

//        if (intent.hasExtra("LOGO")){
//            //TODO Regular Open Activity From Generate Logo Activity
//            val selectedLogo = intent.getSerializableExtra("LOGO") as LogoData
//            Log.d(TAG, "initViewAction: LOGO Model $selectedLogo")
//            tStickerPath = selectedLogo.logo!!
//            Glide.with(this).load(tStickerPath).into(object : CustomTarget<Drawable>() {
//                override fun onLoadCleared(placeholder: Drawable?) {}
//
//                override fun onResourceReady(
//                    resource: Drawable,
//                    transition: Transition<in Drawable>?,
//                ) {
//                    runBlocking {
//                        val job = launch {
//                            addShadowSticker("", resource, null, true, null)
//                            (selectedSticker!!.findViewById(R.id.btnEdit) as ImageView).layoutParams.width    = 35 /*mContainer.width/100*5*/
//                            (selectedSticker!!.findViewById(R.id.btnEdit) as ImageView).layoutParams.height   = 35 /*mContainer.width/100*5*/
//                            (selectedSticker!!.findViewById(R.id.btnFlip) as ImageView).layoutParams.width    = 35 /*mContainer.width/100*5*/
//                            (selectedSticker!!.findViewById(R.id.btnFlip) as ImageView).layoutParams.height   = 35 /*mContainer.width/100*5*/
//                            (selectedSticker!!.findViewById(R.id.btnZoom) as ImageView).layoutParams.width    = 35 /*mContainer.width/100*5*/
//                            (selectedSticker!!.findViewById(R.id.btnZoom) as ImageView).layoutParams.height   = 35 /*mContainer.width/100*5*/
//                            (selectedSticker!!.findViewById(R.id.btnDelete) as ImageView).layoutParams.width  = 35 /*mContainer.width/100*5*/
//                            (selectedSticker!!.findViewById(R.id.btnDelete) as ImageView).layoutParams.height = 35 /*mContainer.width/100*5*/
//                            Log.d(TAG, "onResourceReady: Sticker Icon Size: ${mContainer.width/100*5}")
//                            selectedSticker!!.scaleX = 2.0F
//                            selectedSticker!!.scaleY = 2.0F
//
//                            Log.d(TAG, "onResourceReady: height ${selectedSticker!!.height}")
//                            Log.d(TAG, "onResourceReady: width ${selectedSticker!!.width}")
//                            Log.d(TAG, "onResourceReady: x ${selectedSticker!!.x}")
//                            Log.d(TAG, "onResourceReady: y ${selectedSticker!!.y}")
//
//                            Log.d(TAG, "onResourceReady: mContainer width ${mContainer.width} height ${mContainer.height}")
//                            (selectedSticker!!.findViewById(R.id.btnEdit) as ImageView).requestLayout()
//                            (selectedSticker!!.findViewById(R.id.btnFlip) as ImageView).requestLayout()
//                            (selectedSticker!!.findViewById(R.id.btnZoom) as ImageView).requestLayout()
//                            (selectedSticker!!.findViewById(R.id.btnDelete) as ImageView).requestLayout()
//                            stickerView.performClick()
//                        }
//                        job.invokeOnCompletion {
//                            Handler(Looper.getMainLooper()).postDelayed({
//                                addShadowSticker(intent.getStringExtra("TEXT"), null, null, true, null)
//                                stickerList[index!!].isApplyStroke = true
//                                stickerList[index!!].isAbleToAddWhiteColor = false
//                                setTextColorFromColorPicker(Color.parseColor(selectedLogo.color.text))
////                              selectedSticker!!.translationX = (logoArray[pos].x * mContainer.width).toFloat()
//                                selectedSticker!!.translationY = (selectedLogo.y * mContainer.height).toFloat()
//                                selectedSticker!!.findViewById<AutoResizeTextView>(R.id.realText).typeface = Typeface.createFromAsset(assets, "fonts/sfespresso.ttf")
//                                val strokeColor = Color.parseColor(selectedLogo.color.border)
//                                stickerList[index!!].storeWidth = selectedLogo.stroke
//                                stickerList[index!!].strokeColor = strokeColor
//                                selectedSticker!!.findViewById<AutoResizeTextView>(R.id.realText).setStoke(strokeColor, selectedLogo.stroke)
//                                selectedSticker!!.rotation = (selectedLogo.rotation * -1).toFloat()
//                                selectedSticker!!.findViewById<AutoResizeTextView>(R.id.flippedText).setStoke(strokeColor, selectedLogo.stroke)
//                                selectedSticker!!.findViewById<AutoResizeTextView>(R.id.realText).typeface = Typeface.createFromAsset(assets, "tempFont/${selectedLogo.fontFamily}")
//                                selectedSticker!!.findViewById<AutoResizeTextView>(R.id.flippedText).typeface = Typeface.createFromAsset(assets, "tempFont/${selectedLogo.fontFamily}")
////                                stickerView.performClick()
//                                if (selectedLogo.color.bg.contains("webp") || selectedLogo.color.bg.contains("image")){
//                                    setBackgroundImage(selectedLogo.color.bg)
//                                }else if(selectedLogo.color.bg.contains("#")){
//                                    setBackgroundColor(Color.parseColor(selectedLogo.color.bg))
//                                }
//                                stickerView.performClick()
//                            },50)
//                        }
//                    }
//                }
//            })
//        }else{
//            //TODO Regular Open Activity
//            openAddTextDialogeFirst()
//        }

//        deleteDirectory("$cacheDir/previewFile")
    }

    companion object{
        lateinit var mContainer: ConstraintLayout
        const val CENTER_X = 0.497
        const val CENTER_Y = 0.503
        const val CENTER_X1 = 0.247
        const val CENTER_Y1 = 0.253
        const val CENTER_X2 = 0.747
        const val CENTER_Y2 = 0.753
//        const val CENTER_X = 0.45
//        const val CENTER_Y = 0.55
    }
}
