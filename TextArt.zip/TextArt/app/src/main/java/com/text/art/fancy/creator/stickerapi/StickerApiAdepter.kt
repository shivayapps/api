package com.text.art.fancy.creator.BackgroundApi

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.categorys.parameter.CategoryParametersItem
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.newapi.category.CategoryItem
import java.util.*

class StickerApiAdepter(
    var mContext: Context,
    var imageItems: ArrayList<CategoryItem>?,
    var onItemClickSticker: OnItemClickSticker
) : RecyclerView.Adapter<StickerApiAdepter.MyViewHolder>() {

    interface OnItemClickSticker {
        fun onItemClickSticker(position: Int,string: String)
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgBackground: ImageView = itemView.findViewById(R.id.imgBackground)
        val imgLock: ImageView = itemView.findViewById(R.id.imgLock)
        val imgLockPremium: ImageView = itemView.findViewById(R.id.imgLockPremium)
        val mProgressBar: ProgressBar = itemView.findViewById(R.id.mProgressBar)
        val isLoaded: TextView = itemView.findViewById(R.id.isLoadedData)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StickerApiAdepter.MyViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.rv_api_item, parent, false)
        return MyViewHolder(view)
    }


    override fun getItemCount(): Int {
        return imageItems!!.size
    }

    override fun onBindViewHolder(myholder: MyViewHolder, @SuppressLint("RecyclerView") i: Int) {
        myholder.imgBackground.setOnLongClickListener { true }
        myholder.imgBackground.visibility = View.VISIBLE
        myholder.imgLockPremium.visibility = View.GONE
        myholder.imgLock.visibility = View.GONE
        Glide.with(mContext)
                .load(imageItems!![i].image)
                .listener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(e: GlideException?, model: Any?, target: com.bumptech.glide.request.target.Target<Drawable>?, isFirstResource: Boolean): Boolean {
                        myholder.isLoaded.text = "No"
                        return false
                    }

                    override fun onResourceReady(resource: Drawable?, model: Any?, target: com.bumptech.glide.request.target.Target<Drawable>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                        myholder.isLoaded.text = "Yes"
                        if (imageItems!![i].isPremium == 1) {
                            myholder.imgLockPremium.visibility=View.VISIBLE
                        }else if (imageItems!![i].coin == 10){
                            myholder.imgLock.visibility=View.VISIBLE
                        }
                        return false
                    }
                }).into(myholder.imgBackground)

        myholder.imgBackground.setOnClickListener {
            if (myholder.isLoaded.text == "Yes"){
                onItemClickSticker.onItemClickSticker(i,imageItems!![i].image!!)
            }else{
                Toast.makeText(mContext, "Please wait", Toast.LENGTH_SHORT).show()
            }
        }
    }
}