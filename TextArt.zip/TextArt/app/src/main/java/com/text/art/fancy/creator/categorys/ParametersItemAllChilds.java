package com.text.art.fancy.creator.categorys;

import androidx.room.PrimaryKey;

import com.text.art.fancy.creator.categorys.parameter.CategoryParametersItem;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ParametersItemAllChilds {
	@PrimaryKey(autoGenerate = true)
	private int note_id;

	@SerializedName("name")
	private String name;

	@SerializedName("id")
	private int id;

	@SerializedName("images")
	private ArrayList<CategoryParametersItem> categoryParameters;

	@SerializedName("icon")
	private String icon;

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public void setCategoryParameters(ArrayList<CategoryParametersItem> categoryParameters){
		this.categoryParameters = categoryParameters;
	}

	public ArrayList<CategoryParametersItem> getCategoryParameters(){
		return categoryParameters;
	}

	@Override
 	public String toString(){
		return 
			"ParametersItem{" + 
			"name = '" + name + '\'' + 
			",id = '" + id + '\'' + 
			",category_parameters = '" + categoryParameters + '\'' +
			"}";
		}
}