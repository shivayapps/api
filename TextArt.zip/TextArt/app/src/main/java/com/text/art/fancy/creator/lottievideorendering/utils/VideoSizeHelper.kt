package com.text.art.fancy.creator.lottievideorendering.utils

import android.graphics.Rect
import android.view.View

object VideoSizeHelper {

    fun getX(parent:View,child: View):Float{
        return (getChangedWidht(child).toDouble() / parent.width.toDouble()).toFloat()
    }
    fun getY(parent:View,child: View):Float{
        return (getChangedHeight(child).toDouble() / parent.height.toDouble()).toFloat()
    }

    private fun getChangedWidht(view: View): Float {
        return view.width * view.scaleX
    }

    private fun getChangedHeight(view: View): Float {
        return view.height * view.scaleY
    }

    //will return center of child X
    fun getCenterX(parent: View,child: View):Float{
        val rect = Rect()
        child.getHitRect(rect)
        return (rect.centerX().toDouble()/parent.width.toDouble()).toFloat()
    }

    fun getCenterY(parent: View,child: View):Float{
        val rect = Rect()
        child.getHitRect(rect)
        return (rect.centerY().toDouble()/parent.height.toDouble()).toFloat()
    }

}