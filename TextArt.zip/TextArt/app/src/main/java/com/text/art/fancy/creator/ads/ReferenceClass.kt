package com.text.art.fancy.creator.ads

class ReferenceClass {
//    companion object {
//        init {
//            System.loadLibrary("native-lib")
//        }
//    }

    fun getKeys(type : String): String {
        if (type== "l_i") {
            return "Y2EtYXBwLXB1Yi0yMDMzNDEzMTE4MTE0MjcwLzkwMzUxOTY1MDE=";
        } else if (type=="l_n") {
            return "Y2EtYXBwLXB1Yi0yMDMzNDEzMTE4MTE0MjcwLzM3ODI4Njk4MjM=";
        } else if (type== "l_r") {
            return "";
        }else if (type== "l_b") {
            return "Y2EtYXBwLXB1Yi0yMDMzNDEzMTE4MTE0MjcwLzU2NzMwNDUzMDA=";
        }
        return ""
    }

    fun getKeysf(type : String) : String {
        if (type== "f_i1") {
            return "MzY4MTMxNTkzODMzMTU2XzM2ODEzMTk3MDQ5OTc4NQ==";
        } else if (type=="f_i2") {
            return "MzY4MTMxNTkzODMzMTU2XzQ0MDk0NTk5OTg4NTA0OA==";
        } else if (type== "f_n1") {
            return "MzY4MTMxNTkzODMzMTU2XzM3ODY0MTE5OTQ0ODg2Mg==";
        }else if (type== "f_n2") {
            return "MzY4MTMxNTkzODMzMTU2XzQ0MDk0NTc3NjU1MTczNw==";
        }
        return ""
    }
}