package com.text.art.fancy.creator.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.util.Log
import android.widget.Toast
import com.text.art.fancy.creator.interfaces.broadcastReceivers

class ConnectionReceiver(var listner: broadcastReceivers) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("API123", "" + intent.action)
        if (intent.action == "com.example.androidkotlin.boradcastReceivers.SOME_ACTION")
            Toast.makeText(context, "SOME_ACTION is received", Toast.LENGTH_LONG
        ).show() else {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = cm.activeNetworkInfo
            val isConnected = activeNetwork != null &&
                    activeNetwork.isConnectedOrConnecting
            if (isConnected) {
                try {
                    listner.onNetworkChanged(true)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                listner.onNetworkChanged(false)
            }
        }
    }
}