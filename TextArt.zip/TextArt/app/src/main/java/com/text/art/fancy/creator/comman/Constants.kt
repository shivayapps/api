package com.text.art.fancy.creator.comman

import java.util.regex.Pattern


object Constants {

    const val BOLD           = "BOLD"
    const val ITALIC         = "ITALIC"
    const val UNDERLINE      = "UNDERLINE"
    const val CASE           = "CASE"
    const val FontFolder     = "fontsnew"
    const val MusicFolder    = "OfflineMusic"
    const val downloadedFont = "DownloadedFont"

    //MODE
    const val DRAFT = "DRAFT"
    const val LOGO  = "LOGO"
    const val NAME  = "NAME"

    const val WRITE_EXTERNAL_STORAGE_CODE = 1001
    const val VIEW_TYPE_ITEM = 0
    const val VIEW_TYPE_LOADING = 1

    var isDeleteOperationPerform = false
    var animId: Int = 0
    var frameId: Int = 0
    var stickerId: Int = 0
    var bgId: Int = 0
    var comboId: Int = 0
    var selectedAnimation = ""
    var selectedCombo = ""
    var selectedFrame = ""
    var selectedBg = ""
    var selectedSticker = ""

    var CategoryPosition = 0
    var BgPosition = -1
    var BgPositionColor = -1
    var previousTexturePosition = -1
    const val totalAssetsFont = 19
    //    var stickerTypeface: String = ""
//    var shadowColorShawPrggress: Int = 0
//    var shadowColorShawPrggress1: Int = 0
    //    var typeface: Typeface? = null
    var mCachePath: String = ""
    var isDraftUpdate = false
    var isSaveUpdate = false
    var showAdInSharePage: Boolean? = false
    var isStartDownloadFont: Boolean = false
    var isEditSticker: Boolean = false
    var isAdsShow: Boolean = false
    var buyFromAddTextActivity: Boolean = false
    var stickerText = ""
    var mSelectedColorPos: Int = -1
    var isBgApply: Boolean = false
    var isFirstTimeApplyCombo = true
    var isFirstTimeApplyBg = true
    var isFirstTimeApplyFrame = true

    //Sticker Type
    var LOTTIE = "LottieSticker"
    var TEXT = "TextSticker"
    var IMAGE = "ImageSticker"

    var currentViewPagerItem = 0

    //tmp Variable
    var isComboApply: Boolean = false

    fun isContainEmoji(message: String): Boolean {
        val pattern = Pattern.compile(
            "[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]",
            Pattern.UNICODE_CASE or Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(message)
        while (matcher.find()) {
            return true
        }
        return false
    }

}
