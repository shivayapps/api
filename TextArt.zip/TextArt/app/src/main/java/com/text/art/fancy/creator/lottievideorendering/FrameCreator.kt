package com.text.art.fancy.creator.lottievideorendering

import android.annotation.SuppressLint
import android.graphics.*
import android.util.Log
import android.view.View
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import kotlin.math.roundToInt

class FrameCreator(
    private val lottieDrawable: LottieDrawable,
    private val VIDEO_WIDTH_PX: Float,
    private val VIDEO_HEIGHT_PX: Float,
    private val lottieAnimationView: LottieAnimationView
) {

    private val TAG = "FrameCreator"

    init {
        lottieDrawable.scale = VIDEO_WIDTH_PX / lottieDrawable.intrinsicWidth
        lottieAnimationView.scale = VIDEO_WIDTH_PX / lottieDrawable.intrinsicWidth
    }

    private val durationInFrames: Int = lottieDrawable.composition.durationFrames.toInt()
    private var currentFrame: Int = 0


    fun generateFrame(): Bitmap {
        lottieAnimationView.frame = currentFrame
        val bitmap = viewToImage(lottieAnimationView)
        Log.d(TAG, "generateFrame: bitmap $bitmap")
        ++currentFrame
        Log.d(TAG, "generateFrame: Total $currentFrame")
        return bitmap!!
    }

    fun progress() = (currentFrame.toDouble() / durationInFrames.toDouble() * 100).roundToInt()

    fun hasEnded() = currentFrame > durationInFrames

    @SuppressLint("NewApi")
    private fun viewToImage(view: View): Bitmap {
        view.layout(0, 0, VIDEO_WIDTH_PX.toInt(), VIDEO_HEIGHT_PX.toInt())
        val returnedBitmap = try {
            Bitmap.createBitmap(
                VIDEO_WIDTH_PX.toInt(),
                VIDEO_HEIGHT_PX.toInt(),
                Bitmap.Config.ARGB_8888
            )
        }catch (oome: OutOfMemoryError){
            Bitmap.createBitmap(
                720,
                1080,
                Bitmap.Config.ARGB_8888
            )
        }

        returnedBitmap.setHasAlpha(true)
        val canvas = Canvas(returnedBitmap)
        val bgDrawable = view.background
        if (bgDrawable != null) bgDrawable.draw(canvas) else canvas.drawColor(Color.WHITE)
        view.draw(canvas)

        return returnedBitmap
    }

//    private fun drawBitmap(view: View): Bitmap {
//        view.setDrawingCacheEnabled(true)
//        val bitmap: Bitmap = view.getDrawingCache()
//        val canvas = Canvas(bitmap)
//
//        val bitmapWidth = bitmap.width
//        val bitmapHeight = bitmap.height
//        val videoWidth: Int = VIDEO_WIDTH_PX.toInt()
//        val videoHeight: Int = VIDEO_HEIGHT_PX.toInt()
//        val matrix = getMatrix(bitmapWidth, bitmapHeight, videoWidth, videoHeight)
//        canvas.drawColor(Color.WHITE, PorterDuff.Mode.CLEAR)
//        canvas.drawBitmap(bitmap, matrix!!, null)
//        return bitmap
//    }
//
//
//    private fun getMatrix(bw: Int, bh: Int, vw: Int, vh: Int): Matrix? {
//        val matrix = Matrix()
//        val scale: Float
//        var scaleX = 1f
//        var scaleY = 1f
//        val transX: Float
//        val transY: Float
//        if (bw > vw) {
//            scaleX = vw.toFloat() / bw
//        }
//        if (bh > vh) {
//            scaleY = vh.toFloat() / bh
//        }
//        scale = if (scaleX < scaleY) scaleX else scaleY
//        transX = (vw - bw * scale) / 2
//        transY = (vh - bh * scale) / 2
//        matrix.postScale(scale, scale)
//        matrix.postTranslate(transX, transY)
//        return matrix
//    }


}

//public const val VIDEO_WIDTH_PX = 720f