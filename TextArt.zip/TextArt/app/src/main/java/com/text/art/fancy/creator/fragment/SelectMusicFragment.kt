package com.text.art.fancy.creator.fragment

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.text.art.fancy.creator.BuildConfig
import com.text.art.fancy.creator.lottieaudiorendering.data.SharedMediaStoragePublisher.Companion.isAndroidQ
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.EditAnimationActivity.Companion.lottieDuration
import com.text.art.fancy.creator.adepter.LottieMusicAdapter
import com.text.art.fancy.creator.adepter.LottieMusicAdapter.Companion.selectedAudioPosition
import com.text.art.fancy.creator.adepter.LottieMusicAdapter.Companion.selectedMusicPosition
import com.text.art.fancy.creator.ads.InterstitialAdHelper
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.interfaces.MusicListener
import com.text.art.fancy.creator.model.LottieMusic
import com.text.art.fancy.creator.utils.*
import com.text.art.fancy.creator.viewModel.OfflineMusicViewModel
import com.google.android.gms.ads.InterstitialAd

class SelectMusicFragment : Fragment(), InterstitialAdHelper.onInterstitialAdListener {

    private val TAG = "SelectMusicFragment"
    private lateinit var musicListener: MusicListener
    private lateinit var btnGift: LottieAnimationView
    private lateinit var offlineMusicData : OfflineMusicViewModel
    private lateinit var rvMusic: RecyclerView
    private lateinit var rvFilesMusic: RecyclerView
    private lateinit var btnShare: ImageView
    private lateinit var musicAdapter: LottieMusicAdapter
    private lateinit var audioAdapter: LottieMusicAdapter //From Files
    private lateinit var btnBack: ImageView
    private lateinit var noMusicFound: TextView
    private lateinit var selectFromGallery: ConstraintLayout
    private var lastClickTime = 0L
    private var interstitial: InterstitialAd? = null
//    private var haveAudioPermission = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        return inflater.inflate(R.layout.fragment_select_music, container, false)
    }

    private fun onBackPressed() {
        requireActivity().onBackPressed()
        /*if (rvFilesMusic.visibility == View.VISIBLE){
            rvFilesMusic.post {
                rvFilesMusic.animate()
                    .translationX(rvFilesMusic.width.toFloat())
                    .alpha(1F)
                    .setListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator?) {
                            super.onAnimationEnd(animation)
                            rvFilesMusic.hide()
                        }
                    })
            }
            rvMusic.post {
                rvMusic.show()
                rvMusic.animate()
                    .translationX(0F)
                    .alpha(1F)
                    .setListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator?) {
                            super.onAnimationEnd(animation)
                        }
                    })
                selectFromGallery.show()
                selectFromGallery.animate()
                    .translationX(0F)
                    .alpha(1F)
                    .setListener(null)
            }
        }else{
            requireActivity().onBackPressed()
        }*/
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btnShare = view.findViewById(R.id.btnShareApp)
        rvMusic = view.findViewById(R.id.rvMusic)
        btnBack = view.findViewById(R.id.btnBack)
        noMusicFound = view.findViewById(R.id.noMusicFound)
        btnGift = view.findViewById(R.id.btnGiftAds)
        rvFilesMusic = view.findViewById(R.id.rvFilesMusic)
        selectFromGallery = view.findViewById(R.id.selectFromGallery)

        if (!MySharedPreferences(
                requireContext()
            ).isSubscribe && requireContext().isOnline()) {
            interstitial = InterstitialAdHelper.instance?.load(requireContext(), this)
        }else{
            btnShare.show()
        }

        view.isFocusableInTouchMode = true
        view.requestFocus()
        view.setOnKeyListener(object : View.OnKeyListener {
            override fun onKey(v: View?, keyCode: Int, event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN) {
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
                        onBackPressed()
                        return true
                    }
                }
                return false
            }
        })

        btnBack.click {
            onBackPressed()
        }

        btnShare.click{
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Text Art")
            var shareMessage = "\nGo with TextArt and make beautiful text image.\n\n"
            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n"
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
            startActivity(Intent.createChooser(shareIntent, "choose one"))
        }

        btnGift.click {
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@click
            lastClickTime = SystemClock.elapsedRealtime()

            isAdBtnClick = true
            interstitial?.show()
        }

        if (requireArguments().getString("from") != ""){
            arguments?.getString("from")?.let {
                Log.d(TAG, "onViewCreated: from $it")
                if (it == "Default"){
                    loadOfflineMusicData()
                }else if (it == "File"){
                    loadAllFilesMusic()
                    rvMusic.hide()
                    rvFilesMusic.show()
                }
            }
        }
    }

    @SuppressLint("Recycle")
    private fun loadAllFilesMusic() {
        if (lottieDuration != oldDuration){
            Log.d(TAG, "loadAllFilesMusic: audioList updated")
            audioList.clear()
            val collection = if (isAndroidQ) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE
            )
            requireContext().contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Audio.Media.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val displayNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

                while(cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val displayName = cursor.getString(displayNameColumn)
                    val duration = cursor.getInt(durationColumn)
                    val size = cursor.getFloat(sizeColumn)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    Log.d(TAG, "loadAllFilesMusic: displayName $displayName duration $duration Lottie Duration $lottieDuration")

                    if (displayName.contains(".mp3") && duration != 0 && duration > lottieDuration){
//                    if (displayName.contains(".mp3") && duration in 1050..50000 && duration > lottieDuration){
                        audioList.add(LottieMusic(displayName, contentUri.toString(), duration, size))
                    }
                }
            } ?: arrayListOf<String>()
        }
        oldDuration = lottieDuration

        //TODO Set Offline Background Adapter
        audioAdapter = LottieMusicAdapter(audioList, LottieMusicAdapter.MusicType.FILE) { pos ->
            if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@LottieMusicAdapter
            lastClickTime = SystemClock.elapsedRealtime()
            musicListener.onMusicClick(LottieMusicAdapter.MusicType.FILE, pos, audioList[pos].musicPath.toUri())
            requireActivity().onBackPressed()
        }
        val audioLayoutManager = GridLayoutManager(requireContext(), 1)
        audioLayoutManager.orientation = LinearLayoutManager.VERTICAL
        rvFilesMusic.layoutManager = audioLayoutManager
        rvFilesMusic.adapter = audioAdapter

        if (audioList.size == 0){
            noMusicFound.show()
            rvFilesMusic.hide()
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun loadOfflineMusicData() {
        offlineMusicData = ViewModelProvider(requireActivity())[OfflineMusicViewModel::class.java]
        offlineMusicData.offlineMusicList.observe(requireActivity()){ data ->
            //TODO Set Offline Background Adapter
            musicAdapter = LottieMusicAdapter(data, LottieMusicAdapter.MusicType.OFFLINE) { pos ->
                if (SystemClock.elapsedRealtime() - lastClickTime < 1000) return@LottieMusicAdapter
                lastClickTime = SystemClock.elapsedRealtime()
                offlineMusicData.offlineMusicList.value?.let {
                    selectedAudioPosition = -1
                    musicListener.onMusicClick(LottieMusicAdapter.MusicType.OFFLINE, pos)
                    requireActivity().onBackPressed()
                }
            }
            val musicLayoutManager = GridLayoutManager(requireContext(), 1)
            musicLayoutManager.orientation = LinearLayoutManager.VERTICAL
            rvMusic.layoutManager = musicLayoutManager
            rvMusic.adapter = musicAdapter
            musicAdapter.notifyItemChanged(selectedMusicPosition)
            musicAdapter.notifyDataSetChanged()
        }

        /*selectFromGallery.click {
            checkPermissions()
            if (haveAudioPermission){
                pickAudio()
            }
        }*/
    }

    private fun pickAudio() {
        //TODO Open Google Files Manager
//        with(Intent()){
//            type = "audio/*"
//            action = Intent.ACTION_GET_CONTENT
//            putExtra(Intent.EXTRA_LOCAL_ONLY, true)
//            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
//            audioPicker.launch(Intent.createChooser(this, getString(R.string.pick_media)))
//        }

        //TODO Open Custom File manager
        rvMusic.requestLayout()
        rvMusic.post {
            rvMusic.animate()
                .translationX(rvMusic.width.toFloat() * -1)
                .alpha(1F)
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator?) {
                        super.onAnimationEnd(animation)
                        rvMusic.hide()
                    }
                })
            selectFromGallery.animate()
                .translationX(selectFromGallery.width.toFloat() * -1)
                .alpha(1F)
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator?) {
                        super.onAnimationEnd(animation)
                        selectFromGallery.hide()
                    }
                })
        }
        rvFilesMusic.requestLayout()
        rvFilesMusic.post {
            rvFilesMusic.show()
            rvFilesMusic.animate()
                .translationX(0F)
                .alpha(1F)
                .setListener(null)
        }
    }

    //TODO Pick Audio From File Manager & Set Audio To Muxer
    @SuppressLint("NotifyDataSetChanged")
    private val audioPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.let { it ->
            if (result.resultCode == Activity.RESULT_OK) {
                it.data?.let { uri ->
                    musicListener.onMusicClick(LottieMusicAdapter.MusicType.FILE, -1, uri)
                    requireActivity().onBackPressed()
                }
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        musicListener = activity as MusicListener
    }

    companion object {
        private var audioList = arrayListOf<LottieMusic>()
        private var oldDuration = 0F
        @JvmStatic
        fun newInstance(from: String): SelectMusicFragment {
            val args = Bundle()
            val f = SelectMusicFragment()
            args.putString("from", from)
            f.arguments = args
            return f
        }
        var isAdBtnClick = false
    }

    override fun onLoad() {
        btnShare.hide()
        btnGift.show()
    }

    override fun onFailed() {
        btnGift.hide()
        btnShare.show()
    }

    override fun onClosed() {
        isAdBtnClick = false
        btnGift.hide()
        btnShare.show()
        interstitial = InterstitialAdHelper.instance?.load(requireContext(), this)
    }

    /*private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            haveAudioPermission = true
        } else {
            haveAudioPermission = false
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                3000
            )
        }
    }*/

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        /*when (requestCode) {
            3000 -> {
                haveAudioPermission = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            }
            else ->
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }

        if (haveAudioPermission) {
            pickAudio()
        } else {
            val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), Manifest.permission.RECORD_AUDIO)
            if (!showRationale) {
                showToast("Permission Is Required To Show Waves Of Music.")
            }
        }*/
    }

}