package com.text.art.fancy.creator.adepter

import android.app.Activity
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.AsyncTask
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.text.art.fancy.creator.model.creation.PhotoModelCreation
import com.text.art.fancy.creator.R
import com.google.android.gms.ads.formats.MediaView
import com.google.android.gms.ads.formats.UnifiedNativeAdView

class MyPhotosAdapter(var context: Context, al_my_photos: ArrayList<PhotoModelCreation>, onClickImage: OnClickImage) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var al_my_photos = ArrayList<PhotoModelCreation>()
    var onClickImage: OnClickImage
    private var isLongClicked: Boolean = false
    private var mTask: SelectionTask? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == SHOW_DATE) {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.my_photo_header_row_new, parent, false)
            v.tag = "date"
            ViewHolder(v)
        } else if (viewType == SHOW_ADS) {
            val unifiedNativeLayoutView = LayoutInflater.from(parent.context).inflate(R.layout.ads_row, parent, false)
            UnifiedNativeAdViewHolder(unifiedNativeLayoutView)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.myphotos_adapter, parent, false)
            view.tag = "image"
            ViewHolder(view)
        }
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, i: Int) {
        Log.d(TAG, "onBindViewHolder: Photos" + al_my_photos[i].path + "  " + i)
        Log.d(TAG, context.toString())

        if (al_my_photos[i].isHeader) {
            val holder = viewHolder as ViewHolder
            holder.txtDate!!.text = al_my_photos[i].date

            if (al_my_photos[i].isDelete) {
                //holder.imgAllSelected!!.background = context.resources.getDrawable(R.drawable.ic_select_button)
                holder.imgAllSelected!!.setImageResource(R.drawable.ic_select)
            } else {
                holder.imgAllSelected!!.setImageResource(R.drawable.ic_unselected)
                holder.imgAllSelected!!.setPadding(0, 0, 0, 0)
            }

            if (isLongClicked) {
                holder.imgAllSelected!!.visibility = View.VISIBLE
            } else {
                holder.imgAllSelected!!.visibility = View.GONE
            }

            holder.imgAllSelected!!.setOnClickListener {
                if(al_my_photos[i].isDelete){
                    al_my_photos[i].isDelete = false
                    holder.imgAllSelected!!.setImageResource(R.drawable.ic_unselected)
                    holder.imgAllSelected!!.setPadding(0, 0, 0, 0)
                    updateDataDelete(i, false)
                }else{
                    al_my_photos[i].isDelete = true
                    //holder.imgAllSelected!!.background = context.resources.getDrawable(R.drawable.ic_select_button)
                    holder.imgAllSelected!!.setImageResource(R.drawable.ic_select)
                    //holder.imgAllSelected!!.setPadding(10, 10, 10, 10)
                    updateDataDelete(i, true)
                }

                notifyDataSetChanged()

            }
        } else if (al_my_photos[i].isShowAds) {

        } else {

            val holder = viewHolder as ViewHolder

                //Display Images && Video Thumb
                holder.myphotos_video!!.visibility = View.GONE
                holder.myphotos_image!!.visibility = View.VISIBLE
                Glide.with(context)
                    .load(al_my_photos[i].path)
                    .override(400, 400)
                    .centerCrop()
                    .listener(object : RequestListener<Drawable?> {
                        override fun onLoadFailed(e: GlideException?, model: Any, target: Target<Drawable?>, isFirstResource: Boolean): Boolean {
                            holder.progressImage!!.visibility = View.GONE
                            return false
                        }

                        override fun onResourceReady(resource: Drawable?, model: Any, target: Target<Drawable?>, dataSource: DataSource, isFirstResource: Boolean): Boolean {
                            holder.progressImage!!.visibility = View.GONE
                            return false
                        }
                    })
                    .into(holder.myphotos_image!!)

            Log.d("TAG", "Long Click $isLongClicked")
            if (isLongClicked) {
                holder.mImgSelection!!.setImageResource(R.drawable.ic_unselected)
                holder.mImgSelection!!.setPadding(0, 0, 0, 0)
                holder.mClicked = false
                holder.mImgSelection!!.visibility = View.VISIBLE
            } else {
                holder.mImgSelection!!.visibility = View.GONE
            }

            //Show checkbox
            if (al_my_photos[i].isDelete) {
                //holder.mImgSelection!!.background = context.resources.getDrawable(R.drawable.ic_select_button)
                holder.mImgSelection!!.setImageResource(R.drawable.ic_select)
                //holder.mImgSelection!!.setPadding(10, 10, 10, 10)
            } else {
                holder.mImgSelection!!.setImageResource(R.drawable.ic_unselected)
                holder.mImgSelection!!.setPadding(0, 0, 0, 0)
            }



            holder.itemView.setOnClickListener {
                if(isLongClicked){
                    if(!al_my_photos[i].isDelete) {
                        al_my_photos[i].isDelete = true
                        //holder.mImgSelection!!.background = context.resources.getDrawable(R.drawable.ic_select_button)
                        holder.mImgSelection!!.setImageResource(R.drawable.ic_select)
                        //holder.mImgSelection!!.setPadding(10, 10, 10, 10)
                        holder.mClicked = true
                        notifyDataSetChanged()
                    }else{
                        al_my_photos[i].isDelete = false
                        holder.mImgSelection!!.setImageResource(R.drawable.ic_unselected)
                        holder.mImgSelection!!.setPadding(0, 0, 0, 0)
                        holder.mClicked = false
                        notifyDataSetChanged()
                    }
                    select(i)
                }else{
                    holder.mImgSelection!!.visibility = View.GONE
                    onClickImage.onClick(i)
                }
            }

            holder.mImgSelection!!.setOnClickListener {
                if(!al_my_photos[i].isDelete){
                    //holder.itemView.chkDelete.isChecked = true
                    al_my_photos[i].isDelete = true
                    //holder.mImgSelection!!.background = context.resources.getDrawable(R.drawable.ic_select_button)
                    holder.mImgSelection!!.setImageResource(R.drawable.ic_select)
                    //holder.mImgSelection!!.setPadding(10, 10, 10, 10)
                    holder.mClicked = true
                    notifyDataSetChanged()
                }else{
                    //holder.itemView.chkDelete.isChecked = false
                    al_my_photos[i].isDelete = false
                    holder.mImgSelection!!.setImageResource(R.drawable.ic_unselected)
                    holder.mImgSelection!!.setPadding(0, 0, 0, 0)
                    holder.mClicked = false
                    notifyDataSetChanged()
                }
                select(i)
            }

            holder.itemView.setOnLongClickListener {
                if (!isLongClicked) {
                    isLongClicked = true
                    onClickImage.onLongClick()
                    makeAllVisible(true)

                    al_my_photos[i].isDelete = true
                    holder.mImgSelection!!.setImageResource(R.drawable.ic_select)
                    holder.mClicked = true

                    select(i)
                } else {
                }
                return@setOnLongClickListener false
            }

        }

    }

    private fun updateDataDelete(i: Int, isChecked: Boolean) {
        for (j in al_my_photos.indices) {
            Log.d("78945613123", "updateDataDelete: " + j + " " + al_my_photos[j].date)
            if (al_my_photos[i].date.equals(al_my_photos[j].date)) {
                if (isChecked) {
                    al_my_photos[j].isDelete = true
                } else {
                    al_my_photos[j].isDelete = false
                }
            }
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var myphotos_image: ImageView? = null
        var myphotos_video: VideoView? = null
        var imgAllSelected: ImageView? = null
        var txtDate: TextView? = null
        var frameLayout: FrameLayout? = null
        var progressImage: ProgressBar? = null
        var mImgSelection: ImageView? = null
        var mClicked: Boolean = false

        init {
            myphotos_image = itemView.findViewById(R.id.myphotos_image)
            myphotos_video = itemView.findViewById(R.id.myphotos_video)
            imgAllSelected = itemView.findViewById(R.id.imgAllSelected)
            txtDate = itemView.findViewById(R.id.txtDate)
            frameLayout = itemView.findViewById(R.id.fl_adplaceholder)
            progressImage = itemView.findViewById(R.id.progressImage)
            mImgSelection = itemView.findViewById(R.id.img_pic_selected)
        }
    }

    override fun getItemViewType(position: Int): Int {
        //TODO: Wood (Remove When Issue Solved)
        return try {
            if (al_my_photos[position].isHeader && al_my_photos[position].date != "") {
                SHOW_DATE
            } else if (al_my_photos[position].isShowAds && al_my_photos[position].date == "" && al_my_photos[position].unifiedNativeAd != null) {
                SHOW_ADS
            } else {
                SHOW_IMAGE
            }
        }catch (e: Exception){
            SHOW_IMAGE
        }
    }

    override fun getItemCount(): Int {
        return al_my_photos.size
    }

    interface OnClickImage {
        fun onClick(i: Int)
        fun onLongClick()
    }

    inner class UnifiedNativeAdViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val adView: UnifiedNativeAdView

        init {
            adView = view.findViewById<View>(R.id.ad_view) as UnifiedNativeAdView

            // The MediaView will display a video asset if one is present in the ad, and the
            // first image asset otherwise.
            adView.mediaView = adView.findViewById<View>(R.id.ad_media) as MediaView

            // Register the view used for each individual asset.
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.bodyView = adView.findViewById(R.id.ad_body)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_icon)
            adView.priceView = adView.findViewById(R.id.ad_price)
            adView.starRatingView = adView.findViewById(R.id.ad_stars)
            adView.storeView = adView.findViewById(R.id.ad_store)
            adView.advertiserView = adView.findViewById(R.id.ad_advertiser)
        }
    }

    companion object {
        private const val TAG = "MyPhotosAdapter"
        const val SHOW_DATE = 1
        const val SHOW_IMAGE = 2
        const val SHOW_ADS = 3
    }

    init {
        this.al_my_photos = al_my_photos
        this.onClickImage = onClickImage
    }

    fun notifyAdapter() {
        notifyDataSetChanged()
    }

    fun getisLongCliked(): Boolean {
        return isLongClicked
    }

    fun makeAllVisible(isVisible:Boolean){
        if(!al_my_photos.isNullOrEmpty()) {
            for (i in al_my_photos.indices) {
                al_my_photos[i].isVisible = isVisible
                if (!isVisible) {
                    al_my_photos[i].isDelete = isVisible
                }
            }
            notifyDataSetChanged()
            if (!isVisible) {
                isLongClicked = false
            }
        }
    }

    fun getTrueDeleteImageList():ArrayList<PhotoModelCreation>{
        var mDeleteImageList:ArrayList<PhotoModelCreation> = ArrayList()
        for(i in al_my_photos.indices){
            if(al_my_photos[i].isDelete){
                mDeleteImageList.add(al_my_photos[i])
            }
        }
        return mDeleteImageList
    }

    fun getTrueDeleteVideoList():ArrayList<PhotoModelCreation>{
        var mDeleteImageList:ArrayList<PhotoModelCreation> = ArrayList()
        for(i in al_my_photos.indices){
            if(al_my_photos[i].isDelete){
                mDeleteImageList.add(al_my_photos[i])
            }
        }
        return mDeleteImageList
    }

    fun refreshAdapter(position: Int){
        al_my_photos.removeAt(position)
        notifyItemRemoved(position)
        notifyItemChanged(position)
        notifyDataSetChanged()
    }

    fun select(position: Int) {
        if (mTask != null) {
            mTask!!.cancel(true)
        }
        mTask = SelectionTask(position)
        mTask!!.execute()
    }

    fun getDeleteImageList():ArrayList<PhotoModelCreation>{
        var mDeleteImageList:ArrayList<PhotoModelCreation> = ArrayList()
        for(i in al_my_photos.indices){
            if (al_my_photos[i].isImage!!){
                mDeleteImageList.add(al_my_photos[i])
            }
        }
        return mDeleteImageList
    }

    fun getDeleteVideoList(): ArrayList<PhotoModelCreation> {
        var mDeleteVideoList:ArrayList<PhotoModelCreation> = ArrayList()
        for(i in al_my_photos.indices){
            if (!al_my_photos[i].isImage!!){
                mDeleteVideoList.add(al_my_photos[i])
            }
        }
        return mDeleteVideoList
    }

    inner class SelectionTask(private val position: Int) : AsyncTask<Void?, Void?, Void?>() {
        private var index = 0
        override fun doInBackground(vararg voids: Void?): Void? {
            val list: java.util.ArrayList<PhotoModelCreation> = java.util.ArrayList<PhotoModelCreation>()
            for (imageModel in al_my_photos) {
                if (imageModel.date!!.contentEquals(al_my_photos[position].date!!)) {
                    list.add(imageModel)
                }
            }
            var isCheck = true
            for (model in list) {
                if (!model.isDelete && !model.isHeader) {
                    isCheck = false
                    break
                }
            }
            if (list.size > 0 && isCheck) {
                index = al_my_photos.indexOf(list[0])
                if (al_my_photos[index].isHeader) {
                    al_my_photos[al_my_photos.indexOf(list[0])].isDelete=true
                    (context as Activity).runOnUiThread { notifyItemChanged(index) }
                }
            } else {
                index = al_my_photos.indexOf(list[0])
                if (al_my_photos[index].isHeader) {
                    al_my_photos[al_my_photos.indexOf(list[0])].isDelete=false
                    (context as Activity).runOnUiThread { notifyItemChanged(index) }
                }
            }
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
        }
    }

    interface OnLongDeleteShow {
        fun OnDeleteShow(isPressed: Boolean)
    }
}