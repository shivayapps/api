package com.text.art.fancy.creator.model

import android.graphics.Typeface
import android.view.View

data class UndoRedo(var action: String, var position: Int, var operation: Operation) {
    class Operation {
        lateinit var stickerView: View
        var newText: String = ""
        var typeface: Typeface? = null
        var fontPosition: Int = -1
        var singleColor: Int = -1
//        var mGlowColor: Int = 0
        var mGlowColor: Int = -1
        var mGlowProgress: Int = 0
        var mPatternFromGallery = false
        var mPattern: Int = -1
        var mPatternString: String = ""
        var mCurve: Int = 0
        var bgImage: String = ""
        var bgImageOffline: Int = 0
        var bgColor: Int = 0
        var frameImage: String = ""
        var frameImageOffline: Int = 0
        var m3Dx: Int = 0
        var m3Dy: Int = 0
        var oldX: Float = 0F
        var oldY: Float = 0F
        var width = 0
        var height = 0
        var mWidth: Int = 0
        var mRotation: Float = 0F
        var mGradientColor: Int = -1
        var mMultiColor: Int = -1
        var mShadowSpace: Int = 0
        var mShadowOpacity: Int = 0
        var isBold = false
        var isItalic = false
        var isUnderLine = false
        var fontType = "Default"
    }
}
