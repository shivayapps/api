package com.text.art.fancy.creator.widgets.trimMusic

object MusicUitlis {

    private var mSampleRate = 0
    private var mSamplesPerFrame = 0

    fun setSoundFile(soundFile: SoundFile) {
        mSampleRate = soundFile.sampleRate
        mSamplesPerFrame = soundFile.samplesPerFrame
    }

    fun secondsToFrames(seconds: Double): Int {
        return (1.0 * seconds * mSampleRate / mSamplesPerFrame + 0.5).toInt()
    }

}