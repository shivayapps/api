package com.text.art.fancy.creator.fragment

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.*
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.text.art.fancy.creator.model.creation.PhotoModelCreation
import com.text.art.fancy.creator.model.ImageModel
import com.text.art.fancy.creator.R
import com.text.art.fancy.creator.activitys.FullMyPhotoActivity
import com.text.art.fancy.creator.activitys.HomeActivity
import com.text.art.fancy.creator.adepter.MyPhotosAdapter
import com.text.art.fancy.creator.comman.Constants
import com.text.art.fancy.creator.data.MySharedPreferences
import com.text.art.fancy.creator.interfaces.OnLongClickPressedMyCreation
import com.text.art.fancy.creator.utils.showToast
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.collections.ArrayList
import kotlin.properties.Delegates

@SuppressLint("NotifyDataSetChanged")
class MyImagesFragment : Fragment() {
    private var TAG: String = "MyImagesFragment"

    private var mRecyclerMyPhotos: RecyclerView?=null
    private var progressBar1: ProgressBar?=null

    private var clickedItem = 0
    private var NUMBER_OF_DATES = 0
    private var dateCount = 0
    private var mIsSubScribe by Delegates.notNull<Boolean>()
    private var isFirstTime = true

    private var mOnLongClickPressedMyCreation: OnLongClickPressedMyCreation?=null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view1:View = inflater.inflate(R.layout.fragment_my_images, container, false)
        mOnLongClickPressedMyCreation = context as OnLongClickPressedMyCreation
        mIsSubScribe = MySharedPreferences(
            requireContext()
        ).isSubscribe
        initView(view1)

        /*//1. OLD
        LoadMyPhotoTask().execute()*/
//        setImageToRecyclerView()
        return view1
    }

    private fun setImageToRecyclerView() {
        val executor = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())
        executor.execute {
            getPhotos()
            handler.post {
                if (myPhotosAdapter != null) {
                    myPhotosAdapter!!.notifyDataSetChanged()
                }
                if (mPhotoList.size == 0) {
                    progressBar1!!.visibility = View.GONE
                    mRecyclerMyPhotos!!.visibility = View.GONE
                    mConstraintImagesNotFound!!.visibility = View.VISIBLE
                } else {
                    activity?.let {
                        setDataToAdapter()
                        Handler(Looper.getMainLooper()).postDelayed({
                            progressBar1!!.visibility = View.GONE
                            mRecyclerMyPhotos!!.visibility = View.VISIBLE
                            mConstraintImagesNotFound!!.visibility = View.GONE
                        }, 1000)
                    }
                }
            }
        }
    }

    private fun initView(view:View){
        mRecyclerMyPhotos = view.findViewById(R.id.recyclerMyPhotos)
        progressBar1 = view.findViewById(R.id.progressBar1)
        mConstraintImagesNotFound = view.findViewById(R.id.constraintImagesNotFound)
    }

    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(context, HomeActivity::class.java))
            requireActivity().finish()
        }

        Log.d(TAG, "onResume: MyImageFragment $isFirstTime isSaveUpdate ${Constants.isSaveUpdate}")
        if (isFirstTime){
            isFirstTime = false
            setImageToRecyclerView()
        }else if (Constants.isSaveUpdate){
            Constants.isSaveUpdate = false
            setImageToRecyclerView()
        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun getPhotos() {
        NUMBER_OF_DATES = 0
        dateCount = 0
        clickedItem = 0
        mPhotoList.clear()
        val file = File(
            Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_PICTURES + "/" + "TextArt"
        ).toString())
        var pos = 1
        if (file.isDirectory) {
            val files = file.listFiles { pathname ->
                pathname.path.endsWith(".jpg") || pathname.path.endsWith(".jpeg") || pathname.path.endsWith(".png")
            }
            var temp: File
            if (files != null && files.size != 0) {
                for (i in files.indices) {
                    for (j in i + 1 until files.size) {
                        if (files[i].lastModified() < files[j].lastModified()) {
                            temp = files[i]
                            files[i] = files[j]
                            files[j] = temp
                        }
                    }
                }
                val lastModDate = Date(files[0].lastModified())
                val dateFormat = SimpleDateFormat("dd MMM yyyy")
                NUMBER_OF_DATES += 1
                Log.d(TAG, "getPhotos: data lastModified Date $lastModDate")
                mPhotoList.add(0,
                    PhotoModelCreation("",
                        dateFormat.format(lastModDate),
                        NUMBER_OF_DATES,
                        true,
                        false,
                        null,
                        false,
                        true))
                mPhotoList.add(pos,
                    PhotoModelCreation(files[0].absolutePath,
                        dateFormat.format(lastModDate),
                        NUMBER_OF_DATES,
                        false,
                        false,
                        null,
                        false,
                        true))
                for (i in 0 until files.size - 1) {
                    pos++
                    val nextDate = Date(files[i + 1].lastModified())
                    var current = Date(files[i].lastModified())
                    Log.d("8792343212123",
                        "getPhotos: " + dateFormat.format(current) + "  " + files[i].absolutePath)
                    if (dateFormat.format(current) != dateFormat.format(nextDate)) {
                        current = nextDate
                        NUMBER_OF_DATES += 1
                        mPhotoList.add(pos,
                            PhotoModelCreation("",
                                dateFormat.format(nextDate),
                                NUMBER_OF_DATES,
                                true,
                                false,
                                null,
                                false,
                                true))
                        pos++
                    }
                    mPhotoList.add(pos,
                        PhotoModelCreation(files[i + 1]!!.absolutePath,
                            dateFormat.format(current),
                            NUMBER_OF_DATES,
                            false,
                            false,
                            null,
                            false,
                            true))
                    Log.d("mycreationsda", "getPhotos: Images " + files[i + 1]!!.absolutePath)
                }
            }
        }
    }

    private fun setDataToAdapter() {
        try {
            myPhotosAdapter = MyPhotosAdapter(requireActivity(), mPhotoList!!,
                object : MyPhotosAdapter.OnClickImage {
                override fun onClick(i: Int) {
                    Log.d(TAG, "onClick: $i")
                    val path: String = mPhotoList[i].path!!
                    context?.let {
                        startActivity(Intent(it, FullMyPhotoActivity::class.java).apply {
                            putExtra("type", "view")
                            putExtra("image", path)
                            putExtra("from", "image")
                        })
                    }
                }

                override fun onLongClick() {
                    openMenu()
                }
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val layoutManager = GridLayoutManager(activity, 3)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(i: Int): Int {
                return when (myPhotosAdapter!!.getItemViewType(i)) {
                    MyPhotosAdapter.SHOW_DATE -> 3
                    MyPhotosAdapter.SHOW_ADS -> 3
                    MyPhotosAdapter.SHOW_IMAGE -> 1
                    else -> 1
                }
            }
        }
        //    myphotos.addItemDecoration(new GridSpacingItemDecoration(3,10,true));
        mRecyclerMyPhotos!!.layoutManager = layoutManager
        mRecyclerMyPhotos!!.adapter = myPhotosAdapter
    }

    private fun openMenu() {
        mOnLongClickPressedMyCreation!!.isLongClickPressed(true)
    }

    fun delete(): Boolean {
        (mPhotoList.filter {
            if (it.isVisible)
                !File(it.path).delete()
            else
                true
        } as ArrayList<ImageModel>).apply {
            mPhotoList.clear()
//                mPhotoList!!.addAll(this@apply)
        }

        PhotoFragment.isShowCheckBox = false
        if (mPhotoList.isEmpty())
            return true

        myPhotosAdapter?.notifyDataSetChanged()
        return false
    }

    companion object{
        @SuppressLint("StaticFieldLeak")
        var myPhotosAdapter: MyPhotosAdapter? = null
        var mConstraintImagesNotFound: ConstraintLayout?=null
        val mPhotoList: ArrayList<PhotoModelCreation> = ArrayList()
    }
}