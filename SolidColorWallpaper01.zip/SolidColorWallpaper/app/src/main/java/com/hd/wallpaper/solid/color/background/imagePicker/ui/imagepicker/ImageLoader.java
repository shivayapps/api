package com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.hd.wallpaper.solid.color.background.R;
import com.hd.wallpaper.solid.color.background.imagePicker.model.Image;


public class ImageLoader {

    private RequestOptions options;

    public ImageLoader() {
        options = new RequestOptions()
                .placeholder(R.drawable.imagepicker_image_placeholder)
                .error(R.drawable.imagepicker_image_placeholder)
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE);
    }

    public void loadImage(final Image path, final ImageView imageView, final Bitmap bitmap) {
        Glide.with(imageView.getContext())
                .load(path.getPath())
                .apply(options)
                .addListener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        Log.d("877894564564563", "onLoadFailed: ");
//                        imageView.setImageBitmap(bitmap);
                        Glide.with(imageView.getContext()).load(bitmap).into(imageView);
                        imageView.setPadding(50,50,50,50);
                        path.setCorrupted(true);
                        return true;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        Log.d("877894564564563", "onResourceReady: ");
                        imageView.setPadding(0,0,0,0);
                        path.setCorrupted(false);
                        return false;
                    }
                })
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView);
    }
}
