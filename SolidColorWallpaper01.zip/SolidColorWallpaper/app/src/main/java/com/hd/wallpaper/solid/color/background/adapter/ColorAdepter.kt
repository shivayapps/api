package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.model.SolidColorModel
import java.util.*

class ColorAdepter(private val mColors: ArrayList<SolidColorModel>, private val mContext: Context, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<ColorAdepter.MyViewHolder>() {
    private val LastSelectedView: MyViewHolder? = null
    private val LastSelectedItem = 0

    interface setOnItemClickListener {
        fun OnItemClicked(model: SolidColorModel?, i: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.row_color, null))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        val shape = GradientDrawable()
        shape.shape = GradientDrawable.RECTANGLE
        shape.setColor(mColors[i].color)
        myViewHolder.colorImage.background = shape
        if (mColors[i].imagePosition != -1) {
            Glide.with(mContext).asBitmap().load(Constants.mEmojiList[mColors[i].imagePosition]).into(object : CustomTarget<Bitmap?>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                    myViewHolder.imgEmoji.setImageBitmap(resource)
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
        } else {
            myViewHolder.imgEmoji.setImageBitmap(null)
        }
        myViewHolder.imgColor.setOnClickListener { mListener.OnItemClicked(mColors[i], i) }
    }

    override fun getItemCount(): Int {
        return mColors.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgColor: CardView = itemView.findViewById(R.id.imgColor)
        val imgEmoji: ImageView = itemView.findViewById(R.id.imgEmoji)
        val colorImage: ImageView = itemView.findViewById(R.id.colorImage)

    }

}