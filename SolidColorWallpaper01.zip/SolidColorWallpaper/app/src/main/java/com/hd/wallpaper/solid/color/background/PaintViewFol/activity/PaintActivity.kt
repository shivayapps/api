package com.hd.wallpaper.solid.color.background.PaintViewFol.activity

//import com.hd.wallpaper.solid.color.background.PaintView.imagePicker.ui.imagepicker.ImagePicker
//import com.hd.wallpaper.solid.color.background.PaintView.imagePicker.ui.imagepicker.ImagePicker
import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.*
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.paint_solidcolor.R

import com.jaredrummler.android.colorpicker.ColorPickerDialog
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener

import com.hd.wallpaper.solid.color.background.PaintViewFol.constant.Constants
import com.hd.wallpaper.solid.color.background.PaintViewFol.customs.BottomSheetFragmentDiscard
import com.hd.wallpaper.solid.color.background.PaintViewFol.drawing.Brush
import com.hd.wallpaper.solid.color.background.PaintViewFol.drawing.Brushes.get
import com.hd.wallpaper.solid.color.background.PaintViewFol.drawing.PaintView
import com.hd.wallpaper.solid.color.background.PaintViewFol.fragments.AddTextFragment
import com.hd.wallpaper.solid.color.background.PaintViewFol.fragments.AddTextFragment.Companion.newInstance

import com.hd.wallpaper.solid.color.background.PaintViewFol.showToast
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.activity.GifLiveWallPaper.Companion.TAG
import com.hd.wallpaper.solid.color.background.activity.MainStartActivity
import com.hd.wallpaper.solid.color.background.activity.ViewPaintActivity
import com.hd.wallpaper.solid.color.background.constants.Constants.mBitmapPath
import com.hd.wallpaper.solid.color.background.constants.Constants.mBitmapPathUndo
import com.hd.wallpaper.solid.color.background.constants.Constants.mGalleryBitmap
import com.hd.wallpaper.solid.color.background.constants.Constants.mGalleryUri
import com.hd.wallpaper.solid.color.background.imagePicker.ui.imagepicker.ImagePicker
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.willy.ratingbar.ScaleRatingBar
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_add_color_menu.*
import kotlinx.android.synthetic.main.content_text_brush_menu.*
import java.util.*


class PaintActivity : AppCompatActivity(), View.OnClickListener, ColorPickerDialogListener {

    private var mMainActivity: PaintActivity? = null

    //Widgets and Layouts
    var time = 0L
    private var imgColor: CardView? = null
    private var mainFrame: FrameLayout? = null
//    var mConstraintMenuAddColor: ConstraintLayout? = null
    var mConstraintMenuBrush: LinearLayout? = null
    var mConstraintMenuEraser: LinearLayout? = null
    var mConstraintMenuTextBrush: LinearLayout? = null
    var mConstraintBottomSubMenu: ConstraintLayout? = null
//    var mImgMenuAddColor: ImageView? = null
    private var mySharedPref: MySharedPref? = null
    var mImgMenuBrush: ImageView? = null
    var mImgMenuEraser: ImageView? = null
    var mImgMenuTextBrush: ImageView? = null
    var selectGradientColor:ImageView?=null
    var imgGallerys:ImageView?=null
    var txtGradientColor:TextView?=null
    var txtGallery:TextView?=null
//    private var mTxtMenuAddColor: TextView? = null
    private var mTxtMenuBrush: TextView? = null
    private var mTxtMenuEraser: TextView? = null
    private var mTxtMenuTextBrush: TextView? = null
    private var mMenuBrush: ConstraintLayout? = null
    private var mMenuAddColor: ConstraintLayout? = null
    private var mMenuEraser: ConstraintLayout? = null
    private var mMenuTextBrush: ConstraintLayout? = null
    private var mLinearUndoRedo: LinearLayout? = null
    private var mainBottomlayoutSelect: LinearLayout? = null
    private var btnNon: LinearLayout? = null
    private var mLblHeaderTextBrush: TextView? = null
    private var mImgBack: ImageView? = null
    private var mImgDone: ImageView? = null
    private var imgForGallery: LinearLayout? = null

    private var mSeekBrushSize: SeekBar? = null
    private var mSeekBrushOpacity: SeekBar? = null
    private var mImgSubBrushSelect: ImageView? = null
    private var mImgSubBrushColor: ImageView? = null

    private var mPaintView: PaintView? = null
    var brush: Brush? = null

    var bottomSheetFragment:BottomSheetFragmentDiscard?=null

    //Add color
    private var mBtnAddColor1: ImageView? = null
    private var mBtnAddColor2: ImageView? = null
    private var mImageRotateColor: LinearLayout? = null
    private var mImageCenterColor: LinearLayout? = null
    private var imageCenter: ImageView? = null
    private var imageRotate: ImageView? = null
    private var mImgGradient: ImageView? = null
//    private var cradientCancel: LinearLayout? = null

    private val orientations =
            arrayOf(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    GradientDrawable.Orientation.TR_BL,
                    GradientDrawable.Orientation.RIGHT_LEFT,
                    GradientDrawable.Orientation.BR_TL,
                    GradientDrawable.Orientation.BOTTOM_TOP,
                    GradientDrawable.Orientation.BL_TR,
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    GradientDrawable.Orientation.TL_BR
            )
    private var orientation = GradientDrawable.Orientation.TOP_BOTTOM
    private val colors = IntArray(2)
    private var mCurrentOrientation = 0

    private var isColor1 = false
    private var isColor2 = false
    private var isColorBrush = false
    private var isColorTextBrush = false
    private var isColorSelected = false
    private var isImageSelected = false
    private var isColor2Selected = false
    private var isCenter = false
    private var isCircle = false
    private var selectedColor = Color.parseColor("#EBEBEB")
    private var selectedColor2 = Color.parseColor("#EBEBEB") //-8241345;

    //Eraser
    private var mSeekEraserBrushSize: SeekBar? = null
    private var mSeekEraserBrushOpacity: SeekBar? = null

    //Text brush
    private var frmTextFragment: FrameLayout? = null
    private var mImgSubTextBrushSelect: ImageView? = null
    private var mImgSubTextBrushColor: ImageView? = null
    private var mSeekTextBrushSize: SeekBar? = null
    private var mSeekTextBrushOpacity: SeekBar? = null
    private var anim: ObjectAnimator? = null

    private var addTextFragment: AddTextFragment? = null

    private var isFragmentLoaded = false
    private var currentTextBrushColor = Color.parseColor("#000000")
    private var btnColorLayout: LinearLayout? = null

    //Others
    private var mCurrentBrushId = 0 //default brush
    private var mDrawingColor = -0xbb7734 //default color
    private var mCurrentBrushSize = 0
    private var isUserTextBrushFirstTime = true
    private var imgGallery: ImageView? = null
    var mCheckNet: Boolean = false
    var mLastClickTime=0L
    companion object {
        init {
            System.loadLibrary("native-lib")
        }

        private const val REQUEST_BRUSH_SELECT = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mMainActivity = this@PaintActivity
        addTextFragment = AddTextFragment()

        mDrawingColor = Color.BLACK
        mBitmapPath.clear()
        mBitmapPathUndo.clear()

        initView()

        mySharedPref = MySharedPref(this)

        initViewAction()

        initViewListener()

        initPaintView()

//        changeColorOfMenuBrush()
//        imgForGallery!!.isEnabled = true
//        btnColorLayout!!.isEnabled = true

        mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
        mImgMenuEraser!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuTextBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        selectGradientColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))
        imgGallerys!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))

        txtGradientColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        txtGallery!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
        mTxtMenuEraser!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuTextBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))

        findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
        findViewById<LinearLayout>(R.id.llMainButton).visibility = View.INVISIBLE
        mMenuAddColor!!.visibility = View.INVISIBLE
        mMenuBrush!!.visibility=View.VISIBLE
        mMenuEraser!!.visibility=View.INVISIBLE
        mMenuTextBrush!!.visibility=View.INVISIBLE

//        setNormalColor()



        //open by default ads
        onClick(mainBottomlayoutSelect as View)

        findViewById<LinearLayout>(R.id.llMainButton).visibility = View.GONE

        if (!AdsPrefs.getBoolean(this@PaintActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            if (isNetworkConnected()) {
//                loadInterstialAd()
                isShowInterstitialAd{

                }
            }

//            showInterstitial()
        }
    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo()!!.isConnected()
    }


    private fun initView() {
        imgColor = findViewById(R.id.imgColor)
        mainFrame = findViewById(R.id.mainFrame)
        mPaintView = findViewById(R.id.paint_view)
        btnNon = findViewById(R.id.btnNon)
//        mConstraintMenuAddColor = findViewById(R.id.constraintMenuAddColor)
        mConstraintMenuBrush = findViewById(R.id.constraintMenuBrush)
        mConstraintMenuEraser = findViewById(R.id.constraintMenuEraser)
        mainBottomlayoutSelect = findViewById(R.id.mainBottomlayoutSelect)
        mConstraintMenuTextBrush = findViewById(R.id.constraintMenuTextBrush)
        mConstraintBottomSubMenu = findViewById(R.id.constraintBottomSubMenu)
//        mImgMenuAddColor = findViewById(R.id.imgMenuAddColor)
        selectGradientColor=findViewById(R.id.selectGradientColor)
        imgGallerys=findViewById(R.id.imgGallerys)
        mImgMenuBrush = findViewById(R.id.imgMenuBrush)
        mImgMenuEraser = findViewById(R.id.imgMenuEraser)
        mImgMenuTextBrush = findViewById(R.id.imgMenuTextBrush)
        txtGradientColor=findViewById(R.id.txtGradientColor)
        txtGallery=findViewById(R.id.txtGallery)
//        mTxtMenuAddColor = findViewById(R.id.txtMenuAddColor)
        imgGallery = findViewById(R.id.imgGallery)
        mTxtMenuBrush = findViewById(R.id.txtMenuBrush)
        mTxtMenuEraser = findViewById(R.id.txtMenuEraser)
        mTxtMenuTextBrush = findViewById(R.id.txtMenuTextBrush)
        mMenuBrush = findViewById(R.id.menuBrush)
        mMenuAddColor = findViewById(R.id.menuAddColor)
        mMenuEraser = findViewById(R.id.menuEraser)
        mMenuTextBrush = findViewById(R.id.menuTextBrush)
        mLinearUndoRedo = findViewById(R.id.linearUndoRedo)
        mLblHeaderTextBrush = findViewById(R.id.lblHeaderTextBrush)
        btnColorLayout = findViewById(R.id.btnColorLayout)

        mImgBack = findViewById(R.id.imgBack)
        mImgDone = findViewById(R.id.imgDone)
        mImgDone!!.isEnabled = false

        mSeekBrushSize = findViewById(R.id.seekBrushSize)
        mSeekBrushOpacity = findViewById(R.id.seekBrushOpacity)
        mImgSubBrushSelect = findViewById(R.id.imgSubBrushSelect)
        mImgSubBrushColor = findViewById(R.id.imgSubBrushColor)

        mSeekEraserBrushSize = findViewById(R.id.seekEraserBrushSize)
        mSeekEraserBrushOpacity = findViewById(R.id.seekEraserBrushOpacity)

        mBtnAddColor1 = findViewById(R.id.btnAddColor1)
        mBtnAddColor2 = findViewById(R.id.btnAddColor2)
        imgForGallery = findViewById(R.id.imgForGallery)
        mImageRotateColor = findViewById(R.id.btnRotateColor)
        mImageCenterColor = findViewById(R.id.btnCenterColor)
        imageCenter = findViewById(R.id.imageGradient)
        imageRotate = findViewById(R.id.imageRotate)
        mImgGradient = findViewById(R.id.imgGradient)
//        cradientCancel = findViewById(R.id.cradientCancel)

        frmTextFragment = findViewById(R.id.frmTextFragment)
        mImgSubTextBrushSelect = findViewById(R.id.imgSubTextBrushSelect)
        mImgSubTextBrushColor = findViewById(R.id.imgSubTextBrushColor)
        mSeekTextBrushSize = findViewById(R.id.seekTextBrushSize)
        mSeekTextBrushOpacity = findViewById(R.id.seekTextBrushOpacity)
    }

    private fun initViewAction() {

        val imgUndo: ImageView = findViewById(R.id.imgUndo)
        val imgRedo: ImageView = findViewById(R.id.imgRedo)

        imgUndo.setOnClickListener {
                checkUndoRedoDisable()
                mPaintView!!.undo()
                checkSomethingIsAddedOnCanvas()
        }

        imgRedo.setOnClickListener {

                checkUndoRedoDisable()
                mPaintView!!.redo()
                checkSomethingIsAddedOnCanvas()

        }
    }

    private fun initViewListener() {
//        mConstraintMenuAddColor!!.setOnClickListener(this)
        btnNon!!.setOnClickListener(this)
        mConstraintMenuBrush!!.setOnClickListener(this)
        mConstraintMenuEraser!!.setOnClickListener(this)
//        cradientCancel!!.setOnClickListener(this)
        imgForGallery!!.setOnClickListener(this)
        imgGallery!!.setOnClickListener(this)
        mConstraintMenuTextBrush!!.setOnClickListener(this)
        mBtnAddColor1!!.setOnClickListener(this)
        mBtnAddColor2!!.setOnClickListener(this)
        mImageRotateColor!!.setOnClickListener(this)
        mImageCenterColor!!.setOnClickListener(this)
        mImgDone!!.setOnClickListener(this)
        mImgBack!!.setOnClickListener(this)
        btnColorLayout!!.setOnClickListener(this)

    }

    fun save(context: Context) {
        getPrefs(context).edit().putBoolean("is_first_time", false).apply()
    }

    fun getBoolean(context: Context): Boolean {
        return getPrefs(context).getBoolean("is_first_time", true)
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences("app_center", Context.MODE_PRIVATE)
    }

    //Brush
    private fun initPaintView() {
        brush = get(mMainActivity)!![mCurrentBrushId]!!
        //mFirstBrushButton!!.setImageResource(brush!!.iconId)
        mPaintView!!.isDrawingCacheEnabled = true
        mPaintView!!.brush = brush
        setColor(brush!!.defaultColor)
        mPaintView!!.setDrawingBgColor(Color.WHITE)
        mPaintView!!.setLottieView(lottie_hand)
        mSeekBrushSize!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                setScaledSize(seekBar.progress / 100f)
            }
        })

        mSeekBrushOpacity!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    setOpacity(progress / 100f)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        setScaledSize(mPaintView!!.drawingScaledSize)
        setOpacity(0.5f)

        mImgSubBrushColor!!.setOnClickListener {

            if (System.currentTimeMillis() - time < 1000L)
                return@setOnClickListener
            time = System.currentTimeMillis()

            isColorBrush = true

            ColorPickerDialog.newBuilder()
                    .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                    .setAllowPresets(false)
                    .setDialogId(0)
                    .setColor(
                            /*if (mDrawingColor == Color.BLACK || mDrawingColor == Color.parseColor(
                                    "#ff333333"
                                )
                            ) Color.WHITE else*/ mDrawingColor
                    )
                    .setShowAlphaSlider(true)
                    .show(this)
        }

        mImgSubBrushSelect!!.setOnClickListener {
            val brushSelect = Intent(this@PaintActivity, BrushSelectActivity::class.java)
            brushSelect.putExtra(Constants.EXTRA_BRUSH_ID, mCurrentBrushId)
            brushSelect.putExtra(Constants.EXTRA_BRUSH_TYPE, 0)
            startActivityForResult(
                    brushSelect,
                    REQUEST_BRUSH_SELECT
            )
        }
    }

    private fun setScaledSize(scaledSize: Float) {
        mSeekBrushSize!!.progress = (scaledSize * 100.0f).toInt()
        mPaintView!!.drawingScaledSize = scaledSize
    }

    private fun setOpacity(opacity: Float) {
        mSeekBrushOpacity!!.progress = (opacity * 100.0f).toInt()
        //this.mColorButton.setColor(getColorWithAlpha(this.mPaintView.getDrawingColor(), opacity));
        mPaintView!!.drawingAlpha = opacity
    }

    private fun setTextOpacity(opacity: Float) {
        //mSeekTextBrushOpacity!!.progress = (opacity * 100.0f).toInt()
        //this.mColorButton.setColor(getColorWithAlpha(this.mPaintView.getDrawingColor(), opacity));
        mPaintView!!.setTextAlpha(opacity)
    }

    private fun setColor(color: Int) {
        //this.mColorButton.setColor(getColorWithAlpha(color, this.mPaintView.getDrawingAlpha()));
        mPaintView!!.setDrawingColor(color)
        mDrawingColor = color
    }

    private fun setBrush(brushId: Int) {
        val brushes = get(applicationContext)
        if (brushId >= 0 && brushId < brushes!!.size) {
            if (mPaintView != null) {
                mPaintView!!.brush = brushes[brushId]
                Log.d("TAGnvv", brushId.toString() + "")

                if (brushId != brushes.size - 1) {
                    mCurrentBrushId = brushId
                } else {
                    mPaintView!!.drawingScaledSize = brushes[brushId]!!.scaledSize
                    mSeekEraserBrushSize!!.progress = (brushes[brushId]!!.scaledSize * 100).toInt()
                    mPaintView!!.drawingAlpha = brushes[brushId]!!.colorPatchAlpha
                    mSeekEraserBrushOpacity!!.progress =
                            (brushes[brushId]!!.colorPatchAlpha * 100).toInt()
                }

                mPaintView!!.drawingScaledSize = brushes[brushId]!!.scaledSize
                mSeekBrushSize!!.progress = (brushes[brushId]!!.scaledSize * 100).toInt()
                mPaintView!!.drawingAlpha = brushes[brushId]!!.colorPatchAlpha
                mSeekBrushOpacity!!.progress = (brushes[brushId]!!.colorPatchAlpha * 100).toInt()
            }
        }
    }

    //Add colors
    private fun openColorPicker(selectedColor2: Int): Unit {
        if (isColor1) {
            ColorPickerDialog.newBuilder()
                    .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                    .setAllowPresets(false)
                    .setDialogId(0)
                    .setColor(selectedColor2)
                    .setShowAlphaSlider(true)
                    .show(this)
        } else {
            ColorPickerDialog.newBuilder()
                    .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                    .setAllowPresets(false)
                    .setDialogId(1)
                    .setColor(selectedColor2)
                    .setShowAlphaSlider(true)
                    .show(this)
        }
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation) {
        val shape = GradientDrawable(orientation, colors)
        shape.shape = GradientDrawable.RECTANGLE
        mImgGradient!!.background = shape
    }

    private fun setCenterDrawable() {
        if (isCenter) {
            imageCenter!!.setImageDrawable(resources.getDrawable(R.drawable.ic_right_arrow))
        } else {
            imageCenter!!.setImageDrawable(resources.getDrawable(R.drawable.ic_left_arrow))
        }
        setCircleGradient(isCenter)
    }

    private fun setCircleGradient(isInner: Boolean) {
        if (isInner) {
            val new_colors = intArrayOf(colors[1], colors[0])
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.setColors(new_colors)
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = mainFrame!!.getWidth().toFloat()
            mImgGradient!!.setBackground(shape)
            isCenter = false
        } else {
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.setColors(colors)
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = mainFrame!!.getWidth().toFloat()
            mImgGradient!!.setBackground(shape)
            isCenter = true
        }
    }

    private fun onclickRotateColor() {
        imageRotate!!.rotation = imageRotate!!.rotation + 45
        mCurrentOrientation = (mCurrentOrientation + 1) % orientations.size
        orientation = orientations[mCurrentOrientation]
        setGradientDrawable(orientation)
    }

    //Eraser
    private fun initEraser() {
        val brushes = get(applicationContext)
        setBrush(brushes!!.size - 1)

        mSeekEraserBrushSize!!.setOnSeekBarChangeListener(object :
                SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                setScaledSize(seekBar!!.progress / 100f)
            }
        })

        mSeekEraserBrushOpacity!!.setOnSeekBarChangeListener(object :
                SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    setOpacity(progress / 100f)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    //Text Brush
    private fun initTextBrush() {
        mImgSubTextBrushSelect!!.setOnClickListener {
            if (isUserTextBrushFirstTime) {
                isUserTextBrushFirstTime = false
                anim!!.cancel()
                mImgSubTextBrushSelect!!.setColorFilter(
                        ContextCompat.getColor(
                                mMainActivity!!,
                                R.color.colorStart
                        )
                )
            }
            if (!isFragmentLoaded) {
                onclickText()
            }
        }
        mImgSubTextBrushColor!!.setOnClickListener {

//            Toast.makeText(this, "Wednesday", Toast.LENGTH_SHORT).show()
            
            isColorTextBrush = true
            ColorPickerDialog.newBuilder()
                .setDialogType(ColorPickerDialog.TYPE_PRESETS)
                .setAllowPresets(false)
                .setDialogId(0)
                .setColor(mPaintView!!.getTextColor())
                .setShowAlphaSlider(true)
                .show(this)
            
        }

        if (mPaintView!!.getTextAlpha() == 255) {
            mSeekTextBrushOpacity!!.progress = 100
        }
        mSeekTextBrushOpacity!!.setOnSeekBarChangeListener(object :
                SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // if (fromUser) {
                if (progress < 10) {
                    setTextOpacity(progress + 10 / 100f)
                } else {
                    setTextOpacity(progress / 100f)
                }
                //}
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        mSeekTextBrushSize!!.progress = mPaintView!!.getTextSize().toInt()
        mSeekTextBrushSize!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                mPaintView!!.setTextSize(seekBar!!.progress.toFloat() + 40)
            }

        })
    }

    override fun onStart() {
        super.onStart()
        Log.e(TAG, "onStart: chjabnsccaksdbc")
    }

    override fun onRestart() {
        super.onRestart()
        Log.e(TAG, "onRestart:csadcadscsadcsdc ")
    }

    private fun loadTextOnBrush() {
        mPaintView!!.setTexts(Constants.brushText!!)

        if (Constants.textFontPath!!.contains("fonts_neon")) {
            mPaintView!!.setTextTypeface(
                    Typeface.createFromAsset(
                            assets,
                            Constants.textFontPath!!
                    )
            )
        } else {
            mPaintView!!.setTextTypeface(Typeface.createFromFile(Constants.textFontPath))
        }
    }

    private fun manageBlinkEffect() {
        anim = ObjectAnimator.ofInt(
                mImgSubTextBrushSelect,
                "colorFilter",
                ContextCompat.getColor(mMainActivity!!, R.color.colorPrimary),
                ContextCompat.getColor(mMainActivity!!, R.color.colorStart),
                ContextCompat.getColor(mMainActivity!!, R.color.colorPrimary)
        )
        anim!!.duration = 1500
        anim!!.setEvaluator(ArgbEvaluator())
        anim!!.repeatMode = ValueAnimator.REVERSE
        anim!!.repeatCount = Animation.INFINITE
        anim!!.start()
    }

    private fun onclickText() {
        mConstraintMenuTextBrush!!.isEnabled = false
        addTextFragment = newInstance(mPaintView!!.getTexts(), Constants.textFontPath)
        val ft = supportFragmentManager.beginTransaction()
        ft.add(R.id.frmTextFragment, addTextFragment!!)
        ft.commit()
        isFragmentLoaded = true
        mLinearUndoRedo!!.visibility = View.INVISIBLE
        mLblHeaderTextBrush!!.visibility = View.VISIBLE
        mImgBack!!.setImageResource(R.drawable.ic_close)
        mImgDone!!.alpha = 1f
    }

    private fun removeFragment() {
        try {
            mConstraintMenuTextBrush!!.isEnabled = true
            supportFragmentManager.beginTransaction()
                    .remove(addTextFragment!!)
                    .commitAllowingStateLoss()
            imgColor!!.visibility = View.VISIBLE
            mLinearUndoRedo!!.visibility = View.VISIBLE
            mLblHeaderTextBrush!!.visibility = View.GONE
            mImgBack!!.setImageResource(R.drawable.ic_back_paint)
            isFragmentLoaded = false
            hideKeyboard(this)
            mImgDone!!.alpha = 0.5f
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideKeyboard(activity: Activity) {
        val imm =
                activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        //Find the currently focused view, so we can grab the correct window token from it.
        var view = activity.currentFocus
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = View(activity)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

    //Change UI control colors
    private fun changeColorOfMenuAddColor() {
//        mImgMenuAddColor!!.setBackgroundResource(R.drawable.btn_dotted_add_color_border_selected)
//        mImgMenuAddColor!!.setColorFilter(
//                ContextCompat.getColor(
//                        mMainActivity!!,
//                        R.color.colorSeekSelected
//                )
//        )
        mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuEraser!!.setColorFilter(
                ContextCompat.getColor(
                        mMainActivity!!,
                        R.color.colorNormal
                )
        )
        mImgMenuTextBrush!!.setColorFilter(
                ContextCompat.getColor(
                        mMainActivity!!,
                        R.color.colorNormal
                )
        )
//        mTxtMenuAddColor!!.setTextColor(
//                ContextCompat.getColor(
//                        mMainActivity!!,
//                        R.color.colorSeekSelected
//                )
//        )
        mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuEraser!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuTextBrush!!.setTextColor(
                ContextCompat.getColor(
                        mMainActivity!!,
                        R.color.colorNormal
                )
        )

        mMenuAddColor!!.visibility = View.INVISIBLE
        mMenuBrush!!.visibility = View.INVISIBLE
        mMenuEraser!!.visibility = View.INVISIBLE
        mMenuTextBrush!!.visibility = View.INVISIBLE
    }

    private fun changeColorOfMenuBrush() {
//        mImgMenuAddColor!!.setBackgroundResource(R.drawable.btn_dotted_add_color_border)
//        mImgMenuAddColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
        mImgMenuEraser!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuTextBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        selectGradientColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))
        imgGallerys!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))


//        mTxtMenuAddColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
        mTxtMenuEraser!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuTextBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        txtGradientColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        txtGallery!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))

        mMenuAddColor!!.visibility = View.INVISIBLE
        mMenuBrush!!.visibility = View.VISIBLE
        mMenuEraser!!.visibility = View.INVISIBLE
        mMenuTextBrush!!.visibility = View.INVISIBLE
    }

    private fun changeColorOfMenuEraser() {
//        mImgMenuAddColor!!.setBackgroundResource(R.drawable.btn_dotted_add_color_border)
////        mImgMenuAddColor!!.setColorFilter(
//                ContextCompat.getColor(
//                        mMainActivity!!,
//                        R.color.colorNormal
//                )
//        )
        mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuEraser!!.setColorFilter(
                ContextCompat.getColor(
                        mMainActivity!!,
                        R.color.colorSelected
                )
        )
        mImgMenuTextBrush!!.setColorFilter(
                ContextCompat.getColor(
                        mMainActivity!!,
                        R.color.colorNormal
                )
        )
        selectGradientColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))
        imgGallerys!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))

        txtGradientColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        txtGallery!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))

//        mTxtMenuAddColor!!.setTextColor(
//                ContextCompat.getColor(
//                        mMainActivity!!,
//                        R.color.colorNormal
//                )
//        )
        mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuEraser!!.setTextColor(
                ContextCompat.getColor(
                        mMainActivity!!,
                        R.color.colorSelected
                )
        )
        mTxtMenuTextBrush!!.setTextColor(
                ContextCompat.getColor(
                        mMainActivity!!,
                        R.color.colorNormal
                )
        )

        mMenuAddColor!!.visibility = View.INVISIBLE
        mMenuBrush!!.visibility = View.INVISIBLE
        mMenuEraser!!.visibility = View.VISIBLE
        mMenuTextBrush!!.visibility = View.INVISIBLE
    }

    private fun changeColorOfMenuTextBrush() {
//        mImgMenuAddColor!!.setBackgroundResource(R.drawable.btn_dotted_add_color_border)
//        mImgMenuAddColor!!.setColorFilter(
//                ContextCompat.getColor(
//                        mMainActivity!!,
//                        R.color.colorNormal
//                )
//        )
        mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuEraser!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuTextBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
        selectGradientColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))
        imgGallerys!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))

        txtGradientColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        txtGallery!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuEraser!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuTextBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))

        mMenuAddColor!!.visibility = View.INVISIBLE
        mMenuBrush!!.visibility = View.INVISIBLE
        mMenuEraser!!.visibility = View.INVISIBLE
        mMenuTextBrush!!.visibility = View.VISIBLE
    }

    //Save image in gallery
    private fun create_Save_Image(): Unit {
        Dexter.withActivity(mMainActivity)
                .withPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(object : PermissionListener {
                    override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                        saveImage(getMainFrameBitmap(mainFrame!!))
                    }

                    override fun onPermissionRationaleShouldBeShown(
                            p0: PermissionRequest?,
                            token: PermissionToken?
                    ) {
                        token!!.continuePermissionRequest()
                    }

                    override fun onPermissionDenied(response: PermissionDeniedResponse?) {
                        if (response!!.isPermanentlyDenied) {
                            openPermissionSettingDialog()
                        }
                    }

                })
                .check()
    }

    private fun getMainFrameBitmap(view: View): Bitmap {
        val bitmap = Bitmap.createBitmap(
                view.width,
                view.height,
                Bitmap.Config.ARGB_8888
        )
        view.draw(Canvas(bitmap))
        return bitmap
    }

    private fun saveImage(bitmap2: Bitmap) {
        Constants.mSavedBitmap = bitmap2
        try {
//            startActivity(Intent(this, ViewPaintActivity::class.java))
        } catch (e: Exception) {
            Toast.makeText(this, resources.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPermissionSettingDialog() {
        var permissionDialog = androidx.appcompat.app.AlertDialog.Builder(mMainActivity!!)
        permissionDialog.setTitle("Allow Permission")
        permissionDialog.setMessage("Allow permission to access this feature.")
        permissionDialog.setPositiveButton(
                "Yes",
                DialogInterface.OnClickListener { dialogInterface, i ->
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", packageName, null)
                    })
                })
        permissionDialog.setNegativeButton(
                "No",
                DialogInterface.OnClickListener { dialogInterface, i ->
                    showToast("Permission required")
                })
        permissionDialog.show()
    }

    fun checkSomethingIsAddedOnCanvas(): Boolean {
        if (mPaintView!!.isAnyDrawing() || colors[0] != 0) {
            mImgDone!!.isEnabled = true
            mImgDone!!.alpha = 1f
            return true
        } else {
            mImgDone!!.isEnabled = true
            mImgDone!!.alpha = 0.5f
            return false
        }
    }

    fun checkUndoRedoDisable() {
        if (mPaintView!!.checkUndo()) {
            imgUndo.alpha = 1f
        } else {
            imgUndo.alpha = 0.5f
        }

        if (mPaintView!!.checkRedo()) {
            imgRedo.alpha = 1f
        } else {
            imgRedo.alpha = 0.5f
        }
    }

    override fun onStop() {
        super.onStop()
//        removeFragment()
        mImgDone!!.alpha = 1f

    }

    override fun onBackPressed() {
//        if (mainBottomlayoutSelect!!.visibility == View.VISIBLE) {
//            imgForGallery!!.isEnabled = true
//            btnColorLayout!!.isEnabled = true
            findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
            findViewById<LinearLayout>(R.id.llMainButton).visibility = View.GONE
//            mMenuAddColor!!.visibility = View.INVISIBLE
//            mMenuBrush!!.visibility = View.INVISIBLE
//            mMenuEraser!!.visibility = View.INVISIBLE
//            mMenuTextBrush!!.visibility = View.INVISIBLE
            mImgDone!!.isEnabled = true
            mImgDone!!.alpha = 1f

//        } else {
            if (isFragmentLoaded) {
                removeFragment()
            } else {
                showAlertDialog()
            }
//        }
    }

    private fun showRateDialog() {
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView = LayoutInflater.from(this).inflate(com.hd.wallpaper.solid.color.background.R.layout.dialog_rate_app, viewGroup, false)
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        builder.setView(dialogView)
        val alertDialog = builder.create()
        Objects.requireNonNull(alertDialog.window)!!.setBackgroundDrawableResource(android.R.color.transparent)
        alertDialog.setOnCancelListener { alertDialog.dismiss() }
        val btnClose = dialogView.findViewById<ImageView>(com.hd.wallpaper.solid.color.background.R.id.btnClose)
        btnClose.setOnClickListener { alertDialog.dismiss() }
        val ratingBar1: ScaleRatingBar = dialogView.findViewById(com.hd.wallpaper.solid.color.background.R.id.ratingBar)
        ratingBar1.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            if (rating > 2) {
                rate_app()
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)

            } else {
                Toast.makeText(this, "Rate Is : $rating", Toast.LENGTH_SHORT).show()
//                sendMail()
//                //  Toast.makeText(SetWallpaperActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
            }
        }

        dialogView.findViewById<View>(com.hd.wallpaper.solid.color.background.R.id.btnNextTime).setOnClickListener {
            alertDialog.dismiss()
            mySharedPref!!.countExist = 0
        }
        if (!this@PaintActivity.isFinishing) {
            alertDialog.show()
        }
    }

    private fun rate_app() {
        mySharedPref!!.setVisitPlay()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
        }
    }


    private fun showAlertDialog() {
         bottomSheetFragment = BottomSheetFragmentDiscard(this, resources.getString(R.string.discard), resources.getString(R.string.if_you_discard_work_will_unsaved), resources.getString(R.string.discard), resources.getString(R.string.cancel), R.drawable.ic_discard_dialog, object : BottomSheetFragmentDiscard.OnButtonClickListener {
            override fun onPositive(bottomSheetDialo: BottomSheetFragmentDiscard) {
                bottomSheetDialo.dismiss()
                finish()
            }

            override fun onNegative(bottomSheetDialog: BottomSheetFragmentDiscard) {
                bottomSheetDialog.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }


    override fun onColorSelected(dialogId: Int, color: Int) {
        imgGradient!!.setImageDrawable(null)
        if (!isColorBrush) {
            if (isColorTextBrush) {
                isColorTextBrush = false
                mPaintView!!.setTextColor(color)
                return
            }
            if (isColor1) {
                selectedColor = color
                colors[0] = color
                checkSomethingIsAddedOnCanvas()
                if (!isColor2Selected) {
                    colors[1] = color
                    imageCenter!!.alpha = 0.5f
                    imageRotate!!.alpha = 0.5f
                    // btnNext.setEnabled(false);
                    // btnNext.setAlpha(0.5f);
                }
                val shape = GradientDrawable()
                shape.shape = GradientDrawable.RECTANGLE
                shape.setColor(color)
                shape.cornerRadius = 18f
                shape.setStroke(3, Color.BLACK)
                mBtnAddColor1!!.setImageDrawable(shape)
            } else if (isColor2) {
                isColor2Selected = true
                selectedColor2 = color
                colors[1] = color
                val shape = GradientDrawable()
                shape.shape = GradientDrawable.RECTANGLE
                shape.setColor(color)
                shape.cornerRadius = 18f
                shape.setStroke(3, Color.BLACK)
                mBtnAddColor2!!.setImageDrawable(shape)
            }
            mBtnAddColor2!!.setAlpha(1f)
            setGradientDrawable(orientation)
            imgGallery!!.setImageBitmap(null)

            if (isColor2) {
                imageCenter!!.alpha = 1f
                imageRotate!!.alpha = 1f
            }
        } else {
            isColorBrush = false
            setColor(color)
        }
    }

    override fun onResume() {
        super.onResume()
        imgForGallery!!.isEnabled = true
        btnColorLayout!!.isEnabled = true
        Log.e(TAG, "onResume: jnadjklsjklbdsnkjcas")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    override fun onDialogDismissed(dialogId: Int) {

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != 0) {
            when (requestCode) {
                REQUEST_BRUSH_SELECT -> {
                    val brushId = data!!.getIntExtra(Constants.EXTRA_BRUSH_ID, 0)
                    setBrush(brushId)
                }
                else -> {
                }
            }
        }
        if (requestCode == 1111 && resultCode == 2222) {
            imgForGallery!!.isEnabled = true
            btnColorLayout!!.isEnabled = true
            if (mGalleryBitmap != null) {
                try {
                    selectedColor = Color.parseColor("#EBEBEB")
                    selectedColor2 = Color.parseColor("#EBEBEB")
                    colors[0] = selectedColor
                    colors[1] = selectedColor2

                    imgGallery!!.setImageBitmap(com.hd.wallpaper.solid.color.background.constants.Constants.mGalleryBitmap)
                    imgDone!!.isEnabled = true
                    isImageSelected = true
                    imgDone!!.alpha = 1f
                    btnAddColor1!!.setImageDrawable(resources.getDrawable(R.drawable.ic_plus_select))
                    btnAddColor2!!.setImageDrawable(resources.getDrawable(R.drawable.ic_plus_select))
//                    onClick(cradientCancel as View)
                    mImgDone!!.isEnabled = true
                    mImgDone!!.alpha = 1f
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun onClick(v: View?) {
        when (v!!.id) {
//            R.id.constraintMenuAddColor -> {
//                removeFragment()
//                mPaintView!!.setBrushType(PaintView.ADDCOLOR)
//                changeColorOfMenuAddColor()
//                checkSomethingIsAddedOnCanvas()
//                findViewById<LinearLayout>(R.id.llMainButton).visibility = View.GONE
//                findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
//
//            }
            R.id.btnNon -> {
                mGalleryBitmap = null
                mGalleryUri = null

                imgGallery!!.setImageBitmap(null)

                selectedColor = Color.parseColor("#EBEBEB")
                selectedColor2 = Color.parseColor("#EBEBEB")
                colors[0] = selectedColor
                colors[1] = selectedColor2

                btnAddColor1!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))
                btnAddColor2!!.setImageDrawable(resources.getDrawable(R.drawable.ic_gradient_select))

                val shape: GradientDrawable = GradientDrawable()
                shape.setColor(selectedColor)
                imgGradient!!.setImageDrawable(shape)
                isImageSelected = false
                isColor2Selected = false
                isColorSelected = false
                mImgDone!!.isEnabled = true
                mImgDone!!.alpha = 1f
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true
//                mMenuAddColor!!.visibility = View.INVISIBLE

            }

            R.id.constraintMenuBrush -> {
                removeFragment()
                mPaintView!!.setBrushType(PaintView.PAINT)
                changeColorOfMenuBrush()
                setBrush(mCurrentBrushId)
                checkSomethingIsAddedOnCanvas()
            }
            R.id.constraintMenuEraser -> {
                removeFragment()
                mPaintView!!.setBrushType(PaintView.ERASER1)
                changeColorOfMenuEraser()
                initEraser()
                checkSomethingIsAddedOnCanvas()
            }
            R.id.constraintMenuTextBrush -> {
                if (getBoolean(this)) {
                    lottie_hand.visibility = View.VISIBLE
                    save(this)
                } else {
                    lottie_hand.visibility = View.GONE
                }
                changeColorOfMenuTextBrush()
                mPaintView!!.setBrushType(PaintView.TEXT)
                if (!isFragmentLoaded) {
                    initTextBrush()
                }
                if (isUserTextBrushFirstTime) {
                    manageBlinkEffect()
                }
                checkSomethingIsAddedOnCanvas()
            }
            R.id.imgForGallery -> onclickGallery()
            R.id.imgBack -> {
                onBackPressed()
            }
            R.id.btnColorLayout -> {
                removeFragment()
//                btnColorLayout!!.alpha=1f
                imgForGallery!!.isEnabled = true
                btnColorLayout!!.isEnabled = true

                mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
                mImgMenuEraser!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
                mImgMenuTextBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
                selectGradientColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorSelected))
                imgGallerys!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))

                txtGradientColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
                txtGallery!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
                mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
                mTxtMenuEraser!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
                mTxtMenuTextBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))

                findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
                findViewById<LinearLayout>(R.id.llMainButton).visibility = View.INVISIBLE
                mMenuAddColor!!.visibility = View.VISIBLE
                mMenuBrush!!.visibility=View.INVISIBLE
                mMenuEraser!!.visibility=View.INVISIBLE
                mMenuTextBrush!!.visibility=View.INVISIBLE

                setNormalColor()
            }
//            R.id.cradientCancel -> {
////                if(checkSomethingIsAddedOnCanvas()) {
//                imgForGallery!!.isEnabled = true
//                btnColorLayout!!.isEnabled = true
//                findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.INVISIBLE
//                findViewById<LinearLayout>(R.id.llMainButton).visibility = View.VISIBLE
//                mMenuAddColor!!.visibility = View.INVISIBLE
//                mMenuBrush!!.visibility = View.INVISIBLE
//                mMenuEraser!!.visibility = View.INVISIBLE
//                mMenuTextBrush!!.visibility = View.INVISIBLE
//                setNormalColor()
////                }else{
////                    showToast("Please select color/image")
////                }
//            }
            R.id.imgDone -> {
                Log.e(TAG, "onClick: jkbhdsjkbfsdjksdanfgasddsadas")
                mySharedPref!!.countExist = mySharedPref!!.countExist + 1
                Log.d("12345", "onclickNext: Create Solid ${mySharedPref!!.countExist}")
                 if (isFragmentLoaded) {

//                    if (isNetworkConnected()) {
//
//                        Log.e(TAG, "onClick: jkbhdsjkbewewewfsdsdsd2323jksdanfgas")
//
//                        showInterstitial()
//                        loadInterstialAd1()
//                    }


                    if (Constants.brushText!!.length != 0) {
                        removeFragment()
                        loadTextOnBrush()
                        Log.e(TAG, "onClick: jksdsdsdsbhdsjewewkbfjksdanfgas")

                    } else {
                        Log.e(TAG, "onClick: jkbhdsjkbdsfjkewew223sdanfgasdsdss")

                        showToast(resources.getString(R.string.toast_add_some_text))
                    }
                }
               else if (mainBottomlayoutSelect!!.visibility == View.VISIBLE) {
//                    imgForGallery!!.isEnabled = true
//                    selectGradientColor!!.isEnabled = true
//                    findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.INVISIBLE
//                    mMenuAddColor!!.visibility = View.INVISIBLE
//                    mMenuBrush!!.visibility = View.INVISIBLE
//                    mMenuEraser!!.visibility = View.INVISIBLE
//                    mMenuTextBrush!!.visibility = View.INVISIBLE

                     if (!AdsPrefs.getBoolean(this@PaintActivity, AdsPrefs.IS_SUBSCRIBED, false)){
                         if (checkSomethingIsAddedOnCanvas()) {

                             if (isNetworkConnected()) {
                                 Log.e(TAG, "onClick: jkbhdsjkbfeweweewewqwwsdsdsdjksdanfgas")
                                 create_Save_Image()
                                 isShowInterstitialAd{
                                     create_Save_Image()
                                     startActivity(Intent(this@PaintActivity, ViewPaintActivity::class.java))
                                 }
                             } else {
                                 Log.e(TAG, "onClick: jkbhdsjkbfsdewewsdsdjksdanfgas")

                                 create_Save_Image()
                                 startActivity(Intent(this@PaintActivity, ViewPaintActivity::class.java))

                             }

                         } else {
                             Toast.makeText(this, getString(com.hd.wallpaper.solid.color.background.R.string.select_color), Toast.LENGTH_SHORT).show()
                         }
                     }
                     else {
                         create_Save_Image()
                         startActivity(Intent(this@PaintActivity, ViewPaintActivity::class.java))
                     }

               }

                else {
                    if (checkSomethingIsAddedOnCanvas()) {
                        Log.e(TAG, "onClick: jkbhdsjkbdsfjkewew223sdasdadsadsadsnfgasdsdss")
                        findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
//                        findViewById<LinearLayout>(R.id.llMainButton).visibility = View.VISIBLE
//                        mMenuAddColor!!.visibility = View.INVISIBLE
//                        mMenuBrush!!.visibility = View.INVISIBLE
//                        mMenuEraser!!.visibility = View.INVISIBLE
//                        mMenuTextBrush!!.visibility = View.INVISIBLE

                        setNormalColor()

                        if (!AdsPrefs.getBoolean(this@PaintActivity, AdsPrefs.IS_SUBSCRIBED, false)) {

                            if (isNetworkConnected()) {
                                isShowInterstitialAd{
                                    create_Save_Image()
                                    findViewById<LinearLayout>(R.id.mainBottomlayoutSelect).visibility = View.VISIBLE
                                    startActivity(Intent(this@PaintActivity, ViewPaintActivity::class.java))
                                }
                            } else {
                                create_Save_Image()
                                startActivity(Intent(this@PaintActivity, ViewPaintActivity::class.java))

                            }

                        } else {
                            create_Save_Image()
                            startActivity(Intent(this@PaintActivity, ViewPaintActivity::class.java))
                        }

                    } else {
                        Toast.makeText(this, getString(com.hd.wallpaper.solid.color.background.R.string.select_color), Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.btnAddColor1 -> {
                isColor1 = true
                isColor2 = false
                openColorPicker(selectedColor)
            }
            R.id.btnAddColor2 -> {
                if (colors[0] != 0) {
                    isColor1 = false
                    isColor2 = true
                    openColorPicker(selectedColor2)
                } else {
                    showToast(resources.getString(R.string.toast_choose_previous_color))
                }
            }
            R.id.btnCenterColor -> {
                if (isColor2Selected) {
                    setCenterDrawable()
                    isCircle = true
                } else {
                    showToast(resources.getString(R.string.toast_first_choose_both_colors))
                }
            }
            R.id.btnRotateColor -> {
                if (isColor2Selected) {
                    onclickRotateColor()
                    isCircle = false
                } else {
                    showToast(resources.getString(R.string.toast_first_choose_both_colors))
                }
            }
        }
    }

    private fun setNormalColor() {
//        mImgMenuAddColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//        mImgMenuAddColor!!.setColorFilter(
//                ContextCompat.getColor(
//                        mMainActivity!!,
//                        R.color.colorNormal
//                )
//        )
        selectGradientColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorSelected))
        mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuEraser!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mImgMenuTextBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))

//        mTxtMenuAddColor!!.setTextColor(
//                ContextCompat.getColor(
//                        mMainActivity!!,
//                        R.color.colorNormal
//                )
//        )

        txtGradientColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
        mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuEraser!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
        mTxtMenuTextBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
    }


    private fun onclickGallery() {
//        imgForGallery!!.isEnabled = false
//        btnColorLayout!!.isEnabled = false
//
//        mImgMenuBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//        mImgMenuEraser!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//        mImgMenuTextBrush!!.setColorFilter(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//        selectGradientColor!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorNormal))
//        imgGallerys!!.setColorFilter(ContextCompat.getColor(mMainActivity!!,R.color.colorSelected))
//
//        txtGradientColor!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//        txtGallery!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorSelected))
//        mTxtMenuBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//        mTxtMenuEraser!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//        mTxtMenuTextBrush!!.setTextColor(ContextCompat.getColor(mMainActivity!!, R.color.colorNormal))
//
//        mMenuAddColor!!.visibility = View.INVISIBLE



        ImagePicker.with(this)
                .setFolderMode(true)
                .setFolderTitle("Album")
                .setMultipleMode(false)
                .setImageCount(1)
                .setMaxSize(10)
                .setBackgroundColor("#ffffff")
                .setAlwaysShowDoneButton(true)
                .setRequestCode(1111)
                .setKeepScreenOn(true)
                .start()

//        mMenuAddColor!!.visibility = View.INVISIBLE
//        mMenuBrush!!.visibility=View.INVISIBLE
//        mMenuEraser!!.visibility=View.INVISIBLE
//        mMenuTextBrush!!.visibility=View.INVISIBLE
    }
}
