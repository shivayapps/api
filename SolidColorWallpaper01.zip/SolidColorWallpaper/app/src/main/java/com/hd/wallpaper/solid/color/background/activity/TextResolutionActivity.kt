package com.hd.wallpaper.solid.color.background.activity

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.app.Service
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.Layout
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.NetworkHelper
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.ApiNotSupportedException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.exceptions.NullWifiConfigurationException
import com.bitbucket.lonelydeveloper97.wifiproxysettingslibrary.proxy_change_realisation.wifi_network.wifi_proxy_changing_realisations.api_from_21_to_22.WifiConfiguration
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd

import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.hd.wallpaper.solid.color.background.BuildConfig
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication.Companion.instance
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.custom.MatrixClonable
import com.hd.wallpaper.solid.color.background.live_wallpaper.CustomNewWallpaper
import com.hd.wallpaper.solid.color.background.model.ResolutionModel
import com.hd.wallpaper.solid.color.background.model.StickerModel
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperResolution
import com.willy.ratingbar.ScaleRatingBar
import com.xiaopo.flying.sticker.DrawableSticker
import com.xiaopo.flying.sticker.Sticker
import com.xiaopo.flying.sticker.StickerView
import com.xiaopo.flying.sticker.TextSticker
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.lang.reflect.InvocationTargetException
import java.util.*

class TextResolutionActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var btnShare: ImageView? = null
    private var btnSave: ImageView? = null
    private var btnHome: ImageView? = null
    private var btnBack: ImageView? = null
    private var btnSetWallpaper: TextView? = null
    private var mBitmap: Bitmap? = null
    private var mPermissionGranted: Boolean = false
    private var mPermissionGrantedWallpaper: Boolean = false
    private var isShared: Boolean = false
    private val isCircle: Boolean = false
    private var mainLayout: RelativeLayout? = null
    private var progressBar: ProgressDialog? = null
    private var mySharedPref: MySharedPref? = null
    private var isSetWallpaper: Boolean = false
    private var vibrator: Vibrator? = null
    private var imgWallpaper: ImageView? = null
    private var mAllSticker: ArrayList<StickerModel?>? = null
    private var resolutionModel: ResolutionModel? = null
    private var sticker_view: StickerView? = null
    private var mainFrame: FrameLayout? = null
    private var imgFromG: ImageView? = null
    var ratecheck = false

    var bottomSheetFragment: BottomSheetFragment? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_resolution)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted
            startActivity(Intent(this@TextResolutionActivity, MainStartActivity::class.java))
            finish()
        } else {
            Constants.savedPath = null
            mySharedPref = MySharedPref(this)
            if ( /*!mySharedPref.getAdsRemoved() &&*/!getBoolean(this@TextResolutionActivity, AdsPrefs.IS_SUBSCRIBED, false)) {

                if (isNetworkConnected()) {
                    Constants.isInstrastial1 = false
                    isShowInterstitialAd {

                    }
                }

                //   loadInterstialAdFb();
            }
            initViews()
            initViewAction()
            initListner()
        }

        if (mySharedPref!!.countExist % 3 == 0 && mySharedPref!!.visitPlay == null) {
            showRateDialog()
        }
    }

    private fun isNetworkConnected(): Boolean {
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo != null && cm.activeNetworkInfo!!.isConnected
    }

    private fun initListner() {
        btnSave!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnSetWallpaper!!.setOnClickListener(this)
        btnHome!!.setOnClickListener(this)
        btnBack!!.setOnClickListener(this)
        imgFromG!!.setOnClickListener(this)

    }


    private fun initViewAction() {
        mAllSticker = ArrayList()
        val mList: ArrayList<ResolutionModel> = DBHelperResolution(this@TextResolutionActivity).resolutionModelList
        /*  for (int i = 0; i < mList.size(); i++) {
            Log.d(TAG, "addTextSticker: " + mList.get(i).getMainWidth());
            Log.d(TAG, "addTextSticker: " + mList.get(i).getMainHeight());
            Log.d(TAG, "addTextSticker: " + mList.get(i).getColor1());
            Log.d(TAG, "addTextSticker: " + mList.get(i).getColor2());
            Log.d(TAG, "addTextSticker: " + mList.get(i).isCircle());
            Log.d(TAG, "addTextSticker: " + mList.get(i).isInner());
            Log.d(TAG, "addTextSticker: " + mList.get(i).getOrientation());
            Log.d(TAG, "addTextSticker: " + mList.get(i).getmAllSticker());
        }
        Log.d("784512746", "initViewAction: "+mList.size());*/
        resolutionModel = mList.get(mList.size - 1)
        mAllSticker!!.addAll((resolutionModel!!.getmAllSticker())!!)
        addTextSticker()
        if (resolutionModel!!.isCircle) {
            setCircleGradient(resolutionModel!!.isInner)
        } else {
            setGradientDrawable(resolutionModel!!.orientation)
        }
        if (mySharedPref!!.vibration) {
            vibrator = getSystemService(Service.VIBRATOR_SERVICE) as Vibrator?
        }
        progressBar = ProgressDialog(this@TextResolutionActivity)
        progressBar!!.setMessage(getResources().getString(R.string.dialog_msg_please_wait))
        progressBar!!.setCancelable(false)
    }

    private fun initViews() {
        btnSave = findViewById(R.id.btnSave)
        btnSetWallpaper = findViewById(R.id.btnSetWallpaper)
        btnShare = findViewById(R.id.btnShare)
        btnHome = findViewById(R.id.btnHome)
        mainLayout = findViewById(R.id.mainLayout)
        btnBack = findViewById(R.id.btnBack)
        imgWallpaper = findViewById(R.id.imgWallpaper)
        imgFromG = findViewById(R.id.imgFromG)

        sticker_view = findViewById(R.id.sticker_viewnew)
        mainFrame = findViewById(R.id.mainFrame)
        sticker_view!!.isLocked = true
    }

    public override fun onClick(view: View) {
        when (view.id) {
            R.id.btnSave -> {
                isSetWallpaper = false
                isShared = false
                if (ContextCompat.checkSelfPermission(
                        applicationContext,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    ActivityCompat.requestPermissions(
                        this@TextResolutionActivity,
                        arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                        READ_PERMISSION
                    )
                } else {
                    mPermissionGranted = true
                }
                if (mPermissionGranted) {
                    if (Constants.savedPath == null) {
                        showSaveDialog()
                    } else {
                        showSnackbar(getResources().getString(R.string.wallpaper_already_exist))
                        //    Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            R.id.btnSetWallpaper -> {
                isSetWallpaper = true
                isShared = false
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.SET_WALLPAPER) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@TextResolutionActivity, arrayOf(Manifest.permission.SET_WALLPAPER), WALLPAPER_PERMISSION)
                } else {
                    mPermissionGrantedWallpaper = true
                }
                if (mPermissionGrantedWallpaper) {
                    if ( /*Constants.isText && */mySharedPref!!.scale.equals("Fit", ignoreCase = true)) {
                        try {
                            if (mBitmap == null) {
                                mBitmap = outputBitmap
                            }
                            Constants.mWallpaperBitmap = mBitmap
                            val intent: Intent = Intent(
                                WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER
                            )
                            intent.putExtra(
                                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                ComponentName(this, CustomNewWallpaper::class.java)
                            )
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                            showSnackbar(getResources().getString(R.string.live_wallpaper_not_supported))
                        }
                    } else {
                        showCustomDialog()
                    }
                    //onclickSave();
                }
            }
            R.id.btnShare -> {
                isShared = true
                isSetWallpaper = false
                shareWallpaper()
            }
            R.id.btnBack -> onBackPressed()
            R.id.btnHome -> {
                mySharedPref!!.setImagePath("")
                startActivity(Intent(this@TextResolutionActivity, HomeActivity::class.java))
                finish()
            }
        }
    }

//    private fun showGoogleAdHome() {
//        if (instance!!.requestNewInterstitial()) {
//
//            instance!!.mInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
//                override fun onAdDismissedFullScreenContent() {
////                    Log.d(TAG, 'Ad was dismissed.')
//                    startActivity(Intent(this@TextResolutionActivity, HomeActivity::class.java))
//                    finish()
//                }
//
//                override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
//                    super.onAdFailedToShowFullScreenContent(p0)
//                    startActivity(Intent(this@TextResolutionActivity, HomeActivity::class.java))
//                    finish()
//                }
//
//                override fun onAdShowedFullScreenContent() {
////                    Log.d(TAG, 'Ad showed fullscreen content.')
//
//                    instance!!.mInterstitialAd = null;
//                }
//            }
//            instance!!.mInterstitialAd!!.show(this)
//        } else {
//            startActivity(Intent(this@TextResolutionActivity, HomeActivity::class.java))
//            finish()
//        }
//    }

    private fun showCustomDialog() {
        btnSetWallpaper!!.isEnabled = false
        val builder1: BottomSheetDialog = BottomSheetDialog(this@TextResolutionActivity, R.style.BottomSheetDialog)
        val v: View = layoutInflater.inflate(R.layout.dialog_setwallpaper, null)
        builder1.setContentView(v)
        builder1.show()
        builder1.setOnDismissListener { btnSetWallpaper!!.isEnabled = true }
        val wallpaper: LinearLayout = v.findViewById(R.id.btnHomeScreen)
        val bothwallpaper: LinearLayout = v.findViewById(R.id.btnBoth)
        val lockscreen: LinearLayout = v.findViewById(R.id.btnLockScreen)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            bothwallpaper.visibility = View.GONE
            lockscreen.visibility = View.GONE
        }
        lockscreen.setOnClickListener { view: View? ->
            builder1.dismiss()
            progressBar!!.show()
            Handler().postDelayed(Runnable {

                //   progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                    //  showRateDialog()
                    mySharedPref!!.countExist = 0
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@TextResolutionActivity).updateData()
                cancelAlarm(
                    ("2121" + mySharedPref!!.alarmId).toInt(),
                    this@TextResolutionActivity,
                    EventReceiver::class.java
                )
            }
            Handler().postDelayed({ lockScreenWallpaper() }, 400)
        }
        wallpaper.setOnClickListener(View.OnClickListener { v1: View? ->
            builder1.dismiss()
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //  progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                    // showRateDialog()
                    mySharedPref!!.countExist = 0
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@TextResolutionActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@TextResolutionActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ onclickWallpaper(false) }, 400)
        })
        bothwallpaper.setOnClickListener(View.OnClickListener { v12: View? ->
            builder1.dismiss()
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //  progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                    mySharedPref!!.countExist = 0
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@TextResolutionActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@TextResolutionActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({
                onclickWallpaper(true)
                lockScreenWallpaper()
            }, 400)
        })
    }

    private fun showRateDialog() {
        val viewGroup: ViewGroup = findViewById(android.R.id.content)
        val dialogView: View = LayoutInflater.from(this).inflate(R.layout.dialog_rate_app, viewGroup, false)
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        val alertDialog: AlertDialog = builder.create()
        Objects.requireNonNull(alertDialog.window)!!.setBackgroundDrawableResource(android.R.color.transparent)
        alertDialog.setOnCancelListener { alertDialog.dismiss() }
        val btnClose: ImageView = dialogView.findViewById(R.id.btnClose)
        btnClose.setOnClickListener { alertDialog.dismiss() }
        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
        ratingBar1.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            if (rating > 3) {
                rate_app()
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
            } else {
                mySharedPref!!.setVisitPlay()
//                sendMail()
                Toast.makeText(this, "Thanks for review", Toast.LENGTH_SHORT).show()
                //Toast.makeText(TextResolutionActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
            }
        }
        dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener {
            mySharedPref!!.countExist = 0
            alertDialog.dismiss()
        }
        if (!isFinishing) {
            alertDialog.show()
        }
    }

    private fun sendMail() {
        mySharedPref!!.setVisitPlay()
        val send: Intent = Intent(Intent.ACTION_SENDTO)
        val uriText: String = ("mailto:" + Uri.encode("profagnesh009@gmail.com") +
                "?subject=" + Uri.encode("Share valuable feedback to improve app quality of Solid Color Wallpaper") +
                "&body=" + Uri.encode(""))
        val uri: Uri = Uri.parse(uriText)
        send.data = uri
        startActivity(Intent.createChooser(send, "Send Email..."))
    }

    private fun rate_app() {
        mySharedPref!!.setVisitPlay()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
        }
    }

    private fun lockScreenWallpaper() {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val wm: WallpaperManager = WallpaperManager.getInstance(this)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wm.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_LOCK) //For Lock screen
                    progressBar!!.dismiss()
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) {
                            vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            vibrator!!.vibrate(200)
                        }
                    }
                    showSnackbar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
                } else {
                    Toast.makeText(
                        this, "Lock Screen Wallpaper Not Supported",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun showSaveDialog() {
        bottomSheetFragment = BottomSheetFragment(
            getResources().getString(R.string.save),
            getResources().getString(R.string.do_you_want_to_save),
            getResources().getString(R.string.save),
            getResources().getString(R.string.cancel),
            R.drawable.ic_save_dialog,
            object : BottomSheetFragment.OnButtonClickListener {
                public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                    bottomSheetDialo!!.dismiss()
                    onclickSave()
                }

                public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                    bottomSheetDialog!!.dismiss()
                }
            })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
        } catch (e: Exception) {

        }
    }

    private fun shareWallpaper() {
        if (Constants.savedPath == null) {
            if (ContextCompat.checkSelfPermission(
                    applicationContext,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(this@TextResolutionActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), SHARE_PERMISSION)
            } else {
                mPermissionGranted = true
            }
            if (mPermissionGranted) {
                onclickSave()
            }
        } else {
            val uri: Uri? = FileProvider.getUriForFile(
                this@TextResolutionActivity,
                BuildConfig.APPLICATION_ID.toString() + ".provider",
                File(Constants.savedPath)
            )
            if (uri != null) {
                val intent: Intent = Intent(Intent.ACTION_SEND)
                intent.type = "image/jpeg"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                var shareMessage: String = ""
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
                intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivityForResult(Intent.createChooser(intent, getResources().getString(R.string.share_wallpaper)), 100)
            }
        }
    }

    private fun onclickWallpaper(isBoth: Boolean) {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val wallpaperManager: WallpaperManager = WallpaperManager.getInstance(applicationContext)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                } else {
                    wallpaperManager.setBitmap(mBitmap)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (!isBoth) {
                progressBar!!.dismiss()
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        vibrator!!.vibrate(200)
                    }
                }
                //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                showSnackbar(getResources().getString(R.string.toast_wallpaper_set_seccessfully))
            }
        } else {
            showSnackbar(getResources().getString(R.string.try_again_later))
            //Toast.makeText(this, "Try Again Later!", Toast.LENGTH_SHORT).show();
        }
    }

    private fun showSnackbar(msg: String) {
        val snackbar: Snackbar = Snackbar.make(findViewById(R.id.mainContainer), msg, Snackbar.LENGTH_SHORT)
        val v: View = snackbar.view
        val params: CoordinatorLayout.LayoutParams = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView: TextView = v.findViewById(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    private fun onclickSave() {
        mBitmap = outputBitmap
        if (mBitmap != null) {
            val myDir: File = File(Constants.path)
            myDir.mkdirs()
            val fname: String
            if (Constants.isTextWallpaper) {
                fname = "Text_" + (System.currentTimeMillis() / 1000) + ".png"
            } else {
                fname = "Gradient_" + (System.currentTimeMillis() / 1000) + ".png"
            }
            val file: File = File(myDir, fname)
            var out: FileOutputStream? = null
            try {
                out = FileOutputStream(file)
                mBitmap!!.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
                out.close()
                Constants.savedPath = Constants.path + "/" + fname
                Constants.isDataChanges = true
                if (!isShared && !isSetWallpaper) {
                    showSnackbar(getResources().getString(R.string.wallpaper_saved))
                    // Toast.makeText(this, "Wallpaper Saved.", Toast.LENGTH_SHORT).show();
                } else if (isSetWallpaper) {
                    // setWall();
                    showCustomDialog()
                } else {
                    shareWallpaper()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val scanIntent: Intent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri: Uri = Uri.fromFile(file)
                scanIntent.data = contentUri
                sendBroadcast(scanIntent)
            } else {
                val intent: Intent = Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://" + Environment.getExternalStorageDirectory()))
                sendBroadcast(intent)
            }
        }
    }

    private val outputBitmap: Bitmap?
        private get() {
            System.gc()
            Runtime.getRuntime().gc()
            val displayMetrics: DisplayMetrics = DisplayMetrics()
            windowManager.defaultDisplay.getMetrics(displayMetrics)
            val height: Int = displayMetrics.heightPixels
            val width: Int = displayMetrics.widthPixels

            try {
                val bitmap: Bitmap = Bitmap.createBitmap(mainFrame!!.width, mainFrame!!.height, Bitmap.Config.ARGB_8888)
                val canvas: Canvas = Canvas(bitmap)
                mainFrame!!.draw(canvas)
                return bitmap

            } catch (e: Exception) {
                return null
            }
        }

    public override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            READ_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (Constants.savedPath == null) {
                        showSaveDialog()
                    } else {
                        showSnackbar(getResources().getString(R.string.wallpaper_already_exist))
                        // Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            WALLPAPER_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showCustomDialog()
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            SHARE_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    shareWallpaper()
                } else {
                    val showRationale: Boolean = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, getResources().getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    fun pemissionDialog() {
        val alertDialog: android.app.AlertDialog
        val viewGroup: ViewGroup = findViewById(android.R.id.content)
        val dialogView: View = LayoutInflater.from(this).inflate(R.layout.permission_dialog, viewGroup, false)
        val builder1: android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(this)
        builder1.setView(dialogView)
        alertDialog = builder1.create()
        val cancel: Button = dialogView.findViewById(R.id.btnCancel)
        cancel.setOnClickListener { alertDialog.dismiss() }
        val ok: Button = dialogView.findViewById(R.id.btnOk)
        ok.setOnClickListener {
            startInstalledAppDetailsActivity(this@TextResolutionActivity)
            alertDialog.dismiss()
        }
        alertDialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }

    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i: Intent = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    override fun onRestart() {
        super.onRestart()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted
            startActivity(Intent(this@TextResolutionActivity, MainStartActivity::class.java))
            finish()
        }
    }

    public override fun onBackPressed() {
        finish()
    }

    override fun onResume() {
        super.onResume()
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }

    fun addTextSticker() {
        for (i in mAllSticker!!.indices) {
            val model: StickerModel = mAllSticker!![i]!!
            if (model.isText) {
                val strk: TextSticker = TextSticker(this@TextResolutionActivity)
                strk.drawable = (ContextCompat.getDrawable(applicationContext, R.drawable.sticker_transparent_background))!!
                if (model.typeface!!.contains("Solid Color Fonts/")) {
                    strk.setTypeface(Typeface.createFromFile(model.typeface))
                } else {
                    if (!model.typeface!!.contains("fonts_neon/")) {
                        model.typeface = "fonts_neon/" + model.typeface
                    }
                    strk.setTypeface(Typeface.createFromAsset(assets, model.typeface))
                }
                strk.text = model.getText()
                strk.setTextColor(model.textColor)
                strk.setTextAlign(Layout.Alignment.ALIGN_CENTER)
                strk.alpha = model.textAlhpa
                strk.resizeText()
                sticker_view!!.addSticker(strk)
            } else {
                val sticker1: DrawableSticker = DrawableSticker(model.drawable)
                sticker1.color = model.drawableColor
                sticker1.alpha = model.drawableAlpha
                sticker_view!!.addSticker(sticker1)
            }
        }
        sticker_view!!.post {
            imgWallpaper!!.post {
                for (i in sticker_view!!.stickers.indices) {
                    val sticker: Sticker = sticker_view!!.stickers[i]
                    sticker.setMatrix(mAllSticker!![i]!!.matrix)
                }
                sticker_view!!.invalidate()
                for (i in sticker_view!!.stickers.indices) {
                    val sticker: Sticker = sticker_view!!.stickers[i]
                    if (sticker is TextSticker) {
                        val sclW: Float = imgWallpaper!!.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        val sclH: Float = imgWallpaper!!.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val values: FloatArray = FloatArray(9)
                        resolutionModel!!.getmAllSticker()!![i]?.matrix!!.getValues(values)
                        val globalX: Float = values[Matrix.MTRANS_X]
                        val globalY: Float = values[Matrix.MTRANS_Y]
                        val scale1: Float = values[Matrix.MSCALE_X]
                        val scale2: Float = values[Matrix.MSCALE_Y]
                        val m0: Float = values[Matrix.MPERSP_0]
                        val m1: Float = values[Matrix.MPERSP_1]
                        val m2: Float = values[Matrix.MPERSP_2]
                        val mx: Float = values[Matrix.MSKEW_X]
                        val my: Float = values[Matrix.MSKEW_Y]
                        Log.d("TAG123==>", "run: " + sclW + "  =  " + scale1 + "               " + imgWallpaper!!.width)
                        Log.d("TAG123==>", "run: " + sclH + "  =  " + scale2 + "               " + imgWallpaper!!.height)
                        val matrix: MatrixClonable = MatrixClonable()
                        matrix.set(sticker.getMatrix())
                        matrix.postScale(sclW, sclH)
                        sticker.setMatrix(matrix)
                    } else {
                        val sclH: Float = imgWallpaper!!.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val sclW: Float = imgWallpaper!!.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        val matrix: MatrixClonable = MatrixClonable()
                        matrix.set(sticker.matrix)
                        matrix.postScale(sclW, sclH)
                        sticker.setMatrix(matrix)
                    }
                }
                sticker_view!!.invalidate()
                mainFrame!!.post { mBitmap = outputBitmap }
            }
        }
        try {
            if (Constants.mGalleryBitmap != null) {
                if (!Constants.mGalleryBitmap!!.isRecycled) {
                    imgFromG!!.setImageBitmap(Constants.mGalleryBitmap)
                }
            }


        } catch (e: Exception) {
            Log.d("EWEWEW", e.message!!)

        }
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?) {
        val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
        val shape: GradientDrawable = GradientDrawable(orientation, new_colors)
        shape.shape = GradientDrawable.RECTANGLE
        imgWallpaper!!.background = shape
    }

    private fun setCircleGradient(isInner: Boolean) {
        val metrics: DisplayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        if (!isInner) {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color2, resolutionModel!!.color1)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = metrics.widthPixels.toFloat()
            imgWallpaper!!.background = shape
        } else {
            val new_colors: IntArray = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
            val shape: GradientDrawable = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = metrics.widthPixels.toFloat()
            imgWallpaper!!.background = shape
        }
    }

    fun onClickSave(view: View?) {

    }

    companion object {
        private val TAG: String = "TextResolutionActivity"
        private val READ_PERMISSION: Int = 101
        private val WALLPAPER_PERMISSION: Int = 235
        private val SHARE_PERMISSION: Int = 452
    }
}