package com.hd.wallpaper.solid.color.background.model

class ScreenModel(var path: String, var isFree: Boolean)