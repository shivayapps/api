package com.hd.wallpaper.solid.color.background.model

class CategoryNameIconModel(var categoryName: String, var categoryIcon: String)