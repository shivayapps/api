package com.hd.wallpaper.solid.color.background.imagePicker.listener;

import android.view.View;


public interface OnImageClickListener {
    boolean onImageClick(View view, int position, boolean isSelected);
}
