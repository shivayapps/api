package com.hd.wallpaper.solid.color.background.activity

import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import java.util.*

class LiveandHDWallpaperActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_liveand_h_d_wallpaper)

        System.gc()

        SolidWallpaperApplication.staticLanguage.Factory.create(this)

        initViewAction()

    }

    private fun initViewAction() {

    }
}