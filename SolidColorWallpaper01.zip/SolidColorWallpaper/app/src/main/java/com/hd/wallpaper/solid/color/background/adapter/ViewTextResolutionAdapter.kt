package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.custom.MatrixClonable
import com.hd.wallpaper.solid.color.background.model.ResolutionModel
import com.hd.wallpaper.solid.color.background.model.StickerModel
import com.xiaopo.flying.sticker.DrawableSticker
import com.xiaopo.flying.sticker.StickerView
import com.xiaopo.flying.sticker.TextSticker
import java.util.*

class ViewTextResolutionAdapter(private val context: Context, private val mColors: ArrayList<ResolutionModel>) : PagerAdapter() {
    private var mAllSticker: ArrayList<StickerModel?>? = null
    private var resolutionModel: ResolutionModel? = null
    override fun getCount(): Int {
        return mColors.size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.layout_text_resolution_full_wallpaper, null)
        val sticker_view: StickerView
        val imgWallpaper: ImageView
        val mainFrame: FrameLayout
        sticker_view = view.findViewById(R.id.sticker_viewnew)
        imgWallpaper = view.findViewById(R.id.imgWallpaper)
        mainFrame = view.findViewById(R.id.mainFrame)
        sticker_view.isLocked = true
        mAllSticker = ArrayList()
        resolutionModel = mColors[position]
        mAllSticker!!.addAll(mColors[position].getmAllSticker()!!)
        addTextSticker(sticker_view, imgWallpaper)
        if (mColors[position].isCircle) {
            setCircleGradient(mColors[position].isInner, imgWallpaper)
        } else {
            setGradientDrawable(mColors[position].orientation, imgWallpaper)
        }
        val viewPager = container as ViewPager
        view.tag = "myview$position"
        viewPager.addView(view, 0)
        return view
    }

    fun addTextSticker(sticker_view: StickerView, imgWallpaper: ImageView) {
        for (i in mAllSticker!!.indices) {
            val model = mAllSticker!![i]
            if (model!!.isText) {
                val strk = TextSticker(context)
                strk.drawable = ContextCompat.getDrawable(context, R.drawable.sticker_transparent_background)!!
                strk.setTypeface(Typeface.createFromAsset(context.assets, model.typeface))
                strk.text = model.getText()
                strk.setTextColor(model.textColor)
                strk.setTextAlign(Layout.Alignment.ALIGN_CENTER)
                strk.alpha = model.textAlhpa
                strk.resizeText()
                sticker_view.addSticker(strk)
            } else {
                val sticker1 = DrawableSticker(model.drawable)
                sticker1.color = model.drawableColor
                sticker1.alpha = model.drawableAlpha
                sticker_view.addSticker(sticker1)
            }
        }
        sticker_view.post {
            imgWallpaper.post {
                for (i in sticker_view.stickers.indices) {
                    val sticker = sticker_view.stickers[i]
                    sticker.setMatrix(mAllSticker!![i]!!.matrix)
                }
                sticker_view.invalidate()
                for (i in sticker_view.stickers.indices) {
                    val sticker = sticker_view.stickers[i]
                    if (sticker is TextSticker) {
                        val sclH = imgWallpaper.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val sclW = imgWallpaper.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        val matrix = MatrixClonable()
                        matrix.set(sticker.getMatrix())
                        matrix.postScale(sclW, sclH)
                        sticker.setMatrix(matrix)
                    } else {
                        val sclH = imgWallpaper.height.toFloat() / resolutionModel!!.mainHeight.toFloat()
                        val sclW = imgWallpaper.width.toFloat() / resolutionModel!!.mainWidth.toFloat()
                        val matrix = MatrixClonable()
                        matrix.set(sticker.matrix)
                        matrix.postScale(sclW, sclH)
                        sticker.setMatrix(matrix)
                    }
                }
                sticker_view.invalidate()
            }
        }
    }

    private fun setGradientDrawable(orientation: GradientDrawable.Orientation?, imgWallpaper: ImageView) {
        val new_colors = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
        val shape = GradientDrawable(orientation, new_colors)
        shape.shape = GradientDrawable.RECTANGLE
        imgWallpaper.background = shape
    }

    private fun setCircleGradient(isInner: Boolean, imgWallpaper: ImageView) {
        if (!isInner) {
            val new_colors = intArrayOf(resolutionModel!!.color2, resolutionModel!!.color1)
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = 400f
            imgWallpaper.background = shape
        } else {
            val new_colors = intArrayOf(resolutionModel!!.color1, resolutionModel!!.color2)
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.RECTANGLE
            shape.colors = new_colors
            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
            shape.gradientRadius = 400f
            imgWallpaper.background = shape
        }
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        val viewPager = container as ViewPager
        val view = `object` as View
        viewPager.removeView(view)
    }

}