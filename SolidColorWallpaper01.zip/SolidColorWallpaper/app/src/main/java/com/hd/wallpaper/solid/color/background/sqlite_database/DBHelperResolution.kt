package com.hd.wallpaper.solid.color.background.sqlite_database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.Log
import com.hd.wallpaper.solid.color.background.custom.MatrixClonable
import com.hd.wallpaper.solid.color.background.model.GradientResolutionModel
import com.hd.wallpaper.solid.color.background.model.ResolutionModel
import com.hd.wallpaper.solid.color.background.model.StickerModel
import java.io.ByteArrayOutputStream
import java.util.*

class DBHelperResolution(private val mContext: Context) : SQLiteOpenHelper(mContext, DATABASE_NAME, null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table resolution " +
                        "(id integer primary key, width integer,height integer,colour_1 text,colour_2 text,iscircle text,isinner text,orientation integer)"
        )

        // TODO Auto-generated method stub
        db.execSQL(
                "create table resolution_gradient " +
                        "(id integer primary key, width integer,height integer,colour_1 text,colour_2 text,iscircle text,isinner text,orientation integer,emoji_path text,emoji_color text,emoji_opacity text)"
        )

        // TODO Auto-generated method stub
        db.execSQL(
                "create table stickers_gradient " +
                        "(id integer primary key,id_sticker integer,istext text,sticker_text text,sticker_typeface text,sticker_text_color text,sticker_text_alpha integer,sticker_drawable BLOB,sticker_drawable_color text,sticker_drawable_alpha integer,mtransx text,mtransy text,mscalex text,mscaley text,mskewx text,mskewy text)"
        )

        // TODO Auto-generated method stub
        db.execSQL(
                "create table stickers " +
                        "(id integer primary key,id_sticker integer,istext text,sticker_text text,sticker_typeface text,sticker_text_color text,sticker_text_alpha integer,sticker_drawable BLOB,sticker_drawable_color text,sticker_drawable_alpha integer,mtransx text,mtransy text,mscalex text,mscaley text,mskewx text,mskewy text)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS resolution")
        db.execSQL("DROP TABLE IF EXISTS stickers")
        onCreate(db)
    }

    fun insertResolutionModel(model: ResolutionModel) {
        deleteData()
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(RESOLUTION_COLUMN_WIDTH, model.mainWidth)
        contentValues.put(RESOLUTION_COLUMN_HEIGHT, model.mainHeight)
        contentValues.put(RESOLUTION_COLUMN_COLOUR_1, model.color1.toString())
        contentValues.put(RESOLUTION_COLUMN_COLOUR_2, model.color2.toString())
        contentValues.put(RESOLUTION_COLUMN_IS_CIRCLE, if (model.isCircle) "1" else "0")
        contentValues.put(RESOLUTION_COLUMN_IS_INNER, if (model.isInner) "1" else "0")
        contentValues.put(RESOLUTION_COLUMN_ORIENTAION, model.orientation!!.ordinal)
        db.insert("resolution", null, contentValues)
        db.close()
        insertIntoStickerTable(model.getmAllSticker()!!)
    }

    private fun insertIntoStickerTable(getmAllSticker: ArrayList<StickerModel?>) {
        val db = this.writableDatabase
        var mainID = 0
        val cursor = db.rawQuery("SELECT  * FROM resolution", null)
        if (cursor.moveToLast()) {
            mainID = cursor.getInt(0)
        }
        for (i in getmAllSticker.indices) {
            val contentValues = ContentValues()
            contentValues.put(STICKER_STICKER_ID, mainID)
            if (getmAllSticker[i]!!.isText) {
                contentValues.put(STICKER_TEXT, getmAllSticker[i]!!.text)
                contentValues.put(STICKER_TEXT_TYPEFACE, getmAllSticker[i]!!.typeface)
                contentValues.put(STICKER_TEXT_COLOR, getmAllSticker[i]!!.textColor.toString())
                contentValues.put(STICKER_TEXT_ALPHA, getmAllSticker[i]!!.textAlhpa)
            } else {
                System.gc()
                Runtime.getRuntime().gc()
                val bitmap = (getmAllSticker[i]!!.drawable as BitmapDrawable).bitmap
                val stream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                val bitmapdata = stream.toByteArray()
                contentValues.put(STICKER_DRAWABLE, bitmapdata)
                contentValues.put(STICKER_DRAWABLE_COLOR, getmAllSticker[i]!!.drawableColor.toString())
                contentValues.put(STICKER_DRAWABLE_ALPHA, getmAllSticker[i]!!.drawableAlpha)
            }
            Log.d("78912378445456", "insertIntoStickerTable: " + getmAllSticker[i]!!.isText)
            contentValues.put(STICKER_ISTEXT, if (getmAllSticker[i]!!.isText) "1" else "0")
            val values = FloatArray(9)
            getmAllSticker[i]!!.matrix!!.getValues(values)
            val globalX = values[Matrix.MTRANS_X]
            val globalY = values[Matrix.MTRANS_Y]
            val scale1 = values[Matrix.MSCALE_X]
            val scale2 = values[Matrix.MSCALE_Y]
            val mx = values[Matrix.MSKEW_X]
            val my = values[Matrix.MSKEW_Y]
            contentValues.put(MATRIX_MSCALEX, scale1)
            contentValues.put(MATRIX_MSCALEY, scale2)
            contentValues.put(MATRIX_MTRANSX, globalX)
            contentValues.put(MATRIX_MTRANSY, globalY)
            contentValues.put(MATRIX_MSKEW_X, mx)
            contentValues.put(MATRIX_MSKEW_Y, my)
            db.insert("stickers", null, contentValues)
        }
        db.close()
    }

    val resolutionModelList: ArrayList<ResolutionModel>
        get() {
            val cursor = writableDatabase.rawQuery("SELECT * FROM resolution", null)
            val employees = ArrayList<ResolutionModel>()
            if (cursor.moveToFirst()) {
                do {
                    val resolutionModel = ResolutionModel()
                    resolutionModel.mainWidth = cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_WIDTH))
                    resolutionModel.mainHeight = cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_HEIGHT))
                    resolutionModel.color1 = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_COLOUR_1)).toInt()
                    resolutionModel.color2 = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_COLOUR_2)).toInt()
                    resolutionModel.isCircle = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_IS_CIRCLE)) == "1"
                    resolutionModel.isInner = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_IS_INNER)) == "1"
                    resolutionModel.orientation = getOrientation(cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_ORIENTAION)))
                    resolutionModel.setmAllSticker(getAllSticker(cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_ID))))
                    employees.add(resolutionModel)
                } while (cursor.moveToNext())
            }
            cursor.close()
            return employees
        }

    private fun getOrientation(anInt: Int): GradientDrawable.Orientation {
        val orientation: GradientDrawable.Orientation
        orientation = when (anInt) {
            0 -> GradientDrawable.Orientation.TOP_BOTTOM
            1 -> GradientDrawable.Orientation.TR_BL
            2 -> GradientDrawable.Orientation.RIGHT_LEFT
            3 -> GradientDrawable.Orientation.BR_TL
            4 -> GradientDrawable.Orientation.BOTTOM_TOP
            5 -> GradientDrawable.Orientation.BL_TR
            6 -> GradientDrawable.Orientation.LEFT_RIGHT
            7 -> GradientDrawable.Orientation.TL_BR
            else ->                 // Should not get here as exception is thrown above if angle is not multiple
                // of 45 degrees
                GradientDrawable.Orientation.TOP_BOTTOM
        }
        return orientation
    }

    private fun getAllSticker(anInt: Int): ArrayList<StickerModel?> {
        val cursor = writableDatabase.rawQuery("SELECT * FROM stickers WHERE id_sticker=$anInt", null)
        val mStickerList = ArrayList<StickerModel?>()
        if (cursor.moveToFirst()) {
            do {
                val model = StickerModel()
                if (cursor.getString(cursor.getColumnIndex(STICKER_ISTEXT)) == "1") {
                    model.typeface = cursor.getString(cursor.getColumnIndex(STICKER_TEXT_TYPEFACE))
                    model.text = cursor.getString(cursor.getColumnIndex(STICKER_TEXT))
                    model.textColor = cursor.getString(cursor.getColumnIndex(STICKER_TEXT_COLOR)).toInt()
                    model.textAlhpa = cursor.getInt(cursor.getColumnIndex(STICKER_TEXT_ALPHA))
                } else {
                    val photo = cursor.getBlob(cursor.getColumnIndex(STICKER_DRAWABLE))
                    val image: Drawable = BitmapDrawable(mContext.resources, BitmapFactory.decodeByteArray(photo, 0, photo.size))
                    model.drawable = image
                    model.drawableAlpha = cursor.getInt(cursor.getColumnIndex(STICKER_DRAWABLE_ALPHA))
                    model.drawableColor = cursor.getString(cursor.getColumnIndex(STICKER_DRAWABLE_COLOR)).toInt()
                }
                model.isText = cursor.getString(cursor.getColumnIndex(STICKER_ISTEXT)) == "1"
                val values = FloatArray(9)
                values[Matrix.MTRANS_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MTRANSX)).toFloat()
                values[Matrix.MTRANS_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MTRANSY)).toFloat()
                values[Matrix.MSCALE_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MSCALEX)).toFloat()
                values[Matrix.MSCALE_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MSCALEY)).toFloat()
                values[Matrix.MSKEW_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MSKEW_X)).toFloat()
                values[Matrix.MSKEW_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MSKEW_Y)).toFloat()
                values[Matrix.MPERSP_0] = 0.0f
                values[Matrix.MPERSP_1] = 0.0f
                values[Matrix.MPERSP_2] = 1.0f
                val matrix = MatrixClonable()
                matrix.setValues(values)
                model.matrix = matrix
                mStickerList.add(model)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return mStickerList
    }

    fun insertResolutionModelGradient(model: GradientResolutionModel) {
        deleteData()
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(RESOLUTION_COLUMN_WIDTH, model.mainWidth)
        contentValues.put(RESOLUTION_COLUMN_HEIGHT, model.mainHeight)
        contentValues.put(RESOLUTION_COLUMN_COLOUR_1, model.color1.toString())
        contentValues.put(RESOLUTION_COLUMN_COLOUR_2, model.color2.toString())
        contentValues.put(RESOLUTION_COLUMN_IS_CIRCLE, if (model.isCircle) "1" else "0")
        contentValues.put(RESOLUTION_COLUMN_IS_INNER, if (model.isInner) "1" else "0")
        contentValues.put(RESOLUTION_COLUMN_ORIENTAION, model.orientation!!.ordinal)
        contentValues.put(RESOLUTION_COLUMN_EMOJI_PATH, model.emojiImage)
        contentValues.put(RESOLUTION_COLUMN_EMOJI_COLOR, model.emojiColor.toString())
        contentValues.put(RESOLUTION_COLUMN_EMOJI_OPACITY, model.opacityEmoji.toString())
        db.insert("resolution_gradient", null, contentValues)
        db.close()
        insertIntoStickerTableGradient(model.getmAllSticker()!!)
    }

    private fun deleteData() {
        try {
            val db = this.writableDatabase
            db.delete("resolution_gradient", null, null)
            db.delete("stickers_gradient", null, null)
            db.delete("stickers", null, null)
            db.delete("resolution", null, null)
            db.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun insertIntoStickerTableGradient(getmAllSticker: ArrayList<StickerModel>) {
        val db = this.writableDatabase
        var mainID = 0
        val cursor = db.rawQuery("SELECT  * FROM resolution_gradient", null)
        if (cursor.moveToLast()) {
            mainID = cursor.getInt(0)
        }
        for (i in getmAllSticker.indices) {
            val contentValues = ContentValues()
            contentValues.put(STICKER_STICKER_ID, mainID)
            if (getmAllSticker[i].isText) {
                contentValues.put(STICKER_TEXT, getmAllSticker[i].text)
                contentValues.put(STICKER_TEXT_TYPEFACE, getmAllSticker[i].typeface)
                contentValues.put(STICKER_TEXT_COLOR, getmAllSticker[i].textColor.toString())
                contentValues.put(STICKER_TEXT_ALPHA, getmAllSticker[i].textAlhpa)
            } else {
                System.gc()
                Runtime.getRuntime().gc()
                val bitmap = (getmAllSticker[i].drawable as BitmapDrawable).bitmap
                val stream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                val bitmapdata = stream.toByteArray()
                contentValues.put(STICKER_DRAWABLE, bitmapdata)
                contentValues.put(STICKER_DRAWABLE_COLOR, getmAllSticker[i].drawableColor.toString())
                contentValues.put(STICKER_DRAWABLE_ALPHA, getmAllSticker[i].drawableAlpha)
            }
            Log.d("78912378445456", "insertIntoStickerTable: " + getmAllSticker[i].isText)
            contentValues.put(STICKER_ISTEXT, if (getmAllSticker[i].isText) "1" else "0")
            val values = FloatArray(9)
            getmAllSticker[i].matrix!!.getValues(values)
            val globalX = values[Matrix.MTRANS_X]
            val globalY = values[Matrix.MTRANS_Y]
            val scale1 = values[Matrix.MSCALE_X]
            val scale2 = values[Matrix.MSCALE_Y]
            val mx = values[Matrix.MSKEW_X]
            val my = values[Matrix.MSKEW_Y]
            contentValues.put(MATRIX_MSCALEX, scale1)
            contentValues.put(MATRIX_MSCALEY, scale2)
            contentValues.put(MATRIX_MTRANSX, globalX)
            contentValues.put(MATRIX_MTRANSY, globalY)
            contentValues.put(MATRIX_MSKEW_X, mx)
            contentValues.put(MATRIX_MSKEW_Y, my)
            db.insert("stickers_gradient", null, contentValues)
        }
        db.close()
    }

    val resolutionModelGradientList: ArrayList<GradientResolutionModel>
        get() {
            val cursor = writableDatabase.rawQuery("SELECT * FROM resolution_gradient", null)
            val employees = ArrayList<GradientResolutionModel>()
            if (cursor.moveToFirst()) {
                do {
                    val resolutionModel = GradientResolutionModel()
                    resolutionModel.mainWidth = cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_WIDTH))
                    resolutionModel.mainHeight = cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_HEIGHT))
                    resolutionModel.color1 = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_COLOUR_1)).toInt()
                    resolutionModel.color2 = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_COLOUR_2)).toInt()
                    resolutionModel.isCircle = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_IS_CIRCLE)) == "1"
                    resolutionModel.isInner = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_IS_INNER)) == "1"
                    resolutionModel.orientation = getOrientation(cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_ORIENTAION)))
                    resolutionModel.setmAllSticker(getAllStickerGradient(cursor.getInt(cursor.getColumnIndex(RESOLUTION_COLUMN_ID))))
                    resolutionModel.emojiImage = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_EMOJI_PATH))
                    resolutionModel.emojiColor = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_EMOJI_COLOR)).toInt()
                    resolutionModel.opacityEmoji = cursor.getString(cursor.getColumnIndex(RESOLUTION_COLUMN_EMOJI_OPACITY)).toFloat()
                    employees.add(resolutionModel)
                } while (cursor.moveToNext())
            }
            cursor.close()
            return employees
        }

    private fun getAllStickerGradient(anInt: Int): ArrayList<StickerModel> {
        val cursor = writableDatabase.rawQuery("SELECT * FROM stickers_gradient WHERE id_sticker=$anInt", null)
        val mStickerList = ArrayList<StickerModel>()
        if (cursor.moveToFirst()) {
            do {
                val model = StickerModel()
                if (cursor.getString(cursor.getColumnIndex(STICKER_ISTEXT)) == "1") {
                    model.typeface = cursor.getString(cursor.getColumnIndex(STICKER_TEXT_TYPEFACE))
                    model.text = cursor.getString(cursor.getColumnIndex(STICKER_TEXT))
                    model.textColor = cursor.getString(cursor.getColumnIndex(STICKER_TEXT_COLOR)).toInt()
                    model.textAlhpa = cursor.getInt(cursor.getColumnIndex(STICKER_TEXT_ALPHA))
                } else {
                    val photo = cursor.getBlob(cursor.getColumnIndex(STICKER_DRAWABLE))
                    val image: Drawable = BitmapDrawable(mContext.resources, BitmapFactory.decodeByteArray(photo, 0, photo.size))
                    model.drawable = image
                    model.drawableAlpha = cursor.getInt(cursor.getColumnIndex(STICKER_DRAWABLE_ALPHA))
                    model.drawableColor = cursor.getString(cursor.getColumnIndex(STICKER_DRAWABLE_COLOR)).toInt()
                }
                model.isText = cursor.getString(cursor.getColumnIndex(STICKER_ISTEXT)) == "1"
                val values = FloatArray(9)
                values[Matrix.MTRANS_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MTRANSX)).toFloat()
                values[Matrix.MTRANS_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MTRANSY)).toFloat()
                values[Matrix.MSCALE_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MSCALEX)).toFloat()
                values[Matrix.MSCALE_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MSCALEY)).toFloat()
                values[Matrix.MSKEW_X] = cursor.getString(cursor.getColumnIndex(MATRIX_MSKEW_X)).toFloat()
                values[Matrix.MSKEW_Y] = cursor.getString(cursor.getColumnIndex(MATRIX_MSKEW_Y)).toFloat()
                values[Matrix.MPERSP_0] = 0.0f
                values[Matrix.MPERSP_1] = 0.0f
                values[Matrix.MPERSP_2] = 1.0f
                val matrix = MatrixClonable()
                matrix.setValues(values)
                model.matrix = matrix
                mStickerList.add(model)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return mStickerList
    }

    companion object {
        const val DATABASE_NAME = "Resolution3_012.db"
        const val RESOLUTION_COLUMN_ID = "id"
        const val RESOLUTION_COLUMN_WIDTH = "width"
        const val RESOLUTION_COLUMN_HEIGHT = "height"
        const val RESOLUTION_COLUMN_COLOUR_1 = "colour_1"
        const val RESOLUTION_COLUMN_COLOUR_2 = "colour_2"
        const val RESOLUTION_COLUMN_IS_CIRCLE = "iscircle"
        const val RESOLUTION_COLUMN_IS_INNER = "isinner"
        const val RESOLUTION_COLUMN_ORIENTAION = "orientation"
        const val RESOLUTION_COLUMN_EMOJI_PATH = "emoji_path"
        const val RESOLUTION_COLUMN_EMOJI_COLOR = "emoji_color"
        const val RESOLUTION_COLUMN_EMOJI_OPACITY = "emoji_opacity"
        const val STICKER_STICKER_ID = "id_sticker"
        const val STICKER_ISTEXT = "istext"
        const val STICKER_TEXT = "sticker_text"
        const val STICKER_TEXT_TYPEFACE = "sticker_typeface"
        const val STICKER_TEXT_COLOR = "sticker_text_color"
        const val STICKER_TEXT_ALPHA = "sticker_text_alpha"
        const val STICKER_DRAWABLE = "sticker_drawable"
        const val STICKER_DRAWABLE_COLOR = "sticker_drawable_color"
        const val STICKER_DRAWABLE_ALPHA = "sticker_drawable_alpha"
        const val MATRIX_MTRANSX = "mtransx"
        const val MATRIX_MTRANSY = "mtransy"
        const val MATRIX_MSCALEX = "mscalex"
        const val MATRIX_MSCALEY = "mscaley"
        const val MATRIX_MSKEW_X = "mskewx"
        const val MATRIX_MSKEW_Y = "mskewy"
    }

}