package com.hd.wallpaper.solid.color.background.imagePicker.listener;

import com.hd.wallpaper.solid.color.background.imagePicker.model.Folder;

public interface OnFolderClickListener {
    void onFolderClick(Folder folder);
}
