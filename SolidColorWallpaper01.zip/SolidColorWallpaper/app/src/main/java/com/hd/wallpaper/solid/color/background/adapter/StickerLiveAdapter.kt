package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.model.WallpaperWeekModel
import com.hd.wallpaper.solid.color.background.newModel.WallpaperWeekModelNewResponse
import java.util.*

class StickerLiveAdapter(private val mForegroundList: ArrayList<WallpaperWeekModelNewResponse?>?, private val mContext: Context, private val onItemSelectedListner: OnItemSelectedListner) : RecyclerView.Adapter<StickerLiveAdapter.MyViewholder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewholder {
        return MyViewholder(LayoutInflater.from(mContext).inflate(R.layout.rv_sticker_live, parent, false))
    }

    override fun onBindViewHolder(holder: MyViewholder, position: Int) {
        val model = mForegroundList?.get(position)
        holder.progressContent.visibility = View.VISIBLE
        holder.imgForeground.visibility = View.GONE
        holder.layoutLock.visibility = View.GONE
        holder.layoutWatchAd.visibility = View.GONE
        Glide.with(mContext).load(model!!.imageItem!!.image).override(400).into(object : CustomTarget<Drawable?>() {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
                holder.imgForeground.setImageDrawable(resource)
                holder.progressContent.visibility = View.GONE
                holder.imgForeground.visibility = View.VISIBLE

                /*if (model.isPremium()){
                    holder.layoutSubscribe.setVisibility(View.VISIBLE);
                    holder.layoutLock.setVisibility(View.GONE);
                }else*/
                /* if (!model.isLocked()){
                    holder.layoutSubscribe.setVisibility(View.GONE);
                    holder.layoutLock.setVisibility(View.GONE);
                }else {
                    holder.layoutSubscribe.setVisibility(View.GONE);
                    holder.layoutLock.setVisibility(View.VISIBLE);
                    holder.txtCoin.setText(String.valueOf(model.getCoins()));
                }*/
                if (!model.isLocked) {
                    holder.layoutWatchAd.visibility = View.GONE
                    holder.layoutLock.visibility = View.GONE
                } else if (model.coins <= 10) {
                    holder.layoutWatchAd.visibility = View.VISIBLE
                    holder.layoutLock.visibility = View.GONE
                } else {
                    holder.txtCoin.text = model.coins.toString()
                    holder.layoutLock.visibility = View.VISIBLE
                }
            }

            override fun onLoadCleared(placeholder: Drawable?) {
                holder.progressContent.visibility = View.GONE
                holder.imgForeground.visibility = View.VISIBLE
            }
        })
        holder.mainLayout.setOnClickListener { v: View? -> onItemSelectedListner.onItemClick(model, position) }
    }

    interface OnItemSelectedListner {
        fun onItemClick(model: WallpaperWeekModelNewResponse?, position: Int)
    }

    override fun getItemCount(): Int {
        return mForegroundList!!.size
    }

    inner class MyViewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgForeground: ImageView = itemView.findViewById(R.id.imgForeground)
        var mainLayout: RelativeLayout = itemView.findViewById(R.id.mainLayout)
        var progressContent: ProgressBar = itemView.findViewById(R.id.progressContent)
        var txtCoin: TextView = itemView.findViewById(R.id.txtCoin)
        var layoutLock: RelativeLayout = itemView.findViewById(R.id.layoutLock)
        var layoutWatchAd: RelativeLayout = itemView.findViewById(R.id.layoutWatchAd)

    }

}