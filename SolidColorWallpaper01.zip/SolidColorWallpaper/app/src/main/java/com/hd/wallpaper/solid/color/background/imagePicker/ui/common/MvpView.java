package com.hd.wallpaper.solid.color.background.imagePicker.ui.common;

public interface MvpView {
}
