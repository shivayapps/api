package com.hd.wallpaper.solid.color.background.PaintViewFol.drawing

import android.graphics.Bitmap

class BrushModel(var drawX: Float,var drawY:Float,var tipScale:Float, mPathLayer:Bitmap, tipSpeedAlpha:Float) {
}