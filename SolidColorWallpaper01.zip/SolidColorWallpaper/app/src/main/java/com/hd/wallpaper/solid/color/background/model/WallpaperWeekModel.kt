package com.hd.wallpaper.solid.color.background.model

import android.os.Parcel
import android.os.Parcelable
import com.hd.wallpaper.solid.color.background.model.api.ImageItem

class WallpaperWeekModel : Parcelable {
    var imageItem: ImageItem? = null
    var isLocked: Boolean
    var coins = 0

    constructor(imageItem: ImageItem?, isLocked: Boolean, coins: Int) {
        this.imageItem = imageItem
        this.coins = coins
        this.isLocked = isLocked
    }

    protected constructor(`in`: Parcel) {
        isLocked = `in`.readByte().toInt() != 0
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeByte((if (isLocked) 1 else 0).toByte())
    }
//
//    companion object {
//        val CREATOR: Parcelable.Creator<WallpaperWeekModel?> = object : Parcelable.Creator<WallpaperWeekModel?> {
//            override fun createFromParcel(`in`: Parcel): WallpaperWeekModel? {
//                return WallpaperWeekModel(`in`)
//            }
//
//            override fun newArray(size: Int): Array<WallpaperWeekModel?> {
//                return arrayOfNulls(size)
//            }
//        }
//    }
    companion object CREATOR : Parcelable.Creator<WallpaperWeekModel> {
        override fun createFromParcel(parcel: Parcel): WallpaperWeekModel {
            return WallpaperWeekModel(parcel)
        }

        override fun newArray(size: Int): Array<WallpaperWeekModel?> {
            return arrayOfNulls(size)
        }
    }
}