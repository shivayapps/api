package com.hd.wallpaper.solid.color.background.activity

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.app.Service
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.hd.wallpaper.solid.color.background.BuildConfig
import com.hd.wallpaper.solid.color.background.PaintViewFol.activity.PaintActivity
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.SolidWallpaperApplication
import com.hd.wallpaper.solid.color.background.constants.Constants
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import com.willy.ratingbar.ScaleRatingBar
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*

class ViewPaintActivity : AppCompatActivity(), View.OnClickListener {
    private val READ_PERMISSION = 101
    private val WALLPAPER_PERMISSION = 235
    private val SHARE_PERMISSION = 452
    private val REQUEST_CODE_MY_PICK = 123
    private var mainImg: ImageView? = null
    private var btnShare: ImageView? = null
    private var btnSave: ImageView? = null
    private var btnHome: ImageView? = null
    private var btnBack: ImageView? = null
    private var btnSetWallpaper: TextView? = null
    private var mBitmap: Bitmap? = null
    private var mainLayout: LinearLayout? = null
    private var mPermissionGranted = false
    private var mPermissionGrantedWallpaper = false
    private var isShared = false
    private var isSetWallpaper = false
    private val isCircle = false
    private var progressBar: ProgressDialog? = null

    private var mySharedPref: MySharedPref? = null
    private var vibrator: Vibrator? = null

    var bottomSheetFragment:BottomSheetFragment?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_paint)
        System.gc()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@ViewPaintActivity, MainStartActivity::class.java))
            finish()
        } else {
            Constants.savedPath = null
            mySharedPref = MySharedPref(this)
            progressBar = ProgressDialog(this@ViewPaintActivity)
            progressBar!!.setMessage(resources.getString(R.string.dialog_msg_please_wait))
            progressBar!!.setCancelable(false)
            if ( /*!mySharedPref.getAdsRemoved() &&*/!AdsPrefs.getBoolean(this@ViewPaintActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                Constants.isInstrastial1 = false
//                loadInterstialAd()
//                loadInterstialAdFb()
//                showGoogleAd()
            }
            initViews()
            initViewAction()
            initListner()
        }

        if (mySharedPref!!.countExist % 3 ==0 && mySharedPref!!.visitPlay == null) {
             showRateDialog()
        }
    }

    private fun initListner() {
        btnSave?.setOnClickListener(this)
        btnShare?.setOnClickListener(this)
        btnSetWallpaper?.setOnClickListener(this)
        btnHome?.setOnClickListener(this)
        btnBack?.setOnClickListener(this)
    }

    private fun initViewAction() {
        mBitmap = com.hd.wallpaper.solid.color.background.PaintViewFol.constant.Constants.mSavedBitmap
        if (mBitmap == null) {
            val previouslyEncodedImage = mySharedPref!!.image
            if (!previouslyEncodedImage.equals("", ignoreCase = true)) {
                try {
                    val b = Base64.decode(previouslyEncodedImage, Base64.DEFAULT)
                    mBitmap = BitmapFactory.decodeByteArray(b, 0, b.size)
                } catch (e: java.lang.Exception) {
                }

            }
        }
        if (mySharedPref!!.vibration) {
            vibrator = getSystemService(Service.VIBRATOR_SERVICE) as Vibrator
        }

        //  mainImg.setBackgroundColor(Color.TRANSPARENT);
//        mainLayout!!.setBackgroundColor(Constants.SOLID_CREATE_SELECTED_COLOR)
//        if (Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE != null) {
//            Glide.with(this).load(Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE).fitCenter().into(object : CustomTarget<Drawable?>() {
//               override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable?>?) {
//                    resource.colorFilter = PorterDuffColorFilter(Constants.SOLID_CREATE_SELECTED_EMOJI_IMAGE_COLOR, PorterDuff.Mode.SRC_IN)
//                    //    mainImg.setImageDrawable(resource);
//                }
//
//                override fun onLoadCleared(placeholder: Drawable?) {}
//            })
//        }
        mainImg!!.setImageBitmap(com.hd.wallpaper.solid.color.background.PaintViewFol.constant.Constants.mSavedBitmap)
        // mainImg.setAlpha(Constants.SOLID_CREATE_OPACITY);
    }

    private fun initViews() {
        mainImg = findViewById(R.id.mainImg)
        btnSave = findViewById<ImageView>(R.id.btnSave)
        btnSetWallpaper = findViewById(R.id.btnSetWallpaper)
        btnShare = findViewById<ImageView>(R.id.btnShare)
        btnHome = findViewById<ImageView>(R.id.btnHome)
        mainLayout = findViewById(R.id.mainLayout)
        btnBack = findViewById<ImageView>(R.id.btnBack)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btnSave -> {
                    isShared = false
                    isSetWallpaper = false
                    if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@ViewPaintActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), READ_PERMISSION)
                    } else {
                        mPermissionGranted = true
                    }
                    if (mPermissionGranted) {
                        if (Constants.savedPath == null) {
                            showSaveDialog()
                        } else {
                            showSnackBar(resources.getString(R.string.wallpaper_already_exist))
                            //   Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                        }
                    }
            }
            R.id.btnSetWallpaper -> {
                isShared = false
                isSetWallpaper = true
                if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.SET_WALLPAPER) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@ViewPaintActivity, arrayOf(Manifest.permission.SET_WALLPAPER), WALLPAPER_PERMISSION)
                } else {
                    mPermissionGrantedWallpaper = true
                }
                if (mPermissionGrantedWallpaper) {
                    showCustomDialog()
                }
            }
            R.id.btnShare -> {
                isShared = true
                isSetWallpaper = false
                shareWallpaper()
            }
            R.id.btnBack -> onBackPressed()
            R.id.btnHome -> {

                    startActivity(Intent(this@ViewPaintActivity, MainStartActivity::class.java))
                   // finish()
            }
        }
    }

    private fun setWall() {
        val uri = FileProvider.getUriForFile(this@ViewPaintActivity, BuildConfig.APPLICATION_ID + ".provider", File(Constants.savedPath))
        val intent = Intent("android.intent.action.ATTACH_DATA")
        intent.addCategory(Intent.CATEGORY_DEFAULT)
        intent.setDataAndType(uri, "image/jpeg")
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.putExtra("mimeType", "image/jpeg")
        startActivityForResult(Intent.createChooser(intent, resources.getString(R.string.set_as)), REQUEST_CODE_MY_PICK)
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("778945646465456", "onActivityResult: "+data);
        if (requestCode == REQUEST_CODE_MY_PICK) {
            assert data != null;
            String appName = data.getComponent().flattenToShortString();
            Log.d("778945646465456", "onActivityResult: "+appName);
        }
    }*/

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("778945646465456", "onActivityResult: "+data);
        if (requestCode == REQUEST_CODE_MY_PICK) {
            assert data != null;
            String appName = data.getComponent().flattenToShortString();
            Log.d("778945646465456", "onActivityResult: "+appName);
        }
    }*/

    private fun showCustomDialog() {
        btnSetWallpaper!!.isEnabled = false
        /* View v=View.inflate(this,R.layout.wallpaper_dialog_new,null);
        final BottomSheet.Builder builder1 = new BottomSheet.Builder(this);
        builder1.setView(v);
        builder1.show();

        builder1.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                btnSetWallpaper.setEnabled(true);
            }
        });*/
        val builder1 = BottomSheetDialog(this@ViewPaintActivity, R.style.BottomSheetDialog)
        val v = layoutInflater.inflate(R.layout.dialog_setwallpaper, null)
        builder1.setContentView(v)
        builder1.show()
        builder1.setOnDismissListener { btnSetWallpaper!!.isEnabled = true }
        val wallpaper = v.findViewById<LinearLayout>(R.id.btnHomeScreen)
        val bothwallpaper = v.findViewById<LinearLayout>(R.id.btnBoth)
        val lockscreen = v.findViewById<LinearLayout>(R.id.btnLockScreen)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            bothwallpaper.visibility = View.GONE
            lockscreen.visibility = View.GONE
        }
        lockscreen.setOnClickListener {
            mySharedPref!!.countExist = mySharedPref!!.countExist + 1
            builder1.dismiss()
            progressBar!!.show()
            Handler().postDelayed({ // progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countExist >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewPaintActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewPaintActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ lockScreenWallpaper() }, 400)
        }
        wallpaper.setOnClickListener {
            builder1.dismiss()
            //   Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_SHORT).show();
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //   progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewPaintActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewPaintActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({ onclickWallpaper(false) }, 400)
        }
        bothwallpaper.setOnClickListener {
            builder1.dismiss()
            //  Toast.makeText(ViewGradientCreatedWallpaperActivity.this, "Please Wait...", Toast.LENGTH_LONG).show();
            mySharedPref!!.countCreated = mySharedPref!!.countCreated + 1
            progressBar!!.show()
            Handler().postDelayed({ //   progressBar.dismiss();
                btnSetWallpaper!!.isEnabled = true
                if (mySharedPref!!.countCreated >= 3 && mySharedPref!!.visitPlay == null) {
                    //showRateDialog()
                }
            }, 3000)
            if (mySharedPref!!.alarmId != -1) {
                DBHelperAutoWallpaper(this@ViewPaintActivity).updateData()
                cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@ViewPaintActivity, EventReceiver::class.java)
            }
            Handler().postDelayed({
                onclickWallpaper(true)
                lockScreenWallpaper()
            }, 400)
        }
    }

    private fun showRateDialog() {
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_rate_app, viewGroup, false)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        val alertDialog = builder.create()
        Objects.requireNonNull(alertDialog.window)?.setBackgroundDrawableResource(android.R.color.transparent)
        alertDialog.setOnCancelListener { alertDialog.dismiss() }
        val btnClose = dialogView.findViewById<ImageView>(R.id.btnClose)
        btnClose.setOnClickListener { alertDialog.dismiss() }
        val ratingBar1: ScaleRatingBar = dialogView.findViewById(R.id.ratingBar)
        ratingBar1.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            if (rating > 3) {
                rate_app()
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
            } else {
                mySharedPref!!.setVisitPlay()
                //  Toast.makeText(ViewPaintActivity.this, getResources().getString(R.string.thanks_for_review), Toast.LENGTH_SHORT).show();
                Toast.makeText(this, "Thanks for review", Toast.LENGTH_SHORT).show()
                Handler().postDelayed({ alertDialog.dismiss() }, 1000)
            }
        }

        dialogView.findViewById<View>(R.id.btnNextTime).setOnClickListener {
            mySharedPref!!.countExist = 0
            alertDialog.dismiss()
        }
        if (!this@ViewPaintActivity.isFinishing) {

            alertDialog.show()
        }
    }

//    private fun sendMail() {
//        mySharedPref!!.setVisitPlay()
//        /*    Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
//        emailIntent.setType("text/plain");
//        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"profagnesh009@gmail.com"});
//        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Share your valuable feedback with us to improve app quality and add more features in Solid Color Wallpaper");
//        emailIntent.setType("message/rfc822");
//        try {
//            startActivity(Intent.createChooser(emailIntent,
//                    "Send email using..."));
//        } catch (android.content.ActivityNotFoundException ex) {
//            Toast.makeText(this,
//                    "No email clients installed.",
//                    Toast.LENGTH_SHORT).show();
//        }*/
//        val send = Intent(Intent.ACTION_SENDTO)
//        val uriText = "mailto:" + Uri.encode("profagnesh009@gmail.com") +
//                "?subject=" + Uri.encode("Share valuable feedback to improve app quality of Solid Color Wallpaper") +
//                "&body=" + Uri.encode("")
//        val uri = Uri.parse(uriText)
//        send.data = uri
//        startActivity(Intent.createChooser(send, "Send Email..."))
//    }

    private fun rate_app() {
        mySharedPref!!.setVisitPlay()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (anfe: ActivityNotFoundException) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
        }
    }

    private fun lockScreenWallpaper() {
        // mBitmap=getOutputBitmap();
        if (mBitmap != null) {
            val wm = WallpaperManager.getInstance(this)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wm.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_LOCK) //For Lock screen
                    progressBar!!.dismiss()
                    if (vibrator != null) {
                        if (Build.VERSION.SDK_INT >= 26) {
                            vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                        } else {
                            vibrator!!.vibrate(200)
                        }
                    }
                    //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                    showSnackBar(resources.getString(R.string.toast_wallpaper_set_seccessfully))
                } else {
                    Toast.makeText(this, "Lock Screen Wallpaper Not Supported",
                            Toast.LENGTH_SHORT).show()
                    //   MusicLibrary.setImageWallpaper(mBitmap);
                    //    mMediaBrowserHelper.getTransportControls().play();
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun showSaveDialog() {
        /*  final AlertDialog alertDialog;
        ViewGroup viewGroup = findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.custom_save_dialog, viewGroup, false);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        alertDialog = builder.create();
        alertDialog.show();

        Button save = dialogView.findViewById(R.id.btnSave);
        Button cancel = dialogView.findViewById(R.id.btnCancel);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                onclickSave();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });*/
         bottomSheetFragment = BottomSheetFragment(resources.getString(R.string.save), resources.getString(R.string.do_you_want_to_save), resources.getString(R.string.save), resources.getString(R.string.cancel), R.drawable.ic_save_dialog, object : BottomSheetFragment.OnButtonClickListener {
            override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                bottomSheetDialo!!.dismiss()
                onclickSave()
            }

            override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(supportFragmentManager, "dialog")
    }

    override fun onPause() {
        super.onPause()

        try {
            bottomSheetFragment!!.dismiss()
        }catch (e:Exception){

        }
    }

    private fun shareWallpaper() {
        if (Constants.savedPath == null) {
            if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this@ViewPaintActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), SHARE_PERMISSION)
            } else {
                mPermissionGranted = true
            }
            if (mPermissionGranted) {
                onclickSave()
            }
        } else {
            val uri = FileProvider.getUriForFile(this@ViewPaintActivity, BuildConfig.APPLICATION_ID + ".provider", File(Constants.savedPath))
            if (uri != null) {
                val intent = Intent(Intent.ACTION_SEND)
                intent.type = "image/jpeg"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                var shareMessage = ""
                shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=com.solid.color.wallpaper.hd.image.background"
                intent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                startActivityForResult(Intent.createChooser(intent, resources.getString(R.string.share_wallpaper)), 100)

                /*   final BottomSheetDialog dialog = new BottomSheetDialog(ViewPaintActivity.this,R.style.BottomSheetDialog);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                View sheetView = ViewPaintActivity.this.getLayoutInflater().inflate(R.layout.dialog_chooser, null);
                dialog.setContentView(sheetView);


                List<ResolveInfo> launchables=getPackageManager().queryIntentActivities(intent, 0);
                Collections.sort(launchables,new ResolveInfo.DisplayNameComparator(getPackageManager()));

                RecyclerView recyclerAds=sheetView.findViewById(R.id.recyclerAds);
                LinearLayoutManager manager=new LinearLayoutManager(ViewPaintActivity.this,RecyclerView.HORIZONTAL,false);
                recyclerAds.setLayoutManager(manager);

                AppsAdapter.onSelectApp app=new AppsAdapter.onSelectApp() {
                    @Override
                    public void onClickApp(int i) {
                        dialog.dismiss();

                        ResolveInfo launchable=launchables.get(i);
                        ActivityInfo activity=launchable.activityInfo;
                        ComponentName name=new ComponentName(activity.applicationInfo.packageName,
                                activity.name);
                        intent.addCategory(Intent.CATEGORY_LAUNCHER);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                        intent.setComponent(name);
                        startActivity(intent);

                    }
                };

                AppsAdapter adapter=new AppsAdapter(ViewPaintActivity.this,launchables, getPackageManager(), app);
                recyclerAds.setAdapter(adapter);

                dialog.show();*/
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 100 && !AdsPrefs.getBoolean(this, AdsPrefs.IS_SUBSCRIBED, false)) {
//            if (SolidWallpaperApplication.instance!!.requestNewInterstitial()) {
//                SolidWallpaperApplication.instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                    override fun onAdClosed() {
//                        super.onAdClosed()
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdFailedToLoad(i: Int) {
//                        super.onAdFailedToLoad(i)
//                        loadInterstialAd()
//                    }
//
//                    override fun onAdLoaded() {
//                        super.onAdLoaded()
//                    }
//                }
//            }
//        }
    }

    private fun onclickWallpaper(isBoth: Boolean) {
        // mBitmap = getOutputBitmap();
        if (mBitmap != null) {
            val wallpaperManager = WallpaperManager.getInstance(applicationContext)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    wallpaperManager.setBitmap(mBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                } else {
                    wallpaperManager.setBitmap(mBitmap)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (!isBoth) {
                progressBar!!.dismiss()
                if (vibrator != null) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator!!.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        vibrator!!.vibrate(200)
                    }
                }
                //Toast.makeText(WallpaperViewActivity.this, "Wallpaper Set Successfully.", Toast.LENGTH_SHORT).show();
                showSnackBar(resources.getString(R.string.toast_wallpaper_set_seccessfully))
            }
        } else {
            showSnackBar(resources.getString(R.string.try_again_later))
            //Toast.makeText(this, "Try Again Later!", Toast.LENGTH_SHORT).show();
        }
    }

    private fun showSnackBar(msg: String) {
        val snackbar = Snackbar.make(findViewById(R.id.mainContainer), msg, Snackbar.LENGTH_SHORT)
        val v = snackbar.view
        val params = v.layoutParams as CoordinatorLayout.LayoutParams
        params.gravity = Gravity.BOTTOM
        params.width = FrameLayout.LayoutParams.MATCH_PARENT
        v.layoutParams = params
        v.setBackgroundColor(Color.WHITE)
        val textView = v.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
        textView.setTextColor(resources.getColor(R.color.text_colour_new))
        snackbar.show()
    }

    private fun onclickSave() {
        // mBitmap = getOutputBitmap();
        if (mBitmap != null) {
            val myDir = File(Constants.path)
            myDir.mkdirs()
            val fname = "PAINT_" + System.currentTimeMillis() / 1000 + ".png"
            val file = File(myDir, fname)
            var out: FileOutputStream? = null
            try {
                out = FileOutputStream(file)
                mBitmap!!.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
                out.close()
                Constants.savedPath = Constants.path + "/" + fname
                Constants.isDataChanges = true
                if (!isShared && !isSetWallpaper) {
                    showSnackBar(resources.getString(R.string.wallpaper_saved))
                    // Toast.makeText(this, "Wallpaper Saved.", Toast.LENGTH_SHORT).show();
                } else if (isSetWallpaper) {
                    setWall()
                } else {
                    shareWallpaper()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val scanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                val contentUri = Uri.fromFile(file)
                scanIntent.data = contentUri
                sendBroadcast(scanIntent)
            } else {
                val intent = Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://" + Environment.getExternalStorageDirectory()))
                sendBroadcast(intent)
            }
        }
    }

    private fun getOutputBitmap(): Bitmap? {
        val bitmap = Bitmap.createBitmap(mainLayout!!.width, mainLayout!!.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        if (Constants.SOLID_CREATE_SELECTED_COLOR == Color.TRANSPARENT) {
            mainImg!!.draw(canvas)
        } else {
            mainLayout!!.draw(canvas)
        }
        return bitmap
    }

    private fun setStatusbarColor(color: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = color
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = color
        }
    }

//    private fun loadInterstialAd() {
//        if (SolidWallpaperApplication.instance!!.mInterstitialAd!!.isLoaded) {
//            //Log.e("if", "if");
//            //iv_moreapp.setVisibility(View.VISIBLE);
//        } else {
//            SolidWallpaperApplication.instance!!.mInterstitialAd!!.adListener = null
//            SolidWallpaperApplication.instance!!.mInterstitialAd = null
//            SolidWallpaperApplication.instance!!.ins_adRequest = null
//            SolidWallpaperApplication.instance!!.LoadAds()
//            SolidWallpaperApplication.instance!!.mInterstitialAd!!.adListener = object : AdListener() {
//                override fun onAdLoaded() {
//                    super.onAdLoaded()
//                    //Log.e("load", "load");
//                    //iv_moreapp.setVisibility(View.VISIBLE);
//                }
//
//                override fun onAdFailedToLoad(i: Int) {
//                    super.onAdFailedToLoad(i)
//                    //Log.e("fail", "fail");
//                    //iv_moreapp.setVisibility(View.GONE);
//                    //ColoringApplication.getInstance().LoadAds();
//                    loadInterstialAd()
//                    loadInterstialAdFb()
//                }
//            }
//        }
//    }
//
//    private fun loadInterstialAdFb() {
//        if (SolidWallpaperApplication.instance!!.mInterstitialAdfb!!.isAdLoaded) {
//        } else {
//            SolidWallpaperApplication.instance!!.mInterstitialAdfb!!.setAdListener(null)
//            SolidWallpaperApplication.instance!!.mInterstitialAdfb = null
//            SolidWallpaperApplication.instance!!.LoadAdsFb()
//            SolidWallpaperApplication.instance!!.mInterstitialAdfb!!.setAdListener(object : InterstitialAdListener {
//                override fun onError(ad: Ad, adError: AdError) {
//                    //loadInterstialAdFb();
//                    loadInterstialAd()
//                }
//
//                override fun onAdLoaded(ad: Ad) {}
//                override fun onAdClicked(ad: Ad) {}
//                override fun onLoggingImpression(ad: Ad) {}
//                override fun onInterstitialDisplayed(ad: Ad) {}
//                override fun onInterstitialDismissed(ad: Ad) {
//                    loadInterstialAdFb()
//                }
//            })
//        }
//    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            READ_PERMISSION -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (Constants.savedPath == null) {
                        showSaveDialog()
                    } else {
                        showSnackBar(resources.getString(R.string.wallpaper_already_exist))
                        //    Toast.makeText(this, "Wallpaper Already Exist.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, resources.getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            WALLPAPER_PERMISSION -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    //showCustomDialog();
                    onclickSave()
                } else {
                    val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, resources.getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
            SHARE_PERMISSION -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    shareWallpaper()
                } else {
                    val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SET_WALLPAPER)
                    if (!showRationale) {
                        pemissionDialog()
                    }
                    Toast.makeText(this, resources.getString(R.string.permission_required), Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }


    fun pemissionDialog() {
        val alertDialog: android.app.AlertDialog
        val viewGroup = findViewById<ViewGroup>(android.R.id.content)
        val dialogView = LayoutInflater.from(this).inflate(R.layout.permission_dialog, viewGroup, false)
        val builder1 = android.app.AlertDialog.Builder(this)
        builder1.setView(dialogView)
        alertDialog = builder1.create()
        val cancel = dialogView.findViewById<Button>(R.id.btnCancel)
        cancel.setOnClickListener { alertDialog.dismiss() }
        val ok = dialogView.findViewById<Button>(R.id.btnOk)
        ok.setOnClickListener {
            startInstalledAppDetailsActivity(this@ViewPaintActivity)
            alertDialog.dismiss()
        }
        alertDialog.show()
    }


    fun startInstalledAppDetailsActivity(context: Activity?) {
        if (context == null) {
            return
        }
        val i = Intent()
        i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        i.addCategory(Intent.CATEGORY_DEFAULT)
        i.data = Uri.parse("package:" + context.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
        i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        context.startActivity(i)
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onRestart() {
        super.onRestart()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            startActivity(Intent(this@ViewPaintActivity, MainStartActivity::class.java))
            finish()
        }
    }

    override fun onBackPressed() {
//        startActivity(Intent(this,PaintActivity::class.java))
        finish()
    }

    override fun onResume() {
        super.onResume()
        if (mBitmap == null) {
            val previouslyEncodedImage = mySharedPref!!.image
            if (!previouslyEncodedImage.equals("", ignoreCase = true)) {
                try {
                    val b = Base64.decode(previouslyEncodedImage, Base64.DEFAULT)
                    mBitmap = BitmapFactory.decodeByteArray(b, 0, b.size)
                } catch (e: java.lang.Exception) {
                }
            }
        }
        SolidWallpaperApplication.staticLanguage.Factory.create(this)
    }
}