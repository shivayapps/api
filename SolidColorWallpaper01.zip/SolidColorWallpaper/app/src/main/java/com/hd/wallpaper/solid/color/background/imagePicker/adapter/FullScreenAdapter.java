package com.hd.wallpaper.solid.color.background.imagePicker.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;


import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.hd.wallpaper.solid.color.background.R;
import com.hd.wallpaper.solid.color.background.imagePicker.model.Image;
import com.hd.wallpaper.solid.color.background.imagePicker.widget.ExpandableImageViewTouch;

import java.util.List;

public class FullScreenAdapter extends PagerAdapter {
    private Context context;
    private List<Image> al_my_photos;


    public FullScreenAdapter(Context context, List<Image> al_my_photos) {
        this.context = context;
        this.al_my_photos=al_my_photos;
    }

    @Override
    public int getCount() {
        return al_my_photos.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.gallery_fullimage_item, null);

        //  TouchImageView  iv = view.findViewById(R.id.adapterImage);
        final ExpandableImageViewTouch iv = view.findViewById(R.id.adapterImage);
        final ProgressBar progressBar=view.findViewById(R.id.progressBar);

        Glide.with(context).asBitmap().load(al_my_photos.get(position).getPath()).override(720,1200)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        progressBar.setVisibility(View.GONE);
                        iv.setImageBitmap(resource);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                        progressBar.setVisibility(View.GONE);
                    }
                });

        ViewPager viewPager = (ViewPager) container;



        viewPager.addView(view, 0);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        ViewPager viewPager = (ViewPager) container;
        View view = (View) object;
        viewPager.removeView(view);
    }
}
