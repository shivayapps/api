package com.hd.wallpaper.solid.color.background.activity

import android.app.AlarmManager
import android.app.Dialog
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver
import com.auto.wallpaper.live.background.changer.editor.receiver.EventReceiver.Companion.cancelAlarm
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.activity.AutoWallpaperChangerBackupActivity
import com.hd.wallpaper.solid.color.background.activity.PremiumAccessActivity
import com.hd.wallpaper.solid.color.background.adapter.LiveWallpaperListAdapter
import com.hd.wallpaper.solid.color.background.adapter.LiveWallpaperListAdapter.OnSelectAction
import com.hd.wallpaper.solid.color.background.adapter.SettingsRecyclerAdapter
import com.hd.wallpaper.solid.color.background.adapter.SettingsRecyclerAdapter.OnLongClicked
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragment
import com.hd.wallpaper.solid.color.background.custom.BottomSheetFragmentDiscard
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.fragment.*
import com.hd.wallpaper.solid.color.background.model.*
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs
import com.hd.wallpaper.solid.color.background.shared_pref.AdsPrefs.getBoolean
import com.hd.wallpaper.solid.color.background.shared_pref.MySharedPref
import com.hd.wallpaper.solid.color.background.sqlite_database.DBHelperAutoWallpaper
import java.io.*
import java.util.*

class AutoWallpaperChangerBackupActivity constructor() : AppCompatActivity(), View.OnClickListener {
    private var btnNext: ImageView? = null
    private var btnShare: ImageView? = null
    private var icSubcription: ImageView? = null
    private var icBack: ImageView? = null
    var bottomSheetFragment:BottomSheetFragmentDiscard?=null
    private var imgCreationDD: ImageView? = null
    private var imgSolidDD: ImageView? = null
    private var btnAddWallpaper: ConstraintLayout? = null
    private var layoutMainWallpaperList: ConstraintLayout? = null
    private var layoutSelectWallpaper: ConstraintLayout? = null
    private var selectDDCreation: ConstraintLayout? = null
    private var selectDDSolid: ConstraintLayout? = null
    private var cstMainSettings: ConstraintLayout? = null
    private var bottomButtonEditSettings: ConstraintLayout? = null
    private var bottomButtonLayoutSettings: ConstraintLayout? = null
    private var layoutTopSetting: ConstraintLayout? = null
    private var llScreenMode: ConstraintLayout? = null
    private var llDelayTime: ConstraintLayout? = null
    private var layoutNoWallpaper: ConstraintLayout? = null
    private var recyclerSelectedWallpaper: RecyclerView? = null
    private var recyclerMainWallpaer: RecyclerView? = null
    private var isSelectWallpaperMenuOpen: Boolean = false
    private var solidSelectableFragment: SolidSelectableFragment? = null
    private var gradientSelectableFragment: GradientSelectableFragment? = null
    private var textSelectableFragment: TextSelectableFragment? = null
    private var creationSelectableFragment: CreationSelectableFragment? = null
    private var gallerySelectableFragment: GallerySelectableFragment? = null
    private var solidSingleSelectableFragment: SolidSingleSelectableFragment? = null
    private var gradientSingleSelectableFragment: GradientSingleSelectableFragment? = null
    private var textSingleSelectableFragment: TextSingleSelectableFragment? = null
    private var creationSingleSelectableFragment: CreationSingleSelectableFragment? = null
    private var gallerySingleSelectableFragment: GallerySingleSelectableFragment? = null
    private var txtCreationDD: TextView? = null
    private var txtSolidDD: TextView? = null
    private var btnApplyWallpaperSettings: TextView? = null
    private var btnAddWallpaperSettings: TextView? = null
    private var txtScreenMode: TextView? = null
    private var txtDelayTime: TextView? = null
    private var btnDeleteWallpaperSettings: TextView? = null
    private var btnEditWallpaperSettings: TextView? = null
    private var spinnerSolidDD: Spinner? = null
    private var spinnerCreationDD: Spinner? = null
    private val items: Array<String> = arrayOf("Solid", "Gradient", "Text")
    private val items2: Array<String> = arrayOf("Creation", "Gallery")
    private var frameGallery: FrameLayout? = null
    private var frameCreation: FrameLayout? = null
    private var frameText: FrameLayout? = null
    private var frameGradient: FrameLayout? = null
    private var frameSolid: FrameLayout? = null
    private var isFirstS: Boolean = false
    private var isFirstC: Boolean = false
    private var isFirstS1: Boolean = false
    private var isFirstC1: Boolean = false
    private var positionSolid: Int = 0
    private var positionCreation: Int = 0
    private var progressFragment: ProgressBar? = null
    private var progressRecycler: ProgressBar? = null
    private var mSelectedList: ArrayList<Any>? = null
    private var delayTime: String? = "Random"
    private var screenMode: String? = "Home Screen"
    private var mBitmapList: ArrayList<Bitmap>? = null
    private var mSelectedImagesList: ArrayList<SettingsImagesModel>? = null
    private var dbHelperAutoWallpaper: DBHelperAutoWallpaper? = null
    private var isLongClicked: Boolean = false
    private var settingsRecyclerAdapter: SettingsRecyclerAdapter? = null
    private var isAddMenuOpen: Boolean = false
    private var isEditOpen: Boolean = false
    private var isApplyClicked: Boolean = false
    private var isSettingsOpen: Boolean = false
    private var settingsImagesModelEdit: SettingsImagesModel? = null
    private var mAllWallpaperList: ArrayList<AutoWallpaperModel>? = null
    private var liveWallpaperAdapter: LiveWallpaperListAdapter? = null
    private var glideLoadImageCount: Int = 0
    private var imageList: ArrayList<String>? = null
    private var isEditSettingsOpen: Boolean = false
    private var mySharedPref: MySharedPref? = null
    private var isEditClicked: Boolean = false
    private var autoWallpaperModelEdit: AutoWallpaperModel? = null
    var bottomSheetFragments:BottomSheetFragment?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auto_wallpaper_changer_backup)
        mySharedPref = MySharedPref(this)
        initViews()
        initListner()
        initViewAction()
    }

    private fun initViewAction() {
        if (getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            btnShare!!.setVisibility(View.VISIBLE)
            icSubcription!!.setVisibility(View.GONE)
        } else {
            btnShare!!.setVisibility(View.GONE)
            icSubcription!!.setVisibility(View.VISIBLE)
        }
        mAllWallpaperList = ArrayList()
        dbHelperAutoWallpaper = DBHelperAutoWallpaper(this@AutoWallpaperChangerBackupActivity)
        val cacheDir: String = "/Pictures/.autowallpaper"
        val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
        Log.d("78911789789126", "initViewAction: " + fullCacheDir.exists())
        mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        if (mAllWallpaperList!!.size > 0 && fullCacheDir.exists()) {
            recyclerMainWallpaer!!.visibility = View.VISIBLE
            layoutNoWallpaper!!.visibility = View.GONE
            recyclerMainWallpaer!!.layoutManager = LinearLayoutManager(this@AutoWallpaperChangerBackupActivity, RecyclerView.VERTICAL, false)
            liveWallpaperAdapter = LiveWallpaperListAdapter(mAllWallpaperList!!, this@AutoWallpaperChangerBackupActivity, object : OnSelectAction {
                public override fun onPlay(autoWallpaperModel: AutoWallpaperModel?) {
                    dbHelperAutoWallpaper!!.updateDataRow(autoWallpaperModel!!.id)
                    setAlarmAuto(autoWallpaperModel)
                }

                public override fun onEdit(autoWallpaperModel: AutoWallpaperModel?) {
                    editWallpaper(autoWallpaperModel)
                }

                public override fun onDelete(autoWallpaperModel: AutoWallpaperModel?) {
                    showRemoveDialog(autoWallpaperModel)
                }
            })
            recyclerMainWallpaer!!.adapter = liveWallpaperAdapter
        } else {
            dbHelperAutoWallpaper!!.deleteAllData()
            recyclerMainWallpaer!!.visibility = View.GONE
            layoutNoWallpaper!!.visibility = View.VISIBLE
        }
        mBitmapList = ArrayList()
        mSelectedImagesList = ArrayList()
        val manager: GridLayoutManager = GridLayoutManager(this@AutoWallpaperChangerBackupActivity, 3)
        recyclerSelectedWallpaper!!.layoutManager = manager
        recyclerSelectedWallpaper!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(6), true))
        recyclerSelectedWallpaper!!.itemAnimator = DefaultItemAnimator()
    }

    private fun editWallpaper(autoWallpaperModel: AutoWallpaperModel?) {
        screenMode = autoWallpaperModel!!.screenmode
        delayTime = autoWallpaperModel.delaytime
        autoWallpaperModelEdit = autoWallpaperModel
        layoutMainWallpaperList!!.animate().translationYBy(-layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
        recyclerSelectedWallpaper!!.visibility = View.GONE
        cstMainSettings!!.visibility = View.VISIBLE
        progressRecycler!!.visibility = View.VISIBLE
        layoutTopSetting!!.visibility = View.VISIBLE
        txtDelayTime!!.text = autoWallpaperModel.delaytime
        txtScreenMode!!.text = autoWallpaperModel.screenmode
        isEditClicked = true
        val gson: Gson = Gson()
        val token: TypeToken<ArrayList<String?>?> = object : TypeToken<ArrayList<String?>?>() {}
        imageList = gson.fromJson(autoWallpaperModel.imagespath, token.type)
        Handler().postDelayed({
            LoadImages().execute()
            isEditSettingsOpen = true
        }, 300)
        isSettingsOpen = true
        bottomButtonLayoutSettings!!.visibility = View.INVISIBLE
        layoutTopSetting!!.post {
            Log.d(TAG, "onclickDone: " + cstMainSettings!!.height)
            layoutTopSetting!!.translationY = -layoutTopSetting!!.height.toFloat()
            Handler().postDelayed({ layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.height.toFloat()).setDuration(300).start() }, 100)
            layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.height.toFloat()).withEndAction {
                bottomButtonLayoutSettings!!.visibility = View.VISIBLE
                bottomButtonLayoutSettings!!.translationY = bottomButtonLayoutSettings!!.height.toFloat()
                bottomButtonLayoutSettings!!.post { bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.height.toFloat()).setDuration(300).start() }
            }.setDuration(300).start()
            if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                icSubcription!!.animate().alpha(0f).withEndAction {
                    Log.d(TAG, "run: ")
                    icSubcription!!.visibility = View.INVISIBLE
                    isSelectWallpaperMenuOpen = false
                }.setDuration(300).start()
                btnNext!!.visibility = View.VISIBLE
                btnNext!!.animate().alpha(1f).setDuration(300).start()
            } else {
                btnShare!!.animate().alpha(0f).withEndAction {
                    btnShare!!.visibility = View.INVISIBLE
                    isSelectWallpaperMenuOpen = false
                }.setDuration(300).start()
                btnNext!!.visibility = View.VISIBLE
                btnNext!!.animate().alpha(1f).setDuration(300).start()
            }
            isSelectWallpaperMenuOpen = false
        }
    }

    internal inner class LoadImages constructor() : AsyncTask<Void?, Boolean?, Boolean>() {
        var count: Int = 0
        override fun onPreExecute() {
            super.onPreExecute()
        }

        override fun onPostExecute(aBoolean: Boolean) {
            super.onPostExecute(aBoolean)
            if (aBoolean) {
                progressRecycler!!.visibility = View.GONE
                recyclerSelectedWallpaper!!.visibility = View.VISIBLE
                val onLongClicked: OnLongClicked = object : OnLongClicked {
                    public override fun onLongClicked(isClicked: Boolean) {
                        isLongClicked = true
                        bottomButtonEditSettings!!.visibility = View.VISIBLE
                        bottomButtonEditSettings!!.translationY = bottomButtonLayoutSettings!!.height.toFloat()
                        bottomButtonLayoutSettings!!.post {
                            bottomButtonLayoutSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.height.toFloat()).setDuration(300).start()
                            bottomButtonEditSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.height.toFloat()).setDuration(300).start()
                        }
                    }
                }
                settingsRecyclerAdapter = SettingsRecyclerAdapter((mSelectedImagesList)!!, this@AutoWallpaperChangerBackupActivity, onLongClicked)
                recyclerSelectedWallpaper!!.adapter = settingsRecyclerAdapter
            }
        }

        protected override fun doInBackground(vararg params: Void?): Boolean? {
            mSelectedImagesList!!.clear()
            for (i in imageList!!.indices) {
                Glide.with(this@AutoWallpaperChangerBackupActivity).asBitmap().load(imageList!!.get(i)).into(object : CustomTarget<Bitmap?>() {
                    public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                        mSelectedImagesList!!.add(SettingsImagesModel(resource, false))
                        count++
                        if (count == imageList!!.size) {
                            onPostExecute(true)
                            count++
                        }
                    }

                    public override fun onLoadCleared(placeholder: Drawable?) {}
                })
            }
            return false
        }
    }

    private val dataWallpaper: Unit
        private get() {
            mAllWallpaperList!!.clear()
            mAllWallpaperList = dbHelperAutoWallpaper!!.allAutoWallpaper
        }

    private fun initListner() {
        icBack!!.setOnClickListener(this)
        icSubcription!!.setOnClickListener(this)
        btnShare!!.setOnClickListener(this)
        btnNext!!.setOnClickListener(this)
        btnAddWallpaper!!.setOnClickListener(this)
        selectDDCreation!!.setOnClickListener(this)
        selectDDSolid!!.setOnClickListener(this)
        btnApplyWallpaperSettings!!.setOnClickListener(this)
        btnAddWallpaperSettings!!.setOnClickListener(this)
        llScreenMode!!.setOnClickListener(this)
        llDelayTime!!.setOnClickListener(this)
        btnDeleteWallpaperSettings!!.setOnClickListener(this)
        btnEditWallpaperSettings!!.setOnClickListener(this)
        findViewById<View>(R.id.toolbar).setOnClickListener(this)
    }

    private fun initViews() {
        icBack = findViewById(R.id.icBack)
        icSubcription = findViewById(R.id.icSubcription)
        btnNext = findViewById(R.id.btnNext)
        btnShare = findViewById(R.id.btnShare)
        btnAddWallpaper = findViewById(R.id.btnAddWallpaper)
        layoutSelectWallpaper = findViewById(R.id.layoutSelectWallpaper)
        layoutMainWallpaperList = findViewById(R.id.layoutMainWallpaperList)
        selectDDSolid = findViewById(R.id.selectDDSolidN)
        selectDDCreation = findViewById(R.id.selectDDCreationN)
        txtSolidDD = findViewById(R.id.txtSolidDD)
        txtCreationDD = findViewById(R.id.txtCreationDD)
        imgSolidDD = findViewById(R.id.imgSolidDD)
        imgCreationDD = findViewById(R.id.imgCreationDD)
        spinnerCreationDD = findViewById(R.id.spinnerCreationDD)
        spinnerSolidDD = findViewById(R.id.spinnerSolidDD)
        frameSolid = findViewById(R.id.frameSolid)
        frameGradient = findViewById(R.id.frameGradient)
        frameGallery = findViewById(R.id.frameGallery)
        frameCreation = findViewById(R.id.frameCreation)
        frameText = findViewById(R.id.frameText)
        progressFragment = findViewById(R.id.progressFragment)
        cstMainSettings = findViewById(R.id.cstMainSettings)
        layoutTopSetting = findViewById(R.id.layoutTopSetting)
        bottomButtonLayoutSettings = findViewById(R.id.bottomButtonLayoutSettings)
        recyclerSelectedWallpaper = findViewById(R.id.recyclerSelectedWallpaper)
        progressRecycler = findViewById(R.id.progressRecycler)
        btnAddWallpaperSettings = findViewById(R.id.btnAddWallpaperSettings)
        btnApplyWallpaperSettings = findViewById(R.id.btnApplyWallpaperSettings)
        llDelayTime = findViewById(R.id.llDelayTime)
        llScreenMode = findViewById(R.id.llScreenMode)
        txtDelayTime = findViewById(R.id.txtDelayTime)
        txtScreenMode = findViewById(R.id.txtScreenMode)
        recyclerMainWallpaer = findViewById(R.id.recyclerMainWallpaer)
        layoutNoWallpaper = findViewById(R.id.layoutNoWallpaper)
        bottomButtonEditSettings = findViewById(R.id.bottomButtonEditSettings)
        btnEditWallpaperSettings = findViewById(R.id.btnEditWallpaperSettings)
        btnDeleteWallpaperSettings = findViewById(R.id.btnDeleteWallpaperSettings)
    }

    public override fun onClick(v: View) {
        when (v.getId()) {
            R.id.icBack -> onBackPressed()
            R.id.icSubcription -> startActivity(Intent(this@AutoWallpaperChangerBackupActivity, PremiumAccessActivity::class.java))
            R.id.btnShare -> {
            }
            R.id.btnNext -> onclickDone()
            R.id.btnAddWallpaper -> onClickAddWallpaper()
            R.id.selectDDSolidN -> onClickSolidDropDown()
            R.id.selectDDCreationN -> onClickCreationDropDown()
            R.id.btnAddWallpaperSettings -> onClickAddWallpaperSettings()
            R.id.btnApplyWallpaperSettings -> onClickApplyWallpaperSettings()
            R.id.llDelayTime -> onClickDelayTime()
            R.id.llScreenMode -> onClickScreenMode()
            R.id.btnEditWallpaperSettings ->{
//                btnEditWallpaperSettings!!.isEnabled = false
                btnNext!!.isEnabled = false
                onClickEditWallpaper()
            }
            R.id.btnDeleteWallpaperSettings -> onClickDeleteWallpaper()
        }
    }

    private fun onClickEditWallpaper() {
//        Handler(Looper.getMainLooper()).postDelayed({
//            findViewById<TextView>(R.id.btnEditWallpaperSettings).isEnabled = true
//            findViewById<TextView>(R.id.btnAddWallpaperSettings).isEnabled = true
//            btnAddWallpaperSettings!!.isEnabled=true
//        },5000)

        layoutSelectWallpaper!!.visibility=View.VISIBLE
        cstMainSettings!!.visibility=View.GONE

        btnNext!!.visibility = View.VISIBLE
//        icAdd!!.visibility=View.GONE

        if (mSelectedImagesList != null && mSelectedImagesList!!.size > 0) {
            var count: Int = 0
            var position: Int = 0
            for (i in mSelectedImagesList!!.indices) {
                if (mSelectedImagesList!!.get(i).isDeletable) {
                    count++
                    position = i
                }
            }
            if (count > 1) {
                Toast.makeText(this, "You can edit 1 image at a time.", Toast.LENGTH_SHORT).show()
            } else if (count < 1) {
                Toast.makeText(this, "Select 1 image to edit.", Toast.LENGTH_SHORT).show()
            } else {
                isEditOpen = true
                isLongClicked = false
                settingsImagesModelEdit = mSelectedImagesList!![position]
                val onItemClicked: SolidSingleSelectableFragment.OnItemClicked = object : SolidSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked1: GradientSingleSelectableFragment.OnItemClicked = object : GradientSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        solidSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked2: TextSingleSelectableFragment.OnItemClicked = object : TextSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        solidSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked3: CreationSingleSelectableFragment.OnItemClicked = object : CreationSingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        solidSingleSelectableFragment!!.setDataChanged()
                        gallerySingleSelectableFragment!!.setDataChanged()
                    }
                }
                val onItemClicked4: GallerySingleSelectableFragment.OnItemClicked = object : GallerySingleSelectableFragment.OnItemClicked {
                    public override fun onItemClicked() {
                        gradientSingleSelectableFragment!!.setDataChanged()
                        textSingleSelectableFragment!!.setDataChanged()
                        solidSingleSelectableFragment!!.setDataChanged()
                        creationSingleSelectableFragment!!.setDataChanged()
                    }
                }
                solidSingleSelectableFragment = SolidSingleSelectableFragment(onItemClicked)
                gradientSingleSelectableFragment = GradientSingleSelectableFragment(onItemClicked1)
                textSingleSelectableFragment = TextSingleSelectableFragment(onItemClicked2)
                creationSingleSelectableFragment = CreationSingleSelectableFragment(onItemClicked3)
                gallerySingleSelectableFragment = GallerySingleSelectableFragment(onItemClicked4)
                val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
                transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameSolid)))!!)
                transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameCreation)))!!)
                transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameGallery)))!!)
                transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameText)))!!)
                transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameGradient)))!!)
                transaction.replace(R.id.frameSolid, solidSingleSelectableFragment!!)
                transaction.replace(R.id.frameCreation, creationSingleSelectableFragment!!)
                transaction.replace(R.id.frameGradient, gradientSingleSelectableFragment!!)
                transaction.replace(R.id.frameText, textSingleSelectableFragment!!)
                transaction.replace(R.id.frameGallery, gallerySingleSelectableFragment!!)
                transaction.commitAllowingStateLoss()
                layoutTopSetting!!.animate().translationYBy(-layoutTopSetting!!.height.toFloat()).setDuration(300).start()
                recyclerSelectedWallpaper!!.animate().alpha(0f).withEndAction {
                    recyclerSelectedWallpaper!!.visibility = View.GONE
                    recyclerSelectedWallpaper!!.alpha = 1f
                }.setDuration(200).start()
                bottomButtonEditSettings!!.animate().translationYBy(bottomButtonEditSettings!!.height.toFloat()).withEndAction {
                    layoutSelectWallpaper!!.animate().translationYBy(-layoutMainWallpaperList!!.height.toFloat()).withEndAction {
                        if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                            icSubcription!!.animate().alpha(0f).withEndAction { icSubcription!!.visibility = View.INVISIBLE }.setDuration(300).start()
                            btnNext!!.alpha = 0f
                            btnNext!!.visibility = View.VISIBLE
                            btnNext!!.animate().alpha(1f).setDuration(300).start()
                        } else {
                            btnShare!!.animate().alpha(0f).withEndAction { btnShare!!.visibility = View.INVISIBLE }.setDuration(300).start()
                            btnNext!!.alpha = 0f
                            btnNext!!.visibility = View.VISIBLE
                            btnNext!!.animate().alpha(1f).setDuration(300).start()
                        }
                    }.setDuration(200).start()
                }.setDuration(300).start()
            }
        }
    }

    private fun onClickDeleteWallpaper() {
        if (mSelectedImagesList != null && mSelectedImagesList!!.size > 0) {
            var count: Int = 0
            val mTempList: ArrayList<SettingsImagesModel> = ArrayList()
            for (i in mSelectedImagesList!!.indices) {
                if (mSelectedImagesList!![i].isDeletable) {
                    mTempList.add(mSelectedImagesList!![i])
                    count++
                }
            }
            if (count < 1) {
                Toast.makeText(this, "Select 1 image to delete.", Toast.LENGTH_SHORT).show()
            } else if (count == mSelectedImagesList!!.size) {
                Toast.makeText(this, "You can't remove all images.", Toast.LENGTH_SHORT).show()
            } else {
                showAlertDialog()
            }
        }
    }

    private fun showAlertDialog() {
         bottomSheetFragments= BottomSheetFragment(getResources().getString(R.string.remove), getResources().getString(R.string.are_you_want_to_remove), getResources().getString(R.string.remove), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                for (i in mSelectedImagesList!!.indices) {
                    if (mSelectedImagesList!!.get(i).isDeletable) {
                        mSelectedImagesList!!.removeAt(i)
                    }
                }
                settingsRecyclerAdapter!!.setDataChanged()
                bottomSheetDialo!!.dismiss()
                isLongClicked = false
                bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                bottomButtonEditSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragments!!.show(supportFragmentManager, "dialog")
    }

    private fun onClickScreenMode() {
        val dialog: Dialog = Dialog(this@AutoWallpaperChangerBackupActivity)
        dialog.setContentView(R.layout.dialog_screenmode_select)
        Objects.requireNonNull(dialog.window)!!.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        val txtBoth: TextView = dialog.findViewById(R.id.txtBoth)
        val txtLockScreen: TextView = dialog.findViewById(R.id.txtLockScreen)
        val txtHomeScreen: TextView = dialog.findViewById(R.id.txtHomeScreen)
        val btnPositive: Button = dialog.findViewById(R.id.btnPositive)
        val btnNagative: Button = dialog.findViewById(R.id.btnNagative)
        val checkBoth: ImageView = dialog.findViewById(R.id.checkBoth)
        val checkHome: ImageView = dialog.findViewById(R.id.checkHome)
        val checkLock: ImageView = dialog.findViewById(R.id.checkLock)
        val list: Array<Any> = arrayOf(checkBoth, checkHome, checkLock)
        if ((screenMode == "Home Screen")) {
            setSelection(checkHome, list)
        } else if ((screenMode == "Lock Screen")) {
            setSelection(checkLock, list)
        } else {
            setSelection(checkBoth, list)
        }
        txtBoth.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(checkBoth, list)
            screenMode = "Both"
        })
        txtLockScreen.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(checkLock, list)
            screenMode = "Lock Screen"
        })
        txtHomeScreen.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(checkHome, list)
            screenMode = "Home Screen"
        })
        btnNagative.setOnClickListener(View.OnClickListener({ v: View? -> dialog.dismiss() }))
        btnPositive.setOnClickListener(View.OnClickListener { v: View? ->
            dialog.dismiss()
            txtScreenMode!!.setText(screenMode)
        })
        dialog.show()
    }

    private fun onClickDelayTime() {
        val dialog: Dialog = Dialog(this@AutoWallpaperChangerBackupActivity)
        dialog.setContentView(R.layout.dialog_delaytime_select)
        Objects.requireNonNull(dialog.getWindow())!!.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)
        val textView5Sec: TextView = dialog.findViewById(R.id.txt5Second)
        val textView15Sec: TextView = dialog.findViewById(R.id.txt15Second)
        val textView30Sec: TextView = dialog.findViewById(R.id.txt30Second)
        val textView2Min: TextView = dialog.findViewById(R.id.txt2Min)
        val textView5Min: TextView = dialog.findViewById(R.id.txt5Min)
        val textView15Min: TextView = dialog.findViewById(R.id.txt15Min)
        val textViewRandom: TextView = dialog.findViewById(R.id.txtRandom)
        val btnPositive: Button = dialog.findViewById(R.id.btnPositive)
        val btnNagative: Button = dialog.findViewById(R.id.btnNagative)
        val imgView5Sec: ImageView = dialog.findViewById(R.id.check5Sec)
        val imgView15Sec: ImageView = dialog.findViewById(R.id.check15Sec)
        val imgView30Sec: ImageView = dialog.findViewById(R.id.check30Sec)
        val imgView2Min: ImageView = dialog.findViewById(R.id.check2Min)
        val imgView5Min: ImageView = dialog.findViewById(R.id.check5Min)
        val imgView15Min: ImageView = dialog.findViewById(R.id.check15Min)
        val imgViewRandom: ImageView = dialog.findViewById(R.id.checkRandom)
        val list: Array<Any> = arrayOf(imgView5Sec, imgView15Sec, imgView30Sec, imgView2Min, imgView5Min, imgView15Min, imgViewRandom)
        when (delayTime) {
            "5 Sec" -> setSelection(imgView5Sec, list)
            "15 Sec" -> setSelection(imgView15Sec, list)
            "30 Sec" -> setSelection(imgView30Sec, list)
            "2 Min" -> setSelection(imgView2Min, list)
            "5 Min" -> setSelection(imgView5Min, list)
            "15 Min" -> setSelection(imgView15Min, list)
            else -> setSelection(imgViewRandom, list)
        }
        textView5Sec.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView5Sec, list)
            delayTime = "5 Sec"
        })
        textView15Sec.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView15Sec, list)
            delayTime = "15 Sec"
        })
        textView30Sec.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView30Sec, list)
            delayTime = "30 Sec"
        })
        textView2Min.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView2Min, list)
            delayTime = "2 Min"
        })
        textView5Min.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView5Min, list)
            delayTime = "5 Min"
        })
        textView15Min.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgView15Min, list)
            delayTime = "15 Min"
        })
        textViewRandom.setOnClickListener(View.OnClickListener { v: View? ->
            setSelection(imgViewRandom, list)
            delayTime = "Random"
        })
        btnNagative.setOnClickListener(View.OnClickListener({ v: View? -> dialog.dismiss() }))
        btnPositive.setOnClickListener(View.OnClickListener { v: View? ->
            dialog.dismiss()
            txtDelayTime!!.setText(delayTime)
        })
        dialog.show()
    }

    fun setSelection(imageView: ImageView, list: Array<Any>) {
        for (o: Any in list) {
            if ((imageView == o)) {
                (o as ImageView).visibility = View.VISIBLE
            } else {
                (o as ImageView).visibility = View.GONE
            }
        }
    }

    private fun onClickApplyWallpaperSettings() {
        if (mSelectedImagesList != null && mSelectedImagesList!!.size > 0) {
            SaveDataTOStorage().execute()
        }
    }

    internal inner class SaveDataTOStorage constructor() : AsyncTask<Void?, Void?, Void?>() {
        var mAllPathList: ArrayList<String>? = null
        var progressDialog: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()
            progressDialog = ProgressDialog(this@AutoWallpaperChangerBackupActivity)
            progressDialog!!.setMessage("Please wait...")
            progressDialog!!.setCancelable(false)
            progressDialog!!.show()
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            val gson: Gson = Gson()
            val inputString: String = gson.toJson(mAllPathList)
            val model: AutoWallpaperModel = AutoWallpaperModel()
            model.screenmode = screenMode
            model.delaytime = delayTime
            model.imagespath = inputString
            model.status = 1
            dbHelperAutoWallpaper!!.insertAutoWallpaper(model)
            if (progressDialog != null && progressDialog!!.isShowing) {
                progressDialog!!.dismiss()
            }
            try {
                /*  Intent intent = new Intent(
                        WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(AutoWallpaperChangerBackupActivity.this, LiveWallpaper.class));
                startActivity(intent);*/
                setAlarmAuto(model)
                //isApplyClicked = true;
                isApplyClicked = false
                isSettingsOpen = false
                isEditSettingsOpen = false
                dataWallpaper
                if (mAllWallpaperList!!.size > 0) {
                    recyclerMainWallpaer!!.visibility = View.VISIBLE
                    layoutNoWallpaper!!.visibility = View.GONE
                    recyclerMainWallpaer!!.layoutManager = LinearLayoutManager(this@AutoWallpaperChangerBackupActivity, RecyclerView.VERTICAL, false)
                    liveWallpaperAdapter = LiveWallpaperListAdapter((mAllWallpaperList)!!, this@AutoWallpaperChangerBackupActivity, object : OnSelectAction {
                        public override fun onPlay(autoWallpaperModel: AutoWallpaperModel?) {
                            dbHelperAutoWallpaper!!.updateDataRow(autoWallpaperModel!!.id)
                            setAlarmAuto(autoWallpaperModel)
                        }

                        public override fun onEdit(autoWallpaperModel: AutoWallpaperModel?) {
                            editWallpaper(autoWallpaperModel)
                        }

                        public override fun onDelete(autoWallpaperModel: AutoWallpaperModel?) {
                            showRemoveDialog(autoWallpaperModel)
                        }
                    })
                    recyclerMainWallpaer!!.adapter = liveWallpaperAdapter
                } else {
                    recyclerMainWallpaer!!.visibility = View.GONE
                    layoutNoWallpaper!!.visibility = View.VISIBLE
                }
                if (isEditClicked) {
                    isEditClicked = false
                    if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        btnNext!!.animate().alpha(0f).withEndAction {
                            Log.d(TAG, "run: ")
                            btnNext!!.visibility = View.INVISIBLE
                            isSelectWallpaperMenuOpen = false
                        }.setDuration(300).start()
                        icSubcription!!.visibility = View.VISIBLE
                        icSubcription!!.animate().alpha(1f).setDuration(300).start()
                    } else {
                        btnNext!!.animate().alpha(0f).withEndAction {
                            btnNext!!.visibility = View.INVISIBLE
                            isSelectWallpaperMenuOpen = false
                        }.setDuration(300).start()
                        btnShare!!.visibility = View.VISIBLE
                        btnShare!!.animate().alpha(1f).setDuration(300).start()
                    }
                }
                layoutMainWallpaperList!!.animate().translationYBy(layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
                // cstMainSettings.animate().translationYBy(cstMainSettings.getHeight()).setDuration(300).start();
                cstMainSettings!!.visibility = View.GONE
            } catch (e: Exception) {
                e.printStackTrace()
                //Live Wallpaper not supported
            }
        }

        protected override fun doInBackground(vararg params: Void?): Void? {
            mAllPathList = ArrayList()
            val cacheDir: String = "/Pictures/.autowallpaper"
            val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
            if (!fullCacheDir.exists()) {
                fullCacheDir.mkdirs()
            }
            for (i in mSelectedImagesList!!.indices) {
                val bitmap: Bitmap = mSelectedImagesList!!.get(i).bitmap
                val fileLocalName: String = System.currentTimeMillis().toString() + ".PNG"
                val fileUri: File = File(fullCacheDir.toString(), fileLocalName)
                mAllPathList!!.add(fileUri.absolutePath)
                Log.d("7812123123123", "onClickApplyWallpaperSettings: " + fileUri.getAbsolutePath())
                var outStream: FileOutputStream? = null
                try {
                    outStream = FileOutputStream(fileUri)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream)
                    outStream.flush()
                    outStream.close()
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } catch (e: IOException) {
                    Log.i("CACHE", "Error: File could not be stuffed!")
                    e.printStackTrace()
                }
            }
            return null
        }
    }

    internal inner class UpdateData constructor() : AsyncTask<Void?, Void?, Void?>() {
        var mAllPathList: ArrayList<String>? = null
        var progressDialog: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()
            progressDialog = ProgressDialog(this@AutoWallpaperChangerBackupActivity)
            progressDialog!!.setMessage("Please wait...")
            progressDialog!!.setCancelable(false)
            progressDialog!!.show()
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            val gson: Gson = Gson()
            val inputString: String = gson.toJson(mAllPathList)
            val model: AutoWallpaperModel = AutoWallpaperModel()
            model.id = autoWallpaperModelEdit!!.id
            model.screenmode = screenMode
            model.delaytime = delayTime
            model.imagespath = inputString
            model.status = 0
            dbHelperAutoWallpaper!!.updateDataToDB(model)
            if (progressDialog != null && progressDialog!!.isShowing) {
                progressDialog!!.dismiss()
            }
            try {
                isApplyClicked = false
                isSettingsOpen = false
                isEditSettingsOpen = false
                dataWallpaper
                if (mAllWallpaperList!!.size > 0) {
                    recyclerMainWallpaer!!.visibility = View.VISIBLE
                    layoutNoWallpaper!!.visibility = View.GONE
                    recyclerMainWallpaer!!.layoutManager = LinearLayoutManager(this@AutoWallpaperChangerBackupActivity, RecyclerView.VERTICAL, false)
                    liveWallpaperAdapter = LiveWallpaperListAdapter((mAllWallpaperList)!!, this@AutoWallpaperChangerBackupActivity, object : OnSelectAction {
                        public override fun onPlay(autoWallpaperModel: AutoWallpaperModel?) {
                            dbHelperAutoWallpaper!!.updateDataRow(autoWallpaperModel!!.id)
                            setAlarmAuto(autoWallpaperModel)
                        }

                        public override fun onEdit(autoWallpaperModel: AutoWallpaperModel?) {
                            editWallpaper(autoWallpaperModel)
                        }

                        public override fun onDelete(autoWallpaperModel: AutoWallpaperModel?) {
                            showRemoveDialog(autoWallpaperModel)
                        }
                    })
                    recyclerMainWallpaer!!.adapter = liveWallpaperAdapter
                } else {
                    recyclerMainWallpaer!!.visibility = View.GONE
                    layoutNoWallpaper!!.visibility = View.VISIBLE
                }
                layoutMainWallpaperList!!.animate().translationYBy(layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
                cstMainSettings!!.visibility = View.GONE
                if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                    btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                        public override fun run() {
                            Log.d(TAG, "run: ")
                            btnNext!!.visibility = View.INVISIBLE
                            isSelectWallpaperMenuOpen = false
                        }
                    }).setDuration(300).start()
                    icSubcription!!.visibility = View.VISIBLE
                    icSubcription!!.animate().alpha(1f).setDuration(300).start()
                } else {
                    btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                        public override fun run() {
                            btnNext!!.visibility = View.INVISIBLE
                            isSelectWallpaperMenuOpen = false
                        }
                    }).setDuration(300).start()
                    btnShare!!.visibility = View.VISIBLE
                    btnShare!!.animate().alpha(1f).setDuration(300).start()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                //Live Wallpaper not supported
            }
        }

        protected override fun doInBackground(vararg params: Void?): Void? {
            mAllPathList = ArrayList()
            val cacheDir: String = "/Pictures/.autowallpaper"
            val fullCacheDir: File = File(Environment.getExternalStorageDirectory().toString(), cacheDir)
            if (!fullCacheDir.exists()) {
                fullCacheDir.mkdirs()
            }
            for (i in mSelectedImagesList!!.indices) {
                val bitmap: Bitmap = mSelectedImagesList!!.get(i).bitmap
                val fileLocalName: String = System.currentTimeMillis().toString() + ".PNG"
                val fileUri: File = File(fullCacheDir.toString(), fileLocalName)
                mAllPathList!!.add(fileUri.absolutePath)
                Log.d("7812123123123", "onClickApplyWallpaperSettings: " + fileUri.getAbsolutePath())
                var outStream: FileOutputStream? = null
                try {
                    outStream = FileOutputStream(fileUri)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outStream)
                    outStream.flush()
                    outStream.close()
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } catch (e: IOException) {
                    Log.i("CACHE", "Error: File could not be stuffed!")
                    e.printStackTrace()
                }
            }
            return null
        }
    }

    private fun setAlarmAuto(model: AutoWallpaperModel?) {
        val calendar: Calendar = Calendar.getInstance()
        val id: Int = 0
        Log.d("89712378161456", "setAlarmAuto: " + id)
        if (mySharedPref!!.alarmId != -1) {
            cancelAlarm(("2121" + mySharedPref!!.alarmId).toInt(), this@AutoWallpaperChangerBackupActivity, EventReceiver::class.java)
        }
        val myIntent: Intent = Intent(this@AutoWallpaperChangerBackupActivity, EventReceiver::class.java)
        val pendingIntent: PendingIntent = PendingIntent.getBroadcast(this@AutoWallpaperChangerBackupActivity, ("2121" + id).toInt(), myIntent, PendingIntent.FLAG_IMMUTABLE)
        val alarmManager: AlarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        mySharedPref!!.alarmId = 0
        var timeInterval: Int = 0
        when (model!!.delaytime) {
            "5 Sec" -> timeInterval = 5 * 1000
            "15 Sec" -> timeInterval = 15 * 1000
            "30 Sec" -> timeInterval = 30 * 1000
            "2 Min" -> timeInterval = 2 * 60 * 1000
            "5 Min" -> timeInterval = 5 * 60 * 1000
            "15 Min" -> timeInterval = 15 * 60 * 1000
            else -> timeInterval = 60 * 1000
        }
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    timeInterval.toLong(),
                    pendingIntent
            )
            MySharedPref(this@AutoWallpaperChangerBackupActivity).setAlarm(id, true)
            //  Constants.isSetEvent = true
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis + timeInterval,
                        pendingIntent
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis + timeInterval,
                        pendingIntent
                )
            } else {
                alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis + timeInterval,
                        pendingIntent
                )
            }
        }
    }

    private fun onClickAddWallpaperSettings() {
        mBitmapList!!.clear()
        isAddMenuOpen = true
        solidSelectableFragment = SolidSelectableFragment()
        gradientSelectableFragment = GradientSelectableFragment()
        textSelectableFragment = TextSelectableFragment()
        creationSelectableFragment = CreationSelectableFragment()
        gallerySelectableFragment = GallerySelectableFragment()
        val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        try {
            transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameSolid)))!!)
            transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameCreation)))!!)
            transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameGallery)))!!)
            transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameText)))!!)
            transaction.remove((Objects.requireNonNull(supportFragmentManager.findFragmentById(R.id.frameGradient)))!!)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        transaction.replace(R.id.frameSolid, solidSelectableFragment!!)
        transaction.replace(R.id.frameCreation, creationSelectableFragment!!)
        transaction.replace(R.id.frameGradient, gradientSelectableFragment!!)
        transaction.replace(R.id.frameText, textSelectableFragment!!)
        transaction.replace(R.id.frameGallery, gallerySelectableFragment!!)
        transaction.commitAllowingStateLoss()
        layoutSelectWallpaper!!.visibility = View.VISIBLE
        layoutSelectWallpaper!!.translationY = layoutSelectWallpaper!!.height.toFloat()
        progressFragment!!.visibility = View.GONE
        layoutTopSetting!!.animate().translationYBy(-layoutTopSetting!!.height.toFloat()).setDuration(300).start()
        recyclerSelectedWallpaper!!.animate().alpha(0f).withEndAction {
            recyclerSelectedWallpaper!!.visibility = View.GONE
            recyclerSelectedWallpaper!!.alpha = 1f
        }.setDuration(200).start()
        bottomButtonLayoutSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.height.toFloat()).withEndAction {
            layoutSelectWallpaper!!.animate().translationYBy(-layoutMainWallpaperList!!.height.toFloat()).withEndAction {
                if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                    icSubcription!!.animate().alpha(0f).withEndAction { icSubcription!!.visibility = View.INVISIBLE }.setDuration(300).start()
                    btnNext!!.alpha = 0f
                    btnNext!!.visibility = View.VISIBLE
                    btnNext!!.animate().alpha(1f).setDuration(300).start()
                } else {
                    btnShare!!.animate().alpha(0f).withEndAction { btnShare!!.visibility = View.INVISIBLE }.setDuration(300).start()
                    btnNext!!.alpha = 0f
                    btnNext!!.visibility = View.VISIBLE
                    btnNext!!.animate().alpha(1f).setDuration(300).start()
                }
            }.setDuration(200).start()
        }.setDuration(300).start()
    }

    private fun onClickCreationDropDown() {
        txtSolidDD!!.alpha = 0.5f
        imgSolidDD!!.visibility = View.GONE
        txtCreationDD!!.alpha = 1f
        imgCreationDD!!.visibility = View.VISIBLE
        if (positionCreation == 0) {
            frameSolid!!.visibility = View.GONE
            frameCreation!!.visibility = View.VISIBLE
            frameGallery!!.visibility = View.GONE
            frameGradient!!.visibility = View.GONE
            frameText!!.visibility = View.GONE
        } else if (positionCreation == 1) {
            frameSolid!!.visibility = View.GONE
            frameCreation!!.visibility = View.GONE
            frameGallery!!.visibility = View.VISIBLE
            frameGradient!!.visibility = View.GONE
            frameText!!.visibility = View.GONE
        }
        isFirstS1 = false
        if (isFirstC1) {
            spinnerCreationDD!!.performClick()
        } else {
            isFirstC1 = true
        }
    }

    private fun onClickSolidDropDown() {
        txtCreationDD!!.alpha = 0.5f
        imgCreationDD!!.visibility = View.GONE
        txtSolidDD!!.alpha = 1f
        imgSolidDD!!.visibility = View.VISIBLE
        if (positionSolid == 0) {
            frameSolid!!.visibility = View.VISIBLE
            frameCreation!!.visibility = View.GONE
            frameGallery!!.visibility = View.GONE
            frameGradient!!.visibility = View.GONE
            frameText!!.visibility = View.GONE
        } else if (positionSolid == 1) {
            frameSolid!!.visibility = View.GONE
            frameCreation!!.visibility = View.GONE
            frameGallery!!.visibility = View.GONE
            frameGradient!!.visibility = View.VISIBLE
            frameText!!.visibility = View.GONE
        } else if (positionSolid == 2) {
            frameSolid!!.visibility = View.GONE
            frameCreation!!.visibility = View.GONE
            frameGallery!!.visibility = View.GONE
            frameGradient!!.visibility = View.GONE
            frameText!!.visibility = View.VISIBLE
        }
        isFirstC1 = false
        if (isFirstS1) {
            spinnerSolidDD!!.performClick()
        } else {
            isFirstS1 = true
        }
    }

    private fun onclickDone() {
        Log.d(TAG, "onclickDone: " + isEditOpen + "  " + isEditClicked + "  " + isAddMenuOpen)
        if (isEditOpen) {
            val mTempList: ArrayList<Any> = ArrayList()
            if (solidSingleSelectableFragment != null) {
                mTempList.addAll(solidSingleSelectableFragment!!.dataList)
            }
            if (gradientSingleSelectableFragment != null) {
                mTempList.addAll(gradientSingleSelectableFragment!!.dataList)
            }
            if (textSingleSelectableFragment != null) {
                mTempList.addAll(textSingleSelectableFragment!!.dataList)
            }
            if (creationSingleSelectableFragment != null) {
                mTempList.addAll(creationSingleSelectableFragment!!.dataList)
            }
            if (gallerySingleSelectableFragment != null) {
                mTempList.addAll(gallerySingleSelectableFragment!!.dataList)
            }
            if (mTempList.size <= 0) {
                Toast.makeText(this, "Please select atleast 1 image.", Toast.LENGTH_SHORT).show()
            } else {
                isEditOpen = false
                isSettingsOpen = true
                if (settingsImagesModelEdit != null) {
                    val metrics: DisplayMetrics = DisplayMetrics()
                    windowManager.defaultDisplay.getMetrics(metrics)
                    val `object`: Any = mTempList.get(0)
                    if (`object` is SolidSelectableModel) {
                        val shape: GradientDrawable = GradientDrawable()
                        shape.shape = GradientDrawable.RECTANGLE
                        shape.colors = intArrayOf(`object`.solidColorModel.color, `object`.solidColorModel.color)
                        settingsImagesModelEdit!!.bitmap = convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels)
                    } else if (`object` is GradientSelectableModel) {
                        if (`object`.colorModel.circle) {
                            val shape: GradientDrawable = GradientDrawable()
                            shape.shape = GradientDrawable.RECTANGLE
                            shape.colors = intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2)
                            shape.gradientType = GradientDrawable.RADIAL_GRADIENT
                            shape.gradientRadius = metrics.widthPixels.toFloat()
                            settingsImagesModelEdit!!.bitmap = convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels)
                        } else {
                            val shape: GradientDrawable = GradientDrawable(`object`.colorModel.orientation, intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                            shape.shape = GradientDrawable.RECTANGLE
                            settingsImagesModelEdit!!.bitmap = convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels)
                        }
                    } else if (`object` is TextSelectableModel) {
                        Glide.with(this@AutoWallpaperChangerBackupActivity).asBitmap().load(`object`.imgePath).into(object : CustomTarget<Bitmap?>() {
                            public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                                settingsImagesModelEdit!!.bitmap = resource
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                    } else if (`object` is SavedImageModel) {
                        Glide.with(this@AutoWallpaperChangerBackupActivity).asBitmap().load(`object`.path).into(object : CustomTarget<Bitmap?>() {
                            public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                                settingsImagesModelEdit!!.bitmap = resource
                            }

                            public override fun onLoadCleared(placeholder: Drawable?) {}
                        })
                    }
                    settingsRecyclerAdapter!!.setDataChanged()
                    cstMainSettings!!.visibility = View.VISIBLE
                    progressRecycler!!.visibility = View.VISIBLE
                    layoutTopSetting!!.visibility = View.VISIBLE
                    bottomButtonLayoutSettings!!.visibility = View.INVISIBLE
                    layoutTopSetting!!.post {
                        Log.d(TAG, "onclickDone: " + cstMainSettings!!.height)
                        layoutTopSetting!!.translationY = -layoutTopSetting!!.height.toFloat()
                        Handler().postDelayed({ layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.height.toFloat()).setDuration(300).start() }, 100)
                        layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.height.toFloat()).withEndAction {
                            progressRecycler!!.visibility = View.GONE
                            recyclerSelectedWallpaper!!.visibility = View.VISIBLE
                            bottomButtonLayoutSettings!!.visibility = View.VISIBLE
                            bottomButtonLayoutSettings!!.translationY = bottomButtonLayoutSettings!!.height.toFloat()
                            bottomButtonLayoutSettings!!.post { bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.height.toFloat()).setDuration(300).start() }
                        }.setDuration(300).start()
                        if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                            btnNext!!.animate().alpha(0f).withEndAction {
                                Log.d(TAG, "run: ")
                                btnNext!!.visibility = View.INVISIBLE
                                isSelectWallpaperMenuOpen = false
                            }.setDuration(300).start()
                            icSubcription!!.visibility = View.VISIBLE
                            icSubcription!!.animate().alpha(1f).setDuration(300).start()
                        } else {
                            btnNext!!.animate().alpha(0f).withEndAction {
                                btnNext!!.visibility = View.INVISIBLE
                                isSelectWallpaperMenuOpen = false
                            }.setDuration(300).start()
                            btnShare!!.visibility = View.VISIBLE
                            btnShare!!.animate().alpha(1f).setDuration(300).start()
                        }
                        isSelectWallpaperMenuOpen = false
                    }
                }
            }
        } else if (isAddMenuOpen) {
            mSelectedList = ArrayList()
            if (solidSelectableFragment != null) {
                mSelectedList!!.addAll(solidSelectableFragment!!.dataList)
            }
            if (gradientSelectableFragment != null) {
                mSelectedList!!.addAll(gradientSelectableFragment!!.dataList)
            }
            if (textSelectableFragment != null) {
                mSelectedList!!.addAll(textSelectableFragment!!.dataList)
            }
            if (creationSelectableFragment != null) {
                mSelectedList!!.addAll(creationSelectableFragment!!.dataList)
            }
            if (gallerySelectableFragment != null) {
                mSelectedList!!.addAll(gallerySelectableFragment!!.dataList)
            }
            if (mSelectedList!!.size <= 0) {
                Toast.makeText(this, "Please select atleast 1 image.", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    glideLoadImageCount = 0
                    for (`object`: Any in mSelectedList!!) {
                        if (`object` is TextSelectableModel || `object` is SavedImageModel) {
                            glideLoadImageCount++
                        }
                    }
                    recyclerSelectedWallpaper!!.visibility = View.GONE
                    LoadSelectedImages().execute()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                isSettingsOpen = true
                isAddMenuOpen = false
                cstMainSettings!!.visibility = View.VISIBLE
                layoutTopSetting!!.visibility = View.VISIBLE
                recyclerSelectedWallpaper!!.visibility = View.GONE
                bottomButtonLayoutSettings!!.visibility = View.INVISIBLE
                layoutTopSetting!!.post {
                    Log.d(TAG, "onclickDone: " + cstMainSettings!!.height)
                    layoutTopSetting!!.translationY = -layoutTopSetting!!.height.toFloat()
                    Handler().postDelayed({ layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.height.toFloat()).setDuration(300).start() }, 100)
                    layoutSelectWallpaper!!.animate().translationYBy(layoutMainWallpaperList!!.height.toFloat()).withEndAction {
                        bottomButtonLayoutSettings!!.visibility = View.VISIBLE
                        recyclerSelectedWallpaper!!.visibility = View.VISIBLE
                        bottomButtonLayoutSettings!!.translationY = bottomButtonLayoutSettings!!.height.toFloat()
                        bottomButtonLayoutSettings!!.post { bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.height.toFloat()).setDuration(300).start() }
                    }.setDuration(300).start()
                    if (!isEditClicked) {
                        if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                            btnNext!!.animate().alpha(0f).withEndAction {
                                Log.d(TAG, "run: ")
                                btnNext!!.visibility = View.INVISIBLE
                                isSelectWallpaperMenuOpen = false
                            }.setDuration(300).start()
                            icSubcription!!.visibility = View.VISIBLE
                            icSubcription!!.animate().alpha(1f).setDuration(300).start()
                        } else {
                            btnNext!!.animate().alpha(0f).withEndAction {
                                btnNext!!.visibility = View.INVISIBLE
                                isSelectWallpaperMenuOpen = false
                            }.setDuration(300).start()
                            btnShare!!.visibility = View.VISIBLE
                            btnShare!!.animate().alpha(1f).setDuration(300).start()
                        }
                        isSelectWallpaperMenuOpen = false
                    }
                }
            }
        } else if (isEditClicked) {
            Log.d(TAG, "onclickDone: ")
            isEditClicked = false
            UpdateData().execute()
            if (isEditOpen) {
                onBackPressed()
            }
        } else {
            mSelectedList = ArrayList()
            if (solidSelectableFragment != null) {
                mSelectedList!!.addAll(solidSelectableFragment!!.dataList)
            }
            if (gradientSelectableFragment != null) {
                mSelectedList!!.addAll(gradientSelectableFragment!!.dataList)
            }
            if (textSelectableFragment != null) {
                mSelectedList!!.addAll(textSelectableFragment!!.dataList)
            }
            if (creationSelectableFragment != null) {
                mSelectedList!!.addAll(creationSelectableFragment!!.dataList)
            }
            if (gallerySelectableFragment != null) {
                mSelectedList!!.addAll(gallerySelectableFragment!!.dataList)
            }
            if (mSelectedList!!.size <= 0) {
                Toast.makeText(this, "Please select atleast 1 image.", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    glideLoadImageCount = 0
                    for (`object`: Any in mSelectedList!!) {
                        if (`object` is TextSelectableModel || `object` is SavedImageModel) {
                            glideLoadImageCount++
                        }
                    }
                    recyclerSelectedWallpaper!!.setVisibility(View.GONE)
                    LoadSelectedImages().execute()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                isSettingsOpen = true
                isAddMenuOpen = false
                cstMainSettings!!.visibility = View.VISIBLE
                layoutTopSetting!!.visibility = View.VISIBLE
                recyclerSelectedWallpaper!!.visibility = View.GONE
                bottomButtonLayoutSettings!!.visibility = View.INVISIBLE
                layoutTopSetting!!.post(object : Runnable {
                    public override fun run() {
                        Log.d(TAG, "onclickDone: " + cstMainSettings!!.getHeight())
                        layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
                        Handler().postDelayed(object : Runnable {
                            public override fun run() {
                                layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                            }
                        }, 100)
                        layoutSelectWallpaper!!.animate().translationYBy(layoutMainWallpaperList!!.getHeight().toFloat()).withEndAction(object : Runnable {
                            public override fun run() {
                                bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                                recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                                bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                                bottomButtonLayoutSettings!!.post(object : Runnable {
                                    public override fun run() {
                                        bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                                    }
                                })
                            }
                        }).setDuration(300).start()
                        if (!isEditClicked) {
                            if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                                btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                    public override fun run() {
                                        Log.d(TAG, "run: ")
                                        btnNext!!.setVisibility(View.INVISIBLE)
                                        isSelectWallpaperMenuOpen = false
                                    }
                                }).setDuration(300).start()
                                icSubcription!!.setVisibility(View.VISIBLE)
                                icSubcription!!.animate().alpha(1f).setDuration(300).start()
                            } else {
                                btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                    public override fun run() {
                                        btnNext!!.setVisibility(View.INVISIBLE)
                                        isSelectWallpaperMenuOpen = false
                                    }
                                }).setDuration(300).start()
                                btnShare!!.setVisibility(View.VISIBLE)
                                btnShare!!.animate().alpha(1f).setDuration(300).start()
                            }
                            isSelectWallpaperMenuOpen = false
                        }
                    }
                })
            }
        }
    }

    private fun onClickAddWallpaper() {
        btnAddWallpaper!!.setEnabled(false)
        progressFragment!!.setVisibility(View.VISIBLE)
        txtCreationDD!!.setAlpha(0.5f)
        imgCreationDD!!.setVisibility(View.GONE)
        txtSolidDD!!.setAlpha(1f)
        imgSolidDD!!.setVisibility(View.VISIBLE)
        txtSolidDD!!.setText("Solid")
        txtCreationDD!!.setText("Creation")
        delayTime = "Random"
        screenMode = "Home Screen"
        txtDelayTime!!.setText(delayTime)
        txtScreenMode!!.setText(screenMode)
        frameSolid!!.setVisibility(View.GONE)
        frameCreation!!.setVisibility(View.GONE)
        frameGallery!!.setVisibility(View.GONE)
        frameGradient!!.setVisibility(View.GONE)
        frameText!!.setVisibility(View.GONE)
        if (mSelectedList != null) {
            mSelectedList!!.clear()
        }
        if (mSelectedImagesList != null) {
            mSelectedImagesList!!.clear()
        }
        solidSelectableFragment = SolidSelectableFragment()
        gradientSelectableFragment = GradientSelectableFragment()
        textSelectableFragment = TextSelectableFragment()
        creationSelectableFragment = CreationSelectableFragment()
        gallerySelectableFragment = GallerySelectableFragment()
        layoutSelectWallpaper!!.setVisibility(View.VISIBLE)
        layoutSelectWallpaper!!.setTranslationY(layoutMainWallpaperList!!.getHeight().toFloat())
        layoutMainWallpaperList!!.animate().translationYBy(-layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
        layoutSelectWallpaper!!.animate().translationYBy(-layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
        if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
            icSubcription!!.animate().alpha(0f).withEndAction(object : Runnable {
                public override fun run() {
                    Log.d(TAG, "run: ")
                    btnAddWallpaper!!.setEnabled(true)
                    icSubcription!!.setVisibility(View.INVISIBLE)
                    isSelectWallpaperMenuOpen = true
                }
            }).setDuration(300).start()
            btnNext!!.setAlpha(0f)
            btnNext!!.setVisibility(View.VISIBLE)
            btnNext!!.animate().alpha(1f).setDuration(300).start()
        } else {
            btnShare!!.animate().alpha(0f).withEndAction(object : Runnable {
                public override fun run() {
                    btnShare!!.setVisibility(View.INVISIBLE)
                    btnAddWallpaper!!.setEnabled(true)
                    isSelectWallpaperMenuOpen = true
                }
            }).setDuration(300).start()
            btnNext!!.setAlpha(0f)
            btnNext!!.setVisibility(View.VISIBLE)
            btnNext!!.animate().alpha(1f).setDuration(300).start()
        }
        Handler().postDelayed(object : Runnable {
            public override fun run() {
                isFirstC = false
                isFirstS = false
                positionCreation = 0
                positionSolid = 0
                val adapter: ArrayAdapter<String> = ArrayAdapter(this@AutoWallpaperChangerBackupActivity, R.layout.spinner_item, R.id.text1, items)
                adapter.setDropDownViewResource(R.layout.sinner_dropdown_item)
                spinnerSolidDD!!.setAdapter(adapter)
                val adapter2: ArrayAdapter<String> = ArrayAdapter(this@AutoWallpaperChangerBackupActivity, R.layout.spinner_item, R.id.text1, items2)
                adapter2.setDropDownViewResource(R.layout.sinner_dropdown_item)
                spinnerCreationDD!!.setAdapter(adapter2)
                spinnerCreationDD!!.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                    public override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                        if (isFirstC) {
                            positionCreation = position
                            txtCreationDD!!.setText(items2.get(position))
                            if (position == 0) {
                                frameSolid!!.setVisibility(View.GONE)
                                frameCreation!!.setVisibility(View.VISIBLE)
                                frameGallery!!.setVisibility(View.GONE)
                                frameGradient!!.setVisibility(View.GONE)
                                frameText!!.setVisibility(View.GONE)
                            } else if (position == 1) {
                                frameSolid!!.setVisibility(View.GONE)
                                frameCreation!!.setVisibility(View.GONE)
                                frameGallery!!.setVisibility(View.VISIBLE)
                                frameGradient!!.setVisibility(View.GONE)
                                frameText!!.setVisibility(View.GONE)
                            }
                        } else {
                            isFirstC = true
                        }
                    }

                    public override fun onNothingSelected(parent: AdapterView<*>?) {
                        isFirstC1 = true
                    }
                })
                spinnerSolidDD!!.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                    public override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                        if (isFirstS) {
                            positionSolid = position
                            txtSolidDD!!.setText(items.get(position))
                            if (position == 0) {
                                frameSolid!!.setVisibility(View.VISIBLE)
                                frameCreation!!.setVisibility(View.GONE)
                                frameGallery!!.setVisibility(View.GONE)
                                frameGradient!!.setVisibility(View.GONE)
                                frameText!!.setVisibility(View.GONE)
                            } else if (position == 1) {
                                frameSolid!!.setVisibility(View.GONE)
                                frameCreation!!.setVisibility(View.GONE)
                                frameGallery!!.setVisibility(View.GONE)
                                frameGradient!!.setVisibility(View.VISIBLE)
                                frameText!!.setVisibility(View.GONE)
                            } else if (position == 2) {
                                frameSolid!!.setVisibility(View.GONE)
                                frameCreation!!.setVisibility(View.GONE)
                                frameGallery!!.setVisibility(View.GONE)
                                frameGradient!!.setVisibility(View.GONE)
                                frameText!!.setVisibility(View.VISIBLE)
                            }
                        } else {
                            isFirstS = true
                        }
                    }

                    public override fun onNothingSelected(parent: AdapterView<*>?) {
                        isFirstS1 = true
                    }
                })
                val transaction: FragmentTransaction = getSupportFragmentManager().beginTransaction()
                transaction.replace(R.id.frameSolid, solidSelectableFragment!!)
                transaction.replace(R.id.frameCreation, creationSelectableFragment!!)
                transaction.replace(R.id.frameGradient, gradientSelectableFragment!!)
                transaction.replace(R.id.frameText, textSelectableFragment!!)
                transaction.replace(R.id.frameGallery, gallerySelectableFragment!!)
                transaction.commitAllowingStateLoss()
                frameSolid!!.setVisibility(View.VISIBLE)
                frameCreation!!.setVisibility(View.GONE)
                frameGallery!!.setVisibility(View.GONE)
                frameGradient!!.setVisibility(View.GONE)
                frameText!!.setVisibility(View.GONE)
                progressFragment!!.setVisibility(View.GONE)
            }
        }, 300)
    }

    internal inner class LoadSelectedImages constructor() : AsyncTask<Void?, Boolean?, Boolean>() {
        var mBitmapList: ArrayList<SettingsImagesModel>? = null
        var count: Int = 0
        var isTextOrGallery: Boolean = false
        override fun onPostExecute(isTrue: Boolean) {
            super.onPostExecute(isTrue)
            Log.d("1278912789", "onPostExecute: " + isTrue + "  " + isTextOrGallery)
            if (isTrue && isTextOrGallery) {
                progressRecycler!!.setVisibility(View.GONE)
                setDataToAdapter(mBitmapList)
            }
            if (!isTextOrGallery) {
                progressRecycler!!.setVisibility(View.GONE)
                setDataToAdapter(mBitmapList)
            }
        }

        protected override fun doInBackground(vararg params: Void?): Boolean? {
            val metrics: DisplayMetrics = DisplayMetrics()
            getWindowManager().getDefaultDisplay().getMetrics(metrics)
            mBitmapList = ArrayList()
            for (`object`: Any? in mSelectedList!!) {
                if (`object` is SolidSelectableModel) {
                    val shape: GradientDrawable = GradientDrawable()
                    shape.setShape(GradientDrawable.RECTANGLE)
                    shape.setColors(intArrayOf(`object`.solidColorModel.color, `object`.solidColorModel.color))
                    mBitmapList!!.add(SettingsImagesModel(convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels), false))
                } else if (`object` is GradientSelectableModel) {
                    if (`object`.colorModel.circle) {
                        val shape: GradientDrawable = GradientDrawable()
                        shape.setShape(GradientDrawable.RECTANGLE)
                        shape.setColors(intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                        shape.setGradientType(GradientDrawable.RADIAL_GRADIENT)
                        shape.setGradientRadius(metrics.widthPixels.toFloat())
                        mBitmapList!!.add(SettingsImagesModel(convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels), false))
                    } else {
                        val shape: GradientDrawable = GradientDrawable(`object`.colorModel.orientation, intArrayOf(`object`.colorModel.color1, `object`.colorModel.color2))
                        shape.setShape(GradientDrawable.RECTANGLE)
                        mBitmapList!!.add(SettingsImagesModel(convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels), false))
                    }
                } else if (`object` is TextSelectableModel) {
                    isTextOrGallery = true
                    Glide.with(this@AutoWallpaperChangerBackupActivity).asBitmap().override(1000).load(`object`.imgePath).into(object : CustomTarget<Bitmap?>() {
                        public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                            Log.d("1278912789", "onResourceReady: 1 " + count + " = " + glideLoadImageCount)
                            mBitmapList!!.add(SettingsImagesModel(resource, false))
                            count++
                            if (count == glideLoadImageCount) {
                                onPostExecute(true)
                                count++
                            }
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                } else if (`object` is SavedImageModel) {
                    isTextOrGallery = true
                    Glide.with(this@AutoWallpaperChangerBackupActivity).asBitmap().override(1000).load(`object`.path).into(object : CustomTarget<Bitmap?>() {
                        public override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                            Log.d("1278912789", "onResourceReady: 2 " + count + " = " + glideLoadImageCount)
                            mBitmapList!!.add(SettingsImagesModel(resource, false))
                            count++
                            if (count == glideLoadImageCount) {
                                onPostExecute(true)
                                count++
                            }
                        }

                        public override fun onLoadCleared(placeholder: Drawable?) {}
                    })
                }
            }
            return false
        }
    }

    fun getBitmap(path: String?): Bitmap? {
        try {
            var bitmap: Bitmap? = null
            val f: File = File(path)
            val options: BitmapFactory.Options = BitmapFactory.Options()
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            bitmap = BitmapFactory.decodeStream(FileInputStream(f), null, options)
            return bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun setDataToAdapter(mBitmapList: ArrayList<SettingsImagesModel>?) {
        for (mo: SettingsImagesModel in mBitmapList!!) {
            Log.d("1278912789", "setDataToAdapter: " + mo.bitmap)
            this.mBitmapList!!.add(mo.bitmap)
        }
        mSelectedImagesList!!.addAll((mBitmapList))
        recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
        progressRecycler!!.setVisibility(View.GONE)
        val onLongClicked: OnLongClicked = object : OnLongClicked {
            public override fun onLongClicked(isClicked: Boolean) {
                isLongClicked = true
                bottomButtonEditSettings!!.setVisibility(View.VISIBLE)
                bottomButtonEditSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                bottomButtonLayoutSettings!!.post(object : Runnable {
                    public override fun run() {
                        bottomButtonLayoutSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                        bottomButtonEditSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                    }
                })
            }
        }
        settingsRecyclerAdapter = SettingsRecyclerAdapter((mSelectedImagesList)!!, this@AutoWallpaperChangerBackupActivity, onLongClicked)
        recyclerSelectedWallpaper!!.setAdapter(settingsRecyclerAdapter)
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = getResources()
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.getDisplayMetrics()))
    }

    fun convertToBitmap(drawable: GradientDrawable, widthPixels: Int, heightPixels: Int): Bitmap {
        val mutableBitmap: Bitmap = Bitmap.createBitmap(widthPixels, heightPixels, Bitmap.Config.ARGB_8888)
        val canvas: Canvas = Canvas(mutableBitmap)
        drawable.setBounds(0, 0, widthPixels, heightPixels)
        drawable.draw(canvas)
        return mutableBitmap
    }

    public override fun onBackPressed() {
        if (isLongClicked && settingsRecyclerAdapter != null) {
            settingsRecyclerAdapter!!.setDataChanged()
            isLongClicked = false
            bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
            bottomButtonEditSettings!!.animate().translationYBy(bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
            return
        }
        if (isAddMenuOpen) {
            isAddMenuOpen = false
            cstMainSettings!!.setVisibility(View.VISIBLE)
            layoutTopSetting!!.setVisibility(View.VISIBLE)
            bottomButtonLayoutSettings!!.setVisibility(View.INVISIBLE)
            layoutTopSetting!!.post(object : Runnable {
                public override fun run() {
                    layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
                    Handler().postDelayed(object : Runnable {
                        public override fun run() {
                            layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                        }
                    }, 100)
                    layoutSelectWallpaper!!.animate().translationYBy(layoutMainWallpaperList!!.getHeight().toFloat()).withEndAction(object : Runnable {
                        public override fun run() {
                            progressRecycler!!.setVisibility(View.GONE)
                            bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                            bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                            bottomButtonLayoutSettings!!.post(object : Runnable {
                                public override fun run() {
                                    bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                                }
                            })
                            recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                        }
                    }).setDuration(300).start()
                    if (!isEditClicked) {
                        if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                            btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    btnNext!!.setVisibility(View.INVISIBLE)
                                    isSelectWallpaperMenuOpen = false
                                }
                            }).setDuration(300).start()
                            icSubcription!!.setVisibility(View.VISIBLE)
                            icSubcription!!.animate().alpha(1f).setDuration(300).start()
                        } else {
                            btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                                public override fun run() {
                                    btnNext!!.setVisibility(View.INVISIBLE)
                                    isSelectWallpaperMenuOpen = false
                                }
                            }).setDuration(300).start()
                            btnShare!!.setVisibility(View.VISIBLE)
                            btnShare!!.animate().alpha(1f).setDuration(300).start()
                        }
                    }
                    isSelectWallpaperMenuOpen = false
                }
            })
            return
        }
        Log.d("781212312313231", "onBackPressed: " + isEditOpen)
        if (isEditOpen) {
            isEditOpen = false
            if (settingsRecyclerAdapter != null) {
                settingsRecyclerAdapter!!.setDataChanged()
            }
            cstMainSettings!!.setVisibility(View.VISIBLE)
            layoutTopSetting!!.setVisibility(View.VISIBLE)
            bottomButtonLayoutSettings!!.setVisibility(View.INVISIBLE)
            layoutTopSetting!!.setTranslationY(-layoutTopSetting!!.getHeight().toFloat())
            Handler().postDelayed(object : Runnable {
                public override fun run() {
                    layoutTopSetting!!.animate().translationYBy(layoutTopSetting!!.getHeight().toFloat()).setDuration(300).start()
                }
            }, 100)
            Log.d("8745617688778", "run: " + layoutSelectWallpaper!!.getHeight())
            layoutSelectWallpaper!!.animate().translationYBy(layoutSelectWallpaper!!.getHeight().toFloat()).withEndAction(object : Runnable {
                public override fun run() {
                    progressRecycler!!.setVisibility(View.GONE)
                    bottomButtonLayoutSettings!!.setVisibility(View.VISIBLE)
                    bottomButtonLayoutSettings!!.setTranslationY(bottomButtonLayoutSettings!!.getHeight().toFloat())
                    bottomButtonLayoutSettings!!.post(object : Runnable {
                        public override fun run() {
                            bottomButtonLayoutSettings!!.animate().translationYBy(-bottomButtonLayoutSettings!!.getHeight().toFloat()).setDuration(300).start()
                        }
                    })
                    recyclerSelectedWallpaper!!.setVisibility(View.VISIBLE)
                }
            }).setDuration(300).start()
            if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                    public override fun run() {
                        btnNext!!.setVisibility(View.INVISIBLE)
                        isSelectWallpaperMenuOpen = false
                    }
                }).setDuration(300).start()
                icSubcription!!.setVisibility(View.VISIBLE)
                icSubcription!!.animate().alpha(1f).setDuration(300).start()
            } else {
                btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                    public override fun run() {
                        btnNext!!.setVisibility(View.INVISIBLE)
                        isSelectWallpaperMenuOpen = false
                    }
                }).setDuration(300).start()
                btnShare!!.setVisibility(View.VISIBLE)
                btnShare!!.animate().alpha(1f).setDuration(300).start()
            }
            isSelectWallpaperMenuOpen = false
            return
        }
        Log.d("78912781231", "onBackPressed: " + isSettingsOpen)
        if (isSettingsOpen) {
            showAlertDialogDiscard()
            return
        }
        if (isSelectWallpaperMenuOpen) {
            layoutMainWallpaperList!!.animate().translationYBy(layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
            layoutSelectWallpaper!!.animate().translationYBy(layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
            if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                    public override fun run() {
                        Log.d(TAG, "run: ")
                        btnNext!!.setVisibility(View.INVISIBLE)
                        isSelectWallpaperMenuOpen = false
                    }
                }).setDuration(300).start()
                icSubcription!!.setVisibility(View.VISIBLE)
                icSubcription!!.animate().alpha(1f).setDuration(300).start()
            } else {
                btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                    public override fun run() {
                        btnNext!!.setVisibility(View.INVISIBLE)
                        isSelectWallpaperMenuOpen = false
                    }
                }).setDuration(300).start()
                btnShare!!.setVisibility(View.VISIBLE)
                btnShare!!.animate().alpha(1f).setDuration(300).start()
            }
        } else {
            super.onBackPressed()
        }
    }

    private fun showAlertDialogDiscard() {
         bottomSheetFragment= BottomSheetFragmentDiscard(getResources().getString(R.string.dialog_home), getResources().getString(R.string.do_you_want_to_discard), getResources().getString(R.string.discard), getResources().getString(R.string.cancel), R.drawable.ic_discard_dialog, object : BottomSheetFragmentDiscard.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragmentDiscard?) {
                bottomSheetDialo!!.dismiss()
                layoutMainWallpaperList!!.animate().translationYBy(layoutMainWallpaperList!!.getHeight().toFloat()).setDuration(300).start()
                isSettingsOpen = false
                isEditSettingsOpen = false
                cstMainSettings!!.setVisibility(View.GONE)
                if (isEditClicked) {
                    isEditClicked = false
                    if (!getBoolean(this@AutoWallpaperChangerBackupActivity, AdsPrefs.IS_SUBSCRIBED, false)) {
                        btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                            public override fun run() {
                                Log.d(TAG, "run: ")
                                btnNext!!.setVisibility(View.INVISIBLE)
                                isSelectWallpaperMenuOpen = false
                            }
                        }).setDuration(300).start()
                        icSubcription!!.setVisibility(View.VISIBLE)
                        icSubcription!!.animate().alpha(1f).setDuration(300).start()
                    } else {
                        btnNext!!.animate().alpha(0f).withEndAction(object : Runnable {
                            public override fun run() {
                                btnNext!!.setVisibility(View.INVISIBLE)
                                isSelectWallpaperMenuOpen = false
                            }
                        }).setDuration(300).start()
                        btnShare!!.setVisibility(View.VISIBLE)
                        btnShare!!.animate().alpha(1f).setDuration(300).start()
                    }
                    isSelectWallpaperMenuOpen = false
                }
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragmentDiscard?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragment!!.show(getSupportFragmentManager(), "dialog")
    }

    override fun onPause() {
        super.onPause()
        try {
            bottomSheetFragment!!.dismiss()
            bottomSheetFragments!!.dismiss()
        }catch (e:Exception){

        }
    }

    override fun onResume() {
        Log.d(TAG, "onResume: " + isApplyClicked)
        /* if (isApplyClicked) {
            isApplyClicked = false;
            isSettingsOpen = false;
            isEditSettingsOpen = false;
            getDataWallpaper();
            if (mAllWallpaperList.size() > 0) {
                recyclerMainWallpaer.setVisibility(View.VISIBLE);
                layoutNoWallpaper.setVisibility(View.GONE);

                recyclerMainWallpaer.setLayoutManager(new LinearLayoutManager(AutoWallpaperChangerBackupActivity.this, RecyclerView.VERTICAL, false));

                liveWallpaperAdapter = new LiveWallpaperListAdapter(mAllWallpaperList, AutoWallpaperChangerBackupActivity.this, new LiveWallpaperListAdapter.OnSelectAction() {
                    @Override
                    public void onPlay(AutoWallpaperModel autoWallpaperModel) {
                        dbHelperAutoWallpaper.updateDataRow(autoWallpaperModel.getId());
                        setAlarmAuto(autoWallpaperModel);
                    }

                    @Override
                    public void onEdit(AutoWallpaperModel autoWallpaperModel) {
                        editWallpaper(autoWallpaperModel);
                    }

                    @Override
                    public void onDelete(AutoWallpaperModel autoWallpaperModel) {
                        showRemoveDialog(autoWallpaperModel);
                    }
                });
                recyclerMainWallpaer.setAdapter(liveWallpaperAdapter);
            } else {
                recyclerMainWallpaer.setVisibility(View.GONE);
                layoutNoWallpaper.setVisibility(View.VISIBLE);
            }

            layoutMainWallpaperList.animate().translationYBy(layoutMainWallpaperList.getHeight()).setDuration(300).start();
            // cstMainSettings.animate().translationYBy(cstMainSettings.getHeight()).setDuration(300).start();
            cstMainSettings.setVisibility(View.GONE);
        }*/super.onResume()
    }

    private fun showRemoveDialog(autoWallpaperModel: AutoWallpaperModel?) {
         bottomSheetFragments = BottomSheetFragment(resources.getString(R.string.delete), resources.getString(R.string.are_you_want_to_remove), getResources().getString(R.string.delete), getResources().getString(R.string.cancel), R.drawable.ic_delete_dialog, object : BottomSheetFragment.OnButtonClickListener {
            public override fun onPositive(bottomSheetDialo: BottomSheetFragment?) {
                if (dbHelperAutoWallpaper != null) {
                    dbHelperAutoWallpaper!!.deleteData(autoWallpaperModel!!.id)
                    dataWallpaper
                    if (mAllWallpaperList!!.size > 0) {
                        recyclerMainWallpaer!!.setVisibility(View.VISIBLE)
                        layoutNoWallpaper!!.setVisibility(View.GONE)
                        liveWallpaperAdapter = LiveWallpaperListAdapter((mAllWallpaperList)!!, this@AutoWallpaperChangerBackupActivity, object : OnSelectAction {
                            public override fun onPlay(autoWallpaperModel: AutoWallpaperModel?) {
                                dbHelperAutoWallpaper!!.updateDataRow(autoWallpaperModel!!.id)
                                setAlarmAuto(autoWallpaperModel)
                            }

                            public override fun onEdit(autoWallpaperModel: AutoWallpaperModel?) {
                                editWallpaper(autoWallpaperModel)
                            }

                            public override fun onDelete(autoWallpaperModel: AutoWallpaperModel?) {
                                showRemoveDialog(autoWallpaperModel)
                            }
                        })
                        recyclerMainWallpaer!!.setAdapter(liveWallpaperAdapter)
                    } else {
                        recyclerMainWallpaer!!.setVisibility(View.GONE)
                        layoutNoWallpaper!!.setVisibility(View.VISIBLE)
                    }
                }
                bottomSheetDialo!!.dismiss()
            }

            public override fun onNegative(bottomSheetDialog: BottomSheetFragment?) {
                bottomSheetDialog!!.dismiss()
            }
        })
        bottomSheetFragments!!.show(supportFragmentManager, "dialog")
    }

    companion object {
        private val TAG: String = "AutoWallpaperChangerAct"
    }
}