package com.hd.wallpaper.solid.color.background.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.skyfishjy.library.RippleBackground
import com.hd.wallpaper.solid.color.background.R

class SpotlightFragment : Fragment {
    private var onItemClicked: OnItemClicked? = null
    private var position: Int = 1

    constructor() {
        // Required empty public constructor
    }

    constructor(onItemClicked: OnItemClicked?, i: Int) {
        this.onItemClicked = onItemClicked
        position = i
        Log.d("TAG====>>>>", "SpotlightFragment: " + i)
    }

    open interface OnItemClicked {
        fun onItemClicked()
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_spotlight, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mRipplePulseLayout: RippleBackground = view.findViewById(R.id.content)
        mRipplePulseLayout.startRippleAnimation()
        view.findViewById<View>(R.id.mainFrame).setOnClickListener(View.OnClickListener({ v: View? -> }))
        if (position == 0) {
            view.findViewById<View>(R.id.txtText).setVisibility(View.GONE)
            view.findViewById<View>(R.id.txtGradient).setVisibility(View.GONE)
            view.findViewById<View>(R.id.txtSolid).setVisibility(View.VISIBLE)
        } else if (position == 1) {
            view.findViewById<View>(R.id.txtText).setVisibility(View.GONE)
            view.findViewById<View>(R.id.txtGradient).setVisibility(View.VISIBLE)
            view.findViewById<View>(R.id.txtSolid).setVisibility(View.GONE)
        } else {
            view.findViewById<View>(R.id.txtText).setVisibility(View.VISIBLE)
            view.findViewById<View>(R.id.txtGradient).setVisibility(View.GONE)
            view.findViewById<View>(R.id.txtSolid).setVisibility(View.GONE)
        }
        view.findViewById<View>(R.id.btnAdd).setOnClickListener(View.OnClickListener({ v: View? -> onItemClicked!!.onItemClicked() }))
    }
}