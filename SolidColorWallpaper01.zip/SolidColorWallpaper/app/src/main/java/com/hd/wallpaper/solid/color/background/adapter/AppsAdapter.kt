package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R

class AppsAdapter(private val mContext: Context, private val mAppList: List<ResolveInfo>, private val pm: PackageManager, private val onSelectApp: onSelectAppN) : RecyclerView.Adapter<AppsAdapter.MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val v = LayoutInflater.from(mContext).inflate(R.layout.layout_app_item, null)
        return MyViewHolder(v)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val info = mAppList[position]
        holder.imgAppIcon.setImageDrawable(info.loadIcon(pm))
        holder.txtAppName.text = info.loadLabel(pm)
        holder.mainLayout.setOnClickListener { onSelectApp.onClickApp(position) }
    }

    override fun getItemCount(): Int {
        return mAppList.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgAppIcon: ImageView = itemView.findViewById(R.id.imgAppIcon)
        var txtAppName: TextView = itemView.findViewById(R.id.txtAppName)
        var mainLayout: LinearLayout = itemView.findViewById(R.id.mainLayout)
    }

    interface onSelectAppN {
        fun onClickApp(i: Int)
    }

    companion object {
        private const val TAG = "AppsAdapter"
    }

}