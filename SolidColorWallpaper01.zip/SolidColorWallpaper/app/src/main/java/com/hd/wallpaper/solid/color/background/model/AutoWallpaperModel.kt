package com.hd.wallpaper.solid.color.background.model

import java.io.Serializable

class AutoWallpaperModel : Serializable {
    var id = 0
    var delaytime: String? = null
    var screenmode: String? = null
    var imagespath: String? = null
    var status = 0

    constructor() {}
    constructor(id: Int, delaytime: String?, screenmode: String?, imagespath: String?, status: Int) {
        this.id = id
        this.delaytime = delaytime
        this.screenmode = screenmode
        this.imagespath = imagespath
        this.status = status
    }

    constructor(delaytime: String?, screenmode: String?, imagespath: String?, status: Int) {
        this.delaytime = delaytime
        this.screenmode = screenmode
        this.imagespath = imagespath
        this.status = status
    }

}