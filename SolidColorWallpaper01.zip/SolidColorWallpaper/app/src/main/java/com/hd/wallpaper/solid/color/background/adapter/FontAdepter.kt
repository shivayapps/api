package com.hd.wallpaper.solid.color.background.adapter

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import java.util.*

class FontAdepter(private val mFontNames: ArrayList<String>, private val mContext: Context, private val mListener: setOnItemClickListener) : RecyclerView.Adapter<FontAdepter.MyViewHolder>() {
    private var lastCheckedPosition = 0

    interface setOnItemClickListener {
        fun OnItemClicked(position: Int)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(mContext).inflate(R.layout.font_item, viewGroup, false))
    }

    override fun onBindViewHolder(myViewHolder: MyViewHolder, i: Int) {
        val typeface = Typeface.createFromAsset(mContext.assets, mFontNames[i])
        myViewHolder.txtFont.typeface = typeface
        myViewHolder.txtFont.setPadding(0, 0, 0, 0)
        myViewHolder.txtFont.text = "Hello"
        if (lastCheckedPosition == i) {
            myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_selected)
        } else {
            myViewHolder.parentLayout.setBackgroundResource(R.drawable.rectangle_unselected)
        }
        //myViewHolder.imgColor.setVisibility(View.GONE);
        myViewHolder.txtFont.setOnClickListener {
            mListener.OnItemClicked(i)
            lastCheckedPosition = i
            notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return mFontNames.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var parentLayout: LinearLayout = itemView.findViewById(R.id.parentLayout)
        val txtFont: TextView = itemView.findViewById(R.id.txtFont)

    }

}