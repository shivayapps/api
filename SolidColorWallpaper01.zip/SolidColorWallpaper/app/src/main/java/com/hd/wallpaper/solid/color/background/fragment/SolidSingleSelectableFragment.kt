package com.hd.wallpaper.solid.color.background.fragment

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hd.wallpaper.solid.color.background.R
import com.hd.wallpaper.solid.color.background.adapter.SolidColorSingleSelectableAdapter
import com.hd.wallpaper.solid.color.background.custom.GridSpacingItemDecoration
import com.hd.wallpaper.solid.color.background.model.SolidColorModel
import com.hd.wallpaper.solid.color.background.model.SolidSelectableModel
import java.util.*

class SolidSingleSelectableFragment : Fragment {
    var recyclerColor: RecyclerView? = null
    private var mColors: ArrayList<SolidSelectableModel>? = null
    private var onItemClicked: OnItemClicked? = null
    private var colorAdepter: SolidColorSingleSelectableAdapter? = null

    constructor() {
        // Required empty public constructor
    }

    constructor(onItemClicked: OnItemClicked?) {
        this.onItemClicked = onItemClicked
    }

    open interface OnItemClicked {
        fun onItemClicked()
    }

    public override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                                     savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_solid_selectable, container, false)
    }

    public override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        System.gc()
        Runtime.getRuntime().gc()
        mColors = ArrayList()
        val allColors: Array<String> = resources.getStringArray(R.array.colors)
        for (i in allColors.indices) {
            val model: SolidColorModel = SolidColorModel()
            model.color = Color.parseColor(allColors.get(i))
            mColors!!.add(SolidSelectableModel(model, false))
        }
        recyclerColor = view.findViewById(R.id.recyclerColor)
        val manager: GridLayoutManager = GridLayoutManager(activity, 3)
        recyclerColor!!.layoutManager = manager
        recyclerColor!!.addItemDecoration(GridSpacingItemDecoration(3, dpToPx(8), true))
        recyclerColor!!.itemAnimator = DefaultItemAnimator()
        val listener: SolidColorSingleSelectableAdapter.setOnItemClickListener = object : SolidColorSingleSelectableAdapter.setOnItemClickListener {
            public override fun OnItemClicked(model: SolidSelectableModel?, i: Int) {
                onItemClicked!!.onItemClicked()
            }
        }
        colorAdepter = SolidColorSingleSelectableAdapter(mColors!!, activity!!, listener)
        recyclerColor!!.adapter = colorAdepter
    }/*  final GradientDrawable shape = new GradientDrawable();
                    shape.setShape(GradientDrawable.RECTANGLE);
                    shape.setColors(new int[]{mColors.get(i).getSolidColorModel().getColor(), mColors.get(i).getSolidColorModel().getColor()});
                    mList.add(convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels));*/

    //  DisplayMetrics metrics = new DisplayMetrics();
    //   Objects.requireNonNull(getActivity()).getWindowManager().getDefaultDisplay().getMetrics(metrics);
    val dataList: ArrayList<SolidSelectableModel>
        get() {
            val mList: ArrayList<SolidSelectableModel> = ArrayList()
            if (mColors != null) {
                //  DisplayMetrics metrics = new DisplayMetrics();
                //   Objects.requireNonNull(getActivity()).getWindowManager().getDefaultDisplay().getMetrics(metrics);
                for (i in mColors!!.indices) {
                    if (mColors!![i].isDeletable) {
                        /*  final GradientDrawable shape = new GradientDrawable();
                        shape.setShape(GradientDrawable.RECTANGLE);
                        shape.setColors(new int[]{mColors.get(i).getSolidColorModel().getColor(), mColors.get(i).getSolidColorModel().getColor()});
                        mList.add(convertToBitmap(shape, metrics.widthPixels, metrics.heightPixels));*/
                        mList.add(mColors!![i])
                    }
                }
            }
            return mList
        }

    fun setDataChanged() {
        if (colorAdepter != null) {
            colorAdepter!!.setDataChange()
        }
    }

    fun convertToBitmap(drawable: GradientDrawable, widthPixels: Int, heightPixels: Int): Bitmap {
        val mutableBitmap: Bitmap = Bitmap.createBitmap(widthPixels, heightPixels, Bitmap.Config.ARGB_8888)
        val canvas: Canvas = Canvas(mutableBitmap)
        drawable.setBounds(0, 0, widthPixels, heightPixels)
        drawable.draw(canvas)
        return mutableBitmap
    }

    private fun dpToPx(dp: Int): Int {
        val r: Resources = getResources()
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), r.displayMetrics))
    }
}