package messages.text.sms.feature.blocking

data class KeywordItem(val keyword: String)
