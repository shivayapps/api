package messages.text.sms.model

open class ConversationAD(val position: Int) : ModelType {

    override fun getType(): Int {
        return AD_TYPE
    }

}
