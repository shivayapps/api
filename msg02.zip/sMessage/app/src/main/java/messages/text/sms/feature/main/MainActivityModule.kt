package messages.text.sms.feature.main

import androidx.lifecycle.ViewModel
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import io.reactivex.disposables.CompositeDisposable
import messages.text.sms.injection.ViewModelKey
import messages.text.sms.injection.scope.ActivityScope

@Module
class MainActivityModule {

    @Provides
    @ActivityScope
    fun provideCompositeDiposableLifecycle(): CompositeDisposable = CompositeDisposable()

    @Provides
    @IntoMap
    @ViewModelKey(MainViewModel::class)
    fun provideMainViewModel(viewModel: MainViewModel): ViewModel = viewModel

    @Provides
    @IntoMap
    @ViewModelKey(ArchiveViewModel::class)
    fun provideArchiveViewModel(viewModel: ArchiveViewModel): ViewModel = viewModel

    @Provides
    @IntoMap
    @ViewModelKey(PrivateBoxViewModel::class)
    fun providePrivateBoxViewModel(viewModel: PrivateBoxViewModel): ViewModel = viewModel

    @Provides
    @IntoMap
    @ViewModelKey(BlockedMessageViewModel::class)
    fun provideBlockedMessageViewModel(viewModel: BlockedMessageViewModel): ViewModel = viewModel
}