package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.manager.ShortcutManager
import messages.text.sms.manager.WidgetManager
import javax.inject.Inject

class UpdateBadge @Inject constructor(
    private val shortcutManager: ShortcutManager,
    private val widgetManager: WidgetManager,
) : Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<*> {
        return Flowable.just(params)
            .doOnNext { shortcutManager.updateBadge() }
            .doOnNext { widgetManager.updateUnreadCount() }
    }

}