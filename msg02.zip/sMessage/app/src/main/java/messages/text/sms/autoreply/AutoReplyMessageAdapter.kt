package messages.text.sms.autoreply

import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R

class AutoReplyMessageAdapter(
    private var messages: MutableList<String>,
    private var selectedIndex: Int,
    private val onSelected: (Int) -> Unit,
    private val onEdited: (Int, String) -> Unit,
    private val onDeleted: (Int) -> Unit,
) : RecyclerView.Adapter<AutoReplyMessageAdapter.ViewHolder>() {

    private var isEditMode = false

    fun setEditMode(enabled: Boolean) {
        isEditMode = enabled
        notifyDataSetChanged()
    }

    fun updateMessages(newMessages: List<String>) {
        messages = newMessages.toMutableList()
        notifyDataSetChanged()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val radio: RadioButton = view.findViewById(R.id.radioButton)
        val text: TextView = view.findViewById(R.id.tvMessage)
        val btnEdit: ImageView = view.findViewById(R.id.btnEdit)
        val btnDelete: ImageView = view.findViewById(R.id.btnDelete)

        init {
            radio.setOnClickListener {
                onSelected(adapterPosition)
            }

            btnEdit.setOnClickListener {
                val editText = EditText(view.context)
                editText.setText(messages[adapterPosition])
                AlertDialog.Builder(view.context)
                    .setTitle("Edit Message")
                    .setView(editText)
                    .setPositiveButton("Save") { _, _ ->
                        onEdited(adapterPosition, editText.text.toString())
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            btnDelete.setOnClickListener {
                AlertDialog.Builder(view.context)
                    .setTitle("Delete")
                    .setMessage("Delete this message?")
                    .setPositiveButton("Yes") { _, _ -> onDeleted(adapterPosition) }
                    .setNegativeButton("No", null)
                    .show()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_auto_reply_message, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount() = messages.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.text.text = messages[position]
        holder.radio.isChecked = position == selectedIndex
        holder.btnEdit.visibility = if (isEditMode) View.VISIBLE else View.GONE
        holder.btnDelete.visibility = if (isEditMode) View.VISIBLE else View.GONE
    }
}
