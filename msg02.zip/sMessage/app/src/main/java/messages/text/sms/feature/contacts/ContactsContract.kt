package messages.text.sms.feature.contacts

import io.reactivex.Observable
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MainBaseMsgView
import messages.text.sms.extensions.Optional
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.model.ContactDataItem

interface ContactsContract : MainBaseMsgView<ContactsState> {

    val queryChangedIntent: Observable<CharSequence>
    val queryClearedIntent: Observable<*>
    val queryBack: Observable<*>
    val queryEditorActionIntent: Observable<Int>
    val composeItemPressedIntent: Subject<ContactDataItem>
    val composeItemLongPressedIntent: Subject<ContactDataItem>
    val phoneNumberSelectedIntent: Subject<Optional<Long>>
    val phoneNumberActionIntent: Subject<PhoneNumberAction>
    val loadContacts: Observable<*>

    fun clearQuery()
    fun openKeyboard()
    fun back()
    fun finish(result: HashMap<String, String?>)

}
