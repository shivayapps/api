package messages.text.sms.feature.blocking

import android.view.View
import com.bluelinelabs.conductor.RouterTransaction
import com.jakewharton.rxbinding2.view.clicks
import messages.text.sms.R
import messages.text.sms.common.MysmsChangeHandler
import messages.text.sms.common.base.MainBaseController
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.animateLayoutChanges
import messages.text.sms.common.widget.QkSwitch
import messages.text.sms.databinding.BlockingControllerBinding
import messages.text.sms.feature.blocking.messages.BlockedMessagesController
import messages.text.sms.feature.blocking.numbers.BlockedNumbersController
import messages.text.sms.injection.appComponent
import javax.inject.Inject

class BlockingController :
    MainBaseController<BlockingView, BlockingState, BlockingPresenter, BlockingControllerBinding>(
        BlockingControllerBinding::inflate
    ), BlockingView {

    //    override val blockingManagerIntent by lazy { binding.blockingManager.clicks() }
    override val blockedNumbersIntent by lazy { binding.blockedNumbers.clicks() }
    override val blockedMessagesIntent by lazy { binding.blockedMessages.clicks() }
    override val dropClickedIntent by lazy { binding.drop.clicks() }

    @Inject
    lateinit var colors: Colors

    @Inject
    override lateinit var presenter: BlockingPresenter

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH
    }

    override fun onViewCreated() {
        super.onViewCreated()
        binding.parent.postDelayed({ binding.parent.animateLayoutChanges = true }, 100)
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.blocking_title)
//        showBackButton(true)
    }

    override fun render(state: BlockingState) {
//        binding.blockingManager.summary = state.blockingManager
        binding.drop.widget<QkSwitch>().isChecked = state.dropEnabled
        binding.blockedMessages.isEnabled = !state.dropEnabled
    }

    override fun openBlockedNumbers() {
        router.pushController(
            RouterTransaction.with(BlockedNumbersController())
                .pushChangeHandler(MysmsChangeHandler())
                .popChangeHandler(MysmsChangeHandler())
        )
    }

    override fun openBlockedMessages() {
        router.pushController(
            RouterTransaction.with(BlockedMessagesController())
                .pushChangeHandler(MysmsChangeHandler())
                .popChangeHandler(MysmsChangeHandler())
        )
    }

//    override fun openBlockingManager() {
//        router.pushController(
//            RouterTransaction.with(BlockingManagerController())
//                .pushChangeHandler(MysmsChangeHandler())
//                .popChangeHandler(MysmsChangeHandler())
//        )
//    }

}
