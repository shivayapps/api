package  messages.text.sms.ads

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.TextView
import androidx.annotation.ColorInt
import messages.text.sms.R
import messages.text.sms.commons.extensions.clientConfigPref
import messenger.chat.text.messages.sms.ads.NetworkObserver


val Context.firebaseAnalyticsHandler: FirebaseAnalyticsHandler get() = FirebaseAnalyticsHandler(this)

fun Context.isFirstTimeAppOpen(): Boolean {
    return AdsPreferences(this).splashCounter <= 1
}

var logCount = 0
var adapterCalling = 0
var adapterDataLastSize = 0
fun Context.isFirstTimeonCreateLog(): Boolean {
    return AdsPreferences(this).firstonCreateLog <= 1
}

fun Context.isFirstTimeLog(): Boolean {
    return AdsPreferences(this).firstLog <= 1
}

fun Activity.delayExecution(millis: Long, callback: () -> Unit) {
    try {
        Handler(Looper.myLooper()!!).postDelayed({
            callback()
        }, millis)
    } catch (e: Exception) {
        callback()
    }
}

fun Context.getAppOpenSplash(): String {
    return clientConfigPref.AppOpenAdInSplashID
}

fun Context.getAppListNative1(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native1_1")
        return getString(R.string.home_banner_native1_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native1_2")
    return getString(R.string.home_banner_native1_2)
}

fun Context.getAppListNative3(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native3_1")
        return getString(R.string.home_banner_native3_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native3_2")
    return getString(R.string.home_banner_native3_2)
}

fun Context.getAppListNative2(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native2_1")
        return getString(R.string.home_banner_native2_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native2_2")
    return getString(R.string.home_banner_native2_2)
}

fun Context.getAppArchivedNative1(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native1_1")
        return getString(R.string.home_archived_native1_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native1_2")
    return getString(R.string.home_archived_native1_2)
}

fun Context.getAppArchivedNative3(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native3_1")
        return getString(R.string.home_archived_native3_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native3_2")
    return getString(R.string.home_archived_native3_2)
}

fun Context.getAppPrivateNative1(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native1_1")
        return getString(R.string.home_private_native1_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native1_2")
    return getString(R.string.home_private_native1_2)
}

fun Context.getAppPrivateNative3(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: home_banner_native3_1")
        return getString(R.string.home_private_native3_1)
    }
    Log.d("AdsId", "getAppListNative: home_banner_native3_2")
    return getString(R.string.home_private_native3_2)
}

fun Context.getAppManageAppsNative(): String {
    if (AdsPreferences(this).selectedLanguage.isEmpty()) {
        Log.d("AdsId", "getAppListNative: manage_apps_native_1")
        return getString(R.string.manage_apps_native_1)
    }
    Log.d("AdsId", "getAppListNative: manage_apps_native_2")
    return getString(R.string.manage_apps_native_2)
}


fun Context.getAppChatScreenNative(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: chat_screen_native_1")
        return getString(R.string.chat_screen_native_1)
    }
    Log.d("AdsId", "getAppListNative: chat_screen_native_2")
    return getString(R.string.chat_screen_native_2)
}

fun Context.getAppHomeBanner(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppListNative: admob_home_banner_1")
        return getString(R.string.admob_home_banner_1)
    }
    Log.d("AdsId", "getAppListNative: admob_home_banner_2")
    return getString(R.string.admob_home_banner_2)
}

fun Context.getExitBanner(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getExitBanner: admob_exit_banner_1")
        return getString(R.string.admob_exit_banner_1)
    }
    Log.d("AdsId", "getExitBanner: admob_exit_banner_2")
    return getString(R.string.admob_exit_banner_2)
}

fun Context.getAppResumeAppOpenId(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppResumeAppOpenId: app_open_resume_1")
        return getString(R.string.app_open_resume_1)
    }
    Log.d("AdsId", "getAppResumeAppOpenId: app_open_resume_2")
    return getString(R.string.app_open_resume_2)
}

fun Context.getAppManageAppsInter(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppCallerCardNative: manage_apps_inter_1")
        return getString(R.string.manage_apps_inter_1)
    }
    Log.d("AdsId", "getAppCallerCardNative: manage_apps_inter_2")
    return getString(R.string.manage_apps_inter_2)
}

fun Context.getAppPermissionInter(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppPermissionInter: permission_inter_1")
        return getString(R.string.permission_inter_1)
    }
    Log.d("AdsId", "getAppPermissionInter: permission_inter_2")
    return getString(R.string.permission_inter_2)
}

fun Context.getAppMainInter(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppPermissionInter: main_inter_1")
        return getString(R.string.main_inter_1)
    }
    Log.d("AdsId", "getAppPermissionInter: main_inter_2")
    return getString(R.string.main_inter_2)
}

fun Context.getAppLanguageNative(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppPermissionInter: language_native_1")
        return getString(R.string.language_native_1)
    }
    Log.d("AdsId", "getAppPermissionInter: language_native_2")
    return getString(R.string.language_native_2)
}

fun Context.getAppConversionInfoNative(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppPermissionInter: conversation_info_native_1")
        return getString(R.string.conversation_info_native_1)
    }
    Log.d("AdsId", "getAppPermissionInter: conversation_info_native_2")
    return getString(R.string.conversation_info_native_2)
}

fun Context.getAppExitNative(): String {
    if (isFirstTimeAppOpen()) {
        Log.d("AdsId", "getAppPermissionInter: Exit_native_1")
        return getString(R.string.exit_native_1)
    }
    Log.d("AdsId", "getAppPermissionInter: Exit_native_2")
    return getString(R.string.exit_native_2)
}

fun Context.getAppOTPNative(): String {
    return getString(R.string.otp_native)
}

fun Context.getOTPBanner(): String {
    return getString(R.string.otp_banner)
}


private var loaderDialog: Dialog? = null

fun Activity.showLoaderDialog(title: String = "Setting language") {
    if (isFinishing || isDestroyed) return
    if (loaderDialog?.isShowing == true) return

    loaderDialog = Dialog(this).apply {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCancelable(false)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setContentView(R.layout.dialog_loader)

        findViewById<TextView>(R.id.tvLoaderTitle)?.text = title
        show()
    }
}

fun View.setSafeTint(@ColorInt color: Int) {
    runCatching { backgroundTintList = ColorStateList.valueOf(color) }
}


fun Activity.hideLoaderDialog() {
    try {
        loaderDialog?.dismiss()
        loaderDialog = null
    } catch (e: Exception) {
        e.printStackTrace()
    }
}


fun Context.isInternetConnected(): Boolean {


    val intenet = NetworkObserver.isConnected.value

    Log.d("LOG_TAAG", "Request. intenet - $intenet")

    return intenet
}