package messages.text.sms.feature.conversations

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import androidx.core.graphics.drawable.toBitmap
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.Observables
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.dpToPx
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.util.Preferences
import javax.inject.Inject
import kotlin.math.max
import kotlin.math.min

class ConversationItemTouchCallback @Inject constructor(
    colors: Colors,
    disposables: CompositeDisposable,
    prefs: Preferences,
    private val context: Context,
) : ItemTouchHelper.SimpleCallback(0, 0) {

    val swipes: Subject<Pair<Long, Int>> = PublishSubject.create()

    /**
     * Setting the adapter allows us to animate back to the original position
     */
    var adapter: RecyclerView.Adapter<*>? = null
    var callbackSwipe: (() -> Unit)? = null

    private val backgroundPaint = Paint()

    //    private val swipeRightBackgroundPaint = Paint()
//    private val swipeLeftBackgroundPaint = Paint()
    private var rightAction = 0
    private var swipeRightIcon: Bitmap? = null
    private var leftAction = 0
    private var swipeLeftIcon: Bitmap? = null

    private val iconLength = 24.dpToPx(context)

    init {
        disposables += colors.themeObservable()
            // .doOnNext { theme -> backgroundPaint.color = theme.theme }
            .doOnNext { theme -> backgroundPaint.color = context.baseConfig.primaryColor }
//            .doOnNext { theme -> swipeRightBackgroundPaint.color = context.getColorCompat(R.color.yellow) }
//            .doOnNext { theme -> swipeLeftBackgroundPaint.color = context.getColorCompat(R.color.red) }
            .subscribeOn(Schedulers.io())
            .subscribe()

        disposables += Observables
            .combineLatest(
                prefs.swipeRight.asObservable(),
                prefs.swipeLeft.asObservable(),
                colors.themeObservable()
            ) { right, left, theme ->
                rightAction = right
                swipeRightIcon = iconForAction(right, theme.textPrimary)
                leftAction = left
                swipeLeftIcon = iconForAction(left, theme.textPrimary)
                setDefaultSwipeDirs(
                    (if (right == Preferences.SWIPE_ACTION_NONE) 0 else ItemTouchHelper.RIGHT)
                            or (if (left == Preferences.SWIPE_ACTION_NONE) 0 else ItemTouchHelper.LEFT)
                )
            }
            .subscribeOn(Schedulers.io())
            .subscribe()
    }

    override fun onMove(
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        target: RecyclerView.ViewHolder,
    ): Boolean {
        return false
    }

    override fun onChildDraw(
        c: Canvas,
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean,
    ) {

//        if (viewHolder.adapterPosition == 0 || viewHolder.adapterPosition == 4 || viewHolder.adapterPosition == 8) {
        if (viewHolder.adapterPosition == 0 || viewHolder.adapterPosition == 5) {
            // If yes, don't allow swipe
            return
        }

        if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
            val itemView = viewHolder.itemView

            if (dX > 0) {
                c.drawRect(
                    itemView.left.toFloat(), itemView.top.toFloat(),
                    dX, itemView.bottom.toFloat(), backgroundPaint
                )

                swipeRightIcon?.let { icon ->
                    val availablePx = dX.toInt() - iconLength
                    if (availablePx > 0) {
                        val src = Rect(0, 0, min(availablePx, icon.width), icon.height)
                        val dstTop =
                            itemView.top + (itemView.bottom - itemView.top - icon.height) / 2
                        val dst = Rect(
                            iconLength,
                            dstTop,
                            iconLength + src.width(),
                            dstTop + src.height()
                        )
                        c.drawBitmap(icon, src, dst, null)
                    }
                }
            } else if (dX < 0) {
                c.drawRect(
                    itemView.right.toFloat() + dX, itemView.top.toFloat(),
                    itemView.right.toFloat(), itemView.bottom.toFloat(), backgroundPaint
                )

                swipeLeftIcon?.let { icon ->
                    val availablePx = -dX.toInt() - iconLength
                    if (availablePx > 0) {
                        val src = Rect(max(0, icon.width - availablePx), 0, icon.width, icon.height)
                        val dstTop =
                            itemView.top + (itemView.bottom - itemView.top - icon.height) / 2
                        val dst = Rect(
                            itemView.right - iconLength - src.width(), dstTop,
                            itemView.right - iconLength, dstTop + src.height()
                        )
                        c.drawBitmap(icon, src, dst, null)
                    }
                }
            }

            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {

//        if (viewHolder.adapterPosition == 0 || viewHolder.adapterPosition == 4 || viewHolder.adapterPosition == 8) {
        if (viewHolder.adapterPosition == 0 || viewHolder.adapterPosition == 5) {
            // If yes, don't allow swipe
            return
        }
        swipes.onNext(Pair(viewHolder.itemId, direction))

        // This will trigger the animation back to neutral state
        val action = if (direction == ItemTouchHelper.RIGHT) rightAction else leftAction
        if (action != Preferences.SWIPE_ACTION_ARCHIVE) {
            (adapter as? NewConversationsAdapter)?.handleAction(viewHolder.itemId, action)
            (adapter as? ArchiveConversationsAdapter)?.handleAction(viewHolder.itemId, action)
            adapter?.notifyItemChanged(viewHolder.adapterPosition)
            if (Preferences.SWIPE_ACTION_CALL == action) {
                callbackSwipe?.invoke()
            }
        } else {
            (adapter as? NewConversationsAdapter)?.removeItem(viewHolder.itemId)
            (adapter as? ArchiveConversationsAdapter)?.removeItem(viewHolder.itemId)
        }
    }

    private fun iconForAction(action: Int, tint: Int): Bitmap? {
        val res = when (action) {
            Preferences.SWIPE_ACTION_ARCHIVE -> R.drawable.ic_archive_swipe
            Preferences.SWIPE_ACTION_DELETE -> R.drawable.ic_delete_swipe
            Preferences.SWIPE_ACTION_BLOCK -> R.drawable.ic_block_swipe
            Preferences.SWIPE_ACTION_CALL -> R.drawable.ic_call_swipe
            Preferences.SWIPE_ACTION_READ -> R.drawable.ic_read_white_24dp
            Preferences.SWIPE_ACTION_UNREAD -> R.drawable.ic_unread_white_24dp
            else -> null
        }

        return res?.let(context.resources::getDrawable)
            ?.apply { setTint(tint) }
            ?.toBitmap(iconLength, iconLength)
    }


}