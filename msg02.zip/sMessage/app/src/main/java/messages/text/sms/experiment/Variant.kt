package messages.text.sms.experiment

data class Variant<T>(val key: String, val value: T)