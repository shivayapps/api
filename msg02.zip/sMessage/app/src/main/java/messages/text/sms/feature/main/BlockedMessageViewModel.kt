package messages.text.sms.feature.main

import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.Observable
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.schedulers.Schedulers
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.MysmsApplication.Companion.qkApplicationContext
import messages.text.sms.common.base.QkViewModel
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.interactor.MarkAllSeen
import messages.text.sms.interactor.MarkArchived
import messages.text.sms.interactor.MarkPinned
import messages.text.sms.interactor.MarkPrivateBox
import messages.text.sms.interactor.MarkRead
import messages.text.sms.interactor.MarkRecycle
import messages.text.sms.interactor.MarkRemovePrivateBox
import messages.text.sms.interactor.MarkUnarchived
import messages.text.sms.interactor.MarkUnpinned
import messages.text.sms.interactor.MarkUnread
import messages.text.sms.interactor.MigratePreferences
import messages.text.sms.interactor.SyncMessages
import messages.text.sms.manager.PermissionManager
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.REFRESH_ARCHIVE
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject

class BlockedMessageViewModel @Inject constructor(
    markAllSeen: MarkAllSeen,
    migratePreferences: MigratePreferences,
    val conversationRepo: ConversationRepository,
    private val deleteConversations: DeleteConversations,
    private val markArchived: MarkArchived,
    private val markPinned: MarkPinned,
    private val markRead: MarkRead,
    private val markPrivateBox: MarkPrivateBox,
    private val markRemovePrivateBox: MarkRemovePrivateBox,
    private val markUnarchived: MarkUnarchived,
    private val markUnpinned: MarkUnpinned,
    private val markUnread: MarkUnread,
    private val markRecycle: MarkRecycle,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager,
    private val prefs: Preferences,
) : QkViewModel<MainView, MainState>(
    MainState(
        page = Archived(),
    )
) {

    init {
        disposables += deleteConversations
        disposables += markRecycle
        disposables += markAllSeen
        disposables += markArchived
        disposables += markUnarchived
        disposables += markPrivateBox
        markAllSeen.execute(Unit)

    }


    fun getBlockedCount(): Int {
        return conversationRepo.getBlockedListCount()
    }


    override fun bindView(view: MainView) {
        super.bindView(view)
        view.refreshBlocked.withLatestFrom(state) { _, state ->
            newState {
                val conv = conversationRepo.getBlockedListConversations()
                copy(page = Archived(data = conv))
            }
        }.autoDisposable(view.scope()).subscribe()



        view.activityResumedIntent.filter { resumed -> !resumed }.switchMap {
            // Take until the activity is resumed
            prefs.keyChanges.filter { key -> key.contains("theme") }.map { true }
                .mergeWith(prefs.autoColor.asObservable().skip(1))
                .doOnNext { view.themeChanged() }
                .takeUntil(view.activityResumedIntent.filter { resumed -> resumed })
        }.autoDisposable(view.scope()).subscribe()



        view.optionsItemIntent.filter { itemId -> itemId == R.id.delete }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showDeleteDialog(conversations)
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.pin }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markPinned.execute(conversations) {
                    view.clearSelection()
                    view.refreshBlockedList()
                }

            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.block }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showBlockingDialog(conversations, true)
                view.clearSelection()
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.unblock }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showBlockingDialog(conversations, false)
                view.clearSelection()
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.add }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations -> conversations }
            .doOnNext { view.clearSelection() }
            .filter { conversations -> conversations.size == 1 }
            .map { conversations -> conversations.first() }
            .mapNotNull(conversationRepo::getConversation)
            .map { conversation -> conversation.recipients }
            .mapNotNull { recipients -> recipients[0]?.address?.takeIf { recipients.size == 1 } }
            .doOnNext(navigator::addContact)

            .autoDisposable(view.scope()).subscribe()
        view.optionsItemIntent.filter { itemId -> itemId == R.id.unpin }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnpinned.execute(conversations) {
                    view.clearSelection()
                    view.refreshBlockedList()
                }
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.read }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markRead.execute(conversations) {
                    view.clearSelection()
                    view.refreshBlockedList()
                }
            }.autoDisposable(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.unread }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnread.execute(conversations) {
                    view.clearSelection()
                    view.refreshBlockedList()
                }
            }.autoDisposable(view.scope()).subscribe()




        view.optionsItemIntent.filter { itemId -> itemId == R.id.llRemovePrivateBox }
            .filter {
                permissionManager.isDefaultSms().also {
                    if (!it) view.requestDefaultSms()
                }
            }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markRemovePrivateBox.execute(conversations) {
                    view.clearSelection()
                    view.refreshBlockedList()
                }

            }.autoDisposable(view.scope()).subscribe()


        view.conversationsSelectedIntent.withLatestFrom(state) { selection, state ->
            val conversations = selection.mapNotNull(conversationRepo::getConversation)
            val add = conversations.firstOrNull()?.takeIf { conversations.size == 1 }
                ?.takeIf { conversation -> conversation.recipients.size == 1 }?.recipients?.first()
                ?.takeIf { recipient -> recipient.contact == null } != null
            val pin = conversations.sumBy { if (it.pinned) -1 else 1 } >= 0
            val read = conversations.sumBy { if (!it.unread) -1 else 1 } >= 0
            val selected = selection.size

            when (state.page) {
                is Inbox -> {
                    val page = state.page.copy(
                        addContact = add,
                        markPinned = pin,
                        markRead = read,
                        selected = selected
                    )
                    newState { copy(page = page) }
                }

                is ContactPage -> {
                    val page = state.page.copy(selected = selected)
                    newState { copy(page = page) }
                }

                is Archived -> {
                    val page = state.page.copy(
                        addContact = add,
                        markPinned = pin,
                        markRead = read,
                        selected = selected
                    )
                    newState { copy(page = page) }
                }

                is Searching -> {}
            }
        }.autoDisposable(view.scope()).subscribe()

        // Delete the conversation
        view.confirmDeleteIntent.autoDisposable(view.scope()).subscribe { conversations ->
            deleteConversations.execute(conversations) {
                view.clearSelection()
                view.refreshBlockedList()
            }


        }

        view.setAsDefaultClick.autoDisposable(view.scope()).subscribe {
            when {
                !permissionManager.isDefaultSms() -> {
                    val context = qkApplicationContext?.applicationContext
                    context?.startActivity(
                        Intent(context, PermissionActivity::class.java).addFlags(
                            FLAG_ACTIVITY_NEW_TASK
                        ).putExtra("DefaultSms", true)
                    )
                    //  view.requestDefaultSms()
                }

                !permissionManager.hasReadSms() || !permissionManager.hasContacts() -> view.requestPermissions()
            }
        }

    }

}