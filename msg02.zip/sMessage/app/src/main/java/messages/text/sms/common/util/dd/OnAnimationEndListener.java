package messages.text.sms.common.util.dd;

import androidx.annotation.Keep;

@Keep
interface OnAnimationEndListener {

    void onAnimationEnd();
}
