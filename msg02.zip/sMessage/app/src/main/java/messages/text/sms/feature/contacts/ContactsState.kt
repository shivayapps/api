package messages.text.sms.feature.contacts

import messages.text.sms.model.ContactData
import messages.text.sms.model.ContactDataItem

data class ContactsState(
    val query: String = "",
    val composeItems: List<ContactDataItem> = ArrayList(),
    val selectedContact: ContactData? = null, // For phone number picker
)
