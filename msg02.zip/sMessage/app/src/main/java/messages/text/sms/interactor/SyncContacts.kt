package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.repository.SyncRepository
import timber.log.Timber
import javax.inject.Inject

class SyncContacts @Inject constructor(private val syncManager: SyncRepository) :
    Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<Long> {
        return Flowable.just(System.currentTimeMillis())
            .doOnNext { syncManager.syncContacts() }
            .map { startTime -> System.currentTimeMillis() - startTime }
            .doOnNext { duration -> Timber.v("Completed sync in ${duration}ms") }
    }

}