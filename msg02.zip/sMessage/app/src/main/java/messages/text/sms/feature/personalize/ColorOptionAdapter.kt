package messages.text.sms.feature.personalize

import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.commons.extensions.baseConfig

class ColorOptionAdapter(
    private val colors: List<Triple<Int, Int, Int>>,
    private var selectedPosition: Int = 0,
    private var onItemSelected: (Int) -> Unit,
    private val onColorSelected: (Triple<Int, Int, Int>) -> Unit,
) : RecyclerView.Adapter<ColorOptionAdapter.ColorViewHolder>() {

    inner class ColorViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val viewColor: View = view.findViewById(R.id.viewColor)
        val imgCheck: ImageView = view.findViewById(R.id.imgCheck)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ColorViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_color_option, parent, false)
        return ColorViewHolder(view)
    }

    override fun onBindViewHolder(holder: ColorViewHolder, position: Int) {

        val first = colors[position].first
        val stoke = colors[position].second
        val drawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL  // For a circular background
            color = ColorStateList.valueOf(first)  // Set background color
            setStroke(4, stoke)  // Set stroke width and color
        }
        holder.viewColor.background = drawable

        holder.imgCheck.setTint(holder.imgCheck.context.baseConfig.primaryColor)
        // Check if the current position is selected
        if (position == selectedPosition) {
            holder.imgCheck.visibility = View.VISIBLE
        } else {
            holder.imgCheck.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            // Update the previous selected item
            val previousSelectedPosition = selectedPosition
            selectedPosition = position
            onColorSelected(colors[position])

            // Only update the previous and new selected item
            notifyItemChanged(previousSelectedPosition)
            notifyItemChanged(selectedPosition)
            onItemSelected(position)
        }
    }

    override fun getItemCount(): Int = colors.size
}