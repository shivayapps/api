package messages.text.sms.feature.blocking.numbers

import android.view.ViewGroup
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.base.MainBaseRealmAdapter
import messages.text.sms.databinding.BlockedNumberListItemBinding
import messages.text.sms.model.BlockedNumber

class BlockedNumbersAdapter : MainBaseRealmAdapter<BlockedNumber, BlockedNumberListItemBinding>() {

    val unblockAddress: Subject<Long> = PublishSubject.create()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<BlockedNumberListItemBinding> {
        return MainBaseMsgViewHolder(parent, BlockedNumberListItemBinding::inflate).apply {
            binding.unblock.setOnClickListener {
                val number = getItem(adapterPosition) ?: return@setOnClickListener
                unblockAddress.onNext(number.id)
            }
        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<BlockedNumberListItemBinding>,
        position: Int,
    ) {
        val item = getItem(position)!!

        holder.binding.number.text = item.address
        holder.binding.number.setTextColor(holder.binding.number.context.getColor(R.color.black))
    }

}

