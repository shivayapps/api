package messages.text.sms.mapper

import android.database.Cursor
import messages.text.sms.model.MmsPart

interface CursorToPart : Mapper<Cursor, MmsPart> {

    fun getPartsCursor(messageId: Long): Cursor?

}