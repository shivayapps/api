package messages.text.sms.feature.conversations

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.base.MainBaseRealmAdapter
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.extensions.makeToast
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.helpers.ReConstant
import messages.text.sms.databinding.ConversationListItemBinding
import messages.text.sms.model.Conversation
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.Preferences
import java.util.regex.Pattern
import javax.inject.Inject

class ConversationsAdapter @Inject constructor(
    private val colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val prefs: Preferences,
) : MainBaseRealmAdapter<Conversation, ConversationListItemBinding>() {


    private val AD_COUNT = 3 // Total number of ads to display
    private val AD_VIEW_TYPE = 2 // Unique view type for native ads

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    //    fun selectAll(conversationalist: RealmResults<Conversation>?) {
    /* fun toggleSelectAll(isSelect: Boolean) {
         val cnt = itemCount
         if (selection.size == cnt) {
             clearSelection()
         } else {
             for (i in 0 until cnt) {
                 if (getItemViewType(i) == AD_VIEW_TYPE) {
                     // continue
                 } else {
                     val conversation = getItem(i)
 //                    val conversation = getItem(getConversationPosition(i))
                     if (selection.contains(conversation?.id!!)) {
                         if (!isSelect) {
                             selection = selection - conversation.id
                         }
                     } else {
                         if (isSelect) {
                             selection = selection + conversation.id
                         }
                     }
                 }
                 selectionChanges.onNext(selection)
             }
             notifyDataSetChanged()
         }
     }*/

    fun toggleSelectAll(isSelect: Boolean) {
        val cnt = itemCount
        if (selection.size == cnt) {
            clearSelection()
        } else {
            // Create a list of all eligible item IDs (excluding AD_VIEW_TYPE)
            val eligibleIds = (0 until cnt)
                //   .filter { getItemViewType(it) != AD_VIEW_TYPE }
                .mapNotNull { getItem(it)?.id }

            // Use Kotlin's set operations for efficient selection manipulation
            if (isSelect) {
                // Add all eligible IDs to the selection
                selection = selection + eligibleIds
            } else {
                // Remove all eligible IDs from the selection
                selection = selection - eligibleIds
            }

            selectionChanges.onNext(selection)
            notifyDataSetChanged()
        }
    }


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ConversationListItemBinding> {

        return MainBaseMsgViewHolder(parent, ConversationListItemBinding::inflate).apply {


            /*   if (viewType == AD_VIEW_TYPE) {
                   binding.llAds.beVisible()
                   binding.topLine.beVisible()
                   binding.mainConversation.beGone()

               } else {*/
            binding.llAds.beGone()
            binding.topLine.beGone()
            binding.mainConversation.beVisible()


//                val textColorPrimary = parent.context.resolveThemeColor(android.R.attr.textColorPrimary)
            val textColorPrimary = context.baseConfig.textColor
            val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
            binding.title.setTextColor(textColorPrimary)
            binding.date.setTextColor(colorWithAlpha)
            binding.snippet.setTextColor(colorWithAlpha)

            if (viewType == 1) {

                binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)
                binding.snippet.setTypeface(binding.snippet.typeface, Typeface.BOLD)
                binding.snippet.setTextColor(textColorPrimary)
                //  binding.snippet.maxLines = 2

                binding.unread.isVisible = true
                binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
//                binding.date.setTextColor(textColorPrimary)
            } else {
                binding.title.setTypeface(binding.title.typeface, Typeface.NORMAL)
                binding.snippet.setTypeface(binding.snippet.typeface, Typeface.NORMAL)
                binding.snippet.setTextColor(colorWithAlpha)
            }

            binding.mainConversation.setOnClickListener {

//                val conversation =
//                    getItem(position - (position / (AD_COUNT + 1))) ?: return@setOnClickListener
//                when (toggleSelection(conversation.id, false)) {
//                    // ... existing click handler for conversations ...
//                }

                val conversation = getItem(getConversationPosition(adapterPosition))
                    ?: return@setOnClickListener
                when (toggleSelection(conversation.id, false)) {
                    true -> {
                        binding.root.isActivated = isSelected(conversation.id)
                        if (isSelected(conversation.id)) {
                            binding.cbSelect.isChecked = true
                        } else {
                            binding.cbSelect.isChecked = false
                        }
                    }

                    false -> {
                        navigator.showConversation(conversation.id)
                    }
                }
            }

            binding.mainConversation.setOnLongClickListener {
                val conversation =
                    getItem(getConversationPosition(adapterPosition))
                        ?: return@setOnLongClickListener true
                toggleSelection(conversation.id)
                binding.root.isActivated = isSelected(conversation.id)
                if (isSelected(conversation.id)) {
                    binding.cbSelect.isChecked = true
                } else {
                    binding.cbSelect.isChecked = false
                }
                notifyDataSetChanged()
                true
            }
//            }
//            }


        }
    }


    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ConversationListItemBinding>,
        position: Int,
    ) {
//        if(itemCount>0){
        val itemViewType = getItemViewType(position)
//        if (itemViewType == AD_VIEW_TYPE) {
//            loadNativeAd(
//                holder.binding.inBannerViewTop.root,
//                holder.binding.llAds.context,
//                position
//            )
//        } else {
        //    val conversation = getItem(position - (position / (AD_COUNT + 1))) ?: return


        val conversation = getItem(getConversationPosition(position)) ?: return

        holder.binding.root.isActivated = isSelected(conversation.id)
        if (isSelected(conversation.id)) {
            holder.binding.cbSelect.isChecked = true
        } else {
            holder.binding.cbSelect.isChecked = false
        }

        holder.binding.avatars.title = conversation.getTitle()
        holder.binding.avatars.recipients = conversation.recipients
        holder.binding.title.collapseEnabled = conversation.recipients.size > 1
        holder.binding.title.text = conversation.getTitle()
        holder.binding.date.text =
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp)


        try {
            val typeface = ResourcesCompat.getFont(context, prefs.selectedFont.get())
            holder.binding.snippet.setTypeface(typeface)
        } catch (_: Exception) {
        }

        holder.binding.snippet.text = when {
            conversation.draft.isNotEmpty() -> context.getString(
                R.string.main_draft,
                conversation.draft
            )

            conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
            else -> conversation.snippet
        }
        holder.binding.pinned.isVisible = conversation.pinned


        if (isSelection()) {
            holder.binding.cbSelect.beVisible()
        } else {
            holder.binding.cbSelect.beGone()
        }
        holder.binding.cbSelect.buttonTintList =
            ColorStateList.valueOf(context.baseConfig.primaryColor)
        holder.binding.pinned.imageTintList =
            ColorStateList.valueOf(context.baseConfig.primaryColor)


        // If the last message wasn't incoming, then the colour doesn't really matter anyway
        val lastMessage = conversation.lastMessage
        val recipient = when {
            conversation.recipients.size == 1 || lastMessage == null -> conversation.recipients.firstOrNull()
            else -> conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        }
        holder.binding.unread.setTint(context.baseConfig.primaryColor)



        if (conversation.lastMessage != null) {

            val resultOtp =
                Pattern.compile(ReConstant.otp_regex.toString())
                    .matcher(conversation.lastMessage?.body!!.replace("\n", " ").trim()).find()
//            Log.d("check_conversationsadapter", "messageCatType: $resultOtp =====> ${conversation.lastMessage!!.body}")
//            val new = parseCode(lastMessage?.body.toString())
            if (resultOtp) {
                holder.binding.tvOTP.beVisible()
                holder.binding.tvOTP.setOnClickListener {
                    val otpCode = ReConstant.parseCode(lastMessage!!.body.replace("\n", " ").trim())
                    ReConstant.copy(context, otpCode)
                    context.makeToast(R.string.toast_copied)
                }
            } else {
                holder.binding.tvOTP.beGone()
            }

        } else {
            holder.binding.tvOTP.beGone()
        }
    }


    override fun getItemId(position: Int): Long {
        return getItem(position)?.id ?: -1
    }

    /* override fun getItemViewType(position: Int): Int {
         return if (getItem(position)?.unread == false) 0 else 1
     }*/

    override fun getItemViewType(position: Int): Int {
        // Check if the position corresponds to a native ad
//        if (position in listOf(0, 4, 8)) { // Adjust these numbers as needed
//            return AD_VIEW_TYPE
//        }
        return if (getItem(position)?.unread == false) 0 else 1
    }

    /* private fun loadNativeAd(view: ViewGroup, context: Context, position: Int) {

         val activity = (context as Activity)
         val currentActivity = activity.javaClass.simpleName

         Log.e("currentActivity","currentActivity - $currentActivity")
         when (position) {
             0 -> {
                 when (currentActivity) {
                     "MainActivity" -> showNativeHome(context, view)
                     "PrivateConversationsActivity" -> showNativePrivate(context, view)
                     "ArchiveActivity" -> showNativeArchived(context, view)
                 }
             }

             4 -> {
                 when (currentActivity) {
                     "MainActivity" -> showAdAppLovinHome(context, view)
                     "PrivateConversationsActivity" -> showAdAppLovinPrivate(context, view)
                     "ArchiveActivity" -> showAdAppLovinArchived(context, view)
                 }
             }

             8 -> {
                 when (currentActivity) {
                     "MainActivity" -> showNative8Home(context, view)
                     "PrivateConversationsActivity" -> showNative8Private(context, view)
                     "ArchiveActivity" -> showNative8Archived(context, view)
                 }
             }
         }
     }*/


    override fun getItemCount(): Int {
        return super.getItemCount()
//        when (super.getItemCount()) {
//            0 -> return super.getItemCount()
//            in 1..3 -> return super.getItemCount() + 1
//            in 4..6 -> return super.getItemCount() + 2
//            else -> return super.getItemCount() + AD_COUNT
//        }
    }

    private fun getConversationPosition(position: Int): Int {
//        return position - when (position) {
//            in 1..3 -> 1
//            in 5..7 -> 2
//            else -> AD_COUNT
//        }
        return position
    }

}
