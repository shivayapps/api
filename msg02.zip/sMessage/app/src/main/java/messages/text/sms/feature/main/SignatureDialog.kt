package messages.text.sms.feature.main

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import messages.text.sms.R


class SignatureDialog(
    context: Context,
    private val listener: OnMessageActionListener,
    private val initialMessage: String,
) : Dialog(context, R.style.QuickMessageDialogStyle) {

    private lateinit var editText: EditText
    private lateinit var okButton: Button
    private lateinit var deleteButton: Button
    private lateinit var cancelButton: Button
    private lateinit var dialogTitle: TextView
    private lateinit var bgMain: ConstraintLayout

    interface OnMessageActionListener {
        fun onMessageUpdated(message: String)
        fun onMessageDeleted()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)

        /*  if (context.callerCadBaseConfig.callerCardDarkTheme) {
              window?.apply {
                  setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                  setBackgroundDrawableResource(R.drawable.bg_caller_round_button_home_more_dark)
              }
          } else {
              window?.apply {
                  setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                  setBackgroundDrawableResource(R.drawable.bg_caller_round_button_home_more_light)
              }
          }*/
        window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setBackgroundDrawableResource(R.drawable.shape_bg_round_dialog)
        }

        setContentView(R.layout.signature_message)

        editText = findViewById(R.id.dialogEditText)
        okButton = findViewById(R.id.dialogOkButton)
        deleteButton = findViewById(R.id.dialogUpdateButton)
        cancelButton = findViewById(R.id.dialogCancelButton)
        dialogTitle = findViewById(R.id.dialogTitle)
        bgMain = findViewById(R.id.bg_main)

        // Set initial message in EditText
        editText.setText(initialMessage)

        okButton.setOnClickListener {
            val updatedMessage = editText.text.toString().trim()
            if (updatedMessage.isNotEmpty()) {
                listener.onMessageUpdated(updatedMessage)
                dismiss()
            }
        }

        deleteButton.setOnClickListener {
            listener.onMessageDeleted()
            dismiss()
        }

        cancelButton.setOnClickListener {
            cancel()
        }

        /* val tintColor = ContextCompat.getColor(
           context,
           if (context.baseConfig.callerCardDarkTheme) {
               R.color.callercad_card_bg_dark // Dark theme color
           } else {
               R.color.callercad_card_bg_light // Light theme color
           }
       )*/

        ContextCompat.getDrawable(context, R.drawable.callercad_ic_round_bg)?.let { drawable ->
            val mutableDrawable = drawable.mutate()
            mutableDrawable.setTint(
                ContextCompat.getColor(
                    context, R.color.white
                )
            )
            bgMain.background = mutableDrawable
        }


        dialogTitle.setTextColor(
            ContextCompat.getColor(
                context,
                R.color.black
            )
        )
        editText.setTextColor(
            ContextCompat.getColor(
                context,
                R.color.black
            )
        )
    }
}