package messages.text.sms.feature.contacts

import android.view.inputmethod.EditorInfo
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.rx2.awaitFirst
import messages.text.sms.common.base.QkViewModel
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.feature.compose.editing.ComposeItem
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.filter.ContactFilter
import messages.text.sms.filter.ContactFilter2
import messages.text.sms.filter.ContactGroupFilter
import messages.text.sms.interactor.SetDefaultPhoneNumber
import messages.text.sms.model.Contact
import messages.text.sms.model.ContactData
import messages.text.sms.model.ContactDataItem
import messages.text.sms.model.ContactGroup
import messages.text.sms.model.Conversation
import messages.text.sms.model.PhoneNumber
import messages.text.sms.model.Recipient
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.PhoneNumberUtils
import javax.inject.Inject

class ContactsViewModel @Inject constructor(
    sharing: Boolean,
    serializedChips: HashMap<String, String?>,
    val contactFilter: ContactFilter,
    val contactFilter2: ContactFilter2,
    val contactGroupFilter: ContactGroupFilter,
    private val contactsRepo: messages.text.sms.repository.ContactRepository,
    private val conversationRepo: ConversationRepository,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val setDefaultPhoneNumber: SetDefaultPhoneNumber,
) : QkViewModel<ContactsContract, ContactsState>(ContactsState()) {

    private val contactGroups: Observable<List<ContactGroup>> by lazy { contactsRepo.getUnmanagedContactGroups() }
    private val contacts: Observable<List<Contact>> by lazy { contactsRepo.getUnmanagedContacts() }
    private val recents: Observable<List<Conversation>> by lazy {
        if (sharing) conversationRepo.getUnmanagedConversations() else Observable.just(listOf())
    }
    private val starredContacts: Observable<List<Contact>> by lazy {
        contactsRepo.getUnmanagedContacts(
            true
        )
    }

    private val selectedChips = Observable.just(serializedChips)
        .observeOn(Schedulers.io())
        .map { hashmap ->
            hashmap.map { (address, lookupKey) ->
                Recipient(
                    address = address,
                    contact = lookupKey?.let(contactsRepo::getUnmanagedContact)
                )
            }
        }
    var selectedChipsData = emptyList<Recipient>()
    var starredContactsData = emptyList<Contact>()
    var contactsData = emptyList<Contact>()
    var contactGroupsData = emptyList<ContactGroup>()
    private var shouldOpenKeyboard: Boolean = true

    override fun bindView(view: ContactsContract) {
        super.bindView(view)

        if (shouldOpenKeyboard) {
            view.openKeyboard()
            shouldOpenKeyboard = false
        }

        // Update the state's query, so we know if we should show the cancel button
        view.queryChangedIntent
            .autoDisposable(view.scope())
            .subscribe { query -> newState { copy(query = query.toString()) } }

        // Clear the query
        view.queryClearedIntent
            .autoDisposable(view.scope())
            .subscribe { view.clearQuery() }

        // Update the list of contact suggestions based on the query input, while also filtering out any contacts
        // that have already been selected
        Observables
            .combineLatest(
                view.loadContacts,
                recents,
                starredContacts,
                contactGroups,
                contacts,
                selectedChips
            ) { query, recents, starredContacts, contactGroups, contacts, selectedChips ->
                selectedChipsData = selectedChips
                starredContactsData = starredContacts
                contactGroupsData = contactGroups
                contactsData = contacts
                val composeItems = mutableListOf<ComposeItem>()
                /*   composeItems += recents
                       .filter { conversation ->
                           conversation.recipients.any { recipient ->
                               selectedChips.none { chip ->
                                   if (recipient.contact == null) {
                                       chip.address == recipient.address
                                   } else {
                                       chip.contact?.lookupKey == recipient.contact?.lookupKey
                                   }
                               }
                           }
                       }
                       .map(ComposeItem::Recent)

                   composeItems += starredContacts
                       .filterIsInstance<Contact>()
                       .filter { contact -> selectedChips.none { it.contact?.lookupKey == contact.lookupKey } }
                       .map(ComposeItem::Starred)

                   composeItems += contactGroups
                       .filterIsInstance<ContactGroup>()
                       .filter { group ->
                           group.contacts.any { contact ->
                               selectedChips.none { chip -> chip.contact?.lookupKey == contact.lookupKey }
                           }
                       }
                       .map(ComposeItem::Group)*/

                composeItems += contacts
                    .filterIsInstance<Contact>()
                    .filter { contact -> selectedChips.none { it.contact?.lookupKey == contact.lookupKey } }
                    .map(ComposeItem::Person)


                composeItems.filterIsInstance<ComposeItem.Person>().map { ContactDataItem.Person(ContactData(it.value.lookupKey, ArrayList<PhoneNumber>(it.value.numbers), it.value.name, it.value.photoUri, it.value.starred, it.value.lastUpdate)) }
            }
            .subscribeOn(Schedulers.computation())
            .autoDisposable(view.scope())
            .subscribe { items -> newState { copy(composeItems = items) } }

        /* // Listen for ComposeItems being selected, and then send them off to the number picker dialog in case
         // the user needs to select a phone number
         view.queryEditorActionIntent
             .filter { actionId -> actionId == EditorInfo.IME_ACTION_DONE }
             .withLatestFrom(state) { _, state -> state }
             .mapNotNull { state -> state.composeItems.firstOrNull() }
             .mergeWith(view.composeItemPressedIntent)
             .map { composeItem -> composeItem to false }
             .mergeWith(view.composeItemLongPressedIntent.map { composeItem -> composeItem to true })
             .observeOn(Schedulers.io())
             .map { (composeItem, force) ->
                 HashMap(composeItem.getContacts().associate { contact ->
                     if (contact.numbers.size == 1 || contact.getDefaultNumber() != null && !force) {
                         val address =
                             contact.getDefaultNumber()?.address ?: contact.numbers[0]!!.address
                         address to contact.lookupKey
                     } else {
                         runBlocking {
                             newState { copy(selectedContact = contact) }
                             val action = view.phoneNumberActionIntent.awaitFirst()
                             newState { copy(selectedContact = null) }
                             val numberId = view.phoneNumberSelectedIntent.awaitFirst().value
                             val number = contact.numbers.find { number -> number.id == numberId }

                             if (action == PhoneNumberAction.CANCEL || number == null) {
                                 return@runBlocking null
                             }

                             if (action == PhoneNumberAction.ALWAYS) {
                                 val params =
                                     SetDefaultPhoneNumber.Params(contact.lookupKey, number.id)
                                 setDefaultPhoneNumber.execute(params)
                             }

                             number.address to contact.lookupKey
                         } ?: return@map hashMapOf<String, String?>()
                     }
                 })
             }
             .filter { result -> result.isNotEmpty() }
             .observeOn(AndroidSchedulers.mainThread())
             .autoDisposable(view.scope())
             .subscribe { result -> view.finish(result) }*/

        view.queryEditorActionIntent.filter { actionId -> actionId == EditorInfo.IME_ACTION_DONE }
            .withLatestFrom(state) { _, state -> state }
            .mapNotNull { state -> state.composeItems.firstOrNull() }
            .mergeWith(view.composeItemPressedIntent)
            .map { composeItem -> composeItem to false }
            .mergeWith(view.composeItemLongPressedIntent.map { composeItem -> composeItem to true })
            .observeOn(Schedulers.io()).map { (composeItem, force) ->
                HashMap(composeItem.getContacts().associate { contact ->
                    if (contact.numbers.size == 1 || contact.getDefaultNumber() != null && !force) {
                        val address =
                            contact.getDefaultNumber()?.address ?: contact.numbers[0].address
                        address to contact.lookupKey
                    } else {
                        runBlocking {
                            newState { copy(selectedContact = contact) }
                            val action = view.phoneNumberActionIntent.awaitFirst()
                            newState { copy(selectedContact = null) }
                            val numberId = view.phoneNumberSelectedIntent.awaitFirst().value
                            val number = contact.numbers.find { number -> number.id == numberId }

                            if (action == PhoneNumberAction.CANCEL || number == null) {
                                return@runBlocking null
                            }

                            if (action == PhoneNumberAction.ALWAYS) {
                                val params =
                                    SetDefaultPhoneNumber.Params(contact.lookupKey, number.id)
                                setDefaultPhoneNumber.execute(params)
                            }

                            number.address to contact.lookupKey
                        } ?: return@map hashMapOf<String, String?>()
                    }
                })
            }.filter { result -> result.isNotEmpty() }.observeOn(AndroidSchedulers.mainThread())
            .autoDisposable(view.scope())
            .subscribe { result -> view.finish(result) }
    }

}
