package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.repository.ConversationRepository
import javax.inject.Inject

import android.util.Log

class MarkBlocked @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val markRead: MarkRead,
) : Interactor<MarkBlocked.Params>() {

    data class Params(val threadIds: List<Long>, val blockingClient: Int, val blockReason: String?)

    override fun buildObservable(params: Params): Flowable<*> {
        Log.d("MarkBlocked", "buildObservable called with params: $params")

        return Flowable.just(params)
            .doOnNext { (threadIds, blockingClient, blockReason) ->
                Log.d(
                    "MarkBlocked",
                    "Marking blocked threads: $threadIds, blockingClient: $blockingClient, reason: $blockReason"
                )
                conversationRepo.markBlocked(threadIds, blockingClient, blockReason)
            }
            .flatMap { (threadIds) ->
                Log.d("MarkBlocked", "Calling markRead for threads: $threadIds")
                markRead.buildObservable(threadIds)
            }
    }
}
