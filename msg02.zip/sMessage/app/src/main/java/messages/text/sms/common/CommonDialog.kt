package messages.text.sms.common

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.util.TypedValue
import android.view.View.GONE
import android.view.Window
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R

class CommonDialog(val context: Context) {

    val moreClicks: Subject<Unit> = PublishSubject.create()

    fun show(
        activity: Activity,
        title: String,
        message: String,
        positive: String,
        negative: String,
        neutral: String,
        onPositive: () -> Unit = {},
        onNegative: () -> Unit = {},
        onNeutral: () -> Unit = {},
        onDialogClose: () -> Unit = {},
        cancelable: Boolean = true
    ) {
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val window = dialog.window
        window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(cancelable)
        dialog.setContentView(R.layout.custom_dialog_common)
        dialog.findViewById<ConstraintLayout>(R.id.cl_dialog_main).background = ResourcesCompat.getDrawable(activity.resources, R.drawable.rounded_corners, null)
        dialog.findViewById<TextView>(R.id.tv_title).text = if (title.isNotEmpty())title else " "
        dialog.findViewById<TextView>(R.id.tv_desc).text = if (message.isNotEmpty())message else " "
        dialog.findViewById<TextView>(R.id.tv_action_cancel).apply {
            if(negative.isNullOrEmpty()) { visibility = GONE }
            text = negative
            setOnClickListener {
                onNegative()
                dialog.dismiss() }
        }
        dialog.findViewById<TextView>(R.id.tv_action_ok).apply {
            text = positive
            setOnClickListener {
                onPositive()
                dialog.dismiss() }
        }
        dialog.setOnCancelListener {
            onDialogClose()
        }
        dialog.show()

    }



}