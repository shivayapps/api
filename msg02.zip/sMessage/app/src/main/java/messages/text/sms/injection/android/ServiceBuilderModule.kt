package messages.text.sms.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import messages.text.sms.feature.backup.RestoreBackupService
import messages.text.sms.injection.scope.ActivityScope
import messages.text.sms.receiver.SendSmsReceiver
import messages.text.sms.service.HeadlessSmsSendService

@Module
abstract class ServiceBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindHeadlessSmsSendService(): HeadlessSmsSendService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRestoreBackupService(): RestoreBackupService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSendSmsReceiver(): SendSmsReceiver

}
