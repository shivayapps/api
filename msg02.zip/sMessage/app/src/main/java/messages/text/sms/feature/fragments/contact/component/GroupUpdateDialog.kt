package messages.text.sms.feature.fragments.contact.component

import android.app.Activity
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import io.realm.Realm
import messages.text.sms.R
import messages.text.sms.common.util.extensions.showKeyboard
import messages.text.sms.commons.extensions.getAlertDialogBuilder
import messages.text.sms.commons.extensions.getProperTextColor
import messages.text.sms.commons.extensions.setupDialogStuff
import messages.text.sms.commons.helpers.ensureBackgroundThread
import messages.text.sms.databinding.DialogMessageBinding
import messages.text.sms.model.ContactGroup

class GroupUpdateDialog(
    val activity: Activity,
    private var group: ContactGroup? = null,
    private val existGroup: List<ContactGroup> = ArrayList(),
    private val callback: () -> Unit = {},
) {

    private var dialog: AlertDialog? = null

    init {
        var dialogTitle = activity.getString(R.string.group_dialog_title_add)
        val textInput = EditText(activity)
        val maxLength = 40
        textInput.setFilters(arrayOf<InputFilter>(InputFilter.LengthFilter(maxLength)))
        textInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        textInput.setSingleLine()
        activity.getProperTextColor().let { textInput.setTextColor(it) }
        activity.getProperTextColor().let { textInput.setHintTextColor(it) }
        if (!group?.title.isNullOrEmpty()) {
            textInput.setText(group?.title)
        }

        if (group != null) {
            dialogTitle = activity.getString(R.string.group_dialog_title_edit)
        }
        textInput.hint = "Write group name..."
        val layout = LinearLayout(activity)
        val layoutPaddingSide = 50
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(layoutPaddingSide, 30, layoutPaddingSide, 0)
        layout.addView(getCustomTitleView(dialogTitle)) // displays the user input bar
        layout.addView(textInput) // displays the user input bar

        activity.getAlertDialogBuilder()
            .setPositiveButton(R.string.ok) { _, _ ->
                val groupName = textInput.text.trim().toString()
                val existingGroupMessage =
                    "Group  name \"$groupName\" already exists, choose a different name."
                if (groupName.isEmpty()) {
                    textInput.error = "Please enter a group name"
                    showAlert("Name cannot be empty")
                } else {
                    val existingGroup =
                        existGroup.firstOrNull { groupName.lowercase() == it.title.lowercase() }
                    val groupExists = existingGroup != null && existingGroup.title.equals(
                        groupName,
                        ignoreCase = true
                    )
                    // if for group list
                    if (group == null && groupExists) {
                        showAlert(existingGroupMessage)
                        // if for group detail
                    } else if (groupExists && existingGroup?.id != group?.id) {
                        showAlert(existingGroupMessage)
                    } else {

                        ensureBackgroundThread {
                            Realm.getDefaultInstance().use { realm ->
                                if (group?.id != null) {
                                    group?.title = groupName
                                } else {
                                    val currentIdNum: Number? =
                                        realm.where(ContactGroup::class.java).max("id")
                                    val nextId: Long = if (currentIdNum == null) {
                                        1L
                                    } else {
                                        currentIdNum.toInt() + 1L
                                    }
                                    group = ContactGroup(id = nextId, title = groupName)
                                }
                                realm.executeTransaction { realm.insertOrUpdate(group!!) }
                            }
                            activity.runOnUiThread {
                                dialog?.dismiss()
                                callback.invoke()
                            }
                        }
                    }
                }
            }
            .setNegativeButton(R.string.cancel) { _, _ -> dialog?.dismiss() }
            .apply {
                activity.setupDialogStuff(
                    layout,
                    this,
                    cancelOnTouchOutside = false
                ) { alertDialog ->
                    dialog = alertDialog
                    dialog?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
                    layout.post {
                        textInput.showKeyboard()
                    }
                }
            }
    }

    private fun getCustomTitleView(title: String): View {
        val customTitle = TextView(activity)
        customTitle.text = title
        customTitle.setPadding(50, 30, 50, 30)
        customTitle.gravity = Gravity.CENTER
        activity.getProperTextColor()?.let { customTitle.setTextColor(it) } // Set title text color
        customTitle.textSize = 20f
        return customTitle
    }

    private fun showAlert(message: String) {
        var positive: Int = R.string.ok;
        val view = activity.let { DialogMessageBinding.inflate(it.layoutInflater, null, false) }
        view.message.text = message
        val builder = activity.getAlertDialogBuilder().setPositiveButton(positive) { _, _ -> }
        builder.apply {
            this?.let {
                activity.setupDialogStuff(
                    view.root,
                    it,
                    titleText = "",
                    cancelOnTouchOutside = true
                ) { alertDialog ->
                }
            }
        }

    }
}
