package messages.text.sms.appmanager

import android.app.Activity
import android.app.ActivityManager
import android.content.Context

object Utility {

    // Placeholder for your Firebase Analytics Handler
    // You should replace this with your actual implementation
    val firebaseAnalyticsHandler = object {
        fun logMessages(event: String, activityName: String) {
            // Your actual analytics logging logic here
            println("Analytics Event: $event, Activity: $activityName")
        }
    }

    // Placeholder for your analytics event constant
    const val app_manage_apps_screen2_open = "app_manage_apps_screen2_open"

    // Placeholder for your AdmobNative configuration
    // Replace with your actual ad unit ID retrieval
    fun getAppManageAppsNative(): String {
        return "ca-app-pub-3940256099942544/2247696110" // Example Ad Unit ID (Test Ad)
    }

    fun totalRamMemorySize(context: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(mi)
        return mi.totalMem
    }

    fun freeRamMemorySize(context: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(mi)
        return mi.availMem
    }

    fun calculatePercentage(value: Long, total: Long): Int {
        if (total == 0L) return 0
        return ((value * 100.0f) / total).toInt()
    }

    fun getActivityName(activity: Activity): String {
        return activity::class.java.simpleName
    }
}