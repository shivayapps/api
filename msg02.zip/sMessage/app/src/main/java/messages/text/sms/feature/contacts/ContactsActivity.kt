package messages.text.sms.feature.contacts

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Log
import android.view.MenuItem
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.ViewModelProviders
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.jakewharton.rxbinding2.view.clicks
import com.reddit.indicatorfastscroll.FastScrollItemIndicator
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.RealmList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.common.ViewModelFactory
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.hideKeyboard
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.common.widget.QkDialog
import messages.text.sms.commons.adapters.NewContactItemAdapter
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.getColorStateList
import messages.text.sms.commons.extensions.getContrastColor
import messages.text.sms.commons.extensions.normalizeString
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ContactsActivityBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.feature.compose.editing.ComposeItem
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.feature.compose.editing.PhoneNumberPickerAdapter
import messages.text.sms.model.Contact
import messages.text.sms.model.ContactData
import messages.text.sms.model.ContactDataItem
import messages.text.sms.model.PhoneNumber
import java.util.Locale
import javax.inject.Inject

class ContactsActivity : MainBaseThemedActivity(), ContactsContract {

    companion object {
        const val SharingKey = "sharing"
        const val ChipsKey = "chips"
    }


    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelFactory

    override val queryChangedIntent: Observable<CharSequence> = PublishSubject.create()
    override val queryClearedIntent: Observable<*> by lazy { binding.cancel.clicks() }
    override val queryBack: Observable<*> by lazy { binding.ivBack.clicks() }
    override val queryEditorActionIntent: Observable<Int> = PublishSubject.create()
    override val composeItemPressedIntent: Subject<ContactDataItem> by lazy { contactsAdapter.clicks }
    override val composeItemLongPressedIntent: Subject<ContactDataItem> by lazy { contactsAdapter.longClicks }
    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()
    override val loadContacts: Observable<CharSequence> by lazy { fetchContacts }
    val fetchContacts: Subject<CharSequence> = PublishSubject.create()

    var allContacts: List<ComposeItem> = ArrayList()
    var composeItems: List<ContactDataItem> = ArrayList()
    private val binding by viewBinding(ContactsActivityBinding::inflate)
    private val viewModel by lazy {
        ViewModelProviders.of(
            this, viewModelFactory
        )[ContactsViewModel::class.java]
    }
    private val searchHandle = Handler(Looper.getMainLooper())
    private val searchRunnable = Runnable {
        search()
    }
    var contactsAdapter = NewContactItemAdapter()
    private var searchJob: Job? = null
    private fun search() {
        val search = binding.search.text.toString().trim().lowercase()

        // cancel previous search if still running
        searchJob?.cancel()

        searchJob = lifecycleScope.launch(Dispatchers.IO) {
            if (search.isNotEmpty()) {
                Log.e("SearchContacts", "search: start $search")

                val composeItemsFiltered = ArrayList<ContactDataItem>()
                val selectedKeys = ArrayList(viewModel.selectedChipsData).mapNotNull { it.contact?.lookupKey?.lowercase() }

                val dataList = ArrayList(composeItems).filterIsInstance<ContactDataItem.Person>().filter { !selectedKeys.contains(it.value.lookupKey.lowercase()) }

                if (phoneNumberUtils.isPossibleNumber(search)) {
                    val newAddress = phoneNumberUtils.formatNumber(search)
                    val newContact = Contact(numbers = RealmList(PhoneNumber(address = newAddress)))
                    composeItemsFiltered += ContactDataItem.New(ContactData(contact = newContact))
                }

                val normalized = search.replace("\\s".toRegex(), "")
                composeItemsFiltered += dataList.filter { contact ->
                    viewModel.contactFilter2.filter(contact.value, normalized)
                }

                Log.e("SearchContacts", "search: result ${composeItemsFiltered.size}")

                withContext(Dispatchers.Main) {
                    setAdaptor(composeItemsFiltered)
                }
            } else {

                withContext(Dispatchers.Main) {
                    setAdaptor(composeItems)
                }
            }
        }
    }

    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        showBackButton(true)
        viewModel.bindView(this)

        binding.contacts.itemAnimator = null
        binding.contacts.adapter = contactsAdapter

        setUpTheme()
    }


    @SuppressLint("ClickableViewAccessibility")
    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")
//        if (baseConfig.useImageResource){
//            if (baseConfig.storedImageResource==-1){
//
//            }else{
////                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.mainLayout.background = drawable
//            }
//        }

        updateTextColors(binding.contentView)
//        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
//            binding.llBottomAction.background = ColorDrawable(resources.getColor(R.color.bottom_tabs_black_backgroundnew))
//            arrayListOf(binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.white)
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
//        } else {
//            binding.llBottomAction.background = ColorDrawable(baseConfig.statusBarColor)
//            arrayListOf(binding.ivDelete, binding.ivMore, binding.ivArchive, binding.ivRead, binding.ivBlock).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.black)
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
//        }

        if (baseConfig.useImageResource == true) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")

//                val bitmapDrawable = BitmapDrawable(resources, baseConfig.storedBitmap)
//                constraintLayout.background = bitmapDrawable
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable

                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

            }
        } else {

            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
//            binding.navView.setBackgroundColor(baseConfig.backgroundColor)
//            lloptionmenu.setBackgroundColor(baseConfig.backgroundColor)
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

//        supportActionBar?.setHomeButtonEnabled(true)
//        supportActionBar?.setDisplayHomeAsUpEnabled(true)
//        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        val primaryColorWithAlpha = ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())
        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.6F)
        binding.search.setBackgroundTint(primaryColorWithAlpha)
//        binding.search.textSize = resources.getDimension(R.dimen.search_hint_text_size)
        binding.search.setHintTextColor(colorWithAlpha)

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }/* binding.ivKeyboard.setOnClickListener {
             openKeyboard()
         }*/

        binding.ivKeyboard.setOnClickListener {
            isNumericKeyboard = !isNumericKeyboard
            toggleKeyboard()
        }

        binding.search.doAfterTextChanged {
            /* searchHandle.removeCallbacks(searchRunnable)
             searchHandle.postDelayed(searchRunnable, 300)*/
            search()
        }

        binding.letterFastscroller.textColor = colorWithAlpha.getColorStateList()
        binding.letterFastscroller.pressedTextColor = baseConfig.primaryColor
        binding.letterFastscrollerThumb.textColor = baseConfig.primaryColor.getContrastColor()
        binding.letterFastscrollerThumb.thumbColor = baseConfig.primaryColor.getColorStateList()

        binding.contacts.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (binding.search.hasFocus() && newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    binding.search.hideKeyboard()
                    binding.search.post {
                        binding.search.clearFocus()
                    }

                }
            }
        })
        binding.letterFastscroller.setOnTouchListener { view, _ ->
            if (binding.search.hasFocus()) {
                binding.search.hideKeyboard()
                binding.search.post {
                    binding.search.clearFocus()
                }
            }

            return@setOnTouchListener false
        }
    }

    override fun render(state: ContactsState) {
        binding.cancel.isVisible = state.query.length > 1
        if (binding.search.length() == 0) {
            composeItems = state.composeItems
            setAdaptor(ArrayList(composeItems))
        }


        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            if (state.selectedContact.name.isEmpty() && state.selectedContact.numbers.isEmpty() && state.selectedContact.getContacts().size == 1 && state.selectedContact.getContacts().first().contact != null) {
                val contactNumber = state.selectedContact.getContacts().first().contact?.numbers?.first()?.address ?: ""
                if (contactNumber.isNotEmpty()) {
                    val map = HashMap<String, String?>()
                    map[contactNumber] = ""
                    finish(map)
                }
                return
            }

            if (composeItems.isEmpty()) {
                // show empty UI or at least clear adapter
                setAdaptor(emptyList())
                return
            }

            if (binding.search.length() == 0) {
                setAdaptor(composeItems)
            } else {
                search() // ensures search works on updated list
            }

            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name

            phoneNumberDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
    }

    fun setAdaptor(list: List<ContactDataItem>) {

        Log.e("setAdaptor", "setAdaptor - : ${list.size}")

        binding.contacts.layoutManager?.onRestoreInstanceState(null)
        contactsAdapter.updateData(list) { dataList ->
            setupLetterFastscroller(dataList)
            binding.letterFastscrollerThumb.setupWithFastScroller(binding.letterFastscroller)
            binding.letterFastscrollerThumb.postDelayed({
                binding.letterFastscroller.beVisible()
            }, 200)
        }
    }

    fun setupLetterFastscroller(contacts: List<ContactDataItem>) {
        binding.letterFastscroller.setupWithRecyclerView(binding.contacts, { position ->
            try {
                val contact = contacts[position]
                var name = when (contact) {
                    is ContactDataItem.New -> ""
                    is ContactDataItem.Header -> contact.value
                    is ContactDataItem.Person -> contact.value.name
                    else -> ""
                }

                val character = if (name.isNotEmpty()) name.substring(0, 1) else ""
                FastScrollItemIndicator.Text(
                    character.normalizeString().uppercase(Locale.getDefault())
                )
            } catch (e: Exception) {
                FastScrollItemIndicator.Text("")
            }
        })

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        fetchContacts.onNext("") // force refresh every time screen is opened
    }


    override fun clearQuery() {
        binding.search.text = null
    }

    private var isNumericKeyboard = false

    private fun toggleKeyboard() {
        binding.search.postDelayed({
            if (isNumericKeyboard) {
                // Show numeric keyboard
                binding.search.inputType = InputType.TYPE_CLASS_NUMBER
                binding.ivKeyboard.setImageResource(R.drawable.ic_keyboard) // show ABC icon
            } else {
                // Show alphabetic keyboard
                binding.search.inputType = InputType.TYPE_CLASS_TEXT
                binding.ivKeyboard.setImageResource(R.drawable.ic_keyboard_number) // show 123 icon
            }

            // Move cursor to end
            binding.search.setSelection(binding.search.text?.length ?: 0)

            // Show keyboard
            binding.search.showKeyboard()
        }, 100)
    }


    fun EditText.showKeyboard() {
        requestFocus()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
    }


    override fun openKeyboard() {
        binding.search.postDelayed({
            binding.search.showKeyboard()
        }, 100)
    }

    override fun back() {
        onBackPressed()
    }

    override fun finish(result: HashMap<String, String?>) {
        binding.search.hideKeyboard()
        Log.e("SearchResult", "finish: ${result.size}")
        val intent = Intent().putExtra(ChipsKey, result)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

}
