package messages.text.sms.feature.blocking

import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.google.android.material.tabs.TabLayout
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityMainBlockBinding
import messages.text.sms.feature.main.BlockedMessageListActivity
import messages.text.sms.util.Preferences

class MainBlockActivity : MainBaseThemedActivity() {
    private val binding by viewBinding(ActivityMainBlockBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        setTitle(getString(R.string.custom_blocking))
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        // Default tab
        switchToTab(0)

        binding.tabKeywords.setOnClickListener { switchToTab(0) }
        binding.tabContact.setOnClickListener { switchToTab(1) }

        val selectedTab = intent.getIntExtra("selected_tab", 0)
        switchToTab(selectedTab)

        setUpTheme()


    }


    private fun setUpTheme() {

        updateTextColors(binding.main)
        //  binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.main.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
        } else {
            binding.main.background = ColorDrawable(baseConfig.backgroundColor)
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.main.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }
    }

    private fun switchToTab(position: Int) {
        val fragment = when (position) {
            1 -> ContactFragment()
            else -> KeywordsFragment()
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()

        updateTabStyle(position)
    }

    private fun updateTabStyle(selected: Int) {
        val selectedDrawable =
            ContextCompat.getDrawable(this, R.drawable.tab_selected_background)?.mutate()?.apply {
                setTint(baseConfig.primaryColor)
            }
        val unselectedDrawable =
            ContextCompat.getDrawable(this, R.drawable.tab_unselected_background)

        val white = Color.WHITE
        val black = Color.BLACK

        binding.tabKeywords.apply {
            background = if (selected == 0) selectedDrawable else unselectedDrawable
            setTextColor(if (selected == 0) white else black)
        }

        binding.tabContact.apply {
            background = if (selected == 1) selectedDrawable else unselectedDrawable
            setTextColor(if (selected == 1) white else black)
        }
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (item.itemId == android.R.id.home) {
            onBackPressed(); true
        } else {
            super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}
