package messages.text.sms.feature.contacts

import android.os.Bundle
import android.util.Log
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.realm.Realm
import io.realm.RealmList
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.adapters.ContactItemAdapter
import messages.text.sms.commons.helpers.ensureBackgroundThread
import messages.text.sms.databinding.ActivityGroupsBinding
import messages.text.sms.feature.fragments.contact.component.ContactDialog
import messages.text.sms.model.Contact
import messages.text.sms.model.ContactData
import messages.text.sms.model.ContactGroup
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.REFRESH_CONTACT_GROUP
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject

class GroupsActivity : MainBaseThemedActivity() {

    var id: Long = 0
    var title: String = ""

    @Inject
    lateinit var contactsRepo: messages.text.sms.repository.ContactRepository

    private val allContacts: Observable<List<Contact>> by lazy { contactsRepo.getUnmanagedContacts() }
    private val contactGroups: Observable<List<ContactGroup>> by lazy { contactsRepo.getUnmanagedContactGroups() }

    var contacts: RealmList<Contact> = RealmList()
    var contactGroup: ContactGroup? = null
    var contactsAdapter = ContactItemAdapter()

    private val binding by viewBinding(ActivityGroupsBinding::inflate)

    //    lateinit var binding:ActivityGroupsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        binding=ActivityGroupsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        setTitle(R.string.groups_label)
        showBackButton(true)
        if (intent.hasExtra("groupId")) {
            id = intent.getLongExtra("groupId", 0)
            title = intent.getStringExtra("groupName") ?: ""
            Log.e("GroupsActivity", "id:${id},title:${title}")
        }

        allContacts.autoDisposable(scope()).subscribe {
            Log.e("GroupsActivity", "allContacts:${it.size}")
            contacts.addAll(it)
//            updateContactGroup(contacts)
        }
        contactGroups.autoDisposable(scope()).subscribe { groups ->
            Log.e("GroupsActivity", "allContactGroups:${groups.size}")
            for (group in groups) {
                Log.e("GroupsActivity", "group.id:${group.id},contacts.size:${group.contacts.size}")
            }
            contactGroup = groups.firstOrNull { it.id == id }
//            contactGroup=groups.filter { it.id==id }.first()
            Log.e("GroupsActivity", "001:${groups.firstOrNull { it.id == id }?.contacts?.size}")

            if (contactGroup != null) {
                Log.e("GroupsActivity", "currentGroupContact:${contactGroup?.contacts?.size}")
                contacts.addAll(contactGroup?.contacts!!)
                updateContactGroup(contacts)
            }
        }

        binding.addGroupButton.floatingButton.setOnClickListener { _ ->
            val contactDialog = ContactDialog(contacts) {
                Log.e("GroupsActivity", "checkedContacts:${it.size}")
                contacts.addAll(it)
                addContactToGroup(it)
            }
            contactDialog.show(supportFragmentManager, contactDialog.tag)
        }

        binding.contacts.adapter = contactsAdapter
//        val list = (this)?.contacts ?: ArrayList()
//        contactsAdapter.data = list
    }

    fun updateContactGroup(contactList: RealmList<Contact>) {
        val contactDataList = contactList.map { contact ->
            ContactData(
                lookupKey = contact.lookupKey,
                numbers = ArrayList(contact.numbers),
                name = contact.name,
                photoUri = contact.photoUri,
                starred = contact.starred,
                lastUpdate = contact.lastUpdate
            )
        }
        runOnUiThread {
            contactsAdapter.data = contactDataList as List<ContactData>
        }
    }

    fun addContactToGroup(selectedContact: RealmList<Contact>) {
        ensureBackgroundThread {
            Realm.getDefaultInstance().use { realm ->
                val group = ContactGroup(id = id, title = title, contacts = selectedContact)
                realm.executeTransaction { realm.insertOrUpdate(group) }
            }
            runOnUiThread {
                EventBus.getDefault().post(MessageEvent(REFRESH_CONTACT_GROUP))
//                dialog?.dismiss()
//                callback.invoke()
            }
        }
    }
}