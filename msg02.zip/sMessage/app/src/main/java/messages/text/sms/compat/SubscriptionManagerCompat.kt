package messages.text.sms.compat

import android.content.Context
import android.telephony.SubscriptionManager
import messages.text.sms.manager.PermissionManager
import javax.inject.Inject

class SubscriptionManagerCompat @Inject constructor(
    context: Context,
    private val permissions: PermissionManager,
) {

    private val subscriptionManager: SubscriptionManager?
        get() = field?.takeIf { permissions.hasPhone() }

    val activeSubscriptionInfoList: List<SubscriptionInfoCompat>
        get() {
            return subscriptionManager?.activeSubscriptionInfoList?.map { SubscriptionInfoCompat(it) }
                ?: listOf()
        }

    init {
        subscriptionManager = SubscriptionManager.from(context)
    }

    fun addOnSubscriptionsChangedListener(listener: OnSubscriptionsChangedListener) {
        subscriptionManager?.addOnSubscriptionsChangedListener(listener.listener)
    }

    fun removeOnSubscriptionsChangedListener(listener: OnSubscriptionsChangedListener) {
        subscriptionManager?.removeOnSubscriptionsChangedListener(listener.listener)
    }

    abstract class OnSubscriptionsChangedListener {

        val listener: SubscriptionManager.OnSubscriptionsChangedListener? =
            object : SubscriptionManager.OnSubscriptionsChangedListener() {
                override fun onSubscriptionsChanged() {
                    this@OnSubscriptionsChangedListener.onSubscriptionsChanged()
                }
            }

        abstract fun onSubscriptionsChanged()

    }

}