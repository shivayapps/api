package messages.text.sms.feature.themepicker

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgViewContract

interface ThemePickerView : MainBaseMsgViewContract<ThemePickerState> {

    fun themeSelected(): Observable<Int>
    fun hsvThemeSelected(): Observable<Int>
    fun clearHsvThemeClicks(): Observable<*>
    fun applyHsvThemeClicks(): Observable<*>

    fun setCurrentTheme(color: Int)

}