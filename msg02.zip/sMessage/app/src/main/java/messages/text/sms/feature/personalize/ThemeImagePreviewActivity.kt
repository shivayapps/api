package messages.text.sms.feature.personalize

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.app_image_theme_applied_successfully
import messages.text.sms.ads.app_image_theme_preview_activity
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.getBackgroundDrawable
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityThemePreviewBinding

class ThemeImagePreviewActivity : MainBaseThemedActivity() {

    //    var imagePath: String = "";
    var imageResource: Int = -1
    var primary_color: Int = 0;
    var jasin: String = "";
    var c_name: String = "";
    var statusbarcolorcheck: Int = 0
    var themeNo: Int = 0
//    private lateinit var bitmap: Bitmap

    private val binding by viewBinding(ActivityThemePreviewBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)



        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        showBackButton(true)
        setTitle(R.string.themes)

        setUI()
        setUpListener()
//        binding.ivBack.setOnClickListener {
//            onBackPressed()
//        }

        setUpTheme()

        binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))

        firebaseAnalyticsHandler.logMessages(
            app_image_theme_preview_activity, getActivityName()
        )

    }


    private fun setUpTheme() {

        updateTextColors(binding.contentView)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun setUI() {
        binding.cardBackground.beGone()
        binding.ivBackgroundImage.beVisible()
        c_name = intent.getStringExtra("c_name").toString()
        imageResource = getBackgroundDrawable(c_name)

        Log.e("MainActivity", "setUpTheme.ThemeImagePreview.c_name:${c_name}")
        Log.e("MainActivity", "setUpTheme.ThemeImagePreview.imageResource:${imageResource}")

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.root.background = drawable
            }
        }

        when (c_name.lowercase()) {
            "Th1" -> applyTheme(9, "#E8FFED", "#00A11F", R.drawable.bluw)
            "Th2" -> applyTheme(10, "#FFF8F2", "#FF833E", R.drawable.orange)
            "Th3" -> applyTheme(11, "#EDF9FF", "#0183C9", R.drawable.green)
            "Th3" -> applyTheme(12, "#F0F6FF", "#2569F1", R.drawable.blue)
//            "china" -> applyTheme(13, "#FFF6FB", "#FF6E96", R.drawable.thum_china)
//            "egypt" -> applyTheme(14, "#FEF5EB", "#FF9C00", R.drawable.thum_egypt)
//            "england" -> applyTheme(15, "#F5F6FF", "#49434E", R.drawable.thum_england)
//            "france" -> applyTheme(16, "#FFF1E4", "#805A29", R.drawable.thum_france)
//            "india" -> applyTheme(17, "#FFF9F3", "#FF833E", R.drawable.thum_india)
//            "japan" -> applyTheme(18, "#EBFAFF", "#157AAB", R.drawable.thum_japan)
//            "russia" -> applyTheme(19, "#EDF2FF", "#13539C", R.drawable.thum_russia)
//            "usa" -> applyTheme(20, "#F1FCFA", "#0183C9", R.drawable.thum_usa)
        }
    }

    fun applyTheme(themeNo: Int, statusbarColor: String, primaryColor: String, imageRes: Int) {
        this.themeNo = themeNo
        primary_color = Color.parseColor(primaryColor)
        statusbarcolorcheck = Color.parseColor(statusbarColor)
//        binding.btnApply.setBackgroundResource(R.drawable.round_button)
//        binding.btnApply.backgroundTintList = ColorStateList.valueOf(Color.parseColor(primaryColor))
        Glide.with(this).load(imageRes).into(binding.ivBackgroundImage)
    }

    private fun setUpListener() {

        binding.btnApply.setOnClickListener {

            prefs.selectedThemeNo.set(themeNo)
            baseConfig.themenameuri = ""
            prefs.themechanged.set(true)
            baseConfig.apply {
                themenameuri = c_name
                checkprimaryColortheme = context.resources.getColor(R.color.white);

                baseConfig.statusBarColor = statusbarcolorcheck
                binding.toolbar.setBackgroundColor(statusbarcolorcheck)
                primaryColortheme = primary_color
                primaryColor = primary_color
                storedImageResource = imageResource
                accentColor = Color.parseColor("#FFFFFF")
                backgroundColor = Color.parseColor("#FFFFFF")
                toolbarcolor = Color.parseColor("#00FFFFFF")
                customTextColor = Color.parseColor("#000000")
                customAppIconColor = Color.parseColor("#000000")
                textColor = Color.parseColor("#000000")
                customAccentColor = Color.parseColor("#FFFFFF")
                customPrimaryColor = Color.parseColor("#FFFFFF")

                useImageResource = true
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                window.statusBarColor = statusbarcolorcheck

                if (baseConfig.useImageResource) {
                    if (baseConfig.storedImageResource == -1) {
                    } else {
                        val drawable = ContextCompat.getDrawable(
                            this@ThemeImagePreviewActivity,
                            baseConfig.storedImageResource
                        )
                        binding.contentView.background = drawable
                    }
                }
                updateTextColors(binding.contentView)
                binding.btnApply.setTextColor(accentColor)

            }
            Toast.makeText(
                this,
                "" + resources.getString(R.string.theme_applied_successfully),
                Toast.LENGTH_SHORT
            ).show()

            firebaseAnalyticsHandler.logMessages(
                app_image_theme_applied_successfully, getActivityName()
            )
            onBackPressed()
        }

    }

}