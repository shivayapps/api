package messages.text.sms.commons.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.databinding.ItemMessageCategoryBinding


class AdapterHomeCategory(
    var list: MutableList<Pair<String, Int>>,
    var context: android.content.Context,
    var currentPosition: Int,
    private val listener: (String, Int) -> Unit
) :
    RecyclerView.Adapter<AdapterHomeCategory.HolderCategory>() {

//    private var currentPosition = 0
    var isSelected = false

    inner class HolderCategory(
        var mItemBind: ItemMessageCategoryBinding,
        var categoryHomeAdapter: AdapterHomeCategory
    ) :
        RecyclerView.ViewHolder(mItemBind.root) {
        fun setData(position: Int, listener: (String, Int) -> Unit) {
            val pair = categoryHomeAdapter.list[position]
            mItemBind.tvCatName.text = pair.first
            if (pair.second != 0) {
                mItemBind.imgCat.setImageDrawable(
                    ContextCompat.getDrawable(
                        mItemBind.imgCat.context,
                        pair.second
                    )
                )
                mItemBind.imgCat.beVisible()
            } else {
                mItemBind.imgCat.beGone()

            }
            if (position == categoryHomeAdapter.currentPosition) {
                mItemBind.viewSelect.beVisible()
            } else {
                mItemBind.viewSelect.beGone()
            }
            if(isSelected){
                mItemBind.lnrCatItem.alpha = 0.5f
            }else{
                mItemBind.lnrCatItem.alpha = 1f
            }
            mItemBind.lnrCatItem.setOnClickListener {
                if(isSelected){
                    return@setOnClickListener
                }
                if (position == categoryHomeAdapter.currentPosition) {
                    return@setOnClickListener
                }
                listener("clickCategory", position)
                val previousPos = categoryHomeAdapter.currentPosition
                categoryHomeAdapter.currentPosition = position

                if (previousPos != categoryHomeAdapter.currentPosition) {
                    categoryHomeAdapter.notifyItemChanged(previousPos)
                }
                categoryHomeAdapter.notifyItemChanged(categoryHomeAdapter.currentPosition)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderCategory {
        val mItemBind: ItemMessageCategoryBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_message_category,
            parent,
            false
        )
        return HolderCategory(mItemBind, this)
    }

    override fun onBindViewHolder(holder: HolderCategory, position: Int) {
        holder.setData(position, listener)
    }

    override fun getItemCount(): Int {
        return list.size
    }
}