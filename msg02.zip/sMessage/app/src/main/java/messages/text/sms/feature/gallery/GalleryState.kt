package messages.text.sms.feature.gallery

import io.realm.RealmResults
import messages.text.sms.model.MmsPart

data class GalleryState(
    val navigationVisible: Boolean = true,
    val title: String? = "",
    val parts: RealmResults<MmsPart>? = null,
)
