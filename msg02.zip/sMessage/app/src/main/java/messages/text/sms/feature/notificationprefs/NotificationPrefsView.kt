package messages.text.sms.feature.notificationprefs

import android.net.Uri
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MainBaseMsgView
import messages.text.sms.common.widget.PreferenceView

interface NotificationPrefsView : MainBaseMsgView<NotificationPrefsState> {

    val preferenceClickIntent: Subject<PreferenceView>
    val previewModeSelectedIntent: Subject<Int>
    val ringtoneSelectedIntent: Observable<String>
    val actionsSelectedIntent: Subject<Int>

    fun showPreviewModeDialog()
    fun showRingtonePicker(default: Uri?)
    fun showActionDialog(selected: Int)
}
