package messages.text.sms.feature.compose

import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Layout
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.StyleSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.RealmResults
import messages.text.sms.R
import messages.text.sms.ads.AdmobNative
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.base.MainBaseRealmAdapter
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.TextViewStyler
import messages.text.sms.common.util.extensions.dpToPx
import messages.text.sms.common.util.extensions.forwardTouches
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.setPadding
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.setVisible
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.toast
import messages.text.sms.commons.helpers.BubbleStyleType
import messages.text.sms.commons.helpers.ReConstant
import messages.text.sms.compat.SubscriptionManagerCompat
import messages.text.sms.databinding.MessageListItemInBinding
import messages.text.sms.extensions.isSmil
import messages.text.sms.extensions.isText
import messages.text.sms.feature.compose.BubbleUtils.canGroup
import messages.text.sms.feature.compose.part.PartsAdapter
import messages.text.sms.model.Conversation
import messages.text.sms.model.Message
import messages.text.sms.model.Recipient
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.Preferences
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern
import javax.inject.Inject
import javax.inject.Provider

class MessagesAdapter @Inject constructor(
    subscriptionManager: SubscriptionManagerCompat,
    private val context: Context,
    private val colors: Colors,
    private val dateFormatter: DateFormatter,
    private val partsAdapterProvider: Provider<PartsAdapter>,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val prefs: Preferences,
    private val textViewStyler: TextViewStyler,
) : MainBaseRealmAdapter<Message, MessageListItemInBinding>() {

    companion object {
        private const val VIEW_TYPE_MESSAGE_IN = 0
        private const val VIEW_TYPE_MESSAGE_OUT = 1
        private const val VIEW_TYPE_ADS = 2

        // https://gist.github.com/cmkilger/b8f7dba3e76244a84e7e
        private val EMOJI_REGEX = Regex(
            "^[\\s\n\r]*(?:(?:[\u00a9\u00ae\u203c\u2049\u2122\u2139\u2194-\u2199\u21a9-\u21aa\u231a-\u231b\u2328\u23cf\u23e9-\u23f3\u23f8-\u23fa\u24c2\u25aa-\u25ab\u25b6\u25c0\u25fb-\u25fe\u2600-\u2604\u260e\u2611\u2614-\u2615\u2618\u261d\u2620\u2622-\u2623\u2626\u262a\u262e-\u262f\u2638-\u263a\u2648-\u2653\u2660\u2663\u2665-\u2666\u2668\u267b\u267f\u2692-\u2694\u2696-\u2697\u2699\u269b-\u269c\u26a0-\u26a1\u26aa-\u26ab\u26b0-\u26b1\u26bd-\u26be\u26c4-\u26c5\u26c8\u26ce-\u26cf\u26d1\u26d3-\u26d4\u26e9-\u26ea\u26f0-\u26f5\u26f7-\u26fa\u26fd\u2702\u2705\u2708-\u270d\u270f\u2712\u2714\u2716\u271d\u2721\u2728\u2733-\u2734\u2744\u2747\u274c\u274e\u2753-\u2755\u2757\u2763-\u2764\u2795-\u2797\u27a1\u27b0\u27bf\u2934-\u2935\u2b05-\u2b07\u2b1b-\u2b1c\u2b50\u2b55\u3030\u303d\u3297\u3299\ud83c\udc04\ud83c\udccf\ud83c\udd70-\ud83c\udd71\ud83c\udd7e-\ud83c\udd7f\ud83c\udd8e\ud83c\udd91-\ud83c\udd9a\ud83c\ude01-\ud83c\ude02\ud83c\ude1a\ud83c\ude2f\ud83c\ude32-\ud83c\ude3a\ud83c\ude50-\ud83c\ude51\u200d\ud83c\udf00-\ud83d\uddff\ud83d\ude00-\ud83d\ude4f\ud83d\ude80-\ud83d\udeff\ud83e\udd00-\ud83e\uddff\udb40\udc20-\udb40\udc7f]|\u200d[\u2640\u2642]|[\ud83c\udde6-\ud83c\uddff]{2}|.[\u20e0\u20e3\ufe0f]+)+[\\s\n\r]*)+$"
        )
    }

    private var hideItem: Boolean = false
    var isStarred: Boolean = false

    val clicks: Subject<Long> = PublishSubject.create()
    val clicksDelete: Subject<Long> = PublishSubject.create()
    val partClicks: Subject<Long> = PublishSubject.create()
    val cancelSending: Subject<Long> = PublishSubject.create()
    val removeStarMessageSubject: Subject<Long> = PublishSubject.create()
    var messageIdForUndoUnStar: Long = 0

    var data: Pair<Conversation, RealmResults<Message>>? = null
        set(value) {
            if (field === value) return

            field = value
            contactCache.clear()

            updateData(value?.second)
        }

    /**
     * Safely return the conversation, if available
     */
    private val conversation: Conversation?
        get() = data?.first?.takeIf { it.isValid }

    /**
     * Mark this message as highlighted
     */
    var highlight: Long = -1L
        set(value) {
            if (field == value) return

            field = value
            notifyDataSetChanged()
        }

    private val contactCache = ContactCache()
    private val expanded = HashMap<Long, Boolean>()
    private val partsViewPool = RecyclerView.RecycledViewPool()
    private val subs = subscriptionManager.activeSubscriptionInfoList

    var theme: Colors.Theme = colors.theme()


    private val backgroundColorOne = Color.parseColor("#F6F7F9")

    //    private val backgroundColorOne =
//        context.config.getIntData("backgroundColorone", Color.parseColor("#E7F0FB"))
    private val backgroundColorTwo =
        context.config.getIntData("backgroundColortwo", Color.parseColor("#E6F3FF"))
    private val backgroundTextColorOne =
        context.config.getIntData("backgroundtextColorone", Color.parseColor("#333333"))
    private val backgroundTextColorTwo =
        context.config.getIntData("backgroundtextColortwo", Color.parseColor("#1B4F7D"))
    private val stokeTwo =
        context.config.getIntData("stokeTwo", Color.parseColor("#C3E3FF"))

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<MessageListItemInBinding> {

        // Use the parent's context to inflate the layout, otherwise link clicks will crash the app
        val layoutInflater = LayoutInflater.from(parent.context)
        val view: View
        val adview: View
        if (viewType == VIEW_TYPE_ADS) {
            view = layoutInflater.inflate(R.layout.message_list_item_in, parent, false)
//            val binding = MessageListItemInBinding.bind(adView)
//            return MainBaseMsgViewHolder(binding)
        } else if (viewType == VIEW_TYPE_MESSAGE_OUT) {
            view = layoutInflater.inflate(R.layout.message_list_item_out, parent, false)
            view.findViewById<ImageView>(R.id.cancelIcon).setTint(theme.theme)
            view.findViewById<ProgressBar>(R.id.cancel).setTint(theme.theme)
        } else {
            view = layoutInflater.inflate(R.layout.message_list_item_in, parent, false)
        }

        val binding = MessageListItemInBinding.bind(view)

        binding.body.hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NONE
        val partsAdapter = partsAdapterProvider.get()
        partsAdapter.clicks.subscribe(partClicks)
        binding.attachments.adapter = partsAdapter
        binding.attachments.setRecycledViewPool(partsViewPool)
        binding.body.forwardTouches(view)

        if (selection.size > 0) binding.cbSelect.beVisible()
        else binding.cbSelect.beGone()


        val colorStateList = ColorStateList.valueOf(context.baseConfig.primaryColor)
        binding.cbSelect.buttonTintList = colorStateList


        return MainBaseMsgViewHolder(binding).apply {

            view.setOnClickListener {
                val message = getItem(adapterPosition) ?: return@setOnClickListener
                when (toggleSelection(message.id, false)) {
                    true -> {
                        view.isActivated = isSelected(message.id)
//                        binding.cbSelect.isChecked = selection.contains(message.id)
                    }

                    false -> {
                        try {
                            clicks.onNext(message.id)
                            expanded[message.id] = binding.status.visibility != View.VISIBLE
                            notifyItemChanged(adapterPosition)
                        } catch (e: Exception) {

                        }
                    }
                }
//                binding.status.visibility = if (expanded[getItem(adapterPosition)?.id] == true) {
//                    View.VISIBLE
//                } else {
//                    View.GONE
//                }
            }
            view.setOnLongClickListener {
                val message = getItem(adapterPosition) ?: return@setOnLongClickListener true
                toggleSelection(message.id)
                view.isActivated = isSelected(message.id)
                isStarred = message.starred
                true
            }
        }
    }

    fun getBubbleText(adapterPosition: Int): String {
        val conversation = getItem(adapterPosition)
        return if (conversation is Message) {
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getMessageTimestamp) ?: ""
        } else {
            ""
        }
    }

    fun toggleSelectAll(isSelect: Boolean) {
        val cnt = itemCount - 1
        Log.e("MessagesAdapter", "isSelect:$isSelect, cnt:$cnt")
        if (selection.size == cnt) {
            Log.e("MessagesAdapter", "toggleSelectAll.001")
            clearSelection()
        } else {
            selection = listOf()
            for (i in 0 until cnt) {
                val conversation = getItem(i)
                if (conversation != null) {
                    if (selection.contains(conversation.id)) {
                        if (!isSelect) {
                            Log.e("MessagesAdapter", "toggleSelectAll.004:${conversation.id}")
                            selection = selection - conversation.id
                        }
                    } else {
                        if (isSelect) {
                            Log.e("MessagesAdapter", "toggleSelectAll.005:${conversation.id}")
                            selection = selection + conversation.id
                        }
                    }
                }
            }
            Log.e("MessagesAdapter", "selection:${selection.size}")
            selectionChanges.onNext(selection)
            notifyDataSetChanged()
        }
    }


    fun toggleItemVisibility(hide: Boolean) {
        this.hideItem = hide
        notifyDataSetChanged()
//        notifyItemChanged(itemCount - 1)
    }

    override fun getItemCount(): Int {
        return super.getItemCount() + 1
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<MessageListItemInBinding>,
        position: Int,
    ) {


        if (holder.itemViewType == VIEW_TYPE_ADS) {

            holder.binding.clMessageView.visibility = View.GONE
            holder.binding.inNative.cvRoot.visibility = View.VISIBLE
            AdmobNative.populateChatNativeAd(
                holder.binding.root.context,
                holder.binding.inNative.cvRoot,
            )
            if (hideItem) {
                holder.binding.root.visibility = View.INVISIBLE
            } else {
                holder.binding.root.visibility = View.VISIBLE
            }
            return
        }

        holder.binding.inNative.cvRoot.visibility = View.INVISIBLE

        val message = getItem(position) ?: return
        val previous = if (position == 0) null else getItem(position - 1)
        val next = if (position == itemCount - 1) null else getItem(position + 1)

        val theme = when (message.isOutgoingMessage()) {
            true -> colors.theme()
            false -> colors.theme(contactCache[message.address])
        }
        // Update the selected state
        holder.binding.root.isActivated = isSelected(message.id) || highlight == message.id

        if (message.starred) {
            holder.binding.ivStar.beVisible()
            holder.binding.ivStar.setTint(context.baseConfig.primaryColor)
        } else {
            holder.binding.ivStar.beGone()
        }

        holder.binding.ivStar.setOnClickListener {
            val message = getItem(position)
            message?.id?.let { it1 ->
                messageIdForUndoUnStar = it1
                removeStarMessageSubject.onNext(it1)
            }
        }


        // Bind the cancel view
        holder.binding.cancel.let { cancel ->
            val isCancellable = message.isSending() && message.date > System.currentTimeMillis()
            cancel.setVisible(isCancellable)
            cancel.clicks().subscribe { cancelSending.onNext(message.id) }
            cancel.progress = 2

            if (isCancellable) {
                val delay = when (prefs.sendDelay.get()) {
                    Preferences.SEND_DELAY_SHORT -> 3000
                    Preferences.SEND_DELAY_MEDIUM -> 5000
                    Preferences.SEND_DELAY_LONG -> 10000
                    else -> 0
                }
                val progress =
                    (1 - (message.date - System.currentTimeMillis()) / delay.toFloat()) * 100

                ObjectAnimator.ofInt(cancel, "progress", progress.toInt(), 100)
                    .setDuration(message.date - System.currentTimeMillis())
                    .start()
            }
        }
        bindStatus(holder, message, next)

        // Bind the timestamp
        val timeSincePrevious =
            TimeUnit.MILLISECONDS.toMinutes(message.date - (previous?.date ?: 0))
        val subscription = subs.find { sub -> sub.subscriptionId == message.subId }

        holder.binding.timestamp.text = dateFormatter.getMessageTimestamp(message.date)
        holder.binding.simIndex.text = subscription?.simSlotIndex?.plus(1)?.toString()

        holder.binding.timestamp.setVisible(
            timeSincePrevious >= BubbleUtils.TIMESTAMP_THRESHOLD
                    || message.subId != previous?.subId && subscription != null
        )
        holder.binding.sim.setVisible(message.subId != previous?.subId && subscription != null && subs.size > 1)
        holder.binding.simIndex.setVisible(message.subId != previous?.subId && subscription != null && subs.size > 1)

        // Bind the grouping
        val media = message.parts.filter { !it.isSmil() && !it.isText() }
        holder.binding.root.setPadding(
            bottom = if (canGroup(message, next)) 0 else 16.dpToPx(
                context
            )
        )

        // Bind the avatar and bubble colour
        if (!message.isMe()) {
            try {
                holder.binding.avatar.setRecipient(contactCache[message.address])
            } catch (e: Exception) {
            }

            holder.binding.avatar.setVisible(!canGroup(message, next), View.INVISIBLE)

        }


        val fontId = prefs.selectedFont.get()
        val checkTypeface = try {
            ResourcesCompat.getFont(holder.binding.body.context, fontId)
        } catch (e: Resources.NotFoundException) {
            Typeface.DEFAULT
        }
        holder.binding.body.setTypeface(checkTypeface, checkTypeface?.style ?: Typeface.NORMAL)
        holder.binding.body.textSize = prefs.textSize.get().toFloat()

        // Bind the body text
        val messageText = when (message.isSms()) {
            true -> message.body
            false -> {
                val subject = message.getCleansedSubject()
                val body = message.parts
                    .filter { part -> part.isText() }
                    .mapNotNull { part -> part.text }
                    .filter { text -> text.isNotBlank() }
                    .joinToString("\n")

                when {
                    subject.isNotBlank() -> {
                        val spannable =
                            SpannableString(if (body.isNotBlank()) "$subject\n$body" else subject)
                        spannable.setSpan(
                            StyleSpan(Typeface.BOLD), 0, subject.length,
                            Spannable.SPAN_INCLUSIVE_EXCLUSIVE
                        )
                        spannable
                    }

                    else -> body
                }
            }
        }
        val emojiOnly = messageText.isNotBlank() && messageText.matches(EMOJI_REGEX)
        textViewStyler.setTextSize(
            holder.binding.body, when (emojiOnly) {
                true -> TextViewStyler.SIZE_EMOJI
                false -> TextViewStyler.SIZE_PRIMARY
            }, true
        )

        try {
            setDynamicDrawable(
                holder.binding.clMessageView,
                Color.parseColor(backgroundColorTwo.toString()),
                Color.parseColor(stokeTwo.toString())
            )
        } catch (e: Exception) {
        }

        if (!message.isMe()) {

            try {
//                holder.binding.body.background = null
//                val params = holder.binding.body.layoutParams as ConstraintLayout.LayoutParams
//                    params.setMargins(10, 5, 5, 0)
//                holder.binding.body.layoutParams = params

                /*  setDynamicDrawable(
                      holder.binding.clMessageView,
                      Color.parseColor("#F6F7F9"),
                      Color.parseColor("#ECEDEF")
                  )*/

                /* setDynamicDrawable(
                     holder.binding.body,
                     Color.parseColor("#F6F7F9"),
                     Color.parseColor("#ECEDEF")
                 )*/

                /* holder.binding.clMessageView.setBackgroundResource(
                     getBubble(
                         emojiOnly = emojiOnly,
                         canGroupWithPrevious = canGroup(
                             message,
                             previous
                         ) || media.isNotEmpty(),
                         canGroupWithNext = canGroup(message, next),
                         isMe = message.isMe(),
                         style = prefs.bubbleStyle.get()
                     )
                 )*/
//                    holder.binding.clMessageView.setPadding(10, 5, 10, 5)

            } catch (e: Exception) {
            }

            if ((data?.second?.size?.minus(1)) == position) {
                val resultOtp =
                    Pattern.compile(ReConstant.otp_regex.toString())
                        .matcher(message.body.replace("\n", " ").trim()).find()
                Log.e("resultOtp", "resultOtp:$resultOtp,body:${message.body}")
                if (resultOtp) {

                    copyOtpView(message, holder)
                    setDynamicDrawable(
                        holder.binding.clMessageView,
                        Color.parseColor("#F6F7F9"),
                        Color.parseColor("#ECEDEF")
                    )


                    Log.e("resultOtp", "001.width:${holder.binding.clMessageView.width},height:${holder.binding.clMessageView.height}")
//                    val layoutParams = holder.binding.clMessageView.layoutParams as ConstraintLayout.LayoutParams
//                    layoutParams.width = ConstraintLayout.LayoutParams.MATCH_PARENT
//                    layoutParams.width = 900
//                    layoutParams.width = 0
//                    layoutParams.height = ConstraintLayout.LayoutParams.WRAP_CONTENT
//                    layoutParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
//                    holder.binding.clMessageView.layoutParams = layoutParams
//                    holder.binding.clMessageView.updateLayoutParams<ConstraintLayout.LayoutParams> {
//                        width = 0
//                        height = ConstraintLayout.LayoutParams.WRAP_CONTENT
//                    }
//                    holder.binding.clMessageView.requestLayout()
                    Log.e("resultOtp", "002.width:${holder.binding.clMessageView.width},height:${holder.binding.clMessageView.height}")

                } else {
                    holder.binding.ivArrow.beGone()
                    holder.binding.layOtp.beGone()
                    setDynamicDrawable(
                        holder.binding.clMessageView,
                        Color.parseColor("#F6F7F9"),
                        Color.parseColor("#ECEDEF")
                    )
                }
            } else {
                holder.binding.ivArrow.beGone()
                holder.binding.layOtp.beGone()
                Log.e("MessagesAdapter", "001.layOtp.beGone")
                setDynamicDrawable(
                    holder.binding.clMessageView,
                    Color.parseColor("#F6F7F9"),
                    Color.parseColor("#ECEDEF")
                )
            }
        }
        if (selection.size > 0) holder.binding.cbSelect.beVisible()
        else holder.binding.cbSelect.beGone()
        holder.binding.cbSelect.isChecked = selection.contains(message.id)

        holder.binding.body.text = messageText
        //  holder.binding.body.text = Html.fromHtml(messageText.toString(), Html.FROM_HTML_MODE_LEGACY)
        holder.binding.body.setVisible(message.isSms() || messageText.isNotBlank())


        if (holder.binding.body.text.isNotBlank()) {
            holder.binding.rootLayout.post {
//                val constraintSet = ConstraintSet()
//                constraintSet.clone(holder.binding.rootLayout)

                // Set width based on message length
//                val width = if (messageText.length < 15) {
//                    ConstraintLayout.LayoutParams.WRAP_CONTENT
//                } else {
//                    ConstraintSet.MATCH_CONSTRAINT
//                }

                // Update constraints
//                constraintSet.constrainWidth(holder.binding.body.id, width)
//                constraintSet.applyTo(holder.binding.rootLayout)

                // Ensure visibility if hidden
                holder.binding.body.visibility = View.VISIBLE
            }
        } else {
            // Hide the message body if text is blank
            holder.binding.body.visibility = View.GONE
        }
        try {
            if (prefs.bubbleStyleType.get().equals(BubbleStyleType.AUTO.toString())) {

                if (message.isMe()) {
                    try {
                        holder.binding.clMessageView.setBackgroundTint(backgroundColorTwo)
                        holder.binding.body.setTextColor(backgroundTextColorTwo)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    try {
                        holder.binding.clMessageView.setBackgroundTint(backgroundColorOne)
                        holder.binding.body.setTextColor(backgroundTextColorOne)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }

            } else {
                if (message.isMe()) {
                    try {
                        holder.binding.clMessageView.setBackgroundTint(backgroundColorTwo)
                        holder.binding.body.setTextColor(backgroundTextColorTwo)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                } else {
                    try {
                        holder.binding.clMessageView.setBackgroundTint(backgroundColorOne)
                        holder.binding.body.setTextColor(backgroundTextColorOne)
                        holder.binding.tvOtp.setTextColor(backgroundTextColorOne)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }
            }
        } catch (e: Exception) {
        }

        // Bind the attachments
        val partsAdapter = holder.binding.attachments.adapter as PartsAdapter
        partsAdapter.theme = theme
        partsAdapter.setData(message, previous, next, holder)
    }

    //Copy otp View
    private fun copyOtpView(
        message: Message,
        holder: MainBaseMsgViewHolder<MessageListItemInBinding>,
    ) {

        holder.binding.ivArrow.beVisible()
        holder.binding.layOtp.beVisible()
        Log.e("MessagesAdapter", "002.layOtp.beVisible")
        holder.binding.tvOtp.text = ReConstant.parseCode(message.body.replace("\n", " ").trim())
//        holder.binding.clMessageView.setBackgroundResource(
//            R.drawable.message_only
//        )
//        holder.binding.clMessageView.setBackgroundTint(backgroundColorOne)
        holder.binding.btnCopy.setOnClickListener {
            ReConstant.copy(context, holder.binding.tvOtp.text.toString())
            context.toast(context.resources.getString(R.string.toast_copied))
        }
        holder.binding.ivArrow.setOnClickListener {
            toggleSingleLine(holder.binding.body, holder.binding.ivArrow)
        }
        holder.binding.ivDelete.setOnClickListener {
            selection = listOf<Long>()
            selection = selection + message.id
            selectionChanges.onNext(selection)
            //  ReConstant.copy(context, lastMessage?.otpCode ?: "")
            //  context.toast(context.resources.getString(R.string.toast_copied))
            clicksDelete.onNext(conversation?.id!!)
            //adapterItemDelete.onNext(conversation?.id)
        }

    }

    var rotationAngle = 0f
    private fun toggleSingleLine(textView: TextView, imageView: ImageView) {
        if (textView.maxLines == 1) {
            textView.maxLines = Integer.MAX_VALUE // Allow multiple lines
            textView.ellipsize = null

            rotationAngle = if (rotationAngle == 0f) 180f else 0f
            imageView.animate()
                .rotation(rotationAngle)
                .setDuration(300)
                .start()

        } else {
            textView.maxLines = 1 // Restrict to a single line
            textView.ellipsize = TextUtils.TruncateAt.END

            rotationAngle = if (rotationAngle == 0f) 180f else 0f
            imageView.animate()
                .rotation(rotationAngle)
                .setDuration(300)
                .start()
        }
    }

    private fun bindStatus(
        holder: MainBaseMsgViewHolder<MessageListItemInBinding>,
        message: Message,
        next: Message?,
    ) {
        val age = TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - message.date)

        holder.binding.status.text = when {
            message.isSending() -> {
                context.getString(R.string.message_status_sending)
            }

            message.isDelivered() -> {
                context.getString(
                    R.string.message_status_delivered,
                    dateFormatter.getTimestamp(message.dateSent)
                )
            }

            message.isFailedMessage() -> {
                context.getString(R.string.message_status_failed)
            }

            !message.isMe() && (conversation?.recipients?.size ?: 0) > 1 -> {
                "${contactCache[message.address]?.getDisplayName()} • ${
                    dateFormatter.getTimestamp(
                        message.date
                    )
                }"
            }

            else -> dateFormatter.getTimestamp(message.date)
        }

        holder.binding.status.setVisible(
            when {
                expanded[message.id] == true -> {
                    true
                }

                message.isSending() -> {
                    true
                }

                message.isFailedMessage() -> {
                    true
                }

                expanded[message.id] == false -> {
                    false
                }

                (conversation?.recipients?.size ?: 0) > 1 && !message.isMe() && next?.compareSender(
                    message
                ) != true -> {
                    true
                }

                message.isDelivered() && next?.isDelivered() != true && age <= BubbleUtils.TIMESTAMP_THRESHOLD -> {
                    true
                }

                else -> {
                    false
                }
            }
        )
    }

    override fun getItemViewType(position: Int): Int {
        if (position == itemCount - 1) {
            return VIEW_TYPE_ADS
        } else {
            val message = getItem(position) ?: return -1
            return when (message.isMe()) {
                true -> VIEW_TYPE_MESSAGE_OUT
                false -> VIEW_TYPE_MESSAGE_IN
            }

        }
    }

    private inner class ContactCache : HashMap<String, Recipient?>() {

        override fun get(key: String): Recipient? {
            if (super.get(key)?.isValid != true) {
                set(
                    key,
                    conversation?.recipients?.firstOrNull {
                        phoneNumberUtils.compare(
                            it.address,
                            key
                        )
                    })
            }
            return super.get(key)?.takeIf { it.isValid }
        }
    }

    fun setDynamicDrawable(view: View, bgColor: Int, strokeColor: Int) {
        val drawable =
            view.context.getDrawable(R.drawable.message_simple_out_last) as GradientDrawable
        drawable.setColor(bgColor)
        drawable.setStroke(4, strokeColor)
        view.background = drawable
    }

    fun setDynamicDrawable1(view: View, bgColor: Int, strokeColor: Int) {

        val stroke = darkenColor(bgColor, 1.4f)
        val drawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 14.dpToPx(view.context).toFloat()
            color = ColorStateList.valueOf(bgColor)
            setStroke(4, strokeColor)
        }

//        val newColor = darkenColor(color, 1.4f)
//        val drawable = GradientDrawable().apply {
//            shape = GradientDrawable.RECTANGLE
//            cornerRadius = 10.dpToPx(view.context).toFloat() // Convert DP to Pixels
//            setColor(newColor)
//            setStroke(2, color)
//        }
        view.background = drawable
    }

    private fun darkenColor(color: Int, factor: Float): Int {
//        val hsv = FloatArray(3)
//        Color.colorToHSV(color, hsv)
//        hsv[2] = (hsv[2] * factor).coerceAtMost(1.0f) // Increase brightness (value) to make it lighter
//        return Color.HSVToColor(hsv)

        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[2] *= factor // Reduce brightness (value) to make it darker
        return Color.HSVToColor(hsv)
    }

}