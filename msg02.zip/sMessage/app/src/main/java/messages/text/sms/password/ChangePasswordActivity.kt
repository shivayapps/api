package messages.text.sms.password

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.applyColorFilter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityChangePasswordBinding
import messages.text.sms.util.StringManager

class ChangePasswordActivity : MainBaseThemedActivity() {

    private val binding by viewBinding(ActivityChangePasswordBinding::inflate)
    private var tempPassword = ""

    private var password = ""
    private var mTempPassword = ""
    private lateinit var dots: List<ImageView>

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)


        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)


        title = getString(R.string.change_pin)

        init()
        setUpTheme()
        setNumberButtonListeners()
        setBackspaceListener()

    }

    private fun init() {


        binding.tvEnterPassword.text = getString(R.string.please_confirm_your_pin)
        binding.forgetpassword.visibility = View.GONE




        dots = listOf(
            binding.dot1,
            binding.dot2,
            binding.dot3,
            binding.dot4
        )

    }

    private fun setNumberButtonListeners() {
        val buttons = listOf<Button>(
            binding.btn1,
            binding.btn2,
            binding.btn3,
            binding.btn4,
            binding.btn5,
            binding.btn6,
            binding.btn7,
            binding.btn8,
            binding.btn9,
            binding.btn0
        )

        buttons.forEach { button ->
            button.setOnClickListener {
                if (password.length < 4) {
                    password += (button.text as String)
                    updateDots()
                }
                if (password.length == 4) {
                    // Handle 4-digit password entered
                    handlePasswordEntered()
                }
            }
        }
    }

    private fun setBackspaceListener() {
        binding.btnBackspace.setOnClickListener {
            if (password.isNotEmpty()) {
                password = password.dropLast(1)
                updateDots()
            }
        }

        binding.forgetpassword.setOnClickListener {
            startActivity(
                Intent(
                    this@ChangePasswordActivity,
                    ForgetPasswordActivity::class.java
                )
            )
            finish()
        }
    }

    private fun updateDots() {
        for (i in 0 until 4) {
            if (i < password.length) {
                dots[i].setImageResource(R.drawable.ic_dot_filled)
            } else {
                dots[i].setImageResource(R.drawable.ic_dot_empty)
            }
        }
    }

    private fun handlePasswordEntered() {


        if (mTempPassword.isNotEmpty()) {
            if (mTempPassword == password) {
                baseConfig.privatePin = password
                binding.tvEnterPassword.text = getString(R.string.please_enter_your_pin)
                password = ""
                updateDots()
                finish()
            } else {
                binding.tvEnterPassword.text = getString(R.string.pin_does_not_match_try_again)
                password = ""
                mTempPassword = ""
                updateDots()
            }

        } else {
            if (password.length == 4) {
                binding.tvEnterPassword.text = getString(R.string.please_confirm_your_pin)
                mTempPassword = password
                password = ""
                updateDots()
            }
        }


    }

    private fun setUpTheme() {

        updateTextColors(binding.mainLayout)

        if (baseConfig.backgroundColor.equals(Color.BLACK)) {
            binding.toolbar.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.toolbar.background = ColorDrawable(baseConfig.statusBarColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource != -1) {
//                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
//                binding.mainLayout.background = drawable
//                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))

                if (baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(this)
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    binding.mainLayout.background = drawable
                    toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                } else {
                    val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                    binding.mainLayout.background = drawable
                    toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                }
            }
        } else {
            binding.mainLayout.background = null
            toolbar.setBackgroundColor(baseConfig.backgroundColor)

        }

        if (baseConfig.backgroundColor.equals(baseConfig.primaryColor)) {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable

            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(Color.parseColor("#FFFFFF"))

        } else {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(baseConfig.primaryColor)
        }

    }
}