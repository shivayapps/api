package messages.text.sms.commons.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.commons.extensions.applyColorFilter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.getBottomNavigationBackgroundColorFont
import messages.text.sms.commons.extensions.updateTextColors

class FontListAdapter(
    private val context: Context,
    private val fontList: MutableList<Int>,
    var checkstylename: Int,
    private val listener: (Int) -> Unit,
) : RecyclerView.Adapter<FontListAdapter.ViewHolder>() {

    private var selectedPosition = RecyclerView.NO_POSITION
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val fontName = fontList[position]

        context.updateTextColors(holder.llmain)
        holder.fontTextView.text = "AaBbCc"
//        val typeface = Typeface.createFromAsset(context.assets, "font/$fontName.ttf")

        val typeface = ResourcesCompat.getFont(context, fontName)
        holder.fontTextView.typeface = typeface
        holder.item_textsec.typeface = typeface

        try {
            selectedPosition = getPositionByName(checkstylename)
        } catch (e: Exception) {
            selectedPosition = -1
        }

//        if (context.baseConfig.backgroundColor.equals(Color.BLACK)){
        holder.fontTextView.setTextColor(context.baseConfig.textColor)

//        }else{
//            holder.fontTextView.setTextColor(context.resources.getColor(R.color.black))
//        }
        arrayOf(
            holder.llmain
        ).forEach {
            if (context.baseConfig.useImageResource == true) {
                if (context.baseConfig.storedImageResource == -1) {

                } else {
                    it.background.applyColorFilter(context.resources.getColor(R.color.transperent30))
                }
            } else {
                it.background.applyColorFilter(context.getBottomNavigationBackgroundColorFont())
            }
        }
        if (position == selectedPosition) {
            holder.itemView.background.applyColorFilter(context.baseConfig.primaryColor)
            holder.fontTextView.setTextColor(context.resources.getColor(R.color.white))
        } else {
            holder.itemView.background.applyColorFilter(context.getBottomNavigationBackgroundColorFont())
            holder.fontTextView.setTextColor(context.baseConfig.textColor)
        }
    }

    override fun getItemCount(): Int {
        return fontList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fontTextView: TextView = itemView.findViewById(R.id.item_text)
        val item_textsec: TextView = itemView.findViewById(R.id.item_textsec)
        val llmain: LinearLayout = itemView.findViewById(R.id.llmain)

        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val fontName = fontList[position]
                    checkstylename = fontList[position]
                    // Update the selected position and notify the adapter
                    val previousPosition = selectedPosition
                    selectedPosition = position
                    notifyItemChanged(previousPosition)
                    notifyItemChanged(selectedPosition)

                    listener.invoke(checkstylename)
//                    listener.onFontItemClick(fontName)
                }
            }
        }

    }


    fun getPositionByName(fontName: Int): Int {
        return fontList.indexOf(fontName)
    }

}
