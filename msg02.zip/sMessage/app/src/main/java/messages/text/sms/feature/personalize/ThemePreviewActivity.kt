package messages.text.sms.feature.personalize

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.bumptech.glide.Glide
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.app_color_theme_applied_successfully
import messages.text.sms.ads.app_color_theme_preview_activity
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.applyColorFilter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.getProperBackgroundColor
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityThemePreviewBinding

class ThemePreviewActivity : MainBaseThemedActivity() {

    var color: Int = 0;
    var position: Int = 0;
    var c_name: String = "";

//    lateinit var prefs: AdsPreferences

    private val binding by viewBinding(ActivityThemePreviewBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)



        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        showBackButton(true)
        setTitle(R.string.themes)

        setUI()
        setUpListener()
//        binding.ivBack.setOnClickListener {
//            onBackPressed()
//        }

        setUpTheme()

        binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))

        firebaseAnalyticsHandler.logMessages(
            app_color_theme_preview_activity, getActivityName()
        )
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")

        updateTextColors(binding.contentView)
        //   binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
//            arrayListOf(binding.ivBack).forEach {
//                val colorStateList = ColorStateList.valueOf(Color.WHITE)
//                it.imageTintList = colorStateList
//            }
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
//            arrayListOf(binding.ivBack).forEach {
////                val whiteColor = ContextCompat.getColor(this, R.color.black)
//                val colorStateList = ColorStateList.valueOf(Color.BLACK)
//                it.imageTintList = colorStateList
//            }
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    private fun setUI() {

        color = intent.getIntExtra("color", 0)
        position = intent.getIntExtra("position", 0)
        c_name = intent.getStringExtra("c_name").toString()

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.root.background = drawable
            }
        }

        binding.cardBackground.beVisible()
        binding.ivBackgroundImage.beGone()
        if (position == 7) {
            Glide.with(this).load(R.drawable.theme_preview_black).into(binding.ivBackground)
        } else {
            Glide.with(this).load(R.drawable.theme_preview).into(binding.ivBackground)
        }

        if (baseConfig.backgroundColor.equals(color)) {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable

            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(Color.parseColor("#FFFFFF"))
            binding.btnApply.background = applyBackground
            binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))
        } else {
            val applyBackground = ResourcesCompat.getDrawable(
                resources,
                R.drawable.button_background_rounded,
                getTheme()
            ) as RippleDrawable
            (applyBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
                .applyColorFilter(color)
            binding.btnApply.background = applyBackground
            binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))
        }
        /* val carBackground = ResourcesCompat.getDrawable(
             resources,
             R.drawable.button_background_rounded,
             getTheme()
         ) as RippleDrawable
         (carBackground as LayerDrawable).findDrawableByLayerId(R.id.button_background_holder)
             .applyColorFilter(color)
         binding.cardBackground.setCardBackgroundColor(color)*/

        binding.cardBackground.setCardBackgroundColor(color)
        binding.btnApply.setBackgroundResource(R.drawable.round_button)

        binding.btnApply.backgroundTintList = ColorStateList.valueOf(color)
    }

    private fun setUpListener() {

        binding.btnApply.setOnClickListener {
            baseConfig.themenameuri = ""
            prefs.theme().set(color)

            prefs.themechanged.set(true)
            prefs.selectedThemeNo.set(position + 1)
            if (position == 7) {
                baseConfig.statusBarColor = Color.parseColor("#000000")
                baseConfig.apply {
                    useImageResource = false
                    primaryColortheme = color
                    checkprimaryColortheme = color
//                        primaryColor = color
                    primaryColor = Color.parseColor("#0183C9")
                    accentColor = Color.parseColor("#000000")
                    backgroundColor = Color.parseColor("#000000")
                    toolbarcolor = Color.parseColor("#000000")
                    customAccentColor = Color.parseColor("#000000")
                    customPrimaryColor = Color.parseColor("#000000")


                    customTextColor = Color.parseColor("#FFFFFF")
                    customAppIconColor = Color.parseColor("#FFFFFF")
                    textColor = Color.parseColor("#FFFFFF")

                    if (baseConfig.useImageResource == true) {
                        if (baseConfig.storedImageResource == -1) {

                        } else {
                            val bitmapDrawable = ContextCompat.getDrawable(
                                this@ThemePreviewActivity,
                                baseConfig.storedImageResource
                            )
                            binding.contentView.background = bitmapDrawable
                        }
                    }
                    updateTextColors(binding.contentView)
                    getProperBackgroundColor()

                }
                Toast.makeText(
                    this,
                    getString(R.string.the_theme_has_been_applied_successfully), Toast.LENGTH_SHORT
                ).show()
                firebaseAnalyticsHandler.logMessages(
                    app_color_theme_applied_successfully, getActivityName()
                )
                onBackPressed()
            } else {

                baseConfig.statusBarColor = Color.parseColor("#FFFFFF")
                baseConfig.apply {
                    primaryColortheme = color
                    checkprimaryColortheme = color

                    primaryColor = color
                    //   primaryColor = Color.parseColor("#2569F1")
                    accentColor = Color.parseColor("#FFFFFF")
                    backgroundColor = Color.parseColor("#FFFFFF")
                    toolbarcolor = Color.parseColor("#FFFFFF")
                    customTextColor = Color.parseColor("#000000")
                    customAppIconColor = Color.parseColor("#000000")
                    textColor = Color.parseColor("#000000")
                    customAccentColor = Color.parseColor("#FFFFFF")
                    customPrimaryColor = Color.parseColor("#FFFFFF")
                    useImageResource = false
                    updateTextColors(binding.contentView)
                    getProperBackgroundColor()

                    binding.ivBackground.setBackgroundColor(Color.parseColor("#FFFFFF"))
                }
                Toast.makeText(
                    this,
                    getString(R.string.the_theme_has_been_applied_successfully), Toast.LENGTH_SHORT
                ).show()
                firebaseAnalyticsHandler.logMessages(
                    app_color_theme_applied_successfully, getActivityName()
                )
                onBackPressed()
            }

            binding.btnApply.setTextColor(Color.parseColor("#FFFFFF"))
        }

    }

}