package messages.text.sms.feature.blocking

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.util.Log
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.blocking.BlockingClient
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.interactor.MarkBlocked
import messages.text.sms.interactor.MarkUnblocked
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import messages.text.sms.util.appPreference
import javax.inject.Inject

class BlockingDialog @Inject constructor(
    private val blockingManager: BlockingClient,
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val markBlocked: MarkBlocked,
    private val markUnblocked: MarkUnblocked,
) {

    fun show(activity: Activity, conversationIds: List<Long>, block: Boolean) = GlobalScope.launch {
        val addresses = conversationIds.toLongArray()
            .let { conversationRepo.getConversations(*it) }
            .flatMap { conversation -> conversation.recipients }
            .map { it.address }
            .distinct()

        if (addresses.isEmpty()) {
            return@launch
        }

        if (blockingManager.getClientCapability() == BlockingClient.Capability.BLOCK_WITHOUT_PERMISSION) {
            if (activity is MainActivity) {

            } else {
                context.appPreference.isRefreshMessages = true
            }
            // If we can block/unblock in the external manager, then just fire that off and exit


            /* if (block) {
                 markBlocked.execute(
                     MarkBlocked.Params(
                         conversationIds,
                         prefs.blockingManager.get(),
                         null
                     )
                 )
                 blockingManager.block(addresses).subscribe()
             } else {
                 markUnblocked.execute(conversationIds)
                 blockingManager.unblock(addresses).subscribe()
             }*/

            val currentBlockedList = context.baseConfig.blockContactsList


            if (block) {
                // Block contacts
                markBlocked.execute(
                    MarkBlocked.Params(
                        conversationIds,
                        prefs.blockingManager.get(),
                        null
                    )
                )
                //     blockingManager.block(addresses).subscribe()

                // Add new addresses to the blocked list

                for (item in addresses) {
                    currentBlockedList.add(Contact(item, item))
                }
            } else {
                // Unblock contacts
                markUnblocked.execute(conversationIds)
                //     blockingManager.unblock(addresses).subscribe()

                // Remove unblocked addresses from the list

                Log.e("BVVVVVV", "addresses  -  " + addresses)
                /*  for(item in addresses){

                      Log.e("BVVVVVV","currentBlockedList  -  " + item)

                      val localNumber = removeCountryCode(item)
                      currentBlockedList.remove(localNumber)
                  }*/

                val iterator = addresses.iterator()

                while (iterator.hasNext()) {
                    val item = iterator.next()
                    val localNumber = removeCountryCode(item)

                    val match = currentBlockedList.find {
                        removeCountryCode(it.phone?.ifBlank { it.name } ?: "") == localNumber
                    }
                    if (match != null) {
                        Log.e("BVVVVVV", "Removing: $item and $match")

                        currentBlockedList.remove(match)
                        //iterator.remove() // remove from addresses
                    }
                }

            }

            context.baseConfig.blockContactsList = currentBlockedList


        } else if (block == allBlocked(addresses)) {
            if (activity is MainActivity) {

            } else {
                context.appPreference.isRefreshMessages = true
            }
            // If all of the addresses are already in their correct state in the blocking manager, just marked the
            // conversations blocked and exit
            when (block) {
                true -> markBlocked.execute(
                    MarkBlocked.Params(
                        conversationIds,
                        prefs.blockingManager.get(),
                        null
                    )
                )
                false -> markUnblocked.execute(conversationIds)
            }
        } else {
            // Otherwise, show the UI that lets the users know they need to mark the number as blocked in the client
            showDialog(activity, conversationIds, addresses, block)
        }
    }

    private fun allBlocked(addresses: List<String>): Boolean = addresses.all { address ->
        blockingManager.getAction(address).blockingGet() is BlockingClient.Action.Block
    }

    fun removeCountryCode(number: String): String {
        // Remove + sign and non-digit characters
        val cleaned = number.replace("[^\\d]".toRegex(), "")

        // Assuming country code is up to 3 digits and the remaining is 10-digit number
        return if (cleaned.length > 10) {
            cleaned.substring(cleaned.length - 10)
        } else {
            cleaned
        }
    }


    private suspend fun showDialog(
        activity: Activity,
        conversationIds: List<Long>,
        addresses: List<String>,
        block: Boolean,
    ) = withContext(MainScope().coroutineContext) {
        val res = when (block) {
            true -> R.plurals.blocking_block_external
            false -> R.plurals.blocking_unblock_external
        }

        val manager = context.getString(
            when (prefs.blockingManager.get()) {
                Preferences.BLOCKING_MANAGER_SIA -> R.string.blocking_manager_sia_title
                Preferences.BLOCKING_MANAGER_CC -> R.string.blocking_manager_call_control_title
                else -> R.string.blocking_manager_qksms_title
            }
        )

        val message = context.resources.getQuantityString(res, addresses.size, manager)

        // Otherwise, show a dialog asking the user if they want to be directed to the external
        // blocking manager
        AlertDialog.Builder(activity, R.style.CustomFieldDialogTheme)
            .setTitle(
                when (block) {
                    true -> R.string.blocking_block_title
                    false -> R.string.blocking_unblock_title
                }
            )
            .setMessage(message)
            .setPositiveButton(R.string.button_continue) { _, _ ->
                if (block) {
                    markBlocked.execute(
                        MarkBlocked.Params(
                            conversationIds,
                            prefs.blockingManager.get(),
                            null
                        )
                    ) {
                        if (activity is MainActivity) {

                        } else {
                            context.appPreference.isRefreshMessages = true
                        }
                    }
                    //     blockingManager.block(addresses).subscribe()
                } else {
                    markUnblocked.execute(conversationIds) {
                        if (activity is MainActivity) {

                        } else {
                            context.appPreference.isRefreshMessages = true
                        }
                    }
                    //     blockingManager.unblock(addresses).subscribe()
                }
            }
            .setNegativeButton(R.string.button_cancel) { _, _ -> }
            .create()
            .show()
    }

}
