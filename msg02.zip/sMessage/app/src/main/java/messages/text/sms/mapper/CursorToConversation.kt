package messages.text.sms.mapper

import android.database.Cursor
import messages.text.sms.model.Conversation

interface CursorToConversation : Mapper<Cursor, Conversation> {

    fun getConversationsCursor(limit: Boolean = false): Cursor?

}