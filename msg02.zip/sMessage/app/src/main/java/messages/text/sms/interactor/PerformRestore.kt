package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.repository.BackupRepository
import javax.inject.Inject

class PerformRestore @Inject constructor(
    private val backupRepo: BackupRepository,
) : Interactor<String>() {

    override fun buildObservable(params: String): Flowable<*> {
        return Flowable.just(params)
            .doOnNext(backupRepo::performRestore)
    }

}
