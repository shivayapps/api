package messages.text.sms.commons.adapters

import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.util.Preferences

class CustomImageAdapter(
    private val prefs: Preferences,
    private val itemList: List<Bitmap>,
    private val context: Context,
    private val onItemClickListener: OnItemClickListener,
) : RecyclerView.Adapter<CustomImageAdapter.MyViewHolder>() {

//    private var selectedItemPosition: Int = RecyclerView.NO_POSITION

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_custom_theme_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        if (position == 0) {

            Glide.with(context).load(context.resources.getDrawable(R.drawable.pick_theme))
                .into(holder.llcolor)
        } else {
            context.updateTextColors(holder.main)
            if (position == prefs.selectedThemeNo.get() - 1) {

                holder.ivMain.visibility = View.VISIBLE
                holder.ivMainO.visibility = View.VISIBLE
                holder.ivMain.setColorFilter(context.baseConfig.primaryColor)

            } else {

                holder.ivMain.visibility = View.GONE
                holder.ivMainO.visibility = View.GONE
            }
            Glide.with(context).load(itemList[position]).into(holder.llcolor)
            holder.itemView.setOnClickListener {
                onItemClickListener.onItemClick(position, 0, itemList[position].toString())
                //   notifyDataSetChanged()
            }
        }


    }

    override fun getItemCount(): Int = itemList.size + 1

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivMain: ImageView = itemView.findViewById(R.id.ivMain)
        val ivMainO: ImageView = itemView.findViewById(R.id.ivMainO)
        val main: ConstraintLayout = itemView.findViewById(R.id.main)
        val llcolor: ImageView = itemView.findViewById(R.id.llColor)
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int, color: Int, name: String)
    }
}
