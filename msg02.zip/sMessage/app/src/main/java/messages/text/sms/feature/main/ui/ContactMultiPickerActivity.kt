package messages.text.sms.feature.main.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.resolveThemeBoolean
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.feature.main.FetchContactTask
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.PICKED_CONTACT
import messages.text.sms.util.StringManager
import org.greenrobot.eventbus.EventBus
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class ContactMultiPickerActivity : MainBaseThemedActivity() {

    private val executor: ExecutorService = Executors.newFixedThreadPool(1)
    private val contactsData: ArrayList<Contact> = ArrayList()
    private val adapter: ContactMultiPickerAdapter = ContactMultiPickerAdapter(contactsData)

    private var mRecyclerView: RecyclerView? = null
    private var mSwipeRefreshLayout: SwipeRefreshLayout? = null
    private var mCloseButton: ImageView? = null
    private var mFilterEditText: EditText? = null
    private lateinit var btnDone: ImageView

    companion object {

        const val EXTRA_CONTACT_DATA = "EXTRA_CONTACT_DATA"
        const val RC_CONTACT_PICKER = 12
        const val PERMISSION_REQUEST_CODE = 13
    }

    private var mScreenfrom = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // We can only set light nav bar on API 27 in attrs, but we can do it in API 26 here
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) {
            val night = !resolveThemeBoolean(R.attr.isLightTheme)
            window.decorView.systemUiVisibility = if (night) 0 else
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        // Some devices don't let you modify android.R.attr.navigationBarColor
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.navigationBarColor = resolveThemeColor(android.R.attr.windowBackground)
        }


        window.statusBarColor = baseConfig.statusBarColor
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
        }
        setContentView(R.layout.layout_picker_activity)
        mScreenfrom = intent.getStringExtra("from").toString()

        setupViews()
        requestPermission()
        setUpTheme()
    }

    private fun setUpTheme() {

//        updateTextColors(binding.main)


        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

                if (baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(this)
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    findViewById<CoordinatorLayout>(R.id.main).background = drawable
//                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))

                } else {
                    val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                    findViewById<CoordinatorLayout>(R.id.main).background = drawable
//                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                }

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                findViewById<CoordinatorLayout>(R.id.main).background = drawable
//                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
//                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(baseConfig.backgroundColor)
            }


        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                findViewById<CoordinatorLayout>(R.id.main).background =
                    ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            } else {
                findViewById<CoordinatorLayout>(R.id.main).background =
                    ColorDrawable(baseConfig.backgroundColor)
            }
        }
    }

//    private fun fetchContacts() {
//
//        mSwipeRefreshLayout?.isRefreshing = true
//        executor.execute(FetchContactTask(this) { data ->
//            contactsData.clear()
//            data.forEach {
//                contactsData.add(it)
//            }
//            mSwipeRefreshLayout?.isRefreshing = false
//            adapter.notifyDataSetChanged()
//        })
//    }


    /* private fun fetchContacts() {
         mSwipeRefreshLayout?.isRefreshing = true
         executor.execute(FetchContactTask(this) { data ->
             val blockedPhones = baseConfig.blockContactsList.mapNotNull { it.phone }.toSet()

             val filteredSortedContacts = data.filter { contact ->
                 val phone = contact.phone
                 phone == null || !blockedPhones.contains(phone)

             }.sortedBy { it.name }

             runOnUiThread {
                 contactsData.clear()
                 contactsData.addAll(filteredSortedContacts)
                 adapter.setData(contactsData) // Update adapter properly
                 mSwipeRefreshLayout?.isRefreshing = false
             }
         })
     }*/

    private fun fetchContacts() {
        mSwipeRefreshLayout?.isRefreshing = true
        executor.execute(FetchContactTask(this) { data ->
            val blockedPhones = baseConfig.blockContactsList.mapNotNull { it.phone }.toSet()

            /* val filteredSortedContacts = data.filter { contact ->
                 val phone = contact.phone
                 !phone.isNullOrBlank() && !blockedPhones.contains(phone)
             }.sortedBy { it.name }*/

            val filteredSortedContacts = data
                .filter { contact ->
                    val phone = contact.phone
                    !phone.isNullOrBlank() && !blockedPhones.contains(phone)
                }
                .sortedWith(compareBy<Contact> { contact ->
                    // Give alphabetic names priority (true = digits, false = letters)
                    contact.name?.firstOrNull()?.isDigit() ?: true
                }.thenBy { contact ->
                    contact.name?.lowercase() ?: ""
                })


            runOnUiThread {
                contactsData.clear()
                contactsData.addAll(filteredSortedContacts)
                adapter.setData(contactsData) // Update adapter properly
                mSwipeRefreshLayout?.isRefreshing = false
            }
        })
    }


    private var filterRunnable: Runnable? = null


    private fun setupViews() {
        mRecyclerView = findViewById(R.id.rv_contacts)
        mSwipeRefreshLayout = findViewById(R.id.swipe_layout_contact_picker)
        mCloseButton = findViewById(R.id.btn_close_picker)
        mFilterEditText = findViewById(R.id.edt_filter_)
        btnDone = findViewById(R.id.ivDone)

        btnDone.setTint(baseConfig.primaryColor)

        mRecyclerView?.layoutManager = LinearLayoutManager(this)
        mRecyclerView?.adapter = adapter

        btnDone.visibility = View.VISIBLE

        btnDone.setOnClickListener {
            val selectedContacts = adapter.getSelectedContacts()
            val savedData = baseConfig.blockContactsList.toMutableList()

            val existingPhones = savedData.mapNotNull { it.phone }.toSet()

            selectedContacts.forEach { contact ->
                val phone = contact.phone
                if (phone == null || !existingPhones.contains(phone)) {
                    savedData.add(contact)
                }
            }

            baseConfig.blockContactsList = savedData as ArrayList<Contact>

            EventBus.getDefault().post(MessageEvent(PICKED_CONTACT, selectedContacts))
            finish()
        }


        mSwipeRefreshLayout?.setOnRefreshListener { fetchContacts() }
        mCloseButton?.setOnClickListener { finish() }

        /* mFilterEditText?.addTextChangedListener(object : TextWatcher {
             override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                 adapter.filter.filter(s)
             }

             override fun afterTextChanged(s: Editable?) {}
             override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
         })*/


        mFilterEditText?.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterRunnable?.let { mFilterEditText?.removeCallbacks(it) }

                filterRunnable = Runnable {
                    adapter.filterContacts(s.toString())
                }

                mFilterEditText?.postDelayed(filterRunnable, 200)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}
        })

    }

    private fun requestPermission() {

        val state = ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
        if (state == PackageManager.PERMISSION_GRANTED) {

            fetchContacts()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CONTACTS),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.isNotEmpty()) {

            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchContacts()
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        executor.shutdownNow()
    }
}