package messages.text.sms.feature.main

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Resources
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.appopen.AppOpenAd
import com.klinker.android.send_message.Utils.isDefaultSmsApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.ads.AdsPreferences
import messages.text.sms.ads.GoogleMobileAdsConsentManager
import messages.text.sms.ads.app_open_from_notification
import messages.text.sms.ads.app_splash_created
import messages.text.sms.ads.app_splash_open_ad_click
import messages.text.sms.ads.app_splash_open_ad_failed
import messages.text.sms.ads.app_splash_open_ad_show
import messages.text.sms.ads.delayExecution
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.ads.getAppOpenSplash
import messages.text.sms.ads.isFirstTimeAppOpen
import messages.text.sms.ads.isInternetConnected
import messages.text.sms.common.MysmsApplication
import messages.text.sms.common.MysmsApplication.Companion.isAdsNotShowOnResume
import messages.text.sms.common.MysmsApplication.Companion.qkApplicationContext
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.config
import messages.text.sms.databinding.ActivitySplashBinding
import messages.text.sms.manager.PermissionManagerImpl
import messages.text.sms.util.fetchJSONArrayIfNeeded
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean


class SplashActivity : AppCompatActivity() {

    private val isMobileAdsInitializeCalled = AtomicBoolean(false)
    private lateinit var googleMobileAdsConsentManager: GoogleMobileAdsConsentManager

    private lateinit var binding: ActivitySplashBinding


    fun incrementSplashCounter(context: Context) {
        val prefs = AdsPreferences(context)
        val currentTime = System.currentTimeMillis()

        if (currentTime - prefs.lastSplashTime >= 3_000) {
            prefs.splashCounter++
            prefs.lastSplashTime = currentTime
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Setup binding
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        AdsPreferences(this).splashCounter++
        incrementSplashCounter(this)
        Log.e("Splash", "splashCounter - ${AdsPreferences(this).splashCounter}")
        Log.e("AdsId", "splashCounter - ${AdsPreferences(this).splashCounter}")


        // Set default language if none selected
        if (config.selectedLanguagePos == 0) {
            config.selectedLanguage =
                Resources.getSystem().configuration.locales.get(0).language
        }

        firebaseAnalyticsHandler.logMessages(
            app_splash_created, getActivityName()
        )

        // Async config fetch (don’t block UI)
        lifecycleScope.launch(Dispatchers.IO) {
            fetchJSONArrayIfNeeded()
        }

        checkAndResetSnackBarFlag()


        Log.e("Message_Log", "animationScan1 - ")

//        binding.root.beVisible()
        binding.animationScan1.beVisible()
        binding.sTitle.beVisible()
//        binding.progressBar.beVisible()
//        binding.clPrivacyPolicy.beVisible()

//        // Play animation, then go to MainActivity
//        binding.animationScan1.addAnimatorListener(object : AnimatorListenerAdapter() {
//            override fun onAnimationEnd(animation: Animator) {
//                super.onAnimationEnd(animation)
//            }
//        })

        if (isFirstTimeAppOpen()) {
            handleFirstTimeFlow()
        } else {
            handleReturningFlow()
        }

        // Daily log in background (doesn’t block splash)
        lifecycleScope.launch(Dispatchers.IO) {
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                .logOnceDailyWithInterval { logged, daysInterval ->
                    Log.e("DailyLog", "logged:$logged, daysInterval:$daysInterval")
                    if (logged) {
                        val event = if (daysInterval > 45) {
                            "DAILY_OPEN_INTERVAL_45+"
                        } else {
                            "DAILY_OPEN_INTERVAL_$daysInterval"
                        }
                        firebaseAnalyticsHandler.logMessages(event, getActivityName())
                    }
                }
        }

        checkLanguage()


    }

    fun SharedPreferences.logOnceDailyWithInterval(callback: (logged: Boolean, daysInterval: Int) -> Unit) {
        val lastLoggedTime = getLong("last_logged_time", 0L)
        val currentTime = System.currentTimeMillis()
        val oneDayInMillis = 24 * 60 * 60 * 1000
        val daysInterval = ((currentTime - lastLoggedTime) / oneDayInMillis).toInt()

        val loggedToday = daysInterval == 0

        if (!loggedToday) {
            edit().putLong("last_logged_time", currentTime).apply()
        }

        callback(!loggedToday, daysInterval)
    }

    fun checkAndResetSnackBarFlag() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val lastClosedDate = config.snackBarClosedDate  // e.g., "2025-05-08"

        if (lastClosedDate != today) {
            config.snackBarClosedDate = today
        }

        if (!isDefaultSmsApp(this)) {
            config.snackBarClosedDate = today
        }
    }


    fun checkLanguage() {

        val languages = resources.getStringArray(R.array.language_code)
        val defaultLanguage: String = Resources.getSystem().configuration.locale.language
        var position = languages.indexOf(defaultLanguage)

        if (position == -1) {
            position = 0
        }
        val defaultList = resources.getStringArray(R.array.default_list)
        val systemDefaultList = resources.getStringArray(R.array.system_default_list)
        baseConfig.selectedLanguage_default_name1 = defaultList[position] + ""
        baseConfig.selectedLanguage_default_name2 = "(${systemDefaultList[position]})"
    }

    private fun handleFirstTimeFlow() {
        if (isInternetConnected()) {
            lifecycleScope.launch(Dispatchers.IO) {
                googleMobileAdsConsentManager =
                    GoogleMobileAdsConsentManager.getInstance(this@SplashActivity)

                googleMobileAdsConsentManager.gatherConsent(this@SplashActivity) { consentError ->
                    consentError?.let {
                        Log.w("Consent", "${it.errorCode}: ${it.message}")
                    }



                    if (googleMobileAdsConsentManager.canRequestAds) {

                        MobileAds.initialize(qkApplicationContext?.applicationContext!!) {

                            initializeMobileAdsSdk()
                        }
                    } else {
                        launchAds()
                    }

                    if (googleMobileAdsConsentManager.isPrivacyOptionsRequired) {
                        invalidateOptionsMenu()
                    }
                }
            }
        } else {
            runOnUiThread {
                if (baseConfig.callUMP) {
                    launchAds()
                } else {
                    initializeMobileAdsSdk()
                }
            }
        }
    }

    private fun handleReturningFlow() {
        val context = qkApplicationContext?.applicationContext

        if (context == null) {
            // Context unavailable — continue flow without initializing MobileAds
            if (baseConfig.callUMP) {
                launchAds()
            } else {
                initializeMobileAdsSdk()
            }
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(context) {
                runOnUiThread {
                    if (baseConfig.callUMP) {
                        launchAds()
                    } else {
                        initializeMobileAdsSdk()
                    }
                }
            }
        }
    }


    private fun initializeMobileAdsSdk() {


        Log.e("Message_Log", "initializeMobileAdsSdk -  ??????")
        if (isMobileAdsInitializeCalled.getAndSet(true)) {
            launchAds()
            return
        }

        MobileAds.setRequestConfiguration(
            RequestConfiguration.Builder().build()
        )

        lifecycleScope.launch(Dispatchers.IO) {


            if (!isFirstTimeAppOpen()) {
                (application as MysmsApplication).initializeCallerCard()
            }
            withContext(Dispatchers.Main) {
                launchAds()
            }
        }
    }


    private fun launchHomeScreen() {
        baseConfig.callUMP = true
        val actionType = intent.getStringExtra("ACTION_TYPE") ?: ""
        val selectedLanguage = config.selectedLanguage.ifEmpty { "" }

        baseConfig.checkpage = 0

        if (actionType.isNotEmpty()) {
            firebaseAnalyticsHandler.logMessages(app_open_from_notification, getActivityName())
        }

        when {
            isFirstTimeAppOpen() -> {
                val targetIntent = if (!PermissionManagerImpl(this).isDefaultSms() ||
                    !PermissionManagerImpl(this).hasReadSms() ||
                    !PermissionManagerImpl(this).hasContacts()
                ) {
                    Intent(this, PermissionActivity::class.java).putExtra("noLang", true)
                } else if (selectedLanguage.isNotEmpty() && config.clickLangDone) {
                    Intent(this, MainActivity::class.java).putExtra("ACTION_TYPE", actionType)
                } else {
                    Intent(this, PermissionActivity::class.java).putExtra("noLang", true)
                }

                startActivity(targetIntent)
                finish()
            }

            selectedLanguage.isNotEmpty() && config.clickLangDone -> {
                // Show UI while animation plays
                /*  binding.root.beVisible()
                  binding.imageViewMain.beVisible()
                  binding.progressBar.beVisible()
                  binding.clPrivacyPolicy.beVisible()

                  // Play animation, then go to MainActivity
                  binding.animationScan1.addAnimatorListener(object : AnimatorListenerAdapter() {
                      override fun onAnimationEnd(animation: Animator) {
                          super.onAnimationEnd(animation)

                          val targetIntent = Intent(this@SplashActivity, MainActivity::class.java)
                              .putExtra("ACTION_TYPE", actionType)

                          startActivity(targetIntent)
                          finish()
                      }
                  })*/
                val targetIntent = Intent(this@SplashActivity, MainActivity::class.java)
                    .putExtra("ACTION_TYPE", actionType)

                startActivity(targetIntent)
                finish()
            }

            else -> {
                Log.e("Message_Log", "start -> PermissionActivity")
                val targetIntent =
                    Intent(this, PermissionActivity::class.java).putExtra("noLang", true)
                startActivity(targetIntent)
                finish()
            }
        }

    }

    override fun onBackPressed() {
        return
    }

    private fun launchAds() {
        if (getAppOpenSplash().isEmpty()) {
            delayExecution(2000) {
                if (isFirstTimeAppOpen()
                    && clientConfigPref.showAppOpenAdInSplash
                    && getAppOpenSplash().isNotEmpty()
                ) {
                    loadAndShowAppOpen {
                        launchHomeScreen()
                    }
                } else {
                    launchHomeScreen()
                }
            }
        } else {
            delayExecution(200) {
                if (isFirstTimeAppOpen()
                    && clientConfigPref.showAppOpenAdInSplash
                    && getAppOpenSplash().isNotEmpty()) {
                    loadAndShowAppOpen {
                        launchHomeScreen()
                    }
                } else {
                    launchHomeScreen()
                }
            }
        }

    }

    private fun loadAndShowAppOpen(callback: () -> Unit) {
        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            this,
            getAppOpenSplash(),
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {

                override fun onAdLoaded(appOpenAd: AppOpenAd) {

                    Log.e("Message_Log", "App Open onAdLoaded.")
                    appOpenAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                        /** Called when full screen content is dismissed. */
                        override fun onAdDismissedFullScreenContent() {
                            callback.invoke()
                        }

                        /** Called when fullscreen content failed to show. */
                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {

                            firebaseAnalyticsHandler.logMessages(
                                app_splash_open_ad_failed, getActivityName()
                            )
                            callback.invoke()

                        }

                        /** Called when fullscreen content is shown. */
                        override fun onAdShowedFullScreenContent() {
                            Log.e("Message_Log", "onAdShowedFullScreenContent.")

                            firebaseAnalyticsHandler.logMessages(
                                app_splash_open_ad_show, getActivityName()
                            )
                        }

                        override fun onAdClicked() {
                            super.onAdClicked()
                            isAdsNotShowOnResume = true
                            firebaseAnalyticsHandler.logMessages(
                                app_splash_open_ad_click, getActivityName()
                            )
                        }
                    }
                    appOpenAd.show(this@SplashActivity)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.e("Message_Log", "onAdFailedToLoad. ${loadAdError.message}")
                    callback.invoke()

                }
            },
        )
    }

}
