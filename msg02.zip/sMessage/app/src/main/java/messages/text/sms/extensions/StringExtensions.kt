package messages.text.sms.extensions

import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import java.text.Normalizer

/**
 * Strip the accents from a string
 */
fun CharSequence.removeAccents(): String =
    Normalizer.normalize(this, Normalizer.Form.NFKD).replace(Regex("\\p{M}"), "")

fun Drawable.applyColorFilter(color: Int) = mutate().setColorFilter(color, PorterDuff.Mode.SRC_IN)
