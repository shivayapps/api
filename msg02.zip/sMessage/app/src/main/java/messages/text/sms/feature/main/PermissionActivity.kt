package messages.text.sms.feature.main

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Activity
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.PopupWindow
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieDrawable
import com.gallery.mvvm.ads.GoogleNativeAdHelper
import com.google.android.gms.ads.MobileAds
import dagger.android.AndroidInjection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.ads.AdmobInterstitialHelper
import messages.text.sms.ads.AdsPreferences
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.ads.app_ad_language_native_failed
import messages.text.sms.ads.app_ad_language_native_show
import messages.text.sms.ads.app_change_language_created
import messages.text.sms.ads.app_default_Screen_enter_for_default
import messages.text.sms.ads.app_default_Screen_enter_from_splash
import messages.text.sms.ads.app_default_sms_permissions
import messages.text.sms.ads.app_language_created
import messages.text.sms.ads.app_language_open
import messages.text.sms.ads.app_permission_created
import messages.text.sms.ads.app_reject_default_sms_permissions
import messages.text.sms.ads.delayExecution
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.ads.getAppLanguageNative
import messages.text.sms.ads.isFirstTimeAppOpen
import messages.text.sms.common.MysmsApplication.Companion.qkApplicationContext
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.dialog.PermissionRequiredDialog
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beInvisible
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.getPermissionString
import messages.text.sms.commons.extensions.hasPermission
import messages.text.sms.commons.extensions.isPackageInstalled
import messages.text.sms.commons.extensions.isVisible
import messages.text.sms.commons.helpers.PERMISSION_POST_NOTIFICATIONS
import messages.text.sms.commons.helpers.PERMISSION_READ_CONTACTS
import messages.text.sms.commons.helpers.PERMISSION_READ_SMS
import messages.text.sms.commons.helpers.PERMISSION_SEND_SMS
import messages.text.sms.commons.helpers.isOreoPlus
import messages.text.sms.commons.helpers.isQPlus
import messages.text.sms.commons.helpers.isTiramisuPlus
import messages.text.sms.databinding.ActivityPermissionBinding
import messages.text.sms.databinding.LanguageItemBinding
import messages.text.sms.databinding.PopupSetDefaultSmsBinding
import messages.text.sms.extensions.startZoomAnimation
import java.util.Locale


class PermissionActivity : MainBaseThemedActivity() {

    private val binding by viewBinding(ActivityPermissionBinding::inflate)
    var selectedLanguage = Locale.getDefault().language
    var selectedLanguageTempPos = 0
    private var isFromSplash = false
    private var isLanguageAdShow = false
    private var firstTimeInterDelay = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)

        setContentView(binding.root)

        selectedLanguage = config.selectedLanguage.ifEmpty { "" }
        selectedLanguageTempPos = config.selectedLanguagePos

//        if (intent.hasExtra("reset") || intent.hasExtra("noLang")) {
        if (intent.hasExtra("reset")) {
            isFromSplash = false
            binding.mainPermission.beGone()
            binding.mainNewPermission.beGone()
            binding.topLanguage.beVisible()
            setUpLanguages()

            firebaseAnalyticsHandler.logMessages(
                app_change_language_created, getActivityName()
            )

        } else if (intent.hasExtra("noLang")) {
            Log.e("noLang", "onCreate:noLang 1 ")
            isFromSplash = true
            openSplashLoading()
            /* if (AdsPreferences(this).splashCounter > 1) {
                 binding.mainPermission.beGone()
                 binding.topLanguage.beVisible()
                 setUpLanguages()
             } else {
                 isFromSplash = true
                 binding.mainPermission.beVisible()
                 binding.topLanguage.beGone()
             }*/
            firebaseAnalyticsHandler.logMessages(
                app_language_created, getActivityName()
            )
        } else if (intent.hasExtra("DefaultSms")) {

            if (clientConfigPref.defaultNewScreen) {
                binding.mainPermission.beGone()
                binding.mainNewPermission.beVisible()
            } else {
                binding.mainPermission.beVisible()
                binding.mainNewPermission.beGone()
            }

            binding.topLanguage.beGone()
            // Toast.makeText(this, "loaded request--2", Toast.LENGTH_SHORT).show()

            CoroutineScope(Dispatchers.IO).launch {
                // Initialize the Google Mobile Ads SDK on a background thread.
                MobileAds.initialize(qkApplicationContext?.applicationContext!!) {
                    firstTimeInterDelay = clientConfigPref.firstTimeInterDelay
                    delayExecution(firstTimeInterDelay.toLong()) {
                        lifecycleScope.launch {
                            val appContext = qkApplicationContext?.applicationContext
                            if (appContext != null) {
                                Log.e("loadGeneralInter--------------", "  -------------- 1")
                                MainInterAdManager.loadGeneralInter(appContext, 1)
                            }
                        }
                    }
                }

            }
            firebaseAnalyticsHandler.logMessages(
                app_permission_created, getActivityName()
            )
        }



        binding.btnStart.setOnClickListener {
            loadMessages()
        }
        binding.btnStartNew.setOnClickListener {
            loadMessages()
        }
        binding.animationScan1.setOnClickListener {
            loadMessages()
        }
        binding.havingTrouble.setOnClickListener {
            showSetDefaultPopup(binding.root)
        }


        binding.tvTermsPrivacy.paintFlags =
            binding.tvTermsPrivacy.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        binding.tvUserAgreement.paintFlags =
            binding.tvUserAgreement.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        binding.tvTermsPrivacyNew.paintFlags =
            binding.tvTermsPrivacyNew.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        binding.tvUserAgreementNew.paintFlags =
            binding.tvUserAgreementNew.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        binding.tvUserAgreement.setOnClickListener {

            val url: String =
                resources?.getString(R.string.user_agreement_url)
                    .toString()
            privacyUrlRedirect(url)
        }
        binding.tvTermsPrivacy.setOnClickListener {

            val url: String =
                resources?.getString(R.string.privacy_policy_url)
                    .toString()
            privacyUrlRedirect(url)
        }

        binding.tvUserAgreementNew.setOnClickListener {

            val url: String =
                resources?.getString(R.string.user_agreement_url)
                    .toString()
            privacyUrlRedirect(url)
        }
        binding.tvTermsPrivacyNew.setOnClickListener {

            val url: String =
                resources?.getString(R.string.privacy_policy_url)
                    .toString()
            privacyUrlRedirect(url)
        }
//        delayExecution(1000, {
//            handleNotificationPermission { granted ->
//            }
//        })

        if (isFirstTimeAppOpen()) {
            if (intent.hasExtra("reset")) {
                firebaseAnalyticsHandler.logMessages(
                    app_default_Screen_enter_for_default, getActivityName()
                )
            } else {
                firebaseAnalyticsHandler.logMessages(
                    app_default_Screen_enter_from_splash, getActivityName()
                )
            }
        }

        binding.ivDone.setTint(baseConfig.primaryColor)

        lifecycleScope.launch {
            delay(1000) // 1 second delay
            if (clientConfigPref.defaultNewScreen) {
                startZoomAnimation(binding.btnStartNew)
            } else {
                startZoomAnimation(binding.btnStart)
            }
        }

    }

    private fun openSplashLoading() {
//        binding.inSplash.root.beVisible()
//        binding.inSplash.imageViewMain.beVisible()
//        binding.inSplash.progressBar.beVisible()
//        binding.inSplash.clPrivacyPolicy.beVisible()
        binding.mainPermission.beGone()
        binding.mainNewPermission.beGone()
        binding.topLanguage.beVisible()
        setUpLanguages()
//        if (isFirstTimeAppOpen() && isConnectedInternet()) {
//            //    fetchJSONArrayFromRemoteConfig()
//            fetchJSONArrayIfNeeded()
//        }
//        delayExecution(6000) {
//            binding.inSplash.root.beGone()
//            Log.e("noLang", "onCreate:noLang Gone ")
//
//        }
    }

    private fun setUpLanguages() {



        if (intent.hasExtra("reset")) {
            isFromSplash = false
            binding.ivBack.beVisible()
            binding.ivDone.beVisible()
            binding.ivBack.setOnClickListener {
                onBackPressed()
            }
        }

        if (isFromSplash) {
            isFromSplash = false
            binding.ivBack.visibility = View.GONE
        } else {
            binding.ivBack.visibility = View.VISIBLE
        }

        val languages = resources.getStringArray(R.array.language_text)
        val languageSecond = resources.getStringArray(R.array.language_text_second)
        val languageCodes = resources.getStringArray(R.array.language_code)
        val languageFirstLatter = resources.getStringArray(R.array.language_first_latter)
        val languageColor = resources.getStringArray(R.array.language_color)


        val languageColors: List<Int> = languageColor.map { Color.parseColor(it) }

//        val spanCount = if (clientConfigPref.languageAdType == "small") 1 else 2

        binding.rvLanguage.layoutManager = GridLayoutManager(this, 1)
        binding.rvLanguage.adapter = MyAdapter(
            this,
            languages.toList(),
            languageSecond.toList(),
            languageFirstLatter.toList(),
            languageColors.toList(),
            languageCodes.toList()
        )
        binding.ivDone.setOnClickListener {
            // selectedLanguage = appPref.selectedLanguage


            config.clickLangDone = true

            if (selectedLanguage.isEmpty()) {
                Toast.makeText(this, getString(R.string.please_select_language), Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }
            if (config.selectedLanguage.isEmpty() || !intent.hasExtra("reset")) {
                config.selectedLanguagePos = selectedLanguageTempPos
                config.selectedLanguage = selectedLanguage
                config.selectedLanguageName = languages[selectedLanguageTempPos]
                setLocale(selectedLanguage)


                if (clientConfigPref.enableLanguageInterstitial) {
                    AdmobInterstitialHelper.loadAndShowInterstitial(
                        activity = this,
                        adUnitId = clientConfigPref.languageInterstitialAdId,
                        onAdDismissed = {
                            openPermission()
                        },
                        onAdFailed = {
                            openPermission()
                        }
                    )
                } else {
                    /*  if (MainInterAdManager.langInterLoaded()) {
                          isLanguageAdShow = true
                      }
                      MainInterAdManager.showGeneralInterAds(this, true) {
                          openPermission()
                      }*/
                    openPermission()
                }


            } else {
                moveNext(languages)
            }
        }

        if (AdsPreferences(this).adsEnable) {
            binding.adView.beVisible()
            //   binding.determinateBar.visibility = View.VISIBLE
            lifecycleScope.launch {
                showLoader()
                loadNativeAndInterstitialAds(isFromSplash)
            }
        } else {
            binding.adView.beGone()
        }

        firebaseAnalyticsHandler.logMessages(
            app_language_open, getActivityName()
        )
    }

    private fun openPermission() {

        if (clientConfigPref.defaultNewScreen) {

            binding.tvText1New.text =
                getString(R.string.set_message_as_your_default_to_n_work_properly)
            binding.tvText2New.text = getString(R.string.private_conversations)
            binding.tvText3New.text = getString(R.string.exclusive_themes)
            binding.tvText4New.text = getString(R.string.spam_blocking)
            binding.btnStartNew.text = getString(R.string.start_using_messages_onboarding)

            binding.havingTrouble.text = getString(R.string.having_trouble)
            binding.mainPermission.beGone()
            binding.mainNewPermission.beVisible()

        } else {

            binding.tvText1.text =
                getString(R.string.set_message_as_your_default_to_n_work_properly)
            binding.tvText2.text = getString(R.string.private_conversations)
            binding.tvText3.text = getString(R.string.exclusive_themes)
            binding.tvText4.text = getString(R.string.spam_blocking)
            binding.tvText5.text = getString(R.string.schedule_message)
            binding.btnStart.text = getString(R.string.start_using_messages_onboarding)
            binding.tvUserAgreement.text = getString(R.string.user_agreement)
            binding.tvTermsPrivacy.text = getString(R.string.privacy_policy)
            binding.mainPermission.beVisible()
            binding.mainNewPermission.beGone()
        }

        binding.topLanguage.beGone()
        if (!isLanguageAdShow) {
            // Toast.makeText(this, "loaded request--1", Toast.LENGTH_SHORT).show()


            if (clientConfigPref.showFirstTimeInterAd) {
                CoroutineScope(Dispatchers.IO).launch {
                    // Initialize the Google Mobile Ads SDK on a background thread.
                    MobileAds.initialize(qkApplicationContext?.applicationContext!!) {
                        firstTimeInterDelay = clientConfigPref.firstTimeInterDelay
                        delayExecution(firstTimeInterDelay.toLong()) {
                            lifecycleScope.launch {
                                val appContext = qkApplicationContext?.applicationContext
                                if (appContext != null) {
                                    Log.e("loadGeneralInter--------------", "  -------------- 2")
                                    MainInterAdManager.loadGeneralInter(appContext)
                                }
                            }
                        }
                    }
                }
            }

        }

        binding.animationScan1.setAnimation(R.raw.anim_default)
        binding.animationScan1.repeatCount = LottieDrawable.INFINITE
        binding.animationScan1.playAnimation()
    }

    /* private fun moveNext(languageCodes: Array<String>, languages: Array<String>) {
         config.selectedLanguage = selectedLanguage
         val lastIndex = languageCodes.indexOf(selectedLanguage)
         if (lastIndex == -1) {
             config.selectedLanguageName = "English"

         } else {
             config.selectedLanguageName = languages[lastIndex]

         }
         setLocale(selectedLanguage)

         openNextScreen()

     }*/

    private fun moveNext(languages: Array<String>) {
        CoroutineScope(Dispatchers.IO).launch {
            config.selectedLanguagePos = selectedLanguageTempPos
            config.selectedLanguage = selectedLanguage
            config.selectedLanguageName = languages[selectedLanguageTempPos]

            // Suspend until setLocale completes
            withContext(Dispatchers.IO) {
                setLocale(selectedLanguage)
            }

            // Switch back to the main thread to update UI
            withContext(Dispatchers.Main) {
                openNextScreen()
            }
        }
    }

    private fun openNextScreen() {
        if (intent.hasExtra("reset")) {
            binding.progressBar.visibility = View.VISIBLE
            delayExecution(1000) {

                binding.progressBar.visibility = View.GONE
                startActivity(
                    Intent(this, SplashActivity::class.java).setAction("fromLanguage").apply {
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                finishAffinity()
            }
        } else {
            startActivity(Intent(this, MainActivity::class.java).setAction(intent.action))
            finish()
        }
    }

    private fun showLoader() {
        if (isFromSplash) {
            binding.ivBack.visibility = View.GONE
            binding.ivDone.visibility = View.VISIBLE
            binding.ivWait.visibility = View.GONE
//            simulateSuccessProgress(binding.ivWait)
//            Toast.makeText(
//                this, getString(R.string.setting_up_language), Toast.LENGTH_SHORT
//            ).show()

        } else {
            binding.ivDone.visibility = View.VISIBLE
            binding.ivWait.visibility = View.GONE
            doChange()
        }
    }

    /*   private fun simulateSuccessProgress(button: CircularProgressButton) {
           val widthAnimation = ValueAnimator.ofInt(1, 100)
           widthAnimation.setDuration(7000)
           widthAnimation.interpolator = AccelerateDecelerateInterpolator()
           widthAnimation.addUpdateListener { animation ->
               val value = animation.animatedValue as Int
               button.setProgress(value)
           }
           widthAnimation.start()
       }*/

    private fun doChange() {
        //  binding.determinateBar.visibility = View.INVISIBLE
//        binding.ivDone.visibility = View.VISIBLE
//        binding.ivWait.visibility = View.GONE
        setLocale(selectedLanguage)
        updateLan(selectedLanguage)
//        binding.ivDone.text = getString(R.string.next)
//        binding.ivWait.text = getString(R.string.please_wait)
    }

    private fun doChangeLang(position: Int) {


        try {
            if (position == 0) {
                //            setLocale(data)
                //            updateLan(data)
                doChange()

            } else {
                val selectLanguage = resources.getStringArray(R.array.select_language)

                //            binding.ivDone.text = nextText[position]
                //        binding.ivWait.text = getString(R.string.please_wait)
                binding.tvTitle.text = selectLanguage[position]
            }
        } catch (_: Exception) {

        }


    }


    private fun updateLan(date: String) {
        val locale = Locale(date)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)
        binding.tvTitle.text = resources.getString(R.string.select_language)
//        binding.ivDone.text = resources.getString(R.string.next)
    }

    class MyAdapter(
        val activity: PermissionActivity,
        private val languages: List<String>,
        private val languageSecond: List<String>,
        private val languageFirstLatter: List<String>,
        private val languageColor: List<Int>,
        private val languageCodes: List<String>,
    ) : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            val binding =
                LanguageItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return MyViewHolder(binding)
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            with(holder) {
                with(binding) {
                    // Pick a random color
                    val drawables = ContextCompat.getDrawable(
                        activity,
                        R.drawable.rounded_shape_color1
                    ) as? GradientDrawable
                    drawables?.setColor(languageColor[position])
                    startText.background = drawables
                    startText.text = languageFirstLatter[position]


                    val primaryText = if (position == 0) {
                        // activity.getString(R.string.default_txt)
                        // activity.baseConfig.selectedLanguage_default_name1
                        "Default"

                    } else {
                        languages[position]
                    }
                    val currentLanguageCode = activity.resources.configuration.locales[0].language
                    val systemLanguageCode =
                        Locale.getDefault().language // Device's system default language code

                    val secondaryText =
                        if (position == 0 && currentLanguageCode == systemLanguageCode) {
                            //    " (${activity.getString(R.string.system_default)})"
                            activity.baseConfig.selectedLanguage_default_name2 + ""
                        } else {
                            languageSecond[position] + ""
                        }

                    tvLanguage.text = primaryText
                    tvSec.text = secondaryText

                    //    radio.isChecked = activity.selectedLanguage == languageCodes[position]

                    // radio.isChecked = activity.selectedLanguageTempPos == position

                    val drawable = ResourcesCompat.getDrawable(
                        activity.resources,
                        R.drawable.rounded_lang_item_selected,
                        null
                    )

                    if (activity.selectedLanguageTempPos == position) {

                        val d1 = ResourcesCompat.getDrawable(
                            activity.resources,
                            R.drawable.ic_select_qk_msg,
                            null
                        )
                        radio.setImageDrawable(d1)
                        radio.setTint(activity.baseConfig.primaryColor)

                        // Clone the drawable to avoid modifying the same object for both states
                        val selectedDrawable = drawable?.mutate() as GradientDrawable
                        selectedDrawable.setStroke(
                            2,
                            activity.baseConfig.primaryColor
                        )  // Set stroke with primary color
                        llMain.background = selectedDrawable
                    } else {
//                        radio.buttonTintList = ColorStateList.valueOf(Color.GRAY)
                        val d1 = ResourcesCompat.getDrawable(
                            activity.resources,
                            R.drawable.ic_un_select_qk_msg,
                            null
                        )
                        radio.setImageDrawable(d1)
                        radio.setTint(activity.resources.getColor(R.color.gray))

//                        radio.buttonTintList = ColorStateList.valueOf(Color.GRAY)

                        // Clone the drawable for unselected state
                        val unselectedDrawable = drawable?.mutate() as GradientDrawable
                        unselectedDrawable.setStroke(
                            2,
                            activity.getColor(R.color.white)
                        )  // Set stroke with white color
                        llMain.background = unselectedDrawable
                    }

                    radio.setOnClickListener {
                        selectedLanguage(position)
                    }
                    itemView.setOnClickListener {
                        selectedLanguage(position)
                    }
                }
            }
        }

        override fun getItemCount(): Int {
            return languages.size
        }


        private fun selectedLanguage(position: Int) {

            activity.startNextAnimation()

            activity.selectedLanguageTempPos = position
            if (position == 0) {
//                activity.selectedLanguage = Locale.getDefault().language
                activity.selectedLanguage =
                    Resources.getSystem().configuration.locales.get(0).language
            } else {
                activity.selectedLanguage = languageCodes[position]
            }
            Log.e("000000333333", " - " + position + " - " + activity.selectedLanguage)
            activity.doChangeLang(position)
            notifyDataSetChanged()
        }


        inner class MyViewHolder(val binding: LanguageItemBinding) :
            RecyclerView.ViewHolder(binding.root)
    }

    private fun launchHomeScreen() {
        config.saveData("for_first_time", true)
        val loaded = MainInterAdManager.langInterLoaded()
        if (!loaded && !isLanguageAdShow && intent.hasExtra("noLang")) {
            binding.progressBar.beGone()
            delayExecution(1) {
                MainInterAdManager.showGeneralInterAds(this, true) {
                    if (config.selectedLanguage.isNotEmpty() && config.clickLangDone) {
                        openNextScreen()
                    } else {
                        setUpLanguages()
                    }
                }
            }
        } else {
            if (config.selectedLanguage.isNotEmpty() && config.clickLangDone) {
                openNextScreen()
            } else {
                setUpLanguages()
            }
        }
    }

    lateinit var popupWindow: PopupWindow
    /* fun showSetDefaultPopup(anchor: View) {
         val inflater = LayoutInflater.from(anchor.context)
         val popupView = inflater.inflate(R.layout.popup_set_default_sms, null)

           popupWindow = PopupWindow(
             popupView,
             ViewGroup.LayoutParams.MATCH_PARENT,
             ViewGroup.LayoutParams.MATCH_PARENT,
             true
         )

         // Optional: Make popup window background dismissible
 //        popupWindow.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
         popupWindow.isOutsideTouchable = false
 //        popupWindow.elevation = 10f

         // Setup views
         val animationDialog = popupView.findViewById<LottieAnimationView>(R.id.animationDialog)
         val btnStartDialog = popupView.findViewById<AppCompatButton>(R.id.btnStartDialog)

         animationDialog.setAnimation(R.raw.anim_default_dialog)
         animationDialog.repeatCount = LottieDrawable.INFINITE
         animationDialog.playAnimation()
         binding.animationScan1.pauseAnimation()

         binding.btnStartNew.beInvisible()

         btnStartDialog.setOnClickListener {
             loadMessages()
             popupWindow.dismiss()
         }

         animationDialog.setOnClickListener {
             loadMessages()
             popupWindow.dismiss()
         }
         popupWindow.setOnDismissListener {

             binding.animationScan1.playAnimation()
             binding.btnStartNew.beVisible()
 //            startZoomAnimation(binding.animationScan1)

         }
         startZoomAnimation(btnStartDialog)

         // Show the popup centered above anchor
         popupWindow.showAtLocation(anchor, Gravity.CENTER, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
     }*/

    fun showSetDefaultPopup(anchor: View) {
        val inflater = LayoutInflater.from(anchor.context)

        // Inflate with ViewBinding
        val popupBinding = PopupSetDefaultSmsBinding.inflate(inflater)

        popupWindow = PopupWindow(
            popupBinding.root,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            true
        )

        popupWindow.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        popupWindow.isClippingEnabled = false
        popupWindow.isFocusable = true
        popupWindow.isOutsideTouchable = false

        // Setup views using binding
        popupBinding.animationDialog.apply {
            setAnimation(R.raw.anim_default_dialog)
            repeatCount = LottieDrawable.INFINITE
            playAnimation()
        }

        binding.animationScan1.pauseAnimation()
        binding.btnStartNew.beInvisible()

        popupBinding.btnStartDialog.setOnClickListener {
            loadMessages()
            popupWindow.dismiss()
        }

        popupBinding.animationDialog.setOnClickListener {
            loadMessages()
            popupWindow.dismiss()
        }

        popupWindow.setOnDismissListener {
            binding.animationScan1.playAnimation()
            binding.btnStartNew.beVisible()
            // startZoomAnimation(binding.animationScan1)
        }

        startZoomAnimation(popupBinding.btnStartDialog)

        popupWindow.showAtLocation(
            anchor,
            Gravity.CENTER,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }


    private val MAKE_DEFAULT_APP_REQUEST = 111
    private fun loadMessages() {


        if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager!!.isRoleAvailable(RoleManager.ROLE_SMS)) {
                if (roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
//                    askPermissions()
                    launchHomeScreen()
                } else {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
                    intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                    startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
                }
            } else {
                finish()
            }
        } else {
            if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {
//                askPermissions()
                launchHomeScreen()
            } else {
                val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            }
        }
    }

    private fun askPermissions() {
        handlePermission(PERMISSION_READ_SMS) {
            if (it) {
                handlePermission(PERMISSION_SEND_SMS) {
                    if (it) {
                        handlePermission(PERMISSION_READ_CONTACTS) {
                            handleNotificationPermission { granted ->
                                if (!granted) {
                                    PermissionRequiredDialog(
                                        activity = this,
                                        textId = R.string.allow_notifications_incoming_messages,
                                        positiveActionCallback = {

                                            openNotificationSettings() // Open notification settings
                                        },
                                        negativeActionCallback = {
                                            // Handle negative action (e.g., finish activity)
                                            openNotificationSettings()
                                        }
                                    )
                                    //  launchHomeScreen()
                                } else {
                                    firebaseAnalyticsHandler.logMessages(
                                        app_default_sms_permissions, getActivityName()
                                    )


                                    if (config.selectedLanguage.isEmpty()) {

                                        launchHomeScreen()
                                    } else {
                                        isLanguageAdShow = MainInterAdManager.langInterLoaded()
                                        MainInterAdManager.showGeneralInterAds(this, true) {
                                            if (intent.hasExtra("DefaultSms")) {

                                                startActivity(
                                                    Intent(
                                                        this,
                                                        MainActivity::class.java
                                                    ).setAction(intent.action)
                                                )
                                                finish()
                                            } else {
                                                launchHomeScreen()
                                            }
                                        }
                                    }


                                }
                            }
                        }
                    } else {
                        // Handle permission denied case for PERMISSION_SEND_SMS
                        finish()
                    }
                }
            } else {
                // Handle permission denied case for PERMISSION_READ_SMS
                finish()
            }
        }
    }

    fun openNotificationSettings() {
        if (isOreoPlus()) {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(intent)
        } else {
            // For Android versions below Oreo, you can't directly open the app's notification settings.
            // You can open the general notification settings instead.
            val intent = Intent(Settings.ACTION_SETTINGS)
            startActivity(intent)
        }
    }

    fun handleNotificationPermission(callback: (granted: Boolean) -> Unit) {
        if (!isTiramisuPlus()) {
            callback(true)
        } else {
            handlePermission(PERMISSION_POST_NOTIFICATIONS) { granted ->
                callback(granted)
            }
        }
    }

    var actionOnPermission: ((granted: Boolean) -> Unit)? = null
    var isAskingPermissions = false
    private val GENERIC_PERM_HANDLER = 100

    fun handlePermission(permissionId: Int, callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasPermission(permissionId)) {
            callback(true)
        } else {
            isAskingPermissions = true
            actionOnPermission = callback
            ActivityCompat.requestPermissions(
                this,
                arrayOf(getPermissionString(permissionId)),
                GENERIC_PERM_HANDLER
            )
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {
                askPermissions()
            } else if (resultCode == Activity.RESULT_CANCELED) {
                firebaseAnalyticsHandler.logMessages(
                    app_reject_default_sms_permissions, getActivityName()
                )
                isLanguageAdShow = MainInterAdManager.langInterLoaded()
                MainInterAdManager.showGeneralInterAds(this, true) {
                    if (intent.hasExtra("DefaultSms")) {
                        startActivity(
                            Intent(
                                this,
                                MainActivity::class.java
                            ).setAction(intent.action)
                        )
                        finish()
                    } else {
                        launchHomeScreen()
                    }
                }
//                launchHomeScreen()
                //  permissiondialog()
            }
        }
    }

    var alertDialog: android.app.AlertDialog? = null


    private fun privacyUrlRedirect(url: String) {
        val uri = Uri.parse(url)

        val builder = CustomTabsIntent.Builder()
        val params = CustomTabColorSchemeParams.Builder()
        params.setToolbarColor(
            ContextCompat.getColor(
                this@PermissionActivity,
                R.color.color_app_theme
            )
        )
        builder.setDefaultColorSchemeParams(params.build())
        builder.setShowTitle(true)
        builder.setShareState(CustomTabsIntent.SHARE_STATE_ON)
        builder.setInstantAppsEnabled(true)

        val customTabsIntent = builder.build()

        try {
            // Try to use Chrome if installed
            if (isPackageInstalled("com.android.chrome")) {
                customTabsIntent.intent.setPackage("com.android.chrome")
            }
            customTabsIntent.launchUrl(this@PermissionActivity, uri)

        } catch (e: ActivityNotFoundException) {
            // Fallback: Use external browser with chooser
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri)
                val chooser = Intent.createChooser(intent, resources.getString(R.string.open_with))
                startActivity(chooser)
            } catch (ex: ActivityNotFoundException) {
                // Optional: fallback to WebView inside the app
                openInWebView(url)
            }
        }
    }

    private fun openInWebView(url: String) {
        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()

        val dialog = AlertDialog.Builder(this, R.style.CustomFieldDialogTheme)
            .setTitle(resources.getString(R.string.privacy_policy))
            .setView(webView)
            .setPositiveButton(resources.getString(R.string.close)) { dialog, _ -> dialog.dismiss() }
            .create()

        webView.loadUrl(url)
        dialog.show()
    }

    private var backPressedTime: Long = 0


    override fun onBackPressed() {
        /*  if (backPressedTime + 2000 > System.currentTimeMillis()) {
  //            binding.ivDone.clicks()
  //            startActivity(Intent(this, MainActivity::class.java))
  //            finish()
          } else {
              if (intent.hasExtra("reset")) {
                  finish()
              } else {
                  *//*  Toast.makeText(
                      this,
                      getString(R.string.kindly_grant_the_necessary_permissions), Toast.LENGTH_SHORT
                  ).show()*//*
                backPressedTime = System.currentTimeMillis()
            }
        }*/


        if (::popupWindow.isInitialized && popupWindow.isShowing) {
            popupWindow.dismiss()
            return
        }


        if (intent.hasExtra("reset")) {
            finish()
        } else {
            if (binding.topLanguage.isVisible()) {
                // openPermission()
            } else {
                binding.progressBar.beGone()
                delayExecution(1) {
                    MainInterAdManager.showGeneralInterAds(this, true) {
                        startActivity(
                            Intent(
                                this,
                                MainActivity::class.java
                            ).setAction(intent.action)
                        )
                        finish()
                    }
                }
            }

        }
    }

    private fun loadNativeAndInterstitialAds(isFromSplash: Boolean) {
        Log.e("LLL_Splash", "loadNativeAndInterstitialAds =>")

        // Assuming MobileAds.initialize has completed successfully before this function is called
        // or you're sure it's fast enough.
        // However, it's safer to ensure initialization first.

        // Load Native Ad
        GoogleNativeAdHelper(
            this,
            binding.frameNative,
            clientConfigPref.languageAdType,
            getAppLanguageNative()
        ) { isLoaded ->
            binding.adView.visibility = if (isLoaded) View.VISIBLE else View.GONE
            binding.rvLanguage.setPadding(
                0,
                0,
                0,
                if (isLoaded) 20 else 0
            ) // Adjust padding only if ad loaded

            val event =
                if (isLoaded) app_ad_language_native_show else app_ad_language_native_failed
            firebaseAnalyticsHandler.logMessages(event, getActivityName())

        }.loadAd()


        if (isFromSplash && !clientConfigPref.showFirstTimeInterAd) {


            delayExecution(500) {
                lifecycleScope.launch {
                    val appContext = qkApplicationContext?.applicationContext
                    if (appContext != null) {
                        Log.e("loadGeneralInter--------------", "  -------------- 3")
                        MainInterAdManager.loadGeneralInter(appContext)
                    }
                }
            }
        }
    }


    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = true  // Flag to stop or continue the loop
    private var elapsedSeconds = 0  // Track how many seconds have passed

    private fun startRepeatingTask() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (isRunning && elapsedSeconds < 6) {
                    checkSomething()  // Perform your check here
                    elapsedSeconds++  // Increment the counter
                    handler.postDelayed(this, 1000)  // Repeat every second
                } else {
                    stopTask()  // Stop after 6 seconds or if isRunning is false
                    isRunning = false
                    //    doChange()
                    binding.ivDone.visibility = View.VISIBLE
                    binding.ivWait.visibility = View.GONE
                }
            }
        }, 1000)
    }

    private fun checkSomething() {
        val loaded = MainInterAdManager.langInterLoaded()

        if (loaded) {
            isRunning = false
            stopTask()
            //  doChange()

            binding.ivDone.visibility = View.VISIBLE
            binding.ivWait.visibility = View.GONE
        }
    }

    private fun stopTask() {
        handler.removeCallbacksAndMessages(null)  // Remove callbacks to stop the loop
        elapsedSeconds = 0  // Reset counter if needed in future runs
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false  // Stop the loop when activity is destroyed
        stopTask()  // Clean up callbacks to avoid memory leaks
    }


    private fun startNextAnimation() {
        val scaleUpX = ObjectAnimator.ofFloat(binding.ivDone, "scaleX", 1f, 0.9f)
        val scaleUpY = ObjectAnimator.ofFloat(binding.ivDone, "scaleY", 1f, 0.9f)
        val scaleDownX = ObjectAnimator.ofFloat(binding.ivDone, "scaleX", 0.9f, 1f)
        val scaleDownY = ObjectAnimator.ofFloat(binding.ivDone, "scaleY", 0.9f, 1f)

        val scaleUpSet = AnimatorSet().apply {
            playTogether(scaleUpX, scaleUpY)
            duration = 250 // Adjust duration to 250ms for half-cycle
            interpolator = LinearInterpolator()
        }

        val scaleDownSet = AnimatorSet().apply {
            playTogether(scaleDownX, scaleDownY)
            duration = 250 // Another 250ms for the second half
            interpolator = LinearInterpolator()
        }

        // Play scale up and scale down animations sequentially within 1 second
        AnimatorSet().apply {
            playSequentially(scaleUpSet, scaleDownSet)
            start()
        }
    }
}