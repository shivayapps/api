package messages.text.sms.feature.scheduled

import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import com.bumptech.glide.Glide
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.databinding.ScheduledMessageImageListItemBinding

import javax.inject.Inject

class ScheduledMessageAttachmentAdapter @Inject constructor(
    private val context: Context,
) : MainBaseAdapter<Uri, ScheduledMessageImageListItemBinding>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ScheduledMessageImageListItemBinding> {
        return MainBaseMsgViewHolder(parent, ScheduledMessageImageListItemBinding::inflate).apply {
            binding.thumbnail.clipToOutline = true
        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ScheduledMessageImageListItemBinding>,
        position: Int,
    ) {
        val attachment = getItem(position)

        Glide.with(context).load(attachment).into(holder.binding.thumbnail)
    }

}