package messages.text.sms.feature.personalize

import android.app.ProgressDialog
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.util.Log
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import dagger.android.AndroidInjection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.getProperBackgroundColor
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityCropImageThemeBinding
import messages.text.sms.util.StringManager
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CropImageThemeActivity : MainBaseThemedActivity() {

    private lateinit var stringManager: StringManager
    private var imageUri: String = "";
    lateinit var bitmap: Bitmap
    private val binding by viewBinding(ActivityCropImageThemeBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)


        stringManager = StringManager(this)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        showBackButton(true)
        setTitle(R.string.themes)


        //  imageUri = intent.getStringExtra("uri").toString()
        imageUri = intent.getParcelableExtra<Uri>("uri").toString()


        /*  val inputStream = contentResolver.openInputStream(Uri.parse(imageUri))
          bitmap = BitmapFactory.decodeStream(inputStream)*/

        val bitmap: Bitmap? = try {
            contentResolver.openInputStream(Uri.parse(imageUri))?.use { inputStream ->
                BitmapFactory.decodeStream(inputStream)
            }

        } catch (e: Exception) {
            e.printStackTrace()
            null
        }


        if (bitmap != null) {

//        val roundedDrawable = RoundedBitmapDrawableFactory.create(resources, bitmap)
//        roundedDrawable.cornerRadius = 20f

//        binding.ivBackground.setImageDrawable(roundedDrawable)
            binding.ivBackground.setImageBitmap(bitmap)
            binding.ivBackgroundImage.setImageBitmap(bitmap)
        }



        binding.ivBackgroundImage.scaleType = ImageView.ScaleType.FIT_XY
        //  binding.ivBackground.scaleType = ImageView.ScaleType.FIT_XY

        val alphaValue = (75 * 255) / 100  // Transparency between 0 and 255
        val backgroundColor = Color.argb(alphaValue, 0, 0, 0) // Black color with transparency
        binding.ivBackgroundImageblack.setBackgroundColor(backgroundColor)

        setUpTheme()
        setUpListener()
    }

    private fun setUpTheme() {

        //  updateTextColors(binding.contentView)
        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
        }

        if (baseConfig.useImageResource) {

            if (baseConfig.storedImageResource != -1) {
                if (baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(this)
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    binding.contentView.background = drawable
//                    binding.toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                } else {
                    val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                    binding.contentView.background = drawable
//                    binding.toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
                }
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            //   toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }


        binding.btnApply.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)

    }


    // Function to save the bitmap to a file
    private fun saveBitmapToFile(finalBitmap: Bitmap) {
        try {

            /*  val userImageThemeFolder = File(filesDir, "UserImageTheme")
              if (!userImageThemeFolder.exists()) {
                  userImageThemeFolder.mkdirs()
              }

              // Generate a unique filename with a timestamp
              val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
              val tempFile = File(userImageThemeFolder, "image_$timestamp.jpg")

              // Save the bitmap to the file
              val outputStream = FileOutputStream(tempFile)
              finalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
              outputStream.flush()
              outputStream.close()

              // Get the URI of the saved file
              val imageUri = FileProvider.getUriForFile(
                  this,
                  "messages.text.sms.fileprovider",
                  tempFile
              )*/


            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            stringManager.addBitmap(finalBitmap)

            prefs.themechanged.set(true)
            baseConfig.apply {
                themenameuri = "image_$timestamp.jpg"
                checkprimaryColortheme = context.resources.getColor(R.color.white);


                baseConfig.statusBarColor = Color.parseColor("#FFFFFF")
                primaryColortheme = Color.parseColor("#2569F1")
                checkprimaryColortheme = Color.parseColor("#2569F1")
                storedImageResource = 111

                primaryColor = Color.parseColor("#2569F1")
                accentColor = Color.parseColor("#FFFFFF")
                backgroundColor = Color.parseColor("#FFFFFF")
                toolbarcolor = Color.parseColor("#FFFFFF")
                customTextColor = Color.parseColor("#000000")
                customAppIconColor = Color.parseColor("#000000")
                textColor = Color.parseColor("#000000")
                customAccentColor = Color.parseColor("#FFFFFF")
                customPrimaryColor = Color.parseColor("#FFFFFF")
                getProperBackgroundColor()


                useImageResource = true
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                //   window.statusBarColor = statusbarcolorcheck

                if (baseConfig.useImageResource) {
                    if (baseConfig.storedImageResource == -1) {
                    } else {
                        val drawable = ContextCompat.getDrawable(
                            this@CropImageThemeActivity,
                            baseConfig.storedImageResource
                        )
                        binding.contentView.background = drawable
                    }
                }
                updateTextColors(binding.contentView)
                binding.btnApply.setTextColor(accentColor)

            }
            Toast.makeText(
                this,
                "" + resources.getString(R.string.theme_applied_successfully),
                Toast.LENGTH_SHORT
            ).show()


        } catch (e: IOException) {
            Log.e("CropImageThemeActivity", "Error saving image: ${e.message}")
            // Handle the error, e.g., show an error message to the user
        }
    }


    private fun setUpListener() {

//        val backgroundColor = Color.argb(10, 0, 0, 0)
//        binding.ivTransparent.setBackgroundColor(backgroundColor)

        binding.apply.setOnClickListener {
            val transparency = binding.transparencySeek.progress
            val blur = binding.blurSeek.progress
            val progressDialog = ProgressDialog(this).apply {
                setMessage("Processing, please wait...")
                setCancelable(false)
                show()
            }
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    // Call applyTransparencyAndBlur on a background thread
                    val finalBitmap = withContext(Dispatchers.Default) {


                        setBlackWithAlphaOnBitmap(
                            applyTransparencyAndBlur(
                                bitmap,
                                transparency,
                                blur
                            ), transparency
                        )

                    }

                    // Save the bitmap file after processing
                    withContext(Dispatchers.IO) {
                        saveBitmapToFile(finalBitmap)
                        progressDialog.dismiss()
                    }
                } catch (_: Exception) {

                }
            }


        }


        binding.transparencySeek.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.transPer.text = "$progress%"
                val alphaValue = (progress * 255) / 100  // Transparency between 0 and 255

                // Set the color with transparency to the ImageView's background
                val backgroundColor =
                    Color.argb(alphaValue, 0, 0, 0) // Black color with transparency
                binding.ivTransparent.setBackgroundColor(backgroundColor)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user starts dragging the SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user stops dragging the SeekBar
            }
        })
        binding.blurSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.blurPer.text = "$progress%"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val blurRadius = (progress.toFloat() / 30) // Max blur radius of 10
                    if (blurRadius > 0) {
                        val blurEffect = RenderEffect.createBlurEffect(
                            blurRadius,
                            blurRadius,
                            Shader.TileMode.CLAMP
                        )
                        binding.ivBackground.setRenderEffect(blurEffect)
                    } else {
                        binding.ivBackground.setRenderEffect(null)
                    }
                } else {
                    // Fallback for API < 31: Use RenderScript for blur
                    val blurRadius = progress / 30f  // Max blur radius of 10
                    if (blurRadius > 0) {
                        // Apply RenderScript blur
                        binding.ivBackground.setImageBitmap(
                            applyRenderScriptBlur(
                                bitmap,
                                blurRadius
                            )
                        )
                    }
                }
                binding.ivBackground.scaleType = ImageView.ScaleType.FIT_XY
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user starts dragging the SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Optional: You can handle actions when user stops dragging the SeekBar
            }
        })

        binding.transparencySeek.progress = 50
        //    binding.blurSeek.progress = 25


        val blurRadius = 6F
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val blurEffect =
                RenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP)
            binding.ivBackgroundImage.setRenderEffect(blurEffect)
        } else {
            binding.ivBackgroundImage.setImageBitmap(applyRenderScriptBlur(bitmap, blurRadius))
        }
        binding.ivBackgroundImage.scaleType = ImageView.ScaleType.FIT_XY
    }

    // Function to apply transparency and blur to the Bitmap
    private fun applyTransparencyAndBlur(bitmap: Bitmap, transparency: Int, blur: Int): Bitmap {

        return mergeViewsToBitmap()
    }


    fun setBlackWithAlphaOnBitmap(bitmap: Bitmap, alpha: Int): Bitmap {
        // Create a paint object with a black color and the specified alpha value (0-255)
        val paint = Paint().apply {
            color = Color.BLACK
            this.alpha = alpha // Set the alpha value (0 is fully transparent, 255 is fully opaque)
        }

        // Create a canvas from the bitmap
        val canvas = Canvas(bitmap)

        // Draw a rectangle over the entire bitmap with the paint object
        canvas.drawRect(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat(), paint)

        return bitmap
    }

    fun mergeViewsToBitmap(): Bitmap {
        // Get the width and height from ivBackground (assuming ivTransparent has the same size)
        val width = binding.ivBackgroundImage.width
        val height = binding.ivBackgroundImage.height

        // Create a bitmap with the width and height of the views
        val mergedBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mergedBitmap)

        // Draw ivBackground onto the canvas
        binding.ivBackground.draw(canvas)

        // Draw ivTransparent onto the canvas
        binding.ivTransparent.draw(canvas)

        return mergedBitmap
    }


    // Function to apply RenderScript blur for API < 31
    private fun applyRenderScriptBlur(bitmap: Bitmap, radius: Float): Bitmap {
        val outputBitmap = Bitmap.createBitmap(bitmap)

        val renderScript = RenderScript.create(this@CropImageThemeActivity)
        val input = Allocation.createFromBitmap(renderScript, bitmap)
        val output = Allocation.createFromBitmap(renderScript, outputBitmap)

        val scriptIntrinsicBlur =
            ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript))
        scriptIntrinsicBlur.setRadius(radius) // The blur radius (0 < radius <= 25)
        scriptIntrinsicBlur.setInput(input)
        scriptIntrinsicBlur.forEach(output)

        output.copyTo(outputBitmap)

        renderScript.destroy()
        return outputBitmap
    }


}