package messages.text.sms.common

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.ViewGroup
import android.view.Window
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil.setContentView
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.QuickReplyCustomDialogBinding
import messages.text.sms.feature.main.QuickResponseActivity

class QuickMessageCustomDialog(
    private val context: Context,
    private val onDialogShow: (() -> Unit)? = null,
    private val onDialogDismiss: (() -> Unit)? = null,
) {

    private lateinit var adapter: CustomDialogAdapter
    private val callerMessages: MutableList<String> = mutableListOf()
    private var dialog: BottomSheetDialog? = null

    fun show(itemClickListener: (String, Int) -> Unit) {
        dialog = BottomSheetDialog(context, R.style.QuickReplyDialogStyle).apply {
            val binding = QuickReplyCustomDialogBinding.inflate(layoutInflater)
            setContentView(binding.root)

            callerMessages.clear()
            callerMessages.addAll(getCallerMessages(context))
            adapter = CustomDialogAdapter(callerMessages, itemClickListener)
            binding.recyclerView.adapter = adapter
            binding.recyclerView.layoutManager = LinearLayoutManager(context)

            // Set the background and layout params for BottomSheetDialog
            window?.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            binding.quickSettingTitle.setOnClickListener {
                val intent = Intent(context, QuickResponseActivity::class.java)
                context.startActivity(intent)
            }

            // Set listeners
            setOnShowListener {
                onDialogShow?.invoke()
            }
            setOnDismissListener {
                onDialogDismiss?.invoke()
            }
            show()
        }
    }

    fun dismiss() {
        dialog?.dismiss()
        dialog = null
    }

    fun updateList() {
        if (dialog?.isShowing == true) {
            // Update the messages and notify the adapter
            callerMessages.clear()
            callerMessages.addAll(getCallerMessages(context))
            adapter.notifyDataSetChanged()
        }
    }

    private fun getCallerMessages(context: Context): List<String> {
        return context.baseConfig.quickMessagesList
    }
}