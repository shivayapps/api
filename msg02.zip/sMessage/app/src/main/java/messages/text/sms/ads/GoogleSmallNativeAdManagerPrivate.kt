package  messages.text.sms.ads

import android.content.Context
import android.view.ViewGroup
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd

object GoogleSmallNativeAdManagerPrivate {
    var mSmallNativeAd: NativeAd? = null
    var mSmallNativeAdShow = false

    //    var nativeAdViewLovinAdShow = false
    var mSmallNativeAd8: NativeAd? = null
    var mSmallNativeAd8Show = false

    var mSmallNativeAd4: NativeAd? = null
    var mSmallNativeAd4Show = false

    //    -----------------------------------1ST Small native-----------------------------------------
    fun loadSmallNativePrivate(context: Context, mAdId: String, listener: (NativeAd?) -> Unit) {
        loadNativePrivate(context, mAdId) {
            mSmallNativeAd = it
            listener(it)
        }
    }

    fun showNativePrivate(context: Context, parentView: ViewGroup) {
        mSmallNativeAd?.let {
            AdmobNative.populateSmallNativeAd(context, parentView, it)
        }
    }

    private fun loadNativePrivate(context: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected() || !AdsPreferences(context).adsEnable || AdsPreferences(
                context
            ).isPro
        ) {
            listener(null)
            return
        }
        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { listener(it) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener(null)
                    mSmallNativeAdShow = false
                }

                override fun onAdImpression() {
                    mSmallNativeAdShow = true
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }


    //    -----------------------------------4TH Max Small native-----------------------------------------
//    private var nativeAdLoader: MaxNativeAdLoader? = null
//
//    @SuppressLint("StaticFieldLeak")
//    var maxAd: MaxAd? = null
//    var nativeAdView: MaxNativeAdView? = null
//
//    @SuppressLint("StaticFieldLeak")
//    fun loadApplovinSmallNative(context: Context, adIds: String, listener: (MaxAd?) -> Unit) {
//        nativeAdLoader = MaxNativeAdLoader(adIds, context).apply {
//            setNativeAdListener(object : MaxNativeAdListener() {
//                override fun onNativeAdLoaded(nativedView: MaxNativeAdView?, ad: MaxAd) {
//                    maxAd = ad
//                    nativeAdView = nativedView
//                    listener(ad)
//                    nativeAdViewLovinAdShow = true
//                    Log.e("loadApplovinSmallNative", "onNativeAdLoaded")
//                }
//
//                override fun onNativeAdLoadFailed(adUnitId: String, error: MaxError) {
//                    listener(null)
//                    maxAd = null
//                    nativeAdView = null
//                    nativeAdViewLovinAdShow = false
//                    Log.e("loadApplovinSmallNative", "onNativeAdLoadFailed")
//                }
//
//                override fun onNativeAdExpired(ad: MaxAd) {
//                    listener(null)
//                    maxAd = null
//                    nativeAdView = null
//                    nativeAdViewLovinAdShow = false
//                    Log.e("loadApplovinSmallNative", "onNativeAdExpired")
//                }
//            })
//        }
//
//        nativeAdLoader?.setRevenueListener {
//            context.setApplovinLogs(it)
//        }
//        nativeAdLoader?.loadAd(createNativeAdViewPrivate(context))
//    }
//
//    fun showAdAppLovinPrivate(context: Context, parentView: ViewGroup) {
//
//
//        if (nativeAdView != null) {
//
//            try {
//
//                parentView.removeAllViews()
//                //        parentView.addView(createNativeAdViewPrivate(context, maxAd!!))
//                parentView.addView(nativeAdView)
//            } catch (_: Exception) {
//
//                parentView.removeAllViews()
//                parentView.addView(createNativeAdViewPrivate(context, maxAd!!))
//            }
//        } else {
//            parentView.removeAllViews()
//            parentView.addView(createNativeAdViewPrivate(context, maxAd!!))
//        }
//
//
//    }

    //    -----------------------------------4TH Small native-----------------------------------------
    fun loadSmallNative4Private(context: Context, mAdId: String, listener: (NativeAd?) -> Unit) {
        loadNative4Private(context, mAdId) {
            mSmallNativeAd4 = it
            listener(it)
        }
    }

    fun showNative4Private(context: Context, parentView: ViewGroup) {
        mSmallNativeAd4?.let {
            AdmobNative.populateSmallNativeAd(context, parentView, it)
        }
    }


    private fun loadNative4Private(context: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected() || !AdsPreferences(context).adsEnable || AdsPreferences(
                context
            ).isPro
        ) {
            listener(null)
            return
        }

        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { listener(it) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener(null)
                    mSmallNativeAd4Show = false
                }

                override fun onAdImpression() {
                    mSmallNativeAd4Show = true
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    //    -----------------------------------8TH Small native-----------------------------------------
    fun loadSmallNative8Private(context: Context, mAdId: String, listener: (NativeAd?) -> Unit) {
        loadNative8Private(context, mAdId) {
            mSmallNativeAd8 = it
            listener(it)
        }
    }

    fun showNative8Private(context: Context, parentView: ViewGroup) {
        mSmallNativeAd8?.let {
            AdmobNative.populateSmallNativeAd(context, parentView, it)
        }
    }


    private fun loadNative8Private(context: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected() || !AdsPreferences(context).adsEnable || AdsPreferences(
                context
            ).isPro
        ) {
            listener(null)
            return
        }

        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { listener(it) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener(null)
                    mSmallNativeAd8Show = false
                }

                override fun onAdImpression() {
                    mSmallNativeAd8Show = true
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun onDestroy() {
        mSmallNativeAd?.destroy()
        mSmallNativeAd = null
//        maxAd?.let { nativeAdLoader?.destroy(it) }
//        nativeAdLoader?.destroy()
        mSmallNativeAd8?.destroy()
        mSmallNativeAd8 = null
        mSmallNativeAd4?.destroy()
        mSmallNativeAd4 = null
    }


//    private fun createNativeAdViewPrivate(context: Context): MaxNativeAdView {
//        val binder = MaxNativeAdViewBinder.Builder(R.layout.layout_list_item_native_applovin)
//            .setTitleTextViewId(R.id.title_text_view)
//            .setBodyTextViewId(R.id.body_text_view)
//            .setIconImageViewId(R.id.icon_image_view)
//            .setCallToActionButtonId(R.id.cta_button)
//            .build()
//
//        val nativeAdView = MaxNativeAdView(binder, context)
//
//        // Get the CTA button from the native ad view
//        val ctaButton = nativeAdView.findViewById<Button>(R.id.cta_button)
//
//        // Set the text color of the CTA button
//        ctaButton.setTextColor(context.baseConfig.primaryColor)
//
//
//        val applyBackground = ResourcesCompat.getDrawable(
//            context.resources,
//            R.drawable.ads_item_gradiant_rounded,
//            null
//        ) as LayerDrawable
//        val strokeDrawable =
//            applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
//        strokeDrawable.setStroke(2, context.baseConfig.primaryColor)
//
//        ctaButton.background = applyBackground
//
//        return nativeAdView
//    }

//    private fun createNativeAdViewPrivate(context: Context, maxAd: MaxAd): MaxNativeAdView {
//        val binder = MaxNativeAdViewBinder.Builder(R.layout.layout_list_item_native_applovin)
//            .setTitleTextViewId(R.id.title_text_view)
//            .setBodyTextViewId(R.id.body_text_view)
//            .setIconImageViewId(R.id.icon_image_view)
//            .setCallToActionButtonId(R.id.cta_button)
//            .build()
//
//        val nativeAdView = MaxNativeAdView(maxAd.nativeAd, binder, context)
//        maxAd.nativeAd?.setNativeAdView(nativeAdView)
//        // Get the CTA button from the native ad view
//        val ctaButton = nativeAdView.findViewById<Button>(R.id.cta_button)
//        val cvRoot = nativeAdView.findViewById<View>(R.id.cvRoot)
//        try {
//            val iconImageView = nativeAdView.findViewById<RoundedImageView>(R.id.icon_image_view)
//            iconImageView.setImageURI(maxAd.nativeAd!!.icon!!.uri)
//            if (maxAd.nativeAd?.icon?.uri == null) {
//                iconImageView.setImageDrawable(maxAd.nativeAd!!.icon!!.drawable)
//            }
//
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        // Set the text color of the CTA button
//        ctaButton.setTextColor(context.baseConfig.primaryColor)
//        ctaButton.setPadding(40, 10, 40, 10)
//        cvRoot.setOnClickListener {
//            this.nativeAdView!!.callToActionButton.performClick()
//        }
//        val applyBackground = ResourcesCompat.getDrawable(
//            context.resources,
//            R.drawable.ads_item_gradiant_rounded,
//            null
//        ) as LayerDrawable
//        val strokeDrawable =
//            applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
//        strokeDrawable.setStroke(2, context.baseConfig.primaryColor)
//
//        ctaButton.background = applyBackground
//
//        return nativeAdView
//    }
}