package messages.text.sms.autoreply

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.app_block_activity_open
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.AutoReplyActivityBinding
import messages.text.sms.model.ContactData
import messages.text.sms.model.MessageEvent
import messages.text.sms.repository.ContactRepository
import messages.text.sms.repository.ConversationRepository
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject

class AutoReplyActivity : MainBaseThemedActivity() {

    private val binding by viewBinding(AutoReplyActivityBinding::inflate)

    @Inject
    lateinit var contactsRepo: ContactRepository
    val contactDataList: List<ContactData> by lazy { contactsRepo.getContactsList() }

    @Inject
    lateinit var conversationRepository: ConversationRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
        }
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        EventBus.getDefault().takeIf { !it.isRegistered(this) }?.register(this)

        title = getString(R.string.auto_reply_setting)

        setUpTheme()
        setClickListeners()
        firebaseAnalyticsHandler.logMessages(app_block_activity_open, getActivityName())
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().takeIf { it.isRegistered(this) }?.unregister(this)
    }

    override fun onResume() {
        super.onResume()
        updateDetails()
    }

    private fun setClickListeners() = with(binding) {
        val toggleSwitch: () -> Unit = {
            switchToggle.isChecked = !switchToggle.isChecked
            baseConfig.autoReplyEnable = switchToggle.isChecked
            updateDetails()
        }

        autoReplyCard.setOnClickListener { toggleSwitch() }
        switchToggle.setOnClickListener { toggleSwitch() }

        card1.setOnClickListener {
            baseConfig.autoReplySelectedCard = 1
            updateDetails()
        }
        card2.setOnClickListener {
            baseConfig.autoReplySelectedCard = 2
            updateDetails()
        }
        card3.setOnClickListener {
            baseConfig.autoReplySelectedCard = 3
            updateDetails()
        }

        binding.switchReplyContactsOnly.setOnCheckedChangeListener { _, isChecked ->
            baseConfig.onlyReplyContacts = isChecked
        }
    }

    private fun updateDetails() = with(binding) {
        val isEnabled = baseConfig.autoReplyEnable
        switchToggle.isChecked = isEnabled

        offAutoreply.visibility = if (isEnabled) View.GONE else View.VISIBLE
        offAutoreply1.visibility = if (isEnabled) View.GONE else View.VISIBLE
        enableListView.visibility = if (isEnabled) View.VISIBLE else View.GONE
        otherView.visibility = if (isEnabled) View.VISIBLE else View.GONE
        disableTextView.visibility = if (isEnabled) View.GONE else View.VISIBLE

        val selectedCard = baseConfig.autoReplySelectedCard
        val selectIcon = R.drawable.ic_select_qk
        val unselectIcon = R.drawable.ic_unselect_qk

        optionCard1.setImageResource(if (selectedCard == 1) selectIcon else unselectIcon)
        optionCard2.setImageResource(if (selectedCard == 2) selectIcon else unselectIcon)
        optionCard3.setImageResource(if (selectedCard == 3) selectIcon else unselectIcon)


        binding.switchReplyContactsOnly.isChecked = baseConfig.onlyReplyContacts

        if (isEnabled) loadModeFragment(selectedCard)
    }

    private fun loadModeFragment(mode: Int) {
        val fragment = when (mode) {
            1 -> DriveModeFragment()
            2 -> DriveModeFragment()
            3 -> DriveModeFragment()
//            2 -> MeetingModeFragment()
//            3 -> VacationModeFragment()
            else -> null
        }

        fragment?.let {
            supportFragmentManager.beginTransaction()
                .replace(R.id.enableListView, it)
                .commitAllowingStateLoss()
        }
    }


    private fun setUpTheme() = with(binding) {
        updateTextColors(contentView)

        contentView.background = when {
            baseConfig.useImageResource && baseConfig.storedImageResource != -1 -> {
                ContextCompat.getDrawable(this@AutoReplyActivity, baseConfig.storedImageResource)
                    .also {
                        toolbar.setBackgroundColor(
                            ContextCompat.getColor(
                                this@AutoReplyActivity,
                                R.color.transperent
                            )
                        )
                    }
            }

            baseConfig.backgroundColor == Color.parseColor("#000000") -> {
                ColorDrawable(
                    ContextCompat.getColor(
                        this@AutoReplyActivity,
                        R.color.bottom_tabs_black_background_new
                    )
                )
            }

            else -> {
                toolbar.setBackgroundColor(baseConfig.backgroundColor)
                ColorDrawable(baseConfig.backgroundColor)
            }
        }

        ContextCompat.getDrawable(this@AutoReplyActivity, R.drawable.round_button)?.apply {
            setTint(baseConfig.primaryColor)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        // Future use
    }
}
