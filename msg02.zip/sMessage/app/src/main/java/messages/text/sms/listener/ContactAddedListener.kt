package messages.text.sms.listener

import io.reactivex.Observable

interface ContactAddedListener {

    fun listen(): Observable<*>

}
