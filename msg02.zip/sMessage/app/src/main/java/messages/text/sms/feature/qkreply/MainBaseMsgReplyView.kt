package messages.text.sms.feature.qkreply

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgView

interface MainBaseMsgReplyView : MainBaseMsgView<QkReplyState> {

    val menuItemIntent: Observable<Int>
    val textChangedIntent: Observable<CharSequence>
    val changeSimIntent: Observable<*>
    val sendIntent: Observable<Unit>

    fun setDraft(draft: String)
    fun finish()

}