package messages.text.sms.feature.main

import android.content.Context
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.view.ViewGroup
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.extensions.setVisible
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.SearchListItemBinding
import messages.text.sms.extensions.removeAccents
import messages.text.sms.model.SearchResult
import javax.inject.Inject

class SearchAdapter @Inject constructor(
    colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
) : MainBaseAdapter<SearchResult, SearchListItemBinding>() {

    private val highlightColor: Int by lazy { colors.theme().highlight }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<SearchListItemBinding> {
        return MainBaseMsgViewHolder(parent, SearchListItemBinding::inflate).apply {
            binding.root.setOnClickListener {
                val result = getItem(adapterPosition)
                navigator.showConversation(
                    result.conversation.id,
                    result.query.takeIf { result.messages > 0 })
            }
        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<SearchListItemBinding>,
        position: Int,
    ) {
        val previous = data.getOrNull(position - 1)
        val result = getItem(position)

        holder.binding.resultsHeader.setVisible(result.messages > 0 && previous?.messages == 0)

        val query = result.query
        val title = SpannableString(result.conversation.getTitle())
        var index = title.removeAccents().indexOf(query, ignoreCase = true)


        val textColorPrimary = context.baseConfig.textColor
        val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
        holder.binding.title.setTextColor(textColorPrimary)
        holder.binding.date.setTextColor(colorWithAlpha)
        holder.binding.snippet.setTextColor(colorWithAlpha)

        /* while (index >= 0) {
             title.setSpan(
                 BackgroundColorSpan(highlightColor),
                 index,
                 index + query.length,
                 Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
             )
             index = title.indexOf(query, index + query.length, true)
         }*/

        if (index >= 0 && index + query.length <= title.length) {
            title.setSpan(
                BackgroundColorSpan(highlightColor),
                index,
                index + query.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        holder.binding.title.text = title

        holder.binding.avatars.recipients = result.conversation.recipients

        when (result.messages == 0) {
            true -> {
                holder.binding.date.setVisible(true)
                holder.binding.date.text =
                    dateFormatter.getConversationTimestamp(result.conversation.date)
                holder.binding.snippet.text = when (result.conversation.me) {
                    true -> context.getString(R.string.main_sender_you, result.conversation.snippet)
                    false -> result.conversation.snippet
                }
            }

            false -> {
                holder.binding.date.setVisible(false)
                holder.binding.snippet.text =
                    context.getString(R.string.main_message_results, result.messages)
            }
        }
    }

    override fun areItemsTheSame(old: SearchResult, new: SearchResult): Boolean {
        return old.conversation.id == new.conversation.id && old.messages > 0 == new.messages > 0
    }

    override fun areContentsTheSame(old: SearchResult, new: SearchResult): Boolean {
        return old.query == new.query && // Queries are the same
                old.conversation.id == new.conversation.id // Conversation id is the same
                && old.messages == new.messages // Result count is the same
    }
}