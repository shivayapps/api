package messages.text.sms.feature.main.ui

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.tablayout.tintDrawableColor
import messages.text.sms.feature.main.models.Contact


class ContactMultiPickerAdapter(result: List<Contact>) :
    RecyclerView.Adapter<ContactMultiPickerAdapter.ContactViewHolder>(), Filterable {

    private val originalList: MutableList<Contact> = ArrayList(result)
    private val filteredList: MutableList<Contact> = ArrayList(result)
    private val selectedItems: MutableSet<Contact> = mutableSetOf()

    init {
        setHasStableIds(true)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_contact_block_picker, parent, false)
        return ContactViewHolder(view)
    }


    override fun getItemCount(): Int = filteredList.size

    //    override fun getItemId(position: Int): Long {
//        return filteredList[position].phone?.hashCode()?.toLong() ?: position.toLong()
//
//    }
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }


    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val contact = filteredList[position]
        holder.nameTextView.text = contact.name
        holder.phoneTextView.text = contact.phone

        // Colored circle for contact first char
        val colors: IntArray = holder.itemView.context.resources.getIntArray(R.array.random_colors)
        val color = colors[position % colors.size]
        val drawable = ContextCompat.getDrawable(
            holder.contactFirstChar.context,
            R.drawable.round_button_grey
        ) as GradientDrawable
        drawable.setColor(color)
        holder.contactFirstChar.background = drawable
        holder.contactFirstChar.text = contact.name?.firstOrNull()?.toString() ?: ""

        // Handle selection UI
        val context = holder.itemView.context
        val isSelected = selectedItems.contains(contact)

        holder.selectedItem.setImageResource(
            if (isSelected) R.drawable.ic_select_qk_msg else R.drawable.ic_un_select_qk_msg
        )
        holder.selectedItem.tintDrawableColor(context.baseConfig.primaryColor)

        // Click toggle
        holder.itemViewMain.setOnClickListener {
            if (isSelected) {
                selectedItems.remove(contact)
            } else {
                selectedItems.add(contact)
            }
            notifyItemChanged(position)
        }
    }

    fun getSelectedContacts(): List<Contact> = selectedItems.toList()

    fun setData(newList: List<Contact>) {
        originalList.clear()
        originalList.addAll(newList)
        filteredList.clear()
        filteredList.addAll(newList)
        notifyDataSetChanged()
    }

    fun filterContacts(query: String?) {
        filteredList.clear()
        if (query.isNullOrBlank()) {
            filteredList.addAll(originalList)
        } else {
            val lowercaseQuery = query.trim().lowercase()
            filteredList.addAll(originalList.filter {
                it.name?.lowercase()?.contains(lowercaseQuery) == true ||
                        it.phone?.contains(lowercaseQuery) == true
            })
        }
        notifyDataSetChanged()
    }

    override fun getFilter(): Filter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val query = constraint?.toString()?.lowercase()?.trim().orEmpty()
            val results = if (query.isEmpty()) {
                originalList
            } else {
                originalList.filter {
                    it.name?.lowercase()?.contains(query) == true ||
                            it.phone?.contains(query) == true
                }
            }

            return FilterResults().apply {
                values = results
                count = results.size
            }
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            filteredList.clear()
            if (results?.values is List<*>) {
                @Suppress("UNCHECKED_CAST")
                filteredList.addAll(results.values as List<Contact>)
            }
            notifyDataSetChanged()
        }
    }

    class ContactViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val contactFirstChar: TextView = view.findViewById(R.id.iv_contact_photo)
        val nameTextView: TextView = view.findViewById(R.id.tv_contact_name)
        val phoneTextView: TextView = view.findViewById(R.id.tv_contact_phone_number)
        val itemViewMain: RelativeLayout = view.findViewById(R.id.itemView)
        val selectedItem: ImageView = view.findViewById(R.id.selected)
    }
}
