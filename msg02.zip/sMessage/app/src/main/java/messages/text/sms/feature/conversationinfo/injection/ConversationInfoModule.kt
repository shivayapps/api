package messages.text.sms.feature.conversationinfo.injection

import dagger.Module
import dagger.Provides
import messages.text.sms.feature.conversationinfo.ConversationInfoController
import messages.text.sms.injection.scope.ControllerScope
import javax.inject.Named

@Module
class ConversationInfoModule(private val controller: ConversationInfoController) {

    @Provides
    @ControllerScope
    @Named("threadId")
    fun provideThreadId(): Long = controller.threadId

}