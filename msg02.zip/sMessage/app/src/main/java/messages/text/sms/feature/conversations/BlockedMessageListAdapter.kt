package messages.text.sms.feature.conversations

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import io.realm.Realm
import io.realm.RealmResults
import messages.text.sms.R
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive.showNative4Archived
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive.showNative8Archived
import messages.text.sms.ads.GoogleSmallNativeAdManagerArchive.showNativeArchived
import messages.text.sms.ads.delayExecution
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.base.NewBaseAdapter
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.databinding.ConversationListItemBinding
import messages.text.sms.model.Conversation
import messages.text.sms.model.ConversationAD
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.ModelType
import messages.text.sms.model.SYNC_MESSAGE
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.Preferences
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject


class BlockedMessageListAdapter @Inject constructor(
    private val colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val prefs: Preferences,
) : NewBaseAdapter<Conversation, ConversationListItemBinding>() {

    var activity: Activity? = null
    var currentActivity: String? = null
    var isLoadingAd = true
    private val AD_VIEW_TYPE = 2 // Unique view type for native ads

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long {
        val conversation = getItem(getConversationPosition(position)) ?: return -1
        if (conversation is Conversation) {
            return conversation.id ?: -1
        }
        return -1
    }

    fun toggleSelectAll(isSelect: Boolean) {
        val cnt = itemCount
        if (selection.size == cnt) {
            clearSelection()
        } else {
            selection = listOf()
            // Create a list of all eligible item IDs (excluding AD_VIEW_TYPE)
            val eligibleIds =
                asyncListDiffer.currentList.filterIsInstance<Conversation>().map { it.id }

            // Use Kotlin's set operations for efficient selection manipulation
            if (isSelect) {
                // Add all eligible IDs to the selection
                selection = selection + eligibleIds
            } else {
                // Remove all eligible IDs from the selection
                selection = selection - eligibleIds
            }
            selectionChanges.onNext(selection)
            notifyDataSetChanged()
        }
    }

    fun getBubbleText(adapterPosition: Int): String {
        val conversation = getItem(adapterPosition)
        return if (conversation is Conversation) {
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp) ?: ""
        } else {
            ""
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ConversationListItemBinding> {

        return MainBaseMsgViewHolder(parent, ConversationListItemBinding::inflate).apply {
            if (viewType == AD_VIEW_TYPE) {
                binding.llAds.beVisible()
                binding.topLine.beVisible()
                binding.mainConversation.beGone()

            } else {
                binding.llAds.beGone()
                binding.topLine.beGone()
                binding.mainConversation.beVisible()
                val textColorPrimary = context.baseConfig.textColor
                val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
                binding.title.setTextColor(textColorPrimary)
                binding.date.setTextColor(colorWithAlpha)
                binding.snippet.setTextColor(colorWithAlpha)

                if (viewType == 1) {
                    binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)
                    binding.snippet.setTypeface(binding.snippet.typeface, Typeface.BOLD)
                    binding.snippet.setTextColor(textColorPrimary)
                    binding.unread.isVisible = true
                    binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
                } else {
                    binding.title.setTypeface(binding.title.typeface, Typeface.NORMAL)
                    binding.snippet.setTypeface(binding.snippet.typeface, Typeface.NORMAL)
                    binding.snippet.setTextColor(colorWithAlpha)
                }

                binding.mainConversation.setOnClickListener {
                    val conversation = getItem(getConversationPosition(adapterPosition))
                        ?: return@setOnClickListener
                    if (conversation is Conversation) {

                        when (toggleSelection(conversation.id, false)) {
                            true -> {
                                if (isSelected(conversation.id)) {
                                    binding.cbSelect.isChecked = true
                                } else {
                                    binding.cbSelect.isChecked = false
                                }
                            }

                            false -> {
                                navigator.showConversation(conversation.id)
                                if (conversation.unread) {
                                    activity?.delayExecution(500) {
                                        EventBus.getDefault().post(MessageEvent(SYNC_MESSAGE))
                                    }
                                }
                            }
                        }
                    }

                }

                binding.mainConversation.setOnLongClickListener {
                    val conversation = getItem(getConversationPosition(adapterPosition))
                        ?: return@setOnLongClickListener true
                    if (conversation is Conversation) {
                        toggleSelection(conversation.id)
                        if (isSelected(conversation.id)) {
                            binding.cbSelect.isChecked = true
                        } else {
                            binding.cbSelect.isChecked = false
                        }
                        notifyDataSetChanged()
                    }
                    true
                }
            }


        }
    }

    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ConversationListItemBinding>,
        position: Int,
    ) {
        val conversation = getItem(getConversationPosition(position)) ?: return
        if (conversation is Conversation) {
            if (isSelected(conversation.id)) {
                holder.binding.cbSelect.isChecked = true
            } else {
                holder.binding.cbSelect.isChecked = false
            }

            holder.binding.avatars.title = conversation.getTitle()
            holder.binding.avatars.recipients = conversation.recipients
            holder.binding.title.collapseEnabled = conversation.recipients.size > 1
            holder.binding.title.text = conversation.getTitle()
            holder.binding.date.text =
                conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp)


            try {
                val typeface = ResourcesCompat.getFont(context, prefs.selectedFont.get())
                holder.binding.snippet.setTypeface(typeface)
            } catch (_: Exception) {
            }

            holder.binding.snippet.text = when {
                conversation.draft.isNotEmpty() -> context.getString(
                    R.string.main_draft, conversation.draft
                )

                conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
                else -> conversation.snippet
            }
            holder.binding.pinned.isVisible = conversation.pinned


            if (isSelection()) {
                holder.binding.cbSelect.beVisible()
            } else {
                holder.binding.cbSelect.beGone()
            }
            holder.binding.cbSelect.buttonTintList =
                ColorStateList.valueOf(context.baseConfig.primaryColor)
            holder.binding.pinned.imageTintList =
                ColorStateList.valueOf(context.baseConfig.primaryColor)


            // If the last message wasn't incoming, then the colour doesn't really matter anyway
            val lastMessage = conversation.lastMessage
            val recipient = when {
                conversation.recipients.size == 1 || lastMessage == null -> conversation.recipients.firstOrNull()
                else -> conversation.recipients.find { recipient ->
                    phoneNumberUtils.compare(recipient.address, lastMessage.address)
                }
            }
            holder.binding.unread.setTint(context.baseConfig.primaryColor)
        } else if (conversation is ConversationAD) {
            holder.binding.root.isFocusable = false

            if (conversation.position == 0) {
                if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNativeArchived(context, holder.binding.inBannerViewTop.root)

                } else if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd4 != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNative4Archived(context, holder.binding.inBannerViewTop.root)

                } else if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd8 != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNative8Archived(context, holder.binding.inBannerViewTop.root)
                } else {
                    if (!isLoadingAd) {
                        holder.binding.llAds.visibility = View.GONE

                    }
                }
            } else if (conversation.position == 4) {
                if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd4 != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNative4Archived(context, holder.binding.inBannerViewTop.root)

                } else if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNativeArchived(context, holder.binding.inBannerViewTop.root)

                } else if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd8 != null) {
                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNative8Archived(context, holder.binding.inBannerViewTop.root)
                } else {
                    if (!isLoadingAd) {
                        holder.binding.llAds.visibility = View.GONE

                    }
                }

            } else if (conversation.position == 8) {
                if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd8 != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNative8Archived(context, holder.binding.inBannerViewTop.root)

                } else if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNativeArchived(context, holder.binding.inBannerViewTop.root)

                } else if (GoogleSmallNativeAdManagerArchive.mSmallNativeAd4 != null) {

                    holder.binding.inBannerViewTop.root.visibility = View.VISIBLE
                    showNative4Archived(context, holder.binding.inBannerViewTop.root)

                } else {
                    if (!isLoadingAd) {
                        holder.binding.llAds.visibility = View.GONE
                    }
                }
            }


        }

    }

    override fun getItemViewType(position: Int): Int {
        val conversation = getItem(getConversationPosition(position))
        return if (conversation is ConversationAD) AD_VIEW_TYPE else if (conversation is Conversation && !conversation.unread) 0 else 1
    }


    private fun getConversationPosition(position: Int): Int {
        return position
    }

    fun removeItem(threadId: Long) {
        val list =
            ArrayList(asyncListDiffer.currentList).filterIsInstance<Conversation>() as ArrayList<Conversation>
        list.removeIf { (it.id == threadId) }
        notifyList(list)
    }

    fun handleAction(threadId: Long, action: Int) {
        val list =
            ArrayList(asyncListDiffer.currentList).filterIsInstance<Conversation>() as ArrayList<Conversation>
        val conversation = list.firstOrNull { it.id == threadId }
        when (action) {
            Preferences.SWIPE_ACTION_DELETE -> {
                removeItem(threadId)
            }

            Preferences.SWIPE_ACTION_BLOCK -> {
                removeItem(threadId)
            }


            Preferences.SWIPE_ACTION_READ -> {
                if (conversation!!.lastMessage!!.read) {
                    conversation!!.makeUnread()
                } else {
                    conversation!!.makeRead()

                }
                notifyList(list)
            }

            Preferences.SWIPE_ACTION_UNREAD -> {
                if (conversation!!.lastMessage!!.read) {
                    conversation!!.makeUnread()
                } else {
                    conversation!!.makeRead()

                }
                notifyList(list)
            }
        }
    }

    fun updateData(dataMessage: RealmResults<Conversation>?) {
        if (dataMessage != null) {
            val arrayListOfUnmanagedObjects: List<Conversation> =
                Realm.getDefaultInstance().copyFromRealm(dataMessage)
            notifyList(arrayListOfUnmanagedObjects)
        }
    }

    private fun notifyList(arrayListOfUnmanagedObjects: List<Conversation>) {
        if (arrayListOfUnmanagedObjects.isNotEmpty()) {
            val list = ArrayList<ModelType>()
            list.addAll(arrayListOfUnmanagedObjects)
            /*   list.add(0, ConversationAD(0))
               if (list.size > 4) {
                   list.add(4, ConversationAD(4))
               }
               if (list.size > 8) {
                   list.add(8, ConversationAD(8))
               }*/
            asyncListDiffer.submitList(list)
        }
    }
}
