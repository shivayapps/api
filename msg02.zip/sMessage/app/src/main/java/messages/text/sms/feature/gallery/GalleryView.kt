package messages.text.sms.feature.gallery

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgView
import messages.text.sms.model.MmsPart

interface GalleryView : MainBaseMsgView<GalleryState> {

    fun optionsItemSelected(): Observable<Int>
    fun screenTouched(): Observable<*>
    fun pageChanged(): Observable<MmsPart>

    fun requestStoragePermission()

}