package messages.text.sms.common

//import com.uber.rxdogtag.RxDogTag
//import com.uber.rxdogtag.autodispose.AutoDisposeConfigurer
import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.core.content.res.ResourcesCompat
import androidx.core.provider.FontRequest
import androidx.emoji.text.EmojiCompat
import androidx.emoji.text.FontRequestEmojiCompatConfig
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDexApplication

import com.google.android.gms.ads.AdActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.perf.FirebasePerformance
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.realm.Realm
import io.realm.RealmConfiguration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import messages.text.sms.R
import messages.text.sms.ads.AdsPreferences
import messages.text.sms.ads.WelcomeBackActivity
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.ads.getAppResumeAppOpenId
import messages.text.sms.ads.isFirstTimeAppOpen
import messages.text.sms.ads.isInternetConnected
import messages.text.sms.common.util.CrashlyticsTree
import messages.text.sms.common.util.FileLoggingTree
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.feature.main.PermissionActivity
import messages.text.sms.feature.main.SplashActivity
import messages.text.sms.injection.AppComponentManager
import messages.text.sms.injection.appComponent
import messages.text.sms.manager.AnalyticsManager
import messages.text.sms.manager.ReferralManager
import messages.text.sms.migration.QkMigration
import messages.text.sms.migration.QkRealmMigration
import messages.text.sms.util.NightModeManager
import messenger.chat.text.messages.sms.ads.NetworkObserver
import timber.log.Timber
import java.util.Date
import javax.inject.Inject

var isAdsNotShowOnResume = false

var isAppForeground = false
var isAdsNotRequest = false
var isAdsShowOrNot = false

class MysmsApplication : MultiDexApplication(), HasAndroidInjector,
    Application.ActivityLifecycleCallbacks,
    DefaultLifecycleObserver {
    companion object {
        var qkApplicationContext: Context? = null
        var mEnterScreen = false
        var mOpenOverlayScreen = false
        var dataLoading: Boolean? = false
        var isAdsNotShowOnResume = false
        var isHomeInterShow = false
        var isAppOpenFlag = true
        lateinit var adsApplication: MysmsApplication

        lateinit var firebaseAnalytics: FirebaseAnalytics
    }


    private lateinit var appOpenAdManager: AppOpenAdManager
    private var currentActivity: Activity? = null
    var isAppOpenShowShow = false

    /**
     * Inject these so that they are forced to initialize
     */
    @Suppress("unused")
    @Inject
    lateinit var analyticsManager: AnalyticsManager

    @Suppress("unused")
    @Inject
    lateinit var qkMigration: QkMigration

    @Inject
    lateinit var fileLoggingTree: FileLoggingTree

    @Inject
    lateinit var nightModeManager: NightModeManager

    @Inject
    lateinit var realmMigration: QkRealmMigration

    @Inject
    lateinit var referralManager: ReferralManager


    @Inject
    lateinit var androidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector(): AndroidInjector<Any> = androidInjector
    override fun onCreate() {
        super<MultiDexApplication>.onCreate()

        qkApplicationContext = this

        adsApplication = applicationContext as MysmsApplication


        registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)

        NetworkObserver.initialize(adsApplication)

        FirebaseApp.initializeApp(this)
        FirebaseCrashlytics.getInstance().isCrashlyticsCollectionEnabled = true
        FirebasePerformance.getInstance()
        AppComponentManager.init(this)
        // Obtain the FirebaseAnalytics instance.
        firebaseAnalytics = FirebaseAnalytics.getInstance(applicationContext)

        appComponent.inject(this)

        Realm.init(this)
        Realm.setDefaultConfiguration(
            RealmConfiguration.Builder()
                .compactOnLaunch()
                .migration(realmMigration)
                .allowWritesOnUiThread(true)
                .schemaVersion(QkRealmMigration.SchemaVersion)
                .build()
        )


        appOpenAdManager = AppOpenAdManager()

        qkMigration.performMigration()

        if (isFirstTimeAppOpen()) {
            initializeCallerCard()
        }
        GlobalScope.launch(Dispatchers.IO) {
            referralManager.trackReferrer()
        }

        nightModeManager.updateCurrentTheme()

        val fontRequest = FontRequest(
            "com.google.android.gms.fonts",
            "com.google.android.gms",
            "Noto Color Emoji Compat",
            R.array.com_google_android_gms_fonts_certs
        )

        EmojiCompat.init(FontRequestEmojiCompatConfig(this, fontRequest))

        Timber.plant(Timber.DebugTree(), CrashlyticsTree(), fileLoggingTree)

    }

    fun intAdmobAds() {

        CoroutineScope(Dispatchers.IO).launch {
            try {
                MobileAds.initialize(adsApplication) {}
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }


        try {
            appOpenAdManager = AppOpenAdManager()
        } catch (_: Exception) {

        }
        /*   Handler(Looper.getMainLooper()).post {
               try {
                   registerActivityLifecycleCallbacks(this)
               } catch (e: Exception) {
                   Log.d("AppOpenAd", "registerActivityLifecycleCallbacks - $e")
               }

               try {
                   ProcessLifecycleOwner.get().lifecycle.addObserver(this)
               } catch (e: Exception) {
                   Log.d("AppOpenAd", "ProcessLifecycleOwner - $e")
               }
           }*/
    }

    fun initializeCallerCard() {

        intAdmobAds()
        try {

            val drawable = ResourcesCompat.getDrawable(
                applicationContext.resources,
                R.mipmap.ic_launcher,
                null
            )


            baseConfig.callFirstTime = true
        } catch (_: Exception) {
        }
    }


    /**
     * DefaultLifecycleObserver method that shows the app open ad when the app moves to foreground.
     */
    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        isAppForeground = true
        currentActivity?.let {
            // Show the ad (if available) when the app moves to foreground.
            if (isShowingAppOpen(it) && isShowingAppOpenOnResume(it) && currentActivity!!.isInternetConnected() && isAdAvailable() && !isAdsShowOrNot) {
                it.startActivity(Intent(this, WelcomeBackActivity::class.java))
            }
        }
    }


    override fun onStop(owner: LifecycleOwner) {
        super.onStop(owner)
        if (isAppForeground && !isAdAvailable()) {
            currentActivity?.let {
                if (isShowingAppOpen(it)) {

                    Log.d("LOG_TAG", "onStop - ")
                    loadAd(it, getAppResumeAppOpenId(), false)
                }
            }
        }
        isAppForeground = false
    }

    /** ActivityLifecycleCallback methods. */
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

    override fun onActivityStarted(activity: Activity) {
        // An ad activity is started when an ad is showing, which could be AdActivity class from Google
        // SDK or another activity class implemented by a third party mediation partner. Updating the
        // currentActivity only when an ad is not showing will ensure it is not an ad activity, but the
        // one that shows the ad.
        if (!appOpenAdManager.isShowingAd && activity !is AdActivity) {
            currentActivity = activity
        }
        if (activity !is MainActivity ||
             activity !is WelcomeBackActivity ||
             activity !is PermissionActivity ||
            activity !is SplashActivity
 //            activity !is AdActivity
         ) {
             mEnterScreen = true
        }

        /*   if (activity !is MainActivity &&
               activity !is WelcomeBackActivity &&
               activity !is PermissionActivity &&
               activity !is CallerCallerCardActivity
           ) {
               mEnterScreen = true
           }*/

    }

    override fun onActivityResumed(activity: Activity) {}

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {}
    fun isAdAvailable(): Boolean {
        return appOpenAdManager.isAdAvailable()
    }

    fun isLoadingAppOpen(): Boolean {


        if (::appOpenAdManager.isInitialized) {
            return appOpenAdManager.isLoadingAd
        } else {
            return false
        }

    }


    fun isAdShowing(): Boolean {
        return appOpenAdManager.isShowingAd
    }

    /**
     * Shows an app open ad.
     *
     * @param activity the activity that shows the app open ad
     * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
     */
    fun showAdIfAvailable(activity: Activity, onShowAdCompleteListener: OnShowAdCompleteListener) {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.


        appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener)
    }

    /**
     * Load an app open ad.
     *
     * @param activity the activity that shows the app open ad
     */
    fun loadAd(activity: Activity, adId: String, force: Boolean = false) {
        currentActivity = activity
        // We wrap the loadAd to enforce that other classes only interact with MyApplication
        // class.
        currentActivity?.let {

            // Show the ad (if available) when the app moves to foreground.
            if (force || (isShowingAppOpen(it) && activity.isInternetConnected())) {
                appOpenAdManager.loadAd(activity, adId)
            }
        }

    }

    /**
     * Interface definition for a callback to be invoked when an app open ad is complete (i.e.
     * dismissed or fails to show).
     */
    interface OnShowAdCompleteListener {
        fun onShowAdComplete()
    }

    override fun onTerminate() {
        super.onTerminate()
        appOpenAdManager.appOpenAd = null
    }

    /** Inner class that loads and shows app open ads. */
    private inner class AppOpenAdManager {

        var appOpenAd: AppOpenAd? = null
        var isLoadingAd = false
        var isShowingAd = false

        /** Keep track of the time an app open ad is loaded to ensure you don't show an expired ad. */
        private var loadTime: Long = 0

        /**
         * Load an ad.
         *
         * @param context the context of the activity that loads the ad
         */
        fun loadAd(context: Context, adId: String) {
            // Do not load ad if there is an unused ad or one is already loading.
            if (isLoadingAd || isAdAvailable() || !AdsPreferences(context).adsEnable) {
                return
            }

            isLoadingAd = true
            Log.d("LOG_TAG", "Request.")
            Log.d("LOG_TAG", "Request. adId - $adId")
            val request = AdRequest.Builder().build()
            AppOpenAd.load(
                context,
                adId,
                request,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    /**
                     * Called when an app open ad has loaded.
                     *
                     * @param ad the loaded app open ad.
                     */
                    override fun onAdLoaded(ad: AppOpenAd) {
                        appOpenAd = ad
                        isLoadingAd = false

                        loadTime = Date().time
                        Log.d("LOG_TAG", "onAdLoaded.")
                    }

                    /**
                     * Called when an app open ad has failed to load.
                     *
                     * @param loadAdError the error.
                     */
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        isLoadingAd = false
                        appOpenAd = null
                        loadTime = 0
                        Log.d("LOG_TAG", "onAdFailedToLoad: " + loadAdError.message)

                    }
                },
            )
        }

        /** Check if ad was loaded more than n hours ago. */
        private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
            val dateDifference: Long = Date().time - loadTime
            val numMilliSecondsPerHour: Long = 3600000
            return dateDifference < numMilliSecondsPerHour * numHours
        }

        /** Check if ad exists and can be shown. */
        fun isAdAvailable(): Boolean {
            // Ad references in the app open beta will time out after four hours, but this time limit
            // may change in future beta versions. For details, see:
            // https://support.google.com/admob/answer/9341964?hl=en
            return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
        }

        /**
         * Show the ad if one isn't already showing.
         *
         * @param activity the activity that shows the app open ad
         */
        fun showAdIfAvailable(activity: Activity) {
            showAdIfAvailable(
                activity,
                object : OnShowAdCompleteListener {
                    override fun onShowAdComplete() {
                        // Empty because the user will go back to the activity that shows the ad.
                    }
                },
            )
        }

        /**
         * Show the ad if one isn't already showing.
         *
         * @param activity the activity that shows the app open ad
         * @param onShowAdCompleteListener the listener to be notified when an app open ad is complete
         */
        fun showAdIfAvailable(
            activity: Activity,
            onShowAdCompleteListener: OnShowAdCompleteListener,
        ) {
            // If the app open ad is already showing, do not show the ad again.
            if (isShowingAd) {
                Log.d("LOG_TAG", "The app open ad is already showing.")
                return
            }

            // If the app open ad is not available yet, invoke the callback.
            if (!isAdAvailable()) {
                Log.d("LOG_TAG", "The app open ad is not ready yet.")
                onShowAdCompleteListener.onShowAdComplete()
                return
            }

            Log.d("LOG_TAG", "Will show ad.")

            appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                /** Called when full screen content is dismissed. */
                override fun onAdDismissedFullScreenContent() {
                    // Set the reference to null so isAdAvailable() returns false.
                    appOpenAd = null
                    isShowingAd = false
                    Log.d("LOG_TAG", "onAdDismissedFullScreenContent.")
                    onShowAdCompleteListener.onShowAdComplete()
                    isAppOpenShowShow = true
                    isAdsShowOrNot = false
                }

                /** Called when fullscreen content failed to show. */
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    appOpenAd = null
                    isShowingAd = false
                    Log.d("LOG_TAG", "onAdFailedToShowFullScreenContent: " + adError.message)
                    onShowAdCompleteListener.onShowAdComplete()
                    isAppOpenShowShow = false
                    isAdsShowOrNot = false

                }

                /** Called when fullscreen content is shown. */
                override fun onAdShowedFullScreenContent() {
                    Log.d("LOG_TAG", "onAdShowedFullScreenContent.")
                    isAppOpenShowShow = true
                    isAdsShowOrNot = true
                }

                override fun onAdClicked() {
                    super.onAdClicked()
//                    isAdsShowOrNot = true

                    isAdsNotShowOnResume = true
                }
            }
            isShowingAd = true
            appOpenAd?.show(activity)
        }


    }


    fun isShowingAppOpen(activity: Activity): Boolean {
        if (isAdsNotRequest) {
            Log.d("AppOpenCheck", "isAdsNotRequest is true, returning false")
            isAdsNotRequest = false
            return false
        }

        if (!AdsPreferences(activity).adsEnable) {
            Log.d("AppOpenCheck", "Ads are disabled in config, returning false")
            return false
        }

        if (activity is WelcomeBackActivity) {
            Log.d("AppOpenCheck", "Activity is WelcomeBackActivity, returning false")
            return false
        }

        if (activity is PermissionActivity) {
            Log.d("AppOpenCheck", "Activity is PermissionActivity, returning false")
            return false
        }
        if (activity is SplashActivity) {
            Log.d("AppOpenCheck", "Activity is PermissionActivity, returning false")
            return false
        }

        if (activity is AdActivity) {
            Log.d("AppOpenCheck", "Activity is AdActivity, returning false")
            return false
        }

        /* if (activity is SplashActivity) {
             Log.d("AppOpenCheck", "Activity is SplashActivity, returning false")
             return false
         }*/

        if (activity.intent.action.toString() == "fromNotification") {
            Log.d("AppOpenCheck", "Intent action is 'fromNotification', returning false")
            return false
        }

        // Default case
        Log.d("AppOpenCheck", "None of the conditions matched, returning true")
        return true

//        if (activity is OverlayPermissionActivityDialog) {
//            return false
//        }
//        if (activity is MoreAppsActivity) {
//            return false
//        }


        /*  if (activity is CallerCallerCardActivity) {
              return false
          }
          if (activity is CallerCallCardSettingsActivity) {
              return false
          }*/

        return true
    }

    fun isShowingAppOpenOnResume(activity: Activity): Boolean {
        if (isAdsNotShowOnResume) {
            isAdsNotShowOnResume = false
            return false
        }
        if (!isShowingAppOpen(activity)) {
            return false
        }

        if (!AdsPreferences(activity).adsEnable) {
            return false
        }
        return true
    }


}