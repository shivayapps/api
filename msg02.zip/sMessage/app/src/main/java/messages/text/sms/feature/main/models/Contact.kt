package messages.text.sms.feature.main.models

import android.os.Parcel
import android.os.Parcelable

class Contact() : Parcelable {

    public var name: String? = ""
    public var phone: String? = ""

    constructor(parcel: Parcel) : this() {
        name = parcel.readString()
        phone = parcel.readString()
    }

    constructor(name1: String, phone1: String) : this() {
        name = name1
        phone = phone1
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(phone)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Contact> {
        override fun createFromParcel(parcel: Parcel): Contact {
            return Contact(parcel)
        }

        override fun newArray(size: Int): Array<Contact?> {
            return arrayOfNulls(size)
        }
    }
}