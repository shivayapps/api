package messages.text.sms.feature.conversationinfo.injection

import dagger.Subcomponent
import messages.text.sms.feature.conversationinfo.ConversationInfoController
import messages.text.sms.injection.scope.ControllerScope

@ControllerScope
@Subcomponent(modules = [ConversationInfoModule::class])
interface ConversationInfoComponent {

    fun inject(controller: ConversationInfoController)

    @Subcomponent.Builder
    interface Builder {
        fun conversationInfoModule(module: ConversationInfoModule): Builder
        fun build(): ConversationInfoComponent
    }

}