package messages.text.sms.extensions

import android.util.Log
import messages.text.sms.BuildConfig


fun LogE(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.e(tag, msg)
}

fun LogW(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.w(tag, msg)
}

fun LogI(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.i(tag, msg)
}

fun LogD(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.d(tag, msg)
}

fun LogV(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.v(tag, msg)
}