package messages.text.sms.feature.main

import android.Manifest
import android.animation.ObjectAnimator
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.ItemTouchHelper
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import io.realm.RealmResults
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.autoScrollToStart
import messages.text.sms.common.util.extensions.dismissKeyboard
import messages.text.sms.common.util.extensions.resolveThemeColor
import messages.text.sms.common.util.extensions.scrapViews
import messages.text.sms.common.util.extensions.setBackgroundTint
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.common.widget.QkDialog
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.config
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.commons.tablayout.tintDrawableColor
import messages.text.sms.databinding.ConversationsPickerActivityBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.extensions.anyOf
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.feature.compose.editing.PhoneNumberPickerAdapter
import messages.text.sms.feature.contacts.ContactsActivity.Companion.ChipsKey
import messages.text.sms.feature.contacts.GroupsActivity
import messages.text.sms.feature.conversations.ConversationItemTouchCallback
import messages.text.sms.feature.conversations.ConversationsPickerAdapter
import messages.text.sms.feature.conversations.SelectContact
import messages.text.sms.feature.main.models.Contact
import messages.text.sms.model.ContactData
import messages.text.sms.model.ContactGroup
import messages.text.sms.model.Conversation
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.PICKED_CONVERSION
import messages.text.sms.model.REFRESH_ARCHIVE
import messages.text.sms.model.THEME_CHANGED
import messages.text.sms.repository.SyncRepository
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject


class ConversationsPickerActivity : MainBaseThemedActivity(), MainView {
    private val binding by viewBinding(ConversationsPickerActivityBinding::inflate)
//    lateinit var binding :MainActivityBinding

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var disposables: CompositeDisposable

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var conversationsAdapter: ConversationsPickerAdapter

    @Inject
    lateinit var drawerBadgesExperiment: DrawerBadgesExperiment

    @Inject
    lateinit var searchAdapter: SearchAdapter

    @Inject
    lateinit var itemTouchCallback: ConversationItemTouchCallback

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory


    //    var contacts: List<ContactData>? = null
//    var recentContacts: List<ContactData>? = null
//    var contactGroups: List<ContactGroup>? = null
    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()
    override val queryConversationChangedIntent by lazy { binding.messageTab.toolbarSearch.textChanges() }
    override val composeIntent by lazy { binding.messageTab.compose.clicks() }

    //    override val drawerOpenIntent: Observable<Boolean> by lazy {
//        binding.drawerLayout
//            .drawerOpen(Gravity.START)
//            .doOnNext { dismissKeyboard() }
//    }
    override val homeIntent: Subject<Unit> = PublishSubject.create()
    override val navigationIntent: Observable<NavItem> by lazy {
        Observable.merge(
            listOf(
                backPressedSubject,
//                binding.ivCaller.clicks().map { NavItem.SETTINGS },
//                binding.drawer.inbox.clicks().map { NavItem.INBOX },
//                binding.messageTab.archived.clicks().map { NavItem.ARCHIVED },
//                binding.drawer.backup.clicks().map { NavItem.BACKUP },
//                binding.drawer.scheduled.clicks().map { NavItem.SCHEDULED },
//                binding.drawer.blocking.clicks().map { NavItem.BLOCKING },
//                binding.drawer.settings.clicks().map { NavItem.SETTINGS },
//                 binding.drawer.plus.clicks().map { NavItem.PLUS },
//                 binding.drawer.help.clicks().map { NavItem.HELP },
//                binding.drawer.invite.clicks().map { NavItem.INVITE }
            )
        )
    }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()

    //    override val dismissRatingIntent by lazy { binding.drawer.rateDismiss.clicks() }
//    override val rateIntent by lazy { binding.drawer.rateOkay.clicks() }
    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val swipeConversationIntent by lazy { itemTouchCallback.swipes }
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val refreshArchive: Subject<Unit> = PublishSubject.create()
    override val refreshMessages: Subject<Unit> = PublishSubject.create()
    override val refreshBlocked: Subject<Unit> = PublishSubject.create()

    //    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.contactTab.searchContact.textChanges() }
//    override val queryClearedIntent: Observable<*> by lazy { binding.contactTab.cancel.clicks() }
//    override val queryEditorActionIntent: Observable<Int> by lazy { binding.contactTab.searchContact.editorActions() }
    override val queryChangedIntent: Observable<CharSequence> get() = PublishSubject.create<CharSequence>()
    override val queryClearedIntent: Observable<*> get() = PublishSubject.create<Unit>()
    override val queryEditorActionIntent: Observable<Int> get() = PublishSubject.create<Int>()

    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()
    override val composeItemPressedIntent: Subject<ContactData> = PublishSubject.create()
    override val composeItemLongPressedIntent: Subject<ContactData> = PublishSubject.create()

    override val setAsDefaultClick by lazy { binding.messageTab.snackbar.btnSetDefault.clicks() }

    private val viewModel by lazy {
        ViewModelProviders.of(
            this,
            viewModelFactory
        )[MainViewModel::class.java]
    }
    private val itemTouchHelper by lazy { ItemTouchHelper(itemTouchCallback) }
    private val progressAnimator by lazy {
        ObjectAnimator.ofInt(
            binding.messageTab.syncing.syncingProgress,
            resources.getString(R.string.progress),
            0,
            0
        )
    }
    private val backPressedSubject: Subject<NavItem> = PublishSubject.create()
//    private var isSnackBarClosed = false

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter
    private val phoneNumberDialog by lazy {
        QkDialog(this).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }

        }
    }

    var mScreenfrom = ""
    val addList: ArrayList<Conversation> = ArrayList<Conversation>()
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding=MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel.bindView(this)
        onNewIntentIntent.onNext(intent)
        setSupportActionBar(binding.toolbar)

        binding.messageTab.compose.beGone()

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

//        isHomeBackClick = false
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this)

        config.saveData("checkfirst", true)

        mScreenfrom = intent.getStringExtra("from").toString()





        title = resources.getString(R.string.conversations)

        itemTouchCallback.adapter = conversationsAdapter
        conversationsAdapter.autoScrollToStart(binding.messageTab.recyclerView)

        binding.messageTab.snackbar.llDefault.background = backgroundchange()
        binding.messageTab.snackbar.root.beGone()
        binding.messageTab.syncing.root.beGone()



        showBackButton(true)


        // Set the theme color tint to the recyclerView, progressbar, and FAB
        theme
            .autoDisposable(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated)
                )

                resolveThemeColor(android.R.attr.textColorSecondary)
                    .let { textSecondary ->
                        ColorStateList(
                            states,
                            intArrayOf(theme.theme, textSecondary)
                        )
                    }
                    .let { tintList ->
//                        binding.drawer.inboxIcon.imageTintList = tintList
                        binding.messageTab.archivedIcon.imageTintList = tintList
                    }

                // Miscellaneous views
//                listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//                    badge.setBackgroundTint(theme.theme)
//                    badge.setTextColor(theme.textPrimary)
//                }
                binding.messageTab.syncing.syncingProgress.progressTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.syncing.syncingProgress.indeterminateTintList =
                    ColorStateList.valueOf(theme.theme)
                binding.messageTab.compose.setBackgroundTint(theme.theme)
//                binding.messageTab.compose.setTint(theme.textPrimary)

                binding.messageTab.compose.imageTintList = ColorStateList.valueOf(theme.textPrimary)
            }

        viewModel.newState {
            val conv = conversationRepo.getOnlyConversations()
            copy(page = Archived(data = conv)) // filter later during use
        }

        setUpTheme()




        binding.messageTab.rlToolbar.visibility = View.GONE

        conversationsAdapter.selectContact = object : SelectContact {
            override fun selectContact(contact: Conversation, add: Boolean) {
                if (contact.recipients.size == 1) {
                    if (add) {
                        addList.add(contact)
                    } else {
                        addList.remove(contact)
                    }
                }
            }
        }


//        binding.addContacts.backgroundTintList = ColorStateList.valueOf(baseConfig.primaryColor)
        binding.addContacts.tintDrawableColor(baseConfig.primaryColor)

        binding.addContacts.setOnClickListener {


            if (addList.isNotEmpty()) {
                if (mScreenfrom == "private") {
                    val savedContactString = addList.joinToString(",") { it.getTitle() }

                    if (baseConfig.privateContactsList.isEmpty()) {
                        baseConfig.privateContactsList = savedContactString
                    } else {
                        baseConfig.privateContactsList =
                            baseConfig.privateContactsList + "," + savedContactString
                    }

                    for (item in addList) {
                        setPrivate(item.id)
                    }

                    finish()
                } else if (mScreenfrom == "block") {
                    Log.d("BlockScreen", "Screen is in 'block' mode")

                    val existingList = baseConfig.blockContactsList
                    val finalList: ArrayList<Contact> = ArrayList()
                    Log.d("BlockScreen", "Existing blocked contacts: ${existingList.size}")

                    val newContacts = addList.mapNotNull {
                        val recipient = it.recipients.getOrNull(0)
                        val name = recipient?.contact?.name
                        val address = recipient?.address?.trim()

                        Log.d("BlockScreen", "Processing contact - Name: $name, Address: $address")

                        if (!address.isNullOrEmpty()) {
                            val normalizedPhone = address.replace("[^0-9]".toRegex(), "")
                            /* val isAlreadyBlocked = existingList.any { contact ->
                                 val existingPhone = contact.phone?.replace("[^0-9]".toRegex(), "")
                                 existingPhone?.takeLast(9) == normalizedPhone.takeLast(9)
                             }*/
                            val isAlreadyBlocked = existingList.any { contact ->
                                val existingPhone = contact.phone?.replace("[^0-9]".toRegex(), "")
                                existingPhone == normalizedPhone
                            }


                            Log.d(
                                "BlockScreen",
                                "Normalized phone: $normalizedPhone, Already blocked: $isAlreadyBlocked"
                            )

                            if (!isAlreadyBlocked) {
                                Log.d("BlockScreen", "Adding new contact: $name, $normalizedPhone")

                                if (name.isNullOrEmpty()) {

                                    finalList.add(Contact(address, address))

                                } else {
                                    finalList.add(Contact(name, normalizedPhone))
                                }
                            } else {
                                Log.d(
                                    "BlockScreen",
                                    "Skipping already blocked contact: $normalizedPhone"
                                )
                                null
                            }
                        } else {
                            Log.d("BlockScreen", "Address is empty or null, skipping contact")
                            null
                        }
                    }

                    Log.d("BlockScreen", "New contacts to add: ${newContacts.size}")
                    existingList.addAll(finalList)
                    baseConfig.blockContactsList = existingList

                    for (item in addList) {
                        Log.d("BlockScreen", "Blocking conversation ID: ${item.id}")
                        setBlock(item.id)
                    }

                    Log.d(
                        "BlockScreen",
                        "Posting event with total blocked contacts: ${existingList.size}"
                    )
                    EventBus.getDefault().post(MessageEvent(PICKED_CONVERSION, finalList))

                    Log.d("BlockScreen", "Finishing activity")
                    finish()
                }


            } else {
                Toast.makeText(
                    this,
                    getString(R.string.please_select_conversations), Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    fun setPrivate(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds)
                .findAll()

            realm.executeTransaction {
                conversations.forEach { it.isPrivate = true }
            }

            realm.close()
        }
    }

    fun setBlock(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversations = realm.where(Conversation::class.java)
                .anyOf("id", threadIds)
                .findAll()

            realm.executeTransaction {
                conversations.forEach {
                    it.blocked = true
                    it.isPrivate = false
                    it.archived = false
                    it.blockingClient = 0
                    it.blockReason = ""
                }
            }

            realm.close()
        }
    }

    private fun setUpTheme() {


        val primaryColorWithAlpha =
            ColorUtils.setAlphaComponent(baseConfig.primaryColor, (255 * 0.1).toInt())
        val textColorPrimaryss = baseConfig.textColor
        val colorWithAlpha = textColorPrimaryss.addAlpha(0.6F)

        binding.messageTab.toolbarSearch.setBackgroundTint(primaryColorWithAlpha)
        binding.messageTab.toolbarSearch.setHintTextColor(colorWithAlpha)


        updateTextColors(binding.contentView)
        //  binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }


    fun backgroundchange(): GradientDrawable {
        val drawable = GradientDrawable()
        drawable.shape = GradientDrawable.RECTANGLE
        val colorWithOpacity = baseConfig.primaryColor

        val colorWith20Opacity =
            colorWithOpacity.let { ColorUtils.setAlphaComponent(it, 20) } // 51 is 20% of 255

//                val colorWith20Opacity = Color.argb(51, Color.red(colorWithOpacity), Color.green(colorWithOpacity), Color.blue(colorWithOpacity))
        if (colorWith20Opacity != null) {
            drawable.setColor(colorWith20Opacity)
        }
        val strokeWidthInDp = 1.0f
        val strokeWidthInPixels =
            (strokeWidthInDp * resources?.displayMetrics!!.density + 0.5f).toInt()
        baseConfig.let { drawable.setStroke(strokeWidthInPixels, it.primaryColor) }
        val cornerRadius =
            resources?.getDimension(R.dimen.normal_text_size)
        if (cornerRadius != null) {
            drawable.cornerRadius = cornerRadius
        }
        return drawable
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.run(onNewIntentIntent::onNext)
    }

    var addContact = false
    var markPinned = false
    var markRead = false
    var selectedConversations = 0
    var currentPage: MainPage = Inbox()
    override fun render(state: MainState) {
        if (state.hasError) {
            Log.e("render", "MainActivity:render.hasError:${state.hasError}")
            finish()
            return
        }
        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name

            phoneNumberDialog.window?.setBackgroundDrawableResource(R.drawable.rounded_dialog)
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
        currentPage = state.page
        addContact = when (state.page) {
            is Inbox -> state.page.addContact
            is Archived -> state.page.addContact
            else -> false
        }

        markPinned = when (state.page) {
            is Inbox -> state.page.markPinned
            is Archived -> state.page.markPinned
            else -> false
        }

        markRead = when (state.page) {
            is Inbox -> state.page.markRead
            is Archived -> state.page.markRead
            else -> true
        }

        selectedConversations = when (state.page) {
            is Inbox -> state.page.selected
            is Archived -> state.page.selected
            else -> 0
        }

//        binding.toolbarSearch.setVisible(state.page is Inbox && state.page.selected == 0 || state.page is Searching)
//        binding.toolbarTitle.setVisible(binding.toolbarSearch.visibility != View.VISIBLE)

        /* if(selectedConversations == 0){
             binding.addContacts.visibility = View.GONE
         }else{
             binding.addContacts.visibility = View.VISIBLE
         }*/
//        binding.compose.setVisible(state.page is Inbox || state.page is Archived)
        conversationsAdapter.emptyView =
            binding.messageTab.empty.takeIf { state.page is Inbox || state.page is Archived }
        searchAdapter.emptyView = binding.messageTab.empty.takeIf { state.page is Searching }

        when (state.page) {
            /* is Inbox -> {
              //   binding.messageTab.llArchive.isVisible = (state.page.archiveMessages ?: 0) > 0
                 binding.messageTab.llArchive.isVisible = false
                 binding.messageTab.llArchive.visibility = View.GONE

 //                binding.messageTab.llArchive.layoutParams = CoordinatorLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)

                 binding.messageTab.archiveCount.text = state.page.archiveMessages.toString()
                 binding.messageTab.compose.beVisible()
 //                showBackButton(false)
 //                binding.messageTab.toolbar.setNavigationIcon(null)
 //                title = getString(R.string.main_title_selected, state.page.selected)
 //                setTitle(getString(R.string.main_title_selected, state.page.selected))
                 if (state.page.selected > 0) {
                     setTitle(getString(R.string.main_title_selected, state.page.selected))

                     setCommonData(
                         showBottomAction = true
                     )
                 } else {
                     setCommonData(
                         showBottomAction = false
                     )
                     setTitle(getString(R.string.messages))
 //                    showBackButton(false)
                 }
                 setConversationAdapter(
                     state.page.data,
                     state.page.selected > 0,
                     R.string.inbox_empty_text,
                     true
                 )
                 Log.e("MainActivity", "render: Inbox ${state.page.data}")
                 Log.e("MainActivity", "render: archiveMessages ${state.page.archiveMessages}")
             }*/

            is Searching -> {
//                showBackButton(false)
//                binding.messageTab.toolbar.setNavigationIcon(null)
                if (binding.messageTab.recyclerView.adapter !== searchAdapter) binding.messageTab.recyclerView.adapter =
                    searchAdapter
                searchAdapter.data = state.page.data ?: listOf()
                itemTouchHelper.attachToRecyclerView(null)
                binding.messageTab.emptyText.setText(R.string.inbox_search_empty_text)
            }

            is Archived -> {
                binding.messageTab.llArchive.beGone()
                binding.messageTab.compose.beGone()

//                binding.messageTab.llArchive.layoutParams = CoordinatorLayout.LayoutParams(MATCH_PARENT, 0)

                when (state.page.selected != 0) {
                    true -> {
//                        getString(R.string.main_title_selected, state.page.selected)
                        title = getString(
                            R.string.main_title_selected,
                            state.page.selected
                        )
                    }

                    false -> {
                        title = resources.getString(R.string.conversations_list)
                    }
                }
                setConversationAdapter(
                    state.page.data,
                    true,
                    R.string.archived_empty_text,
                    false
                )
            }

            else -> {

            }
        }

        when (state.syncing) {
            is SyncRepository.SyncProgress.Idle -> {

            }

            is SyncRepository.SyncProgress.Running -> {
                binding.messageTab.syncing.syncingProgress.max = state.syncing.max
                progressAnimator.apply {
                    setIntValues(
                        binding.messageTab.syncing.syncingProgress.progress,
                        state.syncing.progress
                    )
                }.start()
                binding.messageTab.syncing.syncingProgress.isIndeterminate =
                    state.syncing.indeterminate
            }
        }

    }


    private fun setConversationAdapter(
        data: RealmResults<Conversation>?,
        backVisible: Boolean,
        inboxEmptyText: Int,
        isTouchHelper: Boolean,
    ) {
        if (binding.messageTab.recyclerView.adapter !== conversationsAdapter) {
            binding.messageTab.recyclerView.apply {
                adapter = conversationsAdapter
            }
        }
        conversationsAdapter.updateData(data)
        itemTouchHelper.attachToRecyclerView(if (isTouchHelper) if (backVisible) null else binding.messageTab.recyclerView else null)
        binding.messageTab.emptyText.text = resources.getString(inboxEmptyText)
        binding.messageTab.recyclerView.post {
            if (conversationsAdapter.data?.isNotEmpty() == true) {
                binding.messageTab.empty.visibility = View.GONE
            } else {
                binding.messageTab.empty.visibility = View.VISIBLE
            }
        }
//        showBackButton(backVisible)
    }

    override fun onResume() {
        super.onResume()
        activityResumedIntent.onNext(true)
    }

    override fun onPause() {
        super.onPause()
        activityResumedIntent.onNext(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
        if (EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().unregister(this)
    }


    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@ConversationsPickerActivity)
    }

    override fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
        binding.messageTab.toolbarSearch.text = null
    }

    override fun clearSelection() {
        conversationsAdapter.clearSelection()
    }


    override fun themeChanged() {
        binding.messageTab.recyclerView.scrapViews()
        EventBus.getDefault().post(MessageEvent(THEME_CHANGED))
    }

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        AlertDialog.Builder(this, R.style.CustomFieldDialogTheme)
            .setTitle(R.string.dialog_delete_title)
            .setMessage(
                resources.getQuantityString(
                    R.plurals.dialog_delete_message,
                    count,
                    count
                )
            )
            .setPositiveButton(R.string.button_delete) { _, _ ->
                confirmDeleteIntent.onNext(
                    conversations
                )
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }


    override fun showArchivedSnackbar() {
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }

            else -> {
                //  optionsItemIntent.onNext(item.itemId)
                return true
            }
        }

    }


    override fun onBackPressed() {
        if (conversationsAdapter.selection.isNotEmpty()) {
            clearSelection()
        } else {
            finish()
        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        /*  when (event.type) {
              REFRESH_MESSAGE -> {
                  Log.e("onMessageEvent", "REFRESH_MESSAGE")

                  viewModel.refreshMessages()
              }


          }*/

    }

    override fun clearQuery() {
//        binding.contactTab.searchContact.text = null
    }

    override fun refreshArchive() {
        EventBus.getDefault().post(MessageEvent(REFRESH_ARCHIVE))
    }

    override fun refreshBlockedList() {
//        EventBus.getDefault().post(MessageEvent(REFRESH_ARCHIVE))
    }


    override fun openKeyboard() {
//        binding.contactTab.searchContact.postDelayed({
//            binding.contactTab.searchContact.showKeyboard()
//        }, 200)
    }

    override fun finish(result: HashMap<String, String?>) {
//        binding.contactTab.searchContact.hideKeyboard()
        val intent =
            Intent(this@ConversationsPickerActivity, ComposeActivity::class.java).putExtra(
                ChipsKey,
                result
            )
        startActivity(intent)
//        finish()
    }

    fun onContactClick(contact: ContactData) {
        composeItemPressedIntent.onNext(contact)
    }

    fun onContactLongClick(contact: ContactData) {
        composeItemLongPressedIntent.onNext(contact)
    }

    fun onContactGroupClick(contact: ContactGroup) {
        startActivity(
            Intent(this, GroupsActivity::class.java).putExtra("groupId", contact.id)
                .putExtra("groupName", contact.title)
        )
    }


}


