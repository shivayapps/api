package messages.text.sms.appmanager

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.util.LruCache
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import java.util.Collections
import java.util.Locale

class LauncherViewModel : ViewModel() {

    // Simple LruCache for icons, size 100 means it can hold up to 100 Drawables.
    // Adjust size based on your app's memory constraints and typical number of apps.
    private val iconCache = LruCache<String, Drawable>(100)

    fun retrieveInstalledApps(context: Context, listener: (List<AppModel>) -> Unit) {
        val packageManager = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null)
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)

        // Use viewModelScope if this class extends ViewModel, otherwise pass a CoroutineScope
        viewModelScope.launch(Dispatchers.IO) {
            val appList = packageManager.queryIntentActivities(mainIntent, 0)
            Collections.sort(appList, ResolveInfo.DisplayNameComparator(packageManager))

            val installedApps = mutableListOf<AppModel>()

            for (resolveInfo in appList) {
                // Filter out system apps that are not updated by the user
                if (resolveInfo.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM == 0 ||
                    resolveInfo.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP != 0
                ) {
                    try {
                        val packageInfo =
                            packageManager.getPackageInfo(resolveInfo.activityInfo.packageName, 0)

                        val appModel = AppModel(
                            packageManager.getApplicationLabel(resolveInfo.activityInfo.applicationInfo)
                                .toString(),
                            resolveInfo.activityInfo.packageName,
                            packageInfo.versionCode,
                            packageInfo.versionName ?: "", // Handle null versionName
                            loadAppIcon(
                                context,
                                resolveInfo.activityInfo.packageName,
                                packageManager
                            )
                        )
                        installedApps.add(appModel)
                    } catch (e: PackageManager.NameNotFoundException) {
                        // Log this error if a package listed by queryIntentActivities somehow isn't found
                        // This should be rare but good for robustness
                        e.printStackTrace()
                    }
                }
            }

            // Sort apps by name on the background thread
            val sortedApps = installedApps.sortedBy { it.appName.lowercase(Locale.getDefault()) }

            withContext(Dispatchers.Main) {
                listener.invoke(sortedApps) // Call listener on the main thread
            }
        }
    }

    private suspend fun loadAppIcon(
        context: Context,
        packageName: String,
        packageManager: PackageManager,
    ): Drawable? {
        return withContext(Dispatchers.IO) {
            // Check cache first
            iconCache.get(packageName)?.let {
                it // Return from cache if available
            } ?: run {
                // If not in cache, load and then put in cache
                val icon = try {
                    packageManager.getApplicationIcon(packageName)
                } catch (e: PackageManager.NameNotFoundException) {
                    ContextCompat.getDrawable(context, R.drawable.manage_apps) // Fallback icon
                }
                if (icon != null) {
                    iconCache.put(packageName, icon)
                }
                icon
            }
        }
    }

    /**
     * Return the launcher activity intent for the given package
     * @param context - context
     * @param packageName - package name of the app
     *
     * @return launcher intent
     */
    fun getLauncherIntent(context: Context, packageName: String): Intent? {
        return context.packageManager.getLaunchIntentForPackage(packageName)
    }
}