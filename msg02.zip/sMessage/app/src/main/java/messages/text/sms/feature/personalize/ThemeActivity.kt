package messages.text.sms.feature.personalize

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.yalantis.ucrop.UCrop
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.ads.app_theme_activity_open
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.adapters.ColorAdapter
import messages.text.sms.commons.extensions.applyColorFilter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.getItemBackgroundColor
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityThemeBinding
import messages.text.sms.util.StringManager
import java.io.File

class ThemeActivity : MainBaseThemedActivity() {
    private lateinit var stringManager: StringManager

    companion object {
        private const val RC_CROP_IMAGE = 102

    }

    private val binding by viewBinding(ActivityThemeBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)


        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector);

        showBackButton(true)
        setTitle(R.string.themes)
        stringManager = StringManager(this)

        setUI()
        setUpTheme()
        setUpListener()

        firebaseAnalyticsHandler.logMessages(
            app_theme_activity_open, getActivityName()
        )
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        //    binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        binding.apply {
            /*  arrayOf(
                  classicLabel,
                  seasonLabel,
              ).forEach {
                  it.setTextColor(getProperPrimaryColor())
              }*/

            arrayOf(
                binding.settingsColorCustomizationHolder,
                binding.userCustomizationHolder,
                binding.countryHolder,
                binding.settingsImageCustomizationHolder
            ).forEach {
                //   it.background.applyColorFilter(getBottomNavigationBackgroundColor())
                if (baseConfig.useImageResource == true) {
                    if (baseConfig.storedImageResource == -1) {

                    } else {
                        it.background.applyColorFilter(resources.getColor(R.color.transperent70))
                    }
                } else {
                    it.background.applyColorFilter(getItemBackgroundColor())

                }
            }
        }

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            /*  arrayListOf(binding.ivBack).forEach {
                  val colorStateList = ColorStateList.valueOf(Color.WHITE)
                  it.imageTintList = colorStateList
              }*/
        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)
            /*  arrayListOf(binding.ivBack).forEach {
  //                val whiteColor = ContextCompat.getColor(this, R.color.black)
                  val colorStateList = ColorStateList.valueOf(Color.BLACK)
                  it.imageTintList = colorStateList
              }*/
        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }


    private fun setUI() {

        val colorList = listOf(
            Color.parseColor("#2569F1"),
            Color.parseColor("#00A11F"),
            Color.parseColor("#FF6E96"),
            Color.parseColor("#FF9C00"),
            Color.parseColor("#FE7D68"),
            Color.parseColor("#2F3F83"),
            Color.parseColor("#0183C9"),
            Color.parseColor("#000000"),
        )
        val itemList = listOf(
            getString(R.string.blue),
            getString(R.string.green),
            getString(R.string.pink),
            getString(R.string.yellow),
            getString(R.string.oral),
            getString(R.string.navy_blue),
            getString(R.string.cerulean_blue),
            getString(R.string.black_blue),
        )

        binding.rvClassic.layoutManager = GridLayoutManager(this, 4)
        val myAdapter =
            ColorAdapter(
                prefs,
                itemList,
                colorList,
                this,
                object : ColorAdapter.OnItemClickListener {
                    override fun onItemClick(position: Int, color: Int, name: String) {


                        val intent = Intent(this@ThemeActivity, ThemePreviewActivity::class.java)
                        intent.putExtra("color", color)
                        intent.putExtra("position", position)
                        intent.putExtra("c_name", name)
                        startActivity(intent)
//                    finish()
                    }
                })

        binding.rvClassic.adapter = myAdapter


//           val listOfTheme = stringManager.getSavedThemeBitmaps()
//
//
//           if(listOfTheme.isEmpty()){
//
//               binding.firstPicker.visibility = View.VISIBLE
//               binding.userCustomizationHolder.visibility = View.GONE
//           }else{
//
//               binding.firstPicker.visibility = View.GONE
//               binding.userCustomizationHolder.visibility = View.VISIBLE
//
//               binding.rvCustom.layoutManager = GridLayoutManager(this, 4)
//               val myCustomImageAdapter =
//                   CustomImageAdapter(
//                       prefs,
//                       listOfTheme,
//                       this,
//                       object : CustomImageAdapter.OnItemClickListener {
//                           override fun onItemClick(position: Int, color: Int, name: String) {
//                               when(position){
//                                   0 -> {
//
//                                   }
//                                   else -> {
//                                       val intent = Intent(this@ThemeActivity, ThemePreviewActivity::class.java)
//                                       intent.putExtra("color", color)
//                                       intent.putExtra("position", position)
//                                       intent.putExtra("c_name", name)
//                                       startActivity(intent)
//                                   }
//                               }
//                           }
//                       })
//
//               binding.rvCustom.adapter = myCustomImageAdapter
//           }


        hideAllItems()

        when (prefs.selectedThemeNo.get()) {
            9 -> showItem(binding.item9, binding.item9Bg, binding.item9O)
            10 -> showItem(binding.item10, binding.item10Bg, binding.item10O)
            11 -> showItem(binding.item11, binding.item11Bg, binding.item11O)
            12 -> showItem(binding.item12, binding.item12Bg, binding.item12O)
            13 -> showItem(binding.selectChina, binding.selectChinaBg, binding.selectChinaO)
            14 -> showItem(binding.selectEgypt, binding.selectEgyptBg, binding.selectEgyptO)
            15 -> showItem(binding.selectEngland, binding.selectEnglandBg, binding.selectEnglandO)
            16 -> showItem(binding.selectFrance, binding.selectFranceBg, binding.selectFranceO)
            17 -> showItem(binding.selectIndia, binding.selectIndiaBg, binding.selectIndiaO)
            18 -> showItem(binding.selectJapan, binding.selectJapanBg, binding.selectJapanO)
            19 -> showItem(binding.selectRussia, binding.selectRussiaBg, binding.selectRussiaO)
            20 -> showItem(binding.selectUSA, binding.selectUSABg, binding.selectUSAO)
        }
    }

    fun showItem(view: ImageView, view1: ImageView, view2: ImageView) {
        view.visibility = View.VISIBLE
        view1.visibility = View.VISIBLE
        view2.visibility = View.VISIBLE
        view.setColorFilter(baseConfig.primaryColor)
    }

    fun hideAllItems() {
        listOf(
            binding.item9, binding.item10, binding.item11, binding.item12,
            binding.item9Bg, binding.item10Bg, binding.item11Bg, binding.item12Bg,
            binding.item9O, binding.item10O, binding.item11O, binding.item12O,
            binding.selectChina, binding.selectEgypt, binding.selectEngland,
            binding.selectFrance, binding.selectIndia, binding.selectJapan,
            binding.selectRussia, binding.selectUSA,
            binding.selectChinaBg, binding.selectEgyptBg, binding.selectEnglandBg,
            binding.selectFranceBg, binding.selectIndiaBg, binding.selectJapanBg,
            binding.selectRussiaBg, binding.selectUSABg,
            binding.selectChinaO, binding.selectEgyptO, binding.selectEnglandO,
            binding.selectFranceO, binding.selectIndiaO, binding.selectJapanO,
            binding.selectRussiaO, binding.selectUSAO
        ).forEach { it.visibility = View.GONE }
    }


    private fun setUpListener() {
        fun setClickListener(view: View, imageRes: Int, countryName: String) {
            view.setOnClickListener {
                val intent = Intent(this, ThemeImagePreviewActivity::class.java).apply {
                    putExtra("imageResource", imageRes)
                    putExtra("c_name", countryName)
                }
                startActivity(intent)
            }
        }

        setClickListener(binding.llspring, R.drawable.bluw_bg, "Th1")
        setClickListener(binding.llautumn, R.drawable.orange_bg, "Th2")
        setClickListener(binding.llsummer, R.drawable.green_bg, "Th3")
        setClickListener(binding.llwinter, R.drawable.blue_bg, "Th3")

//        setClickListener(binding.llChina, R.drawable.china_bg, "China")
//        setClickListener(binding.llEgypt, R.drawable.egypt_bg, "Egypt")
//        setClickListener(binding.llEngland, R.drawable.england_bg, "England")
//        setClickListener(binding.llFrance, R.drawable.france_bg, "France")
//        setClickListener(binding.llIndia, R.drawable.india_bg, "India")
//        setClickListener(binding.llJapan, R.drawable.japan_bg, "Japan")
//        setClickListener(binding.llRussia, R.drawable.russia_bg, "Russia")
//        setClickListener(binding.llUSA, R.drawable.usa_bg, "USA")


        binding.firstPicker.setOnClickListener {
            pickMediaLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }

    private val pickMediaLauncher =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) {
//            Toast.makeText(this@ThemeActivity, "Exif Rotation: ${getExifOrientation(this@ThemeActivity, uri)}", Toast.LENGTH_SHORT).show()
                //  binding.brieImageCropper.load(uri)

                /* val intent = Intent(this@ThemeActivity, CropImageThemeActivity::class.java)
                 intent.putExtra("uri", uri)
                 startActivity(intent)*/


                var destinationFileName: String = "custom_theme_" + System.currentTimeMillis()

                destinationFileName += ".jpg"
                UCrop.of(uri, Uri.fromFile(File(cacheDir, destinationFileName)))
                    .withAspectRatio(9F, 16F)
                    .start(this)


                //      binding.firstPicker.setImageURI(uri)
            }
        }

    override fun onResume() {
        super.onResume()
        if (prefs.themechanged.get()) {
            setUpTheme()
            setUI()
        }
        try {
            window.statusBarColor =
                ContextCompat.getColor(this@ThemeActivity, baseConfig.statusBarColor)
        } catch (e: Exception) {
        }

    }

    override fun onBackPressed() {

        if (clientConfigPref.enableBackPressInter && !isHomeInterShow) {
            Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")

            MainInterAdManager.showMainInterAds(this) {
                Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                isHomeInterShow = true
                finish()
            }

        } else {
            Log.e("Message_Log", "enable_back_press_inter - finish")
            finish()
        }
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            val resultUri = UCrop.getOutput(data!!)
            val intent = Intent(this@ThemeActivity, CropImageThemeActivity::class.java)
            intent.putExtra("uri", resultUri)
            startActivity(intent)

        } else if (resultCode == UCrop.RESULT_ERROR) {
            val cropError = UCrop.getError(data!!)
        }
    }

}