package messages.text.sms.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import androidx.appcompat.widget.SwitchCompat
import androidx.core.graphics.ColorUtils
import messages.text.sms.R
import messages.text.sms.common.util.Colors
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.injection.appComponent
import messages.text.sms.model.MessageEvent
import messages.text.sms.model.THEME_CHANGED
import messages.text.sms.util.Preferences
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject

class QkSwitch @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : SwitchCompat(context, attrs) {

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var prefs: Preferences

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        if (!isInEditMode) {

            val states = arrayOf(
                intArrayOf(-android.R.attr.state_checked),
                intArrayOf(android.R.attr.state_checked)
            )

            val thumbColors = intArrayOf(
                context.getColor(R.color.icon_tint),  // Gray color for unselected state
                context.baseConfig.primaryColor  // Active color
            )


            val primaryColorWithAlpha =
                ColorUtils.setAlphaComponent(context.baseConfig.primaryColor, (255 * 0.4).toInt())

            val trackColors = intArrayOf(
                context.getColor(R.color.trackColorOff),  // Gray color for unselected state
                primaryColorWithAlpha // Active color
                // Active color
            )

            thumbTintList = ColorStateList(states, thumbColors)
            trackTintList = ColorStateList(states, trackColors)

        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.type) {

            THEME_CHANGED -> {

                val states = arrayOf(
                    intArrayOf(-android.R.attr.state_checked),
                    intArrayOf(android.R.attr.state_checked)
                )

                val thumbColors = intArrayOf(
                    context.getColor(R.color.gray),  // Gray color for unselected state
                    context.baseConfig.primaryColor  // Active color
                )

                val trackColors = intArrayOf(
                    context.getColor(R.color.gray),  // Gray color for unselected state
                    context.baseConfig.primaryColor  // Active color
                )

                thumbTintList = ColorStateList(states, thumbColors)
                trackTintList = ColorStateList(states, trackColors)
            }
        }
    }

    fun setColors(textColor: Int, accentColor: Int, backgroundColor: Int) {
        setTextColor(textColor)

        val states = arrayOf(
            intArrayOf(-android.R.attr.state_checked),
            intArrayOf(android.R.attr.state_checked)
        )

        val thumbColors = intArrayOf(
            context.getColor(R.color.gray),  // Gray color for unselected state
            accentColor  // Active color
        )

        val trackColors = intArrayOf(
            context.getColor(R.color.gray),  // Gray color for unselected state
            accentColor  // Active color
        )

        thumbTintList = ColorStateList(states, thumbColors)
        trackTintList = ColorStateList(states, trackColors)
    }
}


/*
class QkSwitch @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : SwitchCompat(context, attrs) {

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var prefs: AdsPreferences

//    @Inject
//    lateinit var textViewStyler: TextViewStyler

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
//            textViewStyler.applyAttributes(this, attrs)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        if (!isInEditMode) {
            val states = arrayOf(
                intArrayOf(-android.R.attr.state_enabled),
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            )

            thumbTintList = ColorStateList(
                states, intArrayOf(
                    context.resolveThemeColor(R.attr.switchThumbDisabled),
                    colors.theme().theme,
                    context.resolveThemeColor(R.attr.switchThumbEnabled)
                )
            )

            trackTintList = ColorStateList(
                states, intArrayOf(
                    context.resolveThemeColor(R.attr.switchTrackDisabled),
                    colors.theme().theme.withAlpha(0x4D),
                    context.resolveThemeColor(R.attr.switchTrackEnabled)
                )
            )
        }
    }

    fun setColors(textColor: Int, accentColor: Int, backgroundColor: Int) {
        setTextColor(textColor)
        val states = arrayOf(intArrayOf(-android.R.attr.state_checked), intArrayOf(android.R.attr.state_checked))
        val thumbCheckedColors =
            accentColor.getContrastColor() //if (accentColor == resources.getColor(R.color.white)) backgroundColor else resources.getColor(R.color.white)
        val thumbColors = intArrayOf(resources.getColor(R.color.thumb_deactivated), accentColor)
        val trackColors = intArrayOf(resources.getColor(R.color.track_deactivated), accentColor) //accentColor.adjustAlpha(0.3f)
        //DrawableCompat.setTintList(DrawableCompat.wrap(thumbDrawable!!), ColorStateList(states, thumbColors))
        //DrawableCompat.setTintList(DrawableCompat.wrap(trackDrawable!!), ColorStateList(states, trackColors))
        thumbTintList = ColorStateList(states, thumbColors)
        trackTintList = ColorStateList(states, trackColors)
    }
}*/
