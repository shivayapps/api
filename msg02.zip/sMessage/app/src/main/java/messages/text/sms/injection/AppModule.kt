package messages.text.sms.injection

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import androidx.lifecycle.ViewModelProvider
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import messages.text.sms.blocking.BlockingClient
import messages.text.sms.blocking.BlockingManager
import messages.text.sms.common.ViewModelFactory
import messages.text.sms.common.util.NotificationManagerImpl
import messages.text.sms.common.util.ShortcutManagerImpl
import messages.text.sms.feature.conversationinfo.injection.ConversationInfoComponent
import messages.text.sms.feature.themepicker.injection.ThemePickerComponent
import messages.text.sms.listener.ContactAddedListener
import messages.text.sms.listener.ContactAddedListenerImpl
import messages.text.sms.manager.ActiveConversationManager
import messages.text.sms.manager.ActiveConversationManagerImpl
import messages.text.sms.manager.AlarmManager
import messages.text.sms.manager.AlarmManagerImpl
import messages.text.sms.manager.AnalyticsManager
import messages.text.sms.manager.AnalyticsManagerImpl
import messages.text.sms.manager.KeyManager
import messages.text.sms.manager.KeyManagerImpl
import messages.text.sms.manager.NotificationManager
import messages.text.sms.manager.PermissionManager
import messages.text.sms.manager.PermissionManagerImpl
import messages.text.sms.manager.RatingManager
import messages.text.sms.manager.ReferralManager
import messages.text.sms.manager.ReferralManagerImpl
import messages.text.sms.manager.ShortcutManager
import messages.text.sms.manager.WidgetManager
import messages.text.sms.manager.WidgetManagerImpl
import messages.text.sms.mapper.CursorToContact
import messages.text.sms.mapper.CursorToContactImpl
import messages.text.sms.mapper.CursorToConversation
import messages.text.sms.mapper.CursorToConversationImpl
import messages.text.sms.mapper.CursorToMessage
import messages.text.sms.mapper.CursorToMessageImpl
import messages.text.sms.mapper.CursorToPart
import messages.text.sms.mapper.CursorToPartImpl
import messages.text.sms.mapper.CursorToRecipient
import messages.text.sms.mapper.CursorToRecipientImpl
import messages.text.sms.mapper.RatingManagerImpl
import messages.text.sms.repository.BackupRepository
import messages.text.sms.repository.BackupRepositoryImpl
import messages.text.sms.repository.BlockingRepository
import messages.text.sms.repository.BlockingRepositoryImpl
import messages.text.sms.repository.ContactRepositoryImpl
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.ConversationRepositoryImpl
import messages.text.sms.repository.MessageRepository
import messages.text.sms.repository.MessageRepositoryImpl
import messages.text.sms.repository.ScheduledMessageRepository
import messages.text.sms.repository.ScheduledMessageRepositoryImpl
import messages.text.sms.repository.StarredMessageRepository
import messages.text.sms.repository.StarredMessageRepositoryImpl
import messages.text.sms.repository.SyncRepository
import messages.text.sms.repository.SyncRepositoryImpl
import javax.inject.Singleton

@Module(
    subcomponents = [
        ConversationInfoComponent::class,
        ThemePickerComponent::class]
)
class AppModule(private var application: Application) {

    @Provides
    @Singleton
    fun provideContext(): Context = application

    @Provides
    fun provideContentResolver(context: Context): ContentResolver = context.contentResolver

    @Provides
    @Singleton
    fun provideSharedPreferences(context: Context): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(context)
    }


    @Provides
    @Singleton
    fun provideRxPreferences(preferences: SharedPreferences): RxSharedPreferences {
        return RxSharedPreferences.create(preferences)
    }

    @Provides
    @Singleton
    fun provideMoshi(): Moshi {
        return Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
    }

    @Provides
    fun provideViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory = factory

    // Listener

    @Provides
    fun provideContactAddedListener(listener: ContactAddedListenerImpl): ContactAddedListener =
        listener

    // Manager

    @Provides
    fun provideActiveConversationManager(manager: ActiveConversationManagerImpl): ActiveConversationManager =
        manager

    @Provides
    fun provideAlarmManager(manager: AlarmManagerImpl): AlarmManager = manager

    @Provides
    fun provideAnalyticsManager(manager: AnalyticsManagerImpl): AnalyticsManager = manager

    @Provides
    fun blockingClient(manager: BlockingManager): BlockingClient = manager


    @Provides
    fun provideKeyManager(manager: KeyManagerImpl): KeyManager = manager

    @Provides
    fun provideNotificationsManager(manager: NotificationManagerImpl): NotificationManager = manager

    @Provides
    fun providePermissionsManager(manager: PermissionManagerImpl): PermissionManager = manager

    @Provides
    fun provideRatingManager(manager: RatingManagerImpl): RatingManager = manager

    @Provides
    fun provideShortcutManager(manager: ShortcutManagerImpl): ShortcutManager = manager

    @Provides
    fun provideReferralManager(manager: ReferralManagerImpl): ReferralManager = manager

    @Provides
    fun provideWidgetManager(manager: WidgetManagerImpl): WidgetManager = manager

    // Mapper

    @Provides
    fun provideCursorToContact(mapper: CursorToContactImpl): CursorToContact = mapper

    @Provides
    fun provideCursorToConversation(mapper: CursorToConversationImpl): CursorToConversation = mapper

    @Provides
    fun provideCursorToMessage(mapper: CursorToMessageImpl): CursorToMessage = mapper

    @Provides
    fun provideCursorToPart(mapper: CursorToPartImpl): CursorToPart = mapper

    @Provides
    fun provideCursorToRecipient(mapper: CursorToRecipientImpl): CursorToRecipient = mapper

    // Repository

    @Provides
    fun provideBackupRepository(repository: BackupRepositoryImpl): BackupRepository = repository

    @Provides
    fun provideBlockingRepository(repository: BlockingRepositoryImpl): BlockingRepository =
        repository

    @Provides
    fun provideContactRepository(repository: ContactRepositoryImpl): messages.text.sms.repository.ContactRepository =
        repository

    @Provides
    fun provideStarredMessageRepository(repository: StarredMessageRepositoryImpl): StarredMessageRepository =
        repository

    @Provides
    fun provideConversationRepository(repository: ConversationRepositoryImpl): ConversationRepository =
        repository

    @Provides
    fun provideMessageRepository(repository: MessageRepositoryImpl): MessageRepository = repository

    @Provides
    fun provideScheduledMessagesRepository(repository: ScheduledMessageRepositoryImpl): ScheduledMessageRepository =
        repository

    @Provides
    fun provideSyncRepository(repository: SyncRepositoryImpl): SyncRepository = repository

}