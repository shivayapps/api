package messages.text.sms.password.callback;


import messages.text.sms.password.dialog.FingerprintDialog;

public interface FailAuthCounterDialogCallback {
    void onTryLimitReached(FingerprintDialog fingerprintDialog);
}
