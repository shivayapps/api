package messages.text.sms.commons.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.common.util.extensions.forwardTouches
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.databinding.ContactListItemNewBinding
import messages.text.sms.databinding.ContactListItemNewHeaderBinding
import messages.text.sms.databinding.ContactListItemNewNumberBinding
import messages.text.sms.feature.compose.editing.PhoneNumberAdapter
import messages.text.sms.model.Contact
import messages.text.sms.model.ContactDataItem
import messages.text.sms.model.PhoneNumber
import messages.text.sms.model.Recipient
import messages.text.sms.model.RecipientData

class NewContactItemAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private val numbersViewPool = RecyclerView.RecycledViewPool()
    var data = ArrayList<ContactDataItem>()
    val clicks: Subject<ContactDataItem> = PublishSubject.create()
    val longClicks: Subject<ContactDataItem> = PublishSubject.create()

    fun updateData(data: List<ContactDataItem>, callback: (ArrayList<ContactDataItem>) -> Unit) {
        this.data.clear()
        this.data.addAll(buildContactListWithHeaders(data))
        callback.invoke(this.data)
        notifyDataSetChanged()
    }

    fun buildContactListWithHeaders(list: List<ContactDataItem>): List<ContactDataItem> {
        // 1. Sort contacts by name
        val newList = list.filterIsInstance<ContactDataItem.New>()
        val contacts = list.filterIsInstance<ContactDataItem.Person>()
        val sorted = contacts.sortedBy { it.value.name.lowercase() }

        val finalList = ArrayList<ContactDataItem>()
        var lastHeader: String? = null

        for (contact in sorted) {
            val header = contact.value.name.firstOrNull()?.uppercase() ?: "#"

            // 2. Insert header when it changes
            if (header != lastHeader) {
                finalList.add(ContactDataItem.Header(header))
                lastHeader = header
            }

            // 3. Add contact
            finalList.add(contact)
        }

        return newList + finalList
    }

    override fun getItemViewType(position: Int): Int {
        val item = data[position]
        if (item is ContactDataItem.Person) {
            return 1
        }
        if (item is ContactDataItem.New) {
            return 2
        }
        return 0
    }

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == 1) {
            val binding =
                ContactListItemNewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            val textColorPrimary = parent.context.baseConfig.textColor
            binding.title.setTextColor(textColorPrimary)
            val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
            binding.subtitle.setTextColor(colorWithAlpha)

            binding.numbers.setRecycledViewPool(numbersViewPool)
            binding.numbers.adapter = PhoneNumberAdapter()
            binding.numbers.forwardTouches(binding.root)



            return ViewHolder(binding)
        } else if (viewType == 2) {
            return ViewHolderNumber(ContactListItemNewNumberBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        } else {
            return ViewHolderHeader(ContactListItemNewHeaderBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }

    }

    fun getItem(position: Int): ContactDataItem {
        return data[position]
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val person = getItem(position) ?: return
        if (holder is ViewHolder && person is ContactDataItem.Person) {
            holder.binding.root.setOnClickListener {
                val item = getItem(position)
                clicks.onNext(item)

            }

            holder.binding.root.setOnLongClickListener {
                val item = getItem(position)
                longClicks.onNext(item)
                true
            }
            val contact = person.value
            with(holder) {
                var numbersList = ArrayList<PhoneNumber>()
                try {
                    numbersList = ArrayList(contact.numbers)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                holder.binding.avatars.recipientData = listOf(
                    RecipientData(
                        address = numbersList.firstOrNull()?.address ?: "",
                        contact = contact
                    )
                )
                try {
                    holder.binding.title.text = contact.name
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                holder.binding.subtitle.isVisible = false
                holder.binding.numbers.isVisible = true
                (holder.binding.numbers.adapter as PhoneNumberAdapter).data = numbersList
            }
        }
        if (holder is ViewHolderNumber && person is ContactDataItem.New) {
            holder.binding.avatars.recipients = listOf(createRecipient(person.value.contact!!))
            holder.binding.title.text = person.value.contact?.numbers?.joinToString { it.address }
            holder.binding.title.setTextColor(holder.binding.title.context.baseConfig.textColor)
            holder.binding.root.setOnClickListener {
                val item = getItem(position)
                clicks.onNext(item)

            }

            holder.binding.root.setOnLongClickListener {
                val item = getItem(position)
                longClicks.onNext(item)
                true
            }
        }

        if (holder is ViewHolderHeader && person is ContactDataItem.Header) {
            holder.binding.title.text = person.value.uppercase()
            holder.binding.title.setTextColor(holder.binding.title.context.baseConfig.textColor)
        }

    }

    private fun createRecipient(contact: Contact): Recipient {
        return Recipient(
            address = contact.numbers.firstOrNull()?.address ?: "",
            contact = contact
        )
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return data.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(val binding: ContactListItemNewBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    class ViewHolderHeader(val binding: ContactListItemNewHeaderBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    class ViewHolderNumber(val binding: ContactListItemNewNumberBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }
}