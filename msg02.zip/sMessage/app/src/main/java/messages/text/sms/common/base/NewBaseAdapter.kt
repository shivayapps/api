package messages.text.sms.common.base

//import io.realm.RealmRecyclerViewAdapter
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.model.Conversation
import messages.text.sms.model.ConversationAD
import messages.text.sms.model.ModelType

abstract class NewBaseAdapter<T : ModelType, Binding : ViewBinding>
    : RecyclerView.Adapter<MainBaseMsgViewHolder<Binding>>() {
    private val diffUtil = object : DiffUtil.ItemCallback<ModelType>() {
        override fun areItemsTheSame(oldItem: ModelType, newItem: ModelType): Boolean {
            return areItemsTheSameCheck(oldItem, newItem)

        }

        override fun areContentsTheSame(oldItem: ModelType, newItem: ModelType): Boolean {
            return areContentsTheSameCheck(oldItem, newItem)
        }

    }
    val asyncListDiffer = AsyncListDiffer(this, diffUtil)

    val selectionChanges: Subject<List<Long>> = BehaviorSubject.create()

    var selection = listOf<Long>()

    /**
     * Toggles the selected state for a particular view
     *
     * If we are currently in selection mode (we have an active selection), then the state will
     * toggle. If we are not in selection mode, then we will only toggle if [force]
     */
    protected fun toggleSelection(id: Long, force: Boolean = true): Boolean {
        if (!force && selection.isEmpty()) return false

        selection = when (selection.contains(id)) {
            true -> selection - id
            false -> selection + id
        }

        selectionChanges.onNext(selection)
        if (selection.isEmpty()) notifyDataSetChanged()
        return true
    }

    fun isSelection(): Boolean {
        return selection.isNotEmpty()
    }

    protected fun isSelected(id: Long): Boolean {
        return selection.contains(id)
    }

    fun clearSelection() {
        selection = listOf()
        selectionChanges.onNext(selection)
        notifyDataSetChanged()
    }

//    fun getItem(position: Int): ModelType {
//        return asyncListDiffer.currentList[position]
//    }

    fun getItem(position: Int): ModelType? {
        return if (position in 0 until asyncListDiffer.currentList.size) {
            asyncListDiffer.currentList[position]
        } else {
            null // Or return a default instance if necessary
        }
    }


    override fun getItemCount(): Int {
        return asyncListDiffer.currentList.size
    }


    fun getAllItems(): List<ModelType> {
        return asyncListDiffer.currentList
    }

    /**
     * Allows the adapter implementation to provide a custom DiffUtil.Callback
     * If not, then the abstract implementation will be used
     */
    private fun getDiffUtilCallback(
        oldData: List<ModelType>,
        newData: List<ModelType>,
    ): DiffUtil.Callback {
        return object : DiffUtil.Callback() {
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                areItemsTheSameCheck(oldData[oldItemPosition], newData[newItemPosition])

            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                areContentsTheSameCheck(oldData[oldItemPosition], newData[newItemPosition])

            override fun getOldListSize() = oldData.size

            override fun getNewListSize() = newData.size
        }
    }

    protected open fun areItemsTheSameCheck(old: ModelType, new: ModelType): Boolean {
        if (old is Conversation && new is Conversation) {
            return old.unread == new.unread
                    && old.pinned == new.pinned
                    && old.archived == new.archived
                    && old.isRecycle == new.isRecycle
                    && old.isPrivate == new.isPrivate
                    && old.blocked == new.blocked
                    && old.lastMessage?.body == new.lastMessage?.body
                    && old.lastMessage?.read == new.lastMessage?.read
        }
        if (old is ConversationAD && new is ConversationAD) {
            return false
        }
        return old.getType() == new.getType()
    }

    protected open fun areContentsTheSameCheck(old: ModelType, new: ModelType): Boolean {
        if (old is Conversation && new is Conversation) {
            return old.unread == new.unread
                    && old.pinned == new.pinned
                    && old.archived == new.archived
                    && old.isRecycle == new.isRecycle
                    && old.isPrivate == new.isPrivate
                    && old.blocked == new.blocked
                    && old.lastMessage?.body == new.lastMessage?.body
                    && old.lastMessage?.read == new.lastMessage?.read
        }
        if (old is ConversationAD && new is ConversationAD) {
            return false
        }
        return old.getType() == new.getType()
    }
}