package messages.text.sms.appmanager

import android.graphics.drawable.Drawable

data class AppModel(
    val appName: String,
    val packageName: String,
    val versionCode: Int,
    val versionName: String,
    val icon: Drawable?, // Now nullable as icon loading might be async/fail
)
