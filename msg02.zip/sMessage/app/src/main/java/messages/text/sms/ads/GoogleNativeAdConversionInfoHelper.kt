package com.gallery.mvvm.ads

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import messages.text.sms.R
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

class GoogleNativeAdConversionInfoHelper(
    private val mContext: Context,
    private val frameLayout: FrameLayout,
    private val mAdId: String,
    private val isAdLoaded: (isLoaded: Boolean) -> Unit = {},
) {

    val TAG = "ADCONFIG_NativeAdHelper"
    private var mLayout: Int = R.layout.layout_language_big_native
    private lateinit var mainAdView: RelativeLayout
    private lateinit var adView: NativeAdView
    private lateinit var shimmerView: ShimmerFrameLayout

    private var isDestroyed = false


    fun loadAd() {

        mLayout = R.layout.layout_language_big_native
        mainAdView = LayoutInflater.from(mContext).inflate(mLayout, null) as RelativeLayout
        adView = mainAdView.findViewById<NativeAdView>(R.id.native_ad_view) as NativeAdView

//        mainAdView.setCardBackgroundColor(mContext.getAppBackgroundColor())
        val callToActionView = mainAdView.findViewById<TextView>(R.id.ad_call_to_action2)

        shimmerView =
            mainAdView.findViewById<ShimmerFrameLayout>(R.id.shimmerView) as ShimmerFrameLayout
//        parentView.visibility = View.VISIBLE
        frameLayout.visibility = View.VISIBLE
        frameLayout.removeAllViews()

        shimmerView.visibility = View.VISIBLE
        frameLayout.addView(mainAdView)
        shimmerView.startShimmer()
        val adId = mAdId

        requireNotEmpty(adId) { "Ad Id cannot be empty" }
        loadAdmobNativeAd(adId)
    }


    @OptIn(ExperimentalContracts::class)
    inline fun requireNotEmpty(value: String?, lazyMessage: () -> String): String {
        contract {
            returns() implies (value != null)
        }

        if (value == null) {
            val message = lazyMessage()
            throw IllegalArgumentException(message)
        } else {
            return value
        }
    }


    @SuppressLint("MissingPermission")
    private fun loadAdmobNativeAd(adId: String) {

        Log.i("ADCONFIG_NativeAdHelper", "loadAdmobNativeAd:${adId}")
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setReturnUrlsForImageAssets(false)
            .setRequestMultipleImages(false)
            .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->

                if (isDestroyed) {
                    nativeAd.destroy()
                    return@forNativeAd
                }

                populateAdmobNativeAd(nativeAd)
                isAdLoaded.invoke(true)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    isAdLoaded.invoke(false)
//                    adView.visibility = View.GONE
                    frameLayout.removeAllViews()
                    frameLayout.visibility = View.GONE
//                    parentView.visibility = View.GONE
                    Log.i(
                        TAG,
                        "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                    )
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    private fun populateAdmobNativeAd(nativeAd: NativeAd) {
//        frameLayout.removeAllViews()
//        frameLayout.addView(adView)
//        parentView.visibility = View.VISIBLE
        shimmerView.beGone()
        adView.beVisible()
        frameLayout.visibility = View.VISIBLE

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        if (headlineView != null) {
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView
        }

        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (bodyView != null) {
            bodyView.text = nativeAd.body
            adView.bodyView = bodyView
        }

//        val adChoiceView = adView.findViewById<AdChoicesView>(R.id.adChoiceView)
//        if (adChoiceView != null) {
//            adView.adChoicesView = adChoiceView
//        }

//        val adPrice = adView.findViewById<TextView>(R.id.ad_price)
//        if (adPrice != null) {
//            adPrice.text = nativeAd.price
//            adView.priceView = adPrice
//        }

//        val adStore = adView.findViewById<TextView>(R.id.ad_store)
//        if (adStore != null) {
//            adStore.text = nativeAd.store
//            adView.storeView = adStore
//        }

        val callToActionView = adView.findViewById<TextView>(R.id.ad_call_to_action)
        if (callToActionView != null) {
            callToActionView.text = nativeAd.callToAction
            adView.callToActionView = callToActionView
        }

        val adAppIcon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        if (adAppIcon != null && nativeAd.icon != null) {
            adAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
            adView.iconView = adAppIcon
        }

//         val adStars = adView.findViewById<RatingBar>(R.id.ad_stars)
//        if (adStars != null && nativeAd.starRating != null) {
//            adStars.rating = nativeAd.starRating!!.toFloat()
//            adView.starRatingView = adStars
//        }

//        val advertiser = adView.findViewById<TextView>(R.id.ad_advertiser)
//        if (advertiser != null) {
//            advertiser.text = nativeAd.advertiser
//            adView.advertiserView = advertiser
//        }

        try {
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            if (mediaView != null) {
                mediaView.visibility = View.VISIBLE
                adView.mediaView = mediaView
                nativeAd.mediaContent?.let {
                    mediaView.setMediaContent(it)
                }
                mediaView.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        adView.setNativeAd(nativeAd)
    }

}