package messages.text.sms.feature.blocking

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.config
import messages.text.sms.databinding.DialogRemoveKeywordBinding
import messages.text.sms.databinding.TabFragmentKeywordsBinding
import messages.text.sms.util.StringManager

class KeywordsFragment : Fragment() {

    private var binding: TabFragmentKeywordsBinding? = null

    private lateinit var keywordList: MutableList<KeywordItem>

    private lateinit var adapter: KeywordAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = TabFragmentKeywordsBinding.inflate(inflater, container, false)
        keywordList = requireContext().config.keywordList
        setupRecyclerView()
        binding?.btnAddKeywords?.setOnClickListener {
            showAddKeywordDialog()
        }
        binding?.fabAddKeywords?.setOnClickListener {
            showAddKeywordDialog()
        }


        val colorInt = requireActivity().baseConfig.primaryColor
        binding!!.fabAddKeywords.backgroundTintList = ColorStateList.valueOf(colorInt)





        setUpTheme()

        return binding!!.root
    }

    /* private fun setUpTheme() {
         if (requireActivity().baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
             binding?.main?.background =
                 ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
         } else {
             binding?.main?.background = ColorDrawable(requireActivity().baseConfig.backgroundColor)
         }

         if (requireActivity().baseConfig.useImageResource) {
             if (requireActivity().baseConfig.storedImageResource == -1) {

             } else {
                 Log.i("onCreate", "onCreateitemselse11111: ")
                 val drawable = ContextCompat.getDrawable(requireActivity(), requireActivity().baseConfig.storedImageResource)
                 binding?.main?.background = drawable

             }
         } else {
             val primaryColor = requireActivity().baseConfig.primaryColor
             Log.i("onCreate", "onCreateitemselse: ")
         }
     }*/

    private fun setUpTheme() {

//        updateTextColors(binding.main)

        if (requireActivity().baseConfig.useImageResource) {
            if (requireActivity().baseConfig.storedImageResource == -1) {

                if (requireActivity().baseConfig.storedImageResource == 111) {
                    val stringManager = StringManager(requireActivity())
                    val imageBitmap = stringManager.getSavedThemeBitmaps().last()
                    val drawable = BitmapDrawable(resources, imageBitmap)
                    binding?.main?.background = drawable
//                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                } else {
                    val drawable = ContextCompat.getDrawable(
                        requireActivity(),
                        requireActivity().baseConfig.storedImageResource
                    )
                    binding?.main?.background = drawable
//                    findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
                }

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(
                    requireActivity(),
                    requireActivity().baseConfig.storedImageResource
                )
                binding?.main?.background = drawable
//                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(resources.getColor(R.color.transperent))
//                findViewById<AppBarLayout>(R.id.toolbar).setBackgroundColor(requireActivity().baseConfig.backgroundColor)
            }


        } else {
            val primaryColor = requireActivity().baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            if (requireActivity().baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
                binding?.main?.background =
                    ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))
            } else {
                binding?.main?.background =
                    ColorDrawable(requireActivity().baseConfig.backgroundColor)
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = KeywordAdapter(keywordList) { position ->

            showCustomKeywordDialog(requireContext(), keywordList[position].keyword, {
                adapter.removeItem(position)
                updateVisibility()
                requireContext().config.keywordList = keywordList
            })

        }
        binding?.recyclerView?.layoutManager = LinearLayoutManager(requireContext())
        binding?.recyclerView?.adapter = adapter
        updateVisibility()
    }

    private fun updateVisibility() {
        if (adapter.itemCount > 0) {
            binding?.noData?.visibility = View.GONE
            binding?.viewData?.visibility = View.VISIBLE
            binding?.fabAddKeywords?.visibility = View.VISIBLE
        } else {
            binding?.viewData?.visibility = View.GONE
            binding?.noData?.visibility = View.VISIBLE
            binding?.fabAddKeywords?.visibility = View.GONE
        }
    }


    private fun showAddKeywordDialog() {
        val dialog = Dialog(requireContext(), R.style.QuickReplyDialogStyle)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val dialogView =
            LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_keyword, null)
        dialog.setContentView(dialogView)
        dialog.setCancelable(true)

        val editKeyword = dialogView.findViewById<EditText>(R.id.editKeyword)
        val btnCancel = dialogView.findViewById<TextView>(R.id.btnCancel)
        val btnAdd = dialogView.findViewById<TextView>(R.id.btnAdd)

        btnCancel.setOnClickListener { dialog.dismiss() }
        btnAdd.setTextColor(requireActivity().baseConfig.primaryColor)
        btnAdd.setOnClickListener {
            val keyword = editKeyword.text.toString().trim()
            if (keyword.isNotEmpty()) {
                adapter.addItem(KeywordItem(keyword))
                updateVisibility()

                requireContext().config.keywordList = adapter.getItems()
                dialog.dismiss()
            } else {
                Toast.makeText(requireContext(), "Please enter a keyword", Toast.LENGTH_SHORT)
                    .show()
            }
        }

        // Set dialog width and margin in dp
        val params = dialog.window?.attributes
        val marginInDp = 30  // 30dp margin on left/right
        val marginInPx = (marginInDp * requireContext().resources.displayMetrics.density).toInt()
        params?.width = requireContext().resources.displayMetrics.widthPixels - 2 * marginInPx
        dialog.window?.attributes = params

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }


    fun showCustomKeywordDialog(context: Context, keyword: String, onDelete: () -> Unit) {
        val dialog = Dialog(context, R.style.QuickReplyDialogStyle)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val binding = DialogRemoveKeywordBinding.inflate(LayoutInflater.from(context))
        dialog.setContentView(binding.root)
        dialog.setCancelable(true)

        binding.tvTitle.text = keyword
        binding.tvMessage.text =
            (context as Activity).getString(R.string.do_you_want_to_remove_this_keyword_from_blacklist)

        binding.btnDelete.setTextColor(context.baseConfig.primaryColor)
        binding.btnCancel.setTextColor(
            ContextCompat.getColor(
                context,
                R.color.transparent
            )
        ) // Replace with appropriate color

        binding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        binding.btnDelete.setOnClickListener {
            onDelete()
            dialog.dismiss()
        }

        // Set dialog width and margin in dp
        val params = dialog.window?.attributes
        val marginInDp = 30  // e.g., 16dp margin on left/right
        val marginInPx = (marginInDp * context.resources.displayMetrics.density).toInt()

// Adjust window layout with calculated margins
        params?.width = context.resources.displayMetrics.widthPixels - 2 * marginInPx
        dialog.window?.attributes = params

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }


}



