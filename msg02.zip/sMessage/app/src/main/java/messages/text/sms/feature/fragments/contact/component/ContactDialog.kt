package messages.text.sms.feature.fragments.contact.component

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.realm.RealmList
import messages.text.sms.commons.adapters.ContactSelectAdapter
import messages.text.sms.databinding.ComponentContactsDialogBinding
import messages.text.sms.model.Contact

class ContactDialog(
    private val contacts: RealmList<Contact>,
    val callBack: (contacts: RealmList<Contact>) -> Unit,
) : DialogFragment() {

    private var _binding: ComponentContactsDialogBinding? = null
    private val binding get() = _binding!!
    private lateinit var recyclerView: RecyclerView
    private var contactsAdapter = ContactSelectAdapter()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        _binding = ComponentContactsDialogBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = binding.groupsRecyclerView
        contactsAdapter.data = contacts

        recyclerView.adapter = contactsAdapter
        recyclerView.layoutManager = LinearLayoutManager(context)

        binding.btnCancel.setOnClickListener {
            dialog?.dismiss()
        }
        binding.btnOk.setOnClickListener {
            val checkedContacts: RealmList<Contact> = RealmList()
            for (contact in contactsAdapter.checkedContact()) {
                checkedContacts.add(contact)
            }
            //groupsService.addContacts(groupId, checkedContacts)
            dialog?.dismiss()
            callBack.invoke(checkedContacts)
        }

    }

    override fun onStart() {
        super.onStart()

        val window = dialog?.window
        val layoutParams = WindowManager.LayoutParams().apply {
            copyFrom(window?.attributes)
            width =
                (resources.displayMetrics.widthPixels * 0.9).toInt() // Set width to 90% of the screen width
//            height = WindowManager.LayoutParams.WRAP_CONTENT
        }
        window?.attributes = layoutParams
    }
}
