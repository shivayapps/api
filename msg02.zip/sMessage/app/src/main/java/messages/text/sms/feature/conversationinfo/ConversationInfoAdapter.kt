package messages.text.sms.feature.conversationinfo

import android.content.Context
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseAdapter
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.common.util.extensions.setVisible
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.databinding.ConversationInfoSettingsBinding
import messages.text.sms.databinding.ConversationMediaListItemBinding
import messages.text.sms.databinding.ConversationRecipientListItemBinding
import messages.text.sms.extensions.isVideo
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoMedia
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoRecipient
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoSettings

import javax.inject.Inject

class ConversationInfoAdapter @Inject constructor(
    private val context: Context,
    private val colors: Colors,
) : MainBaseAdapter<ConversationInfoItem, ViewBinding>() {

    var isPrivate = false
    val recipientClicks: Subject<Long> = PublishSubject.create()
    val recipientLongClicks: Subject<Long> = PublishSubject.create()
    val themeClicks: Subject<Long> = PublishSubject.create()
    val nameClicks: Subject<Unit> = PublishSubject.create()
    val notificationClicks: Subject<Unit> = PublishSubject.create()
    val archiveClicks: Subject<Unit> = PublishSubject.create()
    val blockClicks: Subject<Unit> = PublishSubject.create()
    val deleteClicks: Subject<Unit> = PublishSubject.create()
    val mediaClicks: Subject<Long> = PublishSubject.create()
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ViewBinding> {
        val holder: MainBaseMsgViewHolder<ViewBinding> = when (viewType) {
            0 -> MainBaseMsgViewHolder(parent, ConversationRecipientListItemBinding::inflate)
            1 -> MainBaseMsgViewHolder(parent, ConversationInfoSettingsBinding::inflate)
            2 -> MainBaseMsgViewHolder(parent, ConversationMediaListItemBinding::inflate)
            else -> throw IllegalStateException()
        }

        return holder.apply {
            when (binding) {
                is ConversationRecipientListItemBinding -> {
                    itemView.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoRecipient
                        item?.value?.id?.run(recipientClicks::onNext)
                    }

                    itemView.setOnLongClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoRecipient
                        item?.value?.id?.run(recipientLongClicks::onNext)
                        true
                    }

                    binding.theme.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoRecipient
                        item?.value?.id?.run(themeClicks::onNext)
                    }
                }

                is ConversationInfoSettingsBinding -> {
                    if (isPrivate) {
                        binding.archive.beGone()
                        binding.block.beGone()
                    }
                    binding.groupName.clicks().subscribe(nameClicks)
                    binding.notifications.clicks().subscribe(notificationClicks)
                    binding.archive.clicks().subscribe(archiveClicks)
                    binding.block.clicks().subscribe(blockClicks)
                    binding.delete.clicks().subscribe(deleteClicks)
                }

                is ConversationMediaListItemBinding -> {
                    itemView.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoMedia
                        item?.value?.id?.run(mediaClicks::onNext)
                    }
                }
            }
        }
    }

    override fun onBindViewHolder(holder: MainBaseMsgViewHolder<ViewBinding>, position: Int) {
        val item = getItem(position)
        when {
            item is ConversationInfoRecipient && holder.binding is ConversationRecipientListItemBinding -> {
                val recipient = item.value
                try {
                    holder.binding.avatar.setRecipient(recipient)
                } catch (_: Exception) {

                }

                holder.binding.name.text = recipient.contact?.name ?: recipient.address

                holder.binding.address.text = recipient.address
                holder.binding.address.setVisible(recipient.contact != null)

                holder.binding.add.setVisible(recipient.contact == null)

                val theme = colors.theme(recipient)
                holder.binding.theme.setTint(theme.theme)

                val textColorPrimary = holder.binding.add.context.baseConfig.textColor
                holder.binding.name.setTextColor(textColorPrimary)
                val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
                holder.binding.address.setTextColor(colorWithAlpha)

            }

            item is ConversationInfoSettings && holder.binding is ConversationInfoSettingsBinding -> {


                holder.binding.groupName.isVisible = item.recipients.size > 1
                holder.binding.groupName.summary = item.name

                holder.binding.notifications.isEnabled = !item.blocked

                holder.binding.archive.isEnabled = !item.blocked
                holder.binding.archive.title = context.getString(
                    when (item.archived) {
                        true -> R.string.info_unarchive
                        false -> R.string.info_archive
                    }
                )

                holder.binding.block.title = context.getString(
                    when (item.blocked) {
                        true -> R.string.info_unblock
                        false -> R.string.info_block
                    }
                )
            }

            item is ConversationInfoMedia && holder.binding is ConversationMediaListItemBinding -> {
                val part = item.value

                Glide.with(context)
                    .load(part.getUri())
                    .fitCenter()
                    .into(holder.binding.thumbnail)



                holder.binding.video.isVisible = part.isVideo()
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (data[position]) {
            is ConversationInfoRecipient -> 0
            is ConversationInfoSettings -> 1
            is ConversationInfoMedia -> 2
        }
    }

    override fun areItemsTheSame(old: ConversationInfoItem, new: ConversationInfoItem): Boolean {
        return when {
            old is ConversationInfoRecipient && new is ConversationInfoRecipient -> {
                old.value.id == new.value.id
            }

            old is ConversationInfoSettings && new is ConversationInfoSettings -> {
                true
            }

            old is ConversationInfoMedia && new is ConversationInfoMedia -> {
                old.value.id == new.value.id
            }

            else -> false
        }
    }

    fun makePrivateInfo() {
        isPrivate = true

    }
}
