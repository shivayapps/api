package messages.text.sms.common.util

import android.graphics.Typeface
import android.os.Build
import android.util.AttributeSet
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import messages.text.sms.R
import messages.text.sms.common.widget.BabyTextView
import messages.text.sms.common.widget.MessageTextView
import messages.text.sms.common.widget.StyledTextView
import messages.text.sms.util.Preferences
import javax.inject.Inject


class TextViewStyler @Inject constructor(
    private val prefs: Preferences,
    private val colors: Colors,
    private val fontProvider: FontProvider,
) {

    companion object {
        const val COLOR_THEME = 0
        const val COLOR_PRIMARY_ON_THEME = 1
        const val COLOR_SECONDARY_ON_THEME = 2
        const val COLOR_TERTIARY_ON_THEME = 3

        const val SIZE_PRIMARY = 0
        const val SIZE_SECONDARY = 1
        const val SIZE_TERTIARY = 2
        const val SIZE_TOOLBAR = 3
        const val SIZE_DIALOG = 4
        const val SIZE_EMOJI = 5
        const val SIZE_NORMAL = 6

        fun applyEditModeAttributes(textView: TextView, attrs: AttributeSet?) {
            textView.run {
                var colorAttr = 0
                var textSizeAttr = 0

                when (this) {
                    is BabyTextView -> context.obtainStyledAttributes(attrs, R.styleable.QkTextView)
                        ?.run {
                            colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
//                        textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
                            recycle()
                        }

                    is StyledTextView -> context.obtainStyledAttributes(
                        attrs,
                        R.styleable.QkTextView
                    )?.run {
                        colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
//                        textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
                        recycle()
                    }

//                    is QkEditText -> context.obtainStyledAttributes(attrs, R.styleable.QkEditText)?.run {
//                        colorAttr = getInt(R.styleable.QkEditText_textColor, -1)
////                        textSizeAttr = getInt(R.styleable.QkEditText_textSize, -1)
//                        recycle()
//                    }

                    else -> return
                }

//                textSize = when (textSizeAttr) {
//                    SIZE_PRIMARY -> 16f
//                    SIZE_SECONDARY -> 14f
//                    SIZE_TERTIARY -> 12f
//                    SIZE_TOOLBAR -> 20f
//                    SIZE_DIALOG -> 18f
//                    SIZE_EMOJI -> 32f
//                    else -> textSize / paint.density
//                }
            }
        }
    }

    fun applyAttributes(textView: TextView, attrs: AttributeSet?) {
//        var colorAttr = 0
        var textSizeAttr = 0
        var isMessage = false


        when (textView) {
            is BabyTextView -> textView.context.obtainStyledAttributes(
                attrs,
                R.styleable.QkTextView
            ).run {
                isMessage = false
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
                recycle()
            }

            is StyledTextView -> textView.context.obtainStyledAttributes(
                attrs,
                R.styleable.QkTextView
            ).run {
                isMessage = false
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
//                setTextSize(textView, textSizeAttr)
                recycle()
            }

            is MessageTextView -> textView.context.obtainStyledAttributes(
                attrs,
                R.styleable.QkTextView
            ).run {
                isMessage = true
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)

                try {
                    if (!prefs.systemFont.get()) {
                        fontProvider.getLato { lato ->
                            textView.setTypeface(lato, textView.typeface?.style ?: Typeface.NORMAL)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                recycle()
            }

//            is TextView -> textView.context.obtainStyledAttributes(attrs, R.styleable.QkTextView).run {
//                colorAttr = getInt(R.styleable.QkTextView_textColor, -1)
//                textSizeAttr = getInt(R.styleable.QkTextView_textSize, -1)
//                recycle()
//            }

//            is QkEditText -> textView.context.obtainStyledAttributes(attrs, R.styleable.QkEditText).run {
////                colorAttr = getInt(R.styleable.QkEditText_textColor, -1)
//                textSizeAttr = getInt(R.styleable.QkEditText_textSize, -1)
//                recycle()
//            }

            else -> return
        }

        setTextSize(textView, textSizeAttr, isMessage)

        if (textView is EditText) {
            val drawable = textView.resources.getDrawable(R.drawable.cursor)
                .apply { setTint(colors.theme().theme) }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                textView.textCursorDrawable = drawable
            }
        }
    }

    fun setTextSize(textView: TextView, textSizeAttr: Int, isMessage: Boolean) {
        val textSizePref = prefs.textSize.get()

        // val checkTypeface = ResourcesCompat.getFont(textView.context, prefs.selectedFont.get())
        //  textView.setTypeface(checkTypeface, checkTypeface?.style ?: Typeface.NORMAL)

        when (textSizeAttr) {
            SIZE_PRIMARY -> {
                if (isMessage) textView.textSize = textSizePref.toFloat()
                else textView.textSize = 16f
            }

            SIZE_SECONDARY -> {
                if (isMessage) textView.textSize = (textSizePref * 0.8).toFloat()
                else textView.textSize = 14f
            }

            SIZE_TERTIARY -> {
                if (isMessage) textView.textSize = (textSizePref * 0.6).toFloat()
                else textView.textSize = 12f
            }

            SIZE_TOOLBAR -> {
                if (isMessage) textView.textSize = (textSizePref * 1.2).toFloat()
                else textView.textSize = 20f
            }

            SIZE_DIALOG -> {
                if (isMessage) textView.textSize = (textSizePref * 1.6).toFloat()
                else textView.textSize = 18f
            }

            SIZE_EMOJI -> {
                if (isMessage) textView.textSize = (textSizePref * 2).toFloat()
                else textView.textSize = 32f
            }

            SIZE_NORMAL -> {
                textView.textSize = 16f
            }
//            SIZE_EMOJI -> textView.textSize = 32f
//            SIZE_PRIMARY -> textView.textSize = when (textSizePref) {
//////                AdsPreferences.TEXT_SIZE_SMALL -> 14f
//////                AdsPreferences.TEXT_SIZE_NORMAL -> 16f
//////                AdsPreferences.TEXT_SIZE_LARGE -> 18f
//////                AdsPreferences.TEXT_SIZE_LARGER -> 20f
//                else -> 16f
//            }
//
//            SIZE_SECONDARY -> textView.textSize = when (textSizePref) {
////                AdsPreferences.TEXT_SIZE_SMALL -> 12f
////                AdsPreferences.TEXT_SIZE_NORMAL -> 14f
////                AdsPreferences.TEXT_SIZE_LARGE -> 16f
////                AdsPreferences.TEXT_SIZE_LARGER -> 18f
//                else -> 14f
//            }
//
//            SIZE_TERTIARY -> textView.textSize = when (textSizePref) {
////                AdsPreferences.TEXT_SIZE_SMALL -> 10f
////                AdsPreferences.TEXT_SIZE_NORMAL -> 12f
////                AdsPreferences.TEXT_SIZE_LARGE -> 14f
////                AdsPreferences.TEXT_SIZE_LARGER -> 16f
//                else -> 12f
//            }
//
//            SIZE_TOOLBAR -> textView.textSize = when (textSizePref) {
////                AdsPreferences.TEXT_SIZE_SMALL -> 18f
////                AdsPreferences.TEXT_SIZE_NORMAL -> 20f
////                AdsPreferences.TEXT_SIZE_LARGE -> 22f
////                AdsPreferences.TEXT_SIZE_LARGER -> 26f
//                else -> 20f
//            }
//
//            SIZE_DIALOG -> textView.textSize = when (textSizePref) {
////                AdsPreferences.TEXT_SIZE_SMALL -> 16f
////                AdsPreferences.TEXT_SIZE_NORMAL -> 18f
////                AdsPreferences.TEXT_SIZE_LARGE -> 20f
////                AdsPreferences.TEXT_SIZE_LARGER -> 24f
//                else -> 18f
//            }
//
//            SIZE_EMOJI -> textView.textSize = when (textSizePref) {
////                AdsPreferences.TEXT_SIZE_SMALL -> 28f
////                AdsPreferences.TEXT_SIZE_NORMAL -> 32f
////                AdsPreferences.TEXT_SIZE_LARGE -> 36f
////                AdsPreferences.TEXT_SIZE_LARGER -> 40f
//                else -> 32f
//            }
        }
    }

}