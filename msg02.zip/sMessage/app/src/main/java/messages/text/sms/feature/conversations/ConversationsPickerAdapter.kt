package messages.text.sms.feature.conversations

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseMsgViewHolder
import messages.text.sms.common.base.MainBaseRealmAdapter
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.extensions.setTint
import messages.text.sms.commons.extensions.addAlpha
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.beGone
import messages.text.sms.commons.extensions.beVisible
import messages.text.sms.databinding.ConversationListItemBinding
import messages.text.sms.model.Conversation
import messages.text.sms.util.PhoneNumberUtils
import javax.inject.Inject

class ConversationsPickerAdapter @Inject constructor(
    private val colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val navigator: Navigator,
    private val phoneNumberUtils: PhoneNumberUtils,
) : MainBaseRealmAdapter<Conversation, ConversationListItemBinding>() {
    var selectContact: SelectContact? = null

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    //    fun selectAll(conversationlist: RealmResults<Conversation>?) {
    fun toggleSelectAll(isSelect: Boolean) {
        val cnt = itemCount
        Log.e("ConversationsAdapter", "isSelect:$isSelect, cnt:$cnt")
        if (selection.size == cnt) {
            Log.e("ConversationsAdapter", "toggleSelectAll.001")
            clearSelection()
        } else {
//            Log.e("ConversationsAdapter","toggleSelectAll.002")
            for (i in 0 until cnt) {
//                Log.e("ConversationsAdapter","toggleSelectAll.003")
                val conversation = getItem(i)
                if (selection.contains(conversation?.id!!)) {
//                    selection.add(Conversationlist[i]?.id!!)
                    if (!isSelect) {
                        Log.e("ConversationsAdapter", "toggleSelectAll.004")
                        selection = selection - conversation.id
//                        selectionChanges.onNext(selection)
                    }
                } else {
                    if (isSelect) {
                        Log.e("ConversationsAdapter", "toggleSelectAll.005")
                        selection = selection + conversation.id
//                        selectionChanges.onNext(selection)
                    }
                }
//            toggleSelection(i.toLong(), false)
            }
            Log.e("ConversationsAdapter", "selection:${selection.size}")
            selectionChanges.onNext(selection)
            notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ): MainBaseMsgViewHolder<ConversationListItemBinding> {
        return MainBaseMsgViewHolder(parent, ConversationListItemBinding::inflate).apply {

//                val textColorPrimary = parent.context.resolveThemeColor(android.R.attr.textColorPrimary)
            val textColorPrimary = context.baseConfig.textColor
            val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
            binding.title.setTextColor(textColorPrimary)
            binding.date.setTextColor(colorWithAlpha)
            binding.snippet.setTextColor(colorWithAlpha)

            binding.mainConversation.beVisible()
            binding.llAds.beGone()
            if (viewType == 1) {

                binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)
                binding.snippet.setTypeface(binding.snippet.typeface, Typeface.BOLD)
                binding.snippet.setTextColor(textColorPrimary)
                //  binding.snippet.maxLines = 2

                binding.unread.isVisible = true
                binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
//                binding.date.setTextColor(textColorPrimary)
            } else {
                binding.title.setTypeface(binding.title.typeface, Typeface.NORMAL)
                binding.snippet.setTypeface(binding.snippet.typeface, Typeface.NORMAL)
                binding.snippet.setTextColor(colorWithAlpha)
            }

            binding.root.setOnClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnClickListener
                //   if (conversation.recipients.size == 1) {
                    if (selection.size > 0) {
                        when (toggleSelection(conversation.id, false)) {
                            true -> {
                                binding.root.isActivated = isSelected(conversation.id)
                                if (isSelected(conversation.id)) {
                                    binding.cbSelect.isChecked = true
                                    selectContact?.selectContact(conversation, true)
                                } else {
                                    binding.cbSelect.isChecked = false
                                    selectContact?.selectContact(conversation, false)
                                }
                            }

                            false -> {
                                //  selectContact?.selectContact(conversation.getTitle())
                            }
                        }
                    } else {
                        val conversation = getItem(adapterPosition) ?: return@setOnClickListener
                        toggleSelection(conversation.id)
                        binding.root.isActivated = isSelected(conversation.id)
                        if (isSelected(conversation.id)) {
                            binding.cbSelect.isChecked = true
                            selectContact?.selectContact(conversation, true)
                        } else {
                            binding.cbSelect.isChecked = false
                            selectContact?.selectContact(conversation, false)
                        }
                        notifyDataSetChanged()
                    }

                //   }
            }

            binding.root.setOnLongClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnLongClickListener true

                toggleSelection(conversation.id)
                binding.root.isActivated = isSelected(conversation.id)
                if (isSelected(conversation.id)) {
                    binding.cbSelect.isChecked = true
                    selectContact?.selectContact(conversation, true)
                } else {
                    binding.cbSelect.isChecked = false
                    selectContact?.selectContact(conversation, false)
                }
                notifyDataSetChanged()
                true
            }
        }
    }


    override fun onBindViewHolder(
        holder: MainBaseMsgViewHolder<ConversationListItemBinding>,
        position: Int,
    ) {
        val conversation = getItem(position) ?: return



        holder.binding.root.isActivated = isSelected(conversation.id)
        if (isSelected(conversation.id)) {
            holder.binding.cbSelect.isChecked = true
        } else {
            holder.binding.cbSelect.isChecked = false
        }

        holder.binding.avatars.title = conversation.getTitle()
        holder.binding.avatars.recipients = conversation.recipients
        holder.binding.title.collapseEnabled = conversation.recipients.size > 1
        holder.binding.title.text = conversation.getTitle()
        holder.binding.date.text =
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp)
        holder.binding.snippet.text = when {
            conversation.draft.isNotEmpty() -> context.getString(
                R.string.main_draft,
                conversation.draft
            )

            conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
            else -> conversation.snippet
        }
        holder.binding.pinned.isVisible = conversation.pinned

        Log.e(
            "ConversationsAdapter",
            "selection.size:${selection.size}, isSelection:${isSelection()}, isSelected:${
                isSelected(conversation.id)
            }"
        )


        if (isSelection()) {
            if (conversation.recipients.size > 1) {
                holder.binding.cbSelect.visibility = View.INVISIBLE
            } else {
                holder.binding.cbSelect.beVisible()
            }
        } else {

            holder.binding.cbSelect.beGone()
        }



        holder.binding.cbSelect.buttonTintList =
            ColorStateList.valueOf(context.baseConfig.primaryColor)
        holder.binding.pinned.imageTintList =
            ColorStateList.valueOf(context.baseConfig.primaryColor)


//        if (isSelected(conversation.id)) {
//            holder.binding.cbSelect.isChecked=true
////            holder.binding.cbSelect.visible()
//////            holder.binding.conversationBack.setBackgroundColor(ContextCompat.getColor(MainActivity.mainActivity ?:context,R.color.subs_plan_select_bg))
//        } else {
//            holder.binding.cbSelect.isChecked=false
//////            holder.binding.conversationBack.setBackgroundColor(ContextCompat.getColor(MainActivity.mainActivity ?:context,android.R.color.transparent))
////            holder.binding.cbSelect.beGo()
//        }

        // If the last message wasn't incoming, then the colour doesn't really matter anyway
        val lastMessage = conversation.lastMessage
        val recipient = when {
            conversation.recipients.size == 1 || lastMessage == null -> conversation.recipients.firstOrNull()
            else -> conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        }

        //   holder.binding.unread.setTint(colors.theme(recipient).theme)
        holder.binding.unread.setTint(context.baseConfig.primaryColor)
    }

    override fun getItemId(position: Int): Long {
        return getItem(position)?.id ?: -1
    }

    override fun getItemViewType(position: Int): Int {
        return if (getItem(position)?.unread == false) 0 else 1
    }

}


interface SelectContact {
    fun selectContact(contact: Conversation, add: Boolean)
}
