package messages.text.sms.feature.starred

import androidx.lifecycle.ViewModel
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import messages.text.sms.injection.ViewModelKey

@Module
class StarredActivityModule {

    @Provides
    @IntoMap
    @ViewModelKey(StarredViewModel::class)
    fun provideScheduledViewModel(viewModel: StarredViewModel): ViewModel = viewModel

}