package messages.text.sms.feature.starred

import io.realm.RealmResults
import messages.text.sms.model.Message

data class StarredMessagesState(
    val data: RealmResults<Message>? = null,
    val selected: Int = 0,
)
