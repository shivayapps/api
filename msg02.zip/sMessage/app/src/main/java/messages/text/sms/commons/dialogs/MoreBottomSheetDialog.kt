package messages.text.sms.commons.dialogs

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import messages.text.sms.R
import messages.text.sms.databinding.BottomDialogMoreBinding

class MoreBottomSheetDialog :
    BottomSheetDialogFragment() {
    private lateinit var binding: BottomDialogMoreBinding
    var checkstatus: Boolean = false
    var btnClickListener: ((Int) -> Unit?)? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?,
    ): View {
        val view = inflater.inflate(R.layout.bottom_dialog_more, container, false)
        binding = BottomDialogMoreBinding.bind(view)


        initListener()

        return binding.root
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
        dialog.setOnShowListener {
            val bottomSheet =
                dialog.findViewById<View>(R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundResource(R.drawable.shape_bg_bottom_dialog)

            if (bottomSheet != null) {
                val behavior: BottomSheetBehavior<*> = BottomSheetBehavior.from(bottomSheet)
                behavior.peekHeight = 0 // You can adjust this as needed
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
                behavior.isDraggable = false
            }
        }
        return dialog
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        if (checkstatus == false) {
//            checkdiaogopn = false
        }
    }


    private fun initListener() {
        binding.llScheduledMessages.setOnClickListener {
            checkstatus = true
            btnClickListener?.invoke(0)
            dismiss()
        }
        binding.llSpamBlacklist.setOnClickListener {
            btnClickListener?.invoke(1)
            dismiss()
        }
        binding.llAutoReplay.setOnClickListener {
            btnClickListener?.invoke(2)
            dismiss()
        }
    }


    override fun getTheme(): Int {
        return R.style.AppBottomSheetDialogTheme
    }


    private fun dismissWithDelay(delayMillis: Long, action: () -> Unit) {
        Handler(Looper.getMainLooper()).postDelayed({
            dismiss()
            action()
        }, delayMillis)
    }


}