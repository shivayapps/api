package messages.text.sms.commons.helpers

import android.content.Context
import android.graphics.Color
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import messages.text.sms.commons.extensions.getDefaultKeyboardHeight
import messages.text.sms.feature.blocking.KeywordItem

class Config(context: Context) : BaseConfig(context) {
    companion object {
        fun newInstance(context: Context) = Config(context)
    }

    fun saveUseSIMIdAtNumber(number: String, SIMId: Int) {
        prefs.edit().putInt(USE_SIM_ID_PREFIX + number, SIMId).apply()
    }

    fun getUseSIMIdAtNumber(number: String) = prefs.getInt(USE_SIM_ID_PREFIX + number, 0)

    var showCharacterCounter: Boolean
        get() = prefs.getBoolean(SHOW_CHARACTER_COUNTER, true)
        set(showCharacterCounter) = prefs.edit()
            .putBoolean(SHOW_CHARACTER_COUNTER, showCharacterCounter).apply()

    var useSimpleCharacters: Boolean
        get() = prefs.getBoolean(USE_SIMPLE_CHARACTERS, false)
        set(useSimpleCharacters) = prefs.edit()
            .putBoolean(USE_SIMPLE_CHARACTERS, useSimpleCharacters).apply()

    var sendOnEnter: Boolean
        get() = prefs.getBoolean(SEND_ON_ENTER, false)
        set(sendOnEnter) = prefs.edit().putBoolean(SEND_ON_ENTER, sendOnEnter).apply()

    var enableDeliveryReports: Boolean
        get() = prefs.getBoolean(ENABLE_DELIVERY_REPORTS, false)
        set(enableDeliveryReports) = prefs.edit()
            .putBoolean(ENABLE_DELIVERY_REPORTS, enableDeliveryReports).apply()

    var sendLongMessageMMS: Boolean
        get() = prefs.getBoolean(SEND_LONG_MESSAGE_MMS, false)
        set(sendLongMessageMMS) = prefs.edit().putBoolean(SEND_LONG_MESSAGE_MMS, sendLongMessageMMS)
            .apply()

    var sendGroupMessageMMS: Boolean
        get() = prefs.getBoolean(SEND_GROUP_MESSAGE_MMS, false)
        set(sendGroupMessageMMS) = prefs.edit()
            .putBoolean(SEND_GROUP_MESSAGE_MMS, sendGroupMessageMMS).apply()

    var lockScreenVisibilitySetting: Int
        get() = prefs.getInt(LOCK_SCREEN_VISIBILITY, LOCK_SCREEN_SENDER_MESSAGE)
        set(lockScreenVisibilitySetting) = prefs.edit()
            .putInt(LOCK_SCREEN_VISIBILITY, lockScreenVisibilitySetting).apply()

    fun getBooleanData(key: String?, def: Boolean): Boolean {
        return try {
            prefs.getBoolean(key, def)
        } catch (e: Exception) {
            false
        }
    }


    var clickLangDone: Boolean
        get() = prefs.getBoolean("clickLangDone", false)
        set(clickLangDone) = prefs.edit()
            .putBoolean("clickLangDone", clickLangDone).apply()

    var selectedLanguage: String
        get() = prefs.getString("selectedLanguage", "") ?: ""
        set(selectedLanguage) = prefs.edit().putString("selectedLanguage", selectedLanguage).apply()

    var selectedLanguagePos: Int
        get() = prefs.getInt("selectedLanguagePos", 0)
        set(selectedLanguage) = prefs.edit().putInt("selectedLanguagePos", selectedLanguage).apply()

    var selectedLanguageName: String
        get() = prefs.getString("selectedLanguageName", "") ?: ""
        set(selectedLanguageName) = prefs.edit()
            .putString("selectedLanguageName", selectedLanguageName).apply()

    var keywordList: MutableList<KeywordItem>
        get() {
            val json = prefs.getString("keywordList", null)
            return if (json.isNullOrEmpty()) {
                mutableListOf()
            } else {
                val type = object : TypeToken<MutableList<KeywordItem>>() {}.type
                Gson().fromJson(json, type)
            }
        }
        set(value) {
            val json = Gson().toJson(value)
            prefs.edit().putString("keywordList", json).apply()
        }


    fun saveData(key: String?, boolean: Boolean) {

        prefs.edit()
            .putBoolean(key, boolean)
            .apply()
    }

    fun saveData(key: String?, `val`: Float) {
        prefs
            .edit()
            .putFloat(key, `val`)
            .apply()
    }

    fun saveData(key: String?, `val`: Long) {
        prefs
            .edit()
            .putLong(key, `val`)
            .apply()
    }

    fun saveData(key: String?, `val`: String?) {

        prefs.edit().putString(key, `val`)
            .apply()
    }

    fun saveData(key: String?, `val`: Int) {
        prefs.edit().putInt(key, `val`)
            .apply()
    }

    fun getBooleanData(key: String?): Boolean {
        return try {
            prefs.getBoolean(key, false)
        } catch (e: Exception) {
            false
        }
    }


    fun getLongData(key: String, def: Long): Long {
        return prefs.getLong(key, def)
    }

    fun getIntData(key: String?): Int {
        return try {
            prefs.getInt(key, 1)
        } catch (e: Exception) {
            0
        }
    }

    fun getSavedIntData(key: String?): Int {
        return try {
            prefs.getInt(key, 0)
        } catch (e: Exception) {
            0
        }
    }

    fun getIntDataCustom(key: String?): Int {
        return try {
            prefs.getInt(key, Color.parseColor("#d1d1d1"))
        } catch (e: Exception) {
            0
        }
    }

    fun getIntData(key: String?, def: Int): Int {
        return try {
            prefs
                .getInt(key, def)
        } catch (e: Exception) {
            0
        }
    }

    fun getStringData(key: String): String? {
        return if (key.contains("app_version_code")) {
            try {
                prefs.getString(key, "")
            } catch (e: Exception) {
                ""
            }
        } else {
            prefs.getString(key, "")
        }
    }

    var mmsFileSizeLimit: Long
        get() = prefs.getLong(MMS_FILE_SIZE_LIMIT, FILE_SIZE_600_KB)
        set(mmsFileSizeLimit) = prefs.edit().putLong(MMS_FILE_SIZE_LIMIT, mmsFileSizeLimit).apply()

    var blockedKeywords: Set<String>
        get() = prefs.getStringSet(BLOCKED_KEYWORDS, HashSet<String>())!!
        set(blockedKeywords) = prefs.edit().putStringSet(BLOCKED_KEYWORDS, blockedKeywords).apply()

    fun addBlockedKeyword(keyword: String) {
        blockedKeywords = blockedKeywords.plus(keyword)
    }

    fun removeBlockedKeyword(keyword: String) {
        blockedKeywords = blockedKeywords.minus(keyword)
    }

    var exportSms: Boolean
        get() = prefs.getBoolean(EXPORT_SMS, true)
        set(exportSms) = prefs.edit().putBoolean(EXPORT_SMS, exportSms).apply()

    var exportMms: Boolean
        get() = prefs.getBoolean(EXPORT_MMS, true)
        set(exportMms) = prefs.edit().putBoolean(EXPORT_MMS, exportMms).apply()

    var importSms: Boolean
        get() = prefs.getBoolean(IMPORT_SMS, true)
        set(importSms) = prefs.edit().putBoolean(IMPORT_SMS, importSms).apply()

    var importMms: Boolean
        get() = prefs.getBoolean(IMPORT_MMS, true)
        set(importMms) = prefs.edit().putBoolean(IMPORT_MMS, importMms).apply()

    var wasDbCleared: Boolean
        get() = prefs.getBoolean(WAS_DB_CLEARED, false)
        set(wasDbCleared) = prefs.edit().putBoolean(WAS_DB_CLEARED, wasDbCleared).apply()

    var firstTimeLoadData: Boolean
        get() = prefs.getBoolean("FIRSTTIMELOADDATA", false)
        set(firstTimeLoadData) = prefs.edit().putBoolean("FIRSTTIMELOADDATA", firstTimeLoadData)
            .apply()


    var snackBarClosedDate: String?
        get() = prefs.getString("snackBarClosedDate", null)
        set(value) = prefs.edit().putString("snackBarClosedDate", value).apply()

    var keyboardHeight: Int
        get() = prefs.getInt(SOFT_KEYBOARD_HEIGHT, context.getDefaultKeyboardHeight())
        set(keyboardHeight) = prefs.edit().putInt(SOFT_KEYBOARD_HEIGHT, keyboardHeight).apply()

    var snackBarClosedTimestamp: Long
        get() = prefs.getLong("snack_bar_closed_timestamp", 0L)
        set(keyboardHeight) = prefs.edit().putLong("snack_bar_closed_timestamp", keyboardHeight)
            .apply()


    var isLoadingComplete: Boolean
        get() = prefs.getBoolean("LoadingComplete", false)
        set(useRecycleBin) = prefs.edit().putBoolean("LoadingComplete", useRecycleBin).apply()

    var useRecycleBin: Boolean
        get() = prefs.getBoolean(USE_RECYCLE_BIN, true)
        set(useRecycleBin) = prefs.edit().putBoolean(USE_RECYCLE_BIN, useRecycleBin).apply()

    var lastRecycleBinCheck: Long
        get() = prefs.getLong(LAST_RECYCLE_BIN_CHECK, 0L)
        set(lastRecycleBinCheck) = prefs.edit().putLong(LAST_RECYCLE_BIN_CHECK, lastRecycleBinCheck)
            .apply()

    var isArchiveAvailable: Boolean
        get() = prefs.getBoolean(IS_ARCHIVE_AVAILABLE, true)
        set(isArchiveAvailable) = prefs.edit().putBoolean(IS_ARCHIVE_AVAILABLE, isArchiveAvailable)
            .apply()
    var isPrivatchatAvailable: Boolean
        get() = prefs.getBoolean(IS_PRIVATE_AVAILABLE, true)
        set(isArchiveAvailable) = prefs.edit().putBoolean(IS_PRIVATE_AVAILABLE, isArchiveAvailable)
            .apply()

    var customNotifications: Set<String>
        get() = prefs.getStringSet(CUSTOM_NOTIFICATIONS, HashSet<String>())!!
        set(customNotifications) = prefs.edit()
            .putStringSet(CUSTOM_NOTIFICATIONS, customNotifications).apply()

    fun addCustomNotificationsByThreadId(threadId: Long) {
        customNotifications = customNotifications.plus(threadId.toString())
    }

    fun removeCustomNotificationsByThreadId(threadId: Long) {
        customNotifications = customNotifications.minus(threadId.toString())
    }

    var bubbleStyle: Int
        get() = prefs.getInt(BUBBLE_STYLE, BUBBLE_STYLE_IOS_NEW)
        set(bubbleStyle) = prefs.edit().putInt(BUBBLE_STYLE, bubbleStyle).apply()

    var bubbleInvertColor: Boolean
        get() = prefs.getBoolean(BUBBLE_INVERT_COLOR, false)
        set(bubbleInvertColor) = prefs.edit().putBoolean(BUBBLE_INVERT_COLOR, bubbleInvertColor)
            .apply()

    var bubbleInContactColor: Boolean
        get() = prefs.getBoolean(BUBBLE_IN_CONTACT_COLOR, false)
        set(bubbleInContactColor) = prefs.edit()
            .putBoolean(BUBBLE_IN_CONTACT_COLOR, bubbleInContactColor).apply()

    var actionOnMessageClickSetting: Int
        get() = prefs.getInt(ACTION_ON_MESSAGE_CLICK, ACTION_NOTHING)
        set(actionOnMessageClickSetting) = prefs.edit()
            .putInt(ACTION_ON_MESSAGE_CLICK, actionOnMessageClickSetting).apply()

//    var threadTopStyle: Int
//        get() = prefs.getInt(THREAD_TOP_STYLE, THREAD_TOP_LARGE)
//        set(threadTopStyle) = prefs.edit().putInt(THREAD_TOP_STYLE, threadTopStyle).apply()

    var unreadAtTop: Boolean = false
//        get() = prefs.getBoolean(UNREAD_AT_TOP, false)
//        set(unreadAtTop) = prefs.edit().putBoolean(UNREAD_AT_TOP, unreadAtTop).apply()

    var unreadIndicatorPosition: Int
        get() = prefs.getInt(UNREAD_INDICATOR_POSITION, UNREAD_INDICATOR_START)
        set(unreadIndicatorPosition) = prefs.edit()
            .putInt(UNREAD_INDICATOR_POSITION, unreadIndicatorPosition).apply()

    var showSimSelectionDialog: Boolean
        get() = prefs.getBoolean(SHOW_SIM_SELECTION_DIALOG, false)
        set(showSimSelectionDialog) = prefs.edit()
            .putBoolean(SHOW_SIM_SELECTION_DIALOG, showSimSelectionDialog).apply()

    //Swipe
    var swipeRightAction: Int
        get() = prefs.getInt(SWIPE_RIGHT_ACTION, SWIPE_ACTION_MARK_READ)
        set(swipeRightAction) = prefs.edit().putInt(SWIPE_RIGHT_ACTION, swipeRightAction).apply()

    var swipeLeftAction: Int
        get() = prefs.getInt(SWIPE_LEFT_ACTION, SWIPE_ACTION_DELETE)
        set(swipeLeftAction) = prefs.edit().putInt(SWIPE_LEFT_ACTION, swipeLeftAction).apply()

    var swipeVibration: Boolean
        get() = prefs.getBoolean(SWIPE_VIBRATION, true)
        set(swipeVibration) = prefs.edit().putBoolean(SWIPE_VIBRATION, swipeVibration).apply()


}
