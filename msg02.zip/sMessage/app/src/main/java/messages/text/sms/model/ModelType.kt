package messages.text.sms.model

interface ModelType {
    val CONVERSATION_TYPE: Int
        get() = 1

    val AD_TYPE: Int
        get() = 2

    fun getType(): Int
}