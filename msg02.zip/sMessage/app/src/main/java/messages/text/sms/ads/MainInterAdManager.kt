package  messages.text.sms.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import messages.text.sms.R
import messages.text.sms.ads.GoogleInterAdManager.loadAdGeneral
import messages.text.sms.ads.GoogleInterAdManager.loadAdMain


object MainInterAdManager {
    var isLoading = false
    var isGeneralLoading = false
    var showInterTime: Long = 0
    var adinterval: Long = 0
    var enablead: Boolean = false
    var interex1: String = ""
    var interex2: String = ""

    fun loadManageAppsInter(activity: Activity) {
        if (isLoading) return
        isLoading = true
        GoogleInterAdManager.loadManageAppsInter(activity)
    }

    fun loadGeneralInter(activity: Context, deflt: Int = 0) {

        val adId = if (deflt == 0) {
            val id = activity.getAppPermissionInter()
            id
        } else {
            val id = activity.getString(R.string.permission_inter_2)
            id
        }

        if (!AdsPreferences(activity).adsEnable) return

        tryLoadAd(activity, adId)

    }

    private var lastAdLoadTime = 0L

    fun tryLoadAd(activity: Context, adId: String) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastAdLoadTime >= 2000) { // 2 seconds = 2000 ms
            lastAdLoadTime = currentTime
            loadAdGeneral(activity, adId)

        }
    }


    fun loadHomeInter(activity: Context) {

        Log.d("HomeInterAd", "loadHomeInter() called")

        if (!AdsPreferences(activity).adsEnable) {
            Log.d("HomeInterAd", "Ads disabled → skipping interstitial load")
            return
        }

        val adId = activity.getAppMainInter()
        Log.d("HomeInterAd", "Interstitial Ad ID = $adId")


        Log.d("HomeInterAd", "Loading Home Interstitial Ad")
        loadAdMain(activity, adId)
    }


    fun langInterLoaded(): Boolean {
        return GoogleInterAdManager.langInterLoaded()
    }

    fun showGeneralInterAds(activity: Activity, forward: Boolean, dismissCallback: () -> Unit) {
        GoogleInterAdManager.showGeneralInterAds(activity, dismissCallback, forward)
    }

    fun showMainInterAds(activity: Activity, dismissCallback: () -> Unit) {
        GoogleInterAdManager.showMainInterAds(activity, dismissCallback)
    }

    /*  fun loadGeneralInter(activity: Activity) {
          if (isGeneralLoading && showInterTime != 0L) {
              if (!activity.AdsPreferences(context).adsEnable || adinterval == 0L || !enablead) return
              val diff = Date().time - showInterTime
              Log.e("LLL_Splash", "loadBackPressInter: $diff")
              if (diff < (adinterval * 1000)) {
                  return
              }
              if (isGeneralLoading2) return
              isGeneralLoading2 = true
              val adId = if (activity.isFirstTimeAppOpen()) interex1 else interex2
              Log.e("LLL_Splash", "loadBackPressInter: $adId")
              GoogleInterAdManager.loadAdGeneral(activity, adId)
          }

          if (isGeneralLoading) return
          isGeneralLoading = true
          GoogleInterAdManager.loadAdGeneral(activity, activity.getAppBackPressedInter())
      }*/


    fun showManageAppsInter(activity: Activity, dismissCallback: () -> Unit) {
        GoogleInterAdManager.showManageAppsInter(activity, dismissCallback)
    }


    fun showGeneralInter(activity: Activity, dismissCallback: () -> Unit) {
        GoogleInterAdManager.showGeneralInter(activity, dismissCallback)
    }


    fun isLoadingAds() = isLoading

    fun onDestroy() {
        isGeneralLoading = false
        isLoading = false
        GoogleInterAdManager.onDestroy()
        showInterTime = 0
        adinterval = 0
        enablead = false
        interex1 = ""
        interex2 = ""
    }
}