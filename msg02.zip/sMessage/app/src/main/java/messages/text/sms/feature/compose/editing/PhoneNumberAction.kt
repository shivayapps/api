package messages.text.sms.feature.compose.editing

enum class PhoneNumberAction {
    CANCEL,
    JUST_ONCE,
    ALWAYS
}
