package messages.text.sms.compat

import android.telephony.SubscriptionInfo

data class SubscriptionInfoCompat(private val subscriptionInfo: SubscriptionInfo) {

    val subscriptionId get() = subscriptionInfo.subscriptionId

    val simSlotIndex get() = subscriptionInfo.simSlotIndex

    val displayName get() = subscriptionInfo.displayName

}