package messages.text.sms.appmanager

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import messages.text.sms.R
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.feature.main.SplashActivity

class AlarmReceiver : BroadcastReceiver() {

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onReceive(context: Context, intent: Intent) {
//        Log.e("AppReceiver","onReceiveAlarm")
//        Toast.makeText(context, ALARM_MESSAGE, Toast.LENGTH_LONG).show()
//        val notificationManager = NotificationManagerCompat.from(context)
//        notificationManager.cancel(1)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    @SuppressLint("UnspecifiedImmutableFlag")
    private fun showNotification(context: Context, title: String, message: String) {
        val mNotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_2,
                CH_ID,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            channel.description = EXAMPLE_ALARM
            mNotificationManager.createNotificationChannel(channel)
        }

        Log.e("@@@@####", "setSound 1---> " + Uri.parse(context.baseConfig.ringtoneUri))
        val mBuilder = NotificationCompat.Builder(context, CHANNEL_ID_2)
            .setSmallIcon(R.drawable.ic_message_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setSound(Uri.parse(context.baseConfig.ringtoneUri))
            .setAutoCancel(true)

        Log.e("@@@@####", "setSound 6---> " + Uri.parse(context.baseConfig.ringtoneUri))
        mBuilder.setDefaults(Notification.DEFAULT_ALL)

        val intent = Intent(context, SplashActivity::class.java)

        val pi =
            PendingIntent.getActivity(context, REQUEST_CODE, intent, PendingIntent.FLAG_IMMUTABLE)

        mBuilder.setContentIntent(pi)
        mNotificationManager.notify(NOTIFICATION_ALARM_ID, mBuilder.build())
    }

}
