package messages.text.sms.feature.personalize

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.ads.MainInterAdManager
import messages.text.sms.ads.app_ringtone_applied_successfully
import messages.text.sms.ads.app_ringtones_list_activity_open
import messages.text.sms.ads.firebaseAnalyticsHandler
import messages.text.sms.ads.getActivityName
import messages.text.sms.common.MysmsApplication.Companion.isHomeInterShow
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.extensions.viewBinding
import messages.text.sms.commons.adapters.RingtoneListAdapter
import messages.text.sms.commons.extensions.baseConfig
import messages.text.sms.commons.extensions.clientConfigPref
import messages.text.sms.commons.extensions.updateTextColors
import messages.text.sms.databinding.ActivityRintoneListBinding
import messages.text.sms.model.Ringtone


class RingtonesListActivity : MainBaseThemedActivity() {


    private lateinit var adapter: RingtoneListAdapter
    var mp: MediaPlayer? = null
    var ringtoneuri: String = ""

    private lateinit var list: ArrayList<Ringtone>

    private val binding by viewBinding(ActivityRintoneListBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationIcon(R.drawable.ic_chevron_left_vector)

        showBackButton(true)
        setTitle(R.string.ringtone)

        list = ArrayList<Ringtone>().apply {
            add(Ringtone("Sound Off", R.drawable.ic_ringtone_bg_sound_off, 0))
            add(Ringtone("Default", R.drawable.ic_ringtone_bg_default, 1))
            add(Ringtone("Bling", R.drawable.ic_ringtone_bg_bling, R.raw.ringtone_bling))
            add(Ringtone("Android", R.drawable.ic_ringtone_bg_android, R.raw.ringtone_android))
            add(Ringtone("Whistle", R.drawable.ic_ringtone_bg_whistle, R.raw.ringtone_whistle))
            add(Ringtone("Ting", R.drawable.ic_ringtone_bg_ting, R.raw.ringtone_ting))
            add(Ringtone("Alert", R.drawable.ic_ringtone_bg_alert, R.raw.ic_ringtone_alert))
            add(
                Ringtone(
                    "Instruments", R.drawable.ic_ringtone_bg_instruments,
                    R.raw.ringtone_instrumental
                )
            )
            add(Ringtone("Soul", R.drawable.ic_ringtone_bg_soul, R.raw.ringtone_soul))
            add(Ringtone("Love", R.drawable.ic_ringtone_bg_love, R.raw.ringtone_love))
            add(Ringtone("Water", R.drawable.ic_ringtone_bg_water, R.raw.ringtone_waterdrop))
            add(Ringtone("Tick", R.drawable.ic_ringtone_bg_tick, R.raw.ringtone_tick))
            add(Ringtone("System", R.drawable.ic_ringtone_bg_system, 12))
            add(Ringtone("Customize", R.drawable.ic_ringtone_bg_customize, 13))
        }

        setUI()
        setUpTheme()

        firebaseAnalyticsHandler.logMessages(
            app_ringtones_list_activity_open, getActivityName()
        )
    }

    private fun setUpTheme() {

        Log.e("MainActivity", "setUpTheme.useImageResource:${baseConfig.useImageResource}")
        Log.e("MainActivity", "setUpTheme.storedImageResource:${baseConfig.storedImageResource}")

        updateTextColors(binding.contentView)
        //  binding.toolbarTitle.setTextColor(baseConfig.primaryColor)

        if (baseConfig.backgroundColor.equals(Color.parseColor("#000000"))) {
            binding.contentView.background =
                ColorDrawable(resources.getColor(R.color.bottom_tabs_black_background_new))

        } else {
            binding.contentView.background = ColorDrawable(baseConfig.backgroundColor)

        }

        if (baseConfig.useImageResource) {
            if (baseConfig.storedImageResource == -1) {

            } else {
                Log.i("onCreate", "onCreateitemselse11111: ")
                val drawable = ContextCompat.getDrawable(this, baseConfig.storedImageResource)
                binding.contentView.background = drawable
                toolbar.setBackgroundColor(resources.getColor(R.color.transperent))
            }
        } else {
            val primaryColor = baseConfig.primaryColor
            Log.i("onCreate", "onCreateitemselse: ")
            toolbar.setBackgroundColor(baseConfig.backgroundColor)
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 5555 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }

            startActivityForResult(
                Intent.createChooser(intent, getString(R.string.select_mp3)),
                1313
            )
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, intent)

        if (resultCode == RESULT_OK && requestCode == 1212) {
            data?.let { uri ->
                val alertUri =
                    data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                if (alertUri != null) {
                    handleSelectedMp3(alertUri)
                    baseConfig.ringtoneSelected = 12
                }
            }
        }

        if (requestCode == 1313 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                // uri is the Uri of the selected file
                handleSelectedMp3(uri)
                baseConfig.ringtoneSelected = 13
            }
        }


    }

    private fun handleSelectedMp3(alertUri: Uri) {
        if (mp != null) {
            if (mp!!.isPlaying) mp!!.stop()

        }
        mp = MediaPlayer.create(
            this@RingtonesListActivity,
            alertUri
        )
        mp?.setLooping(false)
        mp?.start()
        ringtoneuri = alertUri.toString()
        baseConfig.ringtoneUri = ringtoneuri
        Toast.makeText(this, getString(R.string.ringtone_applied_successfully), Toast.LENGTH_SHORT)
            .show()

        adapter.notifyDataSetChanged()


        firebaseAnalyticsHandler.logMessages(
            app_ringtone_applied_successfully, getActivityName()
        )


    }

    private fun setUI() {

        binding.rvRingtone.layoutManager = GridLayoutManager(this, 2)
        adapter = RingtoneListAdapter(this@RingtonesListActivity, list) { name, position ->


            when (position) {
                0 -> {
                    ringtoneuri = "null"
                    baseConfig.ringtoneSelected = 0
                    adapter.notifyDataSetChanged()
                }

                1 -> {

                    //  ringtoneuri = "default"
                    baseConfig.ringtoneSelected = 1
                    val defaultToneUri: Uri =
                        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    handleSelectedMp3(defaultToneUri)

                }

                12 -> {

                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                    intent.putExtra(
                        RingtoneManager.EXTRA_RINGTONE_TYPE,
                        RingtoneManager.TYPE_NOTIFICATION
                    )
                    intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Tone")
                    intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, null as Uri?)
                    intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    this.startActivityForResult(intent, 1212)
                }

                13 -> {
                    if (ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        ActivityCompat.requestPermissions(
                            this,
                            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                            5555
                        )
                    } else {
                        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                            type = "audio/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }

                        startActivityForResult(Intent.createChooser(intent, "Select MP3"), 1313)
                    }

                    /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                         // For Android 13+ (API 33), request the READ_MEDIA_AUDIO permission
                         if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                             ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_MEDIA_AUDIO), 5555)
                         } else {
                             openAudioFileChooser()
                         }
                     } else {
                         // For Android 12 and below, request the READ_EXTERNAL_STORAGE permission
                         if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                             ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 5555)
                         } else {
                             openAudioFileChooser()
                         }
                     }*/

                }

                else -> {

                    val alertUri: Uri =
                        Uri.parse("android.resource://${packageName}/${list.get(position).sound}")

                    baseConfig.ringtoneSelected = position
                    handleSelectedMp3(alertUri)
                }


            }


        }

        binding.rvRingtone.adapter = adapter

    }


    override fun onBackPressed() {

        // Stop media player safely
        mp?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
            mp = null
        }

        if (clientConfigPref.enableBackPressInter && !isHomeInterShow) {
            Log.e("Message_Log", "enable_back_press_inter - showMainInterAds")

            MainInterAdManager.showMainInterAds(this) {
                Log.e("Message_Log", "enable_back_press_inter - isHomeInterShow = true")
                isHomeInterShow = true
                finish()
            }

        } else {
            Log.e("Message_Log", "enable_back_press_inter - finish")
            finish()
        }
    }


    override fun onPause() {
        super.onPause()

        if (mp != null) {
            if (mp!!.isPlaying) mp!!.stop()
        }
    }

}