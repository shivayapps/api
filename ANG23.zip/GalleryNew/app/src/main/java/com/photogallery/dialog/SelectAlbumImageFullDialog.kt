package com.photogallery.dialog

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.adapter.PhotoAdapter
import com.photogallery.databinding.DialogAddAlbumFullBinding
import com.photogallery.model.MediaData
import com.photogallery.utils.Preferences

class SelectAlbumImageFullDialog(
    var mContext: Activity,
    var albumDataList: ArrayList<MediaData>,
    val selectPathListener: (path: String) -> Unit,
    val createAlbumListener: () -> Unit
) : DialogFragment() {

    lateinit var binding: DialogAddAlbumFullBinding
    lateinit var albumAdapter: PhotoAdapter

    //    var albumList: ArrayList<PictureData> = ArrayList()
    var albumList: ArrayList<Any> = ArrayList()
    var selectPos = 0
    var preferences: Preferences = Preferences(mContext)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.FullScreenDialog)
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            val width = ViewGroup.LayoutParams.MATCH_PARENT
            val height = ViewGroup.LayoutParams.MATCH_PARENT
            dialog.window!!.setLayout(width, height)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        super.onCreateView(inflater, container, savedInstanceState)
        binding = DialogAddAlbumFullBinding.inflate(layoutInflater, container, false)

        intView()

        return binding.root
    }

    private fun intView() {

        binding.txtTitle.text = mContext.getString(R.string.select_cover_image)

//        val newAlbum=preferences.getLastAlBumCreated()
//        if(newAlbum.isNotEmpty()) {
//            albumList.add(AlbumData(newAlbum.getFilenameFromPath(),folderPath=newAlbum, isCustomAlbum = true))
//        }
//        albumList.addAll(albumList.size, albumDataList.filter { it.isVideo==false })

        albumList.addAll(albumList.size, albumDataList)

        initAdapter()
        initListener()
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener { dismiss() }
        binding.btnDone.setOnClickListener { dismiss() }
    }

    private fun initAdapter() {
        albumAdapter = PhotoAdapter(mContext, clickListener = {
            if (albumList[it] is MediaData) {
                selectPos = it
                val albumData = albumList[selectPos]
                dismiss()
                selectPathListener.invoke((albumData as MediaData).filePath)
            }

        }, longClickListener = {
            if (albumList[it] is MediaData) {
            }
        }, headerSelectListener = {

        })
        albumAdapter.submitList(albumList)
        val gridLayoutManager = GridLayoutManager(mContext, 3, RecyclerView.VERTICAL, false)
        binding.albumRecycler.layoutManager = gridLayoutManager
        binding.albumRecycler.adapter = albumAdapter
    }

}
