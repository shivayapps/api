package vi.imagestopdf;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//SharedPreferences manager class
public class SharedPrefs {

    public static final String KEY_IS_GRID = "KEY_IS_GRID ";
    public static final String IS_A_TO_Z = "IS_A_TO_Z";
    public static final String APP_OPEN_COUNT = "app_open_count";
    public static String TAG="SharedPrefs";
    //// TODO: 2020-07-09 for rate dialog
    public static String key_dialog="keyDialog";

    public static final String AD_INDEX = "ad_index";
    public static String Folder_Entry = "Folder_Entry";

    public static String isIntroDone = "isIntroDone";

    public static String key_subscription="keySubscription";
    public static String key_offer="keyOffer";
    public static String key_offers="keyOffers";
    public static String isSecondTime = "isSecondTime";


    // TODO: 2020-07-09 For SUBSCRIPTION

    public static final String IS_SUBSCRIPTION="IS_SUBSCRIPTION";
    public static final String LIMIT_OVER = "LIMIT_OVER";
    public static final String ISAUTORENEW_LIFE = "ISAUTORENEW_LIFE";
    public static final String ISAUTORENEW_MONTH ="ISAUTORENEW_MONTH" ;
    public static final String ISAUTORENEW_YEAR ="ISAUTORENEW_YEAR" ;
    public static final String PRICE_YEAR ="PRICE_YEAR" ;
    public static final String PRICE_MONTH="PRICE_MONTH";
    public static final String NONE="None";
    public static final String PRICE_DISCOUNT ="PRICE_DISCOUNT";
    public static final String TRIAL_MONTH="TRIAL_MONTH";
    public static final String TRIAL_DISCOUNT ="TRIAL_DISCOUNT";
    public static final String TRIAL_YEAR="TRIAL_YEAR";
    public static final String FIRST_MONTH_PRICE="first_month_price";
    // TODO: plan_details
    public static final String ACCOUNTTYPE = "ACCOUNTTYPE";
    public static final String PLAN_START_DATE = "PLAN_START_DATE";
    public static final String PLAN_END_DATE = "PLAN_END_DATE";
    public static final String PLAN_ID = "PLAN_ID";
    public static final String TOTAL_SPACE = "TOTAL_SPACE";
    public static final String TOTal_LIMITE = "TOTal_LIMITE";
    public static final String TODAY_DATE = "todatdate";
    public static final String CURRENT_DATE = "current_date";





    // TODO: 2020-07-09 Comman CODE
    public static final String COUNT = "more_app_count";

    // TODO: 2020-07-09 DELETE CURRUPTED PDF
    public static String PdfName="" ;
    public static String docCount = "docCount";


    // TODO: SharedPreferences file name
    private static String SHARED_PREFS_FILE_NAME = "man_ride_suit_shared_prefs";

    // TODO: use for getting current device id
    public static final String DEVICE_ID = "device_id";

    // TODO: login ragi detail
    public static final String UID = "uid";
    public static final String loginWith = "loginWith";
    public static final String uemail = "uemail";
    public static final String username = "username";
    public static final String token = "token";

    public static final String backupUserID = "backupUserID";
    public static final String subscription_userID = "subscription_userID";
    public static final String backupUserEmail = "backupUserEmail";
    public static final String AccessTokan = "AccessTokan";
    public static final String UserName = "bUserName";

    // TODO: save facebook accesstoken
    public static final String AccessToken = "AccessToken";


    // TODO: save facebool profile id
    public static final String ProfileId = "ProfileId";
    public static final String IS_ADS_REMOVED = "IS_ADS_REMOVED";
    public static final String PRODUCT_ID = "Which_Product";
    public static final String SPLASH_AD_DATA = "Ad_data";

    // TODO: use for offline data
    public static final String ITEM_SIZE = "item_size";
    public static final String IS_AUTO_RENEW_YEAR="IS_AUTO_RENEW_YEAR";
    public static final String IS_AUTO_RENEW_WEEK="IS_AUTO_RENEW_WEEK";
    public static final String IS_AUTO_RENEW_MONTH="IS_AUTO_RENEW_MONTH";


    public static final String KEY_CREDIT_LEFT = "key_credit_left";




    public  static  void compareDates(Context context) {



        //todo IS_SUBSCRIPTION false then user expire
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Log.e(TAG, "compareDates: aavyu");

        try {
            Date currentDate = sdf.parse(timeStamp);
            Date expiryDate = null;
            Log.e(TAG, "compareDates: " + SharedPrefs.getString(context, SharedPrefs.PLAN_END_DATE));
            if (!SharedPrefs.getString(context, SharedPrefs.PLAN_END_DATE).equalsIgnoreCase("")) {
                expiryDate = sdf.parse(SharedPrefs.getString(context, SharedPrefs.PLAN_END_DATE));
                String date;
//                expiryDate = sdf.parse("2019-08-20 09:14:21");
            } else {
                SharedPrefs.save(context, SharedPrefs.IS_SUBSCRIPTION, true);
                return;
            }

            if (currentDate.compareTo(expiryDate) > 0) {
                Log.e(TAG, "compareDates: 1");
                SharedPrefs.save(context, SharedPrefs.IS_SUBSCRIPTION, false);
            } else if (currentDate.compareTo(expiryDate) < 0) {
                Log.e(TAG, "compareDates: 2");
                SharedPrefs.save(context, SharedPrefs.IS_SUBSCRIPTION, true);
            } else if (currentDate.compareTo(expiryDate) == 0) {
                Log.e(TAG, "compareDates: 3");
                SharedPrefs.save(context, SharedPrefs.IS_SUBSCRIPTION, false);
            } else {
                Log.e(TAG, "compareDates: 4 else");
                SharedPrefs.save(context, SharedPrefs.IS_SUBSCRIPTION, false);
            }

            // TODO: 2019-10-21 check for user plan expire or not

            if (SharedPrefs.getString(context, SharedPrefs.ACCOUNTTYPE).equals("Basic")) {
                SharedPrefs.save(context, SharedPrefs.LIMIT_OVER, true);
            } else {
                SharedPrefs.save(context, SharedPrefs.LIMIT_OVER, false);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }



    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_PRIVATE);
    }

    public static boolean contain(Context context, String key) {
        return getPrefs(context).contains(key);
    }

    public static void clearPrefs(Context context) {
        String device_id = getString(context, DEVICE_ID);
        getPrefs(context).edit().clear().commit();
        save(context, DEVICE_ID, device_id);
    }

    //Save Booleans
    public static void savePref(Context context, String key, boolean value) {
        getPrefs(context).edit().putBoolean(key, value).commit();
    }

    //Get Booleans
    public static boolean getBoolean(Context context, String key) {
        return getPrefs(context).getBoolean(key, false);
    }

    //Get Booleans if not found return activity_new_video_cutter predefined default value
    public static boolean getBoolean(Context context, String key, boolean defaultValue) {
        return getPrefs(context).getBoolean(key, defaultValue);
    }

    //Strings
    public static void save(Context context, String key, String value) {
        getPrefs(context).edit().putString(key, value).commit();
    }

    public static String getString(Context context, String key) {
        return getPrefs(context).getString(key, "");
    }

    public static String getString(Context context, String key, String defaultValue) {
        return getPrefs(context).getString(key, defaultValue);
    }

    //Integers
    public static void save(Context context, String key, int value) {
        getPrefs(context).edit().putInt(key, value).commit();
    }

    public static int getInt(Context context, String key) {
        return getPrefs(context).getInt(key, 0);
    }

    public static int getInt(Context context, String key, int defaultValue) {
        return getPrefs(context).getInt(key, defaultValue);
    }

    //Floats
    public static void save(Context context, String key, float value) {
        getPrefs(context).edit().putFloat(key, value).commit();
    }

    public static float getFloat(Context context, String key) {
        return getPrefs(context).getFloat(key, 0);
    }

    public static float getFloat(Context context, String key, float defaultValue) {
        return getPrefs(context).getFloat(key, defaultValue);
    }

    //Longs
    public static void save(Context context, String key, long value) {
        getPrefs(context).edit().putLong(key, value).commit();
    }public static void save(Context context, String key, boolean value) {
        getPrefs(context).edit().putBoolean(key, value).commit();
    }

    public static long getLong(Context context, String key) {
        return getPrefs(context).getLong(key, 0);
    }

    public static long getLong(Context context, String key, long defaultValue) {
        return getPrefs(context).getLong(key, defaultValue);
    }

    public static void removeKey(Context context, String key) {
        getPrefs(context).edit().remove(key).commit();
    }



}