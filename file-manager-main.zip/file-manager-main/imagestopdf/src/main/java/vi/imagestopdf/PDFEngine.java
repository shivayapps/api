package vi.imagestopdf;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by droidNinja on 25/07/16.
 */
public class PDFEngine {
    private static PDFEngine ourInstance = new PDFEngine();

    public static PDFEngine getInstance() {
        return ourInstance;
    }

    private boolean isShare;
    private int quality;
    private boolean isNeedToShow;

    private PDFEngine() {}

    public void createPDF(Context context, ArrayList<File> files, CreatePDFListener createPDFListener, String name, boolean isShare, int quality, boolean isNeedToShow) {
        this.isShare = isShare;
        this.quality = quality;
        this.isNeedToShow = isNeedToShow;
        new CreatePDFTask(context, files, createPDFListener, name, isShare, quality, isNeedToShow).execute();
    }


    public boolean checkIfPDFExists(ArrayList<File> files, String pdfFileName) {
        if (pdfFileName != null && pdfFileName.equals(Utils.getPDFName(files))) {
            File pdfFile = new File(Utils.PDFS_PATH + File.separator + pdfFileName);
            return pdfFile.exists();
        }

        return false;
    }

    public void sharePDF(Context context, File pdfFile) {
        Intent intentShareFile = new Intent(Intent.ACTION_SEND);

        if (pdfFile.exists()) {
            intentShareFile.setType("application/pdf");
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Make more PDF with app link \n https://play.google.com/store/apps/" +
                    "details?id=com.photo.image.video.photogallery");
            intentShareFile.putExtra(Intent.EXTRA_STREAM, Uri.parse(pdfFile.getPath()));
            intentShareFile.putExtra(Intent.EXTRA_SUBJECT, "Shared via Camera Scanner");

            context.startActivity(Intent.createChooser(intentShareFile, "Share PDF"));
        }
    }

    public static String getScreenShot(View view, String filename) {
        view.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
        view.setDrawingCacheEnabled(false);
        Document document = new Document(PageSize.A4, 38, 38, 50, 38);

        String path = store(bitmap, "" + System.currentTimeMillis());
        String directoryPath = Environment.getExternalStorageDirectory().toString();
        File dir = new File(Utils.PDFS_PATH);
        if (!dir.exists())
            dir.mkdirs();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(Utils.PDFS_PATH + "/" + filename + ".pdf")); //  Change pdf's name.
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        document.open();
        Rectangle documentRect = document.getPageSize();

        Image image = null;  // Change image's name and extension.
        try {
            image = Image.getInstance(path);
        } catch (BadElementException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        float scaler = ((document.getPageSize().getWidth()) / bitmap.getWidth()) * 100;
        image.scalePercent(scaler);
        image.setAlignment(Image.ALIGN_CENTER | Image.ALIGN_CENTER);
        image.setAbsolutePosition((documentRect.getWidth() - image.getScaledWidth()) / 2,
                (documentRect.getHeight() - image.getScaledHeight()) / 2);

        try {
            document.add(image);
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        document.close();


        return Utils.PDFS_PATH + "/" + filename + ".pdf";
    }

    public static String store(Bitmap bm, String fileName) {
        final String dirPath = Utils.PDFS_PATH1 + "/Screenshots";
        File dir = new File(dirPath);
        if (!dir.exists())
            dir.mkdirs();
        File file = new File(dirPath, fileName);
        try {
            FileOutputStream fOut = new FileOutputStream(file);
            bm.compress(Bitmap.CompressFormat.PNG, 85, fOut);
            fOut.flush();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file.getAbsolutePath();
    }

    public static String store1(Bitmap bm, String fileName) {
        final String dirPath = Utils.IDCard;
        File dir = new File(dirPath);
        if (!dir.exists())
            dir.mkdirs();
        File file = new File(dirPath, fileName + ".jpg");
        try {
            FileOutputStream fOut = new FileOutputStream(file);
            bm.compress(Bitmap.CompressFormat.PNG, 85, fOut);
            fOut.flush();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file.getAbsolutePath();
    }

}
