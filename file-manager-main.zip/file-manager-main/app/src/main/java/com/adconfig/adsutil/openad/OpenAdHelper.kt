package com.adconfig.adsutil.openad

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.annotation.NonNull
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.utils.AdsError
import com.adconfig.adsutil.utils.AdsListener
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.Date

object OpenAdHelper {

    private val TAG: String = "ADCONFIG_${javaClass.simpleName}"

    private var mAppOpenAd: AppOpenAd? = null

    private var adLoadTime: Long = 0
    private var isOpenAdShowing: Boolean = false

    var isAdLoading: Boolean = false

    private var mListener: AdsListener? = null

    private fun loadOpenAd(
        @NonNull fContext: Context,
        @NonNull fListener: AdsListener,
        mAdId: String? = ""
    ) {
        var lAppOpenAd: AppOpenAd?
        var adId = Config.admobAppOpenId
        if (mAdId?.length!! > 0) {
            adId = mAdId
        }

        // Log.i(TAG, "Request loadOpenAd:$mAdId")
        isAdLoading = true
        AppOpenAd.load(
            fContext,
            adId,
            AdRequest.Builder().build(),
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            object : AppOpenAd.AppOpenAdLoadCallback() {

                override fun onAdLoaded(appOpenAd: AppOpenAd) {
                    super.onAdLoaded(appOpenAd)
                    isAdLoading = false
                    // Log.i(TAG, "onAdLoaded: ")
                    lAppOpenAd = appOpenAd
                    adLoadTime = Date().time
//                    fListener.onAppOpenAdLoaded(appOpenAd = appOpenAd)
                    fListener.onAdLoaded(appOpenAd)

                    lAppOpenAd?.fullScreenContentCallback =
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                                // Log.i(TAG, "onAdClosed: ")
                                isOpenAdShowing = false
//                            fListener.onAdClosed()
                                fListener.onAdDismissed()
                            }

                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                                fListener.onAdShowed()
                                isOpenAdShowing = true
                                lAppOpenAd = null
                            }

                            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                                super.onAdFailedToShowFullScreenContent(adError)
                                // Log.i(
//                                    TAG,
//                                    "onAdFailedToShowFullScreenContent: \nErrorMessage::${adError.message}\nErrorCode::${adError.code}"
//                                )
                            }
                        }
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    super.onAdFailedToLoad(adError)
                    isAdLoading = false

                    Log.i(
                        TAG,
                        "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                    )
                    lAppOpenAd = null
                    fListener.onAdFailedToShow(
                        AdsError(
                            adError.code,
                            "${adError.responseInfo}"
                        )
                    )
                }
            }
        )


    }

    /**
     * Call this method when you need to load your Open AD
     * you need to call this method only once in your launcher activity or your application class
     *
     * @param fContext this is a reference to your activity context
     * @param onAdLoad callback after ad successfully loaded
     */
    fun loadOpenAd(
        @NonNull fContext: Context,
        @NonNull onAdLoad: () -> Unit = {},
        @NonNull onAdFailed: () -> Unit = {},
        @NonNull onAdShow: () -> Unit = {},
    ) {
        if (Config.enableAds) {
            if (isAdAvailable()) {
                onAdLoad.invoke()
            } else {
                loadOpenAd(fContext, object : AdsListener {
                    override fun onAdLoaded(appOpenAd: Any) {
//                    super.onAdLoaded(appOpenAd)
                        mAppOpenAd = appOpenAd as AppOpenAd
                        onAdLoad.invoke()
                        mListener?.onAdLoaded()

                    }

                    override fun onAdLoaded() {

                    }

                    override fun onAdFailedToShow(adsError: AdsError) {
                        onAdFailed.invoke()
                    }

                    override fun onAdImpression() {
                    }

                    override fun onAdShowed() {
                        onAdShow.invoke()
                    }

                    override fun onAdClicked() {
                    }

                    override fun onAdDismissed() {
//                    super.onAdDismissed()
                        isAnyAdShowing = false
                        Log.i("isAnyAdShowing", "isAnyAdShowing.010:$isAnyAdShowing")
                        // Log.i("ADCONFIG_OpenAd", "setAnyAdShowing.005:$isAnyAdShowing")
                        mAppOpenAd?.fullScreenContentCallback = null
                        mAppOpenAd = null
                        mListener?.onAdDismissed()
                        /*
                                            if (fContext is Activity) {
                                                loadOpenAd(fContext = fContext, onAdLoad = { })
                                            } else {
                                                loadOpenAd(fContext = fContext, onAdLoad = onAdLoad)
                                            }*/
                    }

                })
            }
        } else {
            onAdFailed.invoke()
            return
        }
    }


    fun loadOpenAdId(
        @NonNull fContext: Context, @NonNull onAdLoad: (Boolean) -> Unit = {},
        mAdId: String? = ""
    ) {
        if (Config.enableAds) {
            if (isAdAvailable()) {
                onAdLoad.invoke(true)
            } else {
                loadOpenAd(fContext, object : AdsListener {
                    override fun onAdLoaded(appOpenAd: Any) {
//                    super.onAdLoaded(appOpenAd)
                        mAppOpenAd = appOpenAd as AppOpenAd
                        onAdLoad.invoke(true)
                        mListener?.onAdLoaded()

                    }

                    override fun onAdLoaded() {
                    }

                    override fun onAdFailedToShow(adsError: AdsError) {
                        onAdLoad.invoke(false)
                    }

                    override fun onAdImpression() {
                    }

                    override fun onAdShowed() {

                    }

                    override fun onAdClicked() {
                    }

                    override fun onAdDismissed() {
//                    super.onAdDismissed()
                        isAnyAdShowing = false
                        Log.i("isAnyAdShowing", "isAnyAdShowing.011:$isAnyAdShowing")
                        mAppOpenAd?.fullScreenContentCallback = null
                        mAppOpenAd = null
                        mListener?.onAdDismissed()

//                    if (fContext is Activity) {
//                        loadOpenAd(fContext = fContext, onAdLoad = { })
//                    } else {
//                        loadOpenAd(fContext = fContext, onAdLoad = onAdLoad)
//                    }
                    }

                }, mAdId)
            }
        } else {
            onAdLoad.invoke(false)
            return
        }
    }

    private fun wasLoadTimeLessThanNHoursAgo(): Boolean {
        val dateDifference: Long = Date().time - adLoadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour
    }

    /**
     * this method will check openAd is Available or not
     */
    fun isAdAvailable(): Boolean {
        // Log.i(
//            "ADCONFIG_OpenAdHelper",
//            "isAdAvailable"
//        )
//        return mAppOpenAd != null && wasLoadTimeLessThanNHoursAgo()
        return mAppOpenAd != null
    }

    fun Activity.isShowOpenAd(
        @NonNull onAdClosed: (isLoaded: Boolean) -> Unit,
    ) {
        if(Config.enableAds) {
            if (!isOpenAdShowing) {
                mListener = object : AdsListener {
                    override fun onAdClicked() {

                    }

                    override fun onAdDismissed() {
                        onAdClosed.invoke(true)
                    }

                    override fun onAdLoaded(appOpenAd: Any) {
//                    onAdLoad.invoke()
                        // Log.i("ADCONFIG_OpenAdHelper", "onAdLoaded")
                    }

                    override fun onAdLoaded() {
                    }

                    override fun onAdFailedToShow(adError: AdsError) {
//                    onAdFailed.invoke()
                        onAdClosed.invoke(false)
                        Log.i(
                            "ADCONFIG_OpenAdHelper",
                            "onAdFailedToLoad:${adError.code}:${adError.error}"
                        )
                    }

                    override fun onAdImpression() {
                        // Log.i("ADCONFIG_OpenAdHelper", "onAdImpression")
                    }

                    override fun onAdShowed() {

                    }

                }

                // Log.i("ADCONFIG_OpenAdHelper", "isShowOpenAd:isAdAvailable()::${isAdAvailable()}")
                if (isAdAvailable()) {
                    if (!isAnyAdShowing) {
//                    openAdCounter++
                        // Log.i("ADCONFIG_OpenAdHelper", "isShowOpenAd: Showing Open Ad")
//                    if(openAdCounter%7==0) {
                        isAnyAdShowing = true
                        Log.i("isAnyAdShowing", "isAnyAdShowing.013:$isAnyAdShowing")
                        // Log.i("ADCONFIG_InterAd", "setAnyAdShowing.007:$isAnyAdShowing")
//                    onAdClosed.invoke(true)
                        mAppOpenAd?.show(this)
                    } else {
                        onAdClosed.invoke(false)
                    }
                } else {
                    onAdClosed.invoke(false)
                }
            } else {
                onAdClosed.invoke(false)
            }
        }else {
            onAdClosed.invoke(false)
            return
        }
    }

    fun destroy() {
        adLoadTime = 0
        isOpenAdShowing = false
        isAdLoading = false
        mListener = null
        mAppOpenAd = null
    }
}