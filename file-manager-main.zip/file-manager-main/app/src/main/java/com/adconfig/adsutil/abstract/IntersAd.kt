package com.adconfig.adsutil.abstract

import android.app.Activity
import android.content.Context
import com.adconfig.adsutil.utils.AdsError
import com.adconfig.adsutil.utils.AdsListener

abstract class IntersAd {

    var adsListener: AdsListener?=null

    abstract fun show(activity: Activity)

    abstract fun load(context: Context, mAdId: String, onLoaded: (isLoaded:Boolean) -> Unit = {})
    abstract fun destroy()

    fun adListener(adsListener: AdsListener) {
        this.adsListener = adsListener
    }
}

//public inline fun IntersAd.addListener(
//    crossinline onAdClicked: () -> Unit = {},
//    crossinline onAdDismissed: () -> Unit = {},
//    crossinline onAdFailedToShow: (adsError: AdsError) -> Unit = {},
//    crossinline onAdImpression: () -> Unit = {},
//    crossinline onAdShowed: () -> Unit = {}
//): AdsListener {
//    val listener = object : AdsListener {
//        override fun onAdClicked() = onAdClicked()
//        override fun onAdDismissed() = onAdDismissed()
//        override fun onAdLoaded(appOpenAd: Any) {}
//        override fun onAdLoaded() {}
//        override fun onAdFailedToShow(p0: AdsError) = onAdFailedToShow(p0)
//        override fun onAdImpression() = onAdImpression()
//        override fun onAdShowed() = onAdShowed()
//    }
//    adListener(listener)
//    return listener
//}