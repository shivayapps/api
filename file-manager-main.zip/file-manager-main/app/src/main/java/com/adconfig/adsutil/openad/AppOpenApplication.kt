package com.adconfig.adsutil.openad

//import com.example.app.ads.helper.activity.FullScreenNativeAdDialogActivity
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.SystemClock
import android.util.Log
import android.webkit.WebView
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.OpenAdHelper.loadOpenAd
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.adsutil.utils.isAppForeground
import com.adconfig.adsutil.utils.isInterstitialAdShow
import com.google.android.gms.ads.AdActivity
import com.google.android.gms.ads.MobileAds

open class AppOpenApplication : MultiDexApplication(), DefaultLifecycleObserver {

    private val TAG: String = "ADCONFIG_Application"

    // variable to track pause event time
    private var isPause: Boolean = false
    private var mLastPauseTime: Long = 0
    private val mMinPauseDuration = 100

    private var mOpenAdManager: OpenAdManager? = null

    private val mTestDeviceIds: ArrayList<String> = ArrayList()

    companion object {
        public var previousActivity:String=""
    }
    fun setPreviousActivity(str:String) {
        previousActivity=str
    }

    interface AppLifecycleListener {
        fun onResumeApp(fCurrentActivity: Activity): Boolean
        fun onActivityCreated(fCurrentActivity: Activity,savedInstanceState: Bundle?)
        fun onAppOpenCreatedEvent(fCurrentActivity: Activity)
        fun onAppOpenShownEvent(fCurrentActivity: Activity)
        fun onAppOpenFailedEvent(fCurrentActivity: Activity)
    }

    var mAppLifecycleListener: AppLifecycleListener? = null

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    override fun onCreate() {
        super<MultiDexApplication>.onCreate()
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        mOpenAdManager = OpenAdManager(this@AppOpenApplication)
    }

    fun setAppLifecycleListener(fAppLifecycleListener: AppLifecycleListener) {
        this.mAppLifecycleListener = fAppLifecycleListener
    }

    //    fun initMobileAds(isAppInTesting: Boolean) {
    fun initMobileAds(vararg fDeviceId: String) {
        /*com.example.app.ads.helper.isAppInTesting = isAppInTesting
        setMobileAds(isAppInTesting = isAppInTesting)*/
        setMobileAds(fDeviceId = fDeviceId)
    }

    //    private fun setDeviceIds(isAppInTesting: Boolean) {
    private fun setDeviceIds(vararg fDeviceId: String) {
        /*if (isAppInTesting) {
            mTestDeviceIds.add(getAdsTestDeviceId())
            setTestDeviceIds(*mTestDeviceIds.toTypedArray())
        }*/
        mTestDeviceIds.removeAll(mTestDeviceIds)
        for (lID in fDeviceId) {
            mTestDeviceIds.add(lID)
        }
//        setTestDeviceIds(*mTestDeviceIds.toTypedArray())
    }

    private fun setMobileAds(vararg fDeviceId: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val processName = getProcessName(applicationContext)
            if (processName != null && packageName != processName) {
                try {
                    WebView.setDataDirectorySuffix(processName)
                } catch (e: Exception) {
                    // Log.i(TAG, "WebView Exception:$e")
                }
                MobileAds.initialize(baseContext) {
                    // Log.i(TAG, "onInitializationComplete.1")
                    try {
                        setDeviceIds(fDeviceId = fDeviceId)
                    } catch (e: Exception) {
                    }
                }
            } else {
                MobileAds.initialize(baseContext) {
                    // Log.i(TAG, "onInitializationComplete.2")
                    setDeviceIds(fDeviceId = fDeviceId)
                }
            }
        } else {
            MobileAds.initialize(baseContext) {
                // Log.i(TAG, "onInitializationComplete.3")
                setDeviceIds(fDeviceId = fDeviceId)
            }
        }
    }

    private fun getProcessName(context: Context?): String? {
        if (context == null) return null
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val runningProcesses = manager?.runningAppProcesses ?: return ""
        for (processInfo in runningProcesses) {
            if (processInfo.pid == Process.myPid()) {
                return processInfo.processName
            }
        }
        return ""
    }


    //<editor-fold desc="For Application Lifecycle">
    override fun onPause(owner: LifecycleOwner) {
        super.onPause(owner)
        // Log.i(TAG, "onPause: ")
        mLastPauseTime = SystemClock.elapsedRealtime()
        isPause = true
    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        // Log.i(TAG, "onStart: onAppForegrounded: ")
        isAppForeground = true
    }

    override fun onStop(owner: LifecycleOwner) {
        super.onStop(owner)
        // Log.i(TAG, "onStop: onAppBackgrounded: ")
        if (SystemClock.elapsedRealtime() - mLastPauseTime < mMinPauseDuration) {
            // Log.i(TAG, "onStop: Reset Pause Flag")
            if (isPause) {
                isPause = false
            }
        }
        if (isAppForeground && !OpenAdHelper.isAdAvailable()) {
            mOpenAdManager?.let {
                it.mCurrentActivity?.let {
                    mAppLifecycleListener?.let { lListener ->
//                        lListener.onAppOpenCreatedEvent(it)
                        if (lListener.onResumeApp(it)) {
                            loadOpenAd(it, onAdLoad = {
                            }, onAdFailed = {
                                lListener.onAppOpenFailedEvent(it)
                            }, onAdShow = {
                                lListener.onAppOpenShownEvent(it)
                            })
                        }
                    }
                }
            }
        }
        isAppForeground = false
    }



    override fun onResume(owner: LifecycleOwner) {
        super.onResume(owner)
        // Log.i(TAG, "onResume")
        mAppLifecycleListener?.let { lListener ->
            mOpenAdManager?.let { lOpenAdManager ->
                // Log.i(TAG, "onResume, isAppForeground${isAppForeground},isPause-${isPause}")
                if (isAppForeground && !isPause) {
                    // Log.i(TAG, "onResume 001")
                    lOpenAdManager.mCurrentActivity?.let { fCurrentActivity ->
                        // Log.i(TAG, "onResume 002")
                        if (fCurrentActivity !is AdActivity) {
                            // Log.i(TAG, "onResume 003")
                            if (isAnyAdShowing) {
                                // Log.i(TAG, "onResume 004")
                                isAnyAdShowing = false
                                Log.i("isAnyAdShowing", "isAnyAdShowing.009:$isAnyAdShowing")
                                // Log.i("ADCONFIG_InterAd", "setAnyAdShowing.001:$isAnyAdShowing")
                            } else {
                                // Log.i(TAG, "onResume 005")
//                                    if (fCurrentActivity !is FullScreenNativeAdDialogActivity && !isInterstitialAdShow) {
                                if (!isInterstitialAdShow) {
                                    // Log.i(TAG, "onResume 006")
                                    if (lListener.onResumeApp(fCurrentActivity)) {
                                        // Log.i(TAG, "onResume 007")
                                        lOpenAdManager.showOpenAd()
                                    }
                                }
                            }
                        }
                    }
                }
                if (isPause) {
                    isPause = false
                }
            }
        }
    }
}