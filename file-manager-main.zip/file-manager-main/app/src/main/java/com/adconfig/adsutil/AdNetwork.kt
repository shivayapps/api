package com.adconfig.adsutil

enum class AdNetwork {
    ADMOB//, FACEBOOK
}