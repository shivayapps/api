package com.adconfig.adsutil.admob


enum class NativeLayoutType {
    NativeSmall,
    NativeSmallXL,
    NativeBanner,
    NativeMedium,
    NativeBottom,
    NativeBig,
}