package com.explorefile.filemanager.filecleaner.databinding

import android.widget.TextView
//import androidx.databinding.BindingAdapter
import com.explorefile.filemanager.R
import com.explorefile.filemanager.filecleaner.widget.StorageAnalysisBar
import com.explorefile.filemanager.filecleaner.extension.autoFormatFileSize

//@BindingAdapter("fileSizeToText")
fun fileSizeToText(textView: TextView, size: Long?) {
    textView.text = size?.autoFormatFileSize()
}

//@BindingAdapter("fileSizeToTextDefaultComputing")
fun fileSizeToTextDefaultComputing(textView: TextView, size: Long?) {
    textView.text = size?.autoFormatFileSize() ?: textView.context.getString(R.string.common_computing)
}

//@BindingAdapter("fileCountToTextDefaultComputing")
fun fileCountToTextDefaultComputing(textView: TextView, size: Int?) {
    textView.text = size?.toString() ?: textView.context.getString(R.string.common_computing)
}

//@BindingAdapter("dataAndColorArray")
fun dataAndColorArray(storageAnalysisBar: StorageAnalysisBar, data: Array<Pair<Float, Int>>?) {
    storageAnalysisBar.dataAndColorArray = data
    storageAnalysisBar.invalidate()
}