package com.explorefile.filemanager.fragments

import android.content.Context
import android.util.AttributeSet
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.MainShareFragmentBinding
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.updateTextColors
import java.text.DecimalFormat

class ShareFragment(context: Context, attributeSet: AttributeSet) :
    MyViewPagerFragment<MyViewPagerFragment.ShareInnerBinding>(context, attributeSet){


    private lateinit var binding: MainShareFragmentBinding

    override fun onFinishInflate() {
        super.onFinishInflate()
        binding = MainShareFragmentBinding.bind(this)
        innerBinding = ShareInnerBinding(binding)
    }

    override fun setupFragment(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }
    }

    override fun setupCategoriesBinding(activity: BaseActivity) {

    }

    override fun onResume(textColor: Int) {
        context.updateTextColors(binding.root)
        val properPrimaryColor = context.getProperPrimaryColor()

    }

    override fun refreshFragment() {

    }

//    override fun searchQueryChanged(text: String) {
//
//    }

//    override fun deleteFiles(files: ArrayList<FileDirItem>) {
//        //("Not yet implemented")
//    }
//
//    override fun selectedPaths(paths: ArrayList<String>) {
//        //("Not yet implemented")
//    }
//
//    override fun setupDateTimeFormat() {
//        //("Not yet implemented")
//    }
//
//    override fun toggleFilenameVisibility() {
//        //("Not yet implemented")
//    }
//
//    override fun columnCountChanged() {
//        ("Not yet implemented")
//    }
//
//    override fun finishActMode() {
//        //("Not yet implemented")
//    }

}