package com.explorefile.filemanager.activities

import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd

import com.explorefile.filemanager.App
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityPermissionBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.PERMISSION_WRITE_STORAGE
import com.explorefile.filemanager.helpers.isRPlus

class PermissionActivity : BaseActivity() {

    val binding by viewBinding(ActivityPermissionBinding::inflate)
    private val MANAGE_STORAGE_RC = 201

    override fun onBackPressed() {
        finishAffinity()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //OpenAdHelper.loadOpenAd(this)
        binding.txtGetPermission.setOnClickListener {
            tryInitFileManager()
        }
        binding.txtUsagePermission.setOnClickListener {
            if (!hasUsageStatsPermission()) {
                openUsageAccessSettings()
            }
        }
        binding.txtNext.setOnClickListener {
            if (hasUsageStatsPermission() && hasStoragePermission()) {
//                isShowOpenAd {
                    startNextActivity()
//                }
            }else{
                toast(R.string.no_storage_permissions)
            }
        }
        binding.txtNext.alpha=0.5f


    }

    private fun tryInitFileManager() {
        handleStoragePermission {
            if (it) {
                if (hasUsageStatsPermission() && hasStoragePermission()) {
                    binding.txtNext.alpha=1.0f
                }
//                if (!hasUsageStatsPermission()) {
//                    openUsageAccessSettings()
//                } else {
//                    OpenAdHelper.loadOpenAd(this)
//                    isShowOpenAd {
//                        startNextActivity()
//                    }
//                }

            } else {
                toast(R.string.no_storage_permissions)
            }
        }
    }

    private fun openUsageAccessSettings() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        usagePermissionLauncher.launch(intent)
    }

    private val usagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {

        if (hasUsageStatsPermission() && hasStoragePermission()) {
            binding.txtNext.alpha=1.0f
        }

        if (hasUsageStatsPermission()) {
//            OpenAdHelper.loadOpenAd(this)
//            isShowOpenAd {
//                startNextActivity()
//            }
            Toast.makeText(this, "Usage Access granted ✅", Toast.LENGTH_SHORT).show()
            // You can now safely fetch usage data
        } else {
            Toast.makeText(this, "Usage Access not granted ❌", Toast.LENGTH_SHORT).show()
        }
    }


    fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
        } else {
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun startNextActivity(){
        startActivity(
            Intent(
                this@PermissionActivity,
                MainActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
        finish()
    }

    @SuppressLint("InlinedApi")
    private fun handleStoragePermission(callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasStoragePermission()) {
            callback(true)
        } else {
            if (isRPlus()) {
                isAskingPermissions = true
                actionOnPermission = callback
                try {
                    val intent =
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.addCategory("android.intent.category.DEFAULT")
                    intent.data = Uri.parse("package:$packageName")
//                    if (isPermissionOpen()){
                    App.disabledOpenAds()
//                    }
//                    startActivityForResult(intent, MANAGE_STORAGE_RC)
                    permissionActivityResultLauncher.launch(intent)
                } catch (e: Exception) {
                    showErrorToast(e)
                    val intent = Intent()
                    intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
                    App.disabledOpenAds()
//                    startActivityForResult(intent, MANAGE_STORAGE_RC)
                    permissionActivityResultLauncher.launch(intent)
                }
            } else {
                handlePermission(PERMISSION_WRITE_STORAGE, callback)
            }
        }
    }


    var permissionActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) {
        isAskingPermissions = false
        if (isRPlus()) {
            actionOnPermission?.invoke(Environment.isExternalStorageManager())
        }
    }

//    @SuppressLint("NewApi")
//    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
//        super.onActivityResult(requestCode, resultCode, resultData)
//        isAskingPermissions = false
//        if (requestCode == MANAGE_STORAGE_RC && isRPlus()) {
//            actionOnPermission?.invoke(Environment.isExternalStorageManager())
//        }
//    }

    override fun onResume() {
        super.onResume()
        updateStatusbarColor(getProperBackgroundColor())
        arrayOf(
            binding.txtPermission,
            binding.txtInfo
        ).forEach {
            it.setTextColor(getProperTextColor())
        }
    }

}