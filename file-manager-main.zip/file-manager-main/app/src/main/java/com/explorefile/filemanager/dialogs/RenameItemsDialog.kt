package com.explorefile.filemanager.dialogs

import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.DialogRenameItemsBinding
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.getDoesFilePathExist
import com.explorefile.filemanager.extensions.getFilenameExtension
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getParentPath
import com.explorefile.filemanager.extensions.isAValidFilename
import com.explorefile.filemanager.extensions.isPathOnSD
import com.explorefile.filemanager.extensions.renameFile
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.extensions.showKeyboard
import com.explorefile.filemanager.extensions.toast

// used at renaming folders
class RenameItemsDialog(val activity: BaseActivity, val paths: ArrayList<String>, val callback: () -> Unit) {
    init {
        var ignoreClicks = false
        val view = DialogRenameItemsBinding.inflate(activity.layoutInflater,null, false)

        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(view.root, this) { alertDialog ->
                    alertDialog.showKeyboard(view.renameItemsValue)
                    view.txtOk.setOnClickListener {
                        if (ignoreClicks) {
                            return@setOnClickListener
                        }

                        val valueToAdd = view.renameItemsValue.text.toString()
                        val append = view.renameItemsRadioGroup.checkedRadioButtonId == view.renameItemsRadioAppend.id

                        if (valueToAdd.isEmpty()) {
                            callback()
                            alertDialog.dismiss()
                            return@setOnClickListener
                        }

                        if (!valueToAdd.isAValidFilename()) {
                            activity.toast(R.string.invalid_name)
                            return@setOnClickListener
                        }

                        val validPaths = paths.filter { activity.getDoesFilePathExist(it) }
                        val sdFilePath = validPaths.firstOrNull { activity.isPathOnSD(it) } ?: validPaths.firstOrNull()
                        if (sdFilePath == null) {
                            activity.toast(R.string.unknown_error_occurred)
                            alertDialog.dismiss()
                            return@setOnClickListener
                        }

                        activity.handleSAFDialog(sdFilePath) {
                            if (!it) {
                                return@handleSAFDialog
                            }

                            ignoreClicks = true
                            var pathsCnt = validPaths.size
                            for (path in validPaths) {
                                val fullName = path.getFilenameFromPath()
                                var dotAt = fullName.lastIndexOf(".")
                                if (dotAt == -1) {
                                    dotAt = fullName.length
                                }

                                val name = fullName.substring(0, dotAt)
                                val extension = if (fullName.contains(".")) ".${fullName.getFilenameExtension()}" else ""

                                val newName = if (append) {
                                    "$name$valueToAdd$extension"
                                } else {
                                    "$valueToAdd$fullName"
                                }

                                val newPath = "${path.getParentPath()}/$newName"

                                if (activity.getDoesFilePathExist(newPath)) {
                                    continue
                                }

                                activity.renameFile(path, newPath, true) { success, _ ->
                                    if (success) {
                                        pathsCnt--
                                        if (pathsCnt == 0) {
                                            callback()
                                            alertDialog.dismiss()
                                        }
                                    } else {
                                        ignoreClicks = false
                                        alertDialog.dismiss()
                                    }
                                }
                            }
                        }
                    }

                    view.txtCancel.setOnClickListener {
                        alertDialog.dismiss()
                    }
                }
            }
    }
}
