package com.adconfig.adsutil.openad

import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.adconfig.adsutil.utils.SmUtils.isConnected
import com.adconfig.adsutil.utils.delayExecution
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.databinding.ActivityWelcomeBackBinding
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd


import java.util.Timer
import kotlin.concurrent.timerTask

class WelcomeBackActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWelcomeBackBinding
    var isAdShow = false
    var isTimeOver = false
    private var countDownTimer: CountDownTimer? = null
    private var appOpenAd: AppOpenAd? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (!isConnected(this)) {
            finish()
            return
        }
//        finishAdsTimer()

        val adId = intent.getStringExtra("ad_id") ?: ""

        createTimerSec()
        loadAppOpenAd(adId, {
            countDownTimer?.cancel()
            showOpenAd { isLoaded ->//onAdClosed
                finish()
            }
        })
    }

    private fun loadAppOpenAd(openAdId: String, onAdLoad: (isLoaded: Boolean) -> Unit = {}) {
        val adRequest = AdRequest.Builder().build()
        AppOpenAd.load(
            applicationContext,
            openAdId,
            adRequest,
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    onAdLoad.invoke(true)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpenAd = null
                    onAdLoad.invoke(false)
                }
            }
        )
    }

    private fun showOpenAd(onAdShow: (isShow: Boolean) -> Unit = {}) {
        if (appOpenAd != null) {
            appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {}

                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    onAdShow.invoke(false)
                    //loadAppOpenAd()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    appOpenAd = null
                    onAdShow.invoke(false)
                }
            }
            appOpenAd?.show(this)
        } else {
            onAdShow.invoke(false)
        }
    }

    private fun createTimerSec() {
        val totalTimeMillis = 4
        countDownTimer = object : CountDownTimer(totalTimeMillis * 1000L, 1000) {

            override fun onTick(l: Long) {

            }

            override fun onFinish() {
                finish()
            }
        }
        countDownTimer?.start()
    }

//    private var timer: Timer? = null
//    fun startAdsTimer() {
//        val timeOut = 500L
//        timer?.cancel()
//        timer = Timer()
//        timer?.schedule(timerTask {
//            Log.e("loadNativeCustom", "startAdsTimer: loadNativeAds")
//
//            runOnUiThread {
//                if (isDestroyed || isFinishing) return@runOnUiThread
//                if (OpenAdHelper.isAdAvailable()) {
//                    timer?.cancel()
//                    isAdShow = false
//                    (this@WelcomeBackActivity).isShowOpenAd({
//                        isAdShow = true
//                        Log.e("Sales2", "gotoMainScreen: isShowOpenAd")
//                        finish()
//                    })
//                }
//            }
//        }, timeOut, timeOut)
//
//    }

//    private var finishTimer: Timer? = null
//    fun finishAdsTimer() {
//        val timeOut = 3500L
//        finishTimer?.cancel()
//        finishTimer = Timer()
//        finishTimer?.schedule(timerTask {
//            Log.e("finishAdsTimer", "startAdsTimer: finishAdsTimer $isAdShow")
//            finishTimer?.cancel()
//            isTimeOver = true
//            if (!isAdShow) finish()
////            runOnUiThread {
////            }
//        }, timeOut, timeOut)
//
//    }

    override fun onPause() {
        super.onPause()
        if (!isAnyAdShowing) {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (isTimeOver) {
            finish()
        }
    }
}