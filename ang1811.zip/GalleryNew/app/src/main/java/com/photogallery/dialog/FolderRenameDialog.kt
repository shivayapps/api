package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.OnScanCompletedListener
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.photogallery.R
import com.photogallery.databinding.DialogRenameBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.rescanPath
import com.photogallery.extension.scanPathRecursively
import com.photogallery.extension.toast
import com.photogallery.extension.updateInMediaStore
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class FolderRenameDialog(
    var mContext: Activity,
    var albumData: AlbumData,
    val positiveBtnClickListener: (renamePath: String, oldPath: String) -> Unit,
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogRenameBinding
    var preferences: Preferences = Preferences(mContext)
    var oldName = ""
//    var type = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogRenameBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }


    private fun intView() {
//        val separated: List<String> = pictureData.title.split(".")
        oldName = albumData.title
//        type = separated[1]
        Log.e("", "oldName $oldName")
        bindingDialog.edtName.setText(oldName)
        bindingDialog.edtName.requestFocus()

    }

    var isRenameClicked = false
    private fun intListener() {
        bindingDialog.edtName.addTextChangedListener {
            bindingDialog.icClear.visibility = if (bindingDialog.edtName.text?.trim().toString()
                    .isNotEmpty()
            ) View.VISIBLE else View.GONE
        }
        bindingDialog.icClear.setOnClickListener {
            bindingDialog.edtName.setText("")
        }
        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnRename.setOnClickListener {
            if (!isRenameClicked) {
                mContext.runOnUiThread {
                    bindingDialog.llProgress.beVisible()
                }
                isRenameClicked = true
                val strNewFileName = bindingDialog.edtName.text.toString().trim()
                if (strNewFileName.isNotEmpty()) {
                    val renameFile = File(albumData.folderPath.replace(oldName, strNewFileName))
                    if (!renameFile.exists() || oldName == strNewFileName) {
                        if (oldName != strNewFileName) {
                            val oldFileCount = File(albumData.folderPath).listFiles()?.count() ?: 0
                            Log.e("TAG", "renameEvent: pictureData.folderPath ${albumData.folderPath}")

                            renameFile(strNewFileName) { renamePath ->
                                if (renamePath.isNotEmpty()) {
                                    setRename(oldFileCount, albumData.folderPath, renamePath)
                                    mContext.toast(mContext.getString(R.string.rename_successfully))
                                    bindingDialog.llProgress.beGone()
                                    isRenameClicked = false
                                    positiveBtnClickListener.invoke(renamePath, albumData.folderPath)
                                    dismiss()
                                } else {
                                    bindingDialog.llProgress.beGone()
                                    isRenameClicked = false
                                    mContext.toast(mContext.getString(R.string.failed))
                                    dismiss()
                                }
                            }

                        } else {
                            dismiss()
                            bindingDialog.llProgress.beGone()
                            isRenameClicked = false
                        }
                    } else {
                        bindingDialog.llProgress.beGone()
                        isRenameClicked = false
                        mContext.toast(mContext.getString(R.string.rename_validation2))
                    }
                } else {
                    bindingDialog.llProgress.beGone()
                    isRenameClicked = false
                    mContext.toast(mContext.getString(R.string.rename_validation))
                }
            }
        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }

    private fun setRename(oldFileCount: Int, oldPath: String, renamePath: String) {
        sendEvent("rename", oldPath)
        sendEvent("rename", renamePath)
//        mContext.scanPathRecursively(oldPath)
//        mContext.scanPathRecursively(renamePath)
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

    private fun renameFile(strNewFileName: String, callback: (String) -> Unit) {

        var renamed = false
        val renameFilePath: String = File(albumData.folderPath).parent.toString() + File.separator + strNewFileName
        val oldFile: File = File(albumData.folderPath)
        val renameFile = File(renameFilePath)
        val oldPath = albumData.folderPath
        renamed = oldFile.renameTo(renameFile)
        mContext.updateInMediaStore(oldPath, renameFilePath){
            mContext.rescanPath(renameFilePath) {
                if (!oldPath.equals(renameFilePath, true)) {
                    Utils.deleteFromMediaStore(mContext, oldPath)
                }
                mContext.scanPathRecursively(renameFilePath)
            }

            MediaScannerConnection.scanFile(context, arrayOf<String>(renameFile.path), null,
                OnScanCompletedListener { path: String?, uri: Uri? -> })

            MediaScannerConnection.scanFile(context, arrayOf<String>(albumData.folderPath), null,
                OnScanCompletedListener { path: String?, uri: Uri? -> })

            if (renamed) {
                callback.invoke(renameFilePath)
            } else {
                callback.invoke("")
            }
        }

    }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    fun resizeImage(bitmap: Bitmap, imagePath: String): String? {

        val imageFile = File(imagePath)
        if (imageFile.exists()) {
            imageFile.delete()
            val deleteUrl = FileProvider.getUriForFile(
                mContext,
                "${mContext.packageName}.provider", imageFile
            )
            val contentResolver = mContext.contentResolver
            contentResolver.delete(deleteUrl, null, null)

            MediaScannerConnection.scanFile(
                mContext,
                arrayOf(imageFile.path),
                null
            ) { path: String?, uri: Uri? -> }
        }

        try {
            val stream = FileOutputStream(imageFile)
            bitmap.compress(imageFile.path.getCompressionFormat(), 100, stream)

            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(imageFile)
            mediaScanIntent.data = contentUri
            mContext.sendBroadcast(mediaScanIntent)

            stream.flush()
            stream.close()

            MediaScannerConnection.scanFile(
                mContext, arrayOf<String>(imageFile.path), null
            ) { path, uri ->
            }
            return imagePath
        } catch (e: IOException) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        return null
    }

    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

}
