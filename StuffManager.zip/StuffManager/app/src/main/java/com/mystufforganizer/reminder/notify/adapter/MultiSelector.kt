package com.mystufforganizer.reminder.notify.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView

/**
 * Helper class to keep track of the checked items.
 */
class MultiSelector(private val recyclerView: RecyclerView) {
    var checkedItems: ParcelableSparseBooleanArray =
        ParcelableSparseBooleanArray()
        private set

    /*
    fun onSaveInstanceState(state: Bundle?) {
        state?.putParcelable(CHECKED_STATES, checkedItems)
    }
    fun onRestoreInstanceState(state: Bundle?) {
        if (state != null) {
            checkedItems = state.getParcelable(CHECKED_STATES)
        }
    }
    */

    fun checkView(view: View, position: Int) {
        val isChecked = isChecked(position)
        onChecked(position, !isChecked)
        view.isActivated = !isChecked
    }

    fun isChecked(position: Int): Boolean {
        return if (checkedItems != null) checkedItems[position, false] else false
    }

    private fun onChecked(position: Int, isChecked: Boolean) {
        if (isChecked) {
            checkedItems!!.put(position, true)
        } else {
            checkedItems!!.delete(position)
        }
    }

    val count: Int
        get() = checkedItems!!.size()

    fun clearAll() {
        for (i in 0 until checkedItems!!.size()) {
            val position = checkedItems!!.keyAt(i)
            val viewHolder =
                recyclerView.findViewHolderForAdapterPosition(position)
            if (viewHolder != null) {
                viewHolder.itemView.isActivated = false
            }
        }
        checkedItems!!.clear()
    }

    companion object {
        private const val CHECKED_STATES = "checked_states"
    }

}