package com.mystufforganizer.reminder.notify.adapter

import android.os.Parcel
import android.os.Parcelable
import android.util.SparseBooleanArray

/**
 * Custom SpareBooleanArray that can be treated as a Parcelable.
 */
class ParcelableSparseBooleanArray : SparseBooleanArray, Parcelable {
    constructor() : super() {}
    private constructor(source: Parcel) {
        val size = source.readInt()
        for (i in 0 until size) {
            put(source.readInt(), (source.readValue(null) as Boolean?)!!)
        }
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeInt(size())
        for (i in 0 until size()) {
            dest.writeInt(keyAt(i))
            dest.writeValue(valueAt(i))
        }
    }

    companion object {
        var CREATOR: Parcelable.Creator<ParcelableSparseBooleanArray> =
            object :
                Parcelable.Creator<ParcelableSparseBooleanArray> {
                override fun createFromParcel(source: Parcel): ParcelableSparseBooleanArray? {
                    return ParcelableSparseBooleanArray(
                        source
                    )
                }

                override fun newArray(size: Int): Array<ParcelableSparseBooleanArray?> {
                    return arrayOfNulls(
                        size
                    )
                }
            }
    }
}