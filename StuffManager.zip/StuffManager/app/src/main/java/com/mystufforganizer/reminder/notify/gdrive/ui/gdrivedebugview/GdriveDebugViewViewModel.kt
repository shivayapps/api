package com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview

import androidx.lifecycle.ViewModel

class GdriveDebugViewViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
