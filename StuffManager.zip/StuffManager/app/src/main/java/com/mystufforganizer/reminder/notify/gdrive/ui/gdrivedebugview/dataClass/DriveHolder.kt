package com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.dataClass

data class DriveHolder(val driveId: String?, val driveTitle: String?)