package com.mystufforganizer.reminder.notify.activity

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.text.SpannableStringBuilder
import android.util.Log
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.mystufforganizer.reminder.notify.BuildConfig
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.adapter.SingleCategoryAdapter
import com.mystufforganizer.reminder.notify.crop.BasicActivity
import com.mystufforganizer.reminder.notify.database.Category
import com.mystufforganizer.reminder.notify.database.SQLiteHelper
import com.mystufforganizer.reminder.notify.database.StuffGetSet
import com.mystufforganizer.reminder.notify.databinding.ActivityInsertBinding
import com.mystufforganizer.reminder.notify.util.*
import com.mystufforganizer.reminder.notify.util.AppUtil
import com.mystufforganizer.reminder.notify.wheelview.WheelItemAdapter
import com.mystufforganizer.reminder.notify.wheelview.WheelPicker
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class UpdateActivity : AppCompatActivity() {

    var stuffName: String = ""
    var category: String = ""
    var purchasedate:String = ""
    var price:String = "0.0"
    var stuffId=0
    var expiry_date:String = ""
    var description:String = ""
    var barcode:String = ""
    var exYr:Int=0
    var exMonth:Int=0
    var dateMain: Date = Calendar.getInstance().time

    var byteArray = ByteArray(1024)
    var byteArrayBill = ByteArray(1024)
    var bitmap : Bitmap?= null
    var bitmapBill : Bitmap?= null

    var dbHelper: SQLiteHelper? = null
    var stuffGetSet : StuffGetSet?=null
    val REQUEST_QR = 111
    val REQUEST_CAMERA = 105
    val REQUEST_GALLERY = 106
    val REQUEST_BILL = 107
    var serviceFreq:Int=-1
    var catId = 0
    var serviceFreqStr: List<String?> = ArrayList()

    lateinit var binding: ActivityInsertBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@UpdateActivity, R.color.colorWhite)
        }

        binding = ActivityInsertBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_insert)

        dbHelper= SQLiteHelper(this@UpdateActivity)
        dbHelper!!.open()

        stuffId=intent.getIntExtra("stuff_id",0)

        serviceFreqStr = Arrays.asList(*resources.getStringArray(R.array.serviceFreq))

        MyAsyncTask().execute()
        //stuffGetSet=dbHelper!!.getData(this@UpdateActivity,""+stuffId)
        //setData(stuffGetSet!!)

        binding.txtDate.setOnClickListener {

            val dateTimePicker = DateTimePicker(
                this,
                object :
                    DateTimePicker.ICustomDateTimeListener {
                    override fun onSet(
                        dialog: Dialog?,
                        calendar: Calendar?,
                        date: Date?,
                        year: Int,
                        monthLong: String?,
                        monthShort: String?,
                        monthNumber: Int,
                        day: Int,
                        dayOfWeek: String?,
                        dayOfWeekShort: String?,
                        hour24: Int,
                        hour12: Int,
                        minute: Int,
                        second: Int,
                        AmPm: String?
                    ) {

                        Log.e("DateTimePicker", "date:" + date)
                        Log.e("DateTimePicker", "year:" + year)
                        Log.e("DateTimePicker", "monthLong:" + monthLong)
                        Log.e("DateTimePicker", "monthShort:" + monthShort)
                        Log.e("DateTimePicker", "monthNumber:" + monthNumber)
                        Log.e("DateTimePicker", "day:" + day)
                        Log.e("DateTimePicker", "dayOfWeek:" + dayOfWeek)
                        Log.e("DateTimePicker", "dayOfWeekShort:" + dayOfWeekShort)
                        Log.e("DateTimePicker", "hour24:" + hour24)
                        Log.e("DateTimePicker", "hour12:" + hour12)
                        Log.e("DateTimePicker", "minute:" + minute)
                        Log.e("DateTimePicker", "second:" + second)
                        Log.e("DateTimePicker", "AmPm:" + AmPm)

                        dateMain = date!!
                        val dateStr: String =
                            SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(date)

                        Log.e("DateTimePicker", "dateStr:" + dateStr)

                        binding.txtDate.setText(dateStr)

                        dialog!!.dismiss()
                    }

                    override fun onCancel() {
                    }
                })
            dateTimePicker.showDialog()
        }
        binding.txtDateExpr.setOnClickListener {
            twoStepPicker()
        }
        binding.txtReminderService.setOnClickListener {
            oneStepPicker()
        }
        binding.txtCategory.setOnClickListener {
            categoryPicker()
        }
        binding.toolbarProcess.toolNext.setOnClickListener {
            updateStuff()
        }
        binding.layImg.setOnClickListener {
            openImagePicker()
        }
        binding.iconAttachBill.setOnClickListener {
            if(checkPermission())
                pickBillFromGallery()
            else
                requestPermission(REQUEST_BILL)
        }
        binding.deleteImg.setOnClickListener {
            bitmap=null
            binding.stuffImg.setImageURI(null)
            binding.noImg.visibility=View.VISIBLE
        }
        binding.iconDetachBill.setOnClickListener {
            bitmapBill=null
            binding.iconAttachment.setImageBitmap(null)
            binding.layAttachBill.visibility=View.GONE
        }
        binding.toolbarProcess.toolBack.setOnClickListener {
            onBackPressed()
        }
        binding.iconQr.setOnClickListener {
            //val intent = Intent(this@UpdateActivity, MainActivity::class.java)
            //startActivityForResult(intent,REQUEST_QR)

            if(checkPermission())
                openScanner()
            else
                requestPermission(REQUEST_QR)

        }

        binding.switchService.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener{
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {
                if(isChecked) {
                    serviceFreq=0
                    binding.layServiceSwitch.visibility=View.VISIBLE
                } else {
                    serviceFreq=-1
                    binding.layServiceSwitch.visibility=View.GONE
                }
            }
        })

        if (AppUtil.check_internet(this@UpdateActivity)) {
            val frameLayout: FrameLayout = findViewById(R.id.fl_adplaceholder)

            val adsCallBack= object : AdsClass.adsCallBack{
                override fun onAdLoaded() {}
            }

            AdsClass.refreshAd(
                this@UpdateActivity,
                resources.getString(R.string.ANATIVE_ID),
                frameLayout,
                adsCallBack
            )
        }

    }

    private fun setData(stuffGetSet : StuffGetSet) {
        stuffName=stuffGetSet.stuff_name
        purchasedate=stuffGetSet.stuff_purchase_date
        price=stuffGetSet.stuff_price
        expiry_date=stuffGetSet.stuff_expiry_date
        description=stuffGetSet.stuff_detail
        barcode=stuffGetSet.stuff_barcode
        exYr=stuffGetSet.stuff_warranty_year
        exMonth=stuffGetSet.stuff_warranty_month
        serviceFreq=stuffGetSet.stuff_service_reminder
        catId=stuffGetSet.category_id
        Log.e("UpdateActivity", "setData:serviceFreq:" + serviceFreq)

        bitmap= AppUtil.StringToBitMap(stuffGetSet.stuff_image)
        if(bitmap!=null) {
            binding.stuffImg.setImageBitmap(bitmap!!)
            binding.noImg.visibility=View.GONE
        } else {
            binding.noImg.visibility=View.VISIBLE
        }

        bitmapBill= AppUtil.StringToBitMap(stuffGetSet.stuff_bill)
        if(bitmapBill!=null) {
            binding.iconAttachment.setImageBitmap(bitmapBill!!)
            binding.layAttachBill.visibility=View.VISIBLE
        } else {
            binding.layAttachBill.visibility=View.GONE
        }


        //resources.getString(R.string.rs)
        binding.txtName.setText(stuffName)
        binding.txtPrice.setText(" "+price)
        binding.txtDate.setText(purchasedate)
        binding.txtDetail.setText(description)
        binding.txtSerial.setText(barcode)
        binding.txtCategory.setText(dbHelper!!.getCategoryName(catId))

        if(serviceFreq>=0) {
            binding.switchService.isChecked=true
            binding.layServiceSwitch.visibility=View.VISIBLE
        } else {
            binding.switchService.isChecked=false
            binding.layServiceSwitch.visibility=View.GONE
        }

        if(serviceFreq>=0) {

            Log.e("UpdateActivity", "setData:getFreqStr01:"+serviceFreqStr.get(serviceFreq))
            //val str=serviceFreqStr.get(serviceFreq).toString()
            var expStr:String=serviceFreqStr.get(serviceFreq).toString()
            Log.e("UpdateActivity", "setData:getFreqStr02:"+expStr)

            binding.txtReminderService.setText(expStr)
            //txt_reminder_service.text= SpannableStringBuilder(expStr);
        }

        Log.e("UpdateActivity", "setData:serviceFreq:"+serviceFreq)
        Log.e("UpdateActivity", "setData:txt_reminder_service:"+binding.txtReminderService.text)


        var expStr:String=""
        if(exYr>0) expStr=expStr+" "+exYr+"Y"
        if(exMonth>0) expStr=expStr+" "+exMonth+"M"
        binding.txtDateExpr.setText(expStr.trim())

    }

    fun openScanner() {

        val startingLocation = IntArray(2)
        binding.iconQr.getLocationOnScreen(startingLocation)
        startingLocation[0] += binding.iconQr.getWidth() / 2
        val intent = Intent(this@UpdateActivity, ScannerActivity::class.java)
        intent.putExtra(ScannerActivity.ARG_REVEAL_START_LOCATION, startingLocation)
        startActivityForResult(intent,REQUEST_QR)
    }
    fun openImagePicker() {
        val builder = AlertDialog.Builder(this@UpdateActivity)
        val inflater = layoutInflater

        val dialogLayout: View = inflater.inflate(R.layout.image_picker, null)

        val dialog = builder.create()
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        dialog.setView(dialogLayout, 0, 0, 0, 0)
        dialog.setCanceledOnTouchOutside(true)
        dialog.setCancelable(true)
        val wlmp = dialog.window!!.getAttributes()
        wlmp.gravity = Gravity.BOTTOM

        val btnCamera = dialogLayout.findViewById<LinearLayout>(R.id.lay_camera)
        val btnGallery = dialogLayout.findViewById<LinearLayout>(R.id.lay_gallery)

        btnGallery.setOnClickListener {
            if(checkPermission())
                pickFromGallery()
            else
                requestPermission(REQUEST_GALLERY)
            dialog.dismiss()
        }
        btnCamera.setOnClickListener {
            if(checkPermission())
                goToTakephoto()
            else
                requestPermission(REQUEST_CAMERA)
            dialog.dismiss()
        }

        builder.setView(dialogLayout)

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow()!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        dialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CAMERA && resultCode == Activity.RESULT_OK) {
                try {
                    if(mediaFile!!.exists()) {
                        startCrop(picUri!!)

                    }
                } catch (e:Exception) {

                }
            }
            if (requestCode == 112) {
                //val selectedUri = data!!.data
                val selectedUri = Uri.parse(data!!.getStringExtra("resultUri"))
                picUri=selectedUri

                handleCropResult(data)
                /*
                if (selectedUri != null) {
                    picUri=selectedUri
                    startCrop(selectedUri)
                } else {
                    Snackbar.make(root_layout, R.string.toast_cannot_retrieve_selected_image, Snackbar.LENGTH_LONG).show()
                    //Toast.makeText(this@InsertActivity, R.string.toast_cannot_retrieve_selected_image, Toast.LENGTH_SHORT).show()
                }
                */
            }
            if (requestCode == 114) {
                val selectedUri = data!!.data

                if (selectedUri != null) {
                    picUri=selectedUri
                    startCrop(selectedUri)
                } else {
                    Snackbar.make(binding.rootLayout, R.string.toast_cannot_retrieve_selected_image, Snackbar.LENGTH_LONG).show()
                    //Toast.makeText(this@InsertActivity, R.string.toast_cannot_retrieve_selected_image, Toast.LENGTH_SHORT).show()
                }
            }
            if (requestCode == 113) {
                val selectedUri = data!!.data
                if (selectedUri != null) {
                    fileUri=selectedUri
                    handleFileResult(data)
                } else {
                    Snackbar.make(binding.rootLayout, R.string.toast_cannot_retrieve_selected_image, Snackbar.LENGTH_LONG).show()
                    //Toast.makeText(this@UpdateActivity, R.string.toast_cannot_retrieve_selected_image, Toast.LENGTH_SHORT).show()
                }
            }

            if (requestCode==REQUEST_QR){
                val result: Bundle? = data!!.getExtras()
                val scancode = result!!.getString("scancode")
                binding.txtSerial.setText(scancode)
            }
        } else {
            binding.progressBar.visibility=View.GONE
        }

    }

    private fun handleFileResult(result: Intent) {
        //val resultUri = UCrop.getOutput(result)
        val resultUri = result.data
        if (resultUri != null) {

            bitmapBill = MediaStore.Images.Media.getBitmap(getContentResolver(), resultUri)

            var width: Int = bitmapBill!!.getWidth()
            var height: Int = bitmapBill!!.getHeight()

            val bitmapRatio = width.toFloat() / height.toFloat()
            if (bitmapRatio > 1) {
                width = 500
                height = (width / bitmapRatio).toInt()
            } else {
                height = 500
                width = (height * bitmapRatio).toInt()
            }
            var thePic = Bitmap.createScaledBitmap(bitmapBill!!, width, height, true)

            val matrix = Matrix()

            if (bitmapRatio != globalRatio) matrix.postRotate(0f) else matrix.postRotate(rotate.toFloat())

            thePic = Bitmap.createBitmap(
                thePic,
                0,
                0,
                thePic.width,
                thePic.height,
                matrix,
                true
            )

            val stream = ByteArrayOutputStream()

            Log.e("BimapSize01:", "" + thePic.byteCount)
            byteArrayBill =
                if (thePic.byteCount > 15555555) {
                    thePic.compress(Bitmap.CompressFormat.PNG, 20, stream)
                    stream.toByteArray()
                } else if (thePic.byteCount > 355555) {
                    thePic.compress(Bitmap.CompressFormat.PNG, 30, stream)
                    stream.toByteArray()
                } else if (thePic.byteCount > 15555) {
                    thePic.compress(Bitmap.CompressFormat.PNG, 50, stream)
                    stream.toByteArray()
                } else {
                    thePic.compress(Bitmap.CompressFormat.PNG, 60, stream)
                    stream.toByteArray()
                }

            bitmapBill = BitmapFactory.decodeByteArray(byteArrayBill, 0, byteArrayBill.size)

            binding.iconAttachment.setImageURI(resultUri)
            binding.layAttachBill.visibility=View.VISIBLE
            //progressBar.visibility=View.GONE
        } else {
            //progressBar.visibility=View.GONE
            Snackbar.make(binding.rootLayout, R.string.toast_cannot_retrieve_cropped_image, Snackbar.LENGTH_LONG).show()
            //Toast.makeText(this@UpdateActivity, R.string.toast_cannot_retrieve_cropped_image, Toast.LENGTH_SHORT).show()
        }
    }

    var globalRatio = 0f
    var rotate = 0
    private fun handleCropResult(result: Intent) {
        //val resultUri = UCrop.getOutput(result)
        val resultUri = Uri.parse(result.getStringExtra("resultUri"))
        if (resultUri != null) {

            bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), resultUri)
            bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), resultUri)

            var width: Int = bitmap!!.getWidth()
            var height: Int = bitmap!!.getHeight()

            val bitmapRatio = width.toFloat() / height.toFloat()
            if (bitmapRatio > 1) {
                width = 500
                height = (width / bitmapRatio).toInt()
            } else {
                height = 500
                width = (height * bitmapRatio).toInt()
            }
            var thePic = Bitmap.createScaledBitmap(bitmap!!, width, height, true)

            Log.e("globalRatio", "" + globalRatio)
            Log.e("bitmapRatio", "" + bitmapRatio)
            val matrix = Matrix()

            if (bitmapRatio != globalRatio) matrix.postRotate(0f) else matrix.postRotate(rotate.toFloat())

            thePic = Bitmap.createBitmap(
                thePic,
                0,
                0,
                thePic.width,
                thePic.height,
                matrix,
                true
            )

            val stream = ByteArrayOutputStream()

            Log.e("BimapSize01:", "" + thePic.byteCount)
            //15555555
            //355555
            //15555


            byteArray =
                if (thePic.byteCount > 15555555) {
                    thePic.compress(Bitmap.CompressFormat.PNG, 20, stream)
                    stream.toByteArray()
                } else if (thePic.byteCount > 355555) {
                    thePic.compress(Bitmap.CompressFormat.PNG, 30, stream)
                    stream.toByteArray()
                } else if (thePic.byteCount > 15555) {
                    thePic.compress(Bitmap.CompressFormat.PNG, 50, stream)
                    stream.toByteArray()
                } else {
                    thePic.compress(Bitmap.CompressFormat.PNG, 60, stream)
                    stream.toByteArray()
                }

            bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            binding.stuffImg.setImageURI(resultUri)
            binding.noImg.visibility= View.GONE
            binding.progressBar.visibility=View.GONE
            //ResultActivity.startWithUri(this@UpdateActivity, resultUri)
        } else {
            binding.progressBar.visibility=View.GONE
            Snackbar.make(binding.rootLayout, R.string.toast_cannot_retrieve_cropped_image, Snackbar.LENGTH_LONG).show()
            //Toast.makeText(this@UpdateActivity, R.string.toast_cannot_retrieve_cropped_image, Toast.LENGTH_SHORT).show()
        }
    }


    fun checkPermission(): Boolean {
        var allow = true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            allow = false
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            allow = false
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            allow = false
        }
        return allow
    }

    fun requestPermission(reqcode: Int) {
        val listPermissionsNeeded: MutableList<String> = ArrayList()
        listPermissionsNeeded.add(Manifest.permission.CAMERA)
        listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(listPermissionsNeeded.toTypedArray(), reqcode)
        }
    }

    var picUri:Uri?=null
    var fileUri:Uri?=null
    private fun goToTakephoto() {
        picUri = getOutputMediaFileUri(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE)

        val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        captureIntent.putExtra("outputX", 200)
        captureIntent.putExtra("outputY", 200)
        captureIntent.putExtra("aspectX", 1)
        captureIntent.putExtra("aspectY", 1)

        captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, picUri)
        captureIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivityForResult(captureIntent, REQUEST_CAMERA)

        /*val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            //captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, getPhotoFileUri())
        } else {
            captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, picUri)
        }
        if (captureIntent.resolveActivity(applicationContext.packageManager) != null) {
            startActivityForResult(captureIntent, REQUEST_CAMERA)
        }*/
    }

    fun pickBillFromGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
            .setType("image/*")
            .addCategory(Intent.CATEGORY_OPENABLE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            val mimeTypes = arrayOf("image/jpeg", "image/png")
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
        }
        startActivityForResult(Intent.createChooser(intent, getString(R.string.label_select_picture)), 113)
    }
    fun pickFromGallery() {
/*
        val intent = Intent(this@InsertActivity, BasicActivity::class.java)
        startActivityForResult(intent, 112)*/

        val intent = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            val mimeTypes = arrayOf("image/jpeg", "image/png")
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
        }

        startActivityForResult(Intent.createChooser(intent, getString(R.string.label_select_picture)), 114)
    }


    var mediaFile: File? = null
    private fun getOutputMediaFileUri(type: Int): Uri? {
        mediaFile = getOutputMediaFile(type)
        //return Uri.fromFile(mediaFile)
        return FileProvider.getUriForFile(this@UpdateActivity, BuildConfig.APPLICATION_ID + ".provider", mediaFile!!)
    }

    private fun getOutputMediaFile(type: Int): File? {
        val mediaFile: File
        val mediaStorageDir: File
        mediaStorageDir = File(AppUtil.mainDir)
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.e("StuffManager", "failed to create directory")
                return null
            }
        }

        // Create a media file name
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss",Locale.getDefault()).format(Date())
        if (type == MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE) {
            Log.e("StuffManager","Path001:" + mediaStorageDir.path + File.separator + "IMG_" + timeStamp + ".jpg")

            mediaFile = File(mediaStorageDir.path + File.separator + "IMG_" + timeStamp + ".jpg")
            Log.e("StuffManager:", "Path002:" + mediaFile.path)
            val options = BitmapFactory.Options()
            options.inMutable = true
            //bitmapImage = BitmapFactory.decodeFile(mediaFile.getPath(),options);
        } else {
            return null
        }
        Log.e("Return:", "Ok")
        return mediaFile
    }

    private fun startCrop(uri: Uri) {
        binding.progressBar.visibility=View.VISIBLE

        val intent = Intent(this@UpdateActivity, BasicActivity::class.java)
        intent.putExtra("sourceUri",uri.toString())

        ///val args=Bundle()
        //args.putParcelable("sourceUri", uri)
        //args.putParcelable("FrameRect",null)
        //intent.putExtra("data",args)

        startActivityForResult(intent, 112)

        /*var destinationFileName: String = "SampleCropImage.png"
        var uCrop = UCrop.of(uri, Uri.fromFile(File(cacheDir, destinationFileName)))
        uCrop.start(this@UpdateActivity)*/

    }

    private var categoryArray: ArrayList<Category> = ArrayList<Category>()

    fun categoryPicker() {
        categoryArray=dbHelper!!.getCatDetailAdapter(true)

        val alertDialog = AlertDialog.Builder(this)
        val view = LayoutInflater.from(this).inflate(R.layout.lay_recycler2, null)

        alertDialog.setView(view)
        alertDialog.setCancelable(true)

        val dialog: Dialog = alertDialog.create()
        val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
        val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = view.findViewById<View>(R.id.btnNegative) as TextView
        val btnAdd = view.findViewById<View>(R.id.btnAdd) as ImageView
        txtTitle.text = "Category"
        val rvCategoryOption: RecyclerView = view.findViewById(R.id.rv_recycler_option)
        rvCategoryOption.setHasFixedSize(true)
        rvCategoryOption.layoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.VERTICAL,
            false
        )
        val itemDecoration = ItemOffsetDecoration(this, R.dimen.item_offset)
        rvCategoryOption.addItemDecoration(itemDecoration)

        val categoryAdapter = SingleCategoryAdapter(
            this@UpdateActivity, categoryArray, catId
        )
        categoryAdapter.setListSelectedListener(object : SingleCategoryAdapter.SortListener {
            override fun onCategorySelected(catId: Int,category: String) {

                Log.e("UpdateActivity", "categoryPicker:catId:"+catId)
                //catId=categoryArray.get(position).catId
                this@UpdateActivity.catId =catId
                //txt_category.setText(categoryArray.get(position).category)
                binding.txtCategory.setText(category)
                //sort = position
                categoryAdapter.notifyDataSetChanged()
            }
        })
        rvCategoryOption.adapter=categoryAdapter

        btnAdd.setOnClickListener {
            addNewCategory()
            dialog.dismiss()
        }
        btnPositive.setOnClickListener {
            dialog.dismiss()
        }
        btnNegative.setOnClickListener {
            //this@UpdateActivity.catId =categoryArray.get(categoryArray.size-1).catId
            //txt_category.setText(categoryArray.get(categoryArray.size-1).category)
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    fun addNewCategory() {
        val alertDialog = AlertDialog.Builder(this)
        val view = LayoutInflater.from(this).inflate(R.layout.lay_editview, null)
        alertDialog.setView(view)
        alertDialog.setCancelable(true)

        val dialog: Dialog = alertDialog.create()
        val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
        val editcategory = view.findViewById<View>(R.id.txt_category) as TextInputEditText
        val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = view.findViewById<View>(R.id.btnNegative) as TextView

        txtTitle.setText("Add New Category")
        btnPositive.setOnClickListener {

            category = editcategory.text.toString().trim { it <= ' ' }
            var exist=false
            for(calList:Category in categoryArray) {
                if(calList.category.equals(category,true)) {
                    exist=true
                }
            }
            if(category.isEmpty()) {
                editcategory.setError("Please enter category")
            } else if(category.equals("other",true)) {
                editcategory.setError("Invalid category")
            } else if(exist) {
                editcategory.setError("Category Already Exist")
            }  else {
                dbHelper!!.catInsert(category)
                binding.txtCategory.setText(category)
                dialog.dismiss()
            }

            Handler().postDelayed(Runnable {
                catId=dbHelper!!.getLastCatId(category)
                Log.e("UpdateActivity", "addNewCategory:catId:"+catId)
            },1000)
        }
        btnNegative.setOnClickListener {
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }


    fun oneStepPicker() {
        val inflate: View = View.inflate(this, R.layout.one_step_picker, null)

        val alertDialog = AlertDialog.Builder(this).setView(inflate).setCancelable(true)

        var serviceWheel : WheelPicker=inflate.findViewById(R.id.serviceWheel)
        val btnPositive = inflate.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = inflate.findViewById<View>(R.id.btnNegative) as TextView

        var yearAdapter= WheelItemAdapter(resources.getStringArray(R.array.serviceFreq))

        serviceWheel.setAdapter(yearAdapter)
        serviceWheel.scrollTo(serviceFreq)

        val dialog: AlertDialog = alertDialog.create()
        dialog.setCanceledOnTouchOutside(true)
        btnPositive.setOnClickListener {

            serviceFreq=serviceWheel.getCurrentItemPosition()

            var expStr:String=serviceFreqStr.get(serviceFreq).toString()

            binding.txtReminderService.setText(expStr.trim())

            dialog.dismiss()
        }

        btnNegative.setOnClickListener {

            dialog.dismiss()
        }


        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));

        dialog.show()
    }

    fun twoStepPicker() {
        val inflate: View = View.inflate(this, R.layout.two_step_picker, null)

        val alertDialog = AlertDialog.Builder(this).setView(inflate).setCancelable(true)

        var yearWheel : WheelPicker =inflate.findViewById(R.id.yearWheel)
        var monthWheel : WheelPicker =inflate.findViewById(R.id.monthWheel)
        val btnPositive = inflate.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = inflate.findViewById<View>(R.id.btnNegative) as TextView

        var yearAdapter= WheelItemAdapter(
            resources.getStringArray(R.array.yearArray)
        )
        var monthAdapter= WheelItemAdapter(
            resources.getStringArray(R.array.monthArray)
        )
        yearWheel.setAdapter(yearAdapter)
        monthWheel.setAdapter(monthAdapter)

        yearWheel.scrollTo(exYr)
        monthWheel.scrollTo(exMonth)

        val dialog: AlertDialog = alertDialog.create()
        dialog.setCanceledOnTouchOutside(true)
        btnPositive.setOnClickListener {

            exYr=yearWheel.getCurrentItemPosition()
            exMonth=monthWheel.getCurrentItemPosition()

            var expStr:String=""

            if(exYr>0) expStr=expStr+" "+exYr+"Y"
            if(exMonth>0) expStr=expStr+" "+exMonth+"M"

            binding.txtDateExpr.setText(expStr.trim())

            dialog.dismiss()
        }

        btnNegative.setOnClickListener {
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        /*
        alertDialog.setPositiveButton("Ok", DialogInterface.OnClickListener { dialog, which ->

            exYr=yearWheel.getCurrentItemPosition()
            exMonth=monthWheel.getCurrentItemPosition()

            var expStr:String=""

            if(exYr>0) expStr=expStr+" "+exYr+"Y"
            if(exMonth>0) expStr=expStr+" "+exMonth+"M"

            txt_date_expr.setText(expStr.trim())

            dialog.dismiss()
        })*/

        /*
        alertDialog.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which ->
            dialog.dismiss()
        })
        */

        dialog.show()

    }

    fun updateStuff() {

        stuffName = binding.txtName.text.toString().trim { it <= ' ' }
        description = binding.txtDetail.text.toString().trim { it <= ' ' }
        barcode = binding.txtSerial.text.toString().trim { it <= ' ' }
        price = binding.txtPrice.text.toString().trim { it <= ' ' }

        if (stuffName.isEmpty()) {
            binding.txtName.error = resources.getString(R.string.enter_stuff_name)
            binding.txtName.requestFocus()
        } else {

            if (binding.txtDetail.text.toString().trim { it <= ' ' }.isEmpty() || binding.txtDetail.text.toString().equals("", ignoreCase = true)) {
                description = ""
            } else description = binding.txtDetail.text.toString()

            //val dateFormat = SimpleDateFormat("yyyy-MM-dd")

            try {
                var year = exYr
                var month = exMonth

                val c = Calendar.getInstance()
                c.time = dateMain
                if (year != 0) c.add(Calendar.YEAR, year)
                if (month != 0) c.add(Calendar.MONTH, month)
                val dt = c.time
                val dateFormat = SimpleDateFormat("dd-MM-yyyy",Locale.getDefault())

                expiry_date = dateFormat.format(dt)
                purchasedate=dateFormat.format(dateMain)

                if (year == 0 && month == 0) {
                    expiry_date = "00-00-0000"
                }

                Log.e("UpdateActivity", "expiry_date:" + expiry_date)
                Log.e("UpdateActivity", "purchasedate:" + purchasedate)
                Log.e("UpdateActivity", "serviceFreq:" + serviceFreq)

                val imgStr= AppUtil.BitMapToString(bitmap)

                val stuffGetSet = StuffGetSet(
                    0,
                    0,
                    stuffName,
                    description,
                    barcode,
                    imgStr,
                    imgStr,
                    price,
                    purchasedate,
                    expiry_date,
                    serviceFreq,
                    exMonth,
                    exYr
                )

                dbHelper!!.stuffUpdate(
                    stuffId,
                    catId,
                    stuffName,
                    description,
                    barcode,
                    imgStr,
                    imgStr,
                    price,
                    purchasedate,
                    expiry_date,
                    serviceFreq,
                    exMonth,
                    exYr
                )
                val intent = Intent(this@UpdateActivity, MainActivity::class.java)
                intent.flags=Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)

            } catch (e: ParseException) {
                Log.e("UpdateActivity", "Exception:" + e)
                e.printStackTrace()
            }
            //saveStuff()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.size > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED && grantResults[2] == PackageManager.PERMISSION_GRANTED
            ) {
                if(requestCode==REQUEST_CAMERA) {
                    goToTakephoto()
                }
                else if(requestCode==REQUEST_GALLERY) {
                    pickFromGallery()
                }
                else if(requestCode==REQUEST_BILL) {
                    pickBillFromGallery()
                }
                else if(requestCode==REQUEST_QR) {
                    openScanner()
                }
            }

        }
    }

    inner class MyAsyncTask : AsyncTask<Int?, Void?, StuffGetSet>() {

        override fun doInBackground(vararg params: Int?): StuffGetSet? {
            //return dbHelper!!.getAllData(context)
            return dbHelper!!.getData(this@UpdateActivity,""+stuffId)

        }

        override fun onPostExecute(result: StuffGetSet) {
            super.onPostExecute(result)
            stuffGetSet=result
            setData(result)
        }

    }

}