package com.mystufforganizer.reminder.notify.wheelview

class WheelItemAdapter(strArray: Array<String>) : WheelAdapter() {

    //private val months = DateFormatSymbols.getInstance().months
    private val stringArray = strArray

    fun getMaxIndex(): Int = getSize() - 1

    fun getMinIndex(): Int = 0

    override fun getValue(position: Int): String {
        if (position >= getMinIndex() && position <= getMaxIndex())
            return stringArray[position]

        if (position <= getMaxIndex())
            return stringArray[position + getSize()]

        if (position >= getMinIndex())
            return stringArray[position - getSize()]

        return ""
    }

    override fun getPosition(vale: String): Int = stringArray.indexOf(vale).clamp(getMinIndex(), getMaxIndex())

    override fun getTextWithMaximumLength(): String = stringArray.maxBy { it.length } ?: ""

    override fun getSize(): Int = stringArray.size
}