package com.mystufforganizer.reminder.notify.fragment

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.activity.MainActivity
import com.mystufforganizer.reminder.notify.activity.StuffListActivity
import com.mystufforganizer.reminder.notify.adapter.*
import com.mystufforganizer.reminder.notify.callback.CategoryCallback
import com.mystufforganizer.reminder.notify.callback.DialogCallback
import com.mystufforganizer.reminder.notify.database.Category
import com.mystufforganizer.reminder.notify.database.SQLiteHelper
import com.mystufforganizer.reminder.notify.util.AppUtil
import com.mystufforganizer.reminder.notify.util.Const
import com.mystufforganizer.reminder.notify.util.MyPreference
import java.lang.String
import java.util.*


open class HomeFragment : BaseFragment(),
    CategoryCallback {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    private var gridLayoutManager: GridLayoutManager? = null
    private var categoryArray: ArrayList<Category> = ArrayList<Category>()
    private var categoryAdapter: CategoryAdapter? = null
    open var dbHelper: SQLiteHelper? = null
    private var multiSelector: MultiSelector? = null
    private var myPreference: MyPreference? = null
    private var layType = 1

    private var mRecyclerViewItems: ArrayList<Any>? = null

    var animationList = intArrayOf(
        R.anim.layout_animation_up_to_down,
        R.anim.layout_animation_right_to_left,
        R.anim.layout_animation_down_to_up,
        R.anim.layout_animation_left_to_right
    )

    var tool_option: ImageView? = null
    var tool_sort: ImageView? = null
    var tool_grid: ImageView? = null
    var tool_select: ImageView? = null
    var tool_delete: ImageView? = null
    var tool_search: ImageView? = null
    var tool_back1: ImageView? = null
    var tool_back2: ImageView? = null
    var ed_search: EditText? = null
    var select_title: TextView? = null
    var recyclerview: RecyclerView? = null
    var lay_select: RelativeLayout? = null
    var lay_action: LinearLayout? = null
    var emptyView: LinearLayout? = null
    var lay_search: RelativeLayout? = null
    var progressBar: ProgressBar? = null

    var toolbar: Toolbar? = null
    private var rootView: View? = null
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        rootView = inflater.inflate(R.layout.fragment_home, container, false)

        toolbar = rootView!!.findViewById(R.id.toolbar)
//        (activity as MainActivity).setSupportActionBar(toolbar!!)
//        (activity as MainActivity).getSupportActionBar()!!.setElevation(20f);

        tool_option = rootView!!.findViewById(R.id.tool_option)
        tool_sort = rootView!!.findViewById(R.id.tool_sort)
        tool_grid = rootView!!.findViewById(R.id.tool_grid)
        tool_select = rootView!!.findViewById(R.id.tool_select)
        tool_delete = rootView!!.findViewById(R.id.tool_delete)
        tool_search = rootView!!.findViewById(R.id.tool_search)
        tool_back1 = rootView!!.findViewById(R.id.tool_back1)
        tool_back2 = rootView!!.findViewById(R.id.tool_back2)
        ed_search = rootView!!.findViewById(R.id.ed_search)
        select_title = rootView!!.findViewById(R.id.select_title)

        recyclerview = rootView!!.findViewById(R.id.recyclerview)
        progressBar = rootView!!.findViewById(R.id.progressBar)

        emptyView = rootView!!.findViewById(R.id.emptyView)
        lay_select = rootView!!.findViewById(R.id.lay_select)
        lay_action = rootView!!.findViewById(R.id.lay_action)
        lay_search = rootView!!.findViewById(R.id.lay_search)

        lay_action!!.animate()
            .translationY(0f)
            .alpha(1.0f)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    super.onAnimationEnd(animation)
                    lay_action!!.visibility = View.VISIBLE
                }
            })


        dbHelper = SQLiteHelper(context)
        dbHelper!!.open()
        myPreference = MyPreference(context!!)
        layType = myPreference!!.getInt(context!!, Const.KEY_LAYTYPE, 1)

        multiSelector = MultiSelector(recyclerview!!)
        recyclerview!!.setHasFixedSize(true)

        if (layType == 2) tool_grid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_list_view))
        else tool_grid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_grid_view))

        progressBar!!.visibility=View.VISIBLE
        MyAsyncTask().execute()

        tool_sort!!.setOnClickListener {
            showSortDialog(context!!)
        }
        tool_grid!!.setOnClickListener {
            switchLayout()
        }
        tool_select!!.setOnClickListener {
            if (categoryAdapter!!.isMultipleChoiceMode) {
                categoryAdapter!!.setNormalChoiceMode()
                stopActionMode()
            } else {
                categoryAdapter!!.setMultipleChoiceMode()
                startActionMode()
            }
        }
        tool_delete!!.setOnClickListener {
            if (multiSelector!!.checkedItems.size() > 0) {
                onDeleteOptionClicked()
            }
        }
        tool_search!!.setOnClickListener {
            lay_search!!.visibility = View.VISIBLE
            //lay_action!!.visibility=View.GONE
        }
        tool_back1!!.setOnClickListener {
            lay_search!!.visibility = View.GONE
            ed_search!!.setText("")
            //lay_action!!.visibility=View.VISIBLE
            hideKeyboard(ed_search!!)
        }
        tool_back2!!.setOnClickListener {
            categoryAdapter!!.setNormalChoiceMode()
            stopActionMode()
        }
        tool_option!!.setOnClickListener {
            val popupMenu = PopupMenu(context, tool_option)
            popupMenu.inflate(R.menu.option_main)
            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.share -> {
                        AppUtil.shareApp(context!!)
                    }
                    R.id.rate -> {
                        AppUtil.rateOnPlayStore(context!!)
                    }
                    R.id.privacy -> {
                        val browserIntent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(Const.PRIVACY_POLICY)
                        )
                        startActivity(browserIntent)
                    }
                }
                false
            }
            popupMenu.show()
        }

        ed_search!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (categoryAdapter != null) {
                    categoryAdapter!!.getFilter().filter(s.toString())
                    categoryAdapter!!.notifyDataSetChanged()
                }
            }

        })

        return rootView
    }

    override fun onResume() {
        super.onResume()
        if(Const.isCatAdded) {
            Const.isCatAdded= false
            progressBar!!.visibility=View.VISIBLE
            MyAsyncTask().execute()
        }
    }

    var sort = 0
    var order = 0
    private fun showSortDialog(context: Context) {

        //final Dialog dialog = new Dialog(context);
        val alertDialog = AlertDialog.Builder(context)
        val view = LayoutInflater.from(context).inflate(R.layout.lay_sort, null)

        alertDialog.setView(view)
        alertDialog.setCancelable(true)

        val dialog: Dialog = alertDialog.create()
        val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
        val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = view.findViewById<View>(R.id.btnNegative) as TextView
        txtTitle.text = "Sorting"
        val rvCategoryOption: RecyclerView = view.findViewById(R.id.rv_recycler_option)
        rvCategoryOption.setHasFixedSize(true)
        rvCategoryOption.layoutManager = LinearLayoutManager(
            context,
            LinearLayoutManager.VERTICAL,
            false
        )
        val sortAdapter = SortAdapter(
            arrayOf(
                "Alphabet",
                "Total Stuff"
            ), sort
        )
        rvCategoryOption.adapter = sortAdapter
        sortAdapter.setListSelectedListener(object : SortAdapter.SortListener {
            override fun onCategorySelected(position: Int) {
                sort = position
                sortAdapter.notifyDataSetChanged()
            }
        })
        val rvCategoryOrder: RecyclerView = view.findViewById(R.id.rv_recycler_order)

        rvCategoryOrder.setHasFixedSize(true)
        rvCategoryOrder.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        val orderAdapter = SortAdapter(
            arrayOf(
                "Ascending",
                "Descending"
            ), order
        )
        rvCategoryOrder.adapter = orderAdapter
        orderAdapter.setListSelectedListener(object : SortAdapter.SortListener {
            override fun onCategorySelected(position: Int) {
                order = position
                orderAdapter.notifyDataSetChanged()
            }
        })
        btnPositive.setOnClickListener {
            dialog.dismiss()
            myPreference!!.setInt(getContext()!!,Const.KEY_SORT,sort)
            myPreference!!.setInt(getContext()!!,Const.KEY_ORDR,order)
            sortAdapter(sort, order);

        }
        btnNegative.setOnClickListener {
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        //Dialog dialog=alertDialog.create();
        dialog.show()
    }

    fun sortAdapter(sort: Int, order: Int) {
        when (sort) {
            0 ->
                if (order == 0) Collections.sort<Category>(
                    categoryArray,
                    Category.atozComparator
                )
                else Collections.sort<Category>(categoryArray, Category.ztoaComparator)
            1 ->
                if (order == 0) Collections.sort<Category>(
                    categoryArray,
                    Category._9to0Comparator
                )
                else Collections.sort<Category>(categoryArray, Category._0to9Comparator)

        }
        categoryAdapter!!.notifyDataSetChanged()
        animate()
    }

    private fun animate() {
        val controller = AnimationUtils.loadLayoutAnimation(context, animationList[0])
        recyclerview!!.setLayoutAnimation(controller)
        recyclerview!!.scheduleLayoutAnimation()
    }

    private fun switchLayout() {
        if (gridLayoutManager!!.spanCount == 1) {
            layType = 2
            gridLayoutManager!!.spanCount = 2
            tool_grid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_list_view))
        } else {
            layType = 1
            gridLayoutManager!!.spanCount = 1
            tool_grid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_grid_view))
        }
        myPreference!!.setInt(context!!, Const.KEY_LAYTYPE, layType)
        categoryAdapter!!.refreshData()

        animate()
    }

    fun onEditCategory(catId:Int, cat: kotlin.String) {
        if(cat.equals("other",true)) {
            Snackbar.make(rootView!!,"Can't Edit Category "+cat,Snackbar.LENGTH_LONG).show()
            return
        }
        val alertDialog = AlertDialog.Builder(context)
        val view = LayoutInflater.from(context).inflate(R.layout.lay_editview, null)
        alertDialog.setView(view)
        alertDialog.setCancelable(true)

        val dialog: Dialog = alertDialog.create()
        val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
        val editcategory = view.findViewById<View>(R.id.txt_category) as TextInputEditText
        val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = view.findViewById<View>(R.id.btnNegative) as TextView

        txtTitle.setText("Update Category")
        editcategory.setText(cat)
        btnPositive.setOnClickListener {

            var category = editcategory.text.toString().trim { it <= ' ' }

            var exist=false
            for(calList:Category in categoryArray) {
                if(calList.category.equals(category,true)) {
                    exist=true
                }
            }

            if(category.isEmpty()) {
                editcategory.setError("Please enter category")
            } else if(category.equals("other",true)) {
                editcategory.setError("Invalid category")
            } else if(exist) {
                editcategory.setError("Category Already Exist")
            } else {
                dbHelper!!.catUpdate(catId,category)
                //txt_category.setText(category)
                dialog.dismiss()
            }

            Handler().postDelayed(Runnable {
                onResume()
            },1000)
        }
        btnNegative.setOnClickListener {
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    override fun onAdapterClick(view: View, position: Int, category: Category) {
        if (categoryAdapter!!.isMultipleChoiceMode) {
            multiSelector!!.checkView(view, position)
            updateActionModeTitle()
        } else {

            val intent = Intent(context, StuffListActivity::class.java)
            intent.putExtra("catId", category.catId)
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(activity!!, view, "ivGrid")
            //startActivityForResult(intent, 1, options.toBundle())
            startActivity(intent, options.toBundle())
        }
    }

    override fun onOptionClick(view: View, action: Int, category: Category) {
        if (action == 1) {
            onDeleteItemClicked(category.catId)
        } else if (action == 2) {
            onEditCategory(category.catId,category.category)
            /*
            val intent = Intent(context, UpdateActivity::class.java)
            intent.putExtra("stuff_id", itemId)
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(activity!!, view, "ivGrid")
            startActivity(intent, options.toBundle())
            */

        }
    }

    override fun onAdapterLongClick(view: View, position: Int) {
        if (!categoryAdapter!!.isMultipleChoiceMode) {
            categoryAdapter!!.setMultipleChoiceMode()
            multiSelector!!.checkView(view, position)
            startActionMode()
            updateActionModeTitle()
        }
    }

    private fun onDeleteItemClicked(itemId: Int) {

        AppUtil.askAlertDialog(context,
            Const.DELETE_ALERT_TITLE, Const.DELETE_ALERT_MESSAGE, "Yes", "No",
            object : DialogCallback {
                override fun onClick() {
                    dbHelper!!.catDelete(itemId)
                    MyAsyncTask().execute()
                }
            },
            object : DialogCallback {
                override fun onClick() {
                }
            }
        )

    }

    private fun onDeleteOptionClicked() {
        val checkItems: ParcelableSparseBooleanArray = multiSelector!!.checkedItems
        AppUtil.askAlertDialog(activity,
            Const.DELETE_ALERT_TITLE,
            Const.DELETE_ALERT_MESSAGE,
            "Yes",
            "No",
            object : DialogCallback {
                override fun onClick() {
                    val adapter: CategoryAdapter = recyclerview!!.getAdapter() as CategoryAdapter
                    adapter.deleteItems(checkItems)

                    MyAsyncTask().execute()

                    multiSelector!!.clearAll()
                    stopActionMode()
                }
            },
            object : DialogCallback {
                override fun onClick() {
                    stopActionMode()
                }
            }

            /*DialogInterface.OnClickListener { dialog, which ->
                val adapter: StuffAdapter = recyclerview!!.getAdapter() as StuffAdapter
                adapter.deleteItems(checkItems)

                stuffArray = dbHelper!!.getAllData(context)
                multiSelector!!.clearAll()
                stopActionMode()
                dialog.dismiss()
            },
            DialogInterface.OnClickListener { dialog, which ->
                stopActionMode()
                dialog.dismiss()
            }*/
        )

    }

    private fun updateActionModeTitle() {
        //actionMode.setTitle(String.valueOf(multiSelector.getCount()));
        select_title!!.setText(String.valueOf(multiSelector!!.count))
    }

    override fun onBackPressed(): Boolean {
        Log.e("onBackPressed", "HomeFragment")
        if (lay_search!!.visibility == View.VISIBLE) {
            //lay_search!!.visibility=View.GONE
            tool_back1!!.performClick()
            Log.e("onBackPressed", "lay_search")
            return false
        } else if (lay_select!!.visibility == View.VISIBLE) {
            tool_back2!!.performClick()
            //lay_select!!.visibility = View.GONE
            //stopActionMode()
            Log.e("onBackPressed", "lay_select")
            return false
        } else {
            Log.e("onBackPressed", "else")
            return true
        }
    }

    /*
    override fun onBackPressed() {
        if(lay_search!!.visibility==View.VISIBLE)
            lay_search!!.visibility=View.GONE
        else if(lay_select!!.visibility==View.VISIBLE)
            lay_select!!.visibility=View.GONE
        else onBackPressed()
    }
    */

    private fun startActionMode() {
        lay_select!!.visibility = View.VISIBLE
        lay_action!!.visibility = View.GONE
    }

    private fun stopActionMode() {
        select_title!!.setText("")
        multiSelector!!.clearAll()
        val adapter: CategoryAdapter = recyclerview!!.getAdapter() as CategoryAdapter
        if (adapter != null) adapter.setNormalChoiceMode()
        lay_select!!.visibility = View.GONE
        lay_action!!.visibility = View.VISIBLE
    }

    private fun hideKeyboard(view: View) {
        val inputManager = context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (view != null) {
            inputManager.hideSoftInputFromWindow(view.getWindowToken(), 0)
        }

        var viewCur = activity!!.currentFocus
        if (viewCur != null) {
            inputManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
        }
    }

    private fun setData(result: ArrayList<Category>) {
        if(!isAdded) return

        sort=myPreference!!.getInt(getContext()!!,Const.KEY_SORT)
        order=myPreference!!.getInt(getContext()!!,Const.KEY_ORDR)

        //stuffArray=dbHelper!!.getAllData(context)
        if(result.size>0) {
            emptyView!!.visibility=View.GONE
            recyclerview!!.visibility=View.VISIBLE

            tool_sort!!.visibility=View.VISIBLE
            tool_grid!!.visibility=View.VISIBLE
            tool_search!!.visibility=View.VISIBLE

        } else {
            emptyView!!.visibility=View.VISIBLE
            recyclerview!!.visibility=View.GONE

            tool_sort!!.visibility=View.GONE
            tool_grid!!.visibility=View.GONE
            tool_search!!.visibility=View.GONE
        }

        categoryArray = result

        mRecyclerViewItems = ArrayList()
        mRecyclerViewItems!!.clear()
        mRecyclerViewItems!!.addAll(categoryArray)

        gridLayoutManager = GridLayoutManager(context, layType)
        categoryAdapter = CategoryAdapter(
            activity!!,
            categoryArray,
            this@HomeFragment,
            multiSelector,
            gridLayoutManager!!
        )
        recyclerview!!.layoutManager = gridLayoutManager
        //val itemDecoration = ItemOffsetDecoration(this, R.dimen.item_offset)
        //recyclerview.addItemDecoration(itemDecoration)

        recyclerview!!.adapter = categoryAdapter
        progressBar!!.visibility=View.GONE

        //animate()
        sortAdapter(sort, order);
    }

    inner class MyAsyncTask : AsyncTask<Int?, Void?, ArrayList<Category>>() {

        override fun doInBackground(vararg params: Int?): ArrayList<Category> {
            return dbHelper!!.getCatDetailAdapter(true)
        }

        override fun onPostExecute(result: ArrayList<Category>) {
            super.onPostExecute(result)
            setData(result)
        }

    }

}