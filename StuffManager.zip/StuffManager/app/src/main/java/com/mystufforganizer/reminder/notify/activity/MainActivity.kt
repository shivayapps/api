package com.mystufforganizer.reminder.notify.activity

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.transition.Fade
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.fragment.app.FragmentTransaction
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.google.android.gms.tasks.OnCompleteListener

import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.callback.DialogCallback
import com.mystufforganizer.reminder.notify.databinding.ActivityMainBinding
import com.mystufforganizer.reminder.notify.fragment.BaseFragment
import com.mystufforganizer.reminder.notify.fragment.HomeFragment
import com.mystufforganizer.reminder.notify.fragment.SettingFragment
import com.mystufforganizer.reminder.notify.notification.AlarmService
import com.mystufforganizer.reminder.notify.util.AdsClass
import com.mystufforganizer.reminder.notify.util.AppUtil
import com.mystufforganizer.reminder.notify.util.Const
import com.mystufforganizer.reminder.notify.util.MyPreference


class MainActivity : AppCompatActivity() {

    private var myPreference: MyPreference? = null

    var animationList = intArrayOf(
        R.anim.layout_animation_up_to_down,
        R.anim.layout_animation_right_to_left,
        R.anim.layout_animation_down_to_up,
        R.anim.layout_animation_left_to_right
    )

    companion object {
        val NOTIFICATION_CHANNEL_ID = "10001"
        private val default_notification_channel_id = "default"
    }

    var sectionsPagerAdapter: SectionsPagerAdapter? = null


    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.exitTransition = Fade(Fade.OUT)
        }

        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@MainActivity, R.color.colorWhite)
        }
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_main)

        //val window: Window = activity.getWindow()
        /*
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val decor = window.decorView
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        }
        */

        myPreference = MyPreference(this@MainActivity)

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this@MainActivity, InsertActivity::class.java))
        }

        //switchFragment(HomeFragment(),"home")
        binding.menuHome.setOnClickListener {
            //switchFragment(HomeFragment(), "home")
            binding.viewPager.setCurrentItem(0,true)
        }
        binding.menuSettings.setOnClickListener {
            //switchFragment(SettingFragment(), "setting")
            binding.viewPager.setCurrentItem(1,true)
        }

        //startService(Intent(this, AlarmService::class.java))

        if (AppUtil.check_internet(this@MainActivity)) {
            val frameLayout: FrameLayout = findViewById(R.id.fl_adplaceholder)
            val adsCallBack= object : AdsClass.adsCallBack{
                override fun onAdLoaded() {
                }
            }

//            val adRequest = AdRequest.Builder().build()
            // Start loading the ad in the background.
            /*ad_view.loadAd(adRequest)
            ad_view.adListener=object :AdListener(){
                override fun onAdFailedToLoad(p0: Int) {
                    super.onAdFailedToLoad(p0)
                    ad_view.visibility= View.GONE
                }

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    ad_view.visibility= View.VISIBLE
                }
            }*/
        }

        setViewPager()
        fcmToken()
    }

    private fun setViewPager() {
        sectionsPagerAdapter = SectionsPagerAdapter(this, getSupportFragmentManager())
        binding.viewPager.setAdapter(sectionsPagerAdapter)
        binding.viewPager.setOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {
            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                when(position){
                    0 -> {
                        tag="home"
                        switchMenu(tag)
                    }
                    1 -> {
                        tag="setting"
                        switchMenu(tag)
                    }
                    else -> {
                        tag="home"
                        switchMenu(tag)
                    }
                }
            }
        })

        tag="home"
        switchMenu(tag)
    }


    private fun fcmToken() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            var notificationChannel: NotificationChannel? = null
            notificationChannel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                default_notification_channel_id,
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationChannel.enableLights(true)
            notificationChannel.enableVibration(true)
            notificationChannel.vibrationPattern = longArrayOf(
                100,
                200,
                300,
                400,
                500,
                400,
                300,
                200,
                400
            )
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(notificationChannel)
        }
//        FirebaseInstanceId.getInstance().instanceId
//            .addOnCompleteListener(OnCompleteListener { task ->
//                if (!task.isSuccessful) {
//                    Log.w("TAG", "getInstanceId failed", task.exception)
//                    return@OnCompleteListener
//                }
//                // Get new Instance ID token
//                // String token = task.getResult().getToken();
//                // Log and toast
//                // String msg = getString(R.string.msg_token_fmt, token);
//                val token = task.result!!.token
//                val msg = getString(R.string.fcm_token, token)
//                Log.d("TAG", msg)
//            })
    }

    var tag = "home"
    fun switchFragment(newContent: Fragment?, tag: String) {
        this.tag = tag
        switchMenu(tag)
        if (newContent == null) return
        val fragmentManager = supportFragmentManager
        var fragmentTransaction: FragmentTransaction? = null
        if (fragmentManager != null) {
            fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_container, newContent, tag)
            //fragmentTransaction.addToBackStack(null)
            fragmentTransaction.commitAllowingStateLoss()
        }
    }

    private fun switchMenu(tag: String) {
        if(tag.equals("home",true)) run {

            binding.lblHome.setTextColor(resources.getColor(R.color.colorMain))
            binding.icHome.setColorFilter(resources.getColor(R.color.colorMain))
            binding.lblSetting.setTextColor(resources.getColor(R.color.colorBlack))
            binding.icSetting.setColorFilter(resources.getColor(R.color.colorBlack))
            binding.lblHome.textSize=14f
            binding.lblSetting.textSize=12f
            binding.icHome.setPadding(0,0,0,0)
            binding.icSetting.setPadding(0,3,0,3)

        } else {
            binding.lblHome.setTextColor(resources.getColor(R.color.colorBlack))
            binding.icHome.setColorFilter(resources.getColor(R.color.colorBlack))
            binding.lblSetting.setTextColor(resources.getColor(R.color.colorMain))
            binding.icSetting.setColorFilter(resources.getColor(R.color.colorMain))
            binding.lblHome.textSize=12f
            binding.lblSetting.textSize=14f
            binding.icHome.setPadding(0,3,0,3)
            binding.icSetting.setPadding(0,0,0,0)
        }
    }


    override fun onBackPressed() {

        val fragmentList: List<*> = supportFragmentManager.fragments
        var handled = false
        for (f in fragmentList) {
            if (f is BaseFragment) {

                Log.e("onBackPressed","Fragment_Tag_01:"+f.tag)
                Log.e("onBackPressed","Fragment_Tag_02:"+tag)
                Log.e("onBackPressed","Fragment_Tag_03:"+binding.viewPager.currentItem)
                Log.e("onBackPressed","Fragment_Count:"+supportFragmentManager.backStackEntryCount)
                if(binding.viewPager.currentItem!=0) {
                    binding.viewPager.currentItem=0
                    break
                } else {
                    handled = f.onBackPressed()
                    if (handled) {
                        break
                    }
                }
            }
        }

        Log.e("onBackPressed","Fragment_Count:"+supportFragmentManager.backStackEntryCount)
        if (handled) {

            AppUtil.askAlertDialog(this@MainActivity,
                Const.EXIT_ALERT_TITLE, Const.EXIT_ALERT_MESSAGE,"Yes","No",
                object : DialogCallback {
                    override fun onClick() {
                        //super.onBackPressed()
                        finishAffinity()
                    }
                },
                object : DialogCallback {
                    override fun onClick() {
                    }
                }
            )
        }

    }


    class SectionsPagerAdapter(var mContext: Context?, fragmentManager: FragmentManager) : FragmentPagerAdapter(fragmentManager) {

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )

        override fun getItem(position: Int): Fragment {
            var fragment: Fragment
            when(position){
                0->{
                    fragment=HomeFragment()
                }
                1->{
                    fragment=SettingFragment()
                }
                else->{
                    fragment=HomeFragment()
                }
            }
            return fragment
        }

        override fun getPageTitle(position: Int): CharSequence? {
            return mContext!!.getResources().getString(TAB_TITLES[position])
        }

        override fun getCount(): Int {
            return 2
        }
    }

}