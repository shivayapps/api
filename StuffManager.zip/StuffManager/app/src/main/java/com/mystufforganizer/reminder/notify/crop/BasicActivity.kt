package com.mystufforganizer.reminder.notify.crop

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.crop.BasicFragment.Companion.newInstance
import com.mystufforganizer.reminder.notify.databinding.ActivityBasicBinding



class BasicActivity : AppCompatActivity() {

    lateinit var binding: ActivityBasicBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@BasicActivity, R.color.colorWhite)
        }
        binding = ActivityBasicBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_basic)

        if (savedInstanceState == null) {

            val fragment:BasicFragment
            if(intent.hasExtra("sourceUri")) {
                val arg=intent.getStringExtra("sourceUri")
                fragment=newInstance(arg!!)
            } else {
                fragment=newInstance()
            }

            supportFragmentManager.beginTransaction().add(
                R.id.container,
                fragment
            ).commit()
        }

        // apply custom font
        //FontUtils.setFont(findViewById(R.id.root_layout));
        initToolbar()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    private fun initToolbar() {
        //val toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        //setSupportActionBar(toolbar)
        //val actionBar = supportActionBar
        //FontUtils.setTitle(actionBar, "Basic Sample");
        //actionBar!!.setDisplayHomeAsUpEnabled(true)
        //actionBar.setHomeButtonEnabled(true)
        binding.toolBack.setOnClickListener { onBackPressed() }
        binding.toolNext.visibility=View.GONE
    }

    fun startResultActivity(uri: Uri) {
        if (isFinishing) return
        Log.e("onActivityResult", "handleResult:$uri")
        val intent = Intent()
        intent.putExtra("resultUri", uri.toString())
        setResult(Activity.RESULT_OK, intent)
        finish()

        // Start ResultActivity
        //startActivity(ResultActivity.createIntent(this, uri));
    }

    companion object {
        private val TAG = BasicActivity::class.java.simpleName
        fun createIntent(activity: Activity?): Intent {
            return Intent(activity, BasicActivity::class.java)
        }
    }
}