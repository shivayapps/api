package com.mystufforganizer.reminder.notify.callback

interface DialogCallback {
    fun onClick()
}