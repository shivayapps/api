package com.mystufforganizer.reminder.notify.activity

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.transition.Fade
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.adapter.MultiSelector
import com.mystufforganizer.reminder.notify.adapter.ParcelableSparseBooleanArray
import com.mystufforganizer.reminder.notify.adapter.SortAdapter
import com.mystufforganizer.reminder.notify.adapter.StuffAdapter
import com.mystufforganizer.reminder.notify.callback.AdpCallback
import com.mystufforganizer.reminder.notify.callback.DialogCallback
import com.mystufforganizer.reminder.notify.database.SQLiteHelper
import com.mystufforganizer.reminder.notify.database.StuffGetSet
import com.mystufforganizer.reminder.notify.databinding.ActivityStuffListBinding
import com.mystufforganizer.reminder.notify.util.*
import com.mystufforganizer.reminder.notify.util.AppUtil
import java.lang.String
import java.util.*
import kotlin.collections.LinkedHashSet

class StuffListActivity : AppCompatActivity() ,
    AdpCallback {

    private var gridLayoutManager: GridLayoutManager? = null
    private var stuffArray: ArrayList<StuffGetSet> = ArrayList<StuffGetSet>()
    private var stuffAdapter: StuffAdapter? = null
    open var dbHelper: SQLiteHelper? = null
    private var multiSelector: MultiSelector? = null
    private var myPreference: MyPreference? = null
    private var layType = 1
    private var catId = 0

    private var mRecyclerViewItems: ArrayList<Any>? = null

    var animationList = intArrayOf(
        R.anim.layout_animation_up_to_down,
        R.anim.layout_animation_right_to_left,
        R.anim.layout_animation_down_to_up,
        R.anim.layout_animation_left_to_right
    )

    lateinit var binding: ActivityStuffListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.exitTransition = Fade(Fade.OUT)
        }

        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@StuffListActivity, R.color.colorWhite)
        }
        binding = ActivityStuffListBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_stuff_list)

        binding.toolbarMain.layAction!!.animate()
            .translationY(0f)
            .alpha(1.0f)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    super.onAnimationEnd(animation)
                    binding.toolbarMain.layAction!!.visibility = View.VISIBLE
                }
            })
        binding.toolbarMain.layAction!!.animate()
            .translationY(0f)
            .alpha(1.0f)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    super.onAnimationEnd(animation)
                    binding.toolbarMain.layAction!!.visibility = View.VISIBLE
                }
            })


        dbHelper = SQLiteHelper(this@StuffListActivity)
        dbHelper!!.open()
        myPreference = MyPreference(this@StuffListActivity)
        layType = myPreference!!.getInt(this@StuffListActivity, Const.KEY_LAYTYPE, 1)

        multiSelector = MultiSelector(binding.recyclerview!!)
        binding.recyclerview!!.setHasFixedSize(true)

        if (layType == 2) binding.toolbarMain.toolGrid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_list_view))
        else binding.toolbarMain.toolGrid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_grid_view))

        catId=intent.getIntExtra("catId",0)
        binding.progressBar.visibility=View.VISIBLE
        MyAsyncTask().execute()

        binding.toolbarMain.toolSort!!.setOnClickListener {
            showSortDialog(this@StuffListActivity)
        }
        binding.toolbarMain.toolGrid!!.setOnClickListener {
            switchLayout()
        }
        binding.toolbarMain.toolSelect!!.setOnClickListener {
            if (stuffAdapter!!.isMultipleChoiceMode) {
                stuffAdapter!!.setNormalChoiceMode()
                stopActionMode()
            } else {
                stuffAdapter!!.setMultipleChoiceMode()
                startActionMode()
            }
        }
        binding.toolbarMain.toolDelete!!.setOnClickListener {
            if (multiSelector!!.checkedItems.size() > 0) {
                onDeleteOptionClicked()
            }
        }
        binding.toolbarMain.toolSearch!!.setOnClickListener {
            binding.toolbarMain.laySearch!!.visibility = View.VISIBLE
            //lay_action!!.visibility=View.GONE
        }
        binding.toolbarMain.toolBack1!!.setOnClickListener {
            binding.toolbarMain.laySearch!!.visibility = View.GONE
            binding.toolbarMain.edSearch!!.setText("")
            //lay_action!!.visibility=View.VISIBLE
            hideKeyboard(binding.toolbarMain.edSearch!!)
        }
        binding.toolbarMain.toolBack2!!.setOnClickListener {
            stuffAdapter!!.setNormalChoiceMode()
            stopActionMode()
        }
        binding.toolbarMain.toolOption!!.setOnClickListener {
            val popupMenu = PopupMenu(this@StuffListActivity, binding.toolbarMain.toolOption)
            popupMenu.inflate(R.menu.option_main)
            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.share -> {
                        AppUtil.shareApp(this@StuffListActivity)
                    }
                    R.id.rate -> {
                        AppUtil.rateOnPlayStore(this@StuffListActivity)
                    }
                    R.id.privacy -> {
                        val browserIntent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(Const.PRIVACY_POLICY)
                        )
                        startActivity(browserIntent)
                    }
                }
                false
            }
            popupMenu.show()
        }

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this@StuffListActivity, InsertActivity::class.java).putExtra("catId",catId))
        }

        binding.toolbarMain.edSearch!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (stuffAdapter != null) {
                    stuffAdapter!!.getFilter().filter(s.toString())
                    stuffAdapter!!.notifyDataSetChanged()
                }
            }

        })

        if (AppUtil.check_internet(this@StuffListActivity)) {
            val frameLayout: FrameLayout = findViewById(R.id.fl_adplaceholder)

            val adsCallBack= object : AdsClass.adsCallBack{
                override fun onAdLoaded() {}
            }

            AdsClass.refreshAd(
                this@StuffListActivity,
                resources.getString(R.string.ANATIVE_ID),
                frameLayout,
                adsCallBack
            )
        }
    }

    private fun onDeleteItemClicked(itemId: Int) {

        AppUtil.askAlertDialog(this,
            Const.DELETE_ALERT_TITLE, Const.DELETE_ALERT_MESSAGE, "Yes", "No",
            object : DialogCallback {
                override fun onClick() {
                    dbHelper!!.stuffDelete(itemId)
                    MyAsyncTask().execute()
                }
            },
            object : DialogCallback {
                override fun onClick() {
                }
            }

            /*
            DialogInterface.OnClickListener { dialog, which ->

                dbHelper!!.stuffDelete(itemId)
                dialog.dismiss()
            },
            DialogInterface.OnClickListener { dialog, which ->
                //stopActionMode()
                dialog.dismiss()
            }
            */
        )

    }

    private fun onDeleteOptionClicked() {
        val checkItems: ParcelableSparseBooleanArray = multiSelector!!.checkedItems
        AppUtil.askAlertDialog(this,
            Const.DELETE_ALERT_TITLE,
            Const.DELETE_ALERT_MESSAGE,
            "Yes",
            "No",
            object : DialogCallback {
                override fun onClick() {
                    val adapter: StuffAdapter = binding.recyclerview!!.getAdapter() as StuffAdapter
                    adapter.deleteItems(checkItems)

                    //stuffArray = dbHelper!!.getAllData(context)
                    MyAsyncTask().execute()

                    multiSelector!!.clearAll()
                    stopActionMode()
                }
            },
            object : DialogCallback {
                override fun onClick() {
                    stopActionMode()
                }
            }

            /*DialogInterface.OnClickListener { dialog, which ->
                val adapter: StuffAdapter = recyclerview!!.getAdapter() as StuffAdapter
                adapter.deleteItems(checkItems)

                stuffArray = dbHelper!!.getAllData(context)
                multiSelector!!.clearAll()
                stopActionMode()
                dialog.dismiss()
            },
            DialogInterface.OnClickListener { dialog, which ->
                stopActionMode()
                dialog.dismiss()
            }*/
        )

    }

    private fun updateActionModeTitle() {
        //actionMode.setTitle(String.valueOf(multiSelector.getCount()));
        binding.toolbarMain.selectTitle!!.setText(String.valueOf(multiSelector!!.count))
    }

    override fun onResume() {
        super.onResume()
        if(Const.isAdded) {
            Const.isAdded= false
            binding.progressBar.visibility=View.VISIBLE
            MyAsyncTask().execute()
        }
    }

    var sort = 0;
    var order = 0;
    private fun showSortDialog(context: Context) {

        //final Dialog dialog = new Dialog(context);
        val alertDialog = AlertDialog.Builder(context)
        val view = LayoutInflater.from(context).inflate(R.layout.lay_sort, null)

        alertDialog.setView(view)
        alertDialog.setCancelable(true)

        val dialog: Dialog = alertDialog.create()
        val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
        val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = view.findViewById<View>(R.id.btnNegative) as TextView

        txtTitle.text = "Sorting"
        val rvCategoryOption: RecyclerView = view.findViewById(R.id.rv_recycler_option)
        rvCategoryOption.setHasFixedSize(true)
        rvCategoryOption.layoutManager = LinearLayoutManager(
            context,
            LinearLayoutManager.VERTICAL,
            false
        )
        val sortAdapter = SortAdapter(
            arrayOf(
                "Alphabet",
                "Date",
                "Price"
            ), sort
        )
        rvCategoryOption.adapter = sortAdapter
        sortAdapter.setListSelectedListener(object : SortAdapter.SortListener {
            override fun onCategorySelected(position: Int) {
                sort = position

                sortAdapter.notifyDataSetChanged()
            }
        })
        val rvCategoryOrder: RecyclerView = view.findViewById(R.id.rv_recycler_order)

        rvCategoryOrder.setHasFixedSize(true)
        rvCategoryOrder.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        val orderAdapter = SortAdapter(
            arrayOf(
                "Ascending",
                "Descending"
            ), order
        )
        rvCategoryOrder.adapter = orderAdapter
        orderAdapter.setListSelectedListener(object : SortAdapter.SortListener {
            override fun onCategorySelected(position: Int) {
                order = position
                orderAdapter.notifyDataSetChanged()
            }
        })
        btnPositive.setOnClickListener {
            dialog.dismiss()
            myPreference!!.setInt(this@StuffListActivity,Const.KEY_SORT,sort)
            myPreference!!.setInt(this@StuffListActivity,Const.KEY_ORDR,order)
            sortAdapter(sort, order);

        }
        btnNegative.setOnClickListener {
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        //Dialog dialog=alertDialog.create();
        dialog.show()
    }

    fun sortAdapter(sort: Int, order: Int) {
        when (sort) {
            0 ->
                if (order == 0) Collections.sort<StuffGetSet>(
                    stuffArray,
                    StuffGetSet.atozComparator
                )
                else Collections.sort<StuffGetSet>(stuffArray, StuffGetSet.ztoaComparator)
            1 ->
                if (order == 0) Collections.sort<StuffGetSet>(
                    stuffArray,
                    StuffGetSet.new_oldComparator
                )
                else Collections.sort<StuffGetSet>(stuffArray, StuffGetSet.old_newComparator)
            2 ->
                if (order == 0) Collections.sort<StuffGetSet>(
                    stuffArray,
                    StuffGetSet.ltohComparator
                )
                else Collections.sort<StuffGetSet>(stuffArray, StuffGetSet.htolComparator)
        }
        stuffAdapter!!.notifyDataSetChanged()
        animate()
    }

    private fun animate() {
        val controller = AnimationUtils.loadLayoutAnimation(this, animationList[0])
        binding.recyclerview!!.setLayoutAnimation(controller)
        binding.recyclerview!!.scheduleLayoutAnimation()
    }

    private fun switchLayout() {
        if (gridLayoutManager!!.spanCount == 1) {
            layType = 2
            gridLayoutManager!!.spanCount = 2
            binding.toolbarMain.toolGrid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_list_view))
        } else {
            layType = 1
            gridLayoutManager!!.spanCount = 1
            binding.toolbarMain.toolGrid!!.setImageDrawable(resources.getDrawable(R.drawable.icon_grid_view))
        }
        myPreference!!.setInt(this, Const.KEY_LAYTYPE, layType)
        stuffAdapter!!.refreshData()

        animate()
    }
    private fun startActionMode() {
        binding.toolbarMain.laySelect!!.visibility = View.VISIBLE
        binding.toolbarMain.layAction!!.visibility = View.GONE
    }

    private fun stopActionMode() {
        binding.toolbarMain.selectTitle!!.setText("")
        multiSelector!!.clearAll()
        val adapter: StuffAdapter = binding.recyclerview!!.getAdapter() as StuffAdapter
        if (adapter != null) adapter.setNormalChoiceMode()
        binding.toolbarMain.laySelect!!.visibility = View.GONE
        binding.toolbarMain.layAction!!.visibility = View.VISIBLE
    }

    private fun hideKeyboard(view: View) {
        val inputManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (view != null) {
            inputManager.hideSoftInputFromWindow(view.getWindowToken(), 0)
        }

        var viewCur = currentFocus
        if (viewCur != null) {
            inputManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
        }
    }

    private fun setData(result: ArrayList<StuffGetSet>) {
        //if(!isAdded) return
        //stuffArray=dbHelper!!.getAllData(context)
        
        sort=myPreference!!.getInt(this@StuffListActivity,Const.KEY_SORT)
        order=myPreference!!.getInt(this@StuffListActivity,Const.KEY_ORDR)
        Log.e("StuffListActivity","setData:"+result.size)

        if(result.size>0) {
            binding.progressBar.visibility=View.GONE
            binding.emptyView!!.visibility=View.GONE
            binding.recyclerview!!.visibility=View.VISIBLE

            binding.toolbarMain.toolSort!!.visibility=View.VISIBLE
            binding.toolbarMain.toolGrid!!.visibility=View.VISIBLE
            binding.toolbarMain.toolSearch!!.visibility=View.VISIBLE

        } else {
            binding.progressBar.visibility=View.GONE
            binding.emptyView!!.visibility=View.VISIBLE
            binding.recyclerview!!.visibility=View.GONE

            binding.toolbarMain.toolSort!!.visibility=View.GONE
            binding.toolbarMain.toolGrid!!.visibility=View.GONE
            binding.toolbarMain.toolSearch!!.visibility=View.GONE
        }

        stuffArray = result

        mRecyclerViewItems = ArrayList()
        mRecyclerViewItems!!.clear()
        mRecyclerViewItems!!.addAll(stuffArray)

        gridLayoutManager = GridLayoutManager(this@StuffListActivity, layType)
        stuffAdapter = StuffAdapter(
            this@StuffListActivity,
            stuffArray,
            this@StuffListActivity,
            multiSelector,
            gridLayoutManager!!
        )
        binding.recyclerview.layoutManager = gridLayoutManager
        //val itemDecoration = ItemOffsetDecoration(this, R.dimen.item_offset)
        //recyclerview.addItemDecoration(itemDecoration)

        binding.progressBar.visibility=View.GONE
        binding.recyclerview.adapter = stuffAdapter
        //animate()
        sortAdapter(sort, order);
    }

    inner class MyAsyncTask : AsyncTask<Int?, Void?, ArrayList<StuffGetSet>>() {

        override fun doInBackground(vararg params: Int?): ArrayList<StuffGetSet> {
            //return dbHelper!!.getAllData(this@StuffListActivity)
            return dbHelper!!.getAllDataCat(this@StuffListActivity,catId)
        }

        override fun onPostExecute(result: ArrayList<StuffGetSet>) {
            super.onPostExecute(result)
            setData(result)
        }

    }

    override fun onAdapterClick(view: View, position: Int, stuffGetSet: StuffGetSet) {
        if (stuffAdapter!!.isMultipleChoiceMode) {
            multiSelector!!.checkView(view, position)
            updateActionModeTitle()
        } else {

            val intent = Intent(this@StuffListActivity, DetailActivity::class.java)
            intent.putExtra("stuff_id", stuffGetSet.stuff_id)
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(this@StuffListActivity, view, "ivGrid")
            //startActivityForResult(intent, 1, options.toBundle())
            startActivity(intent, options.toBundle())
        }
    }

    override fun onOptionClick(view: View, action: Int, itemId: Int) {
        if (action == 1) {
            onDeleteItemClicked(itemId)
        } else if (action == 2) {
            val intent = Intent(this@StuffListActivity, UpdateActivity::class.java)
            intent.putExtra("stuff_id", itemId)
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(this@StuffListActivity, view, "ivGrid")
            startActivity(intent, options.toBundle())
        }
    }

    override fun onAdapterLongClick(view: View, position: Int) {
        if (!stuffAdapter!!.isMultipleChoiceMode) {
            stuffAdapter!!.setMultipleChoiceMode()
            multiSelector!!.checkView(view, position)
            startActionMode()
            updateActionModeTitle()
        }
    }

}