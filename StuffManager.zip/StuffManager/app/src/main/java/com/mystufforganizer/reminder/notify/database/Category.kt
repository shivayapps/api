package com.mystufforganizer.reminder.notify.database

import java.util.*

class Category(var catId: Int, var category: String, var total: Int) {

    companion object {
        var atozComparator =
            Comparator<Category> { c1, c2 ->
                val category1 = c1.category.toUpperCase()
                val category2 = c2.category.toUpperCase()
                category1.compareTo(category2)
            }
        var ztoaComparator =
            Comparator<Category> { c1, c2 ->
                val category1 = c1.category.toUpperCase()
                val category2 = c2.category.toUpperCase()
                category2.compareTo(category1)
            }
        var _0to9Comparator =
            Comparator<Category> { c1, c2 ->
                val total1 = c1.total
                val total2 = c2.total
                total2 - total1
            }
        var _9to0Comparator =
            Comparator<Category> { c1, c2 ->
                val total1 = c1.total
                val total2 = c2.total
                total1 - total2
            }
    }

}