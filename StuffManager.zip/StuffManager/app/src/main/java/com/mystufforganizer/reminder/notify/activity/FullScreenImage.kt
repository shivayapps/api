package com.mystufforganizer.reminder.notify.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.databinding.ActivityFullScreenImageBinding
import com.mystufforganizer.reminder.notify.util.Const

class FullScreenImage : AppCompatActivity() {
    lateinit var binding: ActivityFullScreenImageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullScreenImageBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_full_screen_image)

        binding.toolBack.setOnClickListener {
            Const.sharedBitmap=null
            onBackPressed()
        }

        if(Const.sharedBitmap!=null) {
            binding.ivFullScreenIamge.setImageBitmap(Const.sharedBitmap)
        } else {
            binding.ivFullScreenIamge.setImageDrawable(resources.getDrawable(R.drawable.img_default))
        }

    }
}