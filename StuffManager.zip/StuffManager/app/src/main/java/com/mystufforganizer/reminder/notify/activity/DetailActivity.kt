package com.mystufforganizer.reminder.notify.activity

import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.transition.Explode
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.drawToBitmap
import com.mystufforganizer.reminder.notify.BuildConfig
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.callback.DialogCallback
import com.mystufforganizer.reminder.notify.database.SQLiteHelper
import com.mystufforganizer.reminder.notify.database.StuffGetSet
import com.mystufforganizer.reminder.notify.databinding.ActivityDetailBinding
import com.mystufforganizer.reminder.notify.util.AdsClass
import com.mystufforganizer.reminder.notify.util.AppUtil
import com.mystufforganizer.reminder.notify.util.Const
import com.mystufforganizer.reminder.notify.util.MyPreference
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*


class DetailActivity : AppCompatActivity() {

    var dbHelper: SQLiteHelper? = null
    var stuffGetSet : StuffGetSet?=null

    var stuffName: String = ""
    var purchasedate:String = ""
    var price:String = "0.0"
    var expiry_date:String = ""
    var description:String = ""
    var barcode:String = ""
    var exYr:Int=0
    var exMonth:Int=0
    var inrStr: String = ""
    var bitmap : Bitmap?= null
    var bitmapBill : Bitmap?= null
    private var myPreference: MyPreference? = null

    lateinit var binding: ActivityDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.exitTransition = Explode()
        }

        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@DetailActivity, R.color.colorWhite)
        }

        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_detail)

        dbHelper= SQLiteHelper(this@DetailActivity)
        dbHelper!!.open()

        myPreference = MyPreference(this@DetailActivity)
        inrStr=myPreference!!.getString(this@DetailActivity, Const.KEY_INR_STR,resources.getString(R.string.rs))

        val stuffId=intent.getIntExtra("stuff_id",0)

        stuffGetSet=dbHelper!!.getData(this@DetailActivity,""+stuffId)

        setData(stuffGetSet!!)

        binding.iconEdit.setOnClickListener {

            val intent = Intent(this@DetailActivity, UpdateActivity::class.java)
            intent.putExtra("stuff_id",stuffGetSet!!.stuff_id)
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(this@DetailActivity, binding.stuffImg,"ivGrid")
            //startActivityForResult(intent, 1, options.toBundle())
            startActivity(intent, options.toBundle())
        }

        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.iconShare.setOnClickListener {
            shareData(stuffGetSet!!)
        }
        binding.stuffImg.setOnClickListener {
            if(bitmap!=null) {
                Const.sharedBitmap=bitmap
                val intent = Intent(this@DetailActivity, FullScreenImage::class.java)
                val options = ActivityOptionsCompat.makeSceneTransitionAnimation(this@DetailActivity, binding.stuffImg,"ivGrid")
                startActivity(intent, options.toBundle())
            }
        }
        binding.iconAttachment.setOnClickListener {
            if(bitmapBill!=null) {
                Const.sharedBitmap=bitmapBill
                val intent = Intent(this@DetailActivity, FullScreenImage::class.java)
                val options = ActivityOptionsCompat.makeSceneTransitionAnimation(this@DetailActivity, binding.iconAttachment,"ivGrid")
                startActivity(intent, options.toBundle())
            }
        }
        binding.iconDelete.setOnClickListener {

            AppUtil.askAlertDialog(this@DetailActivity,
                Const.DELETE_ALERT_TITLE, Const.DELETE_ALERT_MESSAGE,"Yes","No",
                object : DialogCallback {
                    override fun onClick() {
                        dbHelper!!.stuffDelete(stuffId)
                        onBackPressed()
                    }
                },
                object : DialogCallback {
                    override fun onClick() {
                    }
                }
                /*DialogInterface.OnClickListener { dialog, which ->

                    dbHelper!!.stuffDelete(stuffId)
                    dialog.dismiss()
                },
                DialogInterface.OnClickListener { dialog, which ->
                    //stopActionMode()
                    dialog.dismiss()
                }*/
            )
        }
        if (AppUtil.check_internet(this@DetailActivity)) {
            val frameLayout: FrameLayout = findViewById(R.id.fl_adplaceholder)

            val adsCallBack= object : AdsClass.adsCallBack{
                override fun onAdLoaded() {}
            }

            AdsClass.refreshAd(
                this@DetailActivity,
                resources.getString(R.string.ANATIVE_ID),
                frameLayout,
                adsCallBack
            )
        }
    }

    private fun shareData(stuffGetSet : StuffGetSet) {

        var bitmap_main:Bitmap?=null

        if(bitmap!=null) {

            //lay_main.setDrawingCacheEnabled(true)
            //lay_main.buildDrawingCache()
            //bitmap_main = lay_main.getDrawingCache()
            bitmap_main = binding.layMain.drawToBitmap(Bitmap.Config.ARGB_8888)

            /*
            bitmap_main = Bitmap.createBitmap(
                lay_main.getWidth(),
                lay_main.getHeight(),
                Bitmap.Config.ARGB_8888
            )
            */

        } else {
            //lay_detail.setDrawingCacheEnabled(true)
            //lay_detail.buildDrawingCache()
            //bitmap_main = lay_detail.getDrawingCache()
            bitmap_main = binding.layDetail.drawToBitmap(Bitmap.Config.ARGB_8888)

            /*
            bitmap_main = Bitmap.createBitmap(
                lay_detail.getWidth(),
                lay_detail.getHeight(),
                Bitmap.Config.ARGB_8888
            )
            */

        }

        val bytes = ByteArrayOutputStream()
        bitmap_main.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val f1 = File(AppUtil.mainDir)
        if (f1.mkdir()) {}
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val file = File(AppUtil.mainDir+ "/IMG_" + timeStamp + ".jpg")
        try {
            file.createNewFile()
            val fo = FileOutputStream(file)
            fo.write(bytes.toByteArray())
        } catch (e: IOException) {
            e.printStackTrace()
        }

        //val bitmapPath = Images.Media.insertImage(contentResolver, bitmap_main, "title", null)
        var shareBody= stuffGetSet.stuff_name

        /*
        if(stuffGetSet.stuff_price>0) shareBody+"\nPrice :"+stuffGetSet.stuff_price
        if(!stuffGetSet.stuff_purchase_date.isEmpty()) shareBody+"\nPurchase Date :"+stuffGetSet.stuff_purchase_date
        if(stuffGetSet.stuff_warranty_year>0) shareBody+"\nWarrenty :"+stuffGetSet.stuff_warranty_year+" Year"
        if(stuffGetSet.stuff_warranty_month>0) shareBody+stuffGetSet.stuff_warranty_month+" Month"
        if(!stuffGetSet.stuff_detail.isEmpty()) shareBody+"\nDetail :"+stuffGetSet.stuff_detail
        if(!stuffGetSet.stuff_barcode.isEmpty()) shareBody+"\nSerial :"+stuffGetSet.stuff_barcode
        */

        val GP_DETAIL_PREFIX = "https://play.google.com/store/apps/details?id="
        val shareText: String = resources.getString(R.string.share_desc)
        val share = Intent(Intent.ACTION_SEND)
        share.type = "image/jpeg"
        val bitmapUri=FileProvider.getUriForFile(this@DetailActivity, BuildConfig.APPLICATION_ID + ".provider", file)
        share.putExtra(Intent.EXTRA_STREAM, bitmapUri)
        share.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
        //share.putExtra(Intent.EXTRA_TEXT, shareBody)
        share.putExtra(Intent.EXTRA_TEXT, String.format(Locale.getDefault(), shareText, GP_DETAIL_PREFIX, BuildConfig.APPLICATION_ID));
        startActivity(Intent.createChooser(share, "Share Stuff"))

    }

    private fun setData(stuffGetSet : StuffGetSet) {
        stuffName=stuffGetSet.stuff_name
        purchasedate=stuffGetSet.stuff_purchase_date
        price=stuffGetSet.stuff_price
        expiry_date=stuffGetSet.stuff_expiry_date
        description=stuffGetSet.stuff_detail
        barcode=stuffGetSet.stuff_barcode
        exYr=stuffGetSet.stuff_warranty_year
        exMonth=stuffGetSet.stuff_warranty_month

        bitmap= AppUtil.StringToBitMap(stuffGetSet.stuff_image)
        if(bitmap!=null) {
            binding.stuffImg.setImageBitmap(bitmap!!)
            binding.noImg.visibility=View.GONE
        } else {
            binding.noImg.visibility=View.VISIBLE
        }
        bitmapBill= AppUtil.StringToBitMap(stuffGetSet.stuff_bill)
        if(bitmapBill!=null) {
            binding.iconAttachment.setImageBitmap(bitmapBill!!)
            binding.layAttachBill.visibility=View.VISIBLE
        } else {
            binding.layAttachBill.visibility=View.GONE
        }

        binding.txtName.text=stuffName
        binding.txtPrice.text=inrStr+" "+price
        binding.txtDate.text=purchasedate
        if(!description.isEmpty()|| !description.equals("",true)) binding.txtDetail.text=description

        if(!barcode.isEmpty()) binding.txtSerial.text=barcode

        var expStr:String=""
        if(exYr>0) expStr=expStr+" "+exYr+"Y"
        if(exMonth>0) expStr=expStr+" "+exMonth+"M"
        if(expStr.isEmpty()) expStr="--"
        binding.txtWar.text=expStr.trim()

        if(stuffGetSet.stuff_service_reminder>=0) {
            val remind=stuffGetSet.stuff_service_reminder

            val dateFormat = SimpleDateFormat("dd-MM-yyyy",Locale.getDefault())

            val expiry_date = dateFormat.parse(stuffGetSet.stuff_purchase_date)!!

            var sReminder="--"

            if(remind==0) {
                sReminder=monthlyReminder(expiry_date)
            }
            if(remind==1) {
                sReminder=quarterReminder(expiry_date)
            }
            if(remind==2) {
                sReminder=halfYearReminder(expiry_date)
            }
            if(remind==3) {
                sReminder=yearlyReminder(expiry_date)
            }
            binding.txtNextSevice.text=sReminder
            binding.layNextSevice.visibility=View.VISIBLE
        } else binding.layNextSevice.visibility=View.GONE

    }

    val dateFormat = SimpleDateFormat("dd-MM-yyyy",Locale.getDefault())

    public fun monthlyReminder(date:Date):String {
        Log.e("StuffAdapter :" ,"monthlyReminder")
        //var nextDate:Date=date
        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.MONTH,1)
        }

        //nextDate=calNow.time

        var remain = getDifferenceStr(calNow.time,cal.time)
        var nextDate = dateFormat.format(cal.time)
        if(!remain.isEmpty()) remain=nextDate+"\n "+remain+" Remainig"
        else remain=nextDate
        return remain
    }
    public fun halfYearReminder(date:Date):String {
        Log.e("StuffAdapter :" ,"halfYearReminder")

        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.MONTH,6)
        }

        //getDifferenceStr(nextDate,cal.time)

        var remain = getDifferenceStr(calNow.time,cal.time)
        var nextDate = dateFormat.format(cal.time)
        if(!remain.isEmpty()) remain=nextDate+"\n "+remain+" Remainig"
        else remain=nextDate
        return remain
        //return cal.time
    }
    public fun quarterReminder(date:Date):String {
        Log.e("StuffAdapter :" ,"quarterReminder")

        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.MONTH,3)
        }

        //getDifferenceStr(nextDate,cal.time)

        var remain = getDifferenceStr(calNow.time,cal.time)
        var nextDate = dateFormat.format(cal.time)
        if(!remain.isEmpty()) remain=nextDate+"\n "+remain+" Remainig"
        else remain=nextDate
        return remain
    }
    public fun yearlyReminder(date:Date):String {
        Log.e("StuffAdapter :" ,"yearlyReminder")
        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.YEAR,1)
        }

        //getDifferenceStr(nextDate,cal.time)

        var remain = getDifferenceStr(calNow.time,cal.time)
        var nextDate = dateFormat.format(cal.time)
        if(!remain.isEmpty()) remain=nextDate+"\n "+remain+" Remainig"
        else remain=nextDate
        return remain
    }

    private fun getDifferenceStr(startDate: Date, endDate: Date): String {
        var sAge = ""
        val e = Calendar.getInstance()
        e.time=endDate
        var eYear = e[Calendar.YEAR]
        var eMonth = e[Calendar.MONTH] + 1
        var eDay = e[Calendar.DAY_OF_MONTH]

        //val sDate: List<String> = stuffArrayList[position].stuff_purchase_date.split("-")

        val s = Calendar.getInstance()
        s.time=startDate
        /*
        var sDay = sDate[0]
        var sMonth = sDate[1]
        var sYear = sDate[2]
        */

        val sYear = s[Calendar.YEAR]
        val sMonth = s[Calendar.MONTH] + 1
        val sDay = s[Calendar.DAY_OF_MONTH]

        //if (sDay.isEmpty() || sDay.equals("null", ignoreCase = true)) sDay = "0"
        //if (sMonth.isEmpty() || sMonth.equals("null", ignoreCase = true)) sMonth = "0"
        ///if (sYear.isEmpty() || sYear.equals("null", ignoreCase = true)) sYear = "0"

        var sYYYY = try {
            sYear.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sYear)
        }

        var sMM = 0
        sMM = try {
            sMonth.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sMonth)
        }

        var sDD = 0
        sDD = try {
            sDay.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sDay)
        }

        val fDD: Int
        val fMM: Int
        var fYY: Int

        if (eDay < sDD) {
            eMonth = eMonth - 1
            eDay = eDay + 30
            fDD = eDay - sDD
        } else {
            fDD = eDay - sDD
        }

        if (eMonth < sMM) {
            eYear = eYear - 1
            eMonth = eMonth + 12
            fMM = eMonth - sMM
        } else {
            fMM = eMonth - sMM
        }

        fYY = eYear - sYYYY

        if (fYY != 0) {
            sAge += if (fYY != 1) " - " + fYY + "Y" else " - " + fYY + "Y"
        }

        if (fMM != 0) {
            sAge += if (fMM != 1) " - " + fMM + "M" else " - " + fMM + "M"
        }

        sAge += if (fDD != 0) {
            if (fDD != 1) " - " + fDD + "D" else " - " + fDD + "D"
        } else {
            " - 0D"
        }

        Log.e("StuffAdapter","getDifferenceStr : sAge:"+trim(sAge.trim { it <= ' ' }, "-").trim())
        return trim(sAge.trim { it <= ' ' }, "-").trim()
    }

    private fun trim(str: String, chr: String): String {
        var str = str
        if (str.startsWith(chr)) {
            str = str.substring(1, str.length)
        }
        if (str.endsWith(chr)) {
            str = str.substring(0, str.length - 1)
        }
        return str
    }

}