package com.mystufforganizer.reminder.notify.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mystufforganizer.reminder.notify.adapter.SingleCategoryAdapter.CategoryViewHolder
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.database.Category
import java.util.ArrayList

class SingleCategoryAdapter(
    private val context: Context,
    private var categoryArray: ArrayList<Category> = ArrayList<Category>(),
    catId: Int) :
    RecyclerView.Adapter<CategoryViewHolder>() {
    private var listSelectedListener: SortListener? = null
    private var catId = 0

    interface SortListener {
        fun onCategorySelected(catId: Int,category: String)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        //Create a new view
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_single, null)
        return CategoryViewHolder(view)
    }

    fun setListSelectedListener(listSelectedListener: SortListener?) {
        this.listSelectedListener = listSelectedListener
    }

    class CategoryViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        //val btnOpt: RadioButton
        var mValueTv: TextView
        var root_layout: LinearLayout

        init {
            root_layout = itemView.findViewById(R.id.rowView)
            mValueTv = itemView.findViewById(R.id.value_tv)
        }
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, @SuppressLint("RecyclerView") position: Int) {
        var category = categoryArray.get(position)
        holder.mValueTv.text = category.category

        holder.mValueTv.setOnClickListener {
            catId = category.catId
            listSelectedListener!!.onCategorySelected(category.catId,category.category)
        }

        holder.root_layout.setOnClickListener {
            catId = category.catId
            listSelectedListener!!.onCategorySelected(category.catId,category.category)
        }

        if (category.catId == catId) {
            holder.mValueTv.setTextColor(context.resources.getColor(R.color.orange_900))
        } else {
            holder.mValueTv.setTextColor(context.resources.getColor(R.color.colorBlack))
        }

    }

    override fun getItemCount(): Int {
        return categoryArray.size
    }

    init {
        this.catId = catId
    }
}