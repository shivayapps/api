package com.mystufforganizer.reminder.notify.callback

interface SingleItemCallback {
    fun onClickPosition(position: Int)
}