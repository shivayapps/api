package com.mystufforganizer.reminder.notify.adapter

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
//import com.amulyakhare.textdrawable.TextDrawable
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.callback.CategoryCallback
import com.mystufforganizer.reminder.notify.callback.DialogCallback
import com.mystufforganizer.reminder.notify.database.Category
import com.mystufforganizer.reminder.notify.database.SQLiteHelper
import com.mystufforganizer.reminder.notify.util.AppUtil
import com.mystufforganizer.reminder.notify.util.Const
import com.mystufforganizer.reminder.notify.util.MyPreference
import java.util.*


class CategoryAdapter(
    var context: Activity,
    var categoryArrayList: ArrayList<Category>,
    var adpCallback: CategoryCallback,
    var multiSelector: MultiSelector? = null,
    var mLayoutManager: GridLayoutManager
) : RecyclerView.Adapter<CategoryAdapter.categoryViewHolder>(),Filterable {

    private var categoryArrayListFiltered: ArrayList<Category> = ArrayList<Category>()
    var isMultipleChoiceMode = false
    var dbHelper: SQLiteHelper
    var inflater: LayoutInflater
    private var myPreference: MyPreference? = null
    private var laytype = 1
    var androidColors: IntArray?=null

    init {
        myPreference= MyPreference(context)
        categoryArrayListFiltered=categoryArrayList
        laytype=mLayoutManager.spanCount

        dbHelper = SQLiteHelper(context)
        dbHelper.open()
        androidColors = context.resources.getIntArray(R.array.colorArray)
        inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    }

    private fun trim(str: String, chr: String): String {
        var str = str
        if (str.startsWith(chr)) {
            str = str.substring(1, str.length)
        }
        if (str.endsWith(chr)) {
            str = str.substring(0, str.length - 1)
        }
        return str
    }

    fun deleteItems(checkItems: ParcelableSparseBooleanArray) {
        for (x in categoryArrayList.indices.reversed()) {
            if (checkItems[x, false]) {
                dbHelper.catDelete(categoryArrayList.get(x).catId)
                categoryArrayList.removeAt(x)
            }
        }
        notifyDataSetChanged()
    }

    fun setNormalChoiceMode() {
        isMultipleChoiceMode = false
        notifyDataSetChanged()
    }

    fun setMultipleChoiceMode() {
        isMultipleChoiceMode = true
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        val spanCount = mLayoutManager.spanCount
        laytype=spanCount
        return spanCount
        /*
        return if (spanCount == 1) {
            0
        } else {
            1
        }
        */
    }

    fun refreshData() {
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): categoryViewHolder {
        val view: View
        laytype =viewType
        view = if (viewType == 1) {
            LayoutInflater.from(parent.context).inflate(R.layout.category_listview_layout, parent, false)
        } else {
            LayoutInflater.from(parent.context).inflate(R.layout.category_gridview_layout, parent, false)
        }
        Log.d("MDD__", "call2")
        return categoryViewHolder(view, viewType)
    }

    override fun onBindViewHolder(holder: categoryViewHolder, position: Int) {
        val category = categoryArrayList[position]

        if(position==categoryArrayList.size-1) {
            holder.viewA.visibility=View.VISIBLE
            holder.viewA.setBackgroundColor(context.resources.getColor(R.color.colorWhite))
        }
        else {
            holder.viewA.visibility=View.GONE
        }

        holder.categoryName.text=category.category
        holder.categoryTotal.text="Total : "+category.total

        val catName: String = category.category
        if (!catName.isEmpty()) {
            val mSym: String
            mSym =
                if (catName.contains(" ")) {
                val split: Array<String> = catName.split("\\s+".toRegex()).toTypedArray()
                if (split.size >= 2) {
                    val char1 = split[0]
                    val char2 = split[1]
                    char1[0].toString() + "" + char2[0]
                    //char1[0].toString()
                } else {
                    catName.substring(0, 2).toString()
                    //catName.substring(0, 1).toString()
                }
            } else {
                if (catName.length >= 2){
                    catName.substring(0, 2)
                    //catName.substring(0, 1)
                }
                else{
                    catName.get(0).toString()
                }
            }

            val randomAndroidColor = androidColors!![Random().nextInt(androidColors!!.size)]
            /*
            val drawable = TextDrawable.builder()
                .beginConfig()
                .width(AppUtil.dpToPx(context,32))
                .height(AppUtil.dpToPx(context,32))
                .textColor(randomAndroidColor)
                .fontSize(AppUtil.dpToPx(context,18))
                .bold()
                .toUpperCase()
                .endConfig()
                .buildRect(mSym,Color.WHITE)
                */

            Log.e("CategoryAdapter","categoryName:"+mSym)
            //holder.ivGrid.setImageDrawable(drawable)
            holder.ivGrid.setText(mSym.toUpperCase())
            holder.ivGrid.setTextColor(randomAndroidColor)

        }

        holder.rootView.setOnClickListener {
            if(isMultipleChoiceMode) {
                if(adpCallback!= null) {
                    adpCallback.onAdapterClick(holder.rootView,holder.adapterPosition,category)
                }
                holder.checkBox.isChecked = !holder.checkBox.isChecked
            } else {
                adpCallback.onAdapterClick(holder.ivGrid,holder.adapterPosition,category)
            }
        }

        holder.rootView.isLongClickable=true
        holder.rootView.setOnLongClickListener{
            if(adpCallback!= null)
                adpCallback.onAdapterLongClick(holder.rootView,holder.adapterPosition)

            true
        }


        if (isMultipleChoiceMode) {
            holder.checkBox.setVisibility(View.VISIBLE)
            holder.checkBox.setChecked(multiSelector!!.isChecked(position))
        }
        else holder.checkBox.setVisibility(View.GONE)

        if(laytype==1) {
            setMargins(holder.itemView,0,2,0,0)
        }
        else {
            if(position%2==0)
                setMargins(holder.itemView,0,5,5,0)
            else
                setMargins(holder.itemView,5,5,0,0)
        }

        holder.ivOption.setOnClickListener {
            val popupMenu = PopupMenu(context, holder.ivOption)
            popupMenu.inflate(R.menu.option_menu)
            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.edit -> {
                        adpCallback.onOptionClick(holder.ivGrid,2,category)
                    }
                    R.id.delete -> {
                        if(category.total!=0) {
                            AppUtil.askAlertDialog(context,
                                Const.DELETE_ALERT_TITLE, Const.ALERT_EMPTY_CATEGORY, "OK", null,
                                object : DialogCallback {
                                    override fun onClick() {
                                    }
                                },
                                object : DialogCallback {
                                    override fun onClick() {
                                    }
                                }
                            )
                        } else {
                            adpCallback.onOptionClick(holder.ivGrid,1,category)
                        }
                    }
                }
                false
            }
            popupMenu.show()
        }

    }

    //private var lastPosition = -1
    /*
    fun setFadeAnimation(view: View) {
        val anim = AlphaAnimation(0.0f, 1.0f)
        anim.setDuration(500)
        view.startAnimation(anim)
    }
    */
    /*
    private fun setAnimation(viewToAnimate: View, position: Int) {
        if (position > lastPosition) {
            val animation: Animation = AnimationUtils.loadAnimation(context, android.R.anim.fade_in)
            animation.duration=1000
            viewToAnimate.startAnimation(animation)
            lastPosition = position
        }
    }
    */

    private fun setMargins(view: View, left: Int, top: Int, right: Int, bottom: Int) {

        if (view.layoutParams is ViewGroup.MarginLayoutParams) {
            val p = view.layoutParams as ViewGroup.MarginLayoutParams
            val scale = context.resources.displayMetrics.density
            // convert the DP into pixel
            val l = (left * scale + 0.5f).toInt()
            val r = (right * scale + 0.5f).toInt()
            val t = (top * scale + 0.5f).toInt()
            val b = (bottom * scale + 0.5f).toInt()
            p.setMargins(l, t, r, b)
            view.requestLayout()
        }
    }

    override fun getItemCount(): Int {
        return categoryArrayList.size
    }

    inner class categoryViewHolder(itemView: View, viewType: Int) : RecyclerView.ViewHolder(itemView) {
        var ivGrid: TextView
        var ivOption: ImageView
        var categoryName: TextView
        var categoryTotal: TextView
        var checkBox: CheckBox
        var rootView: View
        var viewA: LinearLayout

        init {
            rootView = itemView.findViewById(R.id.root_layout)
            ivGrid = itemView.findViewById(R.id.ivGrid)
            categoryName = itemView.findViewById(R.id.categoryName)
            categoryTotal = itemView.findViewById(R.id.categoryTotal)
            ivOption = itemView.findViewById(R.id.option_iv)
            checkBox = itemView.findViewById(R.id.isSelected_cb)
            viewA = itemView.findViewById(R.id.viewA)
        }
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val charString = charSequence.toString()
                var filteredList: ArrayList<Category> = ArrayList<Category>()
                if (charString.length == 0 || charString.isEmpty()) {
                    categoryArrayList = categoryArrayListFiltered
                    filteredList = categoryArrayList
                } else {
                    for (row in categoryArrayList) {
                        if (row.category.toLowerCase().contains(charString.toLowerCase()) ||row.category.toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row)
                        }
                    }
                    categoryArrayList = filteredList
                }
                val filterResults = FilterResults()
                filterResults.values = filteredList
                return filterResults
            }

            override fun publishResults(charSequence: CharSequence, filterResults: FilterResults) {
                if (charSequence.length == 0 || charSequence.toString().isEmpty()) {
                    categoryArrayList = categoryArrayListFiltered
                } else {
                    categoryArrayList = filterResults.values as ArrayList<Category>
                }
                notifyDataSetChanged()
            }
        }
    }


}