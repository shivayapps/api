package com.mystufforganizer.reminder.notify.activity

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.text.Layout
import android.text.style.AlignmentSpan
import android.text.style.StyleSpan
import android.util.Log
import android.view.*
import android.view.animation.Animation
import android.view.animation.Transformation
import android.webkit.MimeTypeMap
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import com.ammarptn.gdriverest.DriveServiceHelper
import com.ammarptn.gdriverest.DriveServiceHelper.getGoogleDriveService
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.drive.Drive
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.material.snackbar.Snackbar
import com.google.api.client.http.InputStreamContent
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.callback.DialogCallback
import com.mystufforganizer.reminder.notify.database.SQLiteHandler
import com.mystufforganizer.reminder.notify.databinding.ActivityBackupBinding
import com.mystufforganizer.reminder.notify.databinding.ActivitySplashBinding
import com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.DriveItemConverter
import com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.DriveItemListAdapter
import com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.FolderListDiffUtil
import com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.dataClass.DriveHolder
import com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.viewObject.DriveItem
import com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.viewObject.RecycleViewBaseItem
import com.mystufforganizer.reminder.notify.util.AdsClass
import com.mystufforganizer.reminder.notify.util.AppUtil
import com.mystufforganizer.reminder.notify.util.Const
import java.io.*
import java.nio.channels.FileChannel
import java.text.DecimalFormat

class BackupActivity : AppCompatActivity(){

    private val REQUEST_CODE_SIGN_IN = 109
    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var mDriveServiceHelper: DriveServiceHelper
    private lateinit var adapter: DriveItemListAdapter

    private var drivePathHolder: ArrayList<DriveHolder?> = ArrayList()
    var recycleItemArrayList = ArrayList<RecycleViewBaseItem>()

    lateinit var binding: ActivityBackupBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@BackupActivity, R.color.colorWhite)
        }
        binding = ActivityBackupBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_backup)

        drivePathHolder.add(DriveHolder(null, "Root"))

        binding.folderList.hasFixedSize()
        binding.folderList.layoutManager = GridLayoutManager(this@BackupActivity, 1)

        adapter = DriveItemListAdapter(recycleItemArrayList, object :
            DriveItemListAdapter.addClickListener {
            override fun onFileLongClick(position: Int) {
                Log.e("BackupActivity", "onFileLongClick:"+position )
                val driveItem = recycleItemArrayList[position] as DriveItem
                restoreDialog(driveItem)
                Log.e("BackupActivity", "onFileLongClick:"+drivePathHolder.getPath())
            }

            override fun onFolderLongClick(position: Int) {
                val driveItem = recycleItemArrayList[position] as DriveItem
                restoreDialog(driveItem)
            }

            override fun onBackClick(position: Int) {
                Log.e("BackupActivity", "back to " + drivePathHolder[drivePathHolder.size - 2]?.driveId)
                queryDrive(drivePathHolder[drivePathHolder.size - 2]?.driveId)

                drivePathHolder.removeAt(drivePathHolder.size - 1)

                updateTitle()
            }

            override fun onFolderClick(position: Int) {
                /*
                Log.e("BackupActivity", "select to " + (recycleItemArrayList[position] as DriveItem).driveId)
                queryDrive((recycleItemArrayList[position] as DriveItem).driveId)
                drivePathHolder.add(DriveHolder((recycleItemArrayList[position] as DriveItem).driveId, (recycleItemArrayList[position] as DriveItem).title))
                updateTitle()
                */

                Log.e("BackupActivity", "onFolderClick:"+position )
                val driveItem = recycleItemArrayList[position] as DriveItem
                restoreDialog(driveItem)
                Log.e("BackupActivity", "onFolderClick:"+drivePathHolder.getPath())

            }

            override fun onFileClick(position: Int) {
                Log.e("BackupActivity", "onFileClick:"+position )
                val driveItem = recycleItemArrayList[position] as DriveItem
                restoreDialog(driveItem)
                Log.e("BackupActivity", "onFileClick:"+drivePathHolder.getPath())
            }
        })

        binding.folderList.adapter = adapter

        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.btnBackup.setOnClickListener {

            if(checkPermission()){
                uploadBackup()
            } else {
                requestPermission(101)
            }
        }
        binding.icOut.setOnClickListener {
            signOut()
        }

        binding.layIconDown.setOnClickListener {
            if(binding.folderList.visibility==View.GONE) {
                expand(binding.folderList)
                binding.layIconDown.rotation=-90f
            } else {
                collapse(binding.folderList)
                binding.layIconDown.rotation=90f

            }
        }

        if (AppUtil.check_internet(this@BackupActivity)) {
            val frameLayout: FrameLayout = findViewById(R.id.fl_adplaceholder)

            val adsCallBack= object : AdsClass.adsCallBack{
                override fun onAdLoaded() {}
            }

            AdsClass.refreshAd(
                this@BackupActivity,
                resources.getString(R.string.ANATIVE_ID),
                frameLayout,
                adsCallBack
            )
        }
    }

    fun expand(v: View) {
        v.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val targtetHeight = v.measuredHeight
        v.layoutParams.height = 0
        v.visibility = View.VISIBLE
        val a: Animation = object : Animation() {
            override fun applyTransformation(interpolatedTime: Float, t: Transformation?) {
                v.layoutParams.height = if (interpolatedTime == 1f) ViewGroup.LayoutParams.WRAP_CONTENT else (targtetHeight * interpolatedTime).toInt()
                v.requestLayout()
            }

            override fun willChangeBounds(): Boolean {
                return true
            }
        }
        a.setDuration((targtetHeight / v.context.resources.displayMetrics.density).toLong())
        v.startAnimation(a)
    }

    fun collapse(v: View) {
        val initialHeight = v.measuredHeight
        val a: Animation = object : Animation() {
            override fun applyTransformation(interpolatedTime: Float, t: Transformation?) {
                if (interpolatedTime == 1f) {
                    v.visibility = View.GONE
                } else {
                    v.layoutParams.height = initialHeight - (initialHeight * interpolatedTime).toInt()
                    v.requestLayout()
                }
            }

            override fun willChangeBounds(): Boolean {
                return true
            }
        }
        a.setDuration((initialHeight / v.context.resources.displayMetrics.density).toLong())
        v.startAnimation(a)
    }

    var driveId: String = "null"
    fun restoreDialog(driveItem:DriveItem) {

        val inflate: View = View.inflate(this, R.layout.lay_drive_detail, null)

        val alertDialog = AlertDialog.Builder(this).setView(inflate).setCancelable(true)

        val imgIcon = inflate.findViewById<View>(R.id.icon) as ImageView

        val txtTitle = inflate.findViewById<View>(R.id.title) as TextView
        val txtLocation = inflate.findViewById<View>(R.id.location) as TextView
        val txtSize = inflate.findViewById<View>(R.id.size) as TextView
        val txtLast_update = inflate.findViewById<View>(R.id.last_update) as TextView

        val btnDownload = inflate.findViewById<View>(R.id.btnDownload) as TextView
        val btnDelete = inflate.findViewById<View>(R.id.btnDelete) as TextView

        txtTitle.text=""+driveItem.title
        txtLocation.text="Drive Path : "+driveItem.driveId
        txtSize.text="Size : "+driveItem.fileSize!!.toLong().bytesToMeg()
        txtLast_update.text="Date : "+driveItem.lastUpdate

        val dialog: AlertDialog = alertDialog.create()
        dialog.setCanceledOnTouchOutside(true)

        btnDownload.setOnClickListener {
            driveId=driveItem.driveId!!
            if(checkPermission()){
                onDownload(driveId)
            } else {
                requestPermission(106)
            }
            dialog.dismiss()
        }
        btnDelete.setOnClickListener {

            driveId=driveItem.driveId!!
            if(checkPermission()){
                onDelete(driveId)
            } else {
                requestPermission(103)
            }
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        //dialog.window!!.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        /*
        dialog.setOnShowListener {
            //val custom_font_medium = Typeface.createFromAsset(assets, "sarabun_medium.ttf")
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(resources.getColor(R.color.colorBlack))
            dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(resources.getColor(R.color.color_858585))
            //mAlertDialog1.getButton(DialogInterface.BUTTON_POSITIVE).setTypeface(custom_font_medium)
            //mAlertDialog1.getButton(DialogInterface.BUTTON_NEGATIVE).setTypeface(custom_font_medium)
        }
        */
        dialog.show()
    }

    fun checkPermission(): Boolean {
        var allow = true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            allow = false
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            allow = false
        }
        return allow
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.size > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                if(requestCode==106) {
                    onDownload(driveId)
                }else if(requestCode==103) {
                    onDelete(driveId)
                }else if(requestCode==101) {
                    uploadBackup()
                }
            }
        }
    }

    fun requestPermission(reqcode: Int) {
        val listPermissionsNeeded: MutableList<String> = java.util.ArrayList()
        listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(listPermissionsNeeded.toTypedArray(), reqcode)
        }
    }

    fun uploadBackup () {

        if(AppUtil.check_internet(this@BackupActivity)) {

            binding.progressBar.visibility = View.VISIBLE

            val dbFile = AppUtil.BackupDatabase(this@BackupActivity)
            //var dbFileName = "database"

            val root: List<String>
            if (drivePathHolder.last()?.driveId == null) {
                root = listOf("root")
            } else {
                root = listOf(drivePathHolder.last()?.driveId!!)
            }

            val uri= Uri.fromFile(File(dbFile))

            /*
            val cursor = contentResolver.query(uri!!, null, null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                dbFileName = cursor.getString(nameIndex);
            }
            */

            val extensionFromMimeType = MimeTypeMap.getSingleton().getExtensionFromMimeType(contentResolver.getType(uri))
            val metadata = com.google.api.services.drive.model.File()
                .setParents(root)
                .setMimeType(extensionFromMimeType)
                //.setName("dbFileName")
                .setName("MystuffReminder")
            Log.e("BackupActivity", "002_onActivityResult:extensionFromMimeType:"+extensionFromMimeType)
            Log.e("BackupActivity", "002_onActivityResult:name:"+dbFile)

            val inputStreamContent = InputStreamContent(null, contentResolver.openInputStream(uri))

            mDriveServiceHelper.uploadFile(metadata, inputStreamContent)
                .addOnSuccessListener {
                    binding.progressBar.visibility = View.GONE
                    if (drivePathHolder.last()?.driveId != null) {
                        queryDrive(drivePathHolder.last()?.driveId)
                    } else {
                        queryDrive(null)
                    }

                    Snackbar.make(binding.rootLayout, "Data Uploaded Successfully.", Snackbar.LENGTH_LONG).show()
                    //Toast.makeText(this@BackupActivity,"Data Uploaded Successfully.",Toast.LENGTH_LONG).show()
                }

        } else {
            Snackbar.make(binding.rootLayout, "Internet Connection Required.", Snackbar.LENGTH_LONG).show()
        }
    }

    fun ArrayList<DriveHolder?>.getPath(): String {
        val stringBuilder = java.lang.StringBuilder()
        stringBuilder.append("Path:")
        var listItem = this

        for (i in listItem.indices) {
            stringBuilder.append(listItem[i]?.driveTitle)
            if (i != (listItem.size)) {
                stringBuilder.append("/")
            }

        }
        return stringBuilder.toString()
    }
    val MEGABYTE = (1024L * 1024L).toDouble()
    fun Long.bytesToMeg(): String {
        return DecimalFormat("##.##").format(this / MEGABYTE) + "MB"
    }

    override fun onStart() {
        super.onStart()
        val account = GoogleSignIn.getLastSignedInAccount(this@BackupActivity)
        if (account == null) {
            signIn()
        } else {
            binding.txtUserEmail.setText(account.email)
            Log.e("BackupActivity", "txtUserEmail::"+account.email )
            mDriveServiceHelper = DriveServiceHelper(
                getGoogleDriveService(
                    this@BackupActivity,
                    account,
                    "Stuff Organizer"
                )
            )
            queryDrive(drivePathHolder.last()?.driveId)
        }
        updateTitle()
    }

    private fun updateTitle() {
        var drivePath = StringBuilder()
        for (name in drivePathHolder) {
            drivePath.append(name?.driveTitle).append("/")
        }

    }

    private fun signOut() {
        mGoogleSignInClient = buildGoogleSignInClient()
        mGoogleSignInClient.signOut()
        onBackPressed()
    }

    private fun signIn() {
        mGoogleSignInClient = buildGoogleSignInClient()
        startActivityForResult(mGoogleSignInClient.getSignInIntent(), REQUEST_CODE_SIGN_IN)
    }

    private fun buildGoogleSignInClient(): GoogleSignInClient {
        //val webclientId: String = getString(R.string.default_web_client_id)
        val signInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            //.requestIdToken(webclientId)
            .requestScopes(Drive.SCOPE_FILE)
            //.requestScopes(Scope(DriveScopes.DRIVE_FILE))
            //.requestScopes(Scope(DriveScopes.DRIVE_APPDATA))
            .requestEmail()
            .build()

        return GoogleSignIn.getClient(this@BackupActivity, signInOptions)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.e("BackupActivity", "onActivityResult:resultCode:"+resultCode )
        Log.e("BackupActivity", "onActivityResult:requestCode:"+requestCode )

        when (requestCode) {
            REQUEST_CODE_SIGN_IN ->
                if (resultCode == Activity.RESULT_OK && data != null) {
                handleSignInResult(data)
            }
        }
    }

    private fun handleSignInResult(result: Intent) {

        GoogleSignIn.getSignedInAccountFromIntent(result)
            .addOnSuccessListener(object : OnSuccessListener<GoogleSignInAccount> {
                override fun onSuccess(googleSignInAccount: GoogleSignInAccount) {
                    binding.txtUserEmail.setText(googleSignInAccount.email)
                    Log.e("BackupActivity", "Signed in as " + googleSignInAccount.email)
                    mDriveServiceHelper = DriveServiceHelper(
                        getGoogleDriveService(
                            this@BackupActivity,
                            googleSignInAccount,
                            "Stuff Organizer"
                        )
                    )
                    queryDrive(drivePathHolder.last()?.driveId)
                    Log.e("BackupActivity", "handleSignInResult: $mDriveServiceHelper")
                }
            })
            .addOnFailureListener { e ->
                Log.e("BackupActivity", "handleSignInResult:$e")
                Log.e("BackupActivity", "Unable to sign in."+ e)
            }
    }
    private fun queryDrive(driveId: String?) {
        Log.e("BackupActivity", "queryDrive:" + driveId)
        binding.progressBar.visibility = View.VISIBLE
        mDriveServiceHelper.queryFiles(driveId)
            .addOnSuccessListener {
                binding.progressBar.visibility = View.GONE
                var newList = ArrayList<RecycleViewBaseItem>()
                Log.e("BackupActivity", "queryDrive Success:" + it.size)

                if (drivePathHolder.size > 1) {
                    newList.add(DriveItemConverter().addDriveActionItem("back", R.drawable.icon_back))
                }
                for (fileItem in it) {
                    Log.e("BackupActivity", "item id " + fileItem.id)

                    if(fileItem.mimeType != DriveServiceHelper.TYPE_GOOGLE_DRIVE_FOLDER && fileItem.name.toString().startsWith("MystuffReminder")) {
                        newList.add(
                            DriveItemConverter().addDriveItem(
                                fileItem.id,
                                fileItem.name,
                                getFileOrFolderIcon(fileItem.mimeType),
                                fileItem.mimeType,
                                fileItem.size.toString(),
                                fileItem.modifiedTime.toString()))
                    }
                }

                val folderListDiffUtil = FolderListDiffUtil(recycleItemArrayList, newList)
                val calculateDiff = DiffUtil.calculateDiff(folderListDiffUtil)

                Log.e("BackupActivity", "newList:" + newList.size)
                recycleItemArrayList.clear()
                recycleItemArrayList.addAll(newList)

                calculateDiff.dispatchUpdatesTo(adapter)
            }
            .addOnFailureListener{
                Log.e("BackupActivity", "queryDrive Failed:" + it)
            }

    }
    private fun getFileOrFolderIcon(mimeType: String): Int {
        return when (mimeType) {
            DriveServiceHelper.TYPE_GOOGLE_DRIVE_FOLDER -> {
                R.drawable.ic_folder_vd
            }
            else -> {
                R.drawable.icon_file

            }
        }

    }

    fun onDelete(driveId: String) {
        binding.progressBar.visibility = View.VISIBLE
        mDriveServiceHelper.deleteFolderFile(driveId)
            .addOnSuccessListener { queryDrive(drivePathHolder.last()?.driveId) }

    }

    fun onDownload(driveId: String) {
        binding.progressBar.visibility = View.VISIBLE

        AppUtil.showProgressDialog(this@BackupActivity,"Downloading...")
        //val outFileDir: String = Environment.getExternalStorageDirectory().toString() + "/MystuffReminder"
        val outFileName = AppUtil.mainDir+"/database_restored.db"

        mDriveServiceHelper.downloadFile(File(outFileName), driveId)
            .addOnCompleteListener {
                AppUtil.dismissProgressDialog()
                AppUtil.askAlertDialog(this@BackupActivity,
                    Const.RESTORE_ALERT_TITLE,
                    Const.RESTORE_ALERT_MESSAGE,
                    "Yes", "No",
                    object : DialogCallback {
                        override fun onClick() {
                            //restoreData(outFileName)
                            importDB(outFileName)
                        }
                    },
                    object : DialogCallback {
                        override fun onClick() {
                        }
                    })
            }

        /*
        mDriveServiceHelper.createFolder(driveId, drivePathHolder.last()?.driveId)
            .addOnSuccessListener {
                queryDrive(drivePathHolder.last()?.driveId)
            }
        */

    }

    var isImport=false
    fun importDB(inFileName: String) {
        Const.isAdded=true
        val outFileName = "/data/data/"+applicationContext.packageName+"/databases/"+ SQLiteHandler.DATABASE_NAME
        Log.e("BackupActivity","outFileName:"+outFileName)
        Log.e("BackupActivity","inFileName:"+inFileName)

        try {
            val dbFile = File(inFileName)
            val fis = FileInputStream(dbFile)

            if (dbFile.exists()) {
                Log.e("BackupActivity","dbFile:exists")
            }
            val outFile = File(outFileName)
            Log.e("BackupActivity","outFile_01:"+outFile.path)
            if (outFile.exists()) {
                outFile.delete()
                Log.e("BackupActivity","outFile:"+outFile.path)
            }
            val outFileShm = File(outFileName+"-shm")
            Log.e("BackupActivity","outFileShm_01:"+outFileShm.path)
            if (outFileShm.exists()) {
                outFileShm.delete()
                Log.e("BackupActivity","outFileShm:"+outFileShm.path)
            }
            val outFileWal = File(outFileName+"-wal")
            Log.e("BackupActivity","outFileWal_01:"+outFileWal.path)
            if (outFileWal.exists()) {
                outFileWal.delete()
                Log.e("BackupActivity","outFileWal:"+outFileWal.path)
            }
            // Open the empty db as the output stream
            val output: OutputStream = FileOutputStream(outFileName)

            // Transfer bytes from the input file to the output file
            val buffer = ByteArray(1024)
            var length: Int
            while (fis.read(buffer).also { length = it } > 0) {
                output.write(buffer, 0, length)
            }

            // Close the streams
            output.flush()
            output.close()
            fis.close()

            isImport=true
            Log.e("BackupActivity","Import Completed")
        } catch (e: java.lang.Exception) {
            isImport=false
            Log.e("BackupActivity","Unable to import database."+e)
            e.printStackTrace()
        } finally {
            if(isImport) {
                isImport=false
                Const.isAdded=true
                Snackbar.make(binding.rootLayout, "Data restored Successfully.", Snackbar.LENGTH_LONG).show()
                //Toast.makeText(this@BackupActivity,"Database restored successfully.",Toast.LENGTH_LONG).show()

                //startActivity(Intent(this@BackupActivity, MainActivity::class.java))
                //finish()
                restartDialog()
                //val i = baseContext.packageManager.getLaunchIntentForPackage(baseContext.packageName)
                //i!!.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                //finish()
                //startActivity(i)
                //System.exit(0)
            } else {
                isImport=false
                Snackbar.make(binding.rootLayout, "Unable to import database. Retry", Snackbar.LENGTH_LONG).show()
                //Toast.makeText(this@BackupActivity,"Unable to import database. Retry",Toast.LENGTH_LONG).show()
            }
        }
    }


    fun restartDialog(
    ) {


        val alertDialog = android.app.AlertDialog.Builder(this@BackupActivity)
        val view = LayoutInflater.from(this@BackupActivity).inflate(R.layout.restart_dialog, null)

        alertDialog.setView(view)
        alertDialog.setCancelable(true)

        val dialog: Dialog = alertDialog.create()
        val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
        val txtMessage = view.findViewById<View>(R.id.txtMessage) as TextView
        val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView

        //txtMessage.setTextColor(Color.RED)
        //txtMessage.gravity=Gravity.CENTER_HORIZONTAL
        //txtMessage.setTypeface(null,Typeface.BOLD)
        //txtMessage.setTextSize(30f)

        object : CountDownTimer(3000, 1000) {
            override fun onTick(l: Long) {
                txtMessage.setText("Restart in "+(l/1000))
                //txtTimer.setText("Click Here or Dismiss in "+(l/1000));
            }
            override fun onFinish() {
                startActivity(Intent(this@BackupActivity, MainActivity::class.java))
                finish()
            }
        }.start()

        btnPositive.setOnClickListener {

            startActivity(Intent(this@BackupActivity, MainActivity::class.java))
            finish()
            dialog.dismiss()
        }


        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));

        //Dialog dialog=alertDialog.create();
        dialog.show()

    }

    fun restoreData(outFileName:String) {

        /*
        val dbHandler: SQLiteBackupHandler
        var database: SQLiteDatabase? = null
        dbHandler= SQLiteBackupHandler(this@BackupActivity)

        val dbHandlerMain: SQLiteHandler
        var databaseMain: SQLiteDatabase? = null
        dbHandlerMain= SQLiteHandler(this@BackupActivity)

        database=dbHandler.writableDatabase
        databaseMain=dbHandlerMain.writableDatabase

        try {
            val str2 = "SELECT * FROM stuff_detail"
            var rawQuery = database!!.rawQuery(str2, null)
            val count = rawQuery.count
            Log.e("BackupActivity"," rawQuery:"+count)
            Log.e("BackupActivity"," databaseName:"+dbHandler.databaseName)
            for (i in 0..count) {

                rawQuery = database.rawQuery(str2 + " LIMIT 1 OFFSET " + i, null)

                if (rawQuery.moveToFirst()) {
                    do {

                        val contentValues = ContentValues()
                        contentValues.put("stuff_name", rawQuery.getString(rawQuery.getColumnIndex("stuff_name")))
                        contentValues.put("stuff_detail", rawQuery.getString(rawQuery.getColumnIndex("stuff_detail")))
                        contentValues.put("stuff_barcode", rawQuery.getString(rawQuery.getColumnIndex("stuff_barcode")))
                        contentValues.put("stuff_image", rawQuery.getString(rawQuery.getColumnIndex("stuff_image")))
                        contentValues.put("stuff_price", rawQuery.getDouble(rawQuery.getColumnIndex("stuff_price")))
                        contentValues.put("stuff_purchase_date", rawQuery.getString(rawQuery.getColumnIndex("stuff_purchase_date")))
                        contentValues.put("stuff_expiry_date", rawQuery.getString(rawQuery.getColumnIndex("stuff_expiry_date")))
                        contentValues.put("stuff_warranty_month", rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_month")))
                        contentValues.put("stuff_warranty_year", rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_year")))

                        databaseMain.insert("stuff_detail", null, contentValues)

                        Log.e("BackupActivity"," insert")
                    } while (rawQuery.moveToNext())
                }
            }
            rawQuery.close()
        }
        catch (e: SQLiteException) {
            Log.e("BackupActivity"," SQLiteException:"+e)
        }
        */

        try {
            val sd = Environment.getExternalStorageDirectory()
            //val data = Environment.getDataDirectory()
            if (sd.canWrite()) {
                val currentDBPath = "/data/data/"+applicationContext.packageName+"/databases/"+ SQLiteHandler.DATABASE_NAME
                //val currentDBPath = "//data/package name/databases/database_name"
                val backupDBPath = outFileName
                val currentDB = File(currentDBPath)
                val backupDB = File(backupDBPath)
                Log.e("BackupActivity","currentDBPath:"+currentDBPath)
                Log.e("BackupActivity","currentDB:"+currentDB.path)

                if (currentDB.exists()) {
                    currentDB.delete()

                    val src: FileChannel = FileInputStream(backupDB).getChannel()
                    val dst: FileChannel = FileOutputStream(currentDB).getChannel()
                    dst.transferFrom(src, 0, src.size())
                    src.close()
                    dst.close()

                    val fis = FileInputStream(backupDB)
                    val output: OutputStream = FileOutputStream(outFileName)

                    val buffer = ByteArray(1024)
                    var length: Int
                    try {
                        length = fis.read(buffer)
                        while (length >=0) {
                            output.write(buffer, 0, length);
                            length = fis.read(buffer)
                        }

                        while ((fis.read(buffer)) > 0) {
                            output.write(buffer, 0, length)
                        }

                    } catch (e: IOException){
                        Log.e("BackupDatabase","IOException:"+e)
                    }

                    //Close the streams
                    //output.flush()
                    output.close()
                    fis.close()

                    Log.e("BackupActivity"," Restored successfully")
                    Snackbar.make(binding.rootLayout, "Database Restored successfully", Snackbar.LENGTH_LONG).show()
                    //Toast.makeText(applicationContext, "Database Restored successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Log.e("BackupActivity","currentDB not exist")
                }
            }
        } catch (e: Exception) {
            Log.e("BackupActivity","restoreData:Exception:"+e)
        } finally {
            binding.progressBar.visibility = View.GONE
            Log.e("BackupActivity","finally")
        }

    }

}