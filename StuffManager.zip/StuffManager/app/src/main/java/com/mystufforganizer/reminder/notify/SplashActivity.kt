package com.mystufforganizer.reminder.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mystufforganizer.reminder.notify.activity.MainActivity
import com.mystufforganizer.reminder.notify.databinding.ActivitySplashBinding
import com.mystufforganizer.reminder.notify.notification.AlarmReceiver
import com.mystufforganizer.reminder.notify.util.AppUtil
import java.util.*

class SplashActivity : AppCompatActivity() {

    lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@SplashActivity, R.color.colorWhite)
        }
//        setContentView(R.layout.activity_splash)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)


        // Initialize the Mobile Ads SDK.
        //MobileAds.initialize(this) { }

        delayEnter()


        //val calNow = Calendar.getInstance()
        setNotification()
    }

    fun setNotification() {
        val calNow = Calendar.getInstance()
        val calSet = calNow.clone() as Calendar
        calSet[Calendar.HOUR_OF_DAY] = 1
        calSet[Calendar.MINUTE] = 1
        calSet[Calendar.SECOND] = 0
        calSet[Calendar.MILLISECOND] = 0
        if (calSet.compareTo(calNow) <= 0) {
            calSet.add(Calendar.DATE, 1)
        }
        setAlarm(calSet)
    }

    private fun setAlarm(targetCal: Calendar) {
        val intent = Intent(baseContext, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(baseContext, 1, intent, PendingIntent.FLAG_IMMUTABLE)
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        /*
        alarmManager.set(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 1000 * 5,
            pendingIntent
        )
        */

        val calNow = Calendar.getInstance()
        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP, calNow.getTimeInMillis(),
            2 * 60 * 1000,
            //targetCal.timeInMillis,
            pendingIntent)   //15 min

        Log.e(":::mg::: setAlarm", "ok")
    }

    private fun interstitialAd() {
        enter()
    }

    private fun delayEnter() {
        object : CountDownTimer(1200, 1200) {
            override fun onTick(l: Long) {}
            override fun onFinish() {
                if (AppUtil.check_internet(this@SplashActivity)) {
                    interstitialAd()
                } else {
                    enter()
                }
            }
        }.start()
    }

    private fun enter() {
        startActivity(Intent(this@SplashActivity, MainActivity::class.java))
        //startActivity(Intent(this@SplashActivity, StuffListActivity::class.java))
        //finish()
    }

}