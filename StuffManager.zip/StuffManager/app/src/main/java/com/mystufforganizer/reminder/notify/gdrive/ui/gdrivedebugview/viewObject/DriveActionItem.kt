package com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.viewObject

import com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.DriveItemType


class DriveActionItem() :
    RecycleViewBaseItem(DriveItemType.DRIVE_ACTION_TYPE) {

    var title: String? = null
    var icon: Int? = null

}
