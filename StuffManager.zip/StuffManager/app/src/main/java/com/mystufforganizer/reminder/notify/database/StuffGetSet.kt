package com.mystufforganizer.reminder.notify.database

import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class StuffGetSet(
    var stuff_id: Int,
    var category_id: Int,
    var stuff_name: String,
    var stuff_detail: String,
    var stuff_barcode: String,
    var stuff_image: String,
    var stuff_bill: String,
    var stuff_price: String,
    var stuff_purchase_date: String,
    var stuff_expiry_date: String,
    var stuff_service_reminder: Int,
    var stuff_warranty_month: Int,
    var stuff_warranty_year: Int) {

    object atozComparator : Comparator<StuffGetSet> {
        override fun compare(stuff1: StuffGetSet, stuff2: StuffGetSet): Int {
            return stuff1.stuff_name.substring(0, 1).toUpperCase(Locale.ROOT).compareTo(stuff2.stuff_name.substring(0, 1).toUpperCase(Locale.ROOT))
        }
    }

    object ztoaComparator: Comparator<StuffGetSet> {
        override fun compare(stuff1: StuffGetSet, stuff2: StuffGetSet): Int {
            return stuff2.stuff_name.substring(0, 1).toUpperCase(Locale.ROOT).compareTo(stuff1.stuff_name.substring(0, 1).toUpperCase(Locale.ROOT))
        }
    }

    object ltohComparator: Comparator<StuffGetSet> {
        override fun compare(stuff1: StuffGetSet, stuff2: StuffGetSet): Int {
            return (stuff1.stuff_price.toDouble()-stuff2.stuff_price.toDouble()).roundToInt()
        }
    }
    object htolComparator: Comparator<StuffGetSet> {
        override fun compare(stuff1: StuffGetSet, stuff2: StuffGetSet): Int {
            return (stuff2.stuff_price.toDouble()-stuff1.stuff_price.toDouble()).roundToInt()
        }
    }
    object new_oldComparator: Comparator<StuffGetSet>  {
        override fun compare(stuff1: StuffGetSet, stuff2: StuffGetSet): Int {
            val dateFormat = SimpleDateFormat("dd-MM-yyyy",Locale.getDefault())
            val date1=dateFormat.parse(stuff1.stuff_purchase_date)!!
            val date2=dateFormat.parse(stuff2.stuff_purchase_date)!!

            return date1.compareTo(date2)
            //return date1-date2
        }
    }
    object old_newComparator: Comparator<StuffGetSet> {
        override fun compare(stuff1: StuffGetSet, stuff2: StuffGetSet): Int {
            val dateFormat = SimpleDateFormat("dd-MM-yyyy",Locale.getDefault())
            val date1=dateFormat.parse(stuff1.stuff_purchase_date)!!
            val date2=dateFormat.parse(stuff2.stuff_purchase_date)!!

            return date2.compareTo(date1)
            //return date2-date1
        }
    }

}