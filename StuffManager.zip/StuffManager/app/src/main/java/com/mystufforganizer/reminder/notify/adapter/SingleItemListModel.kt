package com.mystufforganizer.reminder.notify.adapter

import android.os.Parcel
import android.os.Parcelable

class SingleItemListModel : Parcelable {
    var itemData: String?
    var isSelected: Boolean

    constructor() {
        itemData = ""
        isSelected = false
    }

    constructor(itemData: String?, isSelected: Boolean) {
        this.itemData = itemData
        this.isSelected = isSelected
    }

    private constructor(`in`: Parcel) {
        itemData = `in`.readString()
        isSelected = `in`.readByte().toInt() != 0
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(itemData)
        dest.writeByte((if (isSelected) 1 else 0).toByte())
    }

    companion object {
        val CREATOR: Parcelable.Creator<SingleItemListModel> =
            object : Parcelable.Creator<SingleItemListModel> {
                override fun createFromParcel(`in`: Parcel): SingleItemListModel? {
                    return SingleItemListModel(
                        `in`
                    )
                }

                override fun newArray(size: Int): Array<SingleItemListModel?> {
                    return arrayOfNulls(size)
                }
            }
    }
}