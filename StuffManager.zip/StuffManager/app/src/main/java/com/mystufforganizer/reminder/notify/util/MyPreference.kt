package com.mystufforganizer.reminder.notify.util

import android.content.Context
import android.content.SharedPreferences

class MyPreference(private val context: Context) {

    private var prefs: SharedPreferences?
    val PREFS_NAME = "stuff_prefs"

    init {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getLaunchCount(context: Context): Int {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val count = prefs!!.getInt("launch_count", 0)
        if (count <= 10) {
            val editor = prefs!!.edit()
            editor.putInt("launch_count", count + 1)
            editor.apply()
        }
        return count
    }

    fun sharedPreferenceExist(context: Context, key: String?): Boolean {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return !prefs!!.contains(key)
    }

    fun clearSharedPreferences(context: Context) {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val sEdit = prefs!!.edit()
        sEdit.clear()
        sEdit.commit()
    }

    fun setInt(context: Context, key: String?, value: Int) {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs!!.edit()
        editor.putInt(key, value)
        editor.apply()
    }

    fun getInt(context: Context, key: String?): Int {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs!!.getInt(key, 0)
    }

    fun getInt(context: Context, key: String?, defaultValue: Int): Int {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs!!.getInt(key, defaultValue)
    }

    fun setString(context: Context, key: String?, value: String?) {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs!!.edit()
        editor.putString(key, value)
        editor.apply()
    }

    fun getString(context: Context, key: String?): String {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs!!.getString(key, "")!!
    }

    fun getString(context: Context, key: String?, defaultValue: String?): String {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs!!.getString(key, defaultValue)!!
    }

    fun setBoolean(context: Context, key: String?, value: Boolean) {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs!!.edit()
        editor.putBoolean(key, value)
        editor.apply()
    }

    fun getBoolean(context: Context, key: String?): Boolean {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs!!.getBoolean(key, false)
    }

    fun getBoolean(context: Context, key: String?, defaultValue: Boolean): Boolean {
        if (prefs == null) prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs!!.getBoolean(key, defaultValue)
    }

}