package com.mystufforganizer.reminder.notify.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.adapter.SortAdapter.SimpleViewHolder

class SortAdapter(private val dataSource: Array<String>, pos: Int) :
    RecyclerView.Adapter<SimpleViewHolder>() {
    private var listSelectedListener: SortListener? = null
    private var pos = 0

    interface SortListener {
        fun onCategorySelected(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SimpleViewHolder {
        //Create a new view
        val view = LayoutInflater.from(parent.context).inflate(R.layout.lay_option, null)
        return SimpleViewHolder(view)
    }

    fun setListSelectedListener(listSelectedListener: SortListener?) {
        this.listSelectedListener = listSelectedListener
    }

    class SimpleViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        val btnOpt: RadioButton
        var label_tv: TextView
        var root_layout: RelativeLayout

        init {
            root_layout = itemView.findViewById(R.id.root_layout)
            btnOpt = itemView.findViewById(R.id.btnOpt)
            label_tv = itemView.findViewById(R.id.label_tv)
        }
    }

    override fun onBindViewHolder(holder: SimpleViewHolder, @SuppressLint("RecyclerView") position: Int) {
        holder.label_tv.text = dataSource[position]
        holder.btnOpt.setOnClickListener {
            pos = position
            listSelectedListener!!.onCategorySelected(position)
        }

        holder.root_layout.setOnClickListener {
            pos = position
            listSelectedListener!!.onCategorySelected(position)
        }

        if (position == pos) {
            holder.btnOpt.isChecked = true
        } else {
            holder.btnOpt.isChecked = false
        }

    }

    override fun getItemCount(): Int {
        return dataSource.size
    }

    init {
        this.pos = pos
    }
}