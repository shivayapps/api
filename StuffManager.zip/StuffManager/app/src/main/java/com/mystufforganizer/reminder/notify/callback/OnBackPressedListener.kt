package com.mystufforganizer.reminder.notify.callback

interface OnBackPressedListener {
    fun doBack()
}