package com.mystufforganizer.reminder.notify.fragment

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.Transformation
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.OnSuccessListener
import com.google.android.material.snackbar.Snackbar
import com.google.api.services.drive.DriveScopes
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.activity.BackupActivity
import com.mystufforganizer.reminder.notify.activity.MainActivity
import com.mystufforganizer.reminder.notify.adapter.SingleItemListModel
import com.mystufforganizer.reminder.notify.adapter.SingleListItemAdapter
import com.mystufforganizer.reminder.notify.callback.SingleItemCallback
import com.mystufforganizer.reminder.notify.util.*
import com.mystufforganizer.reminder.notify.util.AppUtil
import java.util.*

class SettingFragment : BaseFragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    var lay_action: LinearLayout?=null
    var layFrequency: LinearLayout?=null
    var lay_currency: RelativeLayout?=null
    var lay_backup: RelativeLayout?=null
    var alert_frequency: TextView?=null
    var currency_unit: TextView?=null
    var switch_alert: SwitchButton?=null
    var warrenty_seek: SeekBar?=null
    private var myPreference: MyPreference? = null
    var mSingleItemListModel: ArrayList<SingleItemListModel> = ArrayList<SingleItemListModel>()

    var lay_privacy: LinearLayout?=null
    var lay_rate: LinearLayout?=null
    var lay_share: LinearLayout?=null
    var inrStr: String = ""
    var inrPos: Int = 0

    private val REQUEST_CODE_SIGN_IN = 109
    private lateinit var mGoogleSignInClient: GoogleSignInClient

    var toolbar: Toolbar?=null
    private var rootView: View? = null
    private var rootLayout: View? = null
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_setting, container, false)

        myPreference = MyPreference(context!!)

        toolbar=rootView!!.findViewById(R.id.toolbar)
//        (activity as MainActivity).setSupportActionBar(toolbar!!)
//        (activity as MainActivity).getSupportActionBar()!!.setElevation(20f);

        rootLayout=rootView!!.findViewById(R.id.root_layout)
        lay_action=rootView!!.findViewById(R.id.lay_action)
        lay_currency=rootView!!.findViewById(R.id.lay_currency)
        lay_backup=rootView!!.findViewById(R.id.lay_backup)
        lay_privacy=rootView!!.findViewById(R.id.lay_privacy)
        lay_rate=rootView!!.findViewById(R.id.lay_rate)
        lay_share=rootView!!.findViewById(R.id.lay_share)
        layFrequency=rootView!!.findViewById(R.id.layFrequency)

        alert_frequency=rootView!!.findViewById(R.id.alert_frequency)
        currency_unit=rootView!!.findViewById(R.id.currency_unit)
        switch_alert=rootView!!.findViewById(R.id.switch_alert)
        warrenty_seek=rootView!!.findViewById(R.id.warrenty_seek)

        inrPos=myPreference!!.getInt(context!!, Const.KEY_INR_POS)
        inrStr=myPreference!!.getString(context!!, Const.KEY_INR_STR,resources.getString(R.string.rs))
        currency_unit!!.text=inrStr

        lay_action!!.animate()
            .translationY(0f)
            .alpha(0.0f)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    super.onAnimationEnd(animation)
                    lay_action!!.visibility = View.GONE
                }
            })


        switch_alert!!.isChecked=myPreference!!.getBoolean(context!!,
            Const.KEY_WARRENTY_ALERT)

        if(switch_alert!!.isChecked) {
            expand(layFrequency!!)
            //alert_frequency!!.visibility=View.VISIBLE
            //warrenty_seek!!.visibility=View.VISIBLE
        } else {
            collapse(layFrequency!!)
            //alert_frequency!!.visibility=View.GONE
            //warrenty_seek!!.visibility=View.GONE
        }

        switch_alert!!.setOnCheckedChangeListener(object :
            SwitchButton.OnCheckedChangeListener{
            override fun onCheckedChanged(view: SwitchButton?, isChecked: Boolean) {

                if (myPreference!!.getBoolean(context!!, Const.KEY_WARRENTY_ALERT) != isChecked) {
                    myPreference!!.setBoolean(context!!, Const.KEY_WARRENTY_ALERT, isChecked)
                }
                if(isChecked) {
                    expand(layFrequency!!)
                    //alert_frequency!!.visibility=View.VISIBLE
                    //warrenty_seek!!.visibility=View.VISIBLE
                } else {
                    collapse(layFrequency!!)
                    //alert_frequency!!.visibility=View.GONE
                    //warrenty_seek!!.visibility=View.GONE
                }
            }
        })

        /*switch_alert!!.setOnCheckedChangeListener{ buttonView, isChecked ->

        }*/

        val progress: Int = myPreference!!.getInt(context!!, Const.KEY_WARRENTY_ALERT_FREQUENCY,1)
        alert_frequency!!.setText(String.format(getResources().getString(R.string.warrenty_alert_frequency), progress));
        warrenty_seek!!.progress=(progress-1)

        warrenty_seek!!.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean)
            {
                myPreference!!.setInt(context!!,
                    Const.KEY_WARRENTY_ALERT_FREQUENCY, progress+1)
                alert_frequency!!.setText(String.format(getResources().getString(R.string.warrenty_alert_frequency), progress+1));
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        lay_currency!!.setOnClickListener {
            mSingleItemListModel=setCurrencyData()
            showCurrencyDialog(context!!,mSingleItemListModel)
        }
        lay_privacy!!.setOnClickListener {
            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse(Const.PRIVACY_POLICY)
            )
            startActivity(browserIntent)
        }
        lay_share!!.setOnClickListener {
            AppUtil.shareApp(context!!)
        }
        lay_rate!!.setOnClickListener {
            AppUtil.rateOnPlayStore(context!!)
        }
        lay_backup!!.setOnClickListener {
            val account = GoogleSignIn.getLastSignedInAccount(context)
            if (account == null) {
                signIn()
            } else {

                if(AppUtil.check_internet(context)) {
                    val intent = Intent(context, BackupActivity::class.java)
                    startActivity(intent)
                } else {
                    Snackbar.make(rootLayout!!, "Internet Connection Required.", Snackbar.LENGTH_LONG).show()
                }
                //val openActivity = Intent(context, GDriveDebugViewActivity::class.java)
                //startActivity(openActivity)



            }
        }

        if (AppUtil.check_internet(context)) {
            val frameLayout: FrameLayout = rootView!!.findViewById(R.id.fl_adplaceholder)

            val adsCallBack= object : AdsClass.adsCallBack{
                override fun onAdLoaded() {
//                    adView.visibility=View.VISIBLE
                }
            }

            AdsClass.refreshAd(
                activity!!,
                resources.getString(R.string.ANATIVE_ID),
                frameLayout,
                adsCallBack
            )
        }

        return rootView
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.e("SettingFragment", "onActivityResult:resultCode:"+resultCode )
        Log.e("SettingFragment", "onActivityResult:requestCode:"+requestCode )

        when (requestCode) {
            REQUEST_CODE_SIGN_IN ->
                if (resultCode == Activity.RESULT_OK && data != null) {
                    handleSignInResult(data)
                }
        }
    }

    private fun handleSignInResult(result: Intent) {

        GoogleSignIn.getSignedInAccountFromIntent(result)
            .addOnSuccessListener(object : OnSuccessListener<GoogleSignInAccount> {
                override fun onSuccess(googleSignInAccount: GoogleSignInAccount) {
                    Log.e("SettingFragment", "Signed in as " + googleSignInAccount.email)


                    if(AppUtil.check_internet(context)) {
                        val intent = Intent(context, BackupActivity::class.java)
                        startActivity(intent)
                    } else {
                        Snackbar.make(rootLayout!!, "Internet Connection Required.", Snackbar.LENGTH_LONG).show()
                    }
                    //val openActivity = Intent(context, GDriveDebugViewActivity::class.java)
                    //startActivity(openActivity)
                }


            })
            .addOnFailureListener { e ->
                Log.e("SettingFragment", "handleSignInResult:$e")
                Log.e("SettingFragment", "Unable to sign in."+ e)
            }
    }

    private fun signIn() {
        mGoogleSignInClient = buildGoogleSignInClient()
        startActivityForResult(mGoogleSignInClient.getSignInIntent(), REQUEST_CODE_SIGN_IN)
    }

    private fun buildGoogleSignInClient(): GoogleSignInClient {
        //val webclientId: String = getString(R.string.default_web_client_id)
        val signInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            //.requestIdToken(webclientId)
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))
            .requestScopes(Scope(DriveScopes.DRIVE_APPDATA))
            .requestEmail()
            .build()

        return GoogleSignIn.getClient(context!!, signInOptions)
    }

    private fun setCurrencyData(): ArrayList<SingleItemListModel> {
        val singleItemListModels = ArrayList<SingleItemListModel>()
        try {
            singleItemListModels.clear()
            var lines: List<String?> = ArrayList()
            lines = Arrays.asList(*resources.getStringArray(R.array.currencyArray))

            for (itemData in lines) {
                singleItemListModels.add(
                    SingleItemListModel(
                        itemData,
                        false
                    )
                )
            }

        } catch (e: Exception) {
            Log.e("setItemDataList", "setItemDataList: " + e.message)
        }
        return singleItemListModels
    }

    private fun showCurrencyDialog(context: Context, mSingleItemListModel: ArrayList<SingleItemListModel>) {
        var chkStr:String=myPreference!!.getString(context, Const.KEY_INR_STR,resources.getString(R.string.rs))
        var chkPos:Int=myPreference!!.getInt(context, Const.KEY_INR_POS)

        val singleItemCallback = object :
            SingleItemCallback {
            override fun onClickPosition(position: Int) {
                chkPos=position
                chkStr=mSingleItemListModel[position].itemData!!.split(":")[1]
                Log.e("showSortDialog", "onClickPosition: " + position)
            }
        }

        mSingleItemListModel[inrPos].isSelected=true
        val mSingleListItemAdapter =
            SingleListItemAdapter(
                context,
                mSingleItemListModel,
                singleItemCallback,
                inrPos
            )

        val alertDialog = AlertDialog.Builder(context)
        val view = LayoutInflater.from(context).inflate(R.layout.lay_recycler, null)

        alertDialog.setView(view)
        alertDialog.setCancelable(true)

        val dialog: Dialog = alertDialog.create()
        val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
        val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView
        val btnNegative = view.findViewById<View>(R.id.btnNegative) as TextView
        txtTitle.text = "Select Currency"
        val rvSingleOption: RecyclerView = view.findViewById(R.id.rv_recycler_option)
        rvSingleOption.setHasFixedSize(true)
        rvSingleOption.layoutManager = LinearLayoutManager(
            context,
            LinearLayoutManager.VERTICAL,
            false
        )
        rvSingleOption.adapter=mSingleListItemAdapter

        btnPositive.setOnClickListener {
            currency_unit!!.text=chkStr
            myPreference!!.setString(context, Const.KEY_INR_STR,chkStr)
            myPreference!!.setInt(context, Const.KEY_INR_POS,chkPos)
            dialog.dismiss()
        }

        btnNegative.setOnClickListener {
            dialog.dismiss()
        }

        dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));

        //Dialog dialog=alertDialog.create();
        dialog.show()
    }


    fun expand(v: View) {
        v.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val targtetHeight = v.measuredHeight
        v.layoutParams.height = 0
        v.visibility = View.VISIBLE
        val a: Animation = object : Animation() {
            override fun applyTransformation(interpolatedTime: Float, t: Transformation?) {
                v.layoutParams.height = if (interpolatedTime == 1f) ViewGroup.LayoutParams.WRAP_CONTENT else (targtetHeight * interpolatedTime).toInt()
                v.requestLayout()
            }

            override fun willChangeBounds(): Boolean {
                return true
            }
        }
        a.setDuration((targtetHeight / v.context.resources.displayMetrics.density).toLong())
        v.startAnimation(a)
    }

    fun collapse(v: View) {
        val initialHeight = v.measuredHeight
        val a: Animation = object : Animation() {
            override fun applyTransformation(interpolatedTime: Float, t: Transformation?) {
                if (interpolatedTime == 1f) {
                    v.visibility = View.GONE
                } else {
                    v.layoutParams.height = initialHeight - (initialHeight * interpolatedTime).toInt()
                    v.requestLayout()
                }
            }

            override fun willChangeBounds(): Boolean {
                return true
            }
        }
        a.setDuration((initialHeight / v.context.resources.displayMetrics.density).toLong())
        v.startAnimation(a)
    }

    override fun onBackPressed(): Boolean {
        Log.e("onBackPressed","SettingFragment")
        return true
    }
}