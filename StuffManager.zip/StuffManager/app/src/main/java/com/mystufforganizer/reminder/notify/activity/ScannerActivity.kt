package com.mystufforganizer.reminder.notify.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.util.RevealBackgroundView
import com.google.zxing.Result
import com.mystufforganizer.reminder.notify.databinding.ActivityScannerBinding

import com.mystufforganizer.reminder.notify.util.AdsClass
import com.mystufforganizer.reminder.notify.util.AppUtil
import me.dm7.barcodescanner.zxing.ZXingScannerView

class ScannerActivity : AppCompatActivity() , ZXingScannerView.ResultHandler, RevealBackgroundView.OnStateChangeListener {

    private var mScannerView: ZXingScannerView? = null
    private var tool_back: ImageView? = null
    private var txt_title: TextView? = null
    var vRevealBackground: RevealBackgroundView? = null

    companion object{
        val ARG_REVEAL_START_LOCATION = "reveal_start_location"
    }

    private fun setupRevealBackground(savedInstanceState: Bundle?) {
        vRevealBackground!!.setFillPaintColor(resources.getColor(R.color.colorWhite))
        vRevealBackground!!.setOnStateChangeListener(this@ScannerActivity)
        if (savedInstanceState == null) {
            val startingLocation = intent.getIntArrayExtra(ARG_REVEAL_START_LOCATION)
            vRevealBackground!!.getViewTreeObserver()
                .addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                    override fun onPreDraw(): Boolean {
                        vRevealBackground!!.getViewTreeObserver().removeOnPreDrawListener(this)
                        vRevealBackground!!.startFromLocation(startingLocation)
                        return true
                    }
                })
        } else {
            vRevealBackground!!.setToFinishedFrame()
        }
    }

    lateinit var binding: ActivityScannerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = ContextCompat.getColor(this@ScannerActivity, R.color.colorWhite)
        }

        binding = ActivityScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_scanner)
        //setupToolbar();
        vRevealBackground = findViewById(R.id.vRevealBackground)
        setupRevealBackground(savedInstanceState)

        tool_back = findViewById(R.id.tool_back)
        txt_title = findViewById(R.id.txt_title)
        txt_title!!.setText("QR Scanner")
        tool_back!!.setOnClickListener(View.OnClickListener { onBackPressed() })

        val contentFrame = findViewById<View>(R.id.content_frame) as ViewGroup
        mScannerView = ZXingScannerView(this@ScannerActivity)
        mScannerView!!.setIsBorderCornerRounded(true)
        mScannerView!!.setBorderCornerRadius(100)
        mScannerView!!.setSquareViewFinder(false)
        contentFrame.addView(mScannerView)


        if (AppUtil.check_internet(this@ScannerActivity)) {
            val frameLayout: FrameLayout = findViewById(R.id.fl_adplaceholder)

            val adsCallBack= object : AdsClass.adsCallBack{
                override fun onAdLoaded() {}
            }

            AdsClass.refreshAd(
                this@ScannerActivity,
                resources.getString(R.string.ANATIVE_ID),
                frameLayout,
                adsCallBack
            )
        }

    }

    override fun onResume() {
        super.onResume()
        mScannerView!!.setResultHandler(this)
        mScannerView!!.startCamera()
    }

    override fun onPause() {
        super.onPause()
        mScannerView!!.stopCamera()
    }

    override fun handleResult(rawResult: Result?) {
        val result=rawResult!!.text
        Log.e("onActivityResult","handleResult:"+result)
        intent = Intent()
        intent.putExtra("scancode", result)
        setResult(RESULT_OK, intent);
        finish();
    }

    override fun onStateChange(state: Int) {

    }
}