package com.mystufforganizer.reminder.notify.adapter

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.adapter.StuffAdapter.stuffViewHolder
import com.mystufforganizer.reminder.notify.callback.AdpCallback
import com.mystufforganizer.reminder.notify.database.SQLiteHelper
import com.mystufforganizer.reminder.notify.database.StuffGetSet
import com.mystufforganizer.reminder.notify.util.AppUtil
import com.mystufforganizer.reminder.notify.util.Const
import com.mystufforganizer.reminder.notify.util.MyPreference
import java.text.SimpleDateFormat
import java.util.*


class StuffAdapter(
    var context: Activity,
    var stuffArrayList: ArrayList<StuffGetSet>,
    var adpCallback: AdpCallback,
    var multiSelector: MultiSelector? = null,
    var mLayoutManager: GridLayoutManager
) : RecyclerView.Adapter<stuffViewHolder>(),Filterable {

    private var stuffArrayListFiltered: ArrayList<StuffGetSet> = ArrayList<StuffGetSet>()
    var isMultipleChoiceMode = false
    var dbHelper: SQLiteHelper
    var inflater: LayoutInflater
    private var myPreference: MyPreference? = null
    private var laytype = 1
    var bitmap: Bitmap? = null
    var inrStr: String = ""

    init {
        myPreference= MyPreference(context)
        inrStr=myPreference!!.getString(context, Const.KEY_INR_STR,context.resources.getString(R.string.rs))
        stuffArrayListFiltered=stuffArrayList
        laytype=mLayoutManager.spanCount

        dbHelper = SQLiteHelper(context)
        dbHelper.open()
        inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    }

    private fun trim(str: String, chr: String): String {
        var str = str
        if (str.startsWith(chr)) {
            str = str.substring(1, str.length)
        }
        if (str.endsWith(chr)) {
            str = str.substring(0, str.length - 1)
        }
        return str
    }

    fun deleteItems(checkItems: ParcelableSparseBooleanArray) {
        for (x in stuffArrayList.indices.reversed()) {
            if (checkItems[x, false]) {
                dbHelper.stuffDelete(stuffArrayList.get(x).stuff_id)
                stuffArrayList.removeAt(x)
            }
        }
        notifyDataSetChanged()
    }

    fun setNormalChoiceMode() {
        isMultipleChoiceMode = false
        notifyDataSetChanged()
    }

    fun setMultipleChoiceMode() {
        isMultipleChoiceMode = true
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        val spanCount = mLayoutManager.spanCount
        laytype=spanCount
        return spanCount
        /*
        return if (spanCount == 1) {
            0
        } else {
            1
        }
        */
    }

    fun refreshData() {
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): stuffViewHolder {
        val view: View
        laytype =viewType
        view = if (viewType == 1) {
            LayoutInflater.from(parent.context).inflate(R.layout.listview_layout, parent, false)
        } else {
            LayoutInflater.from(parent.context).inflate(R.layout.gridview_layout, parent, false)
        }
        Log.d("MDD__", "call2")
        return stuffViewHolder(view, viewType)
    }

    override fun onBindViewHolder(holder: stuffViewHolder, position: Int) {
        val stuffGetSet = stuffArrayList[position]

        if(!stuffGetSet.stuff_image.isEmpty()) {
            bitmap= AppUtil.StringToBitMap(stuffGetSet.stuff_image)
            //setMargins(holder.ivGrid,0,0,0,0)
            //holder.ivGrid.setPadding(20,20,20,20)
        }
        else {
            val icon = BitmapFactory.decodeResource(
                context.resources,
                R.drawable.img_default
            )
            //val myDrawable = context.resources.getDrawable(R.mipmap.ic_launcher)
            bitmap = icon
            //setMargins(holder.ivGrid,5,5,5,5)
            //holder.ivGrid.setPadding(20,20,20,20)
        }

        /*
        if(position==stuffArrayList.size-1) {
            holder.viewA.visibility=View.VISIBLE
        } else {
            holder.viewA.visibility=View.GONE
        }
        */

        if(stuffGetSet.stuff_service_reminder>=0) {
            holder.lay_service.visibility=View.VISIBLE
            //holder.stuffService.text
        } else {
            holder.lay_service.visibility=View.GONE
        }

        holder.ivGrid.setImageBitmap(bitmap)
        holder.stuffName.text = stuffGetSet.stuff_name
        holder.stuffPrice.text = inrStr+" "+stuffGetSet.stuff_price

        var sAge = ""
        val e = Calendar.getInstance()
        var eYear = e[Calendar.YEAR]
        var eMonth = e[Calendar.MONTH] + 1
        var eDay = e[Calendar.DAY_OF_MONTH]

        val sDate: List<String> = stuffArrayList[position].stuff_purchase_date.split("-")
        var sDay = sDate[0]
        var sMonth = sDate[1]
        var sYear = sDate[2]

        if (sDay.isEmpty() || sDay.equals("null", ignoreCase = true)) sDay = "0"
        if (sMonth.isEmpty() || sMonth.equals("null", ignoreCase = true)) sMonth = "0"
        if (sYear.isEmpty() || sYear.equals("null", ignoreCase = true)) sYear = "0"
        var sYYYY = try {
            sYear.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sYear)
        }

        var sMM = 0
        sMM = try {
            sMonth.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sMonth)
        }

        var sDD = 0
        sDD = try {
            sDay.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sDay)
        }

        val fDD: Int
        val fMM: Int
        var fYY: Int

        if (eDay < sDD) {
            eMonth = eMonth - 1
            eDay = eDay + 30
            fDD = eDay - sDD
        } else {
            fDD = eDay - sDD
        }

        if (eMonth < sMM) {
            eYear = eYear - 1
            eMonth = eMonth + 12
            fMM = eMonth - sMM
        } else {
            fMM = eMonth - sMM
        }

        fYY = eYear - sYYYY

        if (fYY != 0) {
            sAge += if (fYY != 1) " - " + fYY + "Y" else " - " + fYY + "Y"
        }

        if (fMM != 0) {
            sAge += if (fMM != 1) " - " + fMM + "M" else " - " + fMM + "M"
        }

        sAge += if (fDD != 0) {
            if (fDD != 1) " - " + fDD + "D" else " - " + fDD + "D"
        } else {
            " - 0D"
        }

        if (sYYYY == 0 && sMM == 0 && sDD == 0) {
            //holder.stuffAge.text = stuffGetSet.stuff_purchase_date
        } else {
            //holder.stuffAge.text = stuffGetSet.stuff_purchase_date+" | "+trim(sAge.trim { it <= ' ' }, "-").trim()
        }

        //holder.stuffAge.text = stuffGetSet.stuff_purchase_date
        holder.stuffAge.text = trim(sAge.trim { it <= ' ' }, "-").trim()

        holder.rootView.setOnClickListener {
            if(isMultipleChoiceMode) {
                if(adpCallback!= null) {
                    adpCallback.onAdapterClick(holder.rootView,holder.adapterPosition,stuffGetSet)
                }

                holder.checkBox.isChecked = !holder.checkBox.isChecked

            } else {
                adpCallback.onAdapterClick(holder.ivGrid,holder.adapterPosition,stuffGetSet)
            }
        }

        holder.rootView.isLongClickable=true
        holder.rootView.setOnLongClickListener{
            if(adpCallback!= null)
                adpCallback.onAdapterLongClick(holder.rootView,holder.adapterPosition)

            true
        }

        if (isMultipleChoiceMode) {
            holder.checkBox.setVisibility(View.VISIBLE)
            holder.checkBox.setChecked(multiSelector!!.isChecked(position))
        }
        else holder.checkBox.setVisibility(View.GONE)

        if(laytype==1) {
            setMargins(holder.itemView,0,0,0,2)
        }
        else {
            if(position%2==0)
                setMargins(holder.itemView,0,0,5,5)
            else
                setMargins(holder.itemView,5,0,0,5)
        }

        holder.ivOption.setOnClickListener {
            val popupMenu = PopupMenu(context, holder.ivOption)
            popupMenu.inflate(R.menu.option_menu)
            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.edit -> {
                        adpCallback.onOptionClick(holder.ivGrid,2,stuffGetSet.stuff_id)
                    }
                    R.id.delete -> {
                        adpCallback.onOptionClick(holder.ivGrid,1,stuffGetSet.stuff_id)
                    }
                }
                false
            }
            popupMenu.show()
        }

        if(stuffGetSet.stuff_service_reminder>=0) {
            val remind=stuffGetSet.stuff_service_reminder

            val dateFormat = SimpleDateFormat("dd-MM-yyyy",Locale.getDefault())

            val expiry_date = dateFormat.parse(stuffGetSet.stuff_purchase_date)!!

            var sReminder:Date=expiry_date

            if(remind==0) {
                sReminder=monthlyReminder(expiry_date)
            }
            if(remind==1) {
                sReminder=quarterReminder(expiry_date)
            }
            if(remind==2) {
                sReminder=halfYearReminder(expiry_date)
            }
            if(remind==3) {
                sReminder=yearlyReminder(expiry_date)
            }
            holder.stuffService.text=dateFormat.format(sReminder)
        }

    }

    public fun monthlyReminder(date:Date):Date {
        Log.e("StuffAdapter :" ,"monthlyReminder")
        var nextDate:Date=date
        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.MONTH,1)
        }

        nextDate=calNow.time
        //return getDifferenceStr(nextDate,cal.time)
        return cal.time
    }
    public fun halfYearReminder(date:Date):Date {
        Log.e("StuffAdapter :" ,"halfYearReminder")
        var nextDate:Date=date
        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.MONTH,6)
        }

        nextDate=calNow.time
        getDifferenceStr(nextDate,cal.time)

        //return getDifferenceStr(nextDate,cal.time)
        return cal.time
    }
    public fun quarterReminder(date:Date):Date {
        Log.e("StuffAdapter :" ,"quarterReminder")
        var nextDate:Date=date
        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.MONTH,3)
        }

        nextDate=calNow.time
        getDifferenceStr(nextDate,cal.time)

        //return getDifferenceStr(nextDate,cal.time)
        return cal.time
    }
    public fun yearlyReminder(date:Date):Date {
        Log.e("StuffAdapter :" ,"yearlyReminder")
        var nextDate:Date=date
        val cal = Calendar.getInstance()
        val calNow = Calendar.getInstance()
        cal.time = date

        while (cal.time<calNow.time) {
            cal.add(Calendar.YEAR,1)
        }

        nextDate=calNow.time
        getDifferenceStr(nextDate,cal.time)

        //return getDifferenceStr(nextDate,cal.time)
        return cal.time
    }

    private fun getDifferenceStr(startDate: Date, endDate: Date): String {
        var sAge = ""
        val e = Calendar.getInstance()
        e.time=endDate
        var eYear = e[Calendar.YEAR]
        var eMonth = e[Calendar.MONTH] + 1
        var eDay = e[Calendar.DAY_OF_MONTH]

        //val sDate: List<String> = stuffArrayList[position].stuff_purchase_date.split("-")

        val s = Calendar.getInstance()
        s.time=startDate
        /*
        var sDay = sDate[0]
        var sMonth = sDate[1]
        var sYear = sDate[2]
        */

        val sYear = s[Calendar.YEAR]
        val sMonth = s[Calendar.MONTH] + 1
        val sDay = s[Calendar.DAY_OF_MONTH]

        //if (sDay.isEmpty() || sDay.equals("null", ignoreCase = true)) sDay = "0"
        //if (sMonth.isEmpty() || sMonth.equals("null", ignoreCase = true)) sMonth = "0"
        ///if (sYear.isEmpty() || sYear.equals("null", ignoreCase = true)) sYear = "0"

        var sYYYY = try {
            sYear.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sYear)
        }

        var sMM = 0
        sMM = try {
            sMonth.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sMonth)
        }

        var sDD = 0
        sDD = try {
            sDay.toInt()
        } catch (e1: Exception) {
            Integer.valueOf(sDay)
        }

        val fDD: Int
        val fMM: Int
        var fYY: Int

        if (eDay < sDD) {
            eMonth = eMonth - 1
            eDay = eDay + 30
            fDD = eDay - sDD
        } else {
            fDD = eDay - sDD
        }

        if (eMonth < sMM) {
            eYear = eYear - 1
            eMonth = eMonth + 12
            fMM = eMonth - sMM
        } else {
            fMM = eMonth - sMM
        }

        fYY = eYear - sYYYY

        if (fYY != 0) {
            sAge += if (fYY != 1) " - " + fYY + "Y" else " - " + fYY + "Y"
        }

        if (fMM != 0) {
            sAge += if (fMM != 1) " - " + fMM + "M" else " - " + fMM + "M"
        }

        sAge += if (fDD != 0) {
            if (fDD != 1) " - " + fDD + "D" else " - " + fDD + "D"
        } else {
            " - 0D"
        }

        Log.e("StuffAdapter","getDifferenceStr : sAge:"+trim(sAge.trim { it <= ' ' }, "-").trim())
        return trim(sAge.trim { it <= ' ' }, "-").trim()
    }

    private fun getDifference(startDate: Date, endDate: Date): Long {

        var different = endDate.time - startDate.time
        Log.e("StuffAdapter","getDifference : startDate:"+startDate)
        Log.e("StuffAdapter","getDifference : endDate:"+endDate)
        Log.e("StuffAdapter","getDifference : different:"+different)

        val secondsInMilli: Long = 1000
        val minutesInMilli = secondsInMilli * 60
        val hoursInMilli = minutesInMilli * 60
        val daysInMilli = hoursInMilli * 24

        val elapsedDays = different / daysInMilli
        different = different % daysInMilli
        val elapsedHours = different / hoursInMilli
        different = different % hoursInMilli
        val elapsedMinutes = different / minutesInMilli
        different = different % minutesInMilli
        val elapsedSeconds = different / secondsInMilli
        Log.e("StuffAdapter","getDifference:"+ elapsedDays+" days "+elapsedHours+" hours "+elapsedMinutes+" minutes, "+elapsedSeconds+" seconds")

        return elapsedDays
    }

    //private var lastPosition = -1
    /*
    fun setFadeAnimation(view: View) {
        val anim = AlphaAnimation(0.0f, 1.0f)
        anim.setDuration(500)
        view.startAnimation(anim)
    }
    */
    /*
    private fun setAnimation(viewToAnimate: View, position: Int) {
        if (position > lastPosition) {
            val animation: Animation = AnimationUtils.loadAnimation(context, android.R.anim.fade_in)
            animation.duration=1000
            viewToAnimate.startAnimation(animation)
            lastPosition = position
        }
    }
    */

    private fun setMargins(view: View, left: Int, top: Int, right: Int, bottom: Int) {

        if (view.layoutParams is ViewGroup.MarginLayoutParams) {
            val p = view.layoutParams as ViewGroup.MarginLayoutParams
            val scale = context.resources.displayMetrics.density
            // convert the DP into pixel
            val l = (left * scale + 0.5f).toInt()
            val r = (right * scale + 0.5f).toInt()
            val t = (top * scale + 0.5f).toInt()
            val b = (bottom * scale + 0.5f).toInt()
            p.setMargins(l, t, r, b)
            view.requestLayout()
        }
    }

    override fun getItemCount(): Int {
        return stuffArrayList.size
    }

    inner class stuffViewHolder(itemView: View, viewType: Int) : RecyclerView.ViewHolder(itemView) {
        var ivGrid: ImageView
        var ivOption: ImageView
        var stuffName: TextView
        var stuffAge: TextView
        //var stuffDate: TextView
        var stuffPrice: TextView
        var stuffService: TextView
        var checkBox: CheckBox
        var rootView: View
        var lay_service: LinearLayout
        var viewA: LinearLayout

        init {
            rootView = itemView.findViewById(R.id.root_layout)
            ivGrid = itemView.findViewById(R.id.ivGrid)
            ivOption = itemView.findViewById(R.id.option_iv)
            stuffName = itemView.findViewById(R.id.stuffName)
            stuffAge = itemView.findViewById(R.id.stuffAge)
            //stuffDate = itemView.findViewById(R.id.stuffDate)
            stuffPrice = itemView.findViewById(R.id.stuffPrice)
            stuffService = itemView.findViewById(R.id.stuffService)
            checkBox = itemView.findViewById(R.id.isSelected_cb)
            lay_service = itemView.findViewById(R.id.lay_service)
            viewA = itemView.findViewById(R.id.viewA)
        }
    }



    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val charString = charSequence.toString()

                var filteredList: ArrayList<StuffGetSet> = ArrayList<StuffGetSet>()
                if (charString.length == 0 || charString.isEmpty()) {
                    stuffArrayList = stuffArrayListFiltered
                    filteredList = stuffArrayList
                } else {
                    for (row in stuffArrayList) {

                        if (row.stuff_name.toLowerCase().contains(charString.toLowerCase())
                            ||row.stuff_detail.toLowerCase().contains(charString.toLowerCase())
                        )
                        {
                            filteredList.add(row)
                        }
                    }
                    stuffArrayList = filteredList
                }
                val filterResults = FilterResults()
                filterResults.values = filteredList
                return filterResults
            }

            override fun publishResults(
                charSequence: CharSequence,
                filterResults: FilterResults) {
                if (charSequence.length == 0 || charSequence.toString().isEmpty()) {
                    stuffArrayList = stuffArrayListFiltered
                } else {
                    stuffArrayList = filterResults.values as ArrayList<StuffGetSet>
                }
                notifyDataSetChanged()
            }
        }
    }


}