package com.mystufforganizer.reminder.notify.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Build.VERSION
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.activity.MainActivity
import com.mystufforganizer.reminder.notify.database.SQLiteHelper
import com.mystufforganizer.reminder.notify.database.StuffGetSet
import com.mystufforganizer.reminder.notify.util.Const
import com.mystufforganizer.reminder.notify.util.MyPreference
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class AlarmService : Service() {

    var context: Context? = null
    var stuffArray: ArrayList<StuffGetSet>? = null
    private var myPreference: MyPreference? = null
    var progress: Int = 0
    var ischecked: Boolean = true

    private fun getDifference(startDate: Date, endDate: Date): Long {

        var different = endDate.time - startDate.time
        Log.e("startDate :","$startDate")
        Log.e("endDate :","$endDate")
        Log.e("different :","$different")

        val secondsInMilli: Long = 1000
        val minutesInMilli = secondsInMilli * 60
        val hoursInMilli = minutesInMilli * 60
        val daysInMilli = hoursInMilli * 24

        val elapsedDays = different / daysInMilli
        different = different % daysInMilli
        val elapsedHours = different / hoursInMilli
        different = different % hoursInMilli
        val elapsedMinutes = different / minutesInMilli
        different = different % minutesInMilli
        val elapsedSeconds = different / secondsInMilli
        Log.e("AlarmReceiver","getDifference:"+ elapsedDays+" days "+elapsedHours+" hours "+elapsedMinutes+" minutes, "+elapsedSeconds+" seconds")

        return elapsedDays
    }

    fun Notification(context: Context, str: String, i: Int) {

        val i3 = VERSION.SDK_INT
        val str4 = "idNot"
        val str5 = "isNot"
        val str6 = "isItemClick"
        val str7 = "isFromInsert"
        if (i3 >= 26) {
            createNotificationChannel()
            val intent = Intent(context, MainActivity::class.java)
            intent.putExtra(str7, 2)
            intent.putExtra(str6, true)
            intent.putExtra(str5, true)
            intent.putExtra(str4, i)
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            val activity = PendingIntent.getActivity(context, i, intent, PendingIntent.FLAG_IMMUTABLE)
            val builder = NotificationCompat.Builder(context, "default")
            builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(context.resources.getString(R.string.app_name))
                .setContentText(str)
                .setStyle(NotificationCompat.BigTextStyle())
                .setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                .setNumber(1)
                .setContentIntent(activity).setAutoCancel(true)
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (notificationManager != null) {
                notificationManager.notify(i, builder.build())
                return
            }
            return
        }
        val intent = Intent(context, MainActivity::class.java)
        intent.putExtra("title", context.resources.getString(R.string.app_name))
        intent.putExtra(str7, 2)
        intent.putExtra(str6, true)
        intent.putExtra(str5, true)
        intent.putExtra(str4, i)
        intent.flags = 0
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        val builder = NotificationCompat.Builder(context).setSmallIcon(R.mipmap.ic_launcher).setTicker(str)
                .setStyle(NotificationCompat.BigTextStyle())
                .setContentTitle(context.resources.getString(R.string.app_name))
                .setContentText(str)
                .setContentIntent(PendingIntent.getActivity(context, i, intent, PendingIntent.FLAG_IMMUTABLE))
                .setAutoCancel(true)
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(i, builder.build())

        if (VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            //startForeground(5, notificationManager)

            startService(intent)
        } else {
            startService(intent)
        }

    }

    private fun createNotificationChannel() {
        if (VERSION.SDK_INT >= 26) {
            val notificationManager = getSystemService(NotificationManager::class.java) as NotificationManager
            val notificationChannel = NotificationChannel(
                "default",
                "Channel name",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationChannel.description = "Channel description"
            notificationManager.createNotificationChannel(notificationChannel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        this.context = this@AlarmService

        myPreference= MyPreference(context!!)

        ischecked=myPreference!!.getBoolean(context!!, Const.KEY_WARRENTY_ALERT)
        progress =myPreference!!.getInt(context!!, Const.KEY_WARRENTY_ALERT_FREQUENCY,1)


        if (context!!.getDatabasePath("MystuffReminder.db").length() != 0L) {

            if(ischecked) {
                val sQLiteHelper = SQLiteHelper(context)
                sQLiteHelper.open()
                stuffArray = sQLiteHelper.getAllData(context)
                for (i in stuffArray!!.indices) {
                    val instance = Calendar.getInstance()
                    val time = instance.time
                    instance.add(Calendar.DAY_OF_YEAR, -3)
                    val time2 = instance.time
                    val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
                    val format = simpleDateFormat.format(time2)
                    val format2 = simpleDateFormat.format(time)
                    try {
                        val parse = simpleDateFormat.parse(stuffArray!![i].stuff_expiry_date)
                        simpleDateFormat.parse(format)
                        val difference = getDifference(simpleDateFormat.parse(format2), parse)
                        val sb = StringBuilder()
                        sb.append("")
                        sb.append(difference)
                        Log.e("onStartCommand", ""+sb.toString())
                        Log.e("onStartCommand", "stuff_name:"+stuffArray!![i].stuff_name)
                        Log.e("onStartCommand", "difference:"+difference)
                        Log.e("onStartCommand", "progress:"+progress)

                        if (difference > 0 && difference <= progress) {
                            val str = context!!.resources.getString(R.string.warranty_expire_soon_two)
                            Notification(context!!, str, i)

                        }
                    } catch (e: ParseException) {
                        Log.e("AlarmReceiver","ParseException:"+e.localizedMessage)
                    } catch (e2: Exception) {
                        Log.e("AlarmReceiver","Exception:"+ e2.localizedMessage)
                    }
                }
            }

        }

       /*
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0)
        createNotificationChannel()
        val notification =
            NotificationCompat.Builder(this, "StuffManager")
                .setContentTitle("Stuff Manager")
                .setContentText("StuffManager is running.")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setTicker("Stuff Manager is running.")
                .setWhen(System.currentTimeMillis())
                .build()
                */
        /*
        if (VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            startForeground(5, notification)

            //startService(intent)
        } else {
            startService(intent)
        }
        */
        return START_STICKY
    }

}