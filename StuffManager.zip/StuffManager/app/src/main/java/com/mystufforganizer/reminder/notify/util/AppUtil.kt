package com.mystufforganizer.reminder.notify.util

import android.app.Dialog
import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Environment
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.mystufforganizer.reminder.notify.BuildConfig
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.callback.DialogCallback
import com.mystufforganizer.reminder.notify.database.SQLiteHandler
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

internal class AppUtil {

    companion object {
        val mainDir: String = Environment.getExternalStorageDirectory().toString() + "/MystuffReminder"

        var pDialog: ProgressDialog? = null

        /* Show ProgressDialog */
        fun showProgressDialog(
            context: Context?,
            message: String?
        ) {
            pDialog = ProgressDialog(context)
            pDialog!!.setMessage(message)
            pDialog!!.setCancelable(false)
            try {
                pDialog!!.show()
            } catch (e: java.lang.Exception) {
            }
        }

        /* dismiss ProgressDialog */
        fun dismissProgressDialog() {
            if (pDialog != null) {
                if (pDialog!!.isShowing) {
                    pDialog!!.dismiss()
                }
            }
        }

        fun check_internet(context: Context?): Boolean {
            if (context != null) {
                val connectivityManager =
                    context.getSystemService("connectivity") as ConnectivityManager
                var networkInfo: NetworkInfo? = null
                if (connectivityManager != null) {
                    networkInfo = connectivityManager.activeNetworkInfo
                }
                if (networkInfo != null && (networkInfo.type == 1 || networkInfo.type == 0)) {
                    return java.lang.Boolean.valueOf(true)
                }
            }
            return java.lang.Boolean.valueOf(false)
        }

        fun BackupDatabase(context: Context) : String {
            //Open your local db as the input stream

            val inFileName = "/data/data/"+context.applicationContext.packageName+"/databases/"+ SQLiteHandler.DATABASE_NAME
            val dbFile = File(inFileName)
            val fis = FileInputStream(dbFile)
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss",Locale.getDefault()).format(Date())
            val outFileName: String = mainDir+ "/database"+timeStamp+".db"
            //Open the empty db as the output stream

            val outDir=File(mainDir)
            if(!outDir.exists()) {
                outDir.mkdir()
            }
            val outFile=File(outFileName)
            if(!outFile.exists()) {
                outFile.createNewFile()
            }

            val output: OutputStream = FileOutputStream(outFileName)
            //transfer bytes from the inputfile to the outputfile
            val buffer = ByteArray(1024)
            var length: Int
            try {
                length = fis.read(buffer)
                while (length >=0) {
                    output.write(buffer, 0, length);
                    length = fis.read(buffer)
                }
                /*
                while ((fis.read(buffer)) > 0) {
                    output.write(buffer, 0, length)
                }
                */
            } catch (e:IOException){
                Log.e("BackupDatabase","IOException:"+e)
            }

            //Close the streams
            output.flush()
            output.close()
            fis.close()

            return  outFileName
        }

        fun dpToPx(context: Context, dp: Int): Int {
            val density = context.resources.displayMetrics.density
            return Math.round(dp.toFloat() * density)
        }

        fun BitMapToString(bitmap: Bitmap?): String {
            if(bitmap==null) return "";

            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
            val byte = baos.toByteArray()
            return Base64.encodeToString(byte, Base64.DEFAULT)

        }

        fun StringToBitMap(encodedString: String): Bitmap? {
            return try {
                val encodeByte = Base64.decode(encodedString, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.size)
            } catch (e: Exception) {
                //val photo = BitmapFactory.decodeResource(contex.resources, R.drawable.no_photo)
                null;
            }
        }

        fun askAlertDialog(
            context: Context?,
            title: String?,
            message: String?,
            txtPositive: String?,
            txtNegative: String?,
            positiveListener: DialogCallback?,
            negativeListener: DialogCallback?
        ) {


            val alertDialog = android.app.AlertDialog.Builder(context)
            val view = LayoutInflater.from(context).inflate(R.layout.dialog_layout, null)

            alertDialog.setView(view)
            alertDialog.setCancelable(true)

            val dialog: Dialog = alertDialog.create()
            val txtTitle = view.findViewById<View>(R.id.txtTitle) as TextView
            val txtMessage = view.findViewById<View>(R.id.txtMessage) as TextView
            val btnPositive = view.findViewById<View>(R.id.btnPositive) as TextView
            val btnNegative = view.findViewById<View>(R.id.btnNegative) as TextView

            txtTitle.setText(title)
            txtMessage.setText(message)
            btnPositive.setText(txtPositive)
            if(txtNegative!=null) {
                btnNegative.setText(txtNegative)

                btnNegative.setOnClickListener {
                    if (negativeListener != null) {
                        negativeListener.onClick()
                    }
                    dialog.dismiss()
                }
            }
            else btnNegative.visibility=View.GONE

            if(txtPositive!=null) {

                btnPositive.setOnClickListener {
                    if (positiveListener != null) {
                        positiveListener.onClick()
                    }
                    dialog.dismiss()
                }
            }
            else btnPositive.visibility=View.GONE


            dialog.getWindow()!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));

            //Dialog dialog=alertDialog.create();
            dialog.show()

            /*
            AlertDialog.Builder(context!!)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(btnPositive, positiveListener)
                .setNegativeButton(btnNegative, negativeListener)
                .show()
                */
        }

        fun rateOnPlayStore(context: Context) {
            val uri = Uri.parse("market://details?id=" + context.packageName)
            val myAppLinkToMarket = Intent(Intent.ACTION_VIEW, uri)
            try {
                context.startActivity(myAppLinkToMarket)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(context, " Unable to find Play Store", Toast.LENGTH_LONG).show()
            }
        }


        fun shareApp(context: Context) {
            val GP_DETAIL_PREFIX = "https://play.google.com/store/apps/details?id="
            val shareText = context.resources.getString(R.string.share_desc)
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(
                Intent.EXTRA_TEXT,
                java.lang.String.format(
                    Locale.getDefault(),
                    shareText,
                    GP_DETAIL_PREFIX,
                    BuildConfig.APPLICATION_ID
                )
            )
            sendIntent.type = "text/plain"
            context.startActivity(sendIntent)
        }
    }
}