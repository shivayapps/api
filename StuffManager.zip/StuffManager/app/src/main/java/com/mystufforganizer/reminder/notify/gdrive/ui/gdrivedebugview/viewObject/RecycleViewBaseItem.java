package com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview.viewObject;


public class RecycleViewBaseItem {

    int type;

    public RecycleViewBaseItem(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
