package com.mystufforganizer.reminder.notify.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.util.Base64
import android.util.Log
import com.mystufforganizer.reminder.notify.util.Const
import java.util.*

class SQLiteHelper(context: Context?) {

    var database: SQLiteDatabase? = null
    var dbHandler: SQLiteHandler

    fun open() {
        database = dbHandler.writableDatabase
    }

    fun close() {
        val sQLiteDatabase = database
        if (sQLiteDatabase != null && sQLiteDatabase.isOpen) {
            dbHandler.close()
        }
    }

    fun catInsert(category: String) {
        Const.isCatAdded=true
        val contentValues = ContentValues()
        contentValues.put("category_name", category)
        database!!.insert("category_detail", null, contentValues)
    }
    fun catUpdate(catId: Int,category: String) {
        Const.isCatAdded=true
        val contentValues = ContentValues()
        contentValues.put("category_name", category)
        //database!!.update("category_detail", null, contentValues)

        database!!.update(
            "category_detail",
            contentValues,
            "category_id = ?",
            arrayOf(catId.toString())
        )
    }

    fun getLastCatId(catName: String): Int {
        var lastCatId = 0

        if (catName.equals("other", ignoreCase = true)) {
            return lastCatId
        }
        val selectQuery = "SELECT category_id FROM category_detail WHERE category_name = ?"
        val cursor = database!!.rawQuery(selectQuery, arrayOf(catName))
        if (cursor.moveToFirst()) {
            lastCatId = cursor.getInt(cursor.getColumnIndex("category_id"))
        }
        cursor.close()
        return lastCatId
    }

    fun getCategoryName(id: Int): String {
        return if (id == 0) "Other" else {
            var name = ""
            val selectQuery = "SELECT category_name FROM category_detail WHERE category_id = ?"
            val cursor = database!!.rawQuery(selectQuery, arrayOf(id.toString()))
            if (cursor.moveToFirst()) {
                name = cursor.getString(cursor.getColumnIndex("category_name"))
            }
            cursor.close()
            name ?: "Other"
        }
    }

    fun getCatDetailAdapter(addOther: Boolean): ArrayList<Category> {
        val mCategoryList = ArrayList<Category>()
        val selectQuery = "SELECT category_id,category_name FROM category_detail"
        val cursor = database!!.rawQuery(selectQuery, null)

        if (cursor.count > 0) {
            cursor.moveToFirst()
            do {
                val category_id = cursor.getInt(0)
                val category = cursor.getString(1)

                val selectQuery1 = "SELECT COUNT(stuff_id) FROM stuff_detail WHERE category_id = ?"

                val cursor1 = database!!.rawQuery(selectQuery1, arrayOf(category_id.toString()))
                Log.e("::MG::_count02", "" + cursor1.count)
                if (cursor1.count > 0) {
                    cursor1.moveToFirst()
                    val total = cursor1.getInt(0)
                    val mCategory = Category(category_id,category, total)
                    mCategoryList.add(mCategory)
                } else {
                    val total = 0
                    val mCategory = Category(category_id,category, total)
                    mCategoryList.add(mCategory)
                }
                cursor1.close()
            } while (cursor.moveToNext())
        }
        cursor.close()
        if (addOther) {
            val selectQuery1 = "SELECT COUNT(stuff_id) FROM stuff_detail WHERE category_id = ?"
            val cursor1 = database!!.rawQuery(selectQuery1, arrayOf(0.toString()))
            Log.e("::MG::_count02", "" + cursor1.count)
            if (cursor1.count > 0) {
                cursor1.moveToFirst()
                val total = cursor1.getInt(0)
                val mCategory = Category(0,"Other",  total)
                mCategoryList.add(mCategory)
            }
            cursor1.close()
        }
        return mCategoryList
    }
    fun stuffInsert(
        category_id: Int?,
        stuff_name: String?,
        stuff_detail: String?,
        stuff_barcode: String?,
        stuff_image: String?,
        stuff_bill: String?,
        stuff_price: String,
        stuff_purchase_date: String?,
        stuff_expiry_date: String?,
        stuff_service_reminder: Int,
        stuff_warranty_month: Int,
        stuff_warranty_year: Int
    ) {
        Const.isAdded=true
        Const.isCatAdded=true
        val contentValues = ContentValues()
        contentValues.put("category_id", category_id)
        contentValues.put("stuff_name", stuff_name)
        contentValues.put("stuff_detail", stuff_detail)
        contentValues.put("stuff_barcode", stuff_barcode)
        contentValues.put("stuff_image", stuff_image)
        contentValues.put("stuff_bill", stuff_bill)
        contentValues.put("stuff_price", stuff_price)
        contentValues.put("stuff_purchase_date", stuff_purchase_date)
        contentValues.put("stuff_expiry_date", stuff_expiry_date)
        contentValues.put("stuff_service_reminder", stuff_service_reminder)
        contentValues.put("stuff_warranty_month", stuff_warranty_month)
        contentValues.put("stuff_warranty_year", stuff_warranty_year)
        database!!.insert("stuff_detail", null, contentValues)
    }

    fun stuffContentInsert(contentValues: ContentValues?) {
        Const.isAdded=true
        Const.isCatAdded=true
        val sb = StringBuilder()
        sb.append("")
        sb.append(database!!.insert("stuff_detail", null, contentValues))
        Log.e("database.insert::", sb.toString())
    }

    fun stuffUpdate(
        stuff_id: Int,
        category_id: Int,
        stuff_name: String?,
        stuff_detail: String?,
        stuff_barcode: String?,
        stuff_image: String?,
        stuff_bill: String?,
        stuff_price: String,
        stuff_purchase_date: String?,
        stuff_expiry_date: String?,
        stuff_service_reminder: Int?,
        stuff_warranty_month: Int?,
        stuff_warranty_year: Int?
    ) {
        Const.isAdded=true
        Const.isCatAdded=true
        val contentValues = ContentValues()
        //contentValues.put("stuff_id", stuff_id);
        contentValues.put("category_id", category_id);
        contentValues.put("stuff_name", stuff_name)
        contentValues.put("stuff_detail", stuff_detail)
        contentValues.put("stuff_barcode", stuff_barcode)
        contentValues.put("stuff_image", stuff_image)
        contentValues.put("stuff_bill", stuff_bill)
        contentValues.put("stuff_price", stuff_price)
        contentValues.put("stuff_purchase_date", stuff_purchase_date)
        contentValues.put("stuff_expiry_date", stuff_expiry_date)
        contentValues.put("stuff_service_reminder", stuff_service_reminder)
        contentValues.put("stuff_warranty_month", stuff_warranty_month)
        contentValues.put("stuff_warranty_year", stuff_warranty_year)
        database!!.update(
            "stuff_detail",
            contentValues,
            "stuff_id = ?",
            arrayOf(stuff_id.toString())
        )
    }

    fun isTableExists(str: String?): Boolean {
        val sQLiteDatabase = database
        val sb = StringBuilder()
        sb.append("select DISTINCT tbl_name from sqlite_master where tbl_name = '")
        sb.append(str)
        sb.append("'")
        val rawQuery = sQLiteDatabase!!.rawQuery(sb.toString(), null)
        if (rawQuery != null) {
            if (rawQuery.count > 0) {
                rawQuery.close()
                return true
            }
            rawQuery.close()
        }
        return false
    }

    fun dropOldTable(str: String?): Boolean {
        val sQLiteDatabase = database
        val sb = StringBuilder()
        sb.append("DROP TABLE ")
        sb.append(str)
        val rawQuery = sQLiteDatabase!!.rawQuery(sb.toString(), null)
        if (rawQuery != null) {
            if (rawQuery.count > 0) {
                rawQuery.close()
                return true
            }
            rawQuery.close()
        }
        return false
    }

    fun bitMapToString(bArr: ByteArray?): String? {
        return if (bArr != null) {
            Base64.encodeToString(bArr, 0)
        } else null
    }

    fun truncateAll() {
        Const.isAdded=true
        Const.isCatAdded=true
        database!!.execSQL("DELETE FROM stuff_detail")
    }

    fun getData(context: Context?, str: String): StuffGetSet? {
        Log.e("getData","str:"+str)
        var stuffGetSet: StuffGetSet? = null
        val str2 = ""
        return try {
            val rawQuery = database!!.rawQuery(
                "SELECT * FROM stuff_detail where stuff_id = ?",
                arrayOf(str)
            )
            val sb = StringBuilder()
            sb.append(str2)
            sb.append(rawQuery.count)
            Log.e("cursor::01", sb.toString())
            val sb2 = StringBuilder()
            sb2.append(str2)
            sb2.append(rawQuery.count)
            Log.e("cursor::02", sb2.toString())
            if (rawQuery.moveToFirst()) {
                while (true) {
                    val sb3 = StringBuilder()
                    sb3.append(str2)
                    sb3.append(rawQuery.count)

                    stuffGetSet = StuffGetSet(
                        rawQuery.getInt(rawQuery.getColumnIndex(STUFF_ID)),
                        rawQuery.getInt(rawQuery.getColumnIndex("category_id")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_name")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_detail")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_barcode")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_image")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_bill")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_price")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_purchase_date")),
                        rawQuery.getString(rawQuery.getColumnIndex("stuff_expiry_date")),
                        rawQuery.getInt(rawQuery.getColumnIndex("stuff_service_reminder")),
                        rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_month")),
                        rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_year"))
                    )
                    try {
                        if (!rawQuery.moveToNext()) {
                            break
                        }
                    } catch (unused: SQLiteException) {
                        Log.e("getData","SQLiteException01:"+unused)
                        return stuffGetSet
                    }
                }
                //StuffGetSet2 = stuffGetSet;
            }
            rawQuery.close()
            stuffGetSet
        } catch (unused2: SQLiteException) {
            Log.e("getData","SQLiteException02:"+unused2)
            stuffGetSet
        }
    }

    fun getAllDataCat(context: Context?, cat: Int?): ArrayList<StuffGetSet> {
        val str = ""
        val arrayList = ArrayList<StuffGetSet>()
        try {

            Log.e("getAllDataCat","cat:"+cat)
            val str2 = "SELECT * FROM stuff_detail WHERE category_id = ? "
            var rawQuery = database!!.rawQuery(str2, arrayOf(cat.toString()))

            val count = rawQuery.count
            Log.e("getAllDataCat","count:"+count)
            for (i in 0..count) {
                val sQLiteDatabase = database
                rawQuery = database!!.rawQuery(str2 + " LIMIT 1 OFFSET " + i,  arrayOf(cat.toString()))

                if (rawQuery.moveToFirst()) {
                    do {
                        val stuffGetSet =
                            StuffGetSet(
                                rawQuery.getInt(rawQuery.getColumnIndex(STUFF_ID)),
                                rawQuery.getInt(rawQuery.getColumnIndex("category_id")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_name")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_detail")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_barcode")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_image")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_bill")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_price")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_purchase_date")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_expiry_date")),
                                rawQuery.getInt(rawQuery.getColumnIndex("stuff_service_reminder")),
                                rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_month")),
                                rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_year"))
                            )
                        arrayList.add(stuffGetSet)
                    } while (rawQuery.moveToNext())
                }
            }
            rawQuery.close()
        } catch (e: SQLiteException) {
            Log.e("getAllDataCat","SQLiteException:"+e)
        }

        return arrayList
    }

    fun getAllData(context: Context?): ArrayList<StuffGetSet> {
        val str = ""
        val arrayList = ArrayList<StuffGetSet>()
        try {
            val str2 = "SELECT * FROM stuff_detail"
            var rawQuery = database!!.rawQuery(str2, null)
            val sb = StringBuilder()
            sb.append(str)
            sb.append(rawQuery.count)
            val count = rawQuery.count
            for (i in 0..count) {
                val sQLiteDatabase = database
                rawQuery = database!!.rawQuery(str2 + " LIMIT 1 OFFSET " + i, null)

                if (rawQuery.moveToFirst()) {
                    do {
                        val stuffGetSet =
                            StuffGetSet(
                                rawQuery.getInt(rawQuery.getColumnIndex(STUFF_ID)),
                                0,
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_name")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_detail")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_barcode")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_image")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_bill")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_price")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_purchase_date")),
                                rawQuery.getString(rawQuery.getColumnIndex("stuff_expiry_date")),
                                rawQuery.getInt(rawQuery.getColumnIndex("stuff_service_reminder")),
                                rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_month")),
                                rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_year"))
                            )
                        arrayList.add(stuffGetSet)
                    } while (rawQuery.moveToNext())
                }
            }
            rawQuery.close()
            val sb5 = StringBuilder()
            sb5.append(str)
            sb5.append(arrayList.size)
        } catch (unused: SQLiteException) {
        }

        return arrayList
    }

    fun getAllStuffItem(
        context: Context?,
        str: String?
    ): ArrayList<StuffGetSet> {
        val str2 = "%"
        val str3 = ""
        val arrayList = ArrayList<StuffGetSet>()
        try {
            val str4 = "SELECT * FROM stuff_detail where stuff_name like ?"
            Log.d("QURY__", str4)
            val sQLiteDatabase = database
            val sb = StringBuilder()
            sb.append(str2)
            sb.append(str)
            sb.append(str2)
            val rawQuery = sQLiteDatabase!!.rawQuery(str4, arrayOf(sb.toString()))
            val sb2 = StringBuilder()
            sb2.append(str3)
            sb2.append(rawQuery.count)
            if (rawQuery.moveToFirst()) {
                do {
                    val sb3 = StringBuilder()
                    sb3.append(str3)
                    sb3.append(rawQuery.count)

                    val stuffGetSet =
                        StuffGetSet(
                            rawQuery.getInt(rawQuery.getColumnIndex(STUFF_ID)),
                            rawQuery.getInt(rawQuery.getColumnIndex("category_id")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_name")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_detail")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_barcode")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_image")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_bill")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_price")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_purchase_date")),
                            rawQuery.getString(rawQuery.getColumnIndex("stuff_expiry_date")),
                            rawQuery.getInt(rawQuery.getColumnIndex("stuff_service_reminder")),
                            rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_month")),
                            rawQuery.getInt(rawQuery.getColumnIndex("stuff_warranty_year"))
                        )
                    arrayList.add(stuffGetSet)
                } while (rawQuery.moveToNext())
            }
            rawQuery.close()
            val sb4 = StringBuilder()
            sb4.append(str3)
            sb4.append(arrayList.size)
        } catch (unused: SQLiteException) {
        }
        return arrayList
    }

    val recordCount: Int
        get() {
            val rawQuery = database!!.rawQuery("SELECT DISTINCT stuff_id FROM stuff_detail", null)
            rawQuery.moveToFirst()
            return rawQuery.count
        }

    fun catDelete(id: Int) {
        Const.isCatAdded=true
        val deleteQuery = "DELETE FROM category_detail WHERE category_id='$id'"
        val cursor = database!!.rawQuery(deleteQuery, null)
        Log.e("::MG::", "catUpdate:" + cursor.count)
        cursor.close()
    }

    fun stuffDelete(i: Int) {
        Const.isAdded=true
        Const.isCatAdded=true
        val deleteQuery = "DELETE FROM stuff_detail WHERE stuff_id='$i'"

        database!!.execSQL(deleteQuery)
    }

    companion object {
        private const val STUFF_ID = "stuff_id"
    }

    init {
        dbHandler = SQLiteHandler(context)
    }
}