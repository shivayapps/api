package com.mystufforganizer.reminder.notify.util

import android.app.Activity
import android.app.Dialog
import android.util.Log
import android.view.View
import android.widget.DatePicker
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.mystufforganizer.reminder.notify.R
import java.text.SimpleDateFormat
import java.util.*

class DateTimePicker(private val activity: Activity, iCustomDateTimeListener: ICustomDateTimeListener?)
    : View.OnClickListener {

    private val btn_cancel: TextView
    private val btn_set: TextView
    private var calendar_date: Calendar? = null
    private val datePicker: DatePicker
    private val dialog: Dialog
    private val dialogView: View
    var dialog_sel_hour = 0
    var dialog_sel_minute = 0
    private var iCustomDateTimeListener: ICustomDateTimeListener? = null
    private var is24HourView = true
    private var isAutoDismiss = true
    var isSelectedTime = false
    var isTimeFromDialog = false
    var sel_hour = 0
    var sel_minute = 0
    private var selectedHour = 0
    private var selectedMinute = 0

    interface ICustomDateTimeListener {
        fun onCancel()
        fun onSet(
            dialog: Dialog?,
            calendar: Calendar?,
            date: Date?,
            year: Int,
            monthLong: String?,
            monthShort: String?,
            monthNumber: Int,
            day: Int,
            dayOfWeek: String?,
            dayOfWeekShort: String?,
            hour24: Int,
            hour12: Int,
            minute: Int,
            second: Int,
            AmPm: String?
        )
    }

    private fun getHourIn12Format(i: Int): Int {
        if (i == 0) {
            return 12
        }
        return if (i <= 12) i else i - 12
    }

    fun showDialog() {
        if (!dialog.isShowing) {
            if (calendar_date == null) {
                calendar_date = Calendar.getInstance()
            }
            selectedHour = calendar_date!![11]
            selectedMinute = calendar_date!![12]
            datePicker.updateDate(
                calendar_date!![1],
                calendar_date!![2],
                calendar_date!![5]
            )
            isTimeFromDialog = true
            dialog.show()
        }
    }

    fun setAutoDismiss(isAutoDismiss: Boolean) {
        this.isAutoDismiss = isAutoDismiss
    }

    fun dismissDialog() {
        if (!dialog.isShowing) {
            dialog.dismiss()
        }
    }

    fun setDate(calendar: Calendar?) {
        if (calendar != null) {
            calendar_date = calendar
        }
    }

    fun setDate(date: Date?) {
        if (date != null) {
            calendar_date = Calendar.getInstance()
            calendar_date!!.setTime(date)
            return
        }
        Log.d("CRS__", "NULL")
    }

    fun setDate(i: Int, i2: Int, i3: Int) {
        if (i2 < 12 && i2 >= 0 && i3 < 32 && i3 >= 0 && i > 100 && i < 3000) {
            calendar_date = Calendar.getInstance()
            calendar_date!!.set(i, i2, i3)
        }
    }

    fun setTimeIn24HourFormat(i: Int, i2: Int) {
        if (i < 24 && i >= 0 && i2 >= 0 && i2 < 60) {
            if (calendar_date == null) {
                calendar_date = Calendar.getInstance()
            }
            val calendar = calendar_date
            calendar!![calendar[1], calendar_date!![2], calendar_date!![5], i] = i2
            is24HourView = true
        }
    }

    fun setTimeIn12HourFormat(hour: Int, i2: Int, z: Boolean) {
        var i = hour
        if (i < 13 && i > 0 && i2 >= 0 && i2 < 60) {
            if (i == 12) {
                i = 0
            }
            if (!z) {
                i += 12
            }
            val i3 = i
            if (calendar_date == null) {
                calendar_date = Calendar.getInstance()
            }
            val calendar = calendar_date
            calendar!![calendar[1], calendar_date!![2], calendar_date!![5], i3] = i2
            is24HourView = false
        }
    }

    fun set24HourFormat(z: Boolean) {
        is24HourView = z
    }

    override fun onClick(view: View) {
        val id = view.id
        if (id == R.id.btnCancel) {
            val iCustomDateTimeListener2 = iCustomDateTimeListener
            iCustomDateTimeListener2?.onCancel()
            if (dialog.isShowing) {
                dialog.dismiss()
            }
        } else if (id == R.id.btnOk) {
            if (isTimeFromDialog) {
                if (iCustomDateTimeListener != null) {
                    val month = datePicker.month
                    calendar_date!![datePicker.year, month, datePicker.dayOfMonth, selectedHour] = selectedMinute
                    val iCustomDateTimeListener = iCustomDateTimeListener
                    val dialog2 = dialog
                    val calendar = calendar_date
                    iCustomDateTimeListener!!.onSet(
                        dialog2,
                        calendar,
                        calendar!!.time,
                        calendar_date!![1],
                        getMonthFullName(calendar_date!![2]),
                        getMonthShortName(calendar_date!![2]),
                        calendar_date!![2],
                        calendar_date!![5],
                        getWeekDayFullName(calendar_date!![7]),
                        getWeekDayShortName(calendar_date!![7]),
                        calendar_date!![11],
                        getHourIn12Format(calendar_date!![11]),
                        calendar_date!![12],
                        calendar_date!![13],
                        getAMPM(calendar_date)
                    )
                    if (dialog.isShowing && isAutoDismiss) {
                        dialog.dismiss()
                    }
                }
            } else if (!isSelectedTime) {
                Snackbar.make(dialogView, "Future Time Not Set",Snackbar.LENGTH_LONG).show()
                //Toast.makeText(activity, "Future Time Not Set", Toast.LENGTH_SHORT).show()
            } else if (iCustomDateTimeListener != null) {
                val month2 = datePicker.month
                calendar_date!![datePicker.year, month2, datePicker.dayOfMonth, selectedHour] = selectedMinute
                val iCustomDateTimeListener = iCustomDateTimeListener
                val dialog3 = dialog
                val calendar2 = calendar_date
                iCustomDateTimeListener!!.onSet(
                    dialog3,
                    calendar2,
                    calendar2!!.time,
                    calendar_date!![1],
                    getMonthFullName(calendar_date!![2]),
                    getMonthShortName(calendar_date!![2]),
                    calendar_date!![2],
                    calendar_date!![5],
                    getWeekDayFullName(calendar_date!![7]),
                    getWeekDayShortName(calendar_date!![7]),
                    calendar_date!![11],
                    getHourIn12Format(calendar_date!![11]),
                    calendar_date!![12],
                    calendar_date!![13],
                    getAMPM(calendar_date)
                )
                if (dialog.isShowing && isAutoDismiss) {
                    dialog.dismiss()
                }
            }
        }
    }

    private fun getMonthFullName(i: Int): String {
        val instance = Calendar.getInstance()
        instance[2] = i
        val simpleDateFormat = SimpleDateFormat("MMMM")
        simpleDateFormat.calendar = instance
        return simpleDateFormat.format(instance.time)
    }

    private fun getMonthShortName(i: Int): String {
        val instance = Calendar.getInstance()
        instance[2] = i
        val simpleDateFormat = SimpleDateFormat("MMM")
        simpleDateFormat.calendar = instance
        return simpleDateFormat.format(instance.time)
    }

    private fun getWeekDayFullName(i: Int): String {
        val instance = Calendar.getInstance()
        instance[7] = i
        val simpleDateFormat = SimpleDateFormat("EEEE")
        simpleDateFormat.calendar = instance
        return simpleDateFormat.format(instance.time)
    }

    private fun getWeekDayShortName(i: Int): String {
        val instance = Calendar.getInstance()
        instance[7] = i
        val simpleDateFormat = SimpleDateFormat("EE")
        simpleDateFormat.calendar = instance
        return simpleDateFormat.format(instance.time)
    }

    private fun getAMPM(calendar: Calendar?): String {
        return if (calendar!![9] == 0) "AM" else "PM"
    }

    /* access modifiers changed from: private */
    fun resetData() {
        calendar_date = null
        is24HourView = true
    }

    companion object {
        fun convertDate(
            str: String,
            str2: String?,
            str3: String?
        ): String {
            return try {
                val parse = SimpleDateFormat(str2).parse(str)
                val instance = Calendar.getInstance()
                instance.time = parse
                val simpleDateFormat = SimpleDateFormat(str3)
                simpleDateFormat.calendar = instance
                simpleDateFormat.format(instance.time)
            } catch (e: Exception) {
                e.printStackTrace()
                str
            }
        }

        fun pad(i: Int): String {
            if (i >= 10 || i < 0) {
                return i.toString()
            }
            val sb = StringBuilder()
            //sb.append(AppEventsConstants.EVENT_PARAM_VALUE_NO);
            sb.append(i.toString())
            return sb.toString()
        }
    }

    init {
        this.iCustomDateTimeListener = iCustomDateTimeListener
        dialog = Dialog(activity)
        dialog.setOnDismissListener { resetData() }
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.requestWindowFeature(1)
        dialogView = View.inflate(activity, R.layout.date_picker, null)
        datePicker = dialogView.findViewById<View>(R.id.datePicker) as DatePicker
        btn_set = dialogView.findViewById<View>(R.id.btnOk) as TextView
        btn_cancel = dialogView.findViewById<View>(R.id.btnCancel) as TextView
        datePicker.setOnClickListener(this)
        btn_set.setOnClickListener(this)
        btn_cancel.setOnClickListener(this)
        datePicker.maxDate = System.currentTimeMillis()
        dialog.setContentView(dialogView)
    }
}