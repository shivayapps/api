package com.mystufforganizer.reminder.notify.gdrive.ui.gdrivedebugview

class DriveItemType {

    companion object {

        val DRIVE_ACTION_TYPE = 0
        val DRIVE_ITEM_TYPE = 1

    }

}