package com.mystufforganizer.reminder.notify.util

import android.app.Activity
import android.widget.*

object AdsClass {
    fun refreshAd(
        context: Activity,
        adIds: String?,
        frameLayout: FrameLayout,
        adsCallBack: adsCallBack
    ) {
        frameLayout.removeAllViews()

    }


    interface adsCallBack {
        fun onAdLoaded()
    }
}