package com.mystufforganizer.reminder.notify.util

import android.graphics.Bitmap

class Const {

    companion object {
        var isCatAdded = false
        var isAdded = false

        var sharedBitmap:Bitmap?=null

        val KEY_LAYTYPE = "lay_type"
        val KEY_INR_STR = "inr_str"
        val KEY_INR_POS = "inr_pos"
        val KEY_SORT = "sort"
        val KEY_ORDR = "order"
        val KEY_WARRENTY_ALERT = "warrenty_alert"
        val KEY_WARRENTY_ALERT_FREQUENCY = "alert_frequency"

        val PRIVACY_POLICY = "http://www.privacypolicycenter.com/view.php?v=N0wvMTEvdGVLNjM2TzhHNFFrdzY4Zz09&n=My-Stuff-Organizer"

        val DELETE_ALERT_TITLE = "Delete!"
        val DELETE_ALERT_MESSAGE = "Are you sure you want to delete?"
        val ALERT_EMPTY_CATEGORY = "Category not empty. Delete stuff First."

        val EXIT_ALERT_TITLE = "Do you want to exit.?"
        val EXIT_ALERT_MESSAGE = "Press YES to Exit or NO to Cancel"

        val RESTORE_ALERT_TITLE = "Do you want to restore data.?"
        val RESTORE_ALERT_MESSAGE = "Restoring data losses current data"

    }
}