package com.mystufforganizer.reminder.notify.fragment

import androidx.fragment.app.Fragment

open class BaseFragment : Fragment() {

    open fun onBackPressed(): Boolean {
        return false
    }
}