package com.mystufforganizer.reminder.notify.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mystufforganizer.reminder.notify.R
import com.mystufforganizer.reminder.notify.adapter.SingleListItemAdapter.SingleListItemHolder
import com.mystufforganizer.reminder.notify.callback.SingleItemCallback
import java.util.*

class SingleListItemAdapter(
    private val context: Context,
    private val mSingleItemListModels: ArrayList<SingleItemListModel>,
    var singleItemCallback: SingleItemCallback,
    private val position: Int
) : RecyclerView.Adapter<SingleListItemHolder>() {

    private var pos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SingleListItemHolder {

        val inflatedView = LayoutInflater.from(parent.context).inflate(R.layout.item_value, parent, false)
        return SingleListItemHolder(inflatedView)
    }

    override fun onBindViewHolder(holder: SingleListItemHolder, position: Int) {
        try {
            val CurrentString = mSingleItemListModels[position].itemData!!
            holder.mItemTv!!.text = CurrentString.split(":")[0]
            holder.mValueTv!!.text = CurrentString.split(":")[1]

            if (mSingleItemListModels[position].isSelected) {
                holder.mValueTv!!.setTextColor(context.resources.getColor(R.color.orange_900))
            } else {
                holder.mValueTv!!.setTextColor(context.resources.getColor(R.color.colorBlack))
            }

        } catch (ignored: IndexOutOfBoundsException) {
        }
    }

    override fun getItemCount(): Int {
        return mSingleItemListModels.size
    }

    inner class SingleListItemHolder(v: View) :
        RecyclerView.ViewHolder(v), View.OnClickListener {

        var mItemTv: TextView?=null
        var mValueTv: TextView?=null

        override fun onClick(v: View) {
            try {
                if (mSingleItemListModels.size >= pos) {
                    mSingleItemListModels[pos].isSelected = false
                }

                notifyItemChanged(pos, mSingleItemListModels[pos])

            } catch (e: IndexOutOfBoundsException) {
                Log.e("::MMG::", "SingleListItemAdapter003: " + e.message)
            }
            pos = adapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                if (mSingleItemListModels.size >= pos) mSingleItemListModels[pos].isSelected = true
                notifyItemChanged(pos, mSingleItemListModels[pos])

                singleItemCallback.onClickPosition(pos)

                /*
                if(type==0) SharedPreferenceClass.setInteger(context,"sort_new_cat",pos);
                else SharedPreferenceClass.setInteger(context,"sort_new",pos);
                */
            }
        }

        init {
            mItemTv = v.findViewById<View>(R.id.item_tv) as TextView
            mValueTv = v.findViewById<View>(R.id.value_tv) as TextView
            v.setOnClickListener(this)
            setIsRecyclable(false)
        }
    }

    companion object {
        const val TAG = "SingleListItemAdapter"
    }

    init {
        //myPreference = MyPreference(context)
        pos=position
        //pos = if (position == 0) 0 else 1

        if (mSingleItemListModels.size >= pos) {
            try {
                mSingleItemListModels[pos].isSelected = true
            } catch (e: ArrayIndexOutOfBoundsException) {
                Log.e("::MMG::", "SingleListItemAdapter001: " + e.message)
            } catch (e: IndexOutOfBoundsException) {
                Log.e("::MMG::", "SingleListItemAdapter002: " + e.message)
            }
        }

    }
}