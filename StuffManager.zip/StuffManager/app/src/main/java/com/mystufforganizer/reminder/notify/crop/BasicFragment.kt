package com.mystufforganizer.reminder.notify.crop

//import permissions.dispatcher.NeedsPermission
//import permissions.dispatcher.OnShowRationale
//import permissions.dispatcher.PermissionRequest
//import permissions.dispatcher.RuntimePermissions
import android.app.Activity
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import com.isseiaoki.simplecropview.CropImageView
import com.isseiaoki.simplecropview.callback.CropCallback
import com.isseiaoki.simplecropview.callback.LoadCallback
import com.isseiaoki.simplecropview.callback.SaveCallback
import com.isseiaoki.simplecropview.util.Logger
import com.isseiaoki.simplecropview.util.Utils
import com.mystufforganizer.reminder.notify.R

import java.io.File
import java.text.SimpleDateFormat
import java.util.*

//import android.support.annotation.NonNull;
//import android.support.annotation.StringRes;
//import android.support.v4.app.Fragment;
//import android.support.v7.app.AlertDialog;

//@RuntimePermissions
class BasicFragment : Fragment() {
    private var mCropView: CropImageView? = null
    private var mView: View? = null
    private val mCompressFormat = Bitmap.CompressFormat.JPEG
    private var mFrameRect: RectF? = null
    private var mSourceUri: Uri? = null
    private val ProgressDialogFragment: Calendar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mView =inflater.inflate(
            R.layout.fragment_basic,
            null,
            false
        )
        return mView
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)
        // bind Views
        //mView=view
        bindViews(view)
        mCropView!!.setDebug(false)

        if (savedInstanceState != null) {
            // restore data
            mFrameRect = savedInstanceState.getParcelable(KEY_FRAME_RECT)
            mSourceUri = savedInstanceState.getParcelable(KEY_SOURCE_URI)
        }

        arguments?.let {
            mSourceUri = Uri.parse(it.getString(KEY_SOURCE_URI))
        }

        if (mSourceUri == null) {
            // default data
            //BasicFragmentPermissionsDispatcher.pickImageWithCheck(this@BasicFragment)
            //mSourceUri = getUriFromDrawableResId(getContext(), R.drawable.icon_camera);

            pickImage()
            Log.e("aoki", "mSourceUri = $mSourceUri")
        }
        // load image
        mCropView!!.load(mSourceUri)
            .initialFrameRect(mFrameRect)
            .useThumbnail(true)
            .execute(mLoadCallback)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // save data
        outState.putParcelable(
            KEY_FRAME_RECT,
            mCropView!!.actualCropRect
        )
        outState.putParcelable(KEY_SOURCE_URI, mCropView!!.sourceUri)
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        result: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, result)
        if (resultCode == Activity.RESULT_OK) {
            // reset frame rect
            mFrameRect = null
            when (requestCode) {
                REQUEST_PICK_IMAGE -> {
                    mSourceUri = result!!.data
                    mCropView!!.load(mSourceUri)
                        .initialFrameRect(mFrameRect)
                        .useThumbnail(true)
                        .execute(mLoadCallback)
                }
                REQUEST_SAF_PICK_IMAGE -> {
                    mSourceUri = Utils.ensureUriPermission(
                        context,
                        result
                    )
                    mCropView!!.load(mSourceUri)
                        .initialFrameRect(mFrameRect)
                        .useThumbnail(true)
                        .execute(mLoadCallback)
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        //BasicFragmentPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
    }

    // Bind views //////////////////////////////////////////////////////////////////////////////////
    private fun bindViews(view: View) {
        mCropView =
            view.findViewById<View>(R.id.cropImageView) as CropImageView
        view.findViewById<View>(R.id.buttonDone)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonFitImage)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.button1_1)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.button3_4)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.button4_3)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.button9_16)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.button16_9)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonFree)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonCustom)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonCircle)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonShowCircleButCropAsSquare)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonRotateLeft)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonRotateRight)
            .setOnClickListener(btnListener)
        view.findViewById<View>(R.id.buttonPickImage)
            .setOnClickListener(btnListener)
    }

    private fun selectView(view: View) {
        //var dp=AppUtil.dpToPx(context!!,12)
        //view.setPadding(dp,1,dp,1)
        view.setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_select))
    }
    private fun resetView() {
        //var dp=AppUtil.dpToPx(context!!,12)
        mView!!.findViewById<View>(R.id.buttonFitImage)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.button1_1)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.button3_4)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.button4_3)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.button9_16)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.button16_9)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.buttonFree)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.buttonCustom)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.buttonCircle)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))

        mView!!.findViewById<View>(R.id.buttonShowCircleButCropAsSquare)
            .setBackgroundDrawable(resources.getDrawable(R.drawable.capsule_unselect))
    }

//    @NeedsPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
    fun pickImage() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            startActivityForResult(
                Intent(Intent.ACTION_GET_CONTENT)
                    .setType("image/*"),
                REQUEST_PICK_IMAGE
            )
        } else {
            val intent =
                Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.type = "image/*"
            startActivityForResult(intent, REQUEST_SAF_PICK_IMAGE)
        }
    }

//    @NeedsPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    fun cropImage() {
        showProgress()
        mCropView!!.crop(mSourceUri).execute(mCropCallback)
    }

//    @OnShowRationale(Manifest.permission.READ_EXTERNAL_STORAGE)
    fun showRationaleForPick(request: PermissionRequest) {
        showRationaleDialog(
            R.string.permission_pick_rationale,
            request
        )
    }

//    @OnShowRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    fun showRationaleForCrop(request: PermissionRequest) {
        showRationaleDialog(
            R.string.permission_crop_rationale,
            request
        )
    }

    fun showProgress() {
        //ProgressDialogFragment f = ProgressDialogFragment.getInstance();
        //getFragmentManager().beginTransaction().add(f, PROGRESS_DIALOG).commitAllowingStateLoss();
    }

    fun dismissProgress() {
        /*if (!isResumed()) return;
        FragmentManager manager = getFragmentManager ();
        if (manager == null) return;
        ProgressDialogFragment f =(ProgressDialogFragment) manager . findFragmentByTag (PROGRESS_DIALOG);
        if (f != null) {
            getFragmentManager().beginTransaction().remove(f).commitAllowingStateLoss();
        }*/
    }

    fun createSaveUri(): Uri? {
        return createNewUri(context, mCompressFormat)
    }

    private fun showRationaleDialog(
        @StringRes messageResId: Int,
        request: PermissionRequest
    ) {
//        AlertDialog.Builder(activity!!)
//            .setPositiveButton(
//                R.string.button_allow
//            ) { dialog, which -> request.proceed() }.setNegativeButton(
//                R.string.button_deny
//            ) { dialog, which -> request.cancel() }.setCancelable(false).setMessage(messageResId)
//            .show()
    }

    // Handle button event /////////////////////////////////////////////////////////////////////////
    private val btnListener =
        View.OnClickListener { v ->
            when (v.id) {
                R.id.buttonDone ->{
                    cropImage()
                    //BasicFragmentPermissionsDispatcher.cropImageWithCheck(this@BasicFragment)
                }
                R.id.buttonFitImage -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(CropImageView.CropMode.FIT_IMAGE)
                }
                R.id.button1_1 -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(CropImageView.CropMode.SQUARE)
                }
                R.id.button3_4 -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(CropImageView.CropMode.RATIO_3_4)
                }
                R.id.button4_3 -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(CropImageView.CropMode.RATIO_4_3)
                }
                R.id.button9_16 -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(
                        CropImageView.CropMode.RATIO_9_16
                    )
                }
                R.id.button16_9 -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(
                        CropImageView.CropMode.RATIO_16_9
                    )
                }
                R.id.buttonCustom -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCustomRatio(
                        7,
                        5
                    )
                }
                R.id.buttonFree -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(
                        CropImageView.CropMode.FREE
                    )
                }
                R.id.buttonCircle -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(
                        CropImageView.CropMode.CIRCLE
                    )
                }
                R.id.buttonShowCircleButCropAsSquare -> {
                    resetView()
                    selectView(v)
                    mCropView!!.setCropMode(
                        CropImageView.CropMode.CIRCLE_SQUARE
                    )
                }
                R.id.buttonRotateLeft -> mCropView!!.rotateImage(
                    CropImageView.RotateDegrees.ROTATE_M90D
                )
                R.id.buttonRotateRight -> mCropView!!.rotateImage(
                    CropImageView.RotateDegrees.ROTATE_90D
                )
                R.id.buttonPickImage ->
                {
                    pickImage()
                    //BasicFragmentPermissionsDispatcher.pickImageWithCheck(this@BasicFragment)
                }
            }
        }

    // Callbacks ///////////////////////////////////////////////////////////////////////////////////
    private val mLoadCallback: LoadCallback = object : LoadCallback {
        override fun onSuccess() {}
        override fun onError(e: Throwable) {}
    }
    private val mCropCallback: CropCallback = object : CropCallback {
        override fun onSuccess(cropped: Bitmap) {
            mCropView!!.save(cropped)
                .compressFormat(mCompressFormat)
                .execute(createSaveUri(), mSaveCallback)
        }

        override fun onError(e: Throwable) {}
    }
    private val mSaveCallback: SaveCallback =
        object : SaveCallback {
            override fun onSuccess(outputUri: Uri) {
                dismissProgress()
                (activity as BasicActivity?)!!.startResultActivity(outputUri)
            }

            override fun onError(e: Throwable) {
                dismissProgress()
            }
        }

    companion object {
        private val TAG = BasicFragment::class.java.simpleName
        private const val REQUEST_PICK_IMAGE = 10011
        private const val REQUEST_SAF_PICK_IMAGE = 10012
        private const val PROGRESS_DIALOG = "ProgressDialog"
        private const val KEY_FRAME_RECT = "FrameRect"
        private const val KEY_SOURCE_URI = "SourceUri"
        @JvmStatic
        fun newInstance(): BasicFragment {
            val fragment = BasicFragment()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
        fun newInstance(param1: String): BasicFragment {
            /*
            BasicFragment().apply {
                arguments = Bundle().apply {
                    putString(KEY_SOURCE_URI, param1)
                }
            }
            */
            val fragment = BasicFragment()
            val args = Bundle()
            args.putString(KEY_SOURCE_URI, param1)
            fragment.arguments = args
            return fragment
        }

        val dirPath: String
            get() {
                var dirPath = ""
                var imageDir: File? = null
                val extStorageDir = Environment.getExternalStorageDirectory()
                if (extStorageDir.canWrite()) {
                    imageDir = File(extStorageDir.path + "/simplecropview")
                }
                if (imageDir != null) {
                    if (!imageDir.exists()) {
                        imageDir.mkdirs()
                    }
                    if (imageDir.canWrite()) {
                        dirPath = imageDir.path
                    }
                }
                return dirPath
            }

        fun getUriFromDrawableResId(
            context: Context,
            drawableResId: Int
        ): Uri {
            val builder = StringBuilder()
                .append(ContentResolver.SCHEME_ANDROID_RESOURCE)
                .append("://")
                .append(context.resources.getResourcePackageName(drawableResId))
                .append("/")
                .append(context.resources.getResourceTypeName(drawableResId))
                .append("/")
                .append(context.resources.getResourceEntryName(drawableResId))
            return Uri.parse(builder.toString())
        }
        fun getCropCacheFolder(context: Context): File {
            val cropCacheFolder = File(
                context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                    .toString() + "/cropTemp/"
            )
            if (!cropCacheFolder.exists() || !cropCacheFolder.isDirectory()) cropCacheFolder.mkdirs()
            return cropCacheFolder
        }
        fun createNewUri(context: Context?, format: Bitmap.CompressFormat): Uri? {
            val currentTimeMillis = System.currentTimeMillis()
            val today = Date(currentTimeMillis)
            val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss")
            val title = dateFormat.format(today)
            val dirPath = dirPath
            val fileName =
                "scv" + title + "." + getMimeType(format)
            val path = "$dirPath/$fileName"

//            val file = File(path)
//            val currentTimeMillis = System.currentTimeMillis()
//            val today = Date(currentTimeMillis)
//            val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss")
//            val title = dateFormat.format(today)
//            val fileName = "scv" + title + "." + getMimeType(format!!)
            val cropCacheFolder = File(path)
            val cropFile = File(cropCacheFolder, fileName)

            return Uri.fromFile(cropFile)
        }
        fun createNewUriOld(
            context: Context?,
            format: Bitmap.CompressFormat
        ): Uri? {
            val currentTimeMillis = System.currentTimeMillis()
            val today = Date(currentTimeMillis)
            val dateFormat =
                SimpleDateFormat("yyyyMMdd_HHmmss")
            val title = dateFormat.format(today)
            val dirPath = dirPath
            val fileName =
                "scv" + title + "." + getMimeType(format)
            val path = "$dirPath/$fileName"
            val file = File(path)

            val values = ContentValues()
            values.put(MediaStore.Images.Media.TITLE, title)
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            values.put(
                MediaStore.Images.Media.MIME_TYPE,
                "image/" + getMimeType(format)
            )
            values.put(MediaStore.Images.Media.DATA, path)
            val time = currentTimeMillis / 1000
            values.put(MediaStore.MediaColumns.DATE_ADDED, time)
            values.put(MediaStore.MediaColumns.DATE_MODIFIED, time)
            if (file.exists()) {
                values.put(MediaStore.Images.Media.SIZE, file.length())
            }
            val resolver = context!!.contentResolver
            val uri = resolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            )
            Logger.i("SaveUri = $uri")
            return uri
        }

        fun getMimeType(format: Bitmap.CompressFormat): String {
            Logger.i("getMimeType CompressFormat = $format")
            when (format) {
                Bitmap.CompressFormat.JPEG -> return "jpeg"
                Bitmap.CompressFormat.PNG -> return "png"
                else -> return "jpeg"
            }
            return "png"
        }

        fun createTempUri(context: Context): Uri {
            return Uri.fromFile(File(context.cacheDir, "cropped"))
        }
    }
}