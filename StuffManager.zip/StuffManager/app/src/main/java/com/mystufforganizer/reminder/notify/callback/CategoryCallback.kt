package com.mystufforganizer.reminder.notify.callback

import android.view.View
import com.mystufforganizer.reminder.notify.database.Category
import com.mystufforganizer.reminder.notify.database.StuffGetSet

interface CategoryCallback {
    fun onAdapterClick(view: View, position: Int,category: Category)
    fun onOptionClick(view: View, action: Int,category: Category)
    fun onAdapterLongClick(view: View, position: Int)
}