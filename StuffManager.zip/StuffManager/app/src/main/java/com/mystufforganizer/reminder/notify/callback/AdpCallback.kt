package com.mystufforganizer.reminder.notify.callback

import android.view.View
import com.mystufforganizer.reminder.notify.database.StuffGetSet

interface AdpCallback {
    fun onAdapterClick(view: View, position: Int,stuffGetSet: StuffGetSet)
    fun onOptionClick(view: View, action: Int, itemId: Int)
    fun onAdapterLongClick(view: View, position: Int)
}