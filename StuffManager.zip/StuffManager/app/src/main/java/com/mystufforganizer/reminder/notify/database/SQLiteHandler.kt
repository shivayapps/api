package com.mystufforganizer.reminder.notify.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQLiteHandler(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(sQLiteDatabase: SQLiteDatabase) {
        sQLiteDatabase.execSQL(
            "create table stuff_detail (" +
                    "stuff_id integer primary key autoincrement," +
                    "category_id integer default 0," +
                    "stuff_name text," +
                    "stuff_price text," +
                    "stuff_qnty integer," +
                    "stuff_image text," +
                    "stuff_bill text," +
                    "stuff_detail text," +
                    "stuff_barcode text," +
                    "stuff_purchase_date text," +
                    "stuff_expiry_date text," +
                    "stuff_service_reminder integer default -1," +
                    "stuff_warranty_year integer," +
                    "stuff_warranty_month integer" +
                    ")"
        )

        sQLiteDatabase.execSQL(
            "create table category_detail (" +
                    "category_id integer primary key autoincrement," +
                    "category_name text" +
                    ")"
        )
    }

    override fun onUpgrade(sQLiteDatabase: SQLiteDatabase, i: Int, i2: Int) {
        
    }

    companion object {
        const val DATABASE_NAME = "MystuffReminder.db"
        private const val DATABASE_VERSION = 1
    }
}