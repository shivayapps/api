package com.adconfig.adsutil.admob

import com.adconfig.adsutil.Config

object AdmobIdUtils {

    fun processAdId(id: String, type: ADMOB_ADS): String {
        return when (type) {
            ADMOB_ADS.BANNER ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Banner
                else
                    id

            ADMOB_ADS.NATIVE ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Native_Advanced
                else
                    id

            ADMOB_ADS.INTERSTITIAL ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Interstitial
                else
                    id

            ADMOB_ADS.INTERSTITIAL_REWARD ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Rewarded_Interstitial
                else
                    id

            ADMOB_ADS.APP_OPEN ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.App_Open
                else
                    id

            ADMOB_ADS.REWARD ->
                if (Config.IS_DEBUG)
                    AdmobTestIds.Rewarded
                else
                    id
        }
    }


}

enum class ADMOB_ADS {
    BANNER,
    NATIVE,
    REWARD,
    INTERSTITIAL,
    INTERSTITIAL_REWARD,
    APP_OPEN
}

enum class NativeLayoutType {
    Native_BANNER,
    Native_MEDIUM,
    Native_BUTTON_TOP,
    Native_BUTTON_BOTTOM,
    Native_BIG,
    NATIVE_APP_STORE,
    NATIVE_WEB,
    Native_CUSTOM
}