package com.adconfig.adsutil.admob

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
//import androidx.lifecycle.Lifecycle
//import androidx.lifecycle.LifecycleObserver
//import androidx.lifecycle.LifecycleOwner
//import androidx.lifecycle.OnLifecycleEvent
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.formats.NativeAdOptions.ADCHOICES_TOP_RIGHT
import com.google.android.gms.ads.nativead.*
import com.adconfig.checkLibrary
import com.adconfig.R
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.utils.SmUtils
import java.lang.Exception
import java.lang.RuntimeException
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

class NativeAdHelper(
    private val mContext: Context,
    private val frameLayout: FrameLayout,
    private val mLayoutType: NativeLayoutType? = NativeLayoutType.Native_MEDIUM,
    private var mLayout: Int? = null,
    private val mKeyPref: String? = "admob_native"
) {

    val TAG = "AdmobNativeAdSetup"

    private var mTextColor: Int = 0
    private var mBodyColor: Int = 0

    //    private var mLayoutType: Int = 0
//    private var mLayout: Int = R.layout.layout_google_native_ad_banner
    private var mShimmerLayout: Int = R.layout.layout_shimmer_google_native_ad_banner
    private var mShimmerView: ShimmerFrameLayout? = null

    private lateinit var adView: NativeAdView

    private var isDestroyed = false

    private lateinit var adLoader: AdLoader
    private lateinit var nativeAd: NativeAd


//    init {
//        initAdd()
//    }

    public fun loadAd() {
        if(Config.isAdsEnable) {
            checkLibrary()
            try {
                mTextColor = ContextCompat.getColor(mContext, R.color.title_color)
                mBodyColor = ContextCompat.getColor(mContext, R.color.body_color)

//                mLayoutType =
//                    getInt(
//                        R.styleable.AdmobNativeAdMedia_layout_type,
//                        0
//                    )
                when (mLayoutType) {
                    NativeLayoutType.Native_BANNER -> {//banner
                        mLayout = R.layout.layout_google_native_ad_banner
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_banner
                    }

                    NativeLayoutType.Native_MEDIUM -> {//medium
                        mLayout = R.layout.layout_google_native_ad_medium
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_medium
                    }

                    NativeLayoutType.Native_BUTTON_TOP -> {//button_top
                        mLayout = R.layout.layout_google_native_ad_banner_top
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_banner_top
                    }

                    NativeLayoutType.Native_BUTTON_BOTTOM -> {//button_bottom
                        mLayout = R.layout.layout_google_native_ad_banner_bottom
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_banner_bottom
                    }

                    NativeLayoutType.Native_BIG
                    -> {//big
                        mLayout = R.layout.layout_google_native_ad_big
//                        mLayout = R.layout.sm_admob_native_ad_media
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_big
                    }

                    NativeLayoutType.NATIVE_APP_STORE -> {//custom
                        mLayout = R.layout.layout_google_native_ad_exit_full_screen_app_store
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_exit_full_screen_app_store
                    }
                    NativeLayoutType.NATIVE_WEB -> {//custom
                        mLayout = R.layout.layout_google_native_ad_exit_full_screen_website
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_exit_full_screen_app_store
                    }

                    NativeLayoutType.Native_CUSTOM -> {//custom
                        if(mLayout==null) throw RuntimeException("Custom layout not found.")
//                    mLayout = R.layout.layout_google_native_ad_exit_full_screen_website
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_medium
                    }

                    else -> {
                        mLayout = R.layout.layout_google_native_ad_medium
                        mShimmerLayout = R.layout.layout_shimmer_google_native_ad_medium
                    }
                }


            } finally {
                //frameLayout.recycle()
            }

            if (SmUtils.isConnected(mContext)) {

                adView = LayoutInflater.from(mContext).inflate(mLayout!!, null) as NativeAdView
                val mShimmerLayout =
                    LayoutInflater.from(mContext).inflate(mShimmerLayout, null) as ConstraintLayout
                mShimmerView = mShimmerLayout.findViewById(R.id.shimmerView)

                frameLayout.visibility = View.VISIBLE
                frameLayout.removeAllViews()
//            addView(adView)
                frameLayout.addView(mShimmerLayout)
                mShimmerView?.startShimmer()

                val adId: String = AdmobIdUtils.processAdId(
                    Config.admobNativeId,
                    ADMOB_ADS.NATIVE
                )
//            context.theme
//                .obtainStyledAttributes(
//                    attrs,
//                    R.styleable.AdmobNativeAdMedia, 0, 0
//                )
//                .apply {
//                    adId = AdmobIdUtils.processAdId(
//                        getString(R.styleable.AdmobNativeAdMedia_AD_id).orEmpty(),
//                        ADMOB_ADS.NATIVE
//                    )
//                }

                requireNotEmpty(adId) { "Ad Id cannot be empty" }

                loadAdmobNativeAd(adId)
            } else {
                frameLayout.visibility = View.GONE
            }
        } else {
            frameLayout.removeAllViews()
            frameLayout.visibility = View.GONE
            return
        }


    }

    @OptIn(ExperimentalContracts::class)
    inline fun requireNotEmpty(value: String?, lazyMessage: () -> String): String {
        contract {
            returns() implies (value != null)
        }

        if (value == null) {
            val message = lazyMessage()
            throw IllegalArgumentException(message)
        } else {
            return value
        }
    }


    @SuppressLint("MissingPermission")
    private fun loadAdmobNativeAd(adId: String) {

        Log.i("ADCONFIG_NativeAdHelper", "loadAdmobNativeAd:${adId}")
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
//            .setAdChoicesPlacement(ADCHOICES_TOP_RIGHT)
            .setVideoOptions(videoOptionBuilder.build())

        adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { ad: NativeAd ->
                // Show the ad.
                nativeAd = ad

                if (isDestroyed) {
                    nativeAd.destroy()
                    return@forNativeAd
                }

                if (adLoader.isLoading) {
                    // The AdLoader is still loading ads.
                    // Expect more adLoaded or onAdFailedToLoad callbacks.
                } else {
                    // The AdLoader has finished loading ads.
                    createNativeAd()
                }
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
//                    adView.visibility = View.GONE
                    frameLayout.visibility = View.GONE
                    Log.i("ADCONFIG_NativeAdHelper", "onAdFailedToLoad:${adError.code}:${adError.responseInfo}")
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    private fun createNativeAd() {
//        shimmerView?.hideShimmer()
        frameLayout.removeAllViews()
        frameLayout.addView(adView)
        frameLayout.visibility = View.VISIBLE
        populateAdmobNativeAd()
    }

    private fun populateAdmobNativeAd() {

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        if (headlineView != null) {
            headlineView.setTextColor(mTextColor)
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView
        }

        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (bodyView != null) {
            bodyView.setTextColor(mBodyColor)
            bodyView.text = nativeAd.body
            adView.bodyView = bodyView
        }

        val adChoiceView = adView.findViewById<AdChoicesView>(R.id.adChoiceView)
        if (adChoiceView != null) {
            adView.adChoicesView = adChoiceView
        }

        val adPrice = adView.findViewById<TextView>(R.id.ad_price)
        if (adPrice != null) {
            adPrice.setTextColor(mBodyColor)
            adPrice.text = nativeAd.price
            adView.priceView = adPrice
        }

        val adStore = adView.findViewById<TextView>(R.id.ad_store)
        if (adStore != null) {
            adStore.setTextColor(mBodyColor)
            adStore.text = nativeAd.store
            adView.storeView = adStore
        }

        val callToActionView = adView.findViewById<TextView>(R.id.ad_call_to_action)
        if (callToActionView != null) {
            callToActionView.text = nativeAd.callToAction
            adView.callToActionView = callToActionView
        }

        val adAppIcon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        if (adAppIcon != null && nativeAd.icon != null) {
            adAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
            adView.iconView = adAppIcon
        }

        val adStars = adView.findViewById<RatingBar>(R.id.ad_stars)
        if (adStars != null && nativeAd.starRating != null) {
            adStars.rating = nativeAd.starRating!!.toFloat()
            adView.starRatingView = adStars
        }

        val advertiser = adView.findViewById<TextView>(R.id.ad_advertiser)
        if (advertiser != null) {
            advertiser.text = nativeAd.advertiser
            adView.advertiserView = advertiser
        }

        try {
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            if (mediaView != null) {
                mediaView.visibility = View.VISIBLE
                adView.mediaView = mediaView
                nativeAd.mediaContent?.let {
                    mediaView.setMediaContent(it)
                }
                mediaView.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        adView.setNativeAd(nativeAd)
    }

//    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
//    fun onResume() {
//        Log.e(TAG, "Native Ad Resume")
//        initAdd()
//    }
//    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
//    fun onDestroy() {
//        isDestroyed = true
//        Log.e(TAG, "Native Ad Destroy")
//    }

}