package com.mediaplayer.video.player.videoplayer.music.musicplayer.db

import android.os.Parcel
import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Relation

data class PlaylistWithSongs(
    @Embedded val playlistEntity: PlaylistEntity,
    @Relation(
        parentColumn = "playlist_id",
        entityColumn = "playlist_creator_id"
    )
    val songs: List<SongEntity>
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readParcelable(PlaylistEntity::class.java.classLoader)!!,
        parcel.createTypedArrayList(SongEntity)!!
    )

    override fun describeContents(): Int {
        return 0;
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeTypedList(songs);
    }

    companion object CREATOR : Parcelable.Creator<PlaylistWithSongs> {
        override fun createFromParcel(parcel: Parcel): PlaylistWithSongs {
            return PlaylistWithSongs(parcel)
        }

        override fun newArray(size: Int): Array<PlaylistWithSongs?> {
            return arrayOfNulls(size)
        }
    }
}
