package com.mediaplayer.video.player.videoplayer.music.musicplayer.activities

import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.commit
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMusicSearchBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.resolveColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.search.SearchFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import org.jetbrains.anko.backgroundColor

class MusicSearchActivity : BaseBindingActivity<ActivityMusicSearchBinding>() {

    private val playingQueueFragment = SearchFragment.newInstance()

    override fun getActivityContext(): FragmentActivity {
        return this@MusicSearchActivity
    }

    override fun setBinding(): ActivityMusicSearchBinding {
        return ActivityMusicSearchBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")

        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background =
                RetroGlideExtension.getUserImageTheme(this@MusicSearchActivity)
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        supportFragmentManager.commit {
            replace(R.id.fm_container, playingQueueFragment)
        }
    }
}