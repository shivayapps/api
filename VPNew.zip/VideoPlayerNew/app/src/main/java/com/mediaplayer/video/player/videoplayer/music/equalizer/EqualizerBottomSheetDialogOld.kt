package com.mediaplayer.video.player.videoplayer.music.equalizer


//class EqualizerBottomSheetDialogOld(
//    private val fContext: Context,
//    val audioSessionId: Int
//) : Dialog(fContext, R.style.BottomSheetDialogTheme), DialogInterface.OnDismissListener {
//
//    val ARG_AUDIO_SESSIOIN_ID = "audio_session_id"
//    private val TAG = "EqualizerDialog"
//    private val themeRes = 0
//    private val titleRes = 0
//    private val accentAlpha = Color.BLUE
//    private val darkBackground = Color.GRAY
//    private val backgroundColor = Color.WHITE
//    private val textColor = Color.BLACK
//    private val themeColor = Color.parseColor("#B24242")
//    private val titleString = ""
//
//    private var mEqualizer: Equalizer? = null
//    private var bassBoost: BassBoost? = null
//    private var presetReverb: PresetReverb? = null
//
////    private var points = ArrayList<Float>(5)
//    private val points = floatArrayOf(0.0f, 0.0f, 0.0f, 0.0f, 0.0f)
//
//    private var y = 0
//    private val seekBarFinal = arrayOfNulls<SeekBar>(5)
////    private var equalizer_preset_spinner: RecyclerView? = null
////    private var equalizer_fragment_title: TextView? = null
////    private var controllerBass: SeekBar? = null
////    private var controller3D: SeekBar? = null
//
//    init {
//        @SuppressLint("InflateParams")
//        val sheetView = fContext.inflater.inflate(R.layout.equalizer_dialog, null)
//        setContentView(sheetView)
//        setCanceledOnTouchOutside(true)
//        setCancelable(true)
//
//        val window: Window = window!!
//        val wlp: WindowManager.LayoutParams = window.attributes
//        wlp.gravity = Gravity.BOTTOM
//        wlp.flags = wlp.flags and WindowManager.LayoutParams.FLAG_DIM_BEHIND.inv()
//        window.attributes = wlp
//
//        initViewListener()
//
//        setOnDismissListener(this)
//        show()
//    }
//
//
//    var equalizerPresetSpinnerAdapter: SingleCheckAdapter? = null
//    fun equalizeSound() {
//
//        val equalizerPresetNames: MutableList<String> = ArrayList()
//        //        ArrayAdapter<String> equalizerPresetSpinnerAdapter = new ArrayAdapter<>(ctx,
////                R.layout.item_single_check,
////                equalizerPresetNames);
////        equalizerPresetSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        equalizerPresetNames.add("Custom")
//        for (i in 0 until mEqualizer!!.numberOfPresets) {
//            equalizerPresetNames.add(mEqualizer!!.getPresetName(i.toShort()))
//        }
//        equalizerPresetSpinnerAdapter = SingleCheckAdapter(fContext, equalizerPresetNames)
//        equalizer_preset_spinner!!.adapter = equalizerPresetSpinnerAdapter
//        if (Settings.isEqualizerReloaded && Settings.presetPos != 0) {
//            equalizerPresetSpinnerAdapter!!.setSelection(Settings.presetPos)
//        }
//        equalizerPresetSpinnerAdapter!!.setOnItemClickListener { adapterView, holder, position, id ->
//            try {
//                if (position != 0) {
//                    mEqualizer!!.usePreset((position - 1).toShort())
//                    Settings.presetPos = position
//                    val numberOfFreqBands: Short = 5
//                    val lowerEqualizerBandLevel = mEqualizer!!.bandLevelRange[0]
//                    for (i in 0 until numberOfFreqBands) {
//                        seekBarFinal[i]!!.progress = mEqualizer!!.getBandLevel(i.toShort()) - lowerEqualizerBandLevel
//                        points[i] = (mEqualizer!!.getBandLevel(i.toShort()) - lowerEqualizerBandLevel).toFloat()
//                        Settings.seekbarpos[i] = mEqualizer!!.getBandLevel(i.toShort()).toInt()
//                        Settings.equalizerModel.seekbarpos[i] = mEqualizer!!.getBandLevel(i.toShort()).toInt()
//                    }
//                }
//            } catch (e: java.lang.Exception) {
//                Log.e(TAG, "EqualizerBottomSheetDialog.Exception: equalizerPresetSpinnerAdapter " + e.localizedMessage)
//                Toast.makeText(
//                    fContext,
//                    "Error while updating Equalizer",
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//            Settings.equalizerModel.presetPos = position
//        }
//    }
//
//    private fun initViewListener() {
//
//        val mEndButton = Button(fContext)
//        mEndButton.setBackgroundColor(themeColor)
//        mEndButton.setTextColor(textColor)
//
//        Settings.isEditing = true
//
//        if (Settings.equalizerModel == null) {
//            Settings.equalizerModel = EqualizerModel()
//            Settings.equalizerModel.reverbPreset = PresetReverb.PRESET_NONE
//            Settings.equalizerModel.bassStrength = (1000 / 19).toShort()
//        }
//
//        mEqualizer = Equalizer(0, audioSessionId)
//
//        bassBoost = BassBoost(0, audioSessionId)
//        bassBoost?.setEnabled(true)
//        val bassBoostSettingTemp = bassBoost?.getProperties()
//        val bassBoostSetting = BassBoost.Settings(bassBoostSettingTemp.toString())
//        bassBoostSetting.strength = Settings.equalizerModel.bassStrength
//        bassBoost?.setProperties(bassBoostSetting)
//
//        presetReverb = PresetReverb(0, audioSessionId)
//        presetReverb?.setPreset(Settings.equalizerModel.reverbPreset)
//        presetReverb?.setEnabled(true)
//
//        mEqualizer?.setEnabled(true)
//
//        if (Settings.presetPos == 0) {
//            for (bandIdx in 0 until mEqualizer?.numberOfBands!!) {
//                mEqualizer?.setBandLevel(bandIdx.toShort(), Settings.seekbarpos[bandIdx].toShort())
//            }
//        } else {
//            mEqualizer?.usePreset(Settings.presetPos.toShort())
//        }
//
//
////        equalizer_back_btn.setOnClickListener { dismiss() }
////        equalizer_back_btn.setColorFilter(textColor)
////        equalizerLayout.setBackgroundColor(backgroundColor)
//
//        equalizer_fragment_title?.setTextColor(textColor)
//        if (titleRes != 0) {
//            try {
//                equalizer_fragment_title?.setText(fContext.getString(titleRes))
//            } catch (e: Exception) {
//                Log.e(TAG, "onViewCreated: unable to set title because " + e.localizedMessage)
//            }
//        } else if (!TextUtils.isEmpty(titleString)) {
//            equalizer_fragment_title?.setText(titleString)
//        }
//
//        val equalizerSwitch: SCBSwitch = equalizer_switch
//        equalizerSwitch.isChecked = true
//        equalizerSwitch.setOnCheckedChangeListener { buttonView, isChecked ->
//            mEqualizer!!.enabled = isChecked
//            bassBoost!!.enabled = isChecked
//            presetReverb!!.enabled = isChecked
//        }
//
//        equalizer_preset_spinner?.setLayoutManager(
//            LinearLayoutManager(
//                fContext,
//                LinearLayoutManager.HORIZONTAL,
//                false
//            )
//        )
//
//
//        controllerBass?.progressDrawable?.colorFilter =
//            PorterDuffColorFilter(Color.DKGRAY, PorterDuff.Mode.SRC_IN)
//        controllerBass?.thumb?.colorFilter =
//            PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN)
//        controllerBass?.invalidate()
//
//        controller3D?.progressDrawable?.colorFilter =
//            PorterDuffColorFilter(Color.DKGRAY, PorterDuff.Mode.SRC_IN)
//        controller3D?.thumb?.colorFilter =
//            PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN)
//        controller3D?.invalidate()
//
//        Log.e(TAG, "EqualizerBottomSheetDialog.init.004")
//        if (!Settings.isEqualizerReloaded) {
//            var x = 0
//            if (bassBoost != null) {
//                try {
//                    x = bassBoost!!.roundedStrength * 19 / 1000
//                } catch (e: Exception) {
//                    Log.e(TAG, "Exception: isEqualizerReloaded " + e.localizedMessage)
//                    e.printStackTrace()
//                }
//            }
//            if (presetReverb != null) {
//                try {
//                    y = presetReverb!!.preset * 19 / 6
//                } catch (e: Exception) {
//                    Log.e(TAG, "Exception: presetReverb " + e.localizedMessage)
//                    e.printStackTrace()
//                }
//            }
//            if (x == 0) {
//                controllerBass?.setProgress(1)
//            } else {
//                controllerBass?.setProgress(x)
//            }
//            if (y == 0) {
//                controller3D?.setProgress(1)
//            } else {
//                controller3D?.setProgress(y)
//            }
//        } else {
//            val x = Settings.bassStrength * 19 / 1000
//            y = Settings.reverbPreset * 19 / 6
//            if (x == 0) {
//                controllerBass?.setProgress(1)
//            } else {
//                controllerBass?.setProgress(x)
//            }
//            if (y == 0) {
//                controller3D?.setProgress(1)
//            } else {
//                controller3D?.setProgress(y)
//            }
//        }
//
//        controllerBass?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
//            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
//                Settings.bassStrength = (1000f / 19 * progress).toInt().toShort()
//                try {
//                    bassBoost!!.setStrength(Settings.bassStrength)
//                    Settings.equalizerModel.bassStrength = Settings.bassStrength
//                } catch (e: Exception) {
//                    Log.e(TAG, "Exception: bassController " + e.localizedMessage)
//                    e.printStackTrace()
//                }
//            }
//
//            override fun onStartTrackingTouch(seekBar: SeekBar) {}
//            override fun onStopTrackingTouch(seekBar: SeekBar) {}
//        })
//
//        controller3D?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
//            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
//                Settings.reverbPreset = (progress * 6 / 19).toShort()
//                Settings.equalizerModel.reverbPreset = Settings.reverbPreset
//                try {
//                    presetReverb!!.preset = Settings.reverbPreset
//                } catch (e: Exception) {
//                    Log.e(TAG, "Exception: reverbController " + e.localizedMessage)
//                    e.printStackTrace()
//                }
//                y = progress
//            }
//
//            override fun onStartTrackingTouch(seekBar: SeekBar) {}
//            override fun onStopTrackingTouch(seekBar: SeekBar) {}
//        })
//
//        Log.e(TAG, "EqualizerBottomSheetDialog.init.005")
////        val equalizerHeading = TextView(fContext)
////        equalizerHeading.setText(R.string.equalizer)
////        equalizerHeading.textSize = 20f
////        equalizerHeading.gravity = Gravity.CENTER_HORIZONTAL
//
//        val numberOfFrequencyBands: Short = 5
////        val numberOfFrequencyBands = 5
////        points = FloatArray(numberOfFrequencyBands.toInt())
//
//        val lowerEqualizerBandLevel = mEqualizer!!.bandLevelRange[0]
//        val upperEqualizerBandLevel = mEqualizer!!.bandLevelRange[1]
//
//        for (i in 0 until numberOfFrequencyBands) {
//            val equalizerBandIndex = i.toShort()
//            val frequencyHeaderTextView = TextView(fContext)
//            frequencyHeaderTextView.layoutParams = ViewGroup.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT
//            )
//            frequencyHeaderTextView.gravity = Gravity.CENTER_HORIZONTAL
//            frequencyHeaderTextView.setTextColor(textColor)
//            frequencyHeaderTextView.text = (mEqualizer!!.getCenterFreq(equalizerBandIndex) / 1000).toString() + "Hz"
//            val seekBarRowLayout = LinearLayout(fContext)
//            seekBarRowLayout.orientation = LinearLayout.VERTICAL
//            val lowerEqualizerBandLevelTextView = TextView(fContext)
//            lowerEqualizerBandLevelTextView.layoutParams = ViewGroup.LayoutParams(
//                ViewGroup.LayoutParams.WRAP_CONTENT,
//                ViewGroup.LayoutParams.MATCH_PARENT
//            )
//            lowerEqualizerBandLevelTextView.setTextColor(textColor)
//            lowerEqualizerBandLevelTextView.text = (lowerEqualizerBandLevel / 100).toString() + "dB"
//            val upperEqualizerBandLevelTextView = TextView(fContext)
//            lowerEqualizerBandLevelTextView.layoutParams = ViewGroup.LayoutParams(
//                ViewGroup.LayoutParams.WRAP_CONTENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT
//            )
//            upperEqualizerBandLevelTextView.setTextColor(textColor)
//            upperEqualizerBandLevelTextView.text = (upperEqualizerBandLevel / 100).toString() + "dB"
//            val layoutParams = LinearLayout.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT
//            )
//            layoutParams.weight = 1f
//            var seekBar = SeekBar(fContext)
//            var textView = TextView(fContext)
//            when (i) {
//                0 -> {
//                    seekBar = seekBar1
//                    textView = textView1
//                }
//                1 -> {
//                    seekBar = seekBar2
//                    textView = textView2
//                }
//                2 -> {
//                    seekBar = seekBar3
//                    textView = textView3
//                }
//                3 -> {
//                    seekBar = seekBar4
//                    textView = textView4
//                }
//                4 -> {
//                    seekBar = seekBar5
//                    textView = textView5
//                }
//            }
//            seekBarFinal[i] = seekBar
//            seekBar.progressDrawable.colorFilter = PorterDuffColorFilter(Color.DKGRAY, PorterDuff.Mode.SRC_IN)
//            seekBar.thumb.colorFilter = PorterDuffColorFilter(themeColor, PorterDuff.Mode.SRC_IN)
//            seekBar.id = i
////            seekBar.setLayoutParams(layoutParams);
//            seekBar.max = upperEqualizerBandLevel - lowerEqualizerBandLevel
//
//            textView.text = frequencyHeaderTextView.text
//            textView.setTextColor(textColor)
//            textView.textAlignment = View.TEXT_ALIGNMENT_CENTER
//            if (Settings.isEqualizerReloaded) {
//                points[i] = (Settings.seekbarpos[i] - lowerEqualizerBandLevel).toFloat()
//                seekBar.progress = Settings.seekbarpos[i] - lowerEqualizerBandLevel
//            } else {
//                points[i] = (mEqualizer!!.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel).toFloat()
//                seekBar.progress = mEqualizer!!.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel
//                Settings.seekbarpos[i] = mEqualizer!!.getBandLevel(equalizerBandIndex).toInt()
//                Settings.isEqualizerReloaded = true
//            }
//
//            seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
//                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
//                    mEqualizer!!.setBandLevel(
//                        equalizerBandIndex,
//                        (progress + lowerEqualizerBandLevel).toShort()
//                    )
//                    points[seekBar.id] = (mEqualizer!!.getBandLevel(equalizerBandIndex) - lowerEqualizerBandLevel).toFloat()
//                    Settings.seekbarpos[seekBar.id] = progress + lowerEqualizerBandLevel
//                    Settings.equalizerModel.seekbarpos[seekBar.id] = progress + lowerEqualizerBandLevel
//                }
//                override fun onStartTrackingTouch(seekBar: SeekBar) {
//                    equalizerPresetSpinnerAdapter?.setSelection(0)
//                    Settings.presetPos = 0
//                    Settings.equalizerModel.presetPos = 0
//                }
//                override fun onStopTrackingTouch(seekBar: SeekBar) {
//                }
//            })
//        }
//
//        equalizeSound();
//
//    }
//
//    override fun onDismiss(dialog: DialogInterface?) {
//        if (mEqualizer != null) {
//            mEqualizer!!.release()
//        }
//
//        if (bassBoost != null) {
//            bassBoost!!.release()
//        }
//
//        if (presetReverb != null) {
//            presetReverb!!.release()
//        }
//
//        Settings.isEditing = false
//    }
//
//
////    class Builder {
////        private var id = -1
////        fun setThemeRes(res: Int): Builder {
////            themeRes = res
////            return this
////        }
////
////        fun setAudioSessionId(id: Int): Builder {
////            this.id = id
////            return this
////        }
////
////        fun setAccentColor(color: Int): Builder {
////            themeColor = color
////            return this
////        }
////
////        fun themeColor(color: Int): Builder {
////            backgroundColor = color
////            return this
////        }
////
////        fun textColor(color: Int): Builder {
////            textColor = color
////            return this
////        }
////
////        fun darkColor(color: Int): Builder {
////            darkBackground = color
////            return this
////        }
////
////        fun accentAlpha(color: Int): Builder {
////            accentAlpha = color
////            return this
////        }
////
////        fun title(@StringRes title: Int): Builder {
////            titleRes = title
////            return this
////        }
////
////        fun title(title: String): Builder {
////            titleString = title
////            return this
////        }
////
////        fun build(): DialogEqualizerFragment {
////            return newInstance(id)
////        }
////    }
//}