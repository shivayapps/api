package com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces

import android.view.View
import com.mediaplayer.video.player.videoplayer.music.musicplayer.db.PlaylistWithSongs

interface IPlaylistClickListener {
    fun onPlaylistClick(playlistWithSongs: PlaylistWithSongs, view: View)
}