package com.mediaplayer.video.player.videoplayer.music.musicplayer.model.smartplaylist

import android.os.Parcel
import android.os.Parcelable
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Song


class TopTracksPlaylist() : AbsSmartPlaylist(
    name = App.getContext().getString(R.string.my_top_tracks),
    iconRes = R.drawable.ic_trending_up
) {
    constructor(parcel: Parcel) : this() {
    }

    override fun songs(): List<Song> {
        return topPlayedRepository.topTracks()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        super.writeToParcel(parcel, flags)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<TopTracksPlaylist> {
        override fun createFromParcel(parcel: Parcel): TopTracksPlaylist {
            return TopTracksPlaylist(parcel)
        }

        override fun newArray(size: Int): Array<TopTracksPlaylist?> {
            return arrayOfNulls(size)
        }
    }
}