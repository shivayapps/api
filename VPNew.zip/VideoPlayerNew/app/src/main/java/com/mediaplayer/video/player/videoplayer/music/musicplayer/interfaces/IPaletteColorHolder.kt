
package com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces

/**
 * @author Sujal Lathiya
 */
interface IPaletteColorHolder {
    val paletteColor: Int
}
