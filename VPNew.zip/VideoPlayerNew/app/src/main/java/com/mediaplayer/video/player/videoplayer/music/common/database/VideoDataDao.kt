package com.mediaplayer.video.player.videoplayer.music.common.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query


@Dao
interface VideoDataDao {

    @Query("Select * from video_data where PlaylistName = :playlistname ORDER BY ID DESC ")
    fun getPlaylistVideoLive(playlistname: String?): LiveData<List<VideoDatalist>>

    @Query("Select * from video_data where PlaylistName = :playlistname ORDER BY ID DESC ")
    fun getPlaylistVideo(playlistname: String?): List<VideoDatalist>

    @Insert
    fun insertPlaylistVideo(videoData: VideoDatalist)

    @Query("DELETE from video_data WHERE path = :path and PlaylistName = :playlistname")
    fun deletePlaylistVideo(path: String?, playlistname: String?)

    @Query("DELETE from video_data WHERE PlaylistName = :playlistname")
    fun deletePlaylistVideoName(playlistname: String?)

    @Query("DELETE FROM video_data")
    fun deleteAllPlaylistVideo()

    @Query("Select count(*) from video_data WHERE path = :filepath and PlaylistName = :name")
    fun isAdded(filepath: String, name: String): Int
}