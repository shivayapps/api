package com.mediaplayer.video.player.videoplayer.music.common.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.database.FavoriteVideo
import com.mediaplayer.video.player.videoplayer.music.common.utils.formateSize
import com.mediaplayer.video.player.videoplayer.music.common.utils.setDuration


class FavoriteVideoAdapter(
    val mContext: Activity,
    private val listFile: ArrayList<FavoriteVideo>,
    private val clickListener: View.OnClickListener,
    private val types: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    inner class myClass(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivMainImage: ImageView = itemView.findViewById(R.id.iv_all_video_icon)
        var ivOptions: ImageView = itemView.findViewById(R.id.iv_all_option)
        var txtTitle: TextView = itemView.findViewById(R.id.tv_video_name)
        var txtduration: TextView = itemView.findViewById(R.id.tv_recent_video_lenth)
        var txtfolder: TextView = itemView.findViewById(R.id.tv_name_fol)
        var txtSize: TextView = itemView.findViewById(R.id.tv_size)
        var ivResolution: TextView = itemView.findViewById(R.id.tv_reso)

        var ivCon: ConstraintLayout = itemView.findViewById(R.id.con_main)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val mView: View? =
            LayoutInflater.from(mContext).inflate(R.layout.all_video_list, parent, false)
        return myClass(mView!!)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        if (holder is myClass) {
            if (position >= 0 && position < listFile.size) {
                with(listFile[position]) {
                    val item = this
                    Glide.with(mContext).load(item.path).override(300, 300)
                        .into(holder.ivMainImage)
                    holder.txtduration.text = setDuration(item.duration)
                    holder.txtTitle.text = item.name
                    holder.txtfolder.text = item.bucketName
                    holder.txtSize.text = formateSize(item.size)
                    holder.ivResolution.text = item.width.toString() + "p"
                    holder.ivCon.setOnClickListener(clickListener)
                    holder.ivCon.tag = position
                    holder.ivCon.setTag(R.id.TYPE, types)
                    holder.ivOptions.setOnClickListener(clickListener)
                    holder.ivOptions.tag = position
                    holder.ivOptions.setTag(R.id.TYPE, types)
                }
            } else {
                holder.itemView.visibility = View.GONE
            }
        }
    }

    fun getItem(position: Int): FavoriteVideo {
        return listFile[position]
    }

    override fun getItemViewType(position: Int): Int {
        val returnPos = if (listFile[position].path.isEmpty()) {
            1
        } else {
            0
        }
        return returnPos
    }

    override fun getItemCount(): Int {
        return listFile.size
    }

}