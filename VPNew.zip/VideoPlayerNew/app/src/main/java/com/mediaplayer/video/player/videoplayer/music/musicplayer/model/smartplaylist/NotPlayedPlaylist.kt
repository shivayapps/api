package com.mediaplayer.video.player.videoplayer.music.musicplayer.model.smartplaylist

import android.os.Parcel
import android.os.Parcelable
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.model.Song


class NotPlayedPlaylist() : AbsSmartPlaylist(
    name = App.getContext().getString(R.string.not_recently_played),
    iconRes = R.drawable.ic_watch_later
) {
    constructor(parcel: Parcel) : this() {
    }

    override fun songs(): List<Song> {
        return topPlayedRepository.notRecentlyPlayedTracks()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        super.writeToParcel(parcel, flags)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<NotPlayedPlaylist> {
        override fun createFromParcel(parcel: Parcel): NotPlayedPlaylist {
            return NotPlayedPlaylist(parcel)
        }

        override fun newArray(size: Int): Array<NotPlayedPlaylist?> {
            return arrayOfNulls(size)
        }
    }
}