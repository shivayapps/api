package com.mediaplayer.video.player.videoplayer.music.common.database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {RecentVideo.class, VideoDatalist.class, VideoPlaylist.class, VideoSearchHistory.class, FavoriteVideo.class},exportSchema = false,version = 2)
public abstract class VideoPlayerDatabase extends RoomDatabase {
    private static final String DB_NAME = "video_player_db";
    private static VideoPlayerDatabase Instance;

    public static synchronized VideoPlayerDatabase getInstance(Context context)
    {
        if (Instance == null)
        {
            Instance = Room.databaseBuilder(context.getApplicationContext(),VideoPlayerDatabase.class,DB_NAME)
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return Instance;
    }

    public abstract RecentVideoDao recentVideoDao();
    public abstract VideoPlaylistDao videoPlaylistDao();
    public abstract VideoDataDao videoDataDao();
    public abstract VideoSearchHistoryDao videoSearchHistoryDao();
    public abstract FavoriteVideoDao favoriteVideoDao();
}
