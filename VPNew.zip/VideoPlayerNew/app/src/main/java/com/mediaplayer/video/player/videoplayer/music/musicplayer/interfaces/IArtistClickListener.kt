
package com.mediaplayer.video.player.videoplayer.music.musicplayer.interfaces

import android.view.View

interface IArtistClickListener {
    fun onArtist(artistId: Long, view: View)
}
