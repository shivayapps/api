package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoPlayerDatabase
import com.mediaplayer.video.player.videoplayer.music.common.database.VideoPlaylist
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityPlaylistBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.DeleteDialogBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.NewPlaylistDialogBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.resolveColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.videoplayer.activity.PlaylistVideoActivity
import com.mediaplayer.video.player.videoplayer.music.videoplayer.adapter.PlaylistAdapter
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.jetbrains.anko.backgroundColor
import org.jetbrains.anko.toast


class PlayListActivity : BaseBindingActivity<ActivityPlaylistBinding>() {

    private var mPlaylistAdapter: PlaylistAdapter? = null

    private lateinit var mDB: VideoPlayerDatabase

    companion object {
        var mVideoData: ArrayList<VideoData> = ArrayList()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@PlayListActivity
    }

    override fun setBinding(): ActivityPlaylistBinding {
        return ActivityPlaylistBinding.inflate(layoutInflater)
    }

    override fun onResume() {
        super.onResume()
        initView()
    }

    override fun initView() {
        super.initView()

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(
            GENERAL_THEME, 0
        )

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            mBinding.root.background = RetroGlideExtension.getUserImageTheme(this@PlayListActivity)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            mBinding.root.background =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.root.background = null
            mBinding.root.backgroundColor = resolveColor(R.attr.mainBackgroundColor)
        }

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this)
        }

        mDB = VideoPlayerDatabase.getInstance(mActivity)

        mDB.videoPlaylistDao().getPlaylistLive().observe(this) { mList ->

            mBinding.conEmptyView.visibility = View.GONE
            mBinding.rvVideoPlaylist.visibility = View.VISIBLE

            val mVideoDataLists: java.util.ArrayList<VideoPlaylist> = java.util.ArrayList()
            mVideoDataLists.addAll(mList)
            mVideoDataLists.add(0, VideoPlaylist(getString(R.string.create_playlist)))
            mVideoDataLists.add(1, VideoPlaylist(getString(R.string.my_favorite)))
            mPlaylistAdapter = PlaylistAdapter(
                mActivity,
                mVideoDataLists,
                this@PlayListActivity,
                View.OnLongClickListener { v ->
                    if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                        return@OnLongClickListener true
                    }
                    mLastClickTime = SystemClock.elapsedRealtime()

                    val pos = v.tag as Int
                    val data =
                        getRecyclerVideoPlaylistData(v.getTag(R.id.TYPE).toString(), pos)

                    deleteDialog(data)

                    return@OnLongClickListener true
                },
                AppConstant.TYPE_VIDEO_LIST
            )

            mBinding.rvVideoPlaylist.run {
                adapter = mPlaylistAdapter
                layoutManager =
                    LinearLayoutManager(this@PlayListActivity, LinearLayoutManager.VERTICAL, false)
                itemAnimator = DefaultItemAnimator()
            }
        }
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivBack.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.iv_back -> {
                onBackPressedDispatcher.onBackPressed()
            }

            R.id.con_main_playlist -> {
                when (val pos = v.tag as Int) {
                    0 -> {
                        newPlaylistDialog()
                    }

                    1 -> {
                        startActivity(Intent(this@PlayListActivity, FavoriteActivity::class.java))
                    }

                    else -> {
                        val data = getRecyclerVideoPlaylistData(v.getTag(R.id.TYPE).toString(), pos)
                        val intent = Intent(mActivity, PlaylistVideoActivity::class.java)
                        intent.putExtra(AppConstant.PLAYLIST_NAME, data.PlaylistName)
                        launchActivity(intent)
                    }
                }
            }
        }
    }

    private fun newPlaylistDialog() {
        val dialog = Dialog(mActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        val dialogBinding = NewPlaylistDialogBinding.inflate(LayoutInflater.from(mActivity))
        dialog.setContentView(dialogBinding.root)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        dialogBinding.ivCloseNewPlaylist.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()
        }

        dialogBinding.btnCreate.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            val db = VideoPlayerDatabase.getInstance(mActivity)
            val name = dialogBinding.etPlaylistName.text.toString().trim()
            if (name.isNotEmpty()) {
                val exists = db.videoPlaylistDao().isAdded(name)
                if (exists == 0) {
                    val playlist = VideoPlaylist(name)
                    db.videoPlaylistDao().insertPlaylist(playlist)
                    dialog.cancel()
                    dialog.dismiss()
                } else {
                    toast("Playlist name already exists")
                }
            } else {
                toast("Please enter playlist name")
            }
        }
        dialog.show()
    }

    private fun getRecyclerVideoPlaylistData(type: String, pos: Int): VideoPlaylist {
        var data: VideoPlaylist? = null
        when (type) {
            AppConstant.TYPE_VIDEO_LIST -> {
                data = mPlaylistAdapter!!.getItem(pos)
            }
        }
        return data!!
    }

    private fun deleteDialog(item: VideoPlaylist) {
        val dialog = Dialog(mActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        val dialogBinding = DeleteDialogBinding.inflate(LayoutInflater.from(mActivity))
        dialog.setContentView(dialogBinding.root)

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER

        dialog.window!!.attributes = lp
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        dialogBinding.tvDeleteItem.text = item.PlaylistName + "?"

        dialogBinding.ivCloseDelete.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()
        }

        dialogBinding.btnDelete.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            mDB.videoPlaylistDao().deletePlaylist(item.PlaylistName)
            mDB.videoDataDao().deletePlaylistVideoName(item.PlaylistName)
            dialog.cancel()
            dialog.dismiss()
        }

        dialog.show()
    }

    @Subscribe
    fun OnEvent(str: String?) {
        when (str) {
            AppConstant.EVENT_NOTIFY_PLAYLIST -> {
                if (mPlaylistAdapter != null) {
                    mPlaylistAdapter!!.notifyDataSetChanged()
                }
            }
        }
    }

}