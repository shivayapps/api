package com.mediaplayer.video.player.videoplayer.music.musicplayer

import android.app.Activity
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.util.Log
import androidx.multidex.MultiDexApplication
import code.name.monkey.appthemehelper.ThemeStore
import code.name.monkey.appthemehelper.util.VersionUtils
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.google.firebase.FirebaseApp
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.activity.SplashActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.NetworkChangeReceiver
import com.mediaplayer.video.player.videoplayer.music.musicplayer.appModules
import com.mediaplayer.video.player.videoplayer.music.musicplayer.appshortcuts.DynamicShortcutManager
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.WallpaperAccentManager
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import java.security.MessageDigest

class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
//class App : MultiDexApplication(){

    //raffaello
    private val wallpaperAccentManager = WallpaperAccentManager(this)

    override fun onCreate() {
        super.onCreate()

        instance = this

        startKoin {
            androidContext(this@App)
            modules(appModules)
        }

        if (!ThemeStore.isConfigured(this, 3)) {
            ThemeStore.editTheme(this)
                .accentColorRes(R.color.select_text_color)
                .coloredNavigationBar(true)
                .commit()
        }
        wallpaperAccentManager.init()

        if (VersionUtils.hasNougatMR())
            DynamicShortcutManager(this).initDynamicShortcuts()

        try {

            val filter = IntentFilter()
            filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
            registerReceiver(NetworkChangeReceiver(), filter)

            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())

                //Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }

        } catch (e: Exception) {

        }
        FirebaseApp.initializeApp(this)

        //firebase etc
        AdsConfig
            .builder()
            .setIsDebug(false)
            .isEnableAds(true)
            .isEnableOpenAds(true)
            .setTestDeviceId("")
            .setAdmobInterstitialAdId("ca-app-pub-2750800778809761/3979351497")
            .setAdmobInterClick(2)
            .setAdmobAppOpenId("ca-app-pub-2750800778809761/9896186298")
            .setAdmobBannerId("ca-app-pub-2750800778809761/1557202281")
            .setAdmobNativeId("ca-app-pub-2750800778809761/7286334827")
            .setAdmobRewardId("ca-app-pub-2750800778809761/3289086356")
//            .setAdmobRewardId("ca-app-pub-2750800778809761/1630683468")
            .build(this)
        setAppLifecycleListener(this)
        initMobileAds()
        OpenAdHelper.loadOpenAd(this)

        fireBaseConfigGet()
    }


    private fun fireBaseConfigGet() {
        try {
            val mFirebaseRemoteConfig: FirebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
            mFirebaseRemoteConfig.reset()
            //Setting Developer Mode enabled to fast retrieve the values
            mFirebaseRemoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(5)
                    .build()
            )
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_confing_defaults)
            mFirebaseRemoteConfig.fetchAndActivate()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.e("fireBaseConfigGet","isSuccessful")
                        mFirebaseRemoteConfig.activate()
                        val interAdClickCount: String =
                            mFirebaseRemoteConfig.getString("interAdClickCount")
                        val isAdEnable: Boolean = mFirebaseRemoteConfig.getBoolean("isAdEnable")
                        val isOpenAdEnable: Boolean =
                            mFirebaseRemoteConfig.getBoolean("isOpenAdEnable")
                        val admobInterstitialAdId: String =
                            mFirebaseRemoteConfig.getString("admobInterstitialAdId")
                        val admobAppOpenId: String =
                            mFirebaseRemoteConfig.getString("admobAppOpenId")
                        val admobBannerId: String = mFirebaseRemoteConfig.getString("admobBannerId")
                        val admobNativeId: String = mFirebaseRemoteConfig.getString("admobNativeId")
                        val admobRewardId: String = mFirebaseRemoteConfig.getString("admobRewardId")

                        Log.e("fireBaseConfigGet", "interAdClickCount:$interAdClickCount")
                        Log.e("fireBaseConfigGet", "isAdEnable:$isAdEnable")
                        Log.e("fireBaseConfigGet", "isOpenAdEnable:$isOpenAdEnable")
                        Log.e("fireBaseConfigGet", "admobInterstitialAdId:$admobInterstitialAdId")
                        Log.e("fireBaseConfigGet", "admobAppOpenId:$admobAppOpenId")
                        Log.e("fireBaseConfigGet", "admobBannerId:$admobBannerId")
                        Log.e("fireBaseConfigGet", "admobNativeId:$admobNativeId")
                        Log.e("fireBaseConfigGet", "admobRewardId:$admobRewardId")

                        if(!interAdClickCount.isNullOrEmpty()) Config.admobInterClick = Integer.parseInt(interAdClickCount)
                        if(isAdEnable!=null) Config.isAdsEnable = isAdEnable
//                        Config.isAdsEnable = false
                        if(isOpenAdEnable!=null) Config.isOpenAdEnable = isOpenAdEnable
//                        Config.isOpenAdEnable = false
                        if(!admobInterstitialAdId.isNullOrEmpty()) Config.admobInterstitialAdId = admobInterstitialAdId
                        if(!admobAppOpenId.isNullOrEmpty()) Config.admobAppOpenId = admobAppOpenId
                        if(!admobBannerId.isNullOrEmpty()) Config.admobBannerId = admobBannerId
                        if(!admobNativeId.isNullOrEmpty()) Config.admobNativeId = admobNativeId
                        if(!admobRewardId.isNullOrEmpty()) Config.admobRewardId = admobRewardId
                    } else {
                        Log.e("fireBaseConfigGet","taskFailed")
                    }
                }
        } catch (e: Exception) {
            Log.e("fireBaseConfigGet","Exception:$e")
            e.printStackTrace()
        }
    }

    override fun onTerminate() {
        super.onTerminate()

        wallpaperAccentManager.release()
    }

    companion object {
        private var instance: App? = null

        fun getContext(): App {
            return instance!!
        }

        fun isProVersion(): Boolean {
            return false
        }
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if(fCurrentActivity is SplashActivity) return false
        return true
    }

}
