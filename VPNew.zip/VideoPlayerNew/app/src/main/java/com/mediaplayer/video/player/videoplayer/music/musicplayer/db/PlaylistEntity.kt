
package com.mediaplayer.video.player.videoplayer.music.musicplayer.db

import android.os.Parcel
import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity
class PlaylistEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "playlist_id")
    val playListId: Long = 0,
    @ColumnInfo(name = "playlist_name")
    val playlistName: String
) :  Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readLong(),
        parcel.readString()!!
    )

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeLong(playListId);
        dest.writeString(playlistName);
    }

    companion object CREATOR : Parcelable.Creator<PlaylistEntity> {
        override fun createFromParcel(parcel: Parcel): PlaylistEntity {
            return PlaylistEntity(parcel)
        }

        override fun newArray(size: Int): Array<PlaylistEntity?> {
            return arrayOfNulls(size)
        }
    }
}
