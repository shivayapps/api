package com.mediaplayer.video.player.videoplayer.music.common.status

import android.view.LayoutInflater
import android.view.ViewGroup
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.common.status.adapter.StatusAdapter
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentPhotoStatusBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.hide
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.show
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData

//import com.hdplayer.playerview.videoplayerscreen.base.BaseBindingFragment
//import com.hdplayer.playerview.videoplayerscreen.databinding.FragmentPhotoStatusBinding
//import com.mediaplayer.video.player.videoplayer.music.common.status.adapter.StatusAdapter
//import com.hdplayer.playerview.videoplayerscreen.ui.model.VideoData
//import com.hdplayer.playerview.videoplayerscreen.utils.doHide
//import com.hdplayer.playerview.videoplayerscreen.utils.doVisible


class PhotoStatusFragment : BaseBindingFragment<FragmentPhotoStatusBinding>() {
    var photoStatusAdapter: StatusAdapter? = null
    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentPhotoStatusBinding {
        return FragmentPhotoStatusBinding.inflate(layoutInflater, container, false)
    }

    override fun initView() {
        super.initView()
        setNoData()
    }

    fun setAdapters(photoList: ArrayList<VideoData>) {
        if (photoList.size == 0) {
            mBinding.nodata.show()
            mBinding.rvPhotoStatusList.hide()
        } else {
            mBinding.nodata.hide()
            mBinding.rvPhotoStatusList.show()
            photoStatusAdapter = StatusAdapter(photoList, requireActivity(), requireContext(), 0) {}
            mBinding.rvPhotoStatusList.adapter = photoStatusAdapter
        }
    }

    fun setNoData() {
        mBinding.nodata.show()
        mBinding.rvPhotoStatusList.hide()
    }

}