package com.mediaplayer.video.player.videoplayer.music.common.status

import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingFragment
import com.mediaplayer.video.player.videoplayer.music.common.status.adapter.StatusAdapter
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant.Companion.FOLDER_WHATSAPP
import com.mediaplayer.video.player.videoplayer.music.databinding.FragmentPhotoDownloadBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.hide
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.show
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.FileUtils
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
import java.io.File
import java.util.concurrent.Executors

class PhotoDownloadFragment : BaseBindingFragment<FragmentPhotoDownloadBinding>() {

    private var photoList: ArrayList<VideoData> = ArrayList()
    private var photoDownloadAdapter: StatusAdapter? = null

    override fun setBinding(
        layoutInflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentPhotoDownloadBinding {
        return FragmentPhotoDownloadBinding.inflate(layoutInflater, container, false)
    }


    override fun initView() {
        super.initView()
        val path = FileUtils.getExternalStoragePublicDirectory(
            requireContext(),
            Environment.DIRECTORY_PICTURES
        ) + File.separator + getString(
            R.string.app_name
        ) + File.separator + FOLDER_WHATSAPP + "/Photo"
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            requireActivity().runOnUiThread { mBinding.progressCircular.visibility = View.VISIBLE }
            photoList = FileUtils.getAllList(path)
            requireActivity().runOnUiThread {
                mBinding.progressCircular.visibility = View.GONE
                if (photoList.size == 0) {
                    mBinding.nodata.show()
                    mBinding.rvPhotoDownloadList.hide()
                } else {
                    mBinding.nodata.hide()
                    mBinding.rvPhotoDownloadList.show()
                    photoDownloadAdapter =
                        StatusAdapter(photoList, requireActivity(), requireContext(), 3) {
                            mBinding.nodata.show()
                            mBinding.rvPhotoDownloadList.hide()
                        }
                    mBinding.rvPhotoDownloadList.adapter = photoDownloadAdapter
                }
            }
        }
    }

}