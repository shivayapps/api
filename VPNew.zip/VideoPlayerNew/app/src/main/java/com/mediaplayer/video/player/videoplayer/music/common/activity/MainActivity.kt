package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Parcel
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.BuildConfig
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.common.cropper.CropImage
import com.mediaplayer.video.player.videoplayer.music.common.cropper.CropImageView
import com.mediaplayer.video.player.videoplayer.music.common.gallery.entity.Album
import com.mediaplayer.video.player.videoplayer.music.common.gallery.entity.Item
import com.mediaplayer.video.player.videoplayer.music.common.gallery.entity.SelectionSpec
import com.mediaplayer.video.player.videoplayer.music.common.gallery.model.AlbumMediaCollection
import com.mediaplayer.video.player.videoplayer.music.common.gallery.utils.MimeType
import com.mediaplayer.video.player.videoplayer.music.common.status.StatusIntroActivity
import com.mediaplayer.video.player.videoplayer.music.common.status.WhatsappStatusActivity
import com.mediaplayer.video.player.videoplayer.music.common.status.WhatsappStatusDownloadActivity
import com.mediaplayer.video.player.videoplayer.music.common.utils.AppConstant
import com.mediaplayer.video.player.videoplayer.music.common.utils.asyncBackgroundWork
import com.mediaplayer.video.player.videoplayer.music.common.utils.getColorRes
import com.mediaplayer.video.player.videoplayer.music.common.utils.openURL
import com.mediaplayer.video.player.videoplayer.music.common.utils.redirectPlayStore
import com.mediaplayer.video.player.videoplayer.music.common.utils.shareApp
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityMainBinding
import com.mediaplayer.video.player.videoplayer.music.databinding.DialogUserInfoBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.ADAPTIVE_COLOR_APP
import com.mediaplayer.video.player.videoplayer.music.musicplayer.ALBUM_COVER_TRANSFORM
import com.mediaplayer.video.player.videoplayer.music.musicplayer.APPBAR_MODE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.BANNER_IMAGE_PATH
import com.mediaplayer.video.player.videoplayer.music.musicplayer.BLACK_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CAROUSEL_EFFECT
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CIRCLE_PLAY_BUTTON
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CIRCULAR_ALBUM_ART
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CUSTOM_FONT
import com.mediaplayer.video.player.videoplayer.music.musicplayer.DESATURATED_COLOR
import com.mediaplayer.video.player.videoplayer.music.musicplayer.EXTRA_SONG_INFO
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.HOME_ARTIST_GRID_STYLE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.KEEP_SCREEN_ON
import com.mediaplayer.video.player.videoplayer.music.musicplayer.LANGUAGE_NAME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.LIBRARY_CATEGORIES
import com.mediaplayer.video.player.videoplayer.music.musicplayer.MATERIAL_YOU
import com.mediaplayer.video.player.videoplayer.music.musicplayer.PROFILE_IMAGE_PATH
import com.mediaplayer.video.player.videoplayer.music.musicplayer.ROUND_CORNERS
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TAB_TEXT_MODE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_ADD_CONTROLS
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_FULL_SCREEN
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_GENRE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_HOME_BANNER
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_SEPARATE_LINE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_VOLUME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.USER_NAME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.WALLPAPER_ACCENT
import com.mediaplayer.video.player.videoplayer.music.musicplayer.activities.MusicSearchActivity
import com.mediaplayer.video.player.videoplayer.music.musicplayer.activities.SettingsActivity
import com.mediaplayer.video.player.videoplayer.music.musicplayer.db.toPlayCount
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.dip
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.extra
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.makeStatusBarTransparent
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragment.MusicMainFragment
import com.mediaplayer.video.player.videoplayer.music.musicplayer.fragments.LibraryViewModel
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.musicplayer.helper.MusicPlayerRemote
import com.mediaplayer.video.player.videoplayer.music.musicplayer.service.MusicService
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil
import com.mediaplayer.video.player.videoplayer.music.videoplayer.activity.VideoSearchActivity
import com.mediaplayer.video.player.videoplayer.music.videoplayer.adapter.ViewPagerAdapter
import com.mediaplayer.video.player.videoplayer.music.videoplayer.fragment.VideoMainFragment
import com.mediaplayer.video.player.videoplayer.music.videoplayer.model.VideoData
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.jetbrains.anko.backgroundColor
import org.koin.androidx.viewmodel.ext.android.viewModel
import java.lang.ref.WeakReference

class MainActivity() : BaseBindingActivity<ActivityMainBinding>(),
    SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        const val TAG = "MainActivity"
        const val EXPAND_PANEL = "expand_panel"
    }

    private var mVideoDataList: ArrayList<VideoData> = ArrayList()

    private val videoMainFragment: Fragment = VideoMainFragment.newInstance()

    private val musicMainFragment: Fragment = MusicMainFragment.newInstance()

    private var activeFragment = videoMainFragment

    private val libraryViewModel by viewModel<LibraryViewModel>()

    constructor(parcel: Parcel) : this() {
        receiverRegistered = parcel.readByte() != 0.toByte()
    }

    override fun getActivityContext(): FragmentActivity {
        return this@MainActivity
    }

    override fun setBinding(): ActivityMainBinding {
        return ActivityMainBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        EventBus.getDefault().register(this)
        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit =
            PreferenceManager.getDefaultSharedPreferences(App.getContext()).getInt(GENERAL_THEME, 0)

        makeStatusBarTransparent()

        if (editors == "theme_image") {
            val userImageTheme = RetroGlideExtension.getUserImageTheme(this@MainActivity)
            mBinding.mainBg.setImageDrawable(userImageTheme)
            mBinding.navBg.setImageDrawable(userImageTheme)
            mBinding.constraintLayout.background = null
            mBinding.tbMain.backgroundColor = getColorRes(R.color.bottomNavigation)
            mBinding.navView.background = null
        } else if (editors == "theme_gradient") {
            val userGradientTheme =
                AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.mainBg.setImageDrawable(userGradientTheme)
            mBinding.navBg.setImageDrawable(userGradientTheme)
            mBinding.constraintLayout.background = null
            mBinding.tbMain.backgroundColor = getColorRes(R.color.bottomNavigation)
            mBinding.navView.background = null
        } else if (edit >= 0) {
            mBinding.mainLayout.background = null
            mBinding.navBg.setImageDrawable(null)
        }

        mBinding.drawerLayoutMA.addDrawerListener(object : DrawerLayout.DrawerListener {
            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {

            }

            override fun onDrawerOpened(drawerView: View) {
                mBinding.navBg.scaleType = ImageView.ScaleType.CENTER_CROP
            }

            override fun onDrawerClosed(drawerView: View) {

            }

            override fun onDrawerStateChanged(newState: Int) {

            }
        })

        serviceToken = MusicPlayerRemote.bindToService(this, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                onServiceConnected()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                onServiceDisconnected()
            }
        })

        setUpViewPager()

        Handler().postDelayed({
            getVideo()
        }, 1000)

        Settings.Global.getString(contentResolver, "device_name")

        val profileName = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString("PROFILE_NAME", "User") // +getGreeting()

        mBinding.navHeader.tvMessage.text = profileName?.trim()
        mBinding.navHeader.tvMessage.isSelected = true
    }

    private lateinit var dialogUserInfoBinding: DialogUserInfoBinding

    private fun profileInfoDialog() {

        if (mBinding.drawerLayoutMA.isDrawerOpen(GravityCompat.START)) {
            mBinding.drawerLayoutMA.close()
        }

        dialogUserInfoBinding = DialogUserInfoBinding.inflate(LayoutInflater.from(mActivity))
        val dialog = Dialog(mActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(dialogUserInfoBinding.root)
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER
        dialog.window!!.attributes = lp
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)

        val profileName = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString("PROFILE_NAME", "User")

        dialogUserInfoBinding.name.setText(profileName)

        dialogUserInfoBinding.icClose.setOnClickListener {
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()
        }

        dialogUserInfoBinding.userImage.setOnClickListener {
            CropImage.activity().setGuidelines(CropImageView.Guidelines.ON)
                .setActivityTitle("Profile").setCropMenuCropButtonTitle("Crop").setAspectRatio(1, 1)
                .start(this)
        }

        dialogUserInfoBinding.btnSave.setOnClickListener {
            val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext()).edit()
            val profileName: String = dialogUserInfoBinding.name.text.toString()
            editors.putString("PROFILE_NAME", profileName)
            editors.apply()

            mBinding.navHeader.tvMessage.text = dialogUserInfoBinding.name.text
            dialog.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
            dialog.cancel()
            dialog.dismiss()
        }
        dialog.show()

    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.ivDrawerMenu.setOnClickListener(this)
        mBinding.ivSearch.setOnClickListener(this)
        mBinding.ivOptions.setOnClickListener(this)
        mBinding.navMenu.navStatusSaver.setOnClickListener(this)
        mBinding.navMenu.navDownload.setOnClickListener(this)
        mBinding.navMenu.navSetting.setOnClickListener(this)
        mBinding.navMenu.navHidden.setOnClickListener(this)
        mBinding.navMenu.navTerm.setOnClickListener(this)
        mBinding.navMenu.navShare.setOnClickListener(this)
        mBinding.navMenu.navShare.setOnClickListener(this)
        mBinding.navMenu.navRate.setOnClickListener(this)
        mBinding.navMenu.navPrivacy.setOnClickListener(this)
        mBinding.navMenu.navTheme.setOnClickListener(this)
        mBinding.navMenu.navLanguage.setOnClickListener(this)
        mBinding.navMenu.navEqualizer.setOnClickListener(this)

        mBinding.navMenu.checkDarkMode.isChecked = PreferenceUtil.isBlackMode
        mBinding.navMenu.txtVersion.text = BuildConfig.VERSION_NAME

        mBinding.tbMain.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> {
                        activeFragment = videoMainFragment
                        mBinding.tvFmName.text = getString(R.string.video)
                        mBinding.ivOptions.visibility = View.VISIBLE
                        mBinding.ivSearch.visibility = View.VISIBLE
                    }

                    1 -> {
                        activeFragment = musicMainFragment
                        mBinding.tvFmName.text = getString(R.string.music)
                        mBinding.ivOptions.visibility = View.VISIBLE
                        mBinding.ivSearch.visibility = View.VISIBLE
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {

            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }
        })
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {

            R.id.iv_drawer_menu -> {
                mBinding.drawerLayoutMA.open()
            }

            R.id.iv_search -> {
                if (mBinding.vpMain.currentItem == 0) {
                    VideoSearchActivity.mVideoData.removeAll(VideoSearchActivity.mVideoData.toSet())
                    VideoSearchActivity.mVideoData.addAll(mVideoDataList)
                    val intent = Intent(mActivity, VideoSearchActivity::class.java)
                    launchActivity(intent)
                } else if (mBinding.vpMain.currentItem == 1) {
                    val intent = Intent(mActivity, MusicSearchActivity::class.java)
                    launchActivity(intent)
                }
            }

            R.id.iv_options -> {
                val intent = Intent(this@MainActivity, ThemeActivity::class.java)
                launchActivity(intent)
            }

            R.id.navHidden -> {
                startActivity(Intent(this@MainActivity, LockActivity::class.java))
            }

            R.id.tvMessage -> {
                profileInfoDialog()
            }

            R.id.navStatusSaver -> {
                if (PreferenceUtil.whatsAppShowIntro) {
                    val intent = Intent(this@MainActivity, WhatsappStatusActivity::class.java)
                    launchActivity(intent)
                } else {
                    val intent = Intent(this@MainActivity, StatusIntroActivity::class.java)
                    launchActivity(intent)
                }
            }

            R.id.navDownload -> {
                val intent = Intent(this@MainActivity, WhatsappStatusDownloadActivity::class.java)
                launchActivity(intent)
            }

            R.id.navSetting -> {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }

            R.id.navTheme -> {
                mBinding.navMenu.checkDarkMode.toggle()
                PreferenceUtil.isBlackMode = mBinding.navMenu.checkDarkMode.isChecked
                if (mBinding.navMenu.checkDarkMode.isChecked) {
                    recreate()
                    overridePendingTransition(R.anim.slide_from_top, R.anim.slide_in_top)
                } else {
                    recreate()
                    overridePendingTransition(R.anim.slide_in_top, R.anim.slide_from_top)
                }
            }

            R.id.navLanguage -> {
//                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }

            R.id.navEqualizer -> {
//                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }

            R.id.navShare -> {
                shareApp()
            }

            R.id.navRate -> {
                redirectPlayStore()
            }

            R.id.navPrivacy -> {
                openURL(getString(R.string.privacy_policy_url))
            }
        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)

        if (requestCode == 123 && resultCode == RESULT_OK) {
            callActivity()
        }
    }

    private var mViewPagerAdapter: ViewPagerAdapter? = null

    private fun setUpViewPager() {
        mViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        mViewPagerAdapter?.addFragment(videoMainFragment, "Video")
        mViewPagerAdapter?.addFragment(musicMainFragment, "Music")

        mBinding.vpMain.adapter = mViewPagerAdapter
        mBinding.vpMain.offscreenPageLimit = 4
        mBinding.vpMain.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(mBinding.tbMain))
        mBinding.tbMain.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                mBinding.vpMain.currentItem = tab?.position!!
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {

            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        PreferenceUtil.unregisterOnSharedPreferenceChangedListener(this)
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }
    }

    private fun getVideo() {
        val mSelectionSpec = SelectionSpec.getCleanInstance()
        mSelectionSpec.mimeTypeSet = MimeType.ofVideo()
        mSelectionSpec.mediaTypeExclusive = true
        mSelectionSpec.maxSelectable = 5
        mSelectionSpec.showPreview = false
        mSelectionSpec.showSingleMediaType = true
        mSelectionSpec.orientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val mAlbumMediaCollection = AlbumMediaCollection()
        mAlbumMediaCollection.onCreate(this, object : AlbumMediaCollection.AlbumMediaCallbacks {
            override fun onAlbumMediaLoad(cursor: Cursor?) {
                mVideoDataList.removeAll(mVideoDataList.toSet())
                asyncBackgroundWork({}, {
                    if (cursor != null && cursor.count > 0) {
                        cursor.moveToFirst()
                        do {
                            val item = Item.valueOf(cursor)
                            if (item.bucketName != null && item.name != null) {
                                val video = VideoData(
                                    item.path,
                                    item.pathID,
                                    item.bucketName,
                                    item.name,
                                    item.date * 1000,
                                    item.mimeType ?: "mp4",
                                    item.size,
                                    item.duration,
                                    item.width,
                                    item.height
                                )
                                mVideoDataList.add(video)
                            } else {
                                val video = VideoData(
                                    item.path,
                                    item.pathID,
                                    "Internal",
                                    "Empty",
                                    item.date * 1000,
                                    item.mimeType ?: "mp4",
                                    item.size,
                                    item.duration,
                                    item.width,
                                    item.height
                                )
                                mVideoDataList.add(video)
                            }
                        } while (cursor.moveToNext())
                    }
                }, {
                    mAlbumMediaCollection.onDestroy()
                    (videoMainFragment as VideoMainFragment).setVideo(mVideoDataList)
                })
            }

            override fun onAlbumMediaReset() {

            }
        })

        mAlbumMediaCollection.load(
            Album(Album.ALBUM_ID_ALL, null, Album.ALBUM_ID_ALL, 0), mSelectionSpec.capture
        )
    }

    override fun onServiceConnected() {
        if (!receiverRegistered) {
            musicStateReceiver = MusicStateReceiver(this)

            val filter = IntentFilter()
            filter.addAction(MusicService.PLAY_STATE_CHANGED)
            filter.addAction(MusicService.SHUFFLE_MODE_CHANGED)
            filter.addAction(MusicService.REPEAT_MODE_CHANGED)
            filter.addAction(MusicService.META_CHANGED)
            filter.addAction(MusicService.QUEUE_CHANGED)
            filter.addAction(MusicService.MEDIA_STORE_CHANGED)
            filter.addAction(MusicService.FAVORITE_STATE_CHANGED)

            registerReceiver(musicStateReceiver, filter)

            receiverRegistered = true
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceConnected()
        }
        if (MusicPlayerRemote.playingQueue.isNotEmpty()) {
            if (musicMainFragment.isAdded) {
                (musicMainFragment as MusicMainFragment).hideBottomSheet(false)
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)
        val expand = intent?.extra<Boolean>(EXPAND_PANEL)?.value ?: false

        if (expand && PreferenceUtil.isExpandPanel) {
            intent?.removeExtra(EXPAND_PANEL)
        }
    }

    private fun callActivity() {
        AppConstant.LAYOUT_TYPE = 0
        val intent: Intent = intent
        launchActivity(intent)
        finishAffinity()
    }

    private var musicStateReceiver: MusicStateReceiver? = null

    class MusicStateReceiver(activity: MainActivity) : BroadcastReceiver() {

        val reference: WeakReference<MainActivity> = WeakReference(activity)

        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            val activity = reference.get()
            if (activity != null && action != null) {
                when (action) {
                    MusicService.FAVORITE_STATE_CHANGED -> activity.onFavoriteStateChanged()
                    MusicService.META_CHANGED -> activity.onPlayingMetaChanged()
                    MusicService.QUEUE_CHANGED -> activity.onQueueChanged()
                    MusicService.PLAY_STATE_CHANGED -> activity.onPlayStateChanged()
                    MusicService.REPEAT_MODE_CHANGED -> activity.onRepeatModeChanged()
                    MusicService.SHUFFLE_MODE_CHANGED -> activity.onShuffleModeChanged()
                    MusicService.MEDIA_STORE_CHANGED -> activity.onMediaStoreChanged()
                }
            }
        }
    }

    override fun onServiceDisconnected() {
        if (receiverRegistered) {
            unregisterReceiver(musicStateReceiver)
            receiverRegistered = false
        }

        for (listener in mMusicServiceEventListeners) {
            listener.onServiceDisconnected()
        }
    }

    override fun onQueueChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onQueueChanged()
        }
        libraryViewModel.setFabMargin(dip(R.dimen.bottom_nav_height))
    }

    override fun onPlayingMetaChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayingMetaChanged()
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val entity = repository.songPresentInHistory(MusicPlayerRemote.currentSong)
            if (entity != null) {
                repository.updateHistorySong(MusicPlayerRemote.currentSong)
            } else {
                repository.addSongToHistory(MusicPlayerRemote.currentSong)
            }
            val songs = repository.checkSongExistInPlayCount(MusicPlayerRemote.currentSong.id)
            if (songs.isNotEmpty()) {
                repository.updateSongInPlayCount(songs.first().apply {
                    playCount += 1
                })
            } else {
                repository.insertSongInPlayCount(MusicPlayerRemote.currentSong.toPlayCount())
            }
        }
    }

    override fun onPlayStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onPlayStateChanged()
        }
    }

    override fun onRepeatModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onRepeatModeChanged()
        }
    }

    override fun onShuffleModeChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onShuffleModeChanged()
        }
    }

    override fun onFavoriteStateChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onFavoriteStateChanged()
        }
    }

    override fun onMediaStoreChanged() {
        for (listener in mMusicServiceEventListeners) {
            listener.onMediaStoreChanged()
        }
    }

    override fun onSharedPreferenceChanged(p0: SharedPreferences?, key: String?) {
        if (key == MATERIAL_YOU || key == WALLPAPER_ACCENT || key == BLACK_THEME || key == ADAPTIVE_COLOR_APP || key == USER_NAME || key == TOGGLE_FULL_SCREEN || key == TOGGLE_VOLUME || key == ROUND_CORNERS || key == CAROUSEL_EFFECT || key == TOGGLE_GENRE || key == BANNER_IMAGE_PATH || key == PROFILE_IMAGE_PATH || key == CIRCULAR_ALBUM_ART || key == KEEP_SCREEN_ON || key == TOGGLE_SEPARATE_LINE || key == TOGGLE_HOME_BANNER || key == TOGGLE_ADD_CONTROLS || key == HOME_ARTIST_GRID_STYLE || key == ALBUM_COVER_TRANSFORM || key == DESATURATED_COLOR || key == EXTRA_SONG_INFO || key == TAB_TEXT_MODE || key == LANGUAGE_NAME || key == LIBRARY_CATEGORIES || key == CUSTOM_FONT || key == APPBAR_MODE || key == CIRCLE_PLAY_BUTTON) {
            postRecreate()
        }
    }

    @Subscribe
    fun OnEvent(str: String?) {
        when (str) {
            "getVideo" -> {
                getVideo()
            }
        }
    }

}