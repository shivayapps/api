package com.mediaplayer.video.player.videoplayer.music.common.rateandfeedback

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.mediaplayer.video.player.videoplayer.music.R

private val TAG = "ExitDialogs"

var RATING = -1

fun Context.exitDialog() {
    try {
        val inflater = (this as Activity).layoutInflater
        val alertLayout = inflater.inflate(R.layout.layout_dialog_exit, null)
        val tvTitle = alertLayout.findViewById<TextView>(R.id.exit_tv_title)
        val tvDesc = alertLayout.findViewById<TextView>(R.id.exit_tv_desc)
        val btnNo = alertLayout.findViewById<TextView>(R.id.exit_btn_no)
        val btnYes = alertLayout.findViewById<TextView>(R.id.exit_btn_yes)
//        val tf = Typeface.createFromAsset(assets, fontPath)
//        val tfBold = Typeface.createFromAsset(assets, fontPathBold)
//        tvTitle.typeface = tfBold
//        tvDesc.typeface = tf
//        btnNo.typeface = tf
//        btnYes.typeface = tf

//        val adContainer = alertLayout.findViewById<FrameLayout>(R.id.ad_view_container)
        val alert = AlertDialog.Builder(this)
        alert.setView(alertLayout)
        alert.setCancelable(false)
        val dialog = alert.create()
        btnNo.setOnClickListener { dialog.dismiss() }
        btnYes.setOnClickListener {
            ExitSPHelper(this).updateExitCount()
            dialog.dismiss()
//            nextScreen();
            finishAffinity()
        }
        dialog.show()


    } catch (ignored: Exception) {
        Log.e(TAG, ignored.toString())
    }
}


fun Context.nextScreen() {
    val activity: AppCompatActivity = this as AppCompatActivity
    activity.finishAffinity()

//    val i = Intent(this@nextScreen, ExitActivity::class.java)
//    startActivity(i)

}



fun Context.rateApp() {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
    } catch (anfe: ActivityNotFoundException) {
        Log.e(TAG, anfe.toString())
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
    }
}

interface OnRateListener {
    fun onRate(rate: Int)
}