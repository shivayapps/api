package com.mediaplayer.video.player.videoplayer.music.common.activity

import android.content.Intent
import android.content.SharedPreferences
import android.view.View
import androidx.appcompat.content.res.AppCompatResources
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import com.mediaplayer.video.player.videoplayer.music.R
import com.mediaplayer.video.player.videoplayer.music.common.base.BaseBindingActivity
import com.mediaplayer.video.player.videoplayer.music.databinding.ActivityGetstartedBinding
import com.mediaplayer.video.player.videoplayer.music.musicplayer.ADAPTIVE_COLOR_APP
import com.mediaplayer.video.player.videoplayer.music.musicplayer.ALBUM_COVER_TRANSFORM
import com.mediaplayer.video.player.videoplayer.music.musicplayer.APPBAR_MODE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.App
import com.mediaplayer.video.player.videoplayer.music.musicplayer.BANNER_IMAGE_PATH
import com.mediaplayer.video.player.videoplayer.music.musicplayer.BLACK_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CAROUSEL_EFFECT
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CIRCLE_PLAY_BUTTON
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CIRCULAR_ALBUM_ART
import com.mediaplayer.video.player.videoplayer.music.musicplayer.CUSTOM_FONT
import com.mediaplayer.video.player.videoplayer.music.musicplayer.DESATURATED_COLOR
import com.mediaplayer.video.player.videoplayer.music.musicplayer.EXTRA_SONG_INFO
import com.mediaplayer.video.player.videoplayer.music.musicplayer.GENERAL_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.HOME_ARTIST_GRID_STYLE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.IMAGE_THEME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.KEEP_SCREEN_ON
import com.mediaplayer.video.player.videoplayer.music.musicplayer.LANGUAGE_NAME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.LIBRARY_CATEGORIES
import com.mediaplayer.video.player.videoplayer.music.musicplayer.MATERIAL_YOU
import com.mediaplayer.video.player.videoplayer.music.musicplayer.PROFILE_IMAGE_PATH
import com.mediaplayer.video.player.videoplayer.music.musicplayer.ROUND_CORNERS
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TAB_TEXT_MODE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_ADD_CONTROLS
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_FULL_SCREEN
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_GENRE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_HOME_BANNER
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_SEPARATE_LINE
import com.mediaplayer.video.player.videoplayer.music.musicplayer.TOGGLE_VOLUME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.USER_NAME
import com.mediaplayer.video.player.videoplayer.music.musicplayer.WALLPAPER_ACCENT
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.resolveColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setDrawBehindSystemBars
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setImmersiveFullscreen
import com.mediaplayer.video.player.videoplayer.music.musicplayer.extensions.setStatusBarColor
import com.mediaplayer.video.player.videoplayer.music.musicplayer.glide.RetroGlideExtension
import com.mediaplayer.video.player.videoplayer.music.musicplayer.util.PreferenceUtil

class GetStartedActivity : BaseBindingActivity<ActivityGetstartedBinding>(),
    SharedPreferences.OnSharedPreferenceChangeListener {

    override fun getActivityContext(): FragmentActivity {
        return this@GetStartedActivity
    }

    override fun setBinding(): ActivityGetstartedBinding {
        return ActivityGetstartedBinding.inflate(layoutInflater)
    }

    override fun initView() {
        super.initView()
        PreferenceUtil.registerOnSharedPreferenceChangedListener(this)

        if (PreferenceUtil.isFullScreenMode) {
            setDrawBehindSystemBars()
        } else {
            setImmersiveFullscreen()
        }

        val editors = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getString(IMAGE_THEME, "")
        val edit = PreferenceManager.getDefaultSharedPreferences(App.getContext())
            .getInt(GENERAL_THEME, 0)

        setStatusBarColor(resolveColor(R.attr.mainBackgroundColor))

        if (editors == "theme_image") {
            val userImageTheme = RetroGlideExtension.getUserImageTheme(this@GetStartedActivity)
            mBinding.imgBackground.setImageDrawable(userImageTheme)
            mBinding.constraintLayout.background = null
        } else if (editors == "theme_gradient") {
            val userGradientTheme = AppCompatResources.getDrawable(this, RetroGlideExtension.getUserGradientTheme())
            mBinding.imgBackground.setImageDrawable(userGradientTheme)
            mBinding.constraintLayout.background = null
        } else if (edit >= 0) {
            mBinding.imgBackground.setImageDrawable(null)
        }
    }

    override fun initViewListener() {
        super.initViewListener()
        mBinding.btnPermission.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.btn_permission -> {
                val intent = Intent(mActivity, PermissionActivity::class.java)
                launchActivity(intent, true)
            }
        }
    }

    override fun onSharedPreferenceChanged(p0: SharedPreferences?, key: String?) {
        if (key == MATERIAL_YOU || key == WALLPAPER_ACCENT || key == BLACK_THEME || key == ADAPTIVE_COLOR_APP || key == USER_NAME || key == TOGGLE_FULL_SCREEN || key == TOGGLE_VOLUME || key == ROUND_CORNERS || key == CAROUSEL_EFFECT || key == TOGGLE_GENRE || key == BANNER_IMAGE_PATH || key == PROFILE_IMAGE_PATH || key == CIRCULAR_ALBUM_ART || key == KEEP_SCREEN_ON || key == TOGGLE_SEPARATE_LINE || key == TOGGLE_HOME_BANNER || key == TOGGLE_ADD_CONTROLS || key == HOME_ARTIST_GRID_STYLE || key == ALBUM_COVER_TRANSFORM || key == DESATURATED_COLOR || key == EXTRA_SONG_INFO || key == TAB_TEXT_MODE || key == LANGUAGE_NAME || key == LIBRARY_CATEGORIES || key == CUSTOM_FONT || key == APPBAR_MODE || key == CIRCLE_PLAY_BUTTON) {
            postRecreate()
        }
    }
}