package com.android.i18n.phonenumbers;

public class Phonenumber {
    public static class PhoneNumber {
    }
}
