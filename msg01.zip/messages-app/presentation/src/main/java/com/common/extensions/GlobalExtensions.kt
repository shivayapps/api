package com.common.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
