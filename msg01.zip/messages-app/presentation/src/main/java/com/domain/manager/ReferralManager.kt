package com.domain.manager

interface ReferralManager {

    fun trackReferrer()

}
