Changelog
==========

Version 1.0.26 *(2021-12-17)*
----------------------------

 * ADs Chnages

   Devloper Name :  Priyanka Vadadoriya

   - Add Admodule
   - set All ID From Firbase and Add Back IDS
   - Banner Ads Handling with Firbase Handling
   - Interstital Ads Handling with Firbase Handling
   - Home Screen Interstital Ad
   - Open Ads On Splash  / Onresume Put

 *  Functionality

    Devloper Name :  Parth Board

   - Change All Functionality using new Gallery Code From Github
   - Story Problem Solved
   - Subscription Add
   - Billing Add For already Purchased User
   - Change Design Of Whole App Like Old
   - Chnage Theme Problem Solve
   - set Daily Notification Task
   - All Common Code Add
   
* Version 1.0.30

   Developer Name :  Parth Borad

  - Crash Solving from v1.0.29
  - Rename Media File (Fixed)
  - Bug Invalid Image Open (Fixed)


* Version 1.0.31

 Developer Name :  Parth Borad ,Priyanka , Pradip Chauhan , Arti Thesiya

  - Crash Solving from v1.0.30


* Version 1.0.32

Developer Name :  Ravi Sir , Priyanka Vadadoriya, Arti Thesiya

  - Crash Solving from v1.0.31

* Version 1.0.34

Developer Name :  Parth Borad

  - Crash Solving from v1.0.33
  - Copy/Move/Rename operation on single as well as multiple media files (Fixed). 
  - Multiple pop-ups on share buttons (Fixed).
  - Dynamic subscription UI as well as other necessary changes.
  - No Filter Selected,while unchecked all the filter message to user.
  - No Item found while search, message to user.
  - Cursor of searchView and placeholder not visible on app opens for the first time (Fixed).
  - Duplicate image not deleting issue (Fixed).
  - Unnecessary sections on settings removed.
  

* Version 1.0.35

Developer Name :  Jhanvi Vataliya

  - ReloadOpenAd with admob
  - Separate main Interstitial ID

* Version 1.0.36

Developer Name : Parth Borad

  - Show Subscription Activity if firebase variable is true.
  - Immediate firebase data fetching on internet available.
  - Ads related changes according to the policy.
  - All default id replaced as given.
  - 1833, 1894 back button bug fixed & Default IDs of ID changes reverted.
  - 1832 exit app on permission deny.
  - 1846 all the crashes of version 1.35 reviewed and solved
  - Necessary proguard added, minify enabled.
  - 1852 dedicated activity for theme changes.
  - 1853 exit bug solved.
  - Updated sdk 31 
  - Mediation added
  - 1895 multi-touch in open camera ALbumFragment.
  - 1893 Permission text was showing even after the permission is given.
  - 1892 settings ad spacing below "try premium".
  - Coloring issues in Ads while altering theme mode in Ads (ThemeActivity, In the Stories Activities, Exit Dialog).
  - 1897 EditActivity 3 buttons name in the bottom is trimming
  - 1924 Subscription related UI component changes on Internet off
  - 1927 Interstitial Ad after Allow/Deny Permission 
  - Gradle Dependencies utilized 
  - Ads Module changes (code utilization)
  - 1928 stories data wasn't visible after opens the app from the pause state with permission given (which is denied for the first time)
  - InAppUpdate added

* Version 1.0.37

Developer Name : Parth Borad

  - MainActivity Ad is still showing after the successful subscription without the loading dialog.
  - Drawer header update on successful subscription.

* Version 1.0.38

Developer Name : Parth Borad

- Firebase Handle in Drawer as well as Home Screen Ad.
- Native Ad color on secondary Text (#808080).
- Remove Ads button added in options menu top right.

* Version 1.0.39

(Developer Name :- Priyanka Vadodariya , Arti Thesiya)

- Code Review Of Ads Loading Methods and Change the code
- Rejected Reason :- Subscriptions policy

* Version V1.0.40

(Developer Name :- Arti Thesiya)

- Change Drawer Subscription Price text [Get Permium Version]


* Version V1.0.41

(Developer Name :- Parth Board , Arti Thesiya)

- remove Splash Open Ad Timer
- remove Home Screen Int Ad and add On Skip btn
- fixed show two times Open Ad
- set Window Bg Color 
- add Event of Starting App Flow

* Version V1.0.42

(Developer Name :- Jayesh Dankhara , Arti Thesiya)

- Version +
- Check Events
- Solved two times show open ad in Splash
- Solved App not Open when openAd Not load
- Solved Light/Dark radio button are displayed selected when user change the dark/light mode from system


* Version V1.0.43 

(Developer Name :- Arti Thesiya)

- Decrese Firebase config version 


* Version V1.0.44

(Developer Name :- Arti Thesiya)

- Decrese Firebase config version
- declare google ad activity in manifest file


* Version V1.0.47
(Developer Name :- Hardik Antaliya)
- Remove Native ads from stories (Change Due to Admob restrictive policy)
- Give above line on native/banner ads (Divider)
- Remove open ads on allow/deny dialog delete/Rename Dialog (where open system dialogue in app) (Change Due to Admob restrictive policy)
- Showing Ad dialog before intertial ads on Albums every 5 click 
- From Setting Remove 3 scrolling ads and put Banner/native on Bottom (Change Due to Admob restrictive policy)
- onresume open ads put in handle : is_openAdshow_on_resume (Change Due to Admob restrictive policy)


* Version V1.0.48
(Change Due to Admob restrictive policy)
(Developer Name :- Hardik Antaliya)
-Replace splash app_open ad to int ad (splash -> int -> home) with control From Firebase with variable -  splash_interstitial_enable
-exit app interstitial ad will be in our control and value will be “false” int default remote config(remote_config_default.xml) - is_back_button_ad_enable
-create folder(plus icon in home screen) interstitial ad in our control - create_folder_ad_enable
-album every 5 click Ad show in control -is_five_click_item_ad_enable
- Subscription Activity skip button had interstitial ad  which is now in firebase control value will be “false” int default remote config(remote_config_default.xml) -is_homescreen_interstitial_enable
  due to (v1.0.48->1 issue)

* Version V1.0.49
(Change Due to High rate of Crashes)
(Developer Name :- Hardik Antaliya)
-Removed all GlobalScope From app
-also Added new Code For InterStitial ad holding Splash Screen 

* Version V1.0.50
* (Change Due to Ad  restrictive policy)
* (Developer Name :- Jayesh Dankhara,Priyanka Vadodariya)
-changed verion v.1.0.49 to v.1.0.50


* Version V1.0.51
* (Change Due to Ad  restrictive policy)
* (Developer Name :- Hardik Antaliya,Priyanka Vadodariya)
-Added Firebase dynamic varaibble to control ads at ->
1. is_setting_banner_enabled  : true/false //control banner in Setting
2.is_album_item_preview_screen_banner_enabled :: true/false //control banner in MediaScreen
3.is_theme_screen_big_native_enabled :: true/false // for ThemeScreen native control Manage  :
4.is_home_exit_big_native_enabled :: true/false // for OnBackPress native control Manage  :
5.is_homescreen_drawer_setting_interstitial_enable::true/false  //for homescreen drawer setting
6.is_homescreen_drawer_favourite_interstitial_enable ::true/false //for homescreen drawer favourite
2. from_inside_setting_click_interstitial_enable::true/false   //for goes to setting from inside menu
8.is_full_image_edit_click_interstial_enable ::true/false //for fullImage(VideoPagerActivity) edit int manage
9.is_full_image_delete_interstial_enable ::true/false  //for fullImage(VideoPagerActivity) delete int manage
10.is_thememode_changing_interstitial_enable  ::true/false  //For light/dark button click ad control in themeActivity
11.is_from_album_item_preview_delete_interstitial_enable::true/false  //selected item Delete int control in DirectoryAdapter
---------------------by default all variables are false------------------
-changed version V.1.0.50 to V.1.0.51


* Version V1.0.52
* (Change Due to Ad  restrictive policy)
* (Developer Name :- Hardik Antaliya,Priyanka Vadodariya)
  -changed verion v.1.0.51 to v.1.0.52
--------------------------------------------------------------
* Version V1.0.53
* (Change Due to Ad  restrictive policy)
* (Developer Name :- Hardik Antaliya,Priyanka Vadodariya)
  -changed verion v.1.0.52 to v.1.0.53

---------------------------------------------------------------
* Version V1.0.54
* (Developer Name :- Hardik Antaliya,Priyanka Vadodariya)
  -changed verion v.1.0.53 to v.1.0.54

---------------------------------------------------------------
* Version V1.0.55
* (Change Due to Ad  restrictive policy)
* (Developer Name :- Hardik Antaliya,Jayesh Dankhara,Priyanka Vadodariya)
  -Added FirebaseAnalytics Event For Ads
  - remove All native adcode from whole project
  -remove all mediation library from whole project.
  - added FirebasConfig variable(inAppSubscriptionenabled) at welRecycleBinActivity  to handle SubscriptionActivity.
  -updated bumping version V.1.0,54 to V.1.055
  - 
---------------------------------------------------------------
* Version V1.0.56
* (Change Due to All Media Storage access Permissiomn)
* (Developer Name :- Hardik Antaliya,Priyanka Vadodariya)
  -Added Permission Screen For All media access permission
  -removed All Intro Activity
    - Added New Setting UI
    - Added Hidden files shows in Drawer
    - Added New pattern for (on back button Click)
    - Added New ThemeDialog
    - Added New  Feature in Edit Screen
    - Added New Lottie in duplicate image Activity
    - Added New Exit Dialog with medium rectangle banner ad
    - removed all native ad code from project due to ads issue
    - Added Collapsive banner ad at themeActivity
    - Added interstitial ad in StatusActivity( on back and close layout)
    - Change Ui of title bar main screen
    - changed version v.1.0.55 to v.1.0.56

---------------------------------------------------------------

*Version V1.0.57
*(Change Due to All Media Storage access Permission)
*(Developer Name :- Hardik Antaliya,Priyanka Vadodariya)
  -Add MobileAd Initialised
  -Add ThemeActivity changes
  -Add BottomSheet Dialog on App Exit
  -Add interstitial add with new approach
  -Add Firebase config Variables and prevent open ads
  -Remove all clicks InterstitialAd showing code with old approach
  -changed version v.1.0.56 to v.1.0.57

---------------------------------------------------------------

* Version V1.0.58
* (Change Due to All Media Storage access Permission)
* (Developer Name :- Hardik Antaliya,Priyanka Vadodariya)
  -Removed _x from AdConstant.is_openAdshow_on_resume
  -changed version v.1.0.57 to v.1.0.58
