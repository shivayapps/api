package albums.gallery.photo.folder.picasa.app.web.gallery;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.net.ConnectivityManager;
import android.util.Log;

import com.google.firebase.remoteconfig.FirebaseRemoteConfig;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.Config;
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys;

public class FirebaseConfigHelper {

    public static FirebaseRemoteConfig remoteConfig = FirebaseRemoteConfig.getInstance();


    //Ads Ids From Firebase
    public static String admob_app_open = "admob_app_open";
    public static String admob_open_ads = "admob_open_ads";  // old
    public static String back_admob_open_ads = "back_admob_open_ads";
    public static String admob_banner = "AD_B";
    public static String admob_back_banner = "AD_B_BACK";
//    public static String admob_native = "AD_N";
//    public static String admob_back_native = "AD_N_BACK";
//    public static String story_native_ad_back = "story_native_ad_back";
    public static String admob_int = "AD_I";
    public static String admob_int_album_click = "admob_int_album_click";
    public static String admob_back_int = "AD_I_BACK";
    public static String admob_rewared = "AD_R";
    public static String admob_back_rewared = "AD_R_BACK";
    public static String admob_rewared_int = "AD_R_INTERSTITAL";
    public static String admob_back_rewared_int = "AD_R_INTERSTITAL_BACK";
//    public static String story_native_ad = "story_native_ad";
    private static String admob_splash_interstitial = "admob_splash_interstitial";
    private static String admob_back_splash_interstitial = "admob_back_splash_interstitial";


    //For Back Id Controls
    public static String back_id_required = "back_id_required";

    // For Banner Controls
    public static String is_home_screen_banner_enabled = "is_home_screen_banner_enabled";   // for HomeScreen Banner Manage  :
    public static String is_setting_banner_enabled = "is_setting_banner_enabled";    // for Setting Banner Manage  :
    public static String is_album_item_preview_screen_banner_enabled = "is_album_item_preview_screen_banner_enabled";    // for MediaScreen Banner Manage  :
    public static String admob_banner_control_home = "admob_banner_control_home";    // for HomeScreen Banner Manage Types :
    public static String admob_banner_control = "admob_banner_control"; //banner / smart_banner / adaptive_banner


    //removed
    public static String is_theme_screen_big_native_enabled = "is_theme_screen_big_native_enabled";   // for ThemeScreen native Manage  :     //removed
    public static String is_home_exit_big_native_enabled = "is_home_exit_big_native_enabled";   // for onBackpress native Manage  :          //removed
    public static String is_homescreen_interstitial_enable = "is_homescreen_interstitial_enable";                                            //removed
    public static String is_homescreen_drawer_setting_interstitial_enable = "is_homescreen_drawer_setting_interstitial_enable";             //removed
    public static String is_homescreen_drawer_favourite_interstitial_enable = "is_homescreen_drawer_favourite_interstitial_enable";         //removed
    public static String from_inside_setting_click_interstitial_enable = "from_inside_setting_click_interstitial_enable";          //removed
    public static String is_full_image_edit_click_interstial_enable = "is_full_image_edit_click_interstial_enable"; // edit button intestitial manage   //removed
    public static String is_full_image_delete_interstial_enable = "is_full_image_delete_interstial_enable"; // delete button intestitial manage         //removed
    public static String is_five_click_item_ad_enable = "is_five_click_item_ad_enable";     //removed
    public static String is_back_button_ad_enable = "is_back_button_ad_enable";       //removed



    // for all Screen Interstitial Manage  :
    public static String admob_interstitial_control = "admob_interstitial_control"; //admob_int / admob_rewared / admob_rewared_int

    //For Homescreen Interstitial Show or not

    //for all drawer controls
    public static String is_homescreen_drawer_interstitial_enable = "is_homescreen_drawer_interstitial_enable";

    //for ThemeScreen
    public static String is_thememode_changing_interstitial_enable = "is_thememode_changing_interstitial_enable"; //For light button Click

    //for DirectoryAdapter
    public static String is_from_album_item_preview_delete_interstitial_enable = "is_from_album_item_preview_delete_interstitial_enable";  //selected item Delete int control   //removed


    public static String is_openAdshow_on_resume = "is_openAdshow_on_resume";   // For Control Open Ads On Resume  (usable from AdsConstants From Admodule)





    //Create item Interstitial ad enabe control
    public static final String create_folder_ad_enable = "create_folder_ad_enable";

    //Splash int ad enable control
    public static String splash_interstitial_enable = "splash_interstitial_enable";

    //App Redirect,update Controls
    public static String is_app_live = "is_app_live";
    public static String is_app_redirect_immediate = "is_app_redirect_immediate";
    public static String app_redirect_package = "app_redirect_package";
    public static String is_enabled_sdkx = "is_enabled_sdkx";
    public static String inAppSubscriptionenabled = "inAppSubscriptionenabled";
    public static String immediate_update_mode = "immediate_update_mode";
    public static String update_dialog_show = "update_dialog_show";

    //App SubScription Controls
    public static String pro_app_key = "start_like_pro";
    public static String is_remove_ads = "is_remove_ads";
    public static String gallery_base64EncodedPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhA5bgs6uSWWnEdbFCAhajw/HU3ObIF6A6HakW6hBfHoDlfDe/WDxD4LJ1gEOpoIRBFc6ucXgty7hC8JHZnAEOpZpvkt+3S3FKdIAe8YTX5p5iUzkWIGHIjcZpJGaO0lAUW6wEMVEsc3D1tgQYYDRpeX3aiBygoQZEXv1bKU52QTO9EtJGcp0KeGrMxfw3tJ4UgrO5EN5uLGageN8QO8GpOQUapV1LYEjAKtBtKzezXFfGxBQ9EgrJq/CzeaZTNd/kg++5g/SoorUDTDFsiBMyK++WJvWoxAejffyF3zUrn3UR7u5mKLS2XWnOGVicxME3LpPGx9oRzhVKD3cDnaRzwIDAQAB";

    //Functionality Controls

    public static String is_mediaact_item_click_enable = "is_mediaact_item_click_enable";
    public static String subscription_theme_color = "subscription_theme_color";
    public static String ads_free = "ads free";



    //Setting back button Click interstitial ad control
    public static final String isSettingScreenBackInt_Enable      = "isSettingScreenBackInt_Enable";
    public static final String isFav_Recycle_Back_Int_Enable       = "isFav_Recycle_Back_Int_Enable";
    public static final String isMainScreenDeleteInt_Enable        = "isMainScreenDeleteInt_Enable";
    public static final String isAlbumDetaliScreenDeleteInt_Enable = "isAlbumDetaliScreenDeleteInt_Enable";
    public static final String isEditScreenSaveInt_Enable          = "isEditScreenSaveInt_Enable";
    public static final String themeModeBannerAdEnabled            ="themeModeBannerAdEnabled";
    public static final String themeModeBannerAdTypeControl        ="themeModeBannerAdTypeControl";
    public static final String isCollapsiveBannerEnableThemeMode   ="isCollapsiveBannerEnableThemeMode";
    public static final String isHomeExitBannerAdEnable            ="isHomeExitBannerAdEnable";
    public static final String HomeExitBannerAdType                ="HomeExitBannerAdType";
    public static String isHomeScreenAlbumItemClickAdEnable ="isHomeScreenAlbumItemClickAdEnable";
    public static String isIntEnableStatusBackPress="isIntEnableStatusBackPress";


    public static void logMethod(String adsLoading, String from_button) {
        Log.w("msg", "admob_ads_loading-- " + adsLoading + "         " + from_button);
    }

    public static boolean getIsAppAdFree(Context context) {
        return new Config(context).getBooleanData(context, FirebaseConfigHelper.is_remove_ads, false);
    }

    @SuppressLint("MissingPermission")
    public static boolean isNetworkConnected(Context context) {

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;

    }

    public static String isBackIdRequired(Context context) {
        String back_id_required = "true";

        if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required).equals("")) {
            back_id_required = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_id_required);
        } else {
            if (context != null) {
                back_id_required = context.getString(R.string.back_id_required);
            }
        }
        return back_id_required;
    }

    public static String getAdmob_intSplash(Context context) {
        String admob_int = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_splash_interstitial).equals("")) {
                admob_int = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_splash_interstitial);
            } else {
                if (context != null) {
                    admob_int = context.getString(R.string.admob_splash_interstitial);

                }
            }
        } else {
            admob_int = "ca-app-pub-3940256099942544/1033173712";
        }
        return admob_int;
    }

    public static String getAdmobBack_intSplash(Context context) {
        String admob_int = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_splash_interstitial).equals("")) {
                admob_int = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_splash_interstitial);
            } else {
                if (context != null) {
                    admob_int = context.getString(R.string.admob_back_splash_interstitial);

                }
            }
        } else {
            admob_int = "ca-app-pub-3940256099942544/1033173712";

        }

        return admob_int;
    }

    public static String getAdmob_int(Context context) {
        String admob_int = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_int).equals("")) {
                admob_int = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_int);
            } else {
                if (context != null) {
                    admob_int = context.getString(R.string.admob_int);

                }
            }
        } else {
            admob_int = "ca-app-pub-3940256099942544/1033173712";
        }

        return admob_int;
    }
    public static String getAdmob_intAlbumClick(Context context) {
        String admob_int = "";

        if (verifyForTestAD(context)) {

            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_int_album_click).equals("")) {
                admob_int = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_int_album_click);
            } else {
                if (context != null) {
                    admob_int = context.getString(R.string.admob_int_album_click);

                }
            }
        } else {

            admob_int = "ca-app-pub-3940256099942544/1033173712";
        }
        return admob_int;
    }

    public static String getAdmobBack_int(Context context) {
        String admobBackInt = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_int).equals("")) {
                admobBackInt = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_int);
            } else {
                if (context != null) {
                    admobBackInt = context.getString(R.string.admob_back_int);

                }
            }
        } else {
            admobBackInt = "ca-app-pub-3940256099942544/1033173712";
        }
        return admobBackInt;
    }

//    public static String getAdmobNative(Context context) {
//        String admobNative = "";
//        if (verifyForTestAD(context)) {
//            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_native).equals("")) {
//                admobNative = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_native);
//            } else {
//                if (context != null) {
//                    admobNative = context.getString(R.string.admob_native);
//                }
//            }
//        } else {
//            admobNative = context.getString(R.string.admob_native);
//        }
//        return admobNative;
//    }
//
//    public static String getAdmobBackNative(Context context) {
//        String admobBackNative = "";
//        if (verifyForTestAD(context)) {
//            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_native).equals("")) {
//                admobBackNative = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_native);
//            } else {
//                if (context != null) {
//                    admobBackNative = context.getString(R.string.admob_back_native);
//                }
//            }
//        } else {
//            admobBackNative = context.getString(R.string.admob_back_native);
//        }
//        return admobBackNative;
//    }
//
//    public static String getStory_native_ad(Context context) {
//        String story_native_ad = "";
//        if (verifyForTestAD(context)) {
//            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.story_native_ad).equals("")) {
//                story_native_ad = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.story_native_ad);
//            } else {
//                if (context != null) {
//                    story_native_ad = context.getString(R.string.story_native_ad);
//                }
//            }
//        } else {
//            story_native_ad = context.getString(R.string.story_native_ad);
//        }
//        return story_native_ad;
//    }
//
//
//    public static String getStory_native_ad_back(Context context) {
//        String story_native_ad = "";
//        if (verifyForTestAD(context)) {
//            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.story_native_ad_back).equals("")) {
//                story_native_ad = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.story_native_ad_back);
//            } else {
//                if (context != null) {
//                    story_native_ad = context.getString(R.string.story_native_ad_back);
//                }
//            }
//        } else {
//            story_native_ad = context.getString(R.string.story_native_ad_back);
//        }
//        return story_native_ad;
//    }


    public static String getAdmobBanner(Context context) {
        String admobBanner = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_banner).equals("")) {
                admobBanner = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_banner);
            } else {
                if (context != null) {
                    admobBanner = context.getString(R.string.admob_banner);
                }
            }
        } else {
            admobBanner = "ca-app-pub-3940256099942544/6300978111";
        }
        return admobBanner;
    }

    public static String getAdmobBackBanner(Context context) {
        String admobBackBanner = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_banner).equals("")) {
                admobBackBanner = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_banner);
            } else {
                if (context != null) {
                    admobBackBanner = context.getString(R.string.admob_back_banner);
                }
            }
        } else {
            admobBackBanner = "ca-app-pub-3940256099942544/6300978111";
        }
        return admobBackBanner;
    }

    public static String getAdmobRewared(Context context) {
        String admobRewared = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_rewared).equals("")) {
                admobRewared = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_rewared);
            } else {
                if (context != null) {
                    admobRewared = context.getString(R.string.admob_rewared);
                }
            }
        } else {
            admobRewared = "ca-app-pub-3940256099942544/5224354917";
        }
        return admobRewared;
    }

    public static String getAdmobBackRewared(Context context) {
        String admobBackRewared = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_rewared).equals("")) {
                admobBackRewared = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_rewared);
            } else {
                if (context != null) {
                    admobBackRewared = context.getString(R.string.admob_back_rewared);
                }
            }
        } else {
            admobBackRewared = "ca-app-pub-3940256099942544/5224354917";
        }
        return admobBackRewared;
    }

    public static String getAdmobRewaredInt(Context context) {
        String admobRewaredInt = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_rewared_int).equals("")) {
                admobRewaredInt = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_rewared_int);
            } else {
                admobRewaredInt = context.getString(R.string.admob_rewared_int);

            }
        } else {
            admobRewaredInt = "ca-app-pub-3940256099942544/5354046379";
        }
        return admobRewaredInt;
    }

    public static String getAdmobBackRewaredInt(Context context) {
        String admobBackRewaredInt = "";
        if (verifyForTestAD(context)) {
            if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_rewared_int).equals("")) {
                admobBackRewaredInt = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_back_rewared_int);
            } else {
                admobBackRewaredInt = context.getString(R.string.admob_back_rewared_int);
            }
        } else {
            admobBackRewaredInt = "ca-app-pub-3940256099942544/5354046379";
        }
        return admobBackRewaredInt;
    }


//    public static String getAdmob_open_ads(Context context) {
//        String admob_open_ads = "";
//        if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_app_open).equals("")) {
//            admob_open_ads = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.admob_app_open);
//        } else {
//            if (context != null) {
//                admob_open_ads = context.getString(R.string.admob_app_open);
//            }
//        }
//        return admob_open_ads;
//    }
//
//    public static String getAdmob_open_ads_back(Context context) {
//        String admob_open_ads = "";
//        if (!FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_admob_open_ads).equals("")) {
//            admob_open_ads = FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.back_admob_open_ads);
//        } else {
//            if (context != null) {
//                admob_open_ads = context.getString(R.string.admob_back_app_open);
//            }
//        }
//        return admob_open_ads;
//    }

//    public static Boolean overlayOpenAd(Context context, Boolean value) {
//        return new Config(context).getBooleanData(context, PreferenceKeys.SHOW_OPEN_AD, value);
//    }

    public static boolean verifyInstallerId(Context context) {
        List<String> validInstallers = new ArrayList<>(Arrays.asList("com.android.vending", "com.google.android.feedback"));
        final String installer = context.getPackageManager().getInstallerPackageName(context.getPackageName());
        return installer != null && validInstallers.contains(installer);
    }

    public static boolean verifyForTestAD(Context context) {
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pInfo.versionName.matches("[0-9][0-9.]*[0-9]");

        } catch (Exception e) {
            Log.e("verifyForTest", "verifyForTest: Error" + e.getMessage());
            return false;
        }

    }

}
