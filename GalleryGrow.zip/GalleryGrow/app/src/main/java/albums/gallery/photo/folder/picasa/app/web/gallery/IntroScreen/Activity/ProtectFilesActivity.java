package albums.gallery.photo.folder.picasa.app.web.gallery.IntroScreen.Activity;

import static albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper.verifyInstallerId;
import static albums.gallery.photo.folder.picasa.app.web.gallery.helpers.ConstantsKt.SHOW_INT_AD;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent;
import albums.gallery.photo.folder.picasa.app.web.gallery.R;
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper;
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.MainActivity;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScriptionActivity;

public class ProtectFilesActivity extends AppCompatActivity {

    private Animation animFadeIn, animFadeIn1, animFadeIn2;
    TextView text1, text2, text3, skip_text;
    RelativeLayout first_act_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wel_private);
        getWindow().setStatusBarColor(Color.parseColor("#ffffff"));
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        text3 = findViewById(R.id.text3);
        first_act_layout = findViewById(R.id.first_act_layout);
        animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_to_right);
        animFadeIn1 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_to_right);
        animFadeIn2 = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.left_to_right);
        skip_text = findViewById(R.id.skip_text);
        skip_text.setPaintFlags(skip_text.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                text1.setAnimation(animFadeIn);
                text1.setVisibility(View.VISIBLE);
            }
        }, 600);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                text2.setAnimation(animFadeIn1);
                text2.setVisibility(View.VISIBLE);
            }
        }, 1300);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                text3.setAnimation(animFadeIn2);
                text3.setVisibility(View.VISIBLE);
            }
        }, 2000);

        first_act_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.Companion.logAdapter(
                    GoogleAnalyticsEvent.getPrivateFilesWithLock(),
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.Companion.getNext_button());
                startActivity(new Intent(ProtectFilesActivity.this, PDupFilesActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                overridePendingTransition(R.anim.enter, R.anim.exit);
                finish();
            }
        });
        skip_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.getPrivateFilesWithLock(),
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.getSkip_button());
                if (!FirebaseConfigHelper.getIsAppAdFree(ProtectFilesActivity.this)
                    && FirebaseConfigHelper.isNetworkConnected(ProtectFilesActivity.this) && verifyInstallerId(ProtectFilesActivity.this)
                    && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)) {
                    Intent intent = new Intent(ProtectFilesActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("isFrom", "Start");

                    startActivity(intent);
                    overridePendingTransition(R.anim.enter, R.anim.exit);
                    finish();
                } else {
                    Intent intent = new Intent(ProtectFilesActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!FirebaseConfigHelper.getIsAppAdFree(ProtectFilesActivity.this)
            && FirebaseConfigHelper.isNetworkConnected(ProtectFilesActivity.this) && verifyInstallerId(ProtectFilesActivity.this)
            && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)) {
            Intent intent = new Intent(ProtectFilesActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("isFrom", ProtectFilesActivity.this.getClass().getSimpleName());
            startActivity(intent);
            overridePendingTransition(R.anim.enter, R.anim.exit);
            finish();
        } else {
            startActivity(new Intent(ProtectFilesActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true));
            finish();
        }
    }

}
