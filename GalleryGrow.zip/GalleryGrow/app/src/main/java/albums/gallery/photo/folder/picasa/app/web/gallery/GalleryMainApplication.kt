package albums.gallery.photo.folder.picasa.app.web.gallery

import album.gallery.photo.folder.picasa.app.web.gallery.commons.extensions.checkUseEnglish
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.SplashActivity
import albums.gallery.photo.folder.picasa.app.web.gallery.helpers.Config
import albums.gallery.photo.folder.picasa.app.web.gallery.preference.PreferenceKeys
import android.app.Activity
import android.content.Context
import android.os.Build
import android.util.Log
import android.webkit.WebView
import com.example.admob.adLoader.OpenAdApplication
import com.example.admob.utils.AdsConstants
import com.facebook.FacebookSdk
import com.github.ajalt.reprint.core.Reprint
import com.google.android.gms.ads.MobileAds
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.greedygame.core.AppConfig
import com.greedygame.core.GreedyGameAds
import com.llew.huawei.verifier.LoadedApkHuaWei
import com.squareup.picasso.Downloader
import com.squareup.picasso.Picasso
import com.treebo.internetavailabilitychecker.InternetAvailabilityChecker
import com.treebo.internetavailabilitychecker.InternetConnectivityListener
import okhttp3.Request
import okhttp3.Response


class GalleryMainApplication : OpenAdApplication(), OpenAdApplication.AppLifecycleListener, InternetConnectivityListener {


    private var FbToken: String? = null
    lateinit var context: Context
    lateinit var mInternetAvailabilityChecker: InternetAvailabilityChecker

    lateinit var firebaseAnalytics: FirebaseAnalytics

    companion object {
        var isMobileAdsIntilized = false;
        lateinit var mInstance: GalleryMainApplication
        fun getInstance(): GalleryMainApplication? {
            return mInstance
        }

    }

    override fun onCreate() {
        super.onCreate()
        checkUseEnglish()
        Reprint.initialize(this)
        context = this

        mInstance = this@GalleryMainApplication


        // firebase initialization
        MobileAds.initialize(this) {
            isMobileAdsIntilized = true;
            Log.w("msg", " onCreate:  MobileAds Initilized.... ${it.adapterStatusMap.entries} ")
        }
        firebaseInitialization()
        setAppLifeCycleListener(this)
        Config(applicationContext).saveData(this, PreferenceKeys.SHOW_OPEN_AD, true)
        Config(applicationContext).saveData(this, PreferenceKeys.VERIFY_TEST_AD, FirebaseConfigHelper.verifyForTestAD(this))

        // Added by Parth for Facebook Mediataion
        FacebookSdk.sdkInitialize(this);

        // Internet ChecKer Instance
        InternetAvailabilityChecker.init(this);
        firebaseAnalytics = Firebase.analytics
        mInternetAvailabilityChecker = InternetAvailabilityChecker.getInstance();
        mInternetAvailabilityChecker.addInternetConnectivityListener(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val process = getProcessName()
            if (packageName != process) WebView.setDataDirectorySuffix(process)
        }
        Picasso.setSingletonInstance(Picasso.Builder(this).downloader(object : Downloader {
            override fun load(request: Request) = Response.Builder().build()
            override fun shutdown() {}
        }).build())


        FirebaseConfigHelper.logMethod(
            "is_enabled_sdkx    ", "value " + FirebaseConfigHelper.remoteConfig.getBoolean(
                FirebaseConfigHelper.is_enabled_sdkx
            )
        )

        if (FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.is_enabled_sdkx)) {
            val appConfig = AppConfig.Builder(this)
                .withAppId("")
                .build()
            GreedyGameAds.initWith(appConfig, null)
        }
        try {  // Change by Priyanka - v1.0.30
            LoadedApkHuaWei.hookHuaWeiVerifier(getBaseContext());
        } catch (e: Exception) {
        }
    }

    override fun onInternetConnectivityChanged(isConnected: Boolean) {
        if (isConnected) {
            firebaseInitialization()
        }
    }

    private fun firebaseInitialization() {
        FirebaseApp.initializeApp(this)
        val firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        // FirebaseInstanceId.getInstance().getToken() -> Deprecated
        FirebaseMessaging.getInstance().token.addOnSuccessListener { result ->
            if (result != null) {
                Log.w("msg", "firebaseInitialization: ${result.toString()}  ")
                FbToken = result
            }
        }

        val configSettings = FirebaseRemoteConfigSettings.Builder()
            .setMinimumFetchIntervalInSeconds(1)
            .build()
        firebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults);
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings)
        firebaseRemoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            var errorString = ""
            if (task.isSuccessful) {
                firebaseRemoteConfig.fetchAndActivate()
                FirebaseConfigHelper.logMethod("splash ", "fireBaseConfigGet  activated ")
                errorString = " Firebse task is successful  "
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ back_id_required ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.back_id_required
                    )
                )

                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_app_open ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_app_open
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_open_ads ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_open_ads
                    )
                )  //old
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ back_admob_open_ads ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.back_admob_open_ads
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_banner_control ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_banner_control
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_banner ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_banner
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_back_banner ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_back_banner
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_interstitial_control ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_interstitial_control
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_int ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_int
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_back_int ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_back_int
                    )
                )

                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_rewared ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_rewared
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_back_rewared ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_back_rewared
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_rewared_int ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_rewared_int
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ admob_back_rewared_int ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_back_rewared_int
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ inAppSubscriptionenabled ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(
                        FirebaseConfigHelper.inAppSubscriptionenabled
                    )
                )


                Log.w(
                    "msg",
                    " mFirebaseRemoteConfigis_ is_home_screen_banner_enabled   ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.is_home_screen_banner_enabled
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ is_app_live ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.is_app_live
                    )
                )
                Log.w(
                    "msg",
                    " mFirebaseRemoteConfigis_ is_app_redirect_immediate      ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.is_app_redirect_immediate
                    )
                )
                Log.w(
                    "msg",
                    " mFirebaseRemoteConfigis_ admob_banner_control_home      ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.admob_banner_control_home
                    )
                )
                Log.w(
                    "msg",
                    " mFirebaseRemoteConfigis_ is_setting_banner_enabled      ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.is_setting_banner_enabled
                    )
                )
                Log.w(
                    "msg",
                    " mFirebaseRemoteConfigis_ is_media_banner_enabled      ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.is_album_item_preview_screen_banner_enabled
                    )
                )
                Log.w(
                    "msg", " mFirebaseRemoteConfigis_ subscription_theme_color      ---------" + FirebaseConfigHelper.remoteConfig.getString(
                        FirebaseConfigHelper.subscription_theme_color
                    )
                )
            } else {
                FirebaseConfigHelper.logMethod("splash ", "fireBaseConfigGet  deactivated ")
                errorString = " Firebse task is canceled"
            }
            Log.w(
                "errorString",
                "mFirebaseRemoteConfigis_ " + errorString
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfigis_ is_openAdshow_on_resume ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(
                    AdsConstants.is_openAdshow_on_resume
                )
            )


            Log.w(
                "msg",
                " mFirebaseRemoteConfig create_folder_ad_enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(
                    FirebaseConfigHelper.create_folder_ad_enable
                )
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig splash_interstitial_enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(
                    FirebaseConfigHelper.splash_interstitial_enable
                )
            )


            Log.w(
                "msg",
                " mFirebaseRemoteConfig is_theme_light_enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(
                    FirebaseConfigHelper.is_thememode_changing_interstitial_enable
                )
            )

            Log.w(
                "msg",
                " mFirebaseRemoteConfig istestApp ---------" + FirebaseConfigHelper.verifyForTestAD(this)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig isSettingScreenBackInt_Enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isSettingScreenBackInt_Enable)
            )

            Log.w(
                "msg",
                " mFirebaseRemoteConfig isFav_Recycle_Back_Int_Enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isFav_Recycle_Back_Int_Enable)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig isMainScreenDeleteInt_Enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isMainScreenDeleteInt_Enable)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig isAlbumDetaliScreenDeleteInt_Enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isAlbumDetaliScreenDeleteInt_Enable)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig isEditScreenSaveInt_Enable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isEditScreenSaveInt_Enable)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig themeModeBannerAdEnabled ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.themeModeBannerAdEnabled)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig themeModeBannerAdTypeControl ---------" + FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.themeModeBannerAdTypeControl)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig isCollapsiveBannerEnableThemeMode ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isCollapsiveBannerEnableThemeMode)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig isHomeExitBannerAdEnable ---------" + FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.isHomeExitBannerAdEnable)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfig HomeExitBannerAdType ---------" + FirebaseConfigHelper.remoteConfig.getString(FirebaseConfigHelper.HomeExitBannerAdType)
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfigis_ isHomeScreenAlbumItemClickAdEnable   ---------" + FirebaseConfigHelper.remoteConfig.getString(
                    FirebaseConfigHelper.isHomeScreenAlbumItemClickAdEnable
                )
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfigis_ isIntEnableStatusBackPress   ---------" + FirebaseConfigHelper.remoteConfig.getString(
                    FirebaseConfigHelper.isIntEnableStatusBackPress
                )
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfigis_ admob_int_album_click   ---------" + FirebaseConfigHelper.remoteConfig.getString(
                    FirebaseConfigHelper.admob_int_album_click
                )
            )
            Log.w(
                "msg",
                " mFirebaseRemoteConfigis_ isHomeScreenAlbumItemClickAdEnable   --------- " + FirebaseConfigHelper.remoteConfig.getBoolean(
                    FirebaseConfigHelper.isHomeScreenAlbumItemClickAdEnable
                )
            )

        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        InternetAvailabilityChecker.getInstance().removeAllInternetConnectivityChangeListeners()
    }

    override fun onResumeApp(currentActivity: Activity?): Boolean {
        Log.d(
            "RESUME0",
            " ============================================== ${currentActivity} && ${currentActivity is SplashActivity}"
        )
        return if (currentActivity is SplashActivity) {
            false
        } else if (Config(applicationContext).getBooleanData(this, PreferenceKeys.SystemDialogOpened)) {
            Config(applicationContext).saveData(applicationContext, PreferenceKeys.SystemDialogOpened, false);
            false;
        } else {
            true
        }

    }
}
