package albums.gallery.photo.folder.picasa.app.web.gallery

import android.os.Bundle
import android.util.Log
import androidx.annotation.Size
import com.google.firebase.analytics.ktx.logEvent
import org.jetbrains.annotations.NotNull

class GoogleAnalyticsEvent {

    companion object {

        // 4 Screens after Splash Screen
        @JvmStatic
        val privateFilesWithLock = "Private files with lock"

        @JvmStatic
        val addToFavourites = "Add to Favourites"

        @JvmStatic
        val protectMedia = "Protect Media"

        @JvmStatic
        val skip_button = "SKIP"

        @JvmStatic
        val next_button = "NEXT"
        val done_button = "DONE"

        // Main Activity
        val drawer_button = "Drawer Button"
        val album = "ALBUM"
        val all_media = "All MEDIA"
        val floating_button = "Create New Album"
        val story_recent = "Recent"
        val story_1year = "1 Year"
        val story_3year = "3 Year"
        val story_random = "Random"

        // Drawer
        val drawer_favourites = "Favourites"
        val drawer_recycle_bin = "Recycle Bin"
        val drawer_duplicate = "Duplicate Image Remove"
        val drawer_lock_private_files = "Lock Private Files"
        val drawer_change_theme = "Change Theme Mode"
        val drawer_settings = "Settings"
        val drawer_about = "About"

        // Album Options
        val album_search = "Search"
        val album_camera = "Camera"
        val album_sort_by = "Sort By"
        val album_filter_media = "Filter Media"
        val album_change_view_type = "Change View Type"
        val album_temporarily_show_hidden = "Temporarily Show Hidden"
        val album_stop_show_hidden = "Stop Showing Hidden Media"
        val album_increase_column_count = "Increase Column Count"
        val album_reduce_column_count = "Reduce Column Count"
        val album_settings = "Settings"
        val album_about = "About"

        // All Media Options
        val all_media_search = "Search"
        val all_media_file_visibility = "Toggle File Visibility"
        val all_media_sort_by = "Sort By"
        val all_media_filter_media = "Filter Media"
        val all_media_change_view_type = "Change View Type"
        val all_media_temporarily_show_hidden = "Temporarily Show Hidden"
        val all_media_stop_show_hidden = "Stop Showing Hidden Media"
        val all_media_camera = "Open Camera"
        val all_media_group_by = "Group By"
        val all_media_increase_column_count = "Increase Column Count"
        val all_media_reduce_column_count = "Reduce Column Count"
        val all_media_slideshow = "Slideshow"
        val all_media_settings = "Settings"

        // Media
        val media = "Media Screen"




        val filter = "Filter"



        val rotate_left = "Rotate Left"
        val rotate_right = "Rotate Right"




        // Primary Section
        val toggle_theme = "Themes"
        val duplicate_remove = "Duplicate Image Remove"
        val menu = "menu"
        val date_time_format = "DateTime Format"
        val loading_priority = "Loading Priority"
        val about_us = "About Us"
        val remove_ads = "Remove Ads"

        // Visibility
        val manage_included_folders = "Manage Included Folders"
        val manage_excluded_folders = "Manage Excluded Folders"
        val show_hidden_items = "Show Hidden Items"

        // Videos
        val play_videos_automatically = "Play Videos Automatically"
        val remember_last_video_playback_position = "Remember Last Video "
        val loop_videos = "Loop Videos"
        val open_videos_on_separate_screen = "Always open videos "
        val allow_video_gestures = "Allow controlling video"

        // Thumbnails
        val crop_thumbnails = "Crop thumbnails into squares"
        val file_thumbnail_style = "File thumbnail style"
        val folder_thumbnail_style = "Folder thumbnail style"

        // Scrolling
        val scroll_thumbnails_horizontally = "Scroll thumbnails horizontally"
        val enable_pull_to_refresh = "Enable pull-to-refresh from the top"

        // Fullscreen Media
        val max_brightness = "Max brightness"
        val black_background_at_fullscreen = "Black background "
        val hide_system_ui_at_fullscreen = "Automatically hide "
        val allow_instant_change = "Allow instantly"
        val allow_photo_gestures = "Allow controlling photo "
        val allow_down_gesture = " closing the fullscreen "
        val show_notch = "Show a notch if available"
        val screen_rotation_by = "Rotate fullscreen media by"

        // Deep Zoomable Images
        val allow_deep_zooming_images = "Allow deep zooming images"
        val allow_rotating_gestures = "Allow rotating "
        val show_highest_quality = "quality"
        val allow_one_to_one_zoom = "zooming 1:1 "

        // Extended Details
        val show_extended_details = "Show extended "

        // Security
        val password_protect_whole_app = "Password protect "

        // File Operations
        val delete_empty_folders = "Delete empty folders "
        val keep_last_modified = "Keep old last-modified "
        val skip_delete_confirmation = " delete confirmation "

        // Bottom Actions
        // Hide

        // Recycle Bin
        val move_items_into_recycle_bin = "Move  into the Recycle Bin "
        val show_recycle_bin = "Show the Recycle Bin "
        val show_recycle_bin_last = "last item on the main screen"
        val empty_recycle_bin = "Empty the Recycle Bin"

        // Migrating
        val clear_cache = "Clear cache"
        val export_settings = "Export settings"
        val import_settings = "Import settings"


        // Intorduction Screen




        val BILLING_RESPONSE_RESULT_ITEM_ALREADY_OWNED = "ITEM ALREADY OWNED "
        val BILLING_RESPONSE_RESULT_USER_CANCELED = "USER CANCELED"
        val BILLING_RESPONSE_RESULT_SERVICE_UNAVAILABLE = "SERVICE UNAVAILABLE"
        val BILLING_RESPONSE_RESULT_BILLING_UNAVAILABLE = "BILLING UNAVAILABLE"
        val BILLING_RESPONSE_RESULT_ITEM_UNAVAILABLE = "ITEM UNAVAILABLE"
        val BILLING_RESPONSE_RESULT_DEVELOPER_ERROR = "DEVELOPER ERROR"
        val BILLING_RESPONSE_RESULT_ERROR = "RESULT_ERROR"
        val BILLING_RESPONSE_RESULT_ITEM_NOT_OWNED = "ITEM NOT OWNED"
        val IABHELPER_USER_CANCELLED = "IABHELPER USER CANCELLED"
        const val cancel = "cancel"

        // Subscription
        const val subscription = "Subscription "


        const val skipButton = "Skip_Button"
        const val skip = "Skip"
        const val closeButton = "Close_Button"
        const val tryLimitedVersion = "Try_Limited_Version"
        const val success = "success"

        const val termsPrivacy = "Terms_and_Privacy"
        const val freeTrial = "Free_Trial "

        const val drawer_clicked = "drawer_clicked"
        const val subs_clicked = "click"
        const val click = "click"
        const val opened = "Opened"
        const val open = "Open"
        const val purchasedSuccessful = "Purchased_Successful"
        const val didNotPurchased = "Didn't_Purchased"
        const val purchaseFailed = "Failed"
        const val view = "view"

        const val mainScreen = "HomeScreen"
        const val story = "story"
        const val recent = "recent"
        const val oneYear = "1_Year"
        const val threeYear = "3_Year"
        const val random = "random"
        const val drawer = "Drawer"
        const val Main_ScreenMain_Screen = "Favorites"
        const val recycleBin = "Recycle_Bin"
        const val removeDuplicateImages = "Remove_Duplicate_Images"
        const val themes = "Themes"
        const val themeMode = "Theme_Mode"
        const val light = "Light"
        const val dark = "Dark"
        const val lockPrivateFiles = "Lock_Private_Files"
        const val settings = "Settings"
        const val aboutUs = "About_Us"
        const val getPremiumVersion = "Get_Premium_Version"

        const val exitDialog = "Exit_Dialog"
        const val rate = "rate"
        const val exit = "exit"
        const val close = "close"
        const val swipe = "swipe"
        const val homeOrSwitchApp = "Home_or_SwitchApp"
        const val exitApp = "Exit_App"

        // ViewPagerScreen
        const val mediaView = "Media_View"
        const val bottomButtons = "Bottom_Buttons"
        const val toggleFavourite = "Toggle_Favourite"
        const val edit = "Edit"
        const val share = "Share"
        const val delete = "Delete"

        const val rotate = "Rotate"
        const val rotateRight = "Rotate_Right"
        const val rotateLeft = "Rotate_Left"
        const val rotateBy180 = "Rotate_By_180"
        const val properties = "Properties"

        const val rename = "Rename"
        const val hide = "Hide"
        const val unhide = "Unhide"
        const val copyTo = "Copy_To"
        const val moveTo = "Move_To"
        const val createShortcut = "Create_Shortcut"
        const val openWith = "Open_With"
        const val setAs = "Set_As"
        const val changeOrientation = "change_Orientation"
        const val forcePortrait = "Force_Portrait"
        const val forceLandscape = "Force_Landscape"
        const val useDefaultOrientation = "Use_Default_Orientation"
        const val print = "Print"
        const val resize = "Resize"
        const val saveAs = "Save_As"
        const val showOnMap = "Show_On_Map"
        const val slideshow = "Slideshow"
        const val restore = "Restore_This_File"

        const val favourite = "favourite"
        const val unfavourite = "unfavourite"

        const val imageEditor = "Image_Editor"
        const val effects = "Effects"
        const val crop = "Crop"
        const val brush = "Brush"

        const val mirror = "Mirror"
        const val flipVertically = "Flip_Vertically"
        const val flipHorizontally = "Flip_Horizontally"
        const val resizeGuideline = "Resize_Guideline"
        const val resizeMore = "Resize_More"

        const val mediaList = "Media_List"
        const val search = "Search"
        const val fileNameVisibility = "File_Name_Visibility"
        const val sortBy = "Sort_By"
        const val openCamera = "Open_Camera"
        const val filterMedia = "Filter_Media"
        const val changeViewType = "Change_View_Type"
        const val groupBy = "Group_By"
        const val increaseColumnCount = "Column_Count_++"
        const val reduceColumnCount = "Column_Count_--"
        const val removeAds = "Remove_Ads"
        const val temporarilyShowHidden = "Temporarily_Show_Hidden"
        const val stopShowingHidden = "Stop_Showing_Hidden"


        const val userExit = "user_exit"


        const val mediaActivity = "ImageGridViewActivity"
        const val splashActivity = "Splash_Activity"
        const val themeActivity = "Theme_Activity"
        const val viewPagerActivity = "FullScreenImageActivity"
        const val albumFragment = "Album_Fragment"
        const val allMediaFrag = "AllMedia_Fragment"
        const val searchActivity = "Search_Activity"
        const val subScriptionActivity = "SubScription_Activity"

        const val openAds = "Admob_Open_Ads"

        const val SplashOpenAds = "Startup_Overview"

        val fiveStoryStatus: String="FiveStoryStatusActivity"
        val oneStoryStatus: String="OneStoryStatusActivity"
        val threeStoryStatus: String="ThreeStoryStatusActivity"
        val randomStoryStatus: String="RandomStoryStatusActivity"

        fun stringValue(x: Boolean): String {
            return when (x) {
                true -> "YES"
                false -> "NO"
            }
        }

        @JvmStatic
        fun logAdapter(/*context: Context,*/
            @NotNull @Size(min = 1L, max = 40L) eventName0: String?,
            @Size(min = 1L, max = 40L) paramName0: String?,
            @Size(min = 1L, max = 40L) paramValue0: String?
        ) {

            try {


                val eventName = eventName0?.trim()?.replace(" ", "_")?.replace(",", "_")
                val paramName = paramName0?.trim()?.replace(" ", "_")?.replace(",", "_")?.lowercase()
                val paramValue =
                    paramValue0?.trim()?.replace(" ", "_")?.replace(",", "_")?.replace("/", "_")?.lowercase()
                val bundle = Bundle()
                bundle.putString(paramName, paramValue)
                if (BuildConfig.DEBUG) {
                    if (eventName != null) {
                        GalleryMainApplication.getInstance()?.firebaseAnalytics?.logEvent(eventName) {
                            if (paramName != null && paramValue != null) {
                                param(paramName, paramValue)
                            }
                        }
                    }
                    Log.e("firebaseAnalytics", "$eventName $paramName $paramValue")
                } else {
                    if (eventName != null) {
                        GalleryMainApplication.getInstance()?.firebaseAnalytics?.logEvent(eventName) {
                            if (paramName != null && paramValue != null) {
                                param(paramName, paramValue)
                            }
                        }
                    }
                    Log.e("firebaseAnalytics", "$eventName $paramName $paramValue")

                }
            } catch (e: Exception) {
                Log.e("firebaseAnalytics Error: ", e.message.toString())
            }
        }
    }
}
