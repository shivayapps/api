package albums.gallery.photo.folder.picasa.app.web.gallery.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import albums.gallery.photo.folder.picasa.app.web.gallery.R;



public class CorruptedActivity extends AppCompatActivity {
    Button btnreinstall;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_corrupted);
        btnreinstall = findViewById(R.id.btnreinstall);

        btnreinstall.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View v) {
                Bundle params = new Bundle();
                params.putString("Reinstall Click", "click");
                Intent goRateus = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getApplicationContext().getPackageName()));
                goRateus.addFlags(1208483840);

                try {
                    startActivity(goRateus);
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())));
                }
            }
        });
    }

}
