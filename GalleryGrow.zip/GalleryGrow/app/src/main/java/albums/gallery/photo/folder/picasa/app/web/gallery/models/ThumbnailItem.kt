package albums.gallery.photo.folder.picasa.app.web.gallery.models

open class ThumbnailItem
