package albums.gallery.photo.folder.picasa.app.web.gallery.models

data class GalleryImageModel (
    var path: String,
    var name: String,
    var date: String,
)

