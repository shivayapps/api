package albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Model;

import android.net.Uri;

public class Photo {
    private long finger;
    private String fingerPrint;
    private Boolean fristPosition = false;

    /* renamed from: id */
    private long f5695id;
    private String mimetype;
    private String name;
    private String path;
    private long size;
    private Uri uri;

    public long getFinger() {
        return this.finger;
    }

    public String getFingerPrint() {
        return this.fingerPrint;
    }

    public Boolean getFristPosition() {
        return this.fristPosition;
    }

    public long getId() {
        return this.f5695id;
    }

    public String getMimetype() {
        return this.mimetype;
    }

    public String getName() {
        return this.name;
    }

    public String getPath() {
        return this.path;
    }

    public long getSize() {
        return this.size;
    }

    public void setFinger(long j) {
        this.finger = j;
    }

    public void setFingerPrint(String str) {
        this.fingerPrint = str;
    }

    public void setFristPosition(Boolean bool) {
        this.fristPosition = bool;
    }

    public void setId(long j) {
        this.f5695id = j;
    }

    public void setMimetype(String str) {
        this.mimetype = str;
    }

    public void setName(String str) {
        this.name = str;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public void setSize(long j) {
        this.size = j;
    }
}
