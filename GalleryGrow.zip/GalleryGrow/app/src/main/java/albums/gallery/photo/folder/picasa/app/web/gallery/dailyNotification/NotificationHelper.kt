package albums.gallery.photo.folder.picasa.app.web.gallery.dailyNotification

import albums.gallery.photo.folder.picasa.app.web.gallery.R
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.NotificationStoriesActivity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class NotificationHelper(val context: Context) {
    val CHANNEL_NAME = "High Priority Channel"
    val CHANNEL_ID = "com.example.notificationdemo" + CHANNEL_NAME

    fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, importance).apply {
                description = "Test Notification"
            }

            channel.enableLights(true)
            channel.enableVibration(true)
            channel.lightColor = Color.RED
            channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC

            // Register the channel with the system
            val notificationManager: NotificationManager = (context?.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager?)!!
            notificationManager.createNotificationChannel(channel)
        }
    }
    fun triggerNotification(image_path: String, image_date: String, year: Int, picture_list: String) {
        // Create an explicit intent for an Activity in your app
        lateinit var intent: Intent
        intent = Intent(context, NotificationStoriesActivity::class.java).apply {
            putExtra("arrayList",picture_list)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

//        if(year == 3) {
//            intent = Intent(context, FiveStatusActivity::class.java).apply {
//                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            }
//        } else if (year == 1) {
//            intent = Intent(context, OneStatusActivity::class.java).apply {
//                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            }
//        } else {
//
//            intent = Intent(context, StatusActivity::class.java).apply {
//                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            }
//        }

        val pendingIntent: PendingIntent = PendingIntent.getActivity(context, 22, intent, /*PendingIntent.FLAG_UPDATE_CURRENT*/PendingIntent.FLAG_MUTABLE)

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.app_icon)
            .setContentTitle("Memories $year Year Ago")
            .setContentText(image_date)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setStyle(NotificationCompat.BigPictureStyle()
                .bigPicture(
                    BitmapFactory.decodeFile(image_path))
                .bigLargeIcon(null))
            // Set the intent that will fire when the user taps the notification
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(context)) {
            // notificationId is a unique int for each notification that you must define
            notify(22, builder.build())
        }
    }
}
