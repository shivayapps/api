package albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Util;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.Model.Photo;


public class PhotoRepository {
    private static final String[] STORE_IMAGES = {"_id", "_data", "_display_name", "mime_type", "_size"};
    private static final String TAG = "PhotoRepository";

    public static List<Photo> getPhoto(Context context) {
        try {
            Cursor query = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, STORE_IMAGES, (String) null, (String[]) null, "datetaken desc");
            ArrayList arrayList = new ArrayList();
            while (query != null) {
                try {
                    if (!query.moveToNext()) {
                        break;
                    }
                    try {
                        if (query.getString(1).startsWith("/storage/emulated/0/")) {
                            Photo photo = new Photo();
                            Log.w("msg", " duplicate  getPhoto setId=" + query.getLong(0));
                            Log.w("msg", " duplicate  getPhoto setPath=" + query.getString(1));
                            Log.w("msg", " duplicate  getPhoto setName=" + query.getString(2));
                            Log.w("msg", " duplicate  getPhoto setMimetype=" + query.getString(3));
                            Log.w("msg", " duplicate  getPhoto setSize=" + query.getLong(4));
                            Log.w("msg", " duplicate  getPhoto photo=" + photo);

                            photo.setId(query.getLong(0));
                            photo.setPath(query.getString(1));
                            photo.setName(query.getString(2));
                            photo.setMimetype(query.getString(3));
                            photo.setSize(query.getLong(4));
                            arrayList.add(photo);
                        }
                    } catch (Exception e) {
//                        // e.printStackTrace();
                    }
                } catch (Exception e2) {
//                    e2.printStackTrace();
                }
            }
            if (query != null) {
                try {
                    query.close();
                } catch (Exception e3) {
//                    e3.printStackTrace();
                }
            }
            String str = TAG;
            Log.d(str, "getPhoto: size=" + arrayList.size());
            return arrayList;
        } catch (Exception e4) {
//            e4.printStackTrace();
            return null;
        }
    }
}
