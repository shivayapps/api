 /*
  * Copyright (C) 2019 Grow Solution
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *      http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  */
 package albums.gallery.photo.folder.picasa.app.web.gallery.models;

 import com.google.gson.annotations.SerializedName;

 import java.util.ArrayList;

 /**
  * Created by grow solution on 14/05/2019.
  */
 public class InAppPurchaseModel {
     String id;
     String name;
     String inappPurchaseKey;
     String gallery_base64EncodedPublicKey;

     @SerializedName("inapp_key_list")
     public ArrayList<InAppPurchaseModel> objInAppKeyList = new ArrayList<InAppPurchaseModel>();
  /*{
   inapp_key_list: [
   {
    id: "1",
            inappPurchaseKey: "android.test.purchased"
   },*/

     public InAppPurchaseModel(String id, String name, String inappPurchaseKey,String gallery_base64EncodedPublicKey) {
         this.id = id;
         this.name = name;
         this.inappPurchaseKey = inappPurchaseKey;
         this.gallery_base64EncodedPublicKey = gallery_base64EncodedPublicKey;
     }



     public String getId() {
         return id;
     }

     public void setId(String id) {
         this.id = id;
     }

     public String getInappPurchaseKey() {
         return inappPurchaseKey;
     }

     public String getName() {
         return name;
     }

     public void setName(String name) {
         this.name = name;
     }

     public void setInappPurchaseKey(String inappPurchaseKey) {
         this.inappPurchaseKey = inappPurchaseKey;
     }

     public ArrayList<InAppPurchaseModel> getObjInAppKeyList() {
         return objInAppKeyList;
     }

     public void setObjInAppKeyList(ArrayList<InAppPurchaseModel> objInAppKeyList) {
         this.objInAppKeyList = objInAppKeyList;
     }

     public String getGallery_base64EncodedPublicKey() {
         return gallery_base64EncodedPublicKey;
     }

     public void setGallery_base64EncodedPublicKey(String gallery_base64EncodedPublicKey) {
         this.gallery_base64EncodedPublicKey = gallery_base64EncodedPublicKey;
     }
 }
