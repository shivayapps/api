package albums.gallery.photo.folder.picasa.app.web.gallery.interfaces

import album.gallery.photo.folder.picasa.app.web.gallery.commons.models.FileDirItem
import albums.gallery.photo.folder.picasa.app.web.gallery.models.ThumbnailItem

interface MediaOperationsListener {
    fun refreshItems()

    fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>)

    fun selectedPaths(paths: ArrayList<String>)

    fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>)
}
