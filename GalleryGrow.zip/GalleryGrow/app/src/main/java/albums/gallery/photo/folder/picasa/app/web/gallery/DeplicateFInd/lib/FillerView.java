package albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.lib;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

public class FillerView extends LinearLayout {
    private View mMeasureTarget;

    public FillerView(Context context) {
        super(context);
    }

    public FillerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public FillerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }


    public void onMeasure(int i, int i2) {
        if (this.mMeasureTarget != null) {
//            i2 = View.MeasureSpec.makeMeasureSpec(ViewGroup.LayoutParams.WRAP_CONTENT, View.MeasureSpec.UNSPECIFIED);
            try {
                i2 = MeasureSpec.makeMeasureSpec(this.mMeasureTarget.getMeasuredHeight(), 1073741824);
            } catch (Exception e) {

            }
        }
        super.onMeasure(i, i2);
    }

    public void setMeasureTarget(View view) {
        this.mMeasureTarget = view;
    }
}
