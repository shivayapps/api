package albums.gallery.photo.folder.picasa.app.web.gallery.IntroScreen.Activity;

import static albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper.verifyInstallerId;
import static albums.gallery.photo.folder.picasa.app.web.gallery.helpers.ConstantsKt.SHOW_INT_AD;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import albums.gallery.photo.folder.picasa.app.web.gallery.GoogleAnalyticsEvent;
import albums.gallery.photo.folder.picasa.app.web.gallery.R;
import albums.gallery.photo.folder.picasa.app.web.gallery.FirebaseConfigHelper;
import albums.gallery.photo.folder.picasa.app.web.gallery.activities.MainActivity;
import albums.gallery.photo.folder.picasa.app.web.gallery.startLikePro.Activity.SubScriptionActivity;

public class WelFavouriteActivity extends AppCompatActivity {

    private Animation animFadeIn;
    TextView textview_title1, textview_title2, skip_text;
    ImageView fav_icon;
    RelativeLayout third_act_layout;
    private Animation animFadeIn_bottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wel_favourite);
        getWindow().setStatusBarColor(Color.parseColor("#ffffff"));
        textview_title1 = findViewById(R.id.textview_title1);
        textview_title2 = findViewById(R.id.textview_title2);
        third_act_layout = findViewById(R.id.third_act_layout);
        fav_icon = findViewById(R.id.fav_icon);
        skip_text = findViewById(R.id.skip_text);
        skip_text.setPaintFlags(skip_text.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        animFadeIn_bottom = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_bottom);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                fav_icon.setVisibility(View.VISIBLE);
                fav_icon.startAnimation(animFadeIn_bottom);

            }
        }, 600);
        animFadeIn = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.pull_out);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                textview_title1.setAnimation(animFadeIn);
                textview_title1.setVisibility(View.VISIBLE);
            }
        }, 200);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                textview_title2.setAnimation(animFadeIn);
                textview_title2.setVisibility(View.VISIBLE);
            }
        }, 350);

        third_act_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.getAddToFavourites(),
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.getNext_button());
                startActivity(new Intent(WelFavouriteActivity.this, WelRecycleBinActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                overridePendingTransition(R.anim.enter, R.anim.exit);
                finish();

            }
        });
        skip_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleAnalyticsEvent.logAdapter(
                    GoogleAnalyticsEvent.getAddToFavourites(),
                    GoogleAnalyticsEvent.click,
                    GoogleAnalyticsEvent.getSkip_button()
                );


                if (!FirebaseConfigHelper.getIsAppAdFree(WelFavouriteActivity.this)
                    && FirebaseConfigHelper.isNetworkConnected(WelFavouriteActivity.this) && verifyInstallerId(WelFavouriteActivity.this)
                    && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)
                ) {
                    startActivity(new Intent(WelFavouriteActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    overridePendingTransition(R.anim.enter, R.anim.exit);
                    finish();
                } else {
                    startActivity(new Intent(WelFavouriteActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true));

                    finish();

                }

            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!FirebaseConfigHelper.getIsAppAdFree(WelFavouriteActivity.this)
            && FirebaseConfigHelper.isNetworkConnected(WelFavouriteActivity.this) && verifyInstallerId(WelFavouriteActivity.this)
            && FirebaseConfigHelper.remoteConfig.getBoolean(FirebaseConfigHelper.inAppSubscriptionenabled)) {
            startActivity(new Intent(WelFavouriteActivity.this, SubScriptionActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            overridePendingTransition(R.anim.enter, R.anim.exit);
        } else {
            startActivity(new Intent(WelFavouriteActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(SHOW_INT_AD, true));
        }
        finish();
    }

}
