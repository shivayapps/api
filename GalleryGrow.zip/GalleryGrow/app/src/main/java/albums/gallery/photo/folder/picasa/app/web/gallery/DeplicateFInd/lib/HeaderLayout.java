package albums.gallery.photo.folder.picasa.app.web.gallery.DeplicateFInd.lib;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class HeaderLayout extends FrameLayout {
    private int mHeaderWidth = 1;

    public HeaderLayout(Context context) {
        super(context);
    }

    public HeaderLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public HeaderLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public void onMeasure(int i, int i2) {
        if (this.mHeaderWidth != 1) {
            try {
                i = MeasureSpec.makeMeasureSpec(this.mHeaderWidth, MeasureSpec.getMode(i));
            } catch (Exception e) {

            }
        }
        super.onMeasure(i, i2);
    }

    public void setHeaderWidth(int i) {
        this.mHeaderWidth = i;
    }
}
