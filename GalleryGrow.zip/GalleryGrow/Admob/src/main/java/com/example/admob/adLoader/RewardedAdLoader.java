package com.example.admob.adLoader;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.admob.utils.PreferenceManager;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.firebase.analytics.FirebaseAnalytics;


public class RewardedAdLoader {
    static RewardedAd mRewardedAd;

    private static String F_Request = "f_request";
    private static String F_Load = "f_load";
    private static String F_Fail_Load = "f_fail_load";
    private static String F_Show = "f_show";
    private static String F_Dismiss = "f_dismiss";
    private static String F_Impression = "f_impression";
    private static String F_Show_Fail = "f_show_fail";
    private static String F_Click = "f_click";


    private static String B_Request = "b_request";
    private static String B_Load = "b_load";
    private static String B_Fail_Load = "b_fail_load";
    private static String eventName = "Admob_Reward";

    public interface mCallBack {
        void done(boolean isReworded);

        void failed(boolean isReworded);
    }

    public static void loadAd(Context context, String admob_rewarded, String admob_back_rewarded, String back_id_required,String activityName,FirebaseAnalytics analytics) {
        loadRewardedVideoAd(context, admob_rewarded, admob_back_rewarded, back_id_required,activityName,analytics);
    }

    public static boolean isAdLoaded() {
        return mRewardedAd != null;
    }

    static boolean isRewarded;

    public static void showVideoAd(Activity activity, final mCallBack mCallBack,String activityName,FirebaseAnalytics analytics) {
        if (isAdLoaded()) {
            isRewarded = false;
            mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdShowedFullScreenContent() {
                    PreferenceManager.Companion.saveToShowOpenAd(activity, false);
                    // Called when ad is shown.
                    isRewarded = true;
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Show, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Show + " + " + activityName + " ");
                }

                @SuppressLint("WrongConstant")
                @Override
                public void onAdFailedToShowFullScreenContent(AdError adError) {
                    // Called when ad fails to show.
                    PreferenceManager.Companion.saveToShowOpenAd(activity, true);
                    Toast.makeText(activity, "Video AD is not available ... please try again", 1).show();
                    Log.w("msg", "Ad failed to show.");
//                    isRewarded = true;
                    mCallBack.failed(isRewarded);
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Show_Fail, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Show_Fail + " + " + activityName + " " + " Error : " + adError.getCode());
                    F_Show = "f_show";
                    F_Dismiss = "f_dismiss";
                    F_Impression = "f_impression";
                    F_Show_Fail = "f_show_fail";
                    F_Click = "f_click";

                }
                @Override

                public void onAdClicked() {
                    super.onAdClicked();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Click, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Click + " + " + activityName + " ");

                }
                @Override
                public void onAdImpression() {
                    super.onAdImpression();
                    Bundle bundle = new Bundle();
                    bundle.putString(F_Dismiss, activityName);
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Impression + " + " + activityName + " ");
                }

                @Override
                public void onAdDismissedFullScreenContent() {
                    PreferenceManager.Companion.saveToShowOpenAd(activity, true);
                    Bundle bundle = new Bundle();
                    if (analytics != null) {
                        analytics.logEvent(eventName, bundle);
                    }
                    Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Dismiss + " + " + activityName + " ");

                    F_Show = "f_show";
                    F_Dismiss = "f_dismiss";
                    F_Impression = "f_impression";
                    F_Show_Fail = "f_show_fail";
                    F_Click = "f_click";

                    mCallBack.done(isRewarded);
                }
            });
            mRewardedAd.show(activity, new OnUserEarnedRewardListener() {
                @Override
                public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                    // Handle the reward.
                    Log.w("msg", "The user earned the reward.");
                    isRewarded = true;
                }
            });
        } else {
            mCallBack.failed(isRewarded);
        }
    }

    public static void loadRewardedVideoAd(Context context, String admob_rewarded, String admob_back_rewarded, String back_id_required, String activityName, FirebaseAnalytics analytics) {
        Bundle bundle = new Bundle();
        bundle.putString(F_Request, activityName);
        if (analytics != null) {
            analytics.logEvent(eventName, bundle);
        }
        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Request + " + " + activityName + " " + eventName);
        if (!isAdLoaded()) {
            RewardedAd.load(context, admob_rewarded,
                new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                        mRewardedAd = rewardedAd;
                        isRewarded = true;
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Load + " + " + activityName + " " + eventName);
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        // Handle the error.
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Fail_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Fail_Load + " " + loadAdError.getCode() +" "+ activityName + " " + eventName );
                        mRewardedAd = null;
                        isRewarded = false;
                        if (back_id_required.equals("true")) {
                            loadRewardedVideoAdReLoad(context, admob_back_rewarded,activityName,analytics);
                        }
                    }
                });
        }
    }

    public static void loadRewardedVideoAdReLoad(Context context, String admob_back_rewarded,String activityName,FirebaseAnalytics analytics) {
        Bundle bundle = new Bundle();
        bundle.putString(B_Request, activityName);
        if (analytics != null) {
            analytics.logEvent(eventName, bundle);
        }
        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + F_Request + " + " + activityName + " " + eventName);

        if (!isAdLoaded()) {
            RewardedAd.load(context, admob_back_rewarded,
                new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        // Handle the error.
                        Log.w("msg", loadAdError.getMessage());
                        mRewardedAd = null;
                        isRewarded = false;
                        Bundle bundle = new Bundle();
                        bundle.putString(B_Fail_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + B_Fail_Load + " "+ loadAdError.getCode()+" " + activityName + " " + eventName);
                    }

                    @Override
                    public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                        mRewardedAd = rewardedAd;
                        isRewarded = true;
                        F_Show = "b_show";
                        F_Dismiss = "b_dismiss";
                        F_Impression = "b_impression";
                        F_Show_Fail = "b_show_fail";
                        F_Click = "b_click";
                        Bundle bundle = new Bundle();
                        bundle.putString(F_Load, activityName);
                        if (analytics != null) {
                            analytics.logEvent(eventName, bundle);

                        }
                        Log.w("msg", "Admob - - - - - - - - - - " + eventName + " + " + B_Load + " "+ " " + activityName + " " + eventName);

                    }
                });
        }
    }
}
