package com.gallery.photo.album.video.adshelper

import android.animation.Animator
import android.app.Activity
import android.util.Log
import android.view.View
import com.airbnb.lottie.LottieAnimationView
import com.example.appcenter.utilities.isInterstitialShown
import com.gallery.photo.album.video.R
import com.google.android.gms.ads.interstitial.InterstitialAd

@JvmField
var isAnimationRunning = false

class LottieGiftIconHelper(private val mActivity: Activity) : View.OnClickListener {

    var TAG = javaClass.simpleName

    private var isInterstitialAdLoaded = false
    private var interstitial: InterstitialAd? = null
    private var giftIcon: LottieAnimationView = mActivity.findViewById(R.id.main_la_gift)
    private val giftIconBlast: LottieAnimationView = mActivity.findViewById(R.id.main_la_gift_blast)

    init {
        giftIcon.visibility = View.GONE
        giftIconBlast.visibility = View.GONE
        loadNewInterstitialAd(mActivity)
        giftIcon.setOnClickListener(this)
        setLottieJson(giftIcon, "gift.json")
        //   setLottieJson(giftIcon, "lottie/blast_gift.json")
        setLottieJson(giftIconBlast, "blast_gift.json")

        giftIconBlast.addAnimatorListener(object : Animator.AnimatorListener {
            override fun onAnimationRepeat(p0: Animator?) {

            }

            override fun onAnimationEnd(p0: Animator?) {

                giftIconBlast.visibility = View.GONE
                isAnimationRunning = false
                if (isAdLoaded()) {
                    interstitial!!.show(mActivity)
                }
            }

            override fun onAnimationCancel(p0: Animator?) {

            }

            override fun onAnimationStart(p0: Animator?) {

            }
        })
    }


    private fun loadNewInterstitialAd(fActivity: Activity) {


        InterstitialAdHelper.instance!!.load(fActivity, object : InterstitialAdHelper.InterstitialAdListener {
            override fun onAdLoaded(interstitialAd: InterstitialAd) {
                interstitial = interstitialAd
                isInterstitialAdLoaded = true
                giftIcon.visibility = View.VISIBLE
                giftIconBlast.visibility = View.GONE
            }


            override fun onAdFailedToLoad() {
                isInterstitialAdLoaded = false
                giftIcon.visibility = View.GONE
                giftIconBlast.visibility = View.GONE
                loadNewInterstitialAd(fActivity)
            }

            override fun onAdClosed() {
                isInterstitialAdLoaded = false
                isInterstitialShown =  false
                giftIconBlast.visibility = View.GONE
                giftIcon.visibility = View.GONE
                loadNewInterstitialAd(fActivity)
            }
        })
    }

    override fun onClick(v: View) {
        if (v === giftIcon) {
            giftIcon.visibility = View.GONE
            giftIconBlast.visibility = View.VISIBLE
            giftIconBlast.playAnimation()
            isAnimationRunning = true
            isInterstitialShown = true
            if (!isAdLoaded()) {
                giftIcon.visibility = View.GONE
                giftIconBlast.visibility = View.GONE
            }
        }
    }

    private fun isAdLoaded(): Boolean {
        return isInterstitialAdLoaded
    }

    fun setLottieJson(view: LottieAnimationView, iconPath: String?) {
        if (iconPath.isNullOrEmpty())
            return
        try {
            view.setAnimation(iconPath)
            view.playAnimation()
        } catch (e: Exception) {
            Log.e(TAG, e.toString())
            view.playAnimation()
        }
    }


}