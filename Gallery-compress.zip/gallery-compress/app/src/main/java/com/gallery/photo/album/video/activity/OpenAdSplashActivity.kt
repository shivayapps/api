package com.gallery.photo.album.video.activity

import android.app.Activity
import android.content.Intent
import android.os.*
import android.util.Log
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.appcenter.jsonparsing.JsonParserCallback
import com.example.appcenter.utilities.*
import com.gallery.photo.album.video.BuildConfig
import com.gallery.photo.album.video.utilities.OnPositive
import com.gallery.photo.album.video.utilities.showAlert
import com.gallery.photo.album.video.utilities.isOnline

import com.gallery.photo.album.video.R
import com.gallery.photo.album.video.adshelper.AdsManager
import com.gallery.photo.album.video.adshelper.InterstitialAdHelper
import com.gallery.photo.album.video.dialog.ChangePattrenLockDialog
import com.gallery.photo.album.video.extensions.config
import com.gallery.photo.album.video.fragment.REQUEST_CODE_CHECK_PASSWORD
import com.gallery.photo.album.video.inapp.InAppPurchaseHelper
import com.gallery.photo.album.video.lock.activity.CustomPinActivity
import com.gallery.photo.album.video.lock.managers.AppLock
import com.gallery.photo.album.video.rateandfeedback.ExitSPHelper
import com.gallery.photo.album.video.rateandfeedback.rateApp
import com.gallery.photo.album.video.retrofit.APIService
import com.gallery.photo.album.video.retrofit.model.ForceUpdateModel
import com.gallery.photo.album.video.updatejsonparsing.GetJsonUpdateResponseTask
import com.gallery.photo.album.video.updatejsonparsing.getForceUpdate
import com.gallery.photo.album.video.updatejsonparsing.saveForceUpdate
import com.gallery.photo.album.video.utilities.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import kotlinx.android.synthetic.main.activity_splash.*
import kotlinx.android.synthetic.main.fragment_vault.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.system.exitProcess


private val TAG = OpenAdSplashActivity::class.java.simpleName
private const val SPLASH_DELAY = 5000L

class OpenAdSplashActivity : BaseActivity(), InAppPurchaseHelper.OnPurchased, InterstitialAdHelper.InterstitialAdListener {


    private var isPaused = false // For check in onResume if app is paused or lunch
    private var adsCountDownTimer: AdsCountDownTimer? = null
    private val REQUEST_CODE_CHECK = 1184

    private var isAdClosed = false
    private var isNextActivity = true

    /*override fun attachBaseContext(newBase: Context?) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase!!))
    }
*/

    companion object {
        public var activity: Activity? = null
        var interstitial: InterstitialAd? = null
    }

    // TODO: 09/06/21 for android 11 storage permission
    var goToSetting = false
    override fun onCreate(savedInstanceState: Bundle?) {
        window.setFlags(1024, 1024)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        activity = this
        // Un-Comment this method to test firebase analytics
        //  forceCrash()
    }

    override fun getContext(): Activity {
        return this
    }


    override fun initData() {
        Log.d(TAG, "initData: ")
        //  Call Daily Notification to received offline notification
//        dailyNotifications()

        // Need to set save rate dialog dismiss false if it is true
        // So we can again show rate dialog on back press of the main activity
        if (ExitSPHelper(this).isDismissed()) {
            ExitSPHelper(this).saveDismissed(false)
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.instance!!.load(this, this)
        }

        if (isOnline()) {
            // Fetch App center data from the server
            if (isSDKBelow21()) {
                // Simple json parsing
                val url = getUpdateBaseUrl() + "ApkVersion"
                val pkgName = packageName
                val version = BuildConfig.VERSION_NAME.toDouble()
                GetJsonUpdateResponseTask(object : JsonParserCallback {
                    override fun onSuccess(response: String) {
                        Log.i(TAG, response)
                        saveForceUpdate(response)
                        Log.d(TAG, "checkUpdateStatus: --> forceUpdate 111")
                        checkUpdateStatus(getForceUpdate()!!)
                    }

                    override fun onFailure(message: String) {
                        Log.e(TAG, message)
                        initBilling()
                    }

                }).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, url, pkgName, version.toString())

            } else {
                // Using retrofit with kotlin coroutine
                // To verify force update status
                GlobalScope.launch {
                    checkForceUpdateStatus()
                }
            }
        } else {
            Log.i(TAG, "offline")
            initBilling()
        }
    }

    override fun initActions() {

    }


    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    private suspend fun checkForceUpdateStatus() {
        return withContext(Dispatchers.IO) {
            val retroApiInterface = APIService().getUpdateClient(this@OpenAdSplashActivity)
            try {
                val pkgName = packageName
                val version = BuildConfig.VERSION_NAME.toDouble()

                val reqUpdateStatus = retroApiInterface.getUpdateStatusAsync(pkgName, version)
                val resUpdateStatus = reqUpdateStatus.await()
                if (resUpdateStatus.isSuccessful && resUpdateStatus.body() != null) {
                    val body = resUpdateStatus.body()!!
                    Log.e(TAG, "message: " + body.message)
                    Log.d(TAG, "checkUpdateStatus: --> forceUpdate 222")
                    checkUpdateStatus(body)
                } else {
                    Log.e(TAG, "isSuccessful: false")
                }

            } catch (exception: Exception) {
                Log.e(TAG, exception.toString())
                initBilling()
            }
        }
    }

    private fun checkUpdateStatus(forceUpdateModel: ForceUpdateModel) {

        Log.e(TAG, "message: " + forceUpdateModel.message)
        if (forceUpdateModel.is_need_to_update) {
            Log.i(TAG, "is_need_to_update: true")
            runOnUiThread {
//                progress.visibility = View.GONE
                showAlert(
                    getString(R.string.update_required),
                    getString(R.string.update_message),
                    getString(R.string.update_positive),
                    getString(R.string.update_negative),
                    fontPath,
                    object : OnPositive {
                        override fun onYes() {
                            rateApp()
                            finish()
                        }

                        override fun onNo() {
                            super.onNo()
                            finishAffinity()
                        }
                    })
            }
        } else {
            Log.e(TAG, "is_need_to_update: false")
            initBilling()
        }
    }

    // Every time to need initialize billing
    // to check if subscription or in-app purchase was made or not and even if it is made then to check is it active or expired
    private fun initBilling() {
        runOnUiThread {

            // interstitial = InterstitialAdHelper.instance!!.load(mContext, this)
            try {
                InAppPurchaseHelper.instance!!.initBillingClient(this, this)
            } catch (e: Exception) {
                Log.e(TAG, "initBillingClient: " + e.message)
            }
        }
    }


    /**
     * Called when leaving the mContext
     */
    public override fun onPause() {
        super.onPause()
        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }
        isPaused = true
    }

    override fun onBackPressed() {
        super.onBackPressed()
        Log.i(TAG, "onBackPressed")
        exitProcess(0)
    }

    /**
     * Called when returning to the mContext
     */
    public override fun onResume() {
        super.onResume()
        isMoreAppsClick = true
        Log.i(TAG, "onResume")
//        if (isAdClosed) {
//            Log.i(TAG, "isAdClosed")
//        } else {
        // Perform your task
//            if (AdsManager(mContext).isNeedToShowAds() && interstitial != null) {
//                Log.i(TAG, "Ads loaded..")
//                interstitial?.show(this)
//            }
        if (!isPaused) {
            Log.i(TAG, "is not paused")
            return
        }

        isAdClosed = true
        Handler().postDelayed({ startHome() }, 100)

        Log.i(TAG, "Ads not loaded or may be null")
//        }
    }

    /**
     * AdsCountDownTimer for 5 sec delay
     */
    inner class AdsCountDownTimer(millisInFuture: Long, countDownInterval: Long) : CountDownTimer(millisInFuture, countDownInterval) {
        override fun onTick(millisUntilFinished: Long) {
            tv_count_down.text = (((SPLASH_DELAY - millisUntilFinished) / 1000) + 1).toString()
            Log.i(TAG, "countDownTimer: -->" + tv_count_down.text)
        }

        override fun onFinish() {
            Log.i(TAG, "countDownTimer: onFinish")
//            if (isAdClosed) {
////                Log.e(TAG, "isAdClosed")
//            } else {
//                if (interstitial != null) {
//                    interstitial!!.fullScreenContentCallback = null
//                }
//                if (interstitial != null) {
//                    isInterstitialShown = true
//                    interstitial!!.show(this@OpenAdSplashActivity)
//                } else {
//                    isPaused = true
            startHome()
//                }
//            }
        }
    }

    /**
     * If app is not purchased or subscription not found start count down for 5 sec and load ad
     */
    private fun startSplashDelay() {
//        adsCountDownTimer = AdsCountDownTimer(SPLASH_DELAY, 1000)
//        adsCountDownTimer!!.start()
//        tv_count_down.text = (SPLASH_DELAY / 1000).toString()
//        Log.i(TAG, "Loading")
//

        Log.e(TAG, "startSplashDelay: ")
        try {
            if (isOnline()) {
                adsCountDownTimer = AdsCountDownTimer(1000, 500)
                adsCountDownTimer!!.start()
                Log.e(TAG, "startSplashDelay:5000 ")
            } else {
                adsCountDownTimer = AdsCountDownTimer(1000, 200)
                adsCountDownTimer!!.start()
                Log.e(TAG, "startSplashDelay:1000 ")
            }
            Log.e(TAG, "startSplashDelay:Loading... ")
        } catch (e: java.lang.Exception) {
            Log.e(TAG, "startSplashDelay: " + e.message)
            Thread.sleep(3000)
//            if (isAdClosed) {
//                Log.e(TAG, "isAdClosed")
//            } else {
//                if (interstitial != null) {
//                    interstitial!!.fullScreenContentCallback = null
//                }
//                if (interstitial != null) {
//                    isInterstitialShown = true
//                    interstitial!!.show(this@OpenAdSplashActivity)
//                } else {
            isPaused = true
            startHome()
//                }
//            }
        }


        InterstitialAdHelper.instance!!.load(mContext, this)
    }

    /**
     * Start your splash home our desire activity
     */
    private fun startHome() {
        if (adsCountDownTimer != null) {
            adsCountDownTimer!!.cancel()
        }
        startNextActivity()
//        checkStoragePermission()
//        if (!config.isEnableLock && AdsManager(this).isNeedToShowAds() && appOpenManager!!.isAdAvailable) {
//            /* appOpenManager!!.showAdIfAvailable(object : OnDismissListener {
//                 override fun onDismiss() {
//                     checkStoragePermission()
// //                    startActivity(MainActivity.newIntent(this))
//                 }
//             })*/
//            checkStoragePermission()
//        } else {
////            startActivity(MainActivity.newIntent(this))
//            checkStoragePermission()
//        }
    }

    private fun checkStoragePermission() {
        /*if (config.isAppPasswordProtectionOn && config.isEnableLock) {


            val intent = Intent(this, AppLockScreenActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//          intent.putExtra(AppLock.LOCK_TYPE, Share.LOCK_PIN)
//          intent.putExtra("is_play", false)
            startActivityForResult(intent, 10101)

            //Animate if greater than 2.3.3
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)


        } else {
            startNextActivity()
        }*/
//        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
//            if (interstitial != null) {
//                Log.d(TAG, "checkStoragePermission:-->AdShow ")
//                interstitial!!.show(this)
//            } else {
//                startNextActivity()
//            }
//        } else {

        startNextActivity()
//        }
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!checkPermissionabove11()) {
                showGetPermissionDialog11()
            } else {
                startNextActivity()
            }

        } else {
            handlePermission(PERMISSION_WRITE_STORAGE) {
                if (it) {
                    startNextActivity()
                }
            }
        }*/
    }

    /*private fun showGetPermissionDialog11() {
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle("Permissions Required")
            .setMessage("This Application needs permission to access the files.please allow access to manage all files")
            .setPositiveButton("Ok") { dialog, which ->
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, mUri)

                startActivityForResult(intent, REQ_CODE_FOR_MANAGE_STORAGE)
//                startpermissionactivity.launch(intent)
            }
            .setNegativeButton("Cancel") { dialog, which -> //my code
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
            .create()
            .show()
    }*/


    /* var startpermissionactivity = registerForActivityResult(
         ActivityResultContracts.StartActivityForResult()
     ) {

         if (checkPermissionabove11()) {
             startNextActivity()
         } else {
             val alertDialogBuilder = android.app.AlertDialog.Builder(this, R.style.MyAlertDialogNew)
             alertDialogBuilder.setTitle("Permissions Required")
                 .setMessage("This Application needs permission to access the files.please allow access to manage all files")
                 .setPositiveButton("Ok") { dialog, which ->
                     val intent = Intent(
                         Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                         mUri
                     )
                     startActivity(intent)
                 }
                 .setNegativeButton("Cancel") { dialog, which -> //my code
                     dialog.dismiss()
                     finish()
                 }
                 .setCancelable(false)
                 .create()
                 .show()
         }
     }*/


    /*override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_CODE_FOR_MANAGE_STORAGE -> {

                if (requestCode == REQ_CODE_FOR_MANAGE_STORAGE && checkPermissionabove11()) {
                    startNextActivity()
                } else {


                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {

                        val alertDialogBuilder = android.app.AlertDialog.Builder(this, R.style.MyAlertDialogNew)
                        alertDialogBuilder.setTitle("Permissions Required")
                            .setMessage("Please allow access to manage all files")
                            .setPositiveButton("Ok") { dialog, which ->
                                startActivityForResult(
                                    Intent(
                                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                        mUri
                                    ), REQ_CODE_FOR_MANAGE_STORAGE
                                )
                            }
                            .setNegativeButton("Cancel") { dialog, which -> //my code
                                dialog.dismiss()
                                finish()
                            }
                            .setCancelable(false)
                            .create()
                            .show()
                    }
                }
            }
        }
    }*/

    private fun startNextActivity() {
        if (isNextActivity) {
            isMoreAppsClick = true
            isNextActivity = false
            Log.d("Lock1245645", "startNextActivity: config.oldLockTypePattern --->" + config.oldLockTypePattern)
            Log.d("Lock1245645", "startNextActivity: config.oldLockTypeWhenFingerPrintEnable --->" + config.oldLockTypeWhenFingerPrintEnable)
            Log.d("Lock1245645", "startNextActivity: config.isAppPasswordProtectionOn --->" + config.isAppPasswordProtectionOn)
            Log.d("Lock1245645", "startNextActivity: config.isEnableLock --->" + config.isEnableLock)
            if (config.oldLockTypeWhenFingerPrintEnable.isNotEmpty()) {
                config.isFingerprintEnable = true
            }
            if (config.oldLockTypePattern == LOCK_PATTERN || config.oldLockTypeWhenFingerPrintEnable == LOCK_PATTERN) {
                config.isAppPasswordProtectionOn = false
                config.isEnableLock = false
                config.oldLockTypePattern = ""
                config.oldLockTypeWhenFingerPrintEnable = ""
            }

            startActivity(MainActivity.newIntent(this))
        }
//        finish()


    }


    override fun onPurchasedSuccess(purchase: Purchase) {

    }

    override fun onProductAlreadyOwn() {

    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        GlobalScope.launch(Dispatchers.Main) {
            InAppPurchaseHelper.instance!!.initProducts()
            Log.i(TAG, "IN_APP_BILLING | Done")
            redirectToNextActivity()
        }
    }


    override fun onBillingUnavailable() {
        redirectToNextActivity()
    }

    override fun onBillingKeyNotFound(productId: String) {

    }

    private fun redirectToNextActivity() {
        // Check if in-app or subscription already purchased
        config.isAlertBattery = false
        config.isChargerAlert = false
//        if (config.isAlertBattery) {
//            if (!config.isServiceRunning(this, BatteryLevelAlertService_LOCK::class.java)) {
//                val intent = Intent(this, BatteryLevelAlertService_LOCK::class.java)
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    applicationContext.startForegroundService(intent)
//                } else {
//                    startService(intent)
//                }
//            }
//        }
//        if (config.isChargerAlert) {
//            if (!config.isServiceRunning(this, PowerChargerConnectionServiceLOCK::class.java)) {
//                val intent = Intent(this, PowerChargerConnectionServiceLOCK::class.java)
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    applicationContext.startForegroundService(intent)
//                } else {
//                    startService(intent)
//                }
//            }
//        }
        if (AdsManager(this).isNeedToShowAds()) {
            startSplashDelay()
        } else {
            startHome()
        }
    }

    private fun forceCrash() {
        throw  RuntimeException("Test Crash") // Force a crash
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1010) {
            redirectToNextAfterLockVerify()
        }
        if (requestCode == 10101) {
            redirectToNextAfterLockVerify()
        }
        if (requestCode == REQUEST_CODE_CHECK_PASSWORD) {
            if (resultCode == RESULT_OK) {
                Toast.short(this, getString(R.string.msg_lock_set_sccessfully))
                config.isAppPasswordProtectionOn = true
                config.isEnableLock = true
                config.oldLockTypePattern = ""
                config.oldLockTypeWhenFingerPrintEnable = ""
//                startNextActivity()

            }
        }


    }

    private fun redirectToNextAfterLockVerify() {
        if (isUnLockApp) {
            if (config.oldLockTypePattern == LOCK_PATTERN || config.oldLockTypeWhenFingerPrintEnable == LOCK_PATTERN) {
//              Handler().postDelayed({
                ChangePattrenLockDialog(this) {
                    if (it) {
                        val intent = Intent(this, CustomPinActivity::class.java)
                        //Intent intent = new Intent(AppLockScreenActivity.this, AppLockActivity.class);
                        intent.putExtra(AppLock.EXTRA_TYPE, AppLock.ENABLE_PINLOCK)
                        intent.putExtra("ChangePatternLock", true)
//                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                    } else {
                        finish()
                    }
                }
//              },1000)

            } else {
//                startNextActivity()
            }

        } else {
            checkStoragePermission()
        }
    }

    override fun onAdLoaded(interstitialAd: InterstitialAd) {
//        Log.d(TAG, "checkStoragePermission:-->Ad Loaded ")
        interstitial = interstitialAd
//        interstitialAd.show(this)

    }

    override fun onAdFailedToLoad() {
//        Log.d(TAG, "checkStoragePermission:-->Failed to load ad ")
//        InterstitialAdHelper.instance!!.load(this, this)
    }

    override fun onAdClosed() {
//        isAdClosed = true
//        Log.d(TAG, "checkStoragePermission:-->ad closed ")
//        startNextActivity()
    }

}