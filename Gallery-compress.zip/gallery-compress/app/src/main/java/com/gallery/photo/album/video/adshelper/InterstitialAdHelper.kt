package com.gallery.photo.album.video.adshelper

import android.app.Activity
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.gallery.photo.album.video.R

private val TAG = "Admob_" + InterstitialAdHelper::class.java.simpleName

class InterstitialAdHelper {

    fun load(mContext: Activity, adListener: InterstitialAdListener) {


        var mInterstitialAd: InterstitialAd? = null
        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(mContext, mContext.getString(R.string.inter_ad_unit_id), adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.i(TAG, "onAdFailedToLoad: Interstitial, Ad failed to load : ${adError.responseInfo}")
                mInterstitialAd = null
                adListener.onAdFailedToLoad()
            }

            override fun onAdLoaded(interstitialAd: InterstitialAd) {
                Log.i(TAG, "onAdLoaded: ")
                mInterstitialAd = interstitialAd
                adListener.onAdLoaded(interstitialAd)

                mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        Log.i(TAG, "onAdDismissedFullScreenContent")
                        adListener.onAdClosed()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                        Log.i(TAG, "onAdFailedToShowFullScreenContent")
                    }

                    override fun onAdShowedFullScreenContent() {
                        Log.i(TAG, "onAdShowedFullScreenContent")
                        mInterstitialAd = null
                    }
                }
            }
        })


    }

    interface InterstitialAdListener {
        fun onAdLoaded(interstitialAd: InterstitialAd)
        fun onAdFailedToLoad()
        fun onAdClosed()
    }

    companion object {
        var instance: InterstitialAdHelper? = null
            get() {
                if (field == null) {
                    synchronized(InterstitialAdHelper::class.java) {
                        if (field == null) {
                            field = InterstitialAdHelper()
                        }
                    }
                }
                return field
            }
            private set
    }

}