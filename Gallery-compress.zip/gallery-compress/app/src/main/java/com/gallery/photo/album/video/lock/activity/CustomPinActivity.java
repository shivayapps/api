package com.gallery.photo.album.video.lock.activity;

import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.gallery.photo.album.video.R;
import com.gallery.photo.album.video.lock.managers.AppLockActivity;
import com.gallery.photo.album.video.utilities.ConstantsKt;

import uk.me.lewisdeane.ldialogs.BaseDialog;
import uk.me.lewisdeane.ldialogs.CustomDialog;


/**
 * Created by oliviergoutay on 1/14/15.
 */
public class CustomPinActivity extends AppLockActivity {

    @Override
    public void showForgotDialog() {
        Resources res = getResources();
        // Create the builder with required paramaters - Context, Title, Positive Text
        CustomDialog.Builder builder = new CustomDialog.Builder(this,
                res.getString(R.string.activity_dialog_title),
                res.getString(R.string.activity_dialog_accept));
        builder.content(res.getString(R.string.activity_dialog_content));
        builder.negativeText(res.getString(R.string.activity_dialog_decline));

        //Set theme
        builder.darkTheme(false);
        builder.typeface(Typeface.SANS_SERIF);
        builder.positiveColor(res.getColor(R.color.light_blue_500)); // int res, or int colorRes parameter versions available as well.
        builder.negativeColor(res.getColor(R.color.light_blue_500));
        builder.rightToLeft(false); // Enables right to left positioning for languages that may require so.
        builder.titleAlignment(BaseDialog.Alignment.CENTER);
        builder.buttonAlignment(BaseDialog.Alignment.CENTER);
        builder.setButtonStacking(false);

        //Set text sizes
        builder.titleTextSize((int) res.getDimension(R.dimen._12ssp));
        builder.contentTextSize((int) res.getDimension(R.dimen._11ssp));
        builder.positiveButtonTextSize((int) res.getDimension(R.dimen._12ssp));
        builder.negativeButtonTextSize((int) res.getDimension(R.dimen._12ssp));

        //Build the dialog.
        CustomDialog customDialog = builder.build();
        customDialog.setCanceledOnTouchOutside(false);
        customDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        customDialog.setClickListener(new CustomDialog.ClickListener() {
            @Override
            public void onConfirmClick() {
                Toast.makeText(getApplicationContext(), "Yes", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelClick() {
                Toast.makeText(getApplicationContext(), "Cancel", Toast.LENGTH_SHORT).show();
            }
        });

        // Show the dialog.
        customDialog.show();
    }

    @Override
    public void onPinFailure(int attempts) {

    }

    @Override
    public void onPinSuccess(int attempts) {

    }

    @Override
    public int getPinLength() {
        return super.getPinLength();//you can override this method to change the pin length from the default 4
    }

    /**
     * Created by callmepeanut on 16-1-14.
     */

    public static class LockedCompatActivity extends PinCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_compat_locked);
            initView();
            ConstantsKt.setAppOpenAdShow(false);

        }

        private void initView() {
            Toolbar toolbar = (Toolbar) findViewById(R.id.id_toolbar);
            setSupportActionBar(toolbar);

            toolbar.setTitle("Title");
            toolbar.setTitleTextColor(getResources().getColor(android.R.color.white));
            toolbar.setSubtitle("SubTitle");
            toolbar.setSubtitleTextColor(getResources().getColor(android.R.color.white));
            toolbar.setLogo(R.drawable.ic_launcher);
            toolbar.setNavigationIcon(R.drawable.ic_gallery_sidemenu);
//            toolbar.setBackgroundColor(Share.getAPPThemWisePrimoryColor(getApplicationContext()));
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            ConstantsKt.setAppOpenAdShow(false);

        }
    }
}
