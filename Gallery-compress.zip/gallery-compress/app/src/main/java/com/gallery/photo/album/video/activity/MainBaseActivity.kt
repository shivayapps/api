package com.gallery.photo.album.video.activity

import android.app.Activity
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import com.gallery.photo.album.video.utilities.SPUtil
import com.gallery.photo.album.video.extensions.addPathToDB
import com.gallery.photo.album.video.extensions.updateDirectoryPath
import com.gallery.photo.album.video.extensions.getParentPath
import com.gallery.photo.album.video.extensions.getRealPathFromURI

abstract class MainBaseActivity : BaseSimpleActivity(), View.OnClickListener {

    lateinit var mContext: Activity // Context of the current activity
    lateinit var sp: SPUtil // Obj. of SharedPreference
    //private var jpDialog: JProgress? = null
    val REQ_CODE_FOR_MANAGE_STORAGE = 100;

    // variable to track event time
    open var mLastClickTime: Long = 0
    open var mMinDuration = 1000
    val observer = object : ContentObserver(null) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            super.onChange(selfChange, uri)
            if (uri != null) {
                val path = getRealPathFromURI(uri)
                if (path != null) {
                    updateDirectoryPath(path.getParentPath())
                    addPathToDB(path)
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = getContext()
        sp = SPUtil(mContext)
        //jpDialog = JProgress.create(mContext, JProgress.Style.SPIN_INDETERMINATE)
    }

    override fun setContentView(layout: Int) {
            super.setContentView(layout)

        initViews()
        initAds()
        initData()
        initActions()
    }


    fun showGetPermissionDialog11() {
//        isMoreAppsClick = true
//        isUnLockApp = true
//        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
//        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>Permissions Required</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
//            .setMessage("This Application needs permission to access the files.please allow access to manage all files")
//            .setPositiveButton("Ok") { dialog, which ->
//                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
//
//                startActivityForResult(intent, REQ_CODE_FOR_MANAGE_STORAGE)
////                startpermissionactivity.launch(intent)
//            }
//            .setNegativeButton("Cancel") { dialog, which -> //my code
//                dialog.dismiss()
//                finishAffinity()
//            }
//            .setCancelable(false)
//
//        val alert = alertDialogBuilder.create()
//        alert.show()
//        val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.album.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
//        alert.window?.setBackgroundDrawable(bgDrawable)
//        alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(com.gallery.photo.album.video.R.color.color_primary))
//        alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(com.gallery.photo.album.video.R.color.color_primary))
//        alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(com.gallery.photo.album.video.R.color.color_primary))
    }


    /**
     * ToDo. Set the context of activity
     *
     * @return The context of activity.
     */
    abstract fun getContext(): Activity

    /**
     * ToDo. Use this method to setup views.
     */
    open fun initViews() {}

    /**
     * ToDo. Use this method to setup ads.
     */
    open fun initAds() {}

    /**
     * ToDo. Use this method to initialize data to view components.
     */
    abstract fun initData()

    /**
     * ToDo. Use this method to initialize action on view components.
     */
    abstract fun initActions()

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
    }

    fun jpShow() {
        //jpDialog?.show()
    }

    fun jpDismiss() {
        //jpDialog?.dismiss()
    }

    protected fun registerFileUpdateListener() {
        try {
            contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
            contentResolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
        } catch (ignored: Exception) {
        }
    }

    protected fun unregisterFileUpdateListener() {
        try {
            contentResolver.unregisterContentObserver(observer)
        } catch (ignored: Exception) {
        }
    }

}