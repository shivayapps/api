package com.gallery.photo.album.video.activity

import android.os.Bundle
import android.os.Handler
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.gallery.photo.album.video.R

class ExitActivity : AppCompatActivity() {
    var TAG = "TAG"
    public val timeoutHandler: Handler? = Handler()
    var runnable: Runnable? = null
    public var is_pause = false
  /*  override fun getActivityTheme(): Int {
        return if (PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false)) R.style.AppThemeNormalBlack else R.style.AppThemeLight
    }*/

    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exit)
    }

    public fun nextScreen() {
        finishAffinity()
        System.exit(0)
    }

    override fun onResume() {
        super.onResume()
        runnable = Runnable { nextScreen() }
        timeoutHandler!!.postDelayed(runnable!!, 1000)
        if (is_pause) {
            is_pause = false
        }
    }

    override fun onPause() {
        super.onPause()
        timeoutHandler?.removeCallbacks(runnable!!)
        is_pause = true
    }

    override fun onStop() {
        super.onStop()
        is_pause = true
        timeoutHandler?.removeCallbacks(runnable!!)
    }

    override fun onDestroy() {
        super.onDestroy()
        is_pause = true
        timeoutHandler?.removeCallbacks(runnable!!)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        nextScreen()
    }
}