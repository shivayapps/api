package com.gallery.photo.album.video.activity

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.View.*
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.appcenter.utilities.isInterstitialShown
import com.example.appcenter.utilities.isMoreAppsClick
import com.example.appcenter.utilities.isUnLockApp
import com.gallery.photo.album.video.utilities.isOnline
import com.gallery.photo.album.video.R
import com.gallery.photo.album.video.adapter.ViewPagerFragmentAdapter
import com.gallery.photo.album.video.adshelper.AdsManager
import com.gallery.photo.album.video.adshelper.InterstitialAdHelper
import com.gallery.photo.album.video.adshelper.LottieGiftIconHelper
import com.gallery.photo.album.video.database.FavouriteDBHelper
import com.gallery.photo.album.video.extensions.config
import com.gallery.photo.album.video.extensions.directoryDao
import com.gallery.photo.album.video.extensions.mediaDB
import com.gallery.photo.album.video.extensions.tryDeleteFileDirItem
import com.gallery.photo.album.video.fragment.*
import com.gallery.photo.album.video.inapp.InAppPurchaseHelper
import com.gallery.photo.album.video.inapp.PRODUCT_PURCHASED
import com.gallery.photo.album.video.inapp.showPurchaseSuccess
import com.gallery.photo.album.video.jobs.NewPhotoFetcher
import com.gallery.photo.album.video.offlineads.OfflineNativeAdvancedHelper.loadOfflineGoogleNativeBanner
import com.gallery.photo.album.video.rateandfeedback.displayExitDialog
import com.gallery.photo.album.video.utilities.*
import com.gallery.photo.album.video.extensions.*
import com.gallery.photo.album.video.helpers.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.material.appbar.AppBarLayout
import io.github.inflationx.viewpump.ViewPumpContextWrapper
import kotlinx.android.synthetic.main.activity_image_preview.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.adViewContainer
import kotlinx.android.synthetic.main.activity_main.bottomNav
import kotlinx.android.synthetic.main.activity_main.drawerLayout
import kotlinx.android.synthetic.main.activity_main.etSearch
import kotlinx.android.synthetic.main.activity_main.imgClose
import kotlinx.android.synthetic.main.activity_main.imgOptions
import kotlinx.android.synthetic.main.activity_main.imgSearch
import kotlinx.android.synthetic.main.activity_main.imgSideMenu
import kotlinx.android.synthetic.main.activity_main.toolbar
import kotlinx.android.synthetic.main.activity_main.tvHeaderTitle
import kotlinx.android.synthetic.main.activity_main.viewPagerHome
import kotlinx.android.synthetic.main.activity_main_new.*
import kotlinx.android.synthetic.main.activity_media.*
import kotlinx.android.synthetic.main.drawer_content.*
import kotlinx.android.synthetic.main.fragment_photo_directory.*
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_grid
import kotlinx.android.synthetic.main.fragment_photo_directory.directories_refresh_layout
import kotlinx.android.synthetic.main.fragment_vault.*
import kotlinx.android.synthetic.main.layout_ad_view.*
import kotlinx.android.synthetic.main.layout_gift_icon.*
import kotlinx.android.synthetic.main.layout_gift_icon_lottie.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.anko.toast
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream


private val TAG = MainActivity::class.java.simpleName

val permission_gallery = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)


class MainActivity : BaseActivity(), InAppPurchaseHelper.OnPurchased, InterstitialAdHelper.InterstitialAdListener {

    var prevPos: Int = 0;
    private var mDrawerToggle: ActionBarDrawerToggle? = null
    private val is_closed = true
    private var isOpenPermissionDial: Boolean = false
    var isScroll = false
    var isFromSetting = false;
    var isFromSettingForCamera = false;
    lateinit var viewPagerFragmentAdapter: ViewPagerFragmentAdapter
    lateinit var databaseInputStream1: InputStream
    lateinit var dbHelper: FavouriteDBHelper
    private var mWasProtectionHandled = false
    private var mIsPasswordProtectionPending = false
    var isInActionMode = false
    var isAlertDisplay = false


    var isFirstTime = true
    var isFirstTimeAdShow = false

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    companion object {
        var interstitialAdShow: InterstitialAd? = null
        var isNeedToRefresh: Boolean = false
        var isInternalCall: Boolean = false
        var isRemoveAdClicked = false
        var mLoadingProgressDailog: ProgressDialog? = null
        var activity: Activity? = null

        //        lateinit var HeaderTitle: TextView
        fun newIntent(mContext: Context): Intent {
            return Intent(mContext, MainActivity::class.java)
        }

        fun showLoadingProgress(mContext: Context, msg: String) {
            if (mLoadingProgressDailog == null) {
                mLoadingProgressDailog = ProgressDialog(mContext, R.style.MyAlertDialogNew)
                mLoadingProgressDailog!!.setMessage(msg)

                mLoadingProgressDailog!!.setCancelable(false)
                mLoadingProgressDailog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
                mLoadingProgressDailog!!.show()
            }
        }

        fun dismissLoadingProgress() {

            if (mLoadingProgressDailog != null && mLoadingProgressDailog!!.isShowing) {
                mLoadingProgressDailog!!.dismiss()
                mLoadingProgressDailog = null
            }

        }

    }


    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
    }


    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(WAS_PROTECTION_HANDLED, mWasProtectionHandled)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        mWasProtectionHandled = savedInstanceState.getBoolean(WAS_PROTECTION_HANDLED, false)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            config.temporarilyShowHidden = false
            config.tempSkipDeleteConfirmation = false
            removeTempFolder()
            startNewPhotoFetcher()
        }
        isUnLockApp = false

        activity = this

        setContentView(R.layout.activity_main_new)

        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.instance!!.load(this, this)
        }
        registerFileUpdateListener()
        if (OpenAdSplashActivity.activity != null)
            OpenAdSplashActivity.activity!!.finish()

    }

    override fun getContext(): Activity {
        return this@MainActivity
    }

    override fun initActions() {

//        HeaderTitle = findViewById(R.id.tvHeaderTitle)
    }


    override fun onResume() {
        super.onResume()
        Log.d("TagHidden", "onResume: MainActivity")
//        if (!isFirstTimeAdShow) {
//            Handler().postDelayed({
//                Log.d("TAG898959", "onResume: Ad Load handler")
//                isFirstTimeAdShow = true
//                if (interstitialAdShow != null) {
//                    Log.d("TAG898959", "onResume: Ad Load show")
//                    isFirstTime = false
//                    interstitialAdShow!!.show(this)
//                }
//            }, 3000)
//        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            this.loadOfflineGoogleNativeBanner(findViewById(R.id.adViewContainer))
            adViewContainer.visibility = GONE
        } else {
            adViewContainer.visibility = GONE
        }
//        adViewContainer.visibility = GONE
        mIsPasswordProtectionPending = config.isAppPasswordProtectionOn
        if (isFromSetting) {
            isFromSetting = false
            checkStoragePermission()
        }
        if (isFromSettingForCamera) {
            isFromSettingForCamera = false
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            ) {
                llCamera.performClick()
            }
        }
        if (isAskingPermissionsActionNull) {
            isAskingPermissionsActionNull = false
            checkStoragePermission()
        }


        try {
            InAppPurchaseHelper.instance!!.initBillingClient(this, this)
        } catch (e: Exception) {
            Log.e(TAG, "initBillingClient: " + e.message)
        }

    }

    private fun navigationImagesMargin(view: View) {
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val child = view.getChildAt(i)
                navigationImagesMargin(child)
            }
        } else if (view is ImageView) {
            val param = view.layoutParams as ViewGroup.MarginLayoutParams
            param.topMargin = convertDpToPx(14)
            view.layoutParams = param
        }
    }

    fun convertDpToPx(dp: Int): Int {
        return Math.round(dp * (resources.displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT))
    }

    override fun initData() {
        checkStoragePermission()

    }

    private fun removeTempFolder() {
        if (config.tempFolderPath.isNotEmpty()) {
            val newFolder = File(config.tempFolderPath)
            if (getDoesFilePathExist(newFolder.absolutePath) && newFolder.isDirectory) {
                if (newFolder.list()?.isEmpty() == true && newFolder.getProperSize(true) == 0L && newFolder.getFileCount(true) == 0) {
//                    toast(String.format(getString(R.string.deleting_folder), config.tempFolderPath), Toast.LENGTH_LONG)
                    tryDeleteFileDirItem(newFolder.toFileDirItem(applicationContext), true, true)
                }
            }
            config.tempFolderPath = ""
        }
    }

    private fun startNewPhotoFetcher() {
        if (isNougatPlus()) {
            val photoFetcher = NewPhotoFetcher()
            if (!photoFetcher.isScheduled(applicationContext)) {
                photoFetcher.scheduleJob(applicationContext)
            }
        }
    }

    private fun setData() {

//        setSupportActionBar(toolbar)
        viewPagerFragmentAdapter = ViewPagerFragmentAdapter(this)
        viewPagerFragmentAdapter.addFragment(PhotoDirectoryFragment.getInstance(1))
        viewPagerFragmentAdapter.addFragment(VideoDirectoryFragment.getInstance(2))
        viewPagerFragmentAdapter.addFragment(VaultFragment.getInstance(3))
        viewPagerFragmentAdapter.addFragment(SettingsFragment.getInstance(4))

        viewPagerHome.apply {
            adapter = viewPagerFragmentAdapter
            (getChildAt(0) as RecyclerView).overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            offscreenPageLimit = 4
        }

        /*navigationImagesMargin(bottomNav)*/

        bottomNav.setOnNavigationItemSelectedListener {

            when (it.itemId) {
                R.id.nav_photo -> {
                    viewPagerHome.currentItem = 0
                }
                R.id.nav_video -> {
                    viewPagerHome.currentItem = 1
                }
                R.id.nav_vault -> {
                    viewPagerHome.currentItem = 2
                }
                R.id.nav_settings -> {
                    viewPagerHome.currentItem = 3
                }
                else -> null
            } != null

            /* bottomNav.post {
                 navigationImagesMargin(bottomNav)
             }*/

        }
        /* viewPagerHome.addOnPageChangeListener(object : ViewPager.OnPageChangeListener()
         {
             override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

             }


             override fun onPageSelected(position: Int) {
                 if (prevPos != position) {
                     bottomNav.menu.getItem(prevPos).isChecked = false;
                     bottomNav.menu.getItem(position).isChecked = true;
                     if (etSearch.visibility != GONE) {
                         imgClose.performClick()
                     }
                     var fragment = viewPagerFragmentAdapter.createFragment(prevPos)
                     when (fragment) {
                         is PhotoDirectoryFragment -> {
                             try {
                                 if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                     fragment.getRecyclerAdapter()?.finishActMode()
                                     fragment.setupAdapter(fragment.mDirs, "")
                                 }
                             } catch (e: Exception) {
                                 e.printStackTrace()
                             }
                         }
                         is VideoDirectoryFragment -> {
                             try {
                                 if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                     fragment.getRecyclerAdapter()?.finishActMode()
                                     fragment.setupAdapter(fragment.mDirs, "")
                                 }
                             } catch (e: Exception) {
                                 e.printStackTrace()
                             }
                         }
                         is VaultFragment -> {
                             try {
                                 if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                     fragment.getRecyclerAdapter()?.finishActMode()
                                     fragment.setupAdapter(fragment.mDirs, "")
                                 }
                             } catch (e: Exception) {
                                 e.printStackTrace()
                             }
                         }
                     }

                     if (isScroll) {
                         when (position) {
                             0 -> {
                                 VaultFragment.isTabUnlock = false
                                 adViewContainer.visibility = VISIBLE
                                 tvHeaderTitle.visibility = View.VISIBLE
                                 imgSearch.visibility = View.VISIBLE
                                 tvHeaderTitle.text = "My Photo"
                                 bottomNav.selectedItemId = R.id.nav_photo
                             }
                             1 -> {
                                 VaultFragment.isTabUnlock = false
                                 adViewContainer.visibility = VISIBLE
                                 tvHeaderTitle.visibility = View.VISIBLE
                                 imgSearch.visibility = View.VISIBLE
                                 tvHeaderTitle.text = "My Video"
                                 bottomNav.selectedItemId = R.id.nav_video
                             }
                             2 -> {
                                 tvHeaderTitle.visibility = View.VISIBLE
                                 tvHeaderTitle.text = "Private Gallery"
                                 bottomNav.selectedItemId = R.id.nav_vault
                             }
                             3 -> {
                                 VaultFragment.isTabUnlock = false
                                 adViewContainer.visibility = VISIBLE
                                 tvHeaderTitle.visibility = View.VISIBLE
                                 imgSearch.visibility = View.GONE
                                 tvHeaderTitle.text = "Settings"
                                 bottomNav.selectedItemId = R.id.nav_settings
                             }
                         }
                     }
                     if (!isScroll)
                         isScroll = true
                     prevPos = position
                     //                bottomNavIndicator.
                 }
             }

             override fun onPageScrollStateChanged(state: Int) {
                 TODO("Not yet implemented")
             }


         })*/
        viewPagerHome.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {

                if (prevPos != position) {
                    bottomNav.menu.getItem(prevPos).isChecked = false;
                    bottomNav.menu.getItem(position).isChecked = true;
                    if (etSearch.visibility != GONE) {
                        etSearch.visibility = GONE
                        imgClose.visibility = GONE
                        imgOptions.visibility = VISIBLE
                        imgSearch.visibility = VISIBLE
                        tvHeaderTitle.visibility = VISIBLE
                        etSearch.text = null
                        etSearch.clearFocus()
                        hideKeyboard(etSearch)
                        val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(prevPos)
                        if (photoDirectoryFragment is PhotoDirectoryFragment) {
                            photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                        }
                        if (photoDirectoryFragment is VideoDirectoryFragment) {
                            photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                        }
                    }
                    var fragment = viewPagerFragmentAdapter.createFragment(prevPos)
                    when (fragment) {
                        is PhotoDirectoryFragment -> {
                            try {
                                if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                    fragment.getRecyclerAdapter()?.finishActMode()
                                    fragment.setupAdapter(fragment.mDirs, "")
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        is VideoDirectoryFragment -> {
                            try {
                                if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                    fragment.getRecyclerAdapter()?.finishActMode()
                                    fragment.setupAdapter(fragment.mDirs, "")
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        is VaultFragment -> {
                            try {
                                if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                                    fragment.getRecyclerAdapter()?.finishActMode()
                                    fragment.setupAdapter(fragment.mDirs, "")
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }

//                    if (isScroll) {
                    when (position) {
                        0 -> {
                            enableToolbatScrolling()
                            VaultFragment.isTabUnlock = false
//                            if (AdsManager(this@MainActivity).isNeedToShowAds() && isOnline())
//                                adViewContainer.visibility = VISIBLE
//                            else
                            adViewContainer.visibility = GONE
                            tvHeaderTitle.visibility = View.VISIBLE
                            imgSearch.visibility = View.VISIBLE
                            tvHeaderTitle.text = "My Photo"
                            bottomNav.selectedItemId = R.id.nav_photo
                        }
                        1 -> {
                            enableToolbatScrolling()
                            VaultFragment.isTabUnlock = false
//                            if (AdsManager(this@MainActivity).isNeedToShowAds() && isOnline())
//                                adViewContainer.visibility = VISIBLE
//                            else
                            adViewContainer.visibility = GONE
                            tvHeaderTitle.visibility = View.VISIBLE
                            imgSearch.visibility = View.VISIBLE
                            tvHeaderTitle.text = "My Video"
                            bottomNav.selectedItemId = R.id.nav_video
                        }
                        2 -> {
                            enableToolbatScrolling()
                            if (config.isAppPasswordProtectionOn && config.isEnableLock && VaultFragment.isFirstTime) {
                                disableToolbarScrolling()
                                adViewContainer.visibility = GONE
                            } else {
                                if (!config.isAppPasswordProtectionOn && !config.isEnableLock) {
                                    disableToolbarScrolling()
                                }
                                if (AdsManager(this@MainActivity).isNeedToShowAds() && isOnline())
                                    adViewContainer.visibility = VISIBLE
                                else
                                    adViewContainer.visibility = GONE
                            }
                            tvHeaderTitle.visibility = View.VISIBLE
                            tvHeaderTitle.text = "Private Gallery"
                            bottomNav.selectedItemId = R.id.nav_vault
                        }
                        3 -> {


                            disableToolbarScrolling()
                            VaultFragment.isTabUnlock = false
                            if (AdsManager(this@MainActivity).isNeedToShowAds() && isOnline())
                                adViewContainer.visibility = VISIBLE
                            else
                                adViewContainer.visibility = GONE
                            tvHeaderTitle.visibility = View.VISIBLE
                            imgSearch.visibility = View.GONE
                            tvHeaderTitle.text = "Settings"
                            bottomNav.selectedItemId = R.id.nav_settings
                        }
                    }
                }
//                    if (!isScroll)
//                        isScroll = true
//                }
                prevPos = position
            }
        })
        //        val view: View = bottomNav.findViewById(R.id.nav_photo)
        //        view.performClick()
        //        bottomNav.selectedItemId = R.id.nav_photo
        copyDatabase()
        if (AdsManager(this@MainActivity).isNeedToShowAds()) {
            llRemoveAds.visibility = VISIBLE
            dividerRemoveAd.visibility = VISIBLE
        } else {
            llRemoveAds.visibility = GONE
            dividerRemoveAd.visibility = GONE
        }
        mDrawerToggle = object : ActionBarDrawerToggle(this, drawerLayout, R.string.drawer_open, R.string.drawer_close) {
            override fun onDrawerOpened(drawerView: View) {
                hideKeyboard(etSearch)
                super.onDrawerOpened(drawerView)
                setDrawerData()
                if (AdsManager(this@MainActivity).isNeedToShowAds()) {
                    llRemoveAds.visibility = VISIBLE
                    dividerRemoveAd.visibility = VISIBLE
                } else {
                    llRemoveAds.visibility = GONE
                    dividerRemoveAd.visibility = GONE
                }
            }
        }
        if (config.viewTypeFolders == VIEW_TYPE_GRID) {
            imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_list))
        } else {

            imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_grid))
        }
        drawerLayout.addDrawerListener(mDrawerToggle as ActionBarDrawerToggle)
        imgSideMenu.setOnClickListener(this)
        imgOptions.setOnClickListener(this)
        llRemoveAds.setOnClickListener(this)
        llShareApp.setOnClickListener(this)
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            LottieGiftIconHelper(this)
        }
        llFavourite.setOnClickListener(this)
        llPlaceItem.setOnClickListener(this)
        llDuplicateFinder.setOnClickListener(this)
        llRecoverPhoto.setOnClickListener(this)
        llCamera.setOnClickListener(this)


        setupSearch()

        dbHelper = FavouriteDBHelper(this)

        imgClose.setOnClickListener(this)
        imgSearch.setOnClickListener(this)


    }

    fun disableToolbarScrolling() {
        val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
        appBarLayout.requestLayout()
    }

    fun enableToolbatScrolling() {
        val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL or AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS
        appBarLayout.requestLayout()
    }

    fun visibleADs() {
        enableToolbatScrolling()
        if (AdsManager(this@MainActivity).isNeedToShowAds() && isOnline())
            adViewContainer.visibility = VISIBLE
        else
            adViewContainer.visibility = GONE
    }

    private fun setDrawerData() {
        ensureBackgroundThread {
            val dirs = directoryDao.getTotalDirectory()
            val photos = mediaDB.getTotalMedia(TYPE_IMAGES)
            val videos = mediaDB.getTotalMedia(TYPE_VIDEOS)
            runOnUiThread {
                tvTotalAlbum.text = dirs.size.toString()
                tvTotalImage.text = photos.size.toString()
                tvTotalVideo.text = videos.size.toString()

            }
        }
    }

    private fun copyDatabase() {

        try {
            val f = File("/data/data/$packageName/databases/gallery.sql")
            if (f.exists()) {
                Log.e("TAG", "DataBase Already exists")

            } else {
                try {

                    Log.e("TAG", "DataBase is copying.....")
                    databaseInputStream1 = assets.open("gallery.sql")

                    try {

                        val databaseOutputStream: OutputStream = FileOutputStream(f.absolutePath)
                        val buffer = ByteArray(1024)
                        val databaseInputStream: InputStream = databaseInputStream1
                        while (databaseInputStream.read(buffer) > 0) {
                            databaseOutputStream.write(buffer)
                        }
                        databaseInputStream.close()
                        databaseOutputStream.flush()
                        databaseOutputStream.close()
                        Log.e("TAG", "DataBase is copied.....")
                    } catch (e: java.lang.Exception) {
                        e.printStackTrace()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupSearch() {

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                /* if (s.toString().isNotEmpty()) {
                     imgClose.visibility = VISIBLE
                 } else {
                     imgClose.visibi ity = GONE
                 }*/
                val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                if (photoDirectoryFragment is PhotoDirectoryFragment) {
                    photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, s.toString())
                }
                if (photoDirectoryFragment is VideoDirectoryFragment) {
                    photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, s.toString())
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }

    private fun checkCameraPermission(): Boolean {

        return if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            isUnLockApp = true
            isAppOpenAdShow = false
            ActivityCompat.requestPermissions(
                this@MainActivity, arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
                101
            )
            false
        } else {
            true
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        isAppOpenAdShow = false
        if (requestCode == 101) {
            if (permissions.isEmpty()) {
                return
            }
            var allPermissionsGranted = true
            if (grantResults.isNotEmpty()) {
                for (grantResult in grantResults) {
                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
                        allPermissionsGranted = false
                        break
                    }
                }
            }

            if (!allPermissionsGranted) {
                var somePermissionsForeverDenied = false
                for (permission in permissions) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                        //denied
                        Log.e("denied", permission)
//                        if (requestCode == 1 || requestCode == 2 || requestCode == 3) {
//                            ActivityCompat.requestPermissions(
//                                this@MainActivity, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
//                                1
//                            )
//                        } else {
                        ActivityCompat.requestPermissions(
                            this@MainActivity, arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
                            101
                        )
//                        }
                    } else {
                        if (ActivityCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
                            //allowed
                            Log.e("allowed", permission)
                        } else {
                            //set to never ask again
                            Log.e("set to never ask again", permission)
                            somePermissionsForeverDenied = true
                        }
                    }
                }
                if (somePermissionsForeverDenied) {
                    showCameraPermissionAlert()
                } else {
                    //startActivity(Intent(this, CameraActivity::class.java))

//                    val cameraIntent = Intent(this, OpenCameraActivity::class.java)
//                    startActivity(cameraIntent)
                }

            }


        }

    }

    private fun showCameraPermissionAlert() {
        isUnLockApp = true
        isMoreAppsClick = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>Permissions Required</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage("Please allow permission for Camera")
            .setPositiveButton("OK")
            { dialog, which ->
                dialog.dismiss()
                dirsDialog1 = null
                isFromSettingForCamera = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                isMoreAppsClick = true
                //                            Share.isAppOpenAdShow = false
            }
            .setNegativeButton("CANCEL") { dialog, which ->
                dialog.dismiss()
                dirsDialog1 = null
                //                            finish()
            }
            .setCancelable(false)
        //alert dialog with theme

        if (dirsDialog1 == null) {
            dirsDialog1 = alertDialogBuilder.create()
            if (!dirsDialog1!!.isShowing()) {
                //                            if (MainActivity.mCurrentPageerPossition == 3) {
                //                                Share.isfromFinder = false
                //                            }
                if (!this@MainActivity.isFinishing) {
                    dirsDialog1!!.show()
                    val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.album.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
                    dirsDialog1!!.window?.setBackgroundDrawable(bgDrawable)
                    dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(
                        com.gallery.photo.album.video.R.color.color_primary))
                    dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(
                        com.gallery.photo.album.video.R.color.color_primary))
                    dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(
                        com.gallery.photo.album.video.R.color.color_primary))

                }
                //                            dirsDialog1.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Share.getAPPThemWisePrimoryColor(this@MainActivity))
                //                            dirsDialog1.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Share.getAPPThemWisePrimoryColor(this@MainActivity))
            }
        }
    }

    var dirsDialog1: AlertDialog? = null

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgClose -> {
                etSearch.visibility = GONE
                imgClose.visibility = GONE
                imgOptions.visibility = VISIBLE
                imgSearch.visibility = VISIBLE
                tvHeaderTitle.visibility = VISIBLE
                etSearch.text = null
                etSearch.clearFocus()
                hideKeyboard(etSearch)
                val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                if (photoDirectoryFragment is PhotoDirectoryFragment) {
                    photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                }
                if (photoDirectoryFragment is VideoDirectoryFragment) {
                    photoDirectoryFragment.setupAdapter(photoDirectoryFragment.mDirs, "")
                }
            }
            R.id.imgSearch -> {
                val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                if (photoDirectoryFragment is VaultFragment) {
                    startActivity(Intent(this, VaultSettingsActivity::class.java))
                } else {
                    etSearch.visibility = VISIBLE
                    imgClose.visibility = VISIBLE
                    imgOptions.visibility = GONE
                    imgSearch.visibility = GONE
                    tvHeaderTitle.visibility = GONE
                    val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                    if (photoDirectoryFragment is PhotoDirectoryFragment) {
                        if (photoDirectoryFragment.directories_refresh_layout != null)
                            photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                    }
                    if (photoDirectoryFragment is VideoDirectoryFragment) {
                        if (photoDirectoryFragment.directories_refresh_layout != null)
                            photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                    }
                    showKeyboard(etSearch)
                }
            }
            R.id.llRecoverPhoto -> {
                drawerLayout.closeDrawers()
                Intent(this, RecoverPhotoActivity::class.java).apply {
                    putExtra(DIRECTORY, "")
                    startActivity(this)
                }
            }
            R.id.llDuplicateFinder -> {
                drawerLayout.closeDrawers()
                startActivity(Intent(this, DuplicateFinderActivity::class.java))
            }
            R.id.llPlaceItem -> {
                drawerLayout.closeDrawers()
                startActivity(Intent(this, PlaceActivity::class.java))
            }
            R.id.llFavourite -> {
                drawerLayout.closeDrawers()
                startActivity(Intent(this, FavouriteActivity::class.java))
            }
            R.id.llShareApp -> {
                isMoreAppsClick = true
                isUnLockApp = true
                isInternalCall = true
                drawerLayout.closeDrawers()
                //            Share.isAppOpenAdShow = false
                //            Share.isShareClick = true

                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
                //val sAux = "Download and give review for ${getString(R.string.app_name)} app from play store https://play.google.com/store/apps/details?id=${packageName} "
                val sAux = ""
                i.putExtra(Intent.EXTRA_TEXT, sAux)
                startActivity(Intent.createChooser(i, "Choose one"))
            }
            R.id.llRemoveAds -> {
                isMoreAppsClick = true
                isUnLockApp = true
                isInternalCall = true
                drawerLayout.closeDrawers()
                GlobalScope.launch {
                    InAppPurchaseHelper.instance!!.purchaseProduct(PRODUCT_PURCHASED, false)
                }
            }
            R.id.imgOptions -> {
                if (config.viewTypeFolders == VIEW_TYPE_GRID) {
                    config.viewTypeFolders = VIEW_TYPE_LIST
                    imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_grid))
                } else {
                    config.viewTypeFolders = VIEW_TYPE_GRID
                    imgOptions.setImageDrawable(getDrawable(R.drawable.ic_gallery_list))
                }
                val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(0)
                if (photoDirectoryFragment is PhotoDirectoryFragment) {
                    photoDirectoryFragment.setupLayoutManager()
                    photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                    photoDirectoryFragment.directories_grid.adapter = null
                    photoDirectoryFragment.setupAdapter(photoDirectoryFragment.getRecyclerAdapter()?.dirs ?: photoDirectoryFragment.mDirs)
                }
                val videoDirectoryFragment = viewPagerFragmentAdapter.createFragment(1)
                if (videoDirectoryFragment is VideoDirectoryFragment) {
                    if (videoDirectoryFragment.isAdded) {
                        videoDirectoryFragment.setupLayoutManager()
                        videoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                        videoDirectoryFragment.directories_grid.adapter = null

                        videoDirectoryFragment.setupAdapter(videoDirectoryFragment.getRecyclerAdapter()?.dirs ?: videoDirectoryFragment.mDirs)
                    }
                }
                val vaultFragment = viewPagerFragmentAdapter.createFragment(2)
                if (vaultFragment is VaultFragment) {
                    if (vaultFragment.isAdded) {
                        vaultFragment.setupLayoutManager()
                        vaultFragment.directories_refresh_layout.isRefreshing = false
                        vaultFragment.directories_grid.adapter = null
                        vaultFragment.Alldirectories_grid.adapter = null
                        vaultFragment.setupAdapter(vaultFragment.mDirsHiddenByGallery)
                        vaultFragment.setupAllHiddenAdapter(vaultFragment.mDirsHiddenByOtherApp)
                    }
                }
            }
            R.id.imgSideMenu -> {

                val photoDirectoryFragment = viewPagerFragmentAdapter.createFragment(viewPagerHome.currentItem)
                if (photoDirectoryFragment is PhotoDirectoryFragment) {
                    try {
                        if (photoDirectoryFragment.directories_refresh_layout != null)
                            photoDirectoryFragment.directories_refresh_layout.isRefreshing = false

                    } catch (e: java.lang.Exception) {
                    }
                }
                if (photoDirectoryFragment is VideoDirectoryFragment) {
                    try {
                        if (photoDirectoryFragment.directories_refresh_layout != null)
                            photoDirectoryFragment.directories_refresh_layout.isRefreshing = false
                    } catch (e: java.lang.Exception) {
                    }
                }
                if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.openDrawer(GravityCompat.START)
                } else {
                    drawerLayout.closeDrawers()
                }
            }
            R.id.llCamera -> {
                drawerLayout.closeDrawers()
                isUnLockApp = true
                isMoreAppsClick = true
                handlePermission(PERMISSION_CAMERA) {
                    isUnLockApp = true
                    isMoreAppsClick = true
                    if (it) {
                        //startActivity(Intent(this, CameraActivity::class.java))

//                        val cameraIntent = Intent(this, OpenCameraActivity::class.java)
//                        startActivity(cameraIntent)
                    } else {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                            isUnLockApp = true
                            isMoreAppsClick = true
                            llCamera.performClick()
                        } else {
                            showCameraPermissionAlert()
                        }
                    }
                }
            }
        }

    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawers()
        } else {
            displayExitDialog(interstitialAdShow)
        }
    }


    override fun initAds() {
    }

    private fun removeAds() {
        //  moreAppView.visibility = View.GONE

        adViewContainer.visibility = View.GONE
        clGiftIcon.visibility = View.INVISIBLE

    }


    override fun onPurchasedSuccess(purchase: Purchase) {
        if (!isAlertDisplay) {
            isAlertDisplay = true
            isRemoveAdClicked = false
            Log.i(TAG, "purchase")
            showPurchaseSuccess()
            removeAds()

        }
    }

    override fun onProductAlreadyOwn() {
        isRemoveAdClicked = false
        Log.i(TAG, "onProductAlreadyOwn")
        showPurchaseSuccess()
        removeAds()
    }


    override fun onBillingSetupFinished(billingResult: BillingResult) {

    }

    override fun onBillingUnavailable() {

    }

    override fun onBillingKeyNotFound(productId: String) {
        val message = "SKU Detail not found for product id: $productId"
        toast(message)
    }

    /*  private fun checkPermissions() {

          Dexter.withContext(mContext)
              .withPermissions(*permission_gallery)
              .withListener(object : MultiplePermissionsListener {
                  override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                      when {
                          report.areAllPermissionsGranted() -> {
                              choosePicture()
                          }
                          report.isAnyPermissionPermanentlyDenied -> {
                              showPermissionsAlert(fontPath)
                          }
                          else -> {
                              toast("Required Permissions not granted")
                          }
                      }
                  }

                  override fun onPermissionRationaleShouldBeShown(permissions: List<PermissionRequest>, token: PermissionToken) {
                      token.continuePermissionRequest()
                  }
              }).check()


      }*/

    private fun checkStoragePermission() {
        isMoreAppsClick = true
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            if (!checkPermissionabove11()) {
//                showGetPermissionDialog11()
//            } else {
//                setData()
//            }
//
//        } else {
        isMoreAppsClick = true
        isUnLockApp = true
        handlePermission(PERMISSION_WRITE_STORAGE) {
            isMoreAppsClick = true
            isUnLockApp = true
            if (it) {
//                sendBroadcast(Intent(this, RefreshMediaReceiver::class.java).setAction("com.gallery.photo.video.REFRESH_MEDIA"));
                setData()
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    checkStoragePermission()
                } else {
                    isMoreAppsClick = true
                    isUnLockApp = true
                    val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
                    alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>Permissions Required</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
                        .setMessage("Please allow permission for storage")
                        .setPositiveButton("OK")
                        { dialog, which ->
                            dialog.dismiss()
                            dirsDialog1 = null
                            isFromSetting = true
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", packageName, null)
                            )
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                            isMoreAppsClick = true
//                            Share.isAppOpenAdShow = false
                        }
                        .setNegativeButton("CANCEL") { dialog, which ->
                            dialog.dismiss()
                            finish()
                        }
                        .setCancelable(false)
                    //alert dialog with theme

                    if (dirsDialog1 == null) {
                        dirsDialog1 = alertDialogBuilder.create()
                        if (!dirsDialog1!!.isShowing()) {
//                            if (MainActivity.mCurrentPageerPossition == 3) {
//                                Share.isfromFinder = false
//                            }
                            if (!this@MainActivity.isFinishing) {
                                dirsDialog1!!.show()
                            }
                            val bgDrawable = resources.getColoredDrawableWithColor(
                                com.gallery.photo.album.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
                            dirsDialog1!!.window?.setBackgroundDrawable(bgDrawable)
                            dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(
                                com.gallery.photo.album.video.R.color.color_primary))
                            dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(
                                com.gallery.photo.album.video.R.color.color_primary))
                            dirsDialog1!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(
                                com.gallery.photo.album.video.R.color.color_primary))
//                            dirsDialog1.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Share.getAPPThemWisePrimoryColor(this@MainActivity))
//                            dirsDialog1.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Share.getAPPThemWisePrimoryColor(this@MainActivity))
                        }
                    }
                }
            }
        }
//        }
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            1011 -> {
                checkStoragePermission()
            }
//            REQ_CODE_FOR_MANAGE_STORAGE -> {
//
//                if (requestCode == REQ_CODE_FOR_MANAGE_STORAGE && checkPermissionabove11()) {
//                    setData()
//                } else {
//
//
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//
//                        showGetPermissionDialog11()
//                    }
//                }
//            }

//            1058 -> {
//                llCamera.performClick()
//            }

        }


    }

    fun toggleToolbar(isShowActionBar: Boolean) {
        isInActionMode = isShowActionBar
        if (isShowActionBar) {
//            toolbar.visibility = GONE
            viewPagerHome.isUserInputEnabled = false
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
        } else {
//            toolbar.visibility = VISIBLE
            viewPagerHome.isUserInputEnabled = true
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
        }

    }

    override fun onDestroy() {
        Log.d("TAG_COPY", "on Destroy: base simple activity")
        notificationManager.cancelAll()
        config.isAnyOperationRunning = false
        config.lastDestinationPath = ""
        super.onDestroy()
        isGridSizeChange = false


    }

    override fun onPause() {
        super.onPause()
        if (!SettingsFragment.isShareClicked)
            isUnLockApp = false
        else {
            SettingsFragment.isShareClicked = false
        }
        if (isInternalCall) {
            isInternalCall = false
            isUnLockApp = true
        }
        VaultFragment.isTabUnlock = false

        if (viewPagerHome.currentItem == 0 || viewPagerHome.currentItem == 1)
            if (etSearch.visibility == VISIBLE)
                imgClose.performClick()
        if (viewPagerHome.currentItem == 2) {
            var fragment = viewPagerFragmentAdapter.createFragment(prevPos)
            when (fragment) {
                is VaultFragment -> {
                    try {
                        if (!fragment.getRecyclerAdapter()?.getSelectedPaths().isNullOrEmpty()) {
                            fragment.getRecyclerAdapter()?.finishActMode()
                            fragment.setupAdapter(fragment.mDirs, "")
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    override fun onAdLoaded(interstitialAd: InterstitialAd) {
//        Log.d("TAG898959", "onAdLoaded: ")
        interstitialAdShow = interstitialAd

    }

    override fun onAdFailedToLoad() {
        interstitialAdShow = null
        InterstitialAdHelper.instance!!.load(this, this)
    }

    override fun onAdClosed() {
        isInterstitialShown = false
        interstitialAdShow = null
        InterstitialAdHelper.instance!!.load(this, this)
        if (isFirstTime) {
            val i = Intent(this, ExitActivity::class.java)
            startActivity(i)
        }
        isFirstTime = true
    }

    fun showToolbar() {
        appBarLayout.setExpanded(true, true)

    }

    fun hideimgOption() {

        imgOptions.visibility = GONE
    }
}
