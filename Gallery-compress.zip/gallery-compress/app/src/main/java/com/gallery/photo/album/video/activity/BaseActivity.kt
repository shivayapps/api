package com.gallery.photo.album.video.activity

import android.os.Bundle
import com.gallery.photo.album.video.utilities.hideKeyboard
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlin.coroutines.CoroutineContext

abstract class BaseActivity : MainBaseActivity(), CoroutineScope {

    lateinit var job: Job

    override val coroutineContext: CoroutineContext
        get() = job + Dispatchers.Main
//    lateinit var mProgressDailog: ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        job = Job()
        hideKeyboard()
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }
    fun showProgress(msg:String) {
//        mProgressDailog = ProgressDialog(this, R.style.MyAlertDialogNew)
//        mProgressDailog.setMessage(msg)
//
//        mProgressDailog.setCancelable(false)
//        mProgressDailog.setProgressStyle(ProgressDialog.STYLE_SPINNER)
//        mProgressDailog.show()
    }

    fun dismissProgress() {
//        if (window.decorView.isShown && mProgressDailog.isShowing) {
//            mProgressDailog.dismiss()
//        }
    }


}