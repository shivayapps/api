package com.gallery.photo.album.video.activity


import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.album.video.R
import com.gallery.photo.album.video.adapter.PlacefolderAdapte
import com.gallery.photo.album.video.adshelper.AdsManager
import com.gallery.photo.album.video.adshelper.InterstitialAdHelper
import com.gallery.photo.album.video.adshelper.LottieGiftIconHelper
import com.gallery.photo.album.video.utilities.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import java.io.File
import java.util.*

class PlaceDetailActivity : BaseActivity(),
    InterstitialAdHelper.InterstitialAdListener {
    var rc_plzce: RecyclerView? = null
    var activity: Activity? = null
    var Folder: ArrayList<String>? = null
    var iv_back: ImageView? = null
    var txtheader: TextView? = null
    var notxt: TextView? = null
    var objPlacefolderAdapter: PlacefolderAdapte? = null
    var is_closed = true

/*    override fun getActivityTheme(): Int {
        return if (PreferenceManager.getDefaultSharedPreferences(this).getBoolean(
                "dark_theme",
                false
            )
        ) R.style.AppThemeNormalBlack else R.style.AppThemeLight
    }*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_place_detail)
        activity = this
        initview()
//        if (Build.VERSION.SDK_INT >= 28) {
//            applyColor()
//        }
        initviewAction()
        /*if (intent != null)
            folderPath = intent.getParcelableExtra("folderPath")!!*/
        Folder = ArrayList()
        Folder!!.addAll(folderPath)
        rc_plzce = findViewById(R.id.rc_plzce)
        val gridLayoutManager = GridLayoutManager(activity, 3)
        rc_plzce!!.setLayoutManager(gridLayoutManager)
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dm)
        imageList.clear()
        for (i in Folder!!.indices) {
            val image_path = Folder!![i]
            Log.e("TAG", "onActivityResult: $image_path")
            val editFile = File(image_path)
            // val split = editFile.name.split("\\.".toRegex()).toTypedArray()
            //   val split2 = editFile.path.split("\\/".toRegex()).toTypedArray()
//            Share.load = false
//            Share.GalleryPhotoLoad = false
            var size1 = editFile.length().toFloat()
            size1 = size1 / 1024f
            var size: String
            if (size1 >= 1024f) {
                size1 = size1 / 1024f
                size = "$size1 MB"
                Log.e("TAG", "onClick: File size : $size1 MB")
            } else {
                size = "$size1 KB"
                Log.e("TAG", "onClick: File size : $size1 KB")
            }
            var resolutionWidth = ""
            var resolutionHeight = ""
            val options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeFile(editFile.absolutePath, options)
            resolutionWidth = options.outWidth.toString()
            resolutionHeight = options.outHeight.toString()
            val resolution = "$resolutionWidth x $resolutionHeight"
            val timeStamp = editFile.lastModified().toString()
            val hashMap = HashMap<String, String>()
            hashMap[KEY_PATH] = editFile.path
            hashMap[KEY_IMAGE_NAME] = editFile.name
            hashMap[KEY_ALBUM] = intent.getStringExtra("name")!!
            hashMap[KEY_SIZE] = resolution
            hashMap[KEY_SIZE_IN_KB] = size
            hashMap[KEY_TIME] = converToTime(timeStamp)
            hashMap[KEY_TIMESTAMP] = timeStamp
            imageList.add(0, hashMap)
            Log.e("hashMap", "onCreate: $hashMap")
        }
//        Share.sliding_imageList.clear()
//        Share.sliding_imageList.addAll(imageList)
        objPlacefolderAdapter = PlacefolderAdapte(
            imageList, applicationContext, dm, intent.getStringExtra(
                "name"
            )!!
        )
        rc_plzce!!.setAdapter(objPlacefolderAdapter)
        if (imageList.size == 0) {
            notxt!!.visibility = View.VISIBLE
            rc_plzce!!.setVisibility(View.GONE)
        } else {
            notxt!!.visibility = View.GONE
            rc_plzce!!.setVisibility(View.VISIBLE)
        }
    }
//
//    fun applyColor() {
//        val rel_dinglelock = findViewById<RelativeLayout>(R.id.rel_dinglelock)
//        val ColorId = Share.getAPPThemWisePrimoryColor(applicationContext)
//        rel_dinglelock.setBackgroundColor(ColorId)
//        val HederColor = Share.getAppHeaderColorColor(applicationContext)
//        iv_back!!.setColorFilter(HederColor, PorterDuff.Mode.SRC_IN)
//        txtheader!!.setTextColor(HederColor)
//    }

    var mReciverForRefreshFullDATA: BroadcastReceiver? = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val pos = intent.getIntExtra("pos", 266305)
            Log.e("KKK", "onReceive: $pos")
            if (pos != 266305) {
                objPlacefolderAdapter!!.notifyItemRemoved(pos)
                imageList.removeAt(pos)
            }
            objPlacefolderAdapter!!.notifyDataSetChanged()
            if (objPlacefolderAdapter != null && objPlacefolderAdapter!!.itemCount == 0) {
                notxt!!.visibility = View.VISIBLE
                rc_plzce!!.visibility = View.GONE
            } else {
                notxt!!.visibility = View.GONE
                rc_plzce!!.visibility = View.VISIBLE
            }
        }
    }

    fun initviewAction() {
        iv_back!!.setOnClickListener { onBackPressed() }
        if (AdsManager(this).isNeedToShowAds()) {
//            Share.is_click_more_app = true
//            Share.unLockApp = true
            LottieGiftIconHelper(this)
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (mReciverForRefreshFullDATA != null) {
                unregisterReceiver(mReciverForRefreshFullDATA)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {

    }

    override fun initActions() {

    }


    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun onResume() {
        super.onResume()
//        Share.isShareClick = true
//        Share.unLockApp = true

        val filter = IntentFilter("refreshAdpterdetail")
        registerReceiver(mReciverForRefreshFullDATA, filter)
        if (objPlacefolderAdapter != null && objPlacefolderAdapter!!.itemCount == 0) {
            finish()
        }
    }

    fun initview() {
        iv_back = findViewById(R.id.iv_back)
        notxt = findViewById(R.id.notxt)
        txtheader = findViewById(R.id.txtheader)
        txtheader!!.setText(intent.getStringExtra("name"))
    }

    fun loadInterstialAd() {
        InterstitialAdHelper.instance!!.load(this, this)
        /* if (GalleryApplication.getInstance().mInterstitialAd != null) {
             if (GalleryApplication.getInstance().mInterstitialAd.isLoaded) {
                 Log.e("TAG", "loadInterstialAd if")
                 iv_more_app.visibility = View.VISIBLE
             } else {
                 GalleryApplication.getInstance().mInterstitialAd.adListener = null

                 GalleryApplication.getInstance().ins_adRequest = null
                 GalleryApplication.getInstance().LoadAds()
                 GalleryApplication.getInstance().mInterstitialAd.adListener = object : AdListener() {
                     override fun onAdLoaded() {
                         super.onAdLoaded()
                         Log.e("TAG", "loadInterstialAd load")
                         iv_more_app.visibility = View.VISIBLE
                     }


                     override fun onAdFailedToLoad(p0: LoadAdError?) {
                         super.onAdFailedToLoad(p0)
                         iv_more_app.visibility = View.GONE
                         loadInterstialAd()
                     }
                 }
             }
         }*/
    }

    companion object {
        var folderPath = ArrayList<String>()

        var imageList = ArrayList<HashMap<String, String>>()
    }

    override fun onAdLoaded(interstitialAd: InterstitialAd) {
        interstitialAd.show(this)
    }

    override fun onAdFailedToLoad() {

    }

    override fun onAdClosed() {
//        Share.unLockApp = true
    }

    override fun onPause() {
        super.onPause()
//        Share.unLockApp=true
    }

    override fun onBackPressed() {
//        Share.unLockApp = true
        super.onBackPressed()

    }
}