package com.gallery.photo.album.video.lock.managers;

public class LockSettings {

    public static void disableLock() {
        LockManager mLockManager = LockManager.getInstance();
        if (mLockManager.getAppLock() != null)
            mLockManager.getAppLock().setPasscode(null);
    }

    public static boolean isPinLockAvl() {
        LockManager mLockManager = LockManager.getInstance();
        return  mLockManager.isAppLockEnabled();
    }
}
