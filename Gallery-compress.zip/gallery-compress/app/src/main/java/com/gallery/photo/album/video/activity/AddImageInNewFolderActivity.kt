package com.gallery.photo.album.video.activity

import android.app.Activity
import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.gallery.photo.album.video.R
import com.gallery.photo.album.video.adapter.CreateNewFolderRecyclerViewAdapter
import com.gallery.photo.album.video.asynctask.GetMediaAsynctask
//import com.gallery.photo.album.video.camaramodule.FileUtil
import com.gallery.photo.album.video.extensions.*
import com.gallery.photo.album.video.models.AlbumPhotos
import com.gallery.photo.album.video.models.Medium
import com.gallery.photo.album.video.models.ThumbnailItem
import com.gallery.photo.album.video.utilities.GROUP_BY_LAST_MODIFIED_DAILY
import com.gallery.photo.album.video.utilities.TYPE_GIFS
import com.gallery.photo.album.video.utilities.TYPE_IMAGES
import com.gallery.photo.album.video.utilities.TYPE_VIDEOS
import com.gallery.photo.album.video.extensions.getFilenameFromPath
import com.gallery.photo.album.video.extensions.rescanPaths
import com.gallery.photo.album.video.extensions.toast
import com.gallery.photo.album.video.helpers.ensureBackgroundThread
import com.gallery.photo.album.video.models.FileDirItem
import kotlinx.android.synthetic.main.activity_add_image_in_new_folder.*
import kotlinx.android.synthetic.main.activity_place.*
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class AddImageInNewFolderActivity : BaseActivity() {
    private var AlbumName = ""
    private var FileDir = ""
    private lateinit var progressBar: ProgressDialog
    var AllPathList: java.util.ArrayList<AlbumPhotos> = java.util.ArrayList<AlbumPhotos>()
    lateinit var adapter: CreateNewFolderRecyclerViewAdapter
    private var mCurrAsyncTask: GetMediaAsynctask? = null
    public var viewPager_Position: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_image_in_new_folder)
    }

    companion object {
        lateinit var tvTitleCount: TextView
        var selectedPathList: java.util.ArrayList<AlbumPhotos> = java.util.ArrayList<AlbumPhotos>()
        fun updateCounter(counter: Int) {
            tvTitleCount.text = "$counter Item selected"
        }
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {

        val intent = intent
        FileDir = intent.getStringExtra("FileDir")
        AlbumName = intent.getStringExtra("Album Name")
        viewPager_Position = intent.getIntExtra("ViewPager_Position", 0)


        recyclerView.setNestedScrollingEnabled(false)


        recyclerView.setLayoutManager(GridLayoutManager(applicationContext, 3))
        recyclerView.setHasFixedSize(true)

        ll_back_pressed.setOnClickListener(this)
        ll_done.setOnClickListener(this)
        tvTitleCount = tv_title_count
        tv_title_count.setText("0 Item selected")
//        getData().execute()
        showProgressBar()

        AllPathList.clear()
        selectedPathList.clear()
        mCurrAsyncTask = GetMediaAsynctask(applicationContext, "", false, false, true, TYPE_IMAGES or TYPE_GIFS, GROUP_BY_LAST_MODIFIED_DAILY, false) {
            ensureBackgroundThread {
                val newMedia = it
                try {
                    selectedPathList = gotMedia(newMedia, false)
                    AllPathList = selectedPathList
                    runOnUiThread {
                        if (AllPathList.size == 0) {
                            tv_data_found.setVisibility(View.VISIBLE)
                            recyclerView.setVisibility(View.GONE)
                        } else {
                            tv_data_found.setVisibility(View.GONE)
                            recyclerView.setVisibility(View.VISIBLE)
                            adapter =
                                CreateNewFolderRecyclerViewAdapter(this@AddImageInNewFolderActivity, AllPathList, false, viewPager_Position)
                            recyclerView.setAdapter(adapter)
                        }
                        progressBar.dismiss()
                    }

                } catch (e: Exception) {
                }
            }


        }

        mCurrAsyncTask!!.execute()
        iv_back.setOnClickListener {
            onBackPressed()
        }
        ll_done.setOnClickListener(this)
        progressBar.setCancelable(true)
        progressBar.setOnCancelListener {
            mCurrAsyncTask!!.stopFetching()
            config.tempFolderPath = ""
            if (File(FileDir).exists())
                File(FileDir).delete()
            finish()
        }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.ll_done -> {
                Log.d("TAG", "onClick: " + selectedPathList.filter { it.isChecked }.size.toString())
                if (selectedPathList.filter { it.isChecked }.isNotEmpty()) {
                    copyMoveTo(true)
                } else {
                    com.example.appcenter.utilities.Toast.short(this, "Please select atleast one item")
                }
            }
        }
    }


    override fun onBackPressed() {
        config.tempFolderPath = ""

        if (File(FileDir).exists())
            File(FileDir).delete()
        super.onBackPressed()
    }

    private fun copyMoveTo(isCopyOperation: Boolean) {
        showProgressBar()
        val paths = ArrayList<String>()
        var list = selectedPathList.filter { it.isChecked }
        list.forEach { it ->
            paths.add(it.path)
        }
        val fileDirItems = paths.asSequence().filter { isCopyOperation || !it.startsWith(recycleBinPath) }.map {
            FileDirItem(it, it.getFilenameFromPath())
        }.toMutableList() as java.util.ArrayList

        if (!isCopyOperation && paths.any { it.startsWith(recycleBinPath) }) {
            toast(R.string.moving_recycle_bin_items_disabled, Toast.LENGTH_LONG)
        }

        if (fileDirItems.isEmpty()) {
            return
        }
//        paths.forEach { it ->

        newFileAdd(fileDirItems, fileDirItems[0].getParentPath().trimEnd('/'), FileDir, isCopyOperation, true, config.shouldShowHidden)
        {

            runOnUiThread {
                progressBar.dismiss()
                config.tempFolderPath = ""
                applicationContext.rescanFolderMedia(FileDir)
                applicationContext.rescanFolderMedia(fileDirItems.first().getParentPath())
                val newPaths = fileDirItems.map { "$FileDir/${it.name}" }.toMutableList() as java.util.ArrayList<String>
                rescanPaths(newPaths) {
                    fixDateTaken(newPaths, false)
                }

                MainActivity.isNeedToRefresh = true
                finish()
                com.example.appcenter.utilities.Toast.short(this, "New Album created successfully")
                Log.e("TAG", "copyMoveTo: " + it)
            }

        }

    }

    override fun initActions() {

    }

    override fun onResume() {
        super.onResume()

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)


    fun showProgressBar() {
        progressBar = ProgressDialog(this, R.style.MyAlertDialogNew)
        progressBar.setMessage("" + "Please wait...")
        progressBar.setCancelable(false)
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        progressBar.show()
    }

    private fun gotMedia(newMedia: java.util.ArrayList<ThumbnailItem>, b: Boolean): java.util.ArrayList<AlbumPhotos> {
        var selectedPathList: java.util.ArrayList<AlbumPhotos> = java.util.ArrayList<AlbumPhotos>()
        newMedia.forEach {
            if (it is Medium) {
                if (viewPager_Position == 0) {
                    if (it.type == TYPE_IMAGES) {
                        var albumPhotos = AlbumPhotos()
                        albumPhotos.setPath(it.path)
                        albumPhotos.setChecked(false)
                        selectedPathList.add(albumPhotos)
                    }
                } else {
                    if (it.type == TYPE_VIDEOS) {
                        var albumPhotos = AlbumPhotos()
                        albumPhotos.setPath(it.path)
                        albumPhotos.setChecked(false)
                        selectedPathList.add(albumPhotos)
                    }
                }

            }
        }
        return selectedPathList

    }

}