package com.gallery.photo.album.video.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.example.appcenter.utilities.isOnline
import com.gallery.photo.album.video.R
import com.gallery.photo.album.video.adshelper.AdsManager
import com.gallery.photo.album.video.adshelper.LottieGiftIconHelper
import com.gallery.photo.album.video.mainduplicate.activity.scanningactivities.ScanningActivity
import kotlinx.android.synthetic.main.activity_duplicate_finder.*

class DuplicateFinderActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_duplicate_finder)
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            LottieGiftIconHelper(this)
        }
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        imgBack.setOnClickListener {
            onBackPressed()
        }
    }


    override fun initActions() {
        llScanImages.setOnClickListener(this)
        llScanAudio.setOnClickListener(this)
        llScanVideo.setOnClickListener(this)
        llScanDocument.setOnClickListener(this)
        llScanOther.setOnClickListener(this)
    }
    override fun onClick(view: View) {
        super.onClick(view)
        when(view.id)
        {
            R.id.llScanImages->{
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Image")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanAudio->{
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Audio")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanVideo->{
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Video")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanDocument->{
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Document")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            R.id.llScanOther->{
                var intent = Intent(this, ScanningActivity::class.java)
                intent.putExtra("IsCheckType", "Other")
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
        }
    }
    override fun getAppIconIDs() = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)
}