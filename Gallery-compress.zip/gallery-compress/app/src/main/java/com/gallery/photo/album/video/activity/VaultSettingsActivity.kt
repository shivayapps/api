package com.gallery.photo.album.video.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.example.appcenter.utilities.isMoreAppsClick
import com.example.appcenter.utilities.isOnline
import com.gallery.photo.album.video.R
import com.gallery.photo.album.video.adshelper.AdsManager
import com.gallery.photo.album.video.adshelper.LottieGiftIconHelper
import com.gallery.photo.album.video.dialog.SetSecurityQuestionDialog
import com.gallery.photo.album.video.extensions.config
import com.gallery.photo.album.video.extensions.supportFingerPrint
import com.gallery.photo.album.video.fragment.REQUEST_CODE_CHECK_PASSWORD
import com.gallery.photo.album.video.inapp.InAppPurchaseHelper
import com.gallery.photo.album.video.inapp.PRODUCT_PURCHASED
import com.gallery.photo.album.video.inapp.showPurchaseSuccess
import com.gallery.photo.album.video.lock.activity.CustomPinActivity
import com.gallery.photo.album.video.lock.managers.AppLock
import com.gallery.photo.album.video.lock.managers.LockSettings
import com.gallery.photo.album.video.rateandfeedback.FeedbackActivity
import com.example.appcenter.utilities.isUnLockApp
import com.gallery.photo.album.video.fragment.VaultFragment
import kotlinx.android.synthetic.main.activity_vault_settings.*
import kotlinx.android.synthetic.main.activity_vault_settings.clGiftIcon
import kotlinx.android.synthetic.main.activity_vault_settings.imgBack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

const val REQUEST_CODE_CHANGE_PASSWORD = 101
const val REQUEST_CODE_DISABLE_PASSWORD = 102

class VaultSettingsActivity : BaseActivity(), InAppPurchaseHelper.OnPurchased {
    var isEnableLock = false
    var isEnableFingerPrint = false
    var isRemoveAdClick = false

    // variable to track event time
    override var mLastClickTime: Long = 0
    override var mMinDuration = 1000
    private val REQUEST_CODE_CHECK = 11

    companion object {
        var isUnlock = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vault_settings)
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        imgBack.setOnClickListener {
            onBackPressed()
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            LottieGiftIconHelper(this)
        }
        InAppPurchaseHelper.instance!!.initBillingClient(this, this)
    }

    override fun initActions() {
        clChangePin.setOnClickListener(this)
        clChangeSecQue.setOnClickListener(this)
        clRemoveLock.setOnClickListener(this)
        clFeedBack.setOnClickListener(this)
        clRemoveAds.setOnClickListener(this)
        imgEnableLockRight.setOnClickListener {
            if (isEnableLock) {
                imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
                config.isEnableLock = true
                isEnableLock = false
                VaultFragment.isTabUnlock = false
            } else {
                imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
                config.isEnableLock = false
                isEnableLock = true
            }
        }
        imgUnlockWithFingerPrintRight.setOnClickListener {
            if (config.isEnableLock) {
                if (isEnableFingerPrint) {
                    imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
                    config.isFingerprintEnable = true
                    isEnableFingerPrint = false
                } else {
                    imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
                    config.isFingerprintEnable = false
                    isEnableFingerPrint = true
                }
            } else {
                com.example.appcenter.utilities.Toast.short(this, "Please enable lock first")
            }
        }

        if (config.isEnableLock) {
            isEnableLock = false
            imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
        } else {
            isEnableLock = true
            imgEnableLockRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
        }
        if (config.isFingerprintEnable) {
            isEnableFingerPrint = false
            imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_on))
        } else {
            isEnableFingerPrint = true
            imgUnlockWithFingerPrintRight.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_switch_off))
        }
    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(this).isNeedToShowAds()) {
            clRemoveAds.visibility = VISIBLE
            dividerClRemoveAd.visibility = VISIBLE

            clGiftIcon.visibility = VISIBLE
        } else {
            clRemoveAds.visibility = GONE
            dividerClRemoveAd.visibility = GONE
            clGiftIcon.visibility = GONE
        }
        if (supportFingerPrint()) {
            dividerRemoveLock.visibility = VISIBLE
            clUnlockWithFingerPrint.visibility = VISIBLE
        } else {
            dividerRemoveLock.visibility = GONE
            clUnlockWithFingerPrint.visibility = GONE
        }
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.clChangePin -> {
                if (config.isAppPasswordProtectionOn) {
                    val intent = Intent(this, CustomPinActivity::class.java)
                    intent.putExtra(AppLock.EXTRA_TYPE, AppLock.CHANGE_PIN)
                    intent.putExtra("ChangePatternLock", false)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    startActivityForResult(intent, REQUEST_CODE_CHANGE_PASSWORD)
                } else {
                    Toast.makeText(this, "Please enable lock first", Toast.LENGTH_SHORT).show()
                }
            }
            R.id.clChangeSecQue -> {
                val intent = Intent(this, CustomPinActivity::class.java)
                //Intent intent = new Intent(AppLockScreenActivity.this, AppLockActivity.class);
                intent.putExtra(AppLock.EXTRA_TYPE, AppLock.UNLOCK_PIN)
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                startActivityForResult(intent, REQUEST_CODE_CHECK)


            }
            R.id.clRemoveLock -> {
                if (config.isAppPasswordProtectionOn) {
                    val intent = Intent(this, CustomPinActivity::class.java)
                    intent.putExtra(AppLock.EXTRA_TYPE, AppLock.DISABLE_PINLOCK)
                    intent.putExtra("ChangePatternLock", false)
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    startActivityForResult(intent, REQUEST_CODE_DISABLE_PASSWORD)
                }
            }
            R.id.clFeedBack -> {
                isMoreAppsClick = true
                isUnLockApp = true
                startActivity(FeedbackActivity.newIntent(this, 4))
            }
            R.id.clRemoveAds -> {
                isMoreAppsClick = true
                isUnLockApp = true
                GlobalScope.launch {
                    InAppPurchaseHelper.instance!!.purchaseProduct(PRODUCT_PURCHASED, false)
                }
            }

        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            REQUEST_CODE_CHECK_PASSWORD -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(this, getString(R.string.msg_lock_change_sccessfully), Toast.LENGTH_SHORT).show()

                }
            }
            REQUEST_CODE_DISABLE_PASSWORD -> {
                if (!LockSettings.isPinLockAvl()) {
                    Toast.makeText(
                        this, getString(R.string.msg_lock_remove), Toast.LENGTH_SHORT
                    ).show()
                    config.isAppPasswordProtectionOn = false
                    config.isBatterySecureLock = false
                    config.isChargerSecureLock = false
                    finish()
                }
            }
            REQUEST_CODE_CHECK -> {
                if (resultCode == RESULT_OK) {
//                    Handler().postDelayed({
                    SetSecurityQuestionDialog(this as BaseSimpleActivity) {
                        Toast.makeText(this, "Security Question/Answer changed successfully", Toast.LENGTH_SHORT).show()
                    }
//                    }, 200)
                }

            }

        }
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun onPurchasedSuccess(purchase: Purchase) {
        Log.i("TAG", "purchase")
        if (window.decorView.isShown)
            showPurchaseSuccess()
        removeAds()

    }

    private fun removeAds() {
        clRemoveAds.visibility = GONE
        clGiftIcon.visibility = GONE
        dividerClRemoveAd.visibility = GONE
    }

    override fun onProductAlreadyOwn() {
        Log.i("TAG", "already purchase")
        showPurchaseSuccess()
        removeAds()
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        GlobalScope.launch(Dispatchers.Main) {
            InAppPurchaseHelper.instance!!.initProducts()
            Log.i("TAG", "IN_APP_BILLING | Done")
        }
    }

    override fun onBackPressed() {
        VaultFragment.isTabUnlock = false
        super.onBackPressed()
    }

    override fun onBillingUnavailable() {

    }

    override fun onBillingKeyNotFound(productId: String) {

    }


}