package com.gallery.photo.album.video.activity

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Address
import android.location.Geocoder
import android.media.ExifInterface
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.example.appcenter.utilities.isMoreAppsClick
import com.example.appcenter.utilities.isOnline
import com.example.appcenter.utilities.isUnLockApp
import com.gallery.photo.album.video.R
import com.gallery.photo.album.video.adapter.MediaAdapter
import com.gallery.photo.album.video.adshelper.AdsManager
import com.gallery.photo.album.video.adshelper.LottieGiftIconHelper
import com.gallery.photo.album.video.extensions.*
import com.gallery.photo.album.video.interfaces.MediaOperationsListener
import com.gallery.photo.album.video.models.ThumbnailItem
import com.gallery.photo.album.video.models.ThumbnailSection
import com.gallery.photo.album.video.models.placeModle
import com.gallery.photo.album.video.offlineads.OfflineNativeAdvancedHelper.loadOfflineNativeAdvance
import com.gallery.photo.album.video.utilities.*
import com.gallery.photo.album.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.album.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.album.video.helpers.ensureBackgroundThread
import com.gallery.photo.album.video.models.FileDirItem
import com.gallery.photo.album.video.views.MyGridLayoutManager
import com.gallery.photo.album.video.models.Medium
import com.google.android.material.appbar.AppBarLayout
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_place.*
import kotlinx.android.synthetic.main.activity_place.imgBack
import kotlinx.android.synthetic.main.activity_place.media_empty_text_placeholder
import kotlinx.android.synthetic.main.activity_place.media_grid
import kotlinx.android.synthetic.main.activity_place.media_horizontal_fastscroller
import kotlinx.android.synthetic.main.activity_place.media_refresh_layout
import kotlinx.android.synthetic.main.activity_place.media_vertical_fastscroller
import java.io.File
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList

class PlaceActivity : BaseActivity(), MediaOperationsListener {
    var placeModles: ArrayList<placeModle>? = null

    //    var placeAdapter: PlaceAdapter? = null
    public var is_closed = true
    public var iscontinue = true
    var onjays: getData? = null
    var txtno: TextView? = null
    var aBoolean = false
    var contains = ArrayList<placeModle>()
    var ScanningDialog: AlertDialog? = null
    var media = ArrayList<ThumbnailItem>()
    var allPlaceList = ArrayList<ThumbnailItem>()
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = false
    private var mPath = ""
    private var mLastSearchedText = ""
    private var isFromOneSignal = false
    private var isFromSettings = false

    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_place)
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            LottieGiftIconHelper(this)
        }
    }

    override fun initData() {
//        if (checkPermissionStorage(mContext)) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                checkAllFilePermission()
//            } else {
//                setData()
//            }
//        } else {
        givePermissions(mPermissionStorage)
//        }

    }


    private fun checkPermissionStorage(mContext: Activity): Boolean {

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//            if (checkPermissionabove11()) {
//                return true
//            }
//            return false
//        } else {
        return  if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            isUnLockApp = true
            isAppOpenAdShow = false
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE),
                101
            )
            false
        } else {
            true
        }
//        }


    }

    fun checkAllFilePermission() {
      /*  if (Environment.isExternalStorageManager()) {
            setData()
        } else {
            isFromSettings = true
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse(String.format("package:%s", packageName))
            )
            startActivityForResult(intent, 2296)
        }*/
    }

    private fun givePermissions(permissions: Array<String>) {

        isMoreAppsClick = true
        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
//                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                                checkAllFilePermission()
//                            } else {
                                setData()
//                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {
        isMoreAppsClick = true
        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle("Permissions Required")
            .setMessage("Please allow permission for storage")
            .setPositiveButton("OK")
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                isMoreAppsClick = true
//                            Share.isAppOpenAdShow = false
            }
            .setNegativeButton("CANCEL") { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
//            if (Environment.isExternalStorageManager()) {
//                setData()
//                Log.e("mTAG", "onActivityResult: Service Start ")
//            } else {
//                if (isFromOneSignal) {
//                    startActivity(MainActivity.newIntent(this))
//                    finish()
//                    Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
//                } else {
//                    Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
//                }
//            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                    checkAllFilePermission()
//                } else {
                    setData()
//                }
            } else {
                if (isFromOneSignal) {
                    startActivity(MainActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setData() {
        media_empty_text_placeholder.layoutParams.height = usableScreenSize.y - (statusBarHeight + navigationBarHeight)
        imgBack.setOnClickListener {
            onBackPressed()
        }

        placeModles = ArrayList()
        /*media_grid.setHasFixedSize(true)
        media_grid.itemAnimator = null
        media_grid.setItemViewCacheSize(50)
        media_grid.isEnabled = false
        media_grid.isNestedScrollingEnabled = false
        val gridLayoutManager = GridLayoutManager(this, 1)
        media_grid.layoutManager = gridLayoutManager
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dm)
        media_grid.isEnabled = false*/
        //        placeAdapter = PlaceAdapter(placeModles!!, this.applicationContext, dm)
        //        media_grid.adapter = placeAdapter
        val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
        appBarLayout.requestLayout()
        if (rel_top_Progress != null && rel_top_Progress!!.visibility == View.VISIBLE) {
        } else {
            openDialog()
        }
        Handler().postDelayed({
            placeModles!!.clear()
            placeModles = ArrayList()
            onjays = getData()
            onjays!!.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, *arrayOfNulls<String>(0))

        }, 1000)
        media_refresh_layout.setOnRefreshListener {
            media.clear()
            allPlaceList.clear()
            onjays = getData()
            onjays!!.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, *arrayOfNulls<String>(0))
        }
    }

    override fun onResume() {
        super.onResume()
        if (isFromSettings) {
            isFromSettings = false
            if (checkPermissionStorage(mContext)) {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                    checkAllFilePermission()
//                } else {
                    setData()
//                }
            }
        }
    }

    fun openDialog() {

        rel_top_Progress!!.visibility = View.VISIBLE
    }

    override fun initActions() {

    }

    override fun getContext(): Activity {
        return this
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    inner class getData() : AsyncTask<String?, String?, ArrayList<placeModle>?>() {
        public override fun onCancelled() {
            placeModles!!.clear()
            media.clear()
            allPlaceList.clear()
            cancel(true)
            super.onCancelled()
        }

        override fun doInBackground(vararg strArr1: String?): ArrayList<placeModle>? {
            try {
                //getallPlacewise();
                var str: String?
                val sb = StringBuilder()
                sb.append(Environment.getExternalStorageDirectory().toString())
                sb.append("/DCIM/Camera")
                val valueOf = sb.toString().toLowerCase().hashCode().toString()
                ArrayList<Any?>()
                val strArr = arrayOf(
                    "_data", "title", "date_modified", "_id", "bucket_id", "bucket_display_name",
                    "datetaken", "longitude", "longitude"
                )
                var Count = 0
                val query = contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, strArr,
                    "bucket_id = ?", arrayOf(valueOf), "date_modified DESC"
                )
                if (query!!.moveToFirst()) {
                    query.getColumnIndexOrThrow("_data")
                    do {

                        if (iscontinue) {
                            Count++
                            val aVar = placeModle()
                            val pathname = query.getString(query.getColumnIndex(strArr[0]))
                            val title = query.getString(query.getColumnIndex(strArr[1]))
                            val date_modified = query.getString(query.getColumnIndex(strArr[2]))
                            val datetaken = query.getString(query.getColumnIndex(strArr[6]))
                            query.getString(query.getColumnIndex(strArr[3]))
                            query.getInt(query.getColumnIndex(strArr[4]))
                            aVar.f9757b = query.getString(query.getColumnIndex("bucket_id"))
                            aVar.f9762g = date_modified
                            aVar.placeName = query.getString(query.getColumnIndex("bucket_display_name"))
                            aVar.f9760e = getfilePath(query.getString(query.getColumnIndexOrThrow("_data")))
                            aVar.f9758c = query.getString(query.getColumnIndex("_id"))

                            var file: File? = null
                            try {
                                file = File(pathname)
                            } catch (unused: Exception) {
                            }


                            if (file != null && file.exists()) {
                                if (getstr(applicationContext, pathname).equals(
                                        "",
                                        ignoreCase = true
                                    )
                                ) {
                                    str = getAttributes(pathname)
                                    storeShare(applicationContext, pathname, str)
                                } else {
                                    str = getstr(applicationContext, pathname)
                                }
                                if (str != null && str.length > 0) {
                                    aVar.serplaceName(str)
                                    val mediumHeader = ThumbnailSection(str)
                                    if (!media.contains(mediumHeader))
                                        media.add(mediumHeader)
                                    val medium = Medium(null, title, pathname, file!!.parent, date_modified.toLong(), datetaken.toLong(), file!!.length(), TYPE_IMAGES, 0, false, 0L)
                                    media.add(medium)
                                    allPlaceList.add(medium)
                                    if (contains.contains(aVar)) {
                                        val sb2 = StringBuilder()
                                        sb2.append("getCameraImages:location ")
                                        sb2.append(str)
                                        Log.d("TAG", sb2.toString())
                                        val indexOf = contains.indexOf(aVar)
                                        val aVar2 = contains[indexOf]
                                        val b: ArrayList<String> = aVar2.folderDataPath
                                        b.add(pathname)
                                        aVar2.setFolderPathList(b)
                                        aVar2.setDate(str)
                                        contains[indexOf] = aVar2
                                    } else {
                                        val arrayList: ArrayList<String> = ArrayList<String>()
                                        arrayList.add(pathname)
                                        aVar.setFolderPathList(arrayList)
                                        aVar.setDate(str)
                                        contains.add(aVar)

                                    }
                                    placeModles = contains
                                }
                            }
                        }
                    } while (query.moveToNext())
                }
                query.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return placeModles
        }

        public override fun onPostExecute(placeModles1: ArrayList<placeModle>?) {
            aBoolean = true
            Log.e("KKKK", "onPostExecute:placeModles1.size()    " + placeModles1!!.size)
            Log.e("KKKK", "onPostExecute:placeModles1.size()    " + media.size)
            media_refresh_layout.isRefreshing=false
            runOnUiThread {
                if ( media.size == 0) {

                    media_grid.visibility = View.GONE
                    media_empty_text_placeholder.visibility = View.VISIBLE
                    if (AdsManager(this@PlaceActivity).isNeedToShowAds()) {
                        loadOfflineNativeAdvance(findViewById(R.id.adViewContainer))
                    }
                    hideDialog()
                    val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
                    params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
                    appBarLayout.requestLayout()
                } else {
                    /* placeAdapter!!.setData(placeModles1)
                     hideDialog()
                     placeAdapter!!.notifyDataSetChanged()*/
                    media_empty_text_placeholder.visibility = View.GONE
                    val params: AppBarLayout.LayoutParams = toolbar.layoutParams as AppBarLayout.LayoutParams
                    params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL or AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS
                    appBarLayout.requestLayout()
                    hideDialog()
                    setupAdapter()
                }
                if (ScanningDialog != null && ScanningDialog!!.isShowing) {
                    ScanningDialog!!.cancel()
                }
            }
        }
    }

    private fun setupAdapter() {
        /*     if (!mShowAll && isDirEmpty()) {
                 return
             }*/
        media_refresh_layout.isRefreshing = false
        val currAdapter = media_grid.adapter
        if (currAdapter == null) {
//            initZoomListener()
            val fastscroller = if (config.scrollHorizontally) media_horizontal_fastscroller else media_vertical_fastscroller
            MediaAdapter(
                this, media.clone() as java.util.ArrayList<ThumbnailItem>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, "", media_grid, fastscroller
            ) {
                if (it is Medium && !isFinishing) {
                    itemClicked(it.path)
                }
            }.apply {
//                setupZoomListener(mZoomListener)
                media_grid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                media_grid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
            measureRecyclerViewContent(media)
        } else if (mLastSearchedText.isEmpty()) {
            (currAdapter as MediaAdapter).updateMedia(media)
            handleGridSpacing()
            measureRecyclerViewContent(media)
        } else {
//            searchQueryChanged(mLastSearchedText)
        }

        setupScrollDirection()
    }

    private fun itemClicked(path: String) {
        if (isSetWallpaperIntent()) {
            toast(R.string.setting_wallpaper)

            val wantedWidth = wallpaperDesiredMinimumWidth
            val wantedHeight = wallpaperDesiredMinimumHeight
            val ratio = wantedWidth.toFloat() / wantedHeight

            val options = RequestOptions()
                .override((wantedWidth * ratio).toInt(), wantedHeight)
                .fitCenter()

            Glide.with(this)
                .asBitmap()
                .load(File(path))
                .apply(options)
                .into(object : SimpleTarget<Bitmap>() {
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                        try {
                            WallpaperManager.getInstance(applicationContext).setBitmap(resource)
                            setResult(Activity.RESULT_OK)
                        } catch (ignored: IOException) {
                        }

                        finish()
                    }
                })
        }/* else if (mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent) {
            Intent().apply {
                data = Uri.parse(path)
                setResult(Activity.RESULT_OK, this)
            }
            finish()
        }*/ else {
            val isVideo = path.isVideoFast()
            if (isVideo) {
                val extras = HashMap<String, Boolean>()
                extras[SHOW_FAVORITES] = false

                if (shouldSkipAuthentication()) {
                    extras[SKIP_AUTHENTICATION] = true
                }
//                openPath(path, false, extras)
                val uri = FileProvider.getUriForFile(
                    this,
                    "$packageName.fileprovider", File(path)
                )
                val mimeType = getUriMimeType(path, uri)
                Intent(applicationContext, VideoPlayerActivity::class.java).apply {
                    setDataAndType(uri, mimeType)
                    addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT)
                    if (intent.extras != null) {
                        putExtras(intent.extras!!)
                    }

                    startActivity(this)
                }
            } else {
                ImagePreviewActivity.mPlaceItemList = allPlaceList
                Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(SKIP_AUTHENTICATION, shouldSkipAuthentication())
                    putExtra(PATH, path)
                    putExtra(SHOW_ALL, mShowAll)
                    putExtra(SHOW_FAVORITES, false)
                    putExtra(SHOW_PLACE, true)
                    putExtra(SHOW_RECYCLE_BIN, false)
                    startActivity(this)
                }
            }
        }
    }

    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        (media_grid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
//            media_refresh_layout.layoutParams = ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
//            media_refresh_layout.layoutParams = ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        layoutManager.spanCount = config.mediaColumnCnt
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun getMediaAdapter() = media_grid.adapter as? MediaAdapter

    private fun setupListLayoutManager() {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL
//        media_refresh_layout.layoutParams = ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (media_grid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        media_vertical_fastscroller.isHorizontal = false
        media_vertical_fastscroller.beGoneIf(allowHorizontalScroll)

        media_horizontal_fastscroller.isHorizontal = true
        media_horizontal_fastscroller.beVisibleIf(allowHorizontalScroll)

        val sorting = config.getFolderSorting(SHOW_ALL)
        /* if (allowHorizontalScroll) {
             media_horizontal_fastscroller.setViews(media_grid, media_refresh_layout) {
                 media_horizontal_fastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
             }
         } else {
             media_vertical_fastscroller.setViews(media_grid, media_refresh_layout) {
                 media_vertical_fastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
             }
         }*/
    }

    private fun measureRecyclerViewContent(media: java.util.ArrayList<ThumbnailItem>) {
        media_grid.onGlobalLayout {
            if (config.scrollHorizontally) {
                calculateContentWidth(media)
            } else {
                calculateContentHeight(media)
            }
        }
    }

    private fun calculateContentWidth(media: java.util.ArrayList<ThumbnailItem>) {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        val thumbnailWidth = layoutManager.getChildAt(0)?.width ?: 0
        val spacing = config.thumbnailSpacing
        val fullWidth = ((media.size - 1) / layoutManager.spanCount + 1) * (thumbnailWidth + spacing) - spacing
        media_horizontal_fastscroller.setContentWidth(fullWidth)
        media_horizontal_fastscroller.setScrollToX(media_grid.computeHorizontalScrollOffset())
    }

    private fun calculateContentHeight(media: java.util.ArrayList<ThumbnailItem>) {
        val layoutManager = media_grid.layoutManager as MyGridLayoutManager
        val pathToCheck = SHOW_ALL
        val hasSections = config.getFolderGrouping(pathToCheck) and GROUP_BY_NONE == 0 && !config.scrollHorizontally
        val sectionTitleHeight = if (hasSections) layoutManager.getChildAt(0)?.height ?: 0 else 0
        val thumbnailHeight = if (hasSections) layoutManager.getChildAt(1)?.height ?: 0 else layoutManager.getChildAt(0)?.height ?: 0

        var fullHeight = 0
        var curSectionItems = 0
        media.forEach {
            if (it is ThumbnailSection) {
                fullHeight += sectionTitleHeight
                if (curSectionItems != 0) {
                    val rows = ((curSectionItems - 1) / layoutManager.spanCount + 1)
                    fullHeight += rows * thumbnailHeight
                }
                curSectionItems = 0
            } else {
                curSectionItems++
            }
        }
        val spacing = config.thumbnailSpacing
        fullHeight += ((curSectionItems - 1) / layoutManager.spanCount + 1) * (thumbnailHeight + spacing) - spacing
        media_vertical_fastscroller.setContentHeight(fullHeight)
        media_vertical_fastscroller.setScrollToY(media_grid.computeVerticalScrollOffset())
    }


    private fun handleGridSpacing(media: java.util.ArrayList<ThumbnailItem> = this.media) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (media_grid.itemDecorationCount > 0) {
                currentGridDecoration = media_grid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, config.scrollHorizontally, config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    media_grid.removeItemDecoration(currentGridDecoration)
                }
                media_grid.addItemDecoration(newGridDecoration)
            }
        }
    }

    fun hideDialog() {
        try {

            if (rel_top_Progress != null) {
                if (rel_top_Progress!!.visibility == View.VISIBLE) {
                    rel_top_Progress!!.visibility = View.GONE
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getfilePath(str: String?): String {
        return File(str).absoluteFile.parent
    }

    fun getAttributes(str: String?): String? {
        val f: Float?
        val f2: Float?
        try {
            val exifInterface = ExifInterface(str!!)
            val attribute = exifInterface.getAttribute("GPSLatitude")
            val attribute2 = exifInterface.getAttribute("GPSLatitudeRef")
            val attribute3 = exifInterface.getAttribute("GPSLongitude")
            val attribute4 = exifInterface.getAttribute("GPSLongitudeRef")
            if (attribute == null || attribute2 == null || attribute3 == null || attribute4 == null) {
                f = null
                f2 = null
            } else {
                f = if (attribute2 == "N") {
                    getFloting(attribute)
                } else {
                    java.lang.Float.valueOf(0.0f - getFloting(attribute))
                }
                f2 = if (attribute4 == "E") getFloting(attribute3) else java.lang.Float.valueOf(
                    0.0f - getFloting(
                        attribute3
                    )
                )
            }
            if (f != null || f2 != null) return getAddressFromltLong(
                f!!.toFloat().toDouble(),
                f2!!.toFloat().toDouble()
            )
        } catch (unused: Exception) {
            unused.printStackTrace()
            return null
        }
        return null
    }

    fun getAddressFromltLong(d: Double, d2: Double): String? {
        return try {
            val fromLocation: List<*>? = Geocoder(this, Locale.getDefault()).getFromLocation(
                d,
                d2,
                1
            )
            var addressLine = (fromLocation!![0] as Address).getAddressLine(0)
            val locality = (fromLocation[0] as Address).locality
            val adminArea = (fromLocation[0] as Address).adminArea
            val countryName = (fromLocation[0] as Address).countryName
            if (fromLocation != null && fromLocation.size > 0) {
                addressLine = (fromLocation[0] as Address).subLocality
            }
            if (addressLine == null) {
                addressLine = locality ?: (adminArea ?: countryName)
            }
            val sb = StringBuilder()
            sb.append("getAddress: ")
            sb.append(addressLine)
            sb.append(" ++ ")
            sb.append(locality)
            sb.append(" ++  ")
            sb.append(adminArea)
            sb.append(" ++  ")
            sb.append(countryName)
            Log.d("TAG", sb.toString())
            addressLine
        } catch (unused: Exception) {
            null
        }
    }

    companion object {
        public const val CHANNEL_ID = "1250012"
        fun storeShare(context: Context, str: String?, str2: String?) {
            val edit = context.getSharedPreferences("photogallerydata", 0).edit()
            edit.putString(str, str2)
            edit.commit()
        }

        fun getstr(context: Context, str: String?): String? {
            return context.getSharedPreferences("photogallerydata", 0).getString(str, "")
        }

        fun getFloting(str: String): Float {
            val split = str.split(",".toRegex(), 3).toTypedArray()
            val split2 = split[0].split("/".toRegex(), 2).toTypedArray()
            val valueOf = java.lang.Double.valueOf(split2[0].toDouble() / split2[1].toDouble())
            val split3 = split[1].split("/".toRegex(), 2).toTypedArray()
            val valueOf2 = java.lang.Double.valueOf(split3[0].toDouble() / split3[1].toDouble())
            val split4 = split[2].split("/".toRegex(), 2).toTypedArray()
            return (valueOf.toDouble() + valueOf2.toDouble() / 60.0 + java.lang.Double.valueOf(
                split4[0].toDouble() / split4[1].toDouble()
            ).toDouble() / 3600.0).toFloat()
        }
    }

    override fun onBackPressed() {
//        Share.unLockApp = true
        if (rel_top_Progress!!.visibility == View.VISIBLE) {
            val dialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
                .setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>Exit Scanning</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
                .setMessage("Do you want to stop scanning?")
                .setPositiveButton(HtmlCompat.fromHtml("<b>" + "Yes" + "<b>", HtmlCompat.FROM_HTML_MODE_LEGACY)) { dialogInterface, i ->
                    iscontinue = false
                    if (onjays != null) {
                        onjays!!.onCancelled()
                        onjays!!.cancel(true)
                        onjays = null
                    }
                    placeModles!!.clear()
                    placeModles = ArrayList()
                    finish()
                }
                .setNegativeButton(
                    HtmlCompat.fromHtml(
                        "<b>" + "No" + "<b>",
                        HtmlCompat.FROM_HTML_MODE_LEGACY
                    )
                ) { dialogInterface, i -> dialogInterface.dismiss() }
            ScanningDialog = dialogBuilder.create()
            ScanningDialog!!.show()
            val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.album.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
            ScanningDialog!!.window?.setBackgroundDrawable(bgDrawable)
            ScanningDialog!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(
                com.gallery.photo.album.video.R.color.color_primary))
            ScanningDialog!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(
                com.gallery.photo.album.video.R.color.color_primary))
            ScanningDialog!!.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(
                com.gallery.photo.album.video.R.color.color_primary))

//            ScanningDialog!!.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(
//                Share.getAPPThemWisePrimoryColor(
//                    this@PlaceWiseActiivty
//                )
//            )
//            ScanningDialog!!.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(
//                Share.getAPPThemWisePrimoryColor(
//                    this@PlaceWiseActiivty
//                )
//            )
        } else {
            iscontinue = false
            if (onjays != null) {
                onjays!!.onCancelled()
                onjays!!.cancel(true)
                onjays = null
            }
            placeModles!!.clear()
            placeModles = ArrayList()

            if (isFromOneSignal) {
                startActivity(Intent(this, MainActivity::class.java))
            }
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun isSetWallpaperIntent() = intent.getBooleanExtra(SET_WALLPAPER_INTENT, false)

    private fun shouldSkipAuthentication() = intent.getBooleanExtra(SKIP_AUTHENTICATION, false)

    override fun refreshItems() {
        media.clear()
        allPlaceList.clear()
        onjays = getData()
        onjays!!.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, *arrayOfNulls<String>(0))
    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {
        val filtered = fileDirItems.filter { !getIsPathDirectory(it.path) && it.path.isMediaFile() } as ArrayList
        if (filtered.isEmpty()) {
            return
        }

        /*if (config.useRecycleBin && !filtered.first().path.startsWith(recycleBinPath)) {
            val movingItems = resources.getQuantityString(R.plurals.moving_items_into_bin, filtered.size, filtered.size)
            toast(movingItems)

            movePathsInRecycleBin(filtered.map { it.path } as ArrayList<String>) {
                if (it) {
                    deleteFilteredFiles(filtered)
                } else {
                    toast(R.string.unknown_error_occurred)
                }
            }
        } else {*/
        val deletingItems = resources.getQuantityString(R.plurals.deleting_items, filtered.size, filtered.size)
        toast(deletingItems)
        deleteFilteredFiles(filtered)
//        }
    }

    private fun deleteFilteredFiles(filtered: ArrayList<FileDirItem>) {
        deleteFiles(filtered) {
            if (!it) {
                toast(R.string.unknown_error_occurred)
                return@deleteFiles
            }

            media.removeAll { filtered.map { it.path }.contains((it as? Medium)?.path) }

            ensureBackgroundThread {
                val useRecycleBin = config.useRecycleBin
                filtered.forEach {
//                    if (it.path.startsWith(recycleBinPath) || !useRecycleBin) {
                    deleteDBPath(it.path)
//                    }
                }
            }

            if (MediaActivity.mMedia.isEmpty()) {
                deleteDirectoryIfEmpty()
                deleteDBDirectory()
                finish()
            }
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (config.deleteEmptyFolders) {
            val fileDirItem = FileDirItem(mPath, mPath.getFilenameFromPath(), true)
            if (!fileDirItem.isDownloadsFolder() && fileDirItem.isDirectory) {
                ensureBackgroundThread {
                    if (fileDirItem.getProperFileCount(this, true) == 0) {
                        tryDeleteFileDirItem(fileDirItem, true, true)
                    }
                }
            }
        }
    }

    private fun deleteDBDirectory() {
        ensureBackgroundThread {
            try {
                directoryDao.deleteDirPath(mPath)
            } catch (ignored: Exception) {
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }

}