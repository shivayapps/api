package com.gallery.photo.album.video.rateandfeedback.network

import androidx.annotation.Keep

@Keep
data class ModelResponseFeedback(
    var ResponseCode: Int? = null,
    var ResponseMessage: String? = null
)
