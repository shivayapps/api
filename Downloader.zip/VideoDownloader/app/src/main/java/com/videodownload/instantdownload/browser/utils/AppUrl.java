package com.videodownload.instantdownload.browser.utils;

import android.util.Log;


public class AppUrl {
//    public String hashTagBaseURL() {
//        return appEncrypt.hashTagBaseURL();
//    }
//    public String frameBaseURL() {
//        return appEncrypt.frameBaseURL();
//    }
//    public String instagramBaseURL() {
//        return appEncrypt.instagramBaseURL();
//    }
//    public String hashtagListENDURL() {
//        return appEncrypt.hashtagListENDURL();
//    }
//    public String dpGeneratorCategoryListENDURL() {
//        return appEncrypt.dpGeneratorCategoryListENDURL();
//    }
//    public String dpGeneratorSubcategoryListENDURL() {
//        return appEncrypt.dpGeneratorSubcategoryListENDURL();
//    }
//    public String instagramCopyENDURL() {
//        return appEncrypt.instagramCopyENDURL();
//    }
//    public String callResultUserAgent1() {
//        return appEncrypt.callResultUserAgent1();
//    }
//    public String callResultUserAgent2() {
//        return appEncrypt.callResultUserAgent2();
//    }
//    public String cookieStart() {
//        return appEncrypt.cookieStart();
//    }
//    public String cookieEnd() {
//        return appEncrypt.cookieEnd();
//    }
//    public String DpSearchBaseURL() {
//        return appEncrypt.DpSearchBaseURL();
//    }
//    public String DpSearchENDURL() {
//        return appEncrypt.DpSearchENDURL();
//    }
//    public String callResultUserAgent3() {
//        return appEncrypt.callResultUserAgent3();
//    }
//    public String HDDpSearchBaseURL() {
//        return appEncrypt.HDDpSearchBaseURL();
//    }
//    public String HDDpSearchEndURL() {
//        return appEncrypt.HDDpSearchEndURL();
//    }
//    public String StoriesFullDetailURL() {
//        return appEncrypt.StoriesFullDetailURL();
//    }
//    public String storiesApiURL() {
//        return appEncrypt.storiesApiURL();
//    }
//    public String callResultUserAgent4() {
//        return appEncrypt.callResultUserAgent4();
//    }
//    public String storiesFullDetailHeader0() {
//        return appEncrypt.storiesFullDetailHeader0();
//    }
//    public String storiesFullDetailHeader1() {
//        return appEncrypt.storiesFullDetailHeader1();
//    }
//    public String storiesFullDetailHeader2() {
//        return appEncrypt.storiesFullDetailHeader2();
//    }
//    public String storiesFullDetailHeader3() {
//        return appEncrypt.storiesFullDetailHeader3();
//    }
//
//    public String storiesFullDetailHeader4() {
//        return appEncrypt.storiesFullDetailHeader4();
//    }
//
//    public String storiesFullDetailHeader5() {
//        return appEncrypt.storiesFullDetailHeader5();
//    }
//    public String storiesFullDetailHeader6() {
//        return appEncrypt.storiesFullDetailHeader6();
//    }
//    public String storiesFullDetailHeader7() {
//        return appEncrypt.storiesFullDetailHeader7();
//    }
//    public String storiesFullDetailHeader8() {
//        return appEncrypt.storiesFullDetailHeader8();
//    }
//    public String storiesFullDetailHeader10() {
//        return appEncrypt.storiesFullDetailHeader10();
//    }
//    public String storiesFullDetailHeader11() {
//        return appEncrypt.storiesFullDetailHeader11();
//    }
//    public String storiesFullDetailHeader12() {
//        return appEncrypt.storiesFullDetailHeader12();
//    }
//    public String twitterBaseURL() {
//        return appEncrypt.twitterBaseURL();
//    }
//    public String twitterNope() {
//        return appEncrypt.twitterNope();
//    }
//    public String twitterOrderBy() {
//        return appEncrypt.twitterOrderBy();
//    }
//
    public String hashTagBaseURL(){ return "https://testappjson.s3.ap-southeast-1.amazonaws.com/";}
    public String frameBaseURL(){ return "https://apidpframe.appomania.co.in/api/";}
    public String instagramBaseURL(){ return "https://www.instagram.com/";}
    public String hashtagListENDURL(){ return "hashtag.json";}
    public String dpGeneratorCategoryListENDURL(){ return "category";}
    public String dpGeneratorSubcategoryListENDURL(){ return "get_subcategory/";}
    public String instagramCopyENDURL(){ return "?__a=1&__d=dis";}
    public String callResultUserAgent1(){ return "Instagram 128.0.0.19.128 (Linux; Android 8.0; ANE-LX1 Build/HUAWEIANE-LX1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36";}
    public String callResultUserAgent2(){ return "Mozilla/5.0 (Linux; U; Android 4.2.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30";}
    public String cookieStart(){ return "ds_user_id=";}
    public String cookieEnd(){ return "; sessionid=";}
    public String DpSearchBaseURL(){ return "https://www.instagram.com/web/search/topsearch/?context=blended&query=";}
    public String DpSearchENDURL(){ return "&include_reel=false";}
    public String callResultUserAgent3(){ return "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.131 Mobile Safari/537.36";}
    public String HDDpSearchBaseURL(){ return "https://instagram.com/";}
    public String HDDpSearchEndURL(){ return "/?__a=1&__d=dis";}
    public String StoriesFullDetailURL(){ return "https://i.instagram.com/api/v1/feed/reels_media/";}
    public String storiesApiURL(){ return "https://i.instagram.com/api/v1/feed/reels_tray/";}
    public String callResultUserAgent4(){ return "Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+";}
    public String storiesFullDetailHeader0(){ return "\"Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.131 Mobile Safari/537.36\"";}
    public String storiesFullDetailHeader1(){ return "936619743392459";}
    public String storiesFullDetailHeader2(){ return "*/*";}
    public String storiesFullDetailHeader3(){ return "en-US,en;q=0.5";}
    public String storiesFullDetailHeader4(){ return "198387";}
    public String storiesFullDetailHeader5(){ return "hmac.AR0RiVMdZR3OBMQbj0C2mnJc8cDcVdbTQdcHyaroQcXU6ORB";}
    public String storiesFullDetailHeader6(){ return "https://www.instagram.com/";}
    public String storiesFullDetailHeader7(){ return "1";}
    public String storiesFullDetailHeader8(){ return "keep-alive";}
    public String storiesFullDetailHeader10(){ return "empty";}
    public String storiesFullDetailHeader11(){ return "cors";}
    public String storiesFullDetailHeader12(){ return "trailers";}
    public String twitterBaseURL(){ return "https://twittervideodownloaderpro.com/api/index.php";}
    public String twitterNope(){ return "45f779d949594f51d50e9f2e3a6ad0c44fcabfcd";}
    public String twitterOrderBy(){ return "0123456789abcdefghjklmoprstiuvyzx";}


//    public AppUrl() {
//        appEncrypt = new AppEncrypt();
//    }

//    static {
//        System.loadLibrary("demohideurltext");
//    }
}
