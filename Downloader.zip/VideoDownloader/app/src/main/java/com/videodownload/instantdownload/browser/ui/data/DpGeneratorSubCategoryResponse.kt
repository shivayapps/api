package com.videodownload.instantdownload.browser.ui.data

class DpGeneratorSubCategoryResponse : ArrayList<DpGeneratorSubCategoryItem>()