package com.videodownload.instantdownload.browser.browser.helpers;

import android.webkit.URLUtil;

import androidx.webkit.ProxyConfig;

import com.koushikdutta.async.http.body.Part;
import com.videodownload.instantdownload.browser.utils.Constant;

import org.apache.commons.io.FilenameUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Entities;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;


public class AnyFilesParser {
    boolean forcedStop = false;

    public interface AnyFilesParserHandler {
        void OnComplete(ArrayList<AnyDownloadModel> list);

        void OnError(String str);
    }

    public static void getDownloadUrlFromPinterest(String str, AnyFilesParserHandler anyFilesParserHandler) {
        ArrayList arrayList = new ArrayList();
        Document parse = Jsoup.parse(str);
        parse.outputSettings().escapeMode(Entities.EscapeMode.base);
        Elements elementsByTag = parse.getElementsByTag("video");
        if (elementsByTag.size() > 0) {
            Iterator<Element> it = elementsByTag.iterator();
            if (it.hasNext()) {
                Element next = it.next();
                String guessFileName = URLUtil.guessFileName(next.attributes().get("src"), null, null);
                String extension = FilenameUtils.getExtension(guessFileName);
                arrayList.add(new AnyDownloadModel(AnyDownloadModel.AnyFileType.VIDEO, next.attributes().get("src").replace("/hls/", "/720p/").replace(".m3u8", ".mp4"), next.attributes().get("poster"), FilenameUtils.getBaseName(guessFileName), extension));
            }
            anyFilesParserHandler.OnComplete(arrayList);
            return;
        }
        anyFilesParserHandler.OnError("");
    }

    public void parseAnySite(String str, String str2, AnyFilesParserHandler anyFilesParserHandler) {
        ArrayList arrayList = new ArrayList();
        Document parse = Jsoup.parse(str);
        parse.outputSettings().escapeMode(Entities.EscapeMode.base);
        Iterator<Element> it = parse.getElementsByAttribute("src").iterator();
        while (it.hasNext()) {
            Element next = it.next();
            if (this.forcedStop) {
                break;
            } else if (isImageSource(next.attributes().get("src")) && next.attributes().get("src").toLowerCase().contains(ProxyConfig.MATCH_HTTP)) {
                String guessFileName = URLUtil.guessFileName(next.attributes().get("src"), null, null);
                String extension = FilenameUtils.getExtension(guessFileName);
                arrayList.add(new AnyDownloadModel(AnyDownloadModel.AnyFileType.IMAGE, next.attributes().get("src"), next.attributes().get("src"), FilenameUtils.getBaseName(guessFileName), extension));
            } else if (isVideoSource(next.attributes().get("src")) && next.attributes().get("src").toLowerCase().contains(ProxyConfig.MATCH_HTTP)) {
                String guessFileName2 = URLUtil.guessFileName(next.attributes().get("src"), null, null);
                String extension2 = FilenameUtils.getExtension(guessFileName2);
                arrayList.add(new AnyDownloadModel(AnyDownloadModel.AnyFileType.VIDEO, next.attributes().get("src"), next.attributes().get("src"), FilenameUtils.getBaseName(guessFileName2), extension2));
            }
        }
        if (!this.forcedStop) {
            anyFilesParserHandler.OnComplete(arrayList);
        } else {
            anyFilesParserHandler.OnError("Процесс остановлен принудительно!");
        }
    }

    public void getAnyFilesFromClickedElement(String str, String str2, AnyFilesParserHandler anyFilesParserHandler) {
        String str3;
        String str4;
        if (!str.contains("<html>")) {
            str = "<html>" + str + "</html>";
        }
        ArrayList arrayList = new ArrayList();
        Document parse = Jsoup.parse(str);
        parse.outputSettings().escapeMode(Entities.EscapeMode.base);
        Iterator<Element> it = parse.getElementsByAttribute("src").iterator();
        while (it.hasNext()) {
            Element next = it.next();
            if (this.forcedStop) {
                break;
            } else if (isImageSource(next.attributes().get("src"))) {
                if (!next.attributes().get("src").toLowerCase().contains(ProxyConfig.MATCH_HTTP)) {
                    String str5 = next.attributes().get("src");
                    while (str5.length() > 0 && str5.charAt(0) == '/') {
                        str5 = str5.replaceFirst("/", "");
                    }
                    str3 = Constant.HTTP + str5;
                } else {
                    str3 = next.attributes().get("src");
                }
                String str6 = str3;
                String guessFileName = URLUtil.guessFileName(str6, null, "image/*");
                arrayList.add(new AnyDownloadModel(AnyDownloadModel.AnyFileType.IMAGE, str6, str6, FilenameUtils.getBaseName(guessFileName), FilenameUtils.getExtension(guessFileName)));
            } else if (isVideoSource(next.attributes().get("src")) && next.attributes().get("src").toLowerCase().contains(ProxyConfig.MATCH_HTTP)) {
                if (!next.attributes().get("src").toLowerCase().contains(ProxyConfig.MATCH_HTTP)) {
                    String str7 = next.attributes().get("src");
                    while (str7.length() > 0 && str7.charAt(0) == '/') {
                        str7 = str7.replaceFirst("/", "");
                    }
                    str4 = Constant.HTTP + str7;
                } else {
                    str4 = next.attributes().get("src");
                }
                String str8 = str4;
                String guessFileName2 = URLUtil.guessFileName(str8, null, null);
                arrayList.add(new AnyDownloadModel(AnyDownloadModel.AnyFileType.VIDEO, str8, str8, FilenameUtils.getBaseName(guessFileName2), FilenameUtils.getExtension(guessFileName2)));
            }
        }
        if (!this.forcedStop) {
            anyFilesParserHandler.OnComplete(arrayList);
        } else {
            anyFilesParserHandler.OnError("Процесс остановлен принудительно!");
        }
    }

    public void parseLink(String str, AnyFilesParserHandler anyFilesParserHandler) {
        ArrayList arrayList = new ArrayList();
        if (isImageSource(str)) {
            if (!str.toLowerCase().contains(ProxyConfig.MATCH_HTTP)) {
                while (str.length() > 0 && str.charAt(0) == '/') {
                    str = str.replaceFirst("/", "");
                }
                str = Constant.HTTP + str;
            }
            String str2 = str;
            String guessFileName = URLUtil.guessFileName(str2, null, "image/*");
            arrayList.add(new AnyDownloadModel(AnyDownloadModel.AnyFileType.IMAGE, str2, "", FilenameUtils.getBaseName(guessFileName), FilenameUtils.getExtension(guessFileName)));
        } else if (isVideoSource(str)) {
            if (!str.toLowerCase().contains(ProxyConfig.MATCH_HTTP)) {
                while (str.length() > 0 && str.charAt(0) == '/') {
                    str = str.replaceFirst("/", "");
                }
                str = Constant.HTTP + str;
            }
            String str3 = str;
            String guessFileName2 = URLUtil.guessFileName(str3, null, null);
            arrayList.add(new AnyDownloadModel(AnyDownloadModel.AnyFileType.VIDEO, str3, "", FilenameUtils.getBaseName(guessFileName2), FilenameUtils.getExtension(guessFileName2)));
        }
        if (!this.forcedStop) {
            anyFilesParserHandler.OnComplete(arrayList);
        } else {
            anyFilesParserHandler.OnError("Процесс остановлен принудительно!");
        }
    }

    public void stopTasks() {
        this.forcedStop = true;
    }

    private String getFilenameWithExtFromUrl(String str) {
        String guessFileName;
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.connect();
            httpURLConnection.setInstanceFollowRedirects(false);
            String headerField = httpURLConnection.getHeaderField(Part.CONTENT_DISPOSITION);
            if (headerField != null) {
                guessFileName = headerField.replaceFirst("(?i)^.*filename=\"?([^\"]+)\"?.*$", "$1");
            } else {
                guessFileName = URLUtil.guessFileName(str, null, null);
            }
            return guessFileName;
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        } catch (IOException unused) {
            return null;
        }
    }

    public boolean isImageSource(String str) {
        return str.toLowerCase().contains(".jpg") || str.toLowerCase().contains(".jpeg") || str.toLowerCase().contains(".png") || str.toLowerCase().contains(".gif");
    }

    public boolean isVideoSource(String str) {
        return str.toLowerCase().contains(".mp4") || str.toLowerCase().contains(".3gp") || str.toLowerCase().contains(".avi") || str.toLowerCase().contains(".mov") || str.toLowerCase().contains(".mkv") || str.toLowerCase().contains(".mpeg");
    }
}
