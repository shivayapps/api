package com.videodownload.instantdownload.browser.ui.interfaces

interface CheckFolder {
    fun dataEmpty()
}