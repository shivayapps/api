package com.videodownload.instantdownload.browser.ui.data

data class DpResponse(val graphql: Graphql)

data class Graphql(
    val user: User,
)
