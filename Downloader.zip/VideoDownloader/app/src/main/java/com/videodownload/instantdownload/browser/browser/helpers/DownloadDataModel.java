package com.videodownload.instantdownload.browser.browser.helpers;


public class DownloadDataModel {
    private MediaTypeIdent mediaType = MediaTypeIdent.VIDEO;
    private String fileSize = "";
    private String downloadURL = "";
    private String qualityName = "Неизвестно";
    private String extention = "";
    private String mimeType = "";

    public String getDownloadURL() {
        return this.downloadURL;
    }

    public void setDownloadURL(String str) {
        this.downloadURL = str;
    }

    public String getQualityName() {
        return this.qualityName;
    }

    public void setQualityName(String str) {
        this.qualityName = str;
    }

    public String getExtention() {
        return this.extention;
    }

    public void setExtention(String str) {
        this.extention = str;
    }

    public String getMimeType() {
        return this.mimeType;
    }

    public void setMimeType(String str) {
        this.mimeType = str;
    }

    public MediaTypeIdent getMediaType() {
        return this.mediaType;
    }

    public void setMediaType(MediaTypeIdent mediaTypeIdent) {
        this.mediaType = mediaTypeIdent;
    }

    public String getFileSize() {
        return this.fileSize;
    }

    public void setFileSize(String str) {
        this.fileSize = str;
    }
}
