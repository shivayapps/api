package com.videodownload.instantdownload.browser.network;

import android.app.Activity;
import android.util.Log;

import com.videodownload.instantdownload.browser.utils.AppUrl;

import org.json.JSONObject;

import java.net.SocketTimeoutException;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class RestClientSimple {
    private static Retrofit retrofit = null;
    private static final RestClientSimple restClient = new RestClientSimple();
    APIServices myApi;
    private static Activity mActivity;

    public static RestClientSimple getInstance(Activity activity) {
        mActivity = activity;
        return restClient;
    }

    private RestClientSimple() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(2, TimeUnit.MINUTES)
                .connectTimeout(2, TimeUnit.MINUTES)
                .writeTimeout(2, TimeUnit.MINUTES)
//                .addInterceptor(chain -> {
//                    Response response = null;
//                    try {
//                        Request request = chain.request();
//                        response = chain.proceed(request);
//                        if (response.code() == 200) {
//                            try {
//                                JSONObject jsonObject = new JSONObject(response.body().string());
//                                String data = jsonObject.toString();
//                                printMsg(data + "");
//                                MediaType contentType = response.body().contentType();
//                                ResponseBody responseBody = ResponseBody.create(contentType, data);
//                                return response.newBuilder().body(responseBody).build();
//                            } catch (Exception e) {
////                                e.printStackTrace();
//                            }
//                        }
//                    } catch (Exception e) {
////                        e.printStackTrace();
//                    }
//                    if (response != null)
//                        return response;
//                    return null;
//                })
                .addInterceptor(interceptor)
                .build();
        if (retrofit == null) {

            retrofit = new Retrofit.Builder()
                    .baseUrl(new AppUrl().instagramBaseURL())
                    .addConverterFactory(GsonConverterFactory.create())
//                    .addConverterFactory(GsonConverterFactory.create(new Gson()))
                    .client(client)
                    .build();
            myApi = retrofit.create(APIServices.class);
        }
    }

    public APIServices getService() {
        return retrofit.create(APIServices.class);
    }

    private void printMsg(String msg) {
        int chunkCount = msg.length() / 4050;
        for (int i = 0; i <= chunkCount; i++) {
            int max = 4050 * (i + 1);
            if (max >= msg.length()) {
                Log.d("Response::", msg.substring(4050 * i));
            } else {
                Log.d("Response::", msg.substring(4050 * i, max));
            }
        }
    }
}