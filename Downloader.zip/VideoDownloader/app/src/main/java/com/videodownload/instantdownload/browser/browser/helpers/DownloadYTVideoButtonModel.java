package com.videodownload.instantdownload.browser.browser.helpers;

import java.util.ArrayList;
import java.util.List;

public class DownloadYTVideoButtonModel {
    private int button_id = 0;
    private String videoTitle = "";
    private String domainUrl = "";
    private String targetURL = "";
    private YTVideoType videoType = YTVideoType.CLASSIC_VIDEO_LIST;
    private List<DownloadDataModel> downloadDataModels = new ArrayList();

    public enum YTVideoType {
        CLASSIC_VIDEO_LIST,
        SHORT,
        STREAM,
        CLASSIC_VIDEO_FULLY,
        SHORT_FULLY
    }

    public String toString() {
        return "dwnld-button-" + Integer.toString(this.button_id);
    }

    public String getTargetFullURL() {
        return this.domainUrl + this.targetURL;
    }

    public int getButton_id() {
        return this.button_id;
    }

    public void setButton_id(int i) {
        this.button_id = i;
    }

    public String getDomainUrl() {
        return this.domainUrl;
    }

    public void setDomainUrl(String str) {
        this.domainUrl = str;
    }

    public String getTargetURL() {
        return this.targetURL;
    }

    public void setTargetURL(String str) {
        this.targetURL = str;
    }

    public List<DownloadDataModel> getDownloadDataModels() {
        return this.downloadDataModels;
    }

    public void setDownloadDataModels(List<DownloadDataModel> list) {
        this.downloadDataModels = list;
    }

    public String getVideoTitle() {
        return this.videoTitle;
    }

    public void setVideoTitle(String str) {
        this.videoTitle = str;
    }

    public YTVideoType getVideoType() {
        return this.videoType;
    }

    public void setVideoType(YTVideoType yTVideoType) {
        this.videoType = yTVideoType;
    }
}
