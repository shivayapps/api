package com.videodownload.instantdownload.browser.utils

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri

class Preferences(var context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(Constant.PREF_NAME, Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPreferences.edit()


    fun putStart(isStart: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_START, isStart)
        editor.apply()
    }

    fun isStar(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_START, false)
    }

    fun putRate(isRate: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_RATE, isRate)
        editor.apply()
    }

    fun isRate(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_RATE, false)
    }

    fun putRateCounter(counter: Int) {
        editor.putInt(Constant.PREF_KEY_RATE_COUNTER, counter)
        editor.apply()
    }

    fun getRateCounter(): Int {
        return sharedPreferences.getInt(Constant.PREF_KEY_RATE_COUNTER, 1)
    }

    fun putLoginInstagram(isLogin: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_LOGIN_INSTA, isLogin)
        editor.apply()
    }

    fun isLoginInstagram(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_LOGIN_INSTA, false)
    }

    fun putInstagramIntro(isLogin: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_INSTA_INTRO, isLogin)
        editor.apply()
    }

    fun isInstagramIntro(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_INSTA_INTRO, false)
    }

    fun putFBIntro(isLogin: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_FB_INTRO, isLogin)
        editor.apply()
    }

    fun isFBIntro(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_FB_INTRO, false)
    }

    fun putInstagramUserId(isLogin: String) {
        editor.putString(Constant.PREF_KEY_INSTA_USER_ID, isLogin)
        editor.apply()
    }

    fun getInstagramUserId(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_INSTA_USER_ID, "")
    }

    fun putInstagramToken(isLogin: String) {
        editor.putString(Constant.PREF_KEY_INSTA_TOKEN, isLogin)
        editor.apply()
    }

    fun getInstagramToken(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_INSTA_TOKEN, "")
    }

    fun putInstagramSessionID(isLogin: String) {
        editor.putString(Constant.PREF_KEY_INSTA_SESSION_ID, isLogin)
        editor.apply()
    }

    fun getInstagramSessionID(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_INSTA_SESSION_ID, "")
    }

    fun putInstagramCookies(isLogin: String) {
        editor.putString(Constant.PREF_KEY_INSTA_COOKIES, isLogin)
        editor.apply()
    }

    fun getInstagramCookies(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_INSTA_COOKIES, "")
    }

    fun putLoginFb(isLogin: Boolean) {
        editor.putBoolean(Constant.PREF_KEY_LOGIN_FB, isLogin)
        editor.apply()
    }

    fun isLoginFb(): Boolean {
        return sharedPreferences.getBoolean(Constant.PREF_KEY_LOGIN_FB, false)
    }

    fun putFbUserId(isLogin: String) {
        editor.putString(Constant.PREF_KEY_FB_USER_ID, isLogin)
        editor.apply()
    }

    fun getFbUserId(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_FB_USER_ID, "")
    }

    fun putFbToken(isLogin: String) {
        editor.putString(Constant.PREF_KEY_FB_TOKEN, isLogin)
        editor.apply()
    }

    fun getFbToken(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_FB_TOKEN, "")
    }

    fun putFbSessionID(isLogin: String) {
        editor.putString(Constant.PREF_KEY_FB_SESSION_ID, isLogin)
        editor.apply()
    }

    fun getFbSessionID(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_FB_SESSION_ID, "")
    }

    fun putFbCookies(isLogin: String) {
        editor.putString(Constant.PREF_KEY_FB_COOKIES, isLogin)
        editor.apply()
    }

    fun getFbCookies(): String? {
        return sharedPreferences.getString(Constant.PREF_KEY_FB_COOKIES, "")
    }

    fun getWhatsAppUri(): Uri? {
        val uri: String = getStringValue(Constant.PREF_WHATSAPP_URI, null) ?: return null
        return Uri.parse(uri)
    }

    private fun getStringValue(id: String, def: String?): String? {
        return sharedPreferences.getString(id, def)
    }

    fun setWhatsAppUri(intent: Intent) {
        val uri = intent.data
        val flag = intent.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, flag)
        }
        setStringValue(Constant.PREF_WHATSAPP_URI, uri.toString())
    }

    private fun setStringValue(key: String, value: String?) {
        editor.putString(key, value)
        editor.apply()
    }

    fun putTheme(themeValue: Int) {
        editor.putInt(Constant.PREF_KEY_THEME, themeValue)
        editor.apply()
    }

    fun getThemeValue(): Int {
        return sharedPreferences.getInt(Constant.PREF_KEY_THEME, 0)
    }
}