package com.videodownload.instantdownload.browser.ui.activity.option

import android.app.Dialog
import android.app.DownloadManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.TextPaint
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.snackbar.Snackbar
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.browser.event.DownloadCompleteEvent
import com.videodownload.instantdownload.browser.browser.event.StartDownloadEvent
import com.videodownload.instantdownload.browser.databinding.ActivityBrowserDownloadBinding
import com.videodownload.instantdownload.browser.databinding.DialogHowToUseBinding
import com.videodownload.instantdownload.browser.receiver.DownloadReceiver
import com.videodownload.instantdownload.browser.ui.activity.BaseActivity
import com.videodownload.instantdownload.browser.ui.activity.IntroActivity
import com.videodownload.instantdownload.browser.ui.activity.IntroFbActivity
import com.videodownload.instantdownload.browser.ui.data.DownloadData
import com.videodownload.instantdownload.browser.ui.fragment.DownloadFragment
import com.videodownload.instantdownload.browser.ui.fragment.DownloadProgressFragment
import com.videodownload.instantdownload.browser.ui.fragment.TabBrowserFragment
import com.videodownload.instantdownload.browser.ui.interfaces.AdsLoadCall
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.MyApplication
import com.videodownload.instantdownload.browser.utils.Preferences
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe

class BrowserDownloadActivity : BaseActivity() {

    lateinit var binding: ActivityBrowserDownloadBinding
    var currUrl: String = ""
    var openType = ""
    var countDownComplete = 0
    lateinit var downloadReceiver: DownloadReceiver
    lateinit var tabBrowser: TabBrowserFragment
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBrowserDownloadBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EventBus.getDefault().register(this)
        countDownComplete = 0
        inits()
        intiListener()
        setCountData()
        downloadReceiver = DownloadReceiver()
        registerReceiver(
            downloadReceiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        )

//        loadNativeBrowserDownload()
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.loutToolbar.ivHelp.setOnClickListener {
            if (openType == Constant.TYPE_FB)
                startActivity(
                    Intent(
                        this,
                        IntroFbActivity::class.java
                    )
                )
            else startActivity(
                Intent(
                    this,
                    IntroActivity::class.java
                ).putExtra(Constant.EXTRA_IS_OPEN_FROM_BROWSER, true)
            )
        }
        binding.btnTab1.setOnClickListener {
            binding.viewPager.currentItem = 0
        }
        binding.btnTab2.setOnClickListener {
            binding.viewPager.currentItem = 1
        }
        binding.btnTab3.setOnClickListener {
            binding.viewPager.currentItem = 2
        }
    }

    @Subscribe
    fun onDownloadCompleteEvent(startDownloadEvent: DownloadCompleteEvent) {
        runOnUiThread {
            countDownComplete++
            Log.e("onDownloadCompleteEvent", "countDownComplete==>> $countDownComplete")
            setCountData()
            showSnackbar()
        }
    }

    private fun showSnackbar() {
        val snackbar = Snackbar.make(binding.loutMain, "File Downloaded", Snackbar.LENGTH_LONG)
        snackbar.setActionTextColor(ContextCompat.getColor(this, R.color.selectDotColor))
            .setAction("View") {
                binding.viewPager.currentItem = 2
            }
        snackbar.show()
    }

    private fun setCountData() {
        binding.txtDownloadCount.text = "$countDownComplete"
        if (countDownComplete == 0)
            binding.txtDownloadCount.visibility = View.GONE
        else
            binding.txtDownloadCount.visibility = View.VISIBLE
    }

    private fun inits() {
        preferences = Preferences(this)
        currUrl = intent.getStringExtra(Constant.PUT_KEY_URL).toString()
        openType = intent.getStringExtra(Constant.EXTRA_TYPE).toString()

        binding.loutToolbar.txtTitle.text =
            when (openType) {
                Constant.TYPE_Insta -> getString(R.string.instagram)
                Constant.TYPE_FB -> getString(
                    R.string.facebook
                )

                else -> getString(R.string.web_browser)
            }

        if (openType == Constant.TYPE_FB)
            if (!preferences.isFBIntro()) {
                showHowToUseDialog()
            }


        if (openType == Constant.TYPE_Insta)
            binding.loutToolbar.ivHelp.visibility = View.VISIBLE
        else
            binding.loutToolbar.ivHelp.visibility = View.VISIBLE

        tabBrowser = TabBrowserFragment.newInstance(currUrl, openType)
        tabBrowser.setAdsLoadCall(object : AdsLoadCall {
            override fun isLoadNativeAds() {
//                loadNativeBrowserDownload()
            }
        })
        val progressFragment = DownloadProgressFragment.newInstance()
        val downloadFragment =
            DownloadFragment.newInstance(
                this,
                if (openType == Constant.TYPE_Insta) Constant.DOWNLOAD_INSTAGRAM else Constant.DOWNLOAD_FACEBOOK,
                true, true
            )

        val adapter = ViewPagerAdapter(this)
        adapter.addFragment(tabBrowser)
        adapter.addFragment(progressFragment)
        adapter.addFragment(downloadFragment)
        binding.viewPager.offscreenPageLimit = 3
        binding.viewPager.adapter = adapter

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                binding.viewPager.isUserInputEnabled = position != 0
                setUnselectIcon()
                when (position) {
                    0 -> {
                        binding.ivTab1.setImageDrawable(
                            ContextCompat.getDrawable(
                                this@BrowserDownloadActivity,
                                R.drawable.ic_tab1_select
                            )
                        )
                        setSelectTab(binding.txtTab1, binding.txtTab2, binding.txtTab3)
                    }

                    1 -> {
                        binding.ivTab2.setImageDrawable(
                            ContextCompat.getDrawable(
                                this@BrowserDownloadActivity,
                                R.drawable.ic_tab2_select
                            )
                        )
                        setSelectTab(binding.txtTab2, binding.txtTab1, binding.txtTab3)
                    }

                    2 -> {
                        binding.ivTab3.setImageDrawable(
                            ContextCompat.getDrawable(
                                this@BrowserDownloadActivity,
                                R.drawable.ic_tab3_select
                            )
                        )
                        setSelectTab(binding.txtTab3, binding.txtTab1, binding.txtTab2)
                    }
                }
                if (position == 2) {
                    countDownComplete = 0
                    setCountData()
                }
            }
        })
    }

    private fun showHowToUseDialog() {
        val dialogBinding = DialogHowToUseBinding.inflate(layoutInflater)
        val dialog = Dialog(this, R.style.Theme_Dialog_full)
        dialog.window?.requestFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setGravity(Gravity.BOTTOM)
        dialog.setCancelable(true)

        dialog.setCanceledOnTouchOutside(true)
        dialog.setContentView(dialogBinding.root)
        dialogBinding.ivClose.setOnClickListener {
            dialog.dismiss()
            preferences.putFBIntro(true)
        }
        dialogBinding.btnView.setOnClickListener {
            dialog.dismiss()
            startActivity(
                Intent(
                    this,
                    IntroFbActivity::class.java
                )
            )
        }

        dialog.show()
    }

    private fun setUnselectIcon() {
        binding.ivTab1.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_tab1_unselect
            )
        )
        binding.ivTab2.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_tab2_unselect
            )
        )
        binding.ivTab3.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_tab3_unselect
            )
        )
    }

    private fun setSelectTab(txtTab1: TextView, txtTab2: TextView, txtTab3: TextView) {
        setGradientText(txtTab1)
        removeGradientText(txtTab2)
        removeGradientText(txtTab3)
    }

    private fun removeGradientText(textView: TextView) {
        textView.paint.shader = null
        textView.invalidate()
    }

    private fun setGradientText(btnSelect: TextView) {
        val paint: TextPaint = btnSelect.paint
        val width = paint.measureText(btnSelect.text.toString())

        val textShader: Shader = LinearGradient(
            0f, 0f,
            width,
            btnSelect.textSize,
            intArrayOf(
                ContextCompat.getColor(this, R.color.gradient1),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient2),
                ContextCompat.getColor(this, R.color.gradient3),
            ), null, Shader.TileMode.CLAMP
        )

        btnSelect.paint.shader = textShader
        btnSelect.invalidate()
    }

    class ViewPagerAdapter(fragmentActivity: FragmentActivity) :
        FragmentStateAdapter(fragmentActivity) {

        private val fragments = mutableListOf<Fragment>()
//        private val fragmentTitles = mutableListOf<String>()

        override fun getItemCount(): Int {
            return fragments.size
        }

        override fun createFragment(position: Int): Fragment {
            return fragments[position]
        }

        fun addFragment(fragment: Fragment) {
            fragments.add(fragment)
//            fragmentTitles.add(title)
            notifyDataSetChanged()
        }

//        fun getPageTitle(position: Int): CharSequence {
//            return fragmentTitles[position]
//        }
    }

    @Subscribe
    fun onStartDownloadEvent(startDownloadEvent: StartDownloadEvent) {
        startNewDownload(startDownloadEvent.data)
    }

    private fun startNewDownload(data: DownloadData) {
        MyApplication.addDownloadFiles(data)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)

    }

}