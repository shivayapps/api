package com.videodownload.instantdownload.browser.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.databinding.ItemAlbumBinding

class AlbumAdapter(
    var context: Context,
    var albumList: HashMap<String, ArrayList<String>>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<AlbumAdapter.ViewHolder>() {

    var albumSelect = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemAlbumBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return albumList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val keyByIndex = albumList.keys.elementAt(position)
        val list = albumList.getValue(keyByIndex)
        if (!list.isNullOrEmpty())
            Glide.with(context)
                .load(list[0])
                .into(holder.binding.image)

        holder.binding.tvAlbumName.text = keyByIndex

        holder.binding.tvAlbumName.background = ContextCompat.getDrawable(
            context,
            if (albumSelect == position) R.drawable.ic_rect_gradient else R.drawable.bg_black_tran
        )

        holder.binding.root.setOnClickListener {
            val p = albumSelect
            albumSelect = position
            clickListener(position)
            notifyItemChanged(p)
            notifyItemChanged(albumSelect)
        }
    }

    class ViewHolder(var binding: ItemAlbumBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }
}