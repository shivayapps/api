package com.videodownload.instantdownload.browser.ui.activity.option

import android.os.Bundle
import android.util.Log
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.videodownload.instantdownload.browser.databinding.ActivityTwitterBinding
import com.videodownload.instantdownload.browser.utils.Constant
import java.net.URLConnection
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocketFactory


class TwitterActivity : AppCompatActivity() {

    lateinit var binding: ActivityTwitterBinding
    private var defaultSSLSF: SSLSocketFactory? = null
    var currUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTwitterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        currUrl = intent.getStringExtra(Constant.PUT_KEY_URL).toString()
        defaultSSLSF = HttpsURLConnection.getDefaultSSLSocketFactory()
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.webViewClient = MyBrowser(this, defaultSSLSF)
        binding.webView.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(webView: WebView, i: Int) {
//                binding.swipeRefreshLayout.isRefreshing = i != 100
            }
        }
        binding.webView.loadUrl(currUrl)
    }


    class MyBrowser(
        var activity: TwitterActivity,
        var defaultSSLSF: SSLSocketFactory?,
    ) : WebViewClient() {

        override fun shouldOverrideUrlLoading(webView: WebView, str: String?): Boolean {
            val mimeType = URLConnection.guessContentTypeFromName(str)
            if (mimeType != null && mimeType.startsWith("image")) {
                Log.e(""," MyBrowser type==>> image $str")
            }
            webView.loadUrl(str!!)
            return true
        }

        override fun onPageFinished(webView: WebView?, str: String?) {
            super.onPageFinished(webView, str)
            Log.e("", "MyBrowser onPageFinished")
//            activity.finishLoading()
        }

        override fun onLoadResource(view: WebView, url: String) {
            Log.d("fb :", "URL: $url")
            val viewUrl = view.url
            val title = view.title
//            object : VideoContentSearch(activity, url, viewUrl, title) {
            object : com.videodownload.instantdownload.browser.customView.VideoContentSearch(activity, url, viewUrl, title) {
                override fun onStartInspectingURL() {
                    Log.e("", "MyBrowser onStartInspectingURL")
//                                            Utils.Companion.disableSSLCertificateChecking()

                }

                override fun onFinishedInspectingURL(finishedAll: Boolean) {
                    Log.e("", "MyBrowser onFinishedInspectingURL")
                    HttpsURLConnection.setDefaultSSLSocketFactory(defaultSSLSF)
//                    activity.finishLoading()
                }

                override fun onVideoFound(
                    size: String?,
                    type: String?,
                    link: String?,
                    name: String?,
                    page: String?,
                    chunked: Boolean,
                    website: String?,
                    audio: Boolean
                ) {

                    Log.e(
                        "",
                        "MyBrowser sizee==>> $size type==>> $type link==>> $link name==>> $name page==>> $page "
                    )
//                    if (!link.isNullOrEmpty())
//                        activity.downloadUrl(link, Constant.TYPE_VIDEO)
                    //                        videoList.addItem(size, type, link, name, page, chunked, website, audio)
                    //                        updateFoundVideosBar()
                }
            }.start()
        }
    }

}