package com.videodownload.instantdownload.browser.browser.event

import com.videodownload.instantdownload.browser.ui.data.DownloadData

data class ProgressUpdateDownloadEvent(var data: DownloadData)