package com.videodownload.instantdownload.browser.browser.event;

import com.videodownload.instantdownload.browser.browser.helpers.InstaPostModel;
import com.videodownload.instantdownload.browser.browser.helpers.InstaPostModel;

import java.util.ArrayList;
import java.util.List;


/* loaded from: classes3.dex */
public class NeedModifyInstaHtmlEvent {
    private List<InstaPostModel> posts;

    public NeedModifyInstaHtmlEvent(List<InstaPostModel> list) {
        new ArrayList();
        this.posts = list;
    }

    public List<InstaPostModel> getPosts() {
        return this.posts;
    }

    public void setPosts(List<InstaPostModel> list) {
        this.posts = list;
    }
}
