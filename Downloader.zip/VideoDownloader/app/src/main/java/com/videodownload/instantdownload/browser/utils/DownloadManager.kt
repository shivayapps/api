package com.videodownload.instantdownload.browser.utils

import android.content.Context
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.OnScanCompletedListener
import android.os.Environment
import android.util.Log
import com.videodownload.instantdownload.browser.R
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL


class DownloadManager(var context: Context) {
    fun checkFileDownload(type: String, posterId: String, fileType: Int): Boolean {
        val startTitle = if (type == Constant.TYPE_DP_DOWNLOAD) "" else type
        val fileN =
            startTitle + posterId + if (fileType == Constant.TYPE_IMAGE) ".png" else ".mp4"
        val folderName =
            when (type) {
                Constant.TYPE_Insta, Constant.TYPE_Story -> Constant.FOLDER_INSTAGRAM
                Constant.TYPE_DP_DOWNLOAD -> Constant.FOLDER_DP_DOWNLOADER
                Constant.TYPE_FB -> Constant.FOLDER_FACEBOOK
                Constant.TYPE_TWITTER -> Constant.FOLDER_TWITTER
                else -> "All"
            }
        val folder = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                    + File.separator + context.getString(R.string.app_name)
                    + File.separator + folderName
        )
        val filename = File(
            folder,
            fileN
        )
        if (filename.exists())
            return true
        return false
    }

    fun downloadFile(
        fileUrl: String,
        type: String,
        posterId: String,
        fileType: Int,
        progressUpdateListener: (progress: Int) -> Unit
    ): String {
        var downloadFile = ""
        var input: InputStream? = null
        var output: OutputStream? = null
        var connection: HttpURLConnection? = null
        try {
            Log.e("DownloadManager", "downloadFile URL===>> $fileUrl")
            val url = URL(fileUrl)
            connection = url.openConnection() as HttpURLConnection
            connection.connect()
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
//                return ("Server returned HTTP " + connection.responseCode
//                        + " " + connection.responseMessage)
                return ""
            }


            input = connection.inputStream
            val startTitle = if (type == Constant.TYPE_DP_DOWNLOAD) "" else type
            val fileN =
                startTitle + posterId + if (fileType == Constant.TYPE_IMAGE) ".png" else ".mp4"
            val folderName =
                when (type) {
                    Constant.TYPE_Insta, Constant.TYPE_Story -> Constant.FOLDER_INSTAGRAM
                    Constant.TYPE_DP_DOWNLOAD -> Constant.FOLDER_DP_DOWNLOADER
                    Constant.TYPE_FB -> Constant.FOLDER_FACEBOOK
                    Constant.TYPE_TWITTER -> Constant.FOLDER_TWITTER
                    else -> "All"
                }
            val folder = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath
                        + File.separator + context.getString(R.string.app_name)
                        + File.separator + folderName
            )
            if (!folder.exists())
                folder.mkdirs()

            val filename = File(
                folder,
                fileN
            )

            output = FileOutputStream(filename)
            Log.e("DownloadManager", "downloadFile contentLength===>> ${connection.contentLength}")
            var contentLength: Int = connection.contentLength
            if (contentLength < 0) {
                contentLength = 4096
            }

            val fileLength = contentLength
            val data = ByteArray(contentLength)
//            val data = ByteArray(4096)

            var total: Long = 0
            var count: Int
            while (input.read(data).also { count = it } != -1) {
                total += count.toLong()
                progressUpdateListener((total * 100 / fileLength).toInt())
//                if (fileLength > 0) publishProgress((total * 100 / fileLength).toInt())
                output.write(data, 0, count)
            }

            downloadFile = filename.path
        } catch (e: Exception) {
            Log.e("", "downloadFile Exception===>> ${e.message} message==>> ${e.toString()}")
            return ""
        } finally {
            try {
                output?.close()
                input?.close()
                MediaScannerConnection.scanFile(context, arrayOf<String>(downloadFile), null,
                    OnScanCompletedListener { _, _ -> })
            } catch (ignored: IOException) {
            }
            connection?.disconnect()
        }
        return downloadFile
    }


}