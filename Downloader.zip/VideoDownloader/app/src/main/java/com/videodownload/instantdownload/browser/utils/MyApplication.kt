package com.videodownload.instantdownload.browser.utils

import android.content.Context
import androidx.multidex.MultiDexApplication
//import com.ads.module.open.AdconfigApplication
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.videodownload.instantdownload.browser.browser.event.DownloadCompleteEvent
import com.videodownload.instantdownload.browser.browser.event.ProgressUpdateDownloadEvent
import com.videodownload.instantdownload.browser.ui.data.DownloadData
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.EventBus

class MyApplication : MultiDexApplication() {

    override fun onCreate() {
        super.onCreate()
        myapplication = this
        downloadList = ArrayList()
        isOpenHomeScreen = false
        isAppIsRunning = false

        setupRemoteConfig()
//        MobileAds.initialize(this) { }
//        AudienceNetworkAds.initialize(this);
        isThemeChange = false

        context = this
    }

    private fun setupRemoteConfig() {
        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
        val configSettings = FirebaseRemoteConfigSettings.Builder().setFetchTimeoutInSeconds(2000)
            .setMinimumFetchIntervalInSeconds(0).build()
        firebaseRemoteConfig?.setConfigSettingsAsync(configSettings)
    }



    companion object {
        var isOpenAdHide = false
        var downloadList: ArrayList<DownloadData> = ArrayList()
        var downloadingStar = false
        var isAppIsRunning: Boolean = false
        lateinit var myapplication: MyApplication
        var context: Context? = null
        var firebaseRemoteConfig: FirebaseRemoteConfig? = null
        var isOpenHomeScreen = false
        var isAdsShow = false

        var isThemeChange: Boolean = false

        fun disabledOpenAds() {
//        AdconfigApplication.disabledOpenAds()
            isOpenAdHide = true
//        Log.e("hello123456789", "${isOpenAdHide} Disebled Ads")

        }

        fun addDownloadFiles(downloadData: DownloadData) {
            downloadList.add(downloadData)
            if (!downloadingStar)
                startDownload()
        }

        private fun startDownload() {
            downloadingStar = true
            val downloadManager = DownloadManager(myapplication)
            val filesList: ArrayList<String> = ArrayList()
            Observable.fromCallable {
                var i = 0
                while (i < downloadList.size) {
                    var downloadData = downloadList[i]
                    val path = downloadManager.downloadFile(
                        downloadData.url,
                        downloadData.openType,
                        downloadData.posterId,
                        downloadData.fileType,
                        progressUpdateListener = {
                            downloadData.progress = it
                            EventBus.getDefault().post(ProgressUpdateDownloadEvent(downloadData))
                        })
                    if (path.isNotEmpty()) {
                        filesList.add(path)
                        EventBus.getDefault().post(DownloadCompleteEvent(downloadData))
                    }
                    i++
                }
                return@fromCallable ""
            }.subscribeOn(Schedulers.io())
                .doOnError { throwable: Throwable? ->
                    downloadingStar = false
                }
                .subscribe { result: String? ->
                    downloadingStar = false
                    downloadList.clear()
                }
        }
    }
}