package com.videodownload.instantdownload.browser.ui.data

class DpGeneratorCategoryResponse : ArrayList<DpGeneratorCategoryList>()