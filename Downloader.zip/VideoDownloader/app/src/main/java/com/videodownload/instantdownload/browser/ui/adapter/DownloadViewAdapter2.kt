package com.videodownload.instantdownload.browser.ui.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.databinding.DeleteDialogLayoutBinding
import com.videodownload.instantdownload.browser.databinding.ItemViewDownloadBinding
import com.videodownload.instantdownload.browser.ui.activity.FileFullViewActivity
import com.videodownload.instantdownload.browser.ui.data.DataModel
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.Utils
import java.io.File

class DownloadViewAdapter2(
    val context: Context,
    val fileList: ArrayList<String>,
    val deleteListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<DownloadViewAdapter2.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemViewDownloadBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = File(fileList[position])

        holder.binding.txtDownloadName.text = file.name
        Glide.with(context)
            .load(fileList[position])
            .into(holder.binding.imageDownload)

        if (Utils.isVideoFile(fileList[position]))
            holder.binding.ivPlay.visibility = View.VISIBLE
        else
            holder.binding.ivPlay.visibility = View.GONE

        holder.binding.ivDelete.setOnClickListener {
            val builder = AlertDialog.Builder(context, R.style.CustomAlertDialog).create()
            val deleteDialogLayoutBinding: DeleteDialogLayoutBinding =
                DeleteDialogLayoutBinding.inflate(LayoutInflater.from(context))
            builder.setView(deleteDialogLayoutBinding.root)
            deleteDialogLayoutBinding.tvNo.setOnClickListener {
                builder.dismiss()
            }

            deleteDialogLayoutBinding.tvYes.setOnClickListener {
                builder.dismiss()
                deleteListener(position)

            }
            builder.show()
        }

        holder.binding.ivShare.setOnClickListener {
            Utils.fileShare(context,fileList[position])
        }

        holder.binding.loutMain.setOnClickListener {
            val statusList: ArrayList<DataModel> = ArrayList()
            for (path in fileList) {
                statusList.add(DataModel(path))
            }
            Constant.dataArrayList.clear()
            Constant.dataArrayList.addAll(statusList)
            context.startActivity(
                Intent(context, FileFullViewActivity::class.java).putExtra(
                    Constant.PUT_KEY_POSTION, position
                ).putExtra(
                    Constant.PUT_KEY_EVENT,
                    Constant.VALUE_KEY_DOWNLOAD
                )
            )
        }
    }

    override fun getItemCount(): Int {
        return fileList.size
    }

    class ViewHolder(val binding: ItemViewDownloadBinding) : RecyclerView.ViewHolder(binding.root)
}