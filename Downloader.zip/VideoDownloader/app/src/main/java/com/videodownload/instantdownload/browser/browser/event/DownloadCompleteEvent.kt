package com.videodownload.instantdownload.browser.browser.event

import com.videodownload.instantdownload.browser.ui.data.DownloadData

data class DownloadCompleteEvent(var data: DownloadData)