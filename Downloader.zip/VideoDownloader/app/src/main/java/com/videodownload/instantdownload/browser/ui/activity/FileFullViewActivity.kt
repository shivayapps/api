package com.videodownload.instantdownload.browser.ui.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.browser.event.DownloadDeleteEvent
import com.videodownload.instantdownload.browser.databinding.ActivityFileFullViewBinding
import com.videodownload.instantdownload.browser.databinding.DeleteDialogLayoutBinding
import com.videodownload.instantdownload.browser.ui.data.DataModel
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.FileUtil
import com.videodownload.instantdownload.browser.utils.Utils
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.util.concurrent.Executors

class FileFullViewActivity : BaseActivity() {
    lateinit var binding: ActivityFileFullViewBinding
    var fileList: ArrayList<DataModel> = ArrayList()
    var selectedPosition: Int = 0
    var adapter: ImageReAdapter? = null
    var intentValueEvent = ""
    var path: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFileFullViewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        viewPagerSetup()
        intiListener()
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.loutToolbar.ivShare.setOnClickListener {
            val isAbove11WP = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
            Utils.fileShare(
                this,
                fileList[selectedPosition].path,
                if (intentValueEvent == Constant.VALUE_KEY_STATUS) isAbove11WP else false
            )
        }
        binding.loutToolbar.ivDelete.setOnClickListener {
            if (intentValueEvent == Constant.VALUE_KEY_STATUS) {
                saveFiles(fileList[selectedPosition].path)
            } else {
                val builder = AlertDialog.Builder(this, R.style.CustomAlertDialog).create()
                val deleteDialogLayoutBinding: DeleteDialogLayoutBinding =
                    DeleteDialogLayoutBinding.inflate(LayoutInflater.from(this))
                builder.setView(deleteDialogLayoutBinding.root)
                deleteDialogLayoutBinding.tvNo.setOnClickListener {
                    builder.dismiss()
                }

                deleteDialogLayoutBinding.tvYes.setOnClickListener {
                    builder.dismiss()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        FileUtil.deleteWithoutManageExternalStorage(
                            fileList[selectedPosition].path,
                            this
                        )
                    } else {
                        val file1 = File(fileList[selectedPosition].path)
                        val d = file1.delete()
                        if (d) {
                            updateDelete()

                        }
                    }
                }
                builder.show()
            }
        }
    }

    private fun updateDelete() {
        EventBus.getDefault()
            .post(DownloadDeleteEvent(fileList[selectedPosition].path, 2))
        fileList.removeAt(selectedPosition)
        if (fileList.size == 0) {
            finish()
        } else {
            adapter!!.notifyDataSetChanged()

            if (selectedPosition == fileList.size)
                binding.viewPager.currentItem = fileList.size - 1
            else if (selectedPosition < fileList.size)
                binding.viewPager.currentItem = selectedPosition
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constant.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            updateDelete()
        }
    }

    private fun inits() {
        path = FileUtil.getExternalStoragePublicDirectory(
            this,
            Environment.DIRECTORY_PICTURES
        ) + File.separator + getString(R.string.app_name) + File.separator + Constant.FOLDER_WHATSAPP + "/"

        binding.loutToolbar.ivShare.visibility = View.VISIBLE
        binding.loutToolbar.ivDelete.visibility = View.VISIBLE
        intentValueEvent = intent.getStringExtra(Constant.PUT_KEY_EVENT).toString()
        if (intentValueEvent == Constant.VALUE_KEY_STATUS) {
            binding.loutToolbar.ivDelete.setImageResource(R.drawable.ic_download)
        }
        fileList.addAll(Constant.dataArrayList)
        selectedPosition = intent.getIntExtra(Constant.PUT_KEY_POSTION, 0)

    }

    private fun viewPagerSetup() {
        binding.viewPager.orientation = ViewPager2.ORIENTATION_HORIZONTAL
        binding.viewPager.offscreenPageLimit = 1
        adapter = ImageReAdapter(this, fileList)
        binding.viewPager.adapter = adapter
        binding.viewPager.setCurrentItem(selectedPosition, false)
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
                Log.e("viewpager2", "onPageScrolled $position")
                selectedPosition = position
                if ((fileList.size == 0) && (selectedPosition == 0) && (position == 0)) {
                    val intent = Intent(applicationContext, FileFullViewActivity::class.java)
                    startActivity(intent)
                } else {
                    val file = File(fileList[selectedPosition].path)
                    binding.loutToolbar.txtTitle.text = file.name
                }
            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                selectedPosition = position
                Log.e("viewpager2", "onPageSelected $position")
            }

        })
    }

    inner class ImageReAdapter(
        private val context: Context,
        private val fileMediaList: ArrayList<DataModel>,
    ) : RecyclerView.Adapter<ImageReAdapter.MyViewHolder?>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_pager_layout, parent, false)
            return MyViewHolder(view)
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
            val imageItem = fileMediaList[position]
            val file = File(imageItem.path)
            val ext = file.name.substring(file.name.lastIndexOf("."))
            when (ext) {
                ".jpg" -> holder.video_icon.visibility = View.GONE
                ".png" -> holder.video_icon.visibility = View.GONE
                ".mp4" -> holder.video_icon.visibility = View.VISIBLE
                ".webm" -> holder.video_icon.visibility = View.VISIBLE
                ".mkv" -> holder.video_icon.visibility = View.VISIBLE
            }
            holder.video_icon.setOnClickListener {
                val intent1: Intent = Intent(
                    context,
                    VideoPlayerViewActivity::class.java
                ).putExtra(Constant.PUT_KEY_POSTION, position)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent1)
            }
            Glide.with(context)
                .load(imageItem.path)
                .into(holder.imageView)
            val names = file.name
            binding.loutToolbar.txtTitle.text = names
        }

        override fun getItemCount(): Int {
            return fileMediaList.size
        }

        inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            var imageView: ImageView
            var video_icon: ImageView

            init {
                imageView = itemView.findViewById(R.id.view_Image)
                video_icon = itemView.findViewById(R.id.iv_video_icon1)
            }
        }
    }


    var mainType: String = ""
    var exp: String = ""
    private fun saveFiles(paths: String) {
        val service22 = Executors.newSingleThreadExecutor()
        service22.execute {
            runOnUiThread { }
            val file = File(paths)
            val ext = file.name.substring(file.name.lastIndexOf("."))
            if (ext == ".mp4" || ext == ".webm") {
                mainType = "video/mp4"
                exp = "mp4"
            } else {
                mainType = "image/jpeg"
                exp = "jpeg"
            }
            copyFiles(path, mainType, exp, paths)
            runOnUiThread {
                val snackbar =
                    Snackbar.make(binding.loutMain, getString(R.string.save), Snackbar.LENGTH_LONG)
                snackbar.show()
//                Toast.makeText(this, getString(R.string.save), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun copyFiles(path: String, mainType: String, exp: String, paths: String) {
        val file1 = File(path)
        if (!file1.exists()) {
            file1.mkdirs()
        }
        val ss = Uri.fromFile(File(path))
        val fileNames = "GBWhatsapp2025196" + getFileName(Uri.parse(paths))
        val uri: Uri = FileUtil.dataPathToNewUri(
            this,
            ss,
            fileNames,
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mainType),
            exp
        )
        FileUtil.copyFileData(this, Uri.parse(paths), uri)
    }

    private fun getFileName(uri: Uri): String {
        var name: String? = null
        if (uri.scheme == "content") {
            val cursor: Cursor? =
                contentResolver.query(uri, null, null, null, null)
            if (cursor != null) {
                if (cursor.moveToFirst()) name =
                    cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                cursor.close()
            }
        } else if (uri.scheme == "file") name = uri.lastPathSegment
        return name!!.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()[0]
    }
}