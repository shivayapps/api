package com.videodownload.instantdownload.browser.ui.activity.option.dpGenerator

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import com.videodownload.instantdownload.browser.R

import com.videodownload.instantdownload.browser.browser.event.DownloadDeleteEvent
import com.videodownload.instantdownload.browser.databinding.ActivitySaveImageBinding
import com.videodownload.instantdownload.browser.ui.activity.BaseActivity
import com.videodownload.instantdownload.browser.ui.adapter.SaveAdapter
import com.videodownload.instantdownload.browser.ui.data.DataModel
import com.videodownload.instantdownload.browser.ui.interfaces.CheckFolder
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.FileUtil
import com.videodownload.instantdownload.browser.utils.GetDataMethod
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.util.concurrent.Executors

class SaveImageActivity : BaseActivity(), CheckFolder {

    lateinit var binding: ActivitySaveImageBinding
    var path = " "
    var downloadStatusList: ArrayList<DataModel> = ArrayList()
    var downloadAdapter: SaveAdapter? = null
    var selectPos = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySaveImageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        binding.loutToolbar.txtTitle.text = getString(R.string.savedImage)

        path =
            FileUtil.getExternalStoragePublicDirectory(
                this,
                Environment.DIRECTORY_PICTURES
            ) + File.separator + getString(
                R.string.app_name
            ) + File.separator + Constant.FOLDER_DP_CREATE

        setDataInAdapter()
        intiListener()
    }

    private fun loadBannerAd() {
        loadBannerAds( binding.frameBanner)
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener { onBackPressed() }
    }

    private fun setDataInAdapter() {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            runOnUiThread { binding.progress.visibility = View.VISIBLE }
            downloadStatusList = GetDataMethod(this).getAllList(path)
            runOnUiThread {
                binding.progress.visibility = View.GONE
                setAdapterLayouts()
            }
        }
    }

    private fun setAdapterLayouts() {
        if (downloadStatusList.size == 0) {
            binding.tvNoData.visibility = View.VISIBLE
        } else {
            binding.tvNoData.visibility = View.GONE
            loadBannerAd()
        }
        downloadAdapter =
            SaveAdapter(downloadStatusList, this, this, this, deleteListener = {
                selectPos = it
                val deletePath = downloadStatusList[it].path
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    FileUtil.deleteWithoutManageExternalStorage(deletePath, this)
                } else {
                    val file1 = File(deletePath)
                    val d = file1.delete()
                    if (d) {
                        EventBus.getDefault()
                            .post(DownloadDeleteEvent(deletePath, 1))
                        downloadStatusList.removeAt(it)
                        downloadAdapter!!.notifyDataSetChanged()
                        if (downloadStatusList.size == 0) {
                            dataEmpty()
                        }
                    }
                }
            })
        binding.rvDownload.adapter = downloadAdapter
    }

    override fun dataEmpty() {
        binding.tvNoData.visibility = View.VISIBLE
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constant.DELETE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val deletePath = downloadStatusList[selectPos].path
            EventBus.getDefault()
                .post(DownloadDeleteEvent(deletePath, 1))
            downloadStatusList.removeAt(selectPos)
            downloadAdapter!!.notifyDataSetChanged()
            if (downloadStatusList.size == 0) {
                dataEmpty()
            }
        }
    }

}