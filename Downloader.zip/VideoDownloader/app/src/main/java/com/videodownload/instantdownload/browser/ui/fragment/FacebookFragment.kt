package com.videodownload.instantdownload.browser.ui.fragment

import android.app.Activity
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.databinding.FragmentInstagramBinding
import com.videodownload.instantdownload.browser.ui.activity.option.BrowserDownloadActivity
import com.videodownload.instantdownload.browser.ui.activity.option.LoginFbActivity
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.Preferences
import com.videodownload.instantdownload.browser.utils.Utils
import java.net.URI

class FacebookFragment() : Fragment() {

    lateinit var binding: FragmentInstagramBinding
    lateinit var preferences: Preferences
    lateinit var clipBoard: ClipboardManager
    private var isLogin = false
    var isLoginOpenFromDownload: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentInstagramBinding.inflate(layoutInflater, container, false)
        inti()
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        Handler(Looper.myLooper()!!).postDelayed({ pasteText() }, 200)

    }

    private fun inti() {
        clipBoard =
            requireActivity().getSystemService(AppCompatActivity.CLIPBOARD_SERVICE) as ClipboardManager
        preferences = Preferences(requireActivity())
        binding.loutInstLoin.visibility = View.GONE
        binding.loutTopLogin.visibility = View.GONE
        setSwitchValue()
        binding.rvStories.layoutManager =
            LinearLayoutManager(requireActivity(), RecyclerView.HORIZONTAL, false)
        binding.rvStoriesList.layoutManager =
            GridLayoutManager(requireActivity(), 3)
        intiListener()
        setLoginData()
        binding.loutLoading.visibility = View.GONE
        binding.loutDisplayDownload.visibility = View.GONE
    }


    private fun intiListener() {
        binding.btnPaste.setOnClickListener {
            pasteText()
        }
        binding.btnDownload.setOnClickListener {
//            if (!preferences.isLoginFb())
//                openLoginScreen(true)
//            else
            checkValidation()
        }

        binding.switchPrivate.setOnClickListener {
            val isLoginData: Boolean = !isLogin

            binding.switchPrivate.setImageDrawable(
                ContextCompat.getDrawable(
                    requireContext(),
                    if (isLoginData) R.drawable.ic_switch_on else R.drawable.ic_switch_off
                )
            )
            if (isLoginData) {
                openLoginScreen()
            } else {
                isLogin = false
                preferences.putLoginInstagram(false)
                setLoginData()
            }
        }
    }

    private fun checkValidation() {
        val url = binding.edtPasteUrl.text.toString()
        if (!Utils.isNetworkAvailable(requireActivity())) {
            Toast.makeText(
                requireActivity(),
                getString(R.string.internet_connection_msg),
                Toast.LENGTH_SHORT
            ).show()
            return
        } else
            if (url.contains("fb.watch") || url.contains("facebook.com")) {
                startActivity(
                    Intent(
                        requireActivity(),
                        BrowserDownloadActivity::class.java
                    ).putExtra(
                        Constant.PUT_KEY_URL, url
                    )
                        .putExtra(
                            Constant.EXTRA_TYPE, Constant.TYPE_FB
                        )
                )
            } else {
                Toast.makeText(
                    requireActivity(),
                    getString(R.string.url_instagram_validation),
                    Toast.LENGTH_SHORT
                ).show()
                return
            }
    }


    private fun setSwitchValue() {
        isLogin = preferences.isLoginFb()
        binding.switchPrivate.setImageDrawable(
            ContextCompat.getDrawable(
                requireContext(),
                if (isLogin) R.drawable.ic_switch_on else R.drawable.ic_switch_off
            )
        )
    }

    private fun openLoginScreen(isDownload: Boolean = false) {
        isLoginOpenFromDownload = isDownload
        loginLauncher.launch(Intent(requireActivity(), LoginFbActivity::class.java))
    }

    var loginLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (isLoginOpenFromDownload) {
                    isLoginOpenFromDownload = false
                    setWebCookie()
                } else
                    setLoginData()

            }
            setSwitchValue()
        }

    private fun setLoginData() {
        setWebCookie()
        if (preferences.isLoginFb()) {
            binding.loutInstaStories.visibility = View.GONE

        } else {
            binding.loutInstaStories.visibility = View.GONE
            binding.loutLoading.visibility = View.GONE
        }
    }

    private fun setWebCookie() {
        if (preferences.isLoginFb()) {
            val cookiesList = listOf(preferences.getFbCookies())
            cookiesList.forEach { item ->
                CookieManager.getInstance().setCookie("https://www.facebook.com", item)
            }
        } else {
            CookieManager.getInstance().removeAllCookie()
        }
    }

    private fun pasteText() {

        binding.edtPasteUrl.setText("")
        if (!::clipBoard.isInitialized)
            clipBoard =
                requireActivity().getSystemService(AppCompatActivity.CLIPBOARD_SERVICE) as ClipboardManager

        try {
            if (!clipBoard.hasPrimaryClip()) {
            } else if (!clipBoard.primaryClipDescription!!.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                val url = clipBoard.primaryClip!!.getItemAt(0).text.toString()
                if (url.contains("fb.watch") || url.contains("facebook.com")) {
                    binding.edtPasteUrl.setText(clipBoard.primaryClip!!.getItemAt(0).text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)
                    Log.e(
                        "",
                        "pasteText ==>> else if ==>> ${clipBoard.primaryClip!!.getItemAt(0).text.toString()}"
                    )
                }
            } else {
                val item = clipBoard.primaryClip!!.getItemAt(0)
                if (item.text.toString().contains("facebook.com") || item.text.toString()
                        .contains("fb.watch")
                ) {
                    binding.edtPasteUrl.setText(item.text.toString())
                    binding.edtPasteUrl.setSelection(binding.edtPasteUrl.text.toString().length)
                    Log.e("", "pasteText ==>> else ==>> ${item.text.toString()}")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("", "pasteText ==>> message==>> ${e.message}")
        }
    }

    private fun startLoading() {
        binding.loutDisplayDownload.visibility = View.GONE
        binding.loutLoading.visibility = View.VISIBLE
    }

    private fun finishLoading() {
        requireActivity().runOnUiThread {
            binding.loutLoading.visibility = View.GONE
        }
    }


    fun setUrlFormat(str: String?): String {
        return try {
            val uri = URI(str)
            URI(uri.scheme, uri.authority, uri.path, null, uri.fragment).toString()
        } catch (e2: Exception) {
            e2.printStackTrace()
            ""
        }
    }

    private fun fetchUrlData() {
        val url = binding.edtPasteUrl.text.toString()
//        if (url.startsWith("https://www.instagram.com/reel/")) {
        if (url.isNotEmpty()) {
//            loadUrl(url)
            val str = setUrlFormat(url) + "?__a=1&__d=dis"
            val cookie = preferences.getFbCookies()
//                "ds_user_id=" + preferences.getFbUserId() + "; sessionid=" + preferences.getFbSessionID()
            startLoading()
//            val api = ApiCallingClass()
//            api.callResultFB(requireActivity(), instaObserver, str, cookie)
        }
    }

    companion object {
        fun newInstance() =
            FacebookFragment()
    }


}