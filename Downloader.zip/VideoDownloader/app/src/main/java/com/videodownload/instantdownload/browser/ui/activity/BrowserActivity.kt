package com.videodownload.instantdownload.browser.ui.activity

import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.databinding.ActivityBrowserBinding
import com.videodownload.instantdownload.browser.utils.Constant
import java.util.Objects
import kotlin.jvm.internal.Intrinsics

class BrowserActivity : BaseActivity() {
    lateinit var binding: ActivityBrowserBinding
    var urls: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBrowserBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        intiListener()
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
    }

    private fun inits() {
        binding.loutToolbar.txtTitle.text = getString(R.string.web_browser)
        urls = intent.getStringExtra(Constant.PUT_KEY_URL).toString()
        urls = if (urls != null) {
            urls
        } else {
            "https://www.google.com/"
        }
        val webSettings: WebSettings = binding.web.settings
        webSettings.javaScriptEnabled = true
        webSettings.setJavaScriptEnabled(true)
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true)
        webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH)
        webSettings.setLoadsImagesAutomatically(true)
        webSettings.setAllowContentAccess(true)
        webSettings.setGeolocationEnabled(true)
        webSettings.setSupportMultipleWindows(false)
        webSettings.setUseWideViewPort(true)
        webSettings.setLoadWithOverviewMode(true)
        webSettings.setSaveFormData(true)
        binding.web.setLayerType(2, null)
        webSettings.setCacheMode(2)
        webSettings.setDomStorageEnabled(true)
        binding.web.setClickable(true)
        binding.web.webViewClient = MyWebViewClient(binding.progress, this)
//        if (urls.contains("facebook")) {
//            binding.web.addJavascriptInterface(
//                FacebookViewInterface(this, binding.web),
//                "facebookDataGet"
//            )
//        }
        binding.web.loadUrl(urls)
    }

    fun loadUrlInWebView(str: String?) {
        try {
            val webView = binding.web

            val pairArr = arrayOf(Pair<String, String>("Accept-Language", "en-GB,en-US"))
            val linkedHashMap: LinkedHashMap<String, String> =
                LinkedHashMap<String, String>(pairArr.size)
            linkedHashMap.putAll(pairArr)
            webView.loadUrl(str!!, linkedHashMap)
        } catch (unused: Exception) {
        }
    }

    class MyWebViewClient(
        private var progressBar: ProgressBar,
        var browserActivity: BrowserActivity
    ) : WebViewClient() {
        var TAG = "FBViewInterface Client"
        override fun onLoadResource(view: WebView?, str: String?) {
            Log.e(TAG, "onLoadResource url==>> $str")
            var str2: String = ""
            var str3: String = ""
            var str4: String = ""
            var str5: String = ""
            var str6: String = ""
            var str7: String = ""
            var str8: String = ""
            var str9: String = ""
            var str10: String = ""
            var str11: String = ""
            var str12: String = ""
            var str13: String = ""
            var str14: String = ""
            super.onLoadResource(view, str)
            val str15: String = browserActivity.urls
            val obj: Any? = null
            val valueOf: Boolean = str15.contains("facebook")
            if (valueOf || str15.contains("facebook.com")) {

                try {
                    browserActivity.loadUrlInWebView("javascript:(function() { var items=document.getElementsByClassName('_52jh _7om2 _15kk _15ks _15km _4b47 _4b46'); for (var i = 0; i < items.length; i++) { items[i].style.marginRight = '10px'; }})()");

                    val sb = StringBuilder()
                    sb.append("javascript:(function() { const ary=[];\nvar parents=document.getElementsByClassName('")
                    Objects.requireNonNull<Any>(com.videodownload.instantdownload.browser.utils.FacebookViewInterface.Companion)
                    str2 = com.videodownload.instantdownload.browser.utils.FacebookViewInterface.FACEBOOK_MULTIPLE_POSTS
                    sb.append(str2)
                    sb.append("');\nfor (var j = 0; j < parents.length; j++) {\n\tary[j]=parents[j].innerHTML\n}\nif (parents.length > 0 ) {\nfacebookDataGet.onMultiplePostLoading(ary)}})()")
                    browserActivity.loadUrlInWebView(sb.toString())


                    val sb2 = java.lang.StringBuilder()
                    sb2.append("javascript:(function() { const ary=[];\nvar parents=document.getElementsByClassName('")
                    str3 = com.videodownload.instantdownload.browser.utils.FacebookViewInterface.FACEBOOK_WATCH_POSTS
                    sb2.append(str3)
                    sb2.append("');\nfor (var j = 0; j < parents.length; j++) {\n\tary[j]=parents[j].innerHTML\n}\nif (parents.length > 0 ) {\nfacebookDataGet.onWatchPostLoading(ary)}})()")
                    browserActivity.loadUrlInWebView(sb2.toString())

                    val sb3 = java.lang.StringBuilder()
                    sb3.append("javascript:(function() { const ary=[];\nvar parents=document.getElementsByClassName('")
                    str4 = com.videodownload.instantdownload.browser.utils.FacebookViewInterface.FACEBOOK_FEED
                    sb3.append(str4)
                    sb3.append("');\nfor (var j = 0; j < parents.length; j++) {\n\tary[j]=parents[j].innerHTML\n}\nif (parents.length > 0 ) {\nfacebookDataGet.onLoading(ary)}})()")
                    browserActivity.loadUrlInWebView(sb3.toString())

                    val sb4 = java.lang.StringBuilder()
                    sb4.append("javascript:(function() { const ary=[];\nvar parents=document.getElementsByClassName('")
                    str5 = com.videodownload.instantdownload.browser.utils.FacebookViewInterface.FACEBOOK_SINGLE_POST
                    sb4.append(str5)
                    sb4.append("');\nfor (var j = 0; j < parents.length; j++) {\n\tary[j]=parents[j].innerHTML\n}\nif (parents.length > 0 ) {\nfacebookDataGet.onSinglePostLoading(ary)}})()")
                    browserActivity.loadUrlInWebView(sb4.toString())

                    val sb5 = java.lang.StringBuilder()
                    sb5.append("javascript:(function() { const ary=[];\nvar parents=document.getElementsByClassName('")
                    str6 = com.videodownload.instantdownload.browser.utils.FacebookViewInterface.FACEBOOK_LINK_POST
                    sb5.append(str6)
                    sb5.append("');\nfor (var j = 0; j < parents.length; j++) {\n\tary[j]=parents[j].innerHTML\n}\nif (parents.length > 0 ) {\nfacebookDataGet.onLinkPostLoading(ary)}})()")
                    browserActivity.loadUrlInWebView(sb5.toString())

                    val sb6 = java.lang.StringBuilder()
                    sb6.append("javascript:(function() { const ary=[];\nvar parents=document.getElementsByClassName('")
                    str7 = com.videodownload.instantdownload.browser.utils.FacebookViewInterface.FACEBOOK_COMPLEX_POST
                    sb6.append(str7)
                    sb6.append("');\nfor (var j = 0; j < parents.length; j++) {\n\tary[j]=parents[j].innerHTML\n}\nif (parents.length > 0 ) {\nfacebookDataGet.onSinglePostLoading(ary)}})()")
                    browserActivity.loadUrlInWebView(sb6.toString())

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            browserActivity.loadUrlInWebView("javascript:(function() { var items=document.getElementsByClassName('_aamz'); for (var i = 0; i < items.length; i++) { items[i].style.marginRight = '10px'; }})()")
//            val sb7 = java.lang.StringBuilder()
//            sb7.append("javascript:(function() { const ary=[];\nvar parents=document.getElementsByClassName('")
//            Objects.requireNonNull<Any>(InstaWebViewInterface.Companion)
//            str8 = InstaWebViewInterface.INSTA_ACCOUNT_POSTS
//            sb7.append(str8)
//            sb7.append("');\nfor (var j = 0; j < parents.length; j++) {\n\tary[j]=parents[j].innerHTML\n}\nif (parents.length > 0 ) {\ndataGet.onAccountPostLoading(ary)}})()")
//            browserActivity.loadUrlInWebView(sb7.toString())


        }

        override fun shouldOverrideUrlLoading(view: WebView, str: String): Boolean {
//            Log.e(TAG, "shouldOverrideUrlLoading url==>> $str")
            if (str.contains("twitter.com") && (str.contains("/status/") || str.contains("/photo/"))) {
                //  downloadFile(url);
                Log.e(TAG, "shouldOverrideUrlLoading  twitter url==>> $str")
            }

            if (str != null && startsWithdefault(str, "blob:", false, 2)) {
                return true
            }
            if (!startsWithdefault(
                    str,
                    "http://",
                    false,
                    2
                ) && (!startsWithdefault(str, "https://", false, 2) || startsWithdefault(
                    str,
                    "https://likee.onelink.me",
                    false,
                    2
                ) || startsWithdefault(
                    str,
                    "https://click.snapchat.com/",
                    false,
                    2
                ) || startsWithdefault(str, "https://go.onelink.me/", false, 2))
            ) {

            }


//            view.loadUrl(str)
//            return true
            return super.shouldOverrideUrlLoading(view, str);
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            com.videodownload.instantdownload.browser.utils.FacebookViewInterface.watchSize = 0
            com.videodownload.instantdownload.browser.utils.FacebookViewInterface.linkSize = 0
            com.videodownload.instantdownload.browser.utils.FacebookViewInterface.feedSize = 0
            com.videodownload.instantdownload.browser.utils.FacebookViewInterface.singleSize = 0
            com.videodownload.instantdownload.browser.utils.FacebookViewInterface.complexSize = 0
            super.onPageStarted(view, url, favicon)
            progressBar.visibility = View.VISIBLE
        }

        override fun onPageFinished(view: WebView, url: String) {
            super.onPageFinished(view, url)
            progressBar.visibility = View.GONE
        }

        fun startsWithdefault(str: String, str2: String, z1: Boolean, i: Int): Boolean {
            var z: Boolean = z1
            if (i and 2 != 0) {
                z = false
            }
            Intrinsics.checkNotNullParameter(str, "<this>")
            return if (!z) {
                str.startsWith(str2)
            } else regionMatches(str, 0, str2, 0, str2.length, z)
        }


        fun regionMatches(
            str: String,
            i: Int,
            other: String?,
            i2: Int,
            i3: Int,
            z: Boolean
        ): Boolean {
            Intrinsics.checkNotNullParameter(str, "<this>")
            Intrinsics.checkNotNullParameter(other, "other")
            return if (!z) {
                str.regionMatches(i, other!!, i2, i3)
            } else str.regionMatches(i, other!!, i2, i3, ignoreCase = z)
        }
    }
}