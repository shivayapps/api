package com.videodownload.instantdownload.browser.browser.event

data class DownloadDeleteEvent(var deletePath: String, var isOpenType: Int)
