package com.videodownload.instantdownload.browser.ui.data

import com.google.gson.annotations.SerializedName

data class User( val pk: Long = 0L,
                 @SerializedName("pk_id")
                 val pkId: String?,
                 val username: String,
                 @SerializedName("full_name")
                 val fullName: String,
                 @SerializedName("is_private")
                 val isPrivate: Boolean = false,
                 @SerializedName("is_verified")
                 val isVerified: Boolean,
                 @SerializedName("profile_pic_id")
                 val profilePicId: String?,
                 @SerializedName("profile_pic_url")
                 val profilePicUrl: String?,
                 @SerializedName("profile_pic_url_hd")
                 val hdProfilePicUrl: String? )
