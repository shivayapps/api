package com.videodownload.instantdownload.browser.network;

import com.google.gson.JsonObject;

import org.json.JSONObject;

import io.reactivex.Observable;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;
import retrofit2.http.Url;


public interface APIServices {
    @GET
    Call<JsonObject> callResult2(@Url String Value, @Header("Cookie") String cookie, @Header("User-Agent") String userAgent);
    @GET
    Call<JsonObject> callResult(@Url String Value, @Header("User-Agent") String userAgent);

    @GET
    Call<JsonObject> getStoriesFullDetail2(@Url String Value, @Query("reel_ids") String userId, @Header("Cookie") String cookie, @Header("User-Agent") String userAgent,
                                                            @Header("X-IG-App-ID") String apId, @Header("Accept") String accept, @Header("Accept-Language") String acceptLanguage,
                                                            @Header("X-ASBD-ID") String XASBDID, @Header("X-IG-WWW-Claim") String XIGWWWClaim, @Header("Origin") String origin,
                                                            @Header("DNT") String dnt, @Header("Connection") String conn, @Header("Referer") String referer,
                                                            @Header("Sec-Fetch-Dest") String secfecdest, @Header("Sec-Fetch-Mode") String mode,
                                                            @Header("Sec-Fetch-Site") String site, @Header("Sec-GPC") String gpc, @Header("TE") String te);
    @GET
    Call<JsonObject> getStoriesApi2(@Url String Value, @Header("Cookie") String cookie, @Header("User-Agent") String userAgent);

    @GET
    Call<JsonObject> callDpSearch(@Url String Value, @Header("Cookie") String cookie, @Header("User-Agent") String userAgent);


    @GET
    Observable<JsonObject> callResult1(@Url String Value, @Header("Cookie") String cookie, @Header("User-Agent") String userAgent);


    @GET
    Call<JSONObject> callVideo(
            @Url String Value,
            @Header("id") String cookie,
            @Header("token") String userAgent
    );
}