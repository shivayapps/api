package com.videodownload.instantdownload.browser.ui.fragment

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.databinding.DialogInstaLoginBinding

class LoginDialog(context: Context,val onLoginListener: () -> Unit) : Dialog(context, R.style.Theme_Dialog) {

    lateinit var binding: DialogInstaLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setCancelable(true)
        setCanceledOnTouchOutside(true)
        binding = DialogInstaLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            onLoginListener()
            dismiss()
        }

    }

}