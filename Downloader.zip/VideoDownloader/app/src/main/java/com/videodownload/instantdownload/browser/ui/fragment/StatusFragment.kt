package com.videodownload.instantdownload.browser.ui.fragment

import android.Manifest.permission
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.videodownload.instantdownload.browser.databinding.FragmentStatusBinding
import com.videodownload.instantdownload.browser.ui.adapter.StatusAdapter
import com.videodownload.instantdownload.browser.utils.App
import com.videodownload.instantdownload.browser.utils.Preferences
import java.io.File
import java.util.concurrent.Executors


class StatusFragment(val adsListener: (isShowAds: Boolean) -> Unit) : Fragment() {

    lateinit var binding: FragmentStatusBinding
    var permissionResult: ActivityResultLauncher<String>? = null
    var permissionLauncher: ActivityResultLauncher<Intent>? = null



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentStatusBinding.inflate(layoutInflater, container, false)
        checkPermissionForWhatsApp()
        permissionResult = registerForActivityResult<String, Boolean>(
            ActivityResultContracts.RequestPermission()
        ) { result: Boolean ->
            if (result) {
                searchForStatus(requireActivity())
            } else {
                Toast.makeText(activity, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            permissionLauncher = registerForActivityResult<Intent, ActivityResult>(
                ActivityResultContracts.StartActivityForResult()
            ) { result: ActivityResult ->
                if (result.resultCode == Activity.RESULT_OK) {
                    binding.llPermissionLayout.visibility = View.GONE
                    if (result.data != null) {
                        Preferences(requireContext()).setWhatsAppUri(result.data!!)
                        searchForStatus(requireActivity())
                    }
                }
            }
        }
        return binding.root
    }

    private fun checkPermissionForWhatsApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Preferences(requireContext()).getWhatsAppUri() == null) {
                getPermissionRandAbove()
            } else {
                searchForStatus(requireActivity())
            }
        } else if (ContextCompat.checkSelfPermission(
                requireActivity(),
                permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_DENIED
        ) {
            binding.llPermissionLayout.visibility = View.VISIBLE
            binding.tvNoData.visibility = View.GONE
            binding.tvPermissionStorage.setOnClickListener {
                if (isAppInstalled("com.whatsapp")) {
                    permissionResult!!.launch(permission.READ_EXTERNAL_STORAGE)
                } else {
                    Toast.makeText(activity, "WhatsApp App is not installed", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        } else {
            if (isAppInstalled("com.whatsapp")) {
                searchForStatus(requireActivity())
            } else {
                Toast.makeText(activity, "WhatsApp App is not installed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun getPermissionRandAbove() {
        val intent =
            (requireActivity().getSystemService(Context.STORAGE_SERVICE) as StorageManager).primaryStorageVolume.createOpenDocumentTreeIntent()
        val uri = DocumentsContract.buildDocumentUri(
            "com.android.externalstorage.documents",
            "primary:Android/media/com.whatsapp/WhatsApp/" + File.separator + "Media" + File.separator + ".Statuses"
        )
        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri)
        binding.llPermissionLayout.visibility = View.VISIBLE
        binding.tvNoData.visibility = View.GONE
        binding.tvPermissionStorage.setOnClickListener { v ->
//            if (isAppInstalled("com.whatsapp")) {
                permissionLauncher!!.launch(intent)
//            } else {
//                Toast.makeText(activity, "WhatsApp App is not installed", Toast.LENGTH_SHORT)
//                    .show()
//            }
        }
    }

    private fun isAppInstalled(packageName: String): Boolean {
        return try {
            requireActivity().packageManager.getPackageInfo(
                packageName,
                PackageManager.GET_ACTIVITIES
            )
            true
        } catch (ignored: PackageManager.NameNotFoundException) {
            false
        }
    }


    private fun searchForStatus(activity: Activity) {
        val service = Executors.newSingleThreadExecutor()
        service.execute {
            requireActivity().runOnUiThread { binding.progress.visibility = View.VISIBLE }
            val whatApp = App(activity)
            whatApp.analyze()
            requireActivity().runOnUiThread {
                binding.progress.visibility = View.GONE
                setAdapterLayouts()
            }
        }
    }

    private fun setAdapterLayouts() {
        if (App.whatsAppDataVideo.size == 0) {
            binding.tvNoData.visibility = View.VISIBLE
            adsListener(false)
        } else {
            binding.tvNoData.visibility = View.GONE
            adsListener(true)
        }
        val statusAdapter =
            StatusAdapter(App.whatsAppDataVideo, requireContext(), requireActivity())
        binding.rvStatus.adapter = statusAdapter
    }

}