package com.videodownload.instantdownload.browser.ui.data

data class BrowserTab(var tabTitle:String)
