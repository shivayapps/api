package com.videodownload.instantdownload.browser.browser.event;

public class NeedModifyVimeoHtmlEvent {
}
