package com.videodownload.instantdownload.browser.ui.interfaces

interface AdsLoadCall {
    fun isLoadNativeAds()
}