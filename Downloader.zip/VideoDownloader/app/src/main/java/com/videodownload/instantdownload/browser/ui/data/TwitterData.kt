package com.videodownload.instantdownload.browser.ui.data

data class TwitterData(val thumbURL: String, val url: String, val size: String, val type: Int)
