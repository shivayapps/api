package com.videodownload.instantdownload.browser.ui.activity

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.videodownload.instantdownload.browser.R

import com.videodownload.instantdownload.browser.databinding.ActivityTagFullBinding
import com.videodownload.instantdownload.browser.utils.AdCache
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.MyApplication
import com.videodownload.instantdownload.browser.utils.UtilsAd

class TagFullActivity : BaseActivity() {
    lateinit var binding: ActivityTagFullBinding
    var title = ""
    var tag = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTagFullBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        intiListener()
        loadBannerAd()
    }


    var isAdLoaded=false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    private fun loadBannerAd() {
        if (!isAdLoaded) {
            val adId = getString(R.string.banner_ads)
            BannerAdHelper.showBanner(this, binding.frameBanner, binding.frameBanner, adId,
                AdCache.bannerAdView, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.bannerAdView = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.llCopy.setOnClickListener {
            val clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clipData = ClipData.newPlainText("text", binding.tvTags.text.toString())
            clipboardManager.setPrimaryClip(clipData)
            Toast.makeText(this, "Text copied", Toast.LENGTH_LONG).show()
        }
        binding.llShare.setOnClickListener {
            val shareIntent = Intent()
            shareIntent.action = Intent.ACTION_SEND
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT, binding.tvTags.text.toString());
            MyApplication.disabledOpenAds()
            startActivity(Intent.createChooser(shareIntent, "send to"))
        }
    }

    private fun inits() {
        title = intent.getStringExtra(Constant.PUT_KEY_SUB_TITLE).toString()
        binding.loutToolbar.txtTitle.text = title
        tag = intent.getStringExtra(Constant.PUT_KEY_TAG_STRING).toString()
        if (tag != null) {

            when (title) {
                "Memes" -> {
                    binding.tvTags.text = getString(R.string.Memes)
                }

                "Music" -> {
                    binding.tvTags.text = getString(R.string.Music)
                }

                "Love" -> {
                    binding.tvTags.text = getString(R.string.Love)
                }

                "Logos" -> {
                    binding.tvTags.text = getString(R.string.Logos)
                }

                "Sports" -> {
                    binding.tvTags.text = getString(R.string.sports1)
                }

                "Tattoos" -> {
                    binding.tvTags.text = getString(R.string.tattoos)
                }

                "Transport" -> {
                    binding.tvTags.text = getString(R.string.transport)
                }

                "Stuff" -> {
                    binding.tvTags.text = getString(R.string.stuff)
                }

                "Buildings" -> {
                    binding.tvTags.text = getString(R.string.buildings)
                }

                "Animals" -> {
                    binding.tvTags.text = getString(R.string.animals)
                }

                "Chars" -> {
                    binding.tvTags.text = getString(R.string.chars)
                }

                else -> {
                    binding.tvTags.text = tag
                }
            }
            var counter = 0
            for (c in binding.tvTags.text.toString()) {

                if (c == '#') {

                    counter++
                }
            }
            binding.tvTagCounter.text = "$counter Tags"

        }

    }
}