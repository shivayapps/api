package com.videodownload.instantdownload.browser.browser.page_loading;

public class PageLoadedEvent {
}
