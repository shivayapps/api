package com.videodownload.instantdownload.browser.browser.event.global_download_button;

/* loaded from: classes3.dex */
public class ChangeGlobalDownloadButtonVisibilityEvent {
    private boolean visible;

    public ChangeGlobalDownloadButtonVisibilityEvent(boolean z) {
        this.visible = z;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean z) {
        this.visible = z;
    }
}
