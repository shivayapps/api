package com.videodownload.instantdownload.browser.network

import com.videodownload.instantdownload.browser.utils.AppUrl
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class RetrofitClient2 private constructor() {
    val myApi: ApiService

    init {
        val interceptor = HttpLoggingInterceptor()
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        val client: OkHttpClient = OkHttpClient.Builder()
            .readTimeout(2, TimeUnit.MINUTES)
            .connectTimeout(2, TimeUnit.MINUTES)
            .writeTimeout(2, TimeUnit.MINUTES)
            .addInterceptor(interceptor)
            .build()
        val retrofit = Retrofit.Builder().baseUrl(AppUrl().hashTagBaseURL())
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
        myApi = retrofit.create(ApiService::class.java)
    }

    companion object {
        @get:Synchronized
        var instance: RetrofitClient2? = null
            get() {
                if (field == null) {
                    field = RetrofitClient2()
                }
                return field
            }
            private set
    }


}