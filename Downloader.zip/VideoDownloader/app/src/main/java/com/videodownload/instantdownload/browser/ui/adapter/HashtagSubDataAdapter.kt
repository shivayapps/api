package com.videodownload.instantdownload.browser.ui.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.videodownload.instantdownload.browser.databinding.HashtagArrayItmeLayoutBinding
import com.videodownload.instantdownload.browser.ui.activity.TagFullActivity
import com.videodownload.instantdownload.browser.ui.data.CategoryItemItem
import com.videodownload.instantdownload.browser.utils.Constant

class HashtagSubDataAdapter(var hashtagDataList: ArrayList<CategoryItemItem>, var activity: Activity, var context: Context) : RecyclerView.Adapter<HashtagSubDataAdapter.MyViewHolder>() {
    inner class MyViewHolder(var binding: HashtagArrayItmeLayoutBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(HashtagArrayItmeLayoutBinding.inflate(LayoutInflater.from(parent.context),parent,false))
    }

    override fun getItemCount(): Int {
        return hashtagDataList.size
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        with(holder.binding){
            with(hashtagDataList[position]){
                tvSubTitle.text = subCategoryName
                holder.itemView.setOnClickListener {
                    activity.startActivity(Intent(context, TagFullActivity::class.java).putExtra(Constant.PUT_KEY_TAG_STRING,tag).putExtra(Constant.PUT_KEY_SUB_TITLE,subCategoryName))
                }
            }
        }
    }
}