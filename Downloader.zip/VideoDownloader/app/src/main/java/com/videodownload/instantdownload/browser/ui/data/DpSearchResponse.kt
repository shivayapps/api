package com.videodownload.instantdownload.browser.ui.data

data class DpSearchResponse( val users: ArrayList<UserList> = ArrayList(),val status: String)
data class UserList( val position: Long,
                     val user: User,)
