package com.videodownload.instantdownload.browser.ui.data

import java.io.Serializable

data class ImageVersions(  val candidates: List<Candidate>): Serializable
