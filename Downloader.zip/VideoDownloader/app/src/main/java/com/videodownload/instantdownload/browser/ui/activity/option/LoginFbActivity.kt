package com.videodownload.instantdownload.browser.ui.activity.option

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.webkit.CookieManager
import android.webkit.CookieSyncManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.videodownload.instantdownload.browser.databinding.ActivityLoginBinding
import com.videodownload.instantdownload.browser.ui.activity.BaseActivity
import com.videodownload.instantdownload.browser.utils.Preferences

class LoginFbActivity : BaseActivity() {

    lateinit var binding: ActivityLoginBinding
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        preferences = Preferences(this)
//        if (intent != null) {
//            var url: String? = intent.getStringExtra("url")
//            loadPage(url ?: "")
//        } else
        loadPage()
        binding.swipeRefreshLayout.setOnRefreshListener {
            loadPage()
        }
    }

    private fun loadPage(url: String = "") {
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.clearCache(true)
        val settings: WebSettings = binding.webView.settings
        settings.javaScriptEnabled = true
        settings.setUserAgentString("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36")
        binding.webView.webViewClient = MyBrowser(this, preferences)
        CookieSyncManager.createInstance(this)
        CookieManager.getInstance().removeAllCookie()
//        binding.webView.loadUrl("https://www.facebook.com")
        binding.webView.loadUrl("https://www.facebook.com/")
        binding.webView.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(webView: WebView, i: Int) {
                binding.swipeRefreshLayout.isRefreshing = i != 100
            }
        }
    }

    class MyBrowser(
        var loginActivity: LoginFbActivity,
        var preferences: Preferences,
    ) : WebViewClient() {

        override fun shouldOverrideUrlLoading(webView: WebView, str: String?): Boolean {
            webView.loadUrl(str!!)
            return true
        }

        override fun onPageFinished(webView: WebView?, str: String?) {
            super.onPageFinished(webView, str)
            Log.e("TAG", "onPageFinished onPageFinished==>>  $str")
            val cookie = CookieManager.getInstance().getCookie(str)
            try {
//                val cookie2: String? = getCookie(str, "sessionid")
//                val cookie3: String? = getCookie(str, "csrftoken")
                val cookie4: String? = getCookie(str, "c_user")
                Log.d("TAG", "onPageFinished cookies: $cookie")
                Log.d("TAG", "onPageFinished cookie4: $cookie4")
//                if (TextUtils.isEmpty(cookie4) || TextUtils.isEmpty(cookie2)) {
                if (TextUtils.isEmpty(cookie4) || TextUtils.isEmpty(cookie)) {
//                if (TextUtils.isEmpty(cookie)) {
                    return
                }
//                Log.e("", "onPageFinished sessionid==>> " + cookie2)
//                Log.e("", "onPageFinished userid==>> " + cookie4)
//                Log.e("", "onPageFinished csrftoken==>> " + cookie3)
//                preferences.putFbUserId(cookie4 ?: "")
//                preferences.putFbSessionID(cookie2 ?: "")
                preferences.putFbCookies(cookie ?: "")
//                preferences.putFbToken(cookie3 ?: "")
                preferences.putLoginFb(true)
                webView?.destroy()
                val intent = Intent()
//                intent.putExtra("userid", cookie4)
//                intent.putExtra("sessionid", cookie2)
//                intent.putExtra("csrftoken", cookie3)
                loginActivity.setResult(RESULT_OK, intent)
                loginActivity.finish()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun getCookie(str: String?, str2: String): String? {
            var split: Array<String>
            val cookie = CookieManager.getInstance().getCookie(str)
            if (cookie == null || cookie.isEmpty()) {
                return null
            }
            for (str3 in cookie.split(";".toRegex()).dropLastWhile { it.isEmpty() }
                .toTypedArray()) {
                if (str3.contains(str2)) {
                    return str3.split("=".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()[1]
                }
            }
            return null
        }

    }

}