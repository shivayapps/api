package com.videodownload.instantdownload.browser.ui.activity

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.exoplayer2.ExoPlaybackException
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.source.ConcatenatingMediaSource
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Log
import com.google.android.exoplayer2.util.Util
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.ui.data.DataModel
import com.videodownload.instantdownload.browser.utils.Constant
import java.io.File

class VideoPlayerViewActivity : BaseActivity(), View.OnClickListener {
    var playerView: PlayerView? = null
    var player: SimpleExoPlayer? = null
    var title: TextView? = null
    var videoBack: ImageView? = null
    var lock: ImageView? = null
    var unlock: ImageView? = null
    var scaling: ImageView? = null
    var root: RelativeLayout? = null
    var concatenatingMediaSource: ConcatenatingMediaSource? = null
    var nextButton: ImageView? = null
    var previousButton: ImageView? = null
    var progressBar: ProgressBar? = null
    var imgDisplay: ImageView? = null
    private var controlsMode: ControlsMode? = null

    enum class ControlsMode {
        LOCK, FULLSCREEN
    }

    var mediadata = ArrayList<DataModel>()
    var position = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setFullScreen()
        setContentView(R.layout.activity_video_player_view)
        inits()
    }

    private fun inits() {
        val list = ArrayList<DataModel>()
        list.addAll(Constant.dataArrayList)
        val pos = intent.getIntExtra(Constant.PUT_KEY_POSTION, 0)
        val videoList = list.filter {
            it.path.endsWith(".mp4") || it.path.endsWith(".webm") || it.path.endsWith(".mkv")
        }
        if (videoList.isEmpty())
            finish()

//        videoList.filterIndexed { index, dataModel ->  }

        position = videoList.indexOfFirst { it == list[pos] }
        mediadata.addAll(videoList)

        playerView = findViewById(R.id.exoplayer_view)
        nextButton = findViewById(R.id.exo_next)
        previousButton = findViewById(R.id.exo_prev)
        title = findViewById(R.id.video_title)
        videoBack = findViewById(R.id.video_back)
        lock = findViewById(R.id.lock)
        unlock = findViewById(R.id.unlock)
        scaling = findViewById(R.id.scaling)
        root = findViewById(R.id.root_layout)
        progressBar = findViewById(R.id.progressBar)
        imgDisplay = findViewById(R.id.imgDisplay)
        title!!.text = File(mediadata[position].path).name
        nextButton!!.setOnClickListener(this)
        previousButton!!.setOnClickListener(this)
        videoBack!!.setOnClickListener(this)
        lock!!.setOnClickListener(this)
        unlock!!.setOnClickListener(this)
        scaling!!.setOnClickListener(this)
        if (position == 0) {
            previousButton!!.setImageResource(R.drawable.ic_audio_perv1)
        }
        playVideo()
    }

    private fun playVideo() {
        val path = mediadata[position].path
//        imgDisplay?.let {
//            Glide.with(this)
//                .load(path)
//                .into(it)
//            it.visibility = View.VISIBLE
//        }
        val uri = Uri.parse(path)
        player = SimpleExoPlayer.Builder(this).build()
        val defaultDataSourceFactory =
            DefaultDataSourceFactory(this, Util.getUserAgent(this, "app"))
        concatenatingMediaSource = ConcatenatingMediaSource()
        for (i in mediadata.indices) {
            Log.e("", "mediadata ${mediadata[i].toString()}")
//            File(mediadata[i].toString())
            val mediaSource: MediaSource =
                ProgressiveMediaSource.Factory(defaultDataSourceFactory).createMediaSource(
                    Uri.parse(uri.toString())
                )
            concatenatingMediaSource!!.addMediaSource(mediaSource)
        }

//        val mediaSource: MediaSource =
//            ProgressiveMediaSource.Factory(defaultDataSourceFactory).createMediaSource(
//                Uri.parse(uri.toString())
//            )
//        concatenatingMediaSource!!.addMediaSource(mediaSource)
        playerView!!.player = player
//        playerView!!.keepScreenOn = true
        player!!.prepare(concatenatingMediaSource!!)
        playError()
        Log.e("VideoVIEW", "start the video")
        player!!.playWhenReady = true
//        player!!.seekTo(0)
//        player!!.playWhenReady = false
//        player!!.playWhenReady = true
//        player!!.seekTo(0, 100)
//        player!!.seekTo(0, C.TIME_UNSET)
//        player!!.seekTo(position, C.TIME_UNSET)

//        player!!.addListener(object : Player.Listener {
//
//        })
    }

    private fun playError() {
        player!!.addListener(object : Player.EventListener {
            override fun onPlayerError(error: ExoPlaybackException) {
                Log.e("VideoVIEW", "onPlayerError ${error.toString()}")
                onBackPressed()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                super.onPlayWhenReadyChanged(playWhenReady, reason)
                Log.e("VideoVIEW", "onPlayWhenReadyChanged ")
            }

            override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
                Log.e("VideoVIEW", "onPlayerStateChanged $playWhenReady")
                if (playbackState == Player.STATE_BUFFERING) {
                    progressBar!!.visibility = View.VISIBLE
                    imgDisplay!!.visibility = View.VISIBLE

                } else if (playbackState == Player.STATE_READY || playbackState == Player.STATE_ENDED) {

                    progressBar!!.visibility = View.INVISIBLE
                    imgDisplay!!.visibility = View.INVISIBLE
                }
            }

            override fun onIsLoadingChanged(isLoading: Boolean) {
                super.onIsLoadingChanged(isLoading)
                Log.e("VideoVIEW", "onIsLoadingChanged $isLoading")

            }

            override fun onLoadingChanged(isLoading: Boolean) {
                super.onLoadingChanged(isLoading)
                Log.e("VideoVIEW", "onLoadingChanged $isLoading")

            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                super.onMediaItemTransition(mediaItem, reason)
                Log.e("VideoVIEW", "onMediaItemTransition $reason ")
            }
        })
//        player!!.playWhenReady = true
    }

    override fun onBackPressed() {
        if (player!!.isPlaying) {
            player!!.stop()
        }
        super.onBackPressed()
    }

    private fun setFullScreen() {
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
    }

    var isPause = false

    override fun onPause() {
        super.onPause()
        isPause = true
        player!!.playWhenReady = false
        player!!.playbackState
    }


    override fun onResume() {
        super.onResume()
        if (isPause) {
            isPause = false
            player!!.playWhenReady = true
            player!!.playbackState
        }
    }

    override fun onRestart() {
        super.onRestart()
        player!!.playWhenReady = true
        player!!.playbackState
    }

    fun screenOrientation() {
        try {
            val retriever = MediaMetadataRetriever()
            val path = mediadata[position].path
            val uri = Uri.parse(path)
            retriever.setDataSource(this, uri)
            val bitmap: Bitmap? = retriever.frameAtTime
            val videoWidth = bitmap!!.width
            val videoHight = bitmap.height
            requestedOrientation = if (videoWidth > videoHight) {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        } catch (e: Exception) {
        }
    }

    var isBack = false
    var isDelete = false
    var force_stop = false
    override fun onClick(v: View) {
        when (v.id) {

            R.id.video_back -> {
                if (player!!.isPlaying) {
                    player!!.stop()
                }
                if (player != null) {
                    player!!.release()
                }

                onBackPressed()
            }

            R.id.lock -> {
                controlsMode = ControlsMode.FULLSCREEN
                root!!.visibility = View.VISIBLE
                lock!!.visibility = View.INVISIBLE
                Toast.makeText(this, getString(R.string.unlock), Toast.LENGTH_SHORT).show()
            }

            R.id.unlock -> {
                controlsMode = ControlsMode.LOCK
                root!!.visibility = View.INVISIBLE
                lock!!.visibility = View.VISIBLE
                Toast.makeText(this, getString(R.string.locked), Toast.LENGTH_SHORT).show()
            }

            R.id.root_layout -> {}
            R.id.exo_next -> try {
                previousButton!!.setImageResource(R.drawable.ic_audio_perv)
                player!!.stop()
                position++
                playVideo()
                title!!.text = File(mediadata[position].path).name
            } catch (e: Exception) {
                Toast.makeText(this, getString(R.string.no_next_video), Toast.LENGTH_SHORT).show()
                finish()
            }

            R.id.exo_prev -> try {

                if (position > 0) {
                    player!!.stop()
                    if (position == 1) {
                        previousButton!!.setImageResource(R.drawable.ic_audio_perv1)
                    }
                    position--
                    playVideo()
                    title!!.text = File(mediadata[position].path).name
                } else {
                    previousButton!!.setImageResource(R.drawable.ic_audio_perv1)
                    previousButton!!.isEnabled = false
                }

            } catch (e: Exception) {
                Toast.makeText(this, getString(R.string.no_prv_video), Toast.LENGTH_SHORT).show()
                finish()
            }

            R.id.scaling -> if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }
    }


}