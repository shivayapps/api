package com.videodownload.instantdownload.browser.ui.data

import java.nio.file.Path

data class ImageData(var path: Path)
