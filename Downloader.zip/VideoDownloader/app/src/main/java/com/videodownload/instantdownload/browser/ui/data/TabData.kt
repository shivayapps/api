package com.videodownload.instantdownload.browser.ui.data

data class TabData(var title: String,var type: String)
