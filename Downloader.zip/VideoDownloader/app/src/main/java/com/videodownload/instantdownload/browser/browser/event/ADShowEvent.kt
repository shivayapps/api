package com.videodownload.instantdownload.browser.browser.event


data class ADShowEvent(var isShowADs: Boolean)