package com.videodownload.instantdownload.browser.ui.activity

import android.os.Bundle
import com.videodownload.instantdownload.browser.R

import com.videodownload.instantdownload.browser.databinding.ActivityHashtagBinding
import com.videodownload.instantdownload.browser.ui.adapter.HashtagDataAdapter
import com.videodownload.instantdownload.browser.ui.data.HashtagData

class HashtagActivity : BaseActivity() {
    lateinit var binding: ActivityHashtagBinding
    var hashtagList: ArrayList<HashtagData> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHashtagBinding.inflate(layoutInflater)
        setContentView(binding.root)
        inits()
        intiListener()
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
    }

    private fun loadBannerAd() {
        loadBannerAds( binding.frameBanner)
    }
    private fun inits() {
        binding.loutToolbar.txtTitle.text = getString(R.string.hashtag)
        getData()
        setDataInAdapter()
        loadBannerAd()
    }

    private fun setDataInAdapter() {
        binding.rvHashtag.adapter = HashtagDataAdapter(hashtagList, this, this)
    }

    private fun getData() {
        hashtagList.add(
            HashtagData(
                getString(R.string.popular),
                R.drawable.ic_popular,
                R.color.popular_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.holidays),
                R.drawable.ic_holidays,
                R.color.instagram_holiday_love_bg
            )
        )
        hashtagList.add(HashtagData(getString(R.string.kids), R.drawable.ic_kids, R.color.kids_bg))
        hashtagList.add(
            HashtagData(
                getString(R.string.peoples),
                R.drawable.ic_peoples,
                R.color.peoples_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.nature),
                R.drawable.ic_nature,
                R.color.nature_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.weather),
                R.drawable.ic_weather,
                R.color.weather_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.fashion),
                R.drawable.ic_fashion,
                R.color.fashion_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.photography),
                R.drawable.ic_photography,
                R.color.photography_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.Architecture),
                R.drawable.ic_architecture,
                R.color.architecture_bg
            )
        )
        hashtagList.add(HashtagData(getString(R.string.food), R.drawable.ic_food, R.color.food_bg))
        hashtagList.add(
            HashtagData(
                getString(R.string.family),
                R.drawable.ic_family,
                R.color.family_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.fitness),
                R.drawable.ic_fitness,
                R.color.fitness_festival_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.Entertainment),
                R.drawable.ic_entertainment,
                R.color.entertainment_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.like_comment),
                R.drawable.ic_like_comment,
                R.color.like_comment_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.travel),
                R.drawable.ic_travel,
                R.color.travel_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.Text_Art),
                R.drawable.ic_text_art,
                R.color.text_art_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.festival),
                R.drawable.ic_festival,
                R.color.fitness_festival_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.sports),
                R.drawable.ic_sports,
                R.color.sports_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.instagram),
                R.drawable.ic_instagram_hasteg,
                R.color.IMDB_instagram_s_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.surprise),
                R.drawable.ic_surprise,
                R.color.surprise_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.happy),
                R.drawable.ic_happy,
                R.color.happy_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.love),
                R.drawable.ic_love,
                R.color.instagram_holiday_love_bg
            )
        )
        hashtagList.add(HashtagData(getString(R.string.sad), R.drawable.ic_sad, R.color.sad_bg))
        hashtagList.add(
            HashtagData(
                getString(R.string.angry),
                R.drawable.ic_angry,
                R.color.angry_bg
            )
        )
        hashtagList.add(
            HashtagData(
                getString(R.string.Routine_Words),
                R.drawable.ic_routine_words,
                R.color.routine_words_bg
            )
        )
    }
}