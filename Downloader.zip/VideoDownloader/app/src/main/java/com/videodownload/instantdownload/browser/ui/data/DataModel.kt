package com.videodownload.instantdownload.browser.ui.data

data class DataModel(var path: String = null ?: "", val date: Long = 0L)
