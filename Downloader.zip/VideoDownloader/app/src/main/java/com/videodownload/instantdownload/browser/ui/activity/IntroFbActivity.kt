package com.videodownload.instantdownload.browser.ui.activity

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.databinding.ActivityIntroBinding
import com.videodownload.instantdownload.browser.ui.adapter.IntroAdapter
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.Preferences

class IntroFbActivity : AppCompatActivity() {

    lateinit var binding: ActivityIntroBinding
    var introList: ArrayList<Drawable?> = ArrayList()
    var selectedPos = 0
    var adapter2: IntroAdapter? = null
    var isOpenFromBrowser = false
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        preferences = Preferences(this)
        binding.dotsIndicator.selectedDotColor = ContextCompat.getColor(this, R.color.blue_color)
        binding.btnNext.background = ContextCompat.getDrawable(this, R.drawable.ic_round_blue)

        binding.loutToolbar.txtTitle.text = getString(R.string.how_to_use)
        intiListener()
        getIntroList()
        adapter2 = IntroAdapter(this, introList)
        binding.viewpager.adapter = adapter2
        binding.dotsIndicator.setViewPager2(binding.viewpager)

    }

    private fun getIntroList() {
        introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_fb_1))
        introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_fb_2))
        introList.add(ContextCompat.getDrawable(this, R.drawable.ic_inro_fb_3))
    }

    private fun intiListener() {
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.btnNext.setOnClickListener {
            if (selectedPos < introList.size - 1) {
                selectedPos++
                binding.viewpager.currentItem = selectedPos
            } else {
                preferences.putFBIntro(true)
                finish()
            }
        }

        binding.viewpager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
                Log.e("viewpager2", "onPageScrolled $position")
                selectedPos = position
                binding.btnNext.setImageDrawable(
                    ContextCompat.getDrawable(
                        this@IntroFbActivity,
                        if (selectedPos == introList.size - 1) R.drawable.ic_done else R.drawable.ic_right
                    )
                )

            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                selectedPos = position
            }

        })
    }
}