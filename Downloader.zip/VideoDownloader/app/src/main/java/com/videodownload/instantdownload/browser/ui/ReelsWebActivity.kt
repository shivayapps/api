package com.videodownload.instantdownload.browser.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.google.gson.Gson
import com.videodownload.instantdownload.browser.R
import com.videodownload.instantdownload.browser.databinding.ActivityReelsWebBinding
import com.videodownload.instantdownload.browser.ui.data.DownloadData
import com.videodownload.instantdownload.browser.ui.data.InstagramModel
import com.videodownload.instantdownload.browser.ui.interfaces.APIResponse
import com.videodownload.instantdownload.browser.utils.Constant
import com.videodownload.instantdownload.browser.utils.DownloadManager

class ReelsWebActivity : AppCompatActivity() {
    lateinit var binding: ActivityReelsWebBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReelsWebBinding.inflate(layoutInflater)
        setContentView(binding.root)
        intView()
    }

    private fun intView() {
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.webViewClient = object : WebViewClient() {


            override fun shouldOverrideUrlLoading(webView: WebView, url: String?): Boolean {
                webView.loadUrl(url!!)
                Log.e("ReelsWeb", "shouldOverrideUrlLoading url==>> $url")
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                Log.e("ReelsWeb", "onPageFinished url==>> $url")
                if (url!!.contains("instagram.com/reels")) {
//                    Log.e("ReelsWeb","onPageFinished called reels")
//                    val jsCode = """
//                    javascript:(function() {
//                        var videoElement = document.querySelector('.video-element-selector');
//                        if (videoElement) {
//                            var videoURL = videoElement.getAttribute('src');
//                            AndroidInterface.onVideoURLExtracted(videoURL);
//                        }
//                    })();
//                """.trimIndent()
////                    binding.webView.loadUrl(jsCode)
                }
            }
        }
        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                val url = binding.webView.url
                Log.e("ReelsWeb ", "MyWebViewClient onProgressChanged $newProgress url==>> $url")
                if (url!!.contains("instagram.com/reels")) {
                    if (newProgress >= 100) {
                        Log.e("ReelsWeb", "Progress >= 100")
                    }
                }
            }
        }
//        binding.webView.addJavascriptInterface(JavaScriptInterface(), "AndroidInterface")
//        binding.webView.loadUrl("https://www.instagram.com/reels/CvCzi0PAGtQ/")
        binding.webView.loadUrl("https://www.instagram.com/accounts/login/")
    }


    inner class JavaScriptInterface {
        @android.webkit.JavascriptInterface
        fun onVideoURLExtracted(videoURL: String) {
            Log.e("ReelsWeb", "videoURL==>>> $videoURL")
        }
    }
}