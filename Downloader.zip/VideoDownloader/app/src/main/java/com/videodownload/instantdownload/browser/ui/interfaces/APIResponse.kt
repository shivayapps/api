package com.videodownload.instantdownload.browser.ui.interfaces

interface APIResponse {
    fun onResponse(response: Any)
    fun onFailure(error: String= "")
    fun onLoginRequired()
}