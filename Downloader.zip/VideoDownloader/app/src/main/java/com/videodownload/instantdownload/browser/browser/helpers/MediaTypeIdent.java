package com.videodownload.instantdownload.browser.browser.helpers;

public enum MediaTypeIdent {
    VIDEO,
    AUDIO,
    IMAGE
}
