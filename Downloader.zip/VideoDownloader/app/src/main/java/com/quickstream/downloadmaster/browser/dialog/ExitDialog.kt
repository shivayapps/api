package com.quickstream.downloadmaster.browser.dialog

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.DialogExitBinding
import com.quickstream.downloadmaster.browser.databinding.DialogRateBinding
import com.quickstream.downloadmaster.browser.utils.Preferences
import java.lang.ref.WeakReference

class ExitDialog(
    var activity: Activity,
    val onClickListener: (isFinish: Boolean) -> Unit
) : Dialog(activity) {

    lateinit var bindingDialog: DialogExitBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogExitBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        AdsConfig.isSystemDialogOpen = true
        intView()

    }

    private fun intView() {
        intListener()
    }

    private fun intListener() {

        bindingDialog.tvNo.setOnClickListener {
            dismiss()
            onClickListener.invoke(false)
        }
        bindingDialog.tvYes.setOnClickListener {
            dismiss()
            onClickListener.invoke(true)
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}