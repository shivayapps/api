package com.quickstream.downloadmaster.browser.ui.adapter

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.LinearGradient
import android.graphics.Shader
import android.text.TextPaint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.ItemDpGeneratorCategoryBinding
import com.quickstream.downloadmaster.browser.ui.data.DpGeneratorCategoryList


class DpGeneratorCategoryAdapter(
    var context: Context,
    var categoryList: ArrayList<DpGeneratorCategoryList>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<DpGeneratorCategoryAdapter.ViewHolder>() {
    var tabSelect = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemDpGeneratorCategoryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.txtItem.text = categoryList[position].name

        Glide.with(context)
//            .load(categoryList[position].image_url)
            .load(categoryList[position].icon)
            .placeholder(categoryList[position].icon)
            .error(categoryList[position].icon)
            .into(holder.binding.icon)

        if (tabSelect == position) {
            holder.binding.btnBg.background =
                ContextCompat.getDrawable(context, R.drawable.btn_gradient)
            holder.binding.icon.setColorFilter(ContextCompat.getColor(context, R.color.whiteColor))
            setGradientText(holder.binding.txtItem)
        } else {
            holder.binding.btnBg.background =
                ContextCompat.getDrawable(context, R.drawable.ic_category_unselect)
            holder.binding.icon.setColorFilter(ContextCompat.getColor(context, R.color.tab_icon))
            removeGradientText(holder.binding.txtItem)
        }

        holder.binding.root.setOnClickListener {
            val pre = tabSelect
            tabSelect = position
            clickListener(position)
            notifyItemChanged(tabSelect)
            if (pre != -1)
                notifyItemChanged(pre)
        }
    }

    class ViewHolder(var binding: ItemDpGeneratorCategoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    private fun removeGradientText(textView: TextView) {
        textView.paint.shader = null
        textView.invalidate()
    }

    private fun setGradientText(btnSelect: TextView) {
        val paint: TextPaint = btnSelect.paint
        val width = paint.measureText(btnSelect.text.toString())

//        val bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.btn_button_big)
//        val shader: Shader = BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)

        val textShader: Shader = LinearGradient(
            0f, 0f,
            width,
            btnSelect.textSize,
            intArrayOf(
                ContextCompat.getColor(context, R.color.gradient1),
                ContextCompat.getColor(context, R.color.gradient2),
                ContextCompat.getColor(context, R.color.gradient2),
                ContextCompat.getColor(context, R.color.gradient2),
                ContextCompat.getColor(context, R.color.gradient3),
            ), null, Shader.TileMode.CLAMP
        )

        btnSelect.paint.shader = textShader
        btnSelect.invalidate()
    }
}