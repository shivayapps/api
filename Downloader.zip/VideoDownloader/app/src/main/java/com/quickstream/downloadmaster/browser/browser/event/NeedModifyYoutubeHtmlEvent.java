package com.quickstream.downloadmaster.browser.browser.event;


import com.quickstream.downloadmaster.browser.browser.helpers.DownloadYTVideoButtonModel;

import java.util.ArrayList;
import java.util.List;


public class NeedModifyYoutubeHtmlEvent {
    private DownloadYTVideoButtonModel currentVideoButtonModel;
    private List<DownloadYTVideoButtonModel> downloadShortsButtons;
    private List<DownloadYTVideoButtonModel> downloadVideoButtons;
    private String oldHtmlBodyOfPage;
    private String updatedHtmlBodyOfPage;

    public NeedModifyYoutubeHtmlEvent(String str, String str2, DownloadYTVideoButtonModel downloadYTVideoButtonModel, List<DownloadYTVideoButtonModel> list, List<DownloadYTVideoButtonModel> list2) {
        this.oldHtmlBodyOfPage = "";
        this.updatedHtmlBodyOfPage = "";
        this.downloadVideoButtons = new ArrayList();
        new ArrayList();
        this.oldHtmlBodyOfPage = str;
        this.updatedHtmlBodyOfPage = str2;
        this.currentVideoButtonModel = downloadYTVideoButtonModel;
        this.downloadVideoButtons = list;
        this.downloadShortsButtons = list2;
    }

    public String getUpdatedHtmlBodyOfPage() {
        return this.updatedHtmlBodyOfPage;
    }

    public void setUpdatedHtmlBodyOfPage(String str) {
        this.updatedHtmlBodyOfPage = str;
    }

    public List<DownloadYTVideoButtonModel> getDownloadVideoButtons() {
        return this.downloadVideoButtons;
    }

    public void setDownloadVideoButtons(List<DownloadYTVideoButtonModel> list) {
        this.downloadVideoButtons = list;
    }

    public String getOldHtmlBodyOfPage() {
        return this.oldHtmlBodyOfPage;
    }

    public void setOldHtmlBodyOfPage(String str) {
        this.oldHtmlBodyOfPage = str;
    }

    public List<DownloadYTVideoButtonModel> getDownloadShortsButtons() {
        return this.downloadShortsButtons;
    }

    public void setDownloadShortsButtons(List<DownloadYTVideoButtonModel> list) {
        this.downloadShortsButtons = list;
    }

    public DownloadYTVideoButtonModel getCurrentVideoButtonModel() {
        return this.currentVideoButtonModel;
    }

    public void setCurrentVideoButtonModel(DownloadYTVideoButtonModel downloadYTVideoButtonModel) {
        this.currentVideoButtonModel = downloadYTVideoButtonModel;
    }
}
