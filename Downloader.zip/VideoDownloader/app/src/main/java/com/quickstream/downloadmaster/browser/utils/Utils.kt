package com.quickstream.downloadmaster.browser.utils

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.util.Log
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import com.adconfig.AdsConfig
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.quickstream.downloadmaster.browser.R
import java.io.File
import java.lang.ref.WeakReference
import java.net.URLConnection


object Utils {
    fun isNetworkAvailable(activity: Context): Boolean {
        val connectivityManager =
            activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }

    fun isVideoFile(path: String): Boolean {
        val mimeType = URLConnection.guessContentTypeFromName(path)
        return mimeType != null && mimeType.startsWith("video")
    }

    fun storiesFullDetailHeader0(header: String): String {
        val data = "\"Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.131 Mobile Safari/537.36\""
        return data
    }

    fun convertFileSize(sizeInBytes: Long): String? {
        val units = arrayOf("B", "KB", "MB", "GB")
        var size = sizeInBytes.toDouble()
        var index = 0
        while (size > 1024 && index < units.size - 1) {
            size /= 1024.0
            index++
        }
        return String.format("%.2f %s", size, units[index])
    }

    fun getCacheSize(context: Context): Long {
        try {
            val cacheDir = context.applicationContext.cacheDir
            return getDirSize(cacheDir)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return 0
    }

    private fun getDirSize(dir: File): Long {
        var size: Long = 0
        val files = dir.listFiles()
        if (files != null) {
            for (file in files) {
                size += if (file.isDirectory) {
                    getDirSize(file)
                } else {
                    file.length()
                }
            }
        }
        return size
    }

    private fun getMimeType(fileUri: String): String? {
        val extension = MimeTypeMap.getFileExtensionFromUrl(fileUri)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
    }

    fun fileShare(context: Context, path: String, isAbove11WP: Boolean = false) {
        val share = Intent(Intent.ACTION_SEND)
        share.type = getMimeType(path)
        share.putExtra(
            Intent.EXTRA_TEXT,
            "Download App From here : https://play.google.com/store/apps/details?id=" + context.packageName
        )
        val uri = if (isAbove11WP) Uri.parse(path) else FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            File(path)
        )
        share.putExtra(Intent.EXTRA_STREAM, uri)
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        share.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        MyApplication.disabledOpenAds()
        context.startActivity(Intent.createChooser(share, "Share Image!"))
    }


    fun showInAppRateDialog(activity: Activity) {

        AdsConfig.isSystemDialogOpen = true
        Log.e("RatingDialog", "showInAppRateDialog")
        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialog.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialog.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo
    ) {
        AdsConfig.isSystemDialogOpen = true
        Log.e("RatingDialog", "showInAppRateDialogInternal")
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialogInternal.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    launchAppStore(activity)
                    Log.e("RatingDialog", "showInAppRateDialogInternal.RateUsState.IGNORED")
//                    storeRateResult(fragmentActivity, RateUsState.IGNORED)
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialogInternal.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun launchAppStore(activity: Activity) {

        AdsConfig.isSystemDialogOpen = true
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
        )
        activity.startActivity(intent)
    }

    fun launchFeedBackEmail(activity: Activity) {

        val i = Intent(Intent.ACTION_SEND)
        i.type = "message/rfc822"
        i.putExtra(Intent.EXTRA_EMAIL, arrayOf("shivayapps@outlook.com"))
        i.putExtra(
            Intent.EXTRA_SUBJECT,
            "${activity.getString(R.string.app_name)} ${activity.getString(R.string.feedback)}"
        )
        i.putExtra(Intent.EXTRA_TEXT, "")
        i.setPackage("com.google.android.gm")

        try {
            AdsConfig.isSystemDialogOpen = true
            activity.startActivity(Intent.createChooser(i, activity.getString(R.string.Send_mail)))
        } catch (ex: ActivityNotFoundException) {
            Toast.makeText(activity, activity.getString(R.string.not_installed), Toast.LENGTH_SHORT).show()
        }
    }

}