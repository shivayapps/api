package com.quickstream.downloadmaster.browser.browser.event;

public class NeedModifyPinterestHtmlEvent {
}
