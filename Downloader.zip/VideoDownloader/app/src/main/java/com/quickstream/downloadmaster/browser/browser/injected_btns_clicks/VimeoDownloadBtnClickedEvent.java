package com.quickstream.downloadmaster.browser.browser.injected_btns_clicks;

public class VimeoDownloadBtnClickedEvent {
    String pageUrl;

    public VimeoDownloadBtnClickedEvent(String str) {
        this.pageUrl = str;
    }

    public String getPageUrl() {
        return this.pageUrl;
    }

    public void setPageUrl(String str) {
        this.pageUrl = str;
    }
}
