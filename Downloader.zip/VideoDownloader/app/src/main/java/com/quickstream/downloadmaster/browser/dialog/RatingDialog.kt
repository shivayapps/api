package com.quickstream.downloadmaster.browser.dialog

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.quickstream.downloadmaster.browser.R
import com.quickstream.downloadmaster.browser.databinding.DialogRateBinding
import com.quickstream.downloadmaster.browser.utils.Preferences
import com.quickstream.downloadmaster.browser.utils.Utils
import java.lang.ref.WeakReference

class RatingDialog(
    var activity: Activity,
    val onClickListener: (isFinish: Boolean) -> Unit
) : Dialog(activity) {

    lateinit var bindingDialog: DialogRateBinding
    var rate: Float = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        bindingDialog = DialogRateBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        AdsConfig.isSystemDialogOpen = true
        intView()

    }

    private fun intView() {
        bindingDialog.simpleRatingBar.setOnRatingChangeListener { ratingBar, rating, fromUser ->
            rate = rating
//            when (rating) {
//                0f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_five)
//                }
//
//                1f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_fair))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_one)
//                }
//
//                2f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_fair))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_two)
//                }
//
//                3f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_three)
//                }
//
//                4f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_four)
//                }
//
//                5f -> {
//                    bindingDialog.txtTitle.setText(activity.getString(R.string.rate_title_good))
//                    bindingDialog.ivTop.setImageResource(R.drawable.rate_five)
//                }
//            }
        }

        intListener()

    }


    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
            onClickListener.invoke(false)
        }
        bindingDialog.btnSubmit.setOnClickListener {
            if (rate >= 4) {
                Preferences(activity).putRate(true)
                Utils.showInAppRateDialog(activity)
            } else if (rate >= 1) {
                Utils.launchFeedBackEmail(activity)
                dismiss()
            } else {
                Toast.makeText(activity, "Please rate us. Your opinion is important to us.", Toast.LENGTH_SHORT).show()
                dismiss()
            }
            onClickListener.invoke(true)
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}