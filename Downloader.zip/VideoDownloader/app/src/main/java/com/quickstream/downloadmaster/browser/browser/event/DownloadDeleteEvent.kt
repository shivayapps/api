package com.quickstream.downloadmaster.browser.browser.event

data class DownloadDeleteEvent(var deletePath: String, var isOpenType: Int)
