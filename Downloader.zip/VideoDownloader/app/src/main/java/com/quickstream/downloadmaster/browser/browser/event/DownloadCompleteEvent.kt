package com.quickstream.downloadmaster.browser.browser.event

import com.quickstream.downloadmaster.browser.ui.data.DownloadData

data class DownloadCompleteEvent(var data: DownloadData)