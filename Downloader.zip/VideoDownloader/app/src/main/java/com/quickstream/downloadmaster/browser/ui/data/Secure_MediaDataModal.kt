package com.quickstream.downloadmaster.browser.ui.data

class Secure_MediaDataModal {
    var id = 0
    var path: String? = null
    var paths1: String? = null
    var id_contact: String? = null
    var isSelected = false
    var name: String? = null
    var number: String? = null

    constructor(path: String?) {
        this.path = path
    }

    constructor(name: String?, number: String?) {
        this.name = name
        this.number = number
    }

    constructor() {}
    constructor(id: Int, name: String?, number: String?) {
        this.id = id
        this.name = name
        this.number = number
    }

    fun setId_contact1(id_contact: String?) {
        this.id_contact = id_contact
    }
}