package com.quickstream.downloadmaster.browser.browser.injected_btns_clicks;

public class FBDownloadBtnClickedEvent {
    int btnInPostIndex;
    int postIndex;

    public FBDownloadBtnClickedEvent(int i, int i2) {
        this.postIndex = i;
        this.btnInPostIndex = i2;
    }

    public int getPostIndex() {
        return this.postIndex;
    }

    public void setPostIndex(int i) {
        this.postIndex = i;
    }

    public int getBtnInPostIndex() {
        return this.btnInPostIndex;
    }

    public void setBtnInPostIndex(int i) {
        this.btnInPostIndex = i;
    }
}
