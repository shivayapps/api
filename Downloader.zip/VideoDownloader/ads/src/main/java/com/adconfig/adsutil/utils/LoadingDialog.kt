package com.adconfig.adsutil.utils

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import com.adconfig.databinding.ProgressLoadingBinding

class LoadingDialog(private var ctx: Context, private var message: String) : Dialog(ctx) {

    private lateinit var binding: ProgressLoadingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ProgressLoadingBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        setCancelable(false)
        setCanceledOnTouchOutside(false)

        binding.messageLabel.text = message

    }

    fun setProgress(progress: Int) {
        binding.pbProgress.setProgress(progress)
    }
}