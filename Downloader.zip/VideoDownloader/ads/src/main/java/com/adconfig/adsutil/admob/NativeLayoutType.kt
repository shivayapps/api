package com.adconfig.adsutil.admob


enum class NativeLayoutType {
    NativeList,
    NativeBanner,
    NativeMedium,
    NativeButtonBottom,
    NativeBig,
}