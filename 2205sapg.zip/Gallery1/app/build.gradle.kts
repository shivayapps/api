import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

plugins {
    alias(libs.plugins.android)
    alias(libs.plugins.kotlinAndroid)
    alias(libs.plugins.ksp)
    alias(libs.plugins.kotlinSerialization)
    alias(libs.plugins.parcelize)
    alias(libs.plugins.google.service)
    alias(libs.plugins.crashlytics)
}

fun getTimeStamp(): String {
    val format = SimpleDateFormat("'D'ddMM'T'HHmm", Locale.ENGLISH)
    return format.format(Date())
}

android {
    namespace = "com.photogallery"
    compileSdk = 35

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("app/com.smart.ai.photo.gallery.app.jks")
            storePassword = "com.smart.ai.photo.gallery.app"
            keyAlias = "com.smart.ai.photo.gallery.app"
            keyPassword = "com.smart.ai.photo.gallery.app"
        }
    }

    defaultConfig {
        applicationId = "com.smart.ai.photo.gallery.app"

        minSdk = 30
        targetSdk = 35

        versionCode = 24
        versionName = "2.0.4"

        vectorDrawables.useSupportLibrary = true
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
        setProperty("archivesBaseName", "Gallery-$versionName")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
    }

    bundle {
        language {
            enableSplit = false
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            isShrinkResources = false

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }

        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    flavorDimensions("default")
    productFlavors {

        create("TestAd") {
            isDefault = true

            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")

            resValue("string", "native_language", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "common_native1", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "common_native2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "common_native3", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "common_banner1", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "common_banner2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "common_banner3", "ca-app-pub-3940256099942544/9214589741")

            resValue("string", "inter_language", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "inter_all", "ca-app-pub-3940256099942544/1033173712")

            resValue("string", "open_splash", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "open_all", "ca-app-pub-3940256099942544/9257395921")

        }
        create("LiveAd") {

            resValue("string", "ads_application_id", "ca-app-pub-8220543496759402~7817357717")

            resValue("string", "native_language", "ca-app-pub-8220543496759402/3589618882")

            resValue("string", "common_native1", "ca-app-pub-8220543496759402/4960888101")
            resValue("string", "common_native2", "ca-app-pub-8220543496759402/4842588166")
            resValue("string", "common_native3", "ca-app-pub-8220543496759402/1196668800")
            resValue("string", "common_banner1", "ca-app-pub-8220543496759402/8650373872")  //b_homeActivity
            resValue("string", "common_banner2", "ca-app-pub-8220543496759402/2037013429")  //b_albumActivity
            resValue("string", "common_banner3", "ca-app-pub-8220543496759402/6466213607")  //b_exploreAlbumActivity

            resValue("string", "inter_language", "ca-app-pub-8220543496759402/2053175930")
            resValue("string", "inter_all", "ca-app-pub-8220543496759402/3366257601")

            resValue("string", "open_splash", "ca-app-pub-8220543496759402/3238265092")
            resValue("string", "open_all", "ca-app-pub-8220543496759402/6657785298")

        }
    }
    sourceSets {
        getByName("main").java.srcDirs("src/main/kotlin")
    }

    compileOptions {
        val currentJavaVersionFromLibs = JavaVersion.valueOf("VERSION_17")
        sourceCompatibility = currentJavaVersionFromLibs
        targetCompatibility = currentJavaVersionFromLibs
    }

    tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
        kotlinOptions.jvmTarget = "17"
        kotlinOptions.freeCompilerArgs = listOf(
            "-opt-in=kotlin.RequiresOptIn",
            "-opt-in=com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi",
            "-Xcontext-receivers"
        )
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources {
            excludes += "META-INF/library_release.kotlin_module"
        }
    }
}

dependencies {

    implementation(libs.multidex)
    implementation(libs.android.image.cropper)
    implementation(libs.exif)
    implementation(libs.android.gif.drawable)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.sanselan)
//    implementation(libs.imagefilters)
    implementation(libs.androidsvg.aar)
    implementation(libs.gestureviews)
    implementation(libs.android.splashscreen)
    implementation("androidx.work:work-runtime-ktx:2.9.0")

//    implementation(libs.subsamplingscaleimageview)
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.awebp)
    implementation(libs.apng)
    implementation(libs.okio)
    implementation(libs.picasso) {
        exclude(group = "com.squareup.okhttp3", module = "okhttp")
    }
    implementation(libs.androidx.browser)
    implementation(libs.androidx.window)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    compileOnly(libs.okhttp)

    implementation(libs.zjupure.webpdecoder)
    implementation(libs.parkdatetimepicker)
    implementation(libs.flexbox)

    implementation(libs.bundles.room)
    ksp(libs.androidx.room.compiler)

    implementation(libs.android.sdp)
    implementation(libs.android.ssp)
    implementation(libs.eventbus)
    implementation(libs.dexter)

    implementation("androidx.navigation:navigation-fragment-ktx:2.7.7")
    implementation("androidx.navigation:navigation-ui-ktx:2.7.7")
    implementation("androidx.webkit:webkit:1.11.0")

    implementation(libs.mail)
    implementation(libs.mail.activation)
    implementation(libs.services.maps)
    implementation(libs.services.location)

    implementation("androidx.startup:startup-runtime:1.1.1")

    val billing_version = "7.0.0"
    implementation("com.android.billingclient:billing:$billing_version")
    implementation("com.android.billingclient:billing-ktx:$billing_version")

    //Firebase Auth
//    implementation("com.google.firebase:firebase-auth:22.3.1")
//    implementation("com.google.android.gms:play-services-auth:21.0.0")
    implementation("com.google.android.gms:play-services-ads:23.0.0")
//    implementation("com.google.ads.mediation:facebook:6.17.0.0")
//    implementation("com.google.ads.mediation:applovin:12.4.2.0")

    implementation(libs.review.ktx)
    implementation(libs.app.update)

//    implementation(libs.gpuimage.plus)
//    implementation("org.wysaid:gpuimage-plus:3.0.0-min")
//    implementation("org.wysaid:gpuimage-plus:3.1.2-16k-min")

//    implementation(libs.listenablefuture)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.analytics)
//    implementation(libs.firebase.auth)
    implementation(libs.firebase.perf)
    implementation(libs.firebase.messaging)
    implementation(libs.firebase.config)
    implementation(libs.firebase.crashlytics)

    //from common >>>>
    implementation(libs.kotlinx.serialization.json)
    api(libs.kotlin.immutable.collections)

    implementation(libs.androidx.documentfile)
    implementation(libs.androidx.exifinterface)
    implementation(libs.androidx.biometric.ktx)
    implementation(libs.ez.vcard)

    implementation(libs.bundles.lifecycle)
//    implementation(libs.bundles.compose)
//    implementation(libs.compose.view.binding)
//    debugImplementation(libs.bundles.compose.preview)
//    api(libs.recyclerView.fastScroller)

    api(libs.joda.time)
    api(libs.reprint)
    api(libs.patternLockView)

//    api(libs.themeChanger)
    api(libs.androidx.core.ktx)
    api(libs.androidx.appcompat)
    api(libs.material)
    api(libs.gson)

    implementation(libs.glide.compose)
    api(libs.glide)
    ksp(libs.glide.ksp)
//    ksp(libs.glide.compiler)

    implementation(libs.blurview)
    implementation(libs.lottie)

    implementation(libs.image.labeling)
    implementation("com.itextpdf:itextpdf:5.5.13")
    implementation(project(":ads"))
    implementation(project(":call_after"))
//    implementation(project(":android-pdf-viewer"))

}