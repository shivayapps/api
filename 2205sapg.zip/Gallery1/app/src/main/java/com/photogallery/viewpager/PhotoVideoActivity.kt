package com.photogallery.viewpager

import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipDescription
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.WorkerThread
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.util.UnstableApi
import androidx.viewpager.widget.ViewPager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobBanner
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.AdmobNative
//import com.autotest.photo.editor.activities.PolishEditorActivity
//import com.autotest.photo.editor.polish.PolishPickerView
import com.photogallery.R
import com.photogallery.activities.AlbumSelectorActivity
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityPhotoVideoBinding
import com.photogallery.databinding.PopMenuImageBinding

import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.DetailsDialog
import com.photogallery.dialog.FileRenameDialog
import com.photogallery.dialog.SetWallpaperDialog

import com.photogallery.extension.actionBarHeight
import com.photogallery.extension.beGone
import com.photogallery.extension.beGoneIf
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.deleteEmptyFolders
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.extension.getParentPath
import com.photogallery.extension.getResolution
import com.photogallery.extension.hideSystemUI
import com.photogallery.extension.isGif
import com.photogallery.extension.isVideoFast
import com.photogallery.extension.makeStatusBarTransparent
import com.photogallery.extension.navigationBarHeight
import com.photogallery.extension.onGlobalLayout
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.setStatusBarFontColor
import com.photogallery.extension.showSystemUI
import com.photogallery.extension.statusBarHeight
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.AdUtils
import com.photogallery.utils.Constant
import com.photogallery.utils.Constant.ROTATE_BY_DEVICE_ROTATION
import com.photogallery.utils.Constant.ROTATE_BY_SYSTEM_SETTING
import com.photogallery.utils.Preferences
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.Utils
import com.photogallery.utils.WindowHelper
import com.photogallery.utils.isPiePlus
import com.photogallery.utils.sendEvent
//import com.photogallery.utils.transformation.DepthSlide
//import com.photogallery.utils.transformation.FlipHorizontal
//import com.photogallery.utils.transformation.FlipVertical
//import com.photogallery.utils.transformation.ForegroundToBackground
//import com.photogallery.utils.transformation.Gate
//import com.photogallery.utils.transformation.RotateDown
//import com.photogallery.utils.transformation.RotateUp
//import com.photogallery.utils.transformation.Toss
//import com.photogallery.utils.transformation.ZoomIn
//import com.photogallery.utils.transformation.ZoomOut
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.min

@UnstableApi
class PhotoVideoActivity : AppCompatActivity(), ViewPager.OnPageChangeListener,
    ViewPagerFragment.FragmentListener {

    var displayImageList: ArrayList<MediaData> = ArrayList()

    var selectedPosition = 0
    var isFromPrivate = false
    var isFromRecentlyDelete = false
    val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
    val formatTime = SimpleDateFormat("hh:mm aa", Locale.ENGLISH)

    //    private var mSlideshowHandler = Handler()
//    var mSlideshowInterval = 3000
//    private var mRandomSlideshowStopped = false
//    private var mSlideshowMoveBackwards = false
    private var mIsOrientationLocked = false

    //    private var mIsSlideshowActive = false
    var isFileExists: Boolean = false
    var currentFilePath: String = ""

    //    private var mAreSlideShowMediaVisible = false
    lateinit var preferences: Preferences
    var mIsVideo = false
    var isLensInstalled = false

    lateinit var pagerAdapter: MyPagerAdapter
    lateinit var binding: ActivityPhotoVideoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityPhotoVideoBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        loadPriorityAds()
        makeStatusBarTransparent()
        updateStatusBarColor(Color.parseColor("#282828"))
        window?.decorView?.post {
            setStatusBarFontColor(false)
        }
        if (preferences.maxBrightness) {
            val attributes = window.attributes
            attributes.screenBrightness = 1f
            window.attributes = attributes
        }

        setupOrientation()
        initWindowInsetsController()

//        if (savedInstanceState != null) {
        isFromRecentlyDelete = intent.getBooleanExtra(Constant.EXTRA_IS_OPEN_RECENTLY_DELETE, false)
        isFromPrivate = intent.getBooleanExtra("isFromPrivate", false)
//        }
        intView()

//        hideSystemUI()
    }

    override fun onDestroy() {
        super.onDestroy()
//        Constant.displayImageList.clear()
    }

    private fun loadPriorityAds() {
        if (preferences.bannerPriority == "native") {
            AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobNative().showNativeAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadAdmobBanner()
                } else binding.frameAd.beGone()
            }
        } else if (preferences.bannerPriority == "banner") {
            AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobBanner().showBannerAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadNativeBanner()
                } else binding.frameAd.beGone()
            }
        } else {
            binding.frameAd.beGone()
        }
    }

    private fun loadNativeBanner() {
        AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobNative().showNativeAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun loadAdmobBanner() {
        AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobBanner().showBannerAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun intView() {
        try {
            selectedPosition = Constant.selectedPosition
            displayImageList.addAll(Constant.displayImageList)

            setBottomVisible()

            binding.btnFavorite.visibility =
                if (isFromRecentlyDelete || isFromPrivate) View.GONE else View.VISIBLE
            binding.btnHide.beGoneIf(isFromPrivate)
            binding.ivShare.beGoneIf(isFromPrivate)
            binding.btnMore.beGoneIf(isFromPrivate)
            binding.ivEdit.beGoneIf(isFromPrivate)
            binding.btnUnhide.beVisibleIf(isFromPrivate)

            mPath = displayImageList[selectedPosition].filePath

            initContinue()
            viewPagerSetup()
            intListener()
            checkNotchSupport()
            initActionsLayout()
        } catch (e: Exception) {
            finish()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        resources.getDimension(R.dimen.bottom_actions_height)
//        if (preferences.bottomActions) {
//            bottom += resources.getDimension(R.dimen.bottom_actions_height).toInt()
//        }

//        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE && activity?.hasNavBar() == true) {
//        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//            bottom = 0f
////            binding.llNav.layoutParams.height = navigationBarHeight
//            binding.llNav.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt()
////            binding.frameAd.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt()
//        } else {
////            binding.llNav.layoutParams.height = navigationBarHeight
//            binding.llNav.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
////            binding.frameAd.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
//        }

//        (binding.llBottomOption.layoutParams as RelativeLayout.LayoutParams).apply {
//            bottomMargin = bottom.roundToInt()
////            rightMargin = right
//        }
    }

    private fun initActionsLayout() {
        binding.llNav.layoutParams.height = navigationBarHeight
        binding.loutToolbar.layoutParams.height = statusBarHeight + actionBarHeight
//        binding.loutBottomMainOption.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
//        binding.frameBanner.layoutParams.height = resources.getDimension(R.dimen.bottom_actions_height).toInt() + navigationBarHeight
//        if (preferences.bottomActions) {
        binding.llBottomOption.beVisible()
//        } else {
//            binding.bottomActions.root.beGone()
//        }

        fragmentClicked()
    }

    private fun initContinue() {
        setTitles(selectedPosition)

        binding.viewPager.onGlobalLayout {
            if (!isDestroyed) {
                if (displayImageList.isNotEmpty()) {
                    gotMedia(
                        displayImageList as ArrayList<MediaData>,
                        refetchViewPagerPosition = true
                    )
//                    checkSlideshowOnEnter()
                }
            }
        }

        // show the selected image asap, while loading the rest in the background to allow swiping between them. Might be needed at third party intents
//        if (displayImageList.isEmpty() && mPath.isNotEmpty() && mDirectory != FAVORITES) {
        if (displayImageList.isEmpty() && mPath.isNotEmpty()) {
            val filename = mPath.getFilenameFromPath()
            val folder = mPath.getParentPath()
//            val type = getTypeFromPath(mPath)
//            val medium = Medium(null, filename, mPath, folder, 0, 0, 0, type, 0, false, 0L, 0L)
            val medium = MediaData(
                filePath = mPath,
                fileUri = Utils.getUriFromPath(this@PhotoVideoActivity, mPath).toString(),
                fileName = filename, folderName = folder,
                date = 0,
                dateTaken = 0,
                fileSize = 0,
                isVideo = mPath.isVideoFast(),
                videoDuration = 0,
                bucketPath = "",
                isSelected = false,
                isCheckboxVisible = false,
                isFavorite = false,
                isPrivate = false,
                restorePath = "",
                idDataBase = 0L
            )
            displayImageList.add(medium)
            gotMedia(displayImageList as ArrayList<MediaData>, refetchViewPagerPosition = true)
        }

        refreshViewPager(true)
        binding.viewPager.offscreenPageLimit = 2


        if (preferences.maxBrightness) {
            val attributes = window.attributes
            attributes.screenBrightness = 1f
            window.attributes = attributes
        }

//        if (preferences.hideSystemUI) {
//            binding.viewPager.onGlobalLayout {
//                Handler(Looper.getMainLooper()).postDelayed({
//                    fragmentClicked()
//                }, 500)
//            }
//        }

    }

    private var mPrevHashcode = 0

    private var mFavoritePaths = ArrayList<String>()
    private var mIgnoredPaths = ArrayList<String>()

//    private fun getTypeFromPath(path: String): Int {
//        return when {
//            path.isVideoFast() -> TYPE_VIDEOS
//            path.isGif() -> TYPE_GIFS
//            path.isSvg() -> TYPE_SVGS
//            path.isRawFast() -> TYPE_RAWS
//            path.isPortrait() -> TYPE_PORTRAITS
//            else -> TYPE_IMAGES
//        }
//    }

    private fun isDirEmpty(media: ArrayList<MediaData>): Boolean {
        return if (media.isEmpty()) {
            deleteDirectoryIfEmpty()
            finish()
            true
        } else {
            false
        }
    }

    private fun deleteDirectoryIfEmpty() {
        if (preferences.deleteEmptyFolders) {
            val fileDirItem = File(mDirectory)
            if (fileDirItem.isDirectory) {
                fileDirItem.deleteEmptyFolders(this)
            }
        }
    }


    private fun refreshViewPager(refetchPosition: Boolean = false) {
//        val isRandomSorting = config.getFolderSorting(mDirectory) and SORT_BY_RANDOM != 0
//        if (!isRandomSorting) {
//            GetMediaAsynctask(applicationContext, mDirectory, isPickImage = false, isPickVideo = false, showAll = mShowAll) {
//                gotMedia(it, refetchViewPagerPosition = refetchPosition)
//            }.execute()
//        }
    }

    private fun gotMedia(
        thumbnailItems: ArrayList<MediaData>,
        ignorePlayingVideos: Boolean = false,
        refetchViewPagerPosition: Boolean = false
    ) {
        val media = thumbnailItems.asSequence().filter {
            it is MediaData && !mIgnoredPaths.contains(it.filePath)
        }.map { it as MediaData }.toMutableList() as ArrayList<MediaData>

        if (isDirEmpty(media) || media.hashCode() == mPrevHashcode) {
            return
        }

        val isPlaying = (getCurrentFragment() as? PagerVideoFragment)?.mIsPlaying == true
        if (!ignorePlayingVideos && isPlaying) {
            return
        }

        refreshUI(media, refetchViewPagerPosition)
    }

    private fun refreshUI(media: ArrayList<MediaData>, refetchViewPagerPosition: Boolean) {
        mPrevHashcode = media.hashCode()
        displayImageList = media

        if (refetchViewPagerPosition || mPos == -1) {
            mPos = getPositionInList(media)
            if (mPos == -1) {
                min(mPos, media.lastIndex)
            }
        }

//        updateActionbarTitle()
        updatePagerItems(displayImageList.toMutableList())

        refreshMenuItems()
        checkOrientation()
//        initBottomActions()
    }

    private fun setBottomVisible() {
        binding.btnFavorite.visibility =
            if (isFromRecentlyDelete || isFromPrivate) View.GONE else View.VISIBLE
        binding.loutBottomMainOption.visibility =
            if (isFromRecentlyDelete) View.GONE else View.VISIBLE
        binding.loutReCentDeleteOption.visibility =
            if (isFromRecentlyDelete) View.VISIBLE else View.GONE
    }

//    private fun startSlideShow() {
//
//        binding.loutToolbar.setVisibility(View.GONE)
//        binding.llBottomOption.visibility = View.GONE
//        binding.loutReCentDeleteOption.visibility = View.GONE
//
//        if (!isDestroyed) {
//            val effect = preferences.getInt(Constant.PREF_SLIDE_EFFECT)
////            if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) == SLIDESHOW_ANIMATION_FADE) {
//
//            if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) != SLIDESHOW_ANIMATION_NONE) {
////                setSlideAnimation(Constant.AnimationTypes.entries[effect])
//                setSlideAnimation(effect)
////                binding.viewPager.setPageTransformer(false, FadePageTransformer())
//            }
//            enterImmersiveMode()
//            mRandomSlideshowStopped = false
//            mSlideshowInterval = preferences.getInt(Constant.PREF_SLIDE_TIME, 1)
//            mSlideshowMoveBackwards = preferences.getBoolean(Constant.PREF_SLIDE_BACKWARD)
//            mIsSlideshowActive = true
//            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
//            scheduleSwipe()
//        }
//
//    }

    //    fun setSlideAnimation(animationType: Constant.AnimationTypes){
//    fun setSlideAnimation(animationType: Int) {
//
//        when (animationType) {
//            Constant.AnimationTypes.NONE.id -> {
////                binding.viewPager!!.setPageTransformer(true, ZoomIn())
////                binding.viewPager!!.setPageTransformer(true, ZoomIn())
//            }
//
//            Constant.AnimationTypes.ZOOM_IN.id -> {
//                binding.viewPager!!.setPageTransformer(true, ZoomIn())
//            }
//
//            Constant.AnimationTypes.ZOOM_OUT.id -> {
//                binding.viewPager!!.setPageTransformer(true, ZoomOut())
//            }
//
//            Constant.AnimationTypes.DEPTH_SLIDE.id -> {
//                binding.viewPager!!.setPageTransformer(true, DepthSlide())
//            }
//
//            Constant.AnimationTypes.CUBE_IN.id -> {
//                binding.viewPager!!.setPageTransformer(true, CubeIn())
//            }
//
//            Constant.AnimationTypes.CUBE_OUT.id -> {
//                binding.viewPager!!.setPageTransformer(true, CubeOut())
//            }
//
//            Constant.AnimationTypes.FLIP_HORIZONTAL.id -> {
//                binding.viewPager!!.setPageTransformer(true, FlipHorizontal())
//            }
//
//            Constant.AnimationTypes.FLIP_VERTICAL.id -> {
//                binding.viewPager!!.setPageTransformer(true, FlipVertical())
//            }
//
//            Constant.AnimationTypes.ROTATE_UP.id -> {
//                binding.viewPager!!.setPageTransformer(true, RotateUp())
//            }
//
//            Constant.AnimationTypes.ROTATE_DOWN.id -> {
//                binding.viewPager!!.setPageTransformer(true, RotateDown())
//            }
//
//            Constant.AnimationTypes.FOREGROUND_TO_BACKGROUND.id -> {
//                binding.viewPager!!.setPageTransformer(true, ForegroundToBackground())
//            }
//
//            Constant.AnimationTypes.BACKGROUND_TO_FOREGROUND.id -> {
//                binding.viewPager!!.setPageTransformer(true, BackgroundToForeground())
//            }
//
//            Constant.AnimationTypes.TOSS.id -> {
//                binding.viewPager!!.setPageTransformer(true, Toss())
//            }
//
//            Constant.AnimationTypes.GATE.id -> {
//                binding.viewPager!!.setPageTransformer(true, Gate())
//            }
//
//            else -> {
////                binding.viewPager!!.setPageTransformer(true, FidgetSpinner())
//            }
//        }
//    }

    private fun getCurrentMedium(): MediaData? {
        return if (displayImageList.isEmpty() || mPos == -1) {
            null
        } else {
            displayImageList[min(mPos, displayImageList.lastIndex)]
        }
    }

//    private fun scheduleSwipe() {
//        mSlideshowHandler.removeCallbacksAndMessages(null)
//        Log.d("PhotoVideoActivity", "scheduleSwipe : $mIsSlideshowActive $mSlideshowInterval")
//        if (mIsSlideshowActive) {
//            if (getCurrentMedium()!!.filePath.isImageFast() || getCurrentMedium()!!.filePath.isGif() || getCurrentMedium()!!.filePath.isPortrait()) {
//                mSlideshowHandler.postDelayed({
//                    if (mIsSlideshowActive && !isDestroyed) {
//                        swipeToNextMedium()
//                    }
//                }, mSlideshowInterval * 1000L)
//            } else {
//                (getCurrentFragment() as? PagerVideoFragment)!!.playVideo()
//            }
//        }
//    }

    private fun getCurrentFragment() =
        (binding.viewPager.adapter as? MyPagerAdapter)?.getCurrentFragment(binding.viewPager.currentItem)

//    private fun goToNextMedium(forward: Boolean) {
//        Log.d("PhotoVideoActivity", "goToNextMedium : $forward")
//        val oldPosition = binding.viewPager.currentItem
//        val newPosition = if (forward) oldPosition + 1 else oldPosition - 1
//        if (newPosition == -1 || newPosition > binding.viewPager.adapter!!.count - 1) {
//            slideshowEnded(forward)
//        } else {
//            binding.viewPager.setCurrentItem(newPosition, false)
//        }
//    }

//    private fun slideshowEnded(forward: Boolean) {
//        if (preferences.getBoolean(Constant.PREF_SLIDE_LOOP)) {
//            if (forward) {
//                binding.viewPager.setCurrentItem(0, false)
//            } else {
//                binding.viewPager.setCurrentItem(binding.viewPager.adapter!!.count - 1, false)
//            }
//        } else {
//            stopSlideshow()
//            toast(R.string.slideshow_ended)
//        }
//    }

//    private fun stopSlideshow() {
//        if (mIsSlideshowActive) {
//            binding.viewPager.setPageTransformer(false, DefaultPageTransformer())
////            binding.viewPager.setPageTransformer(null)
//            mIsSlideshowActive = false
//            exitImmersiveMode()
//            mSlideshowHandler.removeCallbacksAndMessages(null)
//            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
//            mAreSlideShowMediaVisible = false
//
//            if (preferences.getBoolean(Constant.PREF_SLIDE_RANDOM_ORDER)) {
//                mRandomSlideshowStopped = true
//            }
//        }
//    }

//    private fun swipeToNextMedium() {
//        if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) == SLIDESHOW_ANIMATION_NONE) {
//            goToNextMedium(!mSlideshowMoveBackwards)
//        } else {
//            animatePagerTransition(!mSlideshowMoveBackwards)
//        }
//    }

    private var mPath = ""
    private var mDirectory = ""

    //    private var mIsFullScreen = false
    private var mIsFullScreen = true
    private var mPos = -1
//    private var mSlideshowMedia = mutableListOf<MediaData>()
//    private fun getMediaForSlideshow(): Boolean {
//        mSlideshowMedia = displayImageList.filter {
//            it.filePath.isImageFast() || it.filePath.isPortrait() || (preferences.getBoolean(
//                Constant.PREF_SLIDE_INCLUDE_VIDEO
//            ) && it.filePath.isVideoFast() || (preferences.getBoolean(Constant.PREF_SLIDE_INCLUDE_GIF) && it.filePath.isGif()))
//        }.toMutableList()
//
//        if (preferences.getBoolean(Constant.PREF_SLIDE_RANDOM_ORDER)) {
//            mSlideshowMedia.shuffle()
//            mPos = 0
//        } else {
//            mPath = getCurrentPath()
//            mPos = getPositionInList(mSlideshowMedia)
//        }
//
//        return if (mSlideshowMedia.isEmpty()) {
//            toast(R.string.no_media_for_slideshow)
//            false
//        } else {
//            updatePagerItems(mSlideshowMedia)
//            mAreSlideShowMediaVisible = true
//            true
//        }
//    }


    private fun getCurrentPath() = getCurrentMedium()?.filePath ?: ""

    private fun getPositionInList(items: MutableList<MediaData>): Int {
        mPos = 0
        for ((i, medium) in items.withIndex()) {
//            val portraitPath = getPortraitPath()
//            val portraitPath = ""
//            if (portraitPath != "") {
//                val portraitPaths = File(portraitPath).parentFile?.list()
//                if (portraitPaths != null) {
//                    for (path in portraitPaths) {
//                        if (medium.fileName == path) {
//                            return i
//                        }
//                    }
//                }
//            } else
            if (medium.filePath.equals(mPath, true)) {
                return i
            }
        }
        return mPos
    }

//    private fun getPortraitPath() = intent.getStringExtra("PORTRAIT_PATH") ?: ""

    private fun updatePagerItems(media: MutableList<MediaData>) {
        pagerAdapter = MyPagerAdapter(this, supportFragmentManager, media)

        if (!isDestroyed) {
            pagerAdapter.shouldInitFragment = mPos < 5
            binding.viewPager.apply {
                // must remove the listener before changing adapter, otherwise it might cause `mPos` to be set to 0
                removeOnPageChangeListener(this@PhotoVideoActivity)
                adapter = pagerAdapter
                pagerAdapter.shouldInitFragment = true
                addOnPageChangeListener(this@PhotoVideoActivity)
                currentItem = mPos
            }
        }
    }

    override fun onBackPressed() {

        if (preferences.isNeedInterAd) {

            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                finish()
            }
        } else {
            super.onBackPressed()
        }
    }


    fun openEditor(path: String) {
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.ivShare.setOnClickListener {
            Utils.shareFile(
                this@PhotoVideoActivity,
                displayImageList[binding.viewPager.currentItem].filePath
            )
        }
//        binding.btnEdit.beGone()
        binding.ivEdit.setOnClickListener {

            if (!isFromPrivate && !mIsVideo) {
                if (isFileExists) {
                    openEditor(displayImageList[binding.viewPager.currentItem].filePath)
                } else {
                    showToastMsg(getString(R.string.corrupted_image_edit))
                }
            }
        }
        binding.btnDelete.setOnClickListener {
            if (isFileExists)
                showDeleteDialog()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_delete)
                    else getString(R.string.corrupted_image_delete)
                )
        }
        binding.btnUnhide.setOnClickListener {
            if (isFileExists)
                setUnHideData()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_unhide)
                    else getString(R.string.corrupted_image_unhide)
                )
        }
        binding.btnHide.setOnClickListener {

            if (isFileExists)
                setHideData()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_hide)
                    else getString(R.string.corrupted_image_hide)
                )
        }
        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }


        binding.btnInfo.setOnClickListener {
            showDetailsDialog()
        }
        //binding.ivFavourite.setOnClickListener {
        binding.btnFavorite.setOnClickListener {
            if (displayImageList[binding.viewPager.currentItem].isFavorite) {
                displayImageList[binding.viewPager.currentItem].isFavorite = false
                setFavImages(binding.viewPager.currentItem)
                setUnFavorite(displayImageList[binding.viewPager.currentItem].filePath)
            } else {
                displayImageList[binding.viewPager.currentItem].isFavorite = true
                setFavImages(binding.viewPager.currentItem)
                setFavorite(displayImageList[binding.viewPager.currentItem].filePath)
            }
            sendEvent("refresh_fav")
        }
        binding.btnRestore.setOnClickListener {
            if (isFileExists) {
                val confirmationDialog = ActionConfirmationDialog(
                    this,
                    getString(R.string.restore),
                    getString(R.string.restore_msg_single),
                    getString(R.string.ok),
                    positiveBtnClickListener = {
                        restorePhoto()

                    })
                confirmationDialog.show()
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_restore)
                    else getString(R.string.corrupted_image_restore)
                )
        }
        binding.btnRecentDelete.setOnClickListener {
            if (isFileExists) {
                val confirmationDialog = ActionConfirmationDialog(
                    this,
                    getString(R.string.delete_permanently),
                    getString(R.string.permanently_delete_msg_single),
                    getString(R.string.delete),
                    positiveBtnClickListener = {
                        recentDeletePhoto()
                    }, true
                )
                confirmationDialog.show()
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_delete)
                    else getString(R.string.corrupted_image_delete)
                )
        }

//        binding.btnRename.setOnClickListener {
//            if (isFileExists)
//                showRenameDialog()
//            else
//                showToastMsg(
//                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_rename)
//                    else getString(R.string.corrupted_image_rename)
//                )
//        }
    }

//    val LENS_PACKAGE = "com.google.ar.lens"
//    val LENS_ACTIVITY = "com.google.vr.apps.ornament.app.lens.LensLauncherActivity"
//    private fun setUpLensIcon() {
//        val lensIntent = Intent.makeMainActivity(ComponentName(LENS_PACKAGE, LENS_ACTIVITY))
//            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
//        if (packageManager.resolveActivity(lensIntent, 0) == null) return
////
////        isLensInstalled = isPackageInstalled(LENS_PACKAGE)
//        isLensInstalled = true
//        binding.btnLens.beVisibleIf(isLensInstalled)
////        binding.btnLens.beVisible()
//
//        Log.e("PhotoVideo", "setUpLensIcon:$LENS_PACKAGE->$isLensInstalled")
//    }

    private fun getShareIntentForImageUri(uri: Uri, mIntent: Intent): Intent {
        var intent = Intent()
        if (mIntent != null) {
            intent = mIntent
        }
        val clipdata = ClipData(
            ClipDescription("content", arrayOf("image/png")),
            ClipData.Item(uri)
        )
        intent.setAction(Intent.ACTION_SEND)
            .setComponent(null)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri).clipData = clipdata
        return Intent.createChooser(intent, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//        return intent
    }

    @WorkerThread
    fun getLensIntentForImageUri(uri: Uri): Intent {
        val intent = Intent()
        intent.setPackage("com.google.ar.lens")
        return getShareIntentForImageUri(uri, intent)
    }

    protected fun checkNotchSupport() {
        if (isPiePlus()) {
            val cutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES

            window.attributes.layoutInDisplayCutoutMode = cutoutMode
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        }
    }

    private fun showToastMsg(msg: String) {
        toast(msg)
    }

    private fun showDropDown(anchor: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopMenuImageBinding.inflate(layoutInflater)

        val popupWindow =
            com.photogallery.utils.PopupWindowHelper(popUpBinding.root)
        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        if (isFromPrivate) {
            popUpBinding.menuCopy.visibility = View.GONE
            popUpBinding.menuMove.visibility = View.GONE
            popUpBinding.menuRename.visibility = View.GONE
//            popUpBinding.menuResize.visibility = View.GONE
        } else {
            popUpBinding.menuCopy.visibility = View.VISIBLE
            popUpBinding.menuMove.visibility = View.VISIBLE
        }

        if (displayImageList[binding.viewPager.currentItem].isVideo || displayImageList[binding.viewPager.currentItem].filePath.isGif()) {
//            popUpBinding.menuRename.beGone()
//            popUpBinding.menuResize.beGone()
            popUpBinding.menuSetWallpaper.beGone()
        } else {
//            popUpBinding.menuRename.beVisible()
//            if (!isFromPrivate) {
//                popUpBinding.menuResize.beVisible()
//            }
            popUpBinding.menuSetWallpaper.beVisible()
        }

        popupWindow.showAsPopUp(anchor)

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists) {
                showAddAlbumDialog(Constant.deviceAlbumList, true)
//                showAddAlbumDialog(Constant.albumList, true)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_copy)
                    else getString(R.string.corrupted_image_copy)
                )
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists) {
                showAddAlbumDialog(Constant.deviceAlbumList, false)
//                showAddAlbumDialog(Constant.albumList, false)
            } else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_move)
                    else getString(R.string.corrupted_image_move)
                )
        }
        popUpBinding.menuSetWallpaper.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists) {

                try {
                    showSetAsChooser(displayImageList[binding.viewPager.currentItem].filePath)
                } catch (e: Exception) {
                    toast("Not supported")
                }

            } else
                showToastMsg(getString(R.string.corrupted_image_wallpaper))
        }


        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (isFileExists)
                showRenameDialog()
            else
                showToastMsg(
                    if (displayImageList[binding.viewPager.currentItem].isVideo) getString(R.string.corrupted_video_rename)
                    else getString(R.string.corrupted_image_rename)
                )
        }

    }

    fun showSetAsChooser(imagePath: String) {
        val file = File(imagePath)
        if (!file.exists()) {
            return
        }

        // Convert to content:// URI via FileProvider
        val imageUri: Uri = FileProvider.getUriForFile(
            this,
            "${packageName}.provider",
            file
        )

        // Create the intent
        val intent = Intent(Intent.ACTION_ATTACH_DATA).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setDataAndType(imageUri, "image/*")
            putExtra("mimeType", "image/*")
        }

        // Show chooser
        val chooser = Intent.createChooser(intent, "Set as")
        startActivity(chooser)
    }

    private fun getResizeImage(image: Bitmap): Bitmap {
        val width = getScreenWidth()
        val iWidth = image.width
        val iHeight = image.height
        if (iWidth > width) {
            val ratio: Float = iWidth / iHeight.toFloat()
            val height = (width / ratio).toInt()
            return Bitmap.createScaledBitmap(image, width, height, false)
        }
        return image
    }

    fun getScreenWidth(): Int {
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
//        val displayMetrics = DisplayMetrics()
//        windowManager.defaultDisplay.getMetrics(displayMetrics)
//        return displayMetrics.widthPixels
        return windowManager.defaultDisplay.width
    }

    private fun showSeAsDialog(imagePath: String) {
        val file = File(imagePath)
        if (!file.exists()) {

            return
        }

        // Decode efficiently (adjust options if you need to downsample)
        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            ?: null

        if (bitmap == null) {

            return
        }

        val wallpaperManager = WallpaperManager.getInstance(this)
        val setWallpaperDialog = SetWallpaperDialog(this) {

            when (it) {
                1 -> {
//                    binding.progressBar.visibility = View.VISIBLE

                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            wallpaperManager.setBitmap(
                                getResizeImage(bitmap),
                                null,
                                true,
                                WallpaperManager.FLAG_LOCK
                            )
                        } else {
                            wallpaperManager.setBitmap(getResizeImage(bitmap))
                        }
                        toast(getString(R.string.wallpaper_success))
                        finish()
                    } catch (e: Exception) {
                        toast(getString(R.string.out_of_memory_error))
                        finish()
                    }
                }

                2 -> {
//                    binding.progressBar.visibility = View.VISIBLE

                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            wallpaperManager.setBitmap(
                                getResizeImage(bitmap),
                                null,
                                true,
                                WallpaperManager.FLAG_SYSTEM
                            )
                        } else {
                            wallpaperManager.setBitmap(getResizeImage(bitmap))
                        }
                        toast(getString(R.string.wallpaper_success))
                        finish()
                    } catch (e: Exception) {
                        toast(getString(R.string.out_of_memory_error))
                        finish()
                    }
                }

                3 -> {
//                    binding.progressBar.visibility = View.VISIBLE

                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            wallpaperManager.setBitmap(
                                getResizeImage(bitmap),
                                null,
                                true,
                                WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                            )
                        } else {
                            wallpaperManager.setBitmap(getResizeImage(bitmap))
                        }

                        toast(getString(R.string.wallpaper_success))
                        finish()
                    } catch (e: Exception) {
                        toast(getString(R.string.out_of_memory_error))
                        finish()
                    }
                }
            }
        }
        setWallpaperDialog.show()
    }


//    private fun animatePagerTransition(forward: Boolean) {
//        Log.d("PhotoVideoActivity", "animatePagerTransition : animatePagerTransition")
//        val oldPosition = binding.viewPager.currentItem
//        val animator = ValueAnimator.ofInt(0, binding.viewPager.width)
//        animator.addListener(object : Animator.AnimatorListener {
//            override fun onAnimationEnd(animation: Animator) {
//                if (binding.viewPager.isFakeDragging) {
//                    try {
//                        binding.viewPager.endFakeDrag()
//                    } catch (ignored: Exception) {
//                        stopSlideshow()
//                    }
//
//                    if (binding.viewPager.currentItem == oldPosition) {
//                        slideshowEnded(forward)
//                    }
//                }
//            }
//
//            override fun onAnimationCancel(animation: Animator) {
//                binding.viewPager.endFakeDrag()
//            }
//
//            override fun onAnimationStart(animation: Animator) {}
//
//            override fun onAnimationRepeat(animation: Animator) {}
//        })
//
////        if (preferences.getInt(Constant.PREF_SLIDE_EFFECT) == SLIDESHOW_ANIMATION_SLIDE) {
////            animator.interpolator = DecelerateInterpolator()
////            animator.duration = SLIDESHOW_SLIDE_DURATION
////        } else {
//        animator.duration = SLIDESHOW_FADE_DURATION
////        }
//
//        animator.addUpdateListener(object : ValueAnimator.AnimatorUpdateListener {
//            var oldDragPosition = 0
//            override fun onAnimationUpdate(animation: ValueAnimator) {
//                if (binding.viewPager.isFakeDragging == true) {
//                    val dragPosition = animation.animatedValue as Int
//                    val dragOffset = dragPosition - oldDragPosition
//                    oldDragPosition = dragPosition
//                    try {
//                        binding.viewPager.fakeDragBy(dragOffset * (if (forward) -1f else 1f))
//                    } catch (e: Exception) {
//                        stopSlideshow()
//                    }
//                }
//            }
//        })
//
//        binding.viewPager.beginFakeDrag()
//        animator.start()
//    }

    private fun showRenameDialog() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val renameDialog =
            FileRenameDialog(
                this,
                pictureData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    val file = File(renamePath)
                    displayImageList[binding.viewPager.currentItem].filePath = renamePath
                    displayImageList[binding.viewPager.currentItem].fileName = file.name
//                    pagerAdapter.notifyDataSetChanged()
                    refreshUI(displayImageList, true)
                })
        renameDialog.show()
    }

//    private fun showResizeDialog() {
//        val pictureData = displayImageList[binding.viewPager.currentItem]
//        val resizeDialog =
//            ResizeDialog(
//                this,
//                pictureData,
//                updateImageListener = { path ->
//                    val file = File(path)
//                    displayImageList.add(
//                        0,
//                        MediaData(
//                            path,
//                            Utils.getUriFromPath(this@PhotoVideoActivity,path).toString(),
//                            file.name,
//                            file.parentFile.path,
//                            file.lastModified(),
//                            file.lastModified(),
//                            file.length()
//                        )
//                    )
//                    refreshUI(displayImageList, true)
//                })
//        resizeDialog.show()
//    }

    private fun setHideData() {
        val confirmationDialog = ActionConfirmationDialog(
            this,
            getString(R.string.label_private),
            getString(R.string.hide_msg_single),
            getString(R.string.hide),
            positiveBtnClickListener = {
                hidePhoto()
            })
        confirmationDialog.show()
    }

    private fun hidePhoto() {
        Log.e("hidePhoto", "displaySize.001:" + displayImageList.size)
        val selectImage: ArrayList<MediaData> = ArrayList()
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        selectImage.add(pictureData)

        Utils.hideFiles(this, selectImage, selectImage.size, hideListener = {

            toast(getString(R.string.hide_successfully))
            displayImageList.removeAt(i)
            if (displayImageList.size != 0)
                pagerAdapter.notifyDataSetChanged()
            Log.e("hidePhoto", "displaySize.002:" + displayImageList.size)
            if (displayImageList.size == 0) {
                finish()
            } else if (i < displayImageList.size - 1) {
                selectedPosition = i
                binding.viewPager.currentItem = selectedPosition
                viewPagerSetup()
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            } else {
                if (i != 0)
                    selectedPosition = i - 1
                binding.viewPager.currentItem = selectedPosition
                viewPagerSetup()
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            }
        })
    }


    private fun showAddAlbumDialog(albumList: ArrayList<AlbumData>, isCopy: Boolean) {
        val selectImage: ArrayList<MediaData> = ArrayList()
        val selectedAlbum: ArrayList<String> = ArrayList()

        val pictureData = displayImageList[binding.viewPager.currentItem]
        selectImage.add(pictureData)

//        val addAlbumDialog =
//            SelectAlbumFullDialog(
//                this,
//                albumList,
//                selectedAlbum,
//                isCopy,
//                selectPathListener = { selectPath ->
//                    setCopyMove(isCopy, selectPath, selectImage)
//                },
//                createAlbumListener = {
//                    val createDialog = CreateAlbumDialog(this, createPathListener = {
//                        setCopyMove(isCopy, it, selectImage)
//                    })
//                    createDialog.show()
////                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) {value->
////                        if (value) {
////                            val createDialog = CreateAlbumDialog(this, createPathListener = {
////                                setCopyMove(isCopy, it, selectImage)
////                            })
////                            createDialog.show()
////                        }
////                    }
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

        isCopyForResult = isCopy
        selectImageForResult = selectImage
        val selectAlbumIntent = Intent(this, AlbumSelectorActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)
    }

    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<MediaData>
    ) {
        val i = binding.viewPager.currentItem
        if (isCopy)
            Utils.copyFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.copy_successfully1))
                    MediaScannerConnection.scanFile(
                        this,
                        arrayOf<String>(selectPath),
                        null
                    ) { path, uri -> }
                    sendEvent("refresh")
                })
        else
            Utils.moveFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                moveListener = {
                    toast(getString(R.string.move_successfully1))
                    MediaScannerConnection.scanFile(
                        this,
                        arrayOf<String>(selectPath),
                        null
                    ) { path, uri -> }
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    displayImageList.removeAt(binding.viewPager.currentItem)
//                    if (displayImageList.size != 0)
//                        adapter.notifyDataSetChanged()
                    if (displayImageList.size == 0) {
                        finish()
                    } else if (i < displayImageList.size - 1) {
                        selectedPosition = i
                        viewPagerSetup()
//                        binding.viewPager.currentItem = selectedPosition
//                        setTitles(selectedPosition)
//                        setFavImages(selectedPosition)
                    } else {
                        if (i != 0)
                            selectedPosition = i - 1
                        viewPagerSetup()
//                        binding.viewPager.currentItem = selectedPosition
//                        setTitles(selectedPosition)
//                        setFavImages(selectedPosition)
                    }
                    sendEvent("refresh")

                })
    }

    private fun restorePhoto() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem

        Utils.restoreFiles(this, arrayListOf(pictureData), 1, hideListener = {
            toast(getString(R.string.restore_successfully))
            displayImageList.removeAt(i)
            if (displayImageList.size == 0) {
                Log.e("restorePhoto", "size == 0 ")
                finish()
            } else if (i < displayImageList.size - 1) {
                selectedPosition = i
                Log.e("restorePhoto", "size - 1  selectedPosition $selectedPosition")
                viewPagerSetup()

            } else {
                if (i != 0)
                    selectedPosition = i - 1
                Log.e("restorePhoto", "i - 1  selectedPosition $selectedPosition")
                viewPagerSetup()

            }
        })

//        val dataBase = AppDatabase.getInstance(this)
//        val restoreList: ArrayList<RestoreData> = ArrayList()
//        Observable.fromCallable {
//            val list = Utils.restoreFile(this, pictureData, dataBase)
//            restoreList.addAll(list)
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                runOnUiThread {
//                    if (restoreList.size != 0) {
////                        EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                        displayImageList.removeAt(i)
//                        Log.e("restorePhoto", "size==>>  ${displayImageList.size}")
////                        if (displayImageList.size != 0)
////                            adapter.notifyDataSetChanged()
//                        if (displayImageList.size == 0) {
//                            Log.e("restorePhoto", "size == 0 ")
//                            finish()
//                        } else if (i < displayImageList.size - 1) {
//                            selectedPosition = i
//                            Log.e("restorePhoto", "size - 1  selectedPosition $selectedPosition")
//                            viewPagerSetup()
////                            binding.viewPager.currentItem = selectedPosition
////                            setTitles(selectedPosition)
////                            setFavImages(selectedPosition)
//                        } else {
//                            if (i != 0)
//                                selectedPosition = i - 1
//                            Log.e("restorePhoto", "i - 1  selectedPosition $selectedPosition")
//                            viewPagerSetup()
////                            binding.viewPager.currentItem = selectedPosition
////                            setTitles(selectedPosition)
////                            setFavImages(selectedPosition)
//                        }
//                    }
//                }
//            }
//            .onErrorReturn { false }
//            .subscribe { _: Boolean? ->
//                runOnUiThread {
//                    if (restoreList.size != 0) {
////                        EventBus.getDefault().post(RestoreDataEvent(restoreList))
//                        displayImageList.removeAt(binding.viewPager.currentItem)
////                        if (displayImageList.size != 0)
////                            adapter.notifyDataSetChanged()
//                        Log.e("restorePhoto", "size==>>  ${displayImageList.size}")
//                        if (displayImageList.size == 0) {
//                            Log.e("restorePhoto", "size == 0 ")
//                            finish()
//                        } else if (i < displayImageList.size - 1) {
//                            selectedPosition = i
//                            Log.e("restorePhoto", "size - 1  selectedPosition $selectedPosition")
//                            viewPagerSetup()
////                            binding.viewPager.currentItem = selectedPosition
////                            setTitles(selectedPosition)
////                            setFavImages(selectedPosition)
//                        } else {
//                            if (i != 0)
//                                selectedPosition = i - 1
//                            Log.e("restorePhoto", "i - 1  selectedPosition $selectedPosition")
//                            viewPagerSetup()
////                            binding.viewPager.currentItem = selectedPosition
////                            setTitles(selectedPosition)
////                            setFavImages(selectedPosition)
//                        }
//                    }
//                }
//            }
    }

    private fun recentDeletePhoto() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val i = binding.viewPager.currentItem
        val deleteList = ArrayList<String>()
        val dataBase = AppDatabase.getInstance(this)
        var isDelete = false
        Observable.fromCallable {
            isDelete = Utils.recentlyDeleteHideFile(this, pictureData, dataBase)
            isDelete
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
//                        if (displayImageList.size != 0)
//                            adapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            viewPagerSetup()
//                            binding.viewPager.currentItem = selectedPosition
//                            setTitles(selectedPosition)
//                            setFavImages(selectedPosition)
                        }
                    }
                }
            }
    }

    fun setUnHideData() {
        val pictureData = displayImageList[binding.viewPager.currentItem]
        val confirmationDialog = ActionConfirmationDialog(
            this,
            getString(R.string.unhide),
            if (pictureData.isVideo) getString(R.string.unhide_msg_video_single) else getString(R.string.unhide_msg_image_single),
            getString(R.string.ok),
            positiveBtnClickListener = {
                unHidePhoto()
            })
        confirmationDialog.show()
    }

    private fun unHidePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        val pictureData = displayImageList[binding.viewPager.currentItem]
        selectImage.add(pictureData)
        val i = binding.viewPager.currentItem

        Utils.unHideFiles(this, selectImage, selectImage.size, hideListener = {

            toast(getString(R.string.unhide_successfully))
            displayImageList.removeAt(binding.viewPager.currentItem)
            Log.e("", "displaySize ${displayImageList.size} pos==>> $i")
//            if (displayImageList.size != 0)
//                adapter.notifyDataSetChanged()

            if (displayImageList.size == 0) {
                finish()
            } else if (i < displayImageList.size - 1) {
                selectedPosition = i
                viewPagerSetup()
//                binding.viewPager.currentItem = selectedPosition
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            } else {
                if (i != 0)
                    selectedPosition = i - 1
                viewPagerSetup()
//                binding.viewPager.currentItem = selectedPosition
//                setTitles(selectedPosition)
//                setFavImages(selectedPosition)
            }
        })
    }

    private fun showDeleteDialog() {
        val pictureData = displayImageList[binding.viewPager.currentItem]

        val deleteDialog = DeleteDialog.newInstance(
            this,
//                getString(R.string.selected_delete_msg),
            btnClickListener = {
                deleteFiles(it, pictureData)
            })
        deleteDialog.show()
    }

    private fun deleteFiles(isPermanent: Boolean, pictureData: MediaData) {
        val i = binding.viewPager.currentItem
        val deleteList = ArrayList<String>()
        val dataBase = AppDatabase.getInstance(this)
        var isDelete = false

        preferences.refreshMedia = true
        preferences.scanMedia = true
        Observable.fromCallable {
            isDelete = Utils.deleteFile(this, pictureData.filePath, dataBase, isPermanent)
            isDelete
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (isDelete) {
                        preferences.refreshMedia = true
                        preferences.scanMedia = true
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
                        if (displayImageList.size != 0)
                            pagerAdapter.notifyDataSetChanged()

                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        }
                    }
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (isDelete) {
                        deleteList.add(pictureData.filePath)
//                        EventBus.getDefault().post(DisplayDeleteEvent(deleteList))
                        displayImageList.removeAt(binding.viewPager.currentItem)
                        if (displayImageList.size != 0)
                            pagerAdapter.notifyDataSetChanged()
                        if (displayImageList.size == 0) {
                            finish()
                        } else if (i < displayImageList.size - 1) {
                            selectedPosition = i
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        } else {
                            if (i != 0)
                                selectedPosition = i - 1
                            binding.viewPager.currentItem = selectedPosition
                            viewPagerSetup()
                        }
                    }
                }
            }
    }

    private fun setFavImages(position: Int) {
        try {

            mIsVideo =
                displayImageList[position].isVideo || displayImageList[position].filePath.isGif()
            binding.ivEdit.alpha = if (mIsVideo) 0.5f else 1.0f
//            if (!isFromPrivate) {
//                binding.btnEdit.beGoneIf(displayImageList[position].isVideo || displayImageList[position].filePath.isGif())
//            }
        } catch (e: Exception) {

        }
//        else {
//            binding.btnEdit.visibility = if (!displayImageList[position].filePath.isVideoFast() || !displayImageList[position].filePath.isGif()) View.VISIBLE else View.GONE
//        }

        try {
            binding.ivFavourite.setImageDrawable(
                ContextCompat.getDrawable(
                    this@PhotoVideoActivity,
                    if (displayImageList[position].isFavorite) R.drawable.ic_favourite_checked else R.drawable.ic_favourite_uncheck
                )
            )
        } catch (e: Exception) {

        }
    }

    fun refreshMenuItems() {}

    private fun setTitles(position: Int) {
        if (position < displayImageList.size) {
            val strDate = format.format(displayImageList[position].date)
            val time = formatTime.format(displayImageList[position].date)
            binding.txtTitle.text = strDate
            binding.txtTime.text = time
        }
    }

    private fun showDetailsDialog() {
        val detailsDialog =
            DetailsDialog(this, displayImageList[binding.viewPager.currentItem], false)
        detailsDialog.show()
    }

    private fun viewPagerSetup() {
        updatePagerItems(displayImageList.toMutableList())

        setTitles(selectedPosition)
        setFavImages(selectedPosition)

        val file = File(displayImageList[selectedPosition].toString())
        var filename = file.name
//        val type = when {
//            filename.isVideoFast() -> TYPE_VIDEOS
//            filename.isGif() -> TYPE_GIFS
//            filename.isRawFast() -> TYPE_RAWS
//            filename.isSvg() -> TYPE_SVGS
//            file.isPortrait() -> TYPE_PORTRAITS
//            else -> TYPE_IMAGES
//        }

//        mIsVideo = type == TYPE_VIDEOS
        mIsVideo = filename.isVideoFast()


    }

    private fun setFavorite(filePath: String) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        if (!favList.contains(filePath)) {
            favList.add(0, filePath)
            preferences.setFavoriteList(favList)
//            EventBus.getDefault().post(UpdateFavoriteEvent(filePath, true))
        }
    }

    private fun setUnFavorite(filePath: String) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        favList.remove(filePath)
        preferences.setFavoriteList(favList)
//        EventBus.getDefault().post(UpdateFavoriteEvent(filePath, false))
    }

    override fun onResume() {
        super.onResume()
        //mAdView?.resume()
//        if (preferences.maxBrightness) {
//            val attributes = window.attributes
//            attributes.screenBrightness = 1f
//            window.attributes = attributes
//        }
//        setupOrientation()
//        refreshMenuItems()
    }

    private fun setupOrientation() {
        if (!mIsOrientationLocked) {
            if (preferences.screenRotation == ROTATE_BY_DEVICE_ROTATION) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
            } else if (preferences.screenRotation == ROTATE_BY_SYSTEM_SETTING) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    private fun checkOrientation() {
        if (!mIsOrientationLocked && preferences.screenRotation == Constant.ROTATE_BY_ASPECT_RATIO) {
            var flipSides = false
            try {
                val pathToLoad = getCurrentPath()
                val exif = ExifInterface(pathToLoad)
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1)
                flipSides =
                    orientation == ExifInterface.ORIENTATION_ROTATE_90 || orientation == ExifInterface.ORIENTATION_ROTATE_270
            } catch (e: Exception) {
            }
            val resolution = applicationContext.getResolution(getCurrentPath()) ?: return
            val width = if (flipSides) resolution.y else resolution.x
            val height = if (flipSides) resolution.x else resolution.y
            if (width > height) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else if (width < height) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }
    }


    override fun fragmentClicked() {
        mIsFullScreen = !mIsFullScreen
        if (mIsFullScreen) {
            enterImmersiveMode()
        } else {
//            stopSlideshow()
            exitImmersiveMode()
        }

//        mIsFullScreen = !mIsFullScreen
        fullscreenToggled()

        val newAlpha = if (mIsFullScreen) 0f else 1f

        binding.llBottomOption.animate().alpha(newAlpha).withStartAction {
            binding.llBottomOption.beVisible()
//            binding.btnLens.beVisibleIf(isLensInstalled)
        }.withEndAction {
            binding.llBottomOption.beVisibleIf(newAlpha == 1f)
//            binding.btnLens.beVisibleIf(newAlpha == 1f && isLensInstalled)
        }.start()

        binding.loutToolbar.animate().alpha(newAlpha).withStartAction {
            binding.loutToolbar.beVisible()
        }.withEndAction {
            binding.loutToolbar.beVisibleIf(newAlpha == 1f)
        }.start()
    }

    override fun onPause() {
        super.onPause()
        //mAdView?.pause()
//        stopSlideshow()
    }


    private lateinit var windowInsetsController: WindowInsetsControllerCompat
    private fun initWindowInsetsController() {
        windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun enterImmersiveMode() {
        WindowHelper.toggleFullscreen(window, true, true)
        hideSystemUI()
        checkNotchSupport()
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
        supportActionBar?.hide()
    }

    private fun exitImmersiveMode() {
        WindowHelper.toggleFullscreen(window, false, true)
        showSystemUI()
        checkNotchSupport()
        windowInsetsController.show(WindowInsetsCompat.Type.systemBars())
        supportActionBar?.show()
    }

    private fun fullscreenToggled() {
        binding.viewPager.adapter?.let {
            (it as MyPagerAdapter).toggleFullscreen(mIsFullScreen)
            val newAlpha = if (mIsFullScreen) 0f else 1f
//            binding.topShadow.animate().alpha(newAlpha).start()
            binding.llBottomOption.animate().alpha(newAlpha).withStartAction {
                binding.llBottomOption.beVisible()
            }.withEndAction {
                binding.llBottomOption.beVisibleIf(newAlpha == 1f)
            }.start()

            binding.loutToolbar.animate().alpha(newAlpha).withStartAction {
                binding.loutToolbar.beVisible()
            }.withEndAction {
                binding.loutToolbar.beVisibleIf(newAlpha == 1f)
            }.start()
        }
    }


    override fun videoEnded(): Boolean {
//        if (mIsSlideshowActive) {
//            swipeToNextMedium()
//        }
        //return mIsSlideshowActive
        return false
    }

    override fun goToPrevItem() {
        binding.viewPager.setCurrentItem(binding.viewPager.currentItem - 1, false)
        checkOrientation()
    }

    override fun goToNextItem() {
        binding.viewPager.setCurrentItem(binding.viewPager.currentItem + 1, false)
        checkOrientation()
    }

    override fun launchViewVideoIntent(path: String) {}

//    override fun isSlideShowActive() = false

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        selectedPosition = position
        setTitles(position)
        setFavImages(position)
        try {
            isFileExists = File(displayImageList[position].filePath).exists()
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    override fun onPageSelected(position: Int) {
        Log.d("PhotoVideoActivity", "onPageSelected : $position $mPos")
        if (mPos != position) {
            mPos = position
            setTitles(position)
            setFavImages(position)
//            scheduleSwipe()
            try {
                isFileExists = File(displayImageList[position].filePath).exists()
                currentFilePath = displayImageList[position].filePath
            } catch (e: Exception) {
                Log.e("printStackTrace", "printStackTrace:$e")
            }

        }
    }

    override fun onPageScrollStateChanged(state: Int) {
        if (state == ViewPager.SCROLL_STATE_IDLE && getCurrentMedium() != null) {
            checkOrientation()
        }
    }

}