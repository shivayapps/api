[//]: # (optimize for Android UI length constraints.)

https://chatgpt.com/share/69ff0968-0a6c-8320-b767-54c7798585bb

i have impletemented call after feature for my gallery application, in which one overlay dialog comes while calling after screen and display some recent photos memory, for that need display_overlay_permission, can you design permission dialog for it


Header
Allow access to your photos

Description
We need access to your photos to show recent memories after calls.

Privacy Card Title
Your privacy matters

Privacy Card Description
We only access your photos to enhance your calling experience. Nothing is stored or shared.

Primary Button
Allow access

Secondary Button
Not now

Footer Note
You can change this later in Settings.


