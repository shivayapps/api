package com.explorefile.filemanager.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface FileDao {

    // Insert a new folder path
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertFolder(folder: SecureTable)

    // Delete a specific folder entry
    @Delete
    suspend fun deleteFolder(folder: SecureTable)

    // Delete by folder path directly
    @Query("DELETE FROM SecureTable WHERE folderPath = :path")
    suspend fun deleteByPath(path: String)

    // Get all SecureTable entries
    @Query("SELECT * FROM SecureTable")
    suspend fun getAllFolders(): List<SecureTable>

    // Get all folder paths as a List<String>
    @Query("SELECT folderPath FROM SecureTable")
    fun getAllFolderPaths(): List<String>

    // Check if a folder path exists
    @Query("SELECT COUNT(*) FROM SecureTable WHERE folderPath = :path")
    suspend fun folderExists(path: String): Int
}
