package com.explorefile.filemanager.activities

import android.hardware.biometrics.BiometricManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityLockBinding
import com.explorefile.filemanager.extensions.isSupportWithErrorInfo
import com.explorefile.filemanager.extensions.showBiometricPrompt
import com.explorefile.filemanager.fragments.LockChangeStyleFragment
import com.explorefile.filemanager.helpers.Constants
import com.explorefile.filemanager.helpers.Preferences
import com.explorefile.filemanager.fragments.LockFragment


class LockActivity : BaseActivity() {

    private val TAG = "LockActivity"
    var isShowPinLock = false

    var isResetPass = false
    var isChangePass = false
    lateinit var animation: Animation
    lateinit var preferences: Preferences

    private lateinit var binding: ActivityLockBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences= Preferences(this)
        isShowPinLock = preferences.getShowPINLock()
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)

        intView()
    }

    private fun intView() {
        isResetPass = intent.getBooleanExtra(Constants.EXTRA_RESET_PASS, false)
        isChangePass = intent.getBooleanExtra(Constants.EXTRA_CHANGE_PASS, false)

        val isChangeLockStyle = intent.getBooleanExtra(Constants.EXTRA_CHANGE_LOCK_STYLE, false)
        val isLockStyleGrid = intent.getBooleanExtra(Constants.EXTRA_LOCK_STYLE, false)


        try {
            if (isChangeLockStyle) {
                loadFragment(LockChangeStyleFragment(this, isLockStyleGrid, lockListener = {
                    setResult(RESULT_OK)
                    finish()
                }))
            } else {
                loadFragment(
                    LockFragment.getInstance(
//                    isOpenPrivate,
                        isResetPass,
                        isChangePass,
                        lockListener = {
                            if (it) {
                                setPasswordSuccess()
                            } else {
                                (this@LockActivity).finish()
                            }
                        }
                    )
                )

                val isFingerprintAvailable = isSupportWithErrorInfo(this, BiometricManager.Authenticators.BIOMETRIC_STRONG)
                if (preferences.enableFingerprint && isFingerprintAvailable.first && !isChangePass && !isResetPass) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        startAndroidxBiometricManager()
                    }, 700)
                }
            }
        } catch (e:Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    private fun loadFragment(fragment: Fragment) {
        try {
            val fm = this.supportFragmentManager
            val fragmentTransaction = fm.beginTransaction()
            fragmentTransaction.replace(R.id.container_lock, fragment)
            fragmentTransaction.commit()
        } catch (e:Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    private fun setPasswordSuccess() {
        runOnUiThread {
            setResult(RESULT_OK)
            (this@LockActivity).finish()
        }
    }

    private fun startAndroidxBiometricManager() {
        showBiometricPrompt(successCallback = { icSuccess ->
            if (icSuccess) {
                setPasswordSuccess()
            }
        }, failureCallback = { icFailed: Boolean, errorCode: Int, errString: CharSequence ->
            Log.e("BiometricManager","\nicFailed:$icFailed,\nerrorCode:$errorCode,errString:$errString")
            //showToast(getString(R.string.authentication_failed))
        })
    }
}