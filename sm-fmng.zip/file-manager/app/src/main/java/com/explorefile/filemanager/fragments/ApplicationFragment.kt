package com.explorefile.filemanager.fragments

import android.app.Dialog
import android.app.ProgressDialog
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.annotation.DrawableRes
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.airbnb.lottie.LottieAnimationView

import com.bumptech.glide.Glide
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.AppManagerActivity
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.adapters.AppAdapter
import com.explorefile.filemanager.databinding.ApplicationFragmentBinding
import com.explorefile.filemanager.dialogs.AppActionDialog
import com.explorefile.filemanager.helpers.ApkInformationExtractor
import com.explorefile.filemanager.helpers.AppManager
import com.explorefile.filemanager.helpers.CreateShortcutTool
import com.explorefile.filemanager.models.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.*

class ApplicationFragment : Fragment(R.layout.application_fragment) {

    private var _binding: ApplicationFragmentBinding? = null
    private val binding get() = _binding!!

    private lateinit var mContext: FragmentActivity

    private var appType = "user"
    private var adapter: AppAdapter? = null

    private val appList = mutableListOf<AppInfo>()
    private val appToUninstall = mutableListOf<AppInfo>()
    private val userAppList = mutableListOf<AppInfo>()
    private val systemAppList = mutableListOf<AppInfo>()

    private var apkInformationExtractor: ApkInformationExtractor? = null
    private var appManOb: AppManager? = null

    private var isLoading = false
    private var path = ""

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"

        fun newInstance(type: String): ApplicationFragment {
            return ApplicationFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_SECTION_NUMBER, type)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = requireActivity()
        appType = arguments?.getString(ARG_SECTION_NUMBER) ?: "user"

        val rootPath = Environment.getExternalStorageDirectory().toString()
        path = "$rootPath/RecoverMedia/Apk Backup/"
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = ApplicationFragmentBinding.bind(view)

        initData()
        initRecycler()
        initActions()
        getApps(appType)
    }

    fun deSelectAll() {
        appToUninstall?.clear()
        binding.button?.visibility = View.GONE
        adapter?.deSelectAll()
    }

    public fun filter(filter: String) {
        if (!filter.isEmpty()) {
            Log.e("AppsFragment", "filter-filterAppList: $appType")
            if (appType.equals("user")) {
                filterAppList(filter, adapter?.getAppList()!!)
            } else if (appType.equals("system")) {
                filterAppList(filter, adapter?.getAppList()!!)
            }
        } else {
            Log.e("AppsFragment", "filter-updateAppList: $appType")
            if (appType.equals("user")) {
                updateAppList(userAppList!!)
            } else if (appType.equals("system")) {
                updateAppList(systemAppList!!)
            }
        }

    }

    public fun sort(type: Int) {
        Log.e("sortAppList", "type:$type")
        val appList = adapter?.getAppList()!!

        Log.e("sortAppList", "appList:${appList.size}")
        sortAppList(type, appList)
//        if(type==0){
//            appList.sortBy { it.usageTimeMillis }
//        }else if(type==1){
//            appList.sortByDescending  { it.usageTimeMillis }
//        }else if(type==2){
//            appList.sortByDescending  { it.appSize }
//        }
        //updateAppList(appList)
    }

    public fun sortAppList(type: Int, newAppList: MutableList<AppInfo>) {
        if (type == 0) {
            newAppList.sortBy { it.usageTimeMillis }
        } else if (type == 1) {
            newAppList.sortByDescending { it.usageTimeMillis }
        } else if (type == 2) {
            newAppList.sortByDescending { it.appSize }
        }
        Log.e("sortAppList", "updateAppList:${newAppList.size}")
        updateAppList(newAppList)
    }

    private fun filterAppList(filter: String, newAppList: MutableList<AppInfo>) {
        val filteredList = ArrayList<AppInfo>()
//        var isUninstalledFilter=false
        for (app in newAppList) {
            if (app.appName.toString().lowercase(Locale.getDefault()).contains(filter)) {
                filteredList.add(app)
            }
//            if(app.isSelected) isUninstalledFilter=true
        }
        updateAppList(filteredList)
//        if (appToUninstall?.size!! > 0 && isUninstalledFilter) {
//            adapter?.isMultiSelect=true
//            buttonUninstall?.visibility = View.VISIBLE
//        } else {
//            adapter?.isMultiSelect=false
//            buttonUninstall?.visibility = View.GONE
//        }
    }


    private fun initData() {
        apkInformationExtractor = ApkInformationExtractor(mContext)
        appManOb = AppManager()

        binding.alertSystem.visibility =
            if (appType == "system") View.VISIBLE else View.GONE

        binding.tvEmtyMsg.text = if (appType == "user") {
            getString(R.string.user_app_list_is_empty)
        } else {
            getString(R.string.system_app_list_is_empty)
        }
    }

    private fun initRecycler() {
        adapter = AppAdapter(
            activity as BaseActivity,
            appType,
            object : AppAdapter.OnAppSelect {

                override fun onAppClick(position: Int, appInfo: AppInfo) {
                    if (!adapter!!.isMultiSelect) {
                        appActionDialog(appInfo)
                    }
                }

                override fun onAppSelect(position: Int, isChecked: Boolean, appInfo: AppInfo) {
                    if (isChecked) {
                        appToUninstall.add(appInfo)
                    } else {
                        appToUninstall.remove(appInfo)
                    }
                    updateMultiSelectState()
                }
            }
        )

        binding.rvApps.apply {
            layoutManager = GridLayoutManager(context, 1)
            adapter = this@ApplicationFragment.adapter
            setItemViewCacheSize(500)
        }
    }

    private fun initActions() {
        binding.buttonUninstall.setOnClickListener {
            if (appToUninstall.isNotEmpty()) {
                uninstallApp(appToUninstall.first())
            }
        }

        binding.buttonRecover.setOnClickListener {
            if (appToUninstall.isNotEmpty()) {
                copyApks()
            } else {
                Toast.makeText(mContext, "Select item first", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateMultiSelectState() {
        adapter?.isMultiSelect = appToUninstall.isNotEmpty()
        binding.button.visibility =
            if (appToUninstall.isNotEmpty()) View.VISIBLE else View.GONE

        adapter?.notifyDataSetChanged()
    }

    private fun getApps(type: String) {
        isLoading = true
        binding.lottieApps.visibility = View.VISIBLE
        if(!isLoading) binding.llEmpty.visibility = View.GONE

        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            try {
                appManOb = ApkInformationExtractor(requireContext()).appManagerInitValues()

                userAppList.clear()
                systemAppList.clear()


                appManOb?.let {
                    userAppList.addAll(it.userApps)
                    systemAppList.addAll(it.systemApps)
                }
                Log.e("DATA_CHECK", "User apps: ${userAppList.size}")
                Log.e("DATA_CHECK", "System apps: ${systemAppList.size}")

                withContext(Dispatchers.Main) {
                    Log.e("DATA_CHECK", "Updating UI list size: ${appList.size}")
                    updateAppList(if (type == "user") userAppList else systemAppList)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateAppList(newList: MutableList<AppInfo>) {
        Log.e("DATA_CHECK", "updateAppList: ${newList.size}")

        appList.clear()
        appList.addAll(newList)
        adapter?.updateList(appList)

        if(!isLoading) binding.lottieApps.visibility = View.GONE
        if(!isLoading) binding.llEmpty.visibility = if (appList.isEmpty()) View.VISIBLE else View.GONE

        binding.rvApps.visibility =
            if (appList.isEmpty()) View.GONE else View.VISIBLE

        isLoading = false

        val title = if (appType == "user") {
            getString(R.string.user_apps)
        } else {
            getString(R.string.system_apps)
        }

        (activity as AppManagerActivity).apply {
            if (appType == "user") {
                binding.tvUserApps.setText("$title (${appList.size})")
            } else {
                binding.tvSystemApps.setText("$title (${appList.size})")
            }
        }
    }

    private fun uninstallApp(appInfo: AppInfo) {
        val uri = Uri.parse("package:${appInfo.appPackage}")
        startActivityForResult(
            Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri),
            115
        )
    }

    private fun appActionDialog(appInfo: AppInfo) {
        AppActionDialog(
            activity as AppManagerActivity,
            appInfo,
            appType
        )
    }

    private fun copyApks() {
        // Move your AsyncTask logic to coroutine / WorkManager
        // (I can rewrite this too if you want)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


//class ApplicationFragment : Fragment() {
//
//    var rootView: View? = null
//    private var tv_emty_msg: TextView? = null
//    private var ll_empty: LinearLayout? = null
//    var rv_apps: RecyclerView? = null
//    var lottie_apps: ProgressBar? = null
//    var buttonUninstall: LinearLayout? = null
//    var buttonRecover: LinearLayout? = null
//    var button: LinearLayout? = null
//    var alertSystem: TextView? = null
////    var lastVisible: Boolean = false
//
//    lateinit var mContext: FragmentActivity
//    var appType = "user"
//
//    private var apkInformationExtractor: ApkInformationExtractor? = null
//    private var progressDialog: ProgressDialog? = null
//
//    public var adapter: AppAdapter? = null
//    public var appList: MutableList<AppInfo>? = null
//    public var appToUninstall: MutableList<AppInfo>? = null
//    public var userAppList: MutableList<AppInfo>? = null
//    public var systemAppList: MutableList<AppInfo>? = null
//
//    //    private var mDbHelper: DBAdapter? = null
//    var mCopyApks: AsyncTask<*, *, *>? = null
//    private var path = ""
//
//    //    internal var arrAppType: Array<String>? = null
//    private var recyclerViewLayoutManager: RecyclerView.LayoutManager? = null
//    private var appManOb: AppManager? = null
//    private var numberOfUserApps: String? = " "
//    private var numberOfSystemApps: String? = " "
//    private var appInAction: AppInfo? = null
//    var isVisibleToUser = false
//
//
//    companion object {
//        private const val ARG_SECTION_NUMBER = "section_number"
//
//        @JvmStatic
//        fun newInstance(type: String): ApplicationFragment {
//            val fragment = ApplicationFragment()
//            val bundle = Bundle()
//            bundle.putString(ARG_SECTION_NUMBER, type)
//            fragment.arguments = bundle
//            return fragment
//        }
//    }
//
//    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
//        //super.setUserVisibleHint(isVisibleToUser)
//        this.isVisibleToUser = isVisibleToUser
////        if(isVisibleToUser) {
////        }
////        else {
////        }
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        mContext = requireActivity()
//        if (arguments != null) {
//            appType = requireArguments().getString(ARG_SECTION_NUMBER)!!
//        }
////        initAds()
//    }
//
//    fun deSelectAll() {
//        appToUninstall?.clear()
//        button?.visibility = View.GONE
//        adapter?.deSelectAll()
//    }
//
//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        // Inflate the layout for this fragment
//        rootView = inflater.inflate(R.layout.application_fragment, container, false)
//        tv_emty_msg = rootView?.findViewById(R.id.tv_emty_msg)
//        ll_empty = rootView?.findViewById(R.id.ll_empty)
//        rv_apps = rootView?.findViewById(R.id.rv_apps)
//        buttonRecover = rootView?.findViewById(R.id.buttonRecover)
//        buttonUninstall = rootView?.findViewById(R.id.buttonUninstall)
//        button = rootView?.findViewById(R.id.button)
//        alertSystem = rootView?.findViewById(R.id.alertSystem)
//
//        lottie_apps = rootView?.findViewById(R.id.lottie_apps)
////        lottie_apps = (requireActivity() as AppManagerActivity).findViewById(R.id.lottie_apps)
//
//        val mRootPath = Environment.getExternalStorageDirectory().toString()
////        var currPath: String = Environment.getExternalStorageDirectory().toString(),
//        path = mRootPath + "/RecoverMedia/Apk Backup/"
//
//        initData()
//        initActions()
//        return rootView;
//    }
//
//    fun initData() {
////        mDbHelper = DBAdapter(mContext)
//
//        progressDialog = ProgressDialog(mContext)
//        progressDialog!!.setMessage(getString(R.string.please_wait))
//        progressDialog!!.setCancelable(false)
//        progressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
//        progressDialog!!.isIndeterminate = true
//        progressDialog!!.progress = 0
//
//        appList = ArrayList()
//
//        appManOb = AppManager()
//
//        userAppList = ArrayList()
//        systemAppList = ArrayList()
//        appToUninstall = ArrayList()
//
//        apkInformationExtractor = ApkInformationExtractor(mContext)
//        recyclerViewLayoutManager = GridLayoutManager(mContext, 1)
////        recyclerViewLayoutManager = LinearLayoutManager(mContext,RecyclerView.VERTICAL,false)
//
//        if (appType == "user") {
////            buttonUninstall.visibility=View.VISIBLE
//            tv_emty_msg?.text = getString(R.string.user_app_list_is_empty)
//            alertSystem?.visibility = View.GONE
//        } else {
////            buttonUninstall?.visibility=View.GONE
//            tv_emty_msg?.text = getString(R.string.system_app_list_is_empty)
//            alertSystem?.visibility = View.VISIBLE
//        }
//        button?.visibility = View.GONE
//        buttonUninstall?.setOnClickListener {
//
//            if (appToUninstall?.size!! > 0) {
//                uninstallApp(appToUninstall!![0])
//            }
//        }
//        buttonRecover?.setOnClickListener {
//
//            goForCopy()
////            if (appToUninstall?.size!! > 0) {
////                uninstallApp(appToUninstall!![0])
////            }
//        }
//
//        adapter = AppAdapter(
//            activity as BaseActivity,
//            appList!!,
//            appType,
//            object : AppAdapter.OnAppSelect {
//                override fun onAppClick(position: Int, appInfo: AppInfo) {
//                    if (!adapter?.isMultiSelect!!) appActionDialog(appInfo, appType)
//                }
//
//                override fun onAppSelect(position: Int, isChecked: Boolean, appInfo: AppInfo) {
////                appActionDialog(appInfo,appType)
//                    if (isChecked) {
////                    Log.e("AppsFragment", "appToUninstall-add: ${appInfo.appPackage}")
////                    Log.e("AppsFragment", "onAppSelect-appToUninstall: ${appToUninstall.size}")
//                        appToUninstall?.add(appInfo)
////                    AppManagerActivity.selectedPackage.add(appInfo.appPackage!!)
//                    } else {
////                    Log.e("AppsFragment", "appToUninstall-remove: ${appInfo.appPackage}")
////                    Log.e("AppsFragment", "onAppSelect-appToUninstall: ${appToUninstall.size}")
//                        appToUninstall?.remove(appInfo)
////                    AppManagerActivity.selectedPackage.remove(appInfo.appPackage!!)
//                    }
//
//                    rv_apps?.scrollToPosition(position)
//
//                    if (appToUninstall?.size!! > 0) {
//                        adapter?.isMultiSelect = true
//                        button?.visibility = View.VISIBLE
//                    } else {
//                        adapter?.isMultiSelect = false
//                        button?.visibility = View.GONE
//                    }
//                    adapter?.notifyDataSetChanged()
//                }
//            })
//
//        rv_apps?.layoutManager = recyclerViewLayoutManager
//        rv_apps?.adapter = adapter
//        rv_apps?.setItemViewCacheSize(500)
//
//        getApps(mContext, appType)
//
////        if (AdsManager(mContext).isNeedToShowAds()) {
////            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
////        }
//    }
//
//    override fun onResume() {
//        super.onResume()
//    }
//
//
//    private fun goForCopy() {
//        if (appToUninstall!!.size != 0) {
//            mCopyApks =
//                CopyFiles(appToUninstall!!).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        } else {
//            Toast.makeText(mContext, "Select item first", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    private inner class CopyFiles(var selectedApp: MutableList<AppInfo>) :
//        AsyncTask<String?, String?, String?>() {
//        val dialog = Dialog(activity!! as AppManagerActivity)
//        var progress_text: TextView? = null
//        var permission_text: TextView? = null
////        var selectedApp: MutableList<AppInfo>? = null
//
//        //        override fun CopyFiles(selectedApp: MutableList<AppInfo>) {
////            this.selectedApp=selectedApp
////        }
//        override fun onPreExecute() {
//            super.onPreExecute()
//
//            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//            dialog.setCancelable(false)
//            dialog.setContentView(R.layout.dialog_progress)
//            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//            dialog.window!!.setLayout(
//                ViewGroup.LayoutParams.MATCH_PARENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT
//            )
//
//            progress_text = dialog.findViewById<TextView>(R.id.permission)
//            progress_text?.text = getString(R.string.label_please_wait)
//            permission_text = dialog.findViewById<TextView>(R.id.permission_text)
//            permission_text?.text = getString(R.string.copying_apk_files)
//            dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)
//
//            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
//                dialog.cancel()
//
//                AdsConfig.isSystemDialogOpen = false
//                if (mCopyApks != null) {
//                    mCopyApks!!.cancel(true)
//                }
//            }
//
//            dialog.setOnDismissListener {
//                AdsConfig.isSystemDialogOpen = false
//            }
//
//            if (!dialog.isShowing) {
//                dialog.show()
//                AdsConfig.isSystemDialogOpen = true
//            }
//        }
//
//        override fun doInBackground(vararg strings: String?): String? {
////            val selectedInfoList = mApkBackupAdapter!!.selectedApk()
////            if (selectedInfoList.isNotEmpty()) {
//            for (i in selectedApp.indices) {
//                if (mCopyApks != null) {
//                    if (mCopyApks!!.isCancelled) {
//                        updateUi(dialog)
//                    } else {
//                        val file = File(selectedApp[i].publicSourceDir!!)
//                        val dir = File(path)
//                        if (dir.exists() || dir.mkdirs()) {
//                            try {
//                                copy(file, selectedApp[i].appName, selectedApp[i].appName)
//                                activity!!.sendBroadcast(
//                                    Intent(
//                                        Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
//                                        Uri.fromFile(file)
//                                    )
//                                )
//                            } catch (e: Exception) {
//                                e.printStackTrace()
//                            }
//                        }
//                    }
//                }
//                activity?.runOnUiThread {
//                    permission_text?.text =
//                        "copying apk files $i/${selectedApp.size}"
//                }
//            }
////            }
//            return null
//        }
//
//        override fun onPostExecute(s: String?) {
//            super.onPostExecute(s)
//
//            try {
//                Handler(Looper.getMainLooper()).post {
//                    deSelectAll()
////                    if(isAdded) {
////                        checkAll!!.isChecked = false
////                    }
//                }
//
//                Handler(Looper.getMainLooper()).postDelayed(Runnable {
//                    try {
//                        if (dialog != null && dialog.isShowing) {
//                            dialog.cancel()
////                            MyApplication.isDialogOpen = false
//                        }
//                    } catch (e: Exception) {
////                        mContext!!.addEvent(e.message!!)
//                    }
//                }, 100)
//
////                mContext!!.viewpager.currentItem = 1
//
//                Toast.makeText(mContext, "Apks copied" + path, Toast.LENGTH_LONG)
//                    .show()
//
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }
//    }
//
//
//    fun updateUi(pd: Dialog) {
//        mContext.runOnUiThread {
//            deSelectAll()
//            pd.cancel()
//        }
//    }
//
//    private fun copy(fileToCopy: File, lPackageName: String?, lAppName: String?) {
//        try {
//            val destinationFile = File(path, "$lAppName#$lPackageName.apk")
//            Log.e("mTAG", "copy: destinationFile -- > $destinationFile")
//            val fis = FileInputStream(fileToCopy)
//            val fos = FileOutputStream(destinationFile)
//            val b = ByteArray(1024)
//            var noOfBytesRead: Int
//            while (fis.read(b).also { noOfBytesRead = it } != -1) {
//                fos.write(b, 0, noOfBytesRead)
//            }
//            fis.close()
//            fos.close()
//        } catch (e: IOException) {
//            e.printStackTrace()
//        }
//    }
//
//    private fun uninstallApp(appToUninstall: AppInfo) {
//
//        appInAction = appToUninstall
//        val appPackage: String = appInAction?.appPackage!!
//        val uri = Uri.parse("package:$appPackage")
//        val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri)
//        startActivityForResult(intent, 115)
//    }
//
//    private fun appActionDialog(appInfo: AppInfo, appType: String) {
//        appInAction = appInfo
//        AppActionDialog(activity as AppManagerActivity, appInfo, appType)
//    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        Log.e("onActivityResult", "fragment-requestCode: $requestCode")
//        Log.e("onActivityResult", "fragment-resultCode: $resultCode")
//        if (requestCode == 112) {
//            //public void saveAppHistory(String name, String packageName, String size, String date)
//
//            if (!ApkInformationExtractor(mContext).isPackageInstalled(appInAction?.appPackage!!)) {
//
//                val formatter = SimpleDateFormat("EEE-MMM dd,yyyy", Locale.getDefault())
//                val calendar = Calendar.getInstance()
////                mDbHelper!!.saveAppHistory(
////                    appInAction?.appName,
////                    appInAction?.appPackage,
////                    "${appInAction?.appSize}",
////                    formatter.format(calendar.time)
////                )
////                AppManagerActivity.needInterstitialAd=true
//                Handler(Looper.getMainLooper()).postDelayed({
//                    getApps(mContext, appType)
//                }, 500)
//            }
//        }
//        if (requestCode == 115) {
//
//            if (!ApkInformationExtractor(mContext).isPackageInstalled(appInAction?.appPackage!!)) {
//                //public void saveAppHistory(String name, String packageName, String size, String date)
//                appToUninstall?.remove(appInAction)
////                Log.e("AppsFragment", "appToUninstall-removeAppInAction: ${appInAction?.appPackage}")
////                Log.e("AppsFragment", "onActivityResult-appToUninstall: ${appToUninstall.size}")
//
//                val formatter = SimpleDateFormat("EEE-MMM dd,yyyy", Locale.getDefault())
//                val calendar = Calendar.getInstance()
////                mDbHelper!!.saveAppHistory(
////                    appInAction?.appName,
////                    appInAction?.appPackage,
////                    "${appInAction?.appSize}",
////                    formatter.format(calendar.time)
////                )
//
//                if (appToUninstall?.size!! > 0) {
//                    adapter?.isMultiSelect = true
//                    uninstallApp(appToUninstall!![0])
//                    button?.visibility = View.VISIBLE
////                    if(lastVisible) rv_apps?.scrollToPosition(adapter?.itemCount!!)
//                } else {
////                    AppManagerActivity.needInterstitialAd=true
//
//                    adapter?.isMultiSelect = false
//                    Handler(Looper.getMainLooper()).postDelayed({
//                        getApps(mContext, appType)
//                    }, 500)
//                }
//            } else {
//                appToUninstall?.remove(appInAction)
////                appToUninstall.clear()
//                if (appToUninstall?.size!! > 0) {
//                    adapter?.isMultiSelect = true
//                    uninstallApp(appToUninstall!![0])
//                    button?.visibility = View.VISIBLE
////                    if(lastVisible) rv_apps?.scrollToPosition(adapter?.itemCount!!)
//                } else {
////                    AppManagerActivity.needInterstitialAd=true
////                    if (AdsManager(activity!!).isNeedToShowAds() && mInterstitial != null) {
////                        if (!SharedPrefsConstant.getBoolean(
////                                activity!!,
////                                SharedPrefsConstant.IS_APP_IN_BACKGROUND,
////                                true
////                            )
////                        ) {
////                            if (mInterstitial != null) mInterstitial!!.show(activity!!)
////                        }
////                    }
//
//                    adapter?.isMultiSelect = false
//                    Handler(Looper.getMainLooper()).postDelayed({
//                        getApps(mContext, appType)
//                    }, 500)
//                }
//            }
//
//        }
//    }
//
//    fun drawableToBitmap(drawable: Drawable): Bitmap? {
//        var bitmap: Bitmap? = null
//        if (drawable is BitmapDrawable) {
//            val bitmapDrawable: BitmapDrawable = drawable as BitmapDrawable
//            if (bitmapDrawable.getBitmap() != null) {
//                return bitmapDrawable.getBitmap()
//            }
//        }
//        bitmap = if (drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
//            Bitmap.createBitmap(
//                1,
//                1,
//                Bitmap.Config.ARGB_8888
//            ) // Single color bitmap will be created of 1x1 pixel
//        } else {
//            Bitmap.createBitmap(
//                drawable.getIntrinsicWidth(),
//                drawable.getIntrinsicHeight(),
//                Bitmap.Config.ARGB_8888
//            )
//        }
//        val canvas = Canvas(bitmap)
//        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight())
//        drawable.draw(canvas)
//        return bitmap
//    }
//
//    private fun getAppIconBitmapByPackageName(ApkTempPackageName: String): Bitmap? {
//        val drawable: Drawable? = try {
//            mContext.packageManager.getApplicationIcon(ApkTempPackageName)
//        } catch (e: PackageManager.NameNotFoundException) {
//            e.printStackTrace()
//            ContextCompat.getDrawable(mContext, R.mipmap.ic_launcher)
//        }
//        return drawableToBitmap(drawable!!)
////        return drawable
//    }
//
//    fun createShortcut(context: Context, name: String, intent: Intent, icon: IconCompat): Boolean {
//        if (ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
//            val pinShortcutInfo = ShortcutInfoCompat.Builder(context, name)
//                .setIcon(icon)
//                .setShortLabel(name)
//                .setIntent(intent)
//                .build()
//            return ShortcutManagerCompat.requestPinShortcut(context, pinShortcutInfo, null)
//        }
//        return false
//    }
//
//    @RequiresApi(Build.VERSION_CODES.O)
//    private fun shortcutDialog1(appInfo: AppInfo, bitmapIcon: Bitmap) {
//        val manager = mContext.getSystemService(ShortcutManager::class.java)
//        if (manager.isRequestPinShortcutSupported) {
//
//            val intent =
//                Intent(mContext.packageManager.getLaunchIntentForPackage(appInfo.appPackage!!))
//
//            val shortcut = ShortcutInfo.Builder(
//                activity,
//                generateId(appInfo.appName!!)
//            )
//                .setShortLabel(appInfo.appName!!)
//                .setIcon(Icon.createWithBitmap(bitmapIcon))
//                .setIntent(intent)
//                .build()
//
//            manager.requestPinShortcut(shortcut, null)
//
//        } else {
//            Toast.makeText(context, "The shortcut not supported", Toast.LENGTH_LONG).show()
//        }
//    }
//
//
//    fun createLauncherIcon(context: Context, activityModel: AppInfo, bitmap: Bitmap?) {
//        val intent = activityModelToIntent(activityModel)
//        val iconCompat = IconCompat.createWithBitmap(bitmap!!)
//        try {
//            createShortcut(context, activityModel.appName!!, intent, iconCompat)
//        } catch (e: Exception) { // android.os.TransactionTooLargeException
//            createLauncherIcon(context, activityModel.appName!!, intent, R.mipmap.ic_launcher)
//        }
//    }
//
//    fun createLauncherIcon(context: Context, name: String, intent: Intent, @DrawableRes icon: Int) {
//        val iconCompat = IconCompat.createWithResource(context, icon)
//        createShortcut(context, name, intent, iconCompat)
//    }
//
//    private fun activityModelToIntent(activityModel: AppInfo): Intent {
//
//        val intent =
//            Intent(mContext.packageManager.getLaunchIntentForPackage(activityModel.appPackage!!))
//        return intent
//    }
//
//    private fun generateId(str: String): String {
//        return str + (Random().nextInt(91) + 10)
//    }
//
//    public fun sort(type: Int) {
//        Log.e("sortAppList","type:$type")
//        val appList = adapter?.getAppList()!!
//
//        Log.e("sortAppList","appList:${appList.size}")
//        sortAppList(type, appList!!)
////        if(type==0){
////            appList.sortBy { it.usageTimeMillis }
////        }else if(type==1){
////            appList.sortByDescending  { it.usageTimeMillis }
////        }else if(type==2){
////            appList.sortByDescending  { it.appSize }
////        }
//        //updateAppList(appList)
//    }
//
//    public fun sortAppList(type: Int, newAppList: MutableList<AppInfo>) {
//        if (type == 0) {
//            newAppList.sortBy { it.usageTimeMillis }
//        } else if (type == 1) {
//            newAppList.sortByDescending { it.usageTimeMillis }
//        } else if (type == 2) {
//            newAppList.sortByDescending { it.appSize }
//        }
//        Log.e("sortAppList","updateAppList:${newAppList.size}}")
//        updateAppList(newAppList)
//    }
//
//    public fun filter(filter: String) {
//        if (!filter.isEmpty()) {
//            Log.e("AppsFragment", "filter-filterAppList: $appType")
//            if (appType.equals("user")) {
//                filterAppList(filter, adapter?.getAppList()!!)
//            } else if (appType.equals("system")) {
//                filterAppList(filter, adapter?.getAppList()!!)
//            }
//        } else {
//            Log.e("AppsFragment", "filter-updateAppList: $appType")
//            if (appType.equals("user")) {
//                updateAppList(userAppList!!)
//            } else if (appType.equals("system")) {
//                updateAppList(systemAppList!!)
//            }
//        }
//
//    }
//
//    var isLoading=false
//    private fun getApps(context: Context, type: String) {
//        if ((activity as AppManagerActivity) != null && isAdded) {
//            (activity as AppManagerActivity).binding.etSearch.setText("")
//        }
//        Log.e("AppsFragment", "fragment-getApps: $type")
//        if (appToUninstall?.size!! > 0) {
//            adapter?.isMultiSelect = true
//            button?.visibility = View.VISIBLE
////            if(lastVisible) rv_apps?.scrollToPosition(adapter?.itemCount!!)
//        } else {
//            adapter?.isMultiSelect = false
//            button?.visibility = View.GONE
//        }
////        lottie_apps?.playAnimation()
//        lottie_apps?.visibility = View.VISIBLE
//        isLoading=true
////        (requireActivity() as AppManagerActivity).playLottie(true)
//        ll_empty?.visibility = View.GONE
//
//        val contextRef: WeakReference<Context> = WeakReference(context)
//
//        //Coroutine
//        GlobalScope.launch(Dispatchers.Default) {
//            try {
//                val context1 = contextRef.get()
//                appManOb = ApkInformationExtractor(context).appManagerInitValues()
//
//                userAppList?.clear()
//                systemAppList?.clear()
//
//                if (appManOb != null) {
//                    numberOfUserApps = " " + appManOb!!.userAppSize
//                    numberOfSystemApps = " " + appManOb!!.systemAppSize
//
//                    userAppList?.addAll(appManOb!!.userApps)
//                    systemAppList?.addAll(appManOb!!.systemApps)
//
//                } else {
//                    numberOfUserApps = " " + "0"
//                    numberOfSystemApps = " " + "0"
//
//                }
//
//                //UI Thread
//                withContext(Dispatchers.Main) {
//
//                    Log.e("AppsFragment", "withContext-updateAppList: $type")
//                    if (type.equals("user")) {
//                        updateAppList(userAppList!!)
//                    } else if (type.equals("system")) {
//                        updateAppList(systemAppList!!)
//                    }
//                }
//            } catch (e: java.lang.Exception) {
//                e.printStackTrace()
//            }
//        }
//    }
//
//    private fun filterAppList(filter: String, newAppList: MutableList<AppInfo>) {
//        val filteredList = ArrayList<AppInfo>()
////        var isUninstalledFilter=false
//        for (app in newAppList) {
//            if (app.appName.toString().lowercase(Locale.getDefault()).contains(filter)) {
//                filteredList.add(app)
//            }
////            if(app.isSelected) isUninstalledFilter=true
//        }
//        updateAppList(filteredList)
////        if (appToUninstall?.size!! > 0 && isUninstalledFilter) {
////            adapter?.isMultiSelect=true
////            buttonUninstall?.visibility = View.VISIBLE
////        } else {
////            adapter?.isMultiSelect=false
////            buttonUninstall?.visibility = View.GONE
////        }
//    }
//
//    private fun updateAppList(newAppList: MutableList<AppInfo>) {
//        Log.e("sortAppList", "updateAppList-newAppList.001: ${newAppList.size}")
//
//        val listCopy = newAppList.toMutableList() // ← make a copy to avoid clearing original
//
//        var isUninstalledFilter = false
//        for (app in listCopy) {
//            if (app.isSelected) isUninstalledFilter = true
//        }
//
//        if (!appToUninstall.isNullOrEmpty() && isUninstalledFilter) {
//            adapter?.isMultiSelect = true
//            button?.visibility = View.VISIBLE
//        } else {
//            adapter?.isMultiSelect = false
//            button?.visibility = View.GONE
//        }
//
//        if (listCopy.isNotEmpty()) {
//            appList?.clear()
//            appList?.addAll(listCopy)
//            adapter?.updateList(listCopy)
//
//            if(!isLoading) ll_empty?.visibility = View.GONE
//            rv_apps?.visibility = View.VISIBLE
//        } else {
//            if(!isLoading) ll_empty?.visibility = View.VISIBLE
//            rv_apps?.visibility = View.GONE
//        }
//
//        if(!isLoading) lottie_apps?.visibility = View.GONE
//        isLoading=false
////        (requireActivity() as AppManagerActivity).playLottie(false)
//        if (progressDialog!!.isShowing) progressDialog!!.dismiss()
//
//        Log.e("sortAppList", "updateAppList-newAppList.002: ${listCopy.size}")
//
//        if (appType == "user") {
//            (activity as AppManagerActivity).binding.tvUserApps.text =
//                "${getString(R.string.user_apps)} (${listCopy.size})"
//        } else if (appType == "system") {
//            (activity as AppManagerActivity).binding.tvSystemApps.text =
//                "${getString(R.string.system_apps)} (${listCopy.size})"
//        }
//    }
//
//
//    fun initActions() {
//    }
//
//
//    override fun onDestroyView() {
//        super.onDestroyView()
////        rootView = null
//    }
//
//
//}