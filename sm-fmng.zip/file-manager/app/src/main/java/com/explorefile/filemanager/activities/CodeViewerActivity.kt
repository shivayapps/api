package com.explorefile.filemanager.activities

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.explorefile.filemanager.databinding.ActivityCodeViewerBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.NavigationIcon
import java.io.File
import kotlin.getValue

class CodeViewerActivity : BaseActivity() {

    private var filePath = ""
    private var fileName = ""
    private var fileType = ""

    val binding by viewBinding(ActivityCodeViewerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        filePath = intent?.getStringExtra("filePath").toString()
        fileName = intent?.getStringExtra("fileName").toString()
        fileType = intent?.getStringExtra("fileType").toString()
        initActions()
        getDataUpdateUi()

        setupToolbar()
    }

    fun initActions() {
//        binding.ivBack.setOnClickListener {
//            onBackPressed()
//        }
    }
    override fun onResume() {
        super.onResume()
        setupToolbar(binding.codeviewerToolbar, NavigationIcon.Arrow)
        updateTopBarColors(binding.codeviewerToolbar, getProperBackgroundColor())
    }
    private fun setupToolbar() {
        binding.codeviewerToolbar.title = fileName
    }
    private fun getDataUpdateUi(){
        filePath = intent?.getStringExtra("filePath").toString()
        fileName = intent?.getStringExtra("fileName").toString()
        fileType = intent?.getStringExtra("fileType").toString()

        try {
            val codeString=readLargeFile(filePath)
            binding.codeView.setCode(codeString.toString())
            //binding.docview.openDoc(this, filePath, 3, -1, false, DocEngine.MICROSOFT)
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to open document.", Toast.LENGTH_SHORT).show()
        }
    }

//    fun readFileAsText(path: String): String {
//        return File(path).readText(Charsets.UTF_8)
//    }

    fun readLargeFile(path: String): StringBuilder {
        val sb = StringBuilder()
        File(path).useLines { lines ->
            lines.forEach { sb.appendLine(it) }
        }
        return sb
    }

}