package com.explorefile.filemanager.models

data class MyTheme(val label: String, val textColorId: Int, val backgroundColorId: Int, val primaryColorId: Int)
