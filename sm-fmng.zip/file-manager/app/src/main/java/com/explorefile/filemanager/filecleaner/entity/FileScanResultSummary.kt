package com.explorefile.filemanager.filecleaner.entity

import com.explorefile.filemanager.filecleaner.entity.FileScanResult
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicInteger

data class FileScanResultSummary(
    val image: FileScanResult = FileScanResult(),
    val video: FileScanResult = FileScanResult(),
    val audio: FileScanResult = FileScanResult(),
    val document: FileScanResult = FileScanResult(),
    val download: FileScanResult = FileScanResult(),
    val compressedApkFile: FileScanResult = FileScanResult(),
    var scanCost: Int = 0,

    val scanTaskNum: AtomicInteger = AtomicInteger(),
    val countDownLatch: CountDownLatch = CountDownLatch(1),
)
