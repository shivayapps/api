####       

1. Extend Application class with AppOpenApplication
   ``Java
   public class MyApplication extends AppOpenApplication implements AppOpenApplication.AppLifecycleListener {
    @Override
    public void onCreate() {
        super.onCreate();
        AdsConfig.Companion
                .builder()
                .setIsDebug(true)
                .isEnableAds(true)
                .isEnableOpenAds(true)
                .setTestDeviceId("VKDFV98HGNIEJ9NNUVCSNDL80928RKL0")
                .setAdmobInterClick(2)
                .setAdmobInterstitialAdId(getString(R.string.G_INTERSTITIAL_ID))
                .setAdmobAppOpenId(getString(R.string.G_APPOPEN_ID))
                .setAdmobBannerId(getString(R.string.G_BANNER_ID))
                .setAdmobNativeId(getString(R.string.G_NATIVE_ID))
                .build(this);
        setAppLifecycleListener(this);
        initMobileAds();
        OpenAdHelper.INSTANCE.loadOpenAd(this, new Function0<Unit>() {
            @Override
            public Unit invoke() {
                return null;
            }
        });
    }
   }
   ``

2. For native Ads
   ``Java
      new NativeAdHelper(this, adContainer, NativeLayoutType.NativeBanner,null,"").loadAd();
   ``
3. For native Ads
   ``Java
      AdsConfig.Companion.showInterstitialAd(context, new Function0<Unit>() {
         @Override
         public Unit invoke() {
            //Perform here
            return null;
         }
      });
   ``
