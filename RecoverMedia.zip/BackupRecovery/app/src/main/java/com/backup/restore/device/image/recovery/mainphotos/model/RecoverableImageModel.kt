package com.backup.restore.device.image.recovery.mainphotos.model

class RecoverableImageModel(
    var filePath: String,
    var isSelected: Boolean,
    var fileDate: Long,
    var fileSize: Long
)