package com.backup.restore.device.image.recovery.junckcleaner.interfaces;

public interface DeleteVirusInterface {

    void listener(boolean call);

 }
