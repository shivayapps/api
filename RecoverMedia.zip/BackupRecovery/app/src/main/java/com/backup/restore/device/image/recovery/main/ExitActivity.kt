package com.backup.restore.device.image.recovery.main

import android.os.Bundle
import android.os.Handler
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityExitBinding

class ExitActivity : AppCompatActivity() {
    lateinit var handler: Handler

    lateinit var binding:ActivityExitBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        super.onCreate(savedInstanceState)
        changeLanguage()
//        setContentView(R.layout.activity_exit)
        binding=ActivityExitBinding.inflate(layoutInflater)
        setContentView(binding.root)

        handler = Handler()
        handler.postDelayed({ finishAffinity() }, 1000)
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }

    override fun onBackPressed() {
        finishAffinity()
        super.onBackPressed()
    }

    override fun onDestroy() {
//        NativeAdvancedModelHelper.destroy()
        super.onDestroy()
    }
}