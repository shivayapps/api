package com.backup.restore.device.image.recovery.mainapps.activity

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.databinding.ActivityThankYouBinding
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import java.util.*


class ThankYouActivity : MyCommonBaseActivity(), View.OnClickListener {

    lateinit var binding:ActivityThankYouBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_thank_you)
        binding=ActivityThankYouBinding.inflate(layoutInflater)
        setContentView(binding.root)

//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            val window = window
//            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
//            window.statusBarColor = resources.getColor(R.color.white)
//            window.navigationBarColor = resources.getColor(R.color.white)
//        }

        addEvent(ThankYouActivity::class.simpleName!!)


    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }

    override fun getContext(): AppCompatActivity {
        return this@ThankYouActivity
    }

    override fun initData() {

    }


    override fun initActions() {
        binding.buttonStart.setOnClickListener(this)
    }


    override fun onBackPressed() {
//        super.onBackPressed()
        setResult(RESULT_OK)
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.buttonStart -> onBackPressed()
        }
    }
}