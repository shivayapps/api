package com.backup.restore.device.image.recovery.mainapps.model

import android.graphics.drawable.Drawable

class SelectedApk {
    var label: String? = null
    var appName: String? = null
    var installedTime: String? = null
    var size: Double? = null
    var drawable: Drawable? = null
    var isChecked = false
    var publicSourceDir: String? = null
}