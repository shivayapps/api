package com.backup.restore.device.image.recovery.main

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.utilities.Info
import com.backup.restore.device.image.recovery.utilities.loadImage
import com.example.jdrodi.callback.RVClickListener
import com.example.jdrodi.utilities.camelCaseString


class MainBackupAdapter(
    val mContext: Activity,
    private val layout: Int,
    private val backupOptions: MutableList<Info>,
    val listener: RVClickListener
) : RecyclerView.Adapter<MainBackupAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(layout, parent, false))
    }

    override fun getItemCount(): Int {
        return backupOptions.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val nearby = backupOptions[position]
        val title = mContext.getString(nearby.name)
        holder.tvTitle.text = camelCaseString(title)
        holder.tvTitle.isSelected = true
        mContext.loadImage(nearby.thumb, holder.ivThumb, null)

        holder.itemView.setOnClickListener { listener.onItemClick(position) }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.tv_title)
        val ivThumb: ImageView = itemView.findViewById(R.id.iv_thumb)
    }
}