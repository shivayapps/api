package com.backup.restore.device.image.recovery.mainapps.fragment

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.text.DecimalFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * A placeholder fragment containing a simple view.
 */
class CpuFragmentNew : Fragment() {

//    var mActivity: MainActivity? = null
    var rootView: View? = null
    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
//    var tvSystemAppsMemory: TextView? = null
//    var tvAvailableRAM: TextView? = null
//    var tvTotalRAMSpace: TextView? = null
    private var rvCpuFeatureList: RecyclerView? = null

    var activityManager: ActivityManager? = null
    var memoryInfo: ActivityManager.MemoryInfo? = null
    var inputStream: InputStream? = null
    var byteArray = ByteArray(1024)
    var cpuData: String = ""
    var iv_share: ImageView? = null


    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        @JvmStatic
        fun newInstance(): CpuFragmentNew {
            val fragment = CpuFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)
        rvCpuFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)


        activity?.addEvent(CpuFragmentNew::class.simpleName!!)
        getCpuInfoMap()
//        getCpuInfo()

        // Init
        val handler = Handler()
        val runnable = object : Runnable {
            override fun run() {
                val totalRamValue = totalRamMemorySize()
                val freeRamValue = freeRamMemorySize()
                val usedRamValue = totalRamValue - freeRamValue
//                arcRAM?.progress = Utils.calculatePercentage(usedRamValue.toDouble(), totalRamValue.toDouble())
                handler.postDelayed(this, 500)
            }
        }
        handler.postDelayed(runnable, 500)

        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        Handler(Looper.getMainLooper()).postDelayed({
            scrollMain.scrollTo(0,0)
        },100)
        return rootView
    }

    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

    private fun getMemoryInfo() {
        activityManager = activity?.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager?
        memoryInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memoryInfo)
        val freeMemory = memoryInfo?.availMem
        val totalMemory = memoryInfo?.totalMem
        val usedMemory = freeMemory?.let { totalMemory?.minus(it) }
//        tvSystemAppsMemory?.text = context?.getString(R.string.system_and_apps) + ":  ".plus(formatSize(usedMemory!!))
//        tvAvailableRAM?.text = context?.getString(R.string.available_ram) + ":  ".plus(formatSize(freeMemory))
//        tvTotalRAMSpace?.text = context?.getString(R.string.total_ram_space) + ":  ".plus(formatSize(totalMemory!!))
    }


    private fun freeRamMemorySize(): Long {
        return try {
            val mi = ActivityManager.MemoryInfo()
            val activityManager = activity?.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            activityManager.getMemoryInfo(mi)
            return mi.availMem
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }

    private fun totalRamMemorySize(): Long {
        return try {
            val mi = ActivityManager.MemoryInfo()
            val activityManager = activity?.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            activityManager.getMemoryInfo(mi)
            mi.totalMem
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }

    private fun formatSize(size: Long): String {
        if (size <= 0)
            return "0"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
        return DecimalFormat("#,##0.#").format(size / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
    }

    private fun getCpuInfoMap() {

//        var lists = ArrayList<FeaturesHW>()
        var processorName=getString(R.string.unavailable)

        val parents = ArrayList<ParentModel>()

        try {
            val s = Scanner(File("/proc/cpuinfo"))
            parents.add(ParentModel(resources.getString(R.string.processor_label)+" : 1",ArrayList<FeaturesHW>()))
            var pIndex=0

            var lists=parents.get(pIndex).lists

            while (s.hasNextLine()) {
                val vals = s.nextLine().split(": ")
                if (vals.size > 1) {
                    val entry = FeaturesHW(vals[0].trim { it <= ' ' }, vals[1].trim { it <= ' ' })
//                    Log.e("getCpuInfoMap", "${entry.featureLable} = ${entry.featureValue}")
                    if(entry.featureLable.equals("Processor")) {
                        processorName=entry.featureValue
                        Log.e("getCpuInfoMap", "parents.processorName : ${entry.featureValue}")
                    }
                    if(entry.featureLable.equals("processor")) {
                        Log.e("getCpuInfoMap", "parents.add : ${entry.featureValue}")
                        pIndex++
                        parents.add(ParentModel(resources.getString(R.string.processor_label)+" : $pIndex",ArrayList<FeaturesHW>()))
                        lists=parents.get(pIndex).lists
                        lists.clear()
                    }
                    Log.e("getCpuInfoMap", "entry.featureValue : ${entry.featureLable} <-::-> ${entry.featureValue}")
                    lists.add(entry)
                }
            }
        } catch (e: Exception) {
            Log.e("getCpuInfoMap", "Exception:"+e)
        }

        Log.e("getCpuInfoMap = ","parents.size:"+parents.size)
        Log.e("getCpuInfoMap = ","parents.lists.size:"+parents.get(0).lists.size)
        if(parents.get(0).lists.size<=1) parents.removeAt(0)

        val adapter = ParentAdapter(parents, requireContext())

        //now adding the adapter to RecyclerView
        rvCpuFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvCpuFeatureList?.hasFixedSize()
        rvCpuFeatureList?.adapter = adapter

        ivType!!.setImageResource(R.drawable.ic_cpu)
        tvTitle!!.text = getString(R.string.processor_information)
        tvSubTitle?.text=processorName
        tvTitle?.isSelected=true
        tvSubTitle?.isSelected=true
    }

    fun getCpuInfo() {
        try {
            val proc = Runtime.getRuntime().exec("cat /proc/cpuinfo")
            val cpuDetails = proc.inputStream
            Log.e("getCpuInfo = ","cpuDetails:"+cpuDetails)
        } catch (e: IOException) {
            Log.e("getCpuInfo", "Exception:" + e.printStackTrace())
        }
    }
}