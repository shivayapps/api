package com.backup.restore.device.image.recovery.ads.updatejsonparsing

import android.content.Context
import com.backup.restore.device.image.recovery.ads.retrofit.model.ForceUpdateModel
import com.example.jdrodi.utilities.SPUtil
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.google.gson.reflect.TypeToken

/**
 * JsonUtil.kt - Utilities of json parsing.
 * @author:  Jignesh N Patel
 * @date: 04-Feb-2021 2:51 PM
 */
private const val KEY_FORCE_UPDATE = "key_force_update"


// [START Save & Get force update]
fun Context.saveForceUpdate(appCenterData: String) {
    SPUtil(this).save(KEY_FORCE_UPDATE, appCenterData)
}

fun Context.saveForceUpdateModel(modelAppCenter: ForceUpdateModel) {
    val modelString = Gson().toJson(modelAppCenter)
    SPUtil(this).save(KEY_FORCE_UPDATE, modelString)
}

fun Context.getForceUpdate(): ForceUpdateModel {
    val jsonString = SPUtil(this).getString(KEY_FORCE_UPDATE, "")
    val nullModel = ForceUpdateModel()
    return if (jsonString.isNullOrEmpty() || jsonString.isNullOrBlank()) {
        nullModel
    } else {
        try {
            val itemType = object : TypeToken<ForceUpdateModel>() {}.type
            Gson().fromJson<ForceUpdateModel>(jsonString, itemType)
        } catch (e: JsonSyntaxException) {
            nullModel
        } catch (e: IllegalStateException) {
            nullModel
        } catch (e: Exception) {
            nullModel
        }
    }
}
// [END Save & Get force update]