package com.backup.restore.device.image.recovery.mainphotos.recoverablefragment

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.databinding.FragmentRecoverableImageVideoBinding
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.RecoverableImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.ViewRecoverableDocumentListActivity
import com.backup.restore.device.image.recovery.mainphotos.callbacks.ItemClickListener
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableFolderModel
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel
import com.backup.restore.device.image.recovery.mainphotos.recoverableadapter.RecoverableFolderAdapter
import com.backup.restore.device.image.recovery.utilities.SPAN_COUNT_THREE
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.getExtension
import com.backup.restore.device.image.recovery.utilities.getGridCount
//import kotlinx.android.synthetic.main.activity_recover_image_new.*
//import kotlinx.android.synthetic.main.fragment_recoverable_image_video.*
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
class RecoverableDocumentFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    lateinit var mView: View
    var selectedList = ArrayList<TrashModel>()
    var isVisibleHint: Boolean = false
    var isAsyncRunning: Boolean = false
    var isForSort = "date_asc"

    var mGetRecoverableAlbum: AsyncTask<*, *, *>? = null
    var mHiddenPictureFolderAdapter: RecoverableFolderAdapter? = null
    var mRecoverableFolderList = ArrayList<RecoverableFolderModel>()
    var mFolderList = ArrayList<RecoverableFolderModel>()

    companion object {
        fun newInstance(): RecoverableDocumentFragment {
            return RecoverableDocumentFragment()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        context!!.registerReceiver(
//            refreshMediaBroadcast,
//            IntentFilter("com.progress.image.Refresh")
//        )
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isAdded) {
            isVisibleHint = isVisibleToUser
//            Log.e(mTAG, "setUserVisibleHint: same $isVisibleToUser")
            if (!isAsyncRunning) stopLoading()
//            object : AsyncTask<Void, Long, Void>() {
//                override fun doInBackground(vararg voids: Void): Void? {
////                Log.e(mTAG, "doInBackground: stopLoading")
//                    if (!isAsyncRunning) stopLoading()
//                    return null
//                }
//
//                override fun onPostExecute(result: Void?) {
//                    super.onPostExecute(result)
//                }
//            }.execute()

            if (isVisibleHint) {

                if (mFolderList != null && mFolderList.size != 0) {
                    if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 3) {
                        if (requireActivity() is RecoverableImageActivity) {
                            (requireActivity() as RecoverableImageActivity).toggleRecoverButtonVisibility(
                                true
                            )
                            if ((requireActivity() as RecoverableImageActivity).binding.ivSpan != null) {
                                (requireActivity() as RecoverableImageActivity).binding.ivSpan.alpha = 1.0F
                                (requireActivity() as RecoverableImageActivity).binding.ivSpan.isEnabled = true
                            }
                            when (isForSort) {
                                "size_asc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectSizeAsc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        true
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        false
                                }
                                "size_desc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectSizeDesc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        true
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        false
                                }
                                "date_desc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectDateDesc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        false
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        true
                                }
                                "date_asc" -> {
                                    (requireActivity() as RecoverableImageActivity).selectTop(1)
//                                (requireActivity() as RecoverableImageActivity).selectDateAsc()
                                    (requireActivity() as RecoverableImageActivity).isDateClick =
                                        false
                                    (requireActivity() as RecoverableImageActivity).isSizeClick =
                                        true
                                }
                            }
                        }
                    }
                } else {

                    if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 3) {
                        if (requireActivity() is RecoverableImageActivity) {
                            (requireActivity() as RecoverableImageActivity).toggleRecoverButtonVisibility(
                                false
                            )
                            (requireActivity() as RecoverableImageActivity).unSelectAll()
                            if ((requireActivity() is RecoverableImageActivity)) {
//                            if ((requireActivity() as RecoverableImageActivity).binding.ivSpan != null) {
                                (requireActivity() as RecoverableImageActivity).binding.ivSpan.alpha = 0.5F
                                (requireActivity() as RecoverableImageActivity).binding.ivSpan.isEnabled = false
                            }
                        }
                    }
                }

                if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 3) {
                    if ((requireActivity() as RecoverableImageActivity).binding.ivSpan != null) (requireActivity() as RecoverableImageActivity).binding.ivSpan!!.isSelected =
                        requireContext().getGridCount() == SPAN_COUNT_THREE
                }
                binding.scanRecoverableAlbum!!.layoutManager = GridLayoutManager(
                    (requireActivity()),
                    (requireActivity()).getGridCount()
                )

            }
        }
    }

//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        mView = inflater.inflate(R.layout.fragment_recoverable_image_video, container, false)
//        return mView
//    }
    lateinit var binding: FragmentRecoverableImageVideoBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
//        mView = inflater.inflate(R.layout.fragment_recoverable_image_video, container, false)
        binding= FragmentRecoverableImageVideoBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_doc)
        binding.tvNotFound.setText(R.string.document_not_found)

        mGetRecoverableAlbum =
            GetRecoverableAlbum().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        mGetRecoverableAlbum = GetRecoverableAlbum().execute()

        binding.scanRecoverableAlbum!!.layoutManager = GridLayoutManager(
            (requireActivity()),
            (requireActivity()).getGridCount()
        )
        binding.scanRecoverableAlbum!!.setHasFixedSize(true)

        mHiddenPictureFolderAdapter = RecoverableFolderAdapter(
            mRecoverableFolderList,
            (requireActivity() as RecoverableImageActivity),
            object :
                ItemClickListener {
                override fun onPicClicked(pictureFolderPath: String?, folderName: String?) {
                    val move = Intent(
                        (requireActivity() as RecoverableImageActivity),
                        ViewRecoverableDocumentListActivity::class.java
                    )
                    move.putExtra("folderPath", pictureFolderPath)
                    move.putExtra("folderName", folderName)
                    startActivity(move)
//                    finish()
                }

            })
        binding.scanRecoverableAlbum.adapter = mHiddenPictureFolderAdapter
    }

    override fun onClick(view: View) {

    }

    override fun onResume() {
        super.onResume()
        if (isAdded) {

//            resumeImageCount += 1
            Log.e(mTAG, "onResume: $isVisibleHint")

            object : AsyncTask<Void, Long, Void>() {
                override fun doInBackground(vararg voids: Void): Void? {
                    Log.e(mTAG, "doInBackground: stopLoading")
                    if (!isAsyncRunning) stopLoading()
                    return null
                }

                override fun onPostExecute(result: Void?) {
                    super.onPostExecute(result)
                }
            }.execute()
        }
    }


    private inner class GetRecoverableAlbum :
        AsyncTask<Void?, String?, ArrayList<RecoverableFolderModel>>() {

        override fun onPreExecute() {
            try {

                isAsyncRunning = true
                binding.lottieRecoverableImage.visibility = View.VISIBLE
                if((requireActivity() is RecoverableImageActivity)) {
//                if((requireActivity() as RecoverableImageActivity).binding.ivSpan!=null) {
                    (requireActivity() as RecoverableImageActivity).binding.ivSpan.alpha = 0.5F
                    (requireActivity() as RecoverableImageActivity).binding.ivSpan.isEnabled = false
                }
                (requireActivity() as RecoverableImageActivity).unSelectAll()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        override fun doInBackground(vararg voids: Void?): ArrayList<RecoverableFolderModel> {
            mFolderList.clear()
            mRecoverableFolderList.clear()
//            mFolderList = gridRecoverableAlbumImage(ShareConstants.mRootPath)
            mFolderList = checkFileOfDirectory(getFileList(ShareConstants.mRootPath)!!)

//            val mlist = Utils.getListAllFiles(ShareConstants.mRootPath)
//            val mFinalList = mlist.filter { file: File? -> file?.path!!.contains("/.") && !file.path.contains("Backup And Recovery") }
//            mFolderList = checkFileOfDirectoryNew(mFinalList)

            return mFolderList
        }

        override fun onPostExecute(lRecoverableFolderList: ArrayList<RecoverableFolderModel>) {
            try {
                Handler(Looper.getMainLooper()).post {
                    isAsyncRunning = false
                    if (isAdded) {
                        try {

                            stopLoading()
                            if (lRecoverableFolderList.size <= 0) {
//                        Log.e(mTAG, "onPostExecute: size 0 ")
                                if(binding.tvRecoverableAlbum!=null) binding.tvRecoverableAlbum!!.visibility = View.VISIBLE
                                if(binding.scanRecoverableAlbum!=null) binding.scanRecoverableAlbum!!.visibility = View.GONE
                                if(binding.lottieRecoverableImage!=null) binding.lottieRecoverableImage.visibility = View.GONE
                                if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 3) {
                                    (requireActivity() as RecoverableImageActivity).unSelectAll()
                                    if ((requireActivity() is RecoverableImageActivity)) {
//                                    if ((requireActivity() as RecoverableImageActivity).binding.ivSpan != null) {
                                        (requireActivity() as RecoverableImageActivity).binding.ivSpan.alpha =
                                            0.5F
                                        (requireActivity() as RecoverableImageActivity).binding.ivSpan.isEnabled =
                                            false
                                    }
                                }
                            } else {
                                if(binding.tvRecoverableAlbum!=null) binding.tvRecoverableAlbum!!.visibility = View.GONE
                                if(binding.scanRecoverableAlbum!=null) binding.scanRecoverableAlbum!!.visibility = View.VISIBLE
                                if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 3) {
                                    (requireActivity() as RecoverableImageActivity).selectTop(1)
                                    if ((requireActivity() is RecoverableImageActivity)) {
//                                    if ((requireActivity() as RecoverableImageActivity).binding.ivSpan != null) {
                                        (requireActivity() as RecoverableImageActivity).binding.ivSpan.alpha = 1F
                                        (requireActivity() as RecoverableImageActivity).binding.ivSpan.isEnabled = true
                                    }
                                }
                            }
                            Collections.sort(
                                lRecoverableFolderList,
                                ShareConstants.RecoverableDateAscending()
                            )
                        } catch (e: Exception) {

                        }
                    }
                    if (isAdded) (requireActivity() as RecoverableImageActivity).mIsCancelAsync =
                        false

                }
//                mHiddenPictureFolderAdapter!!.runLayoutAnimation()
            } catch (e: Exception) {
                e.printStackTrace()
            }


        }
    }


    fun getFileList(str: String): Array<File>? {
        val file = File(str)
        return if (file.isDirectory) {
            file.listFiles()
        } else {
            null
        }
    }

    private fun checkFileOfDirectoryNew(fileArr: List<File>): ArrayList<RecoverableFolderModel> {
        val picPaths = ArrayList<String>()

        var isNewData = false
        for (i in fileArr.indices) {
            isNewData = false

            val folder = Objects.requireNonNull(fileArr[i].parentFile).name
            val mRootPath = fileArr[i].parent!!

            if (fileArr[i].length().toString() != "0") {

                val lExtension = getExtension(fileArr[i].path)
                val isExtensionMatches =
                    SharedPrefsConstant.DocumentArray.contains(lExtension) && fileArr[i].path.endsWith(
                        lExtension
                    )

                if (isExtensionMatches) {
                    //do nothing, just skip these files
//                    } else {
//                        this.alImageData.add(ImageData(fileArr[i]!!.path, false))
                    if (fileArr[i].path.contains("/.")) {

                        Log.e("MMMGGG", "001 checkFileOfDirectoryNew:path->${fileArr[i].path}")
                        Log.e("MMMGGG", "002 checkFileOfDirectoryNew:mRootPath->${mRootPath}")

                        if (!picPaths.contains(mRootPath)) {
                            picPaths.add(mRootPath)
                            val mFolderModel = RecoverableFolderModel()
                            mFolderModel.path = mRootPath
                            mFolderModel.folderName = folder
                            mFolderModel.folderDate = File(mRootPath).lastModified()
//                                val lFolderSize = ShareConstants.getFolderSize(File(mRootPath))
//                                mFolderModel.folderSize = lFolderSize
                            mFolderModel.firstPic = "document"
                            mFolderModel.addPics()
                            mRecoverableFolderList.add(mFolderModel)
                            isNewData = true
                            Log.e("MMMGGG", "003 checkFileOfDirectoryNew:folder->${folder}")
                            Log.e("MMMGGG", "004 checkFileOfDirectoryNew:mRootPath->${mRootPath}")
                            for (j in mRecoverableFolderList.indices) {
                                Log.e(
                                    "MMMGGG",
                                    "0061 checkFileOfDirectoryNew:path-${j}->${mRecoverableFolderList[j].path}"
                                )
                            }

                        } else {
                            for (j in mRecoverableFolderList.indices) {
                                if (mRecoverableFolderList[j].path == mRootPath) {
                                    Log.e(
                                        "MMMGGG",
                                        "005 checkFileOfDirectoryNew:mRootPath->${mRootPath}"
                                    )
                                    Log.e(
                                        "MMMGGG",
                                        "0062 checkFileOfDirectoryNew:path-${j}->${mRecoverableFolderList[j].path}"
                                    )
                                    mRecoverableFolderList[j].firstPic = "document"
                                    mRecoverableFolderList[j].addPics()
                                    isNewData = true
                                }
                            }
                        }
                    }
                }

            }

            if (mGetRecoverableAlbum != null) {
                if (mGetRecoverableAlbum!!.isCancelled) {
                    (requireActivity() as RecoverableImageActivity).runOnUiThread {
                        MyApplication.isDialogOpen = false
//                        mFolderList.clear()
                        binding.scanRecoverableAlbum!!.visibility = View.GONE
                        binding.lottieRecoverableImage.visibility = View.GONE

//                        if (isAdded) mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                        if (isAdded) (requireActivity() as RecoverableImageActivity).mIsCancelAsync =
                            true
                        if (isAdded) (requireActivity() as RecoverableImageActivity).unSelectAll()
                    }
                    break
                }
            }

            if (isAdded && isNewData) {
                (requireActivity() as RecoverableImageActivity).runOnUiThread {
                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                    }, 200)
                }
            }
        }
        Log.e("MMMGGG", "007 mRecoverableFolderList:size->${mRecoverableFolderList.size}")
        return mRecoverableFolderList
    }

    private fun checkFileOfDirectory(fileArr: Array<File>): ArrayList<RecoverableFolderModel> {

        val picPaths = ArrayList<String?>()
        val mFolderModel = RecoverableFolderModel()

        var isNewData = false
        for (i in fileArr.indices) {
            if (fileArr[i].isDirectory && !fileArr[i].name.startsWith("data") &&
                !fileArr[i].name.startsWith("obb") && !fileArr[i].name.startsWith("obj")
                && !fileArr[i].name.startsWith(".trash") && !fileArr[i].name.contains("Backup And Recovery")
            ) {
                checkFileOfDirectory(getFileList(fileArr[i].path)!!)
            } else {

                if (fileArr[i].length().toString() != "0" && fileArr[i].path.contains("/.")) {

                    val lExtension = getExtension(fileArr[i].path)
                    val isExtensionMatches =
                        SharedPrefsConstant.DocumentArray.contains(lExtension) && fileArr[i].path.endsWith(
                            lExtension
                        )

                    if (isExtensionMatches) {
//                        if (fileArr[i].path.contains("/.")) {
                        val folder = Objects.requireNonNull(fileArr[i].parentFile).name
                        val mRootPath = fileArr[i].parent!!

                        if (!picPaths.contains(mRootPath)) {
                            picPaths.add(mRootPath)
                            mFolderModel.path = mRootPath
                            mFolderModel.folderName = folder
                            mFolderModel.folderDate = File(mRootPath).lastModified()
//                                val lFolderSize = ShareConstants.getFolderSize(File(mRootPath))
//                                mFolderModel.folderSize = lFolderSize
                            mFolderModel.firstPic = "document"
                            mFolderModel.addPics()
//                                if(!mRecoverableFolderList.contains(mFolderModel)) mRecoverableFolderList.add(mFolderModel)
                            mRecoverableFolderList.add(mFolderModel)
                            isNewData = true
                        } else {
                            for (j in mRecoverableFolderList.indices) {
                                if (mRecoverableFolderList[j].path == mRootPath) {
                                    mRecoverableFolderList[j].firstPic = "document"
                                    mRecoverableFolderList[j].addPics()
                                    isNewData = true
                                }
                            }
                        }
//                        }

                    }
                }
            }

            if (mGetRecoverableAlbum != null) {
                if (mGetRecoverableAlbum!!.isCancelled) {
                    (requireActivity() as RecoverableImageActivity).runOnUiThread {
                        MyApplication.isDialogOpen = false
                        mFolderList.clear()
                        binding.scanRecoverableAlbum!!.visibility = View.GONE
                        binding.lottieRecoverableImage.visibility = View.GONE

//                        if (isAdded) mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                        if (isAdded) (requireActivity() as RecoverableImageActivity).mIsCancelAsync =
                            true
                        if (isAdded) (requireActivity() as RecoverableImageActivity).unSelectAll()
                    }
                    break
                }
            }
            if (isAdded && isNewData) {
                (requireActivity() as RecoverableImageActivity).runOnUiThread {
                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                    }, 200)
                }
            }
        }
        return mRecoverableFolderList
    }

    private fun gridRecoverableAlbumImage(
        directoryPath: String,
    ): ArrayList<RecoverableFolderModel> {
        val picPaths = ArrayList<String?>()
        val mFolderModel = RecoverableFolderModel()
        val files = File(directoryPath).listFiles()
        if (files != null) {
//            Arrays.sort(files) { o1, o2 -> o2!!.lastModified().compareTo(o1!!.lastModified()) }
            for (file in files) {
                if (file.isDirectory && !file.name.startsWith("data") &&
                    !file.name.startsWith("obb") && !file.name.startsWith("obj")
                    && !file.name.startsWith(".trash") && !file.name.contains("Backup And Recovery")
                ) {
                    gridRecoverableAlbumImage(file.path)
                } else {
                    val filePath = file.absolutePath
//                    Log.e(mTAG, "gridRecoverableAlbumImage: " + file.length())
//                    Log.e(mTAG, "gridRecoverableAlbumImage: " + file.path)
//                    Log.e(mTAG, "gridRecoverableAlbumImage: --------------")
//                    val lExtension = FilenameUtils.getExtension(filePath)
                    val lExtension = getExtension(filePath)
//                    val lImageExtensionList = HashSet(listOf(ImageArray))
                    val isExtensionMatches =
                        SharedPrefsConstant.DocumentArray.contains(lExtension) && filePath.endsWith(
                            lExtension
                        )
                    if (isExtensionMatches && file.length().toString() != "0") {
                        if (filePath.contains("/.")) {
                            val folder = Objects.requireNonNull(File(filePath).parentFile).name
                            val mRootPath = File(filePath).parent!!
                            if (!picPaths.contains(mRootPath)) {
                                picPaths.add(mRootPath)
                                mFolderModel.path = mRootPath
                                mFolderModel.folderName = folder
                                mFolderModel.folderDate = File(mRootPath).lastModified()
//                                val lFolderSize = ShareConstants.getFolderSize(File(mRootPath))
//                                mFolderModel.folderSize = lFolderSize
                                mFolderModel.firstPic = "document"
                                mFolderModel.addPics()
                                mRecoverableFolderList.add(mFolderModel)
                            } else {
                                for (i in mRecoverableFolderList.indices) {
                                    if (mRecoverableFolderList[i].path == mRootPath) {
                                        mRecoverableFolderList[i].firstPic = "document"
                                        mRecoverableFolderList[i].addPics()
                                    }
                                }
                            }

                        }
                    }
                }
                if (mGetRecoverableAlbum != null) {
                    if (mGetRecoverableAlbum!!.isCancelled) {
                        (requireActivity() as RecoverableImageActivity).runOnUiThread {
                            MyApplication.isDialogOpen = false
                            mFolderList.clear()
                            binding.scanRecoverableAlbum!!.visibility = View.GONE
                            binding.lottieRecoverableImage.visibility = View.GONE
                            if (isAdded) (requireActivity() as RecoverableImageActivity).mIsCancelAsync =
                                true
                            if (isAdded) (requireActivity() as RecoverableImageActivity).unSelectAll()
                        }
                        break
                    }
                }
            }
            if (isAdded) {
                (requireActivity() as RecoverableImageActivity).runOnUiThread {
                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
                    }, 200)
                }
            }
        }
        return mRecoverableFolderList
    }


    fun stopLoading() {
        activity?.runOnUiThread {
            Handler(Looper.getMainLooper()).postDelayed({
                if (binding.lottieRecoverableImage != null) binding.lottieRecoverableImage.visibility = View.GONE
                if (isAdded) {
//                        if(isVisibleHint) {
                    if (mFolderList != null && mFolderList.size != 0) {

                        if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 3) {
                            (requireActivity() as RecoverableImageActivity).selectTop(1)

                            if ((requireActivity() as RecoverableImageActivity).binding.ivSpan != null) {
                                (requireActivity() as RecoverableImageActivity).binding.ivSpan.alpha = 1F
                                (requireActivity() as RecoverableImageActivity).binding.ivSpan.isEnabled = true
                            }
                            if ((requireActivity() as NewRecoverImageActivity).binding.btnRecover != null) {
                                (requireActivity() as NewRecoverImageActivity).binding.btnRecover.alpha = 1F
                                (requireActivity() as NewRecoverImageActivity).binding.btnRecover.isEnabled = true
                            }
                            if ((requireActivity() as NewRecoverImageActivity).binding.llSelectAll != null) {
                                (requireActivity() as NewRecoverImageActivity).binding.llSelectAll.alpha = 1F
                                (requireActivity() as NewRecoverImageActivity).binding.llSelectAll.isEnabled = true
                            }
                        }
                        if(binding.tvRecoverableAlbum!=null) binding.tvRecoverableAlbum!!.visibility = View.GONE
                        if(binding.lottieRecoverableImage!=null) binding.lottieRecoverableImage.visibility = View.GONE
                        Log.e(mTAG, "stopLoading: ")
                    } else {
                        if (RecoverableImageActivity.lastSelection == 1 && RecoverableImageActivity.prevPosRecoverable == 3) {
                            (requireActivity() as RecoverableImageActivity).unSelectAll()
                        }
                        if(binding.lottieRecoverableImage!=null) binding.lottieRecoverableImage.visibility = View.GONE
                    }
                }
            }, 1000)
        }
    }


    override fun onDestroy() {
        super.onDestroy()

        if (mGetRecoverableAlbum != null) {
            if (mGetRecoverableAlbum?.status == AsyncTask.Status.RUNNING) {
                mGetRecoverableAlbum?.cancel(true)
            }
        }
//        context!!.unregisterReceiver(refreshMediaBroadcast)
    }
}