package com.backup.restore.device.image.recovery.ads.adshelper

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

const val KEY_NATIVE="native_ads"

class AdsManager(mActivity: Context) {

    // SP to be save & retrieve
    private val isNeedToShow = "isNeedToShow"
    private val isSubscribe = "isSubscribe"
    private val sp: SharedPreferences = SharedPreferences(mActivity)

    fun onProductPurchased() {
        Log.e("IN_APP_BILLING","onProductPurchased")
        sp.save(isNeedToShow, true)
    }

    fun onProductSubscribed() {
        Log.e("IN_APP_BILLING","onProductSubscribed")
        sp.save(isSubscribe, true)
    }

    fun onProductExpired() {
        Log.e("IN_APP_BILLING","onProductExpired")
        sp.save(isNeedToShow, false)
    }
    fun onSubscribeExpired() {
        Log.e("IN_APP_BILLING","onProductExpired")
        sp.save(isSubscribe, false)
    }

    fun isNeedToShowAds(): Boolean {
//        com.example.app.ads.helper.isNeedToShowAds=true
        
        val isProductPurchased = sp.read(isNeedToShow, false)
        val isSubscribe = sp.read(isSubscribe, false)

//        if(BuildConfig.DEBUG) return false
        Log.e("IN_APP_BILLING", "isNeedToShowAds:isProductPurchased-$isProductPurchased")
        Log.e("IN_APP_BILLING", "isNeedToShowAds:isSubscribe-$isSubscribe")
        if(isProductPurchased || isSubscribe) return false
        else return true
    }

/*

    // [START Save & Get Cover Category]
    fun Context.saveCoverCategoryImages(categoryId: String, coverCategorImages: List<CoverCategoryImages>) {
        val jsonString = Gson().toJson(coverCategorImages)
        SPUtil(this).save(categoryId, jsonString)
    }

    fun Context.getCoverCategoryImages(categoryId: String): List<CoverCategoryImages> {
        val jsonString = SPUtil(this).getString(categoryId, "")
        return if (jsonString.isNullOrEmpty() || jsonString.isNullOrBlank()) {
            emptyList()
        } else {
            val itemType = object : TypeToken<List<CoverCategoryBackgrounds>>() {}.type
            Gson().fromJson(jsonString, itemType)
        }
    }
// [END Save & Get Cover Category]
*/



    /**
     *   SharedPreferences helper class
     */
    private inner class SharedPreferences//  Default constructor
    internal constructor(private val mActivity: Context) {
        private val myPreferences = "ads_pref"

        //  Save boolean value
        fun save(key: String, value: Boolean) {
            val editor = mActivity.getSharedPreferences(myPreferences, 0).edit()
            editor.putBoolean(key, value)
            editor.apply()
        }

        //  Read Boolean value
        fun read(key: String, defValue: Boolean): Boolean {
            return mActivity.getSharedPreferences(myPreferences, 0).getBoolean(key, defValue)
        }

        //  Save String value
        fun save(key: String, value: String) {
            val editor = mActivity.getSharedPreferences(myPreferences, 0).edit()
            editor.putString(key, value)
            editor.apply()
        }

        //  Read String value
        fun read(key: String, defValue: String): String? {
            return mActivity.getSharedPreferences(myPreferences, 0).getString(key, defValue)
        }
    }
}