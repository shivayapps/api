package com.backup.restore.device.image.recovery.mainphotos.recoverableadapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.retriever.AlbumItem
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.bumptech.glide.Glide
import java.io.File
import java.util.*

class SimpleVideoAdapter(
    var mScanImageRecycle: RecyclerView,
    private val mContext: Context,
    private val loImageList: ArrayList<AlbumItem>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    init {
//        FullScreenRecoverableImageActivity.mSavedFiles=loImageList
//        for (imageList in loImageList) {
//            FullScreenRecoverableImageActivity.mSavedFiles=loImageList
//        }
    }
    var TAG = javaClass.simpleName

    class MyRecoverableViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvDir: TextView = view.findViewById(R.id.tvDir)
        var thumbnail: ImageView = view.findViewById(R.id.imgItem)
        var rlItem: ImageView = view.findViewById(R.id.rlItem)
        var imgType: ImageView = view.findViewById(R.id.imgType)
        var rlItemFrame: FrameLayout = view.findViewById(R.id.rlItemFrame)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.raw_image_item, parent, false)
        return MyRecoverableViewHolder(itemView)
    }

    override fun onBindViewHolder(holders: RecyclerView.ViewHolder, position: Int) {
        val holder = holders as MyRecoverableViewHolder
        Glide.with(mContext)
            .load(File(loImageList[position].path))
            .override(300, 300)
            .placeholder(R.drawable.img_thumb)
            .into(holder.thumbnail)

        holder.tvDir.text = String.format("%s", ShareConstants.getReadableFileSize(File(loImageList[position].path).length()))
//        holder.rlItem.isSelected = loImageList[position].isSelected

        holder.imgType.visibility=View.VISIBLE
        holder.rlItemFrame.setOnClickListener {


            MyApplication.isInternalCall = true

            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            val lFileUri = FileProvider.getUriForFile(mContext, mContext.applicationContext.packageName + ".provider", File(
                loImageList[position].path))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.setDataAndType(lFileUri, "video/*")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            mContext.startActivity(intent)
        }

    }

    fun runLayoutAnimation() {
        val lController = AnimationUtils.loadLayoutAnimation(mContext, R.anim.layout_animation_fall_down)
        mScanImageRecycle.layoutAnimation = lController
        Objects.requireNonNull(mScanImageRecycle.adapter).notifyDataSetChanged()
        mScanImageRecycle.scheduleLayoutAnimation()
    }

    override fun getItemCount(): Int {
        return loImageList.size
    }

//    fun getSelected(pos: Int): Boolean {
//        return loImageList[pos].isSelected
//    }

//    fun getSelectedCounted(): Int {
//        val selectedList = loImageList.filter { it.isSelected }
//        return selectedList.size
//    }

    override fun getItemViewType(position: Int): Int {
        return if (itemCount > 0) {
            position
        } else super.getItemViewType(position)
    }
}