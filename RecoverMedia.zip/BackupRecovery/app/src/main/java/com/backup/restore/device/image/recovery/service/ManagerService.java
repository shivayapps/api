package com.backup.restore.device.image.recovery.service;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.main.NewHomeActivity;
import com.backup.restore.device.image.recovery.mainapps.asynctask.AutoCleanTrashAsyncTask;
import com.backup.restore.device.image.recovery.receiver.RebootBroadcastReceiver;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

//import com.example.appcenter.utilities.ConstantsKt;

public class ManagerService extends Service {

    public static final String b = ManagerService.class.getSimpleName();
    final Messenger a = new Messenger(new a());
    private BroadcastReceiver d = null;
    private BroadcastReceiver e = null;
    public Messenger f = null;
    public static Activity myActivity;
    private ServiceConnection g = new ServiceConnection() {
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Messenger unused = ManagerService.this.f = new Messenger(iBinder);
            Log.e("TAG", "onServiceConnectedunused: " + unused);
        }

        public void onServiceDisconnected(ComponentName componentName) {
            Messenger unused = ManagerService.this.f = null;
            Log.e("TAG", "onServiceDisconnected: " + unused);

        }
    };

    public static void setData(@NotNull Activity mainActivity2) {
        myActivity=mainActivity2;
        Log.e("TAG1c", "setDatata:000 "+myActivity );
    }


    public static class PreferenceChangeBroadcastReceiver extends BroadcastReceiver {
        private static final String a = PreferenceChangeBroadcastReceiver.class.getSimpleName();
        private ManagerService b;

        public PreferenceChangeBroadcastReceiver() {
        }

        public PreferenceChangeBroadcastReceiver(ManagerService managerService) {
            Log.e("TAG", "PreferenceChangeBroadcastReceiver  managerService : " + managerService);

            this.b = managerService;
        }

        public void onReceive(Context context, Intent intent) {
            Log.e("TAG", "onReceive: " + intent.getData());

            try {
                if (this.b == null) {
                    return;
                }
                if (this.b.f == null) {
                    boolean unused = this.b.b();
                }

                Log.e("TAG", "onReceive: this.mSimpleDateFormate.f ==>>" + this.b.f);
                Log.e("ISSUE ", "strating 1234 : ");

                if (this.b.f != null) {
                    Bundle a2 = this.b.a(this.b.c());
                    Message obtain = Message.obtain((Handler) null, 2, 0, 0);
                    obtain.setData(a2);
                    this.b.f.send(obtain);
                }
            } catch (RemoteException e) {
            }
        }
    }


    class a extends Handler {
        a() {
            Log.e("TAG", "myfrgamant: ");

        }

        public void handleMessage(Message message) {

            Log.e("TAG", "message.what: " + message.what);
            Log.e("TAG", "message.what: ===>>>>>  " + ManagerService.this.f);

            switch (message.what) {
                case 1:
                    try {
                        if (ManagerService.this.f == null) {
                            Log.e("TAG", "handleMessage: Service Messenger is null");
                            break;
                        } else {

                            File file = new File(Environment.getExternalStorageDirectory().getPath());
                            File[] files = file.listFiles();
                            if (files != null) {
                                if (files.length != 0) {
                                    String[] c = ManagerService.this.c(files.length);

                                    int i = 0;
                                    for (File f : files) {

                                        if (!f.getAbsolutePath().equalsIgnoreCase("/storage/emulated/0/Android")) {
                                            Log.e("GAYE", "handleMessage:f.getAbsolutePath() " + f.getAbsolutePath() + "   ii-->" + i);
                                            c[i] = f.getAbsolutePath();
                                            i++;
                                            if (f.isFile() || f.isDirectory()) {

                                            }
                                        }

                                    }
                                    Bundle a2 = ManagerService.this.a(c);
                                    Message obtain = Message.obtain((Handler) null, 2, 0, 0);
                                    obtain.setData(a2);
                                    ManagerService.this.f.send(obtain);
                                    break;
                                }
                            }
                        }
                    } catch (RemoteException e) {
                        e.printStackTrace();
                        break;
                    }
            }
            super.handleMessage(message);
        }
    }

    public static class b extends BroadcastReceiver {
        private static final String a = b.class.getSimpleName();
        private ManagerService b;
        private Activity b1;

        public b() {

        }

        public b(ManagerService managerService) {
            this.b = managerService;
        }

        public void onReceive(Context context, Intent intent) {

            try {
                if (this.b == null) {
                    return;
                }
                if (this.b.f == null) {
                    boolean unused = this.b.b();
                }
                if (this.b.f != null) {
                    Log.e("ISSUE ", "strating 12345 : ");

                    Bundle a2 = this.b.a(this.b.c());
                    Message obtain = Message.obtain((Handler) null, 2, 0, 0);
                    obtain.setData(a2);
                    this.b.f.send(obtain);
                }
            } catch (RemoteException e) {
                Log.e("TAG", "onReceive RemoteException ********************************************************* ");

                e.printStackTrace();
            }
        }
    }


    public Bundle a(String[] strArr) {
        Bundle bundle = new Bundle();
        if (strArr == null) {
            return bundle;
        }
        ArrayList arrayList = new ArrayList(strArr.length);
//        Log.e("ISSUE", "strArr ==>>: " + new Gson().toJson(strArr));

        for (String str : strArr) {
            // Log.e("ISSUE", "myfrgamant: " + str + "c value---->" + com.aainc.recyclebin.d.c.myfrgamant(str));
            if (com.aainc.recyclebin.d.c.a(str)) {
                arrayList.add(str);
            }
        }
        if (arrayList.isEmpty()) {

            com.aainc.recyclebin.storage.a a2 = (com.aainc.recyclebin.storage.a) com.aainc.recyclebin.storage.a.a();
            ArrayList<com.aainc.recyclebin.storage.a.C0027a> c2 = a2.c();
            ArrayList<com.aainc.recyclebin.storage.a.C0027a> d2 = a2.d();
            Iterator<com.aainc.recyclebin.storage.a.C0027a> it = c2.iterator();
            if (it.hasNext()) {
                arrayList.add(it.next().b());
            }
            Iterator<com.aainc.recyclebin.storage.a.C0027a> it2 = d2.iterator();
            if (it2.hasNext()) {
                arrayList.add(it2.next().b());
            }
        }


        boolean[] zArr = new boolean[arrayList.size()];


        for (int i = 0; i < arrayList.size(); i++) {
            zArr[i] = true;
        }
        Log.e("ISSUE ", "GENRATING BUNDLE_INIT_STRING_ARRAY_LIST: " + new Gson().toJson(arrayList));
        bundle.putStringArrayList("BUNDLE_INIT_STRING_ARRAY_LIST", arrayList);
        bundle.putBooleanArray("BUNDLE_INIT_BOOLEAN_ARRAY", zArr);
        return bundle;
    }


    public boolean b() {
        Log.e("TAG", "ManagerService: ==789====>>>");
        return bindService(new Intent(this, ObserverService.class), this.g, BIND_ABOVE_CLIENT);
    }


    public String[] c() {
        Exception e2;
        String[] strArr;
        String[] strArr2 = {"", ""};
        try {
            SharedPreferences sharedPreferences = getSharedPreferences("com.aainc.recyclebin", 0);
            strArr = new String[4];

            for (int i = 0; i < strArr.length; i++) {
                strArr[i] = sharedPreferences.getString("preference.input_path_" + i + 1, (String) null);
            }

        } catch (Exception e4) {
            Exception exc = e4;
            strArr = strArr2;
            e2 = exc;
            return strArr;
        }
        return strArr;
    }

    public String[] c(int size) {
        Exception e2;
        String[] strArr;

        String[] strArr2 = {"", ""};

        try {
            SharedPreferences sharedPreferences = getSharedPreferences("com.aainc.recyclebin", 0);
            strArr = new String[size];
            try {
                for (int i = 0; i < strArr.length; i++) {
                    String a = "preference.input_path_" + (i + 1);
                    strArr[i] = sharedPreferences.getString(a, (String) null);
                    Log.e("GAYE", "c: " + a);
                }
            } catch (Exception e3) {
                e3.printStackTrace();
                e2 = e3;
                return strArr;
            }
        } catch (Exception e4) {
            Exception exc = e4;
            strArr = strArr2;
            e2 = exc;
            return strArr;
        }
        return strArr;
    }


    @Override
    public IBinder onBind(Intent intent) {
        Log.e("TAG", "onBind: call thyc hc" + this.a.getBinder());
        return this.a.getBinder();
    }

    String mChannelId = "RecoveryForegroundServiceChannel";

    private void a() {

        createNotificationChannel();

        Intent intent = new Intent(this, NewHomeActivity.class);
        intent.putExtra("notification", "hide");
        PendingIntent lPendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, mChannelId)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.protecting_your_deleted_image))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setSmallIcon(R.drawable.ic_noti)
                .setContentIntent(lPendingIntent)
                .setPriority(NotificationCompat.PRIORITY_MIN).setContent(null).build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                notification.color = getColor(R.color.colorPrimary);
        }

        startForeground(1500, notification);

//        Intent intent = new Intent(this, NewHomeActivity.class);
//        intent.putExtra("notification", "hide");
//        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, 0);

//        NotificationCompat.Builder bVar = new NotificationCompat.Builder(this, mChannelId);
//        bVar.setSmallIcon(R.drawable.ic_icon);
//        bVar.setContentTitle(getString(R.string.app_name));
//        bVar.setPriority(NotificationManager.IMPORTANCE_MIN);
//        bVar.setContent(null);
//        bVar.setCategory(Notification.CATEGORY_SERVICE);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            bVar.setColor(ContextCompat.getColor(this, R.color.colorPrimary));
//        }
//        bVar.setContentText();
//        bVar.setContentIntent(activity);
//        startForeground(1500, bVar.build());
    }


    private void junkReminder() {
        Calendar calendar = Calendar.getInstance();
        long currentTime = calendar.getTimeInMillis();

        String interval=SharedPrefsConstant.getString(this,"cleanTrashInterval","off");
        Log.e("junkReminder", "interval:"+interval);

        if(interval.equals("off")) {
            // off
//        } else if(interval.equals("1week") && !ConstantsKt.isAppInForeground) {
        } else if(interval.equals("1week")) {
            // 1 week
//            long nextNotification = SharedPrefsConstant.getLong(this,"NextTimeToCleanTrash");
//            if (currentTime > nextNotification) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        calendar.add(Calendar.HOUR, 12);
//                        calendar.add(Calendar.HOUR, 24 * 7);
//                        calendar.add(Calendar.MINUTE, 10);
                        SharedPrefsConstant.save(getApplicationContext(), "NextTimeToCleanTrash",calendar.getTimeInMillis());
                        new AutoCleanTrashAsyncTask(getApplicationContext(),"",a("/"),7).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    }
                });
//            }
//        } else if(interval.equals("1month") && !ConstantsKt.isAppInForeground) {
        } else if(interval.equals("1month")) {
            // 1 month
//            long nextNotification = SharedPrefsConstant.getLong(this,"NextTimeToCleanTrash");
//            if (currentTime > nextNotification) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        calendar.add(Calendar.HOUR, 12);
//                        calendar.add(Calendar.HOUR, 24 * 30);
//                        calendar.add(Calendar.MINUTE, 10);
                        SharedPrefsConstant.save(getApplicationContext(),"NextTimeToCleanTrash",calendar.getTimeInMillis());
                        new AutoCleanTrashAsyncTask(getApplicationContext(),"",a("/"),30).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    }

                });
//            }
//        } else if(interval.equals("3month") && !ConstantsKt.isAppInForeground) {
        } else if(interval.equals("3month")) {
            // 3 month
//            long nextNotification = SharedPrefsConstant.getLong(this,"NextTimeToCleanTrash");
//            if (currentTime > nextNotification) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        calendar.add(Calendar.HOUR, 12);
//                        calendar.add(Calendar.HOUR, 24 * 90);
//                        calendar.add(Calendar.MINUTE, 10);
                        SharedPrefsConstant.save(getApplicationContext(),"NextTimeToCleanTrash",calendar.getTimeInMillis());
                        new AutoCleanTrashAsyncTask(getApplicationContext(),"",a("/"),90).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                    }
                });
//            }
        }
    }


    public String a(String str) {
        if (str == null) {
            throw new IllegalArgumentException("Parameter is invalid. File path can't be null.");
        }
        StringBuilder sb = new StringBuilder();
        try {


            String mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "DCIM/Backup And Recovery" ;
            sb.append(mRootPath);

        } catch (IllegalArgumentException | NullPointerException e) {
            String mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "DCIM/Backup And Recovery" ;
            sb.append(mRootPath);
        }

        sb.append(File.separator);
        sb.append(".trash");
        sb.append(File.separator);
        return sb.toString();
    }

//    private void autoCleanTrash() {
//        String mRootPath = a("/");
//        List<File> fList=Utils.getListAllFiles(mRootPath);
//    }

    private void notifyReminder(
            Context context,
            int id,
            String title,
            String body,
            int icon,
            PendingIntent pendingIntent
    ) {

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, channel())
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        notificationManager.notify(id, notificationBuilder.build());

    }

    private PendingIntent activityPendingIntent() {
        Intent notifyIntent = new Intent(this, NewHomeActivity.class);
        notifyIntent.putExtra("ID", 200);
        notifyIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent pendingIntent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingIntent=PendingIntent.getActivity(
                    this,
                    0,
                    notifyIntent,
                    PendingIntent.FLAG_IMMUTABLE
            );
        } else {
            pendingIntent=PendingIntent.getActivity(
                    this,
                    0,
                    notifyIntent,
                    PendingIntent.FLAG_IMMUTABLE
            );
        }

        return pendingIntent;
    }

    private String channel()  {
        String channelId = "";
        NotificationManager notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            channelId = "Channel Reminder";
            String channelName = "channel is created to remind preferences set by user in this application";
            NotificationChannel channel = new NotificationChannel(
                    channelId, channelName,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationManager.createNotificationChannel(channel);
        }
        return channelId;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(mChannelId, "My Recovery Background Service", NotificationManager.IMPORTANCE_NONE);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE) ;
            manager.createNotificationChannel(serviceChannel);
        }
    }

//    private ServiceLifecycleDispatcher dispatcher;// = ServiceLifecycleDispatcher(this);

    @Override
    public void onCreate() {
        this.e = new PreferenceChangeBroadcastReceiver(this);

        RebootBroadcastReceiver myBroadCastReciever = new RebootBroadcastReceiver();

        Log.e("TAG", "onCreate:myBroadCastReciever in service  "+myBroadCastReciever );

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BOOT_COMPLETED);
        filter.addAction("android.intent.action.QUICKBOOT_POWERON");
        registerReceiver(myBroadCastReciever, filter);

        a();


//        dispatcher = new ServiceLifecycleDispatcher(this);

        registerReceiver(this.e, new IntentFilter("com.aainc.recyclebin.PREFERENCES_CHANGED"));

        if (this.f == null) {
            boolean unused = this.b();
        }
        ManagerService.this.d = new b(ManagerService.this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_MEDIA_MOUNTED);
        intentFilter.addAction(Intent.ACTION_MEDIA_UNMOUNTABLE);
        intentFilter.addAction(Intent.ACTION_MEDIA_EJECT);
        intentFilter.addAction(Intent.ACTION_MEDIA_REMOVED);
        registerReceiver(ManagerService.this.d, intentFilter);

    }

    public void checkJunkAutoClean(@NotNull Activity mainActivity2) {
        myActivity=mainActivity2;
        Calendar calendar = Calendar.getInstance();
        long currentTime = calendar.getTimeInMillis();

        long nextNotification = SharedPrefsConstant.getLong(mainActivity2,"NextTimeToCleanTrash");
        Log.e("junkReminder", "currentTime:"+currentTime);
        Log.e("junkReminder", "nextNotification:"+nextNotification);
//        if (currentTime > nextNotification) {
//            junkReminder();
//        }
    }

    @Override
    public void onDestroy() {
        Log.e("TAG", "onDestroy: ");

        if (this.g != null) {
            unbindService(this.g);
        }
//        dispatcher.onServicePreSuperOnDestroy();
        stopService(new Intent(this, ObserverService.class));
        unregisterReceiver(this.e);
        unregisterReceiver(this.d);
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int i, int i2) {
        new Thread(new Runnable() {
            public void run() {
                Log.e("TAG", "onStartCommand *** ObserverService");
                Log.e("TAG1c", "setDatata:123 "+myActivity );
                ObserverService.setDatata(myActivity);
                startService(new Intent(ManagerService.this.getApplicationContext(), ObserverService.class));
            }
        }).start();
//        dispatcher.onServicePreSuperOnStart();
        return START_STICKY;
    }
}
