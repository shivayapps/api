package com.backup.restore.device.image.recovery.mainapps.fragment

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper

/**
 * A placeholder fragment containing a simple view.
 */
class WifiFragmentNew : Fragment() {
    var rootView: View? = null

    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        @JvmStatic
        fun newInstance(): WifiFragmentNew {
            val fragment = WifiFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()

        getNetworkInfo()

        if (AdsManager(requireActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(requireActivity())) {

//            NativeAdvancedModelHelper(requireActivity()).loadNativeAdvancedAd(
//                NativeAdsSize.Big,
//                rootView?.findViewById(R.id.ad_view_container)!!

////                , isAdLoaded = {
////                    Handler(Looper.getMainLooper()).postDelayed({
////                        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
////                        scrollMain.smoothScrollTo(0,0)
////                    },500)
////                }
//            )
            NativeAdHelper(requireContext(), rootView?.findViewById(R.id.adview)!!, NativeLayoutType.NativeMedium).loadAd()
        } else {
            rootView?.findViewById<FrameLayout>(R.id.adview)?.visibility = View.GONE
        }

//        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
//        scrollMain.scrollTo(0,0)
        return rootView
    }

    private fun getNetworkInfo(): Unit {
        ivType!!.setImageResource(R.drawable.ic_wifi)
        tvTitle!!.text = getString(R.string.network_information)
        tvSubTitle!!.text = getString(R.string.wifi)
        tvTitle!!.isSelected=true
        tvSubTitle!!.isSelected=true

        val parents = ArrayList<ParentModel>()
        val pIndex=0

        parents.add(ParentModel(resources.getString(R.string.network_information),ArrayList<FeaturesHW>()))
        val lists: ArrayList<FeaturesHW> = parents.get(pIndex).lists


        if (Utils.isNetworkConnected(activity)) {
            lists.add(FeaturesHW(getString(R.string.connection_status), "${getString(R.string.connect)}"))
        } else {
            lists.add(FeaturesHW(getString(R.string.connection_status), "${getString(R.string.disconnect)}"))
        }

        if (Utils.isWifiConnected(activity) == context?.getString(R.string.wifi)) {
            val wifiManager = context?.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val wifiInfo = wifiManager.connectionInfo
            tvSubTitle?.text = context?.getString(R.string.wifi)

            lists.add(FeaturesHW(getString(R.string.data_type), "WIFI"))
            lists.add(FeaturesHW(getString(R.string.network_type), "WIFI"))
            lists.add(FeaturesHW(getString(R.string.ip_address), "${getProperText(getIPAddress())}"))
            lists.add(FeaturesHW(getString(R.string.mac_address), "${getProperText(Utils.getMACAddress("wlan0"))}"))
            lists.add(FeaturesHW(getString(R.string.ssid), "${getProperText(wifiInfo.ssid)}"))
            lists.add(FeaturesHW(getString(R.string.link_speed), "${wifiInfo.linkSpeed.toString()+context?.getString(R.string.mbps)}"))
        }
        else if (Utils.isWifiConnected(activity) == context?.getString(R.string.network)) {
            tvSubTitle?.text = context?.getString(R.string.network)

            lists.add(FeaturesHW(getString(R.string.data_type), "${getString(R.string.network)}"))
            lists.add(FeaturesHW(getString(R.string.network_type), "${getString(R.string.network)}"))
            lists.add(FeaturesHW(getString(R.string.ip_address), "${getProperText(getIPAddress())}"))
            lists.add(FeaturesHW(getString(R.string.mac_address), "${getProperText(Utils.getMACAddress("eth0"))}"))
            lists.add(FeaturesHW(getString(R.string.ssid), "${context?.getString(R.string.unavailable)}"))
            lists.add(FeaturesHW(getString(R.string.link_speed), "${context?.getString(R.string.unavailable)}"))
        }
        else {
            tvSubTitle?.text = context?.getString(R.string.unavailable)

            lists.add(FeaturesHW(getString(R.string.data_type), "${getString(R.string.unavailable)}"))
            lists.add(FeaturesHW(getString(R.string.network_type), "${getString(R.string.unavailable)}"))
            lists.add(FeaturesHW(getString(R.string.ip_address), "${getIPAddress()}"))
            lists.add(FeaturesHW(getString(R.string.mac_address), "${context?.getString(R.string.unavailable)}"))
            lists.add(FeaturesHW(getString(R.string.ssid), "${context?.getString(R.string.unavailable)}"))
            lists.add(FeaturesHW(getString(R.string.link_speed), "${context?.getString(R.string.unavailable)}"))
        }

        val adapter = ParentAdapter(parents, requireContext())
        rvFeatureList?.adapter = adapter

        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        Handler(Looper.getMainLooper()).postDelayed({
            scrollMain.scrollTo(0,0)
        },100)
//        setEmptyText(tvConnectionStatus)
//        setEmptyText(tvDataType)
//        setEmptyText(tvNetworkType)
//        setEmptyText(tvSubTitle)
//        setEmptyText(tvIpAddress)
//        setEmptyText(tvMACAddress)
//        setEmptyText(tvSSID)
//        setEmptyText(tvLinkSpeed)
    }



    private fun getIPAddress() : String {
        if (Utils.isNetworkConnected(activity)) {
            return Utils.getIPAddress(true)
        } else {
            return getString(R.string.unavailable)
        }
    }

    private fun getProperText(textValue: String?) : String {
        if(textValue.isNullOrEmpty()) {
            return getString(R.string.unavailable)
        } else return textValue
    }

    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

}