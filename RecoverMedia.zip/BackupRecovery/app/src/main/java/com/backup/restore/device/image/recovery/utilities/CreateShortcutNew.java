package com.backup.restore.device.image.recovery.utilities;

import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.widget.Toast;

import com.backup.restore.device.image.recovery.R;

public class CreateShortcutNew {

    Context mContext;
    public CreateShortcutNew(Context context){
        mContext=context;
    }

    public void addShortCut(String str) {
        try {
//            C3310c C = mo16691C(str);

            PackageManager packageManager = mContext.getPackageManager();
            BitmapDrawable iconBitmap = (BitmapDrawable) packageManager.getApplicationIcon(str);
            String appName = packageManager.getApplicationInfo(str, 0).loadLabel(packageManager).toString();

            if (Build.VERSION.SDK_INT >= 26) {
                ShortcutInfo.Builder builder = new ShortcutInfo.Builder(mContext, mContext.getString(R.string.app_name));
                builder.setShortLabel(appName);
                builder.setLongLabel(appName);
                builder.setIcon(Icon.createWithBitmap(iconBitmap.getBitmap()));
                Intent launchIntentForPackage = packageManager.getLaunchIntentForPackage(str);
                launchIntentForPackage.setAction("android.intent.action.MAIN");
                builder.setIntent(launchIntentForPackage);
                ((ShortcutManager) mContext.getSystemService(ShortcutManager.class)).requestPinShortcut(builder.build(), (IntentSender) null);
                return;
            }
//            String str2 = C.f21662l;
            Intent launchIntentForPackage2 = packageManager.getLaunchIntentForPackage(str);
            launchIntentForPackage2.setAction("android.intent.action.MAIN");
            Intent intent = new Intent();
            intent.putExtra("android.intent.extra.shortcut.INTENT", launchIntentForPackage2);
            intent.putExtra("android.intent.extra.shortcut.NAME", appName);
            intent.putExtra("android.intent.extra.shortcut.ICON", (iconBitmap.getBitmap()));
            intent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            mContext.sendBroadcast(intent);
            new Handler().postDelayed(new C3298a(), 1000);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(mContext, "Sorry, Can't create a shortcut for this app.", Toast.LENGTH_SHORT).show();
        }
    }


    class C3298a implements Runnable {
        C3298a() {
        }

        public void run() {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.HOME");
            intent.setFlags(268435456);
            mContext.startActivity(intent);
        }
    }
}
