package com.backup.restore.device.image.recovery.main

import android.app.Dialog
import android.content.*
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.adshelper.AdsManager
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.RecoverableImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.RecoveredImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.TrashImageActivity
import com.backup.restore.device.image.recovery.service.ManagerService
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.isMyServiceRunning
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityScanningBinding

class ProgressbarActivity : MyCommonBaseActivity() {
    var refreshMediaBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent!!.action == "com.progress.count.Refresh") {
                var count = intent.getLongExtra("count", 0)
//                Log.d("554654", "onReceive: count -> $count")
                if (binding.tvCount != null) {
                    binding.tvCount.visibility = View.VISIBLE
                    binding.tvCount.text = count.toString()
                }
            }
        }
    }

    var backupClick=1

    lateinit var binding:ActivityScanningBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_scanning)
        binding=ActivityScanningBinding.inflate(layoutInflater)
        setContentView(binding.root)


        registerReceiver(refreshMediaBroadcast, IntentFilter("com.progress.count.Refresh"))

        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium).loadAd()
//            NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
//                NativeAdsSize.Big,
//                findViewById(R.id.ad_view_container)
//            )
        } else {
            binding.adview.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(refreshMediaBroadcast)
    }

    override fun getContext(): AppCompatActivity {
        return this@ProgressbarActivity
    }


    override fun initData() {
        binding.tvScanning1.setText(R.string.please_wait)
        binding.tvScanning2.setText(R.string.scanning_is_depend_on_files)
        binding.tvCount.visibility = View.GONE

        if(intent.hasExtra("backupClick")) {
            backupClick=intent.getIntExtra("backupClick",1)
            Log.e("goToNextActivity", "backupClick_001:" + backupClick)
        }

    }

    override fun initActions() {
        if (!isMyServiceRunning(this, ManagerService::class.java)) {
            SharedPrefsConstant.savePrefNoti(mContext, "IsFromService", true)
            ManagerService.setData(mContext)
            startService(Intent(this, ManagerService::class.java))
            SharedPrefsConstant.savePrefNoti(mContext,"ScanningDone",true)
            Log.e("mTAG", "startServiceMethod: " + SharedPrefsConstant.getBooleanNoti(mContext, "IsFromService", false))
            return
        } else {
            SharedPrefsConstant.savePref(mContext, "AfterRecover",false)
            goToNextActivity(backupClick)
//            startActivity(Intent(applicationContext, NewRecoverImageActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("IsFromNotification", "Yes"))
        }
    }

    private fun goToNextActivity(backupClick:Int) {
        Log.e("goToNextActivity", "backupClick_002:" + backupClick)
        when(backupClick){
            1-> {
                TrashImageActivity.lastSelection = 2
                TrashImageActivity.prevFragmentPos = 0
                TrashImageActivity.prevPosTrash = 0
                TrashImageActivity.prevPosRecovered = 0
                TrashImageActivity.prevPosRecoverable = 0
                startActivity(
                    Intent(
                        applicationContext,
                        TrashImageActivity::class.java
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("IsFromNotification", "Yes")
                )
                finish()
            }
            2-> {
                RecoverableImageActivity.lastSelection = 1
                RecoverableImageActivity.prevFragmentPos = 0
                RecoverableImageActivity.prevPosTrash = 0
                RecoverableImageActivity.prevPosRecovered = 0
                RecoverableImageActivity.prevPosRecoverable = 0
                startActivity(
                    Intent(
                        applicationContext,
                        RecoverableImageActivity::class.java
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("IsFromNotification", "Yes")
                )
                finish()
            }
            3-> {
                RecoveredImageActivity.lastSelection = 3
                RecoveredImageActivity.prevFragmentPos = 0
                RecoveredImageActivity.prevPosTrash = 0
                RecoveredImageActivity.prevPosRecovered = 0
                RecoveredImageActivity.prevPosRecoverable = 0
                startActivity(
                    Intent(
                        applicationContext,
                        RecoveredImageActivity::class.java
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("IsFromNotification", "Yes")
                )
                finish()
            }
        }
    }

    override fun onBackPressed() {
        showAlertStopScanning()
//        super.onBackPressed()
//        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun showAlertStopScanning() {

        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.exit_scanning)
        dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.scanning_stop)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            SharedPrefsConstant.savePrefNoti(mContext, "IsFromService", false)
            Log.e("mTAG", "startServiceMethod: " + SharedPrefsConstant.getBooleanNoti(mContext, "IsFromService", false))
            dialog.cancel()
            if (!SharedPrefsConstant.getBooleanNoti(mContext, "IsFromService", false)) {
                startActivity(NewHomeActivity.newIntent(mContext))
                finish()
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()

    }

}