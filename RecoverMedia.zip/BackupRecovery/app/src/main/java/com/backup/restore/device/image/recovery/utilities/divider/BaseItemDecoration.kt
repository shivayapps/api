package com.backup.restore.device.image.recovery.utilities.divider

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.view.View
import androidx.annotation.DimenRes
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.OrientationHelper
import androidx.recyclerview.widget.RecyclerView
import java.util.*

/**
 *Date:2019/7/9
 *Author:kunkun.wang
 *Des:ItemDecoration的基类
 * 该分割线需要支持 网格 线性 瀑布布局
 * 分割线的种类 颜色 单纯的空格 drawable
 * 支持在不同的分割线位置绘制不同的视图
 **/
abstract class BaseItemDecoration constructor(build: Builder) : RecyclerView.ItemDecoration() {

    protected val tag: String = "BaseItemDecoration:"
    private val defaultColor = "#FFFFFF"

    private var paint: Paint = Paint()
    private var dividerWidth: Int = build.dividerWidth


    protected val margin: IntArray = build.margin

    /**
     * RecyclerView 顶部的间距
     */
    protected var recyclerViewTopSpace: Int = build.recyclerViewTopSpace

    /**
     * RecyclerView 尾部的间距
     */
    protected var recyclerViewBottomSpace: Int = build.recyclerViewBottomSpace

    /**
     * 绘制分割线  需要忽略顶部item的数量
     */
    protected var ignoreHeadItemCount = build.ignoreHeadItemCount

    /**
     * 绘制分割线 需要忽略尾部item的数量
     */
    protected var ignoreFooterItemCount = build.ignoreFooterItemCount

    /**
     * 是否绘制RecyclerView 第一个item 上面的分割线
     * 默认为false,如果设置true 也就是说第一个item 有两条分割线 一个是在其上面 一个在其下面
     */
    protected var isDrawFirstTopDivider: Boolean = build.isDrawFirstTopDivider


    private var dividerDrawableProvider: DividerDrawableProvider? = build.dividerDrawableProvider

    private var dividerColorProvider: DividerColorProvider? = build.dividerColorProvider

    private var dividerPaintProvider: DividerPaintProvider? = build.dividerPaintProvider

    protected var dividerSpaceProvider: DividerSpaceProvider? = build.dividerSpaceProvider

    private var dividerVisibleProvider: DividerVisibleProvider? = build.dividerVisibleProvider

    protected var orientation = build.orientation

    protected var isOnlySpace = build.isOnlySpace


    /**
     * 设置分割线绘制的长度是否依照子View的长度  默认是根据RecyclerView的长度或者高度进行绘制的
     */
    protected var dividerDrawByChild = build.dividerDrawByChild

    init {
        if (orientation != OrientationHelper.HORIZONTAL && orientation != OrientationHelper.VERTICAL) {
            throw RuntimeException("请先使用方法 Builder.setOrientation(orientation: Int),设置列表方向")
        }
    }

    protected fun isShouldShowItemDecoration(currentPosition: Int, totalCount: Int): Boolean {
        if (currentPosition < ignoreHeadItemCount) {
            return false
        }
        if (currentPosition >= (totalCount - ignoreFooterItemCount)) {
            return false
        }
        return true
    }

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        super.getItemOffsets(outRect, view, parent, state)
        //total number of views
        val itemSum = parent.adapter?.itemCount ?: parent.childCount
        //The position of the current View
        val position = parent.getChildAdapterPosition(view)
        setItemOffsets(position, itemSum, outRect, view, parent)
    }

    abstract fun setItemOffsets(
        position: Int,
        itemCount: Int,
        outRect: Rect,
        view: View,
        parent: RecyclerView
    )

    abstract fun getDrawRectBound(
        position: Int,
        itemCount: Int,
        view: View,
        parent: RecyclerView
    ): ArrayList<Rect>

    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        if (isOnlySpace || dividerSpaceProvider != null) {
            //Space divider does not draw anything
            return
        }
        val childCount = parent.childCount
        val totalCountItem = parent.adapter?.itemCount ?: parent.childCount
        // Traverse all Views to draw dividing lines
        for (index in 0 until childCount) {
            val child = parent.getChildAt(index)
            //The position of the child View in the adapter
            val childPosition = parent.getChildAdapterPosition(child)
            //no need to draw
            if (this is LinerItemDecoration && !isShouldShowItemDecoration(
                    childPosition,
                    totalCountItem
                )
            ) return
            if ((parent.layoutManager !is GridLayoutManager) && dividerVisibleProvider?.shouldHideDivider(
                    childPosition,
                    parent
                ) == true
            ) {
                //Hidden dividers Grids do not support hidden dividers
                continue
            }

            val rectBound = getDrawRectBound(
                childPosition,
                parent.adapter?.itemCount ?: parent.childCount, child, parent
            )
            if (dividerColorProvider != null) {
                val color = dividerColorProvider?.getDividerColor(childPosition, parent)
                    ?: Color.parseColor(defaultColor)
                paint.color = color
                paint.strokeWidth = dividerWidth.toFloat()
                rectBound.forEach {
                    c.drawRect(
                        it,
                        paint
                    )

                }
                continue
            }
            if (dividerPaintProvider != null) {
                paint = dividerPaintProvider?.getDividerPaint(childPosition, parent) ?: Paint()
                rectBound.forEach {
                    if (Math.abs(it.left - it.right) > Math.abs(it.top - it.bottom)) {
                        //  horizontal bar
                        c.drawLine(
                            it.left.toFloat(),
                            (it.top.toFloat() + it.bottom.toFloat()) / 2,
                            it.right.toFloat(),
                            (it.top.toFloat() + it.bottom.toFloat()) / 2, paint
                        )
                    } else {
                        // vertical bar
                        c.drawLine(
                            (it.left.toFloat() + it.right.toFloat()) / 2,
                            it.top.toFloat(),
                            (it.left.toFloat() + it.right.toFloat()) / 2,
                            it.bottom.toFloat(), paint
                        )
                    }
                }
                continue
            }
            if (dividerDrawableProvider != null) {
                val drawable = dividerDrawableProvider?.getDividerDraw(childPosition, parent)
                if (drawable != null) {
                    rectBound.forEach {
                        drawable.bounds = it
                        drawable.draw(c)
                    }
                }
                continue
            }

        }

    }


    abstract class Builder(private val mContext: Context, layoutOrientation: Int) {
        internal var orientation: Int = layoutOrientation
        internal var dividerWidth: Int = 9


        internal val margin: IntArray = intArrayOf(0, 0, 0, 0)

        internal var isOnlySpace: Boolean = false

        /**
         * Whether to draw the dividing line above the first item of RecyclerView
         * The default is false, if it is set to true, that means the first item has two dividing lines, one is above it and the other is below it
         */
        internal var isDrawFirstTopDivider: Boolean = false


        internal var dividerDrawByChild: Boolean = false

        /**
         * Spacing at the top of RecyclerView
         */
        internal var recyclerViewTopSpace: Int = 0

        /**
         * Spacing at the end of RecyclerView
         */
        internal var recyclerViewBottomSpace: Int = 0

        /**
         * To draw a dividing line, the number of items at the top needs to be ignored
         */
        internal var ignoreHeadItemCount = 0

        /**
         * To draw a dividing line, the number of trailing items needs to be ignored
         */
        internal var ignoreFooterItemCount = 0


        internal var dividerDrawableProvider: DividerDrawableProvider? = null

        internal var dividerColorProvider: DividerColorProvider? = null

        internal var dividerPaintProvider: DividerPaintProvider? = null

        internal var dividerSpaceProvider: DividerSpaceProvider? = null

        internal var dividerVisibleProvider: DividerVisibleProvider? = null


        /**
         * If you set margin or padding directly to RecyclerView, the margin and padding are not in the sliding area,
         * Set the extra space at the top for the first item here
         * Set the spacing at the top of the RecyclerView
         */
        fun setRecyclerViewTopSpacePx(recyclerViewTopSpace: Int): Builder {
            this.recyclerViewTopSpace = recyclerViewTopSpace
            return this
        }

        /**
         * If you set margin or padding directly to RecyclerView, the margin and padding are not in the sliding area,
         * Set the extra space at the end for the first item here
         * Set the spacing at the rear of the RecyclerView
         */
        fun setRecyclerViewBottomSpacePx(recyclerViewBottomSpace: Int): Builder {
            this.recyclerViewBottomSpace = recyclerViewBottomSpace
            return this
        }

        /**
         * Set the number of items RecyclerView ignores the dividing line from the first item
         */
        fun setIgnoreHeadItemCount(ignoreHeadItemCount: Int): Builder {
            this.ignoreHeadItemCount = ignoreHeadItemCount
            return this
        }

        /**
         * Set the number of items RecyclerView ignores the dividing line from the last item
         */
        fun setIgnoreFootItemCount(ignoreFooterItemCount: Int): Builder {
            this.ignoreFooterItemCount = ignoreFooterItemCount
            return this
        }

        fun setIsDrawFirstItemTopDivider(isDraw: Boolean): Builder {
            this.isDrawFirstTopDivider = isDraw
            return this
        }

        /**
         * Set the height of the dividing line
         */
        fun setDividerWidth(@DimenRes dividerWidth: Int): Builder {
            this.dividerWidth = mContext.resources.getDimension(dividerWidth).toInt()
            return this
        }


        /**
         * Set the height of the dividing line
         */
        fun setDividerWidthPx(dividerWidth: Int): Builder {
            this.dividerWidth = dividerWidth
            return this
        }


        /**
         * Set the peripheral margin of the dividing line
         * @param leftMargin left margin
         * @param topMargin top margin
         * @param rightMargin right margin
         * @param bottomMargin bottom margin
         */
        fun setDividerMargin(
            @DimenRes leftMargin: Int,
            @DimenRes topMargin: Int,
            @DimenRes rightMargin: Int,
            @DimenRes bottomMargin: Int
        ): Builder {
            if (mContext.resources == null) {
                return this
            }
            return setDividerMarginPx(
                mContext.resources.getDimension(leftMargin).toInt(),
                mContext.resources.getDimension(topMargin).toInt(),
                mContext.resources.getDimension(rightMargin).toInt(),
                mContext.resources.getDimension(bottomMargin).toInt()
            )
        }

        fun setDividerMarginPx(
            leftMargin: Int,
            topMargin: Int,
            rightMargin: Int,
            bottomMargin: Int
        ): Builder {
            margin[0] = leftMargin
            margin[1] = topMargin
            margin[2] = rightMargin
            margin[3] = bottomMargin
            return this
        }

        fun setDividerDrawableProvider(dividerDrawableProvider: DividerDrawableProvider): Builder {
            this.dividerDrawableProvider = dividerDrawableProvider
            return this
        }

        fun setDividerColorProvider(dividerColorProvider: DividerColorProvider): Builder {
            this.dividerColorProvider = dividerColorProvider
            return this
        }

        fun setDividerPaintProvider(dividerPaintProvider: DividerPaintProvider): Builder {
            this.dividerPaintProvider = dividerPaintProvider
            return this
        }

        /**
         * Set space divider and size but grid divider is not supported
         */
        fun setDividerSpaceProvider(dividerSpaceProvider: DividerSpaceProvider): Builder {
            this.dividerSpaceProvider = dividerSpaceProvider
            return this
        }

        /**
         * Set to hide some dividing lines
         * But it should be noted that the grid dividing line does not support this form
         */
        fun setDividerVisibleProvider(dividerVisibleProvider: DividerVisibleProvider): Builder {
            this.dividerVisibleProvider = dividerVisibleProvider
            return this
        }

        fun setDividerDrawByChild(drawByChild: Boolean): Builder {
            dividerDrawByChild = drawByChild
            return this
        }

        fun setIsOnlySpace(onlySpace: Boolean): Builder {
            isOnlySpace = onlySpace
            return this
        }


        abstract fun build(): BaseItemDecoration

    }

    interface DividerDrawableProvider {
        fun getDividerDraw(position: Int, parent: RecyclerView): Drawable
    }

    interface DividerColorProvider {
        fun getDividerColor(position: Int, parent: RecyclerView): Int
    }

    interface DividerPaintProvider {
        fun getDividerPaint(position: Int, parent: RecyclerView): Paint
    }

    /**
     * Space dividing line This dividing line can set the height of different dividing lines, but this dividing line can only be applied to linear dividing lines. For grid dividing lines, please use the dividerWidth property to set the interval.
     */
    interface DividerSpaceProvider {
        fun getDividerSpace(position: Int, parent: RecyclerView): Int
    }


    interface DividerVisibleProvider {
        fun shouldHideDivider(position: Int, parent: RecyclerView): Boolean
    }

    /**
     * Get the height of the dividing line that needs to be drawn
     */
    protected fun getDrawableHeight(position: Int, parent: RecyclerView): Int {
        if (dividerDrawableProvider != null) {
            dividerDrawableProvider?.getDividerDraw(position, parent)?.apply {
                return if (orientation == OrientationHelper.HORIZONTAL) {
                    this.intrinsicWidth
                } else {
                    this.intrinsicHeight
                }
            }
        }
        return dividerWidth
    }

}