package com.backup.restore.device.image.recovery.utilities.common;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateNumberListModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SharedPrefsConstant {

    private static final String SHARED_PREFS_FILE_NAME = "backup_and_recovery";
    public static String IS_APP_IN_BACKGROUND = "IS_APP_IN_BACKGROUND";

    public static final String ITEM_SIZE = "item_size";
    public static String LAST_BACKUP = "last_backup";
    public static String AUTO_BACKUP = "auto_backup";
    public static Boolean flgNew = false;
    public static boolean isfromFake = false;
    public static String IS_ON_LOCK = "is_on_lock";
    public static final String PATTERN = "passcode";
    public static final String PASSCODE = "passcode";
    public static boolean test = false;

    public static final String LOCK = "which_lock";
    public static String isBackfromHalf = "isBackfromHalf";
    public static String BREAKS_ALERT_ENABLE = "breaks_alert_enable";
    public static boolean alreadyIN = false;
    public static String BACKUP_QUESTION = "backup quesion";
    public static String BACKUP_ANSWER = "backup answer";

    public static final String SAVEPATTERN = "passcode";
    public static final String CURRENT_FAKE_PIN_LOCK = "current_fake_pin_lock";
    public static String IS_ON_FAKE_LOCK = "is_on_fake_lock";
    public static boolean globalPause = false;
    public static String IS_SUBSCRIPTION = "IS_SUBSCRIPTION";
    public static String PRF_IS_LANGUAGE = "PRF_IS_LANGUAGE";
    public static String IS_REFRESH_HOME = "IS_REFRESH_HOME";

    public static boolean isSelfDeleted = false;

    public static String[] ImageArray = new String[]{"2bp", "360", "abm", "accountpicture-ms",
            "acorn", "afx", "agif", "agp", "apd", "apng", "apx", "art", "asw", "avatar", "awd",
            "blkrt", "bm2", "bmc", "bmp", "bss", "can", "cd5", "cdg", "cin", "cit", "colz", "cpc",
            "cpg", "cps", "cpt", "csf", "dcm", "dds", "dib", "djvu", "dm3", "dmi", "dpx", "dt2",
            "dtw", "dvl", "ecw", "epp", "exr", "fits", "fpos", "fpx", "gbr", "gcdp", "gif", "gih",
            "gim", "hdp", "hdr", "hdrp", "hpi", "i3d", "ipx", "itc2", "ithmb", "iwi", "j2c", "jb2",
            "jbig2", "jbr", "jia", "jng", "jp2", "jpc", "jpeg", "jpg", "jps", "jpx", "jxr", "kdi",
            "lif", "mat", "max", "mbm", "mix", "mng", "mnr", "mpf", "mpo", "mrxs", "msp", "mxi",
            "myl", "ncd", "oc3", "oc4", "oc5", "oci", "omf", "ota", "pat", "pbm", "pcd", "pcx",
            "pdd", "pdn", "pe4", "pgf", "pgm", "pi2", "pic", "picnc", "pict", "pictclipping",
            "pixadex", "pmg", "png", "pnm", "pns", "pov", "ppf", "ppm", "prw", "psb", "psd",
            "psdx", "pse", "psf", "psp", "pspbrush", "pspimage", "ptg", "ptx", "pvr", "px",
            "pxd", "pxm", "pxr", "pzp", "qmg", "qti", "qtif", "ras", "rif", "rle", "rli",
            "rpf", "s2mv", "sct", "sdr", "sid", "sig", "skitch", "skm", "spa", "spe", "sph",
            "spj", "spp", "spr", "sup", "tbn", "tex", "tg4", "tga", "thm", "thumb", "tif",
            "tiff", "tjp", "tn", "tpf", "tps", "vss", "wb1", "wbc", "wbd", "wbmp", "wbz",
            "webp", "xcf", "xpm", "yuv", "zif", "jpg"};

    public static String[] VideoArray = new String[]{"3g2", "3gp", "3gp2", "3gpp", "3p2", "890", "aaf", "aec", "aep",
            "aepx", "aetx", "ajp", "ale", "amc", "amv", "amx", "arcut", "arf", "asf", "asx", "avb", "avi", "avp", "avs",
            "avv", "axm", "bdm", "bdmv", "bdt3", "bik", "bmk", "bsf", "camproj", "camrec", "ced", "cine", "cip", "clpi",
            "cmmp", "cmmtpl", "cmproj", "cmrec", "cpi", "cst", "d2v", "d3v", "dce", "dck", "dcr", "dir", "divx", "dmsd",
            "dmsd3d", "dmsm", "dmss", "dmx", "dpa", "dpg", "dream", "dv", "dv-avi", "dvdmedia", "dvr", "dvr-ms", "dvx",
            "dxr", "dzm", "dzp", "dzt", "edl", "evo", "eye", "ezt", "f4p", "f4v", "fbr", "fbz", "fcp", "fcproject", "flc",
            "flh", "fli", "flv", "gfp", "gts", "hdmov", "hkm", "ifo", "imovieproj", "imovieproject", "ircp", "ism", "ismc",
            "ismv", "ivr", "izz", "izzy", "jss", "jts", "jtv", "m1pg", "m21", "m2p", "m2t", "m2ts", "m2v", "m4v", "mani",
            "mgv", "mj2", "mjp", "mk3d", "mkv", "mnv", "mod", "moi", "mov", "mp21", "mp4", "mpeg", "mpg", "mpgindex", "mpl",
            "mpls", "mpv", "mqv", "msdvd", "mse", "mswmm", "mts", "mtv", "mvd", "mve", "mvp", "mvy", "mxf", "mxv", "ncor",
            "nsv", "nuv", "nvc", "ogm", "ogv", "ogx", "otrkey", "pac", "pds", "pgi", "photoshow", "piv", "plproj", "pmf",
            "ppj", "prel", "pro", "prproj", "prtl", "psh", "pxv", "qtl", "qtz", "r3d", "rcd", "rcproject", "rdb", "rec",
            "rm", "rmd", "rmp", "rms", "rmvb", "roq", "rsx", "rum", "rv", "rvl", "sbk", "scc", "scm", "screenflow", "sedprj",
            "seq", "sfvidcap", "siv", "smi", "smil", "smk", "sqz", "srt", "stl", "stx", "svi", "swf", "swi", "swt", "tda3mt",
            "thp", "tivo", "tix", "tod", "tp", "tp0", "tpd", "tpr", "trp", "ts", "tsp", "ttxt", "tvs", "usf", "usm", "vc1",
            "vcpf", "vcv", "vdo", "vdr", "veg", "vep", "vf", "vfz", "vgz", "viewlet", "vlab", "vob", "vp6", "vp7", "vpj",
            "vro", "vsp", "wcp", "webm", "wlmp", "wmd", "wmmp", "wmv", "wmx", "wp3", "wpl", "wtv", "wvx", "xej", "xel",
            "xesc", "xfl", "xlmv", "xvid", "y4m", "yuv", "zm1", "zm2", "zm3", "zmv"};

    public static String[] AudioArray = new String[]{"3ga", "4mp", "8svx", "a2m", "aa", "aa3", "aac", "aax", "abc", "abm", "ac3",
            "acd", "acd-bak", "acd-zip", "acm", "act", "adg", "adt", "adts", "afc", "agm", "agr", "aif", "aifc", "aiff", "akp",
            "alc", "als", "amf", "amr", "ams", "amxd", "amz", "aob", "ape", "apl", "asd", "at3", "au", "aud", "aup", "band",
            "bap", "bdd", "bidule", "bun", "bwf", "bww", "caf", "caff", "cda", "cdda", "cdlx", "cdo", "cdr", "cel", "cfa",
            "cidb", "ckb", "conform", "copy", "cpr", "cpt", "csh", "cts", "cwb", "cwp", "dcf", "dcm", "dct", "dewf", "df2",
            "dfc", "dig", "dls", "dm", "dmf", "dmsa", "dmse", "dra", "drg", "ds2", "dsf", "dsm", "dss", "dtm", "dts", "dtshd",
            "dvf", "dwd", "efa", "efk", "efq", "efs", "efv", "emd", "emp", "emx", "esps", "f2r", "f32", "f3r", "f4a", "f64",
            "fdp", "fev", "flac", "flp", "frg", "fsb", "fsm", "ftm", "fzf", "fzv", "g721", "g723", "g726", "gbs", "gig", "gp5",
            "gpbank", "gpk", "gpx", "groove", "gsm", "hsb", "ics", "iff", "igp", "isma", "iti", "k26", "kar", "kfn", "koz", "kpl",
            "krz", "ksf", "kt3", "logic", "lso", "lwv", "m3u", "m3u8", "m4a", "m4b", "m4p", "m4r", "ma1", "mbr", "med", "mgv", "mid",
            "midi",
            "miniusf", "mka", "mmf", "mmm", "mmp", "mo3", "mod", "mp2", "mp3", "mpa", "mpc", "mpdp", "mpga", "mscz", "mte",
            "mtf", "mti", "mtm", "mtp", "mts", "mus", "mux", "mx5", "mxmf", "myr", "nbs", "ncw", "nkb", "nkc", "nki", "nkm",
            "nks", "nkx", "nra", "nrt", "nsa", "nsf", "nst", "ntn", "nwc", "odm", "oga", "ogg", "okt", "oma", "omf", "omg",
            "omx", "opus", "ots", "ove", "ovw", "pca", "pcast", "pcg", "peak", "pek", "pk", "pkf", "pla", "pls", "ply", "pna",
            "psf", "psm", "ptf", "ptm", "pts", "qcp", "r1m", "ra", "ram", "rax", "rbs", "rex", "rfl", "rip", "rmi", "rmj", "rmx",
            "rng", "rns", "rol", "rsn", "rso", "rti", "rx2", "s3i", "s3m", "sap", "sbi", "sc2", "scs11", "sd", "sd2", "sdat", "sds",
            "seq", "ses", "sesx", "sf2", "sfk", "sfl", "shn", "sib", "slp", "slx", "sma", "smf", "smp", "snd", "sng", "sou", "sppack",
            "sprg", "sseq", "stap", "stm", "stx", "sty", "svd", "swa", "sxt", "syh", "syn", "syw", "syx", "tak", "td0", "tg", "tta",
            "txw", "u", "uax", "ult", "uni", "usf", "usflib", "uw", "uwf", "vag", "vap", "vc3", "vlc", "vmd", "vmo", "voc", "vox",
            "voxal", "vpl", "vpm", "vqf", "vrf", "vsq", "vyf", "w01", "w64", "wav", "wave", "wax", "wfb", "wfd", "wfp", "wma",
            "wow", "wpk", "wpp", "wproj", "wrk", "wus", "wut", "wv", "wvc", "wve", "wwu", "xa", "xfs", "xm", "xrns", "xspf", "zpl", "zvd"};

    public static String[] DocumentArray = new String[]{"323", "abw", "asc", "azw", "azw1", "bib", "cls", "csv", "diff", "doc", "docx", "eml", "enex",
            "epub", "fdx", "htm", "html", "ics", "icz", "lit", "lst", "ltx", "mml", "mobi", "mpp",
            "mpx", "msg", "nb", "numbers", "odp", "ods", "odt", "pdf", "pdx", "pot", "pps", "ppsx", "ppt",
            "pptm", "pptx", "prc", "qpw", "qvw", "rtf", "rtx", "sdc", "sig", "sty", "tex", "text", "tpz",
            "ts", "tsv", "txt", "uls", "vdx", "wb3", "wks", "wpd", "wps", "wpt", "xfdf", "xlr", "xls", "xlsx",
            "xltm", "xltx", "xsl", "xslt", "yml"};

    public static String[] OtherArray = new String[]{"7z", "apk", "arc", "boo", "c", "c++", "cpp", "csh", "cxx", "d", "etx",
            "gcd", "h++", "hh", "hpp", "hs", "htc", "hxx", "java", "lhs", "moc", "p", "pas", "php",
            "rar", "tar", "tcl", "vcf", "vcs", "zip"};

    public static ArrayList<DuplicateNumberListModel> mDuplicateNameListFinal = new ArrayList<>();
    public static ArrayList<DuplicateNumberListModel> mDuplicateNumberListFinal = new ArrayList<>();
    public static ArrayList<DuplicateNumberListModel> mDuplicateEmailListFinal = new ArrayList<>();


    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_PRIVATE);
    }
    public static void setInitialResult(Context context) {
        System.out.println("SplashActivity: setInitialResult");
        Map<String, Integer> map = new HashMap<>();
        map.put("display", 0);
        map.put("multitouch", 0);
        map.put("flashlight", 0);
        map.put("loudspeaker", 0);
        map.put("earspeaker", 0);
        map.put("earproximity", 0);
        map.put("lightsensor", 0);
        map.put("accel", 0);
        map.put("vibration", 0);
        map.put("bluetooth", 0);
        map.put("volumeup", 0);
        map.put("volumedown", 0);
        map.put("fingerprint", 0);
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            getPrefs(context).edit().putInt(entry.getKey(), entry.getValue()).apply();
        }
    }

    public static boolean getInitial(Context context) {
        return getPrefs(context).getBoolean("initial", false);
    }

    public static void setInitial(Context context,boolean value) {
        getPrefs(context).edit().putBoolean("initial", value).apply();
    }
    public static Map<String, ?> getResults(Context context) {
        return getPrefs(context).getAll();
    }

    public static void clearPrefs(Context context) {
        getPrefs(context).edit().clear().apply();
    }

    public static boolean contain(Context context, String key) {
        return getPrefs(context).contains(key);
    }


    public static void savePref(Context context, String key, boolean value) {
        getPrefs(context).edit().putBoolean(key, value).commit();
    }

    private static SharedPreferences getPrefsNoti(Context context) {
        return context.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_MULTI_PROCESS);
    }

    public static void savePrefNoti(Context context, String key, boolean value) {
//        if(key.equals("isDeleteFromEmpty")){
//            isSelfDeleted=value;
//        } else
            getPrefsNoti(context).edit().putBoolean(key, value).commit();
    }

    public static boolean getBooleanNoti(Context context, String key, boolean defaultValue) {
//        if(key.equals("isDeleteFromEmpty")){
//            return isSelfDeleted;
//        } else
            return getPrefsNoti(context).getBoolean(key, defaultValue);
    }

    public static void saveStringNoti(Context context, String key, String value) {
        getPrefsNoti(context).edit().putString(key, value).apply();
    }

    public static String getStringNoti(Context context, String key) {
        return getPrefsNoti(context).getString(key, "");
    }


    //Get Booleans
    public static boolean getBoolean(Context context, String key) {
        return getPrefs(context).getBoolean(key, false);
    }

    //Get Booleans if not found return a predefined default value
    public static boolean getBoolean(Context context, String key, boolean defaultValue) {
        return getPrefs(context).getBoolean(key, defaultValue);
    }


    //Strings
    public static void save(Context context, String key, String value) {
        getPrefs(context).edit().putString(key, value).apply();
    }


    public static String getString(Context context, String key) {
        return getPrefs(context).getString(key, "");
    }

    public static String getString(Context context, String key, String defaultValue) {
        return getPrefs(context).getString(key, defaultValue);
    }

    //Integers
    public static void save(Context context, String key, int value) {
        getPrefs(context).edit().putInt(key, value).apply();
    }

    public static int getInt(Context context, String key) {
        return getPrefs(context).getInt(key, 0);
    }

    public static int getInt1(Context context, String key) {
        return getPrefs(context).getInt(key, -1);
    }

    public static int getInt(Context context, String key, int defaultValue) {
        return getPrefs(context).getInt(key, defaultValue);
    }

    //Floats
    public static void save(Context context, String key, float value) {
        getPrefs(context).edit().putFloat(key, value).apply();
    }

    public static float getFloat(Context context, String key) {
        return getPrefs(context).getFloat(key, 0);
    }

    public static float getFloat(Context context, String key, float defaultValue) {
        return getPrefs(context).getFloat(key, defaultValue);
    }

    //Longs
    public static void save(Context context, String key, long value) {
        getPrefs(context).edit().putLong(key, value).apply();
    }


    public static long getLong(Context context, String key) {
        return getPrefs(context).getLong(key, 0);
    }

    public static long getLong(Context context, String key, long defaultValue) {
        return getPrefs(context).getLong(key, defaultValue);
    }

    public static void removeKey(Context context, String key) {
        getPrefs(context).edit().remove(key).apply();
    }

    //Integers
    public static void saveclick(Context context, String key, int value) {
        getPrefs(context).edit().putInt(key, value).apply();
    }

    public static int getIntclick(Context context, String key) {
        return getPrefs(context).getInt(key, 0);
    }

    //get pattern
    public static String getPattern(Context context, String key) {
        return getPrefs(context).getString(key, "");
    }

    //Save pattern
    public static void savePattern(Context context, String key, String value) {
        getPrefs(context).edit().putString(key, value).commit();
    }

    public static boolean isApplicationSentToBackground(final Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = null;
        try {
            if (am != null) {
                tasks = am.getRunningTasks(1);
            }
            if (tasks != null && !tasks.isEmpty()) {
                ComponentName topActivity = tasks.get(0).topActivity;
                return !topActivity.getPackageName().equals(context.getPackageName());
            }
        } catch (Exception e) {

        }

        return false;
    }
}