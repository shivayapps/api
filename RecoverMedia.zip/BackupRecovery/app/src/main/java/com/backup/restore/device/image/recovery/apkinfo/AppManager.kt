package com.backup.restore.device.image.recovery.apkinfo

import java.util.*

/**
 * Created by Mahendra Gohil on 07-12-2021.
 * Holder for apps
 */

class AppManager {
    var userApps: MutableList<AppInfo> = ArrayList()
    var systemApps: MutableList<AppInfo> = ArrayList()
    var userAppSize: Int = 0
    var systemAppSize: Int = 0
}
