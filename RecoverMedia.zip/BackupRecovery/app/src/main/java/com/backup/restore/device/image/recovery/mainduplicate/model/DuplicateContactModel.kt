package com.backup.restore.device.image.recovery.mainduplicate.model

import android.graphics.drawable.Drawable
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.main.AppController

class DuplicateContactModel(
    var mContactId: String?,
    var mRawContactId: String?,
    var mContactName: String?,
    var mContactNumber: String?,
    var mContactEmail: String?,
    var mLookUpKey: String,
    var mIcon: Drawable? = AppController.appContext!!.resources.getDrawable(R.drawable.no_user_contact_image),
    var mIconUri: String? = ""

)