@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.mainduplicate.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainduplicate.model.EmptyFolderModel
import java.util.*

class EmptyFolderAdapter(
    var mEmptyFileList: ArrayList<EmptyFolderModel>
) : RecyclerView.Adapter<EmptyFolderAdapter.EmptyFolderView>() {

    class EmptyFolderView(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvFilePath: TextView = itemView.findViewById(R.id.filepath)
        var tvFileName: TextView = itemView.findViewById(R.id.fileName)
        var emptyFolderCheckbox: CheckBox = itemView.findViewById(R.id.emptyFolderCheckbox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmptyFolderView {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.raw_empty_file_list, parent, false)
        return EmptyFolderView(view)
    }

    override fun onBindViewHolder(holder: EmptyFolderView, position: Int) {
//        if (position < mEmptyFileList.size) {
        holder.tvFilePath.text = mEmptyFileList[position].path
        holder.tvFilePath.isSelected = true
        holder.tvFileName.text = mEmptyFileList[position].path!!.substring(mEmptyFileList[position].path!!.lastIndexOf("/") + 1)
        holder.emptyFolderCheckbox.isChecked = mEmptyFileList[position].isCheckBox

        holder.emptyFolderCheckbox.setOnCheckedChangeListener { buttonView, isChecked ->
            buttonView.setOnClickListener {
                mEmptyFileList[position].isCheckBox = isChecked
                notifyDataSetChanged()
            }

        }
//        }
    }

    override fun getItemCount(): Int {
        return mEmptyFileList.size
        Log.e("EmptyFolderAdapter", "getItemCount: " + mEmptyFileList.size)
    }

    fun toggleSelection(b: Boolean) {
        mEmptyFileList.forEach {
            it.isCheckBox = b
        }
        notifyDataSetChanged()
    }

    fun getSelectedCounted(): List<EmptyFolderModel> {
        return mEmptyFileList.filter { it.isCheckBox }
    }

//    fun updateList(mEmptyFolderList: ArrayList<EmptyFolderModel>) {
//        mEmptyFileList = mEmptyFolderList
//        notifyDataSetChanged()
//    }
//
//    fun removeItem(it: EmptyFolderModel) {
//        mEmptyFileList.remove(it)
//        notifyDataSetChanged()
//    }


}