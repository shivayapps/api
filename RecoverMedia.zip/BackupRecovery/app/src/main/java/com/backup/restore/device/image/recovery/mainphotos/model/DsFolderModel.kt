package com.backup.restore.device.image.recovery.mainphotos.model

import java.io.File

class DsFolderModel {
    var path: String? = null
    var folderName: String? = null
    var numberOfPics : Int = 0
    var firstPic: String? = null
    var folderDate: Long = 0
    var folderSize : Long = 0
    var moImageLists: ArrayList<File> = ArrayList()

    constructor() {}
    constructor(path: String?, folderName: String?) {
        this.path = path
        this.folderName = folderName
    }

//    fun addPics() {
//    }
    fun addItem(file: File) {
        numberOfPics++
        moImageLists.add(file)
    }
}