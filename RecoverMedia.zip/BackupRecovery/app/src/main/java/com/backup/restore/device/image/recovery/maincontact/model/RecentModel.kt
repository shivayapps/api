package com.backup.restore.device.image.recovery.maincontact.model

class RecentModel {
    var number: String? = null
    var callType = ""
    var callDate: String? = null
    var callTime: String? = null
    var callDuration: String? = null
    var photo: String? = null
    var name = ""
}