package com.backup.restore.device.image.recovery.filepicker.controller;

/**
 * @author akshay sunil masram
 */
public interface NotifyItemChecked {
    void notifyCheckBoxIsClicked();
}