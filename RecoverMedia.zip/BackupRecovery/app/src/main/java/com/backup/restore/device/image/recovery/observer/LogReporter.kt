package com.backup.restore.device.image.recovery.observer


import android.util.Log

class LogReporter : AnalyticsReporter {
    private val events = mutableListOf<String>()

    override fun report(event: String) {
        events.add(event)
    }

    override fun sendAllEvents() {
        events.forEach { event ->
            Log.d(this.javaClass.simpleName, event)
        }
        events.clear()
    }
}