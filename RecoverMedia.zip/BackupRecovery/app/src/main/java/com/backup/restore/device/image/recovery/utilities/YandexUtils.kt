package com.backup.restore.device.image.recovery.utilities

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.content.Context.ACTIVITY_SERVICE
import android.os.Build.VERSION.SDK_INT
import android.text.TextUtils
import android.util.Log
import androidx.annotation.Nullable
import androidx.work.impl.background.greedy.GreedyScheduler
import java.lang.reflect.Method


fun Context.isMainProcess(): Boolean {
    return TextUtils.equals(packageName, getProcessName())
}

@Nullable
private fun Context.getProcessName(): String? {
    if (SDK_INT >= 28) {
        return Application.getProcessName()
    }

    // Try using ActivityThread to determine the current process name.
    try {
        val activityThread = Class.forName("android.app.ActivityThread", false, GreedyScheduler::class.java.classLoader)
        val packageName: Any = if (SDK_INT >= 18) {
            val currentProcessName: Method = activityThread.getDeclaredMethod("currentProcessName")
            currentProcessName.isAccessible = true
            currentProcessName.invoke(null)
        } else {
            val getActivityThread: Method = activityThread.getDeclaredMethod("currentActivityThread")
            getActivityThread.isAccessible = true
            val getProcessName: Method = activityThread.getDeclaredMethod("getProcessName")
            getProcessName.isAccessible = true
            getProcessName.invoke(getActivityThread.invoke(null))
        }
        if (packageName is String) {
            return packageName
        }
    } catch (exception: Throwable) {
        Log.d("TAG", "Unable to check ActivityThread for processName", exception)
    }

    // Fallback to the most expensive way
    val pid: Int = android.os.Process.myPid()
    val am: ActivityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
    val processes: List<ActivityManager.RunningAppProcessInfo> = am.runningAppProcesses
    if (processes.isNotEmpty()) {
        for (process in processes) {
            if (process.pid == pid) {
                return process.processName
            }
        }
    }
    return null
}