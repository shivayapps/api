package com.backup.restore.device.image.recovery.mainapps.activity

import android.os.Bundle
import android.os.SystemClock
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.databinding.ActivityInformationBinding
import com.backup.restore.device.image.recovery.mainapps.asynctask.TestMethod
import com.backup.restore.device.image.recovery.mainapps.fragment.*
import com.backup.restore.device.image.recovery.mainapps.model.TestModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.RatingDialog
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.shareApp
//import com.example.app.ads.helper.GiftIconHelper
import java.util.*


class InformationActivity : MyCommonBaseActivity() {

    public var testList: ArrayList<TestModel> = ArrayList<TestModel>()

    lateinit var binding:ActivityInformationBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_information)
        binding=ActivityInformationBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val mIntent = intent
        var mType = 0
        if (mIntent.hasExtra("info_type")) {
            mType = mIntent.getIntExtra("info_type", 0)
        }


        if (!SharedPrefsConstant.getInitial(mContext)) {
            SharedPrefsConstant.setInitialResult(mContext);
            SharedPrefsConstant.setInitial(mContext,true);
        }

//        val iv_share = findViewById(R.id.iv_share)
        binding.ivShare?.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            shareApp()
        }
//        var fragment : Fragment = DeviceModelFragment.newInstance()
//        val fragment = getOldFragment(mType)
        val fragment = getNewFragment(mType)
        binding.txtTitle.isSelected = true

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.container, fragment)
            .commit()

        val testMethod = TestMethod(this@InformationActivity)
        testList = testMethod.getTestList()

        SharedPrefsConstant.save(
            mContext,
            ShareConstants.RATE_DEVICE_INFO,
            SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_DEVICE_INFO) + 1
        )
    }

    override fun getContext(): AppCompatActivity {
        return this@InformationActivity
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }

    override fun initData() {

    }

    private fun getNewFragment(mType: Int): Fragment {

        var fragment: Fragment = DeviceModelFragmentNew.newInstance()
        when (mType) {
            0 -> {
                //Type.DEVICE
                binding.txtTitle.setText(getString(R.string.device_information))
                fragment = DeviceModelFragmentNew.newInstance()
                addEvent(DeviceModelFragmentNew::class.simpleName!!)
            }
            1 -> {
                //Type.OS
                binding.txtTitle.setText(getString(R.string.os_information))
                fragment = OsInfoFragmentNew.newInstance()
                addEvent(OsInfoFragmentNew::class.simpleName!!)
            }
            2 -> {
                //Type.CPU
                binding.txtTitle.setText(getString(R.string.processor_information))
                fragment = CpuFragmentNew.newInstance()
                addEvent(CpuFragmentNew::class.simpleName!!)
            }
            3 -> {
                //Type.BATTERY
                binding.txtTitle.setText(getString(R.string.battery_information))
                fragment = BatteryFragmentNew.newInstance()
                addEvent(BatteryFragmentNew::class.simpleName!!)
            }
            4 -> {
                //Type.WIFI
                binding.txtTitle.setText(getString(R.string.wifi_information))
                fragment = WifiFragmentNew.newInstance()
                addEvent(WifiFragmentNew::class.simpleName!!)
            }
            5 -> {
                //Type.DISPLAY
                binding.txtTitle.setText(getString(R.string.display_information))
                fragment = DisplayFragmentNew.newInstance()
                addEvent(DisplayFragmentNew::class.simpleName!!)
            }
            6 -> {
                //Type.RAM
                binding.txtTitle.setText(getString(R.string.ram_information))
                fragment = RamFragmentNew.newInstance()
                addEvent(RamFragmentNew::class.simpleName!!)
            }
            7 -> {
                //Type.ROM
                binding.txtTitle.setText(getString(R.string.rom_information))
                fragment = RomFragmentNew.newInstance()
                addEvent(RomFragmentNew::class.simpleName!!)
            }
            8 -> {
                //Type.CAMERA
                binding.txtTitle.setText(getString(R.string.camera_information))
                fragment = CameraSensorFragmentNew.newInstance()
                addEvent(CameraSensorFragmentNew::class.simpleName!!)
            }
            9 -> {
                //Type.SENSOR
                binding.txtTitle.setText(getString(R.string.sensor_information))
                fragment = SensorFragmentNew.newInstance()
                addEvent(SensorFragmentNew::class.simpleName!!)
            }
            10 -> {
                //Type.TEST
                binding.txtTitle.setText(getString(R.string.device_test))
                fragment = TestsFragment.newInstance()
                addEvent(SensorFragmentNew::class.simpleName!!)
            }
        }
        return fragment
    }

    override fun initActions() {

//        if (AdsManager(mContext).isNeedToShowAds()) {
//            if (NetworkManager.isInternetConnected(mContext)) {
////                GiftIconHelper.loadGiftAd(
////                    fContext = mContext,
////                    fivGiftIcon = findViewById(R.id.main_la_gift),
////                    fivBlastIcon = findViewById(R.id.main_la_gift_blast)
////                )
//            }
//        } else {
//            binding.ivShare.visibility = View.VISIBLE
//        }

        binding.ivBack.setOnClickListener(this)
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        val isRated = ExitSPHelper(mContext).isRated()
        if (!isRated) {
            if (SharedPrefsConstant.getInt(
                    mContext,
                    ShareConstants.RATE_DEVICE_INFO
                ) >= 3 && SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_LATTER, 1) == 0
            ) {
                RatingDialog.smileyRatingDialog(mContext)
            } else {
                super.onBackPressed()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                SharedPrefsConstant.save(
                    mContext,
                    ShareConstants.RATE_DEVICE_INFO,
                    SharedPrefsConstant.getInt(mContext, ShareConstants.RATE_DEVICE_INFO) + 1
                )
            }
        } else {
            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }

//        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.iv_back -> onBackPressed()
        }
    }
}