package com.backup.restore.device.image.recovery.mainphotos.recoverdadapter

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.getShareMessage
import com.example.jdrodi.utilities.OnSingleClickListener
import java.io.File
import java.util.*

class OtherRecoveredAdapter(var mContext: Activity, mSaveList: ArrayList<File>, private val mRvAlreadyBackup: RecyclerView, private val mTv_Msg: LinearLayout, private val mIvDeleteAll: ImageView, val type: String, val needAction:Boolean = true) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        var mSavedFiles : ArrayList<File>? = null
    }

    init {
        mSavedFiles = mSaveList
    }

    class MyRecoveredViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var llDelete: LinearLayout = itemView.findViewById(R.id.llDelete)
        var llShare: LinearLayout = itemView.findViewById(R.id.llShare)
        var audioFile: ImageView = itemView.findViewById(R.id.audioFile)
        var fileName: TextView = itemView.findViewById(R.id.fileName)
        var fileSize: TextView = itemView.findViewById(R.id.fileSize)
        var filePath: TextView = itemView.findViewById(R.id.filePath)

    }

    override fun getItemCount(): Int {
        return mSavedFiles!!.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val menuItemLayoutView = LayoutInflater.from(parent.context).inflate(R.layout.raw_list_of_recovered_files_item, parent, false)
        return MyRecoveredViewHolder(menuItemLayoutView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder,  position: Int) {
        val menuItemHolder = holder as MyRecoveredViewHolder
        try {

            if (type == "Audio") {
                menuItemHolder.audioFile.setImageResource(R.drawable.ic_audios)
            } else {
                menuItemHolder.audioFile.setImageResource(R.drawable.ic_doc_file)
            }

            menuItemHolder.fileSize.text = String.format("%s", ShareConstants.getReadableFileSize(mSavedFiles!![position].length()))
            menuItemHolder.fileName.text = mSavedFiles!![position].name
            menuItemHolder.filePath.text = mSavedFiles!![position].absolutePath
            menuItemHolder.filePath.isSelected = true

            menuItemHolder.itemView.setOnClickListener(object : OnSingleClickListener() {
                override fun onSingleClick(v: View?) {
                    try {
                        MyApplication.isInternalCall = true
                        val intent = Intent()
                        intent.action = Intent.ACTION_VIEW
                        val lFileUri = FileProvider.getUriForFile(mContext, mContext.applicationContext.packageName + ".provider", File(mSavedFiles!![position].absolutePath))
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        if(type == "Audio") {
                            intent.setDataAndType(lFileUri, "audio/*")
                        }else {
                            intent.setDataAndType(lFileUri, "*/*")
                        }
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        mContext.startActivity(intent)
                    } catch (exception: ActivityNotFoundException) {

                    }
                }
            })

            if(!needAction) menuItemHolder.llDelete.visibility=View.GONE
            menuItemHolder.llDelete.setOnClickListener {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                deleteMethod(position)

            }
            menuItemHolder.llShare.setOnClickListener {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                NewRecoverImageActivity.isRefresh = false
                val uri = FileProvider.getUriForFile(mContext, mContext.packageName + ".provider", mSavedFiles!![position])
                val share = Intent(Intent.ACTION_SEND)
                if(type == "Audio") {
                    share.type = "audio/*"
                }else{
                    share.type = "*/*"
                }
                share.putExtra(Intent.EXTRA_SUBJECT, mContext.resources.getString(R.string.app_name))
                share.putExtra(Intent.EXTRA_STREAM, uri)
                share.putExtra(Intent.EXTRA_TEXT, mContext.getShareMessage())
                MyApplication.isInternalCall = true
                mContext.startActivity(Intent.createChooser(share, "Share Image"))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun deleteMethod(position: Int) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = mContext.getString(R.string.confirm_delete)
        when (type) {
            "Audio" -> {
                dialog.findViewById<TextView>(R.id.permission_text).text = mContext.getString(R.string.never_get_back_audio)
            }
            else -> {
                dialog.findViewById<TextView>(R.id.permission_text).text = mContext.getString(R.string.never_get_back_file)
            }

        }
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = mContext.getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = mContext.getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            if (mSavedFiles!![position].exists()) {
                mSavedFiles!![position].delete()
                mSavedFiles!!.removeAt(position)
                Toast.makeText(mContext, R.string.deleted_success, Toast.LENGTH_SHORT).show()

                if (mSavedFiles!!.size == 0) {
                    mRvAlreadyBackup.visibility = View.GONE
                    mTv_Msg.visibility = View.VISIBLE
                    mIvDeleteAll.isEnabled = false
                    mIvDeleteAll.alpha = 0.5f

                    if (mContext is NewRecoverImageActivity) {
                        (mContext as NewRecoverImageActivity).unSelectAll()
                    }

                } else {
                    mTv_Msg.visibility = View.GONE;
                    mRvAlreadyBackup.visibility = View.VISIBLE
                    mIvDeleteAll.isEnabled = true
                    mIvDeleteAll.alpha = 1.0f
                }
                notifyDataSetChanged()
            }
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    fun runLayoutAnimation() {
        val lController = AnimationUtils.loadLayoutAnimation(mContext, R.anim.layout_animation_fall_down)
        mRvAlreadyBackup.layoutAnimation = lController
        Objects.requireNonNull(mRvAlreadyBackup.adapter).notifyDataSetChanged()
        mRvAlreadyBackup.scheduleLayoutAnimation()
    }


}