package com.backup.restore.device.image.recovery.ads.rateandfeedback

//import com.backup.restore.device.image.recovery.jsonparsing.JsonParserCallback
//import com.example.appcenter.utilities.*
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.ProgressDialog
import android.content.*
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.backup.restore.device.image.recovery.BuildConfig
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.adapter.FeedbackAdapter
import com.backup.restore.device.image.recovery.ads.rateandfeedback.network.ModelRequestFeedback
import com.backup.restore.device.image.recovery.ads.rateandfeedback.network.ModelResponseFeedback
import com.backup.restore.device.image.recovery.databinding.ActivityFeedbackBinding
import com.backup.restore.device.image.recovery.jsonparsing.JsonParserCallback
import com.backup.restore.device.image.recovery.main.BaseActivity
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
//import com.example.gallery.AGallery
//import com.example.gallery.MimeType
//import com.example.gallery.engine.impl.GlideEngine
//import com.example.gallery.internal.entity.CaptureStrategy
import com.example.jdrodi.utilities.isOnline
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
//import kotlinx.android.synthetic.main.activity_feedback.*
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import java.io.*

private val permission_gallery = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
private const val REQUEST_CODE_CHOOSE = 101
private const val KEY_SMILE = "key_smile"
private const val KEY_REASON = "key_reason"


class FeedbackActivity : BaseActivity() {
    val TAG = javaClass.simpleName
    private var imageArrayList: ArrayList<String> = ArrayList()
    private var mFeedbackAdapter: FeedbackAdapter? = null
    private var intentFilter: IntentFilter? = null

    //    var fieldName: String = ""
    var mSmileRate: Int = 1
    var mReason = ""

    private var progressDialog: ProgressDialog? = null

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    companion object {
        fun newIntent(mContext: Context, rate: Int, reason: String): Intent {
            val intent = Intent(mContext, FeedbackActivity::class.java)
            intent.putExtra(KEY_SMILE, rate)
            intent.putExtra(KEY_REASON, reason)
            return intent
        }
    }

    lateinit var binding:ActivityFeedbackBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_feedback)
        binding=ActivityFeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    override fun getContext(): AppCompatActivity {
        return this@FeedbackActivity
    }

    override fun initActions() {
        binding.ivAdd.setOnClickListener(this)
        binding.btnSubmit.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)
        binding.edtDetails.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.tvCurrentLength.text = s.toString().length.toString()
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })

        binding.edtDetails.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                if (binding.edtDetails.hasFocus()) {
                    v!!.parent.requestDisallowInterceptTouchEvent(true)
                    when (event!!.action and MotionEvent.ACTION_MASK) {
                        MotionEvent.ACTION_SCROLL -> {
                            v.parent.requestDisallowInterceptTouchEvent(false)
                            return true
                        }
                    }
                }
                return false
            }

        })
    }

    override fun initData() {


        binding.edtDetails.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                binding.edtDetails.isFocusableInTouchMode = true
                binding.edtDetails.isCursorVisible = false
                binding.edtDetails.error = null
            }
            false
        }

        binding.edtEmail.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                binding.edtEmail.isFocusableInTouchMode = true
                binding.edtEmail.isCursorVisible = false
                binding.edtEmail.error = null
            }
            false
        }
        progressDialog = ProgressDialog(this)
        progressDialog!!.setMessage(getString(R.string.please_wait))
        progressDialog!!.setCancelable(false)
        progressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        progressDialog!!.isIndeterminate = true
        progressDialog!!.progress = 0


//        val fields: Array<Field> = VERSION_CODES::class.java.fields
//        for (field in fields) {
//            fieldName = field.name
//        }
        mSmileRate = intent.getIntExtra(KEY_SMILE, 1)
        if(intent.hasExtra(KEY_REASON)) {
            mReason = intent.getStringExtra(KEY_REASON)!!
            binding.edtDetails.setText(mReason)
            binding.tvCurrentLength.text = mReason.length.toString()
        }

//        Log.e(TAG, "initData: version name $fieldName")
        Log.e(TAG, "initData: version code  " + BuildConfig.VERSION_NAME)
        Log.e(TAG, "initData: Smiley  $mSmileRate")

        intentFilter = IntentFilter("FeedbackActivity")

    }

    override fun onClick(view: View) {
        super.onClick(view)

        when (view.id) {
            R.id.iv_add -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    checkPermissions()
                }
            }

            R.id.btn_submit -> {
                performSubmit()
            }

            R.id.iv_back -> {
                onBackPressed()
            }
        }

    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                choosePicture()
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse(String.format("package:%s", packageName)))

                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    private fun checkPermissions() {

        Dexter.withContext(mContext)
            .withPermissions(*permission_gallery)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    when {
                        report.areAllPermissionsGranted() -> {
                            choosePicture()
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            Toast.makeText (this@FeedbackActivity,getString(R.string.permission_required),Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(permissions: List<PermissionRequest>, token: PermissionToken) {
                    token.continuePermissionRequest()
                }
            }).check()


    }


    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }
        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {

        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }

    private fun choosePicture() {
        val maxSelection = 4 - imageArrayList.size
//        AGallery.from(mContext)
//            .choose(MimeType.ofImage())
//            .countable(true)
//            .showSingleMediaType(true)
//            .capture(false) // Camera option enable or disable
//            .isNeedToShowAd(AdsManager(mContext).isNeedToShowAds())
//            .captureStrategy(CaptureStrategy(false, "$packageName.fileprovider", "temp"))
//            .maxSelectable(maxSelection) // Maximum image selection limit
//            .minSelectable(0) // Minimum image selection limit
//            .restrictOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
//            .showPreview(true)
//            .thumbnailScale(0.85f)
//            .imageEngine(GlideEngine())
//            .forResult(REQUEST_CODE_CHOOSE)
    }


//    private fun performSubmit() {
//        if (binding.edtDetails.text.toString().isEmpty()) {
//            binding.edtDetails.error = getString(R.string.error_msg_please_enter_problem)
//        } else if (binding.edtEmail.text.isEmpty()) {
//            binding.edtEmail.error = getString(R.string.error_msg_please_enter_contact_detail)
//        } else if (!binding.edtEmail.text.toString().isValidContactInformation()) {
//            binding.edtEmail.error = getString(R.string.error_msg_please_enter_valid_contact)
//        } else {
//            if (isOnline()) {
//                binding.edtDetails.error = null
//                binding.edtEmail.error = null
//                callShareAPI()
//            } else {
//                Toast.makeText(mContext, getString(R.string.error_check_internet), Toast.LENGTH_SHORT).show()
//            }
//        }
//    }

    private fun performSubmit() {
        if (binding.edtDetails.text.toString().isEmpty()) {
            binding.edtDetails.error = getString(R.string.please_enter_your_problem)
        } else if (binding.edtEmail.text.isEmpty()) {
            binding.edtEmail.error = getString(R.string.please_enter_your_contact_detail)
        } else if (!binding.edtEmail.text.toString().isValidContactInformation()) {
            binding.edtEmail.error = getString(R.string.please_enter_valid_contact_detail)
        } else {
            if (isOnline()) {
                binding.edtDetails.error = null
                binding.edtEmail.error = null
                callShareAPI()
            } else {
                Toast.makeText(mContext, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createPartFromString(descriptionString: String): RequestBody {
        return RequestBody.create(MultipartBody.FORM, descriptionString)
    }

    private fun callShareAPI() {
        progressDialog?.show()


        val reqFeedback = ModelRequestFeedback(
            package_name = packageName,
            review = binding.edtDetails.text.toString(),
            ratings = mSmileRate.toString(),
            files = imageArrayList,
            contact_information = binding.edtEmail.text.toString(),
            version_code = BuildConfig.VERSION_CODE.toString(),
            version_name = BuildConfig.VERSION_NAME
        )

//        if (mContext.isOnline()) {
        // Fetch App center data from the server
//        if (isSDKBelow21()) {
//            // Simple json parsing
//            callShareBelow21(reqFeedback)
//
//        } else {
//            GlobalScope.launch(job + Dispatchers.Main) {
//                callShareRetrofitAPI(job, reqFeedback)
//            }
//        }
//        }
    }

    private fun callShareBelow21(feedback: ModelRequestFeedback) {
//        GetFeedbackResponseTask(mContext, feedback, object : JsonParserCallback {
//            override fun onSuccess(response: String) {
//                Log.i(TAG, "onResponse: $String")
//                progressDialog?.dismiss()
//                Toast.makeText(this@FeedbackActivity, getString(R.string.thanks_for_feedback), Toast.LENGTH_SHORT).show()
//                finish()
//            }
//
//            override fun onFailure(message: String) {
//                Log.e(TAG, "onResponse Failed:$message")
//                Toast.makeText(this@FeedbackActivity, message, Toast.LENGTH_SHORT).show()
//                progressDialog?.dismiss()
//            }
//        }).execute()
    }

    private suspend fun callShareRetrofitAPI(job: Job, feedback: ModelRequestFeedback) {
//        return withContext(job + Dispatchers.IO) {
//            val retroApiInterface = FeedbackAPIService().getFeedbackClient(mContext)
//
//
//            val imageArray: ArrayList<MultipartBody.Part> = ArrayList()
//            for (i in imageArrayList.indices) {
//                if (!imageArrayList[i].equals("null", ignoreCase = true)) {
//                    val file = File(imageArrayList[i])
//                    val requestFile = RequestBody.create("*/*".toMediaTypeOrNull(), file)
//                    val a = MultipartBody.Part.createFormData("image[]", file.name, requestFile)
//                    imageArray.add(a)
//                }
//            }
//
//            try {
//                val reqFeedback = retroApiInterface.getFeedbackAsync(
//                    createPartFromString(feedback.package_name),
//                    createPartFromString(feedback.review),
//                    createPartFromString(feedback.ratings),
//                    imageArray,
//                    createPartFromString(feedback.contact_information),
//                    createPartFromString(feedback.version_name),
//                    createPartFromString(feedback.version_code)
//                )
//
//                val resFeedback = reqFeedback.await()
//                runOnUiThread {
//                    progressDialog?.dismiss()
//                    onRetrofitResponse(resFeedback)
//                }
//            } catch (exception: Exception) {
//                Log.e(TAG, exception.toString())
//                runOnUiThread {
//                    progressDialog?.dismiss()
//                    retryDialog(exception)
//                }
//            }
//        }
    }

    private fun onRetrofitResponse(resFeedback: Response<ModelResponseFeedback>) {
        if (resFeedback.isSuccessful && resFeedback.body() != null) {
            val body = resFeedback.body()
            if (body!!.ResponseCode == 1) {
                Log.i(TAG, "onResponse: ${body.ResponseMessage}")
                Toast.makeText(this@FeedbackActivity,  getString(R.string.thanks_for_feedback), Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Log.e(TAG, "onResponse: ${body.ResponseMessage}")
                Toast.makeText(this@FeedbackActivity, body.ResponseMessage.toString(), Toast.LENGTH_SHORT).show()
            }
        } else {
            Log.e(TAG, "onResponse Failed:" + resFeedback.errorBody())
            Toast.makeText(this@FeedbackActivity, resFeedback.errorBody().toString(), Toast.LENGTH_SHORT).show()
        }
    }

    private fun retryDialog(t: Throwable) {

        val dialog = AlertDialog.Builder(this)
        var alert: AlertDialog? = null

        val title = getString(R.string.label_error)
        val msg = t.toString()
        val positiveText = getString(R.string.label_retry)
        val negativeText = getString(R.string.cancel)


        dialog.setCancelable(false)

        // Initialize a new foreground color span instance
        val foregroundColorSpan = ForegroundColorSpan(ContextCompat.getColor(this, R.color.colorPrimaryDark))
        val ssBuilder = SpannableStringBuilder(title)
        ssBuilder.setSpan(foregroundColorSpan, 0, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        dialog.setTitle(ssBuilder)

        if (NetworkManager.isInternetConnected(this)) {
            dialog.setMessage(getString(R.string.connection_time_out))
        } else {
            dialog.setMessage(getString(R.string.no_internet_access))
        }
        dialog.setPositiveButton(positiveText) { _, _ ->
            alert?.dismiss()
            if (progressDialog!!.isShowing) {
                progressDialog!!.dismiss()
            }
            callShareAPI()
        }


        dialog.setNegativeButton(negativeText) { _, _ ->
            alert?.dismiss()
        }

        alert = dialog.create()
        alert.show()


        val textView = alert.findViewById<TextView>(android.R.id.message)
        try {
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            val face = Typeface.createFromAsset(assets, fontPath)
            textView.typeface = face
        } catch (e: Exception) {
            Log.e("showAlert", e.toString())
        }
    }

    private fun updateMediaList() {
        binding.tvCurrentImage.text = imageArrayList.size.toString()
        if (imageArrayList.size > 0) {
            mFeedbackAdapter = FeedbackAdapter(mContext, imageArrayList)
            binding.rvMedia!!.adapter = mFeedbackAdapter
        }
        if (imageArrayList.size >= 4) {
            binding.relativeImg1.visibility = View.GONE
        } else {
            binding.relativeImg1.visibility = View.VISIBLE
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_CODE_CHOOSE -> {
                when (resultCode) {
//                    Activity.RESULT_OK -> {
//                        val mSelected = AGallery.obtainResult(data)
//                        if (mSelected.isNotEmpty() && mSelected.size > 0) {
//                            val paths = AGallery.obtainPathResult(data)
//                            for (path in paths) {
//                                imageArrayList.add(path)
//                            }
//                            updateMediaList()
//                        } else {
//                            Toast.makeText(this@FeedbackActivity, getString(R.string.you_have_select) + mSelected.size + getString(R.string.images), Toast.LENGTH_SHORT).show()
//                        }
//                    }
//                    Activity.RESULT_CANCELED -> {
//                        Toast.makeText(this@FeedbackActivity, getString(R.string.cancel_image_selection), Toast.LENGTH_SHORT).show()
//                    }
//                    else -> {
//                        Toast.makeText(this@FeedbackActivity, getString(R.string.failed_image_selection), Toast.LENGTH_SHORT).show()
//                    }
                }
            }
        }
    }

    private val feedbackStateReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateMediaList()
        }
    }

    public override fun onResume() {
        super.onResume()
        changeLanguage()
        registerReceiver(feedbackStateReceiver, intentFilter, Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(feedbackStateReceiver)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

}