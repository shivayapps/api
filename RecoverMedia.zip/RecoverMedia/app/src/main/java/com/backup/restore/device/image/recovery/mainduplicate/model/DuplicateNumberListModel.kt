package com.backup.restore.device.image.recovery.mainduplicate.model

class DuplicateNumberListModel {
    var mMainKey: String? = null
    var mNumberList : ArrayList<DuplicateContactModel> = ArrayList()
    var isFileCheckBox : Boolean = true

}