package com.backup.restore.device.image.recovery.mainphotos.model

import java.io.FileInputStream

class DeleteImageModel {
    var path: String
    var inputStream: FileInputStream? = null

    constructor(paths: String) {
        path = paths
    }

    constructor(paths: String, inputStreams: FileInputStream?) {
        path = paths
        inputStream = inputStreams
    }
}