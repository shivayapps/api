package com.backup.restore.device.image.recovery.mainduplicate.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainduplicate.activity.previewactivities.PreviewVideoActivity
import com.backup.restore.device.image.recovery.mainduplicate.adapter.ListVideoAdapter.VideoViewHolder
import com.backup.restore.device.image.recovery.mainduplicate.callbacks.MarkedListener
import com.backup.restore.device.image.recovery.mainduplicate.model.IndividualGroupModel
import com.backup.restore.device.image.recovery.mainduplicate.model.ItemDuplicateModel
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.bumptech.glide.Glide
import java.io.File

@Suppress("DEPRECATION")
class ListVideoAdapter  constructor(
    var gridVideoAdapterContext: Context,
    var gridVideoAdapterActivity: Activity,
    var videosMarkedListener: MarkedListener,
    var individualGroupVideos: IndividualGroupModel,
    var video: List<ItemDuplicateModel>,
    var parentCheckbox: CheckBox) : RecyclerView.Adapter<VideoViewHolder>() {

    var inflater: LayoutInflater = gridVideoAdapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0

    class GridViewVideoLoader internal constructor(
        var videoLoaderContext: Context,
        var imageViewReference: ImageView?,
        var checkBoxReference: CheckBox,
        var lTxtIndividualSize: TextView
    ) : AsyncTask<ItemDuplicateModel?, Void?, String?>() {
        var checkBoxStatus: Boolean? = null
        override fun doInBackground(vararg params: ItemDuplicateModel?): String? {
            val lVideoItem = params[0]!!.filePath
            checkBoxStatus = params[0]!!.isFileCheckBox
            mSize = String.format("%s", ShareConstants.getReadableFileSize(params[0]!!.sizeOfTheFile))
            return lVideoItem
        }

        override fun onPostExecute(path: String?) {
            super.onPostExecute(path)
            if (imageViewReference != null && videoLoaderContext != null) {
                Glide.with(videoLoaderContext)
                    .load(Uri.fromFile(File(path!!)))
                    .centerCrop()
                    .placeholder(R.drawable.img_thumb)
                    .into(imageViewReference!!)
                checkBoxReference.isChecked = checkBoxStatus!!
                lTxtIndividualSize.text = mSize
            }
        }
    }

    class VideoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var checkBox: CheckBox = view.findViewById<View>(R.id.checkbox_video) as CheckBox
        var video: ImageView? = view.findViewById<View>(R.id.duplicate_video) as ImageView
        var imgType: ImageView? = view.findViewById<View>(R.id.imgType) as ImageView
        var lIndividualSize: TextView = view.findViewById(R.id.individualsize)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        return VideoViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.raw_list_of_group_of_video_item, parent, false))
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        val lVideoItem = video[position]
        holder.checkBox.isChecked = lVideoItem.isFileCheckBox
        holder.checkBox.tag = position
        holder.video!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(gridVideoAdapterActivity, PreviewVideoActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("videoItem", lVideoItem)
            intent.putExtras(bundle)
            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            gridVideoAdapterActivity.startActivity(
                intent,
                ActivityOptionsCompat.makeCustomAnimation(gridVideoAdapterContext, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
            )
        }
        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                lVideoItem.isFileCheckBox = isChecked
                var selectCount = 0
                val numOffLine = itemCount
                if (lVideoItem.isFileCheckBox) {
                    for (i in 0 until itemCount) {
                        if (video[i].isFileCheckBox) {
                            selectCount++
                        }
                    }
                    if (selectCount != numOffLine) {
//                        GlobalVarsAndFunctions.file_to_be_deleted_videos.add(lVideoItem)
                        GlobalVarsAndFunctions.addSizeVideos(lVideoItem.sizeOfTheFile)
                        videosMarkedListener.updateMarked()
                        individualGroupVideos.isCheckBox = true
                        parentCheckbox.isChecked = true
                    }
                } else {
//                    GlobalVarsAndFunctions.file_to_be_deleted_videos.remove(lVideoItem)
                    GlobalVarsAndFunctions.subSizeVideos(lVideoItem.sizeOfTheFile)
                    videosMarkedListener.updateMarked()
                }
                if (selectCount < numOffLine - 1) {
                    parentCheckbox.isChecked = false
                    individualGroupVideos.isCheckBox = false
                } else {
                    individualGroupVideos.isCheckBox = true
                    parentCheckbox.isChecked = true
                }
                if (numOffLine == selectCount) {
                    MyUtils.showToastMsg(gridVideoAdapterContext, gridVideoAdapterContext.getString(R.string.video_same_not_select))
                    lVideoItem.isFileCheckBox = false
                    holder.checkBox.isChecked = false
                    return@setOnClickListener
                }
                lVideoItem.isFileCheckBox = isChecked
            }
        }
        if (holder.video != null) {
            GridViewVideoLoader(gridVideoAdapterContext, holder.video, holder.checkBox, holder.lIndividualSize).execute(lVideoItem)
            holder.imgType?.visibility=View.VISIBLE
        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = video.size
        return totalNumberOfflineInSet
    }

    companion object {
        var mSize = ""
    }

}