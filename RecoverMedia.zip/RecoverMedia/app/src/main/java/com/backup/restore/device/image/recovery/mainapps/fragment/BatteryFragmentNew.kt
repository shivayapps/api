package com.backup.restore.device.image.recovery.mainapps.fragment

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Context.RECEIVER_NOT_EXPORTED
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.adconfig.adsutil.admob.NativeLayoutType

/**
 * A placeholder fragment containing a simple view.
 */
class BatteryFragmentNew : Fragment() {
    var rootView: View? = null

    var health = 0
    var icon_small = 0
    var level = 0
    var plugged = 0
    var present = false
    var scale = 0
    var status = 0
    var technology = ""
    var temperature = 0
    var voltage = 0
    var deviceStatus = 0

    var batteryType = ""
    var powerSource = ""
    var batteryTemperature = ""
    var batteryVoltage = ""
    var batteryScale = ""
    var batteryHealth = ""
    var batteryCapacity = ""

    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null


    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        @JvmStatic
        fun newInstance(): BatteryFragmentNew {
            val fragment = BatteryFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    private val mBatLow: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
//            fabBatteryCharging.setImageResource(R.drawable.ic_low_battery)
        }
    }

    private val mBatInfoReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            deviceStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)
            icon_small = intent.getIntExtra(BatteryManager.EXTRA_ICON_SMALL, 0)
            plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            present = intent.extras?.getBoolean(BatteryManager.EXTRA_PRESENT)!!
            scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 0)
            status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
            technology = intent.extras?.getString(BatteryManager.EXTRA_TECHNOLOGY)!!
            temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10
            voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            try {
                if(isAdded && !isRemoving) {
                    getBatteryInfo()
                }
            } catch (e: NullPointerException) {
                e.printStackTrace()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        activity?.registerReceiver(mBatInfoReceiver, filter, RECEIVER_NOT_EXPORTED);
        val filter2 = IntentFilter(Intent.ACTION_BATTERY_LOW);
        activity?.registerReceiver(mBatLow, filter2, RECEIVER_NOT_EXPORTED);

//        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
//        scrollMain.scrollTo(0,0)
        return rootView
    }

    @SuppressLint("PrivateApi")
    fun getBatteryCapacity(): Double {
        val powerProfile: Any
        var batteryCapacity = 0.0
        val POWER_PROFILE_CLASS = "com.android.internal.os.PowerProfile"
        try {
            powerProfile = Class.forName(POWER_PROFILE_CLASS)
                .getConstructor(Context::class.java)
                .newInstance(this.context)
            batteryCapacity = Class.forName(POWER_PROFILE_CLASS)
                .getMethod("getBatteryCapacity")
                .invoke(powerProfile) as Double
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return batteryCapacity
    }

    private fun getBatteryInfo() {
        tvSubTitle!!.text = "$level%"

        if (tvSubTitle != null) {
            if (deviceStatus == BatteryManager.BATTERY_STATUS_CHARGING) {
                //fabBatteryCharging.setVisibility(View.VISIBLE)
                tvSubTitle?.setText("$level % ${getString(R.string.charging)}")
            }
            if (deviceStatus == BatteryManager.BATTERY_STATUS_DISCHARGING) {
                //fabBatteryCharging.setVisibility(View.GONE)
                tvSubTitle?.setText("$level %")
            }
            if (deviceStatus == BatteryManager.BATTERY_STATUS_FULL) {
                //fabBatteryCharging.setVisibility(View.GONE)
                tvSubTitle?.setText("$level % ${getString(R.string.full_charged)}")
            }
            if (deviceStatus == BatteryManager.BATTERY_STATUS_UNKNOWN) {
                //fabBatteryCharging.setVisibility(View.GONE)
                tvSubTitle?.setText("$level %")
            }
            if (deviceStatus == BatteryManager.BATTERY_STATUS_NOT_CHARGING) {
                //fabBatteryCharging.setVisibility(View.GONE)
                tvSubTitle?.setText("$level %")
            }
        }

        batteryCapacity="" + getBatteryCapacity()

        batteryTemperature = "" + temperature.toString() + context?.resources?.getString(R.string.c_symbol)

//        if (Validation.isRequiredField(technology)) {
        if (technology != null && !technology.trim().isEmpty()) {
            batteryType = "" + technology
        }

        batteryVoltage = "" + voltage.toString() + "mV"
        batteryScale = "" + scale.toString()
        if (health == 1) {
            batteryHealth=requireContext().resources.getString(R.string.unknown)
        } else if (health == 2) {
            batteryHealth=requireContext().resources.getString(R.string.good)
        } else if (health == 3) {
            batteryHealth=requireContext().resources.getString(R.string.over_heated)
        } else if (health == 4) {
            batteryHealth=requireContext().resources.getString(R.string.dead)
        } else if (health == 5) {
            batteryHealth=requireContext().resources.getString(R.string.over_voltage)
        } else if (health == 6) {
            batteryHealth=requireContext().resources.getString(R.string.failed)
        } else {
            batteryHealth=requireContext().resources.getString(R.string.cold)
        }

        when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> {
//                tvPowerSource?.setText("AC")
                powerSource=requireContext().resources.getString(R.string.ac_power)
            }
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> {
                powerSource=requireContext().resources.getString(R.string.wireless)
            }
            BatteryManager.BATTERY_PLUGGED_USB -> {
                powerSource=requireContext().resources.getString(R.string.usb)
            }
            else -> {
                powerSource=requireContext().resources.getString(R.string.unknown)
            }
        }

        ivType!!.setImageResource(R.drawable.ic_battery)
        tvTitle!!.text = getString(R.string.battery_information)

        tvTitle!!.isSelected=true
        tvSubTitle!!.isSelected=true

        if(batteryType.isEmpty()) batteryType=getString(R.string.unavailable)

        val parents = ArrayList<ParentModel>()
        parents.add(ParentModel(resources.getString(R.string.battery_information),ArrayList<FeaturesHW>()))
        val lists: ArrayList<FeaturesHW> = parents.get(0).lists

        lists.add(FeaturesHW(getString(R.string.battery_type), "${batteryType}"))
        lists.add(FeaturesHW(getString(R.string.power_source), "${powerSource}"))
        lists.add(FeaturesHW(getString(R.string.battery_temperature), "${batteryTemperature}"))
        lists.add(FeaturesHW(getString(R.string.battery_voltage), "${batteryVoltage}"))
        lists.add(FeaturesHW(getString(R.string.battery_scale), "${batteryScale}"))
        lists.add(FeaturesHW(getString(R.string.battery_health), "${batteryHealth}"))
        lists.add(FeaturesHW(getString(R.string.battery_capacity), "${batteryCapacity}"))

        val adapter = ParentAdapter(parents, requireContext())
        rvFeatureList?.adapter = adapter
        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        Handler(Looper.getMainLooper()).postDelayed({
            scrollMain.scrollTo(0,0)
        },100)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

}