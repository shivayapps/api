package com.backup.restore.device.image.recovery.mainapps.adapter

import android.app.Activity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.utilities.Language
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.loadImage
import com.example.jdrodi.callback.RVClickListener
import com.example.jdrodi.utilities.camelCaseString


class LanguageAdapter(
    val mContext: Activity,
    private val languageOptions: MutableList<Language>,
    val listener: RVClickListener
) : RecyclerView.Adapter<LanguageAdapter.ViewHolder>() {

    var oldPosition=0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.raw_language, parent, false))
    }

    override fun getItemCount(): Int {
        return languageOptions.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val language = languageOptions[position]
        val title = mContext.getString(language.name)
        holder.tvTitle.text = camelCaseString(title)
        holder.tvTitle.isSelected = true
        mContext.loadImage(language.flag, holder.ivThumb, null)

//        Log.e("ChangeLanguage","LanguageAdapter:"+SharedPrefsConstant.getString(mContext, ShareConstants.SELECTED_LANGUAGE))
//        Log.e("ChangeLanguage","language.pref:"+language.pref)
//        Log.e("ChangeLanguage","language.pref:"+language.pref+"::"+SharedPrefsConstant.getString(mContext, ShareConstants.SELECTED_LANGUAGE)+"::")

//        if(SharedPrefsConstant.getString(mContext, ShareConstants.SELECTED_LANGUAGE).equals(language.pref,true)) {
//        if(language.type==LocaleHelper.getLocale(mContext).language) {

        if(language.type== SharedPrefsConstant.getString(mContext, ShareConstants.SELECTED_LANGUAGE, "en")!!) {
            holder.cbLanguage.isChecked=true
            Log.e("ChangeLanguage","true.position:"+position)
        } else {
            holder.cbLanguage.isChecked=false
            Log.e("ChangeLanguage","false.position:"+position)
        }
//        holder.itemView.setOnClickListener { listener.onItemClick(position) }
//        holder.cbLanguage.setOnCheckedChangeListener { buttonView, isChecked ->
//            if(isChecked) {
//                languageOptions[position].isSelected = true
//                languageOptions[oldPosition].isSelected = false
//                listener.onItemClick(position)
//                notifyDataSetChanged()
//            }
//        }

        holder.itemView.setOnClickListener {
//            holder.cbLanguage.isSelected=true
            if(!holder.cbLanguage.isChecked) {
                languageOptions[position].isSelected = true
                languageOptions[oldPosition].isSelected = false
                listener.onItemClick(position)
                notifyDataSetChanged()
            }
        }

    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.label_text)
        val ivThumb: ImageView = itemView.findViewById(R.id.application_icon_image)
        val cbLanguage: RadioButton = itemView.findViewById(R.id.cb_select)
    }
}