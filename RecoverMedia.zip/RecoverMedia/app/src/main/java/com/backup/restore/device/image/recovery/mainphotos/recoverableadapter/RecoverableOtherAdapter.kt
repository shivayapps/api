package com.backup.restore.device.image.recovery.mainphotos.recoverableadapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableImageModel
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import java.io.File
import java.util.*

class RecoverableOtherAdapter(
    var mScanImageRecycle: RecyclerView,
    private val mContext: Context,
    private val loImageList: List<RecoverableImageModel>,
    private val checkAll: CheckBox
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var TAG = "RecoverableOtherAdapter"

    class MyRecoverableViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvDir: TextView = view.findViewById(R.id.tvDir)
        var fileName: TextView = view.findViewById(R.id.fileName)
        var fileSize: TextView = view.findViewById(R.id.fileSize)
        var thumbnail: ImageView = view.findViewById(R.id.imgItem)
        var audiocheckbox: CheckBox = view.findViewById(R.id.audiocheckbox)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.raw_other_item, parent, false)
        return MyRecoverableViewHolder(itemView)
    }

    override fun onBindViewHolder(holders: RecyclerView.ViewHolder, position: Int) {
        val holder = holders as MyRecoverableViewHolder

        val extension=File(loImageList[position].filePath).extension

        if(SharedPrefsConstant.AudioArray.contains(extension)) {
            holder.thumbnail.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_audios))
        } else {
            holder.thumbnail.setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_doc_file))
        }

        holder.fileName.text = File(loImageList[position].filePath).name
        holder.fileSize.text = String.format("%s", ShareConstants.getReadableFileSize(File(loImageList[position].filePath).length()))
        holder.tvDir.text = loImageList[position].filePath
        holder.tvDir.isSelected=true
        holder.audiocheckbox.isSelected = loImageList[position].isSelected

        holder.itemView.setOnClickListener {
            if(holder.audiocheckbox.isSelected) {
                holder.audiocheckbox.isSelected=false
                loImageList[position].isSelected=false
            } else {
                holder.audiocheckbox.isSelected=true
                loImageList[position].isSelected=true
            }
            if (checkAll.isChecked && getSelectedCounted() != itemCount) {
//                Log.e(TAG, "onBindViewHolder: " + checkAll.isChecked)
//                Log.e(TAG, "onBindViewHolder: " + getSelectedCounted())
//                Log.e(TAG, "onBindViewHolder: $itemCount")
                ShareConstants.isManualHiddenClick = true
                checkAll.isChecked = getSelectedCounted() == itemCount
            } else if (getSelectedCounted() == itemCount) {
                checkAll.isChecked = true
            }
        }

    }

    fun runLayoutAnimation() {
        val lController = AnimationUtils.loadLayoutAnimation(mContext, R.anim.layout_animation_fall_down)
        mScanImageRecycle.layoutAnimation = lController
        Objects.requireNonNull(mScanImageRecycle.adapter).notifyDataSetChanged()
        mScanImageRecycle.scheduleLayoutAnimation()
    }

    override fun getItemCount(): Int {
        return loImageList.size
    }

    fun getSelected(pos: Int): Boolean {
        return loImageList[pos].isSelected
    }

    fun getSelectedCounted(): Int {
        val selectedList = loImageList.filter { it.isSelected }
        return selectedList.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (itemCount > 0) {
            position
        } else super.getItemViewType(position)
    }
}