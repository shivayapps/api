package com.backup.restore.device.image.recovery.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.backup.restore.device.image.recovery.service.ManagerService;

public class RebootBroadcastReceiver extends BroadcastReceiver {


    public void onReceive(Context context, Intent intent) {

        if (intent.getAction().equalsIgnoreCase("android.intent.action.BOOT_COMPLETED")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(new Intent(context, ManagerService.class));
            } else {
                context.startService(new Intent(context, ManagerService.class));
            }

        }

    }


}
