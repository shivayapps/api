package com.backup.restore.device.image.recovery.mainapps.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainduplicate.model.IgnorePath


class IgnoredAdapter(
    private val mContext: Context, private val appInfoList: MutableList<IgnorePath>, val onPathSelect :OnPathSelect
) : RecyclerView.Adapter<IgnoredAdapter.ViewHolder>() {

    interface OnPathSelect {
        fun onPathClick(position: Int,appInfo: IgnorePath)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.raw_list_of_app, parent, false))
    }

    override fun getItemCount(): Int {
        return appInfoList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val appInfo = appInfoList[position]
        holder.tvTitle.text= "${mContext.getString(R.string.name_)}${appInfo.name}"

        holder.tvDetail.text="${mContext.getString(R.string.path_colon)} ${appInfo.path}"

        holder.ivDelete.setOnClickListener {
            onPathSelect.onPathClick(position,appInfo)
        }

        holder.tvTitle.isSelected=true
        holder.tvDetail.isSelected=true
        holder.ivOption.visibility=View.GONE
        holder.ivDelete.visibility=View.VISIBLE
        holder.ivThumb.setImageResource(R.drawable.ic_folder_ignore)
    }


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.txt_name)
        val tvDetail: TextView = itemView.findViewById(R.id.tv_detail)
        val ivThumb: ImageView = itemView.findViewById(R.id.application_icon_image)
        val ivOption: ImageView = itemView.findViewById(R.id.img_arrow)
        val ivDelete: ImageView = itemView.findViewById(R.id.img_delete)
        val ll_info: LinearLayout = itemView.findViewById(R.id.ll_info)
    }

}