package com.backup.restore.device.image.recovery.mainduplicate.callbacks

interface SearchListener {
    fun checkScanFinish()
    fun updateUi(vararg count: String?)
}