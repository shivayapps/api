package com.backup.restore.device.image.recovery.utilities.divider

import android.content.Context
import android.graphics.Rect
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.OrientationHelper
import androidx.recyclerview.widget.RecyclerView
import java.util.*

/**
 *Date:2019/7/9
 *Author:kunkun.wang
 *Des:grid layout divider
 **/
class GridItemDecoration(builder: Builder) : BaseItemDecoration(builder) {
    private var left = 0
    private var top = 0
    private var right = 0
    private var bottom = 0
    private var span: Int = 0
    private var dividerHeight = 0
    private var ignoreHeadLine = 0
    private var ignoreFooterLine = 0
    var isDrawLastDivider: Boolean = builder.isDrawLastDivider

    override fun setItemOffsets(
        position: Int,
        itemCount: Int,
        outRect: Rect,
        view: View,
        parent: RecyclerView
    ) {
        dividerHeight = getDrawableHeight(position, parent)
        if (span == 0) {
            if (parent.layoutManager !is GridLayoutManager) {
                Log.e(tag, "When using GridItemDecoration, make sure it's a grid layout")
                outRect.set(0, 0, 0, 0)
                return
            }
            span = (parent.layoutManager as GridLayoutManager).spanCount
            ignoreHeadLine = (ignoreHeadItemCount / span.toFloat() + 0.5f).toInt()
            ignoreFooterLine = (ignoreFooterItemCount / span.toFloat() + 0.5f).toInt()
        }

        if (orientation == OrientationHelper.VERTICAL) {
            //vertical layout
            bottom = dividerHeight + margin[1] + margin[3]
            left = dividerHeight / 2 + margin[2]
            right = dividerHeight / 2 + margin[0]
            top = 0
            if (position < span) {
                //first row
                top = recyclerViewTopSpace
                if (isDrawFirstTopDivider) {
                    top += bottom
                }
            }

            when ((position + 1) % span) {
                0 -> {
                    //last row
                    right = 0
                }
                1 -> {
                    //first row
                    left = 0
                }
            }
            if (isLastRow(position, span, itemCount)) {
                bottom += recyclerViewBottomSpace
                if (!isDrawLastDivider) {
                    bottom = recyclerViewBottomSpace
                }
            }

        } else {
            //Landscape layout
            bottom = dividerHeight / 2 + margin[0]
            top = dividerHeight / 2 + margin[2]
            right = dividerHeight + margin[1] + margin[3]
            left = 0
            if (position < span) {
                //first row
                left = recyclerViewTopSpace
                if (isDrawFirstTopDivider) {
                    left += bottom
                }
            }
            if (isLastRow(position, span, itemCount)) {
                right += recyclerViewBottomSpace
                if (!isDrawLastDivider) {
                    right = recyclerViewBottomSpace
                }
            }
            when ((position + 1) % span) {
                0 -> {
                    //the last line
                    bottom = 0
                }
                1 -> {
                    //first row
                    top = 0
                }
            }

        }
        outRect.set(left, top, right, bottom)
    }

    override fun getDrawRectBound(
        position: Int,
        itemCount: Int,
        view: View,
        parent: RecyclerView
    ): ArrayList<Rect> {
        if (parent.layoutManager !is GridLayoutManager) {
            Log.e(tag, "When using GridItemDecoration, make sure it's a grid layout")
            return arrayListOf()
        }
        val rectLists = ArrayList<Rect>()
        val viewBound = Rect()
        val dividerHeight = getDrawableHeight(position, parent)
        parent.getDecoratedBoundsWithMargins(view, viewBound)
        if (span == 0) {
            span = (parent.layoutManager as GridLayoutManager).spanCount
        }
        if (orientation == OrientationHelper.VERTICAL) {
            val isLastRow = isLastRow(position, span, itemCount)
            //portrait
            //Add bottom divider
            left = viewBound.left + view.translationX.toInt()
            right = viewBound.right + view.translationX.toInt()
            bottom = viewBound.bottom + (view.translationY.toInt() - margin[3])
            if (isLastRow) {
                bottom -= recyclerViewBottomSpace
            }
            top = bottom - dividerHeight
            if (!isLastRow || isDrawLastDivider)
                rectLists.add(Rect(left, top, right, bottom))

            if (isDrawFirstTopDivider && position < span) {
                //Add top divider
                top = viewBound.top + view.translationY.toInt() + recyclerViewTopSpace + margin[1]
                bottom = top + dividerHeight
                rectLists.add(Rect(left, top, right, bottom))
            }
            top = viewBound.top + view.translationY.toInt()
            if (position < span) {
                top += recyclerViewTopSpace
            }
            bottom = viewBound.bottom
            if (isLastRow) {
                bottom -= recyclerViewBottomSpace
                if (isDrawLastDivider)
                    bottom -= (margin[3] + dividerHeight)
            }
            when ((position + 1) % span) {
                0 -> {
                    //last row
                    //Draw the dividing line on the left
                    left = viewBound.left + view.translationX.toInt()
                    right = left + dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))
                }
                1 -> {
                    //first row
                    //Draw the dividing line on the right
                    right = viewBound.right + view.translationX.toInt()
                    left = right - dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))
                }
                else -> {
                    //other parts
                    //Draw dividing lines on the left and right sides
                    //left
                    left = viewBound.left + view.translationX.toInt()
                    right = left + dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))
                    //Right
                    right = viewBound.right + view.translationX.toInt()
                    left = right - dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))

                }
            }
        } else {
            val isLastRow = isLastRow(position, span, itemCount)
            //horizontal
            //Draw the dividing line at the tail
            bottom = viewBound.bottom + view.translationY.toInt()
            top = viewBound.top + view.translationY.toInt()
            right = viewBound.right + view.translationX.toInt() - margin[3]
            if (isLastRow) {
                right -= recyclerViewBottomSpace
            }
            left = right - dividerHeight
            if (!isLastRow || isDrawLastDivider)
                rectLists.add(Rect(left, top, right, bottom))
            if (isDrawFirstTopDivider && position < span) {
                //Add top divider
                bottom = viewBound.bottom + view.translationY.toInt()
                top = viewBound.top + view.translationY.toInt()
                left = viewBound.left + margin[1] + recyclerViewTopSpace
                right = left + dividerHeight
                rectLists.add(Rect(left, top, right, bottom))
            }
            left = viewBound.left
            right = viewBound.right
            if (position < span) {
                left += recyclerViewTopSpace
            }
            if (isLastRow) {
                right -= recyclerViewBottomSpace
                if (isDrawLastDivider)
                    right -= (dividerHeight + (margin[3]))
            }
            when ((position + 1) % span) {
                1 -> {
                    //first row
                    //draw the dividing line below
                    bottom = viewBound.bottom + view.translationY.toInt()
                    top = bottom - dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))
                }
                0 -> {
                    //the last line
                    // draw the upper dividing line
                    top = viewBound.top + view.translationY.toInt()
                    bottom = top + dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))
                }
                else -> {
                    //Middle row
                    //Draw the upper and lower dividing lines
                    top = viewBound.top + view.translationY.toInt()
                    bottom = top + dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))

                    bottom = viewBound.bottom + view.translationY.toInt()
                    top = bottom - dividerHeight / 2
                    rectLists.add(Rect(left, top, right, bottom))
                }
            }
        }
        return rectLists
    }

    /**
     * is the last line
     */
    private fun isLastRow(position: Int, spanCount: Int, itemCount: Int): Boolean {
        var remind = itemCount % spanCount
        if (remind == 0) {
            remind = spanCount
        }
        return (itemCount - position) <= remind
    }

    class Builder(mContext: Context, layoutOrientation: Int) :
        BaseItemDecoration.Builder(mContext, layoutOrientation) {

        var isDrawLastDivider: Boolean = false
        override fun build(): BaseItemDecoration {
            return GridItemDecoration(this)
        }

        fun setIsDrawLastDivider(isDrawLastDivider: Boolean): Builder {
            this.isDrawLastDivider = isDrawLastDivider
            return this
        }

    }
}