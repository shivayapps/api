package com.backup.restore.device.image.recovery.ads.rateandfeedback

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.adapter.OptionsAdapter
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ratingview.SmartRatingBar
import com.backup.restore.device.image.recovery.main.ExitActivity
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.fontPath
import com.backup.restore.device.image.recovery.utilities.fontPathBold
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.example.jdrodi.callback.RVClickListener
import com.example.jdrodi.utilities.RvGridSpacingItemDecoration
import java.util.*


val mTAG: String = "ExitDialogs"

var RATING = -1




private fun FragmentActivity.redirectNextActivity(activity: FragmentActivity) {
    val i = Intent(activity, ExitActivity::class.java)
    startActivity(i)
}


//fun Context.NextActivity() {
//    val activity = this as FragmentActivity
//    MyApplication.isInterstitialShown = true
//
//    if (AdsManager(activity).isNeedToShowAds()) {
//        InterstitialAdHelper.instance!!.load(activity,
//            object : InterstitialAdHelper.InterstitialAdListener {
//                override fun onAdLoaded(interstitialAd: InterstitialAd) {
//                    interstitialAd.show(activity)
//                }
//
//                override fun onAdFailedToLoad() {
//                    if (unNativeAd != null && AdsManager(activity).isNeedToShowAds() && NetworkManager.isInternetConnected(activity)) {
//                        display(activity.supportFragmentManager) {
//                            val intent = Intent(activity, ExitActivity::class.java)
//                            activity.startActivity(intent)
//                        }
//                    }else{
//                        val intent = Intent(activity, ExitActivity::class.java)
//                        activity.startActivity(intent)
//                    }
//                }
//
//                override fun onAdClosed() {
//                    val intent = Intent(activity, ExitActivity::class.java)
//                    activity.startActivity(intent)
//                }
//            })
//    } else {
//        val intent = Intent(activity, ExitActivity::class.java)
//        activity.startActivity(intent)
//    }
//}


fun Context.ratingDialog(listener: OnRateListener) {
    try {
        Log.e(mTAG, "Rate Dialog called")

        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_rate_new)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        val inflater = (this as Activity).layoutInflater
//        val alertLayout = inflater.inflate(R.layout.dialog_rate_new, null)

        val imageIcon: ImageView = dialog.findViewById(R.id.imageIcon)
        val ratingStar: SmartRatingBar = dialog.findViewById(R.id.rb_stars)
        val btnDismiss = dialog.findViewById<TextView>(R.id.dialogButtonClose)
        val btnOk = dialog.findViewById<TextView>(R.id.dialogButtonok)
        val tvTitle = dialog.findViewById<TextView>(R.id.rate_tv_title)

        val tf = Typeface.createFromAsset(assets, fontPath)
        tvTitle.typeface = tf
//        btnDismiss.typeface = tf
//        val alert = AlertDialog.Builder(this)
//        alert.setView(alertLayout)
//        alert.setCancelable(false)
//        val dialog = alert.create()

        btnDismiss.setOnClickListener {
            ExitSPHelper(this).saveDismissed(true)
            RATING = -1
            SharedPrefsConstant.save(this,ShareConstants.RATE_LATTER,1)
            if (SharedPrefsConstant.getInt(this, ShareConstants.RATE_RECOVER_APK_COUNT) >= 3) {
                SharedPrefsConstant.save(this, ShareConstants.RATE_RECOVER_APK_COUNT, 2)
            }
            if (SharedPrefsConstant.getInt(this, ShareConstants.RATE_BACKUP_CONTACT_COUNT) >= 3) {
                SharedPrefsConstant.save(this, ShareConstants.RATE_BACKUP_CONTACT_COUNT, 0)
            }
            if (SharedPrefsConstant.getInt(this, ShareConstants.RATE_RECOVER_IMAGE_COUNT) >= 4) {
                SharedPrefsConstant.save(this, ShareConstants.RATE_RECOVER_IMAGE_COUNT, 0)
            }
            if (SharedPrefsConstant.getInt(this, ShareConstants.RATE_DUPLICATE_COUNT) >= 3) {
                SharedPrefsConstant.save(this, ShareConstants.RATE_DUPLICATE_COUNT, 0)
            }
            if (SharedPrefsConstant.getInt(this, ShareConstants.RATE_DEVICE_INFO) >= 3) {
                SharedPrefsConstant.save(this, ShareConstants.RATE_DEVICE_INFO, 0)
            }
            if (SharedPrefsConstant.getInt(this, ShareConstants.RATE_JUNK_CLEANER) >= 3) {
                SharedPrefsConstant.save(this, ShareConstants.RATE_JUNK_CLEANER, 0)
            }
            if (SharedPrefsConstant.getInt(this, ShareConstants.RATE_UNINSTALLER) >= 3) {
                SharedPrefsConstant.save(this, ShareConstants.RATE_UNINSTALLER, 0)
            }
            listener.onRate(-1)
            dialog.dismiss()
        }

        btnOk.setOnClickListener {
            Log.e(mTAG, "ratingStar.rating : ${ratingStar.rating}")
            dialog.dismiss()
            RATING = ratingStar.rating.toInt()
            ExitSPHelper(this).saveRate()
            listener.onRate(RATING)
        }
//        dialog.setOnDismissListener { listener.onRate(RATING) }
        ratingStar.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->

            when(rating.toInt()) {
                1->{
                    imageIcon.setImageResource(R.drawable.ic_rate_one)
                }
                2->{
                    imageIcon.setImageResource(R.drawable.ic_rate_two)
                }
                3->{
                    imageIcon.setImageResource(R.drawable.ic_rate_three)
                }
                4->{
                    imageIcon.setImageResource(R.drawable.ic_rate_four)
                }
                5->{
                    imageIcon.setImageResource(R.drawable.ic_rate_five)
                }
            }
//            dialog.dismiss()

            RATING = rating.toInt()
//            ExitSPHelper(this).saveRate()
        }

        dialog.show()
    } catch (ignored: Exception) {
        Log.e(mTAG, ignored.toString())
    }
}

fun Context.ratingFeedback(rate: Int) {
    try {
        Log.i(mTAG, "Rate Dialog called")
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_rate_feedback)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        val inflater = (this as Activity).layoutInflater
//        val alertLayout = inflater.inflate(R.layout.dialog_rate_feedback, null)

        val btnDismiss = dialog.findViewById<TextView>(R.id.dialogButtonClose)
        val btnOk = dialog.findViewById<TextView>(R.id.dialogButtonok)
        val rv_option = dialog.findViewById<RecyclerView>(R.id.rv_option)

        val listOptions: Array<String> = (this).resources.getStringArray(R.array.rate_feedback)

        var reason=listOptions[0]

        val optionsAdapter = OptionsAdapter(this, listOptions, object : RVClickListener {
            override fun onItemClick(position: Int) {
                reason=listOptions[position]
            }
        })
        rv_option.addItemDecoration(RvGridSpacingItemDecoration(1, 0, true))
        rv_option.adapter = optionsAdapter

        val tvTitle = dialog.findViewById<TextView>(R.id.permission)
        val tf = Typeface.createFromAsset(assets, fontPath)
        tvTitle.typeface = tf
//        btnDismiss.typeface = tf
//        val alert = AlertDialog.Builder(this)
//        alert.setView(alertLayout)
//        alert.setCancelable(false)
//        val dialog = alert.create()

        btnDismiss.setOnClickListener {
            dialog.dismiss()
        }
        btnOk.setOnClickListener {
            startActivity(FeedbackActivity.newIntent(this, rate,reason))
//            val i = Intent(this, FeedbackActivity::class.java)
//            i.putExtra("key_smile", rate)
//            i.putExtra("key_reason", reason)
//            startActivity(i)

            dialog.dismiss()
        }
        dialog.setOnDismissListener { }


        dialog.show()
    } catch (ignored: Exception) {
        Log.e(mTAG, ignored.toString())
    }
}

//fun Activity.inAppReview() {
//    Log.i(TAG, "inAppReview")
//    try {
//        val manager: ReviewManager = ReviewManagerFactory.create(this)
//        val request = manager.requestReviewFlow()
//        request.addOnCompleteListener { task ->
//            if (task.isSuccessful) {
//                Log.i(TAG, "task: success")
//                // We can get the ReviewInfo object
//                val reviewInfo: ReviewInfo = task.result
//                val flow: Task<Void> = manager.launchReviewFlow(this, reviewInfo)
//                flow.addOnCompleteListener { result ->
//                    when {
//                        result.isSuccessful -> {
//                            Log.i(TAG, "result: success: " + result.result)
//                        }
//                        result.isComplete -> {
//                            Log.i(TAG, "result: complete: " + result.result)
//                        }
//                        else -> {
//                            Log.e(TAG, "result: failure: " + result.exception)
//                        }
//                    }
//                }
//            } else {
//                //Problem in receiving object
//                Log.e(TAG, "task: failure")
//                rateApp()
//            }
//        }
//    } catch (activityNotFound: ActivityNotFoundException) {
//        Log.e(TAG, "Error: $activityNotFound")
//        rateApp()
//    }
//}


fun Context.rateApp() {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
    } catch (e: ActivityNotFoundException) {
        Log.e(mTAG, e.toString())
        startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
            )
        )
    }
}

interface OnRateListener {
    fun onRate(rate: Int)
}