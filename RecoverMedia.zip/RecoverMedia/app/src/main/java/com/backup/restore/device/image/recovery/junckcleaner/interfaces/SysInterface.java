package com.backup.restore.device.image.recovery.junckcleaner.interfaces;

public interface SysInterface {
        void sysDone(boolean flag);
    }
