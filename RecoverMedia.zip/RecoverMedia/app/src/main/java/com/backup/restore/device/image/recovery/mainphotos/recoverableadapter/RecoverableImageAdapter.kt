package com.backup.restore.device.image.recovery.mainphotos.recoverableadapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableImageModel
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.bumptech.glide.Glide
import java.io.File
import java.util.*

class RecoverableImageAdapter(
    var mScanImageRecycle: RecyclerView,
    private val mContext: Context,
    private val loImageList: List<RecoverableImageModel>,
    private val checkAll: CheckBox
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var TAG = javaClass.simpleName

    class MyRecoverableViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvDir: TextView = view.findViewById(R.id.tvDir)
        var thumbnail: ImageView = view.findViewById(R.id.imgItem)
        var rlItem: ImageView = view.findViewById(R.id.rlItem)
        var imgType: ImageView = view.findViewById(R.id.imgType)
        var rlItemFrame: FrameLayout = view.findViewById(R.id.rlItemFrame)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.raw_image_item, parent, false)
        return MyRecoverableViewHolder(itemView)
    }

    override fun onBindViewHolder(holders: RecyclerView.ViewHolder, position: Int) {
        val holder = holders as MyRecoverableViewHolder
        try {
            Glide.with(mContext)
                .load(File(loImageList[position].filePath))
                .override(300, 300)
                .placeholder(R.drawable.img_thumb)
                .into(holder.thumbnail)
        } catch (e:Exception) {

        }

        val lExtension=File(loImageList[position].filePath).extension
        val isVideo = SharedPrefsConstant.VideoArray.contains(lExtension)
        if(isVideo) holder.imgType.visibility=View.VISIBLE
        else holder.imgType.visibility=View.GONE

        holder.tvDir.text = String.format("%s", ShareConstants.getReadableFileSize(File(loImageList[position].filePath).length()))
        holder.rlItem.isSelected = loImageList[position].isSelected
        holder.rlItemFrame.isSelected = loImageList[position].isSelected
        holder.rlItemFrame.setOnClickListener {
            val selection = !holder.rlItem.isSelected
            val selection1 = !holder.rlItemFrame.isSelected
            loImageList[position].isSelected = selection
            holder.rlItem.isSelected = selection
            holder.rlItemFrame.isSelected = selection1

            if (checkAll.isChecked && getSelectedCounted() != itemCount) {
//                Log.e(TAG, "onBindViewHolder: " + checkAll.isChecked)
//                Log.e(TAG, "onBindViewHolder: " + getSelectedCounted())
//                Log.e(TAG, "onBindViewHolder: $itemCount")
                ShareConstants.isManualHiddenClick = true
                checkAll.isChecked = getSelectedCounted() == itemCount
            } else if (getSelectedCounted() == itemCount) {
                checkAll.isChecked = true
            }
        }
    }

    fun runLayoutAnimation() {
        val lController = AnimationUtils.loadLayoutAnimation(mContext, R.anim.layout_animation_fall_down)
        mScanImageRecycle.layoutAnimation = lController
        Objects.requireNonNull(mScanImageRecycle.adapter).notifyDataSetChanged()
        mScanImageRecycle.scheduleLayoutAnimation()
    }

    override fun getItemCount(): Int {
        return loImageList.size
    }

    fun getSelected(pos: Int): Boolean {
        return loImageList[pos].isSelected
    }

    fun getSelectedCounted(): Int {
        val selectedList = loImageList.filter { it.isSelected }
        return selectedList.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (itemCount > 0) {
            position
        } else super.getItemViewType(position)
    }
}