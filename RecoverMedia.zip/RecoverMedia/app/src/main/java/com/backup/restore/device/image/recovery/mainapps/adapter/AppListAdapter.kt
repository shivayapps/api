package com.backup.restore.device.image.recovery.mainapps.adapter

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.apkinfo.AppInfo
import com.bumptech.glide.Glide
import java.util.*


class AppListAdapter(
    private val mContext: Context,
    private var appInfoList: MutableList<AppInfo>,
    val onAppSelect: OnAppSelect,
    val appType: String
) : BaseAdapter() {


    interface OnAppSelect {
        fun onAppClick(position: Int, appInfo: AppInfo)
        fun onAppSelect(position: Int, isChecked: Boolean, appInfo: AppInfo)
    }

//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        return ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.raw_list_of_app, parent, false))
//    }

//    override fun getItemCount(): Int {
//        return appInfoList.size
//    }

//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val appInfo = appInfoList[position]
//        holder.tvTitle.text = appInfo.appName
//
//        val size = String.format(Locale.ENGLISH, "%.2f", appInfo.appSize!!.toFloat())
//        holder.tvDetail.text = "$size MB, ${appInfo.installedOn}"
//
//        val uri = appInfo.appDrawableURI
//        try {
//            if (uri != Uri.EMPTY)
//                Glide.with(mContext)
//                    .load(uri)
//                    .into(holder.ivThumb)
//            else {
//                val img = ContextCompat.getDrawable(mContext, R.drawable.appicon)
//                holder.ivThumb.setImageDrawable(img)
//            }
//        } catch (e: Exception) {
//            val img = ContextCompat.getDrawable(mContext, R.drawable.appicon)
//            holder.ivThumb.setImageDrawable(img)
//        }
//        holder.ivOption.setOnClickListener {
//            onAppSelect.onAppClick(position, appInfo)
//        }
//
//        holder.cbSelect.isChecked = appInfoList[position].isSelected
//
//        holder.cbSelect.setOnCheckedChangeListener { buttonView, isChecked ->
//            appInfoList[position].isSelected = isChecked
//
//            onAppSelect.onAppSelect(position, isChecked, appInfo)
//        }
//        holder.ivOption.visibility = View.VISIBLE
//        holder.ivDelete.visibility = View.GONE
//        if (appType == "user") {
//            holder.cbSelect.visibility = View.VISIBLE
//        } else {
//            holder.cbSelect.visibility = View.GONE
//        }
//
//    }

    class ViewHolder(itemView: View) {
        val tvTitle: TextView = itemView.findViewById(R.id.txt_name)
        val tvDetail: TextView = itemView.findViewById(R.id.tv_detail)
        val ivThumb: ImageView = itemView.findViewById(R.id.application_icon_image)
        val ivOption: ImageView = itemView.findViewById(R.id.img_arrow)
        val ivDelete: ImageView = itemView.findViewById(R.id.img_delete)
        val cbSelect: CheckBox = itemView.findViewById(R.id.cb_select)
    }

    fun countSelected(): Int {
        return appInfoList.filter { it.isSelected }.count()
    }

    fun updateList(items: List<AppInfo>?) {
        if (items != null) {
            if (items.isNotEmpty()) {
                appInfoList.clear()
                appInfoList.addAll(items)
                notifyDataSetChanged()
            }
        }
    }

    override fun getCount(): Int {
        return appInfoList.size
    }

    override fun getItem(position: Int): Any {
        return appInfoList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        val view: View?
        val holder: ViewHolder

        if (convertView == null) {
            val layoutInflater = LayoutInflater.from(mContext)
            view = layoutInflater.inflate(R.layout.raw_list_of_app, parent, false)
            holder = ViewHolder(view)
            view.tag = holder
        } else {
            view = convertView
            holder = view.tag as ViewHolder
        }


        val appInfo = appInfoList[position]
        holder.tvTitle.text = appInfo.appName

        val size = String.format(Locale.ENGLISH, "%.2f", appInfo.appSize!!.toFloat())
        holder.tvDetail.text = "$size MB, ${appInfo.installedOn}"

        val uri = appInfo.appDrawableURI
        try {
            if (uri != Uri.EMPTY)
                Glide.with(mContext)
                    .load(uri)
                    .into(holder.ivThumb)
            else {
                val img = ContextCompat.getDrawable(mContext, R.drawable.ic_icon)
                holder.ivThumb.setImageDrawable(img)
            }
        } catch (e: Exception) {
            val img = ContextCompat.getDrawable(mContext, R.drawable.ic_icon)
            holder.ivThumb.setImageDrawable(img)
        }
        holder.ivOption.setOnClickListener {
            onAppSelect.onAppClick(position, appInfo)
        }

//        holder.cbSelect.isChecked = selectedPackage.contains(appInfo.appPackage)
        if(appInfoList[position].isSelected && holder.tvTitle.text==appInfo.appName) {
            holder.cbSelect.isChecked = true
        } else {
            holder.cbSelect.isChecked = false
        }

        holder.cbSelect.setOnCheckedChangeListener { buttonView, isChecked ->
            appInfoList[position].isSelected = isChecked

            onAppSelect.onAppSelect(position, isChecked, appInfo)
        }
        holder.ivOption.visibility = View.VISIBLE
        holder.ivDelete.visibility = View.GONE
        if (appType == "user") {
            holder.cbSelect.visibility = View.VISIBLE
        } else {
            holder.cbSelect.visibility = View.GONE
        }

        return view
    }

//    fun getAppList(): MutableList<AppInfo> {
////        selectedAppList.clear()
////        for(app in appInfoList) {
////            if(app.isSelected) selectedAppList.add(app)
////        }
//        return selectedAppList
//    }
}