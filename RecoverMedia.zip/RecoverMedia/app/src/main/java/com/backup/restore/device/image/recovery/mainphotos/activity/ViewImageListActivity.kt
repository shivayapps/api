package com.backup.restore.device.image.recovery.mainphotos.activity

import android.app.*
import android.content.Intent
import android.os.*
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.adconfig.AdsConfig
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainphotos.recoverdadapter.RecoverableImageAdapter
import com.backup.restore.device.image.recovery.retriever.AlbumItem
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.*
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.*
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityViewImageListBinding
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class ViewImageListActivity : MyCommonBaseActivity() {

    var mTAG: String = "ViewRecoverableImageList"

//    var mGetRecoverableImage: AsyncTask<*, *, *>? = null
    private var mRecoverableImageAdapter: RecoverableImageAdapter? = null

//    private var moImageLists: MutableList<RecoverableImageModel> = ArrayList()
    private var isRecover = false
    var mFolderPath: String? = null
    private var mSavePath: String? = null

    var mIsDateClick = true
    var mIsSizeClick = true
//    private var mInterstitial: InterstitialAd? = null
    private var mIntent: Intent? = null

    companion object {
        var isAsyncRecover = false
        var moImageLists: ArrayList<AlbumItem> = ArrayList()
        var moFileLists: ArrayList<File> = ArrayList()
    }
    
    lateinit var binding: ActivityViewImageListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_view_image_list)
        binding=ActivityViewImageListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(ViewImageListActivity::class.simpleName!!)

//        var commonUsers = moImageLists.Select(a => a.User).Intersect(list2.Select(b => b.User));

    }

    override fun getContext(): AppCompatActivity {
        return this@ViewImageListActivity
    }

    override fun initData() {
//        stopServiceMethod()
        binding.scanImage!!.setHasFixedSize(true)
        binding.scanImage!!.isNestedScrollingEnabled = false

        isManualHiddenClick = false

        binding.ivSpan.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        binding.tvHeader.text = intent.getStringExtra("folderName")
        binding.tvHeader.isSelected=true

        mFolderPath = intent.getStringExtra("folderPath")
        mRootPath = Environment.getExternalStorageDirectory().toString()
        mSavePath = "$mRootPath/RecoverMedia/"

//        mRecoverableImageAdapter = SimpleImageAdapter(binding.scanImage, mContext, moImageLists)
        mRecoverableImageAdapter = RecoverableImageAdapter(
            this@ViewImageListActivity,
            mFolderPath!!,
            moImageLists,
            binding.scanImage,
            binding.tvPhoto,
            ImageView(mContext),
            object : RecoverableImageAdapter.OnClick {
                override fun click(position: Int,foldername: String) {
                    if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                        return
                    }
                    mLastClickTime = SystemClock.elapsedRealtime()

                    NewRecoverImageActivity.mIsFromForImageCheck = "Recovered"

                    val intent = Intent(mContext, FullScreenRecoverableAlbumItemActivity::class.java)
                    intent.putExtra("position", position)
                    intent.putExtra("foldername", File(mFolderPath).name)
                    mIntent=intent

//                    if (AdsManager(mContext).isNeedToShowAds() ) {

                        AdsConfig.showInterstitialAd(mContext,{
                            MyApplication.isInterstitialShown = false
                            if(mIntent!=null) mContext.startActivity(mIntent)
                        })
//                    } else {
//                        mContext.startActivity(mIntent)
//                    }
                }
            },
            false
        )

        binding.scanImage!!.adapter = mRecoverableImageAdapter
        spanCount()

        Log.e("TAG", "Root : $mSavePath")
//        mGetRecoverableImage = GetRecoverableImage().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)

        Handler(Looper.getMainLooper()).post {
            try {
                if (moImageLists.isEmpty()) {
                    binding.tvPhoto.visibility = View.VISIBLE
                    binding.scanImage!!.visibility = View.GONE
                    binding.ivSpan.alpha = 0.5F
                    binding.ivSpan.isEnabled = false
                    binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                    binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                    binding.tvDate.setTextColor(resources.getColor(R.color.filter_text_color))
                    binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                    finish()
                } else {
                    binding.scanImage!!.visibility = View.VISIBLE
                    binding.tvPhoto.visibility = View.GONE
                    binding.ivSpan.alpha = 1F
                    binding.ivSpan.isEnabled = true
                    mIsDateClick = true
                    binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                    binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                    binding.tvDate.setTextColor(resources.getColor(R.color.colorPrimary))
                    binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                    binding.scanImage!!.layoutManager = GridLayoutManager(mContext, mContext.getGridCount())
                    Collections.sort(moImageLists, dateComparatorAlbumItem())
//                    mRecoverableImageAdapter!!.runLayoutAnimation()
                }

                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    try {
                        binding.lottieAnim.visibility = View.GONE
                        binding.ivSpan.alpha = 1F
                        binding.ivSpan.isEnabled = true
                    } catch (e: Exception) {
//                            mContext.addEvent(e.message!!)
                    }
                }, 500)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

//        if (AdsManager(mContext).isNeedToShowAds()) {
//            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
//        }

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            NativeAdHelper(this,binding.adview, NativeLayoutType.NativeMedium,getString(R.string.native_application)).loadAd()
//        } else {
//            binding.adview.visibility = View.GONE
//        }
    }

    private fun startServiceMethod() {
        try {
            SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", false)
        } catch (e: java.lang.Exception) {
            Log.e("mTAG", "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }

    private fun stopServiceMethod() {
        try {
            SharedPrefsConstant.savePrefNoti(mContext, "isDeleteFromEmpty", true)
        } catch (e: java.lang.Exception) {
            Log.e("mTAG", "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }
    override fun initActions() {
        binding.ivBack!!.setOnClickListener {
            onBackPressed()
        }

        binding.ivSpan.setOnClickListener {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            setSpanCount()
        }

        binding.llDateWise.setOnClickListener {
            if (moImageLists.isNotEmpty()) {
                binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                binding.tvSize.setTextColor(resources.getColor(R.color.filter_text_color))
                binding.tvDate.setTextColor(resources.getColor(R.color.colorAccent))
                if (mIsDateClick) {
                    Collections.sort(moImageLists, dateComparatorAlbumItem())
                    mIsDateClick = false
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                } else {
                    Collections.sort(moImageLists, dateComparatorReversAlbumItem())
                    mIsDateClick = true
                    binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down))
                }
                mIsSizeClick = true
                mRecoverableImageAdapter!!.notifyDataSetChanged()
            }
        }
        binding.llSizeWise.setOnClickListener {
            if (moImageLists.isNotEmpty()) {
                binding.llDateWise.background = resources.getDrawable(R.drawable.tab_box_un_fill)
                binding.llSizeWise.background = resources.getDrawable(R.drawable.tab_box_fill)
                binding.selectUpDate.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect))
                binding.tvDate.setTextColor(resources.getColor(R.color.filter_text_color))
                binding.tvSize.setTextColor(resources.getColor(R.color.colorAccent))
                if (mIsSizeClick) {
                    Collections.sort(moImageLists, sizeComparatorAlbumItem())
                    mIsSizeClick = false
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up))
                } else {
                    Collections.sort(moImageLists, sizeComparatorReversAlbumItem())
                    mIsSizeClick = true
                    binding.selectUpSize.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down))
                }
                mIsDateClick = true
                mRecoverableImageAdapter!!.notifyDataSetChanged()
            }
        }
    }

    var mNotificationManager: NotificationManager? = null
    var isBackground = false
    var isBackPressed = false

//    private fun createGridItems(
//        directoryPath: String?,
//        moProgressDialog: Dialog?
//    ): ArrayList<File> {
//        val files = File(directoryPath!!).listFiles()
//        if (files != null) {
//            for (file in files) {
//                if (file.isDirectory) {
//                } else {
//                    val filePath = file.absolutePath
//                    val lExtension = getExtension(filePath)
//                    val isExtensionMatches = ImageArray.contains(lExtension) && filePath.endsWith(lExtension)
//                    if (isExtensionMatches && file.length().toString() != "0") {
//                        if (filePath.contains("/.")) {
//                        }else{
//                            moImageLists.add(File(filePath))
//                            runOnUiThread {
//                                Handler(Looper.getMainLooper()).post {
//                                    Log.e(mTAG, "gridRecoverableAlbumImage: " + moImageLists.size)
//                                    mRecoverableImageAdapter!!.notifyDataSetChanged()
//                                }
//                            }
//                        }
//                    }
//                }
//                if (mGetRecoverableImage != null) {
//                    if (mGetRecoverableImage!!.isCancelled) {
//                        runOnUiThread {
//                            moProgressDialog!!.cancel()
//                            MyApplication.isDialogOpen = false
//                            finish()
//                            overridePendingTransition(
//                                android.R.anim.fade_in,
//                                android.R.anim.fade_out
//                            )
//                        }
//                        break
//                    }
//                }
//            }
//        }
//        return moImageLists
//    }

    private fun setSpanCount() {
        var mCurrentSpanCount = mContext.getGridCount()
        mCurrentSpanCount = if (mCurrentSpanCount == SPAN_COUNT_THREE) {
            SPAN_COUNT_TWO
        } else {
            SPAN_COUNT_THREE
        }
        mContext.saveGridCount(mCurrentSpanCount)
        binding.ivSpan.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        spanCount()
    }

    fun spanCount() {
        if (mRecoverableImageAdapter != null) {
            val lCurrentSpanCount = mContext.getGridCount()
            if (binding.scanImage!!.itemDecorationCount > 0) {
                binding.scanImage!!.removeItemDecorationAt(0)
            }
            binding.scanImage!!.layoutManager = GridLayoutManager(mContext, lCurrentSpanCount)
            mRecoverableImageAdapter!!.notifyItemRangeChanged(0, lCurrentSpanCount)
        }
    }

//    fun selectAll() {
//        for (i in moImageLists.indices) {
//            moImageLists[i].isSelected = true
//        }
//        Log.e(mTAG, "selectAll: moImageLists " + moImageLists.size)
//    }

//    fun diSelectAll() {
//        for (i in moImageLists.indices) {
//            moImageLists[i].isSelected = false
//        }
//    }

    public override fun onPause() {
        super.onPause()
//        if (isRecover) {
//            if (mRecoverableImageAdapter!!.getSelectedCounted() != 0) {
//                AsyncTaskRunner().cancel(true)
//                Log.e(mTAG, "onPause: AsyncTask Cancel")
//            }
//        }
    }

    public override fun onResume() {
        super.onResume()
        changeLanguage()
        if (isRecover) {
            Log.e(mTAG, "onResume: new Recover ")
        }

        if (NewRecoverImageActivity.isRefresh) {
            initData()
            NewRecoverImageActivity.isRefresh = false
        }
    }

    override fun onBackPressed() {
        startServiceMethod()
        isBackPressed=true
        isBackground=true
//        if(mGetRecoverableImage!=null) {
//            if(mGetRecoverableImage?.status==AsyncTask.Status.RUNNING) {
//                mGetRecoverableImage?.cancel(true)
//            }
//        }
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

}