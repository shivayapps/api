package com.backup.restore.device.image.recovery.database;
//package com.codepath.examples.contactloader;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;

import androidx.loader.content.CursorLoader;

import com.backup.restore.device.image.recovery.maincontact.model.ContactModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ContactFetcher {

    private final Context context;

    public ContactFetcher(Context c) {
        this.context = c;
    }

    public ArrayList<ContactModel> fetchAll() {
        String[] projectionFields = new String[]{
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Contacts.PHOTO_URI,
        };
        ArrayList<ContactModel> listContactModels = new ArrayList<>();
        CursorLoader cursorLoader = new CursorLoader(context,
                ContactsContract.Contacts.CONTENT_URI,
                projectionFields, // the columns to retrieve
                null, // the selection criteria (none)
                null, // the selection args (none)
                null // the sort order (default)
        );

        Cursor c = cursorLoader.loadInBackground();

        final Map<String, ContactModel> contactsMap;
        if (c != null) {
            contactsMap = new HashMap<>(c.getCount());

            if (c.moveToFirst()) {

                int idIndex = c.getColumnIndex(projectionFields[0]);
                int nameIndex = c.getColumnIndex(projectionFields[1]);
                int photoIndex = c.getColumnIndex(projectionFields[2]);

                do {
                    String contactId = c.getString(idIndex);
                    String contactDisplayName = c.getString(nameIndex);
                    String photoUri = c.getString(photoIndex);
                    ContactModel contactModel = new ContactModel();
                    //contactModel = new ContactModel(contactId, contactDisplayName,photoUri);
                    contactModel.setMContactId(contactId);
                    contactModel.setMContactName(contactDisplayName);
                    contactModel.setMContactImageUri(photoUri);
                    contactsMap.put(contactId, contactModel);

                    if(contactId==null) contactId="";
                    if(contactDisplayName==null) contactDisplayName="";
                    if(photoUri==null) photoUri="";
//                    Log.e("contactListData", "fetchAll:contactId:"+contactId);
//                    Log.e("contactListData", "fetchAll:contactDisplayName:"+contactDisplayName);
//                    Log.e("contactListData", "fetchAll:photoUri:"+photoUri);

//                    if(!contactId.isEmpty() && !contactDisplayName.isEmpty() && !photoUri.isEmpty()) {
                        listContactModels.add(contactModel);
//                    }
                } while (c.moveToNext());
            }
            c.close();

            matchContactNumbers(contactsMap);
            matchContactEmails(contactsMap);
            matchContactDOB(contactsMap);
        }

        return listContactModels;
    }

    public void matchContactNumbers(Map<String, ContactModel> contactsMap) {
//        Log.e("contactListData", "fetchAll:matchContactNumbers");
        // Get numbers
        final String[] numberProjection = new String[]{
                Phone.NUMBER,
                Phone.TYPE,
                Phone.CONTACT_ID,
        };
        Cursor phone = new CursorLoader(context,
                Phone.CONTENT_URI,
                numberProjection,
                null,
                null,
                null).loadInBackground();

        if (phone.moveToFirst()) {
//            Log.e("contactListData", "fetchAll:phone.moveToFirst()");
            final int contactNumberColumnIndex = phone.getColumnIndex(Phone.NUMBER);
//            final int contactTypeColumnIndex = phone.getColumnIndex(Phone.TYPE);
            final int contactIdColumnIndex = phone.getColumnIndex(Phone.CONTACT_ID);

//            Log.e("contactListData", "fetchAll:phone.getCount():"+phone.getCount());
//            Log.e("contactListData", "fetchAll:phone.getColumnCount():"+phone.getColumnCount());
            int i=0;
            while (!phone.isAfterLast()) {
                final String number = phone.getString(contactNumberColumnIndex);
                final String contactId = phone.getString(contactIdColumnIndex);
                ContactModel contactModel = contactsMap.get(contactId);
//                Log.e("contactListData", "fetchAll:number:"+number);
//                Log.e("contactListData", "fetchAll:contactId:"+contactId);
                if (contactModel == null) {
//                    Log.e("contactListData", "fetchAll:continue");
                    phone.moveToNext();
                    continue;
                }
//                final int type = phone.getInt(contactTypeColumnIndex);
//                String customLabel = "Custom";
//                CharSequence phoneType = Phone.getTypeLabel(context.getResources(), type, customLabel);
                contactModel.setMNumber(number);
                phone.moveToNext();
//                Log.e("contactListData", "fetchAll:iiiii:"+i);
//                Log.e("contactListData", "fetchAll:matchContactNumbers:"+number);
            }
        }

        phone.close();
    }

    public void matchContactEmails(Map<String, ContactModel> contactsMap) {
//        Log.e("contactListData", "fetchAll:matchContactEmails");
        // Get email
        final String[] emailProjection = new String[]{
                ContactsContract.CommonDataKinds.Email.DATA,
                ContactsContract.CommonDataKinds.Email.TYPE,
                ContactsContract.CommonDataKinds.Email.CONTACT_ID,
        };

        Cursor email = new CursorLoader(context,
                ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                emailProjection,
                null,
                null,
                null).loadInBackground();

        if (email.moveToFirst()) {
            final int contactEmailColumnIndex = email.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA);
            final int contactTypeColumnIndex = email.getColumnIndex(ContactsContract.CommonDataKinds.Email.TYPE);
            final int contactIdColumnsIndex = email.getColumnIndex(ContactsContract.CommonDataKinds.Email.CONTACT_ID);

            while (!email.isAfterLast()) {
                final String address = email.getString(contactEmailColumnIndex);
                final String contactId = email.getString(contactIdColumnsIndex);
                String customLabel = "Custom";
                ContactModel contact = contactsMap.get(contactId);
                if (contact == null) {
                    email.moveToNext();
                    continue;
                }
                contact.setMEmail(address);
                email.moveToNext();
//                Log.e("contactListData", "fetchAll:matchContactEmails:"+address);
            }
        }

        email.close();
    }


    public void matchContactDOB(Map<String, ContactModel> contactsMap) {
//        Log.e("contactListData", "fetchAll:matchContactDOB");

        String[] projection = new String[]{
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Event.CONTACT_ID,
                ContactsContract.CommonDataKinds.Event.START_DATE
        };

        String where =
                ContactsContract.Data.MIMETYPE + "= ? AND " +
                        ContactsContract.CommonDataKinds.Event.TYPE + "=" +
                        ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY;
        String[] selectionArgs = new String[]{
                ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE
        };
        String sortOrder = null;
        Cursor cursor = new CursorLoader(context,
                ContactsContract.Data.CONTENT_URI, projection, where, selectionArgs, sortOrder
        ).loadInBackground();

        if (!cursor.isAfterLast()) {
            final int contactIdColumnsIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.CONTACT_ID);
            int birthDayColumnIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Event.START_DATE);

            while (cursor.moveToNext()) {

                final String bDay = cursor.getString(birthDayColumnIndex);
                final String contactId = cursor.getString(contactIdColumnsIndex);

                ContactModel contact = contactsMap.get(contactId);
                if (contact == null) {
                    cursor.moveToNext();
                    continue;
                }
                contact.setMDOB(bDay);
                cursor.moveToNext();
//                Log.e("contactListData", "fetchAll:matchContactDOB:"+bDay);
            }
        }
    }
}
