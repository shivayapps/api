package com.backup.restore.device.image.recovery.mainapps.model

class FeaturesHW(var featureLable: String, var featureValue: String, var percentage: Long=-1)