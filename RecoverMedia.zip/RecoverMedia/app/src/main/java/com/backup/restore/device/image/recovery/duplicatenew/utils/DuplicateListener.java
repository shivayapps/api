package com.backup.restore.device.image.recovery.duplicatenew.utils;

public interface DuplicateListener {
    void duplicateListener();
}
