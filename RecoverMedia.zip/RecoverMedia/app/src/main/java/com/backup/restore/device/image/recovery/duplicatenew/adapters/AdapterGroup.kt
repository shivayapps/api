package com.backup.restore.device.image.recovery.duplicatenew.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.text.format.Formatter
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails
import com.backup.restore.device.image.recovery.duplicatenew.utils.Constants
import com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities.NewDuplicateMediaActivityNEW
import com.backup.restore.device.image.recovery.mainduplicate.activity.previewactivities.*
import com.backup.restore.device.image.recovery.utilities.MyAnnotations
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.bumptech.glide.Glide

class AdapterGroup(
    private val context: Context,
    //private val fileDetailsArrayList: List<FileDetails>,
    scanType: String,
    val listPosition: Int,
    private val checkboxGroup: CheckBox,
    val onSizeUpdate: () -> Unit
) : RecyclerView.Adapter<AdapterGroup.ContactViewHolder>() {
    var scanType = ""

    val selectedFile: ArrayList<FileDetails> = ArrayList<FileDetails>()
    var total: Long = 0

    init {
        this.scanType = scanType
    }

    inner class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val chcekbox: CheckBox = itemView.findViewById(R.id.checkbox_video)
        val llCheckbox: LinearLayout = itemView.findViewById(R.id.ll_checkbox)
        val textViewSize: TextView = itemView.findViewById(R.id.tvSize)
        val fileName: TextView = itemView.findViewById(R.id.fileName)
        val filePath: TextView = itemView.findViewById(R.id.filePath)
        val imageViewIcon: ImageView = itemView.findViewById(R.id.duplicate_video)
        val imageViewPlay: ImageView = itemView.findViewById(R.id.imageViewPlay)

//        init {
//            this.textViewTitle = itemView.findViewById(R.id.tvTitle);
//        }
    }

    fun getSelectedFiles(): ArrayList<FileDetails> {
        selectedFile.clear()
        selectedFile.addAll(GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!!.filter { it.isChecked })
        return selectedFile
    }

    fun getTotalSize(): Long {
        return total
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        if(scanType==MyAnnotations.IMAGES || scanType==MyAnnotations.VIDEOS) {
            return ContactViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.group_video, parent, false))
        } else if(scanType==MyAnnotations.AUDIOS || scanType==MyAnnotations.DOCUMENTS || scanType==MyAnnotations.OTHER) {
            return ContactViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.raw_list_of_document_files_item, parent, false))
        } else  {
            return ContactViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.group_video, parent, false))
        }
    }

    override fun onBindViewHolder(holder: ContactViewHolder, @SuppressLint("RecyclerView") position: Int) {

        val fileDetails = GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!![position]
        holder.textViewSize.text = Formatter.formatFileSize(context,fileDetails.fileSize)
        holder.fileName.text = fileDetails.fileName
        holder.filePath.text = fileDetails.filePath

        if(!NewDuplicateMediaActivityNEW.isScanRunning) {
            holder.fileName.isSelected = true
            holder.filePath.isSelected = true
        }

        holder.chcekbox.isChecked = fileDetails.isChecked
        when (scanType) {
            MyAnnotations.IMAGES -> {
                Glide.with(context)
                    .load("file:///" + Uri.decode(fileDetails.filePath))
                    .override(300, 300)
                    .placeholder(R.drawable.img_thumb)
                    .into(holder.imageViewIcon)
            }
            MyAnnotations.VIDEOS -> {
                holder.imageViewPlay.visibility = View.VISIBLE
                Glide.with(context)
                    .load("file:///" + Uri.decode(fileDetails.filePath))
                    .override(300, 300)
                    .placeholder(R.drawable.img_thumb)
                    .into(holder.imageViewIcon)
            }
            MyAnnotations.AUDIOS -> {
                Glide.with(context)
                    .load(R.drawable.ic_audios)
                    .override(300, 300)
                    .placeholder(R.drawable.ic_audios)
                    .into(holder.imageViewIcon)
            }
            MyAnnotations.DOCUMENTS -> {
                Glide.with(context)
                    .load(R.drawable.ic_doc_file)
                    .override(300, 300)
                    .placeholder(R.drawable.ic_doc_file)
                    .into(holder.imageViewIcon)
            }
            MyAnnotations.OTHER -> {
                Glide.with(context)
                    .load(R.drawable.ic_doc_file)
                    .override(300, 300)
                    .placeholder(R.drawable.ic_doc_file)
                    .into(holder.imageViewIcon)
            }
        }

//        holder.chcekbox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            holder.llCheckbox.setOnClickListener {
                if(NewDuplicateMediaActivityNEW.isScanRunning) {
                    Toast.makeText(context,context.getString(R.string.process_running_please_wait), Toast.LENGTH_SHORT).show()
                } else {

                    holder.chcekbox.toggle()
                    fileDetails.isChecked = holder.chcekbox.isChecked
                    val selectCount = getSelectedFiles().size
                    val numOffline = itemCount
                    if (fileDetails.isChecked) {

                        if (selectCount != numOffline) {
                            GlobalVarsAndFunctions.fileToBeDeleted.add(fileDetails)
                            Constants.addSize(fileDetails.fileSize)
//                        selectedFile.add(fileDetails)
                            total += fileDetails.fileSize
//                        duplicateListener?.updateMarked()
                            checkboxGroup.isChecked = true
                            onSizeUpdate.invoke()
                            //individualGroupPhotos.isCheckBox = true
                        }
                    } else {
                        GlobalVarsAndFunctions.fileToBeDeleted.remove(fileDetails)
                        Constants.minusSize(fileDetails.fileSize)

//                    selectedFile.remove(fileDetails)
                        total -= fileDetails.fileSize
//                    duplicateListener?.updateMarked()
                        onSizeUpdate.invoke()
                    }

                    Log.e("checkboxGroup", "onBindViewHolder selectCount: $selectCount" )
                    Log.e("checkboxGroup", "onBindViewHolder numOffline: $numOffline" )
                    checkboxGroup.isChecked = selectCount >= (numOffline - 1)

                    if (numOffline == selectCount) {
                        MyUtils.showToastMsg(context, context.getString(R.string.photo_same_not_select))
                        fileDetails.isChecked = false
                        holder.chcekbox.isChecked = false
                        return@setOnClickListener
                    }
                    fileDetails.isChecked = holder.chcekbox.isChecked
                    GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!![position].isChecked=holder.chcekbox.isChecked
                }
            }
//        }

//        holder.chcekbox.setOnClickListener { view: View? ->
//            val count=fileDetailsArrayList.filter { it.isChecked }
//            if(fileDetailsArrayList.size-1 == count.size) {
//                MyUtils.showToastMsg(context, context.getString(R.string.photo_same_not_select))
//                return@setOnClickListener
//            }
//            fileDetails.isChecked = !fileDetails.isChecked
//            if (duplicateListener != null) {
//                duplicateListener!!.updateMarked()
//            }
//            holder.chcekbox.isChecked = fileDetails.isChecked
//
//            val newCount=fileDetailsArrayList.filter { it.isChecked }
//            checkboxGroup.isSelected = fileDetailsArrayList.size-1 == newCount.size
//        }

        holder.itemView.setOnClickListener { view: View? ->
            if (scanType == MyAnnotations.IMAGES) {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                val intent = Intent(context, PreviewPhotosActivity::class.java)
                val bundle = Bundle()
                bundle.putSerializable("imageItem", fileDetails)
                intent.putExtras(bundle)
                intent.putExtra("totalNumberOfFiles", GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!!.size)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())

                return@setOnClickListener
            } else if (scanType == MyAnnotations.VIDEOS) {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                val intent = Intent(context, PreviewVideoActivity::class.java)
                val bundle = Bundle()
                bundle.putSerializable("videoItem", fileDetails)
                intent.putExtras(bundle)
                intent.putExtra("totalNumberOfFiles", GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!!.size)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())

                return@setOnClickListener
            } else if (scanType == MyAnnotations.AUDIOS) {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                val intent = Intent(context, PreviewAudioActivity::class.java)
                val bundle = Bundle()
                bundle.putSerializable("audioFile", fileDetails)
                intent.putExtras(bundle)
                intent.putExtra("totalNumberOfFiles", GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!!.size)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())

                return@setOnClickListener
            } else if (scanType == MyAnnotations.DOCUMENTS) {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                val intent = Intent(context, PreviewDocumentActivity::class.java)
                val bundle = Bundle()
                bundle.putSerializable("documentFile", fileDetails)
                intent.putExtras(bundle)
                intent.putExtra("totalNumberOfFiles", GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!!.size)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
                return@setOnClickListener
            } else if (scanType == MyAnnotations.OTHER) {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                val intent = Intent(context, PreviewOthersActivity::class.java)
                val bundle = Bundle()
                bundle.putSerializable("otherFiles", fileDetails)
                intent.putExtras(bundle)
                intent.putExtra("totalNumberOfFiles", GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!!.size)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
                return@setOnClickListener
            }
        }
    }

    override fun getItemCount(): Int {
        return GlobalVarsAndFunctions.listOfDuplicates[listPosition].individualGrpOfDupes!!.size
    }

    fun imagesExtensions(): List<String> {
        val list: MutableList<String> = ArrayList()
        list.add(".jpg")
        list.add(".png")
        list.add(".gif")
        list.add(".webp")
        list.add(".tiff")
        list.add(".psd")
        list.add(".raw")
        list.add(".bmp")
        list.add(".heif")
        list.add(".indd")
        list.add(".jpeg")
        list.add(".svg")
        list.add(".arw")
        list.add(".cr2")
        list.add(".nrw")
        list.add(".k25")
        list.add(".dib")
        list.add(".heic")
        list.add(".ind")
        list.add(".indt")
        list.add(".jp2")
        list.add(".j2k")
        list.add(".jpf")
        list.add(".jpx")
        list.add(".jpm")
        list.add(".mj2")
        list.add(".svgz")
        list.add(".tif")
        return list
    }

    fun videosExtensions(): List<String> {
        val list: MutableList<String> = ArrayList()
        list.add(".webm")
        list.add(".mkv")
        list.add(".flv")
        list.add(".vob")
        list.add(".ogv")
        list.add(".ogg")
        list.add(".rrc")
        list.add(".gifv")
        list.add(".mng")
        list.add(".mov")
        list.add(".avi")
        list.add(".qt")
        list.add(".wmv")
        list.add(".yuv")
        list.add(".rm")
        list.add(".asf")
        list.add(".amv")
        list.add(".mp4")
        list.add(".m4p")
        list.add(".m4v")
        list.add(".mpg")
        list.add(".mp2")
        list.add(".mpeg")
        list.add(".mpe")
        list.add(".mpv")
        list.add(".m4v")
        list.add(".svi")
        list.add(".3gp")
        list.add(".3g2")
        list.add(".mxf")
        list.add(".roq")
        list.add(".nsv")
        list.add(".flv")
        list.add(".f4v")
        list.add(".f4p")
        list.add(".f4a")
        list.add(".f4b")
        return list
    }

    fun audiosExtensions(): List<String> {
        val list: MutableList<String> = ArrayList()
        list.add(".3gp")
        list.add(".aa")
        list.add(".aac")
        list.add(".aax")
        list.add(".act")
        list.add(".aiff")
        list.add(".alac")
        list.add(".amr")
        list.add(".ape")
        list.add(".au")
        list.add(".awb")
        list.add(".dss")
        list.add(".dvf")
        list.add(".flac")
        list.add(".gsm")
        list.add(".iklax")
        list.add(".ivs")
        list.add(".m4b")
        list.add(".mmf")
        list.add(".mp3")
        list.add(".mpc")
        list.add(".msv")
        list.add(".nmf")
        list.add(".wav")
        list.add(".wma")
        list.add(".wv")
        list.add(".webm")
        return list
    }

    fun documentsExtensions(): List<String> {
        val list: MutableList<String> = ArrayList()
        list.add(".pdf")
        list.add(".docx")
        list.add(".dotx")
        list.add(".docm")
        list.add(".dot")
        list.add(".doc")
        list.add(".ppt")
        list.add(".snp")
        list.add(".ppsm")
        list.add(".pptm")
        list.add(".pdi")
        list.add(".pot")
        list.add(".adp")
        list.add(".1sp")
        list.add(".potx")
        list.add(".xsn")
        list.add(".vsd")
        list.add(".mpp")
        list.add(".pmx")
        list.add(".mpx")
        list.add(".js")
        list.add(".py")
        list.add(".csv")
        list.add(".a7z")
        list.add(".csv")
        list.add(".aql")
        list.add(".html")
        list.add(".php")
        list.add(".exi")
        list.add(".apk")
        list.add(".db")
        list.add(".log")
        list.add(".temp")
        return list
    }

}