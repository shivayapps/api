package com.backup.restore.device.image.recovery.mainphotos.callbacks

import com.backup.restore.device.image.recovery.retriever.Album

interface AlbumClickListener {
    fun onPicClicked(albumItem: Album?, folderName: String?)
}