package com.backup.restore.device.image.recovery.database;

import static com.backup.restore.device.image.recovery.utilities.common.MyUtils.logError;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateFoundAndSize;
import com.backup.restore.device.image.recovery.mainduplicate.model.IgnorePath;
import com.backup.restore.device.image.recovery.mainduplicate.model.IndividualGroupModel;
import com.backup.restore.device.image.recovery.mainduplicate.model.ItemDuplicateModel;
import com.backup.restore.device.image.recovery.mainduplicate.model.Md5Model;
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {
    public static int totalNumberOfDuplicatesAudios = 0;
    public static int totalNumberOfDuplicatesAudiosForNotification = 0;
    public static int totalNumberOfDuplicatesDocuments = 0;
    public static int totalNumberOfDuplicatesDocumentsForNotification = 0;
    public static int totalNumberOfDuplicatesOthers = 0;
    public static int totalNumberOfDuplicatesOthersForNotification = 0;
    public static int totalNumberOfDuplicatesPhotos = 0;
    public static int totalNumberOfDuplicatesPhotosForNotification = 0;
    public static int totalNumberOfDuplicatesVideos = 0;
    public static int totalNumberOfDuplicatesVideosForNotification = 0;
    public int groupTagMediaAudios = 0;
    public int groupTagMediaDocuments = 0;
    public int groupTagMediaOthers = 0;
    public int groupTagMediaPhotos = 0;
    public int groupTagMediaVideos = 0;
    public Context mContext;

    public DBHandler(Context context) {
        super(context, GlobalVarsAndFunctions.DATABASE_NAME, null, 1);
        mContext=context;
    }

    public void onCreate(SQLiteDatabase db) {
        logError("MD5 database Created");
        db.execSQL("CREATE TABLE allFilesInfoTable( md5 TEXT, path TEXT, extension TEXT)");
        db.execSQL("CREATE TABLE allFilesInfoTableNotification( md5 TEXT, path TEXT, extension TEXT)");
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        logError("MD5 database updated");
        db.execSQL("DROP TABLE IF EXISTS allFilesInfoTable");
        db.execSQL("DROP TABLE IF EXISTS allFilesInfoTableNotification");
        onCreate(db);
    }

    public void addMd5ValueOfFiles(Md5Model md5Model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GlobalVarsAndFunctions.KEY_MD5, md5Model.getMd5Value());
        values.put(GlobalVarsAndFunctions.KEY_PATH, md5Model.getFilePath());
        values.put(GlobalVarsAndFunctions.KEY_EXTENSION, md5Model.getExtension().toLowerCase());
        db.insert(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO, null, values);
        db.close();
    }

    public void addMd5ValueOfFilesForNotification(Md5Model md5Model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GlobalVarsAndFunctions.KEY_MD5, md5Model.getMd5Value());
        values.put(GlobalVarsAndFunctions.KEY_PATH, md5Model.getFilePath());
        values.put(GlobalVarsAndFunctions.KEY_EXTENSION, md5Model.getExtension().toLowerCase());
        db.insert(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO_NOTIFICATION, null, values);
        db.close();
    }






    public void clearAllFilesInfoTable() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(GlobalVarsAndFunctions.TABLE_ALL_FILES_INFO, null, null);
    }

    private int totalNumberOfDuplicatesPhotos() {
        totalNumberOfDuplicatesPhotos++;
        return totalNumberOfDuplicatesPhotos;
    }

    private int totalNumberOfDuplicatesVideos() {
        totalNumberOfDuplicatesVideos++;
        return totalNumberOfDuplicatesVideos;
    }

    private int totalNumberOfDuplicatesAudios() {
        totalNumberOfDuplicatesAudios++;
        return totalNumberOfDuplicatesAudios;
    }

    private int totalNumberOfDuplicatesDocuments() {
        totalNumberOfDuplicatesDocuments++;
        return totalNumberOfDuplicatesDocuments;
    }

    private int totalNumberOfDuplicatesOthers() {
        totalNumberOfDuplicatesOthers++;
        return totalNumberOfDuplicatesOthers;
    }


}
