package com.backup.restore.device.image.recovery.mainduplicate.adapter

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.SystemClock
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amulyakhare.textdrawable.TextDrawable
import com.amulyakhare.textdrawable.util.ColorGenerator
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateContactModel
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.mLastClickTime
import com.bumptech.glide.Glide

class ListContactAdapter(
    var mContext: Context,
    var contacts: ArrayList<DuplicateContactModel>
) : RecyclerView.Adapter<ListContactAdapter.ContactViewHolder>() {

    private val mColorGenerator = ColorGenerator.MATERIAL
    private var mDrawableBuilder: TextDrawable.IBuilder? = null


    var inflater: LayoutInflater =
        mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0

    class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var contactName: TextView = itemView.findViewById(R.id.contactName)
        var llEmail: LinearLayout = itemView.findViewById(R.id.llEmail)
        var contactEmail: TextView = itemView.findViewById(R.id.contactEmail)
        var contactNumber: TextView = itemView.findViewById(R.id.contactNumber)
        var mContactIcon: ImageView = itemView.findViewById(R.id.ContactIcon)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        return ContactViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.raw_list_of_contact_files_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        val lContactItem = contacts[position]

        holder.contactEmail.isSelected = true
        holder.contactNumber.isSelected = true

        holder.contactName.text = lContactItem.mContactName

        var lEmail = ""
        if (!lContactItem.mContactEmail.equals("")) {
            holder.llEmail.visibility = View.VISIBLE
            lEmail =
                lContactItem.mContactEmail!!.replace("[", "").replace("]", "").replace("\"", "")
            lEmail = lEmail.substring(0, lEmail.length - 1)
        } else {
            holder.llEmail.visibility = View.GONE
        }
        holder.contactEmail.text = lEmail


        val lNum = lContactItem.mContactNumber!!.replace("[", "").replace("]", "").replace("\"", "")
        holder.contactNumber.text = lNum.substring(0, lNum.length - 1)

        /* if (lContactItem.mContactName!!.isNotEmpty()) {
             val mTypeface: Typeface = Typeface.createFromAsset(mContext.assets, "app_font/firasans_medium.ttf")
             mDrawableBuilder = TextDrawable.builder()
                 .beginConfig()
                 .bold()
                 .useFont(mTypeface)
                 .height(50)
                 .width(50)
                 .endConfig()
                 .round()

             val drawable = mDrawableBuilder!!.build(lContactItem.mContactName!![0].toString().capitalize(), mColorGenerator.getColor(lContactItem.mContactName!!))
             Glide.with(mContext).load(getPhotoUri(lContactItem.mContactId)).placeholder(drawable).into(holder.mContactIcon)
         } else {
             holder.mContactIcon.setImageDrawable(mContext.resources.getDrawable(R.drawable.no_user_contact_image))
         }
 */
        if (lContactItem.mIconUri!!.isNotEmpty()) {
            Glide.with(mContext).load(lContactItem.mIconUri)
                .error(mContext.resources.getDrawable(R.drawable.no_user_contact_image))
                .into(holder.mContactIcon)
        } else if (lContactItem.mIcon != null) {
            holder.mContactIcon.setImageDrawable(lContactItem.mIcon)
        } else {
            holder.mContactIcon.setImageDrawable(mContext.resources.getDrawable(R.drawable.no_user_contact_image))
        }
        holder.itemView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            MyApplication.isInternalCall = true
            val intent = Intent(Intent.ACTION_VIEW)
            val uri = Uri.withAppendedPath(
                ContactsContract.Contacts.CONTENT_URI,
                java.lang.String.valueOf(lContactItem.mContactId)
            )
            intent.data = uri
            mContext.startActivity(intent)

        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = contacts.size
        return totalNumberOfflineInSet
    }

    private fun getPhotoUri(photo: String?): Uri? {
        try {
            val cur: Cursor = mContext.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                null,
                ContactsContract.Data.CONTACT_ID + "=" + photo + " AND " + ContactsContract.Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE + "'",
                null,
                null
            )!!
            if (cur != null) {
                if (!cur.moveToFirst()) {
                    return null // no photo
                }
            } else {
                return null // error in cursor process
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
        val person: Uri =
            ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, photo!!.toLong())
        return Uri.withAppendedPath(person, ContactsContract.Contacts.Photo.CONTENT_DIRECTORY)
    }
}