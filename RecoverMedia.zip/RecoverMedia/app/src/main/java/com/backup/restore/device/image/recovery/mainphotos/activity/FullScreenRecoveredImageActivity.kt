@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.mainphotos.activity

import android.app.Activity
import android.app.Dialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.viewpager.widget.PagerAdapter
import com.adconfig.adsutil.admob.BannerAdHelper
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.custom.TouchImageView
import com.backup.restore.device.image.recovery.utilities.getShareMessage
import com.bumptech.glide.Glide
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityFullscreenRecoveredImageBinding
import com.backup.restore.device.image.recovery.utilities.AdCache
import com.google.android.gms.ads.AdView
import java.io.File
import java.util.*

class FullScreenRecoveredImageActivity : MyCommonBaseActivity() {

    val mTAG : String = javaClass.simpleName

    private var imageAdapter: TouchImageAdapter? = null
    var mMainPosition = 0

    companion object {
        var mSavedFiles : ArrayList<File>? = null
    }

    lateinit var binding: ActivityFullscreenRecoveredImageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_fullscreen_recovered_image)
        binding=ActivityFullscreenRecoveredImageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addEvent(FullScreenRecoveredImageActivity::class.simpleName!!)
        binding.tvHeader.setText(R.string.recovered_images)

    }

    override fun getContext(): AppCompatActivity {
        return this@FullScreenRecoveredImageActivity
    }

    override fun initData() {
        val extras = intent.extras
        if (extras != null) {
            mMainPosition = extras.getInt("position", 0)
            binding.viewPager!!.currentItem = mMainPosition
            Log.e(mTAG, "initViewActions: mMainPos -> $mMainPosition")
            resetView()
        }
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            loadAds()
//        }else{
//            binding.adview.visibility = View.GONE
//        }
    }

    var isAdLoaded = false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        changeLanguage()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    fun loadAds() {
        val adId = getString(R.string.admob_banner)
        BannerAdHelper.showBanner(
            this, binding.adview, binding.adview, adId,
            AdCache.bannerDetail, { isLoaded, adView, message ->
                AdCache.bannerDetail = adView
                mAdView = adView
                isAdLoaded = isLoaded
            }
        )
    }
    override fun initActions() {
        binding.ivBack!!.setOnClickListener(this)
        binding.ivShare!!.setOnClickListener(this)
        binding.ivDelete!!.setOnClickListener(this)
    }

    private fun resetView() {
        try {
            imageAdapter = TouchImageAdapter(mContext, FullScreenRecoveredImageActivity.mSavedFiles!!)
            binding.viewPager!!.adapter = imageAdapter
            binding.viewPager!!.currentItem = mMainPosition
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.iv_back -> onBackPressed()
            R.id.ivShare -> {
                val uri = FileProvider.getUriForFile(mContext, "$packageName.provider", FullScreenRecoveredImageActivity.mSavedFiles!![binding.viewPager!!.currentItem])
                val share = Intent(Intent.ACTION_SEND)
                share.type = "image/*"
                share.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
                share.putExtra(Intent.EXTRA_STREAM, uri)
                share.putExtra(Intent.EXTRA_TEXT, mContext.getShareMessage())
                MyApplication.isInternalCall = true
                startActivity(Intent.createChooser(share, "Share Image"))
            }
            R.id.ivDelete -> deleteImage(binding.viewPager!!.currentItem)
        }
    }

    private fun deleteImage(position: Int) {

        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        dialog.findViewById<TextView>(R.id.permission_text).text = getString(R.string.never_get_back_image)
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {

            Log.d(mTAG, "al_my_photos.size():" + FullScreenRecoveredImageActivity.mSavedFiles!!.size)
            if (FullScreenRecoveredImageActivity.mSavedFiles!!.size > 0) {
                val isDeleted = FullScreenRecoveredImageActivity.mSavedFiles!![position].delete()
                Log.d(mTAG, "isDeleted:\$isDeleted")
                if (isDeleted) {
                    deleteFileFromMediaStore(FullScreenRecoveredImageActivity.mSavedFiles!![position].absolutePath)
                    val f = File(FullScreenRecoveredImageActivity.mSavedFiles!![binding.viewPager!!.currentItem].toString())
                    if (f.exists()) {
                        Log.d(mTAG, "img:$f")
                        f.delete()
                    } else {
                        Log.d(mTAG, "deleteImage: Not Read")
                    }
                    SharedPrefsConstant.savePref(mContext, "AfterRecover", true)
                    FullScreenRecoveredImageActivity.mSavedFiles!!.removeAt(position)
                    NewRecoverImageActivity.isRefresh = true
                    if (FullScreenRecoveredImageActivity.mSavedFiles!!.size == 0) {
                        onBackPressed()
                    }
                    imageAdapter!!.notifyDataSetChanged()
                    binding.viewPager!!.adapter = imageAdapter
                    binding.viewPager!!.currentItem = position - 1
                }
            }
            dialog.cancel()
            MyApplication.isDialogOpen = false
            Toast.makeText(mContext, getString(R.string.image_deleted_successfully), Toast.LENGTH_SHORT).show()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun deleteFileFromMediaStore(path: String) {
        try {
            val projection = arrayOf(MediaStore.Images.Media._ID)
            val selection = MediaStore.Images.Media.DATA + " = ?"
            val selectionArgs = arrayOf(path)
            val queryUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val c = contentResolver.query(queryUri, projection, selection, selectionArgs, null)
            if (c!!.moveToFirst()) {
                val id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                val deleteUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                contentResolver.delete(deleteUri, null, null)
            }
            c.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        System.gc()
    }


    internal inner class TouchImageAdapter(private val mActivity: Activity, var arrayList: List<File>) : PagerAdapter() {

        override fun getCount(): Int {
            return arrayList.size
        }

        override fun instantiateItem(container: ViewGroup, position: Int): View {
            val view = layoutInflater.inflate(R.layout.raw_fullscreen_image_item, container, false)
            val img: TouchImageView = view.findViewById(R.id.ivFullScreenImage)
            val progressBar = view.findViewById<ProgressBar>(R.id.progressBar)
            try {
                progressBar.visibility = View.GONE
                val file = File(arrayList[position].absolutePath)
                val imageUri = Uri.fromFile(file)
                Glide.with(mActivity)
                    .load(imageUri)
                    .placeholder(R.drawable.img_thumb)
                    .into(img)
                container.addView(view, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return view
        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            container.removeView(`object` as View)
        }

        override fun isViewFromObject(view: View, `object`: Any): Boolean {
            return view == `object`
        }
    }

    override fun onBackPressed() {
        NewRecoverImageActivity.mIsFromForImageCheck = "Recovered"
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

}