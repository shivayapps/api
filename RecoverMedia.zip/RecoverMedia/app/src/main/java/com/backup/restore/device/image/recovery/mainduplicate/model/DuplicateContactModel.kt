package com.backup.restore.device.image.recovery.mainduplicate.model

import android.graphics.drawable.Drawable
import com.backup.restore.device.image.recovery.R

class DuplicateContactModel(
    var mContactId: String?,
    var mRawContactId: String?,
    var mContactName: String?,
    var mContactNumber: String?,
    var mContactEmail: String?,
    var mLookUpKey: String,
    var mIcon: Drawable? = null,
    var mIconUri: String? = ""

)