@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.mainphotos.activity

import android.Manifest
import android.animation.ObjectAnimator
import android.app.*
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.util.Log
import android.view.*
import android.view.View.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.adconfig.AdsConfig
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.adshelper.EventsHelper.addEvent
import com.backup.restore.device.image.recovery.ads.inapp.InAppActivity
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.databinding.ActivityTrashImageBinding
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel
import com.backup.restore.device.image.recovery.mainphotos.recoverdadapter.OtherRecoveredAdapter
import com.backup.restore.device.image.recovery.mainphotos.trashadapter.AudioOtherTrashAdapter
import com.backup.restore.device.image.recovery.mainphotos.trashadapter.ImageVideoTrashAdapter
import com.backup.restore.device.image.recovery.mainphotos.trashfragment.*
import com.backup.restore.device.image.recovery.service.ManagerService
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.*
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.*
import com.google.android.material.tabs.TabLayout
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
//import kotlinx.android.synthetic.main.activity_trash_image.binding.bottomNavigationTrash
//import kotlinx.android.synthetic.main.activity_trash_image.binding.btnRecover
//import kotlinx.android.synthetic.main.activity_trash_image.binding.checkAll
//import kotlinx.android.synthetic.main.activity_trash_image.binding.frameTrash
//import kotlinx.android.synthetic.main.activity_trash_image.iv_back
//import kotlinx.android.synthetic.main.activity_trash_image.binding.ivDeleteAll
//import kotlinx.android.synthetic.main.activity_trash_image.binding.ivSetting
//import kotlinx.android.synthetic.main.activity_trash_image.binding.ivSpan
//import kotlinx.android.synthetic.main.activity_trash_image.llSelectAll
//import kotlinx.android.synthetic.main.activity_trash_image.llView
//import kotlinx.android.synthetic.main.activity_trash_image.binding.tvHeader
//import kotlinx.android.synthetic.main.activity_trash_image.binding.viewPagerTrash
//import kotlinx.android.synthetic.main.fragment_trash_image_video.*
import java.io.File
import kotlin.collections.ArrayList

class TrashImageActivity : MyCommonBaseActivity() {

    val mTAG: String = TrashImageActivity.javaClass.simpleName
    val mPermissionStorage = arrayOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    private var path = ""
//    var mClGift: ConstraintLayout? = null

    var isDateClick = false
    var isSizeClick = false

    var mIsFromNotification: String? = null
    var mIsCancelAsync = true

    var isFromOneSignal = false

    var trashViewPagerAdapter: ViewPagerAdapter? = null
    var isAsyncTrashVideoFragment = false
    var isAsyncTrashImageFragment = false
    var isAsyncTrashAudioFragment = false
    var isAsyncTrashDocumentFragment = false
    var isAsyncTrashOtherFragment = false
//    private var rewardedAd: RewardedAd? = null
//    private var isRewardVideoAdLoaded: Boolean = false

    companion object {
        var lastSelection = 1
        var prevPosRecoverable: Int = 0
        var prevPosTrash: Int = 0
        var prevPosRecovered: Int = 0

        @JvmField
        var isRefresh = false
        var mIsFromForImageCheck = "Recoverable"
        var resumeImageCount = 0
        var resumeVideoCount = 0
        var resumeAudioCount = 0
        var resumeDocumentCount = 0
        var prevFragmentPos = 0
        var resumeOtherCount = 0
        var isGridChange = false
    }

    lateinit var binding:ActivityTrashImageBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_trash_image)
        binding=ActivityTrashImageBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    override fun getContext(): AppCompatActivity {
        return this@TrashImageActivity
    }

    override fun initData() {

        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }

        mRootPath = Environment.getExternalStorageDirectory().toString()
        path = "$mRootPath/RecoverMedia/"

        mIsFromNotification = intent.getStringExtra("IsFromNotification")
        Log.e(mTAG, "initData: setAllData $mIsFromNotification")


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAllFilePermission()
        } else {
            if (checkPermissionStorage(mContext)) {
                lastSelection=1
                prevPosRecoverable = 0
                prevPosTrash = 0
                prevPosRecovered = 0

                setAllData()
            } else {
                givePermissions(mPermissionStorage)
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                setAllData()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setAllData()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            if (isFromOneSignal) {
                startActivity(NewHomeActivity.newIntent(this))
                finish()
            } else {
                finish()
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            givePermissions(mPermissionStorage)
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    private fun startServiceMethod() {
        try {
            if (!isMyServiceRunning(mContext, ManagerService::class.java)) {
                SharedPrefsConstant.savePrefNoti(mContext, "IsFromService", false)
                ManagerService.setData(mContext)
                startService(Intent(this, ManagerService::class.java))
                Log.e(
                    mTAG,
                    "startServiceMethod: " + SharedPrefsConstant.getBooleanNoti(
                        mContext,
                        "IsFromService",
                        false
                    )
                )
            }
        } catch (e: java.lang.Exception) {
            Log.e(mTAG, "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }


    private fun setAllData() {
        startServiceMethod()

        setupViewPagerTrash(binding.viewPagerTrash)

        setMainAdapter()
    }

    private fun setMainAdapter() {
        when (mIsFromNotification) {
            "Yes" -> {
//                Log.e(mTAG, "setAllData: yes")
//                binding.tvHeader!!.text = getString(R.string.photo_recover)
//                binding.tvHeader!!.isSelected = true
//                binding.ivDeleteAll!!.visibility = GONE
//                binding.ivSetting!!.visibility = GONE
//                binding.ivSpan!!.visibility = VISIBLE
//                binding.frameTrash.visibility = INVISIBLE
//                setValueFalse()
//                mIsFromForImageCheck = "Recoverable"

                lastSelection =2
                addEvent("TrashModule")
                binding.tvHeader!!.text = getString(R.string.trash_recover)
                binding.tvHeader!!.isSelected = true
                binding.ivDeleteAll!!.visibility = GONE
                binding.ivSetting!!.visibility = VISIBLE
                binding.frameTrash.visibility = VISIBLE
//                if (mGetRecoverableAlbum != null) {
//                    mGetRecoverableAlbum!!.cancel(true)
//                }
                deselectPrevSelection()
                binding.viewPagerTrash.currentItem = 0
                prevFragmentPos = 0
                val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
                if (fragment is TrashImageFragment) {
                    fragment.userVisibleHint = true
                }
                setValueFalse()
                binding.checkAll.isChecked = false
                mIsFromForImageCheck = "Trash"
            }
            "No" -> {
//                Log.e(mTAG, "setAllData: no")
//                binding.tvHeader!!.text = getString(R.string.photo_recovered)
//                binding.tvHeader!!.isSelected = true
//                binding.ivDeleteAll!!.visibility = VISIBLE
//                binding.ivSetting!!.visibility = GONE
//                binding.frameTrash.visibility = INVISIBLE
//                setValueFalse()
//                mIsFromForImageCheck = "Recovered"
            }

        }
    }

    override fun initActions() {
        binding.ivBack!!.setOnClickListener {
            onBackPressed()
        }
        binding.ivSpan.setOnClickListener {
//            if (SystemClock.elapsedRealtime() - mLastClickTime < 800) {
//                return@setOnClickListener
//            }
//            mLastClickTime = SystemClock.elapsedRealtime()
            isGridChange = true
            setSpanCount()
        }

        binding.llSelectAll.setOnClickListener {
            if (!binding.checkAll.isChecked) {
                if (trashViewPagerAdapter != null) {
                    val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
                    Log.d(mTAG, "initActions: fragment -->" + fragment.javaClass.simpleName)
                    when (fragment) {
                        is TrashImageFragment -> {
                            fragment.mainCommonAdapter!!.selectAll()
                        }
                        is TrashVideoFragment -> {
                            fragment.mainCommonAdapter!!.selectAll()
                        }
                        is TrashAudioFragment -> {
                            fragment.mainCommonAdapter!!.selectAll()
                        }
                        is TrashDocumentFragment -> {
                            fragment.mainCommonAdapter!!.selectAll()
                        }
                        is TrashOtherFragment -> {
                            fragment.mainCommonAdapter!!.selectAll()
                        }
                    }
                }

            } else {
                if (trashViewPagerAdapter != null) {
                    when (val fragment =
                        trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)) {
                        is TrashImageFragment -> {
                            fragment.selectedList.clear()
                            fragment.mainCommonAdapter!!.deSelectAll()
                        }
                        is TrashVideoFragment -> {
                            fragment.selectedList.clear()
                            fragment.mainCommonAdapter!!.deSelectAll()
                        }
                        is TrashAudioFragment -> {
                            fragment.selectedList.clear()
                            fragment.mainCommonAdapter!!.deSelectAll()
                        }
                        is TrashDocumentFragment -> {
                            fragment.selectedList.clear()
                            fragment.mainCommonAdapter!!.deSelectAll()
                        }
                        is TrashOtherFragment -> {
                            fragment.selectedList.clear()
                            fragment.mainCommonAdapter!!.deSelectAll()
                        }
                    }
                }
            }
        }

//        llDateWise!!.setOnClickListener {
//            Log.e(mTAG, "llDateWise: $mIsFromForImageCheck")
//            if (mIsFromForImageCheck == "Recoverable") {
//                val fragment =
//                    recoverableViewPagerAdapter!!.getItem(viewPager_recoverable.currentItem)
//                when (fragment) {
//                    is RecoverableImageFragment -> {
//                        Log.e(mTAG, "llDateWise RecoverableImageFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llSizeWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mHiddenPictureFolderAdapter?.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredImageFragment initActions: " + fragment.mFolderList.size
//                        )
//                    }
//                    is RecoverableVideoFragment -> {
//                        Log.e(mTAG, "llDateWise RecoverableVideoFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llDateWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableVideoFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                    is RecoverableAudioFragment -> {
//                        Log.e(mTAG, "llDateWise RecoverableAudioFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llDateWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableAudioFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                    is RecoverableDocumentFragment -> {
//                        Log.e(mTAG, "llDateWise RecoverableDocumentFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llDateWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableDocumentFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                    is RecoverableOtherFragment -> {
//                        Log.e(mTAG, "llDateWise RecoverableOtherFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llDateWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableOtherFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                }
//            }
//            else if (mIsFromForImageCheck == "Trash") {
//                val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
//                when (fragment) {
//                    is TrashImageFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "TrashImageFragment initActions: " + fragment.selectedList.size)
//                    }
//                    is TrashVideoFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "TrashVideoFragment initActions: " + fragment.selectedList.size)
//                    }
//                    is TrashAudioFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "TrashAudioFragment initActions: " + fragment.selectedList.size)
//                    }
//                    is TrashDocumentFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "TrashDocumentFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                    is TrashOtherFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "TrashOtherFragment initActions: " + fragment.selectedList.size)
//                    }
//                }
//            }
//            else if (mIsFromForImageCheck == "Recovered") {
//                val fragment = recoveredViewPagerAdapter!!.getItem(viewPager_recovered.currentItem)
//                when (fragment) {
//                    is NewImageFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredImageFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewVideoFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredVideoFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewAudioFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredAudioFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewDocumentFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredDocumentFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewOtherFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllDate()
//                                if (isDateClick) {
//                                    fragment.isForSort = "date_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateAscending()
//                                    )
//                                    isDateClick = false
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "date_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredDateDescending()
//                                    )
//                                    isDateClick = true
//                                    select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isSizeClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredOtherFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                }
//            }
//        }

//        llSizeWise!!.setOnClickListener {
//            Log.e(mTAG, "llSizeWise: $mIsFromForImageCheck")
//            if (mIsFromForImageCheck == "Recoverable") {
//                val fragment = recoverableViewPagerAdapter!!.getItem(viewPager_recoverable.currentItem)
//                when (fragment) {
//                    is RecoverableImageFragment -> {
//                        Log.e(mTAG, "llSizeWise RecoverableOtherFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llSizeWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList != null && fragment.mFolderList.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableImageFragment initActions: " + fragment.mFolderList.size
//                        )
//                    }
//                    is RecoverableVideoFragment -> {
//                        Log.e(mTAG, "llSizeWise RecoverableVideoFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llSizeWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList != null && fragment.mFolderList.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableVideoFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                    is RecoverableAudioFragment -> {
//                        Log.e(mTAG, "llSizeWise RecoverableAudioFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llSizeWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList != null && fragment.mFolderList.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableAudioFragment initActions: " + fragment.selectedList.size
//                        )
//
//                    }
//                    is RecoverableDocumentFragment -> {
//                        Log.e(mTAG, "llSizeWise RecoverableDocumentFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llSizeWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList != null && fragment.mFolderList.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableDocumentFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                    is RecoverableOtherFragment -> {
//                        Log.e(mTAG, "llSizeWise RecoverableOtherFragment")
//                        if (fragment.mHiddenPictureFolderAdapter != null) {
//                            Log.e(mTAG, "llSizeWise mFolderList ${fragment.mFolderList.size}")
//                            if (fragment.mFolderList != null && fragment.mFolderList.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mFolderList,
//                                        RecoverableSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mHiddenPictureFolderAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoverableOtherFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                }
//            }
//            else if (mIsFromForImageCheck == "Trash") {
//                var fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
//                when (fragment) {
//                    is TrashImageFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "ImageFragment initActions: " + fragment.selectedList.size)
//                    }
//                    is TrashVideoFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "TrashVideoFragment initActions: " + fragment.selectedList.size)
//                    }
//                    is TrashAudioFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "TrashAudioFragment initActions: " + fragment.selectedList.size)
//                    }
//                    is TrashDocumentFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "TrashDocumentFragment initActions: " + fragment.selectedList.size
//                        )
//                    }
//                    is TrashOtherFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mCursor != null && fragment.mCursor!!.count != 0) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.onResume()
//                            }
//                        }
//                        Log.e(mTAG, "TrashOtherFragment initActions: " + fragment.selectedList.size)
//                    }
//                }
//            }
//            else if (mIsFromForImageCheck == "Recovered") {
//                val fragment = recoveredViewPagerAdapter!!.getItem(viewPager_recovered.currentItem)
//                when (fragment) {
//                    is NewImageFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//
//                        Log.e(
//                            mTAG,
//                            "RecoveredImageFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewVideoFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredVideoFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewAudioFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredAudioFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewDocumentFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredDocumentFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                    is NewOtherFragment -> {
//                        if (fragment.mainCommonAdapter != null) {
//                            if (fragment.mSavedPhotos != null && fragment.mSavedPhotos.isNotEmpty()) {
//                                selectAllSize()
//                                if (isSizeClick) {
//                                    fragment.isForSort = "size_asc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeAscending()
//                                    )
//                                    isSizeClick = false
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//                                } else {
//                                    fragment.isForSort = "size_desc"
//                                    Collections.sort(
//                                        fragment.mSavedPhotos,
//                                        RecoveredSizeDescending()
//                                    )
//                                    isSizeClick = true
//                                    select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//                                }
//                                isDateClick = true
//                                fragment.mainCommonAdapter!!.notifyDataSetChanged()
//                            }
//                        }
//                        Log.e(
//                            mTAG,
//                            "RecoveredOtherFragment initActions: " + fragment.mSavedPhotos.size
//                        )
//                    }
//                }
//            }
//        }

        binding.ivSetting!!.setOnClickListener { v: View ->
            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val point = Point()
            point.x = location[0]
            point.y = location[1]
            showStatusPopupForNotification(mContext, point)
        }
        binding.btnRecover.setOnClickListener {

            Log.e(
                "binding.btnRecover",
                "FREE_RECOVER_IMAGE_COUNT:" + SharedPrefsConstant.getInt(
                    mContext,
                    FREE_RECOVER_IMAGE_COUNT
                )
            )
            if (SharedPrefsConstant.getInt(mContext, FREE_RECOVER_IMAGE_COUNT) >= 4
            ) {

                if (trashViewPagerAdapter != null) {
                    when (val fragment =
                        trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)) {
                        is TrashImageFragment -> {
                            if (fragment.mainCommonAdapter != null) {
                                if (fragment.selectedList.size != 0) {

                                    AdsConfig.showInterstitialAd(mContext, {
                                        btnRecoverClicked()
                                    })
                                } else {
                                    Toast.makeText(
                                        mContext,
                                        getString(R.string.select_an_image),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.select_an_image),
                                    Toast.LENGTH_SHORT
                                ).show()

                            Log.e(mTAG, "ImageFragment initActions: " + fragment.selectedList.size)
                        }
                        is TrashVideoFragment -> {
                            if (fragment.mainCommonAdapter != null) {
                                if (fragment.selectedList.size != 0) {

                                    AdsConfig.showInterstitialAd(mContext, {
                                        btnRecoverClicked()
                                    })
                                } else {
                                    Toast.makeText(
                                        mContext,
                                        getString(R.string.select_an_video),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.select_an_image),
                                    Toast.LENGTH_SHORT
                                ).show()
                            Log.e(mTAG, "VideoFragment initActions: " + fragment.selectedList.size)
                        }
                        is TrashAudioFragment -> {
                            if (fragment.mainCommonAdapter != null) {
                                if (fragment.selectedList.size != 0) {

                                    AdsConfig.showInterstitialAd(mContext, {
                                        btnRecoverClicked()
                                    })

                                } else {
                                    Toast.makeText(
                                        mContext,
                                        getString(R.string.select_an_audio),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.select_an_image),
                                    Toast.LENGTH_SHORT
                                ).show()
                            Log.e(mTAG, "AudioFragment initActions: " + fragment.selectedList.size)
                        }
                        is TrashDocumentFragment -> {
                            if (fragment.mainCommonAdapter != null) {
                                if (fragment.selectedList.size != 0) {

                                    AdsConfig.showInterstitialAd(mContext, {
                                        btnRecoverClicked()
                                    })
                                } else {
                                    Toast.makeText(
                                        mContext,
                                        getString(R.string.select_an_document),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                            Log.e(
                                mTAG,
                                "DocumentFragment initActions: " + fragment.selectedList.size
                            )
                        }
                        is TrashOtherFragment -> {
                            if (fragment.mainCommonAdapter != null) {
                                if (fragment.selectedList.size != 0) {

                                    AdsConfig.showInterstitialAd(mContext, {
                                        btnRecoverClicked()
                                    })
                                } else {
                                    Toast.makeText(
                                        mContext,
                                        getString(R.string.select_an_document),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.select_an_image),
                                    Toast.LENGTH_SHORT
                                ).show()
                            Log.e(mTAG, "OtherFragment initActions: " + fragment.selectedList.size)
                        }
                    }
                }


            } else {
                btnRecoverClicked()
            }

        }

        binding.ivDeleteAll!!.setOnClickListener {

        }
    }


    private fun btnRecoverClicked() {
        if (trashViewPagerAdapter != null) {
            when (val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)) {
                is TrashImageFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        if (fragment.selectedList.size != 0) {
                            if (!isAsyncTrashImageFragment) {

                                val asyncTaskRunnerForVideoImage = AsyncTaskRunnerForVideoImage(
                                    fragment.selectedList,
                                    fragment.mainCommonAdapter,
                                    "Image"
                                )

                                if (asyncTaskRunnerForVideoImage.status != AsyncTask.Status.RUNNING) {
                                    asyncTaskRunnerForVideoImage.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                                }
                            } else {
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.task_already_running),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else {
                            Toast.makeText(
                                mContext,
                                getString(R.string.select_an_image),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    Log.e(mTAG, "ImageFragment initActions: " + fragment.selectedList.size)
                }
                is TrashVideoFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        if (fragment.selectedList.size != 0) {

                            if (!isAsyncTrashVideoFragment) {

                                var asyncTaskTrashVideoFragment = AsyncTaskRunnerForVideoImage(
                                    fragment.selectedList,
                                    fragment.mainCommonAdapter,
                                    "Video"
                                )


                                if (asyncTaskTrashVideoFragment.status != AsyncTask.Status.RUNNING) {
                                    asyncTaskTrashVideoFragment.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                                }
                            } else {
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.task_already_running),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else {
                            Toast.makeText(
                                mContext,
                                getString(R.string.select_an_video),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    Log.e(mTAG, "VideoFragment initActions: " + fragment.selectedList.size)
                }
                is TrashAudioFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        if (fragment.selectedList.size != 0) {
                            if (!isAsyncTrashAudioFragment) {
                                val asyncTaskTrashAudioFragment = AsyncTaskRunnerForAudioOther(
                                    fragment.selectedList,
                                    fragment.mainCommonAdapter,
                                    "Audio"
                                )

                                if (asyncTaskTrashAudioFragment.status != AsyncTask.Status.RUNNING) {
                                    asyncTaskTrashAudioFragment.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                                }
                            } else {
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.task_already_running),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                        } else {
                            Toast.makeText(
                                mContext,
                                getString(R.string.select_an_audio),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    Log.e(mTAG, "AudioFragment initActions: " + fragment.selectedList.size)
                }
                is TrashDocumentFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        if (fragment.selectedList.size != 0) {
                            if (!isAsyncTrashDocumentFragment) {

                                val asyncTaskRunnerForAudioOther = AsyncTaskRunnerForAudioOther(
                                    fragment.selectedList,
                                    fragment.mainCommonAdapter,
                                    "Document"
                                )
                                if (asyncTaskRunnerForAudioOther.status != AsyncTask.Status.RUNNING) {
                                    asyncTaskRunnerForAudioOther.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                                }
                            } else {
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.task_already_running),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else {
                            Toast.makeText(
                                mContext,
                                getString(R.string.select_an_document),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    Log.e(mTAG, "DocumentFragment initActions: " + fragment.selectedList.size)
                }
                is TrashOtherFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        if (fragment.selectedList.size != 0) {
                            if (!isAsyncTrashOtherFragment) {
                                val asyncTaskRunnerForAudioOther = AsyncTaskRunnerForAudioOther(
                                    fragment.selectedList,
                                    fragment.mainCommonAdapter,
                                    "Other"
                                )

                                if (asyncTaskRunnerForAudioOther.status != AsyncTask.Status.RUNNING) {
                                    asyncTaskRunnerForAudioOther.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                                }
                            } else {
                                Toast.makeText(
                                    mContext,
                                    getString(R.string.task_already_running),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }

                        } else {
                            Toast.makeText(
                                mContext,
                                getString(R.string.select_an_document),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    Log.e(mTAG, "OtherFragment initActions: " + fragment.selectedList.size)
                }
            }
        }
    }

//    private fun createAndLoadRewardedAd() {
//        RewardedAd.load(
//            this,
//            resources.getString(R.string.rewarded_ad_id),
//            AdRequest.Builder().build(),
//            object : RewardedAdLoadCallback() {
//                override fun onAdLoaded(p0: RewardedAd) {
//                    super.onAdLoaded(p0)
//                    rewardedAd = p0
//                }
//
//                override fun onAdFailedToLoad(p0: LoadAdError) {
//                    super.onAdFailedToLoad(p0)
//                    Log.e("TAG", "onAdFailedToLoad: =>" + p0.message)
//                    rewardedAd = null
//                }
//            })
//    }

//    private fun showRewardedAd() {
//        val activityContext: Activity = this@TrashImageActivity
//        rewardedAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
//
//            override fun onAdDismissedFullScreenContent() {
//                Log.i("TAG", "onAdDismissedFullScreenContent")
//                rewardedAd = null
//                Log.d("TAG", "The rewarded close.")
//            }
//
//            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
//            }
//
//            override fun onAdShowedFullScreenContent() {
//                Log.i("TAG", "onAdShowedFullScreenContent")
//            }
//
//        }
//
//        rewardedAd!!.show(activityContext) {
//            Log.e("TAG", "onFinish: sds=>")
//            SharedPrefsConstant.save(
//                mContext,
//                ShareConstants.FREE_RECOVER_IMAGE_COUNT,
//                SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_IMAGE_COUNT) - 1
//            )
//            btnRecoverClicked()
//        }
//    }

//    private fun dialogUnlockPro() {
//        createAndLoadRewardedAd()
//        val dialog = Dialog(mContext)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_unloack_pro)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
//        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)
//
//        watchVideo.setOnClickListener {
//            if (!NetworkManager.isInternetConnected(mContext)) {
//                Toast.makeText(mContext,getString(R.string.no_internet_access),Toast.LENGTH_SHORT).show()
//                createAndLoadRewardedAd()
//            } else if (rewardedAd != null) {
//                showRewardedAd()
//                dialog.dismiss()
//            } else  {
//                Toast.makeText(mContext,getString(R.string.please_wait_for_ads_loading),Toast.LENGTH_SHORT).show()
//                createAndLoadRewardedAd()
//                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
//            }
//        }
//        purchasePro.setOnClickListener {
//            dialog.dismiss()
//
//            startActivity(Intent(mContext, InAppActivity::class.java))
//        }
//
//        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
//            dialog.dismiss()
//        }
//        dialog.show()
//    }

//    private fun dialogUnlockPro() {
//        //createAndLoadRewardedAd()
//
//        val dialog = Dialog(mContext)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(R.layout.dialog_unloack_pro)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        val watchVideo = dialog.findViewById<LinearLayout>(R.id.ll_watch_video)
//        val purchasePro = dialog.findViewById<LinearLayout>(R.id.ll_purchase_pro)
//        watchVideo.alpha = 0.5f
//        watchVideo.isClickable = false
//        isRewardVideoAdLoaded = false
//
//        val activityContext: Activity = this@NewRecoverImageActivity
//        InterstitialRewardHelper.loadRewardedInterstitialAd(activityContext)
//
//        isShowRewardedInterstitialAd(
//            onStartToLoadRewardedInterstitialAd = {
//            },
//            onUserEarnedReward = {
//                Log.e("TAG", "onFinish: sds=>")
//                SharedPrefsConstant.save(
//                    mContext,
//                    ShareConstants.FREE_RECOVER_IMAGE_COUNT,
//                    SharedPrefsConstant.getInt(mContext, ShareConstants.FREE_RECOVER_IMAGE_COUNT) - 1
//                )
//                binding.btnRecoverClicked()
//            },
//            onAdLoaded = {
//                watchVideo.alpha = 1.0f
//                watchVideo.isClickable = true
//                isRewardVideoAdLoaded = true
//            }
//        )
//
//        watchVideo.setOnClickListener {
//            if (!NetworkManager.isInternetConnected(mContext)) {
//                Toast.makeText(mContext, getString(R.string.no_internet_access), Toast.LENGTH_SHORT).show()
//                //createAndLoadRewardedAd()
//            } else if (isRewardVideoAdLoaded) {
//                showRewardVideoAd()
//                dialog.dismiss()
//            } else {
//                Toast.makeText(mContext, getString(R.string.please_wait_for_ads_loading), Toast.LENGTH_SHORT).show()
//                //createAndLoadRewardedAd()
//                Log.d("TAG", "The rewarded ad wasn't loaded yet.")
//            }
//        }
//        purchasePro.setOnClickListener {
//            dialog.dismiss()
//
//            startActivity(Intent(mContext, InAppActivity::class.java))
//        }
//
//        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
//            dialog.dismiss()
//        }
//        dialog.show()
//    }

    private fun deleteImageVideoMethod(
        type: String,
        lSavedPhotos: ArrayList<File>,
        recycleDeletedFiles: RecyclerView,
        LinearRecoveredAlbum: LinearLayout,
        mainCommonAdapter: RecyclerView.Adapter<RecyclerView.ViewHolder>
    ) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        if (type == "Image") {
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.never_get_back_images)
        } else {
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.never_get_back_videos)
        }
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            isRefresh = false
            val deleteAllImageVideo = DeleteAllImageVideo(
                type,
                lSavedPhotos,
                recycleDeletedFiles,
                LinearRecoveredAlbum,
                mainCommonAdapter
            )
            binding.ivSpan!!.isEnabled = false
            binding.ivDeleteAll!!.isEnabled = false
            binding.ivSpan!!.alpha = 0.5f
            binding.ivDeleteAll!!.alpha = 0.5f
            unSelectAll()

            if (deleteAllImageVideo.status != AsyncTask.Status.RUNNING) {
                deleteAllImageVideo.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            }
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun deleteAODMethod(
        type: String,
        lSavedPhotos: ArrayList<File>,
        recycleDeletedFiles: RecyclerView,
        LinearRecoveredAlbum: LinearLayout,
        mainCommonAdapter: OtherRecoveredAdapter
    ) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.confirm_delete)
        if (type == "Audio") {
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.never_get_back_audios)
        } else {
            dialog.findViewById<TextView>(R.id.permission_text).text =
                getString(R.string.never_get_back_files)
        }
        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            isRefresh = false
            val deleteAllAudioDocument = DeleteAllAudioDocument(
                type,
                lSavedPhotos,
                recycleDeletedFiles,
                LinearRecoveredAlbum,
                mainCommonAdapter
            )
            binding.ivSpan!!.isEnabled = false
            binding.ivDeleteAll!!.isEnabled = false
            binding.ivSpan!!.alpha = 0.5f
            binding.ivDeleteAll!!.alpha = 0.5f
            unSelectAll()

            if (deleteAllAudioDocument.status != AsyncTask.Status.RUNNING) {
                deleteAllAudioDocument.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            }
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private inner class DeleteAllImageVideo(
        type: String,
        SavedPhotos: ArrayList<File>,
        recycleDeletedFiles: RecyclerView,
        LinearRecoveredAlbum: LinearLayout,
        mainCommonAdapter: RecyclerView.Adapter<RecyclerView.ViewHolder>
    ) : AsyncTask<String?, String?, String?>() {
        val lType = type
        val lSavedPhotos = SavedPhotos
        val lRecycleDeletedFiles = recycleDeletedFiles
        val lLinearRecoveredAlbum = LinearRecoveredAlbum
        val lMainCommonAdapter = mainCommonAdapter
        val dialog = Dialog(mContext)
        var type = "Deleteing"
        var mNoti = getString(R.string.deleting_files)
        var notificationId = 175
        var isSendNotification = true

        //        var mBuilder : Notification?=null
        var mBuilder = NotificationCompat.Builder(mContext, "Deleteing")

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.setOnKeyListener { dialog, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    Log.e(mTAG, "DeleteAllImageVideo:onBack")
                    if (status == AsyncTask.Status.RUNNING) {
//                        cancel(true)
                        mContext.onBackPressed()
                    }
                }
                return@setOnKeyListener true
            }
            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.deleting_files)
            var btnCancel = dialog.findViewById<Button>(R.id.dialogButtonCancel)
            btnCancel.visibility = VISIBLE
            btnCancel.text = getString(R.string.background)
            btnCancel.setOnClickListener {
                dialog.dismiss()
            }

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }

            try {
                if (mNotificationManager == null) {
                    mNotificationManager =
                        mContext.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                }

                val notifications: Array<StatusBarNotification>
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    notifications = mNotificationManager?.activeNotifications!!
                    for (notification in notifications) {
                        if (notification.id == notificationId) {
                            isSendNotification = true
                            break
                        } else if (notification.id != notificationId) {
                            isSendNotification = false
                        }
                    }
                }
                if (!isSendNotification) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (mNotificationManager?.getNotificationChannel("Deleteing") == null) {
                            val notificationChannel = NotificationChannel(
                                "Deleteing",
                                "BackupAndRecovery",
                                NotificationManager.IMPORTANCE_DEFAULT
                            )
                            notificationChannel.setSound(null, null);
//                            notificationChannel.enableLights(false)
                            notificationChannel.setVibrationPattern(longArrayOf(0))
                            notificationChannel.enableVibration(true)
                            mNotificationManager?.createNotificationChannel(notificationChannel)
                        }
                    }
                }
            } catch (e9: java.lang.Exception) {
                Log.e(mTAG, "copyImageBeforeDelete: " + e9.message)
            }
        }

        override fun doInBackground(vararg strings: String?): String? {

            val size = lSavedPhotos.size
            for (i in lSavedPhotos.indices) {
                if (lSavedPhotos[i] != null) {
                    if (lSavedPhotos[i].exists()) {
                        lSavedPhotos[i].delete()
                    }
                }
                runOnUiThread {
                    dialog.findViewById<TextView>(R.id.permission_text).text =
                        lType + " $i / $size " + getString(R.string.delete)
                }


                mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                    .setContentText("$mNoti ${i}/${size}")
                    .setSmallIcon(R.drawable.ic_icon)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setProgress(size, i, false)
                    .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                    .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                    .setContent(null)
                    .setAutoCancel(false)
                mNotificationManager?.notify(notificationId, mBuilder.build())

            }
            Log.e(mTAG, "doInBackground:lSavedPhotos.size " + lSavedPhotos.size)
            lSavedPhotos.clear()
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {

                mContext.runOnUiThread {
                    if (lSavedPhotos.size == 0) {
                        Log.e(mTAG, "onPostExecute: size 0 ")
                        lRecycleDeletedFiles.visibility = GONE
                        lLinearRecoveredAlbum.visibility = VISIBLE
                        binding.ivSpan!!.isEnabled = false
                        binding.ivDeleteAll!!.isEnabled = false
                        binding.ivSpan!!.alpha = 0.5f
                        binding.ivDeleteAll!!.alpha = 0.5f
                        unSelectAll()
                        Toast.makeText(
                            mContext,
                            "All $lType Are Deleted Successfully",
                            Toast.LENGTH_SHORT
                        ).show()

                        mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                            .setContentText("All $lType Are Deleted Successfully")
                            .setSmallIcon(R.drawable.ic_icon)
                            .setDefaults(Notification.DEFAULT_ALL)
                            .setProgress(0, 0, true)
                            .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                            .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                            .setContent(null)
                            .setAutoCancel(true)
                        mNotificationManager?.notify(notificationId, mBuilder.build())
                        mNotificationManager?.cancel(notificationId)
                        mNotificationManager?.cancelAll()

                    } else {
                        if (lLinearRecoveredAlbum != null) lLinearRecoveredAlbum.visibility = GONE
                        if (lRecycleDeletedFiles != null) lRecycleDeletedFiles.visibility = VISIBLE
                        binding.ivDeleteAll!!.isEnabled = true
                        binding.ivDeleteAll!!.alpha = 1.0f
                        binding.ivSpan!!.isEnabled = true
                        binding.ivSpan!!.alpha = 1.0f
                    }
                    lMainCommonAdapter.notifyDataSetChanged()

                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            if (dialog != null && dialog.isShowing) {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false
                            }
                        } catch (e: Exception) {
//                            mContext.addEvent(e.message!!)
                        }
                    }, 500)

                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private inner class DeleteAllAudioDocument(
        type: String,
        SavedPhotos: ArrayList<File>,
        recycleDeletedFiles: RecyclerView,
        LinearRecoveredAlbum: LinearLayout,
        mainCommonAdapter: OtherRecoveredAdapter
    ) : AsyncTask<String?, String?, String?>() {
        val lType = type
        val lSavedPhotos = SavedPhotos
        val lRecycleDeletedFiles = recycleDeletedFiles
        val lLinearRecoveredAlbum = LinearRecoveredAlbum
        val lMainCommonAdapter = mainCommonAdapter
        val dialog = Dialog(mContext)
        var type = "Deleteing"
        var mNoti = getString(R.string.deleting_files)
        var notificationId = 175
        var isSendNotification = true

        //        var mBuilder : Notification?=null
        var mBuilder = NotificationCompat.Builder(mContext, "Deleteing")

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.setOnKeyListener { dialog, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    Log.e(mTAG, "DeleteAllAudioDocument:onBack")
                    if (status == AsyncTask.Status.RUNNING) {
//                        cancel(true)
                        mContext.onBackPressed()
                    }
                }
                return@setOnKeyListener true
            }
            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.deleting_files)

            var btnCancel = dialog.findViewById<Button>(R.id.dialogButtonCancel)
            btnCancel.visibility = VISIBLE
            btnCancel.text = getString(R.string.background)
            btnCancel.setOnClickListener {
                dialog.dismiss()
            }

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }

            try {
                if (mNotificationManager == null) {
                    mNotificationManager =
                        mContext.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                }

                val notifications: Array<StatusBarNotification>
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    notifications = mNotificationManager?.activeNotifications!!
                    for (notification in notifications) {
                        if (notification.id == notificationId) {
                            isSendNotification = true
                            break
                        } else if (notification.id != notificationId) {
                            isSendNotification = false
                        }
                    }
                }
                if (!isSendNotification) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (mNotificationManager?.getNotificationChannel("Deleteing") == null) {
                            val notificationChannel = NotificationChannel(
                                "Deleteing",
                                "BackupAndRecovery",
                                NotificationManager.IMPORTANCE_DEFAULT
                            )
                            notificationChannel.setSound(null, null);
//                            notificationChannel.enableLights(false)
                            notificationChannel.setVibrationPattern(longArrayOf(0))
                            notificationChannel.enableVibration(true)
                            mNotificationManager?.createNotificationChannel(notificationChannel)
                        }
                    }
                }
            } catch (e9: java.lang.Exception) {
                Log.e(mTAG, "copyImageBeforeDelete: " + e9.message)
            }
        }

        override fun doInBackground(vararg strings: String?): String? {

            val size = lSavedPhotos.size
            for (i in lSavedPhotos.indices) {
                if (lSavedPhotos[i] != null) {
                    if (lSavedPhotos[i].exists()) {
                        lSavedPhotos[i].delete()
                    }
                }
                runOnUiThread {
                    Log.e(mTAG, "doInBackground: mSavedPhotos.size --> $i")
                    Log.e(mTAG, "doInBackground: -----------------------------------------------")
                    dialog.findViewById<TextView>(R.id.permission_text).text =
                        lType + " $i / $size " + getString(R.string.delete)
                }


                mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                    .setContentText("$mNoti ${i}/${size}")
                    .setSmallIcon(R.drawable.ic_icon)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setProgress(size, i, false)
                    .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                    .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                    .setContent(null)
                    .setAutoCancel(false)
                mNotificationManager?.notify(notificationId, mBuilder.build())

            }
            lSavedPhotos.clear()
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {

                mContext.runOnUiThread {
                    if (lSavedPhotos.size == 0) {
                        Log.e(mTAG, "onPostExecute: size 0 ")
                        lRecycleDeletedFiles.visibility = GONE
                        lLinearRecoveredAlbum.visibility = VISIBLE
                        binding.ivDeleteAll!!.isEnabled = false
                        binding.ivDeleteAll!!.alpha = 0.5f
                        binding.ivDeleteAll!!.isEnabled = false
                        unSelectAll()
                        Toast.makeText(
                            mContext,
                            "All $lType Are Deleted Successfully",
                            Toast.LENGTH_SHORT
                        ).show()


                        mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                            .setContentText("All $lType Are Deleted Successfully")
                            .setSmallIcon(R.drawable.ic_icon)
                            .setDefaults(Notification.DEFAULT_ALL)
                            .setProgress(0, 0, true)
                            .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                            .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                            .setContent(null)
                            .setAutoCancel(true)
                        mNotificationManager?.notify(notificationId, mBuilder.build())
                        mNotificationManager?.cancel(notificationId)
                        mNotificationManager?.cancelAll()

                    } else {
                        lLinearRecoveredAlbum.visibility = GONE
                        lRecycleDeletedFiles.visibility = VISIBLE
                        binding.ivDeleteAll!!.isEnabled = true
                        binding.ivDeleteAll!!.alpha = 1.0f
                        binding.ivDeleteAll!!.isEnabled = true
                    }
                    lMainCommonAdapter.notifyDataSetChanged()

                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            if (dialog != null && dialog.isShowing) {
                                dialog.cancel()
                                MyApplication.isDialogOpen = false
                            }
                        } catch (e: Exception) {
//                            mContext.addEvent(e.message!!)
                        }
                    }, 500)

                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    var mNotificationManager: NotificationManager? = null

    private inner class AsyncTaskRunnerForVideoImage(
        selectedList: ArrayList<TrashModel>,
        imageVideoTrashAdapter: ImageVideoTrashAdapter?,
        isFrom: String
    ) : AsyncTask<String?, String?, String>() {
        val dialog = Dialog(mContext)
        val lSelectList = selectedList
        var lImageVideoTrashAdapter = imageVideoTrashAdapter
        var lIsFrom = isFrom
        var type = "Recover"
        var mNoti = "Recover in progress"
        var notificationId = 175
        var isSendNotification = true

        //        var mBuilder : Notification?=null
        var mBuilder = NotificationCompat.Builder(mContext, "Restoring")

        override fun onPreExecute() {
            if (lIsFrom == "Image") {
                isAsyncTrashImageFragment = true
            } else {
                isAsyncTrashVideoFragment = true
            }
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            dialog.setOnKeyListener { dialog, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    Log.e(mTAG, "AsyncTaskRunnerForVideoImage:onBack")
                    if (status == AsyncTask.Status.RUNNING) {
//                        cancel(true)
                        mContext.onBackPressed()
                    }
                }
                return@setOnKeyListener true
            }

            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.restoring)
//            dialog.findViewById<TextView>(R.id.permission_text).text = "Scanning Albums..."
            var btnCancel = dialog.findViewById<Button>(R.id.dialogButtonCancel)
            btnCancel.visibility = VISIBLE
            btnCancel.text = getString(R.string.background)
            btnCancel.setOnClickListener {
                dialog.dismiss()
            }

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }

            try {
                if (mNotificationManager == null) {
                    mNotificationManager =
                        mContext.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                }

                val notifications: Array<StatusBarNotification>
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    notifications = mNotificationManager?.activeNotifications!!
                    for (notification in notifications) {
                        if (notification.id == notificationId) {
                            isSendNotification = true
                            break
                        } else if (notification.id != notificationId) {
                            isSendNotification = false
                        }
                    }
                }
                if (!isSendNotification) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (mNotificationManager?.getNotificationChannel("Restoring") == null) {
                            val notificationChannel = NotificationChannel(
                                "Restoring",
                                "BackupAndRecovery",
                                NotificationManager.IMPORTANCE_DEFAULT
                            )
                            notificationChannel.setSound(null, null);
//                            notificationChannel.enableLights(false)
                            notificationChannel.setVibrationPattern(longArrayOf(0))
                            notificationChannel.enableVibration(true)
                            mNotificationManager?.createNotificationChannel(notificationChannel)
                        }
                    }
                }
            } catch (e9: java.lang.Exception) {
                Log.e(mTAG, "copyImageBeforeDelete: " + e9.message)
            }

        }

        override fun doInBackground(vararg params: String?): String {
            val tempSize = lSelectList.size
            var finalI1 = 0

            //Toast.makeText(mContext,"doInBackground: start =->: ",Toast.LENGTH_LONG).show()
            try {
                for (i in lSelectList.indices) {

                    if (lIsFrom == "Image") {
                        isAsyncTrashImageFragment = true
                    } else {
                        isAsyncTrashVideoFragment = true
                    }
                    val finalI = finalI1
                    runOnUiThread {
                        when (lIsFrom) {
                            "Image" -> {
                                dialog.findViewById<TextView>(R.id.permission_text).text =
                                    getString(R.string.image) + " " + finalI + "/" + tempSize + " " + getString(
                                        R.string.restore
                                    )
                            }
                            "Video" -> {
                                dialog.findViewById<TextView>(R.id.permission_text).text =
                                    getString(R.string.video) + " " + finalI + "/" + tempSize + " " + getString(
                                        R.string.restore
                                    )

                            }
                        }
                        Log.e(mTAG, "run: finalI-> $finalI")
                    }
                    val filename =
                        lSelectList[i].path!!.substring(lSelectList[i].path!!.lastIndexOf("/") + 1)
                    Log.e(mTAG, "doInBackground:format filename $filename")
                    val newFileName = filename.substring(0, filename.length - 8)
                    Log.e(mTAG, "doInBackground:format newName $newFileName")

                    path = "$mRootPath/RecoverMedia/"
                    when (lIsFrom) {
                        "Image" -> {
                            path += "Image/"
                        }
                        "Video" -> {
                            path += "Video/"
                        }
                    }

                    lImageVideoTrashAdapter!!.recover(
                        mContext,
                        (path + newFileName),
                        lSelectList[i].id!!
                    )
                    finalI1 += 1

                    mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                        .setContentText("$mNoti ${finalI1}/${lSelectList.size}")
                        .setSmallIcon(R.drawable.ic_icon)
                        .setDefaults(Notification.DEFAULT_ALL)
                        .setProgress(lSelectList.size, finalI1, false)
                        .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                        .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                        .setContent(null)
                        .setAutoCancel(false)
                    mNotificationManager?.notify(notificationId, mBuilder.build())
                }
            } catch (e: Exception) {
                if (lIsFrom.equals("Image", true)) {
                    isAsyncTrashImageFragment = false
                } else {
                    isAsyncTrashVideoFragment = false
                }
                Log.e(mTAG, "doInBackground: catch =-> " + e.message)
                e.printStackTrace()
            }
            return ""
        }

        override fun onPostExecute(result: String) {
            try {
                if (dialog != null && dialog.isShowing) {
                    dialog.dismiss()
                    MyApplication.isDialogOpen = false
                }
            } catch (e: Exception) {
//                mContext.addEvent(e.message!!)
            }

            if (lSelectList.size != 0) {

                mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                    .setContentText("${getString(R.string.restore_successfully)}")
                    .setSmallIcon(R.drawable.ic_icon)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setProgress(0, 0, true)
                    .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                    .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                    .setContent(null)
                    .setAutoCancel(true)
                mNotificationManager?.notify(notificationId, mBuilder.build())
                mNotificationManager?.cancel(notificationId)
                mNotificationManager?.cancelAll()

                Toast.makeText(
                    mContext,
                    getString(R.string.file_restored_at) + path,
                    Toast.LENGTH_SHORT
                ).show()
                binding.tvHeader!!.text = getString(R.string.photo_recovered)
                binding.tvHeader!!.isSelected = true
                binding.ivDeleteAll!!.visibility = VISIBLE
                binding.ivSetting!!.visibility = GONE
                binding.frameTrash.visibility = INVISIBLE

                lastSelection=3
                if (lIsFrom.equals("Image", true)) {
                    isAsyncTrashImageFragment = false
                    prevPosRecovered=0
                } else {
                    isAsyncTrashVideoFragment = false
                    prevPosRecovered=1
                }
                mIsFromForImageCheck = "Recovered"
                lImageVideoTrashAdapter!!.notifyDataSetChanged()
                setValueFalse()

                SharedPrefsConstant.save(
                    mContext,
                    RATE_RECOVER_IMAGE_COUNT,
                    SharedPrefsConstant.getInt(mContext, RATE_RECOVER_IMAGE_COUNT) + 1
                )
                SharedPrefsConstant.save(
                    mContext,
                    FREE_RECOVER_IMAGE_COUNT,
                    SharedPrefsConstant.getInt(mContext, FREE_RECOVER_IMAGE_COUNT) + 1
                )


            } else {
                if (lIsFrom == "Image") {
                    Toast.makeText(
                        mContext,
                        getString(R.string.select_an_video),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        mContext,
                        getString(R.string.select_an_image),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            if (lIsFrom.equals("Image", true)) {
                isAsyncTrashImageFragment = false
            } else {
                isAsyncTrashVideoFragment = false
            }
            if (trashViewPagerAdapter != null) {
                when (val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)) {
                    is TrashImageFragment -> {
                        prevPosRecovered=0
                        fragment.selectedList.clear()
                        binding.checkAll.isChecked = false
                        fragment.onResume()
                    }
                    is TrashVideoFragment -> {
                        prevPosRecovered=1
                        fragment.selectedList.clear()
                        binding.checkAll.isChecked = false
                        fragment.onResume()
                    }
                }
            }
        }
    }

    private inner class AsyncTaskRunnerForAudioOther(
        selectedList: ArrayList<TrashModel>,
        audioOtherTrashAdapter: AudioOtherTrashAdapter?,
        isFrom: String
    ) : AsyncTask<String?, String?, String>() {
        val dialog = Dialog(mContext)
        val lSelectList = selectedList
        var lAudioOtherTrashAdapter = audioOtherTrashAdapter
        var lIsFrom = isFrom
        var type = "Recover"
        var mNoti = "Recover in progress"
        var notificationId = 178
        var isSendNotification = true

        //        var mBuilder : Notification?=null
        var mBuilder = NotificationCompat.Builder(mContext, "Restoring")


        override fun onPreExecute() {

            if (lIsFrom == "Audio") {
                isAsyncTrashAudioFragment = true
            } else if (lIsFrom == "Document") {
                isAsyncTrashDocumentFragment = true
            } else {
                isAsyncTrashOtherFragment = true
            }
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.setOnKeyListener { dialog, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    Log.e(mTAG, "AsyncTaskRunnerForAudioOther:onBack")
                    if (status == AsyncTask.Status.RUNNING) {
                        cancel(true)
                        mContext.onBackPressed()
                    }
                }
                return@setOnKeyListener true
            }
            dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.restoring)
//            dialog.findViewById<TextView>(R.id.permission_text).text = "Scanning Albums..."

            var btnCancel = dialog.findViewById<Button>(R.id.dialogButtonCancel)
            btnCancel.visibility = VISIBLE
            btnCancel.text = getString(R.string.background)
            btnCancel.setOnClickListener {
                dialog.dismiss()
            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
            try {
                if (mNotificationManager == null) {
                    mNotificationManager =
                        mContext.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                }

                val notifications: Array<StatusBarNotification>
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    notifications = mNotificationManager?.activeNotifications!!
                    for (notification in notifications) {
                        if (notification.id == notificationId) {
                            isSendNotification = true
                            break
                        } else if (notification.id != notificationId) {
                            isSendNotification = false
                        }
                    }
                }
                if (!isSendNotification) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (mNotificationManager?.getNotificationChannel("Restoring") == null) {
                            val notificationChannel = NotificationChannel(
                                "Restoring",
                                "BackupAndRecovery",
                                NotificationManager.IMPORTANCE_DEFAULT
                            )
                            notificationChannel.setSound(null, null);
//                            notificationChannel.enableLights(false)
                            notificationChannel.setVibrationPattern(longArrayOf(0))
                            notificationChannel.enableVibration(true)
                            mNotificationManager?.createNotificationChannel(notificationChannel)
                        }
                    }
                }
            } catch (e9: java.lang.Exception) {
                if (lIsFrom == "Audio") {
                    isAsyncTrashAudioFragment = false
                } else if (lIsFrom == "Document") {
                    isAsyncTrashDocumentFragment = false
                } else {
                    isAsyncTrashOtherFragment = false
                }
                Log.e(mTAG, "copyImageBeforeDelete: " + e9.message)
            }
        }

        override fun doInBackground(vararg params: String?): String {
            val tempSize = lSelectList.size
            var finalI1 = 0
            try {
                for (i in lSelectList.indices) {
                    if (lIsFrom == "Audio") {
                        isAsyncTrashAudioFragment = true
                    } else if (lIsFrom == "Document") {
                        isAsyncTrashDocumentFragment = true
                    } else {
                        isAsyncTrashOtherFragment = true
                    }
                    val finalI = finalI1
                    runOnUiThread {
                        when (lIsFrom) {
                            "Audio" -> {
                                dialog.findViewById<TextView>(R.id.permission_text).text =
                                    getString(R.string.audio) + " " + finalI + "/" + tempSize + " " + getString(
                                        R.string.restore
                                    )
                            }
                            else -> {
                                dialog.findViewById<TextView>(R.id.permission_text).text =
                                    getString(R.string.doc_other_files) + " " + finalI + "/" + tempSize + " " + getString(
                                        R.string.restore
                                    )
                            }
                        }
                        Log.e(mTAG, "run: finalI-> $finalI")
                    }

                    val filename =
                        lSelectList[i].path!!.substring(lSelectList[i].path!!.lastIndexOf("/") + 1)
                    Log.e(mTAG, "doInBackground:format filename $filename")

                    val newFileName = filename.substring(0, filename.length - 8)
                    Log.e(mTAG, "doInBackground:format newName $newFileName")

                    path = "$mRootPath/RecoverMedia/"
                    when (lIsFrom) {
                        "Audio" -> {
                            path += "Audio/"
                        }
                        "Document" -> {
                            path += "Document/"
                        }
                        "Other" -> {
                            path += "Other/"
                        }
                    }

                    lAudioOtherTrashAdapter!!.recover(
                        mContext,
                        (path + newFileName),
                        lSelectList[i].id!!
                    )
                    finalI1 += 1

//                    val intent = Intent(mContext, NewRecoverImageActivity::class.java)
//                    intent.putExtra("IsFromNotification", "yes")
//                    SharedPrefsConstant.saveStringNoti(mContext, "IsTypeFor", type)
//                    intent.putExtra("Typess", type)
//                    intent.action = java.lang.Long.toString(System.currentTimeMillis())
//
//                    var pendingIntent = PendingIntent.getActivity(
//                        mContext,
//                        notificationId,
//                        intent,
//                        PendingIntent.FLAG_UPDATE_CURRENT
//                    )

                    mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                        .setContentText("$mNoti ${finalI1}/${lSelectList.size}")
                        .setSmallIcon(R.drawable.ic_icon)
                        .setDefaults(Notification.DEFAULT_ALL)
                        .setProgress(lSelectList.size, finalI1, false)
                        .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                        .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                        .setContent(null)
                        .setAutoCancel(false)
                    mNotificationManager?.notify(notificationId, mBuilder.build())
                }
            } catch (e: Exception) {
                Log.e(mTAG, "doInBackground: catch =-> " + e.message)
                e.printStackTrace()
            }
            return ""
        }

        override fun onPostExecute(result: String) {
            try {
                if (dialog.isShowing) {
                    dialog.cancel()
                    MyApplication.isDialogOpen = false
                }
            } catch (e: Exception) {
//                mContext.addEvent(e.message!!)
            }
            if (lSelectList.size != 0) {

                mBuilder.setContentTitle(mContext.getString(R.string.app_name))
                    .setContentText("${getString(R.string.restore_successfully)}")
                    .setSmallIcon(R.drawable.ic_icon)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setProgress(0, 0, true)
                    .setColor(ContextCompat.getColor(mContext, R.color.colorPrimary))
                    .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                    .setContent(null)
                    .setAutoCancel(true)
                mNotificationManager?.notify(notificationId, mBuilder.build())
                mNotificationManager?.cancel(notificationId)
                mNotificationManager?.cancelAll()

                Toast.makeText(
                    mContext,
                    getString(R.string.file_restored_at) + path,
                    Toast.LENGTH_SHORT
                ).show()
                binding.tvHeader!!.text = getString(R.string.photo_recovered)
                binding.tvHeader!!.isSelected = true
                binding.ivDeleteAll!!.visibility = VISIBLE
                binding.ivSetting!!.visibility = GONE
                binding.frameTrash.visibility = INVISIBLE

                if (lIsFrom == "Audio") {
                    isAsyncTrashAudioFragment = false
                } else if (lIsFrom == "Document") {
                    isAsyncTrashDocumentFragment = false
                } else {
                    isAsyncTrashOtherFragment = false
                }
                mIsFromForImageCheck = "Recovered"
                lAudioOtherTrashAdapter!!.notifyDataSetChanged()
                setValueFalse()

                SharedPrefsConstant.save(
                    mContext,
                    RATE_RECOVER_IMAGE_COUNT,
                    SharedPrefsConstant.getInt(mContext, RATE_RECOVER_IMAGE_COUNT) + 1
                )
                SharedPrefsConstant.save(
                    mContext,
                    FREE_RECOVER_IMAGE_COUNT,
                    SharedPrefsConstant.getInt(mContext, FREE_RECOVER_IMAGE_COUNT) + 1
                )

            } else {
                if (lIsFrom == "Audio") {
                    Toast.makeText(
                        mContext,
                        getString(R.string.select_an_audio),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        mContext,
                        getString(R.string.select_an_document),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            if (trashViewPagerAdapter != null) {
                when (val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)) {

                    is TrashAudioFragment -> {
                        fragment.selectedList.clear()
                        binding.checkAll.isChecked = false
                        fragment.onResume()
                    }
                    is TrashDocumentFragment -> {
                        fragment.selectedList.clear()
                        binding.checkAll.isChecked = false
                        fragment.onResume()
                    }
                    is TrashOtherFragment -> {
                        fragment.selectedList.clear()
                        binding.checkAll.isChecked = false
                        fragment.onResume()
                    }
                }
            }
        }
    }

    fun toggleRecoverButtonVisibility(isVisible: Boolean) {
        if (isVisible) {
            binding.llView.visibility = VISIBLE
        } else {
            binding.llView.visibility = GONE
        }
    }


    private fun setupViewPagerTrash(viewPager: ViewPager?) {
        trashViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        trashViewPagerAdapter!!.addFrag(TrashImageFragment.newInstance(), "Images")
        trashViewPagerAdapter!!.addFrag(TrashVideoFragment.newInstance(), "Video")
        trashViewPagerAdapter!!.addFrag(TrashAudioFragment.newInstance(), "Audio")
        trashViewPagerAdapter!!.addFrag(TrashDocumentFragment.newInstance(), "Document")
        trashViewPagerAdapter!!.addFrag(TrashOtherFragment.newInstance(), "Other")
        viewPager!!.adapter = trashViewPagerAdapter!!
        viewPager.offscreenPageLimit = 5

//        Log.e(mTAG, "setupViewPager: showStatusPopup --> setViewPager")

        binding.loutTab.addOnTabSelectedListener(object :TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if(tab!=null){
                    binding.viewPagerTrash.currentItem=tab.position
                    when(tab?.position){
                        0 -> {
                            binding.viewPagerTrash.currentItem = 0
                            binding.ivSpan.visibility = VISIBLE
                        }

                        1 -> {
                            binding.viewPagerTrash.currentItem = 1
                            binding.ivSpan.visibility = VISIBLE
                        }

                        2 -> {
                            binding.viewPagerTrash.currentItem = 2
                            binding.ivSpan.visibility = GONE
                        }

                       3 -> {
                            binding.viewPagerTrash.currentItem = 3
                            binding.ivSpan.visibility = GONE
                        }

                        4 -> {
                            binding.viewPagerTrash.currentItem = 4
                            binding.ivSpan.visibility = GONE
                        }

                        else -> {
                            null
                        }
                    }
                }

            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }
        })
//        binding.bottomNavigationTrash.setOnNavigationItemSelectedListener {
//            Log.e(mTAG, "showStatusPopup setupViewPager: " + it.itemId)
//            when (it.itemId) {
//                R.id.nav_image -> {
//                    binding.viewPagerTrash.currentItem = 0
//                    binding.ivSpan.visibility = VISIBLE
//                }
//                R.id.nav_video -> {
//                    binding.viewPagerTrash.currentItem = 1
//                    binding.ivSpan.visibility = VISIBLE
//                }
//                R.id.nav_audio -> {
//                    binding.viewPagerTrash.currentItem = 2
//                    binding.ivSpan.visibility = GONE
//                }
//                R.id.nav_doc -> {
//                    binding.viewPagerTrash.currentItem = 3
//                    binding.ivSpan.visibility = GONE
//                }
//                R.id.nav_other -> {
//                    binding.viewPagerTrash.currentItem = 4
//                    binding.ivSpan.visibility = GONE
//                }
//                else -> {
//                    null
//                }
//            } != null
//
//        }

        binding.viewPagerTrash.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
//                Log.e(mTAG, "showStatusPopup onPageScrolled: $position")
            }


            override fun onPageSelected(position: Int) {

                when (val lFragment = trashViewPagerAdapter!!.getItem(prevPosTrash)) {
                    is TrashImageFragment -> {
//                        Log.e(mTAG, "onPageSelected:Image $lFragment")
//                        Log.e(mTAG, "onPageSelected:Image Adapter " + lFragment.mainCommonAdapter)
                        lFragment.selectedList.clear()
                        if (lFragment.mainCommonAdapter != null) {
                            lFragment.mainCommonAdapter!!.deSelectAll()
                        }
                        setValueFalse()
                        binding.checkAll.isChecked = false
                        binding.ivSpan.visibility = VISIBLE
                    }
                    is TrashVideoFragment -> {
                        lFragment.selectedList.clear()
                        if (lFragment.mainCommonAdapter != null) {
                            lFragment.mainCommonAdapter!!.deSelectAll()
                        }
                        setValueFalse()
                        binding.checkAll.isChecked = false
                        binding.ivSpan.visibility = VISIBLE
                    }
                    is TrashAudioFragment -> {
                        lFragment.selectedList.clear()
                        if (lFragment.mainCommonAdapter != null) {
                            lFragment.mainCommonAdapter!!.deSelectAll()
                        }
                        setValueFalse()
                        binding.checkAll.isChecked = false
                        binding.ivSpan.visibility = GONE
                    }
                    is TrashDocumentFragment -> {
                        lFragment.selectedList.clear()
                        if (lFragment.mainCommonAdapter != null) {
                            lFragment.mainCommonAdapter!!.deSelectAll()
                        }
                        binding.checkAll.isChecked = false
                        binding.ivSpan.visibility = GONE
                    }
                    is TrashOtherFragment -> {
                        lFragment.selectedList.clear()
                        if (lFragment.mainCommonAdapter != null) {
                            lFragment.mainCommonAdapter!!.deSelectAll()
                        }
                        setValueFalse()
                        binding.checkAll.isChecked = false
                        binding.ivSpan.visibility = GONE
                    }
                }

                if (prevPosTrash != position) {
                    prevPosTrash = position

                    binding.loutTab.selectTab(binding.loutTab.getTabAt(position))
                    when (position) {
                        0 -> {
                            val fragment = trashViewPagerAdapter!!.getItem(0)
                            if (fragment is TrashImageFragment) {
                                fragment.userVisibleHint = true
                            }
//                            binding.bottomNavigationTrash.selectedItemId = R.id.nav_image
                            binding.loutTab.selectTab(binding.loutTab.getTabAt(0))
                        }
                        1 -> {
                            val fragment = trashViewPagerAdapter!!.getItem(1)
                            if (fragment is TrashVideoFragment) {
                                fragment.userVisibleHint = true
                            }
//                            binding.bottomNavigationTrash.selectedItemId = R.id.nav_video
                            binding.loutTab.selectTab(binding.loutTab.getTabAt(1))
                        }
                        2 -> {
                            val fragment = trashViewPagerAdapter!!.getItem(2)
                            if (fragment is TrashAudioFragment) {
                                fragment.userVisibleHint = true
                            }
//                            binding.bottomNavigationTrash.selectedItemId = R.id.nav_audio
                            binding.loutTab.selectTab(binding.loutTab.getTabAt(2))
                        }
                        3 -> {
                            val fragment = trashViewPagerAdapter!!.getItem(3)
                            if (fragment is TrashDocumentFragment) {
                                fragment.userVisibleHint = true
                            }
//                            binding.bottomNavigationTrash.selectedItemId = R.id.nav_doc
                            binding.loutTab.selectTab(binding.loutTab.getTabAt(3))
                        }
                        4 -> {
                            val fragment = trashViewPagerAdapter!!.getItem(4)
                            if (fragment is TrashOtherFragment) {
                                fragment.userVisibleHint = true
                            }
//                            binding.bottomNavigationTrash.selectedItemId = R.id.nav_other
                            binding.loutTab.selectTab(binding.loutTab.getTabAt(4))
                        }
                    }

                }
                prevFragmentPos = position
            }

            override fun onPageScrollStateChanged(state: Int) {
//                Log.e(mTAG, "showStatusPopup onPageScrollStateChanged: ")
            }


        })
    }


    class ViewPagerAdapter(manager: FragmentManager?) : FragmentPagerAdapter(manager!!) {

        private val mFragmentList: MutableList<Fragment> = ArrayList()
        private val mFragmentTitleList: MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFrag(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence {
            return mFragmentTitleList[position]
        }
    }

    private fun setSpanCount() {
        var mCurrentSpanCount = mContext.getGridCount()
        mCurrentSpanCount = if (mCurrentSpanCount == SPAN_COUNT_THREE) {
            SPAN_COUNT_TWO
        } else {
            SPAN_COUNT_THREE
        }
        mContext.saveGridCount(mCurrentSpanCount)
        Log.e(mTAG, "setSpanCount: isGridChange mCurrentSpanCount--> $mCurrentSpanCount")
        binding.ivSpan!!.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        spanCount(mCurrentSpanCount)
    }


    private fun deselectPrevSelection() {
        if (trashViewPagerAdapter != null) {
            when (val fragment = trashViewPagerAdapter!!.getItem(prevPosTrash)) {
                is TrashImageFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        fragment.mainCommonAdapter!!.deSelectAll()
                    }
                    if (fragment.selectedList != null) {
                        fragment.selectedList.clear()
                    }
                }
                is TrashVideoFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        fragment.mainCommonAdapter!!.deSelectAll()
                    }
                    if (fragment.selectedList != null) {
                        fragment.selectedList.clear()
                    }
                }
                is TrashAudioFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        fragment.mainCommonAdapter!!.deSelectAll()
                    }
                    if (fragment.selectedList != null) {
                        fragment.selectedList.clear()
                    }
                }
                is TrashDocumentFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        fragment.mainCommonAdapter!!.deSelectAll()
                    }
                    if (fragment.selectedList != null) {
                        fragment.selectedList.clear()
                    }
                }
                is TrashOtherFragment -> {
                    if (fragment.mainCommonAdapter != null) {
                        fragment.mainCommonAdapter!!.deSelectAll()
                    }
                    if (fragment.selectedList != null) {
                        fragment.selectedList.clear()
                    }
                }
            }
        }
    }

    private fun setValueFalse() {
        isDateClick = false
        isSizeClick = false
    }

    private fun showStatusPopupForNotification(context: Activity, p: Point) {
        val layoutInflater = context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val layout = layoutInflater.inflate(R.layout.dialog_new_notification, null)
        val changeStatusPopUp = PopupWindow(context)
        changeStatusPopUp.contentView = layout
        changeStatusPopUp.width = LinearLayout.LayoutParams.WRAP_CONTENT
        changeStatusPopUp.height = LinearLayout.LayoutParams.WRAP_CONTENT
        changeStatusPopUp.isFocusable = true

        val main: ConstraintLayout = layout.findViewById(R.id.main)
        main.setOnClickListener { changeStatusPopUp.dismiss() }

        val llNotificationOn: ConstraintLayout = layout.findViewById(R.id.llNotiOn)
        val lIvOn = layout.findViewById<ImageView>(R.id.iv_select_on)
        val llNotificationOff: ConstraintLayout = layout.findViewById(R.id.llNotiOff)
        val lIvOff = layout.findViewById<ImageView>(R.id.iv_select_off)

        if (SharedPrefsConstant.getBooleanNoti(mContext, "NotificationForDelete", true)) {
            lIvOn.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_select))
            lIvOff.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_unselect))
        } else {
            lIvOn.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_unselect))
            lIvOff.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_select))
        }
        llNotificationOn.setOnClickListener {
            SharedPrefsConstant.savePrefNoti(mContext, "NotificationForDelete", true)
            lIvOn.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_select))
            lIvOff.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_unselect))
            changeStatusPopUp.dismiss()
        }
        llNotificationOff.setOnClickListener {
            SharedPrefsConstant.savePrefNoti(mContext, "NotificationForDelete", false)
            lIvOn.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_unselect))
            lIvOff.setImageDrawable(resources.getDrawable(R.drawable.ic_radio_select))
            changeStatusPopUp.dismiss()
        }
        changeStatusPopUp.setOnDismissListener {
//            spanCount()
        }
        changeStatusPopUp.setBackgroundDrawable(BitmapDrawable())
        changeStatusPopUp.showAtLocation(layout, Gravity.NO_GRAVITY, p.x, p.y)
    }

    /* --------------------------------- Recovered Album End --------------------------------- */


    fun selectTop(pos:Int=1) {
        if(lastSelection == pos) {
            if (selection == 0) selectAll()
            else if (selection == 1) selectAllSize()
            else if (selection == 2) selectAllDate()
        }
    }

    var selection = 0
    fun selectAll() {
        selection = 0
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        llDateWise.isEnabled = true
//        llSizeWise.isEnabled = true
    }

    private fun selectAllSize() {
        selection = 1
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        llDateWise.isEnabled = true
//        llSizeWise.isEnabled = true
    }

    private fun selectAllDate() {
        selection = 2
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        llDateWise.isEnabled = true
//        llSizeWise.isEnabled = true
    }

    fun unSelectAll() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
//        llDateWise.isEnabled = false
//        llSizeWise.isEnabled = false
    }

    override fun onPause() {
        super.onPause()

        when {
            binding.frameTrash.visibility == VISIBLE -> {
                mIsFromForImageCheck = "Trash"
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        this.intent = intent
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()

//        if(mIsFromNotification == "yes") {
//                Handler().postDelayed({
//                    spanCount()
//                }, 500)
//            }

        mIsFromNotification = intent.getStringExtra("IsFromNotification")
        Log.e(mTAG, "onResume: setAllData mIsFromNotification -> $mIsFromNotification")
        Log.e(mTAG, "onResume:mIsFromForImageCheck $mIsFromForImageCheck")

        binding.ivSpan!!.isSelected = mContext.getGridCount() == SPAN_COUNT_THREE
        Log.e(mTAG, "onResume:isGridChange: $isGridChange")
        if (isGridChange) {
            isGridChange = false
            if (mIsFromNotification == "yes") {
                Log.e(mTAG, "onResume:isGridChange isFromNoti ")
            } else {
                Handler().postDelayed({
                    spanCount(mContext.getGridCount())
                }, 500)
                Log.e(mTAG, "onResume:isGridChange spanCount ")
            }
        }

        if (mIsFromNotification == "yes") {
            Log.e(mTAG, "setAllData: yes")
            intent.putExtra("IsFromNotification", "")
            setDataFromNotification()
        }


        when (mIsFromForImageCheck) {
            "Recoverable" -> {
                binding.tvHeader!!.text = getString(R.string.photo_recover)
                binding.tvHeader!!.isSelected = true
                binding.ivDeleteAll!!.visibility = GONE
                binding.ivSetting!!.visibility = GONE
                binding.frameTrash.visibility = INVISIBLE
                setValueFalse()
                mIsFromForImageCheck = "Recoverable"
            }
            "Recovered" -> {
                binding.tvHeader!!.text = getString(R.string.photo_recovered)
                binding.tvHeader!!.isSelected = true
                binding.ivDeleteAll!!.visibility = VISIBLE
                binding.ivSetting!!.visibility = GONE
                binding.frameTrash.visibility = INVISIBLE
                setValueFalse()
                mIsFromForImageCheck = "Recovered"
            }
            "Trash" -> {
                //            setDataFromNotification("Resume")
            }
        }

        if (SharedPrefsConstant.getBoolean(mContext, "AfterRecover", false)) {
            Log.e(mTAG, "onResume:AfterRecover ")
            SharedPrefsConstant.savePref(mContext, "AfterRecover", false)
            binding.tvHeader!!.text = getString(R.string.photo_recovered)
            binding.tvHeader!!.isSelected = true
            binding.ivDeleteAll!!.visibility = VISIBLE
            binding.ivSetting!!.visibility = GONE
            binding.frameTrash.visibility = GONE
            setValueFalse()
            lastSelection = 3

            mIsFromForImageCheck = "Recovered"
        }
        SharedPrefsConstant.savePrefNoti(this@TrashImageActivity, "isDeleteFromEmpty", false)
    }

    private fun setDataFromNotification() {
        setValueFalse()
        mIsFromForImageCheck = "Trash"

        binding.tvHeader!!.text = getString(R.string.trash_recover)
        binding.tvHeader!!.isSelected = true
        binding.ivDeleteAll!!.visibility = GONE
        binding.ivSetting!!.visibility = VISIBLE
        binding.frameTrash.visibility = VISIBLE
        addEvent("TrashModule")
        var type: String? = "Image"

        lastSelection = 2
        Log.e(mTAG, "Resume" + " setAllData :intent.hasExtra(Typess) " + intent.hasExtra("Typess"))
        if (intent.hasExtra("Typess")) {
            type = intent.getStringExtra("Typess")
        }

        if (type == "Image") {
            prevPosTrash=0
            selection=0
            Handler().postDelayed({
//                binding.bottomNavigationTrash.selectedItemId = R.id.nav_image
                binding.loutTab.selectTab(binding.loutTab.getTabAt(0))
            }, 700)
            binding.viewPagerTrash.currentItem = 0
            val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
            if (fragment is TrashImageFragment) {
                fragment.userVisibleHint = true
                fragment.onResume()
                fragment.stopLoading()
            }
        } else if (type == "Video") {
            prevPosTrash=1
            Handler().postDelayed({
//                binding.bottomNavigationTrash.selectedItemId = R.id.nav_video
                binding.loutTab.selectTab(binding.loutTab.getTabAt(1))
            }, 700)
            binding.viewPagerTrash.currentItem = 1
            val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
            if (fragment is TrashVideoFragment) {
                fragment.userVisibleHint = true
                fragment.onResume()
                fragment.stopLoading()
            }
        } else if (type == "Audio") {
            prevPosTrash=2
            Handler().postDelayed({
//                binding.bottomNavigationTrash.selectedItemId = R.id.nav_audio
                binding.loutTab.selectTab(binding.loutTab.getTabAt(2))
            }, 700)
            binding.viewPagerTrash.currentItem = 2
            val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
            if (fragment is TrashAudioFragment) {
                fragment.userVisibleHint = true
                fragment.onResume()
                fragment.stopLoading()
            }
        } else if (type == "Document") {
            prevPosTrash=3
            Handler().postDelayed({
//                binding.bottomNavigationTrash.selectedItemId = R.id.nav_doc
                binding.loutTab.selectTab(binding.loutTab.getTabAt(3))
            }, 700)
            binding.viewPagerTrash.currentItem = 3
            val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
            if (fragment is TrashDocumentFragment) {
                fragment.userVisibleHint = true
                fragment.onResume()
                fragment.stopLoading()
            }
        } else if (type == "Other") {
            prevPosTrash=4
            Handler().postDelayed({
//                binding.bottomNavigationTrash.selectedItemId = R.id.nav_other
                binding.loutTab.selectTab(binding.loutTab.getTabAt(4))
            }, 700)
            binding.viewPagerTrash.currentItem = 4
            val fragment = trashViewPagerAdapter!!.getItem(binding.viewPagerTrash.currentItem)
            if (fragment is TrashOtherFragment) {
                fragment.userVisibleHint = true
                fragment.onResume()
                fragment.stopLoading()
            }
        }
    }

    fun spanCount(lCurrentSpanCount:Int) {
//        val lCurrentSpanCount = mContext.getGridCount()

        Log.e(mTAG, "setSpanCount: mIsFromForImageCheck $mIsFromForImageCheck")

        if (mIsFromForImageCheck == "Trash") {
            if (trashViewPagerAdapter != null) {
                val trashPhotoFragment = trashViewPagerAdapter!!.getItem(0)
                if (trashPhotoFragment != null) {
                    if (trashPhotoFragment is TrashImageFragment) {
                        if (trashPhotoFragment.binding.deletedFilesGrid != null) {
                            Log.e(mTAG, "setSpanCount: Image binding.deletedFilesGrid 01-> $lCurrentSpanCount")
                            trashPhotoFragment.binding.deletedFilesGrid.numColumns = lCurrentSpanCount
                            if (trashPhotoFragment.mainCommonAdapter != null) {
                                Log.e(mTAG, "setSpanCount: Image Adapter notifyDataSetChanged 01->")
                                trashPhotoFragment.mainCommonAdapter!!.notifyDataSetChanged()
                            }
                            Log.e(mTAG, "setSpanCount: Image binding.deletedFilesGrid 02-> $lCurrentSpanCount")
                            trashPhotoFragment.binding.deletedFilesGrid.numColumns = lCurrentSpanCount
                            if (trashPhotoFragment.mainCommonAdapter != null) {
                                Log.e(mTAG, "setSpanCount: Image Adapter notifyDataSetChanged 02->")
                                trashPhotoFragment.mainCommonAdapter!!.notifyDataSetChanged()
                            }
                        }
                        trashPhotoFragment.userVisibleHint = true
                        Handler().postDelayed({
                            trashPhotoFragment.onResume()
                            trashPhotoFragment.stopLoading()
                        },100)
                    }
                }
                val trashVideoFragment = trashViewPagerAdapter!!.getItem(1)
                if (trashVideoFragment != null) {
                    if (trashVideoFragment is TrashVideoFragment) {
                        if (trashVideoFragment.binding.deletedFilesGrid != null) {
                            Log.e(mTAG, "setSpanCount: Video binding.deletedFilesGrid 01-> $lCurrentSpanCount")
                            trashVideoFragment.binding.deletedFilesGrid.numColumns = lCurrentSpanCount
                            if (trashVideoFragment.mainCommonAdapter != null) {
                                Log.e(mTAG, "setSpanCount: Video Adapter notifyDataSetChanged 01->")
                                trashVideoFragment.mainCommonAdapter!!.notifyDataSetChanged()
                            }
                            Log.e(mTAG, "setSpanCount: Video binding.deletedFilesGrid 02-> $lCurrentSpanCount")
                            trashVideoFragment.binding.deletedFilesGrid.numColumns = lCurrentSpanCount
                            if (trashVideoFragment.mainCommonAdapter != null) {
                                Log.e(mTAG, "setSpanCount: Video Adapter notifyDataSetChanged 02->")
                                trashVideoFragment.mainCommonAdapter!!.notifyDataSetChanged()
                            }
                        }
                        trashVideoFragment.userVisibleHint = true
                        Handler().postDelayed({
                            trashVideoFragment.onResume()
                            trashVideoFragment.stopLoading()
                        },100)
                    }
                }
            }
        }
    }

    fun stopAsync() {

//        val trashImage=recoverableViewPagerAdapter!!.getItem(0)
//        val trashVideo=recoverableViewPagerAdapter!!.getItem(1)
//        val trashAudio=recoverableViewPagerAdapter!!.getItem(2)
//        val trashDocument=recoverableViewPagerAdapter!!.getItem(3)

    }

    override fun onBackPressed() {
        stopAsync()
        if (mIsFromNotification == "yes" || isFromOneSignal) {
            startActivity(NewHomeActivity.newIntent(this))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } else if (SharedPrefsConstant.getBooleanNoti(mContext, "IsFromService", false)) {
            Log.e(mTAG, "onBackPressed: IsFromService ")
            startActivity(NewHomeActivity.newIntent(this))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } else {
//            val isRated = ExitSPHelper(mContext).isRated()
//            Log.e(mTAG, "onBackPressed: isRated $isRated")
//            if (!isRated) {
//                if (SharedPrefsConstant.getInt(mContext, RATE_RECOVER_IMAGE_COUNT) >= 4 && SharedPrefsConstant.getInt(mContext,ShareConstants.RATE_LATTER,1)==0) {
//                    RatingDialog.smileyRatingDialog(mContext)
//                } else {
//                    super.onBackPressed()
//                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                }
//            } else {
            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    setAllData()
                    Log.e(mTAG, "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                    }
                    finish()
                    Toast.makeText(
                        mContext,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                setAllData()
            } else {
                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                }
                finish()
                Toast.makeText(
                    mContext,
                    getString(R.string.permission_required),
                    Toast.LENGTH_SHORT
                ).show()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
    }

    fun selectSizeAsc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//        tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }

    fun selectSizeDesc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//        tvSize!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvDate!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }

    fun selectDateDesc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_down1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }

    fun selectDateAsc() {
//        llDateWise!!.background = resources.getDrawable(R.drawable.tab_box_fill)
//        llSizeWise!!.background = resources.getDrawable(R.drawable.tab_box_un_fill)
//        select_up_date!!.setImageDrawable(resources.getDrawable(R.drawable.ic_select_up1))
//        select_up_size!!.setImageDrawable(resources.getDrawable(R.drawable.ic_unselect1))
//        tvDate!!.setTextColor(resources.getColor(R.color.colorPrimary))
//        tvSize!!.setTextColor(resources.getColor(R.color.filter_text_color))
    }

}