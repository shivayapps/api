package com.backup.restore.device.image.recovery.retriever;

import android.app.Activity;

import com.backup.restore.device.image.recovery.utilities.OnFolderLoaded;

public abstract class Retriever {

    private OnFolderLoaded callback;

    public void loadAlbums(final Activity context, final boolean hiddenFolders, int type, final OnFolderLoaded callback) {
        setCallback(callback);
        loadAlbums(context, hiddenFolders, type);
    }

    abstract void loadAlbums(final Activity context, final boolean hiddenFolders, int type);

    public void onDestroy() {
        setCallback(null);
    }

    public void setCallback(OnFolderLoaded callback) {
        this.callback = callback;
    }

    public OnFolderLoaded getCallback() {
        return callback;
    }
}
