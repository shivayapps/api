package com.backup.restore.device.image.recovery.utilities.common;

//import static org.jetbrains.anko.Sdk25ServicesKt.getInputMethodManager;
import static org.jetbrains.anko.Sdk27ServicesKt.getInputMethodManager;

import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Build.VERSION;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.core.os.EnvironmentCompat;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MyUtils {

    public static String TAG = "Utils_Duplicate";

    public static void hideKeyboard(Context context, View target) {
        if (context == null || target == null) {
            return;
        }
        Log.e("hideKeyboard", "hideKeyboard: " );
        InputMethodManager imm = getInputMethodManager(context);
        target.clearFocus();
        imm.hideSoftInputFromWindow(target.getWindowToken(), 0);
    }

    public static void logError(String str) {
        Log.e(TAG, str);
    }

    public static File generateFile(Context context, String prefix) {
        String timeStamp = new SimpleDateFormat("ddMMyyyy_hh_mm_ss", Locale.getDefault()).format(new Date());
        String FILENAME = prefix+""+timeStamp+".xls";

//                    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
//                        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
//                    } else {
//                        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "Android" + File.separator + "data" + File.separator + packageName
//                    }

        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString();
        String path = ShareConstants.mRootPath + "/RecoverMedia/Contact Backup/";
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdir();
        }
        String filePath = dir.getPath() + File.separator + FILENAME;
        File file = new File(dir.getPath() + File.separator + FILENAME);

        if (new File(filePath).exists()) {
            new File(filePath).delete();
            new File(filePath).mkdir();
        }
        if (!new File(file.getParent()).exists()) {
            new File(file.getParent()).mkdir();
        }
        return file;
    }


    public static void showToastMsg(Context context, String str) {
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }

    public static boolean isSelectedStorageAccessFrameWorkPathIsProper(Context context, String pathName) {
        String sdCardPath = getSDCardPath(context);
        Log.e("isSelectedStIsProper", "---saf-df----" + pathName);
        if (sdCardPath == null) {
            return false;
        }
        String[] splitSDCArdPath = sdCardPath.split("\\/");
        return pathName.equals(splitSDCArdPath[splitSDCArdPath.length - 1]);
    }

    public static String getSDCardPath(Context context) {
        File file1 = new File(GlobalVarsAndFunctions.SDCARD_1);
        File file2 = new File(GlobalVarsAndFunctions.SDCARD_2);
        File file3 = new File(GlobalVarsAndFunctions.SDCARD_3);
        File file4 = new File(GlobalVarsAndFunctions.SDCARD_4);
        File file5 = new File(GlobalVarsAndFunctions.SDCARD_5);
        File file6 = new File(GlobalVarsAndFunctions.SDCARD_6);
        if (file1.exists()) {
            return String.valueOf(file1);
        }
        if (file2.exists()) {
            return String.valueOf(file2);
        }
        if (file3.exists()) {
            return String.valueOf(file3);
        }
        if (file4.exists()) {
            return String.valueOf(file4);
        }
        if (file5.exists()) {
            return String.valueOf(file5);
        }
        if (file6.exists()) {
            return String.valueOf(file6);
        }
        return getSD_CardPath_M(context);
    }

    public static String getSD_CardPath_M(Context context) {
        String[] externalStoragePath = getExternalStorageDirectories(context);
        if (externalStoragePath.length == 0) {
            return null;
        }
        return externalStoragePath[0] + "/";
    }

    public static String[] getExternalStorageDirectories(Context context) {
        int i;
        List<String> results = new ArrayList<>();
        if (VERSION.SDK_INT >= 19) {
            try {
                for (File file : context.getExternalFilesDirs(null)) {
                    boolean addPath;
                    String path = file.getPath().split("/Android")[0];
                    if (VERSION.SDK_INT >= 21) {
                        addPath = Environment.isExternalStorageRemovable(file);
                    } else {
                        addPath = "mounted".equals(EnvironmentCompat.getStorageState(file));
                    }
                    if (addPath) {
                        results.add(path);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "getExternalStorageDirectories: " + e.getMessage());
            }
        }
        if (results.isEmpty()) {
            String output = "";
            try {
                Process process = new ProcessBuilder().command("mount | grep /dev/block/vold").redirectErrorStream(true).start();
                process.waitFor();
                InputStream is = process.getInputStream();
                byte[] buffer = new byte[1024];
                while (is.read(buffer) != -1) {
                    output = output + new String(buffer);
                }
                is.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            if (!output.trim().isEmpty()) {
//                for (String voldPoint : output.split(IOUtils.LINE_SEPARATOR_UNIX)) {
                for (String voldPoint : output.split("\n")) {
                    results.add(voldPoint.split(" ")[2]);
                }
            }
        }
        int i2;
        if (VERSION.SDK_INT >= 23) {
            i = 0;
            while (i < results.size()) {
                if (!results.get(i).toLowerCase().matches(".*[0-9a-f]{4}[-][0-9a-f]{4}")) {
                    Log.d(TAG, results.get(i) + " might not be extSDcard");
                    i2 = i - 1;
                    results.remove(i);
                    i = i2;
                }
                i++;
            }
        } else {
            i = 0;
            while (i < results.size()) {
                if (!(results.get(i).toLowerCase().contains("ext") || results.get(i).toLowerCase().contains("sdcard"))) {
                    Log.d(TAG, results.get(i) + " might not be extSDcard");
                    i2 = i - 1;
                    results.remove(i);
                    i = i2;
                }
                i++;
            }
        }
        String[] storageDirectories = new String[results.size()];
        for (i = 0; i < results.size(); i++) {
            storageDirectories[i] = results.get(i);
        }
        return storageDirectories;
    }

    public boolean isNetworkConnected(Context mContext) {
        ConnectivityManager cm = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }
}
