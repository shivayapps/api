package com.backup.restore.device.image.recovery.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Environment
import android.util.Log
import java.io.File


@Suppress("PrivatePropertyName")
class DatabaseHelper(context: Context) : SQLiteOpenHelper(
    context, Environment.getExternalStorageDirectory().toString() + File.separator + "" + "Android" + File.separator + "data" + File.separator + context.packageName + "/RecoverMedia/Database/" + DB_NAME, null, DB_VERSION) {


    private val TAG = javaClass.simpleName

    companion object {
        const val DB_NAME = "SaveImage.DB"
        const val TABLE_NAME1 = "ImageTable"
        const val DB_VERSION = 1

        const val ID = "Id"
        const val r_name = "ConfigName"
        const val r_value = "ConfigValue"
    }

    private val mCreateTable1 = "create table $TABLE_NAME1($ID INTEGER PRIMARY KEY AUTOINCREMENT, $r_name TEXT, $r_value TEXT);"


    override fun onCreate(db: SQLiteDatabase?) {
        Log.d("DB_HELPER", "CREATE")
        db!!.execSQL(mCreateTable1)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        Log.d("DB_HELPER ", "UPOGRADE")
    }

    fun insertData(name: String?, saveValue: String?) {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(r_name, name)
        contentValues.put(r_value, saveValue)
        db.insert(TABLE_NAME1, null, contentValues)
    }


    fun checkAvailable(path: String?): Boolean {
        val db = this.readableDatabase
        val mCursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_NAME1 WHERE $r_name=? ", arrayOf(path))
        var cnt = 0
        if (mCursor != null) {
            cnt = mCursor.count
        }
        return cnt > 0
    }

    fun getValue(path: String?): String {
        val db = this.readableDatabase
        val mCursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_NAME1 WHERE $r_name='$path'", null)
        mCursor.moveToFirst()
        return if (mCursor.getString(2) != null)
            mCursor.getString(2)
        else
            ""
    }


    fun deleteDetail(path: String?) {
        val db = this.writableDatabase
        db.delete(TABLE_NAME1, "$r_name=?", arrayOf(path))
        Log.e(TAG, "deleteDetail: $path")
    }


    fun updateDetail(tableName: String, id: Int?, name: String?, saveValue: String?): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(r_name, name)
        contentValues.put(r_value, saveValue)
        db.update(tableName, contentValues, "$ID=? ", arrayOf(java.lang.String.valueOf(id)))
        return true
    }

//    fun updateClickDetail(tableName: String, id: Int?, name: String?, saveValue: String?, saveDate: String?, saveDelay: String,saveClickSecond: String, saveClickDuration: String /*, saveOrientation : Int*/): Boolean {
//        val db = this.writableDatabase
//        val contentValues = ContentValues()
//        contentValues.put(r_name, name)
//        contentValues.put(r_value, saveValue)
//        db.update(tableName, contentValues, "$ID=? ", arrayOf(java.lang.String.valueOf(id)))
//        return true
//    }
}

