package com.backup.restore.device.image.recovery.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.backup.restore.device.image.recovery.service.ManagerService;

public class MainBroadcastReceiver extends BroadcastReceiver {
        private static final String a = MainBroadcastReceiver.class.getSimpleName();
        private ManagerService b;

        public MainBroadcastReceiver() {
            Log.e("TAG", "onReceive bina ********************************************************* ");

        }

        public MainBroadcastReceiver(ManagerService managerService) {
            this.b = managerService;
            Log.e("TAG", "onReceive bina12 ********************************************************* ");

        }

        public void onReceive(Context context, Intent intent) {
            Log.e("TAG", "onReceive bina23 ********************************************************* ");

        }
    }
