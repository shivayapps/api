package com.backup.restore.device.image.recovery.newsecurity;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.backup.restore.device.image.recovery.maincontact.activity.HideContactActivity;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;

import java.util.List;

public abstract class BaseActivity_Lock extends AppCompatActivity {

    private static final String TAG = "BaseActivity";
    public static Activity currentFgActivity = null;

    public boolean isRunning(Context ctx) {
        ActivityManager activityManager = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = activityManager.getRunningTasks(Integer.MAX_VALUE);

        for (ActivityManager.RunningTaskInfo task : tasks) {
            if (ctx.getPackageName().equalsIgnoreCase(task.baseActivity.getPackageName()))
                return true;
        }

        return false;
    }
    @Override
    protected void onResume() {
        super.onResume();

        Log.e(TAG, "onResume: LOCK "+ SharedPrefsConstant.getString(BaseActivity_Lock.this, SharedPrefsConstant.LOCK) );
        Log.e(TAG, "onResume: IS_ON_LOCK "+SharedPrefsConstant.getBoolean(BaseActivity_Lock.this, SharedPrefsConstant.IS_ON_LOCK) );
        Log.e(TAG, "onResume: globalPause "+SharedPrefsConstant.globalPause );

        if (SharedPrefsConstant.globalPause && (SharedPrefsConstant.contain(BaseActivity_Lock.this, SharedPrefsConstant.LOCK)
               /* SharedPrefsConstant.getBoolean(BaseActivity_Lock.this, SharedPrefsConstant.IS_ON_LOCK)*/)) {

            Log.e(TAG, "onResume:==> LOCK "+SharedPrefsConstant.getString(BaseActivity_Lock.this, SharedPrefsConstant.LOCK) );
            Log.e(TAG, "onResume:==> IS_ON_LOCK "+SharedPrefsConstant.getBoolean(BaseActivity_Lock.this, SharedPrefsConstant.IS_ON_LOCK) );
            Log.e(TAG, "onResume:==> globalPause "+SharedPrefsConstant.globalPause );

            SharedPrefsConstant.globalPause = false;

            ActivityManager am = (ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
            ComponentName cn = am.getRunningTasks(1).get(0).topActivity;
            if (SharedPrefsConstant.getString(BaseActivity_Lock.this, SharedPrefsConstant.LOCK).equalsIgnoreCase("passcode")) {
                PinActivity.forWhat = "unLock";
                startActivity(new Intent(BaseActivity_Lock.this, PinActivity.class));
                if (HideContactActivity.context!=null) {
                    HideContactActivity.context.finish();
                }

            } else if (SharedPrefsConstant.getString(BaseActivity_Lock.this, SharedPrefsConstant.LOCK).equalsIgnoreCase("pattern")) {
                MyPatternActivity.forWhat = "unLock";
                startActivity(new Intent(BaseActivity_Lock.this, MyPatternActivity.class));
                if (HideContactActivity.context!=null) {
                    HideContactActivity.context.finish();
                }

            }

        } else {
            SharedPrefsConstant.globalPause = false;
            initialize();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (SharedPrefsConstant.isApplicationSentToBackground(getApplicationContext())) {
            SharedPrefsConstant.globalPause = true;
            lockEnable();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Runtime.getRuntime().gc();
        System.gc();
    }

    public abstract void initialize();

    public abstract void lockEnable();

}
