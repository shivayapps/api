package com.backup.restore.device.image.recovery.mainduplicate.model

class AppHistory {
    var appId: Long = 0
    var appName: String = ""
    var packageName: String = ""
    var size: String = ""
    var date: String = ""
}