package com.backup.restore.device.image.recovery.maincontact.callbacks

import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.maincontact.model.CountNameModel
import java.io.File

interface OnBackupItemClick {
    fun onItemClick(contact: CountNameModel?, backupFile: File?, position: Int)
    fun onContactItemClick(contact: ContactModel?, position: Int)
}