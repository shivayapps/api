package com.backup.restore.device.image.recovery.utilities

import android.content.Context
import android.content.Intent
import android.util.Log
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication


var sendIntent: Intent? = null
fun Context.prepareShareApp() {
    try {
        sendIntent = Intent()
        sendIntent?.action = Intent.ACTION_SEND
        sendIntent?.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))
        sendIntent?.putExtra(Intent.EXTRA_TEXT, getShareMessage())
        sendIntent?.type = "text/plain"
//        startActivity(sendIntent)

//        MyApplication.isInternalCall = true
    } catch (e: Exception) {
        e.printStackTrace()
        Log.i("shareApp", e.toString())
    }
}

fun Context.shareApp() {
    try {
//        val sendIntent = Intent()
//        sendIntent.action = Intent.ACTION_SEND
//        sendIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))
//        sendIntent.putExtra(Intent.EXTRA_TEXT, getShareMessage())
//        sendIntent.type = "text/plain"
        if (sendIntent != null) startActivity(sendIntent)
        else {

            sendIntent = Intent()
            sendIntent?.action = Intent.ACTION_SEND
            sendIntent?.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))
            sendIntent?.putExtra(Intent.EXTRA_TEXT, getShareMessage())
            sendIntent?.type = "text/plain"
            startActivity(sendIntent)
        }

        MyApplication.isInternalCall = true
    } catch (e: Exception) {
        e.printStackTrace()
        Log.i("shareApp", e.toString())
    }
}

fun Context.getShareMessage(): String {
    val appName = getString(R.string.app_name)
    val pkgName = packageName
    var message = getString(R.string.app_desc)
    message += "https://play.google.com/store/apps/details?id=$pkgName"
    return message
}