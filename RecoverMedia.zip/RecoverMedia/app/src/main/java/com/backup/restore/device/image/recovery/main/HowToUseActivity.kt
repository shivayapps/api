package com.backup.restore.device.image.recovery.main

import android.app.Activity
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.databinding.ActivityHowToUseBinding
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.mLastClickTime

class HowToUseActivity : Activity() {

    var lIsFromActivity = ""

    lateinit var binding:ActivityHowToUseBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        window.setFlags(1024, 1024)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_how_to_use)
        binding=ActivityHowToUseBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        isInterstitialShown = true
        lIsFromActivity = intent.getStringExtra("lIsFromActivity").toString()

        Log.e("TAG", "onCreate: $lIsFromActivity")
        binding.close.setOnClickListener {
            if (SystemClock.elapsedRealtime() - mLastClickTime < 1500) {
                return@setOnClickListener
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        changeLanguage()
    }
    override fun onBackPressed() {
//        MyApplication.isInterstitialShown = false
        if(lIsFromActivity == "SplashScreen") {
            startActivity(NewHomeActivity.newIntent(this))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }else{
            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            startActivity(NewHomeActivity.newIntent(this))
//            finish()
        }
    }
}