package com.backup.restore.device.image.recovery.maincontact.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.SystemClock
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amulyakhare.textdrawable.TextDrawable
import com.amulyakhare.textdrawable.util.ColorGenerator
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.maincontact.activity.ContactDetailsActivity
import com.backup.restore.device.image.recovery.maincontact.activity.FavoriteActivity
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.bumptech.glide.Glide
import com.example.jdrodi.utilities.camelCaseString
import java.util.*

class FavoriteAdapter(var mContext: Context, var mFavContactList: ArrayList<ContactModel>) : RecyclerView.Adapter<FavoriteAdapter.ContactView>() {

    private val mColorGenerator = ColorGenerator.MATERIAL
    private var mDrawableBuilder: TextDrawable.IBuilder? = null

    class ContactView(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivPhoto: ImageView = itemView.findViewById(R.id.ivPhoto)
        var ivContact: ImageView = itemView.findViewById(R.id.ivContact)
        var tvName: TextView = itemView.findViewById(R.id.tvName)
        var tvNumber: TextView = itemView.findViewById(R.id.tvNumber)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactView {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.raw_fav_contact_list_item, parent, false)
        return ContactView(view)
    }

    override fun onBindViewHolder(holder: ContactView, position: Int) {

        if (mFavContactList[position].mContactImageUri != null && mFavContactList[position].mContactImageUri != "null") {
            Glide.with(mContext).load(mFavContactList[position].mContactImageUri).placeholder(R.drawable.no_user_contact_image).into(holder.ivPhoto)
        } else {
            if (mFavContactList[position].mContactName!!.isNotEmpty()  && !TextUtils.isDigitsOnly(mFavContactList[position].mContactName!!.substring(0, 1))) {
                val mTypeface: Typeface = Typeface.createFromAsset(mContext.assets, "app_font/firasans_medium.ttf")
                mDrawableBuilder = TextDrawable.builder()
                    .beginConfig()
                    .bold()
                    .useFont(mTypeface)
                    .height(50)
                    .width(50)
                    .endConfig()
                    .round()
                val drawable = mDrawableBuilder!!.build(mFavContactList[position].mContactName!![0].toString().capitalize(), mColorGenerator.getColor( mFavContactList[position].mContactName))

                holder.ivPhoto.setImageDrawable(drawable)
            } else {
                holder.ivPhoto.setImageDrawable(mContext.resources.getDrawable(R.drawable.no_user_contact_image))
            }

//            holder.ivPhoto.setImageResource(R.drawable.no_user_contact_image)
        }

        holder.tvName.text = camelCaseString(mFavContactList[position].mContactName!!)
        holder.tvNumber.text = mFavContactList[position].mNumber
        holder.ivContact.setOnClickListener {
            MyApplication.isInternalCall = true
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:" + mFavContactList[position].mNumber)
            mContext.startActivity(intent)
        }

        holder.itemView.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            ShareConstants.user_id = mFavContactList[position].mContactId
//            ShareConstants.user_image = mFavContactList[position].mContactPhoto
            ShareConstants.user_name = mFavContactList[position].mContactName
            ShareConstants.user_number = mFavContactList[position].mNumber
            ShareConstants.contact_image_uri = mFavContactList[position].mContactImageUri
            ShareConstants.fav_position = position
            ShareConstants.fav_activity = true
            FavoriteActivity.isShowDialogFav = true
            val intent = Intent(mContext, ContactDetailsActivity::class.java).putExtra("IsFromContact","Fav")
            mContext.startActivity(intent)
        }
    }

    fun setList(list: ArrayList<ContactModel>) {
        mFavContactList = list
        notifyDataSetChanged()
    }
    override fun getItemCount(): Int {
        return mFavContactList.size
    }
}