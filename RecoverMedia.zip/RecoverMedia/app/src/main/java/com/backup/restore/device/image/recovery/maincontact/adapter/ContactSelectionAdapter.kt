@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.maincontact.adapter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amulyakhare.textdrawable.TextDrawable
import com.amulyakhare.textdrawable.TextDrawable.IBuilder
import com.amulyakhare.textdrawable.util.ColorGenerator
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnBackupItemClick
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import java.io.IOException
import java.util.*

class ContactSelectionAdapter(
    private val context: Context,
    private var mContactList: List<ContactModel>,
    private val mCheckAll: CheckBox,
    private val mOnClickListener: OnBackupItemClick
) : RecyclerView.Adapter<ContactSelectionAdapter.ContactView>() {

    //    private var mContactList = ArrayList<ContactModel>()
    private val mColorGenerator = ColorGenerator.MATERIAL
    private var mDrawableBuilder: IBuilder? = null
    private var isAllSelected: Boolean = false

    fun getList(): List<ContactModel> {
        return mContactList
    }

    fun getSelectedItems(): ArrayList<ContactModel> {
        var selectedList = ArrayList<ContactModel>()
        for (con in mContactList) {
            if (con.isSelected) selectedList.add(con)
        }
        return selectedList
    }

    fun setSelectedAll(isSelected: Boolean) {
        Log.e("ContactAdapter", "setSelectedAll: isSelected -$isSelected")
        isAllSelected = isSelected
        for (i in mContactList.indices) {
            mContactList[i].isSelected = isSelected
        }
        notifyDataSetChanged()
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
        //return super.getItemId(position)
    }

    override fun getItemViewType(position: Int): Int {
        return position
        //return super.getItemViewType(position)
    }

    class ContactView(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivContact: ImageView = itemView.findViewById(R.id.ivContact)
        var ivPhoto: CircleImageView = itemView.findViewById(R.id.ivPhoto)
        var cb_select: CheckBox = itemView.findViewById(R.id.cb_select)
        var tvName: TextView = itemView.findViewById(R.id.tvName)
        var tvNumber: TextView = itemView.findViewById(R.id.tvNumber)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactView {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.raw_contact_list, parent, false)
        return ContactView(view)
    }

    override fun onBindViewHolder(holder: ContactView, position: Int) {

        if (position != RecyclerView.NO_POSITION) {
            if (mContactList.size > 0) {

                holder.tvNumber.text = mContactList[position].mNumber

                if (mContactList[position].mNumber != null)
                    holder.tvNumber.text = mContactList[position].mNumber

                if (mContactList[position].mContactName == null || mContactList[position].mContactName == "") {
                    holder.tvName.text = mContactList[position].mNumber
                } else {
                    holder.tvName.text = mContactList[position].mContactName
                }

                if (mContactList[position].mContactImageUri != null) {
                    Glide.with(context).load(mContactList[position].mContactImageUri)
                        .placeholder(R.drawable.no_user_contact_image).into(holder.ivPhoto)
                } else {
                    if (mContactList[position].mContactName != null) {
                        if (mContactList[position].mContactName!!.isNotEmpty() && !TextUtils.isDigitsOnly(
                                mContactList[position].mContactName!!.substring(0, 1)
                            )
                        ) {

                            val mTypeface: Typeface = Typeface.createFromAsset(
                                context.assets,
                                "app_font/firasans_medium.ttf"
                            )

                            mDrawableBuilder = TextDrawable.builder()
                                .beginConfig()
                                .bold()
                                .useFont(mTypeface)
                                .height(50)
                                .width(50)
                                .endConfig()
                                .round()

                            val drawable = mDrawableBuilder!!.build(
                                mContactList[position].mContactName!![0].toString().capitalize(),
                                mColorGenerator.getColor(mContactList[position].mContactName)
                            )
                            holder.ivPhoto.setImageDrawable(drawable)
                        } else {
                            holder.ivPhoto.setImageDrawable(context.resources.getDrawable(R.drawable.no_user_contact_image))
                        }
                    }
                }
            }
            holder.ivContact.visibility = View.GONE
            holder.cb_select.visibility = View.VISIBLE

            if (isAllSelected) mContactList[position].isSelected = true
            if (mContactList[position].isSelected) {
                holder.cb_select.isChecked = true
            } else {
                holder.cb_select.isChecked = false
            }

            holder.itemView.setOnClickListener {
                mOnClickListener.onContactItemClick(mContactList[position], position)
                if (mContactList[position].isSelected) {
                    holder.cb_select.isChecked = false
                    mContactList[position].isSelected = false
                } else {
                    holder.cb_select.isChecked = true
                    mContactList[position].isSelected = true
                }

                if(mCheckAll.visibility==View.VISIBLE) {
                    val selectedSize = getSelectedItems().size
                    if (selectedSize == 0) {
                        mCheckAll.isChecked = false
                    } else {
                        mCheckAll.isChecked = selectedSize == mContactList.size
                    }
                }

            }
        }
    }

    private fun checkContain(
        contact: ContactModel,
        mContactList: ArrayList<ContactModel>
    ): Boolean {
        for (con in mContactList) {
            if (con.mContactName == contact.mContactName
                && con.mNumber == contact.mNumber
                && con.mEmail == contact.mEmail
            ) {
                return true
            }
        }
        return false
    }

    private fun getProfilePicture(uri: String): Bitmap? {
        var bitmap: Bitmap? = null
        Log.e("TAG", "getProfilePicture: uri -$uri")
        try {
            bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, Uri.parse(uri))
        } catch (e: IOException) {
            Log.e("TAG", "getProfilePicture: $e")
            e.printStackTrace()
        }
        return bitmap
    }

    private fun getContactNumber(id: String): String {
        var number = ""
        val pCur = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
            arrayOf(id),
            null
        )
        while (pCur!!.moveToNext()) {
            number =
                pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
            break
        }
        pCur.close()
        return number
    }


    fun setList(filteredNames: List<ContactModel>) {
        mContactList = filteredNames
        if (mContactList.isEmpty()) {

        } else {
            val selectedSize = getSelectedItems().size
            if (selectedSize == mContactList.size) {
//                mCheckAll.isChecked = true
            }
        }
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return mContactList.size
    }

//    private val exampleFilter: Filter = object : Filter() {
//        override fun performFiltering(constraint: CharSequence?): FilterResults {
//            mContactListFull = ContactFetcher(context).fetchAll()
//            mContactListFull.sortWith { lhs: ContactModel, rhs: ContactModel ->
//                if (lhs.mContactName != null && rhs.mContactName != null) {
//                    lhs.mContactName!!.compareTo(
//                        rhs.mContactName!!
//                    )
//                } else return@sortWith 0
//            }
//            val filteredList: MutableList<ContactModel> = ArrayList()
//
//            Log.e("ContactAdapter","constraint:${constraint}")
//            if (constraint == null || constraint.isEmpty()) {
////                filteredList.addAll(mContactListFull)
//                filteredList.clear()
//                filteredList.addAll(mContactListFull)
//                Log.e("ContactAdapter","mContactList-111:${mContactListFull.size}")
//                Log.e("ContactAdapter","mFilterList-111:${mContactList.size}")
//                Log.e("ContactAdapter","filteredList-111:${filteredList.size}")
//            } else {
//                Log.e("ContactAdapter","mContactList-000:${mContactListFull.size}")
//                Log.e("ContactAdapter","mFilterList-000:${mContactList.size}")
//                val filterPattern = constraint.toString().toLowerCase().trim()
//                for (item in mContactListFull) {
//                    if(item.mContactName!=null) {
//                        if (item.mContactName!!.toLowerCase().contains(filterPattern)) {
//                            filteredList.add(item)
//                        }
//                    }
//                }
//            }
//
//            val results = FilterResults()
//            results.values = filteredList
//
//            return results
//        }
//
//        override fun publishResults(constraint: CharSequence?, results: FilterResults) {
//            mContactList.clear()
//            mContactList.addAll(results.values as List<ContactModel>)
//            Log.e("ContactAdapter","mContactList-222:${mContactList.size}")
//            Log.e("ContactAdapter","mFilterList-222:${mContactList.size}")
////            if(filteredList.isEmpty()) mContactList.addAll(mFilterList)
////            else mContactList.addAll(filteredList)
//            notifyDataSetChanged()
//        }
//    }

//    override fun getFilter(): Filter {
//        return exampleFilter
//    }

}