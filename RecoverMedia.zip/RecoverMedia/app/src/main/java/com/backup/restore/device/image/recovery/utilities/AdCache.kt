package com.backup.restore.device.image.recovery.utilities

import com.google.android.gms.ads.AdView

object AdCache {
    var bannerDetail: AdView? = null
}
