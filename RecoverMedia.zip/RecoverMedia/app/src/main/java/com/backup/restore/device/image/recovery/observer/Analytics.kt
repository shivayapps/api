package com.backup.restore.device.image.recovery.observer

import java.util.*

//class Analytics {
//    private var startSessionTimestamp: Long = -1
//    private val reporters = mutableListOf<AnalyticsReporter>()
//
//    fun addReporter(reporter: AnalyticsReporter) {
//        reporters.add(reporter)
//    }
//
//    fun startSession() {
//        startSessionTimestamp = Date().time
//    }
//
//    fun stopSession() {
//        reportSession()
//        sendAllEvents()
//        startSessionTimestamp = -1
//    }
//
//    private fun reportSession() {
//        reporters.forEach {reporter ->
//        val currentTime = Date().time
//        // we should check if session was started and stopped correctly
//        val sessionTime = (currentTime - startSessionTimestamp) / 1000
//            reporter.report("Session time: $sessionTime sec" )
//        }
//    }
//
//    private fun sendAllEvents() {
//        reporters.forEach {reporter ->
//            reporter.sendAllEvents()
//        }
//    }
//}