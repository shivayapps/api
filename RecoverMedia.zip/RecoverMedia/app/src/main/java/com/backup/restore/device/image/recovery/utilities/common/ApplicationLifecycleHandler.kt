package com.backup.restore.device.image.recovery.utilities.common

import android.app.Activity
import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log

//class ApplicationLifecycleHandler : Application.ActivityLifecycleCallbacks, ComponentCallbacks2 {
//    var moActivity: Activity? = null
//    override fun onActivityCreated(activity: Activity, bundle: Bundle?) {
//        moActivity = activity
//    }
//
//    override fun onActivityStarted(activity: Activity) {}
//    override fun onActivityResumed(activity: Activity) {}
//    override fun onActivityPaused(activity: Activity) {}
//    override fun onActivityStopped(activity: Activity) {}
//    override fun onActivitySaveInstanceState(activity: Activity, bundle: Bundle) {}
//    override fun onActivityDestroyed(activity: Activity) {
//        Log.e(TAG, " onActivityDestroyed: ${activity.javaClass.simpleName}")
//    }
//
//    override fun onConfigurationChanged(configuration: Configuration) {}
//    override fun onLowMemory() {}
//    override fun onTrimMemory(i: Int) {}
//
//    companion object {
//        private val TAG = ApplicationLifecycleHandler::class.java.simpleName
//    }
//}