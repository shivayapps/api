package com.backup.restore.device.image.recovery.utilities


const val startTR = "<tr>"
const val endTR = "</tr>"

fun getTDData(title: String, result: String, colSpan: Int = 1): String {
    var data = "<td  colspan=\"{col_span}\">{title} : <span>{value}</span></td>"
    data = data.replace("{col_span}", colSpan.toString())
    data = data.replace("{title}", title.trimStart())
    data = data.replace("{value}", result.trimStart())
    return data
}

/*
      <table class="table-striped first">
                <tr id="challan_no">
                    <td>Challan No. : <span>challan_no_data</span></td>
                    <td>Challan Date : <span>challan_date_data</span></td>
                </tr>
                <tr id="challan_amount">
                    <td colspan="2">Challan Amount : <span>challan_amount_data</span></td>
                </tr>
                <tr id="challan_status">
                    <td colspan="2">Challan Status : <span>challan_status_data</span></td>
                </tr>
                <tr id="challan_payment">
                    <td colspan="2">Challan Payment Date : <span>challan_payment_date</span></td>
                </tr>
            </table>
* */

fun getTableHeader(title: String, isName:Boolean, isNumber:Boolean, isEmail:Boolean, isDob:Boolean): String {
    val spanCount=getSize(isName,isNumber,isEmail,isDob)
    var data = "     <table class=\"table-striped first\" style=\"margin-top: 0\">\n" +
            "            <tr>\n" +
            "                <th colspan=\"$spanCount\">{title}</th>\n" +
            "            </tr>\n" +
            "        </table>"
    data = data.replace("{title}", title.trimStart())
    return data
}

fun getSize(vararg arr:Boolean): Int {
    var count=0
    for(ar in arr) {
        if(ar) count++
    }
    return count+1
}

//fun Context.getContactTableData(contact: ContactModel, sr_no:Int, isName:Boolean, isNumber:Boolean, isEmail:Boolean, isDob:Boolean): String {
//    var data = "            <tr>\n"
//
//
//    data = "$data<td>data_sr_no</td>\n"
//    if(isName) data = "$data<td>data_name</td>\n"
//    if(isNumber) data = "$data<td>data_number</td>\n"
//    if(isEmail) data = "$data<td>data_email</td>\n"
//    if(isDob) data = "$data<td>data_dob</td>\n"
//
////    data = "$data</tr>\n"
//
//    val contactName = if(contact.mContactName!=null) contact.mContactName else ""
//    val contactNumber = if(contact.mNumber!=null) contact.mNumber else ""
//    val contactEmail = if(contact.mEmail!=null) contact.mEmail else ""
//    val contactBirthday =if(contact.mDOB!=null) contact.mDOB else ""
//
//    data = data.replace("data_sr_no", sr_no.toString())
//    data = data.replace("data_name", contactName!!)
//    data = data.replace("data_number", contactNumber!!)
//    data = data.replace("data_email", contactEmail!!)
//    data = data.replace("data_dob", contactBirthday!!)
//
//    return data
//}


fun getColSpan(data1: String? = null, data2: String? = null): Int {
    val colSpan = if (data1 == null && data2 != null) {
        2
    } else if (data1 != null && data2 == null) {
        2
    } else if (data1 != null && data2 != null) {
        1
    } else {
        0
    }
    return colSpan
}


fun getDIV(title: String, result: String): String {
    var div = "<div  style=\"text-decoration:none;background-color: #ffffff; padding-left: 15px;padding-right: 10px;padding-top: 8px;padding-bottom: 8px;margin-left: 12px;margin-right: 12px;margin-top: 10px;border-radius: 5px;text-align:left;\">\n" +
            "<a style=\"font-weight: bold;color: #1977d3;font-size: 18px;\">{title}</a>\n" +
            "<br>\n" +
            "<a style=\"color: #000000;font-size: 18px;margin-top:10px;\">{value}</a>\n" +
            "</div>"

    div = div.replace("{title}", title.trimStart())
    div = div.replace("{value}", result.trimStart())
    return div
}


//private fun Context.getHtmlFromAsset(): String? {
//    var htmlString: String? = null
//    try {
//
//        val `is` = assets.open("webview/backup_pdf.html")
//        val size = `is`.available()
//
//        val buffer = ByteArray(size)
//        `is`.read(buffer)
//        `is`.close()
//
//        htmlString = String(buffer)
//    } catch (e: IOException) {
//        e.printStackTrace()
//    }
//    return htmlString
//}


//fun Activity.generateChallanHTML(share_pdf: WebView, fileName: String, contacts: ArrayList<ContactModel>, isName:Boolean, isNumber:Boolean, isEmail:Boolean, isDob:Boolean) {
//    val progressDialog = ProgressDialog(this)
//    progressDialog.setMessage(getString(R.string.please_wait))
//    progressDialog.show()
////    val fileName = rcDLNumber + "_challan.pdf"
//    var html = getHtmlFromAsset().toString()
//    val headerBuilder = StringBuilder()
//    headerBuilder.append("<thead>\n")
//    headerBuilder.append("<th>No.</th>\n")
//    if(isName) headerBuilder.append("<th>Name</th>\n")
//    if(isNumber) headerBuilder.append("<th>Number</th>\n")
//    if(isEmail) headerBuilder.append("<th>Email</th>\n")
//    if(isDob) headerBuilder.append("<th>Birthday</th>\n")
//    headerBuilder.append("</thead>\n")
//    html = html.replace("{header_data}", headerBuilder.toString())
//    val dataBuilder = StringBuilder()
//
//    dataBuilder.append("<tbody>\n")
//    var i=0;
//    for (ct in contacts) {
//        i++
//        val challanTable = getContactTableData(ct,i,isName, isNumber, isEmail, isDob)
//        dataBuilder.append(challanTable)
//    }
//
//    dataBuilder.append("</tbody>\n")
//    html = html.replace("{table_data}", dataBuilder.toString())
////    html = html.replace("{data}", headerBuilder.toString())
//    loadPdf(share_pdf, fileName, html)
//
//}
//
//
//fun Activity.loadPdf(share_pdf: WebView, fileName: String, html: String) {
//
//    share_pdf.loadDataWithBaseURL(null, html, "text/html", "utf-8", "")
//    // share_pdf.loadUrl("file:///android_asset/pdf_html/rc.html")
//    share_pdf.visibility = View.VISIBLE
//    share_pdf.webViewClient = object : WebViewClient() {
//        override fun onPageFinished(view: WebView, url: String) {
//            shareWebPDF(share_pdf, fileName)
//        }
//    }
//}
//
//
//fun Activity.shareWebPDF(share_pdf: WebView, fileName: String, isWA: Boolean = false) {
//    val progressDialog = ProgressDialog(this)
//    progressDialog.setMessage(getString(R.string.please_wait))
//    progressDialog.show()
//
//    ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
//    val desDirectory = ShareConstants.mRootPath + "/RecoverMedia/Contact Backup/"
//    val desFile = File(desDirectory)
//    if (!desFile.exists()) {
//        desFile.mkdir()
//    }
//
//    var updateFileName = fileName
//    if (updateFileName.contains("-")) {
//        updateFileName = updateFileName.replace("-", "")
//    }
//
//    try {
//
//        val filePathCheck = File(desDirectory, updateFileName)
//        Log.i("updateFileName", "filePathCheck: $filePathCheck")
//        if (filePathCheck.exists()) {
//            Log.i("updateFileName", "filePathCheck_delete: " + filePathCheck.delete())
//        }
//
//        Log.i("updateFileName", "shareWebPDF_filename: $updateFileName")
//        Log.i("updateFileName", "shareWebPDF_dir: $desDirectory")
//
//        val filePath = File(desDirectory + desFile)
//        Log.i("updateFileName", "filePath: $filePath")
//        if (!filePath.exists()) {
//            filePath.mkdir()
//        }
//
//        PdfView.createWebPrintJob(this, share_pdf, File(desDirectory), updateFileName, object : PdfView.Callback {
//            override fun success(path: String) {
//                progressDialog.dismiss()
//                Log.i("updateFileName", "shareWebPDF: $path")
//                val newFile = File(path)
//                if (newFile.exists()) {
//                    shareMyPdf(File(path), isWA)
//                } else {
////                    toast(getString(R.string.error_pdf))
//                }
//            }
//
//            override fun failure() {
//                progressDialog.dismiss()
//            }
//        })
//    } catch (e: Exception) {
//        Log.i("updateFileName", "e: $e")
//        //toast(getString(R.string.error_pdf))
//        progressDialog.dismiss()
//    }
//
//
//}
//
//
//fun Context.shareMyPdf(newFile: File, isWA: Boolean) {
//
//    try {
//        val intent= Intent(this, ShareActivity::class.java)
//        intent.putExtra("file_path",newFile.path)
//        intent.putExtra("file_type",1)
//        startActivity(intent)
//    } catch (e: Exception) {
//    }
//}