package com.backup.restore.device.image.recovery.mainphotos.trashfragment

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Context.RECEIVER_NOT_EXPORTED
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.fragment.app.Fragment
import com.aainc.recyclebin.database.FilesProtectionContentProvider
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.databinding.FragmentTrashImageVideoBinding
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.TrashImageActivity
import com.backup.restore.device.image.recovery.mainphotos.activity.TrashImageActivity.Companion.resumeVideoCount
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel
import com.backup.restore.device.image.recovery.mainphotos.trashadapter.ImageVideoTrashAdapter
import com.backup.restore.device.image.recovery.utilities.SPAN_COUNT_THREE
import com.backup.restore.device.image.recovery.utilities.getGridCount
//import kotlinx.android.synthetic.main.activity_recover_image_new.*
//import kotlinx.android.synthetic.main.fragment_trash_image_video.*

class TrashVideoFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    lateinit var mView: View
    var mainCommonAdapter: ImageVideoTrashAdapter? = null
    var selectedList = ArrayList<TrashModel>()
    var isVisibleHint: Boolean = false
    var mCursor: Cursor? = null
    var isForSort = "date_asc"
    var mPrevCursor: Cursor? = null

    companion object {
        fun newInstance(): TrashVideoFragment {
            return TrashVideoFragment()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireContext().registerReceiver(
            refreshMediaBroadcast,
            IntentFilter("com.progress.video.Refresh"), RECEIVER_NOT_EXPORTED
        )
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isAdded) {
            isVisibleHint = isVisibleToUser
            Log.e(mTAG, "setUserVisibleHint: same $isVisibleToUser")
            if (isVisibleHint) {
                if (mCursor != null && mCursor!!.count != 0) {
                    if (requireActivity() is TrashImageActivity) {
                        if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 1) {
//                            requireActivity().checkAll.isChecked = mCursor!!.count == selectedList.size
                            (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                                true
                            )
                        }
                        when (isForSort) {
                            "size_asc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeAsc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "size_desc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "date_desc" -> {
                                (requireActivity() as TrashImageActivity).selectDateDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                            "date_asc" -> {
                                (requireActivity() as TrashImageActivity).selectTop(2)
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                        }
                        if ((requireActivity() as TrashImageActivity).binding.ivSpan != null) {
                            (requireActivity() as TrashImageActivity).binding.ivSpan.alpha = 1.0F
                            (requireActivity() as TrashImageActivity).binding.ivSpan.isEnabled = true
                        }
                        if ((requireActivity() as TrashImageActivity).binding.btnRecover != null) {
                            (requireActivity() as TrashImageActivity).binding.btnRecover.alpha = 1.0F
                            (requireActivity() as TrashImageActivity).binding.btnRecover.isEnabled = true
                        }
                    }
                } else {
                    if (requireActivity() is TrashImageActivity) {

                        if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 1) {
                            (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                                false
                            )
                        }
                        (requireActivity() as TrashImageActivity).unSelectAll()
                        if ((requireActivity() as TrashImageActivity).binding.ivSpan != null) {
                            (requireActivity() as TrashImageActivity).binding.ivSpan.alpha = 0.5F
                            (requireActivity() as TrashImageActivity).binding.ivSpan.isEnabled = false
                        }
                        if ((requireActivity() as TrashImageActivity).binding.btnRecover != null) {
                            (requireActivity() as TrashImageActivity).binding.btnRecover.alpha = 0.5F
                            (requireActivity() as TrashImageActivity).binding.btnRecover.isEnabled = true
                        }
                    }
                }

                (requireActivity() as TrashImageActivity).binding.ivSpan!!.isSelected = requireContext().getGridCount() == SPAN_COUNT_THREE
                binding.deletedFilesGrid.numColumns = requireContext().getGridCount()
            }
        }
    }

//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        mView = inflater.inflate(R.layout.fragment_trash_image_video, container, false)
//        return mView
//    }

    lateinit var binding: FragmentTrashImageVideoBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
//        mView = inflater.inflate(R.layout.fragment_trash_audio_doc, container, false)
        binding= FragmentTrashImageVideoBinding.inflate(inflater,container,false)
        return binding.root
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_video)
        binding.tvNotFound.setText(R.string.video_not_found)
    }

    override fun onClick(view: View) {

    }

    override fun onResume() {
        super.onResume()
        resumeVideoCount += 1
        Log.e(mTAG, "onResume: $isVisibleHint")
        val whereClause = "type_file=?"
        val whereArgs = arrayOf("Video")
        var sortOrder = ""
        Log.e(mTAG, "ListImage  --> onCreate: Video")

        mPrevCursor = mCursor
        when (isForSort) {
            "size_asc" -> {
                sortOrder = "cast(file_size as INTEGER) ASC"
            }
            "size_desc" -> {
                sortOrder = "cast(file_size as INTEGER) DESC"
            }
            "date_desc" -> {
                sortOrder = "deleted_at ASC"
            }
            "date_asc" -> {
                sortOrder = "deleted_at DESC"
            }

        }
        mCursor = requireActivity().contentResolver.query(
            FilesProtectionContentProvider.a,
            null as Array<String?>?,
            whereClause,
            whereArgs,
            sortOrder
        )!!
//        mCursor = requireActivity().contentResolver.query(FilesProtectionContentProvider.a, null as Array<String?>?, whereClause, whereArgs, null)!!

        Log.e(mTAG, "ListImage  --> onCreate: ${mCursor!!.count}")
        if (mCursor!!.count == 0) {
            binding.tvTrashAlbum.visibility = View.VISIBLE
            binding.lottieTrashImage.visibility = View.GONE
            binding.deletedFilesGrid.visibility = View.GONE
        } else {
            binding.tvTrashAlbum.visibility = View.GONE
            binding.deletedFilesGrid.visibility = View.VISIBLE
        }

        val checkAll: CheckBox? =if((requireActivity() is NewRecoverImageActivity)) {
            (requireActivity() as NewRecoverImageActivity).binding.checkAll
        } else if((requireActivity() is TrashImageActivity)) {
            (requireActivity() as TrashImageActivity).binding.checkAll
        } else null
        mainCommonAdapter = ImageVideoTrashAdapter(
            requireActivity(),
            this,
            mCursor,
            2,
            "Video",
            checkAll,
            isForSort
        )
        binding.deletedFilesGrid.adapter = mainCommonAdapter
        binding.deletedFilesGrid.numColumns = requireContext().getGridCount()
        if (isVisibleHint && TrashImageActivity.mIsFromForImageCheck == "Trash") {
            if (mCursor != null && mCursor!!.count != 0) {
                if (requireActivity() is TrashImageActivity) {
                    if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 1) {
                        (requireActivity() as TrashImageActivity).binding.checkAll.isChecked = mCursor!!.count == selectedList.size
                        (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                            true
                        )
                    }
//                    requireActivity().iv_span.alpha = 1.0F
//                    requireActivity().iv_span.isEnabled = true
                    if (mPrevCursor != null && mPrevCursor!!.count == 0) {
                        (requireActivity() as TrashImageActivity).selectTop(2)

                        when (isForSort) {
                            "size_asc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeAsc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "size_desc" -> {
                                (requireActivity() as TrashImageActivity).selectSizeDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = true
                                (requireActivity() as TrashImageActivity).isSizeClick = false
                            }
                            "date_desc" -> {
                                (requireActivity() as TrashImageActivity).selectDateDesc()
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                            "date_asc" -> {
                                (requireActivity() as TrashImageActivity).selectTop(2)
                                (requireActivity() as TrashImageActivity).isDateClick = false
                                (requireActivity() as TrashImageActivity).isSizeClick = true
                            }
                        }

                    }
                }
            } else {
                if (requireActivity() is TrashImageActivity) {

                    if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 1) {
                        (requireActivity() as TrashImageActivity).toggleRecoverButtonVisibility(
                            false
                        )
                    }
                    (requireActivity() as TrashImageActivity).unSelectAll()
                }
            }

            if (mCursor != null && selectedList.size == mCursor!!.count) {
                mainCommonAdapter!!.selectAll()
            }
        }
        object : AsyncTask<Void, Long, Void>() {
            override fun doInBackground(vararg voids: Void): Void? {
                Log.e(mTAG, "doInBackground: stopLoading")
                stopLoading()
                return null
            }

            override fun onPostExecute(result: Void?) {
                super.onPostExecute(result)
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    fun stopLoading() {
        activity?.runOnUiThread {
            Handler(Looper.getMainLooper()).postDelayed({
                resumeVideoCount -= 1
                Log.e(mTAG, "stopLoading: $resumeVideoCount")
//                if (resumeVideoCount <= 0) {
                    if (isAdded) {
                        if (isVisibleHint) {
                            if (mCursor != null && mCursor!!.count != 0) {
                                if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 1) {
                                    (requireActivity() as TrashImageActivity).selectTop(2)

                                    when (isForSort) {
                                        "size_asc" -> {
                                            (requireActivity() as TrashImageActivity).selectSizeAsc()
                                            (requireActivity() as TrashImageActivity).isDateClick = true
                                            (requireActivity() as TrashImageActivity).isSizeClick = false
                                        }
                                        "size_desc" -> {
                                            (requireActivity() as TrashImageActivity).selectSizeDesc()
                                            (requireActivity() as TrashImageActivity).isDateClick = true
                                            (requireActivity() as TrashImageActivity).isSizeClick = false
                                        }
                                        "date_desc" -> {
                                            (requireActivity() as TrashImageActivity).selectDateDesc()
                                            (requireActivity() as TrashImageActivity).isDateClick = false
                                            (requireActivity() as TrashImageActivity).isSizeClick = true
                                        }
                                        "date_asc" -> {
                                            (requireActivity() as TrashImageActivity).selectTop(2)
                                            (requireActivity() as TrashImageActivity).isDateClick = false
                                            (requireActivity() as TrashImageActivity).isSizeClick = true
                                        }
                                    }

                                    if ((requireActivity() as TrashImageActivity).binding.ivSpan != null) {
                                        (requireActivity() as TrashImageActivity).binding.ivSpan.alpha = 1F
                                        (requireActivity() as TrashImageActivity).binding.ivSpan.isEnabled = true
                                    }
                                    if ((requireActivity() as TrashImageActivity).binding.btnRecover != null) {
                                        (requireActivity() as TrashImageActivity).binding.btnRecover.alpha = 1F
                                        (requireActivity() as TrashImageActivity).binding.btnRecover.isEnabled = true
                                    }
                                    if ((requireActivity() as TrashImageActivity).binding.llSelectAll != null) {
                                        (requireActivity() as TrashImageActivity).binding.llSelectAll.alpha = 1F
                                        (requireActivity() as TrashImageActivity).binding.llSelectAll.isEnabled = true
                                    }
                                }
                                binding.lottieTrashImage.visibility = View.GONE
                                Log.e(mTAG, "stopLoading: ")
                            } else {
                                if (TrashImageActivity.lastSelection == 2 && TrashImageActivity.prevPosTrash == 1) {
                                    (requireActivity() as TrashImageActivity).unSelectAll()
                                }
                            }
                        }
                    }
//                }
            }, 200)
        }
    }

    var refreshMediaBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent!!.action == "com.progress.video.Refresh") {
                Handler(Looper.getMainLooper()).post {
                    onResume()
                }
                if(isVisibleHint) {
                (requireActivity() as TrashImageActivity).unSelectAll()
               (requireActivity() as TrashImageActivity).binding.ivSpan.alpha = 0.5F
               (requireActivity() as TrashImageActivity).binding.ivSpan.isEnabled = false
               (requireActivity() as TrashImageActivity).binding.btnRecover.alpha = 0.5F
               (requireActivity() as TrashImageActivity).binding.btnRecover.isEnabled = false
               (requireActivity() as TrashImageActivity).binding.llSelectAll.alpha = 0.5F
               (requireActivity() as TrashImageActivity).binding.llSelectAll.isEnabled = false
                binding.lottieTrashImage.visibility = View.VISIBLE
                }
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        requireContext().unregisterReceiver(refreshMediaBroadcast)
    }
}