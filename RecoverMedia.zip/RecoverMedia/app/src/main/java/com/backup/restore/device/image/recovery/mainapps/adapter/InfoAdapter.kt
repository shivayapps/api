package com.backup.restore.device.image.recovery.mainapps.adapter

import android.content.Context
import android.graphics.Color
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.example.jdrodi.utilities.camelCaseString

class InfoAdapter(internal var context: Context, private var appslist : List<FeaturesHW>,private val ignoreCount:Int=0) : RecyclerView.Adapter<InfoAdapter.DeviceVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InfoAdapter.DeviceVH {
        val itemView = LayoutInflater.from(context).inflate(R.layout.row_cpu_info, parent, false)
        return DeviceVH(itemView)
    }

    override fun onBindViewHolder(holder: InfoAdapter.DeviceVH, position: Int) {
        holder.bindData(appslist[position], position)
    }

    override fun getItemCount(): Int = appslist.size

    inner class DeviceVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindData(featureHW: FeaturesHW, position: Int) {
            val tvFeatureName: TextView = itemView.findViewById(R.id.tv_feature_name)
            val tvFeatureValue: TextView = itemView.findViewById(R.id.tv_feature_value)
            val tvFeaturePercentage: TextView = itemView.findViewById(R.id.tv_feature_percentage)
            val flPercentage: FrameLayout = itemView.findViewById(R.id.fl_percentage)
            val sepLeft: View = itemView.findViewById(R.id.sepLeft)
            val sepRight: View = itemView.findViewById(R.id.sepRight)

            Log.e("InfoAdapter", "featureLable::${featureHW.featureLable}::")
            Log.e("InfoAdapter", "featureValue::${featureHW.featureValue}::")
            Log.e("InfoAdapter", "--------------------------")
            tvFeatureName.text = "${camelCaseString(featureHW.featureLable)}"
            tvFeatureValue.text = featureHW.featureValue.trim(',')

            tvFeatureValue.movementMethod = ScrollingMovementMethod()

//            tvFeatureName.isSelected = true
//            tvFeatureValue.isSelected = true

            if(featureHW.percentage>=0) {
                tvFeatureValue.visibility=View.GONE
                flPercentage.visibility=View.VISIBLE
                tvFeaturePercentage.text = "${featureHW.featureValue.trim(',')}"
                tvFeaturePercentage.setShadowLayer(1.5f, -1F, 1F, Color.BLACK);
                tvFeaturePercentage.background?.setLevel((featureHW.percentage*100).toInt())
            } else {
                tvFeatureValue.visibility=View.VISIBLE
                flPercentage.visibility=View.GONE
            }
            val newPos = position + ignoreCount;

//            if(newPos % 2 == 0) {
//                sepLeft.visibility=View.VISIBLE
//                sepRight.visibility=View.GONE
//            } else {
//                sepLeft.visibility=View.GONE
//                sepRight.visibility=View.VISIBLE
//            }

        }
    }
}