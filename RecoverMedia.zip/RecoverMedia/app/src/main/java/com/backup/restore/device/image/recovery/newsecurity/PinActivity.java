package com.backup.restore.device.image.recovery.newsecurity;


import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.ads.openad.MyApplication;
import com.backup.restore.device.image.recovery.databinding.ActivityPinBinding;
import com.backup.restore.device.image.recovery.maincontact.activity.HideContactActivity;
import com.backup.restore.device.image.recovery.multilang.LocaleManager;
import com.backup.restore.device.image.recovery.multilang.Locales;
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant;
import com.example.jdrodi.utilities.OnSingleClickListener;

import java.util.ArrayList;


public class PinActivity extends AppCompatActivity {
    private boolean serviceNotDestroy = false;
    private static final String TAG = "PinActivity";
    private static final int REQ_CODE_NEW_PIN_LOCK = 495;
    ImageView ivBackPin;
    public static String forWhat = "newPasscode";
    private static String whichLock = "";
    public static Context context;
    private String firstTryCode;
    // Widgets
    private ConstraintLayout mDeleteButton;
    private TextView title_text_view, mLeftButton;
    private PINCodeView mPINCodeView;
    // Breaks and Alert

    Dialog SecurityDialog;
    String mPreviousSelectedLanguageKey = Locales.INSTANCE.getEnglish().toString();

    ActivityPinBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        LocaleManager.setLocale(PinActivity.this);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_pin);
        binding=ActivityPinBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        context = this;
        mPreviousSelectedLanguageKey = LocaleManager.getLanguagePref(PinActivity.this);

        findIds();
        Log.e(TAG, "onCreate: forWhat==>" + forWhat);
        if (forWhat.equalsIgnoreCase("newPasscode")) {
            title_text_view.setText(R.string.enter_new_passcode);
        } else if (forWhat.equalsIgnoreCase("unLock")) {

            mLeftButton.setVisibility(View.VISIBLE);
            //  viewForgot.setVisibility(View.VISIBLE);
            SharedPrefsConstant.alreadyIN = true;
            title_text_view.setText(R.string.enter_passcode_to_unlock);
        } else if (forWhat.equalsIgnoreCase("remove")) {
            title_text_view.setText(R.string.enter_passcode_remove_lock);
        } else if (forWhat.equalsIgnoreCase("change")) {
            title_text_view.setText(R.string.enter_current_passcode);
        }

        initKeyViews();
        // Delete Button
        mDeleteButton.setOnClickListener(mOnDeleteButtonClickListener);

        mPINCodeView.setListener(mCodeListener);
    }

    private void findIds() {
        mDeleteButton = findViewById(R.id.iv_delete);
        title_text_view = findViewById(R.id.title_text_view);
        mLeftButton = findViewById(R.id.button_left);
        ivBackPin = findViewById(R.id.ivBackPin);
        ivBackPin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });

    }


    private void initKeyViews() {

        findViewById(R.id.button_0).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_1).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_2).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_3).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_4).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_5).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_6).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_7).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_8).setOnClickListener(mOnKeyClickListener);
        findViewById(R.id.button_9).setOnClickListener(mOnKeyClickListener);
        mPINCodeView = findViewById(R.id.code_view);

        mLeftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PinActivity.this.openSecurityDialog();
            }
        });

    }

    private void openSecurityDialog() {

        View view = getLayoutInflater().inflate(R.layout.dialog_set_security_question, null);
        SecurityDialog = new Dialog(this);
        SecurityDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        SecurityDialog.setCanceledOnTouchOutside(false);
        SecurityDialog.setContentView(view);
        SecurityDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        SecurityDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        EditText et_enteranswer = SecurityDialog.findViewById(R.id.et_enteranswer);
        ArrayList<String> list = new ArrayList<>();
        list.add(getString(R.string.select_your_question));
        list.add(getString(R.string.which_is_your_favorite_movie));
        list.add(getString(R.string.what_is_your_favorite_food));
        list.add(getString(R.string.who_is_your_favorite_actress));
        list.add(getString(R.string.whats_your_lucky_number));
        list.add(getString(R.string.in_which_city_were_you_born));
        String[] que = {""};

        et_enteranswer.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        ((ImageView) SecurityDialog.findViewById(R.id.ivCloseDialog)).setOnClickListener(v -> {
            SecurityDialog.dismiss();
            MyApplication.Companion.setDialogOpen(false);
        });
        ((ImageView) SecurityDialog.findViewById(R.id.ivDrop)).setOnClickListener(v -> {
            SecurityDialog.findViewById(R.id.spinner_d).performClick();
        });

        ((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).setOnTouchListener((v, event) -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).getWindowToken(), 0);
            return false;
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<>(PinActivity.this, R.layout.spinner_layout, list);
        ((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).setAdapter(adapter);

        ((Spinner) SecurityDialog.findViewById(R.id.spinner_d)).setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                et_enteranswer.getText().clear();
                que[0] = String.valueOf(parent.getItemAtPosition(position));
                if (position == 0) {
                    et_enteranswer.setEnabled(false);
                    que[0] = "none";
                } else {
                    et_enteranswer.setEnabled(true);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ((CardView) SecurityDialog.findViewById(R.id.ln_submit)).setOnClickListener(v -> {
            if (que[0] == "none") {
                Toast.makeText(getApplicationContext(), getString(R.string.select_question), Toast.LENGTH_SHORT).show();
            } else {
                if (et_enteranswer.getText().toString().trim().equals(""))
                    Toast.makeText(getApplicationContext(),  getString(R.string.enter_answer), Toast.LENGTH_SHORT).show();
                else if (et_enteranswer.getText().toString().length() < 5)
                    Toast.makeText(getApplicationContext(), getString(R.string.at_least_5_character), Toast.LENGTH_SHORT).show();
                else {
                    if (que[0].equalsIgnoreCase(SharedPrefsConstant.getString(context, SharedPrefsConstant.BACKUP_QUESTION))
                            && SharedPrefsConstant.getString(context, SharedPrefsConstant.BACKUP_ANSWER).equalsIgnoreCase(et_enteranswer.getText().toString().trim())) {

                        SharedPrefsConstant.isfromFake = true;
                        PinActivity.forWhat = "newPasscode";
                        PinActivity.this.startActivityForResult(new Intent(context, PinActivity.class), REQ_CODE_NEW_PIN_LOCK);
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                    } else {
                        Toast.makeText(this,  getString(R.string.sorry_wrong), Toast.LENGTH_SHORT).show();
                    }
                    SecurityDialog.cancel();
                    MyApplication.Companion.setDialogOpen(false);
                }
            }
        });

        SecurityDialog.show();
        MyApplication.Companion.setDialogOpen(true);
    }

    private PINCodeView.OnPFCodeListener mCodeListener = new PINCodeView.OnPFCodeListener() {
        @Override
        public void onCodeCompleted(final String code) {
            Log.e(TAG, "onCodeCompleted: " + forWhat);
            if (forWhat.equalsIgnoreCase("newPasscode")) {

                if (SharedPrefsConstant.getString(context, SharedPrefsConstant.CURRENT_FAKE_PIN_LOCK).equalsIgnoreCase(code) &&
                        SharedPrefsConstant.getBoolean(context, SharedPrefsConstant.IS_ON_FAKE_LOCK) && !whichLock.equals("fake_lock")) {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), getString(R.string.different_from_fake_lock), Toast.LENGTH_SHORT).show();
                            for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                                mPINCodeView.delete();
                            }
                            forWhat = "newPasscode";
                        }
                    }, 100);
                    return;
                } else if (SharedPrefsConstant.getString(context, SharedPrefsConstant.PASSCODE).equalsIgnoreCase(code) && whichLock.equals("fake_lock")) {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), getString(R.string.fake_lock_different), Toast.LENGTH_SHORT).show();
                            for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                                mPINCodeView.delete();
                            }
                            forWhat = "newPasscode";

                        }
                    }, 100);
                    return;
                } else if (SharedPrefsConstant.getString(context, SharedPrefsConstant.CURRENT_FAKE_PIN_LOCK).
                        equalsIgnoreCase(code)) {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                                mPINCodeView.delete();
                            }
                            Toast.makeText(getApplicationContext(), getString(R.string.different_from_fake_lock), Toast.LENGTH_SHORT).show();
                        }
                    }, 100);
                    return;
                }
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                            mPINCodeView.delete();
                        }
                        title_text_view.setText(R.string.reenter_passcode_to_confirm);
                        forWhat = "re_enter_passcode";
                        firstTryCode = code;
                    }
                }, 100);


            } else if (forWhat.equalsIgnoreCase("re_enter_passcode")) {

                Log.e(TAG, "onCodeCompleted: " + whichLock);
                if (firstTryCode.equalsIgnoreCase(code)) {
                    if (whichLock.equals("fake_lock")) {
                        SharedPrefsConstant.save(context, SharedPrefsConstant.CURRENT_FAKE_PIN_LOCK, code);
                        setResult(RESULT_OK);
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                        return;
                    } else if (whichLock.equalsIgnoreCase("") && SharedPrefsConstant.isfromFake) {
                        SharedPrefsConstant.isfromFake = false;
                        Toast.makeText(getApplicationContext(), getString(R.string.passcode_create_successfully), Toast.LENGTH_SHORT).show();
                        SharedPrefsConstant.save(context, SharedPrefsConstant.PASSCODE, code);
                        SharedPrefsConstant.save(context, SharedPrefsConstant.LOCK, "passcode");
                        SharedPrefsConstant.alreadyIN = false;
                        Intent intent = new Intent(context, HideContactActivity.class);
                        startActivity(intent);
                        setResult(RESULT_OK, intent);
                        finish();
                        return;

                    }

                    Toast.makeText(getApplicationContext(), getString(R.string.passcode_create_successfully), Toast.LENGTH_SHORT).show();
                    SharedPrefsConstant.save(context, SharedPrefsConstant.PASSCODE, code);
                    SharedPrefsConstant.save(context, SharedPrefsConstant.LOCK, "passcode");
                    SharedPrefsConstant.alreadyIN = false;
                    Intent intent = new Intent(context, HideContactActivity.class);
                    startActivity(intent);
                    setResult(RESULT_OK, intent);
                    finish();


                } else {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                                mPINCodeView.delete();
                            }
                            setErrorAnimation();
                        }
                    }, 100);
                }
            } else if (forWhat.equalsIgnoreCase("unLock")) {

                if (SharedPrefsConstant.getString(context, SharedPrefsConstant.PASSCODE).equalsIgnoreCase(code)) {


                    SharedPrefsConstant.alreadyIN = false;
                    Intent intent = new Intent(context, HideContactActivity.class);
                    startActivity(intent);
                    finish();
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

                } else {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                                mPINCodeView.delete();
                            }
                            if (SharedPrefsConstant.getBoolean(context, SharedPrefsConstant.BREAKS_ALERT_ENABLE) && SharedPrefsConstant.getBoolean(context, SharedPrefsConstant.IS_SUBSCRIPTION)) {
                                new AsyncTask<Void, Void, Void>() {
                                    @Override
                                    protected Void doInBackground(Void... voids) {
                                        if (permissionGrantedCamera()) {
                                        }
                                        return null;
                                    }
                                }.execute();
                            }
                            setErrorAnimation();
                        }
                    }, 100);
                }
            } else if (forWhat.equalsIgnoreCase("remove")) {
                if (SharedPrefsConstant.getString(context, SharedPrefsConstant.PASSCODE).equalsIgnoreCase(code)) {
                    Toast.makeText(getApplicationContext(), R.string.passcode_remove_successfully, Toast.LENGTH_SHORT).show();
                    SharedPrefsConstant.removeKey(context, SharedPrefsConstant.PASSCODE);
                    SharedPrefsConstant.removeKey(context, SharedPrefsConstant.LOCK);
                    SharedPrefsConstant.alreadyIN = false;
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                } else {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                                mPINCodeView.delete();
                            }
                            setErrorAnimation();
                        }
                    }, 100);

                }
            } else if (forWhat.equalsIgnoreCase("change")) {
                if (SharedPrefsConstant.getString(context, SharedPrefsConstant.PASSCODE).equalsIgnoreCase(code)) {

                    PinActivity.forWhat = "newPasscode";
                    finish();
                    startActivity(new Intent(context, PinActivity.class));
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                    SharedPrefsConstant.alreadyIN = false;


                } else {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            for (int i = mPINCodeView.getInputCodeLength(); i > 0; i--) {
                                mPINCodeView.delete();
                            }
                            setErrorAnimation();
                        }
                    }, 100);
                }


            }
        }

        @Override
        public void onCodeNotCompleted(String code) {
        }
    };

    private void setErrorAnimation() {
        Toast.makeText(getApplicationContext(), getString(R.string.passcode_doesnt_match), Toast.LENGTH_SHORT).show();
//        final Animation animShake = AnimationUtils.loadAnimation(PinActivity.this, R.anim.shake_anim);
//        mPINCodeView.startAnimation(animShake);
    }

    private boolean permissionGrantedCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return false;
        } else {
            return true;
        }
    }

    private View.OnClickListener mOnKeyClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v instanceof TextView) {
                Vibrator vb = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                if (vb != null) {
                    vb.vibrate(100);
                }

                String string = v.getTag().toString();
                if (string.length() != 1) {
                    return;
                }
                mPINCodeView.input(string);
            }
        }
    };
    private View.OnClickListener mOnDeleteButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Vibrator v1 = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (v1 != null) {
                v1.vibrate(50);
            }
            mPINCodeView.delete();
        }
    };

    // TODO: Harshil 2019-04-25 12:10 check for fake or real
    public static void setForWhat(String whichLock) {
        PinActivity.whichLock = whichLock;
    }

    @Override
    protected void onResume() {
        super.onResume();
//        changeLanguage(this);
        restartIfRequires();
        //  Log.e(TAG, "onResume:§ " + context);

    }

    private void restartIfRequires() {
        if (mPreviousSelectedLanguageKey != LocaleManager.getLanguagePref(PinActivity.this)) {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, true);
            Log.e("TAG", "restartIfRequires: ");
            recreate();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else {
            SharedPrefsConstant.savePref(this, SharedPrefsConstant.IS_REFRESH_HOME, false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPrefsConstant.test = true;

    }


//    private void openSecurityDialog() {
//        final Dialog dialog = new Dialog(PinActivity.this);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.dialog_set_security_question);
//        Objects.requireNonNull(dialog.getWindow()).setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.95), ViewGroup.LayoutParams.WRAP_CONTENT);
//        //hide keyboard :
//        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//        dialog.setCancelable(true);
//        dialog.setCanceledOnTouchOutside(false);
//
//        final EditText et_enteranswer = dialog.findViewById(R.id.et_enteranswer);
//        //  final LinearLayout im_remove = dialog.findViewById(R.id.im_remove);
//        final CardView ln_submit = dialog.findViewById(R.id.ln_submit);
////        final CardView ln_cancle = dialog.findViewById(R.id.ln_cancle);
//        final TextView txt_submit = dialog.findViewById(R.id.txt_submit);
////        final LinearLayout btnCancle1 = dialog.findViewById(R.id.btnCancle1);
//        final TextView tv_msg = dialog.findViewById(R.id.tv_msg);
////        final TextView tv_question = dialog.findViewById(R.id.tv_question);
////        final LinearLayout bothButton = dialog.findViewById(R.id.bothButton);
////        final LinearLayout btnVerify = dialog.findViewById(R.id.btnVerify);
//        final Spinner spinner = dialog.findViewById(R.id.spinner_d);
////        final TextView txtSecurity = dialog.findViewById(R.id.txtSecurity);
//        final ImageView ivCloseDialog = dialog.findViewById(R.id.ivCloseDialog);
//
//
////        txtSecurity.setVisibility(View.VISIBLE);
////        ln_submit.setVisibility(View.GONE);
////        bothButton.setVisibility(View.VISIBLE);
////        ln_cancle.setVisibility(View.GONE);
////        tv_question.setVisibility(View.VISIBLE);
////        spinner.setVisibility(View.GONE);
//        et_enteranswer.setEnabled(true);
//        txt_submit.setText("VERIFY");
//        tv_msg.setVisibility(View.VISIBLE);
//
//        tv_msg.setText("Verify Question");
//
////        tv_question.setText(SharedPrefsConstant.getString(context, SharedPrefsConstant.BACKUP_QUESTION));
//
//        ivCloseDialog.setOnClickListener(new OnSingleClickListener() {
//            @Override
//            public void onSingleClick(View v) {
//                dialog.dismiss();
//                try {
//                    dialog.dismiss();
//                } catch (Exception e) {
//
//                }
//            }
//        });
////        btnCancle1.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                dialog.dismiss();
////            }
////        });
//        et_enteranswer.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                if (et_enteranswer.getText().toString().length() == 0) {
//                    txt_submit.setTextColor(getResources().getColor(R.color.white));
//                } else {
//                    txt_submit.setTextColor(getResources().getColor(R.color.white));
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//            }
//        });
////        btnVerify.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                if (et_enteranswer.getText().toString().trim().equals(""))
////                    Toast.makeText(PinActivity.this.getApplicationContext(), "Please Enter Answer", Toast.LENGTH_SHORT).show();
////                else if (et_enteranswer.getText().toString().length() < 5)
////                    Toast.makeText(PinActivity.this.getApplicationContext(), "Please Enter At Least 5 Character In Answer", Toast.LENGTH_SHORT).show();
////                else {
////                    if (tv_question.getText().toString().equalsIgnoreCase(SharedPrefsConstant.getString(context, SharedPrefsConstant.BACKUP_QUESTION)) && SharedPrefsConstant.getString(context, SharedPrefsConstant.BACKUP_ANSWER).equalsIgnoreCase(et_enteranswer.getText().toString().trim())) {
////                        SharedPrefsConstant.isfromFake = true;
////                        SharedPrefsConstant.savePref(PinActivity.this, SharedPrefsConstant.isBackfromHalf, true);
////                        PinActivity.forWhat = "newPasscode";
////                        PinActivity.this.startActivityForResult(new Intent(context, PinActivity.class), REQ_CODE_NEW_PIN_LOCK);
////                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
////                        dialog.dismiss();
////                        finish();
////                    } else {
////                        et_enteranswer.setError("Doesn't match");
////                        et_enteranswer.setText("");
////                    }
////                }
////            }
////        });
//
//     /*   im_remove.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                et_enteranswer.getText().clear();
//            }
//        });
//*/
//        ln_submit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//            @Override
//            public void onDismiss(DialogInterface dialogInterface) {
//
//            }
//        });
//
//        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
//            @Override
//            public void onShow(DialogInterface dialogInterface) {
//
//            }
//        });
//
////        ln_cancle.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                dialog.dismiss();
////            }
////        });
//        if (!PinActivity.this.isFinishing() && dialog != null) {
//            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//            dialog.show();
//        }
//
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Log.e(TAG, "onActivityResult:  aya to ave 6");
        if (requestCode == REQ_CODE_NEW_PIN_LOCK) {
            if (resultCode == RESULT_OK) {
                SharedPrefsConstant.globalPause = false;
                PinActivity.this.finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            } else {
                forWhat = "unLock";
            }
        }
    }

    @Override
    public void onBackPressed() {


        if (!forWhat.equalsIgnoreCase("unLock")) {
            super.onBackPressed();
            Intent intent = new Intent();
            setResult(RESULT_CANCELED, intent);
//            SharedPrefsConstant.savePref(this,"IsFromHideActivity",true);
//            startActivity(new Intent(this, ContactMainActivity.class).putExtra("IsFromHideActivity", true));
        } else {
            super.onBackPressed();
//            SharedPrefsConstant.savePref(this,"IsFromHideActivity",true);
//            startActivity(new Intent(this, ContactMainActivity.class).putExtra("IsFromHideActivity", true));
        }
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
