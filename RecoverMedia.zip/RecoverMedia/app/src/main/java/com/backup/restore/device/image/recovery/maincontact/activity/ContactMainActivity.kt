package com.backup.restore.device.image.recovery.maincontact.activity

import android.Manifest
import android.app.*
import android.content.*
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.*
import android.view.View.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.BannerAdHelper
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.openad.MyApplication.*
import com.backup.restore.device.image.recovery.database.ContactFetcher
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.filepicker.controller.DialogSelectionListener
import com.backup.restore.device.image.recovery.filepicker.model.DialogConfigs
import com.backup.restore.device.image.recovery.filepicker.model.DialogProperties
import com.backup.restore.device.image.recovery.filepicker.view.FilePickerDialog
import com.backup.restore.device.image.recovery.importcontacts.Doit
import com.backup.restore.device.image.recovery.importcontacts.VcardImporter.*
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.maincontact.adapter.ContactAdapter
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnBackupItemClick
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.maincontact.model.CountNameModel
import com.backup.restore.device.image.recovery.newsecurity.PinActivity
import com.backup.restore.device.image.recovery.utilities.ExcelUtils
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.checkPermissionContact
import com.backup.restore.device.image.recovery.utilities.common.*
import com.backup.restore.device.image.recovery.utilities.custom.HoloCircleSeekBar
import com.backup.restore.device.image.recovery.utilities.generateEmptyFile
//import com.example.app.ads.helper.GiftIconHelper
//import com.example.app.ads.helper.InterstitialAdHelper
//import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityContactMainBinding
import com.backup.restore.device.image.recovery.utilities.AdCache
import com.google.android.gms.ads.AdView
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
//import kotlinx.android.synthetic.main.activity_contact_main.*
//import kotlinx.android.synthetic.main.dialog_set_lock.*
//import kotlinx.android.synthetic.main.dialog_set_security_question.*
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class ContactMainActivity : MyCommonBaseActivity(), OnClickListener {

    val mTAG: String = ContactMainActivity.javaClass.simpleName

    private var mFileOutputStream: FileOutputStream? = null
    private var mArVCard: ArrayList<String>? = ArrayList()

    var securityDialog: Dialog? = null
    var setLockDialog: Dialog? = null

    var mPermissionStorage: Array<String>? = null
    private var mDbHelper: DBAdapter? = null
    private var mFavCursor: Cursor? = null

    private val REQ_CODE_NEW_PIN_LOCK = 332
    private val REQ_CODE_NEW_PATTERN_LOCK = 799
    private var forWhat = ""

    var isFromOneSignal = false
    var isContactLoaded = false
    private var isContactListLoading = false

    var mContactsCursor: Cursor? = null

    private var mContactAdapter: ContactAdapter? = null
    private var imageFile: File? = null
    private var mCountCont = 0
//    private var rewardedAd: RewardedAd? = null

    //    private var mContactFlag = false
    var backUpAsyncTaskContact: BackUpAsyncTaskContact? = null

//    private var mSelectedPos = 0

    //    private var msActivityToBeOpen = ""
    var mIntentFilter: IntentFilter? = null

    companion object {
        var MainContactList = ArrayList<ContactModel>()
        var isShowDialogContact = false
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    lateinit var binding:ActivityContactMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
//        setContentView(R.layout.activity_contact_main)
        binding=ActivityContactMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    override fun getContext(): AppCompatActivity {
        return this@ContactMainActivity
    }

    override fun initData() {
        mDbHelper = DBAdapter(mContext)
        mPermissionStorage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            arrayOf(Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_CONTACTS)
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_CONTACTS,
                Manifest.permission.READ_CONTACTS
            )
        }

//        if (AdsManager(mContext).isNeedToShowAds()) {
////            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
////            GiftIconHelper.loadGiftAd(
////                fContext = mContext,
////                fivGiftIcon = findViewById(R.id.main_la_gift),
////                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
////            )
//        }
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
//        if (intent.hasExtra("IsFromHideActivity")) {
//            if (intent.getBooleanExtra("IsFromHideActivity", false)) {
//                displayContactMethod("IsFromHideActivity")
//            }
//        }

        mIntentFilter = IntentFilter("MainActivityReceiver")

        if (checkPermissionContact(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                setAllData()
            }
        } else {
            givePermissions(mPermissionStorage!!)
        }

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
            loadAds()
//        } else {
//            binding.adview.visibility = View.GONE
//        }
    }

    var isAdLoaded = false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        changeLanguage()
        registerReceiver(chooseReceiver, mIntentFilter, Context.RECEIVER_NOT_EXPORTED)


//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            mContext.loadOfflineGoogleNativeBanner(findViewById(R.id.ad_view_container))
//        } else {
//            findViewById<FrameLayout>(R.id.ad_view_container).visibility = View.GONE
//        }

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            if (llBackupView.visibility == VISIBLE) {
//                cl_gifts.visibility = VISIBLE
//                cl_gifts.isClickable = true
//            }
//        } else {
//            cl_gifts.visibility = INVISIBLE
//            cl_gifts.isClickable = false
//        }


        try {
            if (SharedPrefsConstant.getString(mContext, SharedPrefsConstant.LAST_BACKUP) != "") {
//                tvLastBackup.text =
//                    "${getString(R.string.keep_your_contacts_in_safe_area)} : " + SharedPrefsConstant.getString(
//                        mContext,
//                        SharedPrefsConstant.LAST_BACKUP
//                    ).trimIndent()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    fun loadAds() {
        val adId = getString(R.string.admob_banner)
        BannerAdHelper.showBanner(
            this, binding.adview, binding.adview, adId,
            AdCache.bannerDetail, { isLoaded, adView, message ->
                AdCache.bannerDetail = adView
                mAdView = adView
                isAdLoaded = isLoaded
            }
        )
    }
    private fun setAllData() {

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(mMessageReceiver, IntentFilter("my_backups"))
        val intent = intent
        if (intent != null) {
            val title = intent.getStringExtra("notification")
            if (title != null) {
                if (title == "confirm_request") {
                    backupContacts()
                }
            }
        }
    }

    override fun initActions() {
        binding.ivBack.setOnClickListener(this)
        binding.llImport.setOnClickListener(this)
        binding.llExport.setOnClickListener(this)
        binding.ivRefresh.setOnClickListener(this)
        binding.ivHistory.setOnClickListener(this)
        binding.ivHide.setOnClickListener(this)

    }

    override fun onClick(view: View) {
        if (view == binding.ivHistory) {
            startActivity(Intent(mContext, ContactHistoryActivity::class.java))
        }
        else if (view == binding.llImport) {
            dialogImportTo()
        }
        else if (view == binding.llExport) {
            val intent = Intent(applicationContext, ConfigureContactActivity::class.java)
            startActivity(intent)
        }
        else if (view == binding.ivBack) {
            onBackPressed()
        }
    }

    private fun dialogImportTo() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_contact_export)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        val checkExcel = dialog.findViewById<RadioButton>(R.id.cb_select_excel)
        val checkPdf = dialog.findViewById<RadioButton>(R.id.cb_select_pdf)
        val iv_select_1 = dialog.findViewById<ImageView>(R.id.iv_select_1)
        val iv_select_2 = dialog.findViewById<ImageView>(R.id.iv_select_2)

        iv_select_1.setImageDrawable(resources.getDrawable(R.drawable.ic_excel_icon))
        iv_select_2.setImageDrawable(resources.getDrawable(R.drawable.ic_vcf_icon))

        dialog.findViewById<TextView>(R.id.tv_select_excel).text = getString(R.string.from_excel)
        dialog.findViewById<TextView>(R.id.tv_select_pdf).text = getString(R.string.from_vcf)
        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.import_contact)
//        dialog.findViewById<ImageView>(R.id.imageIcon).rotation = 180f

        val ll_excel = dialog.findViewById<LinearLayout>(R.id.ll_rating_view)
        val ll_pdf = dialog.findViewById<LinearLayout>(R.id.ll_pdf)
        var isImportExcel = true

        ll_excel.setOnClickListener {
            checkExcel.isChecked = true
            isImportExcel = true
            checkPdf.isChecked = false

        }
        ll_pdf.setOnClickListener {
            checkPdf.isChecked = true
            isImportExcel = false
            checkExcel.isChecked = false

        }

        dialog.findViewById<View>(R.id.dialogButtonClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
            dialog.dismiss()
            if (isImportExcel) {
                dialogFilePicker(0, arrayOf("xls", "xlsx"))
            } else {
                dialogFilePicker(1, arrayOf("vcf"))
            }
        }
        dialog.show()
    }

    private fun dialogFilePicker(type: Int, arrayOf: Array<String>) {
        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        val dialogProperties = DialogProperties()
        dialogProperties.extensions = arrayOf
        dialogProperties.selection_type = DialogConfigs.FILE_SELECT
        dialogProperties.selection_mode = DialogConfigs.SINGLE_MODE
        dialogProperties.show_hidden_files = true
        dialogProperties.root = File(DialogConfigs.DEFAULT_DIR)
        dialogProperties.offset = File(DialogConfigs.DEFAULT_DIR)
        dialogProperties.root = File(ShareConstants.mRootPath)

        val pickerDialog = FilePickerDialog(this@ContactMainActivity, dialogProperties)
        pickerDialog.setTitle(getString(R.string.select_a_file))
        pickerDialog.setPositiveBtnName(getString(R.string.filechooser_ok))

        //Method handle selected files.
        pickerDialog.setDialogSelectionListener(object : DialogSelectionListener {
            override fun onSelectedFilePaths(files: Array<String>) {
                //files is the array of paths selected by the App User.
                for (path in files) {
                    if (type == 0) {
                        val file = File(path)
                        MainContactList = ExcelUtils.readFromExcelWorkbook(
                            application,
                            file.path
                        ) as ArrayList<ContactModel>
                        AddContact(MainContactList).execute()
                    } else {

                        val file = File(path)

//                            ImportVcfTask(false).execute(file)

                        pickedPath = file.path
                        val editor = getSharedPreferences("ImportContacts", 0)?.edit()
                        editor?.putString("location", file.path)
                        editor?.apply()
                        startActivityForResult(
                            Intent(
                                this@ContactMainActivity,
                                Doit::class.java
                            ), 0
                        )
                    }
                }
            }
        })
        pickerDialog.properties = dialogProperties

        pickerDialog.show()
    }

    override fun onCreateDialog(id: Int): Dialog? {
        var ret: Dialog? = null
        when (id) {
//            DIALOG_FILEORDIR -> {
//                // custom layout in an AlertDialog
//                val factory = LayoutInflater.from(this)
//                val dialogView = factory.inflate(
//                    R.layout.fileordir, null
//                )
//
//                // wire up buttons
//                (dialogView.findViewById<View>(R.id.file) as Button)
//                    .setOnClickListener {
//                        _ok = true
//                        _ok_file = true
//                        _dialog!!.dismiss()
//                    }
//                (dialogView.findViewById<View>(R.id.dir) as Button)
//                    .setOnClickListener {
//                        _ok = true
//                        _ok_file = false
//                        _dialog!!.dismiss()
//                    }
//                run {
//                    ret = androidx.appcompat.app.AlertDialog.Builder(this)
//                        .setTitle("Do you want to?")
//                        .setView(dialogView)
//                        .create()
//                    _dialog = ret
//                }
//                ret!!.setOnDismissListener {
//                    if (_ok) {
//
//                        // set a path for this incantation
//                        _file_chooser!!.setMode(
//                            if (_ok_file) FileChooser.MODE_FILE else FileChooser.MODE_DIR
//                        )
//                        _file_chooser!!.path = _path
//
//                        showDialog(DIALOG_FILECHOOSER)
//                    }
//                }
//            }
//            DIALOG_FILECHOOSER -> ret = _file_chooser!!.onCreateDialog()
//            DIALOG_NOSDCARD -> ret = AlertDialog.Builder(this)
//                .setIcon(R.drawable.ic_error)
//                .setTitle(R.string.error_title)
//                .setMessage(R.string.error_nosdcard)
//                .setPositiveButton(
//                    R.string.error_ok
//                ) { dialog, whichButton -> // close the whole app!
//                    setResult(RESULT_OK)
//                    finish()
//                }
//                .create()
        }
        return ret
    }

    protected fun getSdCardPathPrefix(): String? {
        // check sdcard status
        val state = Environment.getExternalStorageState()
        if (Environment.MEDIA_MOUNTED != state &&
            Environment.MEDIA_MOUNTED_READ_ONLY != state
        ) {
            // no sdcard mounted
            return null
        }

        // get sdcard path

        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        val file = ShareConstants.mRootPath + "/RecoverMedia/Contact Backup/"

        var sdcard_path: String?
        try {
            sdcard_path = Environment.getExternalStorageDirectory()
                .canonicalPath
            if (sdcard_path[sdcard_path.length - 1] == '/') sdcard_path =
                sdcard_path.substring(0, sdcard_path.length - 1)
        } catch (e: IOException) {
            sdcard_path = null
        }
        return sdcard_path
    }

    private inner class AddContact(var contactList: ArrayList<ContactModel>) :
        AsyncTask<Void?, String?, Void?>() {
        val dialog = Dialog(mContext)
        var permission_text: TextView? = null

//        fun AddContact(contactList : ArrayList<ContactModel>) {
//            this.contactList=contactList
//        }

        override fun onPreExecute() {
            super.onPreExecute()
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            dialog.findViewById<TextView>(R.id.permission).text =
                getString(R.string.label_please_wait)
            permission_text = dialog.findViewById<TextView>(R.id.permission_text)
            //permission_text.text = getString(R.string.loading_contacts)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).visibility = GONE

            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }


            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }

        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            val parseInt = values[0]?.toInt()
//            permission_text?.setMax(100)
//            val value = parseInt / dataList.size
            runOnUiThread {
                permission_text?.text =
                    "${mContext.getString(R.string.import_contact)} $parseInt / ${contactList.size}"
            }
        }

        override fun doInBackground(vararg voids: Void?): Void? {

            var i = 0
            for (contact in contactList) {
                try {

                    val operationList = ArrayList<ContentProviderOperation>()
                    operationList.add(
                        ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                            .build()
                    )

                    // first and last names
                    operationList.add(
                        ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(
                                ContactsContract.Contacts.Data.RAW_CONTACT_ID,
                                0
                            )
                            .withValue(
                                ContactsContract.Contacts.Data.MIMETYPE,
                                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                            )
                            .withValue(
                                ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME,
                                contact.mContactName
                            )
                            .build()
                    )
                    operationList.add(
                        ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(
                                ContactsContract.Contacts.Data.RAW_CONTACT_ID,
                                0
                            )
                            .withValue(
                                ContactsContract.Data.MIMETYPE,
                                ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                            )
                            .withValue(
                                ContactsContract.CommonDataKinds.Phone.NUMBER,
                                contact.mNumber
                            )
                            .withValue(
                                ContactsContract.CommonDataKinds.Phone.TYPE,
                                ContactsContract.CommonDataKinds.Phone.TYPE_HOME
                            )
                            .build()
                    )
                    try {
                        val results =
                            contentResolver.applyBatch(ContactsContract.AUTHORITY, operationList)
                    } catch (e: java.lang.Exception) {
                        Log.e("TAG", "Exception " + e.message)
                        e.printStackTrace()
                    }
                } catch (e: Exception) {

                }
                if (i % 100 == 0) Thread.sleep(2000)
                publishProgress((i++).toString())
            }

            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            Log.e("TAG", "contact_list " + contactList.size)

            Handler(Looper.getMainLooper()).postDelayed(Runnable {
                try {
                    if (dialog != null && dialog.isShowing) {
                        dialog.cancel()
                        MyApplication.isDialogOpen = false
                    }

                } catch (e: Exception) {
                }
            }, 200)


            Toast.makeText(
                mContext,
                getString(R.string.backup_save_successfully),
                Toast.LENGTH_SHORT
            ).show()
        }
    }


//    private fun selectSecurityStep() {
//
//        var view: View = layoutInflater.inflate(R.layout.dialog_set_security_question, null)
//        securityDialog = Dialog(mContext)
//        securityDialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        securityDialog!!.setCanceledOnTouchOutside(false)
//        securityDialog!!.setContentView(view)
//        securityDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        securityDialog!!.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//
//        val list: MutableList<String?> = ArrayList()
//        list.add(getString(R.string.select_your_question))
//        list.add(getString(R.string.which_is_your_favorite_movie))
//        list.add(getString(R.string.what_is_your_favorite_food))
//        list.add(getString(R.string.who_is_your_favorite_actress))
//        list.add(getString(R.string.whats_your_lucky_number))
//        list.add(getString(R.string.in_which_city_were_you_born))
//        val que = arrayOf("")
//
//        securityDialog!!.et_enteranswer.addTextChangedListener(object : TextWatcher {
//            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
//            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
//                if (securityDialog!!.et_enteranswer.text.toString().isEmpty()) {
//                    securityDialog!!.txt_submit.setTextColor(resources.getColor(R.color.white))
//                } else {
//                    securityDialog!!.txt_submit.setTextColor(resources.getColor(R.color.white))
//                }
//            }
//
//            override fun afterTextChanged(editable: Editable) {}
//        })
//
//        securityDialog!!.ivCloseDialog.setOnClickListener {
//            securityDialog!!.cancel()
//            MyApplication.isDialogOpen = false
//        }
//        securityDialog!!.ivDrop.setOnClickListener {
//            securityDialog!!.spinner_d.performClick()
//        }
//        securityDialog!!.spinner_d.setOnTouchListener { _, _ ->
//            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
//            imm.hideSoftInputFromWindow(securityDialog!!.spinner_d.windowToken, 0)
//            false
//        }
//
//        val adapter: ArrayAdapter<Any?> =
//            ArrayAdapter<Any?>(application, R.layout.spinner_layout, list as List<Any?>)
//        securityDialog!!.spinner_d.adapter = adapter
//
//        securityDialog!!.spinner_d.onItemSelectedListener =
//            object : AdapterView.OnItemSelectedListener {
//                override fun onItemSelected(
//                    parent: AdapterView<*>,
//                    view: View,
//                    position: Int,
//                    id: Long
//                ) {
//                    securityDialog!!.et_enteranswer.text.clear()
//                    que[0] = parent.getItemAtPosition(position) as String
//                    if (position == 0) {
//                        securityDialog!!.et_enteranswer.isEnabled = false
//                        que[0] = "none"
//                    } else {
//                        securityDialog!!.et_enteranswer.isEnabled = true
//                    }
//                }
//
//                override fun onNothingSelected(parent: AdapterView<*>?) {}
//            }
//        securityDialog!!.ln_submit.setOnClickListener {
//            if (que[0] == "none") {
//                Toast.makeText(
//                    applicationContext,
//                    getString(R.string.select_question),
//                    Toast.LENGTH_SHORT
//                ).show()
//            } else {
//                when {
//                    securityDialog!!.et_enteranswer.text.toString().trim() == "" -> {
//                        Toast.makeText(
//                            applicationContext,
//                            getString(R.string.enter_answer),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                    securityDialog!!.et_enteranswer.text.toString().length < 5 -> {
//                        Toast.makeText(
//                            applicationContext,
//                            getString(R.string.at_least_5_character),
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                    else -> {
//                        SharedPrefsConstant.save(
//                            applicationContext,
//                            SharedPrefsConstant.BACKUP_QUESTION,
//                            que[0]
//                        )
//                        SharedPrefsConstant.save(
//                            applicationContext,
//                            SharedPrefsConstant.BACKUP_ANSWER,
//                            securityDialog!!.et_enteranswer.text.toString().trim { it <= ' ' })
//                        lockTypeDialog("lock")
//                        securityDialog!!.cancel()
//                        MyApplication.isDialogOpen = false
//                    }
//                }
//            }
//        }
//        securityDialog!!.show()
//        MyApplication.isDialogOpen = true
//    }

//    private fun lockTypeDialog(forWhat: String) {
//
//        var view: View = layoutInflater.inflate(R.layout.dialog_set_lock, null)
//        setLockDialog = Dialog(mContext)
//        setLockDialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        setLockDialog!!.setCancelable(false)
//        setLockDialog!!.setContentView(view)
//        setLockDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        setLockDialog!!.window!!.setLayout(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//
//        var selectionType = false
//
//        setLockDialog!!.cl_lock_pin.setOnClickListener {
//            selectionType = false
//            setLockDialog!!.ivPinConfirm.setImageResource(R.drawable.ic_radio_select)
//            setLockDialog!!.ivPaternConfirm.setImageResource(R.drawable.ic_radio_unselect)
//        }
//        setLockDialog!!.cl_lock_pattern.setOnClickListener {
//            selectionType = true
//            setLockDialog!!.ivPinConfirm.setImageResource(R.drawable.ic_radio_unselect)
//            setLockDialog!!.ivPaternConfirm.setImageResource(R.drawable.ic_radio_select)
//        }
//
//        setLockDialog!!.cv_done.setOnClickListener {
//            if (!selectionType) {
//                if (forWhat == "fake_lock") {
//                    PinActivity.setForWhat(forWhat)
//                }
//                PinActivity.forWhat = "newPasscode"
//                setLockDialog!!.cancel()
//                MyApplication.isDialogOpen = false
//                startActivityForResult(
//                    Intent(applicationContext, PinActivity::class.java),
//                    REQ_CODE_NEW_PIN_LOCK
//                )
////                finish()
//            } else {
//                MyPatternActivity.forWhat = "new_pattern"
//                setLockDialog!!.cancel()
//                MyApplication.isDialogOpen = false
//                startActivityForResult(
//                    Intent(applicationContext, MyPatternActivity::class.java),
//                    REQ_CODE_NEW_PATTERN_LOCK
//                )
////                finish()
//            }
//        }
//        setLockDialog!!.ivCloseDialogTheme.setOnClickListener {
//            SharedPrefsConstant.removeKey(applicationContext, SharedPrefsConstant.BACKUP_ANSWER)
//            SharedPrefsConstant.removeKey(applicationContext, SharedPrefsConstant.BACKUP_QUESTION)
//            setLockDialog!!.cancel()
//            MyApplication.isDialogOpen = false
//        }
//        setLockDialog!!.setOnDismissListener {
//            MyApplication.isDialogOpen = false
//        }
//
//
//        setLockDialog!!.show()
//        MyApplication.isDialogOpen = true
//    }


    private fun displayContactMethod() {
        binding.clGifts.visibility = INVISIBLE
        binding.clGifts.isClickable = false
        binding.llSettingView.visibility = GONE
        binding.ivRefresh.visibility = VISIBLE
        binding.ivHistory.visibility = GONE
        binding.ivHide.visibility = VISIBLE
        MainContactList.clear()
//        if(lFrom == "llContact") {
//        if (!isContactLoaded) {
        contactListData()
//        if (!isContactListLoading) {
//

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
//            contactListData.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        } else {
//            contactListData.execute()
//        }
//        }
//        }

//        }
//        if (rvContact.adapter != null && mContactAdapter!!.itemCount > 0) {
//            MainContactList.clear()
//            mContactAdapter!!.notifyDataSetChanged()
//        }

    }


    inner class BackUpAsyncTaskContact : AsyncTask<String?, String?, String>() {
        var dialog: AlertDialog? = null
        var holoCircleSeekBar: HoloCircleSeekBar? = null
        var dialogButtonCancel: Button? = null
        override fun onPreExecute() {
            super.onPreExecute()
            try {
                val alertDialogBuilder = AlertDialog.Builder(mContext)
                val inflater = mContext.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
                val view = inflater.inflate(R.layout.dialog_contacts_backup, null)
                alertDialogBuilder.setView(view)
                alertDialogBuilder.setCancelable(false)
                dialog = alertDialogBuilder.create()
                dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                dialogButtonCancel = view.findViewById(R.id.dialogButtonCancel)
                dialogButtonCancel?.setOnClickListener {
                    if (status == AsyncTask.Status.RUNNING) {
                        cancel(true)
                        imageFile!!.delete()
                    }
                    dialog?.dismiss()
                }
                holoCircleSeekBar = view.findViewById(R.id.holoCircleSeekbar)

                dialog!!.setOnDismissListener {
                    MyApplication.isDialogOpen = false
                }


                if (!dialog!!.isShowing) {
                    dialog!!.show()
                    MyApplication.isDialogOpen = true
                }
                mArVCard!!.clear()
            } catch (e: Exception) {
                Log.e("mmmmmgggggg", "55555:" + e)
                e.printStackTrace()
            }
        }

        override fun doInBackground(vararg strings: String?): String {
            try {
                mContactsCursor!!.moveToFirst()
                for (i in 0 until mContactsCursor!!.count) {
                    get(mContactsCursor)
                    publishProgress((i + 1).toString())
                    mContactsCursor!!.moveToNext()
                }
                try {
                    mFileOutputStream!!.close()
                } catch (e: IOException) {
                    Log.e(mTAG, "doInBackground: " + e.printStackTrace())
                    Log.e(mTAG, "doInBackground: message" + e.message)
                    e.printStackTrace()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e(mTAG, "doInBackground: " + e.message)
            }
            return ""
        }

        operator fun get(cursor: Cursor?) {
            //cursor.moveToFirst();
            val lookupKey =
                cursor!!.getString(cursor.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY))
            val uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, lookupKey)
            val fd: AssetFileDescriptor
            try {
                fd = contentResolver.openAssetFileDescriptor(uri, "r")!!
                val fis = fd.createInputStream()
                val buf = readBytes(fis)
                fis.read(buf)
                val vcardstring = String(buf)
                Log.e(mTAG, "get: buffer not 0")
                mArVCard!!.add(vcardstring)
                mFileOutputStream!!.write(vcardstring.toByteArray())
                //                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @Throws(IOException::class)
        fun readBytes(inputStream: InputStream): ByteArray {
            // this dynamically extends to take the bytes you read
            val byteBuffer = ByteArrayOutputStream()

            // this is storage overwritten on each iteration with bytes
            val bufferSize = 1024
            val buffer = ByteArray(bufferSize)

            // we need to know how may bytes were read to write them to the byteBuffer
            var len = 0
            while (inputStream.read(buffer).also { len = it } != -1) {
                byteBuffer.write(buffer, 0, len)
            }
            // and then we can return your byte array.
            return byteBuffer.toByteArray()
        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            val parseInt = values[0]!!.toInt()
            holoCircleSeekBar!!.setMax(100)
            val valCount = parseInt * 100 / mContactsCursor!!.count
            holoCircleSeekBar!!.setValue(valCount.toFloat())
        }

        override fun onPostExecute(string: String) {
            super.onPostExecute(string)

            try {
                if (dialog != null && dialog!!.isShowing) {
                    MyApplication.isDialogOpen = false
                    dialog!!.cancel()
                }
            } catch (e: java.lang.Exception) {

            }
            val timeStamp = SimpleDateFormat("hh:mm:ss dd-MM-yyyy").format(Date())
            SharedPrefsConstant.save(mContext, SharedPrefsConstant.LAST_BACKUP, timeStamp)

            //val path = File(ShareConstants.mRootPath + "/RecoverMedia/Contacts Backup")
            val path =
                File(this@ContactMainActivity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.absolutePath + File.separator + "RecoverMedia" + File.separator + "Contacts Backup")
            if (!path.exists()) {
                path.mkdirs()
            }

            Log.e("mmmmmggggg", "name:" + imageFile!!.name)
            if (imageFile!!.exists()) {
                try {
                    copy(imageFile!!)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            mContext.runOnUiThread {
                Toast.makeText(
                    mContext,
                    getString(R.string.backup_save_successfully),
                    Toast.LENGTH_SHORT
                ).show()
//                tvLastBackup.text = "${getString(R.string.keep_your_contacts_in_safe_area)} : ${
//                    SharedPrefsConstant.getString(
//                        mContext,
//                        SharedPrefsConstant.LAST_BACKUP
//                    )
//                }".trimIndent()
            }

        }
    }

    private fun copy(fileToCopy: File) {
        try {
            ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()

            val destinationFile = generateEmptyFile("contact", "vcf")
            Log.e(mTAG, "copy: fileToCopy -- > ${fileToCopy.path}")
            Log.e(mTAG, "copy: destinationFile -- > ${destinationFile.path}")
            val fis = FileInputStream(fileToCopy)
            val fos = FileOutputStream(destinationFile)
            val b = ByteArray(1024)
            var noOfBytesRead: Int
            while (fis.read(b).also { noOfBytesRead = it } != -1) {
                fos.write(b, 0, noOfBytesRead)
            }
            fis.close()
            fos.close()
        } catch (e: IOException) {
            Log.e(mTAG, "copy: IOException -- > $e")
            e.printStackTrace()
        }
    }


    override fun onRequestPermissionsResult(i: Int, strArr: Array<String>, iArr: IntArray) {
        super.onRequestPermissionsResult(i, strArr, iArr)
        if (i == 10) {
            if (iArr.isEmpty() || iArr[0] != 0) {
                finish()
            } else {
                Log.e("TAG", "granted")
            }
        }
    }

    private val mMessageReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            backupContacts()
        }
    }

    private fun backupContacts() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        } else {
            ShareConstants.mRootPath = Environment.getExternalStorageDirectory()
                .toString() + File.separator + "Android" + File.separator + "data" + File.separator + packageName
        }

//        val path = File(Environment.getExternalStorageDirectory().getAbsolutePath()+ File.separator+ Environment.DIRECTORY_DOWNLOADS+ File.separator+ "RecoverMedia"+ File.separator+ "Contacts Backup")
//        val path = File(this@ContactMainActivity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.absolutePath + File.separator+ "RecoverMedia"+ File.separator+ "Contacts Backup")
//        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        val path = File(ShareConstants.mRootPath + "/RecoverMedia/Contacts Backup")
        if (!path.exists()) {
            path.mkdirs()
        }
        val timeStamp = SimpleDateFormat("hh:mm:ss dd-MM-yyyy").format(Date())
        imageFile = File(path.path, "$timeStamp.vcf")
        try {
            if (!imageFile!!.exists()) {
                imageFile!!.createNewFile()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

        SharedPrefsConstant.save(mContext, SharedPrefsConstant.LAST_BACKUP, timeStamp)
        try {
            Log.e(mTAG, "backupContacts:createNewFile -=>  " + imageFile!!.createNewFile())
            mFileOutputStream = FileOutputStream(imageFile, false)

        } catch (e: IOException) {
            e.printStackTrace()
        }
        mArVCard = ArrayList()
        mContactsCursor =
            contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null)

        mContactsCursor!!.moveToFirst()
        var flgAvailable: Boolean? = true
        var cursor1: Cursor? = mContactsCursor
        if (cursor1!!.count < 10) {
            for (i in 0 until cursor1.count) {
                flgAvailable = false
                flgAvailable = getImgUri(mContactsCursor!!)
                if (flgAvailable == true) {
                    flgAvailable = true
                    break
                }
                cursor1.moveToNext()

            }
        }
        Log.e(mTAG, "backupContacts: flgAvailable :" + flgAvailable + " count :" + cursor1.count)
        if (mContactsCursor != null && mContactsCursor!!.count > 0 && flgAvailable == true) {

            try {
                backUpAsyncTaskContact = BackUpAsyncTaskContact()
                backUpAsyncTaskContact?.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            imageFile!!.delete()
            Toast.makeText(mContext, getString(R.string.no_contact_in_phone), Toast.LENGTH_SHORT)
                .show()
        }

    }


    fun getImgUri(cursor: Cursor?): Boolean {
        //cursor.moveToFirst();
        val lookupKey =
            cursor!!.getString(cursor.getColumnIndex(ContactsContract.Contacts.LOOKUP_KEY))
        val uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, lookupKey)
        val fd: AssetFileDescriptor
        try {
            fd = contentResolver.openAssetFileDescriptor(uri, "r")!!
            val fis = fd.createInputStream()
            val buf = readBytes(fis)
            fis.read(buf)
            val vcardstring = String(buf)
            if (Integer.parseInt(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                Log.e(mTAG, "getImgUri: ")
                return true

            } else {
                Log.e(mTAG, "getImgUri: not")
                return false
            }

            //                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun readBytes(inputStream: InputStream): ByteArray {
        // this dynamically extends to take the bytes you read
        val byteBuffer = ByteArrayOutputStream()

        // this is storage overwritten on each iteration with bytes
        val bufferSize = 1024
        val buffer = ByteArray(bufferSize)

        // we need to know how may bytes were read to write them to the byteBuffer
        var len = 0
        while (inputStream.read(buffer).also { len = it } != -1) {
            byteBuffer.write(buffer, 0, len)
        }

        // and then we can return your byte array.
        return byteBuffer.toByteArray()
    }


    private val chooseReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
//            if(!isContactLoaded)
            contactListData()

//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
//                contactListData.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//            } else {
//                contactListData.execute()
//            }

        }
    }

    fun contactListData() {
        Log.e(mTAG, "contactListData()")
        MainContactList.clear()
        isContactListLoading = true

        runOnUiThread {
            val contactList = ContactFetcher(mContext).fetchAll()
            MainContactList.addAll(contactList.filter { s -> !s.mContactName.isNullOrEmpty() && !s.mNumber.isNullOrEmpty() })
        }
        isContactListLoading = false
        mCountCont = MainContactList.size

        Log.e(mTAG, "contactListData :mCountCont-$mCountCont")
        if (mCountCont > 0) {
            isContactLoaded = true

            Collections.sort(MainContactList, ContactSorter())

            mContactAdapter = ContactAdapter(mContext, MainContactList, object : OnBackupItemClick {
                override fun onItemClick(
                    contact: CountNameModel?,
                    backupFile: File?,
                    position: Int
                ) {
                }

                override fun onContactItemClick(contact: ContactModel?, position: Int) {
                    openContactDetailActivity(contact!!, position)
                }
            })
        }
    }

    // sort
    class ContactSorter : Comparator<ContactModel> {
        override fun compare(lhs: ContactModel, rhs: ContactModel): Int {
            val left: String = lhs.mContactName?.toLowerCase(Locale.getDefault()) ?: ""
            val right: String = rhs.mContactName?.toLowerCase(Locale.getDefault()) ?: ""
//            return if (!lhs.mContactName.isNullOrEmpty() && !rhs.mContactName.isNullOrEmpty())
            return left.compareTo(right)
//            else 0
        }
    }


    private fun openContactDetailActivity(contact: ContactModel, position: Int) {
//        msActivityToBeOpen = "ContactDetailsActivity"
        ShareConstants.user_id = contact.mContactId
//        ShareConstants.user_image = contact.mContactPhoto
        ShareConstants.user_name = contact.mContactName
        ShareConstants.user_number = contact.mNumber
        ShareConstants.contact_image_uri = contact.mContactImageUri
        ShareConstants.user_position = position
        MyApplication.isInterstitialShown = true
//        if (AdsManager(mContext).isNeedToShowAds()) {
                AdsConfig.showInterstitialAd(mContext,{

                    MyApplication.isInterstitialShown = false
                    openContactDetailsActivity()
                })
//        } else {
//            openContactDetailsActivity()
//        }
    }

    private fun givePermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                setAllData()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage!!)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                setAllData()
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }

        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        MyApplication.isInternalCall = true
        startActivityForResult(intent, 200)
    }

    private fun openContactBackupActivity() {
        val intent = Intent(mContext, ContactBackupActivity::class.java)
        startActivity(intent)
    }

    private fun openFavoriteActivity() {
        val intent = Intent(mContext, FavoriteActivity::class.java)
        startActivity(intent)
    }


    private fun openContactDetailsActivity() {
        isShowDialogContact = true
        val intent =
            Intent(mContext, ContactDetailsActivity::class.java).putExtra("IsFromContact", "Main")
        startActivity(intent)
    }

    override fun onBackPressed() {
        if (isFromOneSignal) {
            startActivity(NewHomeActivity.newIntent(this))
            finish()
        } else {
            super.onBackPressed()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        if (chooseReceiver != null) {
            unregisterReceiver(chooseReceiver)
        }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver)

        if(backUpAsyncTaskContact?.status==AsyncTask.Status.RUNNING) {
            backUpAsyncTaskContact?.cancel(true)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    setAllData()
                    Log.e(mTAG, "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                    }
                    finish()
                    Toast.makeText(
                        mContext,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionContact(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    setAllData()
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(NewHomeActivity.newIntent(this))
                }
                finish()
                Toast.makeText(
                    mContext,
                    getString(R.string.permission_required),
                    Toast.LENGTH_SHORT
                ).show()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        } else if (requestCode == 2297) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    dialogImportTo()
                    Log.e(mTAG, "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(NewHomeActivity.newIntent(this))
                    }
                    finish()
                    Toast.makeText(
                        mContext,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            } else {
                dialogImportTo()
            }
        }

        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == 225) {
                val uri = data!!.data
                val src = uri?.path!!
                //?.split(":")?.get(1)!!
//            pickedPath =src
//            val src = getRealPathFromURI(uri!!)
                Log.e("FileChooser", "225-path:" + uri.path)
                Log.e("FileChooser", "225-src:" + src)

                val file = File(
                    Environment.getExternalStorageDirectory(),
                    src.substring(src.indexOf(":") + 1, src.length)
                )

                MainContactList = ExcelUtils.readFromExcelWorkbook(
                    application,
                    file.path
                ) as ArrayList<ContactModel>
                AddContact(MainContactList).execute()
            }
            if (requestCode == 115) {
                val uri = data!!.data
                val src = uri!!.path
//            val src = getRealPathFromURI(uri!!)
                pickedPath = src
                val editor = getSharedPreferences("ImportContacts", 0)?.edit()
                Log.e("FileChooser", "115-path:" + uri?.path)
                Log.e("FileChooser", "115-src:" + src)
                editor?.putString("location", src)
                editor?.apply()
                startActivityForResult(Intent(this@ContactMainActivity, Doit::class.java), 0)
            }
        }

//        if (requestCode == 2000) {
//            if (resultCode == RESULT_OK) {
//                startActivity(Intent(mContext, HideContactActivity::class.java))
//                mContext.finish()
//            }
//        }

        when (requestCode) {
            REQ_CODE_NEW_PIN_LOCK -> if (resultCode == Activity.RESULT_OK) {
                if (forWhat == "fake_lock") {
                    forWhat = ""
                    PinActivity.setForWhat("")
                    SharedPrefsConstant.savePref(
                        applicationContext,
                        SharedPrefsConstant.IS_ON_FAKE_LOCK,
                        true
                    )
                } else {
                    SharedPrefsConstant.savePref(
                        applicationContext,
                        SharedPrefsConstant.IS_ON_LOCK,
                        true
                    )
                }
            } else {
                if (forWhat != "fake_lock") {
                    SharedPrefsConstant.savePref(
                        applicationContext,
                        SharedPrefsConstant.IS_ON_LOCK,
                        false
                    )
                    SharedPrefsConstant.removeKey(
                        applicationContext,
                        SharedPrefsConstant.BACKUP_QUESTION
                    )
                    SharedPrefsConstant.removeKey(
                        applicationContext,
                        SharedPrefsConstant.BACKUP_ANSWER
                    )
                }
                forWhat = ""
                PinActivity.setForWhat("")
            }
            REQ_CODE_NEW_PATTERN_LOCK -> if (resultCode == Activity.RESULT_OK) {
                if (forWhat == "fake_lock") {
                    forWhat = ""
                    PinActivity.setForWhat("")
                    SharedPrefsConstant.savePref(
                        applicationContext,
                        SharedPrefsConstant.IS_ON_FAKE_LOCK,
                        true
                    )
                } else {
                    SharedPrefsConstant.savePref(
                        applicationContext,
                        SharedPrefsConstant.IS_ON_LOCK,
                        true
                    )
                }
            } else {
                if (forWhat != "fake_lock") {
//                        sw_lock.setChecked(false);
                    SharedPrefsConstant.savePref(
                        applicationContext,
                        SharedPrefsConstant.IS_ON_LOCK,
                        false
                    )
                    SharedPrefsConstant.removeKey(
                        applicationContext,
                        SharedPrefsConstant.BACKUP_QUESTION
                    )
                    SharedPrefsConstant.removeKey(
                        applicationContext,
                        SharedPrefsConstant.BACKUP_ANSWER
                    )
                }
                forWhat = ""
//                PatternActivity.setForWhat("")
                //                    sw_fake_lock.setChecked(false);
            }
        }

//        if (requestCode == REQUEST_CODE_CHECK_PASSWORD) {
//            if (resultCode == RESULT_OK) {
//                Toast.makeText(mContext, getString(R.string.msg_lock_set_sccessfully), Toast.LENGTH_SHORT).show()
//                startActivity(Intent(mContext, HideContactActivity::class.java))
//                mContext.finish()
//                SharedPrefsConstant.save(mContext, "IsCheckSecurityType", "PinLock")
//            }
//        }
//        if (requestCode == REQUEST_CODE_CHECK_PATTERN) {
//            if (resultCode == RESULT_OK) {
//                Toast.makeText(mContext, "Pattern Set Successfully", Toast.LENGTH_SHORT).show()
//                startActivity(Intent(mContext, HideContactActivity::class.java))
//                mContext.finish()
//                SharedPrefsConstant.save(mContext, "IsCheckSecurityType", "PatternLock")
//            }
//        }
    }

    private fun getRealPathFromURI(contentURI: Uri): String? {
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val cursor = managedQuery(contentURI, projection, null, null, null)
        val column_index = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
        cursor.moveToFirst()
        return cursor.getString(column_index)
    }
}