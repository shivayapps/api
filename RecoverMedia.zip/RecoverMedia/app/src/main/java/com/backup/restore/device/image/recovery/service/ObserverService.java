package com.backup.restore.device.image.recovery.service;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

import com.aainc.recyclebin.storage.FileSystemHandler;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashSet;

public class ObserverService extends Service {
    public static final String TAG = ObserverService.class.getSimpleName();
    final Messenger b = new Messenger(new a());

    public FileSystemHandler c = null;

    public Messenger d = null;
    public static Activity mContext;

    public static void setDatata(@NotNull Activity mainActivity2) {
        mContext = mainActivity2;
        Log.e("TAG1c", "setDatata:456 " + mContext);
    }

    private ServiceConnection e = new ServiceConnection() {

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {

//            e.mainAdapter().mainAdapter(ObserverService.mainAdapter, "onServiceConnected method");
            Messenger unused = d = new Messenger(iBinder);

            Log.e("TEST", "onServiceConnected: ==>>>");

            try {
                d.send(Message.obtain((Handler) null, 1, 0, 0));
            } catch (RemoteException e) {
                e.printStackTrace();
                // e.mainAdapter().mainAdapter(ObserverService.mainAdapter, "Can't send data to remote service.\nError message: " + e.getMessage() + e.getCause());
            }
        }

        public void onServiceDisconnected(ComponentName componentName) {
            Log.e("TAG", "onServiceDisconnected: ==>>>");

        }
    };



    class a extends Handler {
        a() {

        }

        public void handleMessage(Message message) {

            Log.e("LOL", "message.what:  missing 123456789 ======>>>");

            switch (message.what) {

                case 2:

                    Bundle data = message.getData();
                    if (data != null) {

                        ArrayList<String> stringArrayList = data.getStringArrayList("BUNDLE_INIT_STRING_ARRAY_LIST");
                        Log.e(TAG, "FileObserver handleMessage: " + new Gson().toJson(stringArrayList));
                        boolean[] booleanArray = data.getBooleanArray("BUNDLE_INIT_BOOLEAN_ARRAY");
                        if (stringArrayList == null || booleanArray == null) {
                        } else {
                            HashSet<String> hashSet = new HashSet<>(stringArrayList);
                            ArrayList<Boolean> arrayList = new ArrayList<Boolean>();

                            for (boolean valueOf : booleanArray) {
                                arrayList.add(valueOf);
                            }

                            if (c == null) {
                                FileSystemHandler.a(getApplicationContext());

                                c = FileSystemHandler.a();
                                Log.e("ISSUE", "handleMessage: ");
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        boolean bool=false;
                                        try{
                                            bool=c.a(hashSet, arrayList);
                                        } catch (Exception e){}
                                        if (bool) {
                                            c.c();
                                        } else {
                                            FileSystemHandler unused2 = c = null;
                                        }
                                    }
                                }).start();

                            } else if (!c.b(hashSet, arrayList)) {
                            }
                        }
                        if (c != null) {
                            Log.e(ObserverService.TAG, "Size List of FileObserver is: " + c.b().size());
                            return;
                        } else {
                            Log.e(ObserverService.TAG, "FileSystemHandler is null");
                            return;
                        }
                    } else {
                        return;
                    }
                default:
                    super.handleMessage(message);
                    return;
            }
        }
    }


    @SuppressLint("WrongConstant")
    public boolean a() {
        Log.e("TAG", "ManagerService: ==789====>>>");
        return bindService(new Intent(this, ManagerService.class), this.e, 32);
    }

    private void b() {
        if (this.c != null) {
            this.c.d();
        }
    }


    @Override
    public IBinder onBind(Intent intent) {
        Log.e("TAG", "123456: ===>> " + this.b.getBinder());
        return this.b.getBinder();
    }

    @Override
    public void onCreate() {
        Log.e("TAG", "onCreate obj");
//        setProgressDialog();

//        1646375726747
//        1646548161272


    }

    @Override
    public void onDestroy() {
        Log.e("TAG", "onDestroy: ==>>>");
        try {
            if (this.e != null) {
                unbindService(this.e);
            }
            b();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int i, int i2) {
        new Thread(new Runnable() {
            public void run() {
                Runnable r1 = this;
                ObserverService r0 = ObserverService.this;
                boolean unused = r0.a();

            }
        }).start();
        return START_STICKY;
    }



}
