package com.backup.restore.device.image.recovery.utilities;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.Keep;

import com.backup.restore.device.image.recovery.maincontact.model.ContactModel;
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Excel Worksheet Utility Methods
 * <p>
 * Created by: Ranit Raj Ganguly on 16/04/21.
 */
@Keep
public class ExcelUtils {
    public static final String TAG = "ExcelUtil";
    private static Cell cell;
    private static Sheet sheet;
    private static Workbook workbook;
    private static CellStyle headerCellStyle;


    private static List<ContactModel> importedExcelData;

    /**
     * Import data from Excel Workbook
     *
     * @param context - Application Context
     * @param fileName - Name of the excel file
     * @return importedExcelData
     */
    public static List<ContactModel> readFromExcelWorkbook(Context context, String fileName) {
        return retrieveExcelFromStorage(context, fileName);
    }


    /**
     * Export Data into Excel Workbook
     *
     * @param context  - Pass the application context
     * @param dataList - Contains the actual data to be displayed in excel
     */
    public static boolean exportDataIntoWorkbook(Context context,File file, List<ContactModel> dataList,boolean isName,boolean isNumber,boolean isEmail,boolean isDob) {
        boolean isWorkbookWrittenIntoStorage;

        // Check if available and not read only
        if (!isExternalStorageAvailable() || isExternalStorageReadOnly()) {
            Log.e(TAG, "Storage not available or read only");
            return false;
        }

        // Creating a New HSSF Workbook (.xls format)
        workbook = new HSSFWorkbook();

        setHeaderCellStyle();

        // Creating a New Sheet and Setting width for each column
        sheet = workbook.createSheet("ContactExport");
        if(isName) sheet.setColumnWidth(0, (15 * 400));
        if(isNumber) sheet.setColumnWidth(1, (12 * 400));
        if(isEmail) sheet.setColumnWidth(2, (20 * 400));
        if(isDob) sheet.setColumnWidth(3, (10 * 400));

        setHeaderRow(isName, isNumber, isEmail, isDob);
        fillDataIntoExcel(dataList, isName, isNumber, isEmail, isDob);

        isWorkbookWrittenIntoStorage = storeExcelInStorage(context,file);

        return isWorkbookWrittenIntoStorage;
    }

    /**
     * Checks if Storage is READ-ONLY
     *
     * @return boolean
     */
    private static boolean isExternalStorageReadOnly() {
        String externalStorageState = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED_READ_ONLY.equals(externalStorageState);
    }

    /**
     * Checks if Storage is Available
     *
     * @return boolean
     */
    private static boolean isExternalStorageAvailable() {
        String externalStorageState = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(externalStorageState);
    }

    /**
     * Setup header cell style
     */
    private static void setHeaderCellStyle() {
        headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(HSSFColor.AQUA.index);
        headerCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        headerCellStyle.setAlignment(CellStyle.ALIGN_CENTER);
    }

    /**
     * Setup Header Row
     */
    private static void setHeaderRow(boolean isName,boolean isNumber,boolean isEmail,boolean isDob) {
        Row headerRow = sheet.createRow(0);

//        cell = headerRow.createCell(0);
//        cell.setCellValue("Id");
//        cell.setCellStyle(headerCellStyle);

        int rowCont=0;
        if(isName) {
            cell = headerRow.createCell(rowCont);
            cell.setCellValue("Name");
            cell.setCellStyle(headerCellStyle);
            rowCont++;
        }
        if(isNumber) {
            cell = headerRow.createCell(rowCont);
            cell.setCellValue("Number");
            cell.setCellStyle(headerCellStyle);
            rowCont++;
        }
        if(isEmail) {
            cell = headerRow.createCell(rowCont);
            cell.setCellValue("Email");
            cell.setCellStyle(headerCellStyle);
            rowCont++;
        }
        if(isDob) {
            cell = headerRow.createCell(rowCont);
            cell.setCellValue("DOB");
            cell.setCellStyle(headerCellStyle);
            rowCont++;
        }
    }

    /**
     * Fills Data into Excel Sheet
     * <p>
     * NOTE: Set row index as i+1 since 0th index belongs to header row
     *
     * @param dataList - List containing data to be filled into excel
     */
    private static void fillDataIntoExcel(List<ContactModel> dataList,boolean isName,boolean isNumber,boolean isEmail,boolean isDob) {
        Log.e(TAG, "fillDataIntoExcel");
        for (int i = 0; i < dataList.size(); i++) {
            // Create a New Row for every new entry in list
            Row rowData = sheet.createRow(i + 1);

            // Create Cells for each row
            int rowCont=0;
            if(isName) {
                cell = rowData.createCell(rowCont);
                cell.setCellValue(dataList.get(i).getMContactName());
                rowCont++;
            } else {
                cell = rowData.createCell(rowCont);
                cell.setCellValue("");
                rowCont++;
            }

            if(isNumber) {
                cell = rowData.createCell(rowCont);
                cell.setCellValue(dataList.get(i).getMNumber());
                rowCont++;
            } else {
                cell = rowData.createCell(rowCont);
                cell.setCellValue("");
                rowCont++;
            }

            if(isEmail) {
                cell = rowData.createCell(rowCont);
                cell.setCellValue(dataList.get(i).getMEmail());
                rowCont++;
            } else {
                cell = rowData.createCell(rowCont);
                cell.setCellValue("");
                rowCont++;
            }

            if(isDob) {
                cell = rowData.createCell(rowCont);
                cell.setCellValue(dataList.get(i).getMDOB());
                rowCont++;
            } else {
                cell = rowData.createCell(rowCont);
                cell.setCellValue("");
                rowCont++;
            }

//            cell = rowData.createCell(1);
//            if (dataList.get(i).getPhoneNumberList() != null) {
//                StringBuilder stringBuilder = new StringBuilder();
//
//                // Nested loop: Since one user can have multiple numbers
//                for (int j = 0; j < dataList.get(i).getPhoneNumberList().size(); j++) {
//                    stringBuilder.append(dataList.get(i).getPhoneNumberList().get(j).getNumber())
//                            .append("\n");
//                }
//                cell.setCellValue(String.valueOf(stringBuilder));
//
//            }
//            else {
//                cell.setCellValue("No Phone Number");
//            }
        }
        Log.e(TAG, "//fillDataIntoExcel");
    }

    /**
     * Store Excel Workbook in external storage
     *
     * @param context  - application context
     * @return boolean - returns state whether workbook is written into storage or not
     */
    private static boolean storeExcelInStorage(Context context,File file) {
        boolean isSuccess;
        //File file = new File(context.getExternalFilesDir(null), fileName);
//        String timeStamp = new SimpleDateFormat("ddMMyyyy_hh_mm_ss", Locale.getDefault()).format(new Date());
//        String fileName = "Contact_"+timeStamp+".xls";
//        String fileName = "Contact.xls";

//        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
//            ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString();
//        } else {
//            ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString() + File.separator + "Android" + File.separator + "data" + File.separator + context.getPackageName();
//        }

//        String path = ShareConstants.mRootPath + "/RecoverMedia/Contact Backup/";
//        File dir = new File(path);
//        if (!dir.exists()) {
//            dir.mkdir();
//        }
//        File file = new File(path, fileName);


//        File file = new File(filePath);
        if(!file.exists()) new File(file.getParent()).mkdirs();

        ShareConstants.mExcelPath=file.getPath();
        FileOutputStream fileOutputStream = null;

        try {
            fileOutputStream = new FileOutputStream(file);
            workbook.write(fileOutputStream);
            Log.e(TAG, "Writing file" + file);
            isSuccess = true;
        } catch (IOException e) {
            Log.e(TAG, "Error writing Exception: ", e);
            isSuccess = false;
        } catch (Exception e) {
            Log.e(TAG, "Failed to save file due to Exception: ", e);
            isSuccess = false;
        } finally {
            try {
                if (null != fileOutputStream) {
                    fileOutputStream.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

//        if(isSuccess) {
//            Toast.makeText(context, "ExcelFile saved successfully to location "+file.getPath(), Toast.LENGTH_LONG).show();
//        } else {
//            Toast.makeText(context, "Failed to save file. Try again.", Toast.LENGTH_LONG).show();
//        }
        return isSuccess;
    }

    /**
     * Retrieve excel from External Storage
     *
     * @param context  - application context
     * @param fileName - name of workbook to be read
     * @return importedExcelData
     */
    private static List<ContactModel> retrieveExcelFromStorage(Context context, String fileName) {
        importedExcelData = new ArrayList<>();

        //File file = new File(context.getExternalFilesDir(null), fileName);
//        String timeStamp = new SimpleDateFormat(" ddMMyyyy_hh_mm_ss", Locale.getDefault()).format(new Date());
//        String fileName = "Contact_"+timeStamp+".xls";
//        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString();
//        String path = ShareConstants.mRootPath + "/RecoverMedia/Contact Backup/";
        File file = new File(fileName);
//        File file = new File(context.getExternalFilesDir(null), fileName);
        FileInputStream fileInputStream = null;

        try {
            Log.e(TAG, "Reading from Excel" + file);
            fileInputStream = new FileInputStream(file);

            // Create instance having reference to .xls file
            workbook = new HSSFWorkbook(fileInputStream);

            // Fetch sheet at position 'i' from the workbook
            sheet = workbook.getSheetAt(0);

            // Iterate through each row
            for (Row row : sheet) {
                int index = 0;
                List<String> rowDataList = new ArrayList<>();
//                List<ContactModel.PhoneNumber> phoneNumberList = new ArrayList<>();

                if (row.getRowNum() > 0) {
                    // Iterate through all the columns in a row (Excluding header row)
                    Iterator<Cell> cellIterator = row.cellIterator();

                    while (cellIterator.hasNext()) {
                        Cell cell = cellIterator.next();
                        // Check cell type and format accordingly

//                        rowDataList.add(index, cell.getStringCellValue());
//                        index++;
                        switch (cell.getCellType()) {
                            case Cell.CELL_TYPE_NUMERIC:

                                break;
                            case Cell.CELL_TYPE_STRING:
                                rowDataList.add(index, cell.getStringCellValue());
                                index++;
                                break;
                        }
                    }

                    // Adding cells with phone numbers to phoneNumberList
//                    for (int i = 1; i < rowDataList.size(); i++) {
//                        phoneNumberList.add(new ContactResponse.PhoneNumber(rowDataList.get(i)));
//                    }

                    ContactModel contactModel = new ContactModel();
                    if(rowDataList.size()>0 && rowDataList.get(0)!=null) contactModel.setMContactName(rowDataList.get(0));
                    if(rowDataList.size()>1 && rowDataList.get(1)!=null) contactModel.setMNumber(rowDataList.get(1));
                    if(rowDataList.size()>2 && rowDataList.get(2)!=null) contactModel.setMEmail(rowDataList.get(2));
                    if(rowDataList.size()>3 && rowDataList.get(3)!=null) contactModel.setMDOB(rowDataList.get(3));

                    importedExcelData.add(contactModel);
                }

            }

        } catch (IOException e) {
            Log.e(TAG, "Error Reading Exception: ", e);

        } catch (Exception e) {
            Log.e(TAG, "Failed to read file due to Exception: ", e);

        } finally {
            try {
                if (null != fileInputStream) {
                    fileInputStream.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return importedExcelData;
    }

}
