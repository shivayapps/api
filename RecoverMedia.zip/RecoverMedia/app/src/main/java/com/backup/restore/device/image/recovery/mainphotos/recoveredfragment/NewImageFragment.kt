package com.backup.restore.device.image.recovery.mainphotos.recoveredfragment

import android.os.*
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.databinding.FragmentRecoveredImageVideoBinding
import com.backup.restore.device.image.recovery.mainphotos.activity.RecoveredImageActivity
import com.backup.restore.device.image.recovery.mainphotos.recoverdadapter.RecoveredImageAdapter
import com.backup.restore.device.image.recovery.utilities.SPAN_COUNT_THREE
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.ImageArray
import com.backup.restore.device.image.recovery.utilities.getExtension

import com.backup.restore.device.image.recovery.utilities.getGridCount


import java.io.File

class NewImageFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    var mainCommonAdapter: RecoveredImageAdapter? = null
    var isVisibleHint: Boolean = false
    private var path = ""
    var isForSort = "date_asc"
    var mSavedPhotos: ArrayList<File> = ArrayList()
    var isImageRecover = true

    fun NewImageFragment() {
    }

    companion object {
        fun newInstance(): NewImageFragment {
            val fragment = NewImageFragment()
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isAdded) {
            isVisibleHint = isVisibleToUser
            Log.e(mTAG, "setUserVisibleHint: same$isVisibleToUser")
            if (isVisibleHint) {
                if (isImageRecover) {
                    isImageRecover = false
                    mSavedPhotos.clear()
                    if (binding.deletedFilesRecoveredImageVideo != null && binding.tvRecoveredAlbum != null) {
                        mainCommonAdapter = RecoveredImageAdapter(
                            requireActivity(),
                            mSavedPhotos,
                            binding.deletedFilesRecoveredImageVideo,
                            binding.tvRecoveredAlbum,
                            (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll
                        )
                        binding.deletedFilesRecoveredImageVideo.adapter = mainCommonAdapter
                    }
                    GetRecoveredAlbum().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                }
//                else {
                Log.e(mTAG, "setUserVisibleHint: size" + mSavedPhotos.size)
                if (mSavedPhotos.size <= 0) {
                    if (binding.tvRecoveredAlbum != null) binding.tvRecoveredAlbum.visibility =
                        View.VISIBLE
                    if (binding.deletedFilesRecoveredImageVideo != null) binding.deletedFilesRecoveredImageVideo.visibility =
                        View.GONE
                    (requireActivity() as RecoveredImageActivity).unSelectAll()
                    if ((requireActivity() as RecoveredImageActivity).binding.ivDeleteAll != null) {
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha =
                            0.5f
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled =
                            false
                    }
                    if ((requireActivity() as RecoveredImageActivity).binding.ivSpan != null) {
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 0.5F
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled =
                            false
                    }
                } else {
                    if (binding.tvRecoveredAlbum != null) binding.tvRecoveredAlbum.visibility =
                        View.GONE
                    if (binding.deletedFilesRecoveredImageVideo != null) binding.deletedFilesRecoveredImageVideo.visibility =
                        View.VISIBLE

                    (requireActivity() as RecoveredImageActivity).selectTop(3)

                    if ((requireActivity() as RecoveredImageActivity).binding.ivDeleteAll != null) {
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha =
                            1.0f
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled =
                            true
                    }
                    if ((requireActivity() as RecoveredImageActivity).binding.ivSpan != null) {
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 1.0F
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled =
                            true
                    }

                    Log.e(mTAG, "setUserVisibleHint: isForSort:" + isForSort)
                    when (isForSort) {
                        "size_asc" -> {
                            (requireActivity() as RecoveredImageActivity).selectSizeAsc()
                            (requireActivity() as RecoveredImageActivity).isDateClick = true
                            (requireActivity() as RecoveredImageActivity).isSizeClick = false
                        }

                        "size_desc" -> {
                            (requireActivity() as RecoveredImageActivity).selectSizeDesc()
                            (requireActivity() as RecoveredImageActivity).isDateClick = true
                            (requireActivity() as RecoveredImageActivity).isSizeClick = false
                        }

                        "date_desc" -> {
                            (requireActivity() as RecoveredImageActivity).selectDateDesc()
                            (requireActivity() as RecoveredImageActivity).isDateClick = false
                            (requireActivity() as RecoveredImageActivity).isSizeClick = true
                        }

                        "date_asc" -> {
                            (requireActivity() as RecoveredImageActivity).selectTop(3)
                            (requireActivity() as RecoveredImageActivity).isDateClick = false
                            (requireActivity() as RecoveredImageActivity).isSizeClick = true
                        }
                    }
                }

                mainCommonAdapter = RecoveredImageAdapter(
                    requireActivity(),
                    mSavedPhotos,
                    binding.deletedFilesRecoveredImageVideo,
                    binding.tvRecoveredAlbum,
                    (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll
                )
                binding.deletedFilesRecoveredImageVideo.adapter = mainCommonAdapter
//                }
                (requireActivity() as RecoveredImageActivity).binding.ivSpan?.isSelected =
                    requireActivity().getGridCount() == SPAN_COUNT_THREE
                binding.deletedFilesRecoveredImageVideo?.layoutManager =
                    GridLayoutManager(requireActivity(), requireActivity().getGridCount())
            }
        }
    }

    //    lateinit var mView: View
    lateinit var binding: FragmentRecoveredImageVideoBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
//        mView = inflater.inflate(R.layout.fragment_recovered_image_video, container, false)
        binding = FragmentRecoveredImageVideoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_image)
        binding.tvNotFound.setText(R.string.image_not_found)
        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        path = "${ShareConstants.mRootPath}/RecoverMedia/Image/"


    }

    override fun onClick(view: View) {

    }

    override fun onPause() {
        super.onPause()
    }


    override fun onResume() {
        super.onResume()
        Log.e(mTAG, "onResume: $isVisibleHint")

        if (RecoveredImageActivity.isRefresh) {
            GetRecoveredAlbum().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
            RecoveredImageActivity.isRefresh = false
        }


    }

    private inner class GetRecoveredAlbum : AsyncTask<String?, String?, String?>() {

        override fun onPreExecute() {
            super.onPreExecute()
            if (isAdded) {
                if (binding.lotties != null) {
                    binding.lotties.visibility = View.VISIBLE
                }
            }
            if (isAdded && activity != null) {
                (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll.isEnabled = false
                (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll.alpha = 0.5F
                (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 0.5F
                (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled = false
            }
            mSavedPhotos.clear()
        }

        override fun doInBackground(vararg strings: String?): String? {
            mSavedPhotos.clear()
            val dir = File(path)
            val lListOfFiles = dir.listFiles()
            if (lListOfFiles != null) {
                var i: Long = 0;
                for (file in lListOfFiles) {
                    val lExtension = getExtension(file.name)
                    if (ImageArray.contains(lExtension) && file.name.endsWith(lExtension)) {
                        mSavedPhotos.add(i.toInt(), file)
                        i++
                    }
                }
            }
            if (isAdded && activity != null) {
                activity?.runOnUiThread {
                    Handler(Looper.getMainLooper()).post {
                        Log.e(mTAG, "gridRecoverableAlbumImage: " + mSavedPhotos.size)
                        mainCommonAdapter?.notifyDataSetChanged()
                    }
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)

            try {
                Handler(Looper.getMainLooper()).post {
                    if (isAdded) {

                        if (mSavedPhotos.size <= 0) {
                            if (binding.tvRecoveredAlbum != null) binding.tvRecoveredAlbum.visibility =
                                View.VISIBLE
                            if (binding.deletedFilesRecoveredImageVideo != null) binding.deletedFilesRecoveredImageVideo.visibility =
                                View.GONE
                            Log.e(mTAG, "onPostExecute: size 0000 ")
                            (requireActivity() as RecoveredImageActivity).unSelectAll()
                            if ((requireActivity() as RecoveredImageActivity).binding.ivDeleteAll != null) {
                                (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha =
                                    0.5f
                                (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled =
                                    false
                            }
                            if ((requireActivity() as RecoveredImageActivity).binding.ivSpan != null) {
                                (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha =
                                    0.5F
                                (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled =
                                    false
                            }
                        } else {
                            if (binding.tvRecoveredAlbum != null) binding.tvRecoveredAlbum.visibility =
                                View.GONE
                            if (binding.deletedFilesRecoveredImageVideo != null) binding.deletedFilesRecoveredImageVideo.visibility =
                                View.VISIBLE
                            (requireActivity() as RecoveredImageActivity).selectTop(3)
                            if ((requireActivity() as RecoveredImageActivity).binding.ivDeleteAll != null) {
                                (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha =
                                    1.0f
                                (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled =
                                    true
                            }
                            if ((requireActivity() as RecoveredImageActivity).binding.ivSpan != null) {
                                (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha =
                                    1.0F
                                (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled =
                                    true
                            }
                        }
//                    Collections.sort(mSavedPhotos, ShareConstants.RecoveredDateAscending())

                        mainCommonAdapter!!.notifyDataSetChanged()
                    }
                }

                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    if (isAdded) {
                        try {
                            binding.lotties.visibility = View.GONE
                        } catch (e: Exception) {
                        }
                    }
                }, 500)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}