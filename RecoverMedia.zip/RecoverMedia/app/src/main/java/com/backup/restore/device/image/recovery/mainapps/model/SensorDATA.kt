package com.backup.restore.device.image.recovery.mainapps.model

class SensorDATA(var sensorName: String, var sensorType: Int){
}