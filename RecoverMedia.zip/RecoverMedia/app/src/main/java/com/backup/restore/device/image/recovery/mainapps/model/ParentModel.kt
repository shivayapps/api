package com.backup.restore.device.image.recovery.mainapps.model

import java.util.*

data class ParentModel(
    val title: String = "",
    val lists: ArrayList<FeaturesHW> = ArrayList<FeaturesHW>()
)