package com.backup.restore.device.image.recovery.utilities.common

import android.app.Activity
import com.backup.restore.device.image.recovery.ads.rateandfeedback.*

object RatingDialog {
    fun smileyRatingDialog(activity: Activity) {
        val isRated = ExitSPHelper(activity).isRated()
        if (!isRated) {
            activity.ratingDialog(object : OnRateListener {
                override fun onRate(rate: Int) {
                    if (rate >= 4) {
                        activity.rateApp()
                    } else if (rate >= 0) {
                        activity.ratingFeedback(rate)
//                        val i = Intent(activity, FeedbackActivity::class.java)
//                        i.putExtra("key_smile", rate)
//                        activity.startActivity(i)
                    }
                }
            })
        }
    }
}