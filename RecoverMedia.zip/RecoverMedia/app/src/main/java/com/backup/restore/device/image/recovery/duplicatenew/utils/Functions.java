package com.backup.restore.device.image.recovery.duplicatenew.utils;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Functions {

    public static void showToastMsg(Context context, String str) {
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }


    public static String getSDCardPath(Context context) {
        File file1 = new File(Constants.SDCARD1);
        File file2 = new File(Constants.SDCARD2);
        File file3 = new File(Constants.SDCARD3);
        File file4 = new File(Constants.SDCARD4);
        File file5 = new File(Constants.SDCARD5);
        File file6 = new File(Constants.SDCARD6);

        if (file1.exists()) {
            return String.valueOf(file1);
        }
        if (file2.exists()) {
            return String.valueOf(file2);
        }
        if (file3.exists()) {
            return String.valueOf(file3);
        }
        if (file4.exists()) {
            return String.valueOf(file4);
        }
        if (file5.exists()) {
            return String.valueOf(file5);
        }
        if (file6.exists()) {
            return String.valueOf(file6);
        }

        return getSD_CardPath_M(context);
    }


    public static String getSD_CardPath_M(Context context) {
        String[] externalStoragePath = getExternalStorageDirectories(context);
        if (externalStoragePath.length == 0) {
            return null;
        }
        return externalStoragePath[0] + "/";
    }

    public static String[] getExternalStorageDirectories(Context context) {
        int i;
        List<String> results = new ArrayList();
        try {
            for (File file : context.getExternalFilesDirs(null)) {
                boolean addPath;
                String path = file.getPath().split("/Android")[0];
                addPath = Environment.isExternalStorageRemovable(file);
                if (addPath) {
                    results.add(path);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        int i2;
        if (Build.VERSION.SDK_INT >= 23) {
            i = 0;
            while (i < results.size()) {
                if (!results.get(i).toLowerCase().matches(".*[0-9a-f]{4}[-][0-9a-f]{4}")) {
                    Log.d("ReadingAllFiles", ((String) results.get(i)) + " might not be extSDcard");
                    i2 = i - 1;
                    results.remove(i);
                    i = i2;
                }
                i++;
            }
        } else {
            i = 0;
            while (i < results.size()) {
                if (!(results.get(i).toLowerCase().contains("ext") ||
                        results.get(i).toLowerCase().contains("sdcard"))) {
                    Log.d("ReadingAllFiles", results.get(i) + " might not be extSDcard");
                    i2 = i - 1;
                    results.remove(i);
                    i = i2;
                }
                i++;
            }
        }
        String[] storageDirectories = new String[results.size()];
        for (i = 0; i < results.size(); i++) {
            storageDirectories[i] = results.get(i);
        }
        return storageDirectories;
    }


}
