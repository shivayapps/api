package com.backup.restore.device.image.recovery.mainduplicate.asynctask;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.duplicatenew.models.DuplicateGroupModel;
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails;
import com.backup.restore.device.image.recovery.mainduplicate.callbacks.MarkedListener;
import com.backup.restore.device.image.recovery.mainduplicate.model.PopUp;
import com.backup.restore.device.image.recovery.utilities.MyAnnotations;
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions;
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants;

import java.util.ArrayList;
import java.util.List;


public class DeleteDuplicateMediaAsyncTask extends AsyncTask<Void, Void, Void> {

    Activity deleteActivity;
    Context deleteContext;

    long deleteFileSize;
    int FileDeletingCount = 0;
    ArrayList<FileDetails> fileToBeDeleted;
    List<DuplicateGroupModel> groupOfDuplicates;
    MarkedListener mMarkedListener;
    String message;
    String mIsType;
    List<DuplicateGroupModel> listOfGroup = new ArrayList<>();


    public DeleteDuplicateMediaAsyncTask(String isType, Context context, Activity activity, MarkedListener imagesMarkedListener, String messages, ArrayList<FileDetails> fileToDeletedList, long deletingFileSize, List<DuplicateGroupModel> groupOfDuplicatesList) {
        mIsType = isType;
        deleteContext = context;
        deleteActivity = activity;
        mMarkedListener = imagesMarkedListener;
        message = messages;
        fileToBeDeleted = fileToDeletedList;
        deleteFileSize = deletingFileSize;
        groupOfDuplicates = groupOfDuplicatesList;
        if (fileToDeletedList != null) {
            FileDeletingCount = fileToDeletedList.size();
        }
    }

    protected void onPreExecute() {
        super.onPreExecute();

    }

    protected Void doInBackground(Void... params) {
        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition:doInBackground:" + fileToBeDeleted.size());
        if (fileToBeDeleted != null) {
            deletePhotosByPosition();
        }
        return null;
    }

    private void deletePhotosByPosition() {

        List<FileDetails> listOfFilesToBeDeleted = fileToBeDeleted;
        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition:fromAsync");
        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition-listOfFilesToBeDeleted:" + listOfFilesToBeDeleted.size());
//        Log.e("GlobalVarsAndFunctions", "deletePhotosByPosition-groupOfDuplicatesLocal:" + groupOfDuplicatesLocal.size());

        for (int i = 0; i < listOfFilesToBeDeleted.size(); i++) {
            FileDetails imageItem = listOfFilesToBeDeleted.get(i);
            GlobalVarsAndFunctions.deleteFile(deleteActivity, deleteContext, imageItem.getFilePath());
        }

        listOfGroup=GlobalVarsAndFunctions.listOfDuplicates;

        for (int i = 0; i < listOfGroup.size(); i++) {
            for (int j = 0; j < listOfGroup.get(i).getIndividualGrpOfDupes().size(); j++) {
                FileDetails imageItem = listOfGroup.get(i).getIndividualGrpOfDupes().get(j);
                if(imageItem.isChecked()) {
                    GlobalVarsAndFunctions.listOfDuplicates.get(i).getIndividualGrpOfDupes().remove(j);
                    GlobalVarsAndFunctions.deleteFile(deleteActivity, deleteContext, imageItem.getFilePath());
                }
            }
        }
    }


    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        switch (mIsType) {
            case MyAnnotations.IMAGES:
                setImageDuplicateAdapterWithData(mMarkedListener);
                new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.photos_cleaned_single) + FileDeletingCount : deleteContext.getString(R.string.photos_cleaned) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                break;
            case MyAnnotations.VIDEOS:
                setVideoDuplicateAdapterWithData(mMarkedListener);
                new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.videos_cleaned_single) + FileDeletingCount : deleteContext.getString(R.string.videos_cleaned) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                break;
            case MyAnnotations.AUDIOS:
                setAudioDuplicateAdapterWithData(mMarkedListener);
                new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.audios_cleaned_single) + FileDeletingCount : deleteContext.getString(R.string.audios_cleaned) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                break;
            case MyAnnotations.DOCUMENTS:
                setDocumentDuplicateAdapterWithData(mMarkedListener);
                new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.documents_cleaned_single) + FileDeletingCount : deleteContext.getString(R.string.documents_cleaned) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                break;
            case MyAnnotations.OTHER:
                setOtherDuplicateAdapterWithData(mMarkedListener);
                new PopUp(deleteContext, deleteActivity).showSpaceRecoveredPopUp(mIsType, FileDeletingCount == 1 ? deleteContext.getString(R.string.others_cleaned_single) + FileDeletingCount : deleteContext.getString(R.string.others_cleaned) + FileDeletingCount, deleteContext.getString(R.string.space_regained) + ShareConstants.getReadableFileSize(deleteFileSize), mMarkedListener, FileDeletingCount);
                break;
        }

    }

    private void setImageDuplicateAdapterWithData(MarkedListener mMarkedListener) {
        mMarkedListener.updatePageDetails(null, null, 0, null);

//        AdapterDuplicate individualPhotosAdapter = new AdapterDuplicate(deleteContext, mMarkedListener, MyAnnotations.IMAGES);
//        if (NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp != null) {
//            NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp.setAdapter(individualPhotosAdapter);
//        }
//        individualPhotosAdapter.notifyDataSetChanged();
    }

    private void setVideoDuplicateAdapterWithData(MarkedListener mMarkedListener) {
        mMarkedListener.updatePageDetails(null, null, 0, null);

//        AdapterDuplicate individualPhotosAdapter = new AdapterDuplicate(deleteContext, mMarkedListener, MyAnnotations.VIDEOS);
//        if (NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp != null) {
//            NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp.setAdapter(individualPhotosAdapter);
//        }
//        individualPhotosAdapter.notifyDataSetChanged();
    }


    private void setAudioDuplicateAdapterWithData(MarkedListener mMarkedListener) {
        mMarkedListener.updatePageDetails(null, null, 0, null);

//        AdapterDuplicate individualPhotosAdapter = new AdapterDuplicate(deleteContext, mMarkedListener, MyAnnotations.AUDIOS);
//        if (NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp != null) {
//            NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp.setAdapter(individualPhotosAdapter);
//        }
//        individualPhotosAdapter.notifyDataSetChanged();
    }


    private void setDocumentDuplicateAdapterWithData(MarkedListener mMarkedListener) {
        mMarkedListener.updatePageDetails(null, null, 0, null);

//        AdapterDuplicate individualPhotosAdapter = new AdapterDuplicate(deleteContext, mMarkedListener, MyAnnotations.DOCUMENTS);
//        if (NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp != null) {
//            NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp.setAdapter(individualPhotosAdapter);
//        }
//        individualPhotosAdapter.notifyDataSetChanged();
    }


    private void setOtherDuplicateAdapterWithData(MarkedListener mMarkedListener) {
        mMarkedListener.updatePageDetails(null, null, 0, null);

//        AdapterDuplicate individualPhotosAdapter = new AdapterDuplicate(deleteContext, mMarkedListener, MyAnnotations.OTHER);
//        if (NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp != null) {
//            NewDuplicateMediaActivityNEW.recyclerViewForIndividualGrp.setAdapter(individualPhotosAdapter);
//        }
//        individualPhotosAdapter.notifyDataSetChanged();
    }


}
