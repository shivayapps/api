package com.backup.restore.device.image.recovery.main

//import com.example.appcenter.MoreAppsActivity
import android.Manifest.permission.*
import android.app.AlertDialog
import android.app.Dialog
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentActivity
import com.adconfig.AdsConfig
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.backup.restore.device.image.recovery.*
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.*
import com.backup.restore.device.image.recovery.duplicatenew.ActivityDuplicateFileScanner
import com.backup.restore.device.image.recovery.junckcleaner.activities.JunkActivity
import com.backup.restore.device.image.recovery.mainapps.activity.*
import com.backup.restore.device.image.recovery.maincontact.activity.ContactMainActivity
import com.backup.restore.device.image.recovery.mainduplicate.activity.scanningactivities.*
import com.backup.restore.device.image.recovery.service.ManagerService
import com.backup.restore.device.image.recovery.utilities.*
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.*
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.adconfig.adsutil.admob.NativeLayoutType
import com.adconfig.adsutil.admob.NativeAdHelper
import com.backup.restore.device.image.recovery.databinding.ActivityHomeBinding
import com.example.jdrodi.callback.RVClickListener
import com.example.jdrodi.utilities.*
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener


class HomeRecoverActivity : MyCommonBaseActivity() {

    var mTAG = javaClass.simpleName

    val mPermissionStorage = arrayOf(READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE)
    var mPermissionDuplicate: Array<String>? = null

    private var backupClick: Info? = null
    var rotation: Animation? = null
    var isExiting: Boolean = false

    //    private var mNetworkReceiver: BroadcastReceiver? = null
//    var mInterstitialAd: InterstitialAd? = null

    companion object {
        fun newIntent(mContext: Context): Intent {
            return Intent(
                mContext,
                HomeRecoverActivity::class.java
            )
//                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(null)
//        setContentView(R.layout.activity_new_home)
        binding=ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        SharedPrefsConstant.save(mContext, APP_RUN_COUNT, SharedPrefsConstant.getInt(mContext, APP_RUN_COUNT) + 1)

        SharedPrefsConstant.savePrefNoti(mContext, "IsFromService", false)


    }

    override fun getContext(): AppCompatActivity {
        return this@HomeRecoverActivity
    }

    override fun initActions() {
//        iv_more_apps.setOnClickListener(this)
//        binding.ivShare.setOnClickListener(this)
//        binding.ivRemoveAd.setOnClickListener(this)
        binding.ivSetting.setOnClickListener(this)
        binding.relBlock.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)
//        junkCleaner.setOnClickListener{
//            backupClick = Info(R.string.cleaner, R.drawable.ic_cleaner, Type.CLEANER)
//            manageClick()
//        }

    }

    override fun initAds() {

//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            InAppPurchaseHelper.instance!!.initBillingClient(mContext, this)
////            binding.ivRemoveAd.visibility = View.VISIBLE
//            rotation = AnimationUtils.loadAnimation(this, R.anim.shake_anim)
//            rotation!!.repeatCount = Animation.ABSOLUTE
////            binding.ivRemoveAd.startAnimation(rotation)
//        } else {
//            removeAds()
//        }
    }

    var backupAdapter: MainBackupAdapter? = null
//    var informationAdapter: MainBackupAdapter? = null
//    var duplicateAdapter: MainBackupAdapter? = null

    override fun initData() {

        mPermissionDuplicate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            arrayOf(WRITE_CONTACTS, READ_CONTACTS)
        } else {
            arrayOf(READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE, WRITE_CONTACTS, READ_CONTACTS)
        }

        binding.homeTvTitle.text = getString(R.string.main_lable)
//        binding.txtLabel.text = getString(R.string.main_lable)
        val backupOptions = getBackupOptions()
        backupAdapter = MainBackupAdapter(
            mContext,
            R.layout.raw_main_screen_item,
            backupOptions,
            object : RVClickListener {
                override fun onItemClick(position: Int) {
                    backupClick = backupOptions[position]
                    manageClick()
                }
            })
        binding.homeRv.addItemDecoration(RvGridSpacingItemDecoration(2, 6, true))
        binding.homeRv.adapter = backupAdapter

    }

    private fun manageClick() {

        if (backupClick != null && !isExiting) {
            when (backupClick!!.type) {
                Type.CONTACTS -> {
                    checkPermissions(mPermissionDuplicate!!)
                }
                Type.DUPLICATECONTACT -> {
                    checkPermissions(mPermissionDuplicate!!)
                }
                Type.SHARE -> {
                    shareApp()
                }
                else -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        checkAllFilePermission()
                    } else {
                        checkPermissions(mPermissionStorage)
                    }
                }
            }
        }
    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                goToNextActivity()
            } else {

                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 2296)
                } catch (e: ActivityNotFoundException) {
                }
            }
        }
    }


    override fun onClick(view: View) {

        if (SystemClock.elapsedRealtime() - mLastClickTime < 3000) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()


        when (view) {
//            binding.ivShare -> {
//                shareApp()
//            }
//            junkCleaner -> {
//                backupClick = Info(R.string.cleaner, R.drawable.ic_cleaner, Type.CLEANER)
//                manageClick()
//            }
            binding.ivBack -> {
                onBackPressed()
            }
            binding.ivSetting -> {
                startActivity(Intent(mContext, SettingActivity::class.java))
//                startActivityForResult(Intent(mContext, SettingActivity::class.java), 229)
            }
//            binding.ivRemoveAd -> {
//                startActivityForResult(Intent(mContext, InAppActivity::class.java), 555)
//            }
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
        setResult(RESULT_OK)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//        MyApplication.isExit = true
//        displayExitDialog()
    }

    private fun displayExitDialog() {
        val sp = ExitSPHelper(this)
        if (!sp.isRated() && sp.getExitCount() >= rateDialogCount && !sp.isDismissed()) {
            ratingDialog(object : OnRateListener {
                override fun onRate(rate: Int) {
                    if (rate >= 4) {
                        rateApp()
                    } else if (rate >= 0) {
                        ratingFeedback(rate)
                    }
                }
            })
        } else {
            exitDialog()
        }
    }

    private fun exitDialog() {
        try {
//        val inflater = (this as Activity).layoutInflater
            val alertLayout = LayoutInflater.from(this).inflate(R.layout.dialog_exit, null)
            val tvTitle = alertLayout.findViewById<TextView>(R.id.exit_tv_title)
            val tvDesc = alertLayout.findViewById<TextView>(R.id.exit_tv_desc)
            val btnNo = alertLayout.findViewById<TextView>(R.id.exit_btn_no)
            val btnYes = alertLayout.findViewById<TextView>(R.id.exit_btn_yes)
            val tf = Typeface.createFromAsset(assets, fontPath)
            val tfBold = Typeface.createFromAsset(assets, fontPathBold)
            tvTitle.typeface = tfBold
            tvDesc.typeface = tf
            btnNo.typeface = tf
            btnYes.typeface = tf

            val adContainer = alertLayout.findViewById<FrameLayout>(R.id.adview)
            val alert = AlertDialog.Builder(this)
            alert.setView(alertLayout)
            alert.setCancelable(false)
            val dialog = alert.create()
            btnNo.setOnClickListener {
                dialog.dismiss()
                binding.relBlock.visibility=View.GONE
                MyApplication.isExit = false
            }
            btnYes.setOnClickListener {

                ExitSPHelper(this).updateExitCount()
                dialog.dismiss()
//            MyApplication.isInternalCall = false
//            isInterstitialShown = true
                binding.relBlock.visibility=View.VISIBLE
                nextScreen()
            }
            binding.relBlock.visibility=View.VISIBLE
            dialog.show()

//            if (AdsManager(this).isNeedToShowAds() && NetworkManager.isInternetConnected(this)) {
//            loadNativeAdvance(adContainer)
                NativeAdHelper(this,adContainer, NativeLayoutType.NativeMedium,getString(R.string.native_application)).loadAd()
//            }

        } catch (ignored: Exception) {
            Log.e(
                com.backup.restore.device.image.recovery.ads.rateandfeedback.mTAG,
                ignored.toString()
            )
        }
    }

    fun nextScreen() {
        val activity: FragmentActivity = this as FragmentActivity
//        if (AdsManager(activity).isNeedToShowAds()) {
            isExiting = true
            AdsConfig.showInterstitialAd(mContext,{
                redirectNextActivity(activity)
            })
//        } else {
//            redirectNextActivity(activity)
//        }
    }

    private fun redirectNextActivity(activity: FragmentActivity) {
        val i = Intent(activity, ExitActivity::class.java)
        startActivity(i)
    }

    private fun removeAds() {

//        if (!AdsManager(mContext).isNeedToShowAds()) {
////            moreAppView.visibility = View.GONE
//            binding.ivRemoveAd.visibility = View.GONE
//            binding.ivShare.visibility = View.VISIBLE
//        } else {
////            moreAppView.visibility = View.VISIBLE
//            binding.ivRemoveAd.visibility = View.VISIBLE
//            binding.ivShare.visibility = View.GONE
//        }

    }

    private fun checkPermissions(permissions: Array<String>) {

        MyApplication.isInternalCall = true

        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                goToNextActivity()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            Toast.makeText(
                                mContext,
                                getString(R.string.permission_required),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: List<PermissionRequest>,
                    token: PermissionToken
                ) {
                    token.continuePermissionRequest()
                }
            }).check()


    }

    private fun startServiceMethod() {
        try {
            if (!isMyServiceRunning(mContext, ManagerService::class.java)) {
                ManagerService.setData(mContext)
                startService(Intent(this, ManagerService::class.java))
            }
        } catch (e: java.lang.Exception) {
            Log.e(mTAG, "startServiceMethod: " + e.message)
            e.printStackTrace()
        }
    }


    private fun goToNextActivity() {

//        startServiceMethod()
        if (SystemClock.elapsedRealtime() - mLastClickTime < 800) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()

        if (backupClick != null && !isExiting) {
            when (backupClick!!.type) {

                Type.FEEDBACK -> {
                    startActivity(Intent(mContext, FeedbackActivity::class.java))
                }
//                Type.PICTURE_BACKUP -> {
//                    startActivity(Intent(this, ProgressbarActivity::class.java));
//                }

                Type.BACKUP_TRASH -> {
                    val intent1=Intent(this, ProgressbarActivity::class.java)
                    intent1.putExtra("backupClick",1)
                    startActivity(intent1);
                }
                Type.BACKUP_RECOVERABLE -> {
                    val intent2=Intent(this, ProgressbarActivity::class.java)
                    intent2.putExtra("backupClick",2)
                    startActivity(intent2);
                }
                Type.BACKUP_RECOVERED -> {
                    val intent3=Intent(this, ProgressbarActivity::class.java)
                    intent3.putExtra("backupClick",3)
                    startActivity(intent3);
                }
//                Type.APK -> {
////                    startActivity(Intent(mContext, AppsBackupActivity::class.java))
//                    startActivity(Intent(mContext, AppManagerActivity::class.java))
//                }
                Type.CONTACTS -> {
                    startActivity(Intent(mContext, ContactMainActivity::class.java))
                }
                Type.PICTURE -> {
                    val intent = Intent(mContext, ActivityDuplicateFileScanner::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.IMAGES)
                    intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                }
                Type.VIDEO -> {
                    val intent = Intent(mContext, ActivityDuplicateFileScanner::class.java)
//                    val intent = Intent(mContext, DuplicateVideosActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.VIDEOS)
                    intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                }
                Type.AUDIO -> {
                    val intent = Intent(mContext, ActivityDuplicateFileScanner::class.java)
//                    val intent = Intent(mContext, DuplicateAudiosActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.AUDIOS)
                    intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                }
                Type.DOCUMENT -> {
                    val intent = Intent(mContext, ActivityDuplicateFileScanner::class.java)
//                    val intent = Intent(mContext, DuplicateDocumentsActivity::class.java)
                    intent.putExtra( MyAnnotations.DATA_TYPE, MyAnnotations.DOCUMENTS)
                    intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                }
                Type.OTHER -> {
                    val intent = Intent(mContext, ActivityDuplicateFileScanner::class.java)
//                    val intent = Intent(mContext, DuplicateOthersActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.OTHER)
                    intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                }
                Type.EMPTYFOLDER -> {
                    startActivity(
                        Intent(
                            mContext,
                            EmptyFolderScanningActivity::class.java
                        ).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    )
                }
                Type.DUPLICATECONTACT -> {
                    startActivity(
                        Intent(
                            mContext,
                            DuplicateContactScanningActivity::class.java
                        ).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    )
                }
                Type.CLEANER -> {
                    startActivity(Intent(mContext, JunkActivity::class.java))
                }
                else ->{

                }
            }
        }

    }

//    private fun startServiceMethod() {
//        try {
//            val intent = Intent(this@NewHomeActivity, RecoverImageService::class.java)
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                startForegroundService(intent)
//            } else {
//                startService(intent)
//            }
//        } catch (e: java.lang.Exception) {
//            Log.e(mTAG, "startServiceMethod: " + e.message)
//            e.printStackTrace()
//        }
//    }

    fun showSettingsDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_permission)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
            openSettings()
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            MyApplication.isDialogOpen = false
            dialog.cancel()
        }
        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }
        dialog.show()
        MyApplication.isDialogOpen = true
    }

    private fun openSettings() {
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", packageName, null)
        if (!isExiting) {
            when (backupClick!!.type) {
                Type.CONTACTS -> {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 202)
                }
                Type.DUPLICATECONTACT -> {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 202)
                }
                else -> {
                    MyApplication.isInternalCall = true
                    startActivityForResult(intent, 200)
                }
            }
        }
    }


//    override fun onPurchasedSuccess(purchase: Purchase) {
//        SharedPrefsConstant.savePref(this, IS_ADS_REMOVED, true)
//        showPurchaseSuccess()
//        initAds()
//        removeAds()
//    }
//
//    override fun onProductAlreadyOwn() {
//        SharedPrefsConstant.savePref(this, IS_ADS_REMOVED, true)
//        showPurchaseSuccess()
//        initAds()
//        removeAds()
//    }
//
//    override fun onBillingSetupFinished(billingResult: BillingResult) {
//
//    }
//
//    override fun onBillingUnavailable() {
//        initAds()
//        removeAds()
//    }
//
//    override fun onBillingKeyNotFound(productId: String) {
//
//    }

    override fun onResume() {
        super.onResume()
        SharedPrefsConstant.savePrefNoti(this@HomeRecoverActivity, "isDeleteFromEmpty", false)
        Log.e("UtilsKT", "onResume:HomeActivity")
//        val locale = Locale(SharedPrefsConstant.getString(this, SELECTED_LANGUAGE, "en")!!)
//        val config = this.resources.configuration

//        if(config.locale != locale) {
//            config.locale = locale
//            Locale.setDefault(locale)
//            resources.updateConfiguration(config, this.resources.displayMetrics)
//            recreate()
//        }

        //InitApkData(this@NewHomeActivity, RepositoryStorage(application)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        //InitTempData(this@NewHomeActivity, RepositoryStorage(application)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        //InitEmptyData(this@NewHomeActivity, RepositoryStorage(application)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        //InitTrashData(this@NewHomeActivity, RepositoryStorage(application)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
        //InitUninstalledData(this@NewHomeActivity, RepositoryStorage(application)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
//        startServiceMethod()

    }

//    class NetworkChangeReceiver : BroadcastReceiver() {
//        override fun onReceive(context: Context, intent: Intent?) {
//            try {
//                if (NetworkManager.isInternetConnected(context)) {
//                    moreAppsView.initData()
//
//                    Log.e(TAG, "onReceive: connect")
//                } else {
//
//                    Log.e(TAG, "onReceive: not connect")
//                }
//            } catch (e: NullPointerException) {
//                e.printStackTrace()
//            }
//        }
//    }

    override fun onDestroy() {
        super.onDestroy()
//        unregisterReceiver(mNetworkReceiver)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        SharedPrefsConstant.savePrefNoti(this@HomeRecoverActivity, "isDeleteFromEmpty", false)
        if (requestCode == 229) {
            if (SharedPrefsConstant.getBoolean(mContext, "isLocaleChanged", false)) {
                SharedPrefsConstant.savePref(mContext, "isLocaleChanged", false)

                binding.homeTvTitle.text = getString(R.string.main_lable)
                backupAdapter?.notifyDataSetChanged()

//                moreAppView.setTitle(getString(R.string.more_app))
//                changeLanguageNew()

            }
        } else if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    goToNextActivity()
                    Log.e(mTAG, "onActivityResult: Service Start ")
                } else {
                    Toast.makeText(
                        mContext,
                        getString(R.string.permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    goToNextActivity()
                }
            } else {
                Toast.makeText(
                    mContext,
                    getString(R.string.permission_required),
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else if (requestCode == 202) {
            if (checkPermissionContact(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    goToNextActivity()
                }
            } else {
                Toast.makeText(
                    mContext,
                    getString(R.string.permission_required),
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else if (requestCode == 555) {
            removeAds()
        }
    }
}