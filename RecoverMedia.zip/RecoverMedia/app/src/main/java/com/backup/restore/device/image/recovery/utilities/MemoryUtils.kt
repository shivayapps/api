package com.backup.restore.device.image.recovery.utilities

import android.annotation.TargetApi
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants.getReadableFileSize
import java.io.File


// INTERNAL STORAGE
fun getTotalROMSize(): Long {
    val path: File = Environment.getDataDirectory()
    val stat = StatFs(path.path)
    val blockSize: Int = stat.blockSize
    val totalBlocks: Int = stat.blockCount
    return (totalBlocks * blockSize).toLong()
}

fun getAvailableROMSize(): Long {
    val path: File = Environment.getDataDirectory()
    val stat = StatFs(path.path)
    val blockSize: Int = stat.blockSize
    val availableBlocks: Int = stat.availableBlocks
    return (availableBlocks * blockSize).toLong()
}

fun getTotalSdCard(dirs: Array<File>,isReadable: Boolean=true): String {
    if(isReadable) return getReadableFileSize(getTotalExternalMemorySize(dirs))
    else return getTotalExternalMemorySize(dirs).toString()
}

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
fun getTotalExternalMemorySize(dirs: Array<File>): Long {
    return if (dirs.size > 1) {
        run {
            val stat = StatFs(dirs[1].path)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            totalBlocks * blockSize
        }
    } else {
        1
    }
}

fun getFreeSdCard(dirs: Array<File>,isReadable: Boolean=true): String {
    if(isReadable) return getReadableFileSize(getAvailableExternalMemorySize(dirs))
    else return getAvailableExternalMemorySize(dirs).toString()
}
@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
fun getAvailableExternalMemorySize(dirs: Array<File>): Long {
    return if (dirs.size > 1) {
        val stat = StatFs(dirs[1].path)
        val blockSize = stat.blockSizeLong
        val availableBlocks = stat.availableBlocksLong
        availableBlocks * blockSize
    } else {
        1
    }
}
fun getUsedSdCard(dirs: Array<File>,isReadable: Boolean=true): String {
    if(isReadable) return getReadableFileSize(getTotalExternalMemorySize(dirs)-getAvailableExternalMemorySize(dirs))
    else return (getTotalExternalMemorySize(dirs)-getAvailableExternalMemorySize(dirs)).toString()
}

fun getTotalROM(isReadable: Boolean=true): String {
    if(isReadable) return getReadableFileSize(getTotalROMSize())
    else return getTotalROMSize().toString()
}

fun getUsedROM(isReadable: Boolean=true): String {
    if(isReadable) return getReadableFileSize(getTotalROMSize() - getAvailableROMSize())
    else return (getTotalROMSize() - getAvailableROMSize()).toString()
}


fun getFreeROM(isReadable: Boolean=true): String {
    if(isReadable) return getReadableFileSize(getAvailableROMSize())
    else return getAvailableROMSize().toString()
}


// RAM
fun Context.getTotalRamMemorySize(): Long {
    val mi: ActivityManager.MemoryInfo = ActivityManager.MemoryInfo()
    val activityManager: ActivityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    activityManager.getMemoryInfo(mi)
    return mi.totalMem
}

fun Context.getAvailableRamMemorySize(): Long {
    val mi: ActivityManager.MemoryInfo = ActivityManager.MemoryInfo()
    val activityManager: ActivityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    activityManager.getMemoryInfo(mi)
    return mi.availMem
}


fun Context.getTotalRAM(isReadable: Boolean=true): String {
    if(isReadable) {
        return getReadableFileSize(getTotalRamMemorySize())
    } else {
        return getTotalRamMemorySize().toString()
    }
    //return getReadableFileSize(getTotalRamMemorySize())
}

fun Context.getUsedRAM(isReadable: Boolean=true): String {
    if(isReadable) {
        return getReadableFileSize(getTotalRamMemorySize() - getAvailableRamMemorySize())
    } else {
        return (getTotalRamMemorySize() - getAvailableRamMemorySize()).toString()
    }
    //return getReadableFileSize(getTotalRamMemorySize() - getAvailableRamMemorySize())
}

fun Context.getFreeRAM(isReadable: Boolean=true): String {
    if(isReadable) {
        return getReadableFileSize(getAvailableRamMemorySize())
    } else {
        return getAvailableRamMemorySize().toString()
    }
}


//fun getReadableFileSize(size: Long): String {
//    try {
//        if (size <= 0) return "0 KB"
//        val units = arrayOf("B", "KB", "MB", "GB", "TB")
//        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1000.0)).toInt()
//        return DecimalFormat("#,##0.##").format(size / Math.pow(1000.0, digitGroups.toDouble())) + " " + units[digitGroups]
//    } catch (e: Exception) {
//        e.printStackTrace()
//    }
//    return ""
//}

//fun formatReadableSize(size: Long): String {
//    if (size <= 0) return "0 KB"
//    val units = arrayOf("B", "kB", "MB", "GB", "TB")
//    val digitGroups = (log10(size.toDouble()) / log10(1024.0)).toInt()
//    return DecimalFormat("#,##0.##").format(size / 1024.0.pow(digitGroups.toDouble())).toString() + " " + units[digitGroups]
//}
