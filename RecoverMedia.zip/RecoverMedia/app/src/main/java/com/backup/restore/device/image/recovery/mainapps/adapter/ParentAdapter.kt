package com.backup.restore.device.image.recovery.mainapps.adapter

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ItemDecoration
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import java.util.*


class ParentAdapter(internal var appslist: List<ParentModel>, internal var mContext: Context) :
    RecyclerView.Adapter<ParentAdapter.DeviceVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ParentAdapter.DeviceVH {
        val itemView = LayoutInflater.from(mContext).inflate(R.layout.row_cpu_item, parent, false)
        return DeviceVH(itemView)
    }

    override fun onBindViewHolder(holder: ParentAdapter.DeviceVH, position: Int) {
        Log.e("CPUAdapter", "onBindViewHolder:position:" + position)
        holder.bindData(appslist[position], position)
    }

    override fun getItemCount(): Int = appslist.size

    inner class DeviceVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindData(parentModel: ParentModel, position: Int) {

            Log.e("CPUAdapter", "DeviceVH:featureHW:" + parentModel.lists.size)
            val tvTitle: TextView = itemView.findViewById(R.id.mTitle)
            val rvFeatureList: RecyclerView = itemView.findViewById(R.id.rv_cpu_feature_list)

            tvTitle.text = parentModel.title

            val listFeaturesHW = parentModel.lists
//            Collections.sort(
//                listFeaturesHW,
//                FeaturesSorter()
//            )
            val singleItem = getLargeCount(listFeaturesHW)
            val pairItem = getLengthCount(listFeaturesHW)

            Log.e("CPUAdapter", "singleItem:${singleItem.size}")
            Log.e("CPUAdapter", "pairItem:${pairItem.size}")

//            if(pairItem.size % 2!=0) {
//                listFeaturesHW.add(FeaturesHW("",""))
//            }

            val layoutManager = GridLayoutManager(mContext, 1)
//            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//                override fun getSpanSize(position: Int): Int {
//                    if (listFeaturesHW[position].featureValue.length > 20) {
//                        return 2
//                    } else return 1
//                }
//            }

            rvFeatureList.layoutManager = layoutManager
            rvFeatureList.adapter = InfoAdapter(mContext,listFeaturesHW,singleItem.size-1)

//            val dividerItemDecoration = DividerItemDecoration(mContext, layoutManager.orientation)
//            dividerItemDecoration.setDrawable(mContext.resources.getDrawable(R.drawable.sk_line_divider))
//            rvFeatureList.addItemDecoration(dividerItemDecoration)
//            rvFeatureList.addItemDecoration(DividerItemDecorator(mContext.resources.getDrawable(R.drawable.sk_line_divider)))

        }
    }

    fun getLargeCount(listFeaturesHW: List<FeaturesHW>): List<FeaturesHW> {
        return listFeaturesHW.filter { it.featureValue.length > 20 }
    }
    fun getLengthCount(listFeaturesHW: List<FeaturesHW>): List<FeaturesHW> {
        return listFeaturesHW.filter { it.featureValue.length <= 20 }
    }

    class FeaturesSorter : Comparator<FeaturesHW> {
        override fun compare(lhs: FeaturesHW, rhs: FeaturesHW): Int {
            return rhs.featureValue.length.compareTo(lhs.featureValue.length)
        }
    }

    class DividerItemDecorator(divider: Drawable) : ItemDecoration() {
        private val mDivider: Drawable = divider
        override fun onDrawOver(canvas: Canvas, parent: RecyclerView, state: RecyclerView.State) {
            val dividerLeft = parent.paddingLeft
            val dividerRight = parent.width - parent.paddingRight
            val childCount = parent.childCount
            for (i in 0..childCount - 2) {
                val child = parent.getChildAt(i)
                val params = child.layoutParams as RecyclerView.LayoutParams
                val dividerTop = child.bottom + params.bottomMargin
                val dividerBottom: Int = dividerTop + mDivider.getIntrinsicHeight()
                mDivider.setBounds(dividerLeft, dividerTop, dividerRight, dividerBottom)
                mDivider.draw(canvas)
            }
        }
    }
}
