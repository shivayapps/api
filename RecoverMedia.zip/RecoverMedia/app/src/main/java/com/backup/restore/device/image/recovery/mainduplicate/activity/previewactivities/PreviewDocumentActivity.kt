package com.backup.restore.device.image.recovery.mainduplicate.activity.previewactivities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.databinding.ActivityPreviewDocumentBinding
import com.backup.restore.device.image.recovery.duplicatenew.models.FileDetails
import com.backup.restore.device.image.recovery.utilities.AdCache
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import com.backup.restore.device.image.recovery.utilities.common.MyUtils
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.google.android.gms.ads.AdView
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class PreviewDocumentActivity : MyCommonBaseActivity() {
    var mItemDuplicateModel: FileDetails? = null
    var mFileName: String? = null
    var mFileSize: String? = null
    var mFileType: String? = null
    var mModifiedDate: String? = null
    var mPath: String? = null

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    lateinit var binding:ActivityPreviewDocumentBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_preview_document)
        binding=ActivityPreviewDocumentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MyUtils.logError("preview Document Activity!!!")
    }

    override fun getContext(): AppCompatActivity {
        return this@PreviewDocumentActivity
    }

    override fun initData() {
//        if (AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {
//            GiftIconHelper.loadGiftAd(
//                fContext = mContext,
//                fivGiftIcon = findViewById(R.id.main_la_gift),
//                fivBlastIcon = findViewById(R.id.main_la_gift_blast)
//            )
//            ll_gift.visibility = View.VISIBLE
            loadAds()
//        }else{
//            binding.adview.visibility = View.GONE
////            ll_gift.visibility = View.INVISIBLE
//        }
        assignValuesToWidgets()
        binding.fileName1!!.text = mFileName
        binding.fileName!!.text = mFileName
        binding.fileType!!.text = mFileType
        binding.fileSize!!.text = mFileSize
        binding.modifiedDate!!.text = mModifiedDate
        binding.path!!.isSelected = true
        binding.path!!.text = mPath

    }

    var isAdLoaded = false
    var mAdView: AdView?=null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        changeLanguage()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }
    fun loadAds() {
        val adId = getString(R.string.admob_banner)
        BannerAdHelper.showBanner(
            this, binding.adview, binding.adview, adId,
            AdCache.bannerDetail, { isLoaded, adView, message ->
                AdCache.bannerDetail = adView
                mAdView = adView
                isAdLoaded = isLoaded
            }
        )
    }
    override fun initActions() {
        binding.zoomableImageView!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            MyApplication.isInternalCall = true

            try {
                val intent = Intent()
                intent.action = Intent.ACTION_VIEW
                val lFileUri = FileProvider.getUriForFile(mContext, applicationContext.packageName + ".provider", File(mPath!!))
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.setDataAndType(lFileUri, "*/*")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)

            } catch (exception: ActivityNotFoundException) {}
        }
        binding.backpressAudio!!.setOnClickListener(this)
    }

    private fun assignValuesToWidgets() {
        val b = intent.extras
        if (b != null) {
            mItemDuplicateModel = b.getSerializable("documentFile") as FileDetails?
        }
        mFileName = mItemDuplicateModel!!.fileName
        mFileType = GlobalVarsAndFunctions.getExtension(mItemDuplicateModel!!.filePath)
        mFileSize = mItemDuplicateModel!!.fileSizeStr
        mModifiedDate = SimpleDateFormat("MMM dd,yyyy HH:mm:ss ").format(Date(File(mItemDuplicateModel!!.filePath).lastModified()))
        mPath = mItemDuplicateModel!!.filePath
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        if (view.id == R.id.backpress_audio) {
            onBackPressed()
        }
    }


    override fun onBackPressed() {
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}