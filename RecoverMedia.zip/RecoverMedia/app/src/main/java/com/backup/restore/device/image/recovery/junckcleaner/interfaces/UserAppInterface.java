package com.backup.restore.device.image.recovery.junckcleaner.interfaces;

public interface UserAppInterface {
        void userDone(boolean flag);
    }