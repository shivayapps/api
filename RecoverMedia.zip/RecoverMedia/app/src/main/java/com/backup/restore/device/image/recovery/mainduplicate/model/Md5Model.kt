package com.backup.restore.device.image.recovery.mainduplicate.model

class Md5Model {
    var extension: String? = null
    var filePath: String? = null
    var md5Value: String? = null
}