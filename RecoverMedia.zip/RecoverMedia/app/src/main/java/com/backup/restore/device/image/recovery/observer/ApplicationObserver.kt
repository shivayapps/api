package com.backup.restore.device.image.recovery.observer


import android.content.Context
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant

//class ApplicationObserver(val analytics: Analytics,val mContext : Context) : LifecycleObserver {
//
//    @OnLifecycleEvent(Lifecycle.Event.ON_START)
//    fun onForeground() {
//        analytics.startSession()
//        AppController.isAppRunning = true
//        println("ApplicationObserver" + "onForeground")
//        SharedPrefsConstant.savePref(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, false)
//        if (SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true)) {
//            SharedPrefsConstant.savePref(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, false)
//        }
//        Log.e("TAG", "onAppBackgrounded: IS_APP_IN_BACKGROUND:" + SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true))
//
//    }
//
//    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
//    fun onBackground() {
//        analytics.stopSession()
//        AppController.isAppRunning = false
//        println("ApplicationObserver" + "onBackground")
//        if (!SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true)) {
//            SharedPrefsConstant.savePref(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true)
//        }
//        Log.e("TAG", "onForeground: IS_APP_IN_BACKGROUND:" + SharedPrefsConstant.getBoolean(mContext, SharedPrefsConstant.IS_APP_IN_BACKGROUND, true))
//
//    }
//}