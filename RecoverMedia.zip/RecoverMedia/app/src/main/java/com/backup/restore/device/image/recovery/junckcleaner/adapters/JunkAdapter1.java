package com.backup.restore.device.image.recovery.junckcleaner.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.junckcleaner.interfaces.SelectAll;
import com.backup.restore.device.image.recovery.junckcleaner.models.FileModel;
import com.backup.restore.device.image.recovery.mainapps.model.Utils;

import java.io.File;
import java.util.List;

public class JunkAdapter1 extends ListAdapter<FileModel, JunkAdapter1.FileHolder> {
    Context context;
    View view;
    FileHolder holder;
    String type;

//    SendData sendData;
    SelectAll selectAll;
    double total = 0f;

    List<FileModel> killingApps;
    List<FileModel> adapterApps;


    public JunkAdapter1(Context context, List<FileModel> killingApps, List<FileModel> adapterApps, String type, double total) {
        super(DIFF_CALLBACK);
        this.context = context;
        this.killingApps = killingApps;
        this.adapterApps = adapterApps;
        this.type = type;
        this.total = total;
    }

    public double getAllTotal() {
        double appTotal = 0f;
        for (FileModel app : killingApps) {
            appTotal += app.getSize();
//            double size = Utils.getCalculatedDataSizeMB((float) app.getSize());
//            appTotal += Float.parseFloat(new DecimalFormat("#.##").format(size));
//            appTotal += Float.parseFloat(String.format(Locale.ENGLISH, "%.2f", size));
        }
        return appTotal;
    }

    public double getTotal() {
        return total;
    }

    public static final DiffUtil.ItemCallback<FileModel> DIFF_CALLBACK = new DiffUtil.ItemCallback<FileModel>() {
        @Override
        public boolean areItemsTheSame(@NonNull FileModel oldItem, @NonNull FileModel newItem) {
            return oldItem.equals(newItem);
        }

        @SuppressLint("DiffUtilEquals")
        @Override
        public boolean areContentsTheSame(@NonNull FileModel oldItem, @NonNull FileModel newItem) {
            return oldItem.equals(newItem);
        }
    };


    public void setAdapterApps(List<FileModel> adapterApps) {
        this.adapterApps = adapterApps;
    }

    public void setKillingApps(List<FileModel> killingApps) {
        this.killingApps = killingApps;
    }

    public List<FileModel> getKillingApps() {
        return killingApps;
    }

    public void clearFile() {
        Log.e("JunkAdapter1", "clearFile-->"+type);
        for (FileModel fileModel : killingApps) {
            File file = new File(fileModel.getPath());
            try {
                if (file.exists()) {
                    if (file.delete()) {
                        Log.e("JunkAdapter1", "clearFile-done:" + file.getPath());
                    } else {
                        Log.e("JunkAdapter1", "clearFile-error:" + file.getPath());
                    }
                }
            } catch (Exception e) {
                Log.e("JunkAdapter1", "clearFile-type:" + type);
                Log.e("JunkAdapter1", "clearFile-Exception:" + e);
            }
        }
        Log.e("JunkAdapter1", "clearFile-->exit");
    }

    @NonNull
    @Override
    public FileHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item_1, parent, false);
        holder = new FileHolder(view);
        //return new FileHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull FileHolder holder, int position) {
//        holder.textView_app_name.setText(utils.appInfo(getItem(position).getPath(), MyAnnotations.APP_NAME));
        holder.textView_app_name.setText(getItem(position).getPath());
        holder.textView_app_path.setText(getItem(position).getPath());
        holder.textView_app_name.setSelected(true);
        holder.textView_app_path.setSelected(true);

        holder.checkbox.setBackground(ContextCompat.getDrawable(context, R.drawable.selector_custom_checkbox_red));

        holder.checkbox.setChecked(killingApps.contains(getItem(position)));
//        holder.textView_size.setText(utils.getDataSizeWithPrefix((float) utils.getAllSize(getItem(position).getPath())));
//        holder.textView_size.setText(Utils.getDataSizeWithPrefix((float) new File(getItem(position).getPath()).length()));
//        holder.textView_size.setText(""+getItem(position).getSize());
        Pair<String, String> size = Utils.getDataSizeWithPrefix(context,(float) getItem(position).getSize());
        holder.textView_size.setText(size.first + " " + size.second);
        Log.e("JunkAdapter1", "size01:" + new File(getItem(position).getPath()).length());

        //Glide.with(context).load((Drawable) utils.appInfo(getItem(position), MyAnnotations.APP_ICON)).into(holder.imageView_icon);
//        Glide.with(context).load(getIconFromApk(getItem(position).getPath())).placeholder(R.drawable.ic_android_logo_black).into(holder.imageView_icon);
//        holder.imageView_icon.setImageDrawable(getIconFromApk(getItem(position).getPath()));

//        holder.checkbox.setOnClickListener(v -> {
//            if (killingApps.contains(getItem(position))) {
//                killingApps.remove(getItem(position));
//                total = total - getItem(position).getSize();
//                selectAll.selectAll(false, type);
//            } else {
//                killingApps.add(getItem(position));
//                total = total + getItem(position).getSize();
//                if (killingApps.size() == getCurrentList().size()) {
//                    selectAll.selectAll(true, type);
//                }
//            }
//            sendData.data(String.valueOf(killingApps.size()));
//            notifyItemChanged(position);
//        });

        holder.itemView.setOnClickListener(v -> {
            if (killingApps.contains(getItem(position))) {
                killingApps.remove(getItem(position));
                total = total - getItem(position).getSize();
                selectAll.selectAll(false, type);
                holder.checkbox.setChecked(false);
            } else {
                holder.checkbox.setChecked(true);
                killingApps.add(getItem(position));
                total = total + getItem(position).getSize();
                if (killingApps.size() == getCurrentList().size()) {
                    selectAll.selectAll(true, type);
                } else {
                    selectAll.selectAll(false, type);
                }
            }
//            sendData.data(String.valueOf(killingApps.size()));
            notifyItemChanged(position);
        });

    }

    public Drawable getIconFromApk(String apkPath) {
        PackageManager packageManager = context.getPackageManager();
        PackageInfo packageInfo = packageManager.getPackageArchiveInfo(apkPath, 0);

        // you need to set this variables manually for some reason to get icon from APK file that has not been installed
        Drawable icon = null;
        if (packageInfo != null) {
            packageInfo.applicationInfo.sourceDir = apkPath;
            packageInfo.applicationInfo.publicSourceDir = apkPath;
            icon = packageInfo.applicationInfo.loadIcon(packageManager);
        }

        return icon;
    }

    public void selectAll() {
        if (!killingApps.isEmpty()) {
            killingApps.clear();
        }
//        CheckBox checkBox = holder.itemView.findViewById(R.id.checkbox);
//        if (holder.checkbox != null) {
//            holder.checkbox.setChecked(true);
//        }
        killingApps.addAll(adapterApps);
//        sendData.data(String.valueOf(killingApps.size()));
        notifyDataSetChanged();

    }

    public void clearList() {
        if (!killingApps.isEmpty()) {
            killingApps.clear();
        }
//        CheckBox checkBox = holder.itemView.findViewById(R.id.checkbox);
//        if (holder.checkbox != null) {
//            holder.checkbox.setChecked(false);
//        }
//        sendData.data(String.valueOf(killingApps.size()));

        notifyDataSetChanged();
    }


    static class FileHolder extends RecyclerView.ViewHolder {

        CheckBox checkbox;
        TextView textView_app_name, textView_app_path, textView_size;

        public FileHolder(@NonNull View itemView) {
            super(itemView);
            checkbox = itemView.findViewById(R.id.checkbox);
            textView_app_name = itemView.findViewById(R.id.textView_app_name);
            textView_app_path = itemView.findViewById(R.id.textView_app_path);
            textView_size = itemView.findViewById(R.id.textView_size);

        }
    }

//    public void setSendData(SendData sendData) {
//        this.sendData = sendData;
//    }

    public void setSelectAll(SelectAll selectAll) {
        this.selectAll = selectAll;
    }

}
