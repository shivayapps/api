package com.backup.restore.device.image.recovery.mainphotos.recoverableadapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainphotos.callbacks.ItemClickListener
import com.backup.restore.device.image.recovery.mainphotos.model.RecoverableFolderModel
import com.bumptech.glide.Glide
import java.util.*

class RecoverableFolderAdapter(
    private var folders: ArrayList<RecoverableFolderModel>,
    private val mFolderContext: Context,
    private val listenToClick: ItemClickListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var mLastClickTime: Long = 0
    var mTAG= "RecoverableFolderAdapter"

    class FolderHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var folderPic: ImageView = itemView.findViewById(R.id.folderPic)
        var folderName: TextView = itemView.findViewById(R.id.folderName)
        var folderSize: TextView = itemView.findViewById(R.id.folderSize)
    }

    fun updateList(folders: ArrayList<RecoverableFolderModel>) {
        this.folders = folders
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val cell = inflater.inflate(R.layout.raw_picture_folder_item, parent, false)
        return FolderHolder(cell)
    }

    override fun onBindViewHolder(holders: RecyclerView.ViewHolder, position: Int) {
        val holder = holders as FolderHolder
        val folder = folders[position]

//        Log.e("RecoverableAdapter", "onBindViewHolder:$position - ${folder.path}" )
//        Log.e("RecoverableAdapter", "onBindViewHolder folderName:$position - ${folder.folderName}" )
//        Log.e("RecoverableAdapter", "onBindViewHolder firstPic:$position - ${folder.firstPic}" )
        if (folder.firstPic == "audio") {
            holder.folderPic.setImageResource(R.drawable.ic_audio_cover)
//            val padding=DensityUtils.dpToPx(22)
//            holder.folderPic.setPadding(padding,padding,padding,padding)
        } else if (folder.firstPic == "document") {
            holder.folderPic.setImageResource(R.drawable.ic_doc_cover)
//            val padding=DensityUtils.dpToPx(28)
//            holder.folderPic.setPadding(padding,padding,padding,padding)
        } else if (folder.firstPic == "other") {
            holder.folderPic.setImageResource(R.drawable.ic_doc_cover)
//            val padding=DensityUtils.dpToPx(24)
//            holder.folderPic.setPadding(padding,padding,padding,padding)
        } else {
            Glide.with(mFolderContext)
                .load(folder.firstPic)
                .placeholder(R.drawable.img_thumb)
                .into(holder.folderPic)
        }

        val text = "" + folder.folderName
        val folderSizeString = "(" + folder.numberOfPics + ")"
        holder.folderSize.text = folderSizeString
//        holder.folderName.text = text
        holder.folderName.text = text.trim('.')
        holder.folderPic.setOnClickListener {
            Log.e("RecoverableFolderAdp", "setOnClickListener")
            listenToClick.onPicClicked(folder.path, folder.folderName)
        }
    }

    override fun getItemCount(): Int {
        return folders.size
    }


//    fun runLayoutAnimation() {
//        val lController = AnimationUtils.loadLayoutAnimation(mFolderContext, R.anim.layout_animation_fall_down)
//        mScanAlbumRecycle.layoutAnimation = lController
//        Objects.requireNonNull(mScanAlbumRecycle.adapter).notifyDataSetChanged()
//        mScanAlbumRecycle.scheduleLayoutAnimation()
//    }
}