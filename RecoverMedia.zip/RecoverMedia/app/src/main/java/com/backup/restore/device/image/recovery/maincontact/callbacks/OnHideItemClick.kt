package com.backup.restore.device.image.recovery.maincontact.callbacks

interface OnHideItemClick {
    fun onHideContactItemClick(position: Int)
}