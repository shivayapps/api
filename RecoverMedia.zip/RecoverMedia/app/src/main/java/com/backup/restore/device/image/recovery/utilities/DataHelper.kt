package com.backup.restore.device.image.recovery.utilities

import android.content.Context
import android.os.Environment
import com.example.jdrodi.utilities.SPUtil


const val KEY_PATH = "key_path"
const val KEY_GRID = "key_grid"
const val KEY_LAUNCH = "key_launch"

private val DEFAULT_PATH = Environment.getExternalStorageDirectory().absolutePath + "/RecoverMedia/"
private val DEFAULT_COUNT = 3

fun Context.getPath(): String? {
    return SPUtil(this).getString(KEY_PATH, DEFAULT_PATH).toString()
}

fun Context.savePath(path: String) {
    SPUtil(this).save(KEY_PATH, path)
}

fun Context.isFirstLaunch(): Boolean {
    return SPUtil(this).getBoolean(KEY_LAUNCH, true)
}

fun Context.saveFirstLaunch() {
    SPUtil(this).save(KEY_LAUNCH, false)
}

fun Context.getGridCount(): Int {
    return SPUtil(this).getInt(KEY_GRID, DEFAULT_COUNT)
}

fun Context.saveGridCount(count: Int) {
    SPUtil(this).save(KEY_GRID, count)
}