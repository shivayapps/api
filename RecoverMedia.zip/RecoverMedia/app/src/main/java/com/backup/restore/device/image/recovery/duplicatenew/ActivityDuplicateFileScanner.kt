package com.backup.restore.device.image.recovery.duplicatenew

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.AdsConfig
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.databinding.ActivityDuplicateFileScannerBinding
import com.backup.restore.device.image.recovery.duplicatenew.models.DuplicateGroupModel
import com.backup.restore.device.image.recovery.duplicatenew.utils.DuplicatePreferences
import com.backup.restore.device.image.recovery.duplicatenew.utils.algorathm.ObserveFilesExecutor
import com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities.NewDuplicateMediaActivity
import com.backup.restore.device.image.recovery.mainduplicate.model.PopUp
import com.backup.restore.device.image.recovery.utilities.DuplicateScanningListener
import com.backup.restore.device.image.recovery.utilities.MyAnnotations
import com.backup.restore.device.image.recovery.utilities.common.GlobalVarsAndFunctions
import java.util.*

class ActivityDuplicateFileScanner : MyCommonBaseActivity(), DuplicateScanningListener {
    //    ConstraintLayout clLoading;
    var scanning = false
//    var textViewScanning: TextView? = null
//    var observeFilesExecutor: DuplicateFilesExecutor? = null
    var observeFilesExecutor: ObserveFilesExecutor? = null
    var mIsCheckType: String? = null
    var isFromOneSignal = false

    companion object {
        var whichButtonClicked = ""
    }

    lateinit var binding:ActivityDuplicateFileScannerBinding
    //ShimmerFrameLayout shimmerViewContainer;
    //    public boolean adPlayed = false;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_duplicate_file_scanner)
        binding=ActivityDuplicateFileScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        textViewScanning = findViewById(R.id.tvCount)
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        mIsCheckType = intent.getStringExtra(MyAnnotations.DATA_TYPE)

        GlobalVarsAndFunctions.listOfDuplicates.clear()
        GlobalVarsAndFunctions.fileToBeDeleted.clear()

        when (mIsCheckType) {
            MyAnnotations.IMAGES -> {
                startScanning(MyAnnotations.IMAGES)
                whichButtonClicked = MyAnnotations.IMAGES
                scanning = true
            }
            MyAnnotations.VIDEOS -> {
                startScanning(MyAnnotations.VIDEOS)
                whichButtonClicked = MyAnnotations.VIDEOS
                scanning = true
            }
            MyAnnotations.AUDIOS -> {
                startScanning(MyAnnotations.AUDIOS)
                whichButtonClicked = MyAnnotations.AUDIOS
                scanning = true
            }
            MyAnnotations.DOCUMENTS -> {
                startScanning(MyAnnotations.DOCUMENTS)
                whichButtonClicked = MyAnnotations.DOCUMENTS
                scanning = true
            }
            MyAnnotations.OTHER -> {
                startScanning(MyAnnotations.OTHER)
                whichButtonClicked = MyAnnotations.OTHER
                scanning = true
            }
        }

    }

    private fun startScanning(type: String) {
        observeFilesExecutor = ObserveFilesExecutor(this, this, type)
        observeFilesExecutor!!.execute()
    }

    override fun onBackPressed() {
         PopUp(mContext, mContext).showAlertStopScanning(observeFilesExecutor!!)
    }

    override fun checkScanning() {
        if (whichButtonClicked == MyAnnotations.IMAGES) {
//            GlobalVarsAndFunctions.listOfDuplicates.clear()
//            for (list in GlobalVarsAndFunctions.duplicatesList) {
//                val individualGroupPhotos = DuplicateGroupModel()
//                individualGroupPhotos.isCheckBox = SharedPrefsConstant.getBooleanNoti(
//                    this@ActivityDuplicateFileScanner,
//                    "duplicateSelection",
//                    true
//                )
//                individualGroupPhotos.individualGrpOfDupes = list
//                GlobalVarsAndFunctions.listOfDuplicates.add(individualGroupPhotos)
//            }
            return
        }
        if (whichButtonClicked == MyAnnotations.VIDEOS) {
//            for (list in GlobalVarsAndFunctions.duplicatesList) {
//                val individualGroupPhotos = DuplicateGroupModel()
//                individualGroupPhotos.isCheckBox = SharedPrefsConstant.getBooleanNoti(
//                    this@ActivityDuplicateFileScanner,
//                    "duplicateSelection",
//                    true
//                )
//                individualGroupPhotos.individualGrpOfDupes = list
//                GlobalVarsAndFunctions.listOfDuplicates.add(individualGroupPhotos)
//            }
            return
        }
        if (whichButtonClicked == MyAnnotations.AUDIOS) {
//            for (list in GlobalVarsAndFunctions.duplicatesList) {
//                val individualGroupPhotos = DuplicateGroupModel()
//                individualGroupPhotos.isCheckBox = SharedPrefsConstant.getBooleanNoti(
//                    this@ActivityDuplicateFileScanner,
//                    "duplicateSelection",
//                    true
//                )
//                individualGroupPhotos.individualGrpOfDupes = list
//                GlobalVarsAndFunctions.listOfDuplicates.add(individualGroupPhotos)
//            }
            return
        }
        if (whichButtonClicked == MyAnnotations.DOCUMENTS) {
//            for (list in GlobalVarsAndFunctions.duplicatesList) {
//                val individualGroupPhotos = DuplicateGroupModel()
//                individualGroupPhotos.isCheckBox = SharedPrefsConstant.getBooleanNoti(
//                    this@ActivityDuplicateFileScanner,
//                    "duplicateSelection",
//                    true
//                )
//                individualGroupPhotos.individualGrpOfDupes = list
//                GlobalVarsAndFunctions.listOfDuplicates.add(individualGroupPhotos)
//            }
            return
        }
        if (whichButtonClicked == MyAnnotations.OTHER) {
//            for (list in GlobalVarsAndFunctions.duplicatesList) {
//                val individualGroupPhotos = DuplicateGroupModel()
//                individualGroupPhotos.isCheckBox = SharedPrefsConstant.getBooleanNoti(
//                    this@ActivityDuplicateFileScanner,
//                    "duplicateSelection",
//                    true
//                )
//                individualGroupPhotos.individualGrpOfDupes = list
//                GlobalVarsAndFunctions.listOfDuplicates.add(individualGroupPhotos)
//            }
            return
        }

        DuplicatePreferences.setStopScanForNotification(this, true)
        DuplicatePreferences.setNavigateFromHome(this, true)
    }

    override fun publishProgress(vararg count: String) {
        try {
            if (whichButtonClicked == MyAnnotations.IMAGES || whichButtonClicked == MyAnnotations.VIDEOS || whichButtonClicked == MyAnnotations.AUDIOS || whichButtonClicked == MyAnnotations.DOCUMENTS|| whichButtonClicked == MyAnnotations.OTHER) {
                if (count != null) if (count.size > 1) {
                    if (count[0].equals("Sorting", ignoreCase = true)) {
                        return
                    }
                    val counter = count[0] + " / " + count[1]
                    tvUpdates(counter)

                    if (observeFilesExecutor!!.stopped) {
//                        mContext.isShowInterstitialAd { isShowFullScreenAd ->
//                            Log.e("mTAG", "onClick: isShowFullScreenAd::$isShowFullScreenAd")
//                            MyApplication.isInterstitialShown = false;
//                            goToNext();
//                        }

                        AdsConfig.showInterstitialAd(mContext,{
                            MyApplication.isInterstitialShown = false;
                            goToNext();
                        })
                    }

                }
            } else {
                randomQuotes()
                if (count[0].equals("Sorting", ignoreCase = true)) {
                    return
                }
//                val msg = "Files " + count[0]
//                tvUpdates(msg)
            }
        } catch (exception: Exception) {
            exception.printStackTrace()
        }
    }

    private fun randomQuotes() {
        val listOptions: Array<String> = mContext.resources.getStringArray(R.array.quotes_array)
        val random = Random().nextInt(listOptions.size)
        binding.tvCount.text = listOptions[random]
        if(!isDestroyed) {
            Handler().postDelayed({
                randomQuotes()
            },8000)
        }
    }

    private fun tvUpdates(msg: String) {
        binding.tvCount.text = msg
    }

//    override fun publishProgress(duplicatesList: List<ArrayList<FileDetails>>) {
    override fun publishProgress(duplicatesList: List<DuplicateGroupModel>) {
        if (duplicatesList != null) {
            GlobalVarsAndFunctions.listOfDuplicates = duplicatesList
            if (GlobalVarsAndFunctions.listOfDuplicates.size > 0) {
//                mContext.isShowInterstitialAd { isShowFullScreenAd ->
//                    Log.e("mTAG", "onClick: isShowFullScreenAd::$isShowFullScreenAd")
//                    MyApplication.isInterstitialShown = false;
//                    goToNext();
//                }

                AdsConfig.showInterstitialAd(mContext,{
                    MyApplication.isInterstitialShown = false;
                    goToNext();
                })

            } else {
                goToNext()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (observeFilesExecutor == null) {
            observeFilesExecutor = ObserveFilesExecutor(this, this, whichButtonClicked)
        }
        if (observeFilesExecutor!!.stopped) {
            whichButtonClicked = ""
        }
    }

    fun goToNext() {
//        if (!observeFilesExecutor!!.stopped) {
            scanning = false
            var intent = Intent()
            when (whichButtonClicked) {
                MyAnnotations.IMAGES -> {
                    intent = Intent(this@ActivityDuplicateFileScanner, NewDuplicateMediaActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.IMAGES)
                }
                MyAnnotations.VIDEOS -> {
                    intent = Intent(this@ActivityDuplicateFileScanner, NewDuplicateMediaActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.VIDEOS)
                }
                MyAnnotations.AUDIOS -> {
                    intent = Intent(this@ActivityDuplicateFileScanner, NewDuplicateMediaActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.AUDIOS)
                }
                MyAnnotations.DOCUMENTS -> {
                    intent = Intent(this@ActivityDuplicateFileScanner, NewDuplicateMediaActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.DOCUMENTS)
                }
                MyAnnotations.OTHER -> {
                    intent = Intent(this@ActivityDuplicateFileScanner, NewDuplicateMediaActivity::class.java)
                    intent.putExtra(MyAnnotations.DATA_TYPE, MyAnnotations.OTHER)
                }
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.putExtra("IsCheckOneSignalNotification", isFromOneSignal)
            startActivity(intent)
            Handler().postDelayed({ finish() }, 1000)
//        }
    }

    override fun getContext(): AppCompatActivity {
        return this@ActivityDuplicateFileScanner
    }

    override fun initData() {}
    override fun initActions() {}

}