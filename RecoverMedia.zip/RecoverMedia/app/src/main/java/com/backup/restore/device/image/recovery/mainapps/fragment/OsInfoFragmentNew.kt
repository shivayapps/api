package com.backup.restore.device.image.recovery.mainapps.fragment

import android.os.Build
import android.os.Build.VERSION_CODES
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager
import com.adconfig.adsutil.admob.NativeLayoutType

/**
 * A placeholder fragment containing a simple view.
 */
class OsInfoFragmentNew : Fragment() {

    var rootView: View? = null
    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"

        @JvmStatic
        fun newInstance(): OsInfoFragmentNew {
            val fragment = OsInfoFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()

        getOSInfo()

        return rootView
    }

    private fun getOSInfo() {
        ivType!!.setImageResource(R.drawable.ic_os)
        tvTitle!!.text = getString(R.string.os_information)
        tvSubTitle!!.text = getProperText(VERSION_CODES::class.java.fields[Build.VERSION.SDK_INT].name + " " + Build.VERSION.RELEASE)
        tvTitle!!.isSelected=true
        tvSubTitle!!.isSelected=true

        val parents = ArrayList<ParentModel>()
        parents.add(ParentModel(resources.getString(R.string.os_information),ArrayList<FeaturesHW>()))
        val lists: ArrayList<FeaturesHW> = parents.get(0).lists

        lists.add(FeaturesHW(getString(R.string.version), "${getProperText(Build.VERSION.RELEASE)}"))
        lists.add(FeaturesHW(getString(R.string.version_name), "${getProperText(VERSION_CODES::class.java.fields[Build.VERSION.SDK_INT].name)}"))
        lists.add(FeaturesHW(getString(R.string.api_level), "${getProperText(Build.VERSION.SDK_INT.toString())}"))

        lists.add(FeaturesHW(getString(R.string.build_id), "${getProperText(Build.ID)}"))
        lists.add(FeaturesHW(getString(R.string.build_name), "${getProperText(Utils.getDate(Build.TIME))}"))
        lists.add(FeaturesHW(getString(R.string.fingerprint), "${getProperText(Build.FINGERPRINT)}"))

        val adapter = ParentAdapter(parents, requireContext())
        rvFeatureList?.adapter = adapter
        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        Handler(Looper.getMainLooper()).postDelayed({
            scrollMain.scrollTo(0,0)
        },100)

    }

    private fun getProperText(textValue: String?) : String {
        if(textValue.isNullOrEmpty()) {
            return getString(R.string.unavailable)
        } else return textValue
    }

    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

}