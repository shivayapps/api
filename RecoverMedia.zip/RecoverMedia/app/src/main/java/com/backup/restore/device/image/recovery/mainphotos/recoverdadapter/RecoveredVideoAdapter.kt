package com.backup.restore.device.image.recovery.mainphotos.recoverdadapter

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.mainphotos.activity.NewRecoverImageActivity
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.getShareMessage
import com.bumptech.glide.Glide
import com.example.jdrodi.utilities.OnSingleClickListener
import java.io.File
import java.util.*

class RecoveredVideoAdapter(var mContext: Activity, mSaveList: ArrayList<File>, val mRvAlreadyBackup: RecyclerView, val mTv_Msg: LinearLayout, val mIvDeleteAll: ImageView) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        var mSavedFiles : ArrayList<File>? = null
    }

    init {
        mSavedFiles = mSaveList
    }

    class MyRecoveredViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var llDelete: LinearLayout = itemView.findViewById(R.id.llDelete)
        var llShare: LinearLayout = itemView.findViewById(R.id.llShare)
        var imgItem: ImageView = itemView.findViewById(R.id.imgItem)
        var fileSize: TextView = itemView.findViewById(R.id.fileSize)
        var imgType: ImageView = itemView.findViewById(R.id.imgType)

    }

    override fun getItemCount(): Int {
        return mSavedFiles!!.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val menuItemLayoutView = LayoutInflater.from(parent.context).inflate(R.layout.raw_recoverable_image_item, parent, false)
        return MyRecoveredViewHolder(menuItemLayoutView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder,  position: Int) {
        val menuItemHolder = holder as MyRecoveredViewHolder
        try {
//            val file = File(mSavedFiles!![position].absolutePath)
//            val imageUri = Uri.fromFile(file)
            Glide.with(mContext)
                .load(mSavedFiles!![position].absolutePath)
                .override(300, 300)
                .placeholder(R.drawable.img_thumb)
                .into(menuItemHolder.imgItem)
            menuItemHolder.imgType.visibility=View.VISIBLE

            menuItemHolder.fileSize.text = String.format("%s", ShareConstants.getReadableFileSize(
                mSavedFiles!![position].length()))

            menuItemHolder.fileSize.isSelected = true
            menuItemHolder.itemView.setOnClickListener(object : OnSingleClickListener() {
                override fun onSingleClick(v: View?) {
//                    if(type == "Image") {
//                        val intent = Intent(mContext, FullScreenRecoveredImageActivity::class.java)
//                        intent.putExtra("position", position)
//                        mContext.startActivity(intent)
//                    } else {
                    MyApplication.isInternalCall = true

                        val intent = Intent()
                        intent.action = Intent.ACTION_VIEW
                        val lFileUri = FileProvider.getUriForFile(mContext, mContext.applicationContext.packageName + ".provider", File(mSavedFiles!![position].absolutePath))
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        intent.setDataAndType(lFileUri, "video/*")
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        mContext.startActivity(intent)
//                    }
                }
            })

            menuItemHolder.llDelete.visibility=View.GONE
            menuItemHolder.llDelete.setOnClickListener {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                deleteMethod(position)

            }
            menuItemHolder.llShare.visibility=View.GONE
            menuItemHolder.llShare.setOnClickListener {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                NewRecoverImageActivity.isRefresh = false
                val uri = FileProvider.getUriForFile(mContext, mContext.packageName + ".provider", mSavedFiles!![position])
                val share = Intent(Intent.ACTION_SEND)
//                if(type == "Image") {
//                    share.type = "image/*"
//                }else{
                    share.type = "video/*"
//                }
                share.putExtra(Intent.EXTRA_SUBJECT, mContext.resources.getString(R.string.app_name))
                share.putExtra(Intent.EXTRA_STREAM, uri)
                share.putExtra(Intent.EXTRA_TEXT, mContext.getShareMessage())
                MyApplication.isInternalCall = true
                mContext.startActivity(Intent.createChooser(share, "Share Image"))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun deleteMethod(position: Int) {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_confirmation)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

//        dialog.findViewById<ImageView>(R.id.imageIcon).setImageDrawable(mContext.resources.getDrawable(R.drawable.ic_dialog_delete))
        dialog.findViewById<TextView>(R.id.permission).text = mContext.getString(R.string.confirm_delete)
        dialog.findViewById<TextView>(R.id.permission_text).text = mContext.getString(R.string.never_get_back_video)

        dialog.findViewById<TextView>(R.id.dialogButtonOk).text = mContext.getString(R.string.yes)
        dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = mContext.getString(R.string.no)

        dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
            dialog.cancel()
            if (mSavedFiles!![position].exists()) {
                mSavedFiles!![position].delete()
                mSavedFiles!!.removeAt(position)
                Toast.makeText(mContext, R.string.deleted_success, Toast.LENGTH_SHORT).show()
                if (mSavedFiles!!.size == 0) {
                    mRvAlreadyBackup.visibility = View.GONE
                    mTv_Msg.visibility = View.VISIBLE
                    mIvDeleteAll.isEnabled = false
                    mIvDeleteAll.alpha = 0.5f

                    if (mContext is NewRecoverImageActivity) {
                        (mContext as NewRecoverImageActivity).unSelectAll()
                    }

                } else {
                    mTv_Msg.visibility = View.GONE;
                    mRvAlreadyBackup.visibility = View.VISIBLE
                    mIvDeleteAll.isEnabled = true
                    mIvDeleteAll.alpha = 1.0f
                }
                notifyDataSetChanged()
            }
        }
        dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
            dialog.cancel()
        }
        dialog.show()
    }

    fun runLayoutAnimation() {
        val lController = AnimationUtils.loadLayoutAnimation(mContext, R.anim.layout_animation_fall_down)
        mRvAlreadyBackup.layoutAnimation = lController
        Objects.requireNonNull(mRvAlreadyBackup.adapter).notifyDataSetChanged()
        mRvAlreadyBackup.scheduleLayoutAnimation()
    }


}