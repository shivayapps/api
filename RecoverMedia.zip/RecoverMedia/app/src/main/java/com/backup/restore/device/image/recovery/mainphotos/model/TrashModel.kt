package com.backup.restore.device.image.recovery.mainphotos.model

class TrashModel {
    var path: String? = ""
    var id: Int? = 0

    override fun equals(other: Any?): Boolean {
        return this.path!! == (other as TrashModel).path
    }
}
