package com.backup.restore.device.image.recovery.mainphotos.recoveredfragment

import android.os.*
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.databinding.FragmentRecoveredAudioDocBinding
import com.backup.restore.device.image.recovery.mainphotos.activity.RecoveredImageActivity
import com.backup.restore.device.image.recovery.mainphotos.recoverdadapter.OtherRecoveredAdapter
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant
import com.backup.restore.device.image.recovery.utilities.getExtension

//import kotlinx.android.synthetic.main.activity_recover_image_new.*
//import kotlinx.android.synthetic.main.fragment_recovered_audio_doc.*


import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class NewDocumentFragment : Fragment(), View.OnClickListener {

    val mTAG: String = javaClass.simpleName
    var mainCommonAdapter: OtherRecoveredAdapter? = null
    var isVisibleHint: Boolean = false
    private var path = ""
    var isForSort = "date_asc"
    var mSavedPhotos: ArrayList<File> = ArrayList()
    var isDocumentRecover = true

    companion object {
        fun newInstance(): NewDocumentFragment {
            val fragment = NewDocumentFragment()
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isAdded) {
            isVisibleHint = isVisibleToUser
            Log.e(mTAG, "setUserVisibleHint: same$isVisibleToUser")
//            Log.d(mTAG, "setUserVisibleHint: Cursor Count " + mCursor!!.count)
            if (isVisibleHint) {
                if(isDocumentRecover){
                    isDocumentRecover = false
                    mSavedPhotos.clear()
                    mainCommonAdapter = OtherRecoveredAdapter(requireActivity(), mSavedPhotos, binding.deletedFilesAudio, binding.tvRecoveredAlbum, (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll,"Document")
                    binding.deletedFilesAudio.adapter = mainCommonAdapter
                    GetRecoveredAlbum().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
                }else{
                    if (mSavedPhotos.size <= 0) {
                        if(binding.tvRecoveredAlbum!=null) binding.tvRecoveredAlbum.visibility = View.VISIBLE
                        if(binding.deletedFilesAudio!=null) binding.deletedFilesAudio.visibility = View.GONE
                        Log.e(mTAG, "onPostExecute: size 0 ")
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha = 0.5f
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled = false
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 0.5F
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled = false
                        (requireActivity() as RecoveredImageActivity).unSelectAll()
                    } else {
                        if(binding.tvRecoveredAlbum!=null) binding.tvRecoveredAlbum.visibility = View.GONE
                        if(binding.deletedFilesAudio!=null) binding.deletedFilesAudio.visibility = View.VISIBLE
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha = 1.0f
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled = true
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 1.0F
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled = true
                        (requireActivity() as RecoveredImageActivity).selectTop(3)
                    }
                    mainCommonAdapter = OtherRecoveredAdapter(requireActivity(), mSavedPhotos, binding.deletedFilesAudio, binding.tvRecoveredAlbum, (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll,"Document")
                    binding.deletedFilesAudio.adapter = mainCommonAdapter
                }

            }
        }
    }

    //    lateinit var mView: View
    lateinit var binding: FragmentRecoveredAudioDocBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
//        mView = inflater.inflate(R.layout.fragment_recovered_audio_doc, container, false)
        binding= FragmentRecoveredAudioDocBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        getAppList()
    }

    private fun getAppList() {
//        iv_not_found.setImageResource(R.drawable.ic_backup_not_found_doc)
        binding.tvNotFound.setText(R.string.document_not_found)

        ShareConstants.mRootPath = Environment.getExternalStorageDirectory().toString()
        path = "${ShareConstants.mRootPath}/RecoverMedia/Document/"
        binding.deletedFilesAudio!!.layoutManager = LinearLayoutManager(requireActivity())
    }

    override fun onClick(view: View) {

    }

    override fun onResume() {
        super.onResume()
        Log.e(mTAG, "onResume: $isVisibleHint")

    }

    private inner class GetRecoveredAlbum : AsyncTask<String?, String?, String?>() {

        override fun onPreExecute() {
            super.onPreExecute()
            if(isAdded) {
                if(binding.lotties!= null) {
                    binding.lotties.visibility = View.VISIBLE
                }
            }
            (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll.alpha = 0.5F
            (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll.isEnabled = false
            (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 0.5F
            (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled = false
        }

        override fun doInBackground(vararg strings: String?): String? {
            mSavedPhotos.clear()
            val dir = File(path)
            val files = dir.listFiles()
            if (files != null) {
                for (file in files) {
                    val lExtension = getExtension(file.name)
//                    val lImageExtensionList = SharedPrefsConstant.VideoArray
                    if (SharedPrefsConstant.DocumentArray.contains(lExtension) && file.name.endsWith(lExtension)) {
                        mSavedPhotos.add(file)
                        requireActivity().runOnUiThread {
                            Handler(Looper.getMainLooper()).post {
                                Log.e(mTAG, "gridRecoverableAlbumImage: " + mSavedPhotos.size)
                                mainCommonAdapter!!.notifyDataSetChanged()
                            }
                        }
                    }
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)

            try {
                Handler(Looper.getMainLooper()).post {
                    if (mSavedPhotos.size <= 0) {
                        if(binding.tvRecoveredAlbum!=null) binding.tvRecoveredAlbum.visibility = View.VISIBLE
                        if(binding.deletedFilesAudio!=null) binding.deletedFilesAudio.visibility = View.GONE
                        Log.e(mTAG, "onPostExecute: size 0 ")
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha = 0.5f
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled = false
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 0.5F
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled = false
                        (requireActivity() as RecoveredImageActivity).unSelectAll()
                    } else {
                        if(binding.tvRecoveredAlbum!=null) binding.tvRecoveredAlbum.visibility = View.GONE
                        if(binding.deletedFilesAudio!=null) binding.deletedFilesAudio.visibility = View.VISIBLE
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.alpha = 1.0f
                        (requireActivity() as RecoveredImageActivity).binding.ivDeleteAll!!.isEnabled = true
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.alpha = 1.0F
                        (requireActivity() as RecoveredImageActivity).binding.ivSpan.isEnabled = true

                        (requireActivity() as RecoveredImageActivity).selectTop(3)
                    }
                    Collections.sort(mSavedPhotos, ShareConstants.RecoveredDateAscending())

                    mainCommonAdapter!!.notifyDataSetChanged()


                    Handler(Looper.getMainLooper()).postDelayed(Runnable {
                        try {
                            binding.lotties.visibility = View.GONE
                        } catch (e: Exception) {
//                            context!!.addEvent(e.message!!)
                        }
                    }, 500)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }


        }
    }

}