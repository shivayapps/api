package com.backup.restore.device.image.recovery.mainphotos.model

class RecoverableFolderModel {
    var path: String? = null
    var folderName: String? = null
    var numberOfPics : Int = 0
    var firstPic: String? = null
    var folderDate: Long = 0
    var folderSize : Long = 0

    constructor() {}
    constructor(path: String?, folderName: String?) {
        this.path = path
        this.folderName = folderName
    }

    fun addPics() {
        numberOfPics++
    }
}