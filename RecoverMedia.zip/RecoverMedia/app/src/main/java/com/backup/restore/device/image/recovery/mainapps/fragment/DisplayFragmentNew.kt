package com.backup.restore.device.image.recovery.mainapps.fragment

import android.content.Context
import android.content.res.Configuration
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.mainapps.adapter.ParentAdapter
import com.backup.restore.device.image.recovery.mainapps.model.FeaturesHW
import com.backup.restore.device.image.recovery.mainapps.model.ParentModel
import com.backup.restore.device.image.recovery.mainapps.model.Utils
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import kotlin.collections.ArrayList

class DisplayFragmentNew : Fragment(){

    var rootView: View? = null

    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null

    var iv_share: ImageView? = null
    val dm = DisplayMetrics()

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        @JvmStatic
        fun newInstance(): DisplayFragmentNew {
            val fragment = DisplayFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()

        getDisplayInfo()
        return rootView
    }


    private fun getDisplayInfo() {
        ivType!!.setImageResource(R.drawable.ic_display)
        tvTitle!!.text = getString(R.string.display_information)
        tvSubTitle?.text = Build.DISPLAY
        tvTitle!!.isSelected=true
        tvSubTitle!!.isSelected=true

        val parents = ArrayList<ParentModel>()
        val pIndex=0


        val display = (activity?.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
        activity?.windowManager?.defaultDisplay?.getMetrics(dm)

        /*** Screen Size */
        val screenSizes: String = when (resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK) {
            Configuration.SCREENLAYOUT_SIZE_LARGE -> "Large screen"
            Configuration.SCREENLAYOUT_SIZE_NORMAL -> "Normal screen"
            Configuration.SCREENLAYOUT_SIZE_SMALL -> "Small screen"
            else -> "Screen size is neither large, normal or small"
        }

        /*** Screen physical size */
        activity?.windowManager?.defaultDisplay?.getMetrics(dm)

        val realSize = Point()
        Display::class.java.getMethod("getRealSize", Point::class.java).invoke(display, realSize)
        val pWidth = realSize.x
        val pHeight = realSize.y
        val wi = pWidth.toDouble() / dm.xdpi.toDouble()
        val hi = pHeight.toDouble() / dm.ydpi.toDouble()
        val x = Math.pow(wi, 2.0)
        val y = Math.pow(hi, 2.0)
        val screenInches = Math.sqrt(x + y)

        /*** Screen default orientation */
        var screenOrientation:String?=null
        when {
            activity?.resources?.configuration?.orientation == Configuration.ORIENTATION_PORTRAIT -> screenOrientation = context?.getString(R.string.orientation_portrait)
            activity?.resources?.configuration?.orientation == Configuration.ORIENTATION_LANDSCAPE -> screenOrientation = context?.getString(R.string.orientation_landscape)
            activity?.resources?.configuration?.orientation == Configuration.ORIENTATION_UNDEFINED -> screenOrientation = context?.getString(R.string.orientation_undefined)
        }

        /*** Screen Display buckets */
        var displayBuckets:String?=null
        when {
            activity?.resources?.displayMetrics?.density == .75f -> displayBuckets = context?.getString(R.string.ldpi)
            activity?.resources?.displayMetrics?.density == 1.0f -> displayBuckets = context?.getString(R.string.mdpi)
            activity?.resources?.displayMetrics?.density == 1.5f -> displayBuckets = context?.getString(R.string.hdpi)
            activity?.resources?.displayMetrics?.density == 2.0f -> displayBuckets = context?.getString(R.string.xhdpi)
            activity?.resources?.displayMetrics?.density == 3.0f -> displayBuckets = context?.getString(R.string.xxhdpi)
            activity?.resources?.displayMetrics?.density == 4.0f -> displayBuckets = context?.getString(R.string.xxxhdpi)
        }

        /*** Screen usable width and height */
        val size = Point()
        display.getSize(size)

//        parents.add(ParentModel("Screen Information",ArrayList<FeaturesHW>()))
        parents.add(ParentModel(getString(R.string.screen_information),ArrayList<FeaturesHW>()))
        val lists: ArrayList<FeaturesHW> = parents.get(0).lists
        lists.add(FeaturesHW(getString(R.string.screen_size), "${getProperText(screenSizes)}"))
        lists.add(FeaturesHW(getString(R.string.screen_physical_size), "${getProperText(returnToDecimalPlaces(screenInches).plus(context?.getString(R.string.inches)))}"))
        lists.add(FeaturesHW(getString(R.string.default_screen_orientation), "${getProperText(screenOrientation)}"))
        lists.add(FeaturesHW(getString(R.string.refresh), "${getProperText(display.refreshRate.toString().plus(context?.getString(R.string.fps)))}"))
        lists.add(FeaturesHW(getString(R.string.screen_total_width), "${getProperText(pWidth.toString().plus(context?.getString(R.string.px)))}"))
        lists.add(FeaturesHW(getString(R.string.screen_total_height), "${getProperText(pHeight.toString().plus(context?.getString(R.string.px)))}"))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            lists.add(FeaturesHW(getString(R.string.name), "${display.name.toString()}"))
        }

        //parents.add(ParentModel("Density Information",ArrayList<FeaturesHW>()))
        parents.add(ParentModel(getString(R.string.density_information),ArrayList<FeaturesHW>()))
        val lists2: ArrayList<FeaturesHW> = parents.get(1).lists
        lists2.add(FeaturesHW(getString(R.string.screen_display_bucket), "${getProperText(displayBuckets)}"))
        lists2.add(FeaturesHW(getString(R.string.screen_dpi), "${getProperText(activity?.resources?.displayMetrics?.densityDpi.toString().plus(context?.getString(R.string.dpi)))}"))
        lists2.add(FeaturesHW(getString(R.string.xdpi), "${getProperText(dm.xdpi.toString().plus(context?.getString(R.string.dpi)))}"))
        lists2.add(FeaturesHW(getString(R.string.ydpi), "${getProperText(dm.ydpi.toString().plus(context?.getString(R.string.dpi)))}"))
        lists2.add(FeaturesHW(getString(R.string.screen_logical_density), "${getProperText(dm.density.toString())}"))
        lists2.add(FeaturesHW(getString(R.string.screen_scaled_density), "${getProperText(dm.scaledDensity.toString())}"))

        //parents.add(ParentModel("Resolution Information",ArrayList<FeaturesHW>()))
        parents.add(ParentModel(getString(R.string.resolution_information),ArrayList<FeaturesHW>()))
        val lists3: ArrayList<FeaturesHW> = parents.get(2).lists
        lists3.add(FeaturesHW(getString(R.string.screen_usable_width), "${getProperText(size.x.toString().plus(context?.getString(R.string.px)))}"))
        lists3.add(FeaturesHW(getString(R.string.screen_usable_height), "${getProperText(size.y.toString().plus(context?.getString(R.string.px)))}"))
        lists3.add(FeaturesHW(getString(R.string.density_independent_width), "${getProperText(Utils.pxToDp(context, dm.widthPixels).toString().plus(context?.getString(R.string.dp)))}"))
        lists3.add(FeaturesHW(getString(R.string.density_independent_height), "${getProperText(Utils.pxToDp(context, dm.heightPixels).toString().plus(context?.getString(R.string.dp)))}"))

        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        val adapter = ParentAdapter(parents, requireContext())
        rvFeatureList?.adapter = adapter
//        rvFeatureList?.postDelayed({
//            scrollMain.scrollTo(0,0)
//        },100)
        Handler(Looper.getMainLooper()).postDelayed({
            scrollMain.scrollTo(0,0)
        },100)
//        Handler(Looper.getMainLooper()).postDelayed({
//            scrollMain.scrollTo(0,0)
//            rvFeatureList?.scrollTo(0,0)
//        },500)
    }


    private fun getProperText(textValue: String?) : String {
        if(textValue.isNullOrEmpty()) {
            return getString(R.string.unavailable)
        } else return textValue
    }

    private fun returnToDecimalPlaces(values: Double): String {
        val df = DecimalFormat("#.00", DecimalFormatSymbols(Locale.ENGLISH))
        return df.format(values)
    }
}
