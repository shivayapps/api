package com.backup.restore.device.image.recovery.utilities;


import com.backup.restore.device.image.recovery.retriever.Album;

import java.util.List;

public interface OnFolderLoaded {
    void onFolderLoaded(List<Album> albumList);
    void onSingleFolder(Album album);
    void timeout();
}
