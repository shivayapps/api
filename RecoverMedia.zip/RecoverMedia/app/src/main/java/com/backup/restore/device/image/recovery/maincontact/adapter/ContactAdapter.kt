@file:Suppress("DEPRECATION")

package com.backup.restore.device.image.recovery.maincontact.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.SystemClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.SectionIndexer
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.amulyakhare.textdrawable.TextDrawable
import com.amulyakhare.textdrawable.TextDrawable.IBuilder
import com.amulyakhare.textdrawable.util.ColorGenerator
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.maincontact.callbacks.OnBackupItemClick
import com.backup.restore.device.image.recovery.maincontact.model.ContactModel
import com.backup.restore.device.image.recovery.utilities.common.ShareConstants
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import java.io.IOException
import java.util.*

class ContactAdapter(
    private val context: Context, private var mContactList: ArrayList<ContactModel>,
    private val mOnClickListener: OnBackupItemClick
) : RecyclerView.Adapter<ContactAdapter.ContactView>(), SectionIndexer {

    var miPosition = 0
    private var mSectionPositions: ArrayList<Int>? = null
    private val mColorGenerator = ColorGenerator.MATERIAL
    private var mDrawableBuilder: IBuilder? = null

    override fun getItemId(position: Int): Long {
        return position.toLong()
        //return super.getItemId(position)
    }

    override fun getItemViewType(position: Int): Int {
        return position
        //return super.getItemViewType(position)
    }

    override fun getSectionForPosition(position: Int): Int {
        return 0
    }

    override fun getSections(): Array<String> {
        val sections: MutableList<String> = ArrayList(26)
        mSectionPositions = ArrayList(26)
        var i = 0
        val size = mContactList.size
        while (i < size) {
            val section =
                mContactList[i].mContactName?.substring(0, 1)?.toUpperCase(Locale.getDefault())
            if (!sections.contains(section)) {
                section?.let {
                    sections.add(it)
                    mSectionPositions?.add(i)
                }
            }
            i++
        }
        return sections.toTypedArray()
    }

    override fun getPositionForSection(sectionIndex: Int): Int {
        return mSectionPositions!![sectionIndex]
    }

    class ContactView(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivContact: ImageView = itemView.findViewById(R.id.ivContact)
        var ivPhoto: CircleImageView = itemView.findViewById(R.id.ivPhoto)
        var tvName: TextView = itemView.findViewById(R.id.tvName)
        var tvNumber: TextView = itemView.findViewById(R.id.tvNumber)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactView {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.raw_contact_list_item, parent, false)
        return ContactView(view)
    }

    override fun onBindViewHolder(holder: ContactView, position: Int) {
        if (position != RecyclerView.NO_POSITION) {
            if (mContactList.size > 0) {
//            holder.ivPhoto.setImageResource(R.drawable.no_user_contact_image)

//            var number = "Number not found"
//            val cId = mContactList[position].mContactId
//            if (mContactList[position].isHasPhoneNumber) {
//                number = getContactNumber(cId!!)
//            }
//            mContactList[position].mNumber = number

                if (mContactList[position].mNumber != null)
                    holder.tvNumber.text = mContactList[position].mNumber
//                else {
//                    val cursor = context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(mContactList[position].mContactId), null)
//                    val number = cursor?.getString(cursor.getColumnIndex(ContactsContract.Contacts.Data.DATA1))
//                    mContactList[position].mNumber=number
//                    holder.tvNumber.text = number
//                    cursor?.close()
//                }

                if (mContactList[position].mContactName == null || mContactList[position].mContactName == "") {
                    holder.tvName.text = mContactList[position].mNumber
                } else {
                    holder.tvName.text = mContactList[position].mContactName
                }

//            var bitmap: Bitmap? = null
//            if (mContactList[position].mContactPhoto != null) {
//                bitmap = getProfilePicture(mContactList[position].mContactUri!!)
//            }
                if (mContactList[position].mContactImageUri != null) {
                    Glide.with(context).load(mContactList[position].mContactImageUri)
                        .placeholder(R.drawable.no_user_contact_image).into(holder.ivPhoto)
                } else {
                    if(mContactList[position].mContactName!=null) {

                        if (mContactList[position].mContactName!!.isNotEmpty() && !TextUtils.isDigitsOnly(
                                mContactList[position].mContactName!!.substring(0, 1)
                            )
                        ) {

                            val mTypeface: Typeface =
                                Typeface.createFromAsset(context.assets, "app_font/firasans_medium.ttf")

                            mDrawableBuilder = TextDrawable.builder()
                                .beginConfig()
                                .bold()
                                .useFont(mTypeface)
                                .height(50)
                                .width(50)
                                .endConfig()
                                .round()

                            val drawable = mDrawableBuilder!!.build(
                                mContactList[position].mContactName!![0].toString().capitalize(),
                                mColorGenerator.getColor(mContactList[position].mContactName)
                            )

                            holder.ivPhoto.setImageDrawable(drawable)
                        } else {
                            holder.ivPhoto.setImageDrawable(context.resources.getDrawable(R.drawable.no_user_contact_image))
                        }
                    } else {
                        holder.ivPhoto.setImageDrawable(context.resources.getDrawable(R.drawable.no_user_contact_image))
                    }
                }
            }
            holder.ivContact.setOnClickListener {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                MyApplication.isInternalCall = true
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:" + mContactList[position].mNumber)
                context.startActivity(intent)
            }
            holder.itemView.setOnClickListener {
                if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                    return@setOnClickListener
                }
                ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
                miPosition = position
                mOnClickListener.onContactItemClick(mContactList[position], position)
            }
        }
    }

    private fun getProfilePicture(uri: String): Bitmap? {
        var bitmap: Bitmap? = null
        Log.e("TAG", "getProfilePicture: uri -$uri")
        try {
            bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, Uri.parse(uri))
        } catch (e: IOException) {
            Log.e("TAG", "getProfilePicture: $e")
            e.printStackTrace()
        }
        return bitmap
    }

    private fun getContactNumber(id: String): String {
        var number = ""
        val pCur = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
            arrayOf(id),
            null
        )
        while (pCur!!.moveToNext()) {
            number =
                pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
            break
        }
        pCur.close()
        return number
    }

    fun setList(list: ArrayList<ContactModel>) {
        mContactList.clear()
        mContactList.addAll(list)
        //notifyItemRangeInserted(0,list.size)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return mContactList.size
    }
}