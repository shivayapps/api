package com.backup.restore.device.image.recovery.mainapps.model

import java.util.*

data class SensorModel(
    val title: String = "",
    val lists: ArrayList<SensorDATA> = ArrayList<SensorDATA>()
)