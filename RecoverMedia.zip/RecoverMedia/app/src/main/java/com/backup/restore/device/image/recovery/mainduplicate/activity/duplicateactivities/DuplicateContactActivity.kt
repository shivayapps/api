package com.backup.restore.device.image.recovery.mainduplicate.activity.duplicateactivities

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.Dialog
import android.content.*
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.AsyncTask
import android.os.Bundle
import android.os.SystemClock
import android.provider.ContactsContract
import android.util.Log
import android.view.*
import android.view.View.ROTATION
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityOptionsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.backup.restore.device.image.recovery.MyCommonBaseActivity
import com.backup.restore.device.image.recovery.R
import com.backup.restore.device.image.recovery.ads.openad.MyApplication
import com.backup.restore.device.image.recovery.ads.rateandfeedback.ExitSPHelper
import com.backup.restore.device.image.recovery.database.DBAdapter
import com.backup.restore.device.image.recovery.databinding.ActivityDuplicateContactBinding
import com.backup.restore.device.image.recovery.main.NewHomeActivity
import com.backup.restore.device.image.recovery.mainduplicate.activity.scanningactivities.DuplicateContactScanningActivity
import com.backup.restore.device.image.recovery.mainduplicate.adapter.IndividualContactAdapter
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateContactModel
import com.backup.restore.device.image.recovery.mainduplicate.model.DuplicateNumberListModel
import com.backup.restore.device.image.recovery.utilities.changeLanguage
import com.backup.restore.device.image.recovery.utilities.common.*
import com.backup.restore.device.image.recovery.utilities.common.SharedPrefsConstant.*
import java.util.*
import kotlin.collections.ArrayList

class DuplicateContactActivity : MyCommonBaseActivity() {

    var mTAG: String = javaClass.simpleName
    var mLayoutManager1: LinearLayoutManager? = null

    //    var mLayoutManager2: LinearLayoutManager? = null
//    var mLayoutManager3: LinearLayoutManager? = null
    var index = -1
    var top = -1
    var mDuplicateFound = 0

    //    var mDuplicateContactNumberList = ""
//    var mDuplicateContactNameList = ""
//    var mDuplicateContactEmailList = ""
    var individualContactAdapter: IndividualContactAdapter? = null
    var mDBAdapter: DBAdapter? = null
    private var mIsFrom = "Number"

    var mMergeDuplicateFound = 0

    var isFromOneSignal = false

    companion object {
        var lNumberList = ArrayList<DuplicateNumberListModel>()
        var lNameList = ArrayList<DuplicateNumberListModel>()
        var lEmailList = ArrayList<DuplicateNumberListModel>()
    }

//    override fun attachBaseContext(newBase: Context) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
//    }

    lateinit var binding:ActivityDuplicateContactBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_duplicate_contact)
        binding=ActivityDuplicateContactBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    override fun getContext(): AppCompatActivity {
        return this@DuplicateContactActivity
    }

    override fun initData() {
        mDBAdapter = DBAdapter(mContext)
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        setSupportActionBar(binding.toolbar)

        mLayoutManager1 = LinearLayoutManager(mContext)
        binding.recyclerViewContactByNumber!!.layoutManager = mLayoutManager1
        binding.recyclerViewContactByNumber!!.setHasFixedSize(true)

        if (lNumberList.size >= lNameList.size && lNumberList.size >= lEmailList.size) {
            Log.e(mTAG, "initData:lNumberList ")
            mIsFrom = "Number"
            binding.tvSelectionContact.setText(R.string.duplicate_by_number)
            if (lNumberList.isEmpty()) {
                binding.llNoDuplicate.visibility = View.VISIBLE
            } else {
                mDuplicateFound = lNumberList.size
                (findViewById<View>(R.id.dupes_found) as TextView).text =
                    getString(R.string.duplicate_found) + mDuplicateFound
                binding.RelativeNumber.visibility = View.VISIBLE
                individualContactAdapter = IndividualContactAdapter(mContext, lNumberList, true)
                binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                individualContactAdapter!!.notifyDataSetChanged()
            }
        } else if (lNameList.size >= lNumberList.size && lNameList.size >= lEmailList.size) {
            Log.e(mTAG, "initData:lNameList ")
            mIsFrom = "Name"
            binding.tvSelectionContact.setText(R.string.duplicate_by_name)
            if (lNameList.isEmpty()) {
                binding.llNoDuplicate.visibility = View.VISIBLE
            } else {
                mDuplicateFound = lNameList.size
                (findViewById<View>(R.id.dupes_found) as TextView).text =
                    getString(R.string.duplicate_found) + mDuplicateFound
                binding.RelativeNumber.visibility = View.VISIBLE
                individualContactAdapter = IndividualContactAdapter(mContext, lNameList, true)
                binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                individualContactAdapter!!.notifyDataSetChanged()
            }
        } else {
            Log.e(mTAG, "initData:lEmailList ")
            mIsFrom = "Email"
            binding.tvSelectionContact.setText(R.string.duplicate_by_email)
            if (lEmailList.isEmpty()) {
                binding.llNoDuplicate.visibility = View.VISIBLE
            } else {
                mDuplicateFound = lEmailList.size
                (findViewById<View>(R.id.dupes_found) as TextView).text =
                    getString(R.string.duplicate_found) + mDuplicateFound
                binding.RelativeNumber.visibility = View.VISIBLE
                individualContactAdapter = IndividualContactAdapter(mContext, lEmailList, true)
                binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                individualContactAdapter!!.notifyDataSetChanged()
            }
        }
    }

    override fun initActions() {
        binding.merge!!.setOnClickListener(this)
        binding.backPressContact!!.setOnClickListener(this)
        binding.llSelectionContact!!.setOnClickListener { v: View ->
            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val point = Point()
            point.x = location[0]
            point.y = location[1]
            showStatusPopup(mContext, point, binding.llSelectionContact)
        }
    }

    private fun showStatusPopup(context: Activity, p: Point, anchor: View) {
        val layoutInflater = context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val layout = layoutInflater.inflate(R.layout.dialog_new_custom_for_contact, null)
        val changeStatusPopUp = PopupWindow(context)
        changeStatusPopUp.contentView = layout
        changeStatusPopUp.width = LinearLayout.LayoutParams.MATCH_PARENT
        changeStatusPopUp.height = LinearLayout.LayoutParams.WRAP_CONTENT
        changeStatusPopUp.isFocusable = true

        val main = layout.findViewById<LinearLayout>(R.id.main)
        main.setOnClickListener { changeStatusPopUp.dismiss() }

        val llEmail: ConstraintLayout = layout.findViewById(R.id.llEmail)
        val lIvEmail = layout.findViewById<ImageView>(R.id.iv_select_Email)

        val llNumber: ConstraintLayout = layout.findViewById(R.id.llNumber)
        val lIvNumber = layout.findViewById<ImageView>(R.id.iv_select_Number)

        val llName: ConstraintLayout = layout.findViewById(R.id.llName)
        val lIvName = layout.findViewById<ImageView>(R.id.iv_select_Name)

        when (mIsFrom) {
            "Number" -> {
                lIvNumber.visibility = View.VISIBLE
                lIvEmail.visibility = View.INVISIBLE
                lIvName.visibility = View.INVISIBLE
            }
            "Email" -> {
                lIvEmail.visibility = View.VISIBLE
                lIvNumber.visibility = View.INVISIBLE
                lIvName.visibility = View.INVISIBLE
            }
            else -> {
                lIvEmail.visibility = View.INVISIBLE
                lIvNumber.visibility = View.INVISIBLE
                lIvName.visibility = View.VISIBLE
            }
        }

        llNumber.setOnClickListener {
            if (mIsFrom != "Number") {
                mIsFrom = "Number"
                binding.tvSelectionContact.setText(R.string.duplicate_by_number)
                if (lNumberList.isEmpty()) {
                    binding.llNoDuplicate.visibility = View.VISIBLE
                    mDuplicateFound = 0
                } else {
                    binding.llNoDuplicate.visibility = View.GONE
                    mDuplicateFound = lNumberList.size
                    (findViewById<View>(R.id.dupes_found) as TextView).text =
                        getString(R.string.duplicate_found) + mDuplicateFound
                    binding.RelativeNumber.visibility = View.VISIBLE
                    individualContactAdapter = IndividualContactAdapter(mContext, lNumberList, true)
                    binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                    individualContactAdapter!!.notifyDataSetChanged()

                }
                changeStatusPopUp.dismiss()
            }
            changeStatusPopUp.dismiss()
        }
        llEmail.setOnClickListener {
            if (mIsFrom != "Email") {
                mIsFrom = "Email"
                binding.tvSelectionContact!!.setText(R.string.duplicate_by_email)
                if (lEmailList.isEmpty()) {
                    mDuplicateFound = 0
                    binding.llNoDuplicate.visibility = View.VISIBLE
                } else {
                    binding.llNoDuplicate.visibility = View.GONE
                    mDuplicateFound = lEmailList.size
                    (findViewById<View>(R.id.dupes_found) as TextView).text =
                        getString(R.string.duplicate_found) + mDuplicateFound
                    individualContactAdapter = IndividualContactAdapter(mContext, lEmailList, true)
                    binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                    individualContactAdapter!!.notifyDataSetChanged()
                    binding.RelativeNumber.visibility = View.VISIBLE
                }
                changeStatusPopUp.dismiss()
            }
            changeStatusPopUp.dismiss()
        }
        llName.setOnClickListener {
            if (mIsFrom != "Name") {
                mIsFrom = "Name"
                binding.tvSelectionContact!!.setText(R.string.duplicate_by_name)
                if (lNameList.isEmpty()) {
                    mDuplicateFound = 0
                    binding.llNoDuplicate.visibility = View.VISIBLE
                } else {
                    binding.llNoDuplicate.visibility = View.GONE
                    mDuplicateFound = lNameList.size
                    (findViewById<View>(R.id.dupes_found) as TextView).text =
                        getString(R.string.duplicate_found) + mDuplicateFound
                    individualContactAdapter = IndividualContactAdapter(mContext, lNameList, true)
                    binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                    individualContactAdapter!!.notifyDataSetChanged()
                    binding.RelativeNumber.visibility = View.VISIBLE

                }
                changeStatusPopUp.dismiss()
            }
            changeStatusPopUp.dismiss()
        }
        changeStatusPopUp.setOnDismissListener {
            ObjectAnimator.ofFloat((binding.select as ImageView), ROTATION.name, -180f, 0f).start()
        }
        changeStatusPopUp.setBackgroundDrawable(BitmapDrawable())
//        changeStatusPopUp.showAtLocation(layout, Gravity.NO_GRAVITY, p.x, p.y)
        changeStatusPopUp.showAsDropDown(anchor, -20, 0)
        ObjectAnimator.ofFloat((binding.select as ImageView), ROTATION.name, 180f).setDuration(500).start()
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        when (view.id) {
            R.id.backPress_contact -> onBackPressed()
            R.id.merge -> mergeDuplicate()
        }
    }

    private fun mergeDuplicate() {
        Log.e(mTAG, "mergeDuplicate: " + individualContactAdapter!!.getSelectedCounted())
        if (individualContactAdapter!!.getSelectedCounted() == 0) {
            MyUtils.showToastMsg(mContext, getString(R.string.select_at_least_one_contact))
        } else {
            val dialog = Dialog(mContext)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_confirmation)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            dialog.findViewById<TextView>(R.id.permission).text =
                getString(R.string.merge_alert_title)
            if (individualContactAdapter!!.getSelectedCounted() == 1) {
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.merge_alert_message_contact_single)
            } else {
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.merge_alert_message_contact)
            }

            dialog.findViewById<TextView>(R.id.dialogButtonOk).text = getString(R.string.yes)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.no)

            dialog.findViewById<Button>(R.id.dialogButtonOk).setOnClickListener {
                dialog.cancel()
                MyApplication.isDialogOpen = false
                mMergeDuplicateFound = individualContactAdapter!!.getSelectedCounted()
                MergeDuplicateContact().execute()
                save(
                    mContext,
                    ShareConstants.RATE_DUPLICATE_COUNT,
                    getInt(mContext, ShareConstants.RATE_DUPLICATE_COUNT) + 1
                )

            }
            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                dialog.cancel()
                MyApplication.isDialogOpen = false

            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }

            dialog.show()
            MyApplication.isDialogOpen = true

        }

    }

    private inner class MergeDuplicateContact : AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(mContext)

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_delete_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            dialog.findViewById<Button>(R.id.dialogButtonCancel).visibility = View.GONE

            if (individualContactAdapter!!.getSelectedCounted() == 1) {
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.merge_dialog_message_contact_single)
            } else {
                dialog.findViewById<TextView>(R.id.permission_text).text =
                    getString(R.string.merge_dialog_message_contact)
            }
            dialog.setOnDismissListener {
                MyApplication.isDialogOpen = false
            }


            if (!dialog.isShowing) {
                dialog.show()
                MyApplication.isDialogOpen = true
            }
        }

        override fun doInBackground(vararg strings: String?): String? {
            val selectedList = individualContactAdapter!!.getSelectedList()
            selectedList.forEach {
//                Log.e(mTAG, "mergeDuplicate: " + Gson().toJson(it))
                mergeContacts(it.mNumberList)
                runOnUiThread {
                    when (mIsFrom) {
                        "Number" -> {
                            lNumberList.remove(it)
                        }
                        "Email" -> {
                            lEmailList.remove(it)
                        }
                        "Name" -> {
                            lNameList.remove(it)
                        }
                    }
//                    individualContactAdapter!!.notifyItemRemoved(selectedList.indexOf(it))
                }
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)
            try {

                when (mIsFrom) {
                    "Number" -> {
                        if (lNumberList.isEmpty()) {
                            binding.llNoDuplicate.visibility = View.VISIBLE
                            mDuplicateFound = 0
                        } else {
                            binding.llNoDuplicate.visibility = View.GONE
                            mDuplicateFound = lNumberList.size
                            binding.dupesFound.text = getString(R.string.duplicate_found) + mDuplicateFound
                        }
                    }
                    "Email" -> {
                        if (lEmailList.isEmpty()) {
                            binding.llNoDuplicate.visibility = View.VISIBLE
                            mDuplicateFound = 0
                        } else {
                            binding.llNoDuplicate.visibility = View.GONE
                            mDuplicateFound = lEmailList.size
                            binding.dupesFound.text = getString(R.string.duplicate_found) + mDuplicateFound
                        }
                    }
                    "Name" -> {
                        if (lNameList.isEmpty()) {
                            binding.llNoDuplicate.visibility = View.VISIBLE
                            mDuplicateFound = 0
                        } else {
                            binding.llNoDuplicate.visibility = View.GONE
                            mDuplicateFound = lNameList.size
                            binding.dupesFound.text = getString(R.string.duplicate_found) + mDuplicateFound
                        }
                    }
                }
                individualContactAdapter!!.notifyDataSetChanged()
                try {
                    if (dialog != null && dialog.isShowing) {
                        dialog.cancel()
                        MyApplication.isDialogOpen = false
                    }
                } catch (e: Exception) {
//                    mContext.addEvent(e.message!!)
                }
                showRegainDialog()
//                Toast.makeText(mContext, "Contact Merge Successfully", Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun mergeContacts(contacts: ArrayList<DuplicateContactModel>) {
        //make sure is sorted in ascending order.

        contacts.sortWith { o1, o2 -> o1.mContactId!!.compareTo(o2.mContactId!!) }
        val rawId: String = contacts[0].mRawContactId!! //ContactsContract.RawContacts._ID
        val ops: ArrayList<ContentProviderOperation> = ArrayList()
        var currentContact: DuplicateContactModel
        for (index in 1 until contacts.size) {
            currentContact = contacts[index]
            ops.add(
                ContentProviderOperation.newUpdate(ContactsContract.AggregationExceptions.CONTENT_URI)
                    .withValue(
                        ContactsContract.AggregationExceptions.TYPE,
                        ContactsContract.AggregationExceptions.TYPE_KEEP_TOGETHER
                    )
                    .withValue(ContactsContract.AggregationExceptions.RAW_CONTACT_ID1, rawId)
                    .withValue(
                        ContactsContract.AggregationExceptions.RAW_CONTACT_ID2,
                        currentContact.mRawContactId
                    ).build()
            )
            Log.d(
                mTAG,
                "mergeContacts: merge contacts: " + rawId + " - " + currentContact.mRawContactId
            )
        }
        if (ops.isNotEmpty()) {
            try {
                val result = contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                Log.d(mTAG, "mergeContacts: result: " + result.size)
            } catch (e: Exception) {
                Log.d(mTAG, "mergeContacts: merge Exception: " + e)
            }
        }
    }

    private fun showRegainDialog() {
        val dialog = Dialog(mContext)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_memory_regained)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog.findViewById<TextView>(R.id.permission).text = getString(R.string.duplicate_merge)

        val tv1 = dialog.findViewById<TextView>(R.id.cleaned_photo)
        tv1.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv1.text = getString(R.string.contact_merge) + mMergeDuplicateFound

        val tv2 = dialog.findViewById<TextView>(R.id.cleaned_memory)
        tv2.setTextColor(ViewCompat.MEASURED_STATE_MASK)
        tv2.visibility = View.GONE

        dialog.findViewById<View>(R.id.dialogButtonrescan).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false
            mDBAdapter?.deleteAll()
            intent = Intent(mContext, DuplicateContactScanningActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(
                intent,
                ActivityOptionsCompat.makeCustomAnimation(
                    mContext,
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
                ).toBundle()
            )
            finish()
        }
        dialog.findViewById<View>(R.id.dialogButtonok).setOnClickListener {
            dialog.cancel()
            MyApplication.isDialogOpen = false

            val isRated = ExitSPHelper(mContext).isRated()
            if (!isRated) {
                if (getInt(
                        mContext,
                        ShareConstants.RATE_DUPLICATE_COUNT
                    ) >= 3 && SharedPrefsConstant.getInt(
                        mContext,
                        ShareConstants.RATE_LATTER,
                        1
                    ) == 0
                ) {
                    RatingDialog.smileyRatingDialog(mContext)
                } else {
                }
            }

        }

        dialog.setOnDismissListener {
            MyApplication.isDialogOpen = false
        }


        dialog.show()
        MyApplication.isDialogOpen = true
    }

    public override fun onPause() {
        var i = 0
        super.onPause()
        index = mLayoutManager1!!.findFirstVisibleItemPosition()
        val v = binding.recyclerViewContactByNumber!!.getChildAt(0)
        if (v != null) {
            i = v.top - binding.recyclerViewContactByNumber!!.paddingTop
        }
        top = i
    }

    public override fun onResume() {
        super.onResume()
        changeLanguage()
        if (index != -1) {
            mLayoutManager1!!.scrollToPositionWithOffset(index, top)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.settings_1, menu)
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
        }
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (mDuplicateFound == 0) {
            menu.findItem(R.id.action_selectall).isEnabled = false
            menu.findItem(R.id.action_deselectall).isEnabled = false
        } else {
            menu.findItem(R.id.action_selectall).isEnabled = true
            menu.findItem(R.id.action_deselectall).isEnabled = true
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val intent: Intent
        when (id) {
            R.id.action_home -> {
                mDBAdapter?.deleteAll()
                finish()
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//                intent = Intent(mContext, NewHomeActivity::class.java)
//                intent.addFlags(335544320)
//                startActivity(intent, ActivityOptionsCompat.makeCustomAnimation(mContext, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
//                finish()
                return true
            }
            R.id.action_rescan -> {
                mDBAdapter?.deleteAll()
                GlobalVarsAndFunctions.resetOneTimePopUp()
                intent = Intent(mContext, DuplicateContactScanningActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(
                    intent,
                    ActivityOptionsCompat.makeCustomAnimation(
                        mContext,
                        android.R.anim.fade_in,
                        android.R.anim.fade_out
                    ).toBundle()
                )
                finish()
                return true
            }
            R.id.action_selectall -> {
                if (mDuplicateFound == 0) {
//                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(true, mIsFrom)
                }
                return true
            }
            R.id.action_deselectall -> {
                if (mDuplicateFound == 0) {
//                    Toast.makeText(mContext, "No Duplicate Data Found", Toast.LENGTH_SHORT).show()
                } else {
                    imagesSelectAllAndDeselectAll(false, mIsFrom)
                }
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        Log.e(mTAG, "onBackPressed:->start")
        mDBAdapter?.deleteAll()
        if (isFromOneSignal) {
            Log.e(mTAG, "onBackPressed:->001")
            startActivity(NewHomeActivity.newIntent(this))
            finish()
        } else {
            Log.e(mTAG, "onBackPressed:->002")
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        Log.e(mTAG, "onBackPressed:->exit")
    }

    private fun imagesSelectAllAndDeselectAll(isSelect: Boolean, mIsFrom: String) {
        when (mIsFrom) {
            "Number" -> {
                individualContactAdapter = IndividualContactAdapter(mContext, lNumberList, isSelect)
                binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                individualContactAdapter?.setSelection(isSelect)
                individualContactAdapter!!.notifyDataSetChanged()
            }
            "Name" -> {
                individualContactAdapter = IndividualContactAdapter(mContext, lNameList, isSelect)
                binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                individualContactAdapter?.setSelection(isSelect)
                individualContactAdapter!!.notifyDataSetChanged()
            }
            "Email" -> {
                individualContactAdapter = IndividualContactAdapter(mContext, lEmailList, isSelect)
                binding.recyclerViewContactByNumber!!.adapter = individualContactAdapter
                individualContactAdapter?.setSelection(isSelect)
                individualContactAdapter!!.notifyDataSetChanged()
            }
        }
    }
}