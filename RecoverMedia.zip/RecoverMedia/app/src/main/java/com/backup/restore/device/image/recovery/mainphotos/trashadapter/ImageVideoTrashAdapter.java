package com.backup.restore.device.image.recovery.mainphotos.trashadapter;

import static com.backup.restore.device.image.recovery.utilities.UtilsKt.doCopyFile;
import static com.backup.restore.device.image.recovery.utilities.common.ShareConstants.getReadableFileSize;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.aainc.recyclebin.d.c;
import com.aainc.recyclebin.database.FilesProtectionContentProvider;
import com.backup.restore.device.image.recovery.R;
import com.backup.restore.device.image.recovery.mainphotos.model.TrashModel;
import com.backup.restore.device.image.recovery.mainphotos.trashfragment.TrashImageFragment;
import com.backup.restore.device.image.recovery.mainphotos.trashfragment.TrashVideoFragment;
import com.bumptech.glide.Glide;

import java.io.File;
import java.io.IOException;

public class ImageVideoTrashAdapter extends CursorAdapter {

    public static final String j = ImageVideoTrashAdapter.class.getSimpleName();
    Fragment mFragment;
    String mType = "";
    CheckBox mCheckBox;
    Cursor cursor;
    String isForSort;

    public ImageVideoTrashAdapter(Context context, Fragment fragment, Cursor cursor, int i, String type, CheckBox checkAll, String isForSort) {
        super(context, cursor, i);
        mType = type;
        mFragment = fragment;
        mCheckBox = checkAll;
        this.cursor = cursor;
        this.isForSort = isForSort;
    }

    public void selectAll() {
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                int id = cursor.getInt(0);
                String path = cursor.getString(3);

                TrashModel lTrashModel = new TrashModel();
                lTrashModel.setPath(path);
                lTrashModel.setId(id);

                if (mFragment instanceof TrashImageFragment) {
                    if (!((TrashImageFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashImageFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashImageFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
                if (mFragment instanceof TrashVideoFragment) {
                    if (!((TrashVideoFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashVideoFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashVideoFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
            }
            while (cursor.moveToNext());
            notifyDataSetChanged();
        }
    }

    public void deSelectAll() {
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                int id = cursor.getInt(0);
                String path = cursor.getString(3);

                TrashModel lTrashModel = new TrashModel();
                lTrashModel.setPath(path);
                lTrashModel.setId(id);

                if (mFragment instanceof TrashImageFragment) {
                    if (((TrashImageFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashImageFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashImageFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
                if (mFragment instanceof TrashVideoFragment) {
                    if (((TrashVideoFragment) mFragment).getSelectedList().contains(lTrashModel))
                        ((TrashVideoFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashVideoFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
            }
            while (cursor.moveToNext());
            notifyDataSetChanged();
        }
    }


    private class myCommonClass {

        TextView tvDir;
        ImageView thumbnail;
        ImageView rlItem;
        ImageView imgType;
        FrameLayout rlItemFrame;

        private myCommonClass() {
        }
    }

    public ObjectAnimator a(View view, float f, float f2) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, "rotation", new float[]{f, f2});
        ofFloat.setDuration(300);
        return ofFloat;
    }

    public int b(Context context, int i) {
        return context.getContentResolver().delete(FilesProtectionContentProvider.a, "_id = ? ", new String[]{String.valueOf(i)});
    }

    public Cursor a(Context context) {
        String whereClause = "type_file=?";
        String[] whereArgs = {mType};
        String sortOrder = "";
        switch (isForSort) {
            case "size_asc":
                sortOrder = "file_size ASC";
                break;
            case "size_desc":
                sortOrder = "file_size DESC";
                break;
            case "date_desc":
                sortOrder = "deleted_at ASC";
                break;
            case "date_asc":
                sortOrder = "deleted_at DESC";
                break;
        }
        return context.getContentResolver().query(FilesProtectionContentProvider.a, null, whereClause, whereArgs, sortOrder);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        Log.e("TAG", "newView method=====================================");
        View inflate = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.raw_image_item, viewGroup, false);

        return inflate;
    }

    public void recover(Activity mContext, String path, int ids) {
        try {
            Integer num = Integer.parseInt(String.valueOf(ids));
            Log.e("TAG", "recover: " + num);
            synchronized (this) {
                String a2 = a(mContext, num);
                Log.e("mTAGs", "recover:a2 " + a2);
                Log.e("mTAGs", "recover:path " + path);
                //FileUtils.copyFile(new File(a2), new File(path));
                doCopyFile(new File(a2), new File(path),true);
                MediaScannerConnection.scanFile(mContext,
                        new String[]{new File(path).getAbsolutePath()}, null,
                        (path1, uri) -> {
                            Log.e("ExternalStorage", "Scanned " + path1 + ":");
                            Log.e("ExternalStorage", "-> uri=" + uri);
                        });
//                c.b(a2, path);
                if (!c.c(a2)) {
                    throw new IOException("Restored file can't be deleted from myfrgamant database protected files and device storage.");
                } else if (b(mContext, num.intValue()) == 0) {
                    throw new SQLiteException("Data about restored file can't be removed from myfrgamant database.");
                }
            }
//            Cursor a3 = a(mContext);
//            changeCursor(a3);
        } catch (Exception e) {
            Log.e("recover", "-> Exception=" + e);
            e.printStackTrace();
        }
    }

    public String a(Context context, int i) {
        Uri.Builder builder = new Uri.Builder();
        builder.scheme(FilesProtectionContentProvider.a.getScheme());
        builder.authority(FilesProtectionContentProvider.a.getAuthority());
        for (String appendPath : FilesProtectionContentProvider.a.getPathSegments()) {
            builder.appendPath(appendPath);
        }
        builder.appendEncodedPath(String.valueOf(i));
        Cursor query = context.getContentResolver().query(builder.build(), new String[]{"trash_path"}, null, null, null);
        if (query == null || !query.moveToFirst()) {
        }
        String string = query.getString(0);
        if (string != null) {
            return string;
        }
        return null;
    }

    @Override
    public void bindView(View view, final Context context, final Cursor cursor) {

        myCommonClass lMyCommonClass = new myCommonClass();

        lMyCommonClass.tvDir = view.findViewById(R.id.tvDir);
        lMyCommonClass.thumbnail = view.findViewById(R.id.imgItem);
        lMyCommonClass.rlItem = view.findViewById(R.id.rlItem);
        lMyCommonClass.imgType = view.findViewById(R.id.imgType);
        lMyCommonClass.rlItemFrame = view.findViewById(R.id.rlItemFrame);
        int id = cursor.getInt(0);
        String path = cursor.getString(3);

        if(mType.equalsIgnoreCase("Video")) {
            lMyCommonClass.imgType.setVisibility(View.VISIBLE);
        } else {
            lMyCommonClass.imgType.setVisibility(View.GONE);
        }
        Log.e("mTAG", "bindView: path -> " + path );
        Log.e("mTAG", "bindView: size -> " + getReadableFileSize(new File(path).length()) );
        lMyCommonClass.tvDir.setText(getReadableFileSize(new File(path).length()));
        Glide.with(context).load(path).placeholder(R.drawable.img_thumb).into(lMyCommonClass.thumbnail);


        TrashModel lTrashModel = new TrashModel();
        lTrashModel.setPath(path);
        lTrashModel.setId(id);

        if (mFragment instanceof TrashImageFragment) {
            Log.d("Image ghdsfhg", "bindView: " + ((TrashImageFragment) mFragment).getSelectedList().contains(lTrashModel));
            if (((TrashImageFragment) mFragment).getSelectedList().contains(lTrashModel)) {
                lMyCommonClass.rlItemFrame.setSelected(true);
                lMyCommonClass.rlItem.setSelected(true);
            } else {
                lMyCommonClass.rlItemFrame.setSelected(false);
                lMyCommonClass.rlItem.setSelected(false);
            }
        }
        if (mFragment instanceof TrashVideoFragment) {
            Log.d("Video ghdsfhg", "bindView: " + ((TrashVideoFragment) mFragment).getSelectedList().contains(lTrashModel));
            if (((TrashVideoFragment) mFragment).getSelectedList().contains(lTrashModel)) {
                lMyCommonClass.rlItemFrame.setSelected(true);
                lMyCommonClass.rlItem.setSelected(true);
            } else {
                lMyCommonClass.rlItemFrame.setSelected(false);
                lMyCommonClass.rlItem.setSelected(false);
            }
        }

        lMyCommonClass.rlItemFrame.setOnClickListener(v -> {
            if (lMyCommonClass.rlItemFrame.isSelected()) {
                lMyCommonClass.rlItemFrame.setSelected(false);
                lMyCommonClass.rlItem.setSelected(false);
                if (mFragment instanceof TrashImageFragment) {
                    ((TrashImageFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashImageFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
                if (mFragment instanceof TrashVideoFragment) {
                    ((TrashVideoFragment) mFragment).getSelectedList().remove(lTrashModel);
                    if (cursor.getCount() != ((TrashVideoFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(false);
                    }
                }
            } else {
                lMyCommonClass.rlItemFrame.setSelected(true);
                lMyCommonClass.rlItem.setSelected(true);
                if (mFragment instanceof TrashImageFragment) {
                    if (!((TrashImageFragment) mFragment).getSelectedList().contains(lTrashModel))
                    ((TrashImageFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashImageFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
                if (mFragment instanceof TrashVideoFragment) {
                    if (!((TrashVideoFragment) mFragment).getSelectedList().contains(lTrashModel))
                    ((TrashVideoFragment) mFragment).getSelectedList().add(lTrashModel);
                    if (cursor.getCount() == ((TrashVideoFragment) mFragment).getSelectedList().size()) {
                        mCheckBox.setChecked(true);
                    }
                }
            }
        });
    }

}
