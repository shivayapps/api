package com.backup.restore.device.image.recovery.mainapps.fragment

import android.content.Context
import android.hardware.SensorManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.backup.restore.device.image.recovery.R

import com.backup.restore.device.image.recovery.mainapps.adapter.SensorAdapter
import com.backup.restore.device.image.recovery.mainapps.model.*
import com.backup.restore.device.image.recovery.utilities.common.NetworkManager

/**
 * A placeholder fragment containing a simple view.
 */
class SensorFragmentNew : Fragment() {
    var rootView: View? = null

    var ivType: ImageView? = null
    var tvTitle: TextView? = null
    var tvSubTitle: TextView? = null
    private var rvFeatureList: RecyclerView? = null
    var sensorManager: SensorManager? = null

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"
        @JvmStatic
        fun newInstance(): SensorFragmentNew {
            val fragment = SensorFragmentNew()
            val bundle = Bundle()
            bundle.putInt(ARG_SECTION_NUMBER, 0)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        var index = 1
//        if (arguments != null) {
//            index = arguments!!.getInt(ARG_SECTION_NUMBER)
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rootView = inflater.inflate(R.layout.fragment_device_information, container, false)

        ivType = rootView?.findViewById(R.id.iv_type)
        tvTitle = rootView?.findViewById(R.id.tv_title)
        tvSubTitle = rootView?.findViewById(R.id.tv_sub_title)
        rvFeatureList = rootView?.findViewById(R.id.rv_feature_list)
        rvFeatureList?.layoutManager = GridLayoutManager(activity, 1)
        rvFeatureList?.hasFixedSize()

        sensorManager = activity?.getSystemService(Context.SENSOR_SERVICE) as SensorManager

        getSensorInfo()

//        if (AdsManager(requireActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(requireActivity())) {
            NativeAdHelper(
                requireActivity(),
//                binding.layoutJunkFinished.adview,
                rootView?.findViewById(R.id.adview)!!,
                NativeLayoutType.NativeMedium,getString(R.string.native_application)
            ).loadAd()

//        } else {
//            rootView?.findViewById<FrameLayout>(R.id.adview)?.visibility = View.GONE
//        }

        val scrollMain: NestedScrollView = rootView?.findViewById(R.id.scroll_main)!!
        scrollMain.scrollTo(0,0)
        return rootView
    }

    private fun getSensorInfo(): Unit {
        ivType!!.setImageResource(R.drawable.ic_sensor_info)
        tvTitle!!.text = getString(R.string.sensor_information)
        tvSubTitle!!.text = getString(R.string.sensor_information)
        tvTitle!!.isSelected=true
        tvSubTitle!!.isSelected=true

        val sensorListMethod = SensorListMethod(context)
        val sensorList= sensorListMethod.sensorList

//        val parents = ArrayList<SensorModel>()
//        val pIndex=0

//        val sm = activity?.getSystemService(Context.SENSOR_SERVICE) as SensorManager
//        val list = sm.getSensorList(Sensor.TYPE_ALL)
//        parents.add(SensorModel(resources.getString(R.string.sensor_information),ArrayList<SensorDATA>()))
        val totalSensor=sensorList.size
        tvSubTitle?.text = "$totalSensor ${getString(R.string.sensor_available)}"
//        val lists: ArrayList<SensorDATA> = parents.get(pIndex).lists
//        for (s in list) {
//            lists.add(SensorDATA(s.name, s.type))
//        }

        val adapter = SensorAdapter(requireActivity(),sensorList)

        rvFeatureList?.adapter = adapter

    }


    private fun getSensorDetail(sensorType: String?) : String {
        return ""
    }


    private fun getIPAddress() : String {
        if (Utils.isNetworkConnected(activity)) {
            return Utils.getIPAddress(true)
        } else {
            return getString(R.string.unavailable)
        }
    }

    private fun getProperText(textValue: String?) : String {
        if(textValue.isNullOrEmpty()) {
            return getString(R.string.unavailable)
        } else return textValue
    }

    override fun onDestroyView() {
        super.onDestroyView()
        rootView = null
    }

}