package com.aainc.recyclebin.d;

import android.util.Log;

import java.io.File;

public class c {

    public static String a(String str, String str2) {
        if (str == null || str2 == null) {
            throw new IllegalArgumentException(str == null ? "First parameter is invalid. FileName can't be null." : "Second parameter is invalid. Deleted date can't be null.");
        }
        String[] split = str.split("\\.");
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < split.length - 2) {
            sb.append(split[i]);
            sb.append(".");
            i++;
        }
        sb.append(split[i]);
        sb.append("_");
        sb.append(str2);
        if (split.length != 1) {
            sb.append(".");
            sb.append(split[split.length - 1]);
        }
        return sb.toString();
    }

    public static boolean a(java.lang.String r1) {

        if (r1 == null) {
            return false;

        }
        File r0 = new File(r1);
        if (r0 == null) {
            return false;

        }
        boolean r01 = r0.exists();
        if (!r01) {
            return false;

        }

        return r01;
    }

    public static void b(java.lang.String r7, java.lang.String r8) {
        if (!r8.isEmpty()) {
            java.lang.String r10 = File.separator;
            java.lang.String[] r20 = r8.split(r10);

            int r1 = r20.length;
            int r1v = r1 + -1;
            r10 = r20[r1v];
            java.lang.StringBuilder r1m = new java.lang.StringBuilder(r8);
            int r3 = r8.length();
            int r0f = r20.length;
            int r0g = r3 - r0f;
            int rv3 = r8.length();

            Log.e("TAG-->", "r0g--->>>: " + r20[r1v]);
            Log.e("TAG-->", "r0g--->>>: " + r0g);
            Log.e("TAG-->", "rv3--->>>: " + rv3);
            r1m.delete(r0g, rv3);
            Log.e("TAG-->", "r1m   r1m  --->>>: " + r1m);

            java.lang.String r1h = r10.toString();
            File rv0 = new File(r1h);
            rv0.mkdirs();


            File r0b = new File(r7);
            Log.e("TAG", "mSimpleDateFormate: MYPATH-->>" + r0b.getAbsolutePath());

            // TODO: 23/08/21 when folder delete
            String pathy = new File(r8).getParent();
            if (!new File(pathy).exists()) {
                new File(pathy).mkdir();
            }


            try {

                java.io.FileInputStream rb3 = new java.io.FileInputStream(r0b);
                java.io.FileOutputStream rb1 = new java.io.FileOutputStream(r8);


                try {

                    byte[] buf = new byte[4096];
                    int len;
                    while ((len = rb3.read(buf)) > 0) {
                        rb1.write(buf, 0, len);
                    }

                } finally {
                    rb1.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


        }

    }

    public static boolean b(java.lang.String r2) {
//        Log.e("FileObserver  ", "mSimpleDateFormate: ==>> ");
        if (r2 != null) {
            File r0 = new File(r2);
            if (r0 == null) {
                return false;
            } else {
                if (r0.exists()) {
                    if (r0.length()>0) {
                        return false;
                    }
                }
            }
        }
        return true;

    }

    public static boolean c(String str) {
        if (str != null) {
            File file = new File(str);
            if (file.exists()) {
                return file.delete();
            }
        }
        return false;
    }

}
