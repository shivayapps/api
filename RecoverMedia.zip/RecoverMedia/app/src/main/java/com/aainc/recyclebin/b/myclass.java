package com.aainc.recyclebin.b;

public class myclass {
    private boolean aBoolean1;
    private String cString;

    public myclass(String str, boolean z, boolean z2) {
        this.cString = str;
        this.aBoolean1 = z2;
    }

    public String a() {
        return this.cString;
    }

    public boolean b() {
        return this.aBoolean1;
    }
}
