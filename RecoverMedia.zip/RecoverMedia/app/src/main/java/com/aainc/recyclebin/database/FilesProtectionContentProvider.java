package com.aainc.recyclebin.database;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.util.Log;

public class FilesProtectionContentProvider extends ContentProvider {
    public static final Uri a = Uri.parse("content://com.aainc.recyclebin.contentprovider/files");
    private static final UriMatcher b = new UriMatcher(-1);
    private SQLiteDatabase c;
    private a d;

    static {
        b.addURI("com.aainc.recyclebin.contentprovider", "files", 1);
        b.addURI("com.aainc.recyclebin.contentprovider", "files/#", 2);
    }

    public int delete(Uri uri, String str, String[] strArr) {
        int delete;
        Log.e("TAG ===>>", "delete: " );
        switch (b.match(uri)) {
            case 1:
                delete = this.c.delete("protected_files", str, strArr);
                break;
            case 2:
                StringBuilder sb = new StringBuilder("_id=" + uri.getLastPathSegment());
                if (str != null || !str.isEmpty()) {
                    sb.append("AND (" + str + ")");
                }
                delete = this.c.delete("protected_files", sb.toString(), strArr);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, (ContentObserver) null);
        return delete;
    }

    public String getType(Uri uri) {
        switch (b.match(uri)) {
            case 1:
                return "vnd.android.cursor.dir/vnd.com.aainc.recyclebin.contentprovider.files";
            case 2:
                return "vnd.android.cursor.item/vnd.com.aainc.recyclebin.contentprovider.files";
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
    }

    public Uri insert(Uri uri, ContentValues contentValues) {

        Log.e("FileObserver", "insert:original_path "+contentValues.get("original_path")+ contentValues.get("file_name") );
        Log.e("FileObserver", "insert:trash_path "+contentValues.get("trash_path") );

        String mp = "original_path: " + contentValues.get("original_path") + contentValues.get("file_name")+ "\n\ntrash_path: " + contentValues.get("trash_path");
//        writeStringAsFile22(getContext(),mp);

        switch (b.match(uri)) {
            case 1:
                long insertOrThrow = this.c.insertOrThrow("protected_files", (String) null, contentValues);
                if (insertOrThrow != -1) {
                    Uri withAppendedId = ContentUris.withAppendedId(uri, insertOrThrow);
                    getContext().getContentResolver().notifyChange(withAppendedId, (ContentObserver) null);
                    return withAppendedId;
                }
                throw new SQLiteException("Failed to insert row into " + uri);
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
    }

    public boolean onCreate() {
        this.d = new a(getContext());
        this.c = this.d.getWritableDatabase();
        return true;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        sQLiteQueryBuilder.setTables("protected_files");
        switch (b.match(uri)) {
            case 1:
                break;
            case 2:
                sQLiteQueryBuilder.appendWhere("_id = " + uri.getLastPathSegment());
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

        Cursor query = sQLiteQueryBuilder.query(this.c, strArr, str, strArr2, (String) null, (String) null,
                (str2 == null || str2.isEmpty()) ? "deleted_at DESC" : str2);
        query.setNotificationUri(getContext().getContentResolver(), uri);
        return query;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        int update;
        switch (b.match(uri)) {
            case 1:
                update = this.c.update("protected_files", contentValues, str, strArr);
                break;
            case 2:
                StringBuilder sb = new StringBuilder("_id=" + uri.getLastPathSegment());
                if (str != null || str.isEmpty()) {
                    sb.append("AND (" + str + ")");
                }
                update = this.c.update("protected_files", contentValues, sb.toString(), strArr);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, (ContentObserver) null);
        return update;
    }
}
