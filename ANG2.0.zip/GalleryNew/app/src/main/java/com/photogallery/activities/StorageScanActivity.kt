package com.photogallery.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.format.Formatter
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityJunkScanBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.getPreviousActivity
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.jobs.cleaner.startDuplicateAudioWorker
import com.photogallery.jobs.cleaner.startDuplicatePhotoWorker
import com.photogallery.jobs.cleaner.startDuplicateVideoWorker
import com.photogallery.jobs.cleaner.startDuplicateDocumentWorker
import com.photogallery.jobs.cleaner.startLargeFileWorker
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.Preferences
import com.photogallery.utils.STOP_DUPLICATE_AUDIO_JUNK
import com.photogallery.utils.STOP_DUPLICATE_DOCUMENT_JUNK
import com.photogallery.utils.STOP_DUPLICATE_PHOTO_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_PHOTO_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_PHOTO_SIZE
import com.photogallery.utils.STOP_DUPLICATE_VIDEO_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_VIDEO_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_VIDEO_SIZE
import com.photogallery.utils.STOP_LARGE_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_AUDIO_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_AUDIO_SIZE
import com.photogallery.utils.UPDATE_DUPLICATE_DOCUMENT_JUNK
import com.photogallery.utils.UPDATE_DUPLICATE_DOCUMENT_SIZE
import com.photogallery.utils.UPDATE_LARGE_JUNK
import com.photogallery.utils.UPDATE_LARGE_SIZE
//import com.photogallery.utils.STOP_SS_JUNK
//import com.photogallery.utils.UPDATE_SS_JUNK
//import com.photogallery.utils.UPDATE_SS_SIZE
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File

class StorageScanActivity : BaseActivity() {

    var allPhoto = ArrayList<MediaData>()
    var allVideo = ArrayList<MediaData>()
    var allFile = ArrayList<MediaData>()
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase

    companion object {
        var selectedRealPhotoData: List<Any> = emptyList()
    }

    lateinit var binding: ActivityJunkScanBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val adId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, adId)
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityJunkScanBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)

        updateStatusBarColor(Color.parseColor("#1878F3"))
        initWindowInsetsController()
        intView()

    }


    @SuppressLint("SetTextI18n")
    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        Log.e("Cleaner.onMessageEvent", "event:$event")
        when (event.type) {
            UPDATE_DUPLICATE_PHOTO_JUNK -> {
                if (event.data is Float) {
                    val percent = event.data as Float
                    if (percent <= 100) {
                        binding.tvDuplicatePhotoSize.setText("${percent.toInt()}%")
                    }
                }
            }

            STOP_DUPLICATE_PHOTO_JUNK -> {
                isDuplicatePhotoRunning = false
                binding.arrowDuplicatePhoto.beVisible()
                binding.progressDuplicatePhoto.beGone()
                updateFinalResult()
            }

            UPDATE_DUPLICATE_PHOTO_SIZE -> {
                if (event.data is Pair<*, *>) {
                    val size = event.data as Pair<Long, Int>

                    duplicatePhotoSize = size.first
                    val sizeStr = Formatter.formatShortFileSize(this@StorageScanActivity, size.first)
//                    binding.tvSubTitleDuplicate.setText(getString(R.string.n_photo_be_cleaned, size.second.toString()))
                    //binding.tvSubTitleDuplicate.beGone()
                    binding.tvDuplicatePhotoSize.beVisible()
                    binding.tvDuplicatePhotoSize.setText(sizeStr)
                }
            }


            UPDATE_DUPLICATE_VIDEO_JUNK -> {
                if (event.data is Float) {
                    val percent = event.data as Float
                    if (percent <= 100) {
                        binding.tvDuplicateVideoSize.setText("${percent.toInt()}%")
                    }

                }
            }

            STOP_DUPLICATE_VIDEO_JUNK -> {
                isDuplicateVideoRunning = false
                binding.arrowDuplicateVideo.beVisible()
                binding.progressDuplicateVideo.beGone()
                updateFinalResult()
            }

            UPDATE_DUPLICATE_VIDEO_SIZE -> {
                if (event.data is Pair<*, *>) {
                    val size = event.data as Pair<Long, Int>

                    duplicateVideoSize = size.first
                    val sizeStr = Formatter.formatShortFileSize(this@StorageScanActivity, size.first)
//                    binding.tvSubTitleDuplicate.setText(getString(R.string.n_photo_be_cleaned, size.second.toString()))
                    //binding.tvSubTitleDuplicate.beGone()
                    binding.tvDuplicateVideoSize.beVisible()
                    binding.tvDuplicateVideoSize.setText(sizeStr)
                }
            }

            UPDATE_DUPLICATE_DOCUMENT_JUNK -> {
                if (event.data is Float) {
                    val percent = event.data as Float
                    if (percent <= 100) {
                        binding.tvDuplicateDocumentSize.setText("${percent.toInt()}%")
                    }

                }
            }

            STOP_DUPLICATE_DOCUMENT_JUNK -> {
                isDuplicateDocumentRunning = false
                binding.arrowDuplicateDocument.beVisible()
                binding.progressDuplicateDocument.beGone()
                updateFinalResult()
            }

            UPDATE_DUPLICATE_DOCUMENT_SIZE -> {
                if (event.data is Pair<*, *>) {
                    val size = event.data as Pair<Long, Int>

                    duplicateDocumentSize = size.first
                    val sizeStr = Formatter.formatShortFileSize(this@StorageScanActivity, size.first)
//                    binding.tvSubTitleDuplicate.setText(getString(R.string.n_photo_be_cleaned, size.second.toString()))
                    //binding.tvSubTitleDuplicate.beGone()
                    binding.tvDuplicateDocumentSize.beVisible()
                    binding.tvDuplicateDocumentSize.setText(sizeStr)
                }
            }

            UPDATE_DUPLICATE_AUDIO_JUNK -> {
                if (event.data is Float) {
                    val percent = event.data as Float
                    if (percent <= 100) {
                        binding.tvDuplicateAudioSize.setText("${percent.toInt()}%")
                    }
                }
            }

            STOP_DUPLICATE_AUDIO_JUNK -> {
                isDuplicateAudioRunning = false
                binding.arrowDuplicateAudio.beVisible()
                binding.progressDuplicateAudio.beGone()
                updateFinalResult()
            }

            UPDATE_DUPLICATE_AUDIO_SIZE -> {
                if (event.data is Pair<*, *>) {
                    val size = event.data as Pair<Long, Int>

                    duplicateAudioSize = size.first
                    val sizeStr = Formatter.formatShortFileSize(this@StorageScanActivity, size.first)
//                    binding.tvSubTitleDuplicate.setText(getString(R.string.n_photo_be_cleaned, size.second.toString()))
                    //binding.tvSubTitleDuplicate.beGone()
                    binding.tvDuplicateAudioSize.beVisible()
                    binding.tvDuplicateAudioSize.setText(sizeStr)
                }
            }

            UPDATE_LARGE_JUNK -> {
                if (event.data is Float) {
                    val percent = event.data as Float
                    binding.tvLargeVideoSize.setText("${percent.toInt()}%")
                }
            }

            STOP_LARGE_JUNK -> {
                isLargeRunning = false
                binding.arrowLargeVideo.beVisible()
                binding.progressLargeVideo.beGone()
                updateFinalResult()
            }

            UPDATE_LARGE_SIZE -> {
                if (event.data is Pair<*, *>) {
                    val size = event.data as Pair<Long, Int>

                    largeSize = size.first
                    val sizeStr = Formatter.formatShortFileSize(this@StorageScanActivity, size.first)
//                    binding.tvSubTitleLargeVideo.setText(getString(R.string.nn_clean_media, size.second.toString(), sizeStr))
                    //binding.tvSubTitleLargeVideo.beGone()
                    binding.tvLargeVideoSize.beVisible()
                    binding.tvLargeVideoSize.setText(sizeStr)
                }
            }

        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }

    var isDuplicatePhotoRunning = false
    var isDuplicateVideoRunning = false
    var isDuplicateDocumentRunning = false
    var isDuplicateAudioRunning = false
    var duplicatePhotoSize = 0L
    var duplicateVideoSize = 0L
    var duplicateDocumentSize = 0L
    var duplicateAudioSize = 0L

    var isLargeRunning = false
    var largeSize = 0L
    var totalCounter: Float = 0F
    var scanCounter: Float = 0F

    private fun intView() {
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        CoroutineScope(Dispatchers.IO).launch {
            Observable.fromCallable {
                getImages()
                true
            }.subscribeOn(Schedulers.io())
                .doOnError { throwable: Throwable? ->
                    Log.e("gettingListPhoto", "getData:" + throwable)
//                    runOnUiThread {
                    setFilterData()
//                    }
                }
                .subscribe { result: Boolean? ->
//                    runOnUiThread {
                    setFilterData()
//                    }
                }
        }
        binding.cardDuplicatePhoto.setOnClickListener {
            if (!isDuplicatePhotoRunning) {
                if (Constant.duplicateRealPhotoData.isNotEmpty()) {
                    selectedRealPhotoData = Constant.duplicateRealPhotoData
                    Log.e("JunkScanActivity", "selectedPhotoData:${Constant.duplicateRealPhotoData.size}")
                    val intent = Intent(this, StorageCleanerActivity::class.java)
                    intent.putExtra("cate", "duplicate_photo")
                    //startActivity(intent)
                    cleanerLauncher.launch(intent)
                } else {
                    toast(getString(R.string.no_photos_videos))
                }
            } else {
                toast(getString(R.string.please_be_patient))
            }
        }
        binding.cardDuplicateVideo.setOnClickListener {
            if (!isDuplicateVideoRunning) {
                if (Constant.duplicateRealVideoData.isNotEmpty()) {
                    selectedRealPhotoData = Constant.duplicateRealVideoData
                    Log.e("JunkScanActivity", "selectedPhotoData:${Constant.duplicateRealVideoData.size}")
                    val intent = Intent(this, StorageCleanerActivity::class.java)
                    intent.putExtra("cate", "duplicate_video")
                    //startActivity(intent)
                    cleanerLauncher.launch(intent)
                } else {
                    toast(getString(R.string.no_photos_videos))
                }
            } else {
                toast(getString(R.string.please_be_patient))
            }
        }
        binding.cardDuplicateDocument.setOnClickListener {
            if (!isDuplicateDocumentRunning) {
                if (Constant.duplicateRealDocumentData.isNotEmpty()) {
                    selectedRealPhotoData = Constant.duplicateRealDocumentData
                    Log.e("JunkScanActivity", "selectedPhotoData:${Constant.duplicateRealDocumentData.size}")
                    val intent = Intent(this, StorageCleanerActivity::class.java)
                    intent.putExtra("cate", "duplicate_document")
                    //startActivity(intent)
                    cleanerLauncher.launch(intent)
                } else {
                    toast(getString(R.string.no_photos_videos))
                }
            } else {
                toast(getString(R.string.please_be_patient))
            }
        }
        binding.cardDuplicateAudio.setOnClickListener {
            if (!isDuplicateAudioRunning) {
                if (Constant.duplicateRealAudioData.isNotEmpty()) {
                    selectedRealPhotoData = Constant.duplicateRealAudioData
                    Log.e("JunkScanActivity", "selectedPhotoData:${Constant.duplicateRealAudioData.size}")
                    val intent = Intent(this, StorageCleanerActivity::class.java)
                    intent.putExtra("cate", "duplicate_audio")
                    //startActivity(intent)
                    cleanerLauncher.launch(intent)
                } else {
                    toast(getString(R.string.no_photos_videos))
                }
            } else {
                toast(getString(R.string.please_be_patient))
            }
        }

//        binding.cardScreenshots.setOnClickListener {
//            if (!isScreenshotRunning) {
//                if (Constant.ssRealPhotoData.isNotEmpty()) {
//                    selectedRealPhotoData = Constant.ssRealPhotoData
//                    Log.e("JunkScanActivity", "selectedPhotoData:${Constant.ssRealPhotoData.size}")
//                    val intent = Intent(this, JunkCleanerActivity::class.java)
//                    intent.putExtra("cate", "screenshots")
//                    //startActivity(intent)
//                    cleanerLauncher.launch(intent)
//                } else {
//                    toast(getString(R.string.no_photos_videos))
//                }
//            } else {
//                toast(getString(R.string.please_be_patient))
//            }
//        }

        binding.cardLargeVideo.setOnClickListener {
            if (!isLargeRunning) {
                if (Constant.largeRealPhotoData.isNotEmpty()) {
                    selectedRealPhotoData = Constant.largeRealPhotoData
                    Log.e("JunkScanActivity", "selectedPhotoData:${Constant.largeRealPhotoData.size}")
                    val intent = Intent(this, StorageCleanerActivity::class.java)
                    intent.putExtra("cate", "largemedia")
                    //startActivity(intent)
                    cleanerLauncher.launch(intent)
                } else {
                    toast(getString(R.string.no_photos_videos))
                }
            } else {
                toast(getString(R.string.please_be_patient))
            }
        }
    }

    var cleanerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            Log.e("JunkScanActivity", "registerForActivityResult:${result.resultCode}")
//            setFilterData()
            if (result.resultCode == Activity.RESULT_OK) setResultFilter()
        }

    private fun setResultFilter() {
        //startScreenshot(allFile)
        startLargeFile(allFile)
        startDuplicatePhoto()
        startDuplicateVideo()
        startDuplicateDocument()
        startDuplicateAudio()
    }

    private fun loadAd() {
//        val isFirstSession = preferences.sessionCounter ==1
//        val adId = if (isFirstSession) getString(R.string.native_cleaner1) else getString(R.string.native_cleaner2)
//        NativeAdHelper(
//            this,
//            binding.frameNative,
//            binding.cardNative,
//            NativeLayoutType.NativeSmall,
//            adId
//        ) { isLoaded ->
//
//        }.loadAd()
    }

    private lateinit var windowInsetsController: WindowInsetsControllerCompat
    private fun initWindowInsetsController() {
        windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun getImages() {
        Log.e("contentResolver.001", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()

        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )

            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val selection = getSelectionQuery()
            val selectionArgs = getSelectionArgsQuery().toTypedArray()

            mCursor = contentResolver?.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
//                Log.e("contentResolver.001", "getImages.mCursor.count::${mCursor.count}")
                mCursor.moveToFirst()
                val photoDataArrayList: ArrayList<MediaData> = ArrayList<MediaData>()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    var fileSizeLength =
                        mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                    //val idColumn = it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns._ID)
                    val idColumn = mCursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val id = mCursor.getLong(idColumn)
                    val contentUri = ContentUris.withAppendedId(uri, id)


//                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty() && !excluded && File(path).exists()) {
                    if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                        var d =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                        d *= 1000
                        var dt =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        if (fileSizeLength < 1) {
                            fileSizeLength = File(path).length()
                        }
                        if (fileSizeLength > 0) {
                            val mediaData =
                                MediaData(path,contentUri.toString(), title, bucketName, d, dt, fileSizeLength, false)
                            allPhoto.add(mediaData)
                            allFile.add(mediaData)
                        }
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            } else Log.e("contentResolver.001", "getImages.mCursor.null::")
        } catch (e: Exception) {
            Log.e("contentResolver.001", "getImages.Exception::$e")
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        getVideos()
    }

    private fun getVideos() {
        Log.e("contentResolver.001", "getVideos")
        var title: String
        var path: String
        val duration: Int
        val uri: Uri =
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

        val projection = arrayOf(
            MediaStore.Video.VideoColumns._ID,
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )


        val folderList: MutableList<String> = ArrayList<String>()

        try {
            val selection = getSelectionQuery()
            val selectionArgs = getSelectionArgsQuery().toTypedArray()

            val cursor = contentResolver?.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )

            if (cursor != null) {
//                Log.e("contentResolver.001", "getVideos.mCursor.count::${cursor.count}")
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

//                    if (!folderList.contains(bucketPath)&& !excluded && File(path).exists()) {
                    if (!folderList.contains(bucketPath)) {
                        var d =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                        d *= 1000
                        var fileSizeLength =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                        var dt =
                            cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns._ID)
//                        val idColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                        val id = cursor.getLong(idColumn)
                        val contentUri = ContentUris.withAppendedId(uri, id)

                        dt *= 1000
                        if (dt == 0L)
                            dt = d

                        if (fileSizeLength < 1) {
                            fileSizeLength = File(path).length()
                        }

//                        Log.e("contentResolver.001", "getVideos path:$path, title:$title, bucketName:$bucketName, d:$d, dt:$dt, fileSizeLength:$fileSizeLength, duration:$duration")
                        if (fileSizeLength > 0) {

                            val mediaData = MediaData(
                                path,
                                contentUri.toString(),
                                title,
                                bucketName,
                                d,
                                dt,
                                fileSizeLength,
                                true,
                                cursor.getLong(duration)
                            )
                            mediaData.isVideo = true
                            allVideo.add(mediaData)
                            allFile.add(mediaData)
                        }

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            } else
                Log.e("contentResolver.001", "getVideos.mCursor.null::")
        } catch (exp: java.lang.Exception) {
            Log.e("contentResolver.001", "Exception.getVideos::$exp")
            exp.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
    }

    private fun setFilterData() {
        totalCounter = ((allFile.size).toFloat())

//        startScreenshot(allFile)
        startLargeFile(allFile)
        startDuplicatePhoto()
        startDuplicateVideo()
        startDuplicateDocument()
        startDuplicateAudio()
    }

    private fun startDuplicatePhoto() {
        isDuplicatePhotoRunning = true
        binding.progressDuplicatePhoto.beVisible()
        CoroutineScope(Dispatchers.IO).launch {
            startDuplicatePhotoWorker()
        }
    }

    private fun startDuplicateVideo() {
        isDuplicateVideoRunning = true
        binding.progressDuplicateVideo.beVisible()
        CoroutineScope(Dispatchers.IO).launch {
            startDuplicateVideoWorker()
        }
    }

    private fun startDuplicateDocument() {
        isDuplicateDocumentRunning = true
        binding.progressDuplicateDocument.beVisible()
        CoroutineScope(Dispatchers.IO).launch {
            startDuplicateDocumentWorker()
        }
    }

    private fun startDuplicateAudio() {
        isDuplicateAudioRunning = true
        binding.progressDuplicateAudio.beVisible()
        CoroutineScope(Dispatchers.IO).launch {
            startDuplicateAudioWorker()
        }
    }

    private fun startLargeFile(allMedia: List<MediaData>) {
        isLargeRunning = true
        binding.progressLargeVideo.beVisible()
        CoroutineScope(Dispatchers.IO).launch {
            startLargeFileWorker(allMedia)
        }
    }

//    private fun startScreenshot(allMedia: List<MediaData>) {
//        isScreenshotRunning = true
//        binding.progressScreenshot.beVisible()
//        CoroutineScope(Dispatchers.IO).launch {
//            startScreenShotWorker(allMedia)
//        }
//    }

    private fun getSelectionQuery(): String {
        val query = StringBuilder()
        photoExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

        rawExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        videoExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(): ArrayList<String> {
        val args = ArrayList<String>()
        photoExtensions.forEach {
            args.add("%$it")
        }
        args.add("%.jpg")
        args.add("%.jpeg")
        rawExtensions.forEach {
            args.add("%$it")
        }
        args.add("%.svg")

        videoExtensions.forEach {
            args.add("%$it")
        }

        args.add("%.gif")
        return args
    }

    private fun updateFinalResult() {
//        if (!isDuplicateRunning && !isScreenshotRunning && !isLargeRunning) {
        if (!isDuplicatePhotoRunning && !isDuplicateVideoRunning && !isDuplicateDocumentRunning && !isDuplicateAudioRunning && !isLargeRunning) {
//            binding.clScanning.beGone()
//            binding.clResult.beVisible()
            val size = getFileSize(duplicatePhotoSize + duplicateVideoSize + duplicateDocumentSize + duplicateAudioSize + largeSize)
//            binding.tvJunkSize.setText("${size.first}")
            binding.tvStatus.setText("Scanning Completed")
            binding.animScan.pauseAnimation()
            binding.animScan.beGone()

            preferences.strCleanCount = "${size.first} ${size.second}"
//            binding.tvJunkStr.setText(getString(R.string.storage_found, size.second))
        }
    }

    fun getFileSize(size: Long): Pair<Long, String> {
        val kb = 1024
        val mb = kb * 1024
        val gb = mb * 1024

        return when {
            size < kb -> Pair(size, "B")
            size < mb -> Pair((size / kb.toDouble()).toLong(), "KB")
            size < gb -> Pair((size / mb.toDouble()).toLong(), "MB")
            else -> Pair((size / gb.toDouble()).toLong(), "GB")
        }
    }

    override fun onBackPressed() {
        val previousActivity = getPreviousActivity()
        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                if (previousActivity.contains("HomeActivity")) {
                    finish()
                } else {
                    val intent = Intent(this, HomeActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    startActivity(intent)
                }
            }
        } else {
            if (previousActivity.contains("HomeActivity")) {
                finish()
            } else {
                val intent = Intent(this, HomeActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
            }
        }
    }
}