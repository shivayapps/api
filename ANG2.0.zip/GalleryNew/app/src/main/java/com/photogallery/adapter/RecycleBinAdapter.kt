package com.photogallery.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.photogallery.R
import com.photogallery.databinding.ItemHeaderBinding
import com.photogallery.databinding.ItemPictureBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TIME_FORMAT_12
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class RecycleBinAdapter(
    var context: Activity,
    var showCounter: Boolean = false,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val headerSelectListener: (pos: Int) -> Unit,
) : ListAdapter<Any, RecyclerView.ViewHolder>(DiffCallBack()) {

    val ITEM_PHOTOS_TYPE = 2
    val ITEM_HEADER_TYPE = 1

    private class DiffCallBack : DiffUtil.ItemCallback<Any>() {
        override fun areItemsTheSame(oldItem: Any, newItem: Any) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: Any, newItem: Any) = oldItem == newItem
    }

    //    override fun getItemViewType(position: Int): Int {
//        return if (position >= 0 && position < pictures.size) {
//            if (pictures[position] is AlbumData) {
//                ITEM_HEADER_TYPE
//            } else {
//                ITEM_PHOTOS_TYPE
//            }
//        } else
//            -1
//    }
    override fun getItemViewType(position: Int): Int {
        return if (position in 0..<itemCount) {
            if (getItem(position) is AlbumData) {
                ITEM_HEADER_TYPE
            } else {
                ITEM_PHOTOS_TYPE
            }
        } else -1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_HEADER_TYPE) {
            val binding =
                ItemHeaderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        } else {
            val binding =
                ItemPictureBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            PictureViewHolder(binding)
        }
    }

    override fun onBindViewHolder(pictureViewHolder: RecyclerView.ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) {
            if (payloads[0] == "showCounter") {
                if (pictureViewHolder is PictureViewHolder) {
                    if (showCounter) {
                        val mediaData: MediaData = getItem(position) as MediaData
                        val calendar = Calendar.getInstance()
                        val currentTime = calendar.timeInMillis
                        val daysOld: Long = getDifference(File(mediaData.filePath).lastModified(), currentTime)
                        val daysLeft = 30 - daysOld
                        pictureViewHolder.binding.tvDuration.text = "${if (daysLeft < 0) 0 else daysLeft} day's"
                        pictureViewHolder.binding.tvDuration.beVisible()
                    } else {
                        pictureViewHolder.binding.tvDuration.beGone()
                    }
                }
            }
        } else {
            super.onBindViewHolder(pictureViewHolder, position, payloads)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        Log.e("BindViewHolder", "Favo-pictures.size:" + itemCount)
        if (position in 0..<itemCount)
            if (getItemViewType(position) == ITEM_HEADER_TYPE) {
                val headerViewHolder: HeaderViewHolder =
                    holder as HeaderViewHolder
                val albumData = getItem(position) as AlbumData
                var strDate: String = albumData.title
//                val calendar = Calendar.getInstance()

//                val format = SimpleDateFormat(Constant.dateFormat, Locale.ENGLISH)
//                val today = format.format(calendar.timeInMillis)
//                calendar.add(Calendar.DATE, -1)
//                val yesterday = format.format(calendar.timeInMillis)

//                if (albumData.title == today)
//                    strDate = context.getString(R.string.Today)
//                else if (albumData.title == yesterday)
//                    strDate = context.getString(R.string.Yesterday)

                headerViewHolder.binding.txtHeader.text = strDate
                headerViewHolder.binding.txtSelect.beGone()


            } else {
                val pictureViewHolder = holder as PictureViewHolder
                val mediaData: MediaData = getItem(position) as MediaData

                val glideOptions = RequestOptions()
                    .format(DecodeFormat.PREFER_ARGB_8888)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.IMMEDIATE)
                    .skipMemoryCache(false)

                Glide.with(context.application)
                    .load(mediaData.filePath)
                    .apply(glideOptions)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(pictureViewHolder.binding.image)

//                Glide.with(context.application).load(mediaData.filePath)
//                    .into(pictureViewHolder.binding.image)

                pictureViewHolder.binding.icVideo.visibility =
                    if (mediaData.isVideo) View.VISIBLE else View.GONE

                if (showCounter) {
                    val calendar = Calendar.getInstance()
                    val currentTime = calendar.timeInMillis
                    val daysOld: Long = getDifference(File(mediaData.filePath).lastModified(), currentTime)

                    pictureViewHolder.binding.tvDuration.beVisible()
                    val daysLeft = 30 - daysOld
                    pictureViewHolder.binding.tvDuration.text = "${if (daysLeft < 0) 0 else daysLeft} day's"
                }

                if (mediaData.isCheckboxVisible) {

                    if (mediaData.isSelected){
                        pictureViewHolder.binding.icUnSelect.beGone()
                        pictureViewHolder.binding.icSelect.beVisible()
                    }else {
                        pictureViewHolder.binding.icUnSelect.beVisible()
                        pictureViewHolder.binding.icSelect.beGone()
                    }
//                    pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                    pictureViewHolder.binding.icSelect.visibility =
//                        if (mediaData.isSelected) View.VISIBLE else View.GONE
                    pictureViewHolder.binding.icFavourite.visibility = View.GONE
                } else {
                    pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                    pictureViewHolder.binding.icSelect.visibility = View.GONE

                    pictureViewHolder.binding.icFavourite.visibility =
                        if (mediaData.isFavorite) View.VISIBLE else View.GONE
                }

                holder.binding.loutMain.setOnClickListener {
                    clickListener(position)
                }
                holder.binding.loutMain.setOnLongClickListener {
                    longClickListener(position)
                    true
                }
            }
    }

    fun getDifference(startDate: Long, endDate: Long): Long {
        var different = endDate - startDate

        val secondsInMilli: Long = 1000
        val minutesInMilli = secondsInMilli * 60
        val hoursInMilli = minutesInMilli * 60
        val daysInMilli = hoursInMilli * 24

        val elapsedDays = different / daysInMilli
        different = different % daysInMilli

        val elapsedHours = different / hoursInMilli
        different = different % hoursInMilli

        val elapsedMinutes = different / minutesInMilli
        different = different % minutesInMilli

        val elapsedSeconds = different / secondsInMilli

        Log.e("AutoCleanTrash", "Days:$elapsedDays")
        Log.e("AutoCleanTrash", "Hours:$elapsedHours")
        Log.e("AutoCleanTrash", "Minutes:$elapsedMinutes")
        Log.e("AutoCleanTrash", "Seconds:$elapsedSeconds")

        return elapsedDays
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is PictureViewHolder) {
            Glide.with(context.application).clear(holder.binding.image)
        }
    }

    class HeaderViewHolder(var binding: ItemHeaderBinding) : RecyclerView.ViewHolder(binding.root)

    class PictureViewHolder(var binding: ItemPictureBinding) :
        RecyclerView.ViewHolder(binding.root)

    var preferences: Preferences = Preferences(context)

    //    var dateFormat = "dd/mm/y"
    var timeFormat = TIME_FORMAT_12

    var bubbleText = ""

//    override fun onChange(position: Int): CharSequence {
//        val data = pictures[position]
//        if (data is PictureData) {
//            bubbleText = getBubbleText(data, sorting, dateFormat, timeFormat)
//        }
//        return bubbleText
//    }

}