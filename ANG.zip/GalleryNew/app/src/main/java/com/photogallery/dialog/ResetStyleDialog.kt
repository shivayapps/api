package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import androidx.core.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RadioGroup
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogResetStyleBinding
import com.photogallery.extension.beVisibleIf
import com.photogallery.utils.Preferences

class ResetStyleDialog(
    var mContext: Activity,
    val methodListener: (methodSelected: Int) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogResetStyleBinding
    var preferences: Preferences = Preferences(mContext)
//    var securityMail = ""


    //    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogResetStyleBinding.inflate(layoutInflater, container, false)
//
//        intView()
//        intListener()
//        return bindingDialog.root
//    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogResetStyleBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }

    private fun intView() {

//        securityMail = preferences.securityEmail
//        if (securityMail.isNotEmpty()) {
//            bindingDialog.rbEmail.isChecked = true
//        }

        bindingDialog.rbSecurityQue.isEnabled = (preferences.getSetQuestion())
    }

    private fun intListener() {
//        bindingDialog.btnCancel.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener {
            dismiss()
        }
//        bindingDialog.btnOK.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnOK).setOnClickListener {
//            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
//            val selectedRadioButtonId: Int =
//                bindingDialog.root.findViewById<RadioGroup>(R.id.grpOption).checkedRadioButtonId
//            var typeSelected = when (selectedRadioButtonId) {
//                bindingDialog.rbEmail.id -> 1
//                bindingDialog.rbSecurityQue.id -> 2
//                else -> 1
//            }
            methodListener.invoke(0)
            dismiss()
        }

    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

