package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import androidx.core.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.viewbinding.ViewBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogChangeLockStyleBinding
import com.photogallery.databinding.DialogChangeLockStyleDarkBinding
import com.photogallery.utils.Preferences

class ChangLockStyleDialog(
    var mContext: Activity,
    val updateListener: (isShowPinLock:Boolean) -> Unit,
    val useDarkMode:Boolean?=false
) : Dialog(mContext) {

//    lateinit var bindingDialog: DialogChangeLockStyleBinding
    lateinit var bindingDialog: ViewBinding
    var preferences: Preferences = Preferences(mContext)
    var isShowPinLock = false


//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogChangeLockStyleBinding.inflate(layoutInflater, container, false)
//        if(useDarkMode!!) bindingDialog = DialogChangeLockStyleDarkBinding.inflate(layoutInflater, container, false)
//
//        intView()
//        intListener()
//        return bindingDialog.root
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(mContext, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
//                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
//                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        bindingDialog = DialogChangeLockStyleBinding.inflate(layoutInflater)
        if (useDarkMode!!) bindingDialog = DialogChangeLockStyleDarkBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }

    private fun intView() {
//        if(useDarkMode!!) {
//            bindingDialog.llMain.backgroundTintList= ColorStateList.valueOf(Color.parseColor("##222222"))
//        }

        isShowPinLock = preferences.getShowPINLock()
        if (isShowPinLock) {
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPinLock).isChecked = true
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPatternLock).isChecked = false
//            bindingDialog.rbPinLock.isChecked = false
//            bindingDialog.rbPatternLock.isChecked = false
        } else {
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPinLock).isChecked = false
            bindingDialog.root.findViewById<RadioButton>(R.id.rbPatternLock).isChecked = true
//            bindingDialog.rbPinLock.isChecked = false
//            bindingDialog.rbPatternLock.isChecked = true
        }
    }

    private fun intListener() {
//        bindingDialog.btnCancel.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener {
            dismiss()
        }
//        bindingDialog.btnOK.setOnClickListener {
            bindingDialog.root.findViewById<TextView>(R.id.btnOK).setOnClickListener {
//            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            val selectedRadioButtonId: Int = bindingDialog.root.findViewById<RadioGroup>(R.id.grpOption).checkedRadioButtonId
            var isPinSelected = when (selectedRadioButtonId) {
//                bindingDialog.rbPinLock.id -> true
                (R.id.rbPinLock) -> true
//                bindingDialog.rbPatternLock.id -> false
                (R.id.rbPatternLock) -> false
                else -> false
            }
            dismiss()
            updateListener.invoke(isPinSelected)
//            preferences.putShowPinLock(isShowPinLock)
        }

    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

