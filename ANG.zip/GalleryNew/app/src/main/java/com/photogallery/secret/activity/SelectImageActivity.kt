package com.photogallery.secret.activity

import android.app.Activity
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.databinding.ActivitySelectImageBinding
import com.photogallery.dialog.ConfirmationDialog
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.openPath
import com.photogallery.extension.toast
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.secret.adapter.SelectAlbumAdapter
import com.photogallery.secret.adapter.SelectImageAdapter
import com.photogallery.secret.adapter.SelectImageListAdapter
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import vi.imagestopdf.CreatePDFListener
import vi.imagestopdf.PDFEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Locale

class SelectImageActivity : BaseNoThemeActivity() {

    lateinit var binding: ActivitySelectImageBinding
    lateinit var preferences: Preferences
    var albumList: ArrayList<AlbumData> = ArrayList()
    val allImages: ArrayList<MediaData> = ArrayList()
    val selectedImageList: ArrayList<MediaData> = ArrayList()
    var spinnerAdapter: SelectAlbumAdapter? = null
    var pictures = ArrayList<Any>()
    var pictureAdapter: SelectImageAdapter? = null
    var selectImageAdapter: SelectImageListAdapter? = null
    var selectAlbumPath: String = ""
    var spinnerPos = -1
    var openType = 0
    var includeVideo = true
    lateinit var dropdownAnimation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectImageBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        intView()
        intListener()
        setRvLayoutManager()
        loadBanner()
    }

    private fun intView() {

        binding.loutBottomSelect.visibility = View.GONE
        openType = intent.getIntExtra(Constant.EXTRA_SELECT_TYPE, 0)
        includeVideo = intent.getBooleanExtra(Constant.EXTRA_INCLUDE_VIDEO, true)

        if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
            selectAlbumPath = intent.getStringExtra(Constant.EXTRA_ALBUM_PATH) ?: ""
        }

        if (openType == Constant.SELECT_TYPE_HIDE) {
            binding.btDone.text = getString(R.string.hide)
        }

        preferences = Preferences(this)
        dropdownAnimation = AnimationUtils.loadAnimation(this, R.anim.dropdown_animation)
        getData()
        setSelectAdapter()
    }

    private fun loadBanner() {
//        val isFirstSession=preferences.splashCounter==1
//        val adId=if(isFirstSession) getString(R.string.b_selectImageActivity) else getString(R.string.b_selectImageActivity2)
//        BannerAdHelper.showBanner(context = this, view = binding.layoutBanner.mFLAd,adId)
    }

    private fun setSelectAdapter() {
        selectImageAdapter = SelectImageListAdapter(this, selectedImageList, deleteListener = {
            selectedImageList.removeAt(it)
            selectImageAdapter?.notifyDataSetChanged()
            pictureAdapter?.notifyDataSetChanged()
            checkSelectionEmpty()
        })
        binding.rvSelect.adapter = selectImageAdapter
    }

    private fun checkSelectionEmpty() {
        binding.loutBottomSelect.visibility =
            if (selectedImageList.isEmpty()) View.GONE else View.VISIBLE
        binding.tvImageSelect.text = "${selectedImageList.size} ${getString(R.string.selected)}"
    }

    var isSpinnerOpen = false
    var rotationAngle = 0f

    private fun intListener() {
        binding.icBack.setOnClickListener { finish() }
        binding.icDelete.setOnClickListener {
            val confirmationDialog = ConfirmationDialog(
                this,
                getString(R.string.clear_all),
                getString(R.string.clear_all_msg),
                getString(R.string.yes),
                positiveBtnClickListener = {
                    selectedImageList.clear()
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                },
                false,
                getString(R.string.no)
            )
            confirmationDialog.show()
        }

        binding.btDone.setOnClickListener {
            if (selectedImageList.isNotEmpty()) {
                if (openType == Constant.SELECT_TYPE_CRATE_ALBUM) {
                    val file = File(selectAlbumPath)
                    if (!file.exists())
                        file.mkdirs()

                    Utils.copyFiles(
                        this,
                        selectAlbumPath,
                        selectedImageList,
                        selectedImageList.size,
                        copyListener = {
                            preferences.refreshMedia = true
                            Toast.makeText(
                                this,
                                getString(R.string.import_successfully),
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        }
                    )
                } else if (openType == Constant.SELECT_TYPE_CRATE_PDF) {
                    pdfImages()
                } else if (openType == Constant.SELECT_TYPE_HIDE) {
                    hidePhoto()
                }
            }
        }
        binding.spinner.viewTreeObserver?.addOnWindowFocusChangeListener { hasFocus -> //This updates the arrow icon up/down depending on Spinner opening/closing
            Log.e("spinnerTag", "addOnWindowFocusChangeListener $hasFocus ")
            if (hasFocus) {
                // spinner close
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            } else {
                // spinner open
                rotationAngle = if (rotationAngle == 0f) 180f else 0f
                binding.ivDropDown.animate().rotation(rotationAngle).setDuration(500).start()
            }
        }
        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Log.e("spinnerTag", "onItemSelected")
                if (position != -1)
                    binding.txtItemSpinner.text = albumList[position].title

                if (spinnerPos != position)
                    setImageAdapter(position)
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                Log.e("spinnerTag", "onNothingSelected")
            }

        }
    }

    private fun pdfImages() {
//        Constant.selectedImageList = ArrayList()
//        Constant.selectedImageList.addAll(selectedImageList)

        if (selectedImageList.size == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {

                val uris = ArrayList<File>()
                for (i in selectedImageList.indices) {
                    if (selectedImageList[i] is MediaData) {
                        val model = selectedImageList[i] as MediaData
//                            val uri = FileProvider.getUriForFile(
//                                mActivity!!,
//                                mActivity?.packageName + ".provider",
//                                File(model.filePath)
//                            )
                        uris.add(File(model.filePath))
                    }
                }
                runOnUiThread {
                    var filename = System.currentTimeMillis().toString()
                    val quality = 80
                    PDFEngine.getInstance().createPDF(this, uris, object : CreatePDFListener {
                        override fun onPDFGenerated(pdfFile: File?, numOfImages: Int) {

                            if (pdfFile != null) {
                                if (pdfFile.exists()) {
                                    try {
                                        MediaScannerConnection.scanFile(
                                            this@SelectImageActivity, arrayOf(pdfFile.absolutePath),
                                            null, null
                                        )
                                    } catch (e: Exception) {
                                    }
                                    Log.d("TAG", "onPDFGenerated:  Pdf file -->" + pdfFile!!.absolutePath)
                                    Log.d("TAG", "onPDFGenerated:  numberofPages -->" + numOfImages)
                                    toast("Your pdf is saved at ${pdfFile.absolutePath}")

                                    openPath(pdfFile.absolutePath, true)
                                }
                            }
                        }
                    }, filename, false, quality, true)
                }
            }
        }
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun hidePhoto() {
        Constant.selectedImageList = ArrayList()
        Constant.selectedImageList.addAll(selectedImageList)
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun setImageAdapter(position: Int) {
        pictures.clear()
        pictures.addAll(albumList[position].folderImageList)
        pictureAdapter = SelectImageAdapter(
            this, pictures,
            selectedImageList,
            clickListener = {
//                val pictureData = pictures[it] as PictureData
//                if (pictureData.isCheckboxVisible) {
//                    pictureData.isSelected = !pictureData.isSelected
//                    pictureAdapter?.notifyItemChanged(it)
////                    setSelectedFile()
//                }

                if (pictures[it] is MediaData) {
                    val pictureData = pictures[it] as MediaData
                    pictureData.isSelected = !pictureData.isSelected
                    if (selectedImageList.contains(pictureData)) {
                        selectedImageList.remove(pictureData)
                    } else {
                        selectedImageList.add(pictureData)
                    }
                    pictureAdapter?.notifyItemChanged(it)
                    selectImageAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                            if (isSelectAll) {
                                if (!selectedImageList.contains(model)) {
                                    selectedImageList.add(model)
                                }
                            } else {
                                if (selectedImageList.contains(model)) {
                                    selectedImageList.remove(model)
                                }
                            }
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    selectImageAdapter?.notifyDataSetChanged()
                    pictureAdapter?.notifyDataSetChanged()
                    checkSelectionEmpty()
                }
            })

        binding.pictureRecycler.adapter = pictureAdapter
    }

    fun setSelectedFile() {

    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
        val gridLayoutManager =
            GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        binding.pictureRecycler.layoutManager = gridLayoutManager
        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (pictureAdapter!!.getItemViewType(position) === pictureAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setData() {
        binding.progressBar.visibility = View.GONE
        setEmptyData()
        checkSelectionEmpty()

        if (albumList.isNotEmpty()) {
            spinnerAdapter = SelectAlbumAdapter(this, albumList)
            binding.spinner.adapter = spinnerAdapter
            binding.spinner.setSelection(0)
//            setImageAdapter(0)
        }
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun getData() {
        binding.progressBar.visibility = View.VISIBLE

        Log.e("SelectImageActivity", "startMediaLoader")
        MediaLoaderX(
            this
        ).getAllData(onSuccess = { groupedMediaList, mediaList, mediaFolderList ->
            Log.e("SelectImageActivity", "onSuccess.mediaList:${mediaList.size},albumList:${mediaFolderList.size}")

            allImages.clear()
            allImages.addAll(mediaList)

            albumList.clear()
            albumList.addAll(mediaFolderList)

            Log.e("SelectImageActivity", "onSuccess.setData")
            runOnUiThread {
                setDataList()
            }
        }, onFailed = { error ->
            Log.e("SelectImageActivity", "onFailed.error:$error")
        })
    }

    private fun setDataList() {
        Observable.fromCallable {
            setList()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }

    private fun setList() {

        if (allImages.isNotEmpty()) {
            val albumData = AlbumData()
            albumData.title = "All"
            albumData.mediaData = allImages
            albumList.add(0, albumData)
        }
        val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)

        if (albumList.isNotEmpty()) {
            for (a in albumList.indices) {

                val dateWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
                val picturesList: ArrayList<Any> = ArrayList()
                for (pictureData in albumList[a].mediaData) {
                    val strDate = format.format(pictureData.date)
                    var imagesData1: ArrayList<MediaData> = ArrayList()
                    if (dateWisePictures.containsKey(strDate)) {
                        val list: ArrayList<MediaData>? = dateWisePictures[strDate]
                        if (!list.isNullOrEmpty())
                            imagesData1.addAll(list)
                    } else {
                        imagesData1 = ArrayList()
                    }
                    imagesData1.add(pictureData)
                    dateWisePictures[strDate] = imagesData1

                }
                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                for (i in listKeys.indices) {
                    val imagesData = dateWisePictures[listKeys[i]]
                    if (imagesData != null && imagesData.size != 0) {
                        val bucketData = AlbumData(listKeys[i], imagesData)
                        picturesList.add(bucketData)
                        picturesList.addAll(imagesData)
                    }
                }

                albumList[a].folderImageList = picturesList
            }
        }

    }

}