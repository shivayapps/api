package com.photogallery.event

data class HideEvent(var isUpdate: Boolean = false)
