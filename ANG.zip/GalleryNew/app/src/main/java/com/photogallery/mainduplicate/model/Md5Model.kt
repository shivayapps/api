package com.photogallery.mainduplicate.model

class Md5Model {
    var extension: String? = null
    var filePath: String? = null
    var md5Value: String? = null
}