package com.photogallery.mainduplicate.activity.scanningactivities

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.photogallery.R
import com.photogallery.base.BaseActivity

import com.photogallery.mainduplicate.activity.duplicateactivities.*
import com.photogallery.mainduplicate.asynctask.ReadingAllFilesAsyncTask
import com.photogallery.mainduplicate.callbacks.SearchListener
import com.photogallery.mainduplicate.model.DuplicateFileRemoverSharedPreferences
import com.photogallery.mainduplicate.model.PopUp
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.photogallery.databinding.ActivityScanningNewBinding
import com.photogallery.mainduplicate.BaseSimpleActivity
import com.photogallery.mainduplicate.activity.duplicateactivities.DuplicateAudiosDuplicateActivity
import com.photogallery.utils.AdCache
import com.photogallery.utils.Preferences
import com.google.android.gms.ads.AdView

import java.util.*

class ScanningDuplicateActivity : BaseActivity(), SearchListener {

    var mTAG: String = javaClass.simpleName
    var mIsCheckType: String? = null
    var mIsScanningDone = false
    var isFromSettings = false
    var isPause = false

    lateinit var mContext:Activity
    lateinit var binding:ActivityScanningNewBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding=ActivityScanningNewBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_scanning_new)
        mContext=getContext()
//        initViews()
//        initAds()
        initData()
        initActions()

        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dm)
//        val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
//        val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
//        val screenInches = Math.sqrt(x + y)

        loadAds()
    }


    private fun loadAds() {
        NativeAdHelper(
            this,
            binding.layoutBanner.mFLAd,
            binding.llAdPlace,
            NativeLayoutType.NativeBig,
            getString(R.string.native_scanner)
        ).loadAd();
    }

    fun getContext(): Activity {
        return this@ScanningDuplicateActivity
    }

    fun initData() {
        mIsCheckType = intent.extras!!.getString("IsCheckType")

//        Glide.with(applicationContext)
//            .asGif() // make sure the GIF wont animate
//            .load(resources.getDrawable(R.drawable.loading_circle_animation))
//            .into(imgScanning)
        ReadingAllFilesAsyncTask(
            mContext,
            this,
            mIsCheckType
        ).execute()
    }





    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)

    }

    fun initActions() {
        binding.imgBack.setOnClickListener { onBackPressed() }

//        ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
    }

    override fun checkScanFinish() {
        Log.e(mTAG, "checkScanFinish ")
        redirectActivity()
        mIsScanningDone = true
    }


    private fun redirectActivity() {
        Log.e(mTAG, "redirectActivity: ==>>> $mIsCheckType")
        mIsScanningDone = false
        val intent: Intent = when (mIsCheckType) {
            "Image" -> Intent(mContext, DuplicateImageDuplicateActivity::class.java)
            "Video" -> Intent(mContext, DuplicateVideosDuplicateActivity::class.java)
            "Audio" -> Intent(mContext, DuplicateAudiosDuplicateActivity::class.java)
            "Document" -> Intent(mContext, DuplicateDocumentsDuplicateActivity::class.java)
            "Other" -> Intent(mContext, DuplicateOthersDuplicateActivity::class.java)
            else -> throw IllegalStateException("Unexpected value: $mIsCheckType")
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//        val pi: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
//        pi.send(this, 0, intent)
        startActivity(intent)

        Log.e(mTAG, "redirectActivity: intent ---> $intent")
        Log.e(mTAG, "redirectActivity: $mContext")
        finish()
    }

    override fun updateUi(vararg count: String?) {
        if (!DuplicateFileRemoverSharedPreferences.isScanningStop(mContext)) {
            runOnUiThread {
                if (count[0].equals("scanning", ignoreCase = true)) {
                    binding.tvCount!!.text = count[1]
                    binding.tvScanning2!!.visibility = View.VISIBLE
                } else if (count[0].equals("sorting", ignoreCase = true)) {
                    binding.tvCount!!.visibility = View.INVISIBLE
                    binding.tvScanning1!!.text = count[1]
                    binding.tvScanning2!!.visibility = View.INVISIBLE
                }
            }
        }
    }

    override fun onBackPressed() {
        PopUp(mContext, mContext).showAlertStopScanning(
            com.photogallery.mainduplicate.asynctask.ReadingAllFilesAsyncTask(
                mContext,
                this,
                mIsCheckType
            )
        )
    }

    override fun onResume() {
        super.onResume()
        Log.d("TAG1234", "onResume: Scanning activity ")
        if (isFromSettings) {
            isFromSettings = false
            com.photogallery.mainduplicate.asynctask.ReadingAllFilesAsyncTask(
                mContext,
                this,
                mIsCheckType
            ).execute()

        }
//        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
//            mContext.loadOfflineNativeAdvance(flBanner)
//        }


//        if (config.isAppPasswordProtectionOn && config.isEnableLock && isUnLockApp && mIsScanningDone) {
//            redirectActivity()
//        } else {
//        }
        if (mIsScanningDone) {
            redirectActivity()
        }
    }


    override fun onPause() {
        super.onPause()
        isPause = true
    }
}