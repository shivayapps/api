package com.photogallery.notes.adapter

import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.notes.entities.Notes
import com.photogallery.databinding.ItemRvNotesBinding


class NotesAdapter() : RecyclerView.Adapter<NotesAdapter.NotesViewHolder>() {

    private var allNotesList = ArrayList<Notes>()   // Full list
    var arrList = ArrayList<Notes>()                // Displayed list
    var listener: onItemClickListener? = null

    fun filterList(query: String) {
        val filteredList = if (query.isEmpty()) {
            allNotesList
        } else {
            allNotesList.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.noteText.contains(query, ignoreCase = true) ||
                        it.webLink.contains(query, ignoreCase = true)
            }
        }

        arrList.clear()
        arrList.addAll(filteredList)
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotesViewHolder {
        val binding =
            ItemRvNotesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NotesViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NotesViewHolder, position: Int) {

        holder.binding.tvTitle.text = arrList[position].title
        holder.binding.tvDesc.text = arrList[position].noteText
        holder.binding.tvDateTime.text = arrList[position].dateTime


        if (arrList[position].color != null) {
            holder.binding.cardView.setCardBackgroundColor(Color.parseColor(arrList[position].color))
        } else {
            null
        }

        val imgPath = arrList[position].imgPath.trim()

        if (imgPath.isNotEmpty()) {
            Log.e("aaaaa", "path:${arrList[position].imgPath}")
            holder.binding.imgNote.setImageBitmap(BitmapFactory.decodeFile(arrList[position].imgPath))
            holder.binding.imgNote.visibility = View.VISIBLE
        } else {
            Log.e("aaaaa", "path:----")
            holder.binding.imgNote.visibility = View.GONE
        }

        if (arrList[position].webLink.isNotEmpty()) {
            holder.binding.tvWebLink.text = arrList[position].webLink
            holder.binding.tvWebLink.visibility = View.VISIBLE
        } else {
            holder.binding.tvWebLink.visibility = View.GONE
        }

        holder.binding.cardView.setOnClickListener {
            listener!!.onClicked(arrList[position].id!!)
        }

    }

    override fun getItemCount(): Int {
        return arrList.size
    }

    fun setData(arrNotesList: List<Notes>) {
        allNotesList.clear()
        allNotesList.addAll(arrNotesList)

        arrList.clear()
        arrList.addAll(arrNotesList)

        notifyDataSetChanged()
    }

    fun setOnClickListener(listener1: onItemClickListener) {
        listener = listener1
    }

    inner class NotesViewHolder(var binding: ItemRvNotesBinding) : RecyclerView.ViewHolder(binding.root) {}

    interface onItemClickListener {
        fun onClicked(notesId: Int)
    }

}