package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogResizeBinding
import com.photogallery.extension.getMimeType
import com.photogallery.extension.toast
import com.photogallery.model.MediaData
import com.photogallery.utils.Preferences
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class ResizeDialog(
    var mContext: Activity,
    var mediaData: MediaData,
    val updateImageListener: (path: String) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogResizeBinding
    var preferences: Preferences = Preferences(mContext)
    var oldName = ""
    var type = ""
    var currentWidth = 0
    var currentHeight = 0

    //    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogResizeBinding.inflate(layoutInflater, container, false)
//        intView()
//        intListener()
//        return bindingDialog.root
//    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogResizeBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }


    private fun intView() {

        val separated: List<String> = mediaData.fileName.split(".")
        oldName = separated[0]
        if (separated.size > 0) {
            type = separated[1]
        } else {
            type = mediaData.filePath.getMimeType()
        }

        Log.e("", "oldName $oldName")
        bindingDialog.edtName.setText(oldName)

        val size = mediaData.filePath.getImageResolution()
        bindingDialog.edtWidth.setText("${size.x}")
        bindingDialog.edtHeight.setText("${size.y}")
        currentWidth = size.x
        currentHeight = size.y
        val ratio: Float = currentWidth / currentHeight.toFloat()
        Log.e(
            "ResizeTAG",
            "currentWidth-> $currentWidth  currentHeight-> $currentHeight ratio-> $ratio"
        )

        bindingDialog.edtWidth.requestFocus()
        bindingDialog.edtWidth.addTextChangedListener {
            if (bindingDialog.edtWidth.hasFocus()) {
                var width = getViewValue(bindingDialog.edtWidth)
                Log.e("ResizeTAG", "edtW addTextChanged width-> $width")
                if (width > currentWidth) {
                    bindingDialog.edtWidth.setText(currentWidth.toString())
                    width = currentWidth
                    Log.e("ResizeTAG", "edtW addTextChanged if width-> $width")
                }
                Log.e("ResizeTAG", "edtW addTextChanged Height-> ${(width / ratio).toInt()}")
                bindingDialog.edtHeight.setText((width / ratio).toInt().toString())
            }
        }

        bindingDialog.edtHeight.addTextChangedListener {
            if (bindingDialog.edtHeight.hasFocus()) {
                var height = getViewValue(bindingDialog.edtHeight)
                Log.e("ResizeTAG", "edtH addTextChanged height-> $height")
                if (height > currentHeight) {
                    bindingDialog.edtHeight.setText(currentHeight.toString())
                    height = currentHeight
                    Log.e("ResizeTAG", "edtH addTextChanged if height-> $height")
                }

                Log.e("ResizeTAG", "edtH addTextChanged width-> ${(height * ratio).toInt()}")
                bindingDialog.edtWidth.setText((height * ratio).toInt().toString())
            }
        }
    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnResize.setOnClickListener {
            val width = getViewValue(bindingDialog.edtWidth)
            val height = getViewValue(bindingDialog.edtHeight)
            if ((width <= 0 || height <= 0)) {
                mContext.toast(mContext.getString(R.string.validation_resolution))
                return@setOnClickListener
            }

            val newSize = Point(width, height)

            var strNewFileName = bindingDialog.edtName.text.toString().trim()
//            val strNewFileName = "resize_${oldName}_${System.currentTimeMillis()}"
            if (oldName == strNewFileName) {
                strNewFileName = "resize_${oldName}_${System.currentTimeMillis()}"
            }

            val newFile = File(mediaData.filePath.replace(oldName, strNewFileName))

            if (!newFile.exists() || oldName == strNewFileName) {
                if (width != currentWidth && height != currentHeight) {
                    val progressDialog = ProgressDialog(mContext)
                    dismiss()
                    progressDialog.show()
                    Thread {
                        val newBitmap =
                            Glide.with(mContext.applicationContext).asBitmap()
                                .load(mediaData.filePath)
                                .submit(newSize.x, newSize.y)
                                .get()

//                            var resizeImage = resizeImage(newBitmap, pictureData.filePath)
                        var resizeImage = resizeImage(newBitmap, newFile.path)
                        mContext.runOnUiThread {
                            progressDialog.dismiss()
                            updateImageListener.invoke(newFile.path)
                        }
                    }.start()
                } else
                    dismiss()
            } else {

                mContext.toast(mContext.getString(R.string.rename_validation2))
            }

        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return try {
            if (textValue.isEmpty()) 0
            else textValue.toInt()
        } catch (e: NumberFormatException) {
            2147483647
        }
    }

    private fun setRename(oldPath: String, renamePath: String) {
//        EventBus.getDefault().post(RenameEvent(oldPath, renamePath))
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    fun resizeImage(bitmap: Bitmap, imagePath: String): String? {

        val imageFile = File(imagePath)
        if (imageFile.exists()) {
            imageFile.delete()
            val deleteUrl = FileProvider.getUriForFile(
                mContext,
                "${mContext.packageName}.provider", imageFile
            )
            val contentResolver = mContext.contentResolver
            contentResolver.delete(deleteUrl, null, null)

            MediaScannerConnection.scanFile(
                mContext,
                arrayOf(imageFile.path),
                null
            ) { path: String?, uri: Uri? -> }
        }

        try {
            val stream = FileOutputStream(imageFile)
            bitmap.compress(imageFile.path.getCompressionFormat(), 100, stream)

            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val contentUri = Uri.fromFile(imageFile)
            mediaScanIntent.data = contentUri
            mContext.sendBroadcast(mediaScanIntent)

            stream.flush()
            stream.close()

            MediaScannerConnection.scanFile(
                mContext, arrayOf<String>(imageFile.path), null
            ) { path, uri ->
            }
            return imagePath
        } catch (e: IOException) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
        return null
    }

    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

}

