package com.photogallery.base

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

import androidx.appcompat.app.AppCompatActivity
import com.photogallery.utils.Constant
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

open class BaseNoThemeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation =
            if (Build.VERSION.SDK_INT < 9)
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT

//        setAppTheme()
    }

    override fun onResume() {
        super.onResume()
//        setAppTheme()
    }


    var settingLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                Constant.isReCreateHomeSS = true
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
                Constant.isChangeLanguage = false
            } else if (Constant.isChangeLanguage) {
                Constant.isReCreateHomeSS = true
                Constant.isChangeLanguage = false
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(
            com.photogallery.utils.LocaleHelper.onAttach(
                base, "en"
            )
        )
    }

    fun getAppVersion(): String? {
        try {
            val packageInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(packageName, 0)
//                packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                packageManager.getPackageInfo(packageName, 0)
            }
            return packageInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
        return null
    }

    fun getScreenWidth(): Int {
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val displayMetrics = DisplayMetrics()
//        windowManager.defaultDisplay.getMetrics(displayMetrics)
//        return displayMetrics.widthPixels
        return windowManager.defaultDisplay.width
    }

    public fun setAppTheme() {
//        themeType = Preferences(this).getThemeValue()
//        when (themeType) {
//            Constant.THEME_LIGHT -> {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
//            }
//
//            Constant.THEME_DARK -> {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//            }
//        }
    }

    fun getBitmapFromDrawable(myDrawable: Drawable?): Bitmap {

        if (myDrawable is BitmapDrawable) {
            return myDrawable.bitmap
        }

//        val bitmap =   if(myDrawable!!.intrinsicWidth <= 0 || myDrawable.intrinsicHeight <= 0) {
//            Bitmap.createBitmap(20, 20, Bitmap.Config.ARGB_8888)
//        } else {
//            Bitmap.createBitmap(myDrawable.intrinsicWidth,myDrawable.intrinsicHeight, Bitmap.Config.ARGB_8888)
//        }
        val width = myDrawable?.intrinsicWidth ?: 0
        val height = myDrawable?.intrinsicHeight ?: 0
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        myDrawable?.setBounds(0, 0, width, height)
        myDrawable?.draw(canvas)
        return bitmap

    }

    fun getBitmapFromFilePath(filePath: String): Bitmap? {
        try {
            val options = BitmapFactory.Options()
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            return BitmapFactory.decodeFile(filePath, options)
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
            return null
        }
    }

    fun listAssetFilesInFolder(folderName: String): Array<String> {
        val assetManager: AssetManager = assets

        return try {
            assetManager.list(folderName) ?: arrayOf()
        } catch (e: IOException) {
            Log.e("printStackTrace","printStackTrace:$e")
            arrayOf()
        }
    }

    fun getDrawableFromFile(context: Context, filePath: String): Drawable? {
        try {
            val file = File(filePath)
            if (file.exists()) {
                val bitmap = BitmapFactory.decodeFile(filePath)

                return BitmapDrawable(context.resources, bitmap)
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
        return null
    }


//    fun getPermissionToRequest() = if (isTiramisuPlus())  Manifest.permission.READ_MEDIA_IMAGES else  Manifest.permission.WRITE_EXTERNAL_STORAGE

//    fun getRequiredPermission() = if (isUpsideDownCakePlus()) PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED else getPermissionToRequest()
//
//    fun getPermissionsToRequest(): Collection<Int> {
//        val permissions = mutableListOf(getPermissionToRequest())
////        if (isRPlus()) {
////            permissions.add(PERMISSION_MEDIA_LOCATION)
////        }
//
//        if (isTiramisuPlus()) {
//            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
//        }
//
//        return permissions
//    }

    fun checkCameraPermission(): Boolean {
        val result = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        )
        return result == PackageManager.PERMISSION_GRANTED
    }

//    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
//        val view = currentFocus
//        val ret = super.dispatchTouchEvent(event)
//        if (view is EditText) {
//            val w = currentFocus
//            val scrcoords = IntArray(2)
//            if (w != null) {
//                w.getLocationOnScreen(scrcoords)
//                val x = event.rawX + w.left - scrcoords[0]
//                val y = event.rawY + w.top - scrcoords[1]
//                if (event.action == 1 && (x < w.left || x >= w.right || y < w.top || y > w.bottom)) {
//                    val systemService = getSystemService(Context.INPUT_METHOD_SERVICE)
//                    val imm = systemService as InputMethodManager
//                    val currentFocus = window.currentFocus
//                    imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
//                }
//            }
//        }
//        return ret
//    }
}