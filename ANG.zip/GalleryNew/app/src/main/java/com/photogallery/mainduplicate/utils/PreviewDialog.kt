package com.photogallery.mainduplicate.utils

import android.content.Context
import com.photogallery.dialog.DuplicatePreviewDialog
import com.photogallery.mainduplicate.model.ItemDuplicateModel


object PreviewDialog {
    fun showPreviewDialog(activity: Context, mItemDuplicateModel: ItemDuplicateModel) {
        DuplicatePreviewDialog(activity,mItemDuplicateModel) {

        }
    }
}