package com.photogallery.utils

import org.greenrobot.eventbus.EventBus

const val UPDATE_DUPLICATE_JUNK = "UPDATE_DUPLICATE_JUNK"
const val STOP_DUPLICATE_JUNK = "STOP_DUPLICATE_JUNK"
const val UPDATE_DUPLICATE_SIZE = "UPDATE_DUPLICATE_SIZE"

const val UPDATE_LARGE_JUNK = "UPDATE_LARGE_JUNK"
const val STOP_LARGE_JUNK = "STOP_LARGE_JUNK"
const val UPDATE_LARGE_SIZE = "UPDATE_LARGE_SIZE"

const val UPDATE_SS_JUNK = "UPDATE_SS_JUNK"
const val STOP_SS_JUNK = "STOP_SS_JUNK"
const val UPDATE_SS_SIZE = "UPDATE_SS_SIZE"


data class MessageEvent(val type: String, val data: Any? = null)

fun sendEvent(type: String, data: Any? = null) {
    EventBus.getDefault().post(MessageEvent(type, data))
}

