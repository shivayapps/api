package com.photogallery.mainduplicate.model

object DuplicateFoundAndSize {
    @JvmStatic
    var totalDuplicateAudios = 0
    @JvmStatic
    var totalDuplicateDocuments = 0
    @JvmStatic
    var totalDuplicateOthers = 0
    @JvmStatic
    var totalDuplicatePhotos = 0
    @JvmStatic
    var totalDuplicateVideos = 0
}