package com.photogallery.jobs.cleaner

import android.content.Context
import android.os.Build
import android.util.Log
import com.photogallery.model.AlbumData
import com.photogallery.utils.STOP_SS_JUNK
import com.photogallery.utils.UPDATE_SS_JUNK
import com.photogallery.utils.UPDATE_SS_SIZE
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.sendEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

suspend fun Context.startScreenShotWorker(allMedia: List<MediaData>) {
    ScreenshotWorker.doWork(this, allMedia)
}

object ScreenshotWorker {

    var ssPhotoData: Map<String, List<MediaData>> = emptyMap()
    private var isScreenshotRunning = false
    var totalCounter: Float = 0F
    var scanCounter: Int = 0
    var screenshotSize = 0L

    suspend fun doWork(context: Context, allMedia: List<MediaData>) {

        totalCounter = ((allMedia.size).toFloat())

        val pictures = ArrayList<Any>()
//        var totalFileSize = 0L

        if (allMedia.isEmpty()) return
//        CoroutineScope(Dispatchers.IO).launch {
        if (!isScreenshotRunning) {
            isScreenshotRunning = true

            if (Constant.ssRealPhotoData.isNotEmpty()) {
                setFilterSs()
            } else {
                val screenshot = allMedia.filter { it.filePath.contains("screenshot", true) }
                if (screenshot.isNotEmpty()) {
                    ssPhotoData = mapOf("screenshot" to screenshot)
                }
                val bucketKeys: Set<String> = ssPhotoData.keys
                val listFolderkeys = java.util.ArrayList(bucketKeys)
                Log.e("Cleaner.SSWorker", "RealPhotoData 001 listFolderkeys:${listFolderkeys.size}==>${listFolderkeys}")
                for (index in listFolderkeys.indices) {
                    val list = ssPhotoData[listFolderkeys[index]]
                    pictures.addAll(list as ArrayList<MediaData>)
                }
                Log.e("Cleaner.SSWorker", "RealPhotoData ssRealPhotoData==>${pictures.size}")

                Constant.ssRealPhotoData = pictures
                setFilterSs()
            }
            sendEvent(STOP_SS_JUNK)
        }
//        }
    }

    private fun setFilterSs() {
        Log.e("Cleaner.SSWorker", "setFilterDuplicate:001")
        val pictures = ArrayList<Any>()
        pictures.addAll(Constant.ssRealPhotoData)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            pictures.removeIf { item ->
                item is MediaData && !File(item.filePath).exists()
            }
        } else {
            val iterator = pictures.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item is MediaData && !File(item.filePath).exists()) {
                    iterator.remove()
                }
            }
        }

        //remove empty album
        val indicesToRemove = mutableListOf<Int>()
        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                var hasMediaData = false

                for (j in (i + 1) until pictures.size) {
                    if (pictures[j] is MediaData) {
                        hasMediaData = true
                    } else if (pictures[j] is AlbumData) {
                        break
                    }
                }
                if (!hasMediaData) {
                    indicesToRemove.add(i)
                }
            }
        }
        for (index in indicesToRemove.reversed()) {
            pictures.removeAt(index)
        }
        Constant.ssRealPhotoData = pictures

        val ssSize = pictures.filterIsInstance<MediaData>().size
        val totalFileSize = pictures.filterIsInstance<MediaData>().sumOf { it.fileSize }
        screenshotSize = totalFileSize
        Log.e("Cleaner.DuplicateWorker", "screenshotSize:$screenshotSize")
//        val size = Formatter.formatShortFileSize(this@ScreenshotWorker, totalFileSize)
        updatePercentage()

        val sizePair = Pair(totalFileSize.toLong(), ssSize.toInt())
        isScreenshotRunning = false
//        CoroutineScope(Dispatchers.IO).launch {
        sendEvent(UPDATE_SS_SIZE, sizePair)
//            Handler(Looper.getMainLooper()).postDelayed({
//                sendEvent(STOP_SS_JUNK)
//            },700)
//        }
        Log.e("Cleaner.SSWorker", "setFilterDuplicate:002")
    }

    private fun updatePercentage() {
//        CoroutineScope(Dispatchers.IO).launch {
//        runOnUiThread {
        val percent: Float = (scanCounter / totalCounter) * 100
        Log.e("Cleaner.SSWorker", "updatePercentage:${percent},$scanCounter,$totalCounter")
        sendEvent(UPDATE_SS_JUNK, percent)
//            binding.tvScanPercent.setText("${percent.toInt()}%")
//        }
    }

}
