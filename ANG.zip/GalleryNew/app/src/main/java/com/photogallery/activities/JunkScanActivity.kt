package com.photogallery.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityJunkScanBinding
import com.photogallery.extension.getPreviousActivity
import com.photogallery.utils.Preferences

class JunkScanActivity : BaseActivity() {

    lateinit var preferences: Preferences

    lateinit var binding: ActivityJunkScanBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val adId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, adId)
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityJunkScanBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
    override fun onBackPressed() {
        val previousActivity = getPreviousActivity()
        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false
                if (previousActivity.contains("HomeActivity")) {
                    finish()
                } else {
                    val intent = Intent(this, HomeActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    startActivity(intent)
                }
            }
        } else {
            if (previousActivity.contains("HomeActivity")) {
                finish()
            } else {
                val intent = Intent(this, HomeActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
            }
        }
    }
}