package com.photogallery.activities

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.FileProvider
import com.photogallery.R
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.databinding.ActivitySetWallpaperBinding
import com.photogallery.dialog.SetWallpaperDialog
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.utils.Constant
import java.io.File

class SetWallpaperActivity : BaseNoThemeActivity() {

    private val RATIO_PORTRAIT = 0
    private val RATIO_LANDSCAPE = 1
    private val RATIO_SQUARE = 2

    private val PICK_IMAGE = 1
    private var aspectRatio = RATIO_PORTRAIT
    private var wallpaperFlag = -1

    lateinit var wallpaperManager: WallpaperManager

    lateinit var binding: ActivitySetWallpaperBinding
    var imagePath = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetWallpaperBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateStatusBarColor(Color.parseColor("#161616"))

        intView()
        intListener()
    }


    private fun intView() {

        imagePath = intent.getStringExtra(Constant.EXTRA_WALL_PAPER).toString()

        wallpaperManager = WallpaperManager.getInstance(this)

        val imageUri = FileProvider.getUriForFile(
            this, "$packageName.provider",
            File(imagePath)
        )
        binding.cropView.setImageUriAsync(imageUri)
        binding.cropView.apply {
            val newAspectRatio = Pair(9f, 16f)
            setAspectRatio(newAspectRatio.first.toInt(), newAspectRatio.second.toInt())
        }
    }

    override fun onBackPressed() {
        if (binding.progressBar.visibility != View.VISIBLE) finish()
        else super.onBackPressed()
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icMenu.setOnClickListener {
            showMoreMenu()
        }
        binding.btnApply.setOnClickListener {
            val bitmap = binding.cropView.croppedImage
            if (bitmap != null) {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                showSeAsDialog(bitmap)
//                } else
//                    val wallpaperManager = WallpaperManager.getInstance(this)
//                    wallpaperManager.setBitmap(getResizeImage(bitmap))
//                    finish()
//                }
            }
        }

        binding.bottomSetWallpaperAspectRatio.setOnClickListener {
            changeAspectRatio()
        }

        binding.bottomSetWallpaperRotate.setOnClickListener {
            binding.cropView.rotateImage(90)
        }
    }

    private fun setupAspectRatio() {
        var widthToUse = wallpaperManager.desiredMinimumWidth
        val heightToUse = wallpaperManager.desiredMinimumHeight
        if (widthToUse == heightToUse) {
            widthToUse /= 2
        }

        when (aspectRatio) {
            RATIO_PORTRAIT -> binding.cropView.setAspectRatio(heightToUse, widthToUse)
            RATIO_LANDSCAPE -> binding.cropView.setAspectRatio(widthToUse, heightToUse)
            else -> binding.cropView.setAspectRatio(widthToUse, widthToUse)
        }
    }

    private fun changeAspectRatio() {
        aspectRatio = ++aspectRatio % (RATIO_SQUARE + 1)
        setupAspectRatio()
    }

    private fun showMoreMenu() {
        val popup = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            PopupMenu(this, binding.icMenu, Gravity.END, 0, R.style.BasePopupMenu)
        } else {
            PopupMenu(this, binding.icMenu)
        }
        popup.menuInflater.inflate(R.menu.menu_set_wallpaper, popup.menu)
        popup.setForceShowIcon(true)
        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.allow_changing_aspect_ratio -> {
                    binding.cropView.clearAspectRatio()
                }

            }
            return@setOnMenuItemClickListener true
        }
        popup.show()
    }

    private fun getResizeImage(image: Bitmap): Bitmap {
        val width = getScreenWidth()
        val iWidth = image.width
        val iHeight = image.height
        if (iWidth > width) {
            val ratio: Float = iWidth / iHeight.toFloat()
            val height = (width / ratio).toInt()
            return Bitmap.createScaledBitmap(image, width, height, false)
        }
        return image
    }

//    fun getScreenWidth(): Int {
//        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
//        val displayMetrics = DisplayMetrics()
////        windowManager.defaultDisplay.getMetrics(displayMetrics)
////        return displayMetrics.widthPixels
//        return windowManager.defaultDisplay.width
//    }
    private fun showSeAsDialog(bitmap: Bitmap) {
        val wallpaperManager = WallpaperManager.getInstance(this)
        val setWallpaperDialog = SetWallpaperDialog(this) {

            when (it) {
                1 -> {
                    binding.btnApply.isEnabled = false
                    binding.progressBar.visibility = View.VISIBLE

                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            wallpaperManager.setBitmap(
                                getResizeImage(bitmap),
                                null,
                                true,
                                WallpaperManager.FLAG_LOCK
                            )
                        } else {
                            wallpaperManager.setBitmap(getResizeImage(bitmap))
                        }
//                            runOnUiThread {
                        toast(getString(R.string.wallpaper_success))
                        finish()
//                            }
                    } catch (e: Exception) {
//                            runOnUiThread {
                        toast(getString(R.string.out_of_memory_error))
                        finish()
//                            }
                    }
//                    }.start()
                }

                2 -> {
                    binding.btnApply.isEnabled = false
                    binding.progressBar.visibility = View.VISIBLE
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            wallpaperManager.setBitmap(
                                getResizeImage(bitmap),
                                null,
                                true,
                                WallpaperManager.FLAG_SYSTEM
                            )
                        } else {
                            wallpaperManager.setBitmap(getResizeImage(bitmap))
                        }
                        toast(getString(R.string.wallpaper_success))
                        finish()
//                            }
                    } catch (e: Exception) {
                        toast(getString(R.string.out_of_memory_error))
                        finish()
                    }
                }

                3 -> {
                    binding.btnApply.isEnabled = false
                    binding.progressBar.visibility = View.VISIBLE
//                    binding.tvBtnTitle.text = getString(R.string.applying)

//                    Thread {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            wallpaperManager.setBitmap(
                                getResizeImage(bitmap),
                                null,
                                true,
                                WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                            )
                        } else {
                            wallpaperManager.setBitmap(getResizeImage(bitmap))
                        }
//                            runOnUiThread {

                        toast(getString(R.string.wallpaper_success))
                        finish()
//                            }
                    } catch (e: Exception) {
//                            runOnUiThread {
                        toast(getString(R.string.out_of_memory_error))
                        finish()
//                            }
                    }
//                    }.start()
                }
            }
        }
        setWallpaperDialog.show()
    }
}