package com.photogallery.activities

import android.app.Activity
import android.graphics.Color
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.text.format.Formatter
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.BannerAdHelper.TAG
import com.adconfig.adsutil.utils.isOnline
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.photogallery.R
import com.photogallery.activities.JunkScanActivity.Companion.selectedRealPhotoData
import com.photogallery.adapter.JunkAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityJunkCleanerBinding
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.PreviewDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.toast
import com.photogallery.extension.updateStatusBarColor
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.AdCache
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent

import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class JunkCleanerActivity : BaseActivity() {

    var pictures = ArrayList<Any>()
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var junkAdapter: JunkAdapter? = null
    private var lastLongPressedItem = -1
    var selectedItem = 0
    var actResult = Activity.RESULT_CANCELED
    var isCheckSearchOn = false
    var isSelectAll = true
    var isSmartSelected = true
    var category = ""

    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var binding: ActivityJunkCleanerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
//        if (preferences.isNeedInterAd) {
//            val isFirstSession = preferences.sessionCounter == 1
//            val interAdId = if (isFirstSession) getString(R.string.inter_all) else getString(R.string.inter_all2)
//            AdmobIntersAdImpl().load(this, interAdId)
//        } else {
//            checkReInter {
//                if (it) {
//                    val isFirstSession = preferences.sessionCounter ==1
//                    val adId = if (isFirstSession) interex1 else interex2
//                    AdmobIntersAdImpl().load(this, adId)
//                    preferences.isNeedInterAd = true
//                }
//            }
//        }
        binding = ActivityJunkCleanerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //updateStatusBarColor(Color.parseColor("#1878F3"))
        loadBanner()

        intView()
        intListener()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun intView() {
        category = intent.getStringExtra("cate") ?: ""
        if (category == "screenshots") {
            binding.txtSelectCount.setText(getString(R.string.screenshots))
        }
        if (category == "largemedia") {
            binding.txtSelectCount.setText(getString(R.string.large_media))
        }
        if (category == "duplicate") {
            binding.btnSmartChoice.beVisible()
            binding.txtSelectCount.setText(getString(R.string.duplicate_photos))
        } else {
            binding.btnSmartChoice.beGone()
        }
        pictures = ArrayList(selectedRealPhotoData)

//        binding.groupToolbarSelectHeader.visibility = View.VISIBLE
//        binding.groupToolbarHeader.visibility = View.GONE

        initAdapter()
    }

    private fun intListener() {
//        binding.icBack.setOnClickListener {
//            onBackPressed()
//        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            //setSelectAllColor()
        }
        binding.btnSmartChoice.setOnClickListener {
            isSmartSelected = !isSmartSelected
            setSmartSelectClick(isSmartSelected)
            //setSelectAllColor()
        }
        binding.btnDelete.setOnClickListener {
//            requestStoragePermission(app_cleaner_AFA_allow_nf, app_cleaner_AFA_denied_nf, getActivityName()) {
//                if (it) {
                    showDeleteDialog()
//                }
//            }
        }
        binding.frameProgress.setOnClickListener {
            toast(getString(R.string.please_wait))
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog = DeleteDialog.newInstance(
                this,
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show()
        }
    }

    override fun onBackPressed() {
        setCloseToolbar()
    }

    fun setCloseToolbar() {
        if (selectedItem == 0) {
            if (preferences.isNeedInterAd) {
                AdsConfig.showInterstitialAd(this) {
                    if (it) preferences.isNeedInterAd = false
                    setResult(actResult)
                    finish()
                }
            } else {
                setResult(actResult)
                finish()
            }
        } else {
            setClose()
            longClickListener(false, 0, false)
        }
    }

//    var finalProgressDialog: ProgressDialog? = null

    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        preferences.refreshMedia = true
        preferences.scanMedia = true
        sendEvent("refresh")

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()
//        finalProgressDialog = ProgressDialog(
//            this@JunkCleanerActivity,
//            0,
//            0,
//            getString(R.string.please_wait),
//            ""
//        )

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {

                            val entity = dataBase.dataDao().getLocationEntity(model.filePath)
                            if (entity != null) {
                                dataBase.dataDao().deleteLocationEntity(entity)
                            }

                            val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                            MediaScannerConnection.scanFile(this, arrayOf<String>(model.filePath), null) { path: String?, uri: Uri? -> }

                            if (isDelete) {
                                deleteList.add(model.filePath)
                                runOnUiThread {
                                    progressDialog.setProgress(deleteList.size, selectedItem)
                                }
                            }

                            model.isCheckboxVisible = false
                            model.isSelected = false
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    } else if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    binding.frameProgress.visibility = View.VISIBLE
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()

//                        finalProgressDialog?.show()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    binding.frameProgress.visibility = View.VISIBLE
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
//                        finalProgressDialog?.show()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {

        selectedItem = 0
        notifyAdapter()

        isSelectAll = false
        binding.btnDelete.isEnabled = false
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
//        setEmptyData()

        toast(getString(R.string.Delete_successfully))

        deleteMainList(deleteList) {
//            if (finalProgressDialog?.isShowing!!)
//                finalProgressDialog?.dismiss()
            if (category == "screenshots") {
                Constant.ssRealPhotoData = pictures
            }
            if (category == "largemedia") {
                Constant.largeRealPhotoData = pictures
            }
            if (category == "duplicate") {
                Constant.duplicateRealPhotoData = pictures
            }

            runOnUiThread {
                binding.frameProgress.visibility = View.GONE
                if (pictures.size == 0) {
                    actResult = Activity.RESULT_OK
                    setCloseToolbar()
//                setResult(Activity.RESULT_OK)
//                finish()
                } else {
                    junkAdapter?.submitList(pictures)
                    actResult = Activity.RESULT_OK
                    longClickListener(false, 0, false)
                    isSelectAll = false
                    setSelectClick(isSelectAll)
                }
            }
        }

    }

    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottomAd.beVisible()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottomAd.beGone()
        }
    }

    private fun deleteMainList(deleteList: ArrayList<String>, callback: () -> Unit) {
        if (deleteList.isNotEmpty()) {
            pictures.removeAll { pictureData ->
                pictureData is MediaData && deleteList.contains(pictureData.filePath)
            }
        }

//        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in pictures) {
//                    if (pictureData is MediaData)
//                        if (pictureData.filePath == path) {
//                            pictures.remove(pictureData)
//                            break
//                        }
//                }
//            }
//        }


        CoroutineScope(Dispatchers.IO).launch {
            withContext(Dispatchers.IO) {
                //remove deleted data
//                pictures.removeIf { item ->
//                    item is MediaData && !File(item.filePath).exists()
//                }
                //remove empty album
                val indicesToRemove = mutableListOf<Int>()
                for (i in pictures.indices) {
                    if (pictures[i] is AlbumData) {
                        var hasMediaData = false
                        for (j in (i + 1) until pictures.size) {
                            if (pictures[j] is MediaData) {
                                hasMediaData = true
                            } else if (pictures[j] is AlbumData) {
                                break
                            }
                        }
                        if (!hasMediaData) {
                            indicesToRemove.add(i)
                        }
                    }
                }
                for (index in indicesToRemove.reversed()) {
                    pictures.removeAt(index)
                }
                // Remove AlbumData with only one MediaData between them
                if (category == "duplicate") {
                    val result = removeSingles(pictures)
                    pictures = result
                }
                callback.invoke()
            }
        }
    }

    fun removeSingles(pictures: ArrayList<Any>): ArrayList<Any> {
        val result = ArrayList<Any>()
        var tempAlbumData: AlbumData? = null
        val tempMediaData = ArrayList<MediaData>()

        for (item in pictures) {
            when (item) {
                is AlbumData -> {
                    if (tempMediaData.size > 1 || tempAlbumData == null) {
                        // If there are more than 1 MediaData or this is the first AlbumData, add them all
                        tempAlbumData?.let { result.add(it) }
                        result.addAll(tempMediaData)
                    }
                    tempAlbumData = item
                    tempMediaData.clear()
                }

                is MediaData -> {
                    tempMediaData.add(item)
                }
            }
        }

        // Add remaining AlbumData and MediaData after the loop
        if (tempMediaData.size > 1 || tempAlbumData == null) {
            tempAlbumData?.let { result.add(it) }
            result.addAll(tempMediaData)
        }

        return result
    }

    fun setSmartSelectClick(isSelectAll: Boolean) {
        var selected = 0
        var isSmartSelected = false
        if (isSelectAll) {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = true
                        isSmartSelected = true
                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (isSmartSelected) {
                            model.isSelected = false
                            isSmartSelected = false
                        } else {
                            model.isSelected = true
                            if (isSelectAll)
                                selected++
                        }
                    }
            }
        } else {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        model.isSelected = false
                    }
            }
        }
        notifyAdapter()
        longClickListener(true, selected, false)
        selectedItem = selected

        binding.ivSmartChoice.setImageDrawable(
            if (isSelectAll) ContextCompat.getDrawable(
                this,
                R.drawable.ic_check_right
            )
            else ContextCompat.getDrawable(
                this,
                R.drawable.ic_check_off
            )
        )
    }

    fun setSelectClick(isSelectAll: Boolean) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = isSelectAll
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++
                }
        }
        notifyAdapter()
//        junkAdapter?.notifyItemRangeChanged(0, pictures.size,"showCheckBox")
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected

        isSmartSelected = false
        binding.ivSmartChoice.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_check_off
            )
        )
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        notifyAdapter()
        selectedItem = 0
    }

    fun setRvLayoutManager() {
        try {

//            val layoutManager = MyGridLayoutManager(this, 3, RecyclerView.VERTICAL, false)
            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 3
            layoutManager.orientation = RecyclerView.VERTICAL
            binding.pictureRecycler.layoutManager = layoutManager
//            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < pictures.size) {
                        return if (junkAdapter!!.getItemViewType(position) == junkAdapter!!.ITEM_HEADER_TYPE) {
                            3
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    private fun initAdapter() {
        setRvLayoutManager()
//        binding.cleanerFastscroller.attachFastScrollerToRecyclerView(binding.pictureRecycler)
        junkAdapter = JunkAdapter(this,
            clickListener = {
            if (pictures[it] is MediaData) {
                val mediaData = pictures[it] as MediaData
                if (!isCheckSearchOn) {
                    mediaData.isSelected = !mediaData.isSelected
                    if (::binding.isInitialized)
                        binding.pictureRecycler.recycledViewPool.clear()
                    junkAdapter?.notifyItemChanged(it, "showCheckBox")
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<MediaData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is MediaData) {
                            dataList.add(pictures[i] as MediaData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    Constant.selectedPosition = displayPos
                    if (Constant.displayImageList.size > 0) {
//                        val intent = Intent(this, PhotoVideoActivity::class.java)
//                        intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
//                        photoVideoLauncher.launch(intent)
                    }
                }
            }
        },
            longClickListener = {
            if (pictures[it] is MediaData) {
                val mediaData = pictures[it] as MediaData

                val detailsDialog = PreviewDialog(this, mediaData)
                detailsDialog.show()
            }
        },
            headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is MediaData) {
                        val model = pictures[pos] as MediaData
                        model.isSelected = isSelectAll
                        junkAdapter?.notifyItemChanged(pos, "showCheckBox")
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
//                notifyAdapter()
                setSelectedFile()
            }
        })

        binding.pictureRecycler.setDragSelectActive(-1)
        junkAdapter?.submitList(pictures)
        binding.pictureRecycler.adapter = junkAdapter


        binding.pictureRecycler.post {
            FastScroller(binding.handleView).bind(binding.pictureRecycler)
        }

        initDragListener()
        setupDragListener(mDragListener)

        if (category == "duplicate") {
//            binding.btnSmartChoice.performClick()
            setSmartSelectClick(isSmartSelected)
        } else {
//            binding.icSelect.performClick()
            setSelectClick(isSelectAll)
        }
    }

    private fun notifyAdapter() {
        if (junkAdapter != null) {
//            if (::binding.isInitialized)
//                binding.pictureRecycler.recycledViewPool.clear()
//            binding.pictureRecycler.post {
//                imageListAdapter?.notifyDataSetChanged()
            runOnUiThread {
                junkAdapter?.submitList(pictures)
                junkAdapter?.notifyItemChanged(0, pictures.size)
                junkAdapter?.notifyItemRangeChanged(0, pictures.size,"showCheckBox")
            }
//            }
        }
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int,
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        try {
            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {

                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as MediaData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
        } catch (e: Exception) {

        }

        if (::binding.isInitialized)
            binding.pictureRecycler.recycledViewPool.clear()
        junkAdapter?.notifyItemChanged(pos, "showCheckBox")
        setSelectedFile()
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        if (::binding.isInitialized)
                            binding.pictureRecycler.recycledViewPool.clear()
                        junkAdapter?.notifyItemChanged(currentHeaderPos, "showCheckBox")
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    if (::binding.isInitialized)
                        binding.pictureRecycler.recycledViewPool.clear()
                    junkAdapter?.notifyItemChanged(currentHeaderPos, "showCheckBox")
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        selectedItem = selected

    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean,
    ) {

        isSelectAll = isAllSelect
        binding.btnDelete.isEnabled = if (isShowSelection && selectedItem != 0) true else false
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"

        setSelectAllColor()

        val totalSelectedFileSize: Long = pictures.filterIsInstance<MediaData>().filter { it.isSelected }.sumOf { it.fileSize }
        Log.e("JunkScanActivity", "totalSelectedFileSize:${totalSelectedFileSize}")
        val size = Formatter.formatShortFileSize(this@JunkCleanerActivity, totalSelectedFileSize)
        binding.selectedSize.text = "($size)"
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {
            mAdView= AdCache.cleanerAdView
            val isFirstSession = preferences.sessionCounter ==1
            val adId = if (isFirstSession) getString(R.string.b_duplicate_image) else getString(R.string.b_duplicate_image)
            showBanner(this, binding.layoutBanner.mFLAd, binding.llAdPlace, adId,
                mAdView, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.cleanerAdView = adView
                    isAdLoaded = isLoaded
                    loadInterAd()
                })
        } else loadInterAd()
    }


    fun showBanner(
        context: Activity,
        container: ViewGroup,
        parent: ViewGroup,
        adId: String,
        cacheAdView: AdView?,
        onLoaded: (isLoaded: Boolean, adView: AdView?, message: String) -> Unit,
        mAdSize: AdSize? = null,
    ) {
        if (context.isOnline()) {
            var adView = AdView(context)

            Log.d(TAG, "001.showBanner.adId:$adId")

            adView.adListener = object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    onLoaded.invoke(
                        false,
                        null,
                        "001.onAdFailedToLoad:${adError.code},${adError.message}"
                    )
                    Log.i(
                        TAG,
                        "001.onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                    )
                    container.visibility = View.GONE
                    parent.visibility = View.GONE
                }

                override fun onAdLoaded() {
                    try {
                        onLoaded.invoke(true, adView, "ok")
                        if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
                        if (container.childCount > 0) container.removeAllViews()
                        container.addView(adView)
                        container.visibility = View.VISIBLE
                        parent.visibility = View.VISIBLE

                        Log.d(TAG, "001.onAdLoaded")
                    } catch (e: Exception) {

                    }

                }

                override fun onAdClicked() {
                    super.onAdClicked()
                    Log.d(TAG, "001.onAdClicked")
                    AdsConfig.isSystemDialogOpen = true
                }
            }

            if (cacheAdView != null) {
                adView = cacheAdView

                Log.d(TAG, "onLoadCacheAdView")
                if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
//                if (adView.parent != null) (adView.parent as ViewGroup).removeAllViews()
                if (container.childCount > 0) container.removeAllViews()

                val layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )

                layoutParams.gravity = Gravity.CENTER or Gravity.BOTTOM
                container.post {
                    try {
                        if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
                        if (container.childCount > 0) container.removeAllViews()
                        container.addView(adView, layoutParams)
                        container.bringChildToFront(adView)
                        container.visibility = View.VISIBLE
                        parent.visibility = View.VISIBLE
                        container.invalidate()
                        container.requestLayout()
                        adView.resume()

                        Log.d(
                            TAG,
                            "adView.size:${adView.height}x${adView.width},container.size:${container.height}x${container.width}"
                        )
                    } catch (e: Exception) {
                        container.visibility = View.GONE
                        parent.visibility = View.GONE
                    }
                }
                adView.resume()
            } else {
                Log.d(TAG, "onLoadAdView")
                if (mAdSize != null) {
                    Log.d(TAG, "onLoadAdView.mAdSize-:${mAdSize.height}:${mAdSize.width}:-")
                    adView.setAdSize(mAdSize)
                } else {
                    val adSize = BannerAdHelper.getAdSize(
                        context, container
                    )
                    Log.d(TAG, "onLoadAdView.adSize-:${adSize.height}:${adSize.width}:-")
                    adView.setAdSize(
                        adSize
                    )
                }
                adView.adUnitId = adId
                adView.loadAd(AdRequest.Builder().build())
            }
        } else {
            container.visibility = View.GONE
        }
    }

    private fun loadInterAd() {
        if (preferences.isNeedInterAd) {
            val isFirstSession = preferences.sessionCounter == 1
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val isFirstSession = preferences.sessionCounter == 1
                    val adId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, adId)
                    preferences.isNeedInterAd = true
                }
            }
        }
    }
}