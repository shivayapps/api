package com.photogallery.utils

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var homeAdView:AdView?=null
        var editAdView:AdView?=null
        var albumAdView:AdView?=null
        var exploreAlbumAdView:AdView?=null
        var imageListAdView:AdView?=null
        var recentlyDeletedAdView:AdView?=null
        var mapExploreAdView:AdView?=null
        var recoverMediaAdView:AdView?=null
        var privateViewerAdView:AdView?=null
        var privateAdView:AdView?=null
        var privateListAdView:AdView?=null
        var photoVideoAdView:AdView?=null
        var favoriteListAdView:AdView?=null
        var cleanerAdView:AdView?=null
        var dirsAdView:AdView?=null
        var selectImageAdView:AdView?=null

        var duplicateAudiosAdView:AdView?=null
        var duplicateDocumentAdView:AdView?=null
        var duplicateImageAdView:AdView?=null
        var duplicateVideoAdView:AdView?=null

    }
}


