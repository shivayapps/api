package com.photogallery

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity

import com.github.ajalt.reprint.core.Reprint
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.squareup.picasso.Downloader
import com.squareup.picasso.Picasso
import com.photogallery.activities.setup.PermissionActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TIME_FORMAT_12
import com.photogallery.utils.TIME_FORMAT_24
import okhttp3.Request
import okhttp3.Response

class GalleryApp : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {

    lateinit var remoteConfig: FirebaseRemoteConfig
    override fun onCreate() {
        super.onCreate()
//        com.photogallery.GalleryApp.Companion.mContext = applicationContext

        Reprint.initialize(this)
        Picasso.setSingletonInstance(Picasso.Builder(this).downloader(object : Downloader {
            override fun load(request: Request) = Response.Builder().build()

            override fun shutdown() {}
        }).build())

        preferences =
            Preferences(applicationContext)
        FirebaseApp.initializeApp(applicationContext)
        FirebaseCrashlytics.getInstance()
            .setCrashlyticsCollectionEnabled(!BuildConfig.VERSION_NAME.contains("test"));

        MobileAds.initialize(applicationContext)
        remoteConfig = FirebaseRemoteConfig.getInstance()
        remoteConfig.reset()
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(applicationContext)

        val AdmobAppOpenId = getString(R.string.open_all)

        AdsConfig.builder()
            .setTestDeviceId("43D54D26FD5DBC346211511E0DFD64F9")
            .setAdmobAppOpenId(AdmobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()

//        OpenAdHelper.loadOpenAd(this)

        fireBaseConfigGet()

        Constant.themeType = preferences.getThemeValue()
        setAppTheme(Constant.themeType)
        val dateFormat = preferences.dateFormat
        val timeFormat = if (preferences.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12
        Constant.dateFormat = dateFormat
        Constant.timeFormat = timeFormat
    }
    public fun setAppTheme(themeType:Int) {
        Log.d("GalleryApp", "setAppTheme")
//        themeType = Preferences(this).getThemeValue()
        when (themeType) {
            Constant.THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            Constant.THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
        Log.d("GalleryApp", "setAppTheme.002")
    }

    private fun fireBaseConfigGet() {
        try {
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(0)
                    .setFetchTimeoutInSeconds(3)
                    .build()
            )

            remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)
            remoteConfig.fetch(0)
                .addOnCompleteListener { task: Task<Void?> ->
                    var errorString = ""
                    if (task.isSuccessful) {
                        Log.e("fireBaseConfigGet", "Successful")
                        remoteConfig.fetchAndActivate()

//                        val isEnableAds: Boolean = remoteConfig.getBoolean("isEnableAds")
//                        val isEnableOpenAd: Boolean = remoteConfig.getBoolean("isEnableOpenAd")
//                        val isEnableAds = true
//                        val isEnableOpenAd = true
//
//                        Log.e("fireBaseConfigGet", "isEnableAds:$isEnableAds")
//                        Log.e("fireBaseConfigGet", "isEnableOpenAd:$isEnableOpenAd")
//
//                        preferences.isEnableAds = isEnableAds
//                        preferences.isEnableOpenAds = isEnableAds

                        errorString = " task is successful  "

                    } else {
                        Log.e("fireBaseConfigGet", "Failed:${task.exception}")
                        errorString = "task is canceled"
                    }
                }
        } catch (e: java.lang.Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }
    }

    companion object {
//        private lateinit var mContext: Context
        lateinit var mFirebaseAnalytics: FirebaseAnalytics
        lateinit var preferences: Preferences

//        fun getContext(): Context {
//            return mContext
//        }

    }

    //    override fun onPauseApp(fCurrentActivity: Activity) {
//
//    }
    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is com.photogallery.SplashActivity) {
            return false
        } else if (fCurrentActivity is PermissionActivity) {
            return false
        } else if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
//            if (!OpenAdHelper.isAdAvailable()) {
                val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                fCurrentActivity.startActivity(intent)
//            }
//            else {
//                logMessages("app_appopen_created", fCurrentActivity.localClassName)
//            }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }


}
