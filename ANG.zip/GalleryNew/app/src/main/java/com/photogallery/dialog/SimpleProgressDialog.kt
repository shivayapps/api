package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogProgressSimpleBinding
import com.photogallery.utils.Constant


class SimpleProgressDialog(
    val activity: Activity,
    val txtTopTitle: String,
) : Dialog(activity) {

    lateinit var bindingDialog: DialogProgressSimpleBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        //window?.setDimAmount(0.8f)

        val navigationBarColor = if (Constant.themeType == Constant.THEME_LIGHT) {
            Color.parseColor("#FFFFFFFF")
        } else {
            Color.parseColor("#1F1F1F")
        }

        window?.navigationBarColor = navigationBarColor

        bindingDialog = DialogProgressSimpleBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
//        window?.setLayout(
//            WindowManager.LayoutParams.MATCH_PARENT,
//            WindowManager.LayoutParams.WRAP_CONTENT
//        )
        intView()
    }

    private fun intView() {
        bindingDialog.txtTitle.text = txtTopTitle
        bindingDialog.progressBar.isIndeterminate = true
    }

}