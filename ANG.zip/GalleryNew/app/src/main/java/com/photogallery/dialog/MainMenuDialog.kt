package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogMainMenuBinding
import com.photogallery.utils.Preferences

class MainMenuDialog(var mContext: Context, val currentFragment: Int, val clickListener: (type: Int) -> Unit) :
    Dialog(mContext) {

    lateinit var bindingDialog: DialogMainMenuBinding
    lateinit var preferences: Preferences
    var isShowGrid = false
    var gridCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(mContext, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
//                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
//                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        bindingDialog = DialogMainMenuBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {
        preferences = Preferences(mContext)
        isShowGrid = preferences.getShowGrid()
        gridCount = preferences.getGridCount()
        selectedGrid = gridCount


//        binding.btnGroup.visibility = View.VISIBLE
//        binding.btnList.visibility = View.VISIBLE
//        binding.btnGrid.visibility = View.VISIBLE
//        binding.btnChangeViewType.visibility =  if (isShowAlbumTab) View.VISIBLE else View.GONE

        intListener()
        setView()
        setColumnView()

    }

    private fun setView() {

        if (currentFragment == 0) {
            bindingDialog.btnList.visibility = View.GONE
            bindingDialog.btnGrid.visibility = View.GONE
            bindingDialog.btnDisplayedColumns.visibility = View.VISIBLE
        } else {
            if (isShowGrid) {
                bindingDialog.btnGrid.visibility = View.GONE
                bindingDialog.btnList.visibility = View.VISIBLE
                bindingDialog.btnDisplayedColumns.visibility = View.VISIBLE
            } else {
                bindingDialog.btnGrid.visibility = View.VISIBLE
                bindingDialog.btnList.visibility = View.GONE
                bindingDialog.btnDisplayedColumns.visibility = View.GONE
            }
        }

    }

    var selectedGrid = -1
    private fun intListener() {
        bindingDialog.btnSortBy.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        bindingDialog.btnGroup.setOnClickListener {
            dismiss()
            clickListener(2)
        }
        bindingDialog.btnFilterMedia.setOnClickListener {
            dismiss()
            clickListener(3)
        }


        bindingDialog.btnList.setOnClickListener {
            if (isShowGrid) {
                isShowGrid = false
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener.invoke()
                clickListener(21)
                dismiss()
            } else dismiss()
        }
        bindingDialog.btnGrid.setOnClickListener {
            if (!isShowGrid) {
                isShowGrid = true
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener.invoke()
                clickListener(22)
                dismiss()
            } else dismiss()
        }



        bindingDialog.btnDisplayedColumns.setOnClickListener {
            dismiss()
            clickListener(4)
        }

        bindingDialog.btnRecycleBin.setOnClickListener {
            dismiss()
            clickListener(5)
        }
        bindingDialog.btnSetting.setOnClickListener {
            dismiss()
            clickListener(6)
        }

    }

    private fun setColumnView() {
        when (selectedGrid) {
        }
    }


//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}