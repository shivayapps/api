package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.format.DateFormat
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.photogallery.R
import com.photogallery.databinding.DialogDateTimeBinding

import com.photogallery.utils.DATE_FORMAT_FIVE
import com.photogallery.utils.DATE_FORMAT_FOUR
import com.photogallery.utils.DATE_FORMAT_ONE
import com.photogallery.utils.DATE_FORMAT_SIX
import com.photogallery.utils.DATE_FORMAT_SEVEN
import com.photogallery.utils.DATE_FORMAT_THREE
import com.photogallery.utils.DATE_FORMAT_EIGHT
import com.photogallery.utils.DATE_FORMAT_TWO
import com.photogallery.utils.Preferences
import java.util.Calendar

class DateTimeDialog(
    var mContext: Context, val updateListener: () -> Unit
) :
    Dialog(mContext) {

    lateinit var bindingDialog: DialogDateTimeBinding
    lateinit var preferences: Preferences
    private val timeSample = 1676419200000    // February 15, 2023


    //    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogDateTimeBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog.root
//    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(mContext, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
//                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
//                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        bindingDialog = DialogDateTimeBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {
        preferences = Preferences(mContext)
        val dateFormat = preferences.dateFormat
        val use24HourFormat = preferences.use24HourFormat

        intListener()

        bindingDialog.apply {
            changeDateTimeDialogRadioOne.text = formatDateSample(DATE_FORMAT_ONE)
            changeDateTimeDialogRadioTwo.text = formatDateSample(DATE_FORMAT_TWO)
            changeDateTimeDialogRadioThree.text = formatDateSample(DATE_FORMAT_THREE)
            changeDateTimeDialogRadioFour.text = formatDateSample(DATE_FORMAT_FOUR)
            changeDateTimeDialogRadioFive.text = formatDateSample(DATE_FORMAT_FIVE)
            changeDateTimeDialogRadioSix.text = formatDateSample(DATE_FORMAT_SIX)
            changeDateTimeDialogRadioSeven.text = formatDateSample(DATE_FORMAT_SEVEN)
            changeDateTimeDialogRadioEight.text = formatDateSample(DATE_FORMAT_EIGHT)

            cbTime24hFormat.isChecked = preferences.use24HourFormat

            val formatButton = when (preferences.dateFormat) {
                DATE_FORMAT_ONE -> changeDateTimeDialogRadioOne
                DATE_FORMAT_TWO -> changeDateTimeDialogRadioTwo
                DATE_FORMAT_THREE -> changeDateTimeDialogRadioThree
                DATE_FORMAT_FOUR -> changeDateTimeDialogRadioFour
                DATE_FORMAT_FIVE -> changeDateTimeDialogRadioFive
                DATE_FORMAT_SIX -> changeDateTimeDialogRadioSix
                DATE_FORMAT_SEVEN -> changeDateTimeDialogRadioSeven
                else -> changeDateTimeDialogRadioEight
            }
            formatButton.isChecked = true
        }


    }

    private fun formatDateSample(format: String): String {
//        val cal = Calendar.getInstance(Locale.ENGLISH)
        val cal = Calendar.getInstance()
//        cal.timeInMillis = timeSample
        val strFormat = DateFormat.format(format, cal).toString().trim()
        Log.e("formatDateSample", "format>>$format<<, strFormat>>$strFormat<<")
        return strFormat + " "
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            preferences.dateFormat = when (bindingDialog.grpDateFormat.checkedRadioButtonId) {
                bindingDialog.changeDateTimeDialogRadioOne.id -> DATE_FORMAT_ONE
                bindingDialog.changeDateTimeDialogRadioTwo.id -> DATE_FORMAT_TWO
                bindingDialog.changeDateTimeDialogRadioThree.id -> DATE_FORMAT_THREE
                bindingDialog.changeDateTimeDialogRadioFour.id -> DATE_FORMAT_FOUR
                bindingDialog.changeDateTimeDialogRadioFive.id -> DATE_FORMAT_FIVE
                bindingDialog.changeDateTimeDialogRadioSix.id -> DATE_FORMAT_SIX
                bindingDialog.changeDateTimeDialogRadioSeven.id -> DATE_FORMAT_SEVEN
                else -> DATE_FORMAT_EIGHT
            }

            preferences.use24HourFormat = bindingDialog.cbTime24hFormat.isChecked
            dismiss()
            updateListener()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}