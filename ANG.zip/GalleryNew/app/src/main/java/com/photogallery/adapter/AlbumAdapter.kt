package com.photogallery.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.databinding.ItemAlbumGridBinding
import com.photogallery.databinding.ItemAlbumListBinding
import com.photogallery.databinding.ItemHeaderDividerBinding
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences
import com.photogallery.databinding.LayoutTopBinding
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.loadImage

class AlbumAdapter(
    var context: Context,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val utilClickListener: ((utilPos: Int) -> Unit)? = null,
) : ListAdapter<AlbumData, RecyclerView.ViewHolder>(DiffCallBack()) {

    private class DiffCallBack : DiffUtil.ItemCallback<AlbumData>() {
        override fun areItemsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem
    }

//    val ITEM_ALBUM_HEADER_TYPE = 0
    val ITEM_ALBUM_UTIL_TYPE = 1
    val ITEM_ALBUM_GRID_TYPE = 2
    val ITEM_ALBUM_LIST_TYPE = 3

    var preferences: Preferences = Preferences(context)

    var pinList: ArrayList<String> = ArrayList()

    init {
        pinList = preferences.getPinAlbumList()
    }

    fun updatePinList() {
        pinList = preferences.getPinAlbumList()
    }

    override fun getItemViewType(position: Int): Int {
        return if (preferences.getShowGrid()) {

            if (getItem(position).isCustomAlbum && getItem(position).title.equals("utility")) {
                ITEM_ALBUM_UTIL_TYPE
            } else {
                ITEM_ALBUM_GRID_TYPE
            }
        } else {
            if (getItem(position).isCustomAlbum && getItem(position).title.equals("utility")) {
                ITEM_ALBUM_UTIL_TYPE
            } else {
                ITEM_ALBUM_LIST_TYPE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_ALBUM_GRID_TYPE) {
            val binding =
                ItemAlbumGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumGridViewHolder(binding)
        } else if (viewType == ITEM_ALBUM_LIST_TYPE) {
            val binding =
                ItemAlbumListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumListViewHolder(binding)
        } else if (viewType == ITEM_ALBUM_UTIL_TYPE) {
            val binding = LayoutTopBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            UtilViewHolder(binding)
        }
        else {
            val binding = ItemHeaderDividerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        if (getItemViewType(position) == ITEM_ALBUM_GRID_TYPE) {
            val albumGridViewHolder = holder as AlbumGridViewHolder
            val albumData: AlbumData = getItem(position) as AlbumData

            if (pinList.contains(albumData.folderPath)) albumGridViewHolder.binding.icPin.visibility =
                View.VISIBLE
            else albumGridViewHolder.binding.icPin.visibility = View.GONE

            albumGridViewHolder.binding.txtTitle.text = albumData.title
            if (albumData.mediaData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text = "${albumData.mediaData.size}"
                val coverPath = preferences.getCoverImage(albumData.folderPath)

                if (coverPath.isNotEmpty()) {
                    context.loadImage(
                        path = coverPath,
                        target = albumGridViewHolder.binding.image,
                        signature = albumData.mediaData[0].getKey(),
                        onError = {
                            albumGridViewHolder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                            albumGridViewHolder.binding.image.setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_image_placeholder))
                        }
                    )
                } else {
                    context.loadImage(
                        path = albumData.mediaData[0].filePath,
                        target = albumGridViewHolder.binding.image,
                        signature = albumData.mediaData[0].getKey(),
                        onError = {
                            albumGridViewHolder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                            albumGridViewHolder.binding.image.setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_image_placeholder))
                        }
                    )
                    try {
                        albumGridViewHolder.binding.ivGif!!.beVisibleIf(
                            albumData.mediaData[0].filePath.endsWith(
                                "gif",
                                true
                            )
                        )
                    } catch (e: Exception) {
                    }
                }
//                }
            } else {
                albumGridViewHolder.binding.txtCount.text = "0"
                albumGridViewHolder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            if (albumData.isCheckboxVisible && !albumData.isCustomAlbum) {
                albumGridViewHolder.binding.icUnSelect.visibility = View.VISIBLE
                albumGridViewHolder.binding.icSelect.visibility =
                    if (albumData.isSelected) View.VISIBLE else View.GONE
            } else {
                albumGridViewHolder.binding.icUnSelect.visibility = View.GONE
                albumGridViewHolder.binding.icSelect.visibility = View.GONE
//                albumGridViewHolder.binding.icFavourite.visibility =
//                    if (albumData.isFavorite) View.VISIBLE else View.GONE
            }

            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(position)
            }
            albumGridViewHolder.binding.root.setOnLongClickListener {
                longClickListener(position)
                true
            }
        }
        else if (getItemViewType(position) == ITEM_ALBUM_LIST_TYPE) {
            val albumGridViewHolder = holder as AlbumListViewHolder
            val albumData: AlbumData = getItem(position) as AlbumData

            if (pinList.contains(albumData.folderPath)) albumGridViewHolder.binding.icPin.visibility =
                View.VISIBLE
            else albumGridViewHolder.binding.icPin.visibility = View.GONE

            albumGridViewHolder.binding.txtTitle.text = albumData.title


            if (albumData.mediaData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text =
                    "${albumData.mediaData.size} ${context.getString(R.string.items)}"

//                val glideOptions = RequestOptions()
//                    .format(DecodeFormat.PREFER_ARGB_8888)
//                    .diskCacheStrategy(DiskCacheStrategy.NONE)
//                    .skipMemoryCache(true)
                val coverPath = preferences.getCoverImage(albumData.folderPath)
                if (coverPath.isNotEmpty()) {
//                    Glide.with(context.applicationContext)
//                        .asBitmap()
//                        .apply(glideOptions)
//                        .override(180)
//                        .diskCacheStrategy(DiskCacheStrategy.ALL)
//                        .load(coverPath)
//                        .into(albumGridViewHolder.binding.image)

                    context.loadImage(
                        path = coverPath,
                        target = albumGridViewHolder.binding.image,
                        signature = albumData.mediaData[0].getKey(),
                        onError = {
                            albumGridViewHolder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                            albumGridViewHolder.binding.image.setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_image_placeholder))
                        }
                    )
                } else {
//                    Glide.with(context.applicationContext)
//                        .asBitmap()
//                        .apply(glideOptions)
//                        .override(180)
//                        .diskCacheStrategy(DiskCacheStrategy.ALL)
//                        .load(albumData.pictureData[0].filePath)
//                        .into(albumGridViewHolder.binding.image)

                    context.loadImage(
                        path = albumData.mediaData[0].filePath,
                        target = albumGridViewHolder.binding.image,
                        signature = albumData.mediaData[0].getKey(),
                        onError = {
                            albumGridViewHolder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                            albumGridViewHolder.binding.image.setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_image_placeholder))
                        }
                    )
                    try {
                        albumGridViewHolder.binding.ivGif.beVisibleIf(
                            albumData.mediaData[0].filePath.endsWith(
                                "gif",
                                true
                            )
                        )
                    } catch (e: Exception) {
                    }
                }

//                try {
//                    albumGridViewHolder.binding.ivGif.beVisibleIf(
//                        albumData.pictureData[0].filePath.endsWith(
//                            "gif",
//                            true
//                        )
//                    )
//                } catch (e: Exception) {
//                }
//                }
            } else {
                albumGridViewHolder.binding.txtCount.text = "0 ${context.getString(R.string.items)}"
                albumGridViewHolder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            if (albumData.isCheckboxVisible && !albumData.isCustomAlbum) {
                albumGridViewHolder.binding.icUnSelect.visibility = View.VISIBLE
                albumGridViewHolder.binding.icSelect.visibility =
                    if (albumData.isSelected) View.VISIBLE else View.GONE
//                albumGridViewHolder.binding.icFavourite.visibility = View.GONE
            } else {
                albumGridViewHolder.binding.icUnSelect.visibility = View.GONE
                albumGridViewHolder.binding.icSelect.visibility = View.GONE
//                albumGridViewHolder.binding.icFavourite.visibility =
//                    if (albumData.isFavorite) View.VISIBLE else View.GONE
            }

            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(position)
            }
            albumGridViewHolder.binding.root.setOnLongClickListener {
                longClickListener(position)
                true
            }
        }
        else if (getItemViewType(position) == ITEM_ALBUM_UTIL_TYPE) {
            val albumHeaderViewHolder = holder as UtilViewHolder
            albumHeaderViewHolder.binding.llRecent.setOnClickListener {
                utilClickListener?.invoke(0)
            }
            albumHeaderViewHolder.binding.llAllVideo.setOnClickListener {
                utilClickListener?.invoke(1)
            }
            albumHeaderViewHolder.binding.llFavorite.setOnClickListener {
                utilClickListener?.invoke(2)
            }
            albumHeaderViewHolder.binding.llHidden.setOnClickListener {
                utilClickListener?.invoke(4)
            }
        }
//        else {
//            val albumHeaderViewHolder = holder as HeaderViewHolder
//            val headerText: AlbumData = getItem(position) as AlbumData
//            albumHeaderViewHolder.binding.txtHeader.text = headerText.title
//        }
    }

//    override fun getItemCount(): Int {
//        return albumList.size
//    }

    class UtilViewHolder(var binding: LayoutTopBinding) : RecyclerView.ViewHolder(binding.root)
    class HeaderViewHolder(var binding: ItemHeaderDividerBinding) : RecyclerView.ViewHolder(binding.root)

    class AlbumGridViewHolder(var binding: ItemAlbumGridBinding) :
        RecyclerView.ViewHolder(binding.root)

    class AlbumListViewHolder(var binding: ItemAlbumListBinding) :
        RecyclerView.ViewHolder(binding.root)

    fun getBubbleText(adapterPosition: Int): String {
//        val sorting = preferences.getAlbumSortType()
//        return albumList.getOrNull(position)?.getBubbleText(directorySorting, context, dateFormat, timeFormat) ?: ""
//        return getBubbleText(getItem(position) as AlbumData, sorting, dateFormat, timeFormat).toString()
        return getItem(adapterPosition).title
    }

//    private fun getBubbleText(
//        albumData: AlbumData,
//        sorting: Int,
//        dateFormat: String? = null,
//        timeFormat: String? = null
//    ): String {
//        var strKey = ""
//
//        when (sorting) {
//            Constant.SORT_NAME -> strKey = albumData.title
//            Constant.SORT_PATH -> strKey = albumData.title
//            Constant.SORT_SIZE -> strKey = albumData.title
//            Constant.SORT_LAST_MODIFIED -> {
//                strKey = DateFormat.format("$dateFormat, $timeFormat", albumData.date).toString()
//            }
//            Constant.SORT_DATE_TAKEN -> {
//                strKey = DateFormat.format("$dateFormat, $timeFormat", albumData.date).toString()
//            }
//        }
//
//        Log.e("PictureAdapter", "getBubbleText.002:$sorting, $strKey")
//        return strKey
//    }

}