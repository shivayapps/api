package com.photogallery.secret.activity

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import com.photogallery.R
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.databinding.ActivityLockBinding
import com.photogallery.extension.showBiometricPrompt
import com.photogallery.extension.toast
import com.photogallery.secret.fragment.LockFragment
import com.photogallery.utils.Preferences


class ResetLockActivity : BaseNoThemeActivity() {

    lateinit var preferences: Preferences

    lateinit var binding: ActivityLockBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preferences = Preferences(this)

        intView()

    }

    private fun setPasswordSuccess() {
         //startActivity(Intent(this, PrivateActivity::class.java))
        setResult(RESULT_OK)
        (this@ResetLockActivity).finish()
    }

    private fun startAndroidxBiometricManager() {
//        AuthPromptHost(activity as FragmentActivity)
        showBiometricPrompt(successCallback = { icSuccess ->
            if (icSuccess) {
                setPasswordSuccess()
            }
        }, failureCallback = { icFailed: Boolean, errorCode: Int, errString: CharSequence ->
            Log.e("BiometricManager","\nicFailed:$icFailed,\nerrorCode:$errorCode,errString:$errString")
            toast(R.string.authentication_failed)
        })

    }

    private fun intView() {
//        if (isChangeLockStyle) {
//            loadFragment(LockChangeStyleFragment(this, isLockStyleGrid, lockListener = {
//                setResult(RESULT_OK)
//                finish()
//            }))
//        } else {
            loadFragment(
                LockFragment(
                    this,
                    false,
                    false,
                    lockListener = {
                        if (it) {
                            setPasswordSuccess()
                        } else {
                            finish()
                        }
                    }
                )
            )
//        }
    }

    private fun loadFragment(fragment: Fragment) {
        val fm = this.supportFragmentManager
        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.container_lock, fragment)
        fragmentTransaction.commit()
    }

}