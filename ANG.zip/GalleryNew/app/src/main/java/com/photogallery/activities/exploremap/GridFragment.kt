package com.photogallery.activities.exploremap

import android.app.Activity
import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.activities.ImageListActivity
import com.photogallery.adapter.PlaceAdapter
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.databinding.FragmentGridBinding
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.model.PlaceData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import java.io.File
import java.util.Locale


class GridFragment : Fragment() {


    lateinit var activity: Activity
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var placeList: ArrayList<PlaceData> = ArrayList()
    var placeAdapter: PlaceAdapter? = null

    public fun setData(list: ArrayList<PlaceData>){
        placeList.clear()
        placeList.addAll(list)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    lateinit var binding: FragmentGridBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        binding = FragmentGridBinding.inflate(layoutInflater, container, false)
        if(isAdded && !isDetached) {
            initView()
        }
        return binding.root
    }

    private fun initView() {
        activity = requireActivity()
        preferences = Preferences(activity)

        placeAdapter = PlaceAdapter(activity, placeList,
            clickListener = {
                val albumData = placeList[it]
                openPlaceList(albumData)
            })

        binding.recyclerViewPlace.adapter = placeAdapter

        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanCount = 3

        initData()
    }

    private fun initData() {
        dataBase = AppDatabase.getInstance(activity)
        dataBase.dataDao().getLocationLiveEntityList()
            .observe(requireActivity()) { places: List<LocationEntity> ->
                sortPlace(places)
            }
    }

    private fun openPlaceList(placeData: PlaceData) {

        Constant.albumData = AlbumData(
            placeData.place,
            placeData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent=Intent(activity, ImageListActivity::class.java)
        intent.putExtra("isFromMap",true)
        intent.putExtra("lati",placeData.lati)
        intent.putExtra("long",placeData.long)
        startActivity(intent)
    }

    private fun sortPlace(placeList: List<LocationEntity>) {
//        val placeList = dataBase.dataDao().getLocationEntityList()
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")
        this.placeList.clear()
        placeList.forEach { data ->

            val strKey = data.title

            var imagesData1: ArrayList<MediaData> = ArrayList()

            val file = File(data.path)
            if(file.exists()) {

                val pictureData = MediaData(
                    file.path,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in this.placeList.indices) {
                    if (this.placeList[i].place == strKey) {
                        this.placeList[i].pictureData.add(pictureData)
                    }
                }

                if (this.placeList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(pictureData)
                    val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    this.placeList.add(placeData)
                }
            }
            else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }

        getImageOnMap()
        setEmptyData()
    }

    private fun setEmptyData() {
        if (placeList != null && placeList.size != 0) {
            binding.recyclerViewPlace.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.recyclerViewPlace.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    fun getImageOnMap() {
//        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
//        layoutManager.orientation = RecyclerView.VERTICAL
//        (binding.recyclerViewPlace.layoutManager as MyGridLayoutManager).spanCount =3
        Log.e("MapExploreActivity", "getImageOnMap:::albumWisePictures:${placeList.size}")
//        if (albumList != null && albumList.size > 0) {
//            albumList.forEach { album ->
////          for (album in albumList) {
//                addMarker(album)
//            }
//        }

        activity.runOnUiThread{
            if(placeAdapter!=null) {
                placeAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun latLongToAddressString(latitude: Float, longitude: Float): String {
        var addressString = ""
        val geocoder = Geocoder(activity, Locale.getDefault())
        try {
            val addresses: List<Address>? =
                geocoder.getFromLocation(latitude.toDouble(), longitude.toDouble(), 1)
            if (addresses != null) {
                val returnedAddress: Address = addresses[0]
                val strReturnedAddress = StringBuilder("")

                Log.w(
                    "MapExploreActivity",
                    "addressline:::==================================================="
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::adminArea==>:${returnedAddress.adminArea}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::featureName==>:${returnedAddress.featureName}"
                )
                Log.w("MapExploreActivity", "addressline:::locality==>:${returnedAddress.locality}")
                Log.w(
                    "MapExploreActivity",
                    "addressline:::subLocality==>:${returnedAddress.subLocality}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::countryName==>:${returnedAddress.countryName}"
                )
                Log.w(
                    "MapExploreActivity",
                    "addressline:::subAdminArea==>:${returnedAddress.subAdminArea}"
                )
                Log.w("MapExploreActivity", "addressline:::premises==>:${returnedAddress.premises}")


                if (returnedAddress.subLocality != null) {
                    strReturnedAddress.append(returnedAddress.subLocality)
                } else if (returnedAddress.locality != null) {
                    strReturnedAddress.append(returnedAddress.locality)
                }

                addressString = strReturnedAddress.toString()
            }
        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
        return addressString
    }

}