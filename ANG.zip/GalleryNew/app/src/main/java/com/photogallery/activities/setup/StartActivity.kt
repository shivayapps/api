package com.photogallery.activities.setup


import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log

import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.photogallery.R
import com.photogallery.activities.HomeActivity
import com.photogallery.base.BaseActivity

import com.photogallery.databinding.ActivityStartBinding
import com.photogallery.extension.toast
import com.photogallery.utils.Constant
import com.photogallery.utils.LogEvent
import com.photogallery.utils.Preferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class StartActivity : BaseActivity() {

    lateinit var binding: ActivityStartBinding
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferences = Preferences(this)
        init()
    }

    private fun init() {
//        binding.txtMsg.text = getString(R.string.permission_msg)
        binding.btnAllow.setOnClickListener {
            startActivity(nextScreen())
        }
    }

    private fun nextScreen(): Intent {
        Log.e("SplashTag", "nextScreen call")
        Log.e("SplashTag", "nextScreen ${preferences.isSetLanguage}")

        var intent = Intent(this, HomeActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (!checkStoragePermission()) {
            intent = Intent(
                this,
                PermissionActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } else if (!preferences.isSetLanguage) {
            intent = Intent(this, LanguageActivity::class.java)
//            intent = Intent(this, StartActivity::class.java)
                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, true)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } else  {
            intent = Intent(
                this,
                HomeActivity::class.java
            ).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return intent
    }



}