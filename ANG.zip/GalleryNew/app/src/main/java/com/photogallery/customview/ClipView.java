package com.photogallery.customview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Xfermode;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

public class ClipView extends View {
    private Paint paint = new Paint();
    //Brush to draw the border of the cropping area
    private Paint borderPaint = new Paint();
    //Crop frame horizontal spacing
    private float mHorizontalPadding;
    //Crop box border width
    private int clipBorderWidth;
    //The radius of the cropping circle
    private int clipRadiusWidth;
    //Cropping box rectangle width
    private int clipWidth;
    //Cropping frame category, (circle, rectangle), default is circle
    private ClipType clipType = ClipType.CIRCLE;
    private Xfermode xfermode;

    public ClipView(Context context) {
        this(context, null);
    }

    public ClipView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ClipView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        //去锯齿
        paint.setAntiAlias(true);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setColor(Color.WHITE);
        borderPaint.setStrokeWidth(clipBorderWidth);
        borderPaint.setAntiAlias(true);
        xfermode = new PorterDuffXfermode(PorterDuff.Mode.DST_OUT);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int LAYER_FLAGS = canvas.saveLayer(0, 0, getWidth(), getHeight(), null, Canvas.ALL_SAVE_FLAG);
        //Use Xfermode's DST_OUT to generate a transparent clipping area in the middle. You must create a new Layer.
        canvas.saveLayer(0, 0, this.getWidth(), this.getHeight(), null, Canvas.ALL_SAVE_FLAG);
        //set background
        canvas.drawColor(Color.parseColor("#a8000000"));
        paint.setXfermode(xfermode);
        //Draw a circular cropping box
        if (clipType == ClipType.CIRCLE) {
            //transparent circle in the middle
            canvas.drawCircle(this.getWidth() / 2, this.getHeight() / 2, clipRadiusWidth, paint);
            //white round border
            canvas.drawCircle(this.getWidth() / 2, this.getHeight() / 2, clipRadiusWidth, borderPaint);
        } else if (clipType == ClipType.RECTANGLE) { //Draw a rectangular cropping box
            //Draw the middle rectangle
            canvas.drawRect(mHorizontalPadding, this.getHeight(),
                    this.getWidth() - mHorizontalPadding, this.getHeight(), paint);
            //Draw a white rectangular border
            canvas.drawRect(mHorizontalPadding, this.getHeight() ,
                    this.getWidth() - mHorizontalPadding, this.getHeight(), borderPaint);
        }
        //Pop the stack and restore to the previous layer, which means that the new layer will be deleted and the content on the new layer will be drawn to the canvas (or the previous layer)
        canvas.restore();
    }

    /**
     * 获取裁剪区域的Rect
     *
     * @return
     */
    public Rect getClipRect() {
        Rect rect = new Rect();
        //Half the width - the radius of the circle
        rect.left = (this.getWidth() - clipRadiusWidth);
        //half the width + the radius of the circle
        rect.right = (this.getWidth() + clipRadiusWidth);
        //Half the height - the radius of the circle
        rect.top = (this.getHeight() - clipRadiusWidth);
        //half the height + the radius of the circle
        rect.bottom = (this.getHeight() + clipRadiusWidth);
        return rect;
    }

    /**
     * Set crop box border width
     *
     * @param clipBorderWidth
     */
    public void setClipBorderWidth(int clipBorderWidth) {
        this.clipBorderWidth = clipBorderWidth;
        borderPaint.setStrokeWidth(clipBorderWidth);
        invalidate();
    }

    /**
     * Set the horizontal spacing of the cropping frame
     *
     * @param mHorizontalPadding
     */
    public void setmHorizontalPadding(float mHorizontalPadding) {
        this.mHorizontalPadding = mHorizontalPadding;
//        this.clipRadiusWidth = (int) (getScreenWidth(getContext()) - 2 * mHorizontalPadding) / 2;
        this.clipRadiusWidth = 0;
        this.clipWidth = clipRadiusWidth * 2;
        Log.e("", "clipWidth==>> " + clipWidth);
    }

    /**
     * Get screen height
     *
     * @param context
     * @return
     */
    public static int getScreenWidth(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.widthPixels;
    }


    /**
     * Set cropping frame category
     *
     * @param clipType
     */
    public void setClipType(ClipType clipType) {
        this.clipType = clipType;
    }

    /**
     * Cropping frame category, circle, rectangle
     */
    public enum ClipType {
        CIRCLE, RECTANGLE
    }
}
