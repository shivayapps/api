package com.photogallery.model

data class RestoreData(var path: String, var deletedPath: String)