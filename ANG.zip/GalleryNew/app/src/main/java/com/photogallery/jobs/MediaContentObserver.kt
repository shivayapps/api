package com.photogallery.jobs

import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import com.photogallery.GalleryApp
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.sendEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

class MediaContentObserver(
    val handler: Handler, private val context: Context
) : ContentObserver(handler) {
    val NOTIFY_NO_DELAY: Int = 1 shl 15

    //    val screenshotsPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_SCREENSHOTS).absolutePath
    var urifetch: Uri? = null

    val runnable = Runnable {
        urifetch?.let {
            Log.d("MediaContentObserver", "Change detected at URI: 1")
            if (it.toString().contains(MediaStore.Images.Media.EXTERNAL_CONTENT_URI.toString()) || it.toString().contains(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString())) {
                Log.d("MediaContentObserver", "Change detected at URI: 2")
                if (isScreenshotUri(context, it)) {
                    Log.d("MediaContentObserver", "Change detected at URI: 3")
                    fetchNewMediaInsert(it)
                }
            }
        }
    }

    override fun onChange(selfChange: Boolean, uri: Uri?, flags: Int) {
        super.onChange(selfChange, uri, flags)
        Log.d("MediaContentObserver", "Change detected at flags uri: ${flags}")
        urifetch = uri
        handler.removeCallbacks(runnable)
        handler.postDelayed(runnable, 2000)
    }

    override fun onChange(selfChange: Boolean, uri: Uri?) {
        super.onChange(selfChange, uri)
        Log.d("MediaContentObserver", "Change detected at URI: $uri $selfChange")

    }

    companion object {
        var mediaContentObserver: MediaContentObserver? = null
        fun registerContentObserver(context: Context) {
            val contentResolver = context.contentResolver
            mediaContentObserver = MediaContentObserver(Handler(Looper.getMainLooper()), context)
            try {
                contentResolver.registerContentObserver(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaContentObserver!!
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                contentResolver.registerContentObserver(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaContentObserver!!
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun unregisterContentObserver(context: Context) {
            try {
                if (mediaContentObserver != null) {
                    val contentResolver = context.contentResolver
                    contentResolver.unregisterContentObserver(
                        mediaContentObserver!!
                    )
                    contentResolver.unregisterContentObserver(
                        mediaContentObserver!!
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun fetchNewMediaInsert(uri: Uri) {
        CoroutineScope(Dispatchers.IO).launch {
            Log.d("MediaContentObserver", "fetchNewMediaInsert start")
            val app = context.applicationContext as GalleryApp
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATA,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.BUCKET_ID,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.SIZE
            )
            val selection = getSelectionQueryImages()
            val selectionArgs = getSelectionArgsQueryImages().toTypedArray()

            val mCursor = context.contentResolver!!.query(
                uri,  // Uri
                projection,  // Projection
                selection, selectionArgs, MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            mCursor?.use {
                val idIndex = mCursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val pathIndex = mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                val titleIndex = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val bucketNameIndex = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
                val bucketIdIndex = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_ID)
                val dateModifiedIndex = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                val fileSizeLengthIndex = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val dateTakenIndex = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
                while (mCursor.moveToNext()) {
                    val path = mCursor.getString(pathIndex)
//                    val file = File(path)
//                    if (!file.exists()) {
//                        continue
//                    }
                    val mediaId = mCursor.getLong(idIndex)
                    val title = mCursor.getString(titleIndex)
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    val bPath = bucketPath
                    var bucketName = mCursor.getString(bucketNameIndex)
                    if (bucketName == null) {
                        bucketName = File(bucketPath).name
                    }
                    val bId = mCursor.getString(bucketIdIndex)
                    val dateModified = mCursor.getLong(dateModifiedIndex) * 1000
                    val fileSizeLength = mCursor.getLong(fileSizeLengthIndex)
                    var dTaken = mCursor.getLong(dateTakenIndex)
                    if (dTaken == 0L) dTaken = dateModified
                    Log.d("MediaContentObserver", "fetchNewMediaInsert fetch $path")

//                    if (!excludeAlbumPath.contains(bPath)) {
//                        AllMediaBoxOperations.deleteForever(app, path)
//                        val model = ObjectMediaModel(
//                            filePath = path,
//                            fileName = title,
//                            folderName = bucketName,
//                            bucketPath = bPath,
//                            dateModified = dateModified,
//                            dateTaken = dTaken,
//                            fileSize = fileSizeLength,
//                            mediaType = if (path.endsWith(".gif")) FileType.Gif.id else FileType.Image.id
//                        )
//                        AllMediaBoxOperations.insertUpdateMedia(app, model)
                    sendEvent("refresh")
                    Log.d("MediaContentObserver", "fetchNewMediaInsert REFRESH_MEDIA")
//                    }
                }
            }
        }
    }

    private fun getSelectionQueryImages(): String {
        val query = StringBuilder()
        photoExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

        rawExtensions.forEach {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

        /* videoExtensions.forEach {
             query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
         }*/
        query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQueryImages(): ArrayList<String> {
        val args = ArrayList<String>()
        photoExtensions.forEach {
            args.add("%$it")
        }
        args.add("%.jpg")
        args.add("%.jpeg")
        args.add("%.png")
        rawExtensions.forEach {
            args.add("%$it")
        }
        args.add("%.svg")/*  videoExtensions.forEach {
              args.add("%$it")
          }*/
        args.add("%.gif")
        return args
    }

    private fun isScreenshotUri(context: Context, uri: Uri): Boolean {
        try {
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.DISPLAY_NAME,
            )

            val cursor = context.contentResolver.query(
                uri,
                projection,
                null,
                null,
                null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val pathIndex = it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                    val titleIndex = it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    val title = it.getString(titleIndex)
                    val path = it.getString(pathIndex)
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    Log.d("MediaContentObserver", "Change detected at URI: 4 $bucketPath")
//                Log.d("MediaContentObserver", "Change detected at URI: 5 $screenshotsPath")
                    if (
                        bucketPath.lowercase(Locale.getDefault()).contains("screenshots")
                        || bucketPath.lowercase(Locale.getDefault()).contains("camera")
                        || bucketPath.lowercase(Locale.getDefault()).contains("whatsapp")
                    ) {
                        return true
                    }
                }
            }
        } catch (e: IllegalStateException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }
}
