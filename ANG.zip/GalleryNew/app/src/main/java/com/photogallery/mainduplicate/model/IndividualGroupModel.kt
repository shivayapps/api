package com.photogallery.mainduplicate.model

class IndividualGroupModel {
    var isCheckBox = false
    var groupExtension: String? = null
    var groupTag = 0
    var individualGrpOfDupes: List<ItemDuplicateModel>? = null
}