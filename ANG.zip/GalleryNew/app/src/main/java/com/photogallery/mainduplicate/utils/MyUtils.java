package com.photogallery.mainduplicate.utils;

import static android.content.Context.INPUT_METHOD_SERVICE;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.core.os.EnvironmentCompat;


import com.photogallery.mainduplicate.GlobalVarsAndFunctions;
import com.photogallery.mainduplicate.GlobalVarsAndFunctions;

import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


public class MyUtils {

    public static String TAG = "Utils_Duplicate";

    public static String mNewFilePath;
    public static String mHiddenCopyImagePath;
    public static final String[] ImageExtension = {"2bp", "360", "abm", "accountpicture-ms", "acorn", "afx", "agif", "agp", "apd", "apng", "apx", "art", "asw", "avatar", "awd", "blkrt", "bm2", "bmc", "bmp", "bss", "can", "cd5", "cdg", "cin", "cit", "colz", "cpc", "cpg", "cps", "cpt", "csf", "dcm", "dds", "dib", "djvu", "dm3", "dmi", "dpx", "dt2", "dtw", "dvl", "ecw", "epp", "exr", "fits", "fpos", "fpx", "gbr", "gcdp", "gif", "gih", "gim", "hdp", "hdr", "hdrp", "hpi", "i3d", "info", "ipx", "itc2", "ithmb", "iwi", "j2c", "jb2", "jbig2", "jbr", "jia", "jng", "jp2", "jpc", "jpeg", "jpg", "jps", "jpx", "jxr", "kdi", "lif", "mat", "max", "mbm", "mix", "mng", "mnr", "mpf", "mpo", "mrxs", "msp", "mxi", "myl", "ncd", "oc3", "oc4", "oc5", "oci", "omf", "ota", "pat", "pbm", "pcd", "pcx", "pdd", "pdn", "pe4", "pgf", "pgm", "pi2", "pic", "picnc", "pict", "pictclipping", "pixadex", "pmg", "png", "pnm", "pns", "pov", "ppf", "ppm", "prw", "psb", "psd", "psdx", "pse", "psf", "psp", "pspbrush", "pspimage", "ptg", "ptx", "pvr", "px", "pxd", "pxm", "pxr", "pzp", "qmg", "qti", "qtif", "ras", "rif", "rle", "rli", "rpf", "s2mv", "sct", "sdr", "sid", "sig", "skitch", "skm", "spa", "spe", "sph", "spj", "spp", "spr", "sup", "tbn", "tex", "tg4", "tga", "thm", "thumb", "tif", "tiff", "tjp", "tn", "tpf", "tps", "vss", "wb1", "wbc", "wbd", "wbmp", "wbz", "webp", "xcf", "xpm", "yuv", "zif"};


    public static String replaceName(String str) {
        return str.replace("_slash_", "/").replace("_dash_", "-").replace("_coma_", ",").replace("_esh_", ".");
    }


    public static void hideKeyboard(Context context, View target) {
        if (context == null || target == null) {
            return;
        }
        Log.e("hideKeyboard", "hideKeyboard: ");
        InputMethodManager imm = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
        target.clearFocus();
        imm.hideSoftInputFromWindow(target.getWindowToken(), 0);
    }

    public static void logError(String str) {
        Log.e(TAG, str);
    }

    public static void showToastMsg(Context context, String str) {
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }

    public static boolean isSelectedStorageAccessFrameWorkPathIsProper(Context context, String pathName) {
        String sdCardPath = getSDCardPath(context);
        Log.e("isSelectedStIsProper", "---saf-df----" + pathName);
        if (sdCardPath == null) {
            return false;
        }
        String[] splitSDCArdPath = sdCardPath.split("\\/");
        return pathName.equals(splitSDCArdPath[splitSDCArdPath.length - 1]);
    }

    public static String getSDCardPath(Context context) {
        File file1 = new File(GlobalVarsAndFunctions.SDCARD_1);
        File file2 = new File(GlobalVarsAndFunctions.SDCARD_2);
        File file3 = new File(GlobalVarsAndFunctions.SDCARD_3);
        File file4 = new File(GlobalVarsAndFunctions.SDCARD_4);
        File file5 = new File(GlobalVarsAndFunctions.SDCARD_5);
        File file6 = new File(GlobalVarsAndFunctions.SDCARD_6);
        if (file1.exists()) {
            return String.valueOf(file1);
        }
        if (file2.exists()) {
            return String.valueOf(file2);
        }
        if (file3.exists()) {
            return String.valueOf(file3);
        }
        if (file4.exists()) {
            return String.valueOf(file4);
        }
        if (file5.exists()) {
            return String.valueOf(file5);
        }
        if (file6.exists()) {
            return String.valueOf(file6);
        }
        return getSD_CardPath_M(context);
    }

    public static String getSD_CardPath_M(Context context) {
        String[] externalStoragePath = getExternalStorageDirectories(context);
        if (externalStoragePath.length == 0) {
            return null;
        }
        return externalStoragePath[0] + "/";
    }

    public static String[] getExternalStorageDirectories(Context context) {
        int i;
        List<String> results = new ArrayList<>();
        if (VERSION.SDK_INT >= 19) {
            try {
                for (File file : context.getExternalFilesDirs(null)) {
                    boolean addPath;
                    String path = file.getPath().split("/Android")[0];
                    if (VERSION.SDK_INT >= 21) {
                        addPath = Environment.isExternalStorageRemovable(file);
                    } else {
                        addPath = "mounted".equals(EnvironmentCompat.getStorageState(file));
                    }
                    if (addPath) {
                        results.add(path);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "getExternalStorageDirectories: " + e.getMessage());
            }
        }
        if (results.isEmpty()) {
            String output = "";
            try {
                Process process = new ProcessBuilder().command("mount | grep /dev/block/vold").redirectErrorStream(true).start();
                process.waitFor();
                InputStream is = process.getInputStream();
                byte[] buffer = new byte[1024];
                while (is.read(buffer) != -1) {
                    output = output + new String(buffer);
                }
                is.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
            if (!output.trim().isEmpty()) {
                for (String voldPoint : output.split(IOUtils.LINE_SEPARATOR_UNIX)) {
                    results.add(voldPoint.split(" ")[2]);
                }
            }
        }
        int i2;
        if (VERSION.SDK_INT >= 23) {
            i = 0;
            while (i < results.size()) {
                if (!((String) results.get(i)).toLowerCase().matches(".*[0-9a-f]{4}[-][0-9a-f]{4}")) {
                    Log.d(TAG, ((String) results.get(i)) + " might not be extSDcard");
                    i2 = i - 1;
                    results.remove(i);
                    i = i2;
                }
                i++;
            }
        } else {
            i = 0;
            while (i < results.size()) {
                if (!(((String) results.get(i)).toLowerCase().contains("ext") || ((String) results.get(i)).toLowerCase().contains("sdcard"))) {
                    Log.d(TAG, ((String) results.get(i)) + " might not be extSDcard");
                    i2 = i - 1;
                    results.remove(i);
                    i = i2;
                }
                i++;
            }
        }
        String[] storageDirectories = new String[results.size()];
        for (i = 0; i < results.size(); i++) {
            storageDirectories[i] = (String) results.get(i);
        }
        return storageDirectories;
    }

}
