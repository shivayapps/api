package com.photogallery.extension

import android.Manifest
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getSystemService
import com.photogallery.BuildConfig
import com.photogallery.R
import com.photogallery.activities.HomeActivity

fun Context.showHomeNotification() {

    if (ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    ) {
        if (!BuildConfig.DEBUG) {
            val notificationManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getSystemService(NotificationManager::class.java) as NotificationManager
            } else {
                notificationManager
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "MessageHomeNotification",
                    "Channel Name",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Channel Description"
                }
                notificationManager.createNotificationChannel(channel)
            }


            val remoteViews = RemoteViews(packageName, R.layout.custom_notification_big)

            val homeIntent = Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val homePendingIntent = PendingIntent.getActivity(
                this, 1,
                homeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Set PendingIntents on buttons
            remoteViews.setOnClickPendingIntent(R.id.homeButton, homePendingIntent)
            remoteViews.setOnClickPendingIntent(R.id.favoriteButton, homePendingIntent)
            remoteViews.setOnClickPendingIntent(R.id.travelButton, homePendingIntent)
            remoteViews.setOnClickPendingIntent(R.id.noteButton, homePendingIntent)

            val notification = NotificationCompat.Builder(this, "MessageHomeNotification")
                .setSmallIcon(R.drawable.ic_notification_logo)
                .setCustomBigContentView(remoteViews)
                .setCustomContentView(remoteViews)
                .setStyle(NotificationCompat.DecoratedCustomViewStyle())
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true)
                .setDefaults(Notification.DEFAULT_LIGHTS)
                .setCategory(Notification.CATEGORY_EVENT)
                .setOngoing(true)
                .build()

            notificationManager.notify(4488, notification)
        }

    }
}

fun isAppInBackground(context: Context): Boolean {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val appProcesses = activityManager.runningAppProcesses ?: return true

    for (process in appProcesses) {
        if (process.processName == context.packageName) {
            return process.importance != ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
        }
    }
    return true
}