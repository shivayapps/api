package com.photogallery.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.databinding.ItemMultiImageBinding
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences


class MultiImageAdapter(
    var context: Context,
    val albumList: LinkedHashMap<String, ArrayList<AlbumData>>,
    val clickListener: (albumList: String, ArrayList<AlbumData>) -> Unit
//    val clickListener: (albumList: ArrayList<AlbumData>) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var preferences: Preferences = Preferences(context)
    var albumKeys: ArrayList<String> = ArrayList()

    init {
        val folderKeys: Set<String> = albumList.keys
        albumKeys.clear()
        albumKeys.addAll(folderKeys)
    }
//    val albumKeys: Set<String> = albumList.keys

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemMultiImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlbumGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        Log.e("MultiImageAdapter", "albumList::${albumList.size}")
        val folderKeys: Set<String> = albumList.keys
        if(albumKeys.size!=albumList.size) {
            albumKeys.clear()
            albumKeys.addAll(folderKeys)
        }

        Log.e("MultiImageAdapter", "albumKeys::${albumKeys.size}, ${albumKeys}")

        val albumGridViewHolder = holder as AlbumGridViewHolder
//        val albumData: ArrayList<AlbumData> = albumList[position] as AlbumData
//        val albumData: ArrayList<AlbumData> = albumList[albumKeys[position]] as ArrayList<AlbumData>
        val key=albumKeys[position]
        val albumData = albumList[key] as ArrayList<AlbumData>
//        val pictureData=albumData[0].pictureData

        albumGridViewHolder.binding.txtTitle.text = albumKeys[position]
        if (albumData.isNotEmpty()) {
            albumGridViewHolder.binding.txtCount.text = "${albumData.size}"

//            val pictureData=pictureData
            if(albumData.size>0) {
                Glide.with(context.applicationContext)
                    .load(albumData[0].mediaData[0].filePath)
                    .into(albumGridViewHolder.binding.image1)
            }

            if(albumData.size>1) {
                Glide.with(context.applicationContext)
                    .load(albumData[1].mediaData[0].filePath)
                    .into(albumGridViewHolder.binding.image2)
            }

            if(albumData.size>2) {
                Glide.with(context.applicationContext)
                    .load(albumData[2].mediaData[0].filePath)
                    .into(albumGridViewHolder.binding.image3)
            }
            if(albumData.size>3) {
                Glide.with(context.applicationContext)
                    .load(albumData[3].mediaData[0].filePath)
                    .into(albumGridViewHolder.binding.image4)
            }


        }
        else {
            albumGridViewHolder.binding.txtCount.text = "0"

//            albumGridViewHolder.binding.image1.setImageDrawable(
//                ContextCompat.getDrawable(
//                    context,
//                    R.drawable.ic_image_placeholder
//                )
//            )
        }

        albumGridViewHolder.binding.root.setOnClickListener {
            clickListener(key,albumData)
        }

    }

    override fun getItemCount(): Int {
        return albumList.size
    }

    class AlbumGridViewHolder(var binding: ItemMultiImageBinding) :
        RecyclerView.ViewHolder(binding.root)



}