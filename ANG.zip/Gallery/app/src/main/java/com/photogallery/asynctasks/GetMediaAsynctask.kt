package com.photogallery.asynctasks

import android.content.Context
import android.os.AsyncTask
import com.photogallery.helper.MediaFetcher
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.SHOW_ALL


class GetMediaAsynctask(
    val context: Context,
    val mPath: String,
    val isPickImage: Boolean = false,
    val isPickVideo: Boolean = false,
    val showAll: Boolean,
    val callback: (media: ArrayList<MediaData>) -> Unit
) :
    AsyncTask<Void, Void, ArrayList<MediaData>>() {
    private val mediaFetcher = MediaFetcher(context)
    val config = Preferences(context)

    override fun doInBackground(vararg params: Void): ArrayList<MediaData> {

        val pathToUse = if (showAll) SHOW_ALL else mPath
        val folderGrouping = config.getGroupBy()
        val folderSorting = config.getSortType()
        val getProperDateTaken = folderSorting and Constant.SORT_DATE_TAKEN != 0 ||
                folderGrouping and Constant.GROUP_BY_DATE_TAKEN_DAILY != 0 ||
                folderGrouping and Constant.GROUP_BY_DATE_TAKEN_MONTHLY != 0

        val getProperLastModified = folderSorting and Constant.SORT_DATE_TAKEN != 0 ||
                folderGrouping and Constant.GROUP_BY_LAST_MODIFIED_DAILY != 0 ||
                folderGrouping and Constant.GROUP_BY_LAST_MODIFIED_MONTHLY != 0

        val getProperFileSize = folderSorting and Constant.SORT_SIZE != 0
        val favoritePaths = config.getFavoriteList()
//        val getVideoDurations = context.config.showThumbnailVideoDuration
        val getVideoDurations = false
        val lastModifieds =
            if (getProperLastModified) mediaFetcher.getLastModifieds()
            else HashMap()

        val dateTakens =
            if (getProperDateTaken) mediaFetcher.getDateTakens()
            else HashMap()

        val media =
            if (showAll) {
//            val foldersToScan = mediaFetcher.getFoldersToScan().filter { it != RECYCLE_BIN && it != FAVORITES && !context.config.isFolderProtected(it) }
//                val foldersToScan = mediaFetcher.getFoldersToScan().filter { !config.isFolderProtected(it) }
                val foldersToScan = mediaFetcher.getFoldersToScan()
                val media = ArrayList<MediaData>()
                foldersToScan.forEach {
                    val newMedia = mediaFetcher.getFilesFrom(
                        it,
                        isPickImage,
                        isPickVideo,
                        getProperDateTaken,
                        getProperLastModified,
                        getProperFileSize,
                        favoritePaths,
                        getVideoDurations,
                        lastModifieds,
                        dateTakens.clone() as HashMap<String, Long>,
                        null
                    )
                    media.addAll(newMedia)
                }

                mediaFetcher.sortMedia(media, config.getSortType())
                media
            } else {
                mediaFetcher.getFilesFrom(
                    mPath,
                    isPickImage,
                    isPickVideo,
                    getProperDateTaken,
                    getProperLastModified,
                    getProperFileSize,
                    favoritePaths,
                    getVideoDurations,
                    lastModifieds,
                    dateTakens,
                    null
                )
            }

//        return mediaFetcher.groupMedia(media, pathToUse)
        return media
    }

    override fun onPostExecute(media: ArrayList<MediaData>) {
        super.onPostExecute(media)
        callback(media)
    }

    fun stopFetching() {
        mediaFetcher.shouldStop = true
        cancel(true)
    }
}
