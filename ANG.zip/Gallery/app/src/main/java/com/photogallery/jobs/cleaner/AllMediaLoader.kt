package com.photogallery.jobs.cleaner

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.photogallery.GalleryApp
import com.photogallery.R
import com.photogallery.extension.getFilenameExtension
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.isApng
import com.photogallery.extension.isGif
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isPng
import com.photogallery.extension.isPortrait
import com.photogallery.extension.isSvg
import com.photogallery.extension.isVideoFast
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.audioExtensions
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import com.photogallery.utils.documentExtensions
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AllMediaLoader(
    private val mContext: Context,
) {

    private var TAG = "AllMediaLoader"
    private var ROOT_PATH = ""
    private var mJob: Job = Job()

    val projectionImage = arrayOf(
        MediaStore.Images.Media.DATA,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
    )
    val projectionVideo = arrayOf(
        MediaStore.Video.VideoColumns.DATA,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.VideoColumns.SIZE,
        MediaStore.Video.VideoColumns.DURATION,
        MediaStore.Video.VideoColumns.DATE_MODIFIED,
        MediaStore.Video.VideoColumns.DATE_TAKEN,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
    )

    suspend fun getAllImageData(
        onSuccess: ((mediaList: ArrayList<MediaData>) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {

        mJob = CoroutineScope(Dispatchers.IO).launch {
            try {
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
                val allMedia: ArrayList<MediaData> = ArrayList()
                allMedia.clear()

                ROOT_PATH = Constant.ROOT_PATH
                Log.e(TAG, "ROOT_PATH:${ROOT_PATH}")

                allMedia.addAll(getImages())

//                applyMediaSorting(allMedia) { media ->
//                    sortedMedia.addAll(media)
//                }

                withContext(Dispatchers.Main) {
                    Log.e(TAG, "onSuccess?.invoke")
                    onSuccess?.invoke(allMedia)
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }

    suspend fun getAllVideoData(
        onSuccess: ((mediaList: ArrayList<MediaData>) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {

        mJob = CoroutineScope(Dispatchers.IO).launch {
            try {
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
                val allMedia: ArrayList<MediaData> = ArrayList()
                allMedia.clear()

                ROOT_PATH = Constant.ROOT_PATH
                Log.e(TAG, "ROOT_PATH:${ROOT_PATH}")

                allMedia.addAll(getVideos())

//                applyMediaSorting(allMedia) { media ->
//                    sortedMedia.addAll(media)
//                }

                withContext(Dispatchers.Main) {
                    Log.e(TAG, "onSuccess?.invoke")
                    onSuccess?.invoke(allMedia)
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }
    suspend fun getAllDocumentData(
        onSuccess: ((mediaList: ArrayList<MediaData>) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {

        mJob = CoroutineScope(Dispatchers.IO).launch {
            try {
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
                val allMedia: ArrayList<MediaData> = ArrayList()
                allMedia.clear()

                ROOT_PATH = Constant.ROOT_PATH
                Log.e(TAG, "ROOT_PATH:${ROOT_PATH}")

                allMedia.addAll(getDocument())

//                applyMediaSorting(allMedia) { media ->
//                    sortedMedia.addAll(media)
//                }

                withContext(Dispatchers.Main) {
                    Log.e(TAG, "onSuccess?.invoke")
                    onSuccess?.invoke(allMedia)
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }

    suspend fun getAllAudioData(
        onSuccess: ((mediaList: ArrayList<MediaData>) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {

        mJob = CoroutineScope(Dispatchers.IO).launch {
            try {
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
                val allMedia: ArrayList<MediaData> = ArrayList()
                allMedia.clear()

                ROOT_PATH = Constant.ROOT_PATH
                Log.e(TAG+"_Audio", "ROOT_PATH:${ROOT_PATH}")

                allMedia.addAll(getAudio())

//                applyMediaSorting(allMedia) { media ->
//                    sortedMedia.addAll(media)
//                }

                withContext(Dispatchers.Main) {
                    Log.e(TAG+"_Audio", "onSuccess?.invoke")
                    onSuccess?.invoke(allMedia)
                }

            } catch (e: Exception) {
                Log.e(TAG+"_Audio", "Exception:$e")
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }
    fun getAllData(
        onSuccess: ((mediaList: ArrayList<MediaData>) -> Unit)? = null,
        onFailed: ((error: String) -> Unit)? = null,
    ) {

        mJob = CoroutineScope(Dispatchers.IO).launch {
            try {
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
                val allMedia: ArrayList<MediaData> = ArrayList()
                allMedia.clear()

                ROOT_PATH = Constant.ROOT_PATH
                Log.e(TAG, "ROOT_PATH:${ROOT_PATH}")

                allMedia.addAll(getImages())
                allMedia.addAll(getVideos())

//                applyMediaSorting(allMedia) { media ->
//                    sortedMedia.addAll(media)
//                }

                withContext(Dispatchers.Main) {
                    Log.e(TAG, "onSuccess?.invoke")
                    onSuccess?.invoke(allMedia)
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
                }
            }
        }
    }

    private fun getImages(folderPath: String = ""): ArrayList<MediaData> {
        Log.e(TAG, "getImages >>>>")
        val mediaList = ArrayList<MediaData>()
        try {
            val uri: Uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            val cursor = mContext.contentResolver.query(
                uri, projectionImage, getSelectionQuery(TYPE_IMAGES),
                getSelectionArgsQuery(TYPE_IMAGES).toTypedArray(),
                MediaStore.Images.Media.DATE_MODIFIED + " DESC"
            )

            cursor?.use {
                while (it.moveToNext()) {

                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var bucketName = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)) ?: path.getParentFolder()
                    if (bucketPath == ROOT_PATH) bucketName = "Root"

                    val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)).takeIf { size -> size > 0 } ?: File(path).length()
                    val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)) * 1000
                    val dateTaken = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000

                    if (folderPath.isNotEmpty()) {
                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
                            if (fileSize > 0) {
                                val mediaData = MediaData(
                                    filePath = path, fileName = title, folderName = bucketName, date = date,
                                    bucketPath = bucketPath, dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize
                                )

                                mediaList.add(mediaData)
                            }
                        }
                    } else {
                        if (fileSize > 0) {
                            val mediaData = MediaData(
                                filePath = path, fileName = title, folderName = bucketName, date = date,
                                bucketPath = bucketPath, dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize
                            )

                            mediaList.add(mediaData)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getImages Exception:$e")
        }
        Log.e(TAG, "getImages <<<<")
        return mediaList
    }

    private fun getVideos(folderPath: String = ""): ArrayList<MediaData> {
        Log.e(TAG, "getVideos >>>>")
        val mediaList = ArrayList<MediaData>()
        try {
            val uri: Uri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

            val cursor = mContext.contentResolver.query(
                uri, projectionVideo, getSelectionQuery(TYPE_VIDEOS),
                getSelectionArgsQuery(TYPE_VIDEOS).toTypedArray(),
                MediaStore.Video.Media.DATE_MODIFIED + " DESC"
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    val title = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                    var bucketName = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)) ?: path.getParentFolder()
                    if (bucketPath == ROOT_PATH) bucketName = "Root"

                    val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)).takeIf { size -> size > 0 } ?: File(path).length()
                    val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED)) * 1000
                    val dateTaken = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000
                    val duration = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION))

                    if (folderPath.isNotEmpty()) {
                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
                            if (fileSize > 0) {
                                val mediaData = MediaData(
                                    filePath = path, fileName = title, folderName = bucketName, date = date,
                                    dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize,
                                    bucketPath = bucketPath, isVideo = true, videoDuration = duration
                                )

                                mediaList.add(mediaData)
                            }
                        }
                    } else {
                        if (fileSize > 0) {
                            val mediaData = MediaData(
                                filePath = path, fileName = title, folderName = bucketName, date = date,
                                dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize,
                                bucketPath = bucketPath, isVideo = true, videoDuration = duration
                            )

                            mediaList.add(mediaData)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getVideos Exception:$e")
        }
        Log.e(TAG, "getVideos <<<<")
        return mediaList
    }

    private fun getDocument(folderPath: String = ""): ArrayList<MediaData> {
        val mediaList = ArrayList<MediaData>()

        val uri: Uri = MediaStore.Files.getContentUri("external")

        val projection = arrayOf(
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )

        val selection = buildString {
            append("(")
            documentExtensions.forEachIndexed { index, ext ->
                append("${MediaStore.Files.FileColumns.DATA} LIKE ?")
                if (index != documentExtensions.size - 1) append(" OR ")
            }
            append(")")
        }

        val selectionArgs = documentExtensions.map { "%$it" }.toTypedArray()

        val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"

        try {
            val cursor = mContext.contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
            cursor?.use {
                while (it.moveToNext()) {
                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA))
                    val title = it.getString(it.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME))
                    val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)).takeIf { size -> size > 0 } ?: File(path).length()
                    val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)) * 1000

                    val bucketPath = path.substringBeforeLast("/")
                    val bucketName = bucketPath.getFilenameFromPath()

                    if (folderPath.isNotEmpty()) {
                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
                            if (fileSize > 0) {
                                mediaList.add(
                                    MediaData(
                                        filePath = path,
                                        fileName = title,
                                        folderName = bucketName,
                                        date = date,
                                        bucketPath = bucketPath,
                                        dateTaken = date,
                                        fileSize = fileSize
                                    )
                                )
                            }
                        }
                    } else {
                        if (fileSize > 0 && File(path).exists()) {
                            mediaList.add(
                                MediaData(
                                    filePath = path,
                                    fileName = title,
                                    folderName = bucketName,
                                    date = date,
                                    bucketPath = bucketPath,
                                    dateTaken = date,
                                    fileSize = fileSize
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getDocument Exception: $e")
        }

        return mediaList
    }

    private fun getAudio(folderPath: String = ""): ArrayList<MediaData> {
        Log.e(TAG+"_Audio", "getAudio")
        val mediaList = ArrayList<MediaData>()

        val uri: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_MODIFIED
        )

        val selection = buildString {
            append("(")
            audioExtensions.forEachIndexed { index, ext ->
                append("${MediaStore.Files.FileColumns.DATA} LIKE ?")
                if (index != audioExtensions.size - 1) append(" OR ")
            }
            append(")")
        }

        val selectionArgs = audioExtensions.map { "%$it" }.toTypedArray()

        val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"

        try {
            val cursor = mContext.contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA))
                    val title = it.getString(it.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME))
                    val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)).takeIf { size -> size > 0 }
                        ?: File(path).length()
                    val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)) * 1000

                    val bucketPath = path.substringBeforeLast("/")
                    val bucketName = bucketPath.getFilenameFromPath()

                    if (folderPath.isNotEmpty()) {
                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
                            if (fileSize > 0) {
                                mediaList.add(
                                    MediaData(
                                        filePath = path,
                                        fileName = title,
                                        folderName = bucketName,
                                        date = date,
                                        bucketPath = bucketPath,
                                        dateTaken = date,
                                        fileSize = fileSize
                                    )
                                )
                            }
                        }
                    } else {
                        if (fileSize > 0 && File(path).exists()) {
                            mediaList.add(
                                MediaData(
                                    filePath = path,
                                    fileName = title,
                                    folderName = bucketName,
                                    date = date,
                                    bucketPath = bucketPath,
                                    dateTaken = date,
                                    fileSize = fileSize
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG+"_Audio", "getAudio Exception: $e")
        }

        return mediaList
    }

    fun getAllHiddenFiles(
        rootDir: File = File(Environment.getExternalStorageDirectory().absolutePath),
        onResult: (List<MediaData>) -> Unit,
        onError: ((Throwable) -> Unit)? = null
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val hiddenFiles = ArrayList<MediaData>()
                scanHiddenFilesRecursively(rootDir, hiddenFiles)

                withContext(Dispatchers.Main) {
                    onResult(hiddenFiles)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onError?.invoke(e)
                }
            }
        }
    }


    private fun scanHiddenFilesRecursively(dir: File, hiddenList: MutableList<MediaData>) {
        if (!dir.exists() || !dir.canRead()) return

        dir.listFiles()?.forEach { file ->
            if (file.name.startsWith(".") || file.parentFile?.name?.startsWith(".") == true) {
                if (file.isFile && file.length() > 0) {
                    hiddenList.add(
                        MediaData(
                            filePath = file.absolutePath,
                            fileName = file.name,
                            folderName = file.parentFile?.name ?: "",
                            date = file.lastModified(),
                            bucketPath = file.parent ?: "",
                            dateTaken = file.lastModified(),
                            fileSize = file.length()
                        )
                    )
                }
            }

            if (file.isDirectory) {
                scanHiddenFilesRecursively(file, hiddenList)
            }
        }
    }


    fun applyMediaSorting(
        mediaList: MutableList<MediaData>,
        onSortingComplete: (List<MediaData>) -> Unit
    ) {
        Log.e(TAG, "applyMediaSorting >>>>")
        try {
            val comparator = compareBy<MediaData> { it.date }
            val sortedList = mediaList.sortedWith(comparator)


            onSortingComplete(sortedList)
        } catch (e: Exception) {
            Log.e(TAG, "applyMediaSorting Exception:$e")
            onSortingComplete(mediaList)
        }

        Log.e(TAG, "applyMediaSorting <<<<")
    }



    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }
        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }

        return args
    }

    fun destroyLoader() {
        mJob.cancel()
    }

}
