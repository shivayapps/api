package com.photogallery.filepicker

import android.app.Activity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.photogallery.adapter.DirsAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityFilePickerBinding
import com.photogallery.utils.Preferences


class FilePickerActivity : BaseActivity() {

    lateinit var preferences: Preferences
    lateinit var adapter: DirsAdapter

    lateinit var binding: ActivityFilePickerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilePickerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initView()
    }

    private fun initView() {
        preferences = Preferences(this)

        getData()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }

        intListener()
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
//            onBackPressedDispatcher.onBackPressed()
        }

    }

    override fun onBackPressed() {
//        super.onBackPressed()
//        onBackPressedDispatcher.onBackPressed()
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun getData() {



    }

}