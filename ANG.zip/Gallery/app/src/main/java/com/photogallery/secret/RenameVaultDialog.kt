package com.photogallery.secret

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import androidx.core.content.ContextCompat
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogRenameBinding
import com.photogallery.event.RenameEvent
import com.photogallery.extension.toast
import com.photogallery.utils.Preferences
import org.greenrobot.eventbus.EventBus
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class RenameVaultDialog(
    var mContext: Activity,
    var album: String,
    val positiveBtnClickListener: (newFolder: String, oldFolder: String) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogRenameBinding
    var preferences: Preferences = Preferences(mContext)

    //    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogRenameBinding.inflate(layoutInflater, container, false)
//        bindingDialog.root.backgroundTintList= ColorStateList.valueOf(Color.parseColor("#1F1F1F"))
//        intView()
//        intListener()
//        return bindingDialog.root
//    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogRenameBinding.inflate(layoutInflater)
//        bindingDialog.root.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1F1F1F"))
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }


    private fun intView() {

        bindingDialog.edtName.setText(album)
        bindingDialog.edtName.requestFocus()

        bindingDialog.clMain.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1F1F1F"))
        bindingDialog.edtName.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#222222"))
        bindingDialog.btnCancel.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#383838"))
        bindingDialog.btnRename.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
        bindingDialog.icClear.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
        bindingDialog.edtName.setTextColor(Color.parseColor("#FFFFFF"))
        bindingDialog.tvTitle.setTextColor(Color.parseColor("#FFFFFF"))
        bindingDialog.btnCancel.setTextColor(Color.parseColor("#FFFFFF"))
        bindingDialog.btnRename.setTextColor(Color.parseColor("#1F1F1F"))

    }

    private fun intListener() {
        bindingDialog.edtName.addTextChangedListener {
            bindingDialog.icClear.visibility = if (bindingDialog.edtName.text?.trim().toString()
                    .isNotEmpty()
            ) View.VISIBLE else View.GONE
        }
        bindingDialog.icClear.setOnClickListener {
            bindingDialog.edtName.setText("")
        }
        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnRename.setOnClickListener {

            val strNewFileName = bindingDialog.edtName.text.toString().trim()
            if (strNewFileName.isNotEmpty()) {
                positiveBtnClickListener(album, strNewFileName)
                dismiss()
            } else
                mContext.toast(mContext.getString(R.string.rename_validation))
        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }

    private fun setRename(oldPath: String, renamePath: String) {
//        EventBus.getDefault().post(RenameEvent(oldPath, renamePath))
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }

    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

