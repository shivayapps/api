package com.photogallery.activities

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.photogallery.BuildConfig
import com.photogallery.R
import com.photogallery.adapter.FavouriteAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.PopBottomMenuBinding
import com.photogallery.dialog.ConfirmationDialog
import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.event.CopyMoveEvent
import com.photogallery.event.DeleteEvent
import com.photogallery.event.DisplayDeleteEvent
import com.photogallery.event.RenameEvent
import com.photogallery.event.UpdateFavoriteEvent
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import com.photogallery.databinding.ActivityFavouriteListBinding
import com.photogallery.dialog.DetailsDialog
import com.photogallery.dialog.DisplayedColumnsDialog
import com.photogallery.dialog.FilterMediaDialog
import com.photogallery.dialog.GroupDialog
import com.photogallery.dialog.MainMenuDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.RenameDialog
import com.photogallery.dialog.ResizeDialog
import com.photogallery.dialog.SelectAlbumDialog
import com.photogallery.dialog.SelectAlbumFullDialog
import com.photogallery.dialog.SortDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.delayExecution
import com.photogallery.extension.getFinalUriFromPath
import com.photogallery.extension.getPreviousActivity
import com.photogallery.extension.getUriMimeType
import com.photogallery.extension.isGif
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.openPath
import com.photogallery.extension.showErrorToast
import com.photogallery.extension.toast
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.utils.AdCache
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.utils.sendEvent

import com.photogallery.viewpager.PhotoVideoActivity
import vi.imagestopdf.CreatePDFListener
import vi.imagestopdf.PDFEngine
import java.util.Locale

class FavouriteListActivity : BaseActivity() {

    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()
    var favoriteAdapter: FavouriteAdapter? = null
    lateinit var preferences: Preferences
    var mediaLoader: MediaLoaderX? = null
    var selectedItem = 0
    var isSelectAll = false

    lateinit var binding: ActivityFavouriteListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val adId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, adId)
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityFavouriteListBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        EventBus.getDefault().register(this)
        loadBanner()
        intView()

    }

    private fun intView() {
        binding.txtTitle.text = getString(R.string.Favorite)

        mediaLoader = MediaLoaderX(
            this,
            sortOrder = preferences.getSortOrder("favourite"),
            sortType = preferences.getSortType("favourite"),
            prefKey = "favourite"
        )
        mediaLoader?.refreshLoader("favourite")

        getData()
        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
        intListener()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {

        if (!isAdLoaded) {
            val adId = getString(R.string.b_favoriteListActivity)
            BannerAdHelper.showBanner(
                this, binding.layoutBanner.mFLAd, binding.llAdPlace, adId,
                AdCache.favoriteListAdView, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.favoriteListAdView = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }


    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }
//        binding.icImport.setOnClickListener {
//            val intent = Intent(this, SelectImageActivity::class.java)
//            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_FAVORITE)
//            selectImageActivityResultLauncher.launch(intent)
//        }
        binding.btnShare.setOnClickListener {
            shareImages()
        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
//            requestStoragePermission(app_delete_AFA_allow_nf, app_delete_AFA_denied_nf, getActivityName()) {
//                if (it) {
//                    showDeleteDialog()
//                }
//            }

        }
//        binding.btnUnFavorite.setOnClickListener {
//            setUnFavoriteData()
//        }
        binding.btnHide.setOnClickListener {
            setHideData()
//            requestStoragePermission(app_private_AFA_allow_nf, app_private_AFA_denied_nf, getActivityName()) {
//                if (it) {
//                    setHideData()
//                }
//            }
        }
        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }
        binding.icMenu.setOnClickListener {
            showMenu()
        }
    }

    var selectImageActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            binding.swipeRefreshLayout.isRefreshing = true

            val favList: ArrayList<String> = ArrayList()
            favList.addAll(preferences.getFavoriteList())

            val picture = Constant.selectedImageList
            for (i in picture.indices) {
//            if (pictures[i] != null)
                if (picture[i] is MediaData) {
                    val model: MediaData = picture[i] as MediaData
                    if (model.isSelected) {
//                        if (isFavorite) {
                        if (!favList.contains(model.filePath)) favList.add(model.filePath)
//                        } else {
                        //if (favList.contains(model.filePath)) favList.remove(model.filePath)
//                        }
                    }
                }
            }
            sendEvent("refresh")
            preferences.setFavoriteList(favList)
            delayExecution(1500, {
                getData()
            })
        }
    }

    private fun showMenu() {
        val dialog = MainMenuDialog(this, 0, clickListener = {
            when (it) {
                1 -> {//show sort
                    showSortDialog()
                }

                2 -> {//show group
                    showGroupByDialog()
                }

                3 -> {//show filter
                    val filterMediaDialog = FilterMediaDialog(this@FavouriteListActivity, updateListener = {
                        getData()
                    })
                    filterMediaDialog.show()
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        this, "",
                        false,
                        updateListener = {
                            setRvLayoutManager()
//                            photosFragment.setRvLayoutManager()
//                            albumFragment.setRvLayoutManager()
                        })
                    displayColumnsDialog.show()
                }

                21 -> {
                    setRvLayoutManager()
                    sendEvent("refresh_layoutmanager")
                }

                22 -> {
                    setRvLayoutManager()
                    setListGridData()
                    sendEvent("refresh_layoutmanager")
                }

                5 -> {
                    recycleLauncher.launch(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }
            }
        })
        dialog.show()

    }

    var recycleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

        }

    private fun showSortDialog() {
        val sortDialog = SortDialog(this, "favourite", updateListener = {
            getData()
//            photosFragment.setFilterData()
//            albumFragment.setFilterData()
        })
        sortDialog.show()
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog("favourite", updateListener = {
            getData()
//            photosFragment.setList()
//            albumFragment.setFilterData()
        })
        groupDialog.show(supportFragmentManager, groupDialog.tag)
    }

    private fun clearFav() {
        preferences.setFavoriteList(ArrayList())
        allList.clear()
        pictures.clear()
//        EventBus.getDefault().post(UpdateFavoriteEvent(unFavoriteList = favList, isFavorite = false))
        setData()
    }

    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        var needToAddFav = false
        var needToRemoveFav = false
        var isVideoSelected = false

        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    if (model.isVideo || model.filePath.isGif()) isVideoSelected = true

                    if (model.isFavorite)
                        needToRemoveFav = true
                    else
                        needToAddFav = true
                }
            }
        }

        popUpBinding.menuEdit.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuSetAs.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuResize.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuInfo.beVisibleIf(selectedItem == 1)
        popUpBinding.menuRename.beVisibleIf(selectedItem == 1)
        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)
        popUpBinding.menuCover.beGone()
        //popUpBinding.menuExclude.beGone()

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem == 1) {
                showRenameDialog()
            } //else showBatchRenameDialog()
        }
        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            setAs()
        }
        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            showResizeDialog()
        }
        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(true)
        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(false)
        }
        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
//            requestStoragePermission(app_edit_AFA_allow_nf, app_edit_AFA_denied_nf, getActivityName()) {
//                if (it) {
            openEditor()
//                }
//            }
        }
        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
//            showAddAlbumDialog(Constant.albumList, true)

            if (selectedItem == 0) {
                toast(getString(R.string.PleaseSelectAlbum))
            } else {

                val selectedAlbum = ArrayList<String>()
                val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                    .filter { it.isSelected } // Filter selected MediaData objects
                    .forEach { selectImage.add(it) } // Add to the set
                showAddAlbumDialog(
                    Constant.deviceAlbumList,
                    selectImage,
                    selectedAlbum,
                    true
                )
            }
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()

            if (selectedItem == 0) {
                toast(getString(R.string.PleaseSelectAlbum))
            } else {

                val selectedAlbum = ArrayList<String>()
                val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                    .filter { it.isSelected } // Filter selected MediaData objects
                    .forEach { selectImage.add(it) } // Add to the set
                showAddAlbumDialog(
                    Constant.deviceAlbumList,
                    selectImage,
                    selectedAlbum,
                    false
                )
            }
//            requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                if (it) {
//                    showAddAlbumDialog(Constant.deviceAlbumList, false)
//                }
//            }
        }
        popupWindow.showAsPopUp(view)
    }


    fun showDetailsDialog() {

        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val detailsDialog = DetailsDialog(this, pictureData, false)
        detailsDialog.show()
    }

    fun openEditor() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]
        val path: String = pictureData.filePath
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }

    fun setAs() {

        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        ensureBackgroundThread {
            val newUri =
                getFinalUriFromPath(pictureData.filePath, BuildConfig.APPLICATION_ID)
                    ?: return@ensureBackgroundThread
            Intent().apply {
                action = Intent.ACTION_ATTACH_DATA
                setDataAndType(newUri, getUriMimeType(pictureData.filePath, newUri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(this, getString(R.string.set_as))

                try {
                    startActivityForResult(chooser, 101)
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.no_app_found)
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
        }

    }

    fun showRenameDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        val pictureData = selectImage[0]
        val renameDialog =
            RenameDialog(
                this,
                pictureData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    notifyAdapter()
                })
        renameDialog.show()
    }

    fun showResizeDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val resizeDialog =
            ResizeDialog(
                this,
                pictureData,
                updateImageListener = { path ->
                    val file = File(path)
                    pictures.add(
                        0,
                        MediaData(
                            path,
                            file.name,
                            file.parentFile.path,
                            file.lastModified(),
                            file.lastModified(),
                            file.length()
                        )
                    )
                    setCloseToolbar()
                })
        resizeDialog.show()
    }

    fun setFavorite(isFavorite: Boolean) {

        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath))
                            favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath))
                            favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
        preferences.refreshMedia = true
        sendEvent("refresh")

        setCloseToolbar()
        getData()
    }

    private fun notifyAdapterRemove(pos: Int) {
//        if (imageListAdapter != null) {
//            imageListAdapter?.notifyItemRemoved(pos)
//        }
    }

    private fun notifyAdapter() {
        Log.e("FavoriteActivity", "notifyAdapter")
        if (favoriteAdapter != null) {
//            pictureAdapter?.notifyDataSetChanged()
            favoriteAdapter?.submitList(pictures)
            favoriteAdapter?.notifyItemRangeChanged(0, pictures.size)
        }
    }

    private fun setData() {
        Log.e("FavoriteActivity", "setData")
        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (favoriteAdapter != null) notifyAdapter() else initAdapter()
        Log.e("FavoriteActivity", "setEmptyData.001")
        setEmptyData()
    }

    private fun setEmptyData() {
        Log.e("FavoriteActivity", "pictures:${pictures.size}")
        if (pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
//            binding.icImport.visibility = View.GONE
            binding.layoutBottom.beVisible()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            //binding.icImport.visibility = View.VISIBLE
            binding.layoutBottom.beGone()
        }
    }

    private fun initAdapter() {
        Log.e("FavoriteActivity", "initAdapter")
        setRvLayoutManager()
        favoriteAdapter = FavouriteAdapter(
            this,
            clickListener = {
                try {
                    if (pictures[it] is MediaData) {
                        val mediaData = pictures[it] as MediaData
                        if (mediaData.isCheckboxVisible) {
                            mediaData.isSelected = !mediaData.isSelected
                            favoriteAdapter?.notifyItemChanged(it)
                            setSelectedFile()
                        } else {
                            val dataList = ArrayList<MediaData>()
                            var displayPos = 0
                            for (i in pictures.indices) {
                                if (pictures[i] is MediaData) {
                                    dataList.add(pictures[i] as MediaData)
                                    if (it == i) {
                                        displayPos = dataList.size - 1
                                    }
                                }
                            }
                            Constant.displayImageList = ArrayList()
                            Constant.displayImageList.addAll(dataList)
                            Constant.selectedPosition = displayPos
                            if (Constant.displayImageList.size > 0) {
                                val intent = Intent(this, PhotoVideoActivity::class.java)
                                intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                                startActivity(intent)
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            longClickListener = {
                try {
                    if (pictures[it] is MediaData) {
                        val mediaData = pictures[it] as MediaData
                        for (i in pictures.indices) {
                            if (pictures[i] != null)
                                if (pictures[i] is AlbumData) {
                                    val model = pictures[i] as AlbumData
                                    model.isCheckboxVisible = true
                                } else if (pictures[i] is MediaData) {
                                    val model = pictures[i] as MediaData
                                    model.isCheckboxVisible = true
                                }
                        }
                        mediaData.isCheckboxVisible = true
                        mediaData.isSelected = true
                        notifyAdapter()
                        setSelectedFile()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            headerSelectListener = {
                try {
                    if (pictures[it] is AlbumData) {
                        val albumData = pictures[it] as AlbumData
                        val isSelectAll = !albumData.isSelected
                        albumData.isSelected = isSelectAll
                        var pos = it + 1
                        while (pos < pictures.size) {
                            if (pictures[pos] is MediaData) {
                                val model = pictures[pos] as MediaData
                                model.isSelected = isSelectAll
                                pos++
                            } else if (pictures[pos] is AlbumData) {
                                break
                            }
                        }
                        notifyAdapter()
                        setSelectedFile()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            })
        favoriteAdapter?.submitList(pictures)
        binding.pictureRecycler.adapter = favoriteAdapter

//        binding.root.doOnPreDraw {
        binding.pictureRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                val firstPosition = (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()

//                binding.icImport.beVisibleIf(firstPosition > 3)
//                if (firstPosition > 0) {
//                    binding.icImport.beGone()
//                } else {
//                    binding.icImport.beVisible()
//                }
            }
        })

        Log.e("FavoriteActivity", "initAdapter end")
//        }
    }

    override fun onBackPressed() {
        val previousActivity = getPreviousActivity()
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else {
            if (preferences.isNeedInterAd) {
                AdsConfig.showInterstitialAd(this) {
                    if (it) preferences.isNeedInterAd = false
                    if (previousActivity.contains("HomeActivity")) {
                        finish()
                    } else {
                        val intent = Intent(this, HomeActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        startActivity(intent)
                    }
                }
            } else {
                if (previousActivity.contains("HomeActivity")) {
                    finish()
                } else {
                    val intent = Intent(this, HomeActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    startActivity(intent)
                }
            }
        }
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text =
            "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    fun setListGridData() {
        setRvLayoutManager()
        if (favoriteAdapter != null) {
//            albumAdapter!!.notifyDataSetChanged()
            favoriteAdapter?.notifyItemRangeChanged(0, pictures.size)
        }
    }

    fun setRvLayoutManager() {
        Log.e("FavoriteActivity", "setRvLayoutManager")
        val gridCount = preferences.getGridCount()
//        val layoutManager = MyGridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
//        binding.pictureRecycler.layoutManager = layoutManager
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = gridCount
        layoutManager.orientation = RecyclerView.VERTICAL
//        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (favoriteAdapter!!.getItemViewType(position) == favoriteAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        favoriteAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    favoriteAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val uris = ArrayList<Uri>()
            ensureBackgroundThread {
                runOnUiThread {
                    for (i in pictures.indices) {
                        if (pictures[i] is MediaData) {
                            val model = pictures[i] as MediaData
                            if (model.isSelected) {
                                val uri = FileProvider.getUriForFile(
                                    this,
                                    this.packageName + ".provider",
                                    File(model.filePath)
                                )
                                uris.add(uri)
                            }
                        }
                    }
                    Utils.shareFilesList(this, uris)
                }
            }
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog = DeleteDialog.newInstance(
                this,
//                getString(R.string.selected_delete_msg),
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show()
        }
    }

    private fun setUnFavoriteData() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val clearDialog = ConfirmationDialog(
                this,
                getString(R.string.unfavorite),
                getString(R.string.unFavorites_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    setUnFavoriteSelect()
                })
            clearDialog.show()
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
//            requestStoragePermission(app_private_AFA_allow_nf, app_private_AFA_denied_nf, getActivityName()) {
//                if (it) {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show()
//                }
//            }

        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils.hideFiles(this, selectImage, selectedItem, hideListener = { deleteList ->
            toast(getString(R.string.hide_successfully))
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
            runOnUiThread {
//                progressDialog.dismiss()
                setBeforeDeleteUpdate(deleteList)
                getData()
            }
        }, "", true)
    }


    private fun showAddAlbumDialog(
        albums: ArrayList<AlbumData>,
        selectedMedia: ArrayList<MediaData>,
        selectedAlbum: ArrayList<String>,
//        selectedAlbum: ArrayList<AlbumData>,
        isCopy: Boolean) {
//        val selectedAlbum = ArrayList<AlbumData>()
//        val selectImage = mutableSetOf<MediaData>() // Use a set to avoid duplicates
//        albumList.filter { it.isSelected }.forEach { album ->
//            selectedAlbum.add(album) // Add selected album
//            album.mediaData.forEach { picture ->
//                if (picture is MediaData) {
//                    selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
//                }
//            }
//        }

//        pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
//            .filter { it.isSelected } // Filter selected MediaData objects
//            .forEach { selectImage.add(it) } // Add to the set

        val uniqueSelectImage = ArrayList(selectedMedia.distinctBy { it.filePath })

        for (media in uniqueSelectImage) {
            Log.e("uniqueSelectImage", "uniqueSelectImage-->:${media.filePath}")
        }

//        val addAlbumDialog =
//            SelectAlbumFullDialog(
//                this@HomeActivity,
//                albums,
//                selectedAlbum,
//                isCopy,
//                selectPathListener = { selectPath ->
//                    setCopyMove(isCopy, selectPath, uniqueSelectImage)
//                },
//                createAlbumListener = {
////                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) { value ->
////                        if (value) {
//                    val createDialog = CreateAlbumDialog(this@HomeActivity, createPathListener = {
//                        setCopyMove(isCopy, it, uniqueSelectImage)
//                    })
//                    createDialog.show()
////                        }
////                    }
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

        isCopyForResult = isCopy
        selectImageForResult = uniqueSelectImage
        val selectAlbumIntent = Intent(this, SelectAlbumFullActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)

    }

    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<MediaData>
    ) {
        if (isCopy)
            Utils.copyFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
                    MediaScannerConnection.scanFile(this, arrayOf<String>(selectPath), null) { path, uri -> }
                    selectedItem = 0
                    preferences.refreshMedia = true
                    sendEvent("refresh")
                    longClickListener(false, 0, false)
                    setClose()
                })
        else
            Utils.moveFiles(
                this,
                selectPath,
                selectImage,
                selectedItem,
                moveListener = {
                    toast(getString(R.string.move_successfully))
                    MediaScannerConnection.scanFile(this, arrayOf<String>(selectPath), null) { path, uri -> }
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    sendEvent("refresh")
                    longClickListener(false, 0, false)
                    setClose()
                }, true
            )

    }

    private fun setUnFavoriteSelect() {
        val unFavList = ArrayList<String>()
        val favList = preferences.getFavoriteList()
        Observable.fromCallable {
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            if (favList.contains(model.filePath)) {
                                favList.remove(model.filePath)
                                unFavList.add(model.filePath)
                            }
                        } else {
                            model.isCheckboxVisible = false
                        }
                    }
            }

            var index = 0
            while (index < pictures.size) {
                if (pictures[index] != null)
                    if (pictures[index] is AlbumData) {
                        val model = pictures[index] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[index] is MediaData) {
                        val model = pictures[index] as MediaData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (index != 0) {
                                isPre = pictures[index - 1] is AlbumData
                            }
                            if (index < pictures.size - 2) {
                                isNext = pictures[index + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(index)
                                pictures.removeAt(index - 1)
                            } else if (index == pictures.size - 1) {
                                pictures.removeAt(index)
                                if (isPre) {
                                    pictures.removeAt(index - 1)
                                }
                            } else {
                                pictures.removeAt(index)
                            }
                            if (index != 0) {
                                index--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                index++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    setUpdateFavorite(unFavList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    setUpdateFavorite(unFavList)
                }
            }
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            this@FavouriteListActivity,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.show()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null) if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    if (model.isSelected) {
//                        runOnUiThread {
//                            bindingDialog.txtTitle.text = model.fileName
//                        }

                        val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                        MediaScannerConnection.scanFile(this, arrayOf<String>(model.filePath), null) { path: String?, uri: Uri? -> }

                        if (isDelete) {
                            deleteList.add(model.filePath)
                            runOnUiThread {
                                progressDialog.setProgress(deleteList.size, selectedItem)
                            }
                        }
                    } else {
                        model.isCheckboxVisible = false
                    }
                } else if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                                notifyAdapterRemove(i)
                                notifyAdapterRemove(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                notifyAdapterRemove(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                    notifyAdapterRemove(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                                notifyAdapterRemove(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
//        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
//        longClickListener(false, 0, false)
        setEmptyData()

        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
        getData()
        sendEvent("refresh")
    }

    private fun setUpdateFavorite(unFavoriteList: ArrayList<String>) {
//        EventBus.getDefault().post(UpdateFavoriteEvent(unFavoriteList = unFavoriteList, isFavorite = false))
        selectedItem = 0
        notifyAdapter()
        longClickListener(false, 0, false)
        setEmptyData()

        toast(getString(R.string.FilesUnfavoritesuccessfully))
        deleteMainList(unFavoriteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>, isFromFav: Boolean = false) {
        if (deleteList.size != 0) {
            val favList = preferences.getFavoriteList()
            for (path in deleteList) {
                if (!isFromFav)
                    if (favList.contains(path))
                        favList.remove(path)
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }

            preferences.setFavoriteList(favList)
        }
    }

    private fun getData() {
        disableScroll()
//        val excludeList: ArrayList<String> = ArrayList()
//        excludeList.addAll(preferences.getExcludeList())

//        allList.clear()
//        pictures.clear()
        binding.swipeRefreshLayout.isRefreshing = true
        mediaLoader?.getFavouriteList({ groupedMediaList, mediaList ->
            Log.e("FavoriteActivity", "groupedMediaList:${groupedMediaList.size}")
            Log.e("FavoriteActivity", "mediaList:${mediaList.size}")
            allList.clear()

            allList.addAll(mediaList)

            pictures.clear()
            pictures.addAll(groupedMediaList)

            runOnUiThread {
                enableScroll()
                binding.swipeRefreshLayout.isRefreshing = false
                setData()
            }
        })

//        Observable.fromCallable<Boolean> {
//            var favList = preferences.getFavoriteList()
//            if (!favList.isNullOrEmpty()) {
//                for (favPath in favList) {
//                    var file = File(favPath)
//                    var excluded = false
//                    excluded = excludeList.any { favPath == it }
//                    if (file.exists() && !excluded) {
//                        val mediaData =
//                            MediaData(
//                                favPath,
//                                file.name,
//                                file.parentFile.name,
//                                file.lastModified(),
//                                file.lastModified(),
//                                file.length(),
//                                Utils.isVideoFile(favPath)
//                            )
//                        mediaData.isFavorite = true
//                        allList.add(mediaData)
//                    }
//                }
//
//            }
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { throwable: Throwable? ->
//                runOnUiThread {
//                    setFilterData()
//                }
//            }
//            .subscribe { result: Boolean? ->
//                runOnUiThread {
//                    setFilterData()
//                }
//            }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }

    private fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()

            runOnUiThread {
                setData()
            }
        }
    }

    private fun setFilter() {
        Log.e("", "imageVideo size==>> " + allList.size)
        val sortType = preferences.getSortType("favourite")
        val sortOrder = preferences.getSortOrder("favourite")

        Collections.sort(allList, Comparator { p1, p2 ->
            if (p1 == null || p2 == null) -1
            else if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        setList()
    }


    private fun setList() {
        pictures.clear()

//        val dateWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
        val dateWisePictures: LinkedHashMap<String, ArrayList<MediaData>> = linkedMapOf()
        val currentGrouping = preferences.getGroupBy()
        val groupOrder = preferences.getGroupOrderBy()
//        var format = SimpleDateFormat("dd MMM yyyy")
        var format = SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)

        format = when (currentGrouping) {
            Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
//                SimpleDateFormat("dd MMM yyyy")
                SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            }

            Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
//                SimpleDateFormat("dd MMM yyyy")
                SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            }

            Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
            else -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
        }

        if (allList.size != 0) {
            for (pictureData in allList) {
                val strDate = format.format(pictureData.date)

                var imagesData1: ArrayList<MediaData> = ArrayList()
                if (dateWisePictures.containsKey(strDate)) {
                    val list: ArrayList<MediaData>? = dateWisePictures[strDate]
                    if (!list.isNullOrEmpty())
                        imagesData1.addAll(list)
                } else {
                    imagesData1 = ArrayList()
                }
                imagesData1.add(pictureData)
                dateWisePictures[strDate] = imagesData1
            }

            val keys: Set<String> = dateWisePictures.keys
            val listKeys = ArrayList(keys)

            if (groupOrder == Constant.ORDER_DESCENDING) {
                listKeys.reverse()
            }

            for (i in listKeys.indices) {
                val imagesData = dateWisePictures[listKeys[i]]
                if (imagesData != null && imagesData.size != 0) {
//                    val bucketData = AlbumData(listKeys[i])
                    val bucketData = AlbumData(listKeys[i], imagesData)
                    pictures.add(bucketData)
                    pictures.addAll(imagesData)
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }
}