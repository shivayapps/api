package com.photogallery.calendardaterangepicker.customviews

class InvalidDateException(message: String) : IllegalArgumentException(message)
