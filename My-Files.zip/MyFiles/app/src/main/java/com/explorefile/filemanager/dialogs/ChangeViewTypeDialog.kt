package com.explorefile.filemanager.dialogs

import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.DialogChangeViewTypeBinding
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.helpers.VIEW_TYPE_GRID
import com.explorefile.filemanager.helpers.VIEW_TYPE_LIST

class ChangeViewTypeDialog(
    val activity: BaseActivity,
    val path: String = "",
    val callback: () -> Unit
) {
    private var binding: DialogChangeViewTypeBinding
    private var config = activity.config

    init {
        binding = DialogChangeViewTypeBinding.inflate(activity.layoutInflater).apply {
            val currViewType = config.getFolderViewType(this@ChangeViewTypeDialog.path)
            val viewToCheck = if (currViewType == VIEW_TYPE_GRID) {
                changeViewTypeDialogRadioGrid.id
            } else {
                changeViewTypeDialogRadioList.id
            }

            changeViewTypeDialogRadio.check(viewToCheck)
        }

        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(binding.root, this) { alertDialog ->
                    binding.txtOk.setOnClickListener {
                        dialogConfirmed()
                        alertDialog.dismiss()
                    }
                    binding.txtCancel.setOnClickListener {
                        alertDialog.dismiss()
                    }
                }
            }
    }

    private fun dialogConfirmed() {
        val viewType =
            if (binding.changeViewTypeDialogRadio.checkedRadioButtonId == binding.changeViewTypeDialogRadioGrid.id) {
                VIEW_TYPE_GRID
            } else {
                VIEW_TYPE_LIST
            }

        config.viewType = viewType

        callback()
    }
}
