package com.explorefile.filemanager

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.Config.isAdsEnable
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.explorefile.filemanager.activities.SplashActivity
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.onesignal.OneSignal


class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
    companion object {
        var isAppIsRunning: Boolean = false
        var isOpenAdHide = false

        fun disabledOpenAds() {
            isOpenAdHide = true
        }

        fun enabledOpenAds() {
            Handler(Looper.getMainLooper()).postDelayed({ isOpenAdHide = false }, 500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        isAppIsRunning = false

        Thread {
            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)
            OneSignal.initWithContext(this@App)
            OneSignal.setAppId("8d111b4d-2db5-432b-893f-235768b6cbd5")
        }.start()

        val openAdId = getString(R.string.open_all)
        AdsConfig.builder()
            .isEnableAds(true)
            .isEnableOpenAds(true)
            .setTestDeviceId("VKDFV98HGNIEJ9NNUVCSNDL80928RKL0")
            .setAdmobAppOpenId(openAdId)
            .build(this)
        setAppLifecycleListener(this)
        initMobileAds()
        fireBaseConfigGet()
//        OpenAdHelper.loadOpenAd(this) { null }
    }

    private fun fireBaseConfigGet() {
        try {
            val mFirebaseRemoteConfig: FirebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
            mFirebaseRemoteConfig.reset()
            //Setting Developer Mode enabled to fast retrieve the values
            mFirebaseRemoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(5)
                    .build()
            )
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_confing_defaults)
            mFirebaseRemoteConfig.fetchAndActivate()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.e("fireBaseConfigGet", "isSuccessful")
                        mFirebaseRemoteConfig.activate()
                        val interAdClickCount: String =
                            mFirebaseRemoteConfig.getString("interAdClickCount")
                        val isAdEnable: Boolean = mFirebaseRemoteConfig.getBoolean("isAdEnable")
                        val isOpenAdEnable: Boolean =
                            mFirebaseRemoteConfig.getBoolean("isOpenAdEnable")
                        val admobInterstitialAdId: String =
                            mFirebaseRemoteConfig.getString("admobInterstitialAdId")
                        val admobAppOpenId: String =
                            mFirebaseRemoteConfig.getString("admobAppOpenId")
                        val admobBannerId: String = mFirebaseRemoteConfig.getString("admobBannerId")
                        val admobNativeId: String = mFirebaseRemoteConfig.getString("admobNativeId")
                        val admobRewardId: String = mFirebaseRemoteConfig.getString("admobRewardId")

                        Log.e("fireBaseConfigGet", "interAdClickCount:$interAdClickCount")
                        Log.e("fireBaseConfigGet", "isAdEnable:$isAdEnable")
                        Log.e("fireBaseConfigGet", "isOpenAdEnable:$isOpenAdEnable")
                        Log.e("fireBaseConfigGet", "admobInterstitialAdId:$admobInterstitialAdId")
                        Log.e("fireBaseConfigGet", "admobAppOpenId:$admobAppOpenId")
                        Log.e("fireBaseConfigGet", "admobBannerId:$admobBannerId")
                        Log.e("fireBaseConfigGet", "admobNativeId:$admobNativeId")
                        Log.e("fireBaseConfigGet", "admobRewardId:$admobRewardId")

                        if (isAdEnable != null) Config.isAdsEnable = isAdEnable
//                        Config.isAdsEnable = false
                        if (isOpenAdEnable != null) Config.isOpenAdEnable = isOpenAdEnable
//                        Config.isOpenAdEnable = false
                        if (!admobAppOpenId.isNullOrEmpty()) Config.admobAppOpenId = admobAppOpenId
                    } else {
                        Log.e("fireBaseConfigGet", "taskFailed")
                    }
                }
        } catch (e: Exception) {
            Log.e("fireBaseConfigGet", "Exception:$e")
            e.printStackTrace()
        }
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashActivity) return false
        else if (isOpenAdHide) {
            enabledOpenAds()
            return false
        }
        return true
    }


    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity)) {
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
        }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }
}