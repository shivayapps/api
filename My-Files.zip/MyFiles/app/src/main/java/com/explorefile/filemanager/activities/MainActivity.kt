package com.explorefile.filemanager.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.GravityCompat
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper

import com.explorefile.filemanager.App
import com.explorefile.filemanager.BuildConfig
import com.explorefile.filemanager.R
import com.explorefile.filemanager.adapters.ViewPagerAdapter
import com.explorefile.filemanager.databinding.ActivityMainBinding
import com.explorefile.filemanager.dialogs.ChangeSortingDialog
import com.explorefile.filemanager.dialogs.ChangeViewTypeDialog
import com.explorefile.filemanager.dialogs.ConfirmationAdvancedDialog
import com.explorefile.filemanager.dialogs.ConfirmationDialog
import com.explorefile.filemanager.dialogs.CreateNewItemDialog
import com.explorefile.filemanager.dialogs.RateDialog
import com.explorefile.filemanager.dialogs.ThemeDialog
import com.explorefile.filemanager.extensions.*
import com.explorefile.filemanager.filecleaner.StorageAnalysisActivity
import com.explorefile.filemanager.fragments.ItemsFragment
import com.explorefile.filemanager.fragments.MyViewPagerFragment
import com.explorefile.filemanager.fragments.RecentsFragment
import com.explorefile.filemanager.fragments.StorageFragment
import com.explorefile.filemanager.helpers.*
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.MyTheme
import com.explorefile.filemanager.models.RadioItem
import com.google.android.gms.ads.AdView
import com.stericson.RootTools.RootTools
import java.io.File

class MainActivity : BaseActivity() {

    companion object {
        var onNxtPage = false
        var onChangeColum = false
        var onChangeViewType = false
        var onChangeToggleName = false
        var isSelectable = false
        private const val MANAGE_STORAGE_RC = 201
        private const val PICKED_PATH = "picked_path"
        var mLastPath = ""
        var itemMoment = false
    }

    val binding by viewBinding(ActivityMainBinding::inflate)
    private var mTabsToShow = ArrayList<Int>()

    private var mStoredDateFormat = ""
    private var mStoredTimeFormat = ""
    private var mStoredShowTabs = 0

    private val THEME_LIGHT = 0
    private val THEME_DARK = 1
    private val THEME_AUTO = 8

    private var curTextColor = 0
    private var curBackgroundColor = 0
    private var curPrimaryColor = 0
    private var curAccentColor = 0
    private var curSelectedThemeId = 0
    private var hasUnsavedChanges = false
    private var predefinedThemes = LinkedHashMap<Int, MyTheme>()

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        appLaunched(BuildConfig.APPLICATION_ID)
        setupOptionsMenu()
        refreshMenuItems()
        mTabsToShow = getTabsList()
        //checkForAppUpdate(binding.root)

        if (!config.wasStorageAnalysisTabAdded && isOreoPlus()) {
            config.wasStorageAnalysisTabAdded = true
            if (config.showTabs and TAB_STORAGE_ANALYSIS == 0) {
                config.showTabs += TAB_STORAGE_ANALYSIS
            }
        }

        initAd()
        storeStateVariables()
        setupTabs()
        setupDrawer()

        updateMaterialActivityViews(
            binding.mainCoordinator, null, useTransparentNavigation = false, useTopSearchMenu = true
        )

        if (savedInstanceState == null) {
            initFragments()
            tryInitFileManager()
            checkIfRootAvailable()
        }

        initColorVariables()

        setupThemes()

        updateLabelColors(getProperTextColor(), getProperBackgroundColor())
    }

    var mAdView: AdView? = null
    var isAdLoaded = false
    private fun initAd() {
        val adId =getString(R.string.b_main)
        BannerAdHelper.showBanner(this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.bannerMain,
            { isLoaded, adView, message ->
                mAdView = adView
                AdCache.bannerMain = adView
                isAdLoaded = isLoaded
            })
    }
    private fun setupDrawer() {
        setupShowHidden()
        setupTrash()
        setupLanguage()
        setupShareApp()
        setupRate()
        setupPrivacy()
        setupVersion()

        binding.headerAnalyseHolder.setOnClickListener {
            startActivity(Intent(this,StorageAnalysisActivity::class.java))
        }
    }


    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        binding.mainViewPager.setPagingEnabled(false)

        refreshMenuItems()
        updateMenuColors(getProperTextColor(), getProperBackgroundColor())

        getAllFragments().forEach {
            it?.onResume(getProperTextColor())
        }

        if (mStoredDateFormat != config.dateFormat || mStoredTimeFormat != getTimeFormat()) {
            getAllFragments().forEach {
                (it as? ItemOperationsListener)?.setupDateTimeFormat()
            }
        }

        if (binding.mainViewPager.adapter == null) {
            initFragments()
        }

        updateTextColors(binding.headerScrollview)

        setTheme(getThemeId())

        updateBackgroundColor(getCurrentBackgroundColor())
        getRecentsFragment()?.refreshFragment()
        if (onChangeColum) {
            onChangeColum = false
            updateFragmentColumnCounts()
        }
        if (onChangeViewType) {
            onChangeViewType = false
            getItemsFragment()?.refreshFragment()
        }
        if (onChangeToggleName) {
            onChangeToggleName = false
            getAllFragments().forEach {
                (it as? ItemOperationsListener)?.toggleFilenameVisibility()
            }
        }
        setupLanguage()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        storeStateVariables()
        onNxtPage = false
    }

    override fun onDestroy() {
        super.onDestroy()
        config.temporarilyShowHidden = false
    }

    override fun onBackPressed() {
        val currentFragment = getCurrentFragment()
        if (binding.mainMenu.isSearchOpen) {
            binding.mainMenu.closeSearch()
        } else if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        } else if (currentFragment is StorageFragment) {

                ConfirmationDialog(
                    this,
                    "",
                    R.string.are_you_sure_you_want_to_exit,
                    R.string.yes,
                    R.string.no,
                    true,
                    R.string.exit
                ) {
                    finishAffinity()
                    App.isAppIsRunning = false
                }
//            }
        } else if (currentFragment is RecentsFragment) {
            binding.mainViewPager.currentItem = 0
        } else if ((currentFragment as ItemsFragment).getBreadcrumbs().getItemCount() <= 1) {
            binding.mainViewPager.currentItem = 0
        } else {
            currentFragment.getBreadcrumbs().removeBreadcrumb()
            openPath(currentFragment.getBreadcrumbs().getLastItem().path)
        }
    }

    fun refreshMenuItems() {
        val currentFragment = getCurrentFragment() ?: return
        binding.mainMenu.getToolbar().menu.apply {
            findItem(R.id.sort).isVisible = currentFragment is ItemsFragment
            findItem(R.id.change_view_type).isVisible = currentFragment !is StorageFragment
            findItem(R.id.add).isVisible = currentFragment is ItemsFragment

            findItem(R.id.temporarily_show_hidden).isVisible =
                !config.shouldShowHidden() && currentFragment is ItemsFragment

            findItem(R.id.stop_showing_hidden).isVisible =
                config.temporarilyShowHidden && currentFragment is ItemsFragment
        }
        if (currentFragment !is StorageFragment) {
            binding.mainMenu.nextPage()
        } else {
            binding.mainMenu.onHomePage()
            binding.mainMenu.pageName(this.getString(R.string.app_name))
        }

        if (currentFragment is StorageFragment) {
            if (itemMoment) {
                itemMoment = false
                getStorageFragment()?.refreshFragment()
            }
        }
    }

    private fun setupOptionsMenu() {
        binding.mainMenu.apply {
            getToolbar().inflateMenu(R.menu.menu)
            toggleHideOnScroll(false)
            setupMenu()

            onSearchClosedListener = {
                getAllFragments().forEach {
                    it?.searchQueryChanged("")
                }
            }

            onDrawerListener = {
                openDrawer()
            }

            onBackListener = {
                onBackPressed()
            }

            onSearchTextChangedListener = { text ->
                getCurrentFragment()?.searchQueryChanged(text)
            }

            getToolbar().setOnMenuItemClickListener { menuItem ->
                if (getCurrentFragment() == null) {
                    return@setOnMenuItemClickListener true
                }

                when (menuItem.itemId) {
                    R.id.sort -> showSortingDialog()
                    R.id.toggle_filename -> toggleFilenameVisibility()
                    R.id.add -> createNewItem()
                    R.id.change_view_type -> changeViewType()
                    R.id.temporarily_show_hidden -> tryToggleTemporarilyShowHidden()
                    R.id.stop_showing_hidden -> tryToggleTemporarilyShowHidden()
                    else -> return@setOnMenuItemClickListener false
                }
                return@setOnMenuItemClickListener true
            }
        }
    }

    private fun tryToggleTemporarilyShowHidden() {
        if (config.temporarilyShowHidden) {
            toggleTemporarilyShowHidden(false)
        } else {
            toggleTemporarilyShowHidden(true)
        }
    }

    private fun openDrawer() {
        binding.drawerLayout.openDrawer(GravityCompat.START)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(PICKED_PATH, getItemsFragment()?.currentPath ?: "")

    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val path = savedInstanceState.getString(PICKED_PATH) ?: internalStoragePath

        if (binding.mainViewPager.adapter == null) {
            binding.mainViewPager.onGlobalLayout {
                restorePath(path)
            }
        } else {
            restorePath(path)
        }
    }

    @SuppressLint("NewApi")
    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        isAskingPermissions = false
        if (requestCode == MANAGE_STORAGE_RC && isRPlus()) {
            actionOnPermission?.invoke(Environment.isExternalStorageManager())
        }
    }

    private fun restorePath(path: String) {
        openPath(path, true)
    }

    private fun updateMenuColors(textColor: Int, currentBackgroundColor: Int) {
        updateStatusbarColor(currentBackgroundColor)
        binding.mainMenu.updateColors(textColor, currentBackgroundColor)
        binding.navView.setBackgroundColor(currentBackgroundColor)

        arrayOf(
            binding.myTextView,
            binding.headerTrashLabel,
            binding.headerTrash,
            binding.headerAnalyseLabel,
            binding.headerThemeLabel,
            binding.headerTheme,
            binding.headerLanguage,
            binding.headerLanguageLabel,
//            binding.headerHiddenLabel,
            binding.headerShareLabel,
            binding.headerRateLabel,
//            binding.headerRate,
            binding.headerPrivacyLabel,
        ).forEach {
            it.setTextColor(textColor)
        }

        arrayOf(
            binding.imageTrash,
            binding.imageTheme,
            binding.imageAnalyse,
            binding.imageLanguage,
//            binding.imageHidden,
            binding.imageShare,
            binding.imageRate,
            binding.imagePrivacy
//            binding.imageVersion
        ).forEach {
            it.setColorFilter(textColor)
        }

    }

    private fun storeStateVariables() {
        config.apply {
            mStoredDateFormat = dateFormat
            mStoredTimeFormat = context.getTimeFormat()
            mStoredShowTabs = showTabs
        }
    }

    private fun tryInitFileManager() {
        val hadPermission = hasStoragePermission()
        handleStoragePermission {
            checkOTGPath()
            if (it) {
                if (binding.mainViewPager.adapter == null) {
                    initFragments()
                }

                binding.mainViewPager.onGlobalLayout {
                    initFileManager(!hadPermission)
                }
            } else {
                toast(R.string.no_storage_permissions)
                finishAffinity()
//                AdconfigApplication.adConfigFinishAffinity()
                App.isAppIsRunning = false
            }
        }
    }

    @SuppressLint("InlinedApi")
    private fun handleStoragePermission(callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasStoragePermission()) {
            callback(true)
        } else {
            if (isRPlus()) {
                ConfirmationAdvancedDialog(
                    this, "", R.string.access_storage_prompt, R.string.ok, 0, false
                ) { success ->
                    if (success) {
                        isAskingPermissions = true
                        actionOnPermission = callback
                        try {
                            val intent =
                                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                            intent.addCategory("android.intent.category.DEFAULT")
                            intent.data = Uri.parse("package:$packageName")
//                            if (isPermissionOpen()) {
                                App.disabledOpenAds()
//                            }
                            startActivityForResult(intent, MANAGE_STORAGE_RC)
                        } catch (e: Exception) {
                            showErrorToast(e)
                            val intent = Intent()
                            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
//                            if (isPermissionOpen()) {
                                App.disabledOpenAds()
//                            }
                            startActivityForResult(intent, MANAGE_STORAGE_RC)
                        }
                    } else {
                        finishAffinity()
//                        AdconfigApplication.adConfigFinishAffinity()
                        App.isAppIsRunning = false
                    }
                }
            } else {
                handlePermission(PERMISSION_WRITE_STORAGE, callback)
            }
        }
    }


    private fun initFileManager(refreshRecents: Boolean) {
        if (intent.action == Intent.ACTION_VIEW && intent.data != null) {
            val data = intent.data
            if (data?.scheme == "file") {
                openPath(data.path!!)
            } else {
                val path = getRealPathFromURI(data!!)
                if (path != null) {
                    openPath(path)
                } else {
                    openPath(config.homeFolder)
                }
            }

            if (!File(data.path!!).isDirectory) {
                tryOpenPathIntent(data.path!!, false, finishActivity = true)
            }

            binding.mainViewPager.currentItem = 0
        } else {
            openPath(config.homeFolder)
        }

        if (refreshRecents) {
            getStorageFragment()?.refreshFragment()
            getRecentsFragment()?.refreshFragment()
        }
    }

    private fun initFragments() {
        binding.mainViewPager.apply {
            adapter = ViewPagerAdapter(this@MainActivity, mTabsToShow)
            offscreenPageLimit = 2
            addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
                override fun onPageScrollStateChanged(state: Int) {}

                override fun onPageScrolled(
                    position: Int, positionOffset: Float, positionOffsetPixels: Int
                ) {
                }

                override fun onPageSelected(position: Int) {
                    getAllFragments().forEach {
                        (it as? ItemOperationsListener)?.finishActMode()
                    }
                    refreshMenuItems()
                }
            })

            onGlobalLayout {
                refreshMenuItems()
            }
        }
    }

    private fun setupTabs() {
        val action = intent.action
        val isPickFileIntent =
            action == RingtoneManager.ACTION_RINGTONE_PICKER || action == Intent.ACTION_GET_CONTENT || action == Intent.ACTION_PICK
        val isCreateDocumentIntent = action == Intent.ACTION_CREATE_DOCUMENT

        if (isPickFileIntent) {
            mTabsToShow.remove(TAB_STORAGE_ANALYSIS)
            if (mTabsToShow.none { it and config.showTabs != 0 }) {
                config.showTabs = TAB_FILES
                mStoredShowTabs = TAB_FILES
                mTabsToShow = arrayListOf(TAB_FILES)
            }
        } else if (isCreateDocumentIntent) {
            mTabsToShow.clear()
            mTabsToShow = arrayListOf(TAB_FILES)
        }
    }

    private fun checkOTGPath() {
        ensureBackgroundThread {
            if (!config.wasOTGHandled && hasPermission(PERMISSION_WRITE_STORAGE) && hasOTGConnected() && config.OTGPath.isEmpty()) {
                getStorageDirectories().firstOrNull {
                    it.trimEnd('/') != internalStoragePath && it.trimEnd(
                        '/'
                    ) != sdCardPath
                }?.apply {
                    config.wasOTGHandled = true
                    config.OTGPath = trimEnd('/')
                }
            }
        }
    }

    private fun openPath(path: String, forceRefresh: Boolean = false) {
        var newPath = path
        val file = File(path)
        if (config.OTGPath.isNotEmpty() && config.OTGPath == path.trimEnd('/')) {
            newPath = path
        } else if (file.exists() && !file.isDirectory) {
            newPath = file.parent!!
        } else if (!file.exists() && !isPathOnOTG(newPath)) {
            newPath = internalStoragePath
        }

        getItemsFragment()?.openPath(newPath, forceRefresh)
    }

    private fun showSortingDialog() {
        ChangeSortingDialog(this, getCurrentFragment()!!.currentPath) {
            (getCurrentFragment() as? ItemsFragment)?.refreshFragment()
        }
    }

    private fun createNewItem() {
        CreateNewItemDialog(this@MainActivity, getCurrentFragment()!!.currentPath) {
            if (it) {
                (getCurrentFragment() as? ItemsFragment)?.refreshFragment()
            } else {
                this.toast(R.string.unknown_error_occurred)
            }
        }
    }

    private fun toggleFilenameVisibility() {
        config.displayFilenames = !config.displayFilenames
        getAllFragments().forEach {
            (it as? ItemOperationsListener)?.toggleFilenameVisibility()
        }
    }

    fun updateFragmentColumnCounts() {
        getAllFragments().forEach {
            (it as? ItemOperationsListener)?.columnCountChanged()
        }
    }

    private fun changeViewType() {
            if (config.viewType == VIEW_TYPE_LIST) {
                config.viewType = VIEW_TYPE_GRID
            } else {
                config.viewType = VIEW_TYPE_LIST
            }
//        ChangeViewTypeDialog(
//            this, getCurrentFragment()!!.currentPath
//        ) {
            getAllFragments().forEach {
                it?.refreshFragment()
            }
//        }
    }

    private fun toggleTemporarilyShowHidden(show: Boolean) {
        config.temporarilyShowHidden = show
        getAllFragments().forEach {
            it?.refreshFragment()
        }
    }

    private fun checkIfRootAvailable() {
        ensureBackgroundThread {
            config.isRootAvailable = RootTools.isRootAvailable()
            if (config.isRootAvailable && config.enableRootAccess) {
                RootHelpers(this).askRootIfNeeded {
                    config.enableRootAccess = it
                }
            }
        }
    }

    fun pickedPath(path: String) {
        val resultIntent = Intent()
        val uri = getFilePublicUri(File(path), BuildConfig.APPLICATION_ID)
        val type = path.getMimeType()
        resultIntent.setDataAndType(uri, type)
        resultIntent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }


    fun pickedRingtone(path: String) {
        val uri = getFilePublicUri(File(path), BuildConfig.APPLICATION_ID)
        val type = path.getMimeType()
        Intent().apply {
            setDataAndType(uri, type)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            putExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, uri)
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    fun pickedPaths(paths: ArrayList<String>) {
        val newPaths =
            paths.map { getFilePublicUri(File(it), BuildConfig.APPLICATION_ID) } as ArrayList
        val clipData = ClipData(
            "Attachment", arrayOf(paths.getMimeType()), ClipData.Item(newPaths.removeAt(0))
        )

        newPaths.forEach {
            clipData.addItem(ClipData.Item(it))
        }

        Intent().apply {
            this.clipData = clipData
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    fun openedDirectory() {
        if (binding.mainMenu.isSearchOpen) {
            binding.mainMenu.closeSearch()
        }
    }

    private fun getRecentsFragment() = findViewById<RecentsFragment>(R.id.recents_fragment)
    fun getItemsFragment() = findViewById<ItemsFragment>(R.id.items_fragment)
    private fun getStorageFragment() = findViewById<StorageFragment>(R.id.storage_fragment)
    private fun getAllFragments(): ArrayList<MyViewPagerFragment<*>?> =
        arrayListOf(getItemsFragment(), getStorageFragment(), getRecentsFragment())

    fun getCurrentFragment(): MyViewPagerFragment<*>? {
        val showTabs = config.showTabs
        val fragments = arrayListOf<MyViewPagerFragment<*>>()

        if (showTabs and TAB_STORAGE_ANALYSIS != 0) {
            fragments.add(getStorageFragment())
        }

        if (showTabs and TAB_FILES != 0) {
            fragments.add(getItemsFragment())
        }

        if (showTabs and TAB_RECENT_FILES != 0) {
            fragments.add(getRecentsFragment())
        }
        return fragments.getOrNull(binding.mainViewPager.currentItem)
    }

    private fun getTabsList() = arrayListOf(TAB_STORAGE_ANALYSIS, TAB_RECENT_FILES, TAB_FILES)


    private fun setupShowHidden() {
//        binding.headerHidden.isChecked = config.showHidden
//        binding.headerHiddenHolder.setOnClickListener {
//            toggleShowHidden()
//        }
    }

    private fun toggleShowHidden() {
//        binding.headerHidden.toggle()
//        config.showHidden = binding.headerHidden.isChecked
    }

    private fun setupVersion() {
//        binding.headerVersion.text = BuildConfig.VERSION_NAME
    }

    private fun setupPrivacy() {
        binding.headerPrivacyHolder.setOnClickListener {
            startActivity(Intent(this@MainActivity, StorageAnalysisActivity::class.java))
//            launchViewIntent(getPrivacyPolicy())
        }
    }

    private fun setupRate() {
        binding.headerRateHolder.setOnClickListener {
            RateDialog(this) {}
        }
    }

    private fun setupShareApp() {
        binding.headerShareHolder.setOnClickListener {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(
                Intent.EXTRA_TEXT,
                "Hey check out my app at: https://play.google.com/store/apps/details?id=$packageName"
            )
            sendIntent.type = "text/plain"
            startActivity(sendIntent)
        }
    }

    private fun setupLanguage() {
        binding.headerLanguageHolder.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    LanguageActivity::class.java
                ).putExtra(INTENT_KEY, LANGUAGE_KEY)
            )
            finish()
        }

        binding.headerLanguage.text = when (config.languageSting) {
            "en" -> this.resources.getString(R.string.english)

            "de" -> this.resources.getString(R.string.german)

            "es" -> this.resources.getString(R.string.spanish)

            "fil" -> this.resources.getString(R.string.filipino)

            "fr" -> this.resources.getString(R.string.french)

            "hi" -> this.resources.getString(R.string.hindi)

            "in" -> this.resources.getString(R.string.indonesian)

            "it" -> this.resources.getString(R.string.italian)

            "tr" -> this.resources.getString(R.string.turkish)

            "zh" -> this.resources.getString(R.string.chinese)

            "ar" -> this.resources.getString(R.string.arabic)

            "ru" -> this.resources.getString(R.string.russian)

            "ja" -> this.resources.getString(R.string.japanese)

            else -> {
                this.resources.getString(R.string.english)
            }
        }
    }

    private fun setupTrash() {
        binding.headerTrashHolder.setOnClickListener {
            startActivity(Intent(this, TrashedActivity::class.java))
        }
    }

    private fun setupThemes() {
        predefinedThemes.apply {
            put(
                THEME_LIGHT,
                MyTheme(
                    getString(R.string.light_theme),
                    R.color.theme_light_text_color,
                    R.color.theme_light_background_color,
                    R.color.color_primary
                )
            )

            put(
                THEME_DARK,
                MyTheme(
                    getString(R.string.dark_theme),
                    R.color.theme_dark_text_color,
                    R.color.theme_dark_background_color,
                    R.color.color_primary
                )
            )
        }
        setupThemePicker()
    }

    private fun setupThemePicker() {
        curSelectedThemeId = getCurrentThemeId()
        binding.headerTheme.text = getThemeText()
        binding.headerThemeHolder.setOnClickListener {
            themePickerClicked()
        }
    }

    private fun themePickerClicked() {
        val items = arrayListOf<RadioItem>()
        for ((key, value) in predefinedThemes) {
            items.add(RadioItem(key, value.label))
        }

        ThemeDialog(this@MainActivity, items, curSelectedThemeId) {
            updateColorTheme(it as Int)
            saveChanges()
        }
    }

    private fun updateColorTheme(themeId: Int) {
        curSelectedThemeId = themeId
        binding.headerTheme.text = getThemeText()

        resources.apply {
            val theme = predefinedThemes[curSelectedThemeId]!!
            curTextColor = getColor(theme.textColorId)
            curBackgroundColor = getColor(theme.backgroundColorId)

            if (curSelectedThemeId != THEME_AUTO) {
                curPrimaryColor = getColor(theme.primaryColorId)
                curAccentColor = getColor(R.color.color_primary)
            }

            setTheme(getThemeId())
            colorChanged()
        }

        hasUnsavedChanges = true

        updateLabelColors(getCurrentTextColor(), getCurrentBackgroundColor())
        updateBackgroundColor(getCurrentBackgroundColor())
    }

    private fun getAutoThemeColors(): MyTheme {
        val isUsingSystemDarkTheme = isUsingSystemDarkTheme()
        val textColor =
            if (isUsingSystemDarkTheme) R.color.theme_dark_text_color else R.color.theme_light_text_color
        val backgroundColor =
            if (isUsingSystemDarkTheme) R.color.theme_dark_background_color else R.color.theme_light_background_color
        return MyTheme(
            getString(R.string.auto_light_dark_theme),
            textColor,
            backgroundColor,
            R.color.color_primary
        )
    }

    private fun getCurrentThemeId(): Int {
        var themeId = THEME_AUTO
        resources.apply {
            for ((key, value) in predefinedThemes.filter { it.key != THEME_AUTO }) {
                if (curTextColor == getColor(value.textColorId) &&
                    curBackgroundColor == getColor(value.backgroundColorId) &&
                    curPrimaryColor == getColor(value.primaryColorId)
                ) {
                    themeId = key
                }
            }
        }

        return themeId
    }

    private fun getThemeText(): String {
        var label = getString(R.string.custom)
        for ((key, value) in predefinedThemes) {
            if (key == curSelectedThemeId) {
                label = value.label
            }
        }
        return label
    }

    private fun saveChanges() {
        when (curSelectedThemeId) {
            THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
            THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
        baseConfig.apply {
            textColor = curTextColor
            backgroundColor = curBackgroundColor
            primaryColor = curPrimaryColor
            accentColor = curAccentColor
        }
        hasUnsavedChanges = false
        this.recreate()
    }

    private fun initColorVariables() {
        curTextColor = baseConfig.textColor
        curBackgroundColor = baseConfig.backgroundColor
        curPrimaryColor = baseConfig.primaryColor
        curAccentColor = baseConfig.accentColor
    }

    private fun colorChanged() {
        hasUnsavedChanges = true
    }

    private fun updateLabelColors(textColor: Int, currentBackgroundColor: Int) {
        updateMenuColors(textColor, currentBackgroundColor)

        getAllFragments().forEach {
            it?.onResume(textColor)
        }
    }

    private fun getCurrentTextColor() = curTextColor

    private fun getCurrentBackgroundColor() = curBackgroundColor

}
