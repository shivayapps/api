package com.video.aimagic.onboardingflow.dataset

import androidx.annotation.DrawableRes
import androidx.annotation.RawRes
import androidx.annotation.StringRes
import com.video.aimagic.R

enum class CustomOnBoardingPage(
    @StringRes val titleResId: Int,
    @StringRes val subtitleResId: Int,
    @StringRes val descriptionResId: Int,
    @DrawableRes val imageResId: Int,
    @RawRes val videoResId: Int,
    val contentType: ContentType
) {
    WELCOME(
        titleResId = R.string.onboarding_slide1_title,
        subtitleResId = R.string.s1,
        descriptionResId = R.string.s1h,
        imageResId = 0,
        videoResId = R.raw.ai_video_effect,
        contentType = ContentType.VIDEO
    ),
    FEATURES(
        titleResId = R.string.onboarding_slide2_title,
        subtitleResId = R.string.s2,
        descriptionResId = R.string.s2h,
        imageResId = R.drawable.baby_gen,
        videoResId = 0,
        contentType = ContentType.IMAGE
    ),
    GET_STARTED(
        titleResId = R.string.onboarding_slide3_title,
        subtitleResId = R.string.s3,
        descriptionResId = R.string.s3h,
        imageResId = 0,
        videoResId = R.raw.face_dance,
        contentType = ContentType.VIDEO
    ),
    FACESWAP(
        titleResId = R.string.onboarding_slide3_title,
        subtitleResId = R.string.s3,
        descriptionResId = R.string.s3h,
        imageResId = R.drawable.face_swap,
        videoResId = 0,
        contentType = ContentType.IMAGE
    );

    enum class ContentType {
        IMAGE, VIDEO
    }
}