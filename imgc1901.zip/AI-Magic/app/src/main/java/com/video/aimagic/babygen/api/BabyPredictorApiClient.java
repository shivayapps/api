package com.video.aimagic.babygen.api;


import okhttp3.*;
import android.util.Log;

import com.video.aimagic.callback.ApiCallback;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class BabyPredictorApiClient {
    private static BabyPredictorApiClient instance;
    private OkHttpClient client;

    private static final String TAG = "BabyPredictorApiClient";
    private static final String BASE_URL = "https://babygenerator.aapthi.in/baby_predict_features/";

    private BabyPredictorApiClient() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(new LoggingInterceptor())
                .build();
    }

    public static synchronized BabyPredictorApiClient getInstance() {
        if (instance == null) {
            instance = new BabyPredictorApiClient();
        }
        return instance;
    }




    public void predictBabyFeatures(PredictRequest request, ApiCallback callback) {
        Log.d(TAG, "predictBabyFeatures() called");

        // Validate callback
        if (callback == null) {
            Log.e(TAG, "Callback cannot be null");
            throw new IllegalArgumentException("Callback cannot be null");
        }

        // Validate request
        if (request == null) {
            Log.e(TAG, "Request object is null");
            callback.onError("Request object cannot be null");
            return;
        }

        // Log request parameters
        logRequestParameters(request);

        // Validate required parameters
        if (!validateRequiredParameters(request, callback)) {
            return;
        }

        // Validate percentage values
        if (request.getMotherPercent() + request.getFatherPercent() != 100) {
            Log.e(TAG, "Mother and father percentages must sum to 100");
            callback.onError("Mother and father percentages must sum to 100");
            return;
        }

        // Build URL with query parameters
        HttpUrl.Builder urlBuilder = HttpUrl.parse(BASE_URL).newBuilder();
        urlBuilder.addQueryParameter("baby_gender", request.getBabyGender());
        urlBuilder.addQueryParameter("baby_country", request.getBabyCountry());
        urlBuilder.addQueryParameter("app_name", request.getAppName());
        urlBuilder.addQueryParameter("mother_percent", String.valueOf(request.getMotherPercent()));
        urlBuilder.addQueryParameter("father_percent", String.valueOf(request.getFatherPercent()));
        urlBuilder.addQueryParameter("skintone", request.getSkinTone());
        urlBuilder.addQueryParameter("age_group", request.getAgeGroup());
        urlBuilder.addQueryParameter("country_code", request.getCountryCode());
        urlBuilder.addQueryParameter("platform", request.getPlatform());

        String url = urlBuilder.build().toString();
        Log.d(TAG, "Final URL: " + url);

        // Create multipart form data
        MultipartBody.Builder bodyBuilder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("mother_list", request.getMotherList())
                .addFormDataPart("father_list", request.getFatherList());

        // Add mother image if provided
        if (request.getMotherImage() != null && request.getMotherImage().exists()) {
            bodyBuilder.addFormDataPart("moth_image",
                    request.getMotherImage().getName(),
                    RequestBody.create(request.getMotherImage(), MediaType.parse("image/png")));
            Log.d(TAG, "Added mother image: " + request.getMotherImage().getAbsolutePath());
        }

        // Add father image if provided
        if (request.getFatherImage() != null && request.getFatherImage().exists()) {
            bodyBuilder.addFormDataPart("fath_image",
                    request.getFatherImage().getName(),
                    RequestBody.create(request.getFatherImage(), MediaType.parse("image/png")));
            Log.d(TAG, "Added father image: " + request.getFatherImage().getAbsolutePath());
        }

        RequestBody requestBody = bodyBuilder.build();

        // Build headers
        Headers.Builder headersBuilder = new Headers.Builder()
                .add("accept", "application/json")
                .add("Content-Type", "multipart/form-data");

        // Add optional headers
        if (request.getFcmToken() != null && !request.getFcmToken().trim().isEmpty()) {
            headersBuilder.add("fcmtoken", request.getFcmToken());
            Log.d(TAG, "Added fcmtoken header");
        }

        if (request.getFirebaseAppCheck() != null && !request.getFirebaseAppCheck().trim().isEmpty()) {
            headersBuilder.add("x-firebase-appcheck", request.getFirebaseAppCheck());
            Log.d(TAG, "Added x-firebase-appcheck header");
        }

        Headers headers = headersBuilder.build();
        Log.d(TAG, "Request headers: " + headers.toString());

        // Build the request
        Request httpRequest = new Request.Builder()
                .url(url)
                .headers(headers)
                .post(requestBody)
                .build();

        Log.d(TAG, "Sending HTTP POST request...");

        // Execute the request
        client.newCall(httpRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Network request failed: " + e.getMessage(), e);
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    Log.d(TAG, "Received response. Code: " + response.code() + ", Message: " + response.message());

                    if (response.isSuccessful()) {
                        String responseBody = response.body() != null ? response.body().string() : "Empty response";
                        Log.d(TAG, "Success response: " + responseBody);
                        callback.onSuccess(responseBody);
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "HTTP error: " + response.code() + " - " + response.message() + ", Body: " + errorBody);
                        callback.onError("HTTP error: " + response.code() + " - " + response.message());
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error reading response: " + e.getMessage(), e);
                    callback.onError("Error reading response: " + e.getMessage());
                } finally {
                    if (response != null) {
                        response.close();
                    }
                }
            }
        });
    }

    private boolean validateRequiredParameters(PredictRequest request, ApiCallback callback) {
        if (request.getBabyGender() == null || request.getBabyGender().trim().isEmpty()) {
            Log.e(TAG, "Baby gender is required");
            callback.onError("Baby gender is required");
            return false;
        }

        if (request.getBabyCountry() == null || request.getBabyCountry().trim().isEmpty()) {
            Log.e(TAG, "Baby country is required");
            callback.onError("Baby country is required");
            return false;
        }

        if (request.getAppName() == null || request.getAppName().trim().isEmpty()) {
            Log.e(TAG, "App name is required");
            callback.onError("App name is required");
            return false;
        }

        if (request.getSkinTone() == null || request.getSkinTone().trim().isEmpty()) {
            Log.e(TAG, "Skin tone is required");
            callback.onError("Skin tone is required");
            return false;
        }

        if (request.getAgeGroup() == null || request.getAgeGroup().trim().isEmpty()) {
            Log.e(TAG, "Age group is required");
            callback.onError("Age group is required");
            return false;
        }

        if (request.getCountryCode() == null || request.getCountryCode().trim().isEmpty()) {
            Log.e(TAG, "Country code is required");
            callback.onError("Country code is required");
            return false;
        }

        if (request.getPlatform() == null || request.getPlatform().trim().isEmpty()) {
            Log.e(TAG, "Platform is required");
            callback.onError("Platform is required");
            return false;
        }

        if (request.getMotherList() == null || request.getMotherList().trim().isEmpty()) {
            Log.e(TAG, "Mother list is required");
            callback.onError("Mother list is required");
            return false;
        }

        if (request.getFatherList() == null || request.getFatherList().trim().isEmpty()) {
            Log.e(TAG, "Father list is required");
            callback.onError("Father list is required");
            return false;
        }

        return true;
    }

    private void logRequestParameters(PredictRequest request) {
        Log.d(TAG, "Request parameters:");
        Log.d(TAG, "Baby Gender: " + request.getBabyGender());
        Log.d(TAG, "Baby Country: " + request.getBabyCountry());
        Log.d(TAG, "App Name: " + request.getAppName());
        Log.d(TAG, "Mother Percent: " + request.getMotherPercent());
        Log.d(TAG, "Father Percent: " + request.getFatherPercent());
        Log.d(TAG, "Skin Tone: " + request.getSkinTone());
        Log.d(TAG, "Age Group: " + request.getAgeGroup());
        Log.d(TAG, "Country Code: " + request.getCountryCode());
        Log.d(TAG, "Platform: " + request.getPlatform());
        Log.d(TAG, "Mother List: " + request.getMotherList());
        Log.d(TAG, "Father List: " + request.getFatherList());
        Log.d(TAG, "FCM Token: " + (request.getFcmToken() != null ? "Provided" : "Not provided"));
        Log.d(TAG, "Firebase AppCheck: " + (request.getFirebaseAppCheck() != null ? "Provided" : "Not provided"));

        if (request.getMotherImage() != null) {
            Log.d(TAG, "Mother Image: " + request.getMotherImage().getAbsolutePath() +
                    " (Exists: " + request.getMotherImage().exists() + ")");
        } else {
            Log.d(TAG, "Mother Image: Not provided");
        }

        if (request.getFatherImage() != null) {
            Log.d(TAG, "Father Image: " + request.getFatherImage().getAbsolutePath() +
                    " (Exists: " + request.getFatherImage().exists() + ")");
        } else {
            Log.d(TAG, "Father Image: Not provided");
        }
    }

    private static class LoggingInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();

            long startTime = System.nanoTime();
            Log.d(TAG, String.format("Sending request %s", request.url()));

            Response response = chain.proceed(request);

            long endTime = System.nanoTime();
            Log.d(TAG, String.format("Received response for %s in %.1fms - Code: %d",
                    response.request().url(), (endTime - startTime) / 1e6d, response.code()));

            return response;
        }
    }
}