package com.video.aimagic.commonscreen.data

import com.video.aimagic.R

object DrawableProvider {

    fun getDrawables(category: DrawableCategory): List<Int> {
        return when (category) {
            DrawableCategory.SOLID -> listOf(
                R.drawable.solid_1,
                R.drawable.solid_2,
                R.drawable.solid_3,
                R.drawable.solid_4,
                R.drawable.solid_5,
                R.drawable.solid_6,
                R.drawable.solid_7,
                R.drawable.solid_8
            )

            DrawableCategory.GRADIENT -> listOf(
                R.drawable.gradient_1,
                R.drawable.gradient_2,
                R.drawable.gradient_3,
                R.drawable.gradient_4,
                R.drawable.gradient_5,
            )

            DrawableCategory.TRENDING -> listOf(
                R.drawable.trending_1,
                R.drawable.trending_2,
                R.drawable.trending_3,
                R.drawable.trending_4,
                R.drawable.trending_5
            )
        }
    }
}
