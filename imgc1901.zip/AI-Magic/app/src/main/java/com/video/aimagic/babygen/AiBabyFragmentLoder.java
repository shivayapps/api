package com.video.aimagic.babygen;

import android.util.SparseArray;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.video.aimagic.babygen.fragments.BabyBoy;
import com.video.aimagic.babygen.fragments.BabyGirl;


public class AiBabyFragmentLoder extends FragmentStateAdapter {

    private final SparseArray<Fragment> fragmentList = new SparseArray<>();

    public AiBabyFragmentLoder(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment;
        if (position == 0) {
            fragment = new BabyBoy();
        } else {
            fragment = new BabyGirl();
        }
        fragmentList.put(position, fragment); // Track fragment instance
        return fragment;
    }

    @Override
    public int getItemCount() {
        return 2;
    }

    public Fragment getFragment(int position) {
        return fragmentList.get(position);
    }
}
