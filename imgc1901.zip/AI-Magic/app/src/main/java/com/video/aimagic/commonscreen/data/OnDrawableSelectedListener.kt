package com.video.aimagic.commonscreen.data

interface OnDrawableSelectedListener {
    fun onDrawableSelected(
        category: DrawableCategory,
        drawableRes: Int
    )
}
