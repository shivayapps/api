package com.video.aimagic.commonscreen.screen;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.adconfig.AdsConfig;
import com.adconfig.AdsConfigKt;
import com.adconfig.adsutil.admob.AdmobIntersAdImpl;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityCommonResultScreenBinding;
import com.video.aimagic.aivideos.api.get.DownloadVideoAndPlay;
import com.video.aimagic.callback.ResponseCallBack;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.facedance.api.get.FaceDanceDownloadVideoAndPlay;
import com.video.aimagic.singletone.ConfirmDialog;
import com.video.aimagic.singletone.ExitDialog;
import com.video.aimagic.singletone.PhotoUploadManager;
import com.video.aimagic.utils.Methods;
import com.video.aimagic.utils.appconfig.AppConfig;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class CommonResultScreen extends AppCompatActivity {

    private ActivityCommonResultScreenBinding binding;
    private boolean isImageSaved = false;
    private boolean isOutputImage = true;
    private String currentImageUrl = "";
    private String currentVideoUrl = "";
    private String currentFeature = "";
    private String requestID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCommonResultScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this, false);

        requestID = getIntent().getStringExtra(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT);
        currentFeature = getIntent().getStringExtra(AppConfig.INTENT_FEATURED_PASSED_AS);

        setupClickListeners();

        Log.e("ResultScreen", "CommonResultScreen.currentFeature:" + currentFeature);
        if (currentFeature != null) {
            switch (currentFeature) {
                case AppConfig.FEATURE_COUPLE:
                case AppConfig.FEATURE_INDIVISUAL:
                case AppConfig.FEATURE_AI_VIDEO_SINGLE:
                    currentImageUrl = "";
                    isOutputImage = false;
                    callVideoPlayerAndDownloading(requestID, new ResponseCallBack() {
                        @Override
                        public void onSuccess(String response) {
                            Log.e("ResultScreen", "onSuccess.currentVideoUrl:" + currentVideoUrl);
                            currentVideoUrl = response;
                        }

                        @Override
                        public void onError(String errorMessage) {

                        }
                    });
                    break;
                case AppConfig.FEATURE_BABY_BOY:
                case AppConfig.FEATURE_BABY_GIRL:
                    isOutputImage = true;
                    currentImageUrl = "https://babygenerator.aapthi.in/results/babyfeatures/NaturePhotoFramesandEditor/" + requestID;
                    loadingAiBabyEffect(requestID);
                    break;
                case AppConfig.FEATURE_FACESWAP:
                    currentImageUrl = "https://faceswap.aapthi.in/examples/results/" + AppConfig.DEFAULT_APP_NAME + "/" + requestID;
                    Log.e("ResultApi", "FEATURE_FACESWAP.currentImageUrl:" + currentImageUrl);
                    loadingFaceSwapImage(requestID);
                    break;
                case AppConfig.FEATURE_FACE_DANCE:
                    currentImageUrl = "";
                    isOutputImage = false;
                    callFaceDanceAndPlay(requestID, new ResponseCallBack() {
                        @Override
                        public void onSuccess(String response) {
                            Log.e("FaceDance", "ResultScreen onSuccess.currentVideoUrl:" + currentVideoUrl);
                            currentVideoUrl = response;
                        }

                        @Override
                        public void onError(String errorMessage) {
                            finish();
                            Log.e("FaceDance", "ResultScreen onError.errorMessage:" + errorMessage);
                        }
                    });
                    break;
                case AppConfig.FEATURE_TRANSE_FACE_SWAP:
                    isOutputImage = true;
                    currentImageUrl = "https://cartoon-testapi.faceswapmagic.com/stablediff_results/" + AppConfig.DEFAULT_APP_NAME + "/" + requestID;
                    Log.e("ResultApi", "FEATURE_TRANSE_FACE_SWAP.currentImageUrl:" + currentImageUrl);
                    loadingVisionaryImage(requestID);
                    break;
                case AppConfig.FEATURE_CHANGE_BG:
                case AppConfig.FEATURE_REMOVE_BG:
                    isOutputImage = true;
                    currentImageUrl = "https://faceswapmagic.com/pixellab/examples/results/NaturePhotoFramesandEditor/" + requestID;
                    loadRemoveBGImage(requestID);
                    break;
                case AppConfig.FEATURE_AIENHANCER:
                    isOutputImage = true;
                    currentImageUrl = "https://enhance.faceswapmagic.com/pixellab/examples/results/NaturePhotoFramesandEditor/" + requestID;
                    loadImageEnhancerPhoto(requestID);
                    break;
                default:
                    break;
            }
        }
        PhotoUploadManager.getInstance().clear();
        Methods.INSTANCE.finishCommonProcessingActivity();
        Methods.INSTANCE.finishCropActivity();
//
//        if(isOutputImage) binding.ivPreview.setVisibility(View.VISIBLE);
//        else binding.ivPreview.setVisibility(View.GONE);
    }


    @Override
    public void onBackPressed() {
        saveAndExit();
//        super.onBackPressed();
    }


    private void saveAndExit() {
        if (!isImageSaved) {
            new ConfirmDialog(CommonResultScreen.this, 0, new Function1<Boolean, Unit>() {
                @Override
                public Unit invoke(Boolean isSave) {
                    if (isSave) {
                        showAdThenSave();
                    } else {
                        finish();
                    }
                    return null;
                }
            }).show();
        } else {
            finish();
        }
    }

    private void setupClickListeners() {
//        initAdLoadingDialog();
        loadAds();
        binding.buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveAndExit();
            }
        });

        binding.ivPreview.setOnClickListener(v -> {

            if (isOutputImage) {
                Methods.INSTANCE.showImagePreviewDialog(CommonResultScreen.this, currentImageUrl);
            } else {
                Methods.INSTANCE.showVideoPreviewDialog(CommonResultScreen.this, currentVideoUrl);
            }
        });
        binding.saveButton.setOnClickListener(v -> {
            showAdThenSave();
        });
        binding.shareButton.setOnClickListener(v -> {
            if (isOutputImage) {
                shareImage();
            } else {
                shareVideo();
            }

        });

        binding.buttonSupport.setOnClickListener(v -> Methods.INSTANCE.showFeedbackDialog(this));

        binding.togglePlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.videoView.isPlaying()) {
                    binding.videoView.pause();
                } else {
                    binding.videoView.start();
                }
            }
        });
        binding.togglePlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.videoView.isPlaying()) {
                    binding.togglePlay.setImageResource(R.drawable.ic_pause);
                    binding.videoView.pause();
                } else {
                    binding.togglePlay.setImageResource(R.drawable.ic_play_vector);
                    binding.videoView.start();
                }
            }
        });
        binding.muteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("ResultScreen", "muteButton.currentFeature:" + currentFeature);
                if (currentFeature.equals(AppConfig.FEATURE_FACE_DANCE)) {
                    faceDancePlayer.toggleMute();
                    binding.muteButton.setImageResource(
                            faceDancePlayer.isMuted()
                                    ? R.drawable.ic_volume_off
                                    : R.drawable.ic_volume_on
                    );
                } else {
                    player.toggleMute();
                    binding.muteButton.setImageResource(
                            player.isMuted()
                                    ? R.drawable.ic_volume_off
                                    : R.drawable.ic_volume_on
                    );
                }

            }
        });
        // Social media share buttons
        binding.instagramShare.setOnClickListener(v -> shareToSocialMedia("com.instagram.android"));
        binding.facebookShare.setOnClickListener(v -> shareToSocialMedia("com.facebook.katana"));
        binding.whatsappShare.setOnClickListener(v -> shareToSocialMedia("com.whatsapp"));
        binding.twitterShare.setOnClickListener(v -> shareToSocialMedia("com.twitter.android"));
        binding.snapchatShare.setOnClickListener(v -> shareToSocialMedia("com.snapchat.android"));
    }

    int radius = 24;

    private void loadImageEnhancerPhoto(String requestID) {
//        Glide.with(CommonResultScreen.this).load(currentImageUrl).centerCrop().into(binding.generatedImage);
        loadFinalImageFromUrl(currentImageUrl);
//        Glide.with(this)
//                .load(currentImageUrl)
//                .apply(new RequestOptions().transform(new RoundedCorners(radius)))
//                .into(binding.generatedImage);
    }


    Bitmap currentBitmap;

    public void loadFinalImageFromUrl(String currentUrl) {
        Glide.with(this).asBitmap().load(currentUrl).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                try {
                    currentBitmap = bitmap;
                    binding.generatedImage.setImageBitmap(getRoundedBitmap(bitmap, 25));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onLoadCleared(Drawable placeholder) {
            }
        });
    }

    public static Bitmap getRoundedBitmap(Bitmap bitmap, float radius) {
        Bitmap output = Bitmap.createBitmap(
                bitmap.getWidth(),
                bitmap.getHeight(),
                Bitmap.Config.ARGB_8888
        );

        Canvas canvas = new Canvas(output);
        Paint paint = new Paint();
        paint.setAntiAlias(true);

        BitmapShader shader = new BitmapShader(
                bitmap,
                Shader.TileMode.CLAMP,
                Shader.TileMode.CLAMP
        );
        paint.setShader(shader);

        RectF rect = new RectF(
                0f, 0f,
                bitmap.getWidth(),
                bitmap.getHeight()
        );

        canvas.drawRoundRect(rect, radius, radius, paint);
        return output;
    }

    public void playPauseForAd(boolean pause) {
        if (pause) {
            binding.videoView.pause();
        } else {
            binding.videoView.start();
        }
    }

    DownloadVideoAndPlay player;

    private void callVideoPlayerAndDownloading(String requestID, ResponseCallBack responseCallBack) {
        Log.e("ResultScreen", "callVideoPlayerAndDownloading");
        binding.generatedImage.setVisibility(View.GONE);
//        binding.togglePlay.setVisibility(View.VISIBLE);
//        binding.muteButton.setVisibility(View.VISIBLE);
        player = DownloadVideoAndPlay.getInstance(CommonResultScreen.this);
        player.makeRequest(AppConfig.DEFAULT_APP_NAME, requestID, binding.loadingProgressBar, binding.progressBar, binding.videoView, responseCallBack);
    }

    FaceDanceDownloadVideoAndPlay faceDancePlayer;

    private void callFaceDanceAndPlay(String requestID, ResponseCallBack responseCallBack) {
        Log.e("FaceDance", "callFaceDanceAndPlay");
        binding.generatedImage.setVisibility(View.GONE);
//        binding.togglePlay.setVisibility(View.VISIBLE);
//        binding.muteButton.setVisibility(View.VISIBLE);
        faceDancePlayer = FaceDanceDownloadVideoAndPlay.getInstance(CommonResultScreen.this);
        faceDancePlayer.makeRequest("NaturePhotoFramesandEditor", requestID, binding.loadingProgressBar, binding.progressBar, binding.videoView, responseCallBack);
    }

    private void loadingAiBabyEffect(String requestID) {
        loadFinalImageFromUrl(currentImageUrl);
//        Glide.with(CommonResultScreen.this).load(currentImageUrl).centerCrop().into(binding.generatedImage);
//        Glide.with(this)
//                .load(currentImageUrl)
//                .apply(new RequestOptions()
//                        .transform(new RoundedCorners(radius)))
//                .into(binding.generatedImage);
    }

    private void loadRemoveBGImage(String requestID) {
        loadFinalImageFromUrl(currentImageUrl);
//        Glide.with(CommonResultScreen.this).load(currentImageUrl).centerCrop().into(binding.generatedImage);
//        Glide.with(this)
//                .load(currentImageUrl)
//                .apply(new RequestOptions()
//                        .transform(new RoundedCorners(radius)))
//                .into(binding.generatedImage);
    }

    private void loadingFaceSwapImage(String requestID) {
        loadFinalImageFromUrl(currentImageUrl);
//        Glide.with(CommonResultScreen.this).load(currentImageUrl).centerCrop().into(binding.generatedImage);
//        Glide.with(this)
//                .load(currentImageUrl)
//                .apply(new RequestOptions()
//                        .transform(new RoundedCorners(radius)))
//                .into(binding.generatedImage);
    }

    private void loadingVisionaryImage(String requestID) {
        loadFinalImageFromUrl(currentImageUrl);
//        Glide.with(CommonResultScreen.this).load(currentImageUrl).centerCrop().into(binding.generatedImage);
//        Glide.with(this)
//                .load(currentImageUrl)
//                .apply(new RequestOptions()
//                        .transform(new RoundedCorners(radius)))
//                .into(binding.generatedImage);
    }

    private void saveVideoToGallery() {

        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "Imagic_vid_" + System.currentTimeMillis() + ".mp4");
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/AiMagic");

        Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);

        if (uri == null) {
            Toast.makeText(this, "Failed to create video file", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            InputStream input = getInputStreamFromPath(currentVideoUrl);
            OutputStream output = getContentResolver().openOutputStream(uri);
            byte[] buffer = new byte[8192];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }

            Toast.makeText(this, "Video saved to gallery", Toast.LENGTH_SHORT).show();
            isImageSaved = true;
            updateSaveButtonState();
            playPauseForAd(false);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save video", Toast.LENGTH_SHORT).show();
        }
    }


    private void loadAds() {
        String interAdId = getString(R.string.inter_ad);
        new AdmobIntersAdImpl().load(this, interAdId, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean isLoaded) {
                Log.d("TAG", "Interstitial loaded: " + isLoaded);
                return Unit.INSTANCE;
            }
        });
    }

//    private void showAdLoading() {
//        if (adLoadingDialog != null && !adLoadingDialog.isShowing()) {
//            adLoadingDialog.show();
//        }
//    }
//
//    private void hideAdLoading() {
//        if (adLoadingDialog != null && adLoadingDialog.isShowing()) {
//            adLoadingDialog.dismiss();
//        }
//    }

//    private void showAdThenSave() {
//        AdsConfig.Companion.showInterstitialAd(this, new Function1<Boolean, Unit>() {
//            @Override
//            public Unit invoke(Boolean shown) {
//                saveMedia();
//                return Unit.INSTANCE;
//            }
//        });
//    }

    private void showAdThenSave() {
        if (!isOutputImage) playPauseForAd(true);
        AdsConfig.Companion.showInterstitialAd(this, new Function1<Boolean, Unit>() {
            @Override
            public Unit invoke(Boolean aBoolean) {
                if (isOutputImage) {
                    saveImageToGallery();
                } else {
                    saveVideoToGallery();
                }
                return null;
            }
        });
    }

    private void saveImageToGallery() {
        if (isImageSaved) {
            Toast.makeText(this, "Image already saved", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the bitmap from the ImageView
        Bitmap bitmap = currentBitmap;
        if (currentBitmap == null) {
            binding.generatedImage.setDrawingCacheEnabled(true);
            binding.generatedImage.buildDrawingCache();
            bitmap = binding.generatedImage.getDrawingCache();
        }

        if (bitmap != null) {
            try {
                String storageDirPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getPath() + "/AiMagic/";

                File storageDir = new File(storageDirPath);
                if (!storageDir.exists()) {
                    storageDir.mkdirs(); // ✅ create folder
                }

                File imageFile = new File(storageDir, "Imagic_img_" + System.currentTimeMillis() + ".jpg");

                FileOutputStream outputStream = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();
//
//                // Notify the system that a new image has been added
                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                mediaScanIntent.setData(Uri.fromFile(imageFile));
                sendBroadcast(mediaScanIntent);
//
                isImageSaved = true;
                updateSaveButtonState();
//
                Toast.makeText(this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
            }
        } else {
            // If we don't have a bitmap, download and save it
            downloadAndSaveImage();
        }
    }

    private InputStream getInputStreamFromPath(String path) throws Exception {

        if (path.startsWith("content://")) {
            return getContentResolver().openInputStream(Uri.parse(path));
        }

        if (path.startsWith("file://")) {
            return new FileInputStream(new File(Uri.parse(path).getPath()));
        }

        // normal file path
        return new FileInputStream(new File(path));
    }


    private void downloadAndSaveImage() {
        Glide.with(this).asBitmap().load(currentImageUrl).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                try {
                    File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                    File imageFile = new File(storageDir, "Imagic_" + System.currentTimeMillis() + ".jpg");

                    FileOutputStream outputStream = new FileOutputStream(imageFile);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                    outputStream.flush();
                    outputStream.close();

                    // Notify the system that a new image has been added
                    Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    mediaScanIntent.setData(Uri.fromFile(imageFile));
                    sendBroadcast(mediaScanIntent);

                    isImageSaved = true;
                    updateSaveButtonState();

                    Toast.makeText(CommonResultScreen.this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(CommonResultScreen.this, "Failed to save image", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onLoadCleared(Drawable placeholder) {
            }
        });
    }

    private void updateSaveButtonState() {
        if (isImageSaved) {
            binding.saveButton.setAlpha(0.5f);
            binding.saveButton.setClickable(false);
        } else {
            binding.saveButton.setAlpha(1.0f);
            binding.saveButton.setClickable(true);
        }
    }

    private void shareImage() {
        // Get the bitmap from the ImageView
        binding.generatedImage.setDrawingCacheEnabled(true);
        binding.generatedImage.buildDrawingCache();
        Bitmap bitmap = binding.generatedImage.getDrawingCache();

        if (bitmap != null) {
            try {
                // Save the image to cache
                File cachePath = new File(getCacheDir(), "images");
                cachePath.mkdirs();
                File file = new File(cachePath, "shared_image.jpg");
                FileOutputStream outputStream = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();

                // Share the image
                Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/jpeg");
                shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share image via"));
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to share image", Toast.LENGTH_SHORT).show();
            }
        } else {
            // If we don't have a bitmap, share the URL
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, currentImageUrl);
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        }
    }

    private void shareVideo() {
        try {
            File videoFile = new File(currentVideoUrl);

            if (!videoFile.exists()) {
                Toast.makeText(this, "Video file not found", Toast.LENGTH_SHORT).show();
                return;
            }

            Uri videoUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".provider",
                    videoFile
            );

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("video/*");
            shareIntent.putExtra(Intent.EXTRA_STREAM, videoUri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            startActivity(Intent.createChooser(shareIntent, "Share video via"));

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Unable to share video", Toast.LENGTH_SHORT).show();
        }
    }


    private File getSharedImageFile() throws IOException {

        File cachePath = new File(getCacheDir(), "share");
        cachePath.mkdirs();

        File file = new File(cachePath, "image.jpg");

        Bitmap bitmap = ((BitmapDrawable) binding.generatedImage.getDrawable()).getBitmap();

        FileOutputStream fos = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        fos.close();

        return file;
    }

    private void shareToSocialMedia(String packageName) {
        Log.e("ResultScreen", "CommonResult:" + packageName);

        try {
            getPackageManager().getPackageInfo(packageName, 0);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setPackage(packageName);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            Uri uri;
            String mimeType;

            if (isOutputImage) {
                // IMAGE SHARE
                File file = getSharedImageFile();
                uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
                mimeType = "image/jpeg";

            } else {
                // VIDEO SHARE
                File videoFile = new File(currentVideoUrl);
                uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", videoFile);
                mimeType = "video/mp4";
            }

            shareIntent.setType(mimeType);
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.setClipData(ClipData.newRawUri("", uri));

            startActivity(shareIntent);

        } catch (Exception e) {
            Log.e("ResultScreen", "CommonResult.Exception:" + e);
            //e.printStackTrace();
            Toast.makeText(this, "App not installed or cannot share", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareToSocialMedia1(String packageName) {
        // Check if the app is installed
        try {
            getPackageManager().getPackageInfo(packageName, 0);

            // Get the bitmap from the ImageView
            binding.generatedImage.setDrawingCacheEnabled(true);
            binding.generatedImage.buildDrawingCache();
            Bitmap bitmap = binding.generatedImage.getDrawingCache();

            if (bitmap != null) {
                try {
                    // Save the image to cache
                    File cachePath = new File(getCacheDir(), "images");
                    cachePath.mkdirs();
                    File file = new File(cachePath, "shared_image.jpg");
                    FileOutputStream outputStream = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                    outputStream.flush();
                    outputStream.close();

                    // Share to specific app
                    Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);

                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("image/jpeg");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                    shareIntent.setPackage(packageName);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(shareIntent);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Failed to share image", Toast.LENGTH_SHORT).show();
                }
            } else {
                // If we don't have a bitmap, share the URL
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, currentImageUrl);
                shareIntent.setPackage(packageName);
                startActivity(shareIntent);
            }
        } catch (Exception e) {
            // App is not installed
            Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}