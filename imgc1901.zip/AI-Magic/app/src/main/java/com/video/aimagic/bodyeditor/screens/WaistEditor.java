package com.video.aimagic.bodyeditor.screens;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.video.aimagic.R;
import com.video.aimagic.databinding.ActivityWaistEditorBinding;
import com.video.aimagic.extension.ExtensionsKt;
import com.video.aimagic.singletone.PhotoUploadManager;

import java.util.Stack;

public class WaistEditor extends AppCompatActivity {

    Bitmap saveBitmap;
    Bitmap mBitmap;
    boolean maskareaValuesadded;
    private ActivityWaistEditorBinding binding;
    private float pw;
    private float px;
    private float py;
    private float ratio;
    private float ph;
    private SeekBar.OnSeekBarChangeListener seekBarChangeListener = new seekbarListener();
    private Stack<EditState> undoStack = new Stack<>();
    private Stack<EditState> redoStack = new Stack<>();
    private int lastProgress = 0;
    private boolean isProgrammaticSeekBarChange = false;

    private float[] sourceVerts;
    private float[] warpedVerts;

    private int meshWidth = 10;
    private int meshHeight = 10;

    private int regionStartY;
    private int regionHeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityWaistEditorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        ExtensionsKt.setStatusBarFontColor(this,false);
        mBitmap = PhotoUploadManager.getInstance().getUniversalBitmap();
        setImageAndSeekBar();
        setOnClickListners();
        setupMesh(mBitmap);

    }

    private void setImageAndSeekBar() {
        binding.changeHipsSeekBar.setMin(-10);
        binding.changeHipsSeekBar.setMax(10);
        binding.changeHipsSeekBar.setProgress(0);
        binding.waiseView.imageView = binding.bodyPreviewImage;
        binding.bodyPreviewImage.setImageBitmap(mBitmap);
        binding.changeHipsSeekBar.setOnSeekBarChangeListener(seekBarChangeListener);
    }

    private void setupMesh(Bitmap bitmap) {
        int count = (meshWidth + 1) * (meshHeight + 1) * 2;
        sourceVerts = new float[count];
        warpedVerts = new float[count];

        float bitmapWidth = bitmap.getWidth();
        float bitmapHeight = bitmap.getHeight();

        float dx = bitmapWidth / meshWidth;
        float dy = bitmapHeight / meshHeight;

        int index = 0;
        for (int y = 0; y <= meshHeight; y++) {
            float fy = y * dy;
            for (int x = 0; x <= meshWidth; x++) {
                float fx = x * dx;
                sourceVerts[index * 2] = fx;
                sourceVerts[index * 2 + 1] = fy;
                index++;
            }
        }
    }

    private void calculateMaskArea() {
        if (!maskareaValuesadded) {
            maskareaValuesadded = true;
            float viewWidth = binding.waiseView.getWidth() * binding.waiseView.getScaleX();
            float viewHeight = binding.waiseView.getHeight() * binding.waiseView.getScaleY();
            float viewX = binding.waiseView.getX() + ((binding.waiseView.getWidth() - viewWidth) / 2.0f);
            float viewY = binding.waiseView.getY() + ((binding.waiseView.getHeight() - viewHeight) / 2.0f);

            ratio = (float) mBitmap.getHeight() / (float) binding.implimentedView.getHeight();

            pw = viewWidth;
            ph = viewHeight;
            px = viewX;
            py = viewY;

            regionStartY = (int) (py * ratio);
            regionHeight = (int) (ph * ratio);

            showSeekBarView();
        }
    }

    public void createFilter(int pro) {

        if (saveBitmap != null) {
            undoStack.push(new EditState(saveBitmap, lastProgress));
            PhotoUploadManager.getInstance().setUniversalBitmap(saveBitmap);
            redoStack.clear();
        } else {
            // First time use
            undoStack.push(new EditState(mBitmap, 0));
            redoStack.clear();
        }

        lastProgress = pro;

        applyWaistWarp(pro);

    }

    private void setOnClickListners() {
        binding.undoFace.setOnClickListener(v -> {
            undo();
        });
        binding.reduFace.setOnClickListener(v -> {
            redo();
        });

        binding.applyBtn.setOnClickListener(v -> {
            finish();
        });
    }

    private void updateUndoRedoIcons() {
        if (!undoStack.isEmpty()) {
            binding.undoFace.setImageResource(R.drawable.body_undo_enable);
            binding.undoFace.setEnabled(true);
        } else {
            binding.undoFace.setImageResource(R.drawable.body_undo_disable);
            binding.undoFace.setEnabled(false);
        }

        if (!redoStack.isEmpty()) {
            binding.reduFace.setImageResource(R.drawable.body_redu_enable);
            binding.reduFace.setEnabled(true);
        } else {
            binding.reduFace.setImageResource(R.drawable.body_redu_disable);
            binding.reduFace.setEnabled(false);
        }
    }

    public void undo() {
        if (!undoStack.isEmpty()) {
            redoStack.push(new EditState(saveBitmap, lastProgress));

            EditState previous = undoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(previous.bitmap);
            saveBitmap = previous.bitmap;
            lastProgress = previous.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeHipsSeekBar.setProgress(previous.progress);
            isProgrammaticSeekBarChange = false;

        }
    }

    public void redo() {
        if (!redoStack.isEmpty()) {
            undoStack.push(new EditState(saveBitmap, lastProgress));

            EditState next = redoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(next.bitmap);
            saveBitmap = next.bitmap;
            lastProgress = next.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeHipsSeekBar.setProgress(next.progress); // <-- Update SeekBar
            isProgrammaticSeekBarChange = false;


        }
    }

    private void showSeekBarView() {

        binding.changeHipsSeekBar.setVisibility(View.VISIBLE);

    }

    private void applyWaistWarp(long progress) {
        float strength = progress / 30f; // range: -1 to +1
        System.arraycopy(sourceVerts, 0, warpedVerts, 0, sourceVerts.length);

        float bitmapWidth = mBitmap.getWidth();
        float bitmapHeight = mBitmap.getHeight();

        float regionStartX = px * ratio;
        float regionWidth = pw * ratio;

        float centerX = regionStartX + (regionWidth / 2f); // center of binding.waiseView only
        float maxOffset = regionWidth * 0.5f; // max offset within binding.waiseView bounds

        for (int i = 0; i < warpedVerts.length; i += 2) {
            float x = sourceVerts[i];
            float y = sourceVerts[i + 1];

            // Only apply warp inside the waist region (vertically and horizontally)
            if (y > regionStartY && y < regionStartY + regionHeight &&
                    x > regionStartX && x < regionStartX + regionWidth) {

                float distanceFromCenter = x - centerX;
                float normalizedDistance = distanceFromCenter / (regionWidth / 2f); // -1 to +1

                float verticalFactor = (float) Math.sin(((y - regionStartY) / (float) regionHeight) * Math.PI);

                float offset = -normalizedDistance * maxOffset * strength * verticalFactor;

                warpedVerts[i] = x + offset;
            }
        }

        Bitmap output = Bitmap.createBitmap((int) bitmapWidth, (int) bitmapHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmapMesh(mBitmap, meshWidth, meshHeight, warpedVerts, 0, null, 0, paint);
        binding.bodyPreviewImage.setImageBitmap(output);
        saveBitmap = output;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }

    class seekbarListener implements SeekBar.OnSeekBarChangeListener {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
            if (isProgrammaticSeekBarChange) return;
            // getMaskValues();
            calculateMaskArea();
            int progressss = seekBar.getProgress();
            progressss = progressss * -1;
            createFilter(progressss);
            if (binding.applyBtn.getVisibility() == View.GONE) {
                binding.applyBtn.setVisibility(View.VISIBLE);
            }

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            if (isProgrammaticSeekBarChange) return;
            updateUndoRedoIcons();


        }

    }
}