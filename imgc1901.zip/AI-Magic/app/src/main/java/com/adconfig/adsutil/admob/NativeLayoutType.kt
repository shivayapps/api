package com.adconfig.adsutil.admob


enum class NativeLayoutType {
    NativeSmall,
    NativeBanner,
    NativeMedium,
    NativeButtonBottom,
    NativeBig,
}