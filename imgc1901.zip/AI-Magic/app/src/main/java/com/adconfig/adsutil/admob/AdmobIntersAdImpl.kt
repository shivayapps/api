package com.adconfig.adsutil.admob

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.abstract.IntersAd
import com.adconfig.adsutil.utils.AdsError
import com.adconfig.adsutil.utils.AdsListener
import com.adconfig.adsutil.utils.isOnline

class AdmobIntersAdImpl : IntersAd() {

    private val TAG: String = "ADCONFIG_InterAd"
//    var auInterstitialAds = AuInterstitialAds()

    override fun destroy() {
        Config.mInterstitialAd = null
    }

    override fun show(activity: Activity) {
        Log.i(TAG, "show.000")
        if (Config.mInterstitialAd == null) {
            Log.i(TAG, "show.001")
            adsListener?.onAdFailedToShow(AdsError(0, ""))
        } else {
            Log.i(TAG, "show.002")
            Config.mInterstitialAd?.show(activity)
            Config.mInterstitialAd?.fullScreenContentCallback = fullScreenContentCallback
        }
    }


    override fun load(context: Context, mAdId: String, onLoaded: (isLoaded: Boolean) -> Unit) {
        Log.i(TAG, "load:$mAdId")
        if (Config.mInterstitialAd == null) {
            loadInters(context, { isLoaded, message, interstitial ->
                onLoaded.invoke(isLoaded)
                if (isLoaded) {
//                    Config.mInterstitialAd = interstitial
                } else {
                    adsListener?.onAdFailedToShow(AdsError(0, message))
                }
            }, mAdId)
        } else {
            onLoaded.invoke(true)
        }
    }

    private val fullScreenContentCallback = object : FullScreenContentCallback() {
        override fun onAdClicked() {
            super.onAdClicked()
            adsListener?.onAdClicked()
        }

        override fun onAdDismissedFullScreenContent() {
            super.onAdDismissedFullScreenContent()
            adsListener?.onAdDismissed()
        }

        override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
            super.onAdFailedToShowFullScreenContent(adError)
            adsListener?.onAdFailedToShow(AdsError(adError.code, adError.message))
        }

        override fun onAdImpression() {
            super.onAdImpression()
            adsListener?.onAdImpression()
        }

        override fun onAdShowedFullScreenContent() {
            super.onAdShowedFullScreenContent()
            adsListener?.onAdShowed()
        }
    }

    private fun getAdRequest(): AdRequest {
        return AdRequest
            .Builder()
//            .setHttpTimeoutMillis(3000)
            .build()
    }

    private fun loadInters(
        context: Context,
        onLoaded: (isLoaded: Boolean, message: String, interstitial: InterstitialAd?) -> Unit,
        mAdId: String
    ) {
        Log.i(TAG, "loadInters:isOnline:${context.isOnline()}")
        if(!context.isOnline()) {
            onLoaded.invoke(false, "failed:Device Offline", null)
        } else {
            Log.d("LoadAd", "loadInterAd:$mAdId")
            val interAdId = mAdId
            InterstitialAd.load(
                context,
                interAdId,
                getAdRequest(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        super.onAdFailedToLoad(adError)
                        Log.i(
                            TAG,
                            "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                        )
                        onLoaded.invoke(
                            false,
                            "${adError.code}\n${adError.message}\n${adError.responseInfo}",
                            null
                        )

                    }

                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        Log.i(TAG, "onAdLoaded")
                        Config.mInterstitialAd = interstitialAd
                        onLoaded.invoke(true, "Success", interstitialAd)
                    }
                }
            )
        }
    }
}