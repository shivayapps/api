package com.adconfig.adsutil.openad

import android.app.Activity
import android.app.Application
import android.os.Bundle

class OpenAdManager(
    private val myApplication: AppOpenApplication
) : Application.ActivityLifecycleCallbacks {

    var mCurrentActivity: Activity? = null

    init {
        myApplication.registerActivityLifecycleCallbacks(this)
    }

    override fun onActivityResumed(activity: Activity) {
        mCurrentActivity = activity
    }

    override fun onActivityDestroyed(activity: Activity) {

    }

    override fun onActivityStopped(activity: Activity) {
    }

    override fun onActivityStarted(activity: Activity) {

    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {

    }

    override fun onActivityPaused(activity: Activity) {

    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    fun showOpenAd() {
        myApplication.mAppLifecycleListener?.onAppOpenCreatedEvent(mCurrentActivity!!)
       /* mCurrentActivity?.let {
            it.isShowOpenAd({
                Log.i("ADCONFIG_OpenAdManager", "showOpenAd: Ads Close")
            }, onAdLoad = {
                Log.e("Sales2", "gotoMainScreen: onAdLoad")

            }, onAdFailed = {
                Log.e("Sales2", "gotoMainScreen: onAdFailed")


            }, onAdShow = {
//                myApplication.mAppLifecycleListener?.onAppOpenShownEvent(mCurrentActivity!!)
            }, onAdEvent = {
                if (it) {
                    myApplication.mAppLifecycleListener?.onAppOpenShownEvent(mCurrentActivity!!)
                } else {
                    myApplication.mAppLifecycleListener?.onAppOpenFailedEvent(mCurrentActivity!!)

                }

            })
        }*/
    }
}