import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.google.gms.google.services)
    alias(libs.plugins.google.firebase.crashlytics)
    alias(libs.plugins.google.firebase.firebase.perf)
}


fun getTimeStamp(): String {
    val format = SimpleDateFormat("ddMM", Locale.ENGLISH)
    return format.format(Date())
}

android {
    namespace = "com.video.aimagic"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ai.video.art.photo.faceswap"
        minSdk = 26
        targetSdk = 35
        versionCode = 100
        versionName = "100"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        setProperty("archivesBaseName", "iMagic-${getTimeStamp()}")
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = true
            //isDebuggable = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    flavorDimensions("default")
    productFlavors {

        create("TestAd") {
            isDefault = true

            buildConfigField("Boolean", "TEST_ADS", "true")
            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")

            resValue("string", "banner_ad", "ca-app-pub-3940256099942544/9214589741")

            resValue("string", "native_ad", "ca-app-pub-3940256099942544/2247696110")

            resValue("string", "inter_ad", "ca-app-pub-3940256099942544/1033173712")

            resValue("string", "open_ad", "ca-app-pub-3940256099942544/9257395921")

        }
        create("LiveAd") {
            buildConfigField("Boolean", "TEST_ADS", "false")
            resValue("string", "ads_application_id", "ca-app-pub-9792335391559731~1489798682")
            resValue("string", "banner_ad", "ca-app-pub-9792335391559731/9214589741")
            resValue("string", "native_ad", "ca-app-pub-9792335391559731/8518580770")
            resValue("string", "inter_ad", "ca-app-pub-9792335391559731/5992489786")
            resValue("string", "open_ad", "ca-app-pub-9792335391559731/1097904685")
            resValue("string", "reward_ad", "ca-app-pub-9792335391559731/4415344925")
            resValue("string", "banner_ad", "ca-app-pub-9792335391559731/4679408118")
        }
    }


    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
    lint {
        baseline = file("lint-baseline.xml")
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
//        dataBinding = true
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation("androidx.multidex:multidex:2.0.1")

    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)

    implementation(libs.android.sdp)
    implementation(libs.android.ssp)
    implementation(libs.androidx.browser)

    implementation(libs.firebase.crashlytics)
    implementation(libs.firebase.perf)
    implementation(libs.firebase.messaging)
    implementation(libs.firebase.config)

    implementation("com.tbuonomo:dotsindicator:4.3")
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.google.code.gson:gson:2.10.1")
    implementation("androidx.navigation:navigation-fragment:2.4.1")
    implementation("androidx.navigation:navigation-ui:2.4.1")
    annotationProcessor("com.github.bumptech.glide:compiler:4.12.0")
    implementation("com.github.bumptech.glide:glide:4.15.1")
    implementation("com.github.bumptech.glide:okhttp3-integration:4.15.1")
    implementation("com.airbnb.android:lottie:3.4.0")
    implementation("com.vanniktech:android-image-cropper:4.5.0")
//    implementation("com.squareup.retrofit2:retrofit:2.9.0")
//    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
//    implementation("com.squareup.okhttp3:okhttp:4.11.0")
//    implementation("com.squareup.okhttp3:logging-interceptor:4.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.google.android.gms:play-services-mlkit-face-detection:17.1.0")

//    implementation("kim.jujin:fixedorder-staggered-grid-layoutmanager:<version>")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

//    implementation(project(":ads"))
    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:2.6.1")
    implementation("com.google.android.gms:play-services-ads:24.7.0")
    implementation("com.facebook.shimmer:shimmer:0.5.0")

}