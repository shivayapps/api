package com.photogallery.activities

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import androidx.core.view.doOnPreDraw
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
import com.photogallery.BuildConfig
import com.google.android.gms.ads.AdView
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.install.model.InstallStatus
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.photogallery.R
import com.photogallery.activities.exploremap.MapAlbumActivity
import com.photogallery.activities.setup.LanguageActivity
import com.photogallery.adapter.AlbumAdapter
import com.photogallery.adapter.PictureAdapter
import com.photogallery.inapp_helper.AppUpdateInstallerListener
import com.photogallery.inapp_helper.AppUpdateInstallerManager
import com.photogallery.inapp_helper.InAppUpdateInstallerManager
import com.photogallery.base.BaseActivity
//import com.photogallery.browser.WebBrowserActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityHomeBinding
import com.photogallery.databinding.HomeMenuFilterBinding
import com.photogallery.databinding.PopBottomMenuBinding
import com.photogallery.dialog.AlbumDetailsDialog
import com.photogallery.dialog.ConfirmationDialog

import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.DetailsDialog
import com.photogallery.dialog.DisplayedColumnsDialog
import com.photogallery.dialog.ExitDialog
import com.photogallery.dialog.FilterMediaDialog
import com.photogallery.dialog.GroupDialog
import com.photogallery.dialog.HomeMenuDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.RenameDialog
import com.photogallery.dialog.RenameFolderDialog
import com.photogallery.dialog.ResizeDialog
import com.photogallery.dialog.SelectAlbumFullDialog
import com.photogallery.dialog.SelectAlbumImageFullDialog
import com.photogallery.dialog.SimpleMessageDialog
import com.photogallery.dialog.SimpleProgressDialog
import com.photogallery.dialog.SortDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.delayExecution
import com.photogallery.extension.getFinalUriFromPath
import com.photogallery.extension.getUriMimeType
import com.photogallery.extension.initFirebaseConfig
import com.photogallery.extension.isGif
import com.photogallery.extension.openEditorIntent
import com.photogallery.extension.scanPathRecursively
import com.photogallery.extension.showErrorToast
import com.photogallery.extension.showHomeNotification
import com.photogallery.extension.toast
import com.photogallery.helper.SettingPermissionActivity
import com.photogallery.jobs.MediaContentObserver
//import com.photogallery.fragment.AlbumFragment
//import com.photogallery.fragment.PhotosFragment
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.jobs.autoclean.startAutoCleanTrashWorker
import com.photogallery.jobs.fetchRecentMedia
import com.photogallery.jobs.startPlacesFetcher
import com.photogallery.mainduplicate.DuplicateFinderActivity
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.model.PlaceData
import com.photogallery.notes.NotesActivity
import com.photogallery.recover.RecoverMediaActivity
import com.photogallery.secret.activity.LockActivity
import com.photogallery.secret.activity.PrivateActivity
import com.photogallery.secret.activity.SelectImageActivity
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.MAX_COLUMN_COUNT_ALBUM
import com.photogallery.utils.MAX_COLUMN_COUNT_PICTURE
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.Utils
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.utils.sendEvent
import com.photogallery.viewpager.PhotoVideoActivity
import com.photogallery.views.CommonPagerAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest.*
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfig.*
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.single.PermissionListener
import com.photogallery.adapter.PlaceAdapter
import com.photogallery.adapter.TimeLineAdapter
import com.photogallery.database.LocationEntity
import com.photogallery.extension.sendEmail
import com.photogallery.jobs.TimeLineLoaderX
import com.photogallery.views.bottomnav.NiceBottomBar
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class HomeActivity : BaseActivity() {

    lateinit var preferences: Preferences

    var selectedPhotosCount = 0
    var selectedAlbumCount = 0
    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()
    var pictureAdapter: PictureAdapter? = null

    var albumList: ArrayList<AlbumData> = ArrayList()
    var albumAdapter: AlbumAdapter? = null

    lateinit var mAdmobNative: AdmobNative

    var isFromNotification = false
    var mActivityName = ""

    //    var dataBase: AppDatabase? = null
    private val dataBase: AppDatabase by lazy { AppDatabase.getInstance(this) }

    val pinList: ArrayList<String> = ArrayList()
    var isEmptyPhoto = false
    var isEmptyAlbum = false

    private var googleMap: GoogleMap? = null
    var isMarkerAdded = false
//    var isMapLoaded = false
//    var placeList: ArrayList<PlaceData> = ArrayList()
//    var mapPlace: ArrayList<String> = ArrayList()

    var timeList: ArrayList<AlbumData> = ArrayList()
    var timeLineAdapter: TimeLineAdapter? = null

    var placeList: ArrayList<PlaceData> = ArrayList()
    var placeAdapter: PlaceAdapter? = null

    var albumLoader: MediaLoaderX? = null
    var photosLoader: MediaLoaderX? = null
    var timeLineLoader: TimeLineLoaderX? = null

    private var mAlbumZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mAlbumDragListener: MyRecyclerView.MyDragListener? = null

    private var mPhotoZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mPhotosDragListener: MyRecyclerView.MyDragListener? = null

    private var lastLongPressedMedia = -1
    private var lastLongPressedAlbum = -1
    var needRefreshMedia = false
    var isSelectAll = false
    var imageFilePath = ""
    var tabPos = 0
    lateinit var binding: ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkNotification(intent)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferences = Preferences(this)

        //initMap(savedInstanceState)

        initView()
        startNewPhotoFetcher()
        startCleanRecycleBin()

        loadBannerAds()
//        getData()

        setRvLayoutManager()
        albumLoader = MediaLoaderX(
            this,
            sortOrder = preferences.getSortOrder("frag_0"),
            sortType = preferences.getSortType("frag_0"),
            addCustomAlbum = true,
            prefKey = "frag_0"
        )
        photosLoader = MediaLoaderX(
            this,
            sortOrder = preferences.getSortOrder("frag_1"),
            sortType = preferences.getSortType("frag_1"),
            loadImage = true,
            loadVideo = false,
            prefKey = "frag_1"
        )
        timeLineLoader = TimeLineLoaderX(
            this,
            sortOrder = preferences.getSortOrder("frag_0"),
            sortType = preferences.getSortType("frag_0"),
            prefKey = "frag_0"
        )

        sendEvent("get_data")
        startPlacesFetcher()

        //delayExecution(800) {
        initMapData()
        //}
        setExploreData()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("get_data")) {
            getData()
        }
//        if (event.type.equals("refresh_map")) {
//            initMapData()
//        }
        if (event.type.equals("hideCamera")) {
            runOnUiThread {
                toggleCameraVisibility()
            }
        }
        if (event.type.equals("rename")) {
            if (event.data is String) scanPathRecursively(event.data)
        }
        if (event.type.equals("refresh_layoutmanager")) {
            delayExecution(800) {
                setRvLayoutManager()
//                if (albumFragment != null) albumFragment.setRvLayoutManager()
//                if (photosFragment != null) photosFragment.setRvLayoutManager()
            }
        }
        if (event.type.equals("refresh")) {
            needRefreshMedia = true
            preferences.refreshMedia = true
//            delayExecution(50) {
//                if (albumFragment != null) albumFragment.refreshData()
//                if (photosFragment != null) photosFragment.refreshData()
//            }
        }
    }

    private fun getData() {
        albumLoader?.refreshLoader("frag_0")
        photosLoader?.refreshLoader("frag_1")
        timeLineLoader?.refreshLoader("frag_0")
        getAlbumData()
        getPhotoData()
        getSearchData()
        //detectRegion()
        binding.drawerContent.tvAppVersion.text = BuildConfig.VERSION_NAME
    }

    private fun detectRegion() {
        val region = Locale.getDefault().country
        Log.d("detectRegion", "Device Region: $region")

        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val simCountry = telephonyManager.simCountryIso?.uppercase(Locale.US)
        val networkCountry = telephonyManager.networkCountryIso?.uppercase(Locale.US)

        Log.d("detectRegion", "SIM Country: $simCountry, Network Country: $networkCountry")
    }

//    private fun initMap(savedInstanceState: Bundle?) {
//        try {
//            binding.exploreTab.map.onCreate(savedInstanceState)
//            binding.exploreTab.map.getMapAsync { map ->
////                map.uiSettings.setAllGesturesEnabled(false)
//                isMapLoaded = true
//                googleMap = map
////            googleMap?.isMyLocationEnabled = true
//                googleMap?.setOnMarkerClickListener { marker ->
//                    val intent = Intent(this@HomeActivity, MapExploreActivity::class.java)
//                    intent.putExtra("pos", 0)
//                    startActivity(intent)
//                    true
//                }
//                getImageOnMap()
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }

    private fun initMapData() {
//        try {
//            //CoroutineScope(Dispatchers.IO).launch {
//            val places = dataBase.dataDao().getLocationEntityList()
//            val sortedPlaces = places.sortedByDescending { it.locationId }
//            if (sortedPlaces.isNotEmpty()) {
//                sortPlaceList(sortedPlaces)
//            }
//            //}
//        } catch (e: Exception) {
//            Log.e("XXPermissions", "getAllImagesFromGallery:::exception.001:$e")
//        }
    }

//    private fun sortPlaceList(locationList: List<LocationEntity>) {
//        Log.e("XXPermissions", "sortImage:::placeList.${locationList.size}")
//        //binding.exploreTab.llPlaces.beVisibleIf(locationList.size > 0)
//        CoroutineScope(Dispatchers.IO).launch {
//            locationList.forEach { data ->
//                try {
//                    val strKey = data.title
//                    var imagesData1: ArrayList<MediaData> = ArrayList()
//                    val file = File(data.path)
//                    if (file.exists()) {
//                        try {
//                            val mediaData = MediaData(
//                                file.path,
//                                file.name,
//                                file.parentFile.name,
//                                file.lastModified(),
//                                file.lastModified(),
//                                file.length()
//                            )
//                            for (i in placeList.indices) {
//                                if (placeList[i].place == strKey) {
//                                    placeList[i].pictureData.add(mediaData)
//                                }
//                            }
//
//                            if (placeList.filter { it.place == strKey }.isNullOrEmpty()) {
//                                imagesData1.add(mediaData)
//                                val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
//                                placeList.add(placeData)
//                                mapPlace.add(mediaData.filePath)
//                            }
//                        } catch (e: Exception) {
//                        }
//                    } else {
//                        try {
//                            dataBase.dataDao().deleteLocationEntity(data)
//                        } catch (e: Exception) {
//                        }
//                    }
//                } catch (e: Exception) {
//                }
//            }
//
//            //mapPlaces()
//        }
//    }

//    private fun mapPlaces() {
//        runOnUiThread {
//            if (mapPlace.isNotEmpty()) {
//                if (mapPlace.size > 0) {
//                    Glide.with(applicationContext!!)
//                        .load(mapPlace[0])
//                        .placeholder(R.drawable.ic_image_placeholder)
//                        .into(binding.exploreTab.image1)
//                }
//
//                if (mapPlace.size > 1) {
//                    Glide.with(applicationContext!!)
//                        .load(mapPlace[1])
//                        .placeholder(R.drawable.ic_image_placeholder)
//                        .into(binding.exploreTab.image2)
//                }
//
//                if (mapPlace.size > 2) {
//                    Glide.with(applicationContext!!)
//                        .load(mapPlace[2])
//                        .placeholder(R.drawable.ic_image_placeholder)
//                        .into(binding.exploreTab.image3)
//                }
//                if (mapPlace.size > 3) {
//                    Glide.with(applicationContext!!)
//                        .load(mapPlace[3])
//                        .placeholder(R.drawable.ic_image_placeholder)
//                        .into(binding.exploreTab.image4)
//                }
//
//            }
//        }
//    }

    private fun getAlbumData() {

        binding.albumTab.albumRecycler.suppressLayout(true)
        binding.albumTab.swipeRefreshAlbum.isRefreshing = true
        albumLoader?.destroyLoader()
        albumLoader?.getAllAlbum({ customAlbumList, allAlbumList, mediaList ->
            albumList.clear()
            albumList.addAll(customAlbumList)
            Constant.deviceAlbumList.clear()
            Constant.deviceAlbumList.addAll(allAlbumList)

            Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")

            runOnUiThread {
                binding.albumTab.albumRecycler.suppressLayout(false)
                binding.albumTab.swipeRefreshAlbum.isRefreshing = false
                setAlbumData()
            }
        })

        val isGridShow = preferences.getShowGrid() ?: false
        if (isGridShow) {
            val layoutManager = binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager
            mAlbumZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceAlbumGrid()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_ALBUM) {
                        increaseAlbumGrid()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mAlbumZoomListener = null
        }
        binding.albumTab.albumRecycler.setupZoomListener(mAlbumZoomListener)

        mAlbumDragListener = object : MyRecyclerView.MyDragListener {

            override fun selectItem(position: Int) {
                toggleAlbumSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int, lastDraggedIndex: Int, minReached: Int, maxReached: Int,
            ) {
                selectAlbumRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedAlbum = -1
                }
            }

        }
        binding.albumTab.albumRecycler.setupDragListener(mAlbumDragListener)
    }

    private fun getSearchData() {
        timeLineLoader?.destroyLoader()
        timeLineLoader?.getAllData({ groupedMediaList, mediaList, customAlbumList ->
            timeList.clear()
            timeList.addAll(customAlbumList)

            Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")

            runOnUiThread {
                binding.searchTab.timeLineRecycler.suppressLayout(false)
                //binding.searchTab.swipeRefreshAlbum.isRefreshing = false
                setSearchData()
            }
        })

        placeAdapter = PlaceAdapter(
            this, placeList,
            clickListener = {
                val albumData = placeList[it]
                openPlaceList(albumData)
            })

        binding.searchTab.recyclerViewPlace.adapter = placeAdapter


        binding.searchTab.recyclerViewPlace.layoutManager =
            GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false)
        binding.searchTab.recyclerViewPlace.setHasFixedSize(false)

//        val layoutManager = binding.searchTab.recyclerViewPlace.layoutManager as MyGridLayoutManager
//        layoutManager.orientation = RecyclerView.VERTICAL
//        layoutManager.spanCount = 3


        //dataBase = AppDatabase.getInstance(activity)
        dataBase.dataDao().getLocationLiveEntityList()
            .observe(this) { places: List<LocationEntity> ->
                sortPlace(places)
            }

    }

    private fun openPlaceList(placeData: PlaceData) {

        Constant.albumData = AlbumData(
            placeData.place,
            placeData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(this, ImageListActivity::class.java)
        intent.putExtra("isFromMap", true)
        intent.putExtra("lati", placeData.lati)
        intent.putExtra("long", placeData.long)
        startActivity(intent)
    }

    private fun sortPlace(placeList: List<LocationEntity>) {
//        val placeList = dataBase.dataDao().getLocationEntityList()
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")
        this.placeList.clear()
        placeList.forEach { data ->

            val strKey = data.title

            var imagesData1: ArrayList<MediaData> = ArrayList()

            val file = File(data.path)
            if (file.exists()) {

                val pictureData = MediaData(
                    file.path,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in this.placeList.indices) {
                    if (this.placeList[i].place == strKey) {
                        this.placeList[i].pictureData.add(pictureData)
                    }
                }

                if (this.placeList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(pictureData)
                    val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    this.placeList.add(placeData)
                }
            } else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }

        runOnUiThread {
            if (placeAdapter != null) {
                placeAdapter?.notifyDataSetChanged()
            }
        }
        //setEmptyData()
    }

    private fun getPhotoData() {
        binding.photosTab.pictureRecycler.suppressLayout(true)
        binding.photosTab.swipeRefreshPhotos.isRefreshing = true
        photosLoader?.destroyLoader()
        photosLoader?.getAllMedia(onSuccess = { groupedMediaList, mediaList ->
            allList.clear()
            allList.addAll(mediaList)

            pictures.clear()
            pictures.addAll(groupedMediaList)

            runOnUiThread {
                binding.photosTab.pictureRecycler.suppressLayout(false)
                binding.photosTab.swipeRefreshPhotos.isRefreshing = false
                setPhotoData()
            }
        })
    }

    private fun openCutomImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(this, ImageListActivity::class.java)
        if (albumData.lati > 0 && albumData.long > 0) {
            intent.putExtra("isFromMap", true)
            intent.putExtra("lati", albumData.lati)
            intent.putExtra("long", albumData.long)
        }
        startActivity(intent)
    }

    private fun setSearchData() {
//        runOnUiThread {
//            binding.searchTab.swipeRefreshAlbum.isRefreshing = false
//        }

        binding.searchTab.timeLineRecycler.suppressLayout(false)
        if (timeLineAdapter != null) {
            binding.searchTab.timeLineRecycler.post {
                if (timeLineAdapter != null) {
                    timeLineAdapter?.submitList(timeList)
                    timeLineAdapter?.notifyItemRangeChanged(0, timeList.size)
                }
            }
        } else initSearchAdapter()
        //setEmptyAlbum()
    }

    private fun setAlbumData() {
        runOnUiThread {
            binding.albumTab.swipeRefreshAlbum.isRefreshing = false
        }

        binding.albumTab.albumRecycler.suppressLayout(false)
        if (albumAdapter != null) {
            binding.albumTab.albumRecycler.post {
                if (albumAdapter != null) {
                    albumAdapter?.submitList(albumList)
                    albumAdapter?.notifyItemRangeChanged(0, albumList.size)
                }
            }
        } else initAlbumAdapter()
        setEmptyAlbum()
    }

    private fun setPhotoData() {
        runOnUiThread {
            binding.photosTab.swipeRefreshPhotos.isRefreshing = false
        }

        binding.photosTab.pictureRecycler.suppressLayout(false)

        if (pictureAdapter != null) {
            binding.photosTab.pictureRecycler.post {
                if (pictureAdapter != null) {
                    //pictureAdapter?.notifyDataSetChanged()
                    pictureAdapter?.submitList(pictures)
                    pictureAdapter?.notifyItemRangeChanged(0, pictures.size)
                }
            }
        } else initPhotoAdapter()
        setEmptyPhoto()

        val layoutManager = binding.photosTab.pictureRecycler.layoutManager as MyGridLayoutManager
        mPhotoZoomListener = object : MyRecyclerView.MyZoomListener {
            override fun zoomIn() {
                if (layoutManager.spanCount > 2) {
                    reducePhotoGrid()
//                        getRecyclerAdapter()?.finishActMode()
                }
            }

            override fun zoomOut() {
                if (layoutManager.spanCount < MAX_COLUMN_COUNT_PICTURE) {
                    increasePhotoGrid()
//                        getRecyclerAdapter()?.finishActMode()
                }
            }
        }
        binding.photosTab.pictureRecycler.setupZoomListener(mPhotoZoomListener)
        mPhotosDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleMediaSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectMediaRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedMedia = -1
                }
            }

        }
        binding.photosTab.pictureRecycler.setupDragListener(mPhotosDragListener)

    }

    private fun setExploreData() {
        binding.exploreTab.llDuplicate.setOnClickListener {
            startActivity(Intent(this@HomeActivity, DuplicateFinderActivity::class.java))
        }
        binding.exploreTab.llTravelDiary.setOnClickListener {
            startActivity(Intent(this@HomeActivity, MapAlbumActivity::class.java))
        }
        binding.exploreTab.llPrivate.setOnClickListener {
            val intent = Intent(this@HomeActivity, LockActivity::class.java)
            lockActivityResultLauncher.launch(intent)
        }
        binding.exploreTab.llNotes.setOnClickListener {
            startActivity(Intent(this@HomeActivity, NotesActivity::class.java))
        }
        binding.exploreTab.llPdf.setOnClickListener {
            val intent = Intent(this@HomeActivity, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
            intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
            startActivity(intent)
        }
    }


    private fun setPhotoGroup() {
        binding.photosTab.swipeRefreshPhotos.isRefreshing = true
        val currentGrouping = preferences.getGroupBy()
        val groupOrder = preferences.getGroupOrderBy()
        photosLoader?.applyMediaGrouping(allList, currentGrouping = currentGrouping, groupOrder = groupOrder) { groupedMediaList ->
            Log.e("PhotosFragment", "groupedMediaList size==>> ${groupedMediaList.size}")
            pictures.clear()
            pictures.addAll(groupedMediaList)
            binding.photosTab.swipeRefreshPhotos.isRefreshing = false
            setPhotoData()
        }
    }

    private fun checkNotification(mIntent: Intent) {
        if (mIntent.hasExtra("activity") && mIntent.hasExtra("isFromNotification")) {
            isFromNotification = mIntent.getBooleanExtra("isFromNotification", false)
            mActivityName = mIntent.getStringExtra("activity") ?: ""
            var initialLocationTitle = mIntent.getStringExtra("initialLocationTitle") ?: ""

            val progressDialog = SimpleProgressDialog(
                this@HomeActivity,
                getString(R.string.please_wait),
            )
            progressDialog.setCancelable(false)

            if (!mActivityName.contains("recent")) progressDialog.show()

//            val locationId = intent.getLongExtra("locationId", 0L)
//            val latitude = intent.getFloatExtra("latitude", 0f)
//            val longitude = intent.getFloatExtra("longitude", 0f)
            intent.putExtra("activity", "")
            intent.putExtra("initialLocationTitle", "")
            intent.putExtra("isFromNotification", false)
            intent.data = null
            delayExecution(2500) {
                if (progressDialog != null
                    && progressDialog.isShowing
                    && !isFinishing
                    && !isDestroyed
                ) progressDialog.dismiss()

                if (isFromNotification && mActivityName.isNotEmpty()) {
                    try {
                        val intent = if (mActivityName.contains("setting")) {
                            Intent(this@HomeActivity, SettingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        } else if (mActivityName.contains("language")) {
                            Intent(this@HomeActivity, LanguageActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        } else if (mActivityName.contains("cleaner")) {
                            Intent(this@HomeActivity, RecoverMediaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
//                            Intent(this@HomeActivity, JunkScanActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        } else if (mActivityName.contains("map")) {
                            Intent(this@HomeActivity, MapAlbumActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                                .putExtra("initialLocationTitle", initialLocationTitle)
//                                .putExtra("locationId", locationId)
//                                .putExtra("latitude", latitude)
//                                .putExtra("longitude", longitude)
                        } else if (mActivityName.contains("recover")) {
                            Intent(this@HomeActivity, RecoverMediaActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        } else if (mActivityName.contains("favorite")) {
                            Intent(this@HomeActivity, FavouriteListActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        } else if (mActivityName.contains("recent")) {
                            val recentList = fetchRecentMedia(this@HomeActivity)
                            val albumData = AlbumData(getString(R.string.recent), recentList as ArrayList<MediaData>)
                            Constant.albumData = AlbumData(
                                albumData.title,
                                albumData.mediaData,
                                albumData.folderPath,
                                albumData.date,
                                albumData.fileSize
                            )
                            Intent(this@HomeActivity, ImageListActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                                .putExtra("folderPath", "${albumData.folderPath}")
                        } else null

                        isFromNotification = false
                        mActivityName = ""
                        initialLocationTitle = ""
                        if (intent != null) startActivity(intent)
                    } catch (e: Exception) {
                        Log.w("TAG", "Exception.002:$e")
                    }
                }
            }
        }
    }

    public fun openImageList(albumData: AlbumData) {
        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )
        val intent = Intent(this@HomeActivity, ImageListActivity::class.java)
        intent.putExtra("folderPath", "${albumData.folderPath}")
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT)
        startActivity(intent)
//        setBackAlbumData()

    }

//    public fun setBackAlbumData() {
//        Constant.albumList.clear()
//        for (albumData in albumList) {
//            Constant.albumList.add(
//                AlbumData(
//                    albumData.title,
//                    albumData.mediaData,
//                    albumData.folderPath,
//                    albumData.date,
//                    albumData.fileSize
//                )
//            )
//        }
//    }

    private fun initView() {
        //adsPref = PrefCalls(this)

        Log.e("RateTag", "intView isReCreateHomeSS ${Constant.isReCreateHomeSS}")
        if (Constant.isReCreateHomeSS) {
            Constant.isReCreateHomeSS = false
        }
//        else {
//            Log.e("native_exit", "preferences.appOpenCounter001:${preferences.appOpenCounter}")
//            var appOpenCounter = preferences.appOpenCounter
//            appOpenCounter += 1
//            preferences.appOpenCounter = appOpenCounter
//            Log.e("native_exit", "preferences.appOpenCounter002:${appOpenCounter}")
//        }

        if (preferences.isFirstTimeInstall) {
            preferences.isFirstTimeInstall = false
        }

        //needDialog = adsPref.firstTimeDialog

//        CoroutineScope(Dispatchers.IO).launch {
        setTab()
        setToolbarSelectionMaintain(false, 0, false)
//        }

        intListener()
        initPhotoListener()
        initAlbumListener()
        initExploreListener()

//        val serviceIntent = Intent(
//            this,
//            PhoneStateForegroundService::class.java
//        )
//        startService(serviceIntent)


        val remoteConfig = getInstance()
//        fetchFamilyApps(remoteConfig)
        checkForceAppUpdate(remoteConfig)
//        checkInAppUpdate()

        Log.e("native_exit", "delayExecution")
        initFirebaseConfig {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestNotificationPermission()
            } else {
                showHomeNotification()
//                if (callerCadBaseConfig.callerCadEnable) {
//                    checkCaller()
//                }
            }

        }

        if (!isDestroyed || !isFinishing) {
            delayExecution(5000) {
                loadExitAds()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun requestNotificationPermission() {
        Log.e("POST_NOTIFICATIONS", "requestNotificationPermission")
        Dexter.withContext(this@HomeActivity)
            .withPermission(
                Manifest.permission.POST_NOTIFICATIONS
            )
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                    Log.e("POST_NOTIFICATIONS", "onPermissionGranted")
                    showHomeNotification()
//                    if (callerCadBaseConfig.callerCadEnable) {
//                        checkCaller()
//                    }
                }

                override fun onPermissionDenied(PermissionDeniedResponse: PermissionDeniedResponse?) {
                    Log.e("POST_NOTIFICATIONS", "onPermissionDenied:${PermissionDeniedResponse?.isPermanentlyDenied}")
                    if (PermissionDeniedResponse?.isPermanentlyDenied!!) {
                        //showPermissionDeniedDialog(getString(R.string.permission_Needed), getString(R.string.notification_permission_message))
                        showPermissionDeniedDialog(getString(R.string.permission_Needed), "Enable notification permission to stay updated with important alerts and updates.")
                    } else {
//                        if (callerCadBaseConfig.callerCadEnable) {
//                            checkCaller()
//                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: PermissionRequest?, token: PermissionToken?) {
                    token?.continuePermissionRequest()
                    Log.e("POST_NOTIFICATIONS", "onPermissionRationaleShouldBeShown")
                }

            }).check()
    }

//    var needDialog = true
//    private fun checkCaller() {
//        Log.e("checkCaller", "001")
//        val readPhoneState =
//            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
//        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            Settings.canDrawOverlays(this)
//        } else {
//            true
//        }
//        if (readPhoneState && canDrawOverlays) {
//            binding.icCall.beGone()
////            setAutoStartPermission(this)
//            Log.e("checkCaller.icCall", "icCall.beGone")
//        } else {
//
//            if (callerCadBaseConfig.callerCadEnable) {
//                binding.icCall.beVisible()
//                if (!callerCadBaseConfig.callerCadPermissionDialogDismiss) {
//                    showCallPermissionDialog()
//                } else if (needDialog) {
//                    adsPref.firstTimeDialog = false
//                    showCallPermissionDialog()
//                }
//            }
//        }
//    }

    private fun requestSystemOverlayPermission() {
        AdsConfig.isSystemDialogOpen = true

        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + applicationContext.packageName)
        )

        try {
            startActivityForResult(intent, 101)
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
        }

//        Handler(Looper.getMainLooper()).postDelayed({
//            val intent1 = Intent(this@HomeActivity, SettingPermissionActivity::class.java)
//            intent1.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
//            startActivity(intent1)
//        }, 500)

    }

//    var callerDialog: CallerPermissionDialog? = null
//    private fun showCallPermissionDialog() {
//        Log.e("checkCaller", "preferences.showCallPermissionDialog")
//        callerDialog = CallerPermissionDialog(
//            this, callerCadBaseConfig.callerCadPermissionDialogDismiss,
//            {//positiveListener
//                AdsConfig.isSystemDialogOpen = true
//                Dexter.withContext(this@HomeActivity).withPermission(
//                    Manifest.permission.READ_PHONE_STATE
//                ).withListener(object : PermissionListener {
//                    override fun onPermissionGranted(permissionGrantedResponse: PermissionGrantedResponse) {
//                        Log.e("checkCaller", "onPermissionGranted")
//                        LogEvent.logCallerCard("CAD_CALL_ALLOW_PERMISSION")
//                        if (Settings.canDrawOverlays(this@HomeActivity)) {
//                            val readPhoneState =
//                                ContextCompat.checkSelfPermission(
//                                    this@HomeActivity,
//                                    Manifest.permission.READ_PHONE_STATE
//                                ) == 0
//                            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                                Settings.canDrawOverlays(this@HomeActivity)
//                            } else {
//                                true
//                            }
//                            binding.icCall.beGoneIf(canDrawOverlays && readPhoneState)
//                            Log.e(
//                                "checkCaller.icCall",
//                                "icCall.beGoneIf.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
//                            )
//                            callerDialog?.dismiss()
//                        } else {
//                            callerDialog?.dismiss()
//                            requestSystemOverlayPermission()
//                        }
////                    requestSystemOverlayPermission()
//                    }
//
//                    override fun onPermissionDenied(permissionDeniedResponse: PermissionDeniedResponse) {
//                        Log.e("checkCaller", "onPermissionDenied")
//                        LogEvent.logCallerCard("CAD_CALL_DENY_PERMISSION")
//
//                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//                        val uri = Uri.fromParts("package", packageName, null)
//                        intent.data = uri
//                        callerLauncher.launch(intent)
//                        AdsConfig.isSystemDialogOpen = true
//                        toast(
//                            "Please allow phone permission to enable feature"
//                        )
//                        callerDialog?.dismiss()
//                    }
//
//                    override fun onPermissionRationaleShouldBeShown(
//                        permissionRequest: PermissionRequest,
//                        permissionToken: PermissionToken,
//                    ) {
//                        permissionToken.continuePermissionRequest()
//                    }
//                }).check()
//
//            }, {//closeListener
//                var closeCounter = adsPref.closeCounter
//                closeCounter++
//                adsPref.closeCounter = closeCounter
//                callerDialog?.dismiss()
//
//                if (!callerCadBaseConfig.callerCadPermissionDialogDismiss) {
//                    val calendar = _root_ide_package_.java.util.Calendar.getInstance()
//                    val format = _root_ide_package_.java.text.SimpleDateFormat("dd/mm/yy", _root_ide_package_.java.util.Locale.ENGLISH)
//                    val today = format.format(calendar.timeInMillis)
//                    LogEvent.logCallerCard("CAD_PERMISSION_CLOSE:$today")
//                    AdsConfig.isSystemDialogOpen = true
//                    //finishAffinity()
//                }
//            })
//        callerDialog?.setOnDismissListener { dialogInterface: _root_ide_package_.android.content.DialogInterface? ->
//            val readPhoneState =
//                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
//            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                Settings.canDrawOverlays(this)
//            } else {
//                true
//            }
//
//            if (callerCadBaseConfig.callerCadEnable) {
//                binding.icCall.beGoneIf(canDrawOverlays && readPhoneState)
//                Log.e(
//                    "checkCaller.icCall",
//                    "setOnDismissListener.icCall.beGoneIf.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
//                )
//            }
//
//        }
//        if (!isFinishing && !isDestroyed) {
//            AdsConfig.isSystemDialogOpen = true
//            callerDialog?.show()
//        }
//    }

    private fun startCleanRecycleBin() {
        if (preferences.deleteAfter30Days) {
            CoroutineScope(Dispatchers.IO).launch {
                startAutoCleanTrashWorker()
            }
        }
    }

    private fun startNewPhotoFetcher() {
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)
        MediaContentObserver.registerContentObserver(this)
//        if (isNougatPlus()) {
//            val photoFetcher = NewPhotoFetcher()
//            if (!photoFetcher.isScheduled(applicationContext)) {
//                photoFetcher.scheduleJob(applicationContext)
//            }
//        }
    }


    private fun setRvLayoutManager() {
        try {
            val gridCount = preferences.getGridCount()
            val layoutManager = binding.photosTab.pictureRecycler.layoutManager as MyGridLayoutManager

            layoutManager.spanCount = gridCount
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    if (position >= 0 && position < pictures.size) {
                        return if (pictureAdapter!!.getItemViewType(position) == pictureAdapter!!.ITEM_HEADER_TYPE) {
                            gridCount
                        } else 1
                    } else {
                        return 1
                    }
                }
            }
        } catch (e: Exception) {
        }

        try {
            binding.photosTab.pictureRecycler.post {
                FastScroller(binding.photosTab.photosHandle).bind(binding.photosTab.pictureRecycler)
            }
        } catch (e: Exception) {
        }

        try {
            val gridCount = preferences.getAlbumGridCount() ?: 0
            val isGridShow = preferences.getShowGrid() ?: false

            if (isGridShow) {
                val layoutManager = binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager
                layoutManager.orientation = RecyclerView.VERTICAL
                layoutManager.spanCount = gridCount
                layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        if (position >= 0 && position < albumList.size) {
                            return if (albumAdapter!!.getItemViewType(position) == albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
                                gridCount
                            } else if (albumAdapter!!.getItemViewType(position) == albumAdapter!!.ITEM_ALBUM_UTIL_TYPE) {
                                gridCount
                            } else 1
                        } else {
                            return 1
                        }
                    }
                }
            } else {
                val layoutManager = binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager
                layoutManager.spanCount = 1
                layoutManager.orientation = RecyclerView.VERTICAL
                layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        return 1
                    }
                }
                mAlbumZoomListener = null

            }
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        MediaContentObserver.unregisterContentObserver(this)
//        MediaContentObserver.unbindService()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }


    private fun setTab() {
        binding.groupToolbarHeader.visibility = View.VISIBLE
        toggleCameraVisibility()

        val commonPagerAdapter = CommonPagerAdapter()
        commonPagerAdapter.insertViewId(R.id.albumTab)
        commonPagerAdapter.insertViewId(R.id.photosTab)
        commonPagerAdapter.insertViewId(R.id.exploreTab)
        commonPagerAdapter.insertViewId(R.id.searchTab)
        binding.viewPager.offscreenPageLimit = 4
        binding.viewPager.adapter = commonPagerAdapter

        //binding.bottomNavigation.setActiveItem()
        binding.bottomNavigation.setOnItemSelectedListener(object : NiceBottomBar.OnItemListener {
            override fun onItemLongClick(pos: Int) {
            }

            override fun onItemReselect(pos: Int) {
            }

            override fun onItemSelect(pos: Int) {
                when (pos) {
                    0 -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 0
                        }
                    }

                    1 -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 1
                        }
                    }

                    2 -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 2
                        }
                    }

                    3 -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 3
                        }
                    }

                    else -> {
                        binding.viewPager.post {
                            binding.viewPager.currentItem = 0
                        }
                    }
                }
            }
        })

//        binding.bottomNavigation.setOnItemSelectedListener {
//            when (it.itemId) {
//                R.id.tab1 -> {
//                    binding.viewPager.post {
//                        binding.viewPager.currentItem = 0
//                    }
//                }
//
//                R.id.tab2 -> {
//                    binding.viewPager.post {
//                        binding.viewPager.currentItem = 1
//                    }
//                }
//
//                R.id.tab3 -> {
//                    binding.viewPager.post {
//                        binding.viewPager.currentItem = 2
//                    }
//                }
//
//                R.id.tab4 -> {
//                    binding.viewPager.post {
//                        binding.viewPager.currentItem = 3
//                    }
//                }
//
////                R.id.tab3 -> {
////                    binding.viewPager.post {
////                        binding.viewPager.currentItem = 2
////                    }
////                }
//
//                else -> {
//                    binding.viewPager.post {
//                        binding.viewPager.currentItem = 0
//                    }
//                }
//            }
//            true
//        }

        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {
                when (position) {
                    0 -> {
                        setEmptyAlbum()
                        setEmptyData(isEmptyAlbum)
                        //binding.bottomNavigation.selectedItemId = R.id.tab1
                        binding.bottomNavigation.setActiveItem(0)
                    }

                    1 -> {
                        setEmptyPhoto()
                        setEmptyData(isEmptyPhoto)
                        //binding.bottomNavigation.selectedItemId = R.id.tab2
                        binding.bottomNavigation.setActiveItem(1)
                    }

                    2 -> {
//                        setEmptyPhoto()
//                        setEmptyData(isEmptyPhoto)
                        //binding.bottomNavigation.selectedItemId = R.id.tab3
                        binding.bottomNavigation.setActiveItem(2)
                    }

                    3 -> {
//                        setEmptyPhoto()
//                        setEmptyData(isEmptyPhoto)
                        //binding.bottomNavigation.selectedItemId = R.id.tab4
                        binding.bottomNavigation.setActiveItem(3)
                    }

//                    2 -> {
//                        var isEmpty = false
//                        isEmpty = isEmptyAlbum && isEmptyPhoto
//                        setEmptyData(isEmpty)
//
//                        binding.bottomNavigation.selectedItemId = R.id.tab3
//                    }
                }
//                binding.loutTab.onPageSelected(position)
                tabPos = position

                if (position == 2 || position == 3) {
                    if (binding.titleSwitcher.displayedChild != 1) {
                        binding.titleSwitcher.displayedChild = 1
                    }
                } else if (position == 0 || position == 1) {
                    if (binding.titleSwitcher.displayedChild != 0) {
                        binding.titleSwitcher.displayedChild = 0
                    }
                }
//                if ((position == 2 || position == 3) && binding.titleSwitcher.displayedChild != 1) {
//                    binding.titleSwitcher.displayedChild = 1
//                } else if (binding.titleSwitcher.displayedChild == 1) {
//                    binding.titleSwitcher.displayedChild = 0
//                }

                Log.e("HomeActivity", "onPageSelected.refreshMedia:${preferences.refreshMedia}")
                if (preferences.refreshMedia) {
                    preferences.refreshMedia = false
                    getAlbumData()
                    getPhotoData()
                }

            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })

        var isEmpty = false
        isEmpty = isEmptyAlbum && isEmptyPhoto
        setEmptyData(isEmpty)
    }

    private fun addMarker(album: PlaceData) {
        isMarkerAdded = true
        val lat = album.lati.toDouble()
        val lng = album.long.toDouble()
        if (lat != null && lng != null) {
            val location = LatLng(lat, lng)

//            Log.e("XXPermissions", "getImageOnMap:::addMarker==>lat:${lat}, lng:${lng}")

            val marker = googleMap?.addMarker(
                MarkerOptions()
                    .position(location)
                    .anchor(0.5f, 0.5f)
                    .icon(
                        BitmapDescriptorFactory.fromBitmap(
                            getMarkerBitmapFromView(album.pictureData.firstOrNull()!!.filePath, album.pictureData.size)
                        )
                    )
            )

            marker?.tag = album.place
        }
    }

    private fun getMarkerBitmapFromView(photoPath: String, size: Int): Bitmap {
        val customMarkerView: View =
            (getSystemService(AppCompatActivity.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.custom_marker,
                null
            )
        val markerImageView = customMarkerView.findViewById<View>(R.id.profile_image) as ImageView
        val markerCounter = customMarkerView.findViewById<View>(R.id.txtCount) as TextView
        markerCounter.text = "$size"

        val options = android.graphics.BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = android.graphics.BitmapFactory.decodeFile(photoPath, options)
        markerImageView.setImageBitmap(bitmap)

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        customMarkerView.layout(
            0,
            0,
            customMarkerView.measuredWidth,
            customMarkerView.measuredHeight
        )
        //customMarkerView.buildDrawingCache()
        val returnedBitmap = Bitmap.createBitmap(
            customMarkerView.measuredWidth, customMarkerView.measuredHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = customMarkerView.background
        drawable?.draw(canvas)
        customMarkerView.draw(canvas)
        return returnedBitmap
    }

    private fun setEmptyPhoto() {
        if (pictures != null && pictures.size != 0) {
            isEmptyPhoto = false
            binding.photosTab.pictureRecycler.visibility = View.VISIBLE
            binding.photosTab.loutNoPhotos.visibility = View.GONE
        } else {
            isEmptyPhoto = true
            binding.photosTab.pictureRecycler.visibility = View.GONE
            binding.photosTab.loutNoPhotos.visibility = View.VISIBLE
        }
    }

    private fun setEmptyAlbum() {
        if (albumList != null && albumList.size != 0) {
            isEmptyAlbum = false
            binding.albumTab.albumRecycler.visibility = View.VISIBLE
            binding.albumTab.loutNoAlbum.visibility = View.GONE
//            binding.llLimitedAccess.beGone()
//            if (hasLimitedPhotoAccess(this)) {
//                binding.llLimitedAccess.beVisible()
//            }

        } else {
            isEmptyAlbum = true
            binding.albumTab.albumRecycler.visibility = View.GONE
            binding.albumTab.loutNoAlbum.visibility = View.VISIBLE
//            binding.llLimitedAccess.beGone()
//            if (hasLimitedPhotoAccess(this)) {
//                binding.llLimitedAccess.beVisible()
//            }
        }
    }

    private fun setEmptyData(isEmpty: Boolean) {
        if (isEmpty) {
            binding.llAdPlace.beGone()
        } else {
            binding.llAdPlace.beVisible()
        }
    }

    private fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        Log.e("1712MG", "longClickListener.refreshMedia:${preferences.refreshMedia}")

        if (preferences.refreshMedia) {
            preferences.refreshMedia = false
//            if (albumFragment != null) albumFragment.refreshData()
//            if (photosFragment != null) photosFragment.refreshData()
            getAlbumData()
            getPhotoData()
        }

        setToolbarSelectionMaintain(
            isShowSelection,
            selected,
            isAllSelect
        )
    }


    var needToAddPin = false
    var needToRemovePin = false
    var mSelectedItem = 0
    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean,
    ) {
        runOnUiThread {

            mSelectedItem = selectedItem
            binding.loutToolbar.visibility = View.VISIBLE
            pinList.clear()
            pinList.addAll(preferences.getPinAlbumList())

            needToAddPin = false
            needToRemovePin = false

            if (isShowSelection) {

                binding.btnHide.visibility =
                    if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
                binding.btnMore.visibility =
                    if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
                binding.btnPin.visibility =
                    if (binding.viewPager.currentItem == 0) View.VISIBLE else View.GONE
                binding.btnShare.visibility =
                    if (binding.viewPager.currentItem == 0) View.GONE else View.VISIBLE

            }

            if (binding.viewPager.currentItem == 0) {
                val selectedAlbum = getSelectedAlbum()
//            val selectImage: ArrayList<PictureData> = ArrayList()
                for (i in selectedAlbum.indices) {
                    val model: AlbumData = selectedAlbum[i] as AlbumData
                    if (pinList.contains(model.folderPath))
                        needToRemovePin = true
                    else
                        needToAddPin = true
                }
            }

            if (needToAddPin && needToRemovePin) {
                binding.btnPin.alpha = 0.5F
            } else if (needToAddPin) {
                binding.btnPin.alpha = 1.0F
                binding.txtPin.text = getString(R.string.pin)
            } else if (needToRemovePin) {
                binding.btnPin.alpha = 1.0F
                binding.txtPin.text = getString(R.string.unpin)
            }

            binding.groupToolbarSelectHeader.visibility =
                if (isShowSelection) View.VISIBLE else View.GONE

//        binding.viewPager.isUserInputEnabled = !isShowSelection
//        binding.viewPager.isEnabled = !isShowSelection
            binding.viewPager.setPagingEnabled(!isShowSelection)
            isSelectAll = isAllSelect

            binding.loutSelectOption.visibility = if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE

            if (binding.viewPager.currentItem == 2) {
                binding.groupToolbarSettingHeader.visibility = View.GONE
                binding.icCamera.visibility = View.GONE
                binding.groupToolbarHeaderPrivate.visibility = if (isShowSelection) View.GONE else View.VISIBLE
            } else {
                if (isShowSelection) {
                    binding.groupToolbarHeader.visibility = View.GONE
                    binding.icCamera.visibility = View.GONE
                } else {
                    binding.groupToolbarHeader.visibility = View.VISIBLE
                    toggleCameraVisibility()
                }
            }

//        binding.loutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        binding.cardLoutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
            binding.bottomNavigation.visibility = if (isShowSelection) View.GONE else View.VISIBLE
            binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
            setSelectAllColor()

        }
    }

    private fun toggleCameraVisibility() {
        //binding.icCamera.beGoneIf(preferences.hideCamera)
    }

    private fun setSelectAllColor() {
        val color = ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    private fun getSelectedAlbum(): ArrayList<AlbumData> {
        val selectAlbum: ArrayList<AlbumData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null) {
//                if (albumList[i] is PictureData) {
                val model: AlbumData = albumList[i] as AlbumData
                if (model.isSelected) {
                    selectAlbum.add(model)
//                        favList.add(model.filePath)
                }
//                }
            }
        }
        return selectAlbum
    }

    private fun getSelectedPhotos(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is MediaData) {
                    val model: MediaData = pictures[i] as MediaData
                    if (model.isSelected) {
                        selectImage.add(model)
//                        favList.add(model.filePath)
                    }
                }
        }
        return selectImage
    }

    private fun getSelectedMedia(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
        if (binding.viewPager.currentItem == 0) {
            for (i in albumList.indices) {
                if (albumList[i] != null)
                    if (albumList[i].isSelected) {
                        val pictureList = albumList[i].mediaData
                        selectImage.addAll(pictureList)
                    }
            }

        } else if (binding.viewPager.currentItem == 1) {
            selectImage.addAll(getSelectedPhotos())
        }
        return selectImage
    }

    private fun getAlbumListForSelect() {
        setBackAlbumData()
    }

    public fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.mediaData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    override fun onResume() {
        super.onResume()
        setAppTheme()
        val readPhoneState = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == 0
        val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        Log.e(
            "checkCaller.icCall",
            "onResume.canDrawOverlays>$canDrawOverlays,readPhoneState>$readPhoneState"
        )
//        if (callerCadBaseConfig.callerCadEnable) {
//
//            if (canDrawOverlays && readPhoneState) {
//                binding.icCall.beGone()
//                Log.e("checkCaller.icCall", "onResume.icCall.beGone")
//            } else {
//                binding.icCall.beVisible()
//                Log.e("checkCaller.icCall", "onResume.icCall.beVisible")
//            }
//        }

        Log.e("HomeActivity", "onResume.refreshMedia:${preferences.refreshMedia}")

//        binding.exploreTab.map.onResume()
//        binding.exploreTab.llHidden.beGoneIf(preferences.hideVault)

//        try {
//            val countRecycle = dataBase.dataDao().getCountDelete()
//            binding.exploreTab.txtRecycleCount.text = "$countRecycle"
//        } catch (e: Exception) {
//        }

        delayExecution(120) {
            if (preferences.refreshMedia || needRefreshMedia) {
                needRefreshMedia = false
                preferences.refreshMedia = false
                refreshData()
            }
        }

        if (preferences.scanMedia) {
            preferences.scanMedia = false
            try {
                ensureBackgroundThread {
                    scanPathRecursively(Constant.ROOT_PATH)
                }
            } catch (e: Exception) {
            }
        }
        adMobBanner?.resume()
    }

    private fun refreshData() {
        delayExecution(150) {
            preferences.refreshMedia = false
            getData()
//            sendEvent("get_data")
        }
    }


    var isOpenCameraPermission: Boolean = false
    private fun requestPermission() {

        val list: ArrayList<String> = ArrayList()
        if (isOpenCameraPermission) {
            list.add(Manifest.permission.CAMERA)
        } else
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            list.add(Manifest.permission.ACCESS_MEDIA_LOCATION)
        }

        Dexter.withContext(this@HomeActivity)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (report.areAllPermissionsGranted()) {
                            openCamera()
                        } else if (report.isAnyPermissionPermanentlyDenied) {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            AdsConfig.isSystemDialogOpen = true
                            //            AdconfigApplication.disabledOpenAds()
                            permissionLauncher.launch(intent)
                        } else {
                            toast(
                                if (isOpenCameraPermission) getString(R.string.permission_camera_toast_msg)
                                else getString(R.string.permission_toast_msg)
                            )
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?,
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()

    }

    private fun intListener() {

        binding.icDrawer.setOnClickListener {
            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
                binding.drawerLay.closeDrawer(GravityCompat.START)
            else binding.drawerLay.openDrawer(GravityCompat.START)
        }

        binding.drawerContent.loutDrawerMain.setOnClickListener {

        }
        intDrawerListener()

        //binding.icCamera.beGoneIf(preferences.hideCamera)
        binding.icCamera.setOnClickListener {
//            if (checkCameraPermission())
            openCamera()
//            else {
//                isOpenCameraPermission=true
//                requestPermission()
//            }

        }
//        binding.icSearch.setOnClickListener {
        binding.searchTab.edtSearch.setOnClickListener {
            val intent = Intent(this, SearchActivity::class.java)
            startActivity(intent)
        }

        var resultAll = 0
        resultAll += TYPE_IMAGES
        resultAll += TYPE_VIDEOS
        resultAll += TYPE_GIFS
//        resultAll += TYPE_RAWS
//        resultAll += TYPE_SVGS
//        resultAll += TYPE_PORTRAITS

        var resultPhoto = 0
        resultPhoto += TYPE_IMAGES
//        resultPhoto += TYPE_RAWS
//        resultPhoto += TYPE_SVGS
//        resultPhoto += TYPE_PORTRAITS

        var resultVideo = 0
        resultVideo += TYPE_VIDEOS

        var resultGif = 0
        resultGif += TYPE_GIFS

        when (preferences.getFilterMedia()) {
            resultAll -> {
                binding.txtTitle.text = getString(R.string.all)
            }

            resultPhoto -> {
                binding.txtTitle.text = getString(R.string.photos)
            }

            resultVideo -> {
                binding.txtTitle.text = getString(R.string.videos)
            }

            resultGif -> {
                binding.txtTitle.text = getString(R.string.gifs)
            }
        }

        binding.txtTitle.setOnClickListener {
            showHomeMenuFilter(binding.txtTitle)
        }
        binding.icMenu.setOnClickListener {
            showMenu()
        }

        binding.icClose.setOnClickListener {
            if (binding.viewPager.currentItem == 1) {
                setCloseToolbar()
                refreshData()
            } else if (binding.viewPager.currentItem == 0) {
                setCloseToolbar()
                refreshData()
            }
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            if (binding.viewPager.currentItem == 1) setPhotosSelect(isSelectAll)
            else if (binding.viewPager.currentItem == 0) setAlbumSelect(isSelectAll)
            setSelectAllColor()
        }

        binding.btnShare.setOnClickListener {
            if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    shareImages()
                }
            }
        }
        binding.btnPin.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                if (needToAddPin && needToRemovePin) {
//                    binding.btnPin.alpha=0.5F
                } else if (needToAddPin) {
                    if (selectedAlbumCount == 0) {
                        toast(getString(R.string.PleaseSelectAlbum))
                    } else {
                        pinAlbum()
                    }
//                    binding.btnPin.alpha=1.0F
//                    binding.txtPin.text=getString(R.string.pin)
                } else if (needToRemovePin) {
                    if (selectedAlbumCount == 0) {
                        toast(getString(R.string.PleaseSelectAlbum))
                    } else {
                        unPinAlbum()
                    }
//                    binding.btnPin.alpha=1.0F
//                    binding.txtPin.text=getString(R.string.unpin)
                }
            }
        }

        binding.btnDelete.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
                    showDeleteDialog(getSelectedMedia())
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    showDeleteDialog(getSelectedMedia())
                }
            }
        }
        binding.btnHide.setOnClickListener {
            if (binding.viewPager.currentItem == 0) {
//                val selectedItem = getSelectedAlbum()
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
                    showHideDialog(getSelectedMedia())
                }
            } else if (binding.viewPager.currentItem == 1) {
//                val selectedItem = getSelectedPhotos()
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    showHideDialog(getSelectedMedia())
                }
            }
        }

        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }
//        binding.tvAllow.setOnClickListener {
//            requestPermissionStorage()
//        }

    }


    private fun closeDrawer() {
        if (binding.drawerLay.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLay.closeDrawer(GravityCompat.START)
        }
    }

    private fun intDrawerListener() {
        binding.drawerContent.llDwHome.setOnClickListener {
            closeDrawer()
            binding.viewPager.currentItem = 0
        }
        binding.drawerContent.llDwFavourite.setOnClickListener {
            closeDrawer()
            startActivity(Intent(this, FavouriteListActivity::class.java))
            getAlbumListForSelect()

        }

        binding.drawerContent.llDwPrivate.setOnClickListener {
            closeDrawer()
            val intent = Intent(this, LockActivity::class.java)
            lockActivityResultLauncher.launch(intent)
        }
        binding.drawerContent.llDwRecentlyDelete.setOnClickListener {
            startActivity(Intent(this, RecentlyDeleteActivity::class.java))
            closeDrawer()
            getAlbumListForSelect()
        }
        binding.drawerContent.llMaps.setOnClickListener {
            startActivity(Intent(this, MapAlbumActivity::class.java))
        }
        binding.drawerContent.llNote.setOnClickListener {
            startActivity(Intent(this, NotesActivity::class.java))
        }
//        binding.drawerContent.llBrowser.setOnClickListener {
//            startActivity(Intent(this, WebBrowserActivity::class.java))
//        }
//        binding.drawerContent.llHidden.setOnClickListener {
//            val intent = Intent(this, LockActivity::class.java)
//            lockActivityResultLauncher.launch(intent)
//        }
        binding.drawerContent.llTimeLine.setOnClickListener {
            startActivity(Intent(this, TimeLineActivity::class.java))
        }
        binding.drawerContent.llPdf.setOnClickListener {
            val intent = Intent(this, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
            intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
            startActivity(intent)
        }
        binding.drawerContent.llDwDuplicate.setOnClickListener {
            startActivity(Intent(this, DuplicateFinderActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwTheme.setOnClickListener {
//            val themeDialog = ThemeDialog(updateListener = {
//                val intent = Intent(this, HomeActivity::class.java)
//                finish()
//                overridePendingTransition(0, 0)
//                startActivity(intent)
//                overridePendingTransition(0, 0)
//            })
//            themeDialog.show(supportFragmentManager, themeDialog.tag)
//            closeDrawer()
        }
        binding.drawerContent.llDwSetting.setOnClickListener {
            settingLauncher.launch(Intent(this, SettingActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llDwLanguage.setOnClickListener {
            languageLauncher.launch(Intent(this, LanguageActivity::class.java))
            closeDrawer()
        }
        binding.drawerContent.llFeedbackSuggestions.setOnClickListener {
            closeDrawer()
            sendEmail("galleryappa@outlook.com", "GalleryApp Feedback/Suggestion", "Message:\n")
        }
        binding.drawerContent.llShare.setOnClickListener {
            closeDrawer()
            try {
                val sendIntent = Intent()
                sendIntent.action = Intent.ACTION_SEND
                sendIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "Check out the App at: https://play.google.com/store/apps/details?id=$packageName"
                )
                sendIntent.type = "text/plain"
                AdsConfig.isSystemDialogOpen = true
                startActivity(sendIntent)
            } catch (e: Exception) {

            }
        }
        binding.drawerContent.llRateUs.setOnClickListener {
            closeDrawer()
            launchAppStore()
        }
        binding.drawerContent.llDwPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
            closeDrawer()
        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${packageName}")
        )
        startActivity(intent)
    }

    fun openPrivacyPolicy() {
        val url = getPrivacyPolicy()
        if (url != null && url.isNotEmpty()) {
            try {
                val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
                builder.setToolbarColor(ContextCompat.getColor(this, R.color.white))
                AdsConfig.isSystemDialogOpen = true
                val customTabsIntent: CustomTabsIntent = builder.build()
                customTabsIntent.intent.setPackage("com.android.chrome")
                customTabsIntent.launchUrl(this, Uri.parse(url))

            } catch (e: Exception) {
                val i = Intent(Intent.ACTION_VIEW)
                i.data = Uri.parse(url)
                AdsConfig.isSystemDialogOpen = true
                startActivity(i)
            }
        }
    }

    var languageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }

//    private fun requestPermissionStorage() {
//        if (preferences.appPermissionCount >= 2) {
//            LimitedAccessDialog(this@HomeActivity) { btn ->
//                if (btn) {
//                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//                    val uri = Uri.fromParts("package", packageName, null)
//                    intent.data = uri
//                    AdsConfig.isSystemDialogOpen = true
//                    permissionLauncher2.launch(intent)
//                }
//            }.show()
//        } else {
//            preferences.appPermissionCount++
//            val list: ArrayList<String> = ArrayList()
//
//            list.add(Manifest.permission.ACCESS_MEDIA_LOCATION)
////        }
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//                list.add(Manifest.permission.READ_MEDIA_IMAGES)
//                list.add(Manifest.permission.READ_MEDIA_VIDEO)
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
//                    list.add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
//                }
////                list.add(Manifest.permission.POST_NOTIFICATIONS)
//            } else {
//                list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
//                list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
//            }
//
//            Dexter.withContext(this@HomeActivity)
//                .withPermissions(
//                    list
//                )
//                .withListener(object : MultiplePermissionsListener {
//                    override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
//                        report?.let {
//                            if (report.areAllPermissionsGranted()) {
//                                getData()
//                            } else {
//                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
//                                    var result = ContextCompat.checkSelfPermission(this@HomeActivity, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
//                                    if (result) {
//                                        getData()
//                                    } else {
//                                        showPermissionDeniedDialog(getString(R.string.permission_Needed), getString(R.string.permission_toast_msg))
//                                    }
//                                } else {
//                                    showPermissionDeniedDialog(getString(R.string.permission_Needed), getString(R.string.permission_toast_msg))
//                                }
//                            }
//                        }
//                    }
//
//                    override fun onPermissionRationaleShouldBeShown(
//                        permissions: MutableList<PermissionRequest>?,
//                        token: PermissionToken?
//                    ) {
//                        token?.continuePermissionRequest()
//                    }
//                }).check()
//        }
//    }

    fun showPermissionDeniedDialog(dialogTitle: String, dialogMsg: String) {
        try {
            val simpleMessageDialog = SimpleMessageDialog(this@HomeActivity, dialogTitle, dialogMsg, {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                AdsConfig.isSystemDialogOpen = true
                startActivity(intent)
            }, {
//            finishAffinity()
            })
            AdsConfig.isSystemDialogOpen = true
            simpleMessageDialog.setCancelable(false)
            simpleMessageDialog.show()
        } catch (e: Exception) {
        }
    }

    private fun initPhotoListener() {
        binding.photosTab.swipeRefreshPhotos.setOnRefreshListener {
            if (binding.photosTab.swipeRefreshPhotos.isEnabled) getData()
            else
                this@HomeActivity.runOnUiThread {
                    binding.photosTab.swipeRefreshPhotos.isRefreshing = false
                }
        }
        binding.photosTab.ivScrollTopPhotos.setOnClickListener {
//            binding.pictureRecycler.smoothScrollToPosition(0)
            binding.photosTab.pictureRecycler.scrollToPosition(0)
            binding.photosTab.ivScrollTopPhotos.beGone()
//            binding.pictureRecycler.smoothScrollBy()
        }
        binding.photosTab.root.doOnPreDraw {
            binding.photosTab.pictureRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    val firstPositon =
                        (binding.photosTab.pictureRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
//                    var lastPositon =
//                        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findLastVisibleItemPosition()
                    binding.photosTab.ivScrollTopPhotos.beVisibleIf(firstPositon > 3)

                    if (firstPositon > 0) {
//                        setBubbleText(pictureAdapter?.getBubbleText(firstPositon)!!)
                        val str = pictureAdapter?.getBubbleText(firstPositon)!!
                        if (str.isNotEmpty()) binding.photosTab.photosBubbleText.text = str
                        binding.photosTab.photosBubble.beVisible()
                    } else {
                        binding.photosTab.photosBubble.beGone()
                    }
                }
            })
        }
    }

    private fun initAlbumListener() {
        binding.albumTab.swipeRefreshAlbum.setOnRefreshListener {
            if (binding.albumTab.swipeRefreshAlbum.isEnabled) getData()
            else
                this@HomeActivity.runOnUiThread {
                    binding.albumTab.swipeRefreshAlbum.isRefreshing = false
                }
        }
        binding.albumTab.ivScrollTopAlbum.setOnClickListener {
            binding.albumTab.albumRecycler.scrollToPosition(0)
            binding.albumTab.ivScrollTopAlbum.beGone()
        }
        binding.albumTab.root.doOnPreDraw {
            binding.albumTab.albumRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    val firstPositon = (binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
                    binding.albumTab.ivScrollTopAlbum.beVisibleIf(firstPositon > 3)
                    if (firstPositon > 0) {
                        val str = albumAdapter?.getBubbleText(firstPositon)!!
                        if (str.isNotEmpty()) binding.albumTab.albumBubbleText.text = str
                        binding.albumTab.albumBubble.beVisible()
                    } else {
                        binding.albumTab.albumBubble.beGone()
                    }
                }
            })
        }
    }

    private fun initExploreListener() {

//        binding.exploreTab.mapFull.setOnClickListener {
//            val intent = Intent(this@HomeActivity, MapExploreActivity::class.java)
//            intent.putExtra("pos", 0)
//            startActivity(intent)
////            startActivity(Intent(activity, MapActivity::class.java))
//        }
//        binding.exploreTab.cardPeople.setOnClickListener {
//
//            val intent = Intent(this@HomeActivity, MapExploreActivity::class.java)
//            intent.putExtra("pos", 1)
//            startActivity(intent)
//        }
//
//        binding.exploreTab.llHidden.setOnClickListener {
//            val intent = Intent(this@HomeActivity, LockActivity::class.java)
////            intent.putExtra(Constant.EXTRA_IS_OPEN_PRIVATE, true)
////            startActivity(intent)
//            lockActivityResultLauncher.launch(intent)
//        }
//
//
//        binding.exploreTab.llRecover.setOnClickListener {
//            val intent = Intent(this@HomeActivity, RecoverMediaActivity::class.java)
//            startActivity(intent)
//        }
//        binding.exploreTab.llRecycle.setOnClickListener {
//            val intent = Intent(this@HomeActivity, RecentlyDeleteActivity::class.java)
//            recycleLauncher.launch(intent)
//        }
//        binding.exploreTab.txtCleanCount.text = preferences.strCleanCount
//        if (preferences.isNeedCleaner) {
//            binding.exploreTab.hintClean.beVisible()
//        }
//        binding.exploreTab.llCleaner.setOnClickListener {
//            preferences.isNeedCleaner = false
//            startActivity(Intent(this@HomeActivity, JunkScanActivity::class.java))
//        }
//        binding.exploreTab.mCVSuggestion.setOnClickListener {
//            startActivity(Intent(this@HomeActivity, FeedbackActivity::class.java))
//        }
    }

    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.e("POST_NOTIFICATIONS", "lockActivityResultLauncher:${result.resultCode}")
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val intent = Intent(this@HomeActivity, PrivateActivity::class.java)
            privateActivityResultLauncher.launch(intent)
        }
    }
    var privateActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
//        if (result.resultCode == AppCompatActivity.RESULT_OK) {
//            val intent=Intent(getRequireActivity(), PrivateActivity::class.java)
//            startActivity(intent)

//        Constant.isReCreateHomeSS = true
//        val intent = getRequireActivity().intent
//        getRequireActivity().finish()
//        getRequireActivity().overridePendingTransition(0, 0)
//        startActivity(intent!!)
//        getRequireActivity().overridePendingTransition(0, 0)
//        Constant.isChangeLanguage = false
//        }
    }

    private fun showHideDialog(selectImage: ArrayList<MediaData>) {
//        requestStoragePermission(app_private_AFA_allow_nf, app_private_AFA_denied_nf, getActivityName()) {
//            if (it) {
        val hideDialog =
            ConfirmationDialog(
                this@HomeActivity,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto(selectImage)
                })
        hideDialog.show()
//            }
//        }
    }

    private fun hidePhoto(selectImage: ArrayList<MediaData>) {
//        val selectImage = mutableSetOf<MediaData>() // Use a set to avoid duplicates
//        val selectedAlbum = ArrayList<AlbumData>()
//        val selectFolder: ArrayList<String> = ArrayList()

//        albumList.filter { it.isSelected }.forEach { album ->
//            selectFolder.add(album.folderPath)
//            selectedAlbum.add(album) // Add selected album
//            album.mediaData.forEach { picture ->
//                if (picture is MediaData) {
//                    selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
//                }
//            }
//        }

//        pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
//            .filter { it.isSelected } // Filter selected MediaData objects
//            .forEach { selectImage.add(it) } // Add to the set

//        val uniqueSelectImage = ArrayList(selectImage)

        Utils.hideFiles(this@HomeActivity, selectImage, selectImage.size, hideListener = { deleteList ->
            toast(getString(R.string.hide_successfully))
//            for (folder in selectFolder) {
//                val files = File(folder).listFiles()
//                if (files.isNullOrEmpty()) {
//                    File(folder).delete()
//                }
//            }
            MediaScannerConnection.scanFile(
                this, deleteList.toTypedArray(), null
            ) { path: String?, uri: Uri? -> }

            longClickListener(false, 0, false)
            setCloseToolbar()
            refreshData()
        })
    }

    private fun showDeleteDialog(selectImage: ArrayList<MediaData>) {
//        requestStoragePermission(app_delete_AFA_allow_nf, app_delete_AFA_denied_nf, getActivityName()) {
//            if (it) {
        val deleteDialog = DeleteDialog.newInstance(this@HomeActivity, btnClickListener = {
            deletePhoto(selectImage, it)
        })
        deleteDialog.show()
//            }
//        }
    }

    private fun deletePhoto(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {

        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()
//        progressDialog.isCancelable = false
//        progressDialog.show(childFragmentManager, progressDialog.tag)

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            selectImage.forEach { model ->
                val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                MediaScannerConnection.scanFile(this, arrayOf<String>(model.filePath), null) { path: String?, uri: Uri? -> }
                if (isDelete) {
                    deleteList.add(model.filePath)
                    runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
//                                bindingDialog.txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                bindingDialog.progressBar.progress = deleteList.size
                    }
                }
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    try {
                        if (progressDialog != null
                            && progressDialog.isShowing
                            && !isFinishing
                            && !isDestroyed
                        )
                            progressDialog.dismiss()
                    } catch (e: Exception) {
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun deletePhotos(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {
        preferences.refreshMedia = true
        preferences.scanMedia = true

        Utils.deleteFiles(this@HomeActivity, selectImage, isPermanent) { deleteList ->
            setBeforeDeleteUpdate(deleteList)
        }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {

        selectedPhotosCount = 0
        selectedAlbumCount = 0
//        enableScroll()
        binding.albumTab.swipeRefreshAlbum.isEnabled = true
        binding.photosTab.swipeRefreshPhotos.isEnabled = true
        setCloseToolbar()
//        longClickListener(false, 0, false)
        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
        notifyAdapter()
        setEmptyAlbum()
        setEmptyPhoto()
//        runOnUiThread {
//            runOnUiThread {
//                val countRecycle = dataBase.dataDao().getCountDelete()
//                binding.exploreTab.txtRecycleCount.text = "$countRecycle"
//            }
//        }
        refreshData()
    }


    private fun deleteMainList(deleteList: ArrayList<String>) {
//        if (deleteList.size > 0) {
//            allList.removeAll {
//                deleteList.contains(it.filePath)
//            }
//        }
//
//        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in albumList) {
//                    if (pictureData.folderPath == path) {
//                        albumList.remove(pictureData)
//                        break
//                    }
//                }
//            }
//        }
    }

    private fun shareImages() {
        ensureBackgroundThread {
            val uris = ArrayList<Uri>()
            for (i in pictures.indices) {
                if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    if (model.isSelected) {
                        val uri = FileProvider.getUriForFile(
                            this@HomeActivity,
                            packageName + ".provider",
                            File(model.filePath)
                        )
                        uris.add(uri)
                    }
                }
            }
            runOnUiThread {
                Utils.shareFilesList(this@HomeActivity, uris)
            }
        }
    }

    private fun setPhotosSelect(isSelectAll: Boolean) {

        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is MediaData) {
                    val model = pictures[i] as MediaData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedPhotosCount = selected

    }


    private fun pinAlbum() {

        val pinList: ArrayList<String> = ArrayList()
        pinList.addAll(preferences.getPinAlbumList())

        val list = albumList.filter { it.isSelected }
        for (i in list.indices) {
            if (list[i].isSelected) {
                if (!pinList.contains(list[i].folderPath)) {
                    pinList.add(0, list[i].folderPath)
                }
            }
        }
        preferences.setPinAlbumList(pinList)
        preferences.refreshMedia = true
        albumAdapter?.pinList = pinList

        setCloseToolbar()
        refreshData()
    }

    private fun unPinAlbum() {
        val pinList: ArrayList<String> = ArrayList()
        pinList.addAll(preferences.getPinAlbumList())

        val list = albumList.filter { it.isSelected }
        for (i in list.indices) {
            if (list[i].isSelected) {
                if (pinList.contains(list[i].folderPath)) {
                    pinList.remove(list[i].folderPath)
                }
            }
        }
        preferences.setPinAlbumList(pinList)
        preferences.refreshMedia = true
        albumAdapter?.pinList = pinList

        setCloseToolbar()
        refreshData()
    }

    private fun setAlbumSelect(isSelectAll: Boolean) {

        var selected = 0
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                        if (isSelectAll) selected++
                    }
                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedAlbumCount = selected
    }

    var isAdLoaded = false

    //    var mAdView: AdView? = null
    var adMobBanner: AdView? = null
//    private var maxBanner: MaxAdView? = null

    override fun onPause() {
        super.onPause()
        adMobBanner?.pause()
    }

//    private fun loadBannerAds() {
//        if (!isAdLoaded) {
//            val isFirstSession = preferences.sessionCounter ==1
//            val adId =
//                if (isFirstSession) getString(R.string.b_homeActivity) else getString(R.string.b_homeActivity2)
//
//            BannerAdHelper.showBanner(this,
//                binding.layoutBanner.mFLAd,
//                binding.llAdPlace,
//                adId,
//                AdCache.homeAdView,
//                { isLoaded, adView, message ->
//                    mAdView = adView
//                    AdCache.homeAdView = adView
//                    isAdLoaded = isLoaded
//                })
//        }
//    }

    private fun loadBannerAds() {
        val adMobId = getString(R.string.b_homeActivity)
        loadAdmobBanner(adMobId, binding.layoutBanner.mFLAd, binding.llAdPlace)
    }

    private fun loadAdmobBanner(
        adId: String,
        container: ViewGroup,
        parent: ViewGroup
    ) {
        Log.i("ADCONFIG_HomeBanner", "loadAdmobBanner")
        adMobBanner = AdView(this)
        adMobBanner?.adListener = object : AdListener() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.i(
                    "ADCONFIG_HomeBanner",
                    "001.onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                )
                container.visibility = View.GONE
                parent.visibility = View.GONE
            }

            override fun onAdLoaded() {
                try {
//                    if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
                    if (container.childCount > 0) container.removeAllViews()
                    container.addView(adMobBanner)
                    container.visibility = View.VISIBLE
                    parent.visibility = View.VISIBLE

                    Log.d("ADCONFIG_HomeBanner", "001.onAdLoaded")
                } catch (e: Exception) {

                }

            }

            override fun onAdClicked() {
                super.onAdClicked()
                Log.d("ADCONFIG_HomeBanner", "001.onAdClicked")
                AdsConfig.isSystemDialogOpen = true
            }
        }
        adMobBanner?.setAdSize(getAdSize())
        adMobBanner?.adUnitId = adId
        adMobBanner?.loadAd(Builder().build())
    }

//    private fun loadMaxBanner(
//        adId: String,
//        container: ViewGroup,
//        parent: ViewGroup
//    ) {
//        Log.i("ADCONFIG_HomeBanner", "loadMaxBanner")
//
//        maxBanner = MaxAdView(adId, this)
//        maxBanner?.setListener(object : MaxAdViewAdListener {
//            override fun onAdLoaded(p0: MaxAd) {
//                Log.i("ADCONFIG_HomeBanner", "onAdLoaded")
//                container.visibility = View.VISIBLE
//                parent.visibility = View.VISIBLE
//            }
//
//            override fun onAdDisplayed(p0: MaxAd) {
//                Log.i("ADCONFIG_HomeBanner", "onAdDisplayed")
//                container.visibility = View.VISIBLE
//                parent.visibility = View.VISIBLE
//            }
//
//            override fun onAdHidden(p0: MaxAd) {
//                Log.i("ADCONFIG_HomeBanner", "onAdHidden")
//            }
//
//            override fun onAdClicked(p0: MaxAd) {
//                Log.i("ADCONFIG_HomeBanner", "onAdClicked")
//            }
//
//            override fun onAdLoadFailed(p0: String, p1: MaxError) {
//                Log.i("ADCONFIG_HomeBanner", "onAdLoadFailed:$p0:$p1")
////                container.visibility = View.GONE
////                parent.visibility = View.GONE
//            }
//
//            override fun onAdDisplayFailed(p0: MaxAd, p1: MaxError) {
//                Log.i("ADCONFIG_HomeBanner", "onAdDisplayFailed:$p0:$p1")
//            }
//
//            override fun onAdExpanded(p0: MaxAd) {
//                Log.i("ADCONFIG_HomeBanner", "onAdExpanded")
//            }
//
//            override fun onAdCollapsed(p0: MaxAd) {
//                Log.i("ADCONFIG_HomeBanner", "onAdCollapsed")
//            }
//        })
//
//        maxBanner?.setRevenueListener { maxAd -> LogEvent.logEvent(maxAd) }
//        // Stretch to the width of the screen for banners to be fully functional
//        val width = ViewGroup.LayoutParams.MATCH_PARENT
//
//        // Banner height on phones and tablets is 50 and 90, respectively
//        val heightPx = resources.getDimensionPixelSize(R.dimen.banner_height)
//        maxBanner?.layoutParams = FrameLayout.LayoutParams(width, heightPx)
//        container.addView(maxBanner)
//        maxBanner?.loadAd()
//
//    }

    private fun getAdSize(): AdSize {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()
//        val adWidth = AdsParameters(this).adWidth
        Log.e("TAG", "adWidth:$adWidth")
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
            this, adWidth
        )
    }

    private fun showDropDown(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)

        val popupWindow = PopupWindowHelper(popUpBinding.root)

//        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
        popUpBinding.menuCover.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 0)
        //popUpBinding.menuExclude.beVisibleIf(binding.viewPager.currentItem == 0)

//        popUpBinding.menuLock.beVisibleIf(binding.viewPager.currentItem == 0)
        popUpBinding.llMain.beVisible()
        popUpBinding.llCover.beGone()

        var needToAddFav = false
        var needToRemoveFav = false
        var videoSelected = false

        if (binding.viewPager.currentItem == 1) {
            val selectedItem = getSelectedPhotos()
            for (i in selectedItem.indices) {
                val model: MediaData = selectedItem[i] as MediaData
                if (model.isVideo || model.filePath.isGif()) videoSelected = true
                if (model.isFavorite)
                    needToRemoveFav = true
                else
                    needToAddFav = true
            }
        }

        popUpBinding.menuEdit.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuSetAs.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuResize.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1 && !videoSelected)
        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
//        popUpBinding.menuAddFavourite.beVisibleIf(binding.viewPager.currentItem == 1 )
//        popUpBinding.menuRemoveFavourite.beVisibleIf(binding.viewPager.currentItem == 1 )
        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)

//        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem == 1)
        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1 && binding.viewPager.currentItem != 2)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (mSelectedItem == 1) {
//                    requestStoragePermission(app_rename_AFA_allow_nf, app_rename_AFA_denied_nf, getActivityName()) {
//                        if (it) {
                    showAlbumRenameDialog()
//                        }
//                    }
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (mSelectedItem == 1) {
//                    requestStoragePermission(app_rename_AFA_allow_nf, app_rename_AFA_denied_nf, getActivityName()) {
//                        if (it) {
                    showMediaRenameDialog()
//                        }
//                    }
                }
            }
        }

        popUpBinding.menuCover.setOnClickListener {
//            popupWindow.dismiss()
            popUpBinding.llMain.beGone()
            popUpBinding.llCover.beVisible()
            popupWindow.dismiss()
            popupWindow.showAsPopUp(view)
        }

        popUpBinding.selectPhoto.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0)
                if (mSelectedItem == 1) setCoverImage()

        }
        popUpBinding.useDefault.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0)
                if (mSelectedItem == 1) setDefaultCoverImage()
        }

        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) {
//                requestStoragePermission(app_edit_AFA_allow_nf, app_edit_AFA_denied_nf, getActivityName()) {
//                    if (it) {
                openEditor()
//                    }
//                }
            }

        }

//        var needToLock = false
//        var needToUnLock = false

//        if (binding.viewPager.currentItem == 0) {
//            val selectedItem = albumFragment.getSelected()
//            for (i in selectedItem.indices) {
//                val model: AlbumData = selectedItem[i] as AlbumData
//                if (preferences.isFolderProtected(model.folderPath))
//                    needToUnLock = true
//                else
//                    needToLock = true
//            }
//        }
//
//        popUpBinding.menuLock.beVisibleIf(needToLock)
//        popUpBinding.menuUnlock.beVisibleIf(needToUnLock)

//        popUpBinding.menuLock.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) albumFragment.tryLockFolder()
//        }
//        popUpBinding.menuUnlock.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) albumFragment.tryUnLockFolder()
//        }

        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) setAs()
        }

        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) showResizeDialog()
        }

//        popUpBinding.menuExclude.setOnClickListener {
//            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0) {
//                if (!preferences.hintExclude) {
//                    val hintDialog = AnimHintDialog(
//                        this@HomeActivity,
//                        getString(R.string.hint_exclude_msg),
//                        R.drawable.hint_exclude_anim,
//                        updateListener = { btnClicked, isDontShowChecked ->
//                            preferences.hintExclude = isDontShowChecked
//                            if (btnClicked == 1) {
//                                addToExclude()
//                            }
//
//                        })
//                    hintDialog.show()
//                } else {
//                    addToExclude()
//                }
//            }
//        }

        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) setFavorite(true)

        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 1) setFavorite(false)
        }

        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) showAlbumDetailDialog()
            if (binding.viewPager.currentItem == 1) showMediaDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    albumList.filter { it.isSelected }.forEach { album ->
                        selectedAlbum.add(album.folderPath) // Add selected album
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                            }
                        }
                    }
                    showAddAlbumDialog(
                        Constant.deviceAlbumList,
                        selectImage,
                        selectedAlbum,
                        true
                    )


                }
            } else if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set
                    showAddAlbumDialog(
                        Constant.deviceAlbumList,
                        selectImage,
                        selectedAlbum,
                        true
                    )
                }
            }
        }

        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
            if (binding.viewPager.currentItem == 0) {
                if (selectedAlbumCount == 0) {
                    toast(getString(R.string.PleaseSelectAlbum))
                } else {
//                    requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                        if (it) {

                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    albumList.filter { it.isSelected }.forEach { album ->
                        selectedAlbum.add(album.folderPath) // Add selected album
                        album.mediaData.forEach { picture ->
                            if (picture is MediaData) {
                                selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                            }
                        }
                    }
                    showAddAlbumDialog(
                        albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                        selectImage,
                        selectedAlbum,
                        false
                    )
//                        }
//                    }
                }
            } else if (binding.viewPager.currentItem == 1) {
                if (selectedPhotosCount == 0) {
                    toast(getString(R.string.PleaseSelectImage))
                } else {
//                    requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                        if (it) {

                    val selectedAlbum = ArrayList<String>()
                    val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                    pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
                        .filter { it.isSelected } // Filter selected MediaData objects
                        .forEach { selectImage.add(it) } // Add to the set
                    showAddAlbumDialog(
                        albumList.filter { it.isCustomAlbum == false } as ArrayList<AlbumData>,
                        selectImage,
                        selectedAlbum,
                        false
                    )
//                        }
//                    }
                }
            }
        }

        popupWindow.showAsPopUp(view)

    }

    private fun openEditor() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val path = selectImage[0].filePath
            val newPath = path.removePrefix("file://")
            openEditorIntent(newPath)
        } else {
            toast(getString(R.string.PleaseSelectImage))
        }
    }

    private fun setDefaultCoverImage() {
        try {
            val albumData = albumList.firstOrNull { it.isSelected }
            preferences.setCoverImage(albumData!!.folderPath, "")
            setCloseToolbar()
            refreshData()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setCoverImage() {
        try {
            val albumData = albumList.firstOrNull { it.isSelected }
            albumData?.let {
                val addAlbumDialog = SelectAlbumImageFullDialog(
                    this@HomeActivity,
                    it.mediaData,
                    selectPathListener = { selectPath ->
                        preferences.setCoverImage(albumData.folderPath, selectPath)
                        //setCopyMove(isCopy, selectPath, selectImage)
                        setCloseToolbar()
                        refreshData()
                    },
                    createAlbumListener = {

                    })
                addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }


    private fun showAddAlbumDialog(
        albums: ArrayList<AlbumData>,
        selectedMedia: ArrayList<MediaData>,
        selectedAlbum: ArrayList<String>,
//        selectedAlbum: ArrayList<AlbumData>,
        isCopy: Boolean
    ) {
//        val selectedAlbum = ArrayList<AlbumData>()
//        val selectImage = mutableSetOf<MediaData>() // Use a set to avoid duplicates
//        albumList.filter { it.isSelected }.forEach { album ->
//            selectedAlbum.add(album) // Add selected album
//            album.mediaData.forEach { picture ->
//                if (picture is MediaData) {
//                    selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
//                }
//            }
//        }

//        pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
//            .filter { it.isSelected } // Filter selected MediaData objects
//            .forEach { selectImage.add(it) } // Add to the set

        val uniqueSelectImage = ArrayList(selectedMedia.distinctBy { it.filePath })

        for (media in uniqueSelectImage) {
            Log.e("uniqueSelectImage", "uniqueSelectImage-->:${media.filePath}")
        }

//        val addAlbumDialog =
//            SelectAlbumFullDialog(
//                this@HomeActivity,
//                albums,
//                selectedAlbum,
//                isCopy,
//                selectPathListener = { selectPath ->
//                    setCopyMove(isCopy, selectPath, uniqueSelectImage)
//                },
//                createAlbumListener = {
////                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) { value ->
////                        if (value) {
//                    val createDialog = CreateAlbumDialog(this@HomeActivity, createPathListener = {
//                        setCopyMove(isCopy, it, uniqueSelectImage)
//                    })
//                    createDialog.show()
////                        }
////                    }
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

        isCopyForResult = isCopy
        selectImageForResult = uniqueSelectImage
        val selectAlbumIntent = Intent(this, SelectAlbumFullActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)

    }

    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }

    private fun setCopyMove(
        isCopy: Boolean, selectPath: String, selectImage: java.util.ArrayList<MediaData>,
    ) {
        Log.e("newAlbum", "setCopyMove:$selectPath")
        if (isCopy) {
            Utils.copyFiles(
                this@HomeActivity,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
//                        MediaScannerConnection.scanFile(it, arrayOf<String>(selectPath), null) { path, uri -> }
                    selectedAlbumCount = 0
//                getData()
//                longClickListener(false, 0, false)
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    refresh()
//                        Handler(Looper.getMainLooper()).postDelayed({
//                        setCloseToolbar()
//                        }, 500)

//                        Handler(Looper.getMainLooper()).postDelayed({
//                            sendEvent("refresh")
//                        }, 500)
                })
        } else {
            Utils.moveFiles(this@HomeActivity, selectPath, selectImage, selectImage.size, moveListener = {
//                    MediaScannerConnection.scanFile(it, arrayOf<String>(selectPath), null) { path, uri -> }
                toast(getString(R.string.move_successfully))
                selectedAlbumCount = 0
//            getData()
//            longClickListener(false, 0, false)
                preferences.refreshMedia = true
                preferences.scanMedia = true
//                    Handler(Looper.getMainLooper()).postDelayed({
                refresh()
//                    }, 500)
            })
        }

    }

    private fun showAlbumDetailDialog() {
        try {
            val albumData = albumList.filter { it.isSelected }
            val detailsDialog = AlbumDetailsDialog(this, albumData[0], false)
            detailsDialog.show()
        } catch (e: IndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showMediaDetailsDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val pictureData = selectImage[0]

            val detailsDialog = DetailsDialog(this@HomeActivity, pictureData, false)
            detailsDialog.show()
        } else {
            toast(getString(R.string.PleaseSelectImage))
        }

    }

    private fun setFavorite(isFavorite: Boolean) {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath)) favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath)) favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
//        preferences.refreshMedia=true

        runOnUiThread {
            setCloseToolbar()
            refreshData()
//            updateData()
        }
    }

    private fun showAlbumRenameDialog() {
        Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")
        val albumData = albumList.firstOrNull { it.isSelected }
        if (albumData != null) {
            val renameDialog = RenameFolderDialog(
                this,
                albumData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    Log.e("AlbumRenameDialog", "albumList.renamePath:${renamePath},oldPath:$oldPath,albumData:${albumData.folderPath}")
                    try {
                        try {
                            scanPathRecursively(albumData.folderPath) {}
                        } catch (e: Exception) {
                        }
                        albumList.removeAll { it.folderPath == albumData.folderPath }
                        Log.e("AlbumRenameDialog", "albumList.size:${albumList.size}")
                    } catch (e: Exception) {
                        Log.e("AlbumRenameDialog", "albumList.Exception:${e}")
                    }
                    runOnUiThread {
//                        MediaScannerConnection.scanFile(this, arrayOf<String>(oldPath), null) { path, uri -> }
                        setClose()
                        setToolbarSelectionMaintain(false, 0, false)
//                        setCloseToolbar()
                        refreshData()
                    }
                })
            renameDialog.show()
        }
    }

    private fun showMediaRenameDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val pictureData = selectImage[0]
            val renameDialog =
                RenameDialog(
                    this,
                    pictureData,
                    positiveBtnClickListener = { renamePath, oldPath ->
//                        sendEvent("rename")
                        MediaScannerConnection.scanFile(this, arrayOf<String>(oldPath), null) { path, uri -> }
                        MediaScannerConnection.scanFile(this, arrayOf<String>(renamePath), null) { path, uri -> }
                        runOnUiThread {
                            notifyAdapter()
                        }
                    })

            renameDialog.show()
        } else {
            toast(getString(R.string.PleaseSelectImage))
        }
    }

    private fun initSearchAdapter() {
        timeLineAdapter = TimeLineAdapter(this, clickListener = { albumData ->
            openCutomImageList(albumData)
        })
        timeLineAdapter?.submitList(timeList)
        binding.searchTab.timeLineRecycler.layoutManager =
            GridLayoutManager(this, 1, GridLayoutManager.HORIZONTAL, false)
        binding.searchTab.timeLineRecycler.setHasFixedSize(false)
        binding.searchTab.timeLineRecycler.adapter = timeLineAdapter
    }

    private fun initAlbumAdapter() {

        albumAdapter = AlbumAdapter(
            this@HomeActivity,
            clickListener = {
                val albumData = albumList[it]
                if (albumData.isCheckboxVisible) {
                    if (!albumData.isCustomAlbum) {
                        albumData.isSelected = !albumData.isSelected
                        albumAdapter?.notifyItemChanged(it)
                        setSelectedAlbum()
                    }
                } else {
                    if (albumData.isCustomAlbum) {
                        if (albumData.mediaData.size != 0) {
                            if (albumData.title == getString(R.string.all_videos)) {
                                val intent = Intent(this@HomeActivity, VideoAlbumActivity::class.java)
                                intent.putExtra("title", "${albumData.title}")
                                startActivity(intent)
                            } else if (albumData.title == getString(R.string.Favorite)) {
                                val intent = Intent(this@HomeActivity, FavouriteListActivity::class.java)
                                intent.putExtra("title", "${albumData.title}")
                                startActivity(intent)
                            } else {
                                openImageList(albumData)
                            }
                        } else {
                            //startActivity(Intent(this@HomeActivity, MediaActivity::class.java))
                        }
                    } else {
                        openImageList(albumData)
                    }
                }
            }, longClickListener = {
                if (!albumList[it].isCustomAlbum) {
                    lastLongPressedAlbum = it
                    binding.albumTab.albumRecycler.setDragSelectActive(it)
                    lastLongPressedAlbum = if (lastLongPressedAlbum == -1) {
                        it
                    } else {
                        val min = min(lastLongPressedAlbum, it)
                        val max = max(lastLongPressedAlbum, it)
                        for (i in min..max) {
                            toggleMediaSelection(true, i, false)
                        }
                        it
                    }

                    val pictureData = albumList[it] as AlbumData
                    for (i in albumList.indices) {
                        val model = albumList[i] as AlbumData
                        model.isCheckboxVisible = true
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedAlbum()
                }
            },
            utilClickListener = { utilPos ->
                when (utilPos) {
                    0 -> {//llRecent

                        val recentList = fetchRecentMedia(this@HomeActivity)
                        val recentAlbum = AlbumData(
                            getString(R.string.recent),
                            //mediaData = recentList,
                            isCustomAlbum = true
                        )
                        recentAlbum.mediaData.addAll(recentList)
                        openImageList(recentAlbum)
                    }

                    1 -> {
                        //llAllVideo
//                        val recentAlbum=AlbumData(
//                            getString(R.string.Favorite),
//                            pictureData = recentList,
//                            isCustomAlbum = true
//                        )
                        val intent = Intent(this@HomeActivity, VideoAlbumActivity::class.java)
                        intent.putExtra("title", getString(R.string.all_videos))
                        startActivity(intent)
                    }

                    2 -> {//llFavorite
                        val intent = Intent(this@HomeActivity, FavouriteListActivity::class.java)
                        intent.putExtra("title", getString(R.string.Favorite))
                        startActivity(intent)
                    }

                    3 -> {//llDuplicate
                        startActivity(Intent(this@HomeActivity, DuplicateFinderActivity::class.java))
                    }

                    4 -> {//llHidden
                        val intent = Intent(this@HomeActivity, LockActivity::class.java)
                        lockActivityResultLauncher.launch(intent)
                    }

                    5 -> {//llTimeLine
                        startActivity(Intent(this@HomeActivity, TimeLineActivity::class.java))
                    }

                    6 -> {//llMaps
                        startActivity(Intent(this@HomeActivity, MapAlbumActivity::class.java))
                    }

                    7 -> {//llNote
                        startActivity(Intent(this@HomeActivity, NotesActivity::class.java))
                    }

//                    8 -> {//llBrowser
//                        startActivity(Intent(this@HomeActivity, WebBrowserActivity::class.java))
//                    }

                    9 -> {//llPdf
//                        val intent=Intent(mActivity, RecoverMediaActivity::class.java)
//                        startActivity(intent)
                        val intent = Intent(this@HomeActivity, SelectImageActivity::class.java)
                        intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_PDF)
                        intent.putExtra(Constant.EXTRA_INCLUDE_VIDEO, false)
                        startActivity(intent)
                    }

                }

            })
        albumAdapter?.submitList(albumList)
        binding.albumTab.albumRecycler.itemAnimator = null
        binding.albumTab.albumRecycler.adapter = albumAdapter

        binding.albumTab.albumRecycler.post {
            FastScroller(binding.albumTab.albumHandle).bind(binding.albumTab.albumRecycler)
        }

    }

    protected fun selectMediaRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleMediaSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleMediaSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleMediaSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleMediaSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleMediaSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleMediaSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleMediaSelection(false, i, true)
                }
            }
        }
    }

    private fun toggleMediaSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
        try {

            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is MediaData) {

                if (select) {
                    (pictures[pos] as MediaData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as MediaData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
            pictureAdapter?.notifyItemChanged(pos)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        setSelectedMedia()

    }

    private fun selectAlbumRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleAlbumSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleAlbumSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleAlbumSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleAlbumSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleAlbumSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleAlbumSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleAlbumSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleAlbumSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {

        if (albumList[pos] is AlbumData) {
            if (select && !albumList[pos].isCustomAlbum) {
                albumList[pos].isSelected = true
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                albumList[pos].isSelected = false
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.remove(itemKey)
            }
        }

        albumAdapter?.notifyItemChanged(pos)
        setSelectedAlbum()
    }

    private fun initPhotoAdapter() {
//        binding.mediaFastscroller.attachFastScrollerToRecyclerView(binding.pictureRecycler)
//        preferences.saveObjectList(pictures)
        pictureAdapter = PictureAdapter(
            this@HomeActivity,
            clickListener = {
                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    if (mediaData.isCheckboxVisible) {
                        mediaData.isSelected = !mediaData.isSelected
                        pictureAdapter?.notifyItemChanged(it)
                        setSelectedMedia()
                    } else {
                        val dataList = ArrayList<MediaData>()
                        var displayPos = 0
                        for (i in pictures.indices) {
                            if (pictures[i] is MediaData) {
                                dataList.add(pictures[i] as MediaData)
                                if (it == i) {
                                    displayPos = dataList.size - 1
                                }
                            }
                        }
                        Constant.displayImageList = ArrayList()
                        Constant.displayImageList.addAll(dataList)
                        Constant.selectedPosition = displayPos
//                        val intent = Intent(activity, ImageViewerActivity::class.java)
                        if (Constant.displayImageList.size > 0) {
                            val intent = Intent(this@HomeActivity, PhotoVideoActivity::class.java)
                            intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
                            startActivity(intent)
                        }
                        setBackAlbumData()
                    }
                }
            },
            longClickListener = {
//            binding.swipeRefreshPhotos.isRefreshing = false
//            binding.swipeRefreshPhotos.isEnabled = false
                lastLongPressedMedia = it
                binding.photosTab.pictureRecycler.setDragSelectActive(it)
                lastLongPressedMedia = if (lastLongPressedMedia == -1) {
                    it
                } else {
                    val min = min(lastLongPressedMedia, it)
                    val max = max(lastLongPressedMedia, it)
                    for (i in min..max) {
                        toggleMediaSelection(true, i, false)
                    }
//                    updateTitle()
                    it
                }

                if (pictures[it] is MediaData) {
                    val mediaData = pictures[it] as MediaData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is MediaData) {
                                val model = pictures[i] as MediaData
                                model.isCheckboxVisible = true
                            }
                    }
                    mediaData.isCheckboxVisible = true
                    mediaData.isSelected = true
                    notifyAdapter()
                    setSelectedMedia()
                }

            },
            headerSelectListener = {
                if (pictures[it] is AlbumData) {
                    val albumData = pictures[it] as AlbumData
                    val isSelectAll = !albumData.isSelected
                    albumData.isSelected = isSelectAll
                    var pos = it + 1
                    while (pos < pictures.size) {
                        if (pictures[pos] is MediaData) {
                            val model = pictures[pos] as MediaData
                            model.isSelected = isSelectAll
                            pos++
                        } else if (pictures[pos] is AlbumData) {
                            break
                        }
                    }
                    notifyAdapter()
                    setSelectedMedia()
                }
            }
        )

        pictureAdapter?.submitList(pictures)
        binding.photosTab.pictureRecycler.itemAnimator = null
        binding.photosTab.pictureRecycler.adapter = pictureAdapter

        binding.photosTab.pictureRecycler.post {
            FastScroller(binding.photosTab.photosHandle).bind(binding.photosTab.pictureRecycler)
        }

    }

    private fun setSelectedMedia() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        pictureAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is MediaData) {
                val model = pictures[i] as MediaData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    pictureAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.photosTab.swipeRefreshPhotos.isEnabled = false
        selectedPhotosCount = selected
    }

    private fun setSelectedAlbum() {
        var selected = 0
        var allItemCount = 0
        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in albumList.indices) {
            if (albumList[i] is AlbumData) {
                val model = albumList[i] as AlbumData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.albumTab.swipeRefreshAlbum.isEnabled = false
//        binding.swipeRefreshAlbum.isEnabled = selected == 0
        selectedAlbumCount = selected
    }

    private fun reducePhotoGrid() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid > 2) {
            preferences.setGridCount(selectedGrid - 1)
        }
        setPhotoColumn()
    }

    private fun increasePhotoGrid() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_PICTURE) {
            preferences.setGridCount(selectedGrid + 1)
        }
        setPhotoColumn()
    }

    private fun reduceAlbumGrid() {
        val selectedGrid = preferences.getAlbumGridCount() ?: 0
        if (selectedGrid > 2) {
            preferences.setAlbumGridCount(selectedGrid - 1)
        }
        setAlbumColumn()
    }

    private fun increaseAlbumGrid() {
        val selectedGrid = preferences.getAlbumGridCount() ?: 0
        if (selectedGrid < MAX_COLUMN_COUNT_ALBUM) {
            preferences.setAlbumGridCount(selectedGrid + 1)
        }
        setAlbumColumn()
    }

    private fun setPhotoColumn() {
        binding.photosTab.pictureRecycler.post {
            (binding.photosTab.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount = preferences.getGridCount()
            pictureAdapter?.apply {
                notifyItemRangeChanged(0, pictures.size)
            }
        }
        setRvLayoutManager()
    }

    private fun setAlbumColumn() {
        (binding.albumTab.albumRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getAlbumGridCount() ?: 3
        albumAdapter?.apply {
            notifyItemRangeChanged(0, albumList.size)
        }
        setRvLayoutManager()
    }

    fun notifyAdapter() {

        binding.albumTab.albumRecycler.post {
            if (albumAdapter != null) {
//            albumAdapter?.notifyDataSetChanged()
                albumAdapter?.submitList(albumList)
                albumAdapter?.notifyItemRangeChanged(0, albumList.size)
            }
        }
        binding.photosTab.pictureRecycler.post {
            if (pictureAdapter != null) {
                //pictureAdapter?.notifyDataSetChanged()
                pictureAdapter?.submitList(pictures)
                pictureAdapter?.notifyItemRangeChanged(0, pictures.size)
            }
        }
    }

    private fun refresh() {
        preferences.refreshMedia = true
        setCloseToolbar()
        refreshData()
//        Handler(Looper.getMainLooper()).postDelayed({
//        sendEvent("refresh")
//        }, 500)
    }

//    private fun addToExclude() {
//        val albumData = albumList.filter { it.isSelected }
//        val excludeList: ArrayList<String> = ArrayList()
//        preferences.getExcludeList().let { excludeList.addAll(it) }
//        for (i in albumData.indices) {
//            if (albumData[i] is AlbumData) {
//                val model = albumData[i] as AlbumData
//                if (model.isSelected && model.folderPath.isNotEmpty()) {
//                    if (!excludeList.contains(model.folderPath)) excludeList.add(model.folderPath)
//                }
//            }
//        }
//        preferences.setExcludeList(excludeList)
//        preferences.refreshMedia = true
//
//        setCloseToolbar()
//        refreshData()
//    }

    private fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)

    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${pictures.size} ")
        albumList.forEach { item ->
            if (item is AlbumData) {
                item.isSelected = false
                item.isCheckboxVisible = false
                Log.e("", "setClose==>> AlbumData selection false")
            }
        }
        pictures.forEach { item ->
            when (item) {
                is AlbumData -> {
                    item.isSelected = false
                    item.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                }

                is MediaData -> {
                    item.isSelected = false
                    item.isCheckboxVisible = false
                    Log.e("", "setClose==>> PictureData selection false")
                }
            }
        }
//        for (i in albumList.indices) {
//            if (albumList[i] != null)
//                if (albumList[i] is AlbumData) {
//                    val model = albumList[i] as AlbumData
//                    model.isSelected = false
//                    model.isCheckboxVisible = false
//                    Log.e("", "setClose==>> AlbumData selection false")
//                }
//        }
//        for (i in pictures.indices) {
//            if (pictures[i] != null)
//                if (pictures[i] is AlbumData) {
//                    val model = pictures[i] as AlbumData
//                    model.isSelected = false
//                    model.isCheckboxVisible = false
//                    Log.e("", "setClose==>> AlbumData selection false")
//                } else if (pictures[i] is MediaData) {
//                    val model = pictures[i] as MediaData
//                    model.isCheckboxVisible = false
//                    model.isSelected = false
//                    Log.e("", "setClose==>> PictureData selection false")
//                }
//        }

        binding.photosTab.swipeRefreshPhotos.isEnabled = true
        binding.albumTab.swipeRefreshAlbum.isEnabled = true
//        notifyAdapter()
        setRvLayoutManager()
//        getAlbumData()
//        getPhotoData()
        selectedPhotosCount = 0
    }

    private fun showResizeDialog() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] is MediaData) {
                val model: MediaData = pictures[i] as MediaData
                if (model.isSelected) {
                    selectImage.add(model)
                }
            }
        }

        if (selectImage.isNotEmpty()) {
            val pictureData = selectImage[0]
            val resizeDialog =
                ResizeDialog(
                    this,
                    pictureData,
                    updateImageListener = { path ->
                        val file = File(path)
                        pictures.add(0, MediaData(path, file.name, file.parent!!, file.lastModified(), file.lastModified(), file.length()))
                    })
            resizeDialog.show()
        } else {
            toast(getString(R.string.PleaseSelectImage))
        }
    }

    private fun setAs() {
        val selectImage = pictures.filterIsInstance<MediaData>()
            .filter { it.isSelected }

        val pictureData = selectImage.firstOrNull()

//        val selectImage: ArrayList<MediaData> = ArrayList()
//        for (i in pictures.indices) {
//            if (pictures[i] != null)
//                if (pictures[i] is MediaData) {
//                    val model: MediaData = pictures[i] as MediaData
//                    if (model.isSelected) {
//                        selectImage.add(model)
//                    }
//                }
//        }
//        val pictureData = selectImage[0]

        ensureBackgroundThread {
            val newUri =
                pictureData?.let { getFinalUriFromPath(it.filePath, BuildConfig.APPLICATION_ID) }
                    ?: return@ensureBackgroundThread
            Intent().apply {
                action = Intent.ACTION_ATTACH_DATA
                setDataAndType(newUri, getUriMimeType(pictureData.filePath, newUri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(this, getString(R.string.set_as))

                try {
                    startActivityForResult(chooser, 101)
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.no_app_found)
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
        }
    }

    private fun openCamera() {
        try {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            AdsConfig.isSystemDialogOpen = true
            startActivity(cameraIntent)
            preferences.refreshMedia = true
        } catch (e: Exception) {
            Log.e("printStackTrace", "printStackTrace:$e")
            toast(getString(R.string.not_found))
        }
    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (checkStoragePermission())
                openCamera()
            else
                requestPermission()
        }

//    var permissionLauncher2 =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
//            if (checkStoragePermissionReadMedia())
//                getData()
//        }

//    var callerLauncher =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
//            Log.e("checkCaller", "callerLauncher")
//            val readPhoneState =
//                ContextCompat.checkSelfPermission(
//                    this@HomeActivity,
//                    Manifest.permission.READ_PHONE_STATE
//                ) == 0
//            val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                Settings.canDrawOverlays(this@HomeActivity)
//            } else {
//                true
//            }
//            if (canDrawOverlays) {
//                LogEvent.logCallerCard("CAD_OVERLAY_ALLOW_PERMISSION")
//            } else {
//                LogEvent.logCallerCard("CAD_OVERLAY_DENY_PERMISSION")
//            }
//            binding.icCall.beGoneIf(canDrawOverlays && readPhoneState && !callerCadBaseConfig.callerCadEnable)
//            if (readPhoneState) {
//                if (canDrawOverlays) {
//                    callerDialog?.dismiss()
//                } else {
//                    requestSystemOverlayPermission()
//                }
//            } else checkCaller()
//
//        }

//    private fun closeSearch() {
////        binding.icSearchClear.visibility = View.GONE
//        binding.groupToolbarHeader.visibility = View.VISIBLE
////        binding.groupSearch.visibility = View.GONE
////        binding.edtSearch.setText("")
////        hideKeyboard(binding.edtSearch)
//        if (tabPos == 0) {
//            if (albumFragment != null)
//                albumFragment.setSwipeRefreshEnabled(true)
//        } else if (tabPos == 1) {
//            if (photosFragment != null) {
//                photosFragment.setSwipeRefreshEnabled(true)
//                photosFragment.isCheckSearchOn = false
//            }
//        }
//    }

//    private fun isSearchShow(): Boolean {
//        if (binding.icSearchBack.visibility == View.VISIBLE && binding.edtSearch.visibility == View.VISIBLE)
//            return true
//        return false
//    }

    private fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun showKeyboard(view: EditText) {
        view.requestFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }


    private fun showHomeMenuFilter(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = HomeMenuFilterBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)
        popupWindow.showAsDropDown(view, 0, 0)

//        val popupView = popUpBinding.root
//        val params = LinearLayout.LayoutParams(
//            ViewGroup.LayoutParams.WRAP_CONTENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//        params.setMargins(0, 0, 50, 60)
//        popupView.layoutParams = params
//        val popupWindow = PopupWindow(
//            popupView,
//            ViewGroup.LayoutParams.WRAP_CONTENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT, true
//        )
//        popupWindow.animationStyle = R.style.PopupAnimations

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        var resultAll = 0
//        resultAll += FILTER_IMAGES
//        resultAll += FILTER_VIDEOS
//        resultAll += FILTER_GIFS
        resultAll += TYPE_IMAGES
        resultAll += TYPE_VIDEOS
        resultAll += TYPE_GIFS
//        resultAll += TYPE_RAWS
//        resultAll += TYPE_SVGS
//        resultAll += TYPE_PORTRAITS

        var resultPhoto = 0
        resultPhoto += TYPE_IMAGES
//        resultPhoto += TYPE_VIDEOS
//        resultPhoto += TYPE_GIFS
//        resultPhoto += TYPE_RAWS
//        resultPhoto += TYPE_SVGS
//        resultPhoto += TYPE_PORTRAITS

        var resultVideo = 0
//        resultVideo += TYPE_IMAGES
        resultVideo += TYPE_VIDEOS
//        resultVideo += TYPE_GIFS
//        resultVideo += TYPE_RAWS
//        resultVideo += TYPE_SVGS
//        resultVideo += TYPE_PORTRAITS

        var resultGif = 0
//        resultGif += TYPE_IMAGES
//        resultGif += TYPE_VIDEOS
        resultGif += TYPE_GIFS
//        resultGif += TYPE_RAWS
//        resultGif += TYPE_SVGS
//        resultGif += TYPE_PORTRAITS

        popUpBinding.tvAll.setTextColor(resources.getColor(R.color.black_text))
        popUpBinding.tvPhoto.setTextColor(resources.getColor(R.color.black_text))
        popUpBinding.tvVideo.setTextColor(resources.getColor(R.color.black_text))
        popUpBinding.tvGif.setTextColor(resources.getColor(R.color.black_text))

        when (preferences.getFilterMedia()) {
            resultAll -> {
                popUpBinding.tvAll.setTextColor(resources.getColor(R.color.color_primary))
            }

            resultPhoto -> {
                popUpBinding.tvPhoto.setTextColor(resources.getColor(R.color.color_primary))
            }

            resultVideo -> {
                popUpBinding.tvVideo.setTextColor(resources.getColor(R.color.color_primary))
            }

            resultGif -> {
                popUpBinding.tvGif.setTextColor(resources.getColor(R.color.color_primary))
            }
        }

        popUpBinding.ivAll.setOnClickListener {
            popupWindow.dismiss()

            var result = 0
            result += TYPE_IMAGES
            result += TYPE_VIDEOS
            result += TYPE_GIFS
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS

            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.all)

            getData()
//            sendEvent("get_data")
        }

        popUpBinding.ivPhoto.setOnClickListener {
            popupWindow.dismiss()
            var result = 0
            result += TYPE_IMAGES
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS
            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.photos)

            getData()
//            sendEvent("get_data")
        }

        popUpBinding.ivVideo.setOnClickListener {
            popupWindow.dismiss()
            var result = 0
//            result += TYPE_IMAGES
            result += TYPE_VIDEOS
//            result += TYPE_GIFS
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS
            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.videos)

            getData()
//            sendEvent("get_data")
        }

        popUpBinding.ivGif.setOnClickListener {
            popupWindow.dismiss()
            var result = 0
//            result += TYPE_IMAGES
//            result += TYPE_VIDEOS
            result += TYPE_GIFS
//            result += TYPE_RAWS
//            result += TYPE_SVGS
//            result += TYPE_PORTRAITS
            preferences.setFilterMedia(result)
            binding.txtTitle.text = getString(R.string.gifs)

            getData()
//            sendEvent("get_data")
        }

    }

    private fun setFilterMenu() {

    }

    private fun showMenu() {
        val dialog = HomeMenuDialog(this, binding.viewPager.currentItem, clickListener = {
            when (it) {
                1 -> {
                    showSortDialog()
                }

                2 -> {
                    val filterMediaDialog = FilterMediaDialog(this@HomeActivity, updateListener = {
                        getData()
//                        sendEvent("get_data")
                    })
                    filterMediaDialog.show()
                }

                21 -> {
                    setRvLayoutManager()
                }

                22 -> {
                    setRvLayoutManager()
                }

                3 -> {
//                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) {
//                        if (it) {
                    showCreateAlbum()
//                        }
//                    }
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        this, "",
                        binding.viewPager.currentItem == 0,
                        updateListener = {
                            setRvLayoutManager()
                        })
                    displayColumnsDialog.show()

                }

                5 -> {
                    //btnRecycleBin
                    val intent = Intent(this, RecentlyDeleteActivity::class.java)
                    recycleLauncher.launch(intent)
                }

                6 -> {
                    //btnFamilyApps
                    val i = Intent(Intent.ACTION_VIEW)
                    i.data = Uri.parse("https://play.google.com/store/apps/developer?id=galleryappa")
                    AdsConfig.isSystemDialogOpen = true
                    startActivity(i)
                    //startActivity(Intent(this, FamilyAppActivity::class.java))
                }

                7 -> {
                    //btnFeedback
//                    val intent = Intent(this, FeedbackActivity::class.java)
//                    startActivity(intent)
                }

                8 -> {
                    //btnSetting
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }

                9 -> {
                    //showGroupByDialog
                    showGroupByDialog()
                }

            }
        })
        dialog.show()
    }

    var recycleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            getData()
//            sendEvent("get_data")
        }

    private fun showCreateAlbum() {
        val createDialog = CreateAlbumDialog(this, createPathListener = { newAlbum ->
            setCloseToolbar()
            refreshData()
            val intent = Intent(this, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_CRATE_ALBUM)
            intent.putExtra(Constant.EXTRA_ALBUM_PATH, newAlbum)
            startActivity(intent)
        }, true)
        createDialog.show()
    }

    private fun showSortDialog() {
        val key = "frag_${binding.viewPager.currentItem}"
        val sortDialog = SortDialog(this, key, updateListener = {
            getData()
//            sendEvent("get_data")
        })
        sortDialog.show()
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(updateListener = {
            setPhotoGroup()
        })
        groupDialog.show(supportFragmentManager, groupDialog.tag)
    }

    private fun checkForceAppUpdate(remoteConfig: FirebaseRemoteConfig) {

        Log.e("checkForceAppUpdate", "checkForceAppUpdate")

        remoteConfig.setConfigSettingsAsync(
            FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(5)
                .setFetchTimeoutInSeconds(5)
                .build()
        )
        remoteConfig.setDefaultsAsync(R.xml.remote_config_defaults)

        // Fetch the remote config
        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
//            if (task.isSuccessful) {
//                try {
//                    val forceUpdate = remoteConfig.getString("force_update")
//                    val jsonForceUpdateObj = JSONObject(forceUpdate)
//
//                    val isNeedToShow = jsonForceUpdateObj.getBoolean("isNeedToShow")
//                    val isCancelable = jsonForceUpdateObj.getBoolean("isCancelable")
//                    val cancelCounter = jsonForceUpdateObj.getInt("cancel_counter")
//                    val latestVersion = jsonForceUpdateObj.getString("latest_version")
//                    val updateDescription = jsonForceUpdateObj.getString("update_description")
//                    val updateFeatures = jsonForceUpdateObj.getString("features")
//                    val displayFromVersion = jsonForceUpdateObj.getInt("display_from_version")
//
//                    Log.d("checkForceAppUpdate", "isNeedToShow:${isNeedToShow}")
//                    Log.d("checkForceAppUpdate", "isCancelable:${isCancelable}")
//                    Log.d("checkForceAppUpdate", "cancelCounter:${cancelCounter}")
//                    Log.d("checkForceAppUpdate", "latestVersion:${latestVersion}")
//                    Log.d("checkForceAppUpdate", "updateDescription:${updateDescription}")
//                    Log.d("checkForceAppUpdate", "updateFeatures:${updateFeatures}")
//                    Log.d("checkForceAppUpdate", "displayFromVersion:${displayFromVersion}")
//
////                    GalleryApp.forceUpdateModel = UpdateModel(
//                    val forceUpdateModel = UpdateModel(
//                        isNeedToShow = isNeedToShow,
//                        isCancelable = isCancelable,
//                        cancelCounter = cancelCounter,
//                        latestVersion = latestVersion,
//                        updateDescription = updateDescription,
//                        updateFeatures = updateFeatures,
//                        displayFromVersion = displayFromVersion,
//                    )
//
//                    if (isNeedToShow
//                        && BuildConfig.VERSION_CODE <= forceUpdateModel.displayFromVersion
//                        && preferences.updateCancelCounter <= forceUpdateModel.cancelCounter
//                    ) {
//                        val updateDialog = UpdateDialog(this, forceUpdateModel)
//                        updateDialog.setCancelable(forceUpdateModel.isCancelable)
//                        updateDialog.show()
//
//                        updateDialog.setOnDismissListener {
//                            var updateCancelCounter = preferences.updateCancelCounter
//                            updateCancelCounter++
//                            preferences.updateCancelCounter = updateCancelCounter
//                        }
//                    } else {
//                        preferences.updateCancelCounter = 0
//                        checkInAppUpdate()
//                    }
//
//                } catch (e: Exception) {
//                    Log.d("checkForceAppUpdate", "Exception:${e.message}")
//                    checkInAppUpdate()
//                }
//            } else {
//                Log.d("checkForceAppUpdate", "Failed:${task.exception}")
//                checkInAppUpdate()
//            }
        }
    }

    private fun checkInAppUpdate() {
        try {
            appUpdateInstallerManager.addAppUpdateListener(appUpdateInstallerListener)
            appUpdateInstallerManager.startCheckUpdate()
        } catch (e: Exception) {
            Log.e("UpdateListener", "checkAppUpdate.Exception:$e")
        }
    }

    private val appUpdateInstallerManager: AppUpdateInstallerManager by lazy {
        InAppUpdateInstallerManager(this)
    }

    private val appUpdateInstallerListener by lazy {
        object : AppUpdateInstallerListener() {
            override fun onDownloadedButNotInstalled() {
                Log.e("UpdateListener", "onDownloadedButNotInstalled")
                popupSnackBarForCompleteUpdate()
            }

            override fun onFailure(e: Exception) {
                Log.e("UpdateListener", "onFailure:$e")
            }

            override fun onNotUpdate() {
                Log.e("UpdateListener", "onNotUpdate")
            }

            override fun onCancelled() {
                Log.e("UpdateListener", "onCancelled")
            }

            override fun onStatus(@InstallStatus status: Int) {
                Log.e("UpdateListener", "onStatus:$status")
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == 101) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
////                if (Settings.canDrawOverlays(this@MainActivity)) {
////                    customPermissionEvent("home_draw_over_granted")
//                AdsConfig.isSystemDialogOpen = true
////                        AdsConfig.isSystemDialogOpen = true
//                val readPhoneState =
//                    ContextCompat.checkSelfPermission(
//                        this@HomeActivity,
//                        Manifest.permission.READ_PHONE_STATE
//                    ) == 0
//                val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                    Settings.canDrawOverlays(this@HomeActivity)
//                } else {
//                    true
//                }
//
//                if (readPhoneState && canDrawOverlays) {
////                    adsPref.isShowCallInfo = true
//                    if (!callerCadBaseConfig.callerCadEnable) {
//                        binding.icCall.beGone()
//                        Log.e("checkCaller.icCall", "onActivityResult.icCall.beGone")
//                    }
//                    callerDialog?.dismiss()
//                } else {
//                    if (callerCadBaseConfig.callerCadEnable) {
//                        binding.icCall.beVisible()
//                        Log.e("checkCaller.icCall", "onActivityResult.icCall.beVisible")
//                    }
//                    var closeCounter = adsPref.closeCounter
//                    closeCounter++
//                    adsPref.closeCounter = closeCounter
//                    if (!callerCadBaseConfig.callerCadPermissionDialogDismiss) {
//                        checkCaller()
//                    }
//                }
//
//            }
//        }
        appUpdateInstallerManager.onActivityResult(requestCode, resultCode, data)
    }

    private fun popupSnackBarForCompleteUpdate() {
        val snackBar = Snackbar.make(
            findViewById(android.R.id.content),
            "An update has just been downloaded.",
            Snackbar.LENGTH_INDEFINITE
        )
        snackBar.setAction("RESTART") { appUpdateInstallerManager.completeUpdate() }
        snackBar.setActionTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        snackBar.show()
    }

    //    var exitDialog: ExitDialog? = null
    var isRatingDialogOpened: Boolean = false
    override fun onBackPressed() {
        Log.e(
            "onBackPressed",
            "preferences.appOpenCounter.onBackPressed:${preferences.sessionCounter}"
        )
//        if (exitDialog != null && exitDialog!!.isShowing) {
//            Log.e("onBackPressed", "onBackPressed.001")
//            exitDialog!!.dismiss()
//        } else {
        Log.e("onBackPressed", "onBackPressed.002")
        if (binding.viewPager.currentItem == 1 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
            refreshData()
        } else if (binding.viewPager.currentItem == 0 && binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
            refreshData()
        } else if (binding.viewPager.currentItem != 0) {
            binding.viewPager.currentItem = 0
        } else if (!preferences.isRatingDone && !isRatingDialogOpened && listOf(
                1,
                3,
                6,
                9
            ).contains(preferences.sessionCounter)
        ) {
            Log.e("onBackPressed", "onBackPressed.003")
            isRatingDialogOpened = true
//            val rateDialog = RatingDialog(this)
//            rateDialog.show()
//            rateDialog.setOnDismissListener {
            showExitDialog()
//            }
        } else {
            showExitDialog()
        }
//        }
    }

    private fun showExitDialog() {
        val exitDialog = ExitDialog(this) { isExit ->
            if (isExit) {
                finishAffinity()
            }
        }
        AdsConfig.isSystemDialogOpen = true
        if (!exitDialog.isShowing) {
            Log.e("onBackPressed", "onBackPressed.006")
            exitDialog.show()
        }
    }

    private fun loadExitAds() {
        Log.e("native_exit", "loadAds.mNativeAd")
//        if (preferences.isNeedInterAd) {
//            AdmobIntersAdImpl().load(this)
//        }
        mAdmobNative = AdmobNative()
        Log.e("loadAds", "loadAds.mNativeAd")

//        if (AdCache.exitNative == null) {
//            mAdmobNative.preLoad(this, { isLoaded, nativeAd ->
//                Log.e("native_exit", "preLoad:$isLoaded")
//                if (isLoaded) {
//                    AdCache.exitNative = nativeAd
//                }
//            }, adId)
//        }

    }
}