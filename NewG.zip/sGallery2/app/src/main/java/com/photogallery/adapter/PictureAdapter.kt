package com.photogallery.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.ItemHeaderBinding
import com.photogallery.databinding.ItemPictureBinding
import com.photogallery.extension.getFilenameExtension
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.loadImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PictureAdapter(
    var context: Activity,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val headerSelectListener: (pos: Int) -> Unit,
    var needShowMore: Boolean = false,
    var showMoreAfter: Int = 10
) : ListAdapter<Any, RecyclerView.ViewHolder>(DiffCallBack())
//    , RecyclerViewFastScroller.OnPopupTextUpdate
//    , OnPopupUpdate {
{

    fun setShowMore(showMore: Boolean, count: Int) {
        needShowMore = showMore
        showMoreAfter = count
        notifyDataSetChanged()
    }

    fun getCurruentListData() = currentList
    val ITEM_PHOTOS_TYPE = 2
    val ITEM_HEADER_TYPE = 1
    var preferences: Preferences = Preferences(context)

    override fun onViewAttachedToWindow(holder: RecyclerView.ViewHolder) {
        super.onViewAttachedToWindow(holder)
    }

    override fun onViewDetachedFromWindow(holder: RecyclerView.ViewHolder) {
        super.onViewDetachedFromWindow(holder)
    }

    private class DiffCallBack : DiffUtil.ItemCallback<Any>() {
        override fun areItemsTheSame(oldItem: Any, newItem: Any) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: Any, newItem: Any) = oldItem == newItem
    }

    override fun getItemViewType(position: Int): Int {
        return if (position in 0..<itemCount) {
            if (getItem(position) is AlbumData) {
                ITEM_HEADER_TYPE
            } else {
                ITEM_PHOTOS_TYPE
            }
        } else -1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_HEADER_TYPE) {
            val binding =
                ItemHeaderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        } else {
            val binding =
                ItemPictureBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            PictureViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
//        if (position >= 0 && position < itemCount)

        holder.itemView.tag = holder
        if (position in 0..<itemCount) {
            if (getItemViewType(position) == ITEM_HEADER_TYPE) {
                val headerViewHolder: HeaderViewHolder =
                    holder as HeaderViewHolder

                val albumData = getItem(position) as AlbumData
//            headerViewHolder.itemView.tag=albumData.folderPath
//            holder.itemView.tag = holder

                var strDate: String = albumData.title
                val calendar = Calendar.getInstance()
                val format = SimpleDateFormat(Constant.dateFormat, Locale.ENGLISH)
                val today = format.format(calendar.timeInMillis)
                calendar.add(Calendar.DATE, -1)
                val yesterday = format.format(calendar.timeInMillis)

                if (albumData.title == today) strDate = context.getString(R.string.Today)
                else if (albumData.title == yesterday) strDate =
                    context.getString(R.string.Yesterday)

                if (preferences.getShowFileCount()) {
                    strDate += " (${albumData.mediaData.size})"
                }

                headerViewHolder.binding.txtHeader.text = strDate

            } else {

                val pictureViewHolder = holder as PictureViewHolder
                val mediaData: MediaData = getItem(position) as MediaData

                context.loadImage(
                    path = mediaData.filePath,
                    target = pictureViewHolder.binding.image,
                    signature = mediaData.getKey(),
                    onError = {
                        pictureViewHolder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                        pictureViewHolder.binding.image.setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_image_placeholder))
                    }
                )

                try {
                    pictureViewHolder.binding.ivGif.beVisibleIf(
                        mediaData.filePath.endsWith(
                            "gif",
                            true
                        )
                    )
                } catch (e: Exception) {
                }
                pictureViewHolder.binding.icVideo.visibility =
                    if (mediaData.isVideo) View.VISIBLE else View.GONE

                try {
                    if (mediaData.isCheckboxVisible) {
                        pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
                        pictureViewHolder.binding.icSelect.visibility =
                            if (mediaData.isSelected) View.VISIBLE else View.GONE
                        pictureViewHolder.binding.icFavourite.visibility = View.GONE
                    } else {
                        pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                        pictureViewHolder.binding.icSelect.visibility = View.GONE

                        pictureViewHolder.binding.icFavourite.visibility =
                            if (mediaData.isFavorite) View.VISIBLE else View.GONE
                    }
                } catch (e: Exception) {
                }

                holder.binding.loutMain.setOnClickListener {
                    try {
                        clickListener.invoke(position)
                    } catch (e: Exception) {
                    }
                }
                holder.binding.loutMain.setOnLongClickListener {
                    try {
                        longClickListener.invoke(position)
                    } catch (e: Exception) {
                    }
                    true
                }
            }
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is PictureViewHolder) {
//            holder.clear()
//            if (!context.isDestroyed) {
            Glide.with(context.application).clear(holder.binding.image)
////                val itemView = holder.itemView
////                val tmb = itemView.allViews.firstOrNull { it.id == R.id.image }
////                if (tmb != null) {
////                    Glide.with(context).clear(tmb)
////                }
//            }

        }
    }

    inner class HeaderViewHolder(var binding: ItemHeaderBinding) : RecyclerView.ViewHolder(binding.root)

    inner class PictureViewHolder(var binding: ItemPictureBinding) : RecyclerView.ViewHolder(binding.root)
//    {
//        private var viewHolderJob = Job()
//        private var viewHolderScope = CoroutineScope(Dispatchers.Main + viewHolderJob)
//
//        fun bind(filePath: String) {
//            viewHolderJob = Job()
//            viewHolderScope = CoroutineScope(Dispatchers.Main + viewHolderJob)
//
//            loadThumbnail(filePath)
//        }
//
//        fun clear() {
//            viewHolderJob.cancel()
//            //    viewHolderScope.cancel() // cancel ongoing thumbnail generation if any
//            binding.image.setImageResource(R.drawable.ic_image_placeholder) // set placeholder
//        }
//        fun loadThumbnail(filePath: String) {
//            viewHolderScope.launch {
//                try {
//                    var thumbnail = thumbnailCache.get(filePath)
//                    if (thumbnail == null) {
//                        thumbnail = withContext(Dispatchers.IO) {
//                            generateThumbnail(context, filePath)
//                        }
//                        if (thumbnail != null) {
//                            thumbnailCache.put(filePath, thumbnail)
//                        }
//                    }
//                    if (thumbnail != null) {
//                        binding.image.setImageBitmap(thumbnail)
//                    } else {
//                        binding.image.setImageResource(R.drawable.ic_image_placeholder)
//                    }
//                } catch (e: Exception) {
//                    Log.e("PictureAdapter", "loadThumbnail.Exception:$e")
//                    binding.image.setImageResource(R.drawable.ic_image_placeholder)
//                }
//            }
//        }
//    }


    //    var dateFormat = "dd/mm/y"
//    var dateFormat = Constant.dateFormat
//    var timeFormat = if (preferences.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12

    fun getBubbleText(adapterPosition: Int): String {
        var bubbleText = ""
        try {
            val data = getItem(adapterPosition)
            val grouping = preferences.getGroupBy()
            if (data is MediaData) {
                bubbleText = getBubbleText(data, grouping, Constant.dateFormat, Constant.timeFormat)
            }
        } catch (e: java.lang.IndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: IndexOutOfBoundsException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return bubbleText
    }

    private fun getBubbleText(
        albumData: MediaData,
        grouping: Int,
        dateFormat: String? = null,
        timeFormat: String? = null,
    ): String {
        var strKey = """"""
        when (grouping) {
            Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
                strKey = DateFormat.format(
                    "$dateFormat, $timeFormat",
                    File(albumData.filePath).lastModified()
                ).toString()
            }

            Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
                strKey = DateFormat.format(
                    "$dateFormat, $timeFormat",
                    File(albumData.filePath).lastModified()
                ).toString()
            }

            Constant.GROUP_BY_FILE_TYPE -> {
                strKey = albumData.fileName.getFilenameExtension()
            }

            Constant.GROUP_BY_EXTENSION -> {
                strKey = albumData.fileName.getFilenameExtension()
            }

            Constant.GROUP_BY_FOLDER -> {
                strKey = albumData.fileName.getParentFolder().getFilenameFromPath()
            }

            Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> {
                strKey = DateFormat.format(
                    "MMMM yyyy, $timeFormat",
                    File(albumData.filePath).lastModified()
                ).toString()
            }

            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> {
                strKey = DateFormat.format(
                    "MMMM yyyy, $timeFormat",
                    File(albumData.filePath).lastModified()
                ).toString()
            }

            Constant.GROUP_BY_NONE -> {
                strKey = albumData.fileName
            }

            else -> strKey = albumData.fileName
        }

        Log.e("PictureAdapter", "getBubbleText.002:$grouping, $strKey")
        return strKey
    }

}