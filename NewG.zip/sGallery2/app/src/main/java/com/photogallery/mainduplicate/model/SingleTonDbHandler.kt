package com.photogallery.mainduplicate.model

import android.content.Context

class SingleTonDbHandler(var singleTonDbHandlerContext: Context) {
    val instance: com.photogallery.mainduplicate.model.DBHandler?
        get() {
            if (mInstance == null) {
                mInstance =
                    com.photogallery.mainduplicate.model.DBHandler(
                        singleTonDbHandlerContext
                    )
            }
            return mInstance
        }

    companion object {
        var mInstance: com.photogallery.mainduplicate.model.DBHandler? = null
    }
}