package com.photogallery.mainduplicate.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.mainduplicate.callbacks.MarkedListener
import com.photogallery.mainduplicate.model.IndividualGroupModel
import com.photogallery.mainduplicate.model.ItemDuplicateModel
import com.photogallery.mainduplicate.GlobalVarsAndFunctions
import java.util.*

class IndividualDocumentAdapter(
    var individualDocumentAdapterContext: Context,
    var documentsMarkedListener: MarkedListener,
    var groupOfDupesDocuments: List<IndividualGroupModel>) : RecyclerView.Adapter<IndividualDocumentAdapter.DocumentViewHolder>() {

    var mLayoutManager: LinearLayoutManager? = null

    class DocumentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var checkBox: CheckBox = itemView.findViewById<View>(R.id.cb_grp_checkbox) as CheckBox
        var recyclerView: RecyclerView = itemView.findViewById<View>(R.id.rv_documents) as RecyclerView
        var textView: TextView = itemView.findViewById(R.id.tv_grp_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DocumentViewHolder {
        return DocumentViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.adapter_media_document, parent, false)
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: DocumentViewHolder, position: Int) {
        val individualGroup = groupOfDupesDocuments[position]
        holder.textView.text = "Set " + individualGroup.groupTag
        holder.checkBox.isChecked = individualGroup.isCheckBox
        mLayoutManager = LinearLayoutManager(individualDocumentAdapterContext)

        val lListDocumentAdapter = ListDocumentAdapter(individualDocumentAdapterContext, documentsMarkedListener, groupOfDupesDocuments[position],
            individualGroup.individualGrpOfDupes!!, holder.checkBox)
        holder.recyclerView.layoutManager = mLayoutManager
        holder.recyclerView.adapter = lListDocumentAdapter

        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                individualGroup.isCheckBox = isChecked
                val listDocumentAdapter1 = ListDocumentAdapter(individualDocumentAdapterContext, documentsMarkedListener, groupOfDupesDocuments[position], setCheckBox(individualGroup.individualGrpOfDupes, isChecked), holder.checkBox)
                holder.recyclerView.adapter = listDocumentAdapter1
                listDocumentAdapter1.notifyDataSetChanged()
            }
        }
    }

    override fun getItemCount(): Int {
        return groupOfDupesDocuments.size
    }

    private fun setCheckBox(documentItems: List<ItemDuplicateModel>?, value: Boolean): List<ItemDuplicateModel> {
        val lListOfDupes: MutableList<ItemDuplicateModel> = ArrayList()
        for (i in documentItems!!.indices) {
            val documentItem = documentItems[i]
            when {
                i != 0 -> {
                    if (!value) {
                        com.photogallery.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_documents.remove(documentItem)
                        com.photogallery.mainduplicate.GlobalVarsAndFunctions.subSizeDocuments(documentItem.sizeOfTheFile)
                        documentsMarkedListener.updateMarked()
                    } else if (!documentItem.isFileCheckBox) {
                        com.photogallery.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_documents.add(documentItem)
                        com.photogallery.mainduplicate.GlobalVarsAndFunctions.addSizeDocuments(documentItem.sizeOfTheFile)
                        documentsMarkedListener.updateMarked()
                    }
                    documentItem.isFileCheckBox = value
                    lListOfDupes.add(documentItem)
                }
                documentItem.isFileCheckBox -> {
                    com.photogallery.mainduplicate.GlobalVarsAndFunctions.file_to_be_deleted_documents.remove(documentItem)
                    documentItem.isFileCheckBox = false
                    lListOfDupes.add(documentItem)
                }
                else -> {
                    documentItem.isFileCheckBox = false
                    lListOfDupes.add(documentItem)
                }
            }
        }
        return lListOfDupes
    }
}