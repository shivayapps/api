package com.photogallery.interfaces;

public interface hidedone {
        void hideComplete();
    }