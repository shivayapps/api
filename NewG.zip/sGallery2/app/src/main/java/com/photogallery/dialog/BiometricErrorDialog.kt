package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import androidx.core.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.TextView
import androidx.biometric.BiometricManager
import androidx.viewbinding.ViewBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogBiometricErrorBinding


class BiometricErrorDialog(
    var mContext: Context,
    val btnClickListener: (isEnable: Boolean) -> Unit,
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogBiometricErrorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
        //window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.navigationBarColor = ContextCompat.getColor(mContext, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
//                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
//                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        bindingDialog = DialogBiometricErrorBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

//    override fun onDismiss(dialog: DialogInterface) {
//        super.onDismiss(dialog)
//        btnClickListener.invoke(false)
//    }

    private fun intView() {
        val isSupportWithErrorInfo=isSupportWithErrorInfo(
            mContext,
            BiometricManager.Authenticators.BIOMETRIC_STRONG,
        )
        bindingDialog.txtMsg.text=isSupportWithErrorInfo.second
        bindingDialog.btnCancel.setOnClickListener { dismiss() }
        bindingDialog.btnOk.setOnClickListener {
            dismiss()
            btnClickListener.invoke(true)
        }
    }

    fun isSupportWithErrorInfo(
        ctx: Context,
        type: Int,
    ): Pair<Boolean, String?> {
        val biometricManager = BiometricManager.from(ctx)
        val authStatusCode = biometricManager.canAuthenticate(type)

        Log.e("BiometricManager","isSupportWithErrorInfo\nauthStatusCode:$authStatusCode\n,type:$type")

        if (authStatusCode == BiometricManager.BIOMETRIC_STATUS_UNKNOWN ||
            authStatusCode == BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED ||
            authStatusCode == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
        ) {
            return Pair(false, mContext.getString(R.string.device_unsupported))
        } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE) {
            return Pair(false, mContext.getString(R.string.setting_biometric_error_hardware_unavailable))
        } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED) {
            return Pair(false, mContext.getString(R.string.setting_biometric_error_not_secure))
        } else if (authStatusCode == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) {
            return Pair(false, mContext.getString(R.string.setting_biometric_error_none_enrolled))
        }

        return Pair(true, null)
    }


//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)

}