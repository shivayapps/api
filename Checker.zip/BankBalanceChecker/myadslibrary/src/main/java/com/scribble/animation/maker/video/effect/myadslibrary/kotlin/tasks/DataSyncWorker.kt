package com.scribble.animation.maker.video.effect.myadslibrary.kotlin.tasks

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.api.ApiHelper
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.api.RetrofitBuilder
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.db.AppDatabase
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.db.entity.AppEntity
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.db.entity.IdEntity
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.model.AppModel
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.repository.MainRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

class DataSyncWorker(val appContext: Context, workerParams: WorkerParameters)
    : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "DataSyncWorker"
    }

    override suspend fun doWork(): Result = coroutineScope {

        val mainRepository = MainRepository(ApiHelper(RetrofitBuilder.apiService))
        val db = AppDatabase.getInstance(appContext)

        val jobs = async {
            val model = mainRepository.getData()

            if (model.status == "1" && model.message == "success") {

                db.AppDao().deleteAll()
                db.AppDao().clearPrimaryKey()
                model.data?.forEach {
                    it?.let {
                        db.AppDao().insert(AppEntity(
                                it.position!!,
                                it.name!!,
                                it.app_link!!,
                                it.image!!,
                                it.is_trending!!
                        ))
                    }

                    /* val mo: AppEntity? = db.AppDao().getApp(it.app_link)
                     mo?.let { s ->
                         if (is_equals(s, it)) {
                             db.AppDao().update(AppEntity(
                                     0,
                                     it.position,
                                     it.name,
                                     it.app_link,
                                     it.image,
                                     it.is_trending
                             ))
                         }
                     } ?: db.AppDao().insert(AppEntity(
                             0,
                             it.position,
                             it.name,
                             it.app_link,
                             it.image,
                             it.is_trending
                     ))*/
                }
            } else {
                throw RuntimeException("Fetching data failed")
            }

        }

        val jobs1 = async {
            val model = mainRepository.getIds()

            if (model.status == "1" && model.message == "success") {

                db.IdDao().deleteAll()
                db.IdDao().clearPrimaryKey()
                model.data?.forEach {dataitem ->
                    dataitem?.let {
                       it.advertisement?.forEach {ad_list->
                           ad_list.let {
                               it?.token?.forEach {
                                   val model = IdEntity(
                                           0,
                                           dataitem.id!!,
                                           dataitem.name!!,
                                           ad_list!!.adCategoryId!!,
                                           ad_list!!.adCategoryName!!,
                                           it.google,
                                           it.facebook
                                   )
                                   db.IdDao().insert(model)
                               }
                           }
                       }
                    }


                }
            } else {
                throw RuntimeException("Fetching data failed")
            }

        }

        try {
            jobs1.await()
            jobs.await()
            Log.e(TAG, "doWork: " )
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure()
        }
    }

    private fun is_equals(it: AppEntity, model: AppModel): Boolean {
        if (it.position != model.position) {
            return false
        }
        if (it.name != model.name) {
            return false
        }
        if (it.app_link != model.app_link) {
            return false
        }
        if (it.image != model.image) {
            return false
        }
        if (it.is_trending != model.is_trending) {
            return false
        }
        return true
    }
}