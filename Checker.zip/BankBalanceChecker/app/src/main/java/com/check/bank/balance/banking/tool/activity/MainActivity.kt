package com.check.bank.balance.banking.tool.activity

import android.Manifest
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.check.bank.balance.banking.tool.reminder.AlarmActivity
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.BankingAdapter
import com.check.bank.balance.banking.tool.adapter.CalculatorAdapter
import com.check.bank.balance.banking.tool.helper.NetworkHelper
import com.check.bank.balance.banking.tool.helper.OfflineNativeAdvanced
import com.check.bank.balance.banking.tool.model.BankingModel
import com.check.bank.balance.banking.tool.model.Currency
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.karumi.dexter.Dexter
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.single.PermissionListener
import com.scribble.animation.maker.video.effect.myadslibrary.dialog.ExitDialogFragment
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.Helper
import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs
import com.scribble.animation.maker.video.effect.myadslibrary.task.BlurBuilder
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.contain_home_screen.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

//    private var mApiClient = APIClient()

    lateinit var mRVBanking: RecyclerView
    lateinit var mRVCalculator: RecyclerView
    lateinit var mBankingLayout: RecyclerView.LayoutManager
    lateinit var mCalLayout: RecyclerView.LayoutManager
    lateinit var mBankingAdapter: BankingAdapter
    lateinit var mCalAdapter: CalculatorAdapter
    lateinit var mBReminder: Button
    lateinit var mTVInd: TextView
    lateinit var mTVUsd: TextView
    lateinit var mToolbar: Toolbar
    var exitDialogFragment: ExitDialogFragment? = null
    var mIsSubScribe: Boolean = false
    private var mInterstitialAdExit: InterstitialAd? = null
    var mEnquiry: ConstraintLayout? = null
    var mSMS: ConstraintLayout? = null
    var mHoliday: ConstraintLayout? = null
    var mUSSD: ConstraintLayout? = null
    var mNetBanking: ConstraintLayout? = null
    var mNearATM: ConstraintLayout? = null
    var mFD: CardView? = null
    var mLoan: CardView? = null
    var mSIP: CardView? = null
    var mEMI: CardView? = null
    private var lastClickTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
//        mRVBanking = findViewById(R.id.mRVBanking)
//        mRVCalculator = findViewById(R.id.mRVCalculator)
        mBReminder = findViewById(R.id.mBReminder)
        mEnquiry = findViewById(R.id.constraintLayout4)
        mSMS = findViewById(R.id.constraintLayout5)
        mHoliday = findViewById(R.id.constraintLayout6)
        mUSSD = findViewById(R.id.constraintLayout10)
        mNetBanking = findViewById(R.id.constraintLayout9)
        mNearATM = findViewById(R.id.constraintLayout8)
        mSIP = findViewById(R.id.cardViewSIP)
        mLoan = findViewById(R.id.cardViewLoan)
        mEMI = findViewById(R.id.cardViewEMI)
        mFD = findViewById(R.id.cardViewFD)
//        mTVInd = findViewById(R.id.mTVInd)
//        mTVUsd = findViewById(R.id.mTVUsd)

        hideSystemUI()
        setBGExitDialog()
        imgView1.setPadding(0, statusBar(), 0, 0)
        loadExitInterstitialAds()

        mIVSetting.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            startActivity(Intent(this, SettingActivity::class.java))
        }

        Glide.with(this).load(R.drawable.ic_home_background).into(findViewById<ImageView>(R.id.imageBackground))

        mNearATM!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val gmmIntentUri = Uri.parse("geo:0,0?q=atm")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)
//            Dexter.withContext(this@MainActivity)
//                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
//                .withListener(object : PermissionListener {
//                    override fun onPermissionGranted(response: PermissionGrantedResponse) {
//              val gmmIntentUri = Uri.parse("geo:0,0?q=atm")
//                  val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
//                  mapIntent.setPackage("com.google.android.apps.maps")
//                  startActivity(mapIntent)
//                    }
//
//                    override fun onPermissionDenied(response: PermissionDeniedResponse) {
////                        Toast.makeText(
////                            this@MainActivity,
////                            "Permission Required",
////                            Toast.LENGTH_LONG
////                        ).show()
//                        if (response.isPermanentlyDenied) {
//                            val builder = AlertDialog.Builder(this@MainActivity)
//                            builder.setTitle("Permission Required")
//                            builder.setMessage("Location Permission is required to Access Location")
//                            builder.setPositiveButton("OK") { dialog, which ->
//                                dialog.dismiss()
//                                val intent =
//                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//                                val uri =
//                                    Uri.fromParts("package", packageName, null)
//                                intent.data = uri
//                                startActivity(intent)
//                            }
//                            builder.setNegativeButton("Cancel") { dialog, which -> dialog.dismiss() }
//                            builder.create().show()
//                        }
//                    }
//
//                    override fun onPermissionRationaleShouldBeShown(
//                        permission: PermissionRequest?,
//                        token: PermissionToken?
//                    ) {
////                        Toast.makeText(
////                            this@MainActivity,
////                            "Permission Required",
////                            Toast.LENGTH_SHORT
////                        ).show()
//                        token?.continuePermissionRequest()
//                    }
//                }).check()
        }

        mNetBanking!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(this@MainActivity, BankActivity::class.java).putExtra("mobile", 3).putExtra("head", 11)
            startActivity(intent)
        }
        mUSSD!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            Dexter.withContext(this@MainActivity)
                .withPermission(Manifest.permission.CALL_PHONE)
                .withListener(object : PermissionListener {
                    override fun onPermissionGranted(response: PermissionGrantedResponse) {
//                        val callIntent = Intent(Intent.ACTION_CALL)
//                        callIntent.data = Uri.parse("tel:$position")
//                        startActivity(callIntent)

                        val intent = Intent(this@MainActivity, USSDActivity::class.java).putExtra("mobile", 3)
                        startActivity(intent)
                    }

                    override fun onPermissionDenied(response: PermissionDeniedResponse) {
                        if (response.isPermanentlyDenied) {
                            val builder = AlertDialog.Builder(this@MainActivity)
                            builder.setTitle("Permission Required")
                            builder.setMessage("Dial Permission is required to Dial Phone")
                            builder.setPositiveButton("OK") { dialog, _ ->
                                dialog.dismiss()
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                val uri = Uri.fromParts("package", packageName, null)
                                intent.data = uri
                                startActivity(intent)
                            }
                            builder.setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                            builder.create().show()
                        }
                    }

                    override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest?, token: PermissionToken?) {
//                        Toast.makeText(this@MainActivity, "Permission Required", Toast.LENGTH_SHORT).show()
                        token?.continuePermissionRequest()
                    }
                }).check()
        }

        mHoliday!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            startActivity(Intent(this@MainActivity, StateActivity::class.java))
        }
        mSMS!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(this@MainActivity, BankActivity::class.java).putExtra("mobile", 2)
            startActivity(intent)
        }

        mEnquiry!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            Dexter.withContext(this@MainActivity)
                .withPermission(Manifest.permission.CALL_PHONE)
                .withListener(object : PermissionListener {
                    override fun onPermissionGranted(response: PermissionGrantedResponse) {
//                        val callIntent = Intent(Intent.ACTION_CALL)
//                        callIntent.data = Uri.parse("tel:$position")
//                        startActivity(callIntent)
                        val intent = Intent(this@MainActivity, BankActivity::class.java).putExtra("mobile", 1).putExtra("nameset", "Enquiry")
                        startActivity(intent)
                    }

                    override fun onPermissionDenied(response: PermissionDeniedResponse) {
                        if (response.isPermanentlyDenied) {
                            val builder = AlertDialog.Builder(this@MainActivity)
                            builder.setTitle("Permission Required")
                            builder.setMessage("Dial Permission is required to Dial Phone")
                            builder.setPositiveButton("OK") { dialog, _ ->
                                dialog.dismiss()
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                val uri = Uri.fromParts("package", packageName, null)
                                intent.data = uri
                                startActivity(intent)
                            }
                            builder.setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
                            builder.create().show()
                        }
                    }

                    override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest?, token: PermissionToken?) {
//                        Toast.makeText(this@MainActivity,"Permission Required",Toast.LENGTH_SHORT).show()
                        token?.continuePermissionRequest()
                    }
                }).check()
        }


        val mBankingList: ArrayList<BankingModel> = arrayListOf()
        mBankingList.add(BankingModel(R.drawable.ic_balance_enquiry, "Balance\nEnquiry"))
        mBankingList.add(BankingModel(R.drawable.ic_sms_banking, "SMS\nBanking"))
        mBankingList.add(BankingModel(R.drawable.ic_net_banking, "NET\nBanking"))
        mBankingList.add(BankingModel(R.drawable.ic_near_atm, "Near\nATM"))
        mBankingList.add(BankingModel(R.drawable.ic_bank_holiday, "Bank\nHoliday"))
        mBankingList.add(BankingModel(R.drawable.ic_ussd_banking, "USSD\nBanking"))

        mBankingLayout = GridLayoutManager(this, 2)

        mBankingAdapter = BankingAdapter(this, mBankingList, object : BankingAdapter.ClickListener {
            override fun onItemClick(position: Int) {
                if (position == 0) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, BankActivity::class.java).putExtra("mobile", 1)
                    startActivity(intent)
                }
                if (position == 1) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, BankActivity::class.java).putExtra("mobile", 2)
                    startActivity(intent)
                }
                if (position == 2) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, BankActivity::class.java).putExtra("mobile", 3)
                    startActivity(intent)
                }
                if (position == 3) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    Dexter.withContext(this@MainActivity).withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        .withListener(object : PermissionListener {
                            override fun onPermissionGranted(response: PermissionGrantedResponse) {
                                val gmmIntentUri = Uri.parse("geo:0,0?q=atm")
                                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                                mapIntent.setPackage("com.google.android.apps.maps")
                                startActivity(mapIntent)
                            }

                            override fun onPermissionDenied(response: PermissionDeniedResponse) {
                                Toast.makeText(this@MainActivity, "Permission Required", Toast.LENGTH_LONG).show()
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                val uri = Uri.fromParts("package", packageName, null)
                                intent.data = uri
                                startActivity(intent)
                            }

                            override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest?, token: PermissionToken?) {
                                Toast.makeText(this@MainActivity, "Permission Required", Toast.LENGTH_SHORT).show()
                                token?.continuePermissionRequest()
                            }
                        }).check()
                }
                if (position == 4) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    startActivity(Intent(this@MainActivity, StateActivity::class.java))
                }
                if (position == 5) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, USSDActivity::class.java).putExtra("mobile", 3)
                    startActivity(intent)
                }
            }
        })
//        mRVBanking.layoutManager = mBankingLayout
//        mRVBanking.adapter = mBankingAdapter
//        val mCall: Call<Currency> = mApiClient.getClient().getData()
//        mCall.enqueue(object : Callback<Currency> {
//            override fun onFailure(call: Call<Currency>?, t: Throwable?) {
//                mCall.cancel()
//            }
//            override fun onResponse(call: Call<Currency>?, response: Response<Currency>?) {
//                val mRates = response!!.body()?.rates
//                if (mRates!=null){
//                    mTVInd.text = "₹" + DecimalFormat("##.##").format((mRates!!.iNR))
//                    mTVUsd.text = "$" + (mRates.uSD).toString()
//                }
//            }
//        })

        mFD!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 3)
            startActivity(intent)
        }

        mSIP!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 4)
            startActivity(intent)
        }

        mEMI!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 1)
            startActivity(intent)
        }

        mLoan!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
            lastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 2)
            startActivity(intent)
        }

        val mCalculatorList: ArrayList<String> = arrayListOf()
        mCalculatorList.add("EMI")
        mCalculatorList.add("LOAN")
        mCalculatorList.add("FD")
        mCalculatorList.add("SIP")

        mCalLayout = GridLayoutManager(this, 4)
        mCalAdapter = CalculatorAdapter(this, mCalculatorList, object : CalculatorAdapter.ClickListener {
            override fun onItemClick(position: Int) {
                if (position == 0) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 1)
                    startActivity(intent)
                }
                if (position == 1) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 2)
                    startActivity(intent)
                }
                if (position == 2) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 3)
                    startActivity(intent)
                }
                if (position == 3) {
                    if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = Intent(this@MainActivity, CalculatorActivity::class.java).putExtra("cal", 4)
                    startActivity(intent)
                }
            }
        })
//        mRVCalculator.layoutManager = mCalLayout
//        mRVCalculator.adapter = mCalAdapter

        mBReminder.setOnClickListener {
            if(checkSystemWritePermission()){
                if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
                lastClickTime = SystemClock.elapsedRealtime()
                startActivity(Intent(this, AlarmActivity::class.java))
            }
//            else {
//                if (SystemClock.elapsedRealtime() - lastClickTime < 2000) return@setOnClickListener
//                lastClickTime = SystemClock.elapsedRealtime()
//                startActivity(Intent(this, AlarmActivity::class.java))
//            }
        }
    }

    private fun setBGExitDialog() {
        BitmapBlurTask().execute()
    }

    inner class BitmapBlurTask : AsyncTask<Void?, Void?, Void?>() {
        override fun doInBackground(vararg p0: Void?): Void? {
            Log.d("TAG", "doInBackground: ")
            Glide.with(this@MainActivity).asBitmap().load(R.drawable.ic_bg_dashboard)
                .into(object : CustomTarget<Bitmap?>() {

                    override fun onLoadCleared(placeholder: Drawable?) {}

                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap?>?) {
                        val bmp: Bitmap = BlurBuilder.blur(this@MainActivity, resource)
                        Helper.mDrawable = BitmapDrawable(resources, bmp)
                    }
                })

            Log.d("TAG", "doInBackground: ")
            return null
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }

    private fun loadExitInterstitialAds() {
//        var adRequest = AdRequest.Builder().build()
//        val interstialAdId = AppIDs().getGoogleInterstitial()
//        mInterstitialAdExit = InterstitialAd(this)
//        mInterstitialAdExit!!.adUnitId = interstialAdId
//        mInterstitialAdExit!!.loadAd(adRequest)
//        mInterstitialAdExit!!.adListener = object : AdListener(){
//            override fun onAdClosed() {
//                super.onAdClosed()
//                Handler().postDelayed({
//                    startActivity(Intent(this@MainActivity, ExitActivity::class.java))
//                    finish()
//                }, 100)
//            }
//
//            override fun onAdFailedToLoad(p0: Int) {
//                super.onAdFailedToLoad(p0)
//            }
//
//            override fun onAdFailedToLoad(p0: LoadAdError?) {
//                super.onAdFailedToLoad(p0)
//            }
//
//            override fun onAdLeftApplication() {
//                super.onAdLeftApplication()
//            }
//
//            override fun onAdOpened() {
//                super.onAdOpened()
//            }
//
//            override fun onAdLoaded() {
//                super.onAdLoaded()
//            }
//
//            override fun onAdClicked() {
//                super.onAdClicked()
//            }
//
//            override fun onAdImpression() {
//                super.onAdImpression()
//            }
//        }
        Log.d("adsload", "loadExitInterstitialAds: ${AppIDs().getGoogleInterstitial()}")
        InterstitialAd.load(this, AppIDs().getGoogleInterstitial(), AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mInterstitialAdExit = null
                    Log.d("test11", "onAdFailedToLoad: $adError")
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAdExit = interstitialAd
                    Log.d("test11", "onAdLoaded: $interstitialAd")
                }
            })

        Log.d("ADS", "loadExitInterstitialAds: ${AppIDs().getGoogleInterstitial()}")
    }

    fun showInterstitialAd() {
        mInterstitialAdExit!!.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
//                super.onAdDismissedFullScreenContent()
                Log.d("showInterstitialAd", "Ad was dismissed.")
                Handler(Looper.getMainLooper()).postDelayed({
                    startActivity(Intent(this@MainActivity, ExitActivity::class.java))
                    finish()
                }, 100)
            }

            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
//                super.onAdFailedToShowFullScreenContent(p0)
                Log.d("showInterstitialAd", "Ad failed to show.")
            }

            override fun onAdShowedFullScreenContent() {
//                super.onAdShowedFullScreenContent()
                Log.d("showInterstitialAd", "Ad showed fullscreen content.")
                mInterstitialAdExit = null
            }
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        exitDialogFragment = ExitDialogFragment(object : ExitDialogFragment.OnButtonClickListener {
            override fun onPositive(exitDialogFragment: ExitDialogFragment?) {
                exitDialogFragment!!.dismiss()
//                finishAffinity()
                if (NetworkHelper.isOnline(this@MainActivity)) {
                    val progressDialog = ProgressDialog(this@MainActivity, R.style.CustomProgressBar)
                    progressDialog.setMessage("Loading Ad...")
                    progressDialog.setCancelable(false)
                    progressDialog.window!!.setLayout(AbsListView.LayoutParams.MATCH_PARENT, AbsListView.LayoutParams.WRAP_CONTENT)
                    if (mInterstitialAdExit != null) {
                        showInterstitialAd()
                        progressDialog.show()
                        Handler(Looper.getMainLooper()).postDelayed(Runnable {
                            progressDialog.dismiss()
                            mInterstitialAdExit!!.show(this@MainActivity)
                        }, 1000)
                    } else {
                        startActivity(Intent(this@MainActivity, ExitActivity::class.java))
                        finish()
                    }
                } else {
                    startActivity(Intent(this@MainActivity, ExitActivity::class.java))
                    finish()
                }
            }

            override fun onNegative(exitDialogFragment: ExitDialogFragment?) {
                exitDialogFragment!!.dismiss()
            }

            override fun onDismiss() {

            }
        }, mIsSubScribe)
        exitDialogFragment!!.isCancelable = false
        exitDialogFragment!!.show(supportFragmentManager, "ExitDialog")
    }

    override fun onResume() {
        super.onResume()
        loadExitInterstitialAds()
    }

    fun statusBar(): Int {
        var result: Int = 0
        try {
            result = 0
            val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
            if (resourceId > 0) {
                result = resources.getDimensionPixelSize(resourceId)
            }
        } catch (e: Exception) {
        }
        return result
    }

   fun checkSystemWritePermission(): kotlin.Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (android.provider.Settings.System.canWrite(this)) return true else openAndroidPermissionsMenu()
        }
        return false
    }

   fun openAndroidPermissionsMenu() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            var intent: Intent? = Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS)
            intent!!.data = android.net.Uri.parse("package:" + this.packageName)
            this.startActivity(intent)
        }
    }
}