package com.check.bank.balance.banking.tool.activity

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.check.bank.balance.banking.tool.R
import kotlinx.android.synthetic.main.custom_toolbar.*

class FirstUssdActivity : AppCompatActivity() {

    lateinit var mBList: Button
    lateinit var mBDial: Button
    lateinit var mToolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_ussd)

        hideSystemUI()
        mTVToolbar.text = "Setup USSD"
        imgBtnBack.setOnClickListener { onBackPressed() }

        mBDial = findViewById(R.id.mBDial)
        mBList = findViewById(R.id.mBList)

        mBList.setOnClickListener {
            startActivity(Intent(this, UssdBankActivity::class.java))
        }

        mBDial.setOnClickListener {
            Log.d("12121", "onCreate: ${isTelephonyEnabled()}")
            if(isTelephonyEnabled()){
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:*99%23")))
            }else{
                Toast.makeText(this, "This Service not available for this Device.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isTelephonyEnabled(): Boolean {
        val tm: TelephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager;
        return tm != null && tm.simState == TelephonyManager.SIM_STATE_READY
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }
}