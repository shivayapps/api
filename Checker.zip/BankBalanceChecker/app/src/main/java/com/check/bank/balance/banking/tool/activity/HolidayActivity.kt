package com.check.bank.balance.banking.tool.activity

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.adapter.HolidayAdapter
import com.check.bank.balance.banking.tool.model.StateModel
import kotlinx.android.synthetic.main.custom_toolbar.*
import org.json.JSONObject
import java.io.InputStream


class HolidayActivity : AppCompatActivity() {

    lateinit var mRVHoliday: RecyclerView
    lateinit var mHolidayLayout: LinearLayoutManager
    lateinit var mHolidayAdapter: HolidayAdapter
    lateinit var mToolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_holiday)
        mRVHoliday = findViewById(R.id.mRVHoliday)

        val state: String? = intent.getStringExtra("state")
        hideSystemUI()
        imgBtnBack.setOnClickListener { onBackPressed() }
        mTVToolbar.text="Holiday List"

        val mStateListModel: ArrayList<StateModel> = arrayListOf()

        val json: String?
//        val inputStream: InputStream = this.assets.open("state.json");
        val inputStream: InputStream = this.assets.open("holiday_2023.json");
        val size = inputStream.available();
        val buffer: ByteArray = ByteArray(size)
        inputStream.read(buffer);
        inputStream.close();
        json = String(buffer, charset("UTF-8"))

        val jsonRootObject = JSONObject(json)
        if (state != null) {
            val jsonObject = jsonRootObject.getJSONObject("states")
            val jsonArray = jsonObject.getJSONArray(state)
            for (i in 0 until jsonArray.length()) {
                val jsonObj = jsonArray.getJSONObject(i)
                val date = jsonObj.optString("Date").toString()
                val day = jsonObj.optString("Day").toString()
                val holiday = jsonObj.optString("Holiday").toString()
                mStateListModel.add(StateModel(date, day, holiday))
            }

            Log.d("mStateListModel", "onCreate: ${mStateListModel.size}")
            mHolidayLayout = LinearLayoutManager(this)
            mHolidayAdapter = HolidayAdapter(this, mStateListModel)
            mRVHoliday.layoutManager = mHolidayLayout
            mRVHoliday.adapter = mHolidayAdapter

        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }
}