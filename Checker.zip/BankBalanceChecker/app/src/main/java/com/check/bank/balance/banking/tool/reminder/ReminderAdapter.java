package com.check.bank.balance.banking.tool.reminder;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bignerdranch.android.multiselector.ModalMultiSelectorCallback;
import com.bignerdranch.android.multiselector.MultiSelector;
import com.bignerdranch.android.multiselector.SwappingHolder;
import com.check.bank.balance.banking.tool.Constants.Constant;
import com.check.bank.balance.banking.tool.R;

import java.text.SimpleDateFormat;

/**
 * Created by kyle on 22/09/16.
 */

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ViewHolder> {

    private MainFragment maintnConte2;
    private Context mContext;
    private Cursor mCursor;
    private isLongClick mListener;
    private ReminderDataHelper mDatabase;
    private SimpleDateFormat timeFormat = new SimpleDateFormat(" d MMM - yyyy");

    private MultiSelector mMultiSelector;
    private ModalMultiSelectorCallback mActionModeCallback;
    private MainFragment.EditListener mEditListener;

    public class ViewHolder extends SwappingHolder implements View.OnClickListener, View.OnLongClickListener {
        public TextView title;
        public TextView content;
        public TextView time;
        public ImageView icon;
        public ImageView imgSelect;
        public ImageView imgUnSelected;
        public CardView card_view;

        public ViewHolder(View view) {
            super(view, mMultiSelector);
//            view.setOnClickListener(this);
//            view.setOnLongClickListener(this);
            title = (TextView) view.findViewById(R.id.title);
            content = (TextView) view.findViewById(R.id.reminder);
            time = (TextView) view.findViewById(R.id.timeLabel);
            icon = (ImageView) view.findViewById(R.id.icon);
            imgSelect = (ImageView) view.findViewById(R.id.imgSelect);
            imgUnSelected = (ImageView) view.findViewById(R.id.imgUnSelected);
            card_view = (CardView) view.findViewById(R.id.card_view);
            this.setSelectionModeBackgroundDrawable(null);
            this.setSelectionModeStateListAnimator(null);
        }

        @Override
        public void onClick(View view) {
            // if not in selection mode, go to detail screen
//            if (!mMultiSelector.tapSelection(ViewHolder.this)) {
            if (mMultiSelector.isSelectable() && AlarmActivity.isLongPress) {
                card_view.setCardBackgroundColor(Color.BLACK);
            } else {
                Log.d("TAG", "onClick: not selected");
                mEditListener.startEditActivity(view);
                card_view.setCardBackgroundColor(Color.GRAY);
            }
//            }else {
//                mEditListener.startEditActivity(view);
//            }
        }

        @Override
        public boolean onLongClick(View view) {
            if (!mMultiSelector.isSelectable()) {
                maintnConte2.onLongClickItem(0);
//        ((AppCompatActivity) mContext).startSupportActionMode(mActionModeCallback);
                mMultiSelector.setSelectable(true);
                mMultiSelector.setSelected(ViewHolder.this, true);
                onClick(view);
                return true;
            }
            return false;
        }
    }

    public interface isLongClick {
        public void onLongClickItem(int position);

        public void removeLongPress();

        public void OnChangeDelete(Boolean isBool);
    }


    public ReminderAdapter(MainFragment context, Context maintnConte, Cursor cursor) {
        mContext = maintnConte;
        maintnConte2 = context;
        mCursor = cursor;
        mDatabase = new ReminderDataHelper(mContext);
    }

    // inflating layout from XML and returning the holder
    @Override
    public ReminderAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        if (mDatabase.isEmpty("All")) {
            View emptyView = parent.findViewById(R.id.empty);
            return new ViewHolder(emptyView);
        } else {

            // Inflate the custom layout
            View reminderView = inflater.inflate(R.layout.list_item_layout, parent, false);

            // Return a new holder
            ViewHolder viewHolder = new ViewHolder(reminderView);
            return viewHolder;
        }
    }

    // Populating the items in the holder
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(ReminderAdapter.ViewHolder viewHolder, int position) {
        mCursor.moveToPosition(position);

        if (AlarmActivity.isLongPress) {
            viewHolder.imgUnSelected.setVisibility(View.VISIBLE);
            viewHolder.imgUnSelected.setImageDrawable(mContext.getDrawable(R.drawable.ic_uncheck_reminder));
        } else {
            viewHolder.imgUnSelected.setVisibility(View.INVISIBLE);
            viewHolder.imgUnSelected.setImageDrawable(null);
        }

        String type = mCursor.getString(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TYPE));
        if (type.equalsIgnoreCase("alert")) {
            viewHolder.time.setText(timeFormat.format(mCursor.getLong(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TIME))));
            viewHolder.icon.setImageResource(R.drawable.ic_watch_reminder);
            viewHolder.time.setVisibility(View.VISIBLE);
            viewHolder.icon.setVisibility(View.VISIBLE);
        } else {
            viewHolder.time.setVisibility(View.GONE);
            viewHolder.icon.setVisibility(View.GONE);
        }
        viewHolder.title.setText(mCursor.getString(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TITLE)));
        viewHolder.content.setText(mCursor.getString(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_CONTENT)));
//        viewHolder.setSelectionModeBackgroundDrawable(mContext.getResources().getDrawable(R.drawable.ic_check_reminder, null));
        if (AlarmActivity.isLongPress) {
            viewHolder.imgSelect.setVisibility(View.VISIBLE);
            viewHolder.imgUnSelected.setVisibility(View.VISIBLE);
        } else {
            mMultiSelector.clearSelections();
            mMultiSelector.setSelected(viewHolder, false);
            viewHolder.imgSelect.setVisibility(View.GONE);
            viewHolder.imgUnSelected.setVisibility(View.GONE);
            viewHolder.imgSelect.setImageDrawable(null);
            viewHolder.imgUnSelected.setImageDrawable(null);
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (AlarmActivity.isLongPress) {
                    viewHolder.imgUnSelected.setImageDrawable(mContext.getDrawable(R.drawable.ic_uncheck_reminder));
                    if (mMultiSelector.isSelected(position, viewHolder.getItemId())) {
                        Log.d("fdfdfdfdf", "" + mMultiSelector.isSelected(position, viewHolder.getItemId()));
                        mMultiSelector.setSelectable(true);
                        mMultiSelector.setSelected(viewHolder, false);
                        viewHolder.imgSelect.setImageDrawable(null);
                        Constant.isDel = mMultiSelector.getSelectedPositions().size();
                        Log.d("TAG11212", "onClick: "+Constant.isDel);
                        Log.d("check1", "onClick: ff "+mMultiSelector.getSelectedPositions().size());

                    } else {
                        Log.d("fdfdfdfdf", "else: ");
                        mMultiSelector.setSelectable(false);
                        mMultiSelector.setSelected(viewHolder, true);
                        Constant.isDel = mMultiSelector.getSelectedPositions().size();
                        Log.d("TAG11212", "onClick1: "+Constant.isDel);
                        viewHolder.imgSelect.setImageDrawable(mContext.getDrawable(R.drawable.ic_check_reminder));
                        Log.d("check1", "onClick: "+mMultiSelector.getSelectedPositions().size());
                    }
                    Log.d("check1", "setupFAB: "+Constant.isDel);

                    notifyDataSetChanged();
                } else {
                    mEditListener.startEditActivity(v);
                }
            }
        });

        viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                viewHolder.imgSelect.setVisibility(View.VISIBLE);
                viewHolder.imgUnSelected.setVisibility(View.VISIBLE);
                AlarmActivity.isLongPress = true;
                maintnConte2.onLongClickItem(0);
                mMultiSelector.setSelectable(false);
                mMultiSelector.setSelected(viewHolder, true);
                viewHolder.imgSelect.setImageDrawable(mContext.getDrawable(R.drawable.ic_check_reminder));
                viewHolder.imgUnSelected.setImageDrawable(mContext.getDrawable(R.drawable.ic_uncheck_reminder));
                viewHolder.itemView.performClick();

                return false;
            }
        });
    }

    public void removeLongPress() {
        AlarmActivity.isLongPress = false;
        maintnConte2.removeLongPress();
        notifyDataSetChanged();
    }

    public int CheckDelete()  {
        return mMultiSelector.getSelectedPositions().size();
    }


    public int getItemCount() {
        return mCursor.getCount();
    }

    public void setMultiSelector(MultiSelector l) {
        mMultiSelector = l;
    }

    public void setModalMultiSelectorCallback(ModalMultiSelectorCallback l) {
        mActionModeCallback = l;
    }

    public void setEditListener(MainFragment.EditListener l) {
        mEditListener = l;
    }

    @Override
    public long getItemId(int position) {
        mCursor.moveToPosition(position);
        return (long) mCursor.getInt(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_ID));
    }
}