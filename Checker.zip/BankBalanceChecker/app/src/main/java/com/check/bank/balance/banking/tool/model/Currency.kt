package com.check.bank.balance.banking.tool.model
import com.google.gson.annotations.SerializedName;


data class Currency (
    @SerializedName("rates")var rates: Rates? = null,

    @SerializedName("base")var base: String? = null,

    @SerializedName("date")var date: String? = null
)