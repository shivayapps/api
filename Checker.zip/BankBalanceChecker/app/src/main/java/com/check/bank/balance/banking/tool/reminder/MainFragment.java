package com.check.bank.balance.banking.tool.reminder;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bignerdranch.android.multiselector.ModalMultiSelectorCallback;
import com.bignerdranch.android.multiselector.MultiSelector;
import com.check.bank.balance.banking.tool.Constants.Constant;
import com.check.bank.balance.banking.tool.R;
import com.check.bank.balance.banking.tool.activity.MainActivity;

import java.util.List;

/**
 * Created by kyle on 27/04/17.
 */

public class MainFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>, SwipeRefreshLayout.OnRefreshListener, ReminderAdapter.isLongClick {
    private ReminderDataHelper mDataHelper;
    private ImageView mEmptyView;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    public static ReminderAdapter mAdapter;
    private String mType;
    private TextView textView8;
    private ImageView imageView4;
    private MultiSelector mMultiSelector;
    private ModalMultiSelectorCallback mActionModeCallBack;
    private SwipeRefreshLayout mRefreshLayout;
    private Cursor mCursor;
    public ConstraintLayout addAlert;
    private Dialog alert;

    @Override
    public void onLongClickItem(int position) {
        AlarmActivity.isLongPress = true;
        textView8.setText("Delete");
        imageView4.setVisibility(View.GONE);
        addAlert.setTag("delete");
    }

    @Override
    public void removeLongPress() {
        onReset();
    }

    @Override
    public void OnChangeDelete(Boolean isBool) {
        if (isBool) {
            addAlert.setTag("delete");
        } else {
            Toast.makeText(requireContext(), "Please Select", Toast.LENGTH_SHORT).show();
        }
    }

    public interface EditListener {
        void startEditActivity(View v);
    }

    private EditListener mEditListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mMultiSelector = new MultiSelector();

        Log.d("TAG1111111", "setupFAB: " + Constant.isDel);
        mEditListener = v -> {
            int position = mRecyclerView.getChildAdapterPosition(v);
            mCursor.moveToPosition(position);
            Intent intent = null;
            String type = mCursor.getString(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TYPE));
            if (type.equalsIgnoreCase("alert")) {
                intent = new Intent(getContext(), CreateOrEditAlert.class);
            }
            intent.putExtra("id", mCursor.getInt(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_ID)));
            getContext().startActivity(intent);
        };
        mType = getArguments().getString("Type");
        getLoaderManager().initLoader(0, null, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.activity_main_fragment, container, false);
    }

    public void onStart() {
        super.onStart();
        mDataHelper = new ReminderDataHelper(getContext());

        mRecyclerView = getActivity().findViewById(R.id.reminder_list);
        imageView4 = getActivity().findViewById(R.id.imageView4);
        mEmptyView = getActivity().findViewById(R.id.empty);
        mRefreshLayout = getActivity().findViewById(R.id.refresh_layout);
        textView8 = getActivity().findViewById(R.id.textView8);
        addAlert = getActivity().findViewById(R.id.add_alert);

        mLayoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRefreshLayout.setOnRefreshListener(this);
        Log.d("TAG1111111", "setupFAB: " + Constant.isDel);
        setupFAB();
    }

    public void onReset() {
        addAlert.setTag("remi");
        textView8.setText("Add Reminder");
        imageView4.setVisibility(View.VISIBLE);
        mAdapter.notifyDataSetChanged();
    }

    public void onResume() {
        super.onResume();
        mRefreshLayout.setRefreshing(true);
        updateData();

        emptyCheck();
    }

    private void setupFAB() {
        addAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("TAG1111111", "setupFAB: " + Constant.isDel);
                if (addAlert.getTag() == "delete") {
                    if (Constant.isDel > 0) {
                        deleteDialog();
                    } else {
                        Toast.makeText(requireContext(), "Please Select ", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    startActivity(new Intent(getContext(), CreateOrEditAlert.class));
                }
            }
        });
    }

    // checks if specified item mType has any members in mDataHelper and sets emptyView
    private void emptyCheck() {
        Cursor res = mDataHelper.getAllItems();
        if (res.getCount() == 0) {
            mEmptyView.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.GONE);
        } else {
            mEmptyView.setVisibility(View.GONE);
            mRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void deleteDialog() {
        alert = new Dialog(getContext());

        View mView = getLayoutInflater().inflate(R.layout.dialog_delete, null);

        Button btn_cancel = (Button) mView.findViewById(R.id.btnNagative);
        Button btn_okay = (Button) mView.findViewById(R.id.btnPositive);
        alert.setContentView(mView);

//        final AlertDialog alertDialog = alert.create();

        alert.setCanceledOnTouchOutside(false);
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        DisplayMetrics mDisplay = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(mDisplay);
        int width = mDisplay.widthPixels;
        alert.getWindow().setLayout((int) (width*0.90), ViewGroup.LayoutParams.WRAP_CONTENT);

        btn_okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri;
                List<Integer> positions = mMultiSelector.getSelectedPositions();
                for (int j = 0; j < positions.size(); j++) {
                    int position = positions.get(j);
                    mCursor.moveToPosition(position);
                    int id = mCursor.getInt(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_ID));
                    int deleteId = id;
                    uri = ContentUris.withAppendedId(ReminderContract.All.CONTENT_URI, deleteId);
                    Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
                    cursor.moveToFirst();

                    // if the selectors item for deletion is an alert, cancel the alarm
                    if ((cursor.getString(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TYPE)).equals("alert"))) {
                        Intent delete = new Intent(getContext(), AlarmService.class);
                        delete.putExtra(AlarmService.ID_KEY, deleteId);
                        delete.setAction(AlarmService.DELETE);
                        getContext().startService(delete);
                        // otherwise just delete note and notify mAdapter
                    } else {
                        uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI, deleteId);
                        getContext().getContentResolver().delete(uri, null, null);
                    }
                }
                mAdapter.removeLongPress();
                alert.dismiss();
                mMultiSelector.clearSelections();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alert.dismiss();
            }
        });

//        AlertDialog alertDialog = new AlertDialog.Builder(getContext())
//                .setTitle("Confirm")
//                .setMessage("Do you want to delete?")
//
//                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//
//                    public void onClick(DialogInterface dialog, int i) {
//                        Uri uri;
//                        List<Integer> positions = mMultiSelector.getSelectedPositions();
//                        for (int j = 0; j < positions.size(); j++) {
//                            int position = positions.get(j);
//                            mCursor.moveToPosition(position);
//                            int id = mCursor.getInt(mCursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_ID));
//                            int deleteId = id;
//                            uri = ContentUris.withAppendedId(ReminderContract.All.CONTENT_URI,
//                                    deleteId);
//                            Cursor cursor = getContext().getContentResolver().query(uri,
//                                    null, null, null, null);
//                            cursor.moveToFirst();
//
//                            // if the selectors item for deletion is an alert, cancel the alarm
//                            if ((cursor.getString(cursor.getColumnIndex(ReminderDataHelper.DB_COLUMN_TYPE))
//                                    .equals("alert"))) {
//                                Intent delete = new Intent(getContext(), AlarmService.class);
//                                delete.putExtra(AlarmService.ID_KEY, deleteId);
//                                delete.setAction(AlarmService.DELETE);
//                                getContext().startService(delete);
//                                // otherwise just delete note and notify mAdapter
//                            } else {
//                                uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI,
//                                        deleteId);
//                                getContext().getContentResolver().delete(uri, null, null);
//                            }
//                        }
//                        mAdapter.removeLongPress();
//                        dialog.dismiss();
//                        mMultiSelector.clearSelections();
//                    }
//
//
//                })
//                .setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int i) {
//                        dialog.dismiss();
//
//                    }
//                })
//                .create();

        alert.show();
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            alert.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateData() {
        getLoaderManager().restartLoader(0, null, this);
    }

    private void invalidate(Cursor data) {
        mAdapter = new ReminderAdapter(this, getContext(), data);
        mAdapter.setHasStableIds(true);
        mAdapter.setMultiSelector(mMultiSelector);
        mAdapter.setModalMultiSelectorCallback(mActionModeCallBack);
        mAdapter.setEditListener(mEditListener);
        mRecyclerView.swapAdapter(mAdapter, false);
        mRefreshLayout.setRefreshing(false);
        emptyCheck();
//        emptyCheck(mType);
    }

    /**
     * Loader callbacks
     */

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri uri;
        switch (mType) {
            case "All":
                uri = ReminderContract.All.CONTENT_URI;
                break;
            case "Alerts":
                uri = ReminderContract.Alerts.CONTENT_URI;
                break;
            default:
                return null;
        }
        return new CursorLoader(getActivity(), uri, null, null, null, null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mCursor = data;
        invalidate(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    /**
     * SwipeRefreshLayout callback
     */

    @Override
    public void onRefresh() {
        updateData();
    }
}
