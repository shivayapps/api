package com.check.bank.balance.banking.tool.reminder;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.check.bank.balance.banking.tool.R;
import com.check.bank.balance.banking.tool.activity.MainActivity;

import static com.check.bank.balance.banking.tool.reminder.MainFragment.mAdapter;

public class AlarmActivity extends AppCompatActivity {

  private TextView mTVToolbar;
  private ImageButton imgBtnBack;
  private FragmentManager mFragmentManager;
  public static Boolean isLongPress =false;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_alarm);
    mTVToolbar = findViewById(R.id.mTVToolbar);
    imgBtnBack = findViewById(R.id.imgBtnBack);

    transparentStatusAndNavigation();

    mTVToolbar.setText("Reminder");
    imgBtnBack.setOnClickListener(v -> {
      onBackPressed();
    });

    mFragmentManager = getSupportFragmentManager();
    Bundle args = new Bundle();
    args.putString("Type", "All");
    Fragment main =new MainFragment();
    main.setArguments(args);
    mFragmentManager.beginTransaction().add(R.id.content_frame, main).commit();
  }

  private void transparentStatusAndNavigation() {
    //make full transparent statusBar
    if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
      setWindowFlag(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, true);
    }
    if (Build.VERSION.SDK_INT >= 19) {
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }
    if (Build.VERSION.SDK_INT >= 21) {
      setWindowFlag(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
      getWindow().setStatusBarColor(Color.TRANSPARENT);
      //getWindow().setNavigationBarColor(Color.TRANSPARENT);
    }
  }

  private void setWindowFlag(final int bits, boolean on) {
    Window win = getWindow();
    WindowManager.LayoutParams winParams = win.getAttributes();
    if (on) {
      winParams.flags |= bits;
    } else {
      winParams.flags &= ~bits;
    }
    win.setAttributes(winParams);
  }

  @Override
  public void onBackPressed() {
    if (isLongPress) {
      isLongPress=false;
      mAdapter.removeLongPress();
    }else {
      startActivity(new Intent(this, MainActivity.class));
     // super.onBackPressed();
    }
  }
}