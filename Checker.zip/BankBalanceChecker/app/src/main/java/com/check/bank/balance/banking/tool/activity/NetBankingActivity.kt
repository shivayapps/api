package com.check.bank.balance.banking.tool.activity

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.check.bank.balance.banking.tool.R
import kotlinx.android.synthetic.main.activity_net_banking.*

class NetBankingActivity : AppCompatActivity() {

    lateinit var mWenView:WebView
    lateinit var progressBar:ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_net_banking)

        hideSystemUI()

        imgView1.setPadding(0, statusBar(), 0, 0)

        mWenView=findViewById(R.id.mWVNetBanking)
        progressBar=findViewById(R.id.progressBar)
//        mWenView.settings.javaScriptEnabled = true
//        mWenView.settings.javaScriptCanOpenWindowsAutomatically = tr
        mWenView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
//                    progressBar.visibility = View.GONE
            }
        }

        mWenView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                // Update the progress bar with page loading progress
                progressBar.progress = newProgress
                if (newProgress == 100) {
                    // Hide the progressbar
                    progressBar.visibility = View.GONE
                }
            }
        }

        val url:String? = intent.getStringExtra("uri")
//
        mWenView.settings.loadsImagesAutomatically = true
        mWenView.settings.javaScriptEnabled = true
        mWenView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
        if (url != null){
            mWenView.loadUrl(url)
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = Color.TRANSPARENT
        }
    }

    fun statusBar(): Int {
        var result: Int = 0
        try {
            result = 0
            val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
            if (resourceId > 0) {
                result = resources.getDimensionPixelSize(resourceId)
            }
        } catch (e: Exception) {
        }
        return result
    }
}