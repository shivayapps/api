package com.check.bank.balance.banking.tool.database

import android.content.Context
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.util.Log
import java.io.*

const val dbName = "bankbalance.db"

class DBHelper(var context: Context) : SQLiteOpenHelper(context, dbName, null, 1) {
    private var db: SQLiteDatabase? = null
    private var tblName = "smsinfo"
    private val DATABASE_NAME = dbName

//    init {
//        // Check if the database already copied to the device.
//        val dbExist = checkDatabase()
//        if (dbExist) {
//            // if already copied then don't do anything.
//            Log.e("-----", "Database exist")
//        } else {
//            // else copy the database to the device.
//            Log.e("-----", "Database doesn't exist")
////            createDatabase()
//        }
//    }
//
//    private fun createDatabase() {
//        copyDatabase()
//    }

    private fun copyDatabase() {
        this.readableDatabase

        val inputStream = context.assets.open(dbName)

        val outputFile = File(context.getDatabasePath(dbName).absolutePath)
        if (!outputFile.exists()) {
            outputFile.mkdir()
        }
        val outputStream = FileOutputStream(outputFile)

        val bytesCopied = inputStream.copyTo(outputStream)
        Log.e("bytesCopied", "$bytesCopied")
        inputStream.close()

        outputStream.flush()
        outputStream.close()
    }

    private fun checkDatabase(): Boolean {
        val dbFile = File(context.getDatabasePath(dbName).path)
        return dbFile.exists()
    }

    fun openDatabase() {
        if (this.db == null) {
            this.db = this.writableDatabase
        }
        db = SQLiteDatabase.openDatabase(context.getDatabasePath(dbName).absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
    }
    override fun close() {
        db!!.close()
        super.close()
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            db.disableWriteAheadLogging();
        }
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val dbFile = context.getDatabasePath(dbName)

        if (!dbFile.exists()){
            this.readableDatabase
            copyDatabase()
        }
        this.db=db
    }

//    @Throws(SQLException::class)
//    fun open(): DBHelper? {
//        if (this.db == null) {
//            this.db = this.writableDatabase
//        }
//        return this
//    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        onCreate(db)
    }
    val allData:Cursor get() {
        openDatabase()
        return db!!.rawQuery("SELECT * FROM $tblName",null)
    }
}