package com.check.bank.balance.banking.tool.retrofit

import APIInterface
import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


//class APIClient() {
//    private var retrofit: Retrofit? = null
//    private var BASE_URL = "https://api.ratesapi.io/api/"
////    private var BASE_URL = "https://api.exchangeratesapi.io/"
//    fun getClient(): APIInterface
//         {
//            if (retrofit == null) {
//                retrofit = Retrofit.Builder()
//                    .baseUrl(BASE_URL)
//                    .addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create()))
//                    .build()
//            }
//            return retrofit!!.create(APIInterface::class.java)
//        }
//}