package com.check.bank.balance.banking.tool.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.check.bank.balance.banking.tool.R
import com.check.bank.balance.banking.tool.model.CallModel

class CallAdapter(var mContext: Context, var mCallList: ArrayList<CallModel>, var clickListener: ClickListener) : RecyclerView.Adapter<CallAdapter.CallViewHolder>() {
    class CallViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var mTVType: TextView = view.findViewById(R.id.mTVType)
        var mTVCall: TextView = view.findViewById(R.id.mTVNumber)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CallViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.single_missed_call, parent, false)
        return CallViewHolder(view)
    }
    override fun getItemCount(): Int = mCallList.size
    override fun onBindViewHolder(holder: CallViewHolder, position: Int) {
        val mList = mCallList[position]
        holder.mTVType.text = mList.mType
        holder.mTVCall.text = "+"+mList.mBalance

        holder.itemView.setOnClickListener {
            clickListener.onItemClick(mList.mBalance!!)
        }
    }

    interface ClickListener {
        fun onItemClick(position: String)
    }
}