package com.check.bank.balance.banking.tool

import android.app.Application
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.multidex.MultiDex

import com.check.bank.balance.banking.tool.helper.AppOpenManager
import com.google.android.gms.ads.MobileAds

import com.scribble.animation.maker.video.effect.myadslibrary.kotlin.appid.AppIDs

class BalanceCheckerApplication:Application() {
//    var openManager: AppOpenManager? = null
    companion object {
        private var singleton: BalanceCheckerApplication? = null

        @JvmStatic
        val instance: BalanceCheckerApplication?
        get() {
            if (singleton == null) {
                singleton = BalanceCheckerApplication()
            }
            return singleton
        }
    }
    override fun onCreate() {
        super.onCreate()
        MultiDex.install(this)
        MobileAds.initialize(this) {
        }
//        AudienceNetworkAds.initialize(this)
        singleton = this

        AppIDs.init(applicationContext, AppIDs.BankBalanceChecker, false)
//        openManager = AppOpenManager(this)
    }
}