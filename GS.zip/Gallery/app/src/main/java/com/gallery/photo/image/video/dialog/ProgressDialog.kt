package com.gallery.photo.image.video.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDeleteProgressBinding
import com.gallery.photo.image.video.extension.beGone

class ProgressDialog(
    val activity: Activity,
    @DrawableRes val resId: Int,
    val maxProgress: Int,
    val txtTopTitle: String,
    val txtTitle: String,
) :
    BottomSheetDialogFragment() {

    //lateinit var bindingDialog: DialogDeleteProgressBinding
    var bindingDialog: DialogDeleteProgressBinding?=null

    fun setProgress(progress: Int, size: Int) {
        bindingDialog?.txtProgressCount?.text = size.toString() + "/" + progress
        bindingDialog?.progressBar?.progress = progress
        Log.e("ProgressDialog", "setProgress:$progress")
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDeleteProgressBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog?.root!!
    }

    private fun intView() {
        bindingDialog?.txtTopTitle?.text = ""
        bindingDialog?.txtTitle?.text = txtTopTitle
        if(resId!=0) bindingDialog?.icIcon?.setImageResource(resId)
        else bindingDialog?.icIcon?.beGone()

        if(maxProgress>0) bindingDialog?.progressBar?.max=maxProgress
        else bindingDialog?.progressBar?.isIndeterminate=true

        Log.e("ProgressDialog", "maxProgress:$maxProgress")
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}