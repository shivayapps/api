package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.text.format.Formatter
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.exifinterface.media.ExifInterface
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.databinding.DialogDeatilsBinding
import com.gallery.photo.image.video.extension.beGoneIf
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.Utils
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Objects

class DetailsDialog(var pictureData: PictureData, val isFromPrivate: Boolean = false) :
    BottomSheetDialogFragment() {

    lateinit var bindingDialog: DialogDeatilsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bindingDialog = DialogDeatilsBinding.inflate(layoutInflater, container, false)
        intView()
        return bindingDialog.root
    }

    private fun intView() {

        intListener()
        bindingDialog.llPath.beGoneIf(isFromPrivate)
        bindingDialog.loutDetails.visibility = View.VISIBLE
        bindingDialog.loutMultipleDetails.visibility = View.GONE

        val formatDetails = SimpleDateFormat("dd/MM/yyyy, hh:mm aa", Locale.ENGLISH)
        bindingDialog.txtName.text = pictureData.fileName
        bindingDialog.txtPath.text = pictureData.filePath
        val strDate = formatDetails.format(pictureData.date)

        bindingDialog.txtTime.text = strDate
        if (isFromPrivate) {
            if (pictureData.isVideo) {
                bindingDialog.txtFormat.text = getString(R.string.videos)
            } else {
                bindingDialog.txtFormat.text = getString(R.string.images)
            }
        } else {
            bindingDialog.txtFormat.text = Utils.getFilenameExtension(pictureData.filePath)
        }

        bindingDialog.txtSize.text =
            Formatter.formatShortFileSize(requireActivity(), pictureData.fileSize)

        var resolution = ""
        if (pictureData.isVideo) {
            resolution = try {
                val metaRetriever = MediaMetadataRetriever()
                metaRetriever.setDataSource(pictureData.filePath)
                val height =
                    Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT))!!
                        .toInt()
                val width =
                    Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH))!!
                        .toInt()
                "$width X $height"
            } catch (e: Exception) {
                Log.e("printStackTrace","printStackTrace:$e")
                "--"
            }
        } else {
            resolution = try {
                val options = BitmapFactory.Options()
                options.inJustDecodeBounds = true
                BitmapFactory.decodeFile(pictureData.filePath, options)
                val imageHeight = options.outHeight
                val imageWidth = options.outWidth
                "$imageWidth X $imageHeight"
            } catch (e: Exception) {
                Log.e("printStackTrace","printStackTrace:$e")
                "--"
            }
        }

        bindingDialog.txtResolution.text = resolution
    }

    private fun intListener() {

        bindingDialog.btnOK.setOnClickListener {
            dismiss()
        }
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)
}