package com.ro.hith.imagic.screens.commonscreen.screen;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.ro.hith.imagic.R;
import com.ro.hith.imagic.databinding.ActivityMainBinding;
import com.ro.hith.imagic.screens.settings.SettingScreen;

public class HomeScreen extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadingFragments();
        setOnClickListners();




    }

    private void navigateToActivity(Class<?> activityClass) {
        Intent intent = new Intent(HomeScreen.this, activityClass);
        startActivity(intent);
        overridePendingTransition(
                R.anim.cusotm_slide_in_right,
                R.anim.custom_slide_out_left
        );
    }

    private void setOnClickListners() {
        binding.settingsButton.setOnClickListener(v -> {
            navigateToActivity(SettingScreen.class);
        });
    }

    private void loadingFragments() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationInHomeScreen);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.navHostMAneger);
        NavController navController = navHostFragment.getNavController();
        NavigationUI.setupWithNavController(bottomNavigationView, navController);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up binding reference
        binding = null;
    }
}