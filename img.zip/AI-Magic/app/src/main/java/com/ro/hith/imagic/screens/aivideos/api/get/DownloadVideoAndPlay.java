package com.ro.hith.imagic.screens.aivideos.api.get;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.VideoView;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.screens.singletone.CustomDialogManager;

import java.io.File;

public class DownloadVideoAndPlay {

    private static DownloadVideoAndPlay instance;
    private Context context;
    private transient String requestId;
    private Handler mainHandler;

    private DownloadVideoAndPlay(Context context) {
        this.context = context.getApplicationContext();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public static synchronized DownloadVideoAndPlay getInstance(Context context) {
        if (instance == null) {
            instance = new DownloadVideoAndPlay(context);
        }
        return instance;
    }

    public void makeRequest(String appName, String videoId, ProgressBar loadingProgressBar,
                            ProgressBar progressBar, VideoView videoView) {
        if (context == null) {
            System.out.println("Error: Context is null");
            return;
        }

        showLoading(true, loadingProgressBar, progressBar, videoView);

        VideoApiClient.getInstance().downloadVideo(context, appName, videoId, loadingProgressBar,
                progressBar, videoView,
                new VideoResponseCallback() {
                    @Override
                    public void onSuccess(File videoFile) {
                        // Run on UI thread
                        mainHandler.post(() -> {
                            playVideoFromFile(context, videoFile, loadingProgressBar, progressBar, videoView);
                        });
                    }

                    @Override
                    public void onProgress(int progress) {
                        // Run on UI thread
                        mainHandler.post(() -> {
                            progressBar.setProgress(progress);
                        });
                    }

                    @Override
                    public void onError(String errorMessage) {
                        // Run on UI thread
                        mainHandler.post(() -> {
                            showToastOnUiThread("Error downloading video: " + errorMessage);
                            showLoading(false, loadingProgressBar, progressBar, videoView);
                        });
                    }
                });
    }

    private void playVideoFromFile(Context context, File videoFile, ProgressBar loadingProgressBar,
                                   ProgressBar progressBar, VideoView videoView) {
        try {
            // Ensure we're on the main thread
            if (Looper.myLooper() != Looper.getMainLooper()) {
                mainHandler.post(() -> playVideoFromFile(context, videoFile, loadingProgressBar, progressBar, videoView));
                return;
            }

            showLoading(false, loadingProgressBar, progressBar, videoView);

            // Use FileProvider for better security and compatibility
            Uri videoUri = Uri.fromFile(videoFile);

            // Reset the VideoView first
            videoView.stopPlayback();
            videoView.setVideoURI(null);

            // Set up the VideoView properly
            videoView.setVideoURI(videoUri);
            videoView.requestFocus();

            videoView.setOnPreparedListener(mp -> {
                Log.d("VideoPlayer", "Video prepared - starting playback");
                progressBar.setVisibility(View.GONE);
                loadingProgressBar.setVisibility(View.GONE);
                videoView.start();

                // Optional: Set up looping if needed
                mp.setLooping(true);
            });

            videoView.setOnErrorListener((mp, what, extra) -> {
                Log.e("VideoPlayer", "Error playing video - what: " + what + ", extra: " + extra);
                showToastOnUiThread("Error playing video. Code: " + what);
                progressBar.setVisibility(View.GONE);
                loadingProgressBar.setVisibility(View.GONE);
                return true;
            });

            videoView.setOnCompletionListener(mp -> {
                Log.d("VideoPlayer", "Video completed");
            });

            // Add info listener for debugging
            videoView.setOnInfoListener((mp, what, extra) -> {
                switch (what) {
                    case android.media.MediaPlayer.MEDIA_INFO_BUFFERING_START:
                        Log.d("VideoPlayer", "Buffering started");
                        break;
                    case android.media.MediaPlayer.MEDIA_INFO_BUFFERING_END:
                        Log.d("VideoPlayer", "Buffering ended");
                        break;
                    case android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START:
                        Log.d("VideoPlayer", "Rendering started");
                        break;
                }
                return false;
            });

        } catch (Exception e) {
            Log.e("VideoPlayer", "Error playing video: " + e.getMessage(), e);
            showToastOnUiThread("Error playing video: " + e.getMessage());
            showLoading(false, loadingProgressBar, progressBar, videoView);
        }
    }

    private void showLoading(boolean show, ProgressBar loadingProgressBar,
                             ProgressBar progressBar, VideoView videoView) {
        // This method should only be called from UI thread
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> showLoading(show, loadingProgressBar, progressBar, videoView));
            return;
        }

        loadingProgressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        videoView.setVisibility(show ? View.GONE : View.VISIBLE);

        if (!show) {
            progressBar.setProgress(0);
        }
    }

    private void showToastOnUiThread(final String message) {
        if (context != null) {
            mainHandler.post(() -> {
                CustomDialogManager.getInstance().showDialog(
                        context,
                        "No Server",
                        "We are unable to connect to the server at this time. Please check your internet connection and try again",
                        "Got it",
                        R.drawable.ic_brush,
                        new CustomDialogManager.DialogButtonClickListener() {
                            @Override
                            public void onButtonClicked() {
                                ((Activity) context).finish();
                            }
                        }
                );
            }) ;
        }
    }

    public void setContext(Context context) {
        this.context = context.getApplicationContext();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }
}