package com.ro.hith.imagic.screens.facedance.api;

import com.ro.hith.imagic.screens.facedance.UploadRequest;

import okhttp3.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import android.util.Log;

public class FaceDanceApiClient {
    private static FaceDanceApiClient instance;
    private OkHttpClient client;

    private static final String TAG = "FaceDanceApiClient";

    private FaceDanceApiClient() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(new LoggingInterceptor()) // Add logging interceptor
                .build();
    }

    public static synchronized FaceDanceApiClient getInstance() {
        if (instance == null) {
            instance = new FaceDanceApiClient();
        }
        return instance;
    }

    public interface ApiCallback {
        void onSuccess(String response);
        void onError(String errorMessage);
    }

    public void uploadImage(UploadRequest request, ApiCallback callback) {
        Log.d(TAG, "uploadImage() called");

        // Validate all required parameters
        if (callback == null) {
            Log.e(TAG, "Callback cannot be null");
            throw new IllegalArgumentException("Callback cannot be null");
        }

        if (request == null) {
            Log.e(TAG, "Request object is null");
            callback.onError("Request object cannot be null");
            return;
        }

        Log.d(TAG, "Request parameters:");
        Log.d(TAG, "AppName: " + request.getAppName());
        Log.d(TAG, "Folder: " + request.getFolder());
        Log.d(TAG, "FileName: " + request.getFileName());
        Log.d(TAG, "CountryCode: " + request.getCountryCode());
        Log.d(TAG, "Platform: " + request.getPlatform());
        Log.d(TAG, "FirebaseAppCheck: " + (request.getFirebaseAppCheck() != null ? "Provided" : "Not provided"));
        Log.d(TAG, "FcmToken: " + (request.getFcmToken() != null ? "Provided" : "Not provided"));

        if (request.getInputImageFile() == null) {
            Log.e(TAG, "Input image file is null");
            callback.onError("Input image file cannot be null");
            return;
        }

        if (!request.getInputImageFile().exists()) {
            Log.e(TAG, "Input image file does not exist: " + request.getInputImageFile().getAbsolutePath());
            callback.onError("Input image file does not exist: " + request.getInputImageFile().getAbsolutePath());
            return;
        }

        Log.d(TAG, "Input image file: " + request.getInputImageFile().getAbsolutePath() +
                " (Size: " + request.getInputImageFile().length() + " bytes)");

        if (request.getAppName() == null || request.getAppName().trim().isEmpty()) {
            Log.e(TAG, "App name is null or empty");
            callback.onError("App name cannot be null or empty");
            return;
        }

        if (request.getFolder() == null || request.getFolder().trim().isEmpty()) {
            Log.e(TAG, "Folder is null or empty");
            callback.onError("Folder cannot be null or empty");
            return;
        }

        if (request.getFileName() == null || request.getFileName().trim().isEmpty()) {
            Log.e(TAG, "File name is null or empty");
            callback.onError("File name cannot be null or empty");
            return;
        }

        if (request.getCountryCode() == null || request.getCountryCode().trim().isEmpty()) {
            Log.e(TAG, "Country code is null or empty");
            callback.onError("Country code cannot be null or empty");
            return;
        }

        if (request.getPlatform() == null || request.getPlatform().trim().isEmpty()) {
            Log.e(TAG, "Platform is null or empty");
            callback.onError("Platform cannot be null or empty");
            return;
        }
        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://facedance.aapthi.in/livepotrait/").newBuilder();
        urlBuilder.addQueryParameter("app_name", request.getAppName());
        urlBuilder.addQueryParameter("folder", request.getFolder());
        urlBuilder.addQueryParameter("file_name", request.getFileName());
        urlBuilder.addQueryParameter("country_code", request.getCountryCode());
        urlBuilder.addQueryParameter("platform", request.getPlatform());

        String url = urlBuilder.build().toString();
        Log.d(TAG, "Final URL: " + url);

        // Create multipart form data
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("input_image",
                        request.getInputImageFile().getName(),
                        RequestBody.create(request.getInputImageFile(),
                                MediaType.parse("image/png")))
                .build();

        Headers.Builder headersBuilder = new Headers.Builder()
                .add("accept", "application/json")
                .add("Content-Type", "multipart/form-data");

        if (request.getFirebaseAppCheck() != null && !request.getFirebaseAppCheck().trim().isEmpty()) {
            headersBuilder.add("x-firebase-appcheck", request.getFirebaseAppCheck());
            Log.d(TAG, "Added x-firebase-appcheck header");
        }

        if (request.getFcmToken() != null && !request.getFcmToken().trim().isEmpty()) {
            headersBuilder.add("fcmtoken", request.getFcmToken());
            Log.d(TAG, "Added fcmtoken header");
        }

        Headers headers = headersBuilder.build();
        Log.d(TAG, "Request headers: " + headers.toString());

        Request httpRequest = new Request.Builder()
                .url(url)
                .headers(headers)
                .post(requestBody)
                .build();

        Log.d(TAG, "Sending HTTP POST request...");
        client.newCall(httpRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Network request failed: " + e.getMessage(), e);
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    Log.d(TAG, "Received response. Code: " + response.code() + ", Message: " + response.message());
                    Log.d(TAG, "Response headers: " + response.headers().toString());

                    if (response.isSuccessful()) {
                        String responseBody = response.body() != null ? response.body().string() : "Empty response";
                        Log.d(TAG, "Success response: " + responseBody);
                        callback.onSuccess(responseBody);
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "HTTP error: " + response.code() + " - " + response.message() + ", Body: " + errorBody);
                        callback.onError("HTTP error: " + response.code() + " - " + response.message());
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error reading response: " + e.getMessage(), e);
                    callback.onError("Error reading response: " + e.getMessage());
                } finally {
                    if (response != null) {
                        response.close();
                    }
                }
            }
        });
    }

    private static class LoggingInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();

            long startTime = System.nanoTime();
            Log.d(TAG, String.format("Sending request %s on %s%n%s",
                    request.url(), chain.connection(), request.headers()));

            Response response = chain.proceed(request);

            long endTime = System.nanoTime();
            Log.d(TAG, String.format("Received response for %s in %.1fms%n%s",
                    response.request().url(), (endTime - startTime) / 1e6d, response.headers()));

            return response;
        }
    }

    private void logRequestDetails(Request request) {
        try {
            Log.d(TAG, "Request Method: " + request.method());
            Log.d(TAG, "Request URL: " + request.url());
            Log.d(TAG, "Request Headers: " + request.headers());

            if (request.body() instanceof MultipartBody) {
                MultipartBody multipartBody = (MultipartBody) request.body();
                Log.d(TAG, "Multipart parts: " + multipartBody.parts().size());
                for (MultipartBody.Part part : multipartBody.parts()) {
                    Log.d(TAG, "Part: " + part.headers());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error logging request details", e);
        }
    }
}