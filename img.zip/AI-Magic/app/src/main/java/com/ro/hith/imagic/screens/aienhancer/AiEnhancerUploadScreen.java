package com.ro.hith.imagic.screens.aienhancer;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.ro.hith.imagic.databinding.ActivityAiEnhancerUploadScreenBinding;
import com.ro.hith.imagic.screens.backgroundchanger.BackgroundChangeScreen;
import com.ro.hith.imagic.screens.commonscreen.screen.CommonProcessing;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

import kotlin.Pair;

public class AiEnhancerUploadScreen extends AppCompatActivity implements PhotoUploadManager.PhotoUploadCallback{

    private static final String UPLOAD_TO_ENHANCER = "ai_enhancer";
    private PhotoUploadManager photoUploadManager;
    private ActivityAiEnhancerUploadScreenBinding binding;
    private static final String TAG = "AiEnhancerUploadScreen";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAiEnhancerUploadScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        photoUploadManager = PhotoUploadManager.getInstance();
        Log.d(TAG, "Activity created, PhotoUploadManager instance: " + photoUploadManager);
        setupClickListeners();
    }

    private void setupClickListeners() {
        // Back button
        binding.buttonBack.setOnClickListener(v -> finish());

        // Upload button
        binding.uploadSIngleScreen.setOnClickListener(v -> {
            Log.d(TAG, "Upload button clicked");
            photoUploadManager.startPhotoUpload(
                    AiEnhancerUploadScreen.this,
                    AppConfig.FEATURE_AIENHANCER,
                    UPLOAD_TO_ENHANCER
            );
        });


        binding.buttonEnhance.setOnClickListener(v -> {
            if (binding.singleImageView.getDrawable() != null) {
                removeBG();
            }
        });
    }


    @SuppressWarnings("unchecked")
    private void removeBG() {
        Log.d(TAG, "Generate face swap button clicked");
        StartActivityGlobally.navigateToActivityWithFeature(
                AiEnhancerUploadScreen.this,
                CommonProcessing.class,
                new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_AIENHANCER)
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Setting callback to this activity");
        // Set callback when activity resumes
        photoUploadManager.setCallback(this);

        // Check if we already have an image URI from a previous upload
        Uri existingUri = photoUploadManager.getCurrentImageUri();
        String uploadType = photoUploadManager.getCurrentUploadType();
        String feature = photoUploadManager.getCurrentFeature();

        if (existingUri != null && UPLOAD_TO_ENHANCER.equals(uploadType) && AppConfig.FEATURE_AIENHANCER.equals(feature)) {
            Log.d(TAG, "Found existing image URI: " + existingUri);
            onPhotoUploaded(existingUri, feature, uploadType);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Removing callback");
        // Remove callback when activity pauses
        if (photoUploadManager.getCallback() == this) {
            photoUploadManager.setCallback(null);
        }
    }

    @Override
    public void onPhotoUploaded(Uri imageUri, String feature, String uploadType) {
        Log.d(TAG, "onPhotoUploaded called - URI: " + imageUri + ", Feature: " + feature + ", Type: " + uploadType);

        if (UPLOAD_TO_ENHANCER.equals(uploadType) && AppConfig.FEATURE_AIENHANCER.equals(feature)) {
            runOnUiThread(() -> {
                Log.d(TAG, "Loading image into ImageView: " + imageUri);
                try {
                    Glide.with(this)
                            .load(imageUri.getPath())
                            .centerCrop()
                            .into(binding.singleImageView);
                    Log.d(TAG, "Glide image load attempted");
                } catch (Exception e) {
                    Log.e(TAG, "Error loading image with Glide: " + e.getMessage());
                    e.printStackTrace();
                }
            });
        } else {
            Log.d(TAG, "Upload type or feature mismatch. Expected: " + UPLOAD_TO_ENHANCER + "/" + AppConfig.FEATURE_AIENHANCER +
                    ", Got: " + uploadType + "/" + feature);
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }


}