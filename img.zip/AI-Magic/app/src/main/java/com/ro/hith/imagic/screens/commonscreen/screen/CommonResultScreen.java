package com.ro.hith.imagic.screens.commonscreen.screen;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.ro.hith.imagic.databinding.ActivityCommonResultScreenBinding;
import com.ro.hith.imagic.screens.aivideos.api.get.DownloadVideoAndPlay;
import com.ro.hith.imagic.screens.facedance.api.get.FaceDanceDownloadVideoAndPlay;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class CommonResultScreen extends AppCompatActivity {

    private ActivityCommonResultScreenBinding binding;
    private boolean isImageSaved = false;
    private String currentImageUrl = "";
    private String currentFeature = "";
    private String requestID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityCommonResultScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        requestID = getIntent().getStringExtra(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT);
        currentFeature = getIntent().getStringExtra(AppConfig.INTENT_FEATURED_PASSED_AS);

        setupClickListeners();

        if (currentFeature != null) {
            switch (currentFeature) {
                case AppConfig.FEATURE_COUPLE:
                case AppConfig.FEATURE_INDIVISUAL:
                case AppConfig.FEATURE_AI_VIDEO_SINGLE:
                    callVideoPlayerAndDownloading(requestID);
                    break;
                case AppConfig.FEATURE_BABY_BOY:
                case AppConfig.FEATURE_BABY_GIRL:
                    currentImageUrl = "https://babygenerator.aapthi.in/results/babyfeatures/NaturePhotoFramesandEditor/" + requestID;
                    loadingAiBabyEffect(requestID);
                    break;
                case AppConfig.FEATURE_FACESWAP:
                    currentImageUrl = "https://faceswap.aapthi.in/examples/results/" + AppConfig.DEFAULT_APP_NAME + "/" + requestID;
                    loadingFaceSwapImage(requestID);
                    break;
                case AppConfig.FEATURE_FACE_DANCE:
                    callFaceDanceAndPlay(requestID);
                    break;
                case AppConfig.FEATURE_TRANSE_FACE_SWAP:
                    currentImageUrl = "https://cartoon-testapi.faceswapmagic.com/stablediff_results/" + AppConfig.DEFAULT_APP_NAME + "/" + requestID;
                    loadingVisionaryImage(requestID);
                    break;
                case AppConfig.FEATURE_REMOVE_BG:
                    currentImageUrl = "https://faceswapmagic.com/pixellab/examples/results/NaturePhotoFramesandEditor/" + requestID;
                    loadRemoveBGImage(requestID);
                    break;
                case AppConfig.FEATURE_AIENHANCER:
                    currentImageUrl = "https://enhance.faceswapmagic.com/pixellab/examples/results/NaturePhotoFramesandEditor/" + requestID;
                    loadImageEnhancerPhoto(requestID);
                    break;
                default:
                    break;
            }
        }
    }

    private void setupClickListeners() {
        binding.buttonBack.setOnClickListener(v -> finish());

        binding.saveButton.setOnClickListener(v -> saveImageToGallery());

        binding.shareButton.setOnClickListener(v -> shareImage());

        // Social media share buttons
        binding.instagramShare.setOnClickListener(v -> shareToSocialMedia("com.instagram.android"));
        binding.facebookShare.setOnClickListener(v -> shareToSocialMedia("com.facebook.katana"));
        binding.whatsappShare.setOnClickListener(v -> shareToSocialMedia("com.whatsapp"));
        binding.twitterShare.setOnClickListener(v -> shareToSocialMedia("com.twitter.android"));
        binding.snapchatShare.setOnClickListener(v -> shareToSocialMedia("com.snapchat.android"));
    }

    private void loadImageEnhancerPhoto(String requestID) {
        Glide.with(CommonResultScreen.this).load(currentImageUrl).into(binding.generatedImage);
    }

    private void callVideoPlayerAndDownloading(String requestID) {
        DownloadVideoAndPlay.getInstance(CommonResultScreen.this).makeRequest(AppConfig.DEFAULT_APP_NAME, requestID, binding.loadingProgressBar, binding.progressBar, binding.videoView);
    }

    private void callFaceDanceAndPlay(String requestID) {
        FaceDanceDownloadVideoAndPlay.getInstance(CommonResultScreen.this).makeRequest("NaturePhotoFramesandEditor", requestID, binding.loadingProgressBar, binding.progressBar, binding.videoView);
    }

    private void loadingAiBabyEffect(String requestID) {
        Glide.with(CommonResultScreen.this).load(currentImageUrl).into(binding.generatedImage);
    }

    private void loadRemoveBGImage(String requestID) {
        Glide.with(CommonResultScreen.this).load(currentImageUrl).into(binding.generatedImage);
    }

    private void loadingFaceSwapImage(String requestID) {
        Glide.with(CommonResultScreen.this).load(currentImageUrl).into(binding.generatedImage);
    }

    private void loadingVisionaryImage(String requestID) {
        Glide.with(CommonResultScreen.this).load(currentImageUrl).into(binding.generatedImage);
    }

    private void saveImageToGallery() {
        if (isImageSaved) {
            Toast.makeText(this, "Image already saved", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the bitmap from the ImageView
        binding.generatedImage.setDrawingCacheEnabled(true);
        binding.generatedImage.buildDrawingCache();
        Bitmap bitmap = binding.generatedImage.getDrawingCache();

        if (bitmap != null) {
            try {
                // Save the image
                File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                File imageFile = new File(storageDir, "Imagic_" + System.currentTimeMillis() + ".jpg");

                FileOutputStream outputStream = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();

                // Notify the system that a new image has been added
                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                mediaScanIntent.setData(Uri.fromFile(imageFile));
                sendBroadcast(mediaScanIntent);

                isImageSaved = true;
                updateSaveButtonState();

                Toast.makeText(this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
            }
        } else {
            // If we don't have a bitmap, download and save it
            downloadAndSaveImage();
        }
    }

    private void downloadAndSaveImage() {
        Glide.with(this)
                .asBitmap()
                .load(currentImageUrl)
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        try {
                            File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                            File imageFile = new File(storageDir, "Imagic_" + System.currentTimeMillis() + ".jpg");

                            FileOutputStream outputStream = new FileOutputStream(imageFile);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                            outputStream.flush();
                            outputStream.close();

                            // Notify the system that a new image has been added
                            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                            mediaScanIntent.setData(Uri.fromFile(imageFile));
                            sendBroadcast(mediaScanIntent);

                            isImageSaved = true;
                            updateSaveButtonState();

                            Toast.makeText(CommonResultScreen.this, "Image saved to gallery", Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Toast.makeText(CommonResultScreen.this, "Failed to save image", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onLoadCleared(Drawable placeholder) {
                    }
                });
    }

    private void updateSaveButtonState() {
        if (isImageSaved) {
            binding.saveButton.setAlpha(0.5f);
            binding.saveButton.setClickable(false);
        } else {
            binding.saveButton.setAlpha(1.0f);
            binding.saveButton.setClickable(true);
        }
    }

    private void shareImage() {
        // Get the bitmap from the ImageView
        binding.generatedImage.setDrawingCacheEnabled(true);
        binding.generatedImage.buildDrawingCache();
        Bitmap bitmap = binding.generatedImage.getDrawingCache();

        if (bitmap != null) {
            try {
                // Save the image to cache
                File cachePath = new File(getCacheDir(), "images");
                cachePath.mkdirs();
                File file = new File(cachePath, "shared_image.jpg");
                FileOutputStream outputStream = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();

                // Share the image
                Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/jpeg");
                shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share image via"));
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to share image", Toast.LENGTH_SHORT).show();
            }
        } else {
            // If we don't have a bitmap, share the URL
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, currentImageUrl);
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        }
    }

    private void shareToSocialMedia(String packageName) {
        // Check if the app is installed
        try {
            getPackageManager().getPackageInfo(packageName, 0);

            // Get the bitmap from the ImageView
            binding.generatedImage.setDrawingCacheEnabled(true);
            binding.generatedImage.buildDrawingCache();
            Bitmap bitmap = binding.generatedImage.getDrawingCache();

            if (bitmap != null) {
                try {
                    // Save the image to cache
                    File cachePath = new File(getCacheDir(), "images");
                    cachePath.mkdirs();
                    File file = new File(cachePath, "shared_image.jpg");
                    FileOutputStream outputStream = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                    outputStream.flush();
                    outputStream.close();

                    // Share to specific app
                    Uri contentUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);

                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("image/jpeg");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                    shareIntent.setPackage(packageName);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(shareIntent);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Failed to share image", Toast.LENGTH_SHORT).show();
                }
            } else {
                // If we don't have a bitmap, share the URL
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, currentImageUrl);
                shareIntent.setPackage(packageName);
                startActivity(shareIntent);
            }
        } catch (Exception e) {
            // App is not installed
            Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}