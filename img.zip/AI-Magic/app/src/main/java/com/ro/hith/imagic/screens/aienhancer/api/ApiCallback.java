package com.ro.hith.imagic.screens.aienhancer.api;

public interface ApiCallback {
    void onSuccess(String response);
    void onError(String errorMessage);
}