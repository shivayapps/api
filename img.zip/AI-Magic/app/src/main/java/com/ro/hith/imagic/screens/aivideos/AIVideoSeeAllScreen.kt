package com.ro.hith.imagic.screens.aivideos

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.ro.hith.imagic.R
import com.ro.hith.imagic.databinding.ActivityAivideoSeeAllScreenBinding
import com.ro.hith.imagic.screens.utils.AIVideoDataLoder

class AIVideoSeeAllScreen : AppCompatActivity() {

    private lateinit var binding: ActivityAivideoSeeAllScreenBinding
    private lateinit var handler: Handler
    private var currentPage = 0

    private val images = listOf(
        R.drawable.slider_hug,
        R.drawable.slider_kiss,
        R.drawable.slider_muscle,
        R.drawable.slider_gunshot,
        R.drawable.slider_cakify
    )

    private val autoSliderRunnable = object : Runnable {
        override fun run() {
            currentPage = (currentPage + 1) % images.size
            binding.videoViewPager.setCurrentItem(currentPage, true)
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAivideoSeeAllScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupViewPager()
        startAutoSlider()
        setAiVideoData()
    }


    private fun setAiVideoData() {
        AIVideoDataLoder.loadAndSetEffects(
            context = this@AIVideoSeeAllScreen,
            recyclerView = binding.effectsGrid,
            rawResourceId = R.raw.aimagic_videoeffects,
            adapterClickListener = { effect ->
                val isSpecialEffect = effect.effect_name == "hug" || effect.effect_name == "kissing"
                val targetActivity =
                    if (isSpecialEffect) DoubleAIVideoScreen::class.java else SingleAIVideoScreen::class.java
                Intent(this@AIVideoSeeAllScreen, targetActivity).apply {
                    putExtra("fromOption", effect.main_head)
                    putExtra("effect_name", effect.effect_name)
                    putExtra("otherEffectSelected", !isSpecialEffect)
                }.also { intent ->
                    startActivity(intent)
                    overridePendingTransition(
                        R.anim.cusotm_slide_in_right,
                        R.anim.custom_slide_out_left
                    )
                }
            }
        )
    }

    private fun setupViewPager() {
        binding.videoViewPager.adapter = AIVideoImageSliderAdapter(this, images)
        binding.videoViewPager.addOnPageChangeListener(createPageChangeListener())
        addDotsIndicator(0)
    }

    private fun createPageChangeListener() =
        object : androidx.viewpager.widget.ViewPager.OnPageChangeListener {
            override fun onPageSelected(position: Int) {
                currentPage = position
                addDotsIndicator(position)
            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageScrollStateChanged(state: Int) {}
        }

    private fun addDotsIndicator(position: Int) {
        binding.indicatorDots.removeAllViews()

        images.indices.forEach { i ->
            ImageView(this).apply {
                setImageResource(if (i == position) R.drawable.ai_video_selected else R.drawable.ai_video_not_selected_dot)

                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(8, 0, 8, 0) }

                animate().scaleX(if (i == position) 1.4f else 1f)
                    .scaleY(if (i == position) 1.4f else 1f)
                    .setDuration(200)
                    .start()

                binding.indicatorDots.addView(this)
            }
        }
    }

    private fun startAutoSlider() {
        handler = Handler(Looper.getMainLooper())
        handler.postDelayed(autoSliderRunnable, 500)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(autoSliderRunnable)
    }
}