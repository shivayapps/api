package com.ro.hith.imagic.screens.bodyeditor.screens;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;

import androidx.appcompat.app.AppCompatActivity;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.databinding.ActivityFaceEditorBinding;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;

import java.util.Stack;

public class FaceEditor extends AppCompatActivity {

    private ActivityFaceEditorBinding binding;
    Bitmap saveBitmap, mBitmap;
    boolean maskareaValuesadded;
    private SeekBar.OnSeekBarChangeListener seekBarChangeListener = new seekbarListener();
    private boolean isProgrammaticSeekBarChange = false;
    private Stack<EditState> undoStack = new Stack<>();
    private Stack<EditState> redoStack = new Stack<>();
    private int lastProgress = 0;
    private Bitmap faceBitmap;
    private float[] sourceVerts;
    private float[] warpedVerts;
    private int meshWidth;
    private float cellSize;
    private int faceX, faceY;
    private float pw;
    private float px;
    private float py;
    private float ratio;
    private float ph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityFaceEditorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        mBitmap = PhotoUploadManager.getInstance().getUniversalBitmap();
        setImageAndSeekBar();
        setOnClickListners();

    }

    private void setImageAndSeekBar() {

        binding.faceView.imageView = binding.bodyPreviewImage;
        binding.bodyPreviewImage.setImageBitmap(mBitmap);
        binding.changeFaceSeekBar.setOnSeekBarChangeListener(seekBarChangeListener);
    }

    private void setOnClickListners() {
        binding.undoFace.setOnClickListener(v -> {
            undo();
        });
        binding.reduFace.setOnClickListener(v -> {
            redo();
        });

        binding.applyBtn.setOnClickListener(v -> {
            finish();
        });
    }




    private void updateUndoRedoIcons() {
        if (!undoStack.isEmpty()) {
            binding.undoFace.setImageResource(R.drawable.body_undo_enable);
            binding.undoFace.setEnabled(true);
        } else {
            binding.undoFace.setImageResource(R.drawable.body_undo_disable);
            binding.undoFace.setEnabled(false);
        }

        if (!redoStack.isEmpty()) {
            binding.reduFace.setImageResource(R.drawable.body_redu_enable);
            binding.reduFace.setEnabled(true);
        } else {
            binding.reduFace.setImageResource(R.drawable.body_redu_disable);
            binding.reduFace.setEnabled(false);
        }
    }


    public void undo() {
        if (!undoStack.isEmpty()) {
            redoStack.push(new EditState(saveBitmap, lastProgress));

            EditState previous = undoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(previous.bitmap);
            saveBitmap = previous.bitmap;
            lastProgress = previous.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeFaceSeekBar.setProgress(previous.progress);
            isProgrammaticSeekBarChange = false;

        }
    }

    public void redo() {
        if (!redoStack.isEmpty()) {
            undoStack.push(new EditState(saveBitmap, lastProgress));

            EditState next = redoStack.pop();
            binding.bodyPreviewImage.setImageBitmap(next.bitmap);
            saveBitmap = next.bitmap;
            lastProgress = next.progress;

            isProgrammaticSeekBarChange = true;
            binding.changeFaceSeekBar.setProgress(next.progress); // <-- Update SeekBar
            isProgrammaticSeekBarChange = false;


        }
    }


    private void showSeekBarView() {

        binding.changeFaceSeekBar.setVisibility(View.VISIBLE);

    }

    public void createFilter(int pro) {

        if (saveBitmap != null) {
            undoStack.push(new EditState(saveBitmap, lastProgress));
            PhotoUploadManager.getInstance().setUniversalBitmap(saveBitmap);
            redoStack.clear();
        } else {

            undoStack.push(new EditState(mBitmap, 0));
            redoStack.clear();
        }

        lastProgress = pro;

        Bitmap b = applyWarp(mBitmap, faceX, faceY, pro);


        binding.bodyPreviewImage.setImageBitmap(b);
        saveBitmap = b;

    }

    public Bitmap applyWarp(Bitmap fullImage, int faceX, int faceY, long progress) {
        float factor = (float) progress / 75.0f;

        for (int i = 0; i < warpedVerts.length; i += 2) {
            int x = (i / 2) % (meshWidth + 1);
            int y = (i / 2) / (meshWidth + 1);
            float fx = x * cellSize;
            float fy = y * cellSize;
            warpedVerts[i] = (sourceVerts[i] * factor) + fx;
            warpedVerts[i + 1] = (sourceVerts[i + 1] * factor) + fy;
        }

        Bitmap result = Bitmap.createBitmap(fullImage.getWidth(), fullImage.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawBitmap(fullImage, 0, 0, null);

        Bitmap faceCopy = faceBitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas faceCanvas = new Canvas(faceCopy);
        faceCanvas.drawBitmapMesh(faceBitmap, meshWidth, meshWidth, warpedVerts, 0, null, 0, null);

        canvas.drawBitmap(faceCopy, faceX, faceY, null);
        faceCopy.recycle();

        return result;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        binding = null;
    }

    class seekbarListener implements SeekBar.OnSeekBarChangeListener {

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {

            if (isProgrammaticSeekBarChange) return;
            getMaskArea();
            meshWidth = 10;
            setupMesh();
            createFilter(seekBar.getProgress());

            if (binding.applyBtn.getVisibility() == View.GONE) {
                binding.applyBtn.setVisibility(View.VISIBLE);
            }

        }

        private void getMaskArea() {
            if (!maskareaValuesadded) {
                maskareaValuesadded = true;
                pw = binding.faceView.getWidth() * binding.faceView.getScaleX();
                ph = binding.faceView.getHeight() * binding.faceView.getScaleY();
                px = binding.faceView.getX() + ((binding.faceView.getWidth() - pw) / 2.0f);
                py = binding.faceView.getY() + ((binding.faceView.getHeight() - ph) / 2.0f);
                ratio = (float) mBitmap.getHeight() / (float) binding.implimentedView.getHeight();

                int cropW = (int) (pw * ratio);
                int cropH = (int) (ph * ratio);
                faceX = (int) (px);
                faceY = (int) (py);

                faceBitmap = Bitmap.createBitmap(mBitmap, faceX, faceY, cropW, cropH);
            }
        }


        private void setupMesh() {
            int count = (meshWidth + 1) * (meshWidth + 1) * 2;
            sourceVerts = new float[count];
            warpedVerts = new float[count];
            cellSize = (float) faceBitmap.getWidth() / meshWidth;

            float center = faceBitmap.getWidth() / 2f;
            for (int i = 0; i < count; i += 2) {
                int idx = i / 2;
                int x = idx % (meshWidth + 1);
                int y = idx / (meshWidth + 1);
                float fx = x * cellSize - center;
                float fy = y * cellSize - center;
                float dist = (float) Math.sqrt(fx * fx + fy * fy);
                float scale = (center - dist) / center;
                if (scale < 0) scale = 0;
                sourceVerts[i] = fx * scale;
                sourceVerts[i + 1] = fy * scale;
            }

            showSeekBarView();
        }


        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            if (isProgrammaticSeekBarChange) return;
            updateUndoRedoIcons();


        }


    }
}