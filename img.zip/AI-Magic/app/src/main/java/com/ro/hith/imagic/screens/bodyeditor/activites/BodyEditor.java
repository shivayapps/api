package com.ro.hith.imagic.screens.bodyeditor.activites;

import android.app.Activity;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.ro.hith.imagic.databinding.ActivityBodyEditorBinding;
import com.ro.hith.imagic.screens.bodyeditor.screens.ChestEditor;
import com.ro.hith.imagic.screens.bodyeditor.screens.FaceEditor;
import com.ro.hith.imagic.screens.bodyeditor.screens.HipsEditor;
import com.ro.hith.imagic.screens.bodyeditor.screens.WaistEditor;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

public class BodyEditor extends AppCompatActivity {
    private ActivityBodyEditorBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityBodyEditorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setOnClickListners();

    }

    private void setOnClickListners() {
        binding.faceControl.setOnClickListener(view -> navigateUser(FaceEditor.class));
        binding.waistControl.setOnClickListener(view -> navigateUser(WaistEditor.class));
        binding.chestControl.setOnClickListener(view -> navigateUser(ChestEditor.class));
        binding.hipsControl.setOnClickListener(view -> navigateUser(HipsEditor.class));
    }

    private void setImageResource() {

        try {
            binding.bodyPreviewImage.setImageBitmap(PhotoUploadManager.getInstance().getUniversalBitmap());
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void onResume() {
        super.onResume();
        setImageResource();
    }

    @SuppressWarnings("unchecked")
    private void navigateUser(Class<? extends Activity> targetActivity) {
        StartActivityGlobally.navigateToActivityWithFeature(
                BodyEditor.this,
                targetActivity);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}