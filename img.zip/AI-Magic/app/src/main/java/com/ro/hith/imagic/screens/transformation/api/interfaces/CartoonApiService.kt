package com.ro.hith.imagic.screens.transformation.api.interfaces

import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface CartoonApiService {
    @Multipart
    @POST("stable_diffusion/")
    suspend fun generateCartoon(
        @Query("app_name") appName: String,
        @Query("category") category: String,
        @Query("sub_category") subCategory: String,
        @Query("prompt") prompt: String,
        @Query("negative_prompt") negativePrompt: String,
        @Query("steps") steps: Int,
        @Query("seed") seed: Long,
        @Query("cfg_scale") cfgScale: Float,
        @Query("denoising_strength") denoisingStrength: Float,
        @Query("sampler_index") samplerIndex: String,
        @Query("model") model: String,
        @Part inputImage: MultipartBody.Part,
        @Header("accept") accept: String = "application/json",
        @Header("fcmtoken") fcmToken: String,
        @Header("x-firebase-appcheck") appCheckToken: String
    ): Response<ResponseBody>
}