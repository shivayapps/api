package com.ro.hith.imagic.screens.facedance;

import java.util.ArrayList;

public class VideoDataHandler {
    private static VideoDataHandler sInstance;
    private String mCurrentVideoUrl;
    private ArrayList<String> mVideoUrls;
    private ArrayList<String> mAllUrls;
    private ArrayList<String> mUserTypes;
    private String mCurrentVideoName;
    private int mCurrentPosition;

    private VideoDataHandler() {
        mVideoUrls = new ArrayList<>();
        mAllUrls = new ArrayList<>();
        mUserTypes = new ArrayList<>();
        mCurrentPosition = 0;
    }

    public static VideoDataHandler getInstance() {
        if (sInstance == null) {
            sInstance = new VideoDataHandler();
        }
        return sInstance;
    }

    public String getVideoUrl() {
        return mCurrentVideoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.mCurrentVideoUrl = videoUrl;
    }

    public ArrayList<String> getVideoList() {
        return mVideoUrls;
    }

    public void setVideoList(ArrayList<String> videoList) {
        this.mVideoUrls = videoList;
    }

    public ArrayList<String> getUrlLists() {
        return mAllUrls;
    }

    public void setUrlLists(ArrayList<String> urlLists) {
        this.mAllUrls = urlLists;
    }

    public ArrayList<String> getUserTypeList() {
        return mUserTypes;
    }

    public void setUserTypeList(ArrayList<String> userTypeList) {
        this.mUserTypes = userTypeList;
    }

    public String getVideoName() {
        return mCurrentVideoName;
    }

    public void setVideoName(String videoName) {
        this.mCurrentVideoName = videoName;
    }

    public int getCurrentPosition() {
        return mCurrentPosition;
    }

    public void setCurrentPosition(int currentPosition) {
        this.mCurrentPosition = currentPosition;
    }
}