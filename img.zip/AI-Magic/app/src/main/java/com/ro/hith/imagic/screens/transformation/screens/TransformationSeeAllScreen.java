package com.ro.hith.imagic.screens.transformation.screens;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.ro.hith.imagic.databinding.ActivityTransformationSeeAllScreenBinding;
import com.ro.hith.imagic.screens.transformation.adapters.TransformationCharacterAdapter;
import com.ro.hith.imagic.screens.transformation.models.TransformationCharacterItem;
import com.ro.hith.imagic.screens.utils.transformation.TransformationDataLoader;

public class TransformationSeeAllScreen extends AppCompatActivity implements TransformationCharacterAdapter.OnItemClickListener {

    private ActivityTransformationSeeAllScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTransformationSeeAllScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.onBackButton.setOnClickListener(v -> finish());

        TransformationDataLoader.setUpTransformationRecyclerview(TransformationSeeAllScreen.this, binding.tranformationRecyclerview, this);
    }

    @Override
    public void onItemClick(TransformationCharacterItem item, String imageUrl) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("SELECTED_IMAGE_URL", imageUrl);
        resultIntent.putExtra("SELECTED_CHARACTER_ITEM", item);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}