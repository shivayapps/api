package com.ro.hith.imagic.screens.facedance;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.ro.hith.imagic.databinding.ActivityFaceDanceSeeAllScreenBinding;
import com.ro.hith.imagic.screens.utils.facedance.FaceDanceDataLoader;

public class FaceDanceSeeAllScreen extends AppCompatActivity {

    private ActivityFaceDanceSeeAllScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityFaceDanceSeeAllScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        FaceDanceDataLoader.loadFaceDanceData(FaceDanceSeeAllScreen.this, binding.faceDanceRecyclerView);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}