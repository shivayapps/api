package com.ro.hith.imagic.screens.commonscreen.screen;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.databinding.ActivityOnLaunchBinding;
import com.ro.hith.imagic.screens.onboardingflow.dataset.CustomOnBoardingPrefManager;
import com.ro.hith.imagic.screens.onboardingflow.screen.CustomOnBoardingActivity;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

public class OnLaunchScreen extends AppCompatActivity {

    private ActivityOnLaunchBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOnLaunchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setGradientColorToText();
        setOnClickListener();
        setUpSplashVideo();

    }

    private void setUpSplashVideo() {

        String videoUriString =
                "android.resource://" + OnLaunchScreen.this.getPackageName() + "/" + R.raw.splash_vid;
        Uri videoUri = Uri.parse(videoUriString);
        binding.splshVideo.setVideoURI(videoUri);

        binding.splshVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {

                mediaPlayer.setLooping(true);
                binding.splshVideo.start();
            }
        });

        binding.splshVideo.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.e("VideoError", "Can't play video. what=" + what + ", extra=" + extra);
                return true;
            }
        });

    }

    private void setOnClickListener() {

        binding.getStartedBtn.setOnClickListener(v -> {
            if (new CustomOnBoardingPrefManager(OnLaunchScreen.this).getInitialAppLaunch()) {
                navigateUser(CustomOnBoardingActivity.class);
            } else {
//                navigateUser(HomeScreen.class);
                navigateUser(CustomOnBoardingActivity.class);
            }
        });
    }


    @SuppressWarnings("unchecked")
    private void navigateUser(Class<? extends Activity> targetActivity) {
        StartActivityGlobally.navigateToActivityWithFeature(
                OnLaunchScreen.this,
                targetActivity);
    }

    private void setGradientColorToText() {
        Shader textShader = new LinearGradient(
                0, 0,
                binding.appName.getPaint().measureText(binding.appName.getText().toString()), // end x
                0,
                new int[]{
                        Color.parseColor("#FB5CD8"),
                        Color.parseColor("#EF60B3"),
                        Color.parseColor("#9F3CD2")
                },
                null,
                Shader.TileMode.CLAMP
        );
        binding.appName.getPaint().setShader(textShader);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}