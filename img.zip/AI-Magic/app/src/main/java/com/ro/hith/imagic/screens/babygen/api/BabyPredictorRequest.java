package com.ro.hith.imagic.screens.babygen.api;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.screens.commonscreen.screen.CommonResultScreen;
import com.ro.hith.imagic.screens.singletone.CustomDialogManager;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

import kotlin.Pair;

public class BabyPredictorRequest {

    private static BabyPredictorRequest instance;
    private Context context;
    private transient String requestId;

    private BabyPredictorRequest(Context context) {
        this.context = context.getApplicationContext();
    }

    public static synchronized BabyPredictorRequest getInstance(Context context) {
        if (instance == null) {
            instance = new BabyPredictorRequest(context);
        }
        return instance;
    }

    public void makeRequest() {
        if (context == null) {
            System.out.println("Error: Context is null");
            return;
        }


        PredictRequest request = new PredictRequest()
                .withBabyGender("boy")
                .withBabyCountry("IN")
                .withAppName("NaturePhotoFramesandEditor")
                .withMotherPercent(50)
                .withFatherPercent(50)
                .withSkinTone("skintone_1")
                .withAgeGroup("baby")
                .withCountryCode("IN")
                .withPlatform("android")
                .withFcmToken("asdf")
                .withFirebaseAppCheck("asdf")
                .withMotherList("string")
                .withFatherList("string")
                .withMotherImage(new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath()))
                .withFatherImage(new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath()));


        BabyPredictorApiClient.getInstance().predictBabyFeatures(request, new ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    String requestIdFromResponse = jsonResponse.optString("request_id", "default_id");

                    final String numericRequestId = requestIdFromResponse.replaceAll("[^\\d.]", "").trim();

                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
                            showToastOnUiThread("Upload successful: " + numericRequestId);
                            processToNextScreen(numericRequestId);
                        }
                    }, 10000);

                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing JSON response: " + e.getMessage());
                    final String fallbackId = String.valueOf(System.currentTimeMillis());
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
                            showToastOnUiThread("Upload successful with fallback ID");
                            showNoServer();
                        }
                    }, 10000);
                }
            }

            @Override
            public void onError(String errorMessage) {
                showNoServer();
                showToastOnUiThread("Upload failed: " + errorMessage);
            }
        });
    }

    private void showToastOnUiThread(final String message) {
        if (context != null) {
            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {

                    Toast.makeText(context, message, Toast.LENGTH_LONG).show();
                }
            });
        }
    }


    private void showNoServer() {
        if (context != null) {
            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {

                    CustomDialogManager.getInstance().showDialog(
                            context,
                            "No Server",
                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
                            "Got it",
                            R.drawable.ic_brush,
                            new CustomDialogManager.DialogButtonClickListener() {
                                @Override
                                public void onButtonClicked() {
                                    ((Activity) context).finish();
                                }
                            }
                    );

                }
            });
        }
    }


    @SuppressWarnings("unchecked")
    private void processToNextScreen(String requestId) {
        Log.d(TAG, "Generate face swap button clicked");
        StartActivityGlobally.navigateToActivityWithFeature(
                context,
                CommonResultScreen.class,
                new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
                new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_BABY_BOY)
        );
        ((Activity) context).finish();

    }


    public void setContext(Context context) {
        this.context = context.getApplicationContext();
    }
}