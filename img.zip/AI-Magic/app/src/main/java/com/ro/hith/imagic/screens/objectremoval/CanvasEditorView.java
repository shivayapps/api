package com.ro.hith.imagic.screens.objectremoval;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class CanvasEditorView extends View {

    private Bitmap sourceImage;
    private Bitmap editableBitmap;
    private Canvas drawingSurface;
    private Paint activeBrush;
    private Path currentStroke;
    private List<Path> allStrokes;
    private List<Paint> brushProperties;
    private Queue<Path> undoHistory;
    private Queue<Path> redoHistory;
    private Queue<Paint> undoBrushHistory;
    private Queue<Paint> redoBrushHistory;
    private boolean hasDrawing = false;
    private Rect zoomArea;
    private Bitmap zoomedView;
    ImageView zoomDisplay;
    private DrawingStateListener stateListener;
    private ObjectRemovalScreen parentActivity;

    public interface DrawingStateListener {
        void onDrawingStateUpdated();
    }

    public void setParentActivity(ObjectRemovalScreen activity) {
        this.parentActivity = activity;
    }

    public void enableUndoButton() {
        if (parentActivity != null) {
            parentActivity.runOnUiThread(() -> parentActivity.adjustUndoOpacity(1.0f));
        }
    }

    public void disableUndoButton() {
        if (parentActivity != null) {
            parentActivity.runOnUiThread(() -> parentActivity.adjustUndoOpacity(0.5f));
        }
    }

    public void enableRedoButton() {
        if (parentActivity != null) {
            parentActivity.runOnUiThread(() -> parentActivity.adjustRedoOpacity(1.0f));
        }
    }

    public void disableRedoButton() {
        if (parentActivity != null) {
            parentActivity.runOnUiThread(() -> parentActivity.adjustRedoOpacity(0.5f));
        }
    }

    public CanvasEditorView(Context context, AttributeSet attributes) {
        super(context, attributes);
        initialize();
        zoomArea = new Rect(0, 0, 200, 200);
    }

    private void initialize() {
        activeBrush = createBrush(Color.WHITE, 10);
        currentStroke = new Path();
        allStrokes = new ArrayList<>();
        brushProperties = new ArrayList<>();
        undoHistory = new LinkedList<>();
        redoHistory = new LinkedList<>();
        undoBrushHistory = new LinkedList<>();
        redoBrushHistory = new LinkedList<>();
        setWillNotDraw(false);
    }

    private Paint createBrush(int colorValue, int thickness) {
        Paint brush = new Paint();
        brush.setColor(colorValue);
        brush.setStrokeWidth(thickness);
        brush.setStyle(Paint.Style.STROKE);
        brush.setAntiAlias(true);
        brush.setStrokeCap(Paint.Cap.ROUND);
        brush.setStrokeJoin(Paint.Join.ROUND);
        return brush;
    }

    public void refreshZoomDisplay(float touchPosX, float touchPosY) {
        if (sourceImage != null) {
            int zoomWidthHalf = zoomArea.width() / 2;
            int zoomHeightHalf = zoomArea.height() / 2;

            touchPosX = Math.max(0, Math.min(touchPosX, sourceImage.getWidth()));
            touchPosY = Math.max(0, Math.min(touchPosY, sourceImage.getHeight()));

            int leftEdge = Math.max(0, (int) (touchPosX - zoomWidthHalf));
            int topEdge = Math.max(0, (int) (touchPosY - zoomHeightHalf));
            int rightEdge = Math.min(sourceImage.getWidth(), leftEdge + zoomArea.width());
            int bottomEdge = Math.min(sourceImage.getHeight(), topEdge + zoomArea.height());

            if (rightEdge - leftEdge < zoomArea.width()) {
                leftEdge = Math.max(0, rightEdge - zoomArea.width());
            }
            if (bottomEdge - topEdge < zoomArea.height()) {
                topEdge = Math.max(0, bottomEdge - zoomArea.height());
            }

            zoomArea.set(leftEdge, topEdge, rightEdge, bottomEdge);

            int displayWidth = zoomArea.width();
            int displayHeight = zoomArea.height();
            if (displayWidth <= 0 || displayHeight <= 0) {
                return;
            }

            if (zoomedView == null || zoomedView.getWidth() != displayWidth || zoomedView.getHeight() != displayHeight) {
                zoomedView = Bitmap.createBitmap(displayWidth, displayHeight, Bitmap.Config.ARGB_8888);
            }

            Canvas zoomCanvas = new Canvas(zoomedView);
            zoomCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);

            Rect sourceRect = new Rect(zoomArea.left, zoomArea.top, zoomArea.right, zoomArea.bottom);
            Rect destinationRect = new Rect(0, 0, displayWidth, displayHeight);
            zoomCanvas.drawBitmap(sourceImage, sourceRect, destinationRect, null);

            float scaleFactorX = (float) displayWidth / (zoomArea.right - zoomArea.left);
            float scaleFactorY = (float) displayHeight / (zoomArea.bottom - zoomArea.top);

            Matrix scalingMatrix = new Matrix();
            scalingMatrix.setScale(scaleFactorX, scaleFactorY);

            for (int i = 0; i < allStrokes.size(); i++) {
                Path scaledPath = new Path();
                allStrokes.get(i).offset(-zoomArea.left, -zoomArea.top, scaledPath);
                scaledPath.transform(scalingMatrix);
                zoomCanvas.drawPath(scaledPath, brushProperties.get(i));
            }

            Path dynamicPath = new Path();
            currentStroke.offset(-zoomArea.left, -zoomArea.top, dynamicPath);
            dynamicPath.transform(scalingMatrix);
            zoomCanvas.drawPath(dynamicPath, activeBrush);

            if (zoomDisplay != null) {
                zoomDisplay.setImageBitmap(zoomedView);
            }
        }
    }

    private Matrix createScalingMatrix(float scaleX, float scaleY) {
        Matrix matrix = new Matrix();
        matrix.setScale(scaleX, scaleY);
        return matrix;
    }

    public void setZoomDisplay(ImageView zoomImageView) {
        this.zoomDisplay = zoomImageView;
    }

    public void loadImage(Bitmap inputImage, Context context) {
        if (inputImage != null) {
            Glide.with(context)
                    .asBitmap()
                    .load(inputImage)
                    .override(720, 1280)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            sourceImage = resource;
                            editableBitmap = Bitmap.createBitmap(resource.getWidth(), resource.getHeight(), Bitmap.Config.ARGB_8888);
                            drawingSurface = new Canvas(editableBitmap);
                            drawingSurface.drawBitmap(resource, 0, 0, null);
                            invalidate();
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (editableBitmap != null) {
            canvas.drawBitmap(editableBitmap, 0, 0, null);
        }

        for (int i = 0; i < allStrokes.size(); i++) {
            canvas.drawPath(allStrokes.get(i), brushProperties.get(i));
        }

        activeBrush.setColor(Color.argb(128, 255, 0, 0));
        canvas.drawPath(currentStroke, activeBrush);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float xPos = event.getX();
        float yPos = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (zoomDisplay != null) {
                    zoomDisplay.setVisibility(View.VISIBLE);
                }
                currentStroke.moveTo(xPos, yPos);
                break;

            case MotionEvent.ACTION_MOVE:
                currentStroke.lineTo(xPos, yPos);
                break;

            case MotionEvent.ACTION_UP:
                allStrokes.add(currentStroke);
                brushProperties.add(new Paint(activeBrush));
                undoHistory.add(currentStroke);
                undoBrushHistory.add(new Paint(activeBrush));
                redoHistory.clear();
                redoBrushHistory.clear();
                currentStroke = new Path();
                hasDrawing = true;
                enableUndoButton();

                if (zoomDisplay != null) {
                    zoomDisplay.setVisibility(View.INVISIBLE);
                }
                break;
        }

        invalidate();
        refreshZoomDisplay(xPos, yPos);
        return true;
    }

    public void performUndo() {
        if (!undoHistory.isEmpty()) {
            Path removedPath = undoHistory.remove();
            Paint removedBrush = undoBrushHistory.remove();
            redoHistory.add(removedPath);
            redoBrushHistory.add(removedBrush);
            allStrokes.remove(allStrokes.size() - 1);
            brushProperties.remove(brushProperties.size() - 1);
            hasDrawing = !allStrokes.isEmpty();
            invalidate();
            enableUndoButton();
            enableRedoButton();
        } else {
            disableUndoButton();
            enableRedoButton();
        }
    }

    public void performRedo() {
        if (!redoHistory.isEmpty()) {
            Path restoredPath = redoHistory.remove();
            Paint restoredBrush = redoBrushHistory.remove();
            undoHistory.add(restoredPath);
            undoBrushHistory.add(restoredBrush);
            allStrokes.add(restoredPath);
            brushProperties.add(restoredBrush);
            hasDrawing = true;
            invalidate();
            enableUndoButton();
            enableRedoButton();
        } else {
            disableRedoButton();
            enableUndoButton();
        }
    }

    public void adjustBrushSize(int newSize) {
        activeBrush.setStrokeWidth(newSize);
    }

    public void adjustBrushColor(int newColor) {
        activeBrush.setColor(newColor);
    }

    public Bitmap getEditedBitmap() {
        if (sourceImage == null) {
            return null;
        }

        Bitmap resultImage = Bitmap.createBitmap(sourceImage.getWidth(), sourceImage.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas resultCanvas = new Canvas(resultImage);
        resultCanvas.drawColor(Color.TRANSPARENT);

        Paint whiteBrush = new Paint();
        whiteBrush.setColor(Color.WHITE);
        whiteBrush.setStyle(Paint.Style.STROKE);
        whiteBrush.setAntiAlias(true);

        for (int i = 0; i < allStrokes.size(); i++) {
            whiteBrush.setStrokeWidth(brushProperties.get(i).getStrokeWidth());
            resultCanvas.drawPath(allStrokes.get(i), whiteBrush);
        }

        return resultImage;
    }

    public boolean hasDrawing() {
        return hasDrawing;
    }

    public boolean canUndo() {
        return !undoHistory.isEmpty();
    }

    public boolean canRedo() {
        return !redoHistory.isEmpty();
    }
}