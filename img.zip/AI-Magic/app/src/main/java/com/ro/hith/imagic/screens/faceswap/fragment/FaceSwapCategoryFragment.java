package com.ro.hith.imagic.screens.faceswap.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.screens.faceswap.FaceSwapImageUploadScreen;
import com.ro.hith.imagic.screens.faceswap.adapter.FaceSwapAdapter;
import com.ro.hith.imagic.screens.faceswap.model.FaceSwapCategory;
import com.ro.hith.imagic.screens.faceswap.model.FaceSwapUrl;

public class FaceSwapCategoryFragment extends Fragment {
    private static final String ARG_CATEGORY = "category";
    private FaceSwapCategory category;

    public static FaceSwapCategoryFragment newInstance(FaceSwapCategory category) {
        FaceSwapCategoryFragment fragment = new FaceSwapCategoryFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_CATEGORY, category);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            category = (FaceSwapCategory) getArguments().getSerializable(ARG_CATEGORY);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_face_swap_category, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        FaceSwapAdapter adapter = new FaceSwapAdapter(category.getUrls(), new FaceSwapAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(FaceSwapUrl faceSwapUrl) {
                Intent intent = new Intent(getActivity(), FaceSwapImageUploadScreen.class);
                intent.putExtra("selected_image_url", faceSwapUrl.getUrl());
                startActivity(intent);
            }
        });

        recyclerView.setAdapter(adapter);

        return view;
    }
}