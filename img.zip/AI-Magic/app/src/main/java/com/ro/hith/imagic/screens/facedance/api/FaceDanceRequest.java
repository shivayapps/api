package com.ro.hith.imagic.screens.facedance.api;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.screens.commonscreen.screen.CommonResultScreen;
import com.ro.hith.imagic.screens.facedance.UploadRequest;
import com.ro.hith.imagic.screens.singletone.CustomDialogManager;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

import kotlin.Pair;

public class FaceDanceRequest {

    private static FaceDanceRequest instance;
    private Context context;

    // Private constructor to prevent instantiation
    private FaceDanceRequest(Context context) {
        this.context = context.getApplicationContext();
    }

    public static synchronized FaceDanceRequest getInstance(Context context) {
        if (instance == null) {
            instance = new FaceDanceRequest(context);
        }
        return instance;
    }

    public void makeRequest() {
        if (context == null) {
            System.out.println("Error: Context is null");
            return;
        }

        UploadRequest request = new UploadRequest()
                .withInputImageFile(new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath()))
                .withAppName("NaturePhotoFramesandEditor")
                .withFolder("angrymood")
                .withFileName("angrymood1.mp4")
                .withCountryCode("IN")
                .withPlatform("android")
                .withFirebaseAppCheck("asd")
                .withFcmToken("asd");

        FaceDanceApiClient.getInstance().uploadImage(request, new FaceDanceApiClient.ApiCallback() {
            @Override
            public void onSuccess(String response) {
                showToastOnUiThread("Upload successful: " + response);
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    String requestIdFromResponse = jsonResponse.optString("request_id", "default_id");

                    final String numericRequestId = requestIdFromResponse.replaceAll("[^\\d.]", "").trim();

                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
                            showToastOnUiThread("Upload successful: " + numericRequestId);
                            processToNextScreen(numericRequestId);
                        }
                    }, 10000);

                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing JSON response: " + e.getMessage());
                    final String fallbackId = String.valueOf(System.currentTimeMillis());
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
                            showToastOnUiThread("Upload successful with fallback ID");
                            showNoServer();
                        }
                    }, 10000);
                }
            }

            @Override
            public void onError(String errorMessage) {
                showNoServer();
                showToastOnUiThread("Upload failed: " + errorMessage);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void processToNextScreen(String requestId) {
        Log.d(TAG, "Generate face swap button clicked");
        StartActivityGlobally.navigateToActivityWithFeature(
                context,
                CommonResultScreen.class,
                new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
                new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_FACE_DANCE)
        );
    }


    private void showNoServer() {
        if (context != null) {
            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    CustomDialogManager.getInstance().showDialog(
                            context,
                            "No Server",
                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
                            "Got it",
                            R.drawable.ic_brush,
                            new CustomDialogManager.DialogButtonClickListener() {
                                @Override
                                public void onButtonClicked() {
                                    ((Activity) context).finish();
                                }
                            }
                    );
                }
            });
        }
    }


    private void showToastOnUiThread(final String message) {
        if (context != null) {
            android.os.Handler handler = new android.os.Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, message, Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    public void setContext(Context context) {
        this.context = context.getApplicationContext();
    }
}