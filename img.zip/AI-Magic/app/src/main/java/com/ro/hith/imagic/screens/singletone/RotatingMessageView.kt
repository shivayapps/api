package com.ro.hith.imagic.screens.singletone


import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.animation.AnimationUtils
import android.widget.TextView
import android.widget.ViewFlipper
import androidx.core.content.res.ResourcesCompat
import com.ro.hith.imagic.R
import java.util.Collections

class RotatingMessageView : ViewFlipper {

    private var appContext: Context
    private var messageCollection: List<String>? = null

    constructor(context: Context) : super(context) {
        this.appContext = context
        initializeComponent(context)
    }

    constructor(context: Context, attributeSet: AttributeSet?) : super(context, attributeSet) {
        this.appContext = context
        initializeComponent(context)
    }

    private fun initializeComponent(context: Context) {
        this.appContext = context
        flipInterval = 1605
        setPadding(convertDpToPixels(5f), convertDpToPixels(0f), convertDpToPixels(5f), convertDpToPixels(0f))
        inAnimation = AnimationUtils.loadAnimation(context, R.anim.`in_flip`)
        outAnimation = AnimationUtils.loadAnimation(context, R.anim.flip_out)
        populateWithMessages(obtainMessageList())
    }

    private fun obtainMessageList(): List<String> {
        val messages = listOf(
            "Generating magic...",
            "Pixels taking shape...",
            "AI is painting...",
            "Bringing vision to life...",
            "Crafting your masterpiece...",
            "Smart creativity loading...",
            "Art in progress...",
            "Unleashing imagination...",
            "Almost there...",
            "Creating brilliance...",
            "Sketching innovation...",
            "Shaping perfection...",
            "Building beauty...",
            "AI is at work...",
            "Brushing up details...",
            "Crafting creativity...",
            "Transforming ideas...",
            "Imagination in motion...",
            "Weaving digital magic...",
            "Masterpiece loading...",
            "AI strokes in progress...",
            "Turning data into art...",
            "Neural networks designing...",
            "Shaping digital wonder...",
            "Pixel perfection coming...",
            "Your idea is evolving...",
            "AI is painting pixels...",
            "Synthesizing creativity...",
            "Dreaming up colors...",
            "Just a few more strokes...",
            "Filling in the details...",
            "Vision becoming reality...",
            "Bringing art to life...",
            "AI magic unfolding...",
            "Composing a masterpiece...",
            "Shaping stunning visuals...",
            "Your request is transforming...",
            "Intelligence meets creativity...",
            "Crafting perfection...",
            "Pixels aligning beautifully...",
            "Loading artistic genius...",
            "Almost ready to reveal...",
            "Final touches in progress...",
            "AI is working for you...",
            "Creating with precision...",
            "Pixels coming to life...",
            "AI-generated beauty unfolding..."
        )

        return messages.shuffled()
    }

    fun populateWithMessages(messageList: List<String>) {
        removeAllViews()
        this.messageCollection = messageList

        for ((position, currentMessage) in messageList.withIndex()) {
            val messageView = TextView(appContext).apply {
                maxLines = 3
                text = currentMessage
                textSize = 18f
                ellipsize = android.text.TextUtils.TruncateAt.END
                typeface = ResourcesCompat.getFont(appContext, R.font.albertsans_bold)
                gravity = Gravity.CENTER
                textAlignment = TEXT_ALIGNMENT_CENTER
                tag = position

                post {
                    setTextColor(Color.WHITE)
                }
            }

            addView(messageView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        }
    }

    private fun convertDpToPixels(dpValue: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dpValue,
            appContext.resources.displayMetrics
        ).toInt()
    }
}