package com.ro.hith.imagic.screens.utils.transformation

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.ro.hith.imagic.R
import com.ro.hith.imagic.screens.transformation.adapters.TransformationCharacterAdapter
import com.ro.hith.imagic.screens.transformation.models.TransformationCharacterItem
import com.ro.hith.imagic.screens.transformation.models.TransformationCharacterModel
import com.ro.hith.imagic.screens.transformation.screens.TransformationImageUploadScreen
import com.ro.hith.imagic.screens.utils.JSONLoder
import org.json.JSONException
import org.json.JSONObject


object TransformationDataLoader {

    @JvmStatic
    fun loadTransformationData(context: Context): List<TransformationCharacterItem> {
        val characterItems = mutableListOf<TransformationCharacterItem>()

        try {
            val jsonStr =
                JSONLoder.loadJSONFromRaw(context, R.raw.transformation_data).toString()
            val root = JSONObject(jsonStr)

            val categories = root.keys()
            while (categories.hasNext()) {
                val category = categories.next()
                val categoryObject = root.getJSONObject(category)

                val subCategories = categoryObject.keys()
                while (subCategories.hasNext()) {
                    val subCategory = subCategories.next()
                    val modelJson = categoryObject.getJSONObject(subCategory)

                    val model = Gson().fromJson(
                        modelJson.toString(),
                        TransformationCharacterModel::class.java
                    )
                    val item =
                        TransformationCharacterItem(
                            category,
                            subCategory,
                            model
                        )
                    characterItems.add(item)
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        return characterItems
    }


    @JvmStatic
    fun setUpTransformationRecyclerview(
        context: Context,
        recyclerView: RecyclerView,
        listener: TransformationCharacterAdapter.OnItemClickListener? = null
    ) {
        val transformationData = TransformationDataLoader.loadTransformationData(context)
        val topAdapter: TransformationCharacterAdapter =
            TransformationCharacterAdapter(
                context,
                transformationData
            )

        topAdapter.setOnItemClickListener { item, imageUrl ->
            if (listener != null) {
                listener.onItemClick(item, imageUrl)
            } else {
                val intent =
                    Intent(context, TransformationImageUploadScreen::class.java).apply {
                        putExtra("transformationItem", item)
                        putExtra("selectedImageUrl", imageUrl)
                    }
                context.startActivity(intent)
                (context as Activity).apply {
                    overridePendingTransition(
                        R.anim.cusotm_slide_in_right,
                        R.anim.custom_slide_out_left
                    )
                }
            }
        }

        recyclerView.adapter = topAdapter
    }
}

