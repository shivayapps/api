package com.developerdepository.noted.inapp

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import kotlinx.android.synthetic.main.activity_in_app.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class InAppActivity : AppCompatActivity(), InAppPurchaseHelper.OnPurchased, View.OnClickListener {

    private val TAG = "InAppActivity"
    var isYearly = true
    var isLifetime = true
    var skuYearly: ProductDetails? = null
    var skuMonthly: ProductDetails? = null
    var skuLifeTime: ProductDetails? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_in_app)

        initActions()
        initData()
    }

    fun getContext(): AppCompatActivity {
        return this@InAppActivity
    }

    fun initData() {

        InAppPurchaseHelper().initBillingClient(this@InAppActivity, this)

        tv_monthly.text = InAppPurchaseHelper().getProductPrice(SUB_MONTHLY)
        tv_yearly.text = InAppPurchaseHelper().getProductPrice(SUB_YEARLY)
        tv_lifetime.text = InAppPurchaseHelper().getProductPrice(PRODUCT_PURCHASED)

        skuMonthly = InAppPurchaseHelper().getProductDetails(SUB_MONTHLY)
        skuYearly = InAppPurchaseHelper().getProductDetails(SUB_YEARLY)
        skuLifeTime = InAppPurchaseHelper().getProductDetails(PRODUCT_PURCHASED)

    }

    fun initActions() {

        iv_close.setOnClickListener(this)
        rel_package_monthly.setOnClickListener(this)
        rel_package_yearly.setOnClickListener(this)
        rel_package_lifetime.setOnClickListener(this)
        buttonPurchase.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.iv_close -> onBackPressed()
            R.id.rel_package_monthly -> {
                isLifetime = false
                changePakage(false)
            }
            R.id.rel_package_yearly -> {
                isLifetime = false
                changePakage(true)
            }
            R.id.rel_package_lifetime -> {
                isLifetime = true

                rel_package_monthly.background = resources.getDrawable(R.drawable.rounded_border)
                rel_package_yearly.background = resources.getDrawable(R.drawable.rounded_border)
                rel_package_lifetime.background = resources.getDrawable(R.drawable.rounded_border_active)

                tv_monthly.background = resources.getDrawable(R.drawable.ic_button_disable)
                tv_yearly.background = resources.getDrawable(R.drawable.ic_button_disable)
                tv_lifetime.background = resources.getDrawable(R.drawable.ic_dialog_button)

            }
            R.id.buttonPurchase -> {
                if (isLifetime) {
                    GlobalScope.launch {
                        InAppPurchaseHelper().purchaseProduct(PRODUCT_PURCHASED, false)
                    }
                } else {
                    GlobalScope.launch {
                        if (isYearly) InAppPurchaseHelper().subscribeProduct(SUB_YEARLY, false)
                        else InAppPurchaseHelper().subscribeProduct(SUB_MONTHLY, false)
                    }
                }
            }
        }
    }


    private fun changePakage(yearly: Boolean) {
        if (yearly) {
            isYearly = yearly

            rel_package_lifetime.background = resources.getDrawable(R.drawable.rounded_border)
            rel_package_monthly.background = resources.getDrawable(R.drawable.rounded_border)
            rel_package_yearly.background = resources.getDrawable(R.drawable.rounded_border_active)

            tv_lifetime.background = resources.getDrawable(R.drawable.ic_button_disable)
            tv_monthly.background = resources.getDrawable(R.drawable.ic_button_disable)
            tv_yearly.background = resources.getDrawable(R.drawable.ic_dialog_button)
        } else {
            isYearly = yearly

            rel_package_lifetime.background = resources.getDrawable(R.drawable.rounded_border)
            rel_package_monthly.background = resources.getDrawable(R.drawable.rounded_border_active)
            rel_package_yearly.background = resources.getDrawable(R.drawable.rounded_border)

            tv_lifetime.background = resources.getDrawable(R.drawable.ic_button_disable)
            tv_monthly.background = resources.getDrawable(R.drawable.ic_dialog_button)
            tv_yearly.background = resources.getDrawable(R.drawable.ic_button_disable)
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onPurchasedSuccess(purchase: Purchase) {
        Log.e(TAG, "onPurchasedSuccess:InAppActivity:" + purchase.products[0])
        setResult(RESULT_OK)
        finish()
    }

    override fun onProductAlreadyOwn() {
        Log.e(TAG, "onProductAlreadyOwn:InAppActivity")
    }

    override fun onBillingSetupFinished(billingResult: BillingResult) {
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.responseCode)
        Log.e(TAG, "onBillingSetupFinished:InAppActivity:" + billingResult.debugMessage)
    }

    override fun onBillingUnavailable() {
        Log.e(TAG, "onBillingUnavailable:InAppActivity")
    }

    override fun onBillingKeyNotFound(productId: String) {
        Log.e(TAG, "onBillingUnavailable:InAppActivity:$productId")
    }

}