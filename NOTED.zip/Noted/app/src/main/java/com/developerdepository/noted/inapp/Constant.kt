package com.developerdepository.noted.inapp


// Products Id's
//const val SUB_MONTHLY = "com.purchase.monthly"
//const val SUB_YEARLY = "com.purchase.yearly"
const val PRODUCT_PURCHASED = "android.test.purchased"

const val SUB_MONTHLY = "com.backupandrecovery.purchase.monthly"
const val SUB_YEARLY = "com.backupandrecovery.purchase.yearly"
//const val PRODUCT_PURCHASED = "com.backupandrecovery.adremoved"

//const val NORMAL_SKU = "com.saumyayoga.quarterly"
//const val MONTH_SKU = "com.saumyayoga.monthly"
//const val YEAR_SKU = "com.saumyayoga.yearly"