package com.akshay.harsoda.permission.helper.request

import android.graphics.Typeface
import androidx.annotation.ColorInt
import androidx.annotation.NonNull
import java.io.Serializable

/**
 * @author Akshay Harsoda
 * @since 18 Mar 2021
 */
class SettingDialogRequest : Serializable {

    public var mTitle: String? = null
    public var mMessage: String? = null
    public var mPositiveText: String? = null
    public var mNegativeText: String? = null

    @ColorInt
    public var mTitleColor: Int? = null
    @ColorInt
    public var mMessageColor: Int? = null
    @ColorInt
    public var mPositiveColor: Int? = null
    @ColorInt
    public var mNegativeColor: Int? = null

    public var mTitleTypeface: Typeface? = null
    public var mMessageTypeface: Typeface? = null
    public var mPositiveTypeface: Typeface? = null
    public var mNegativeTypeface: Typeface? = null

    //<editor-fold desc="Set Dialog Text">
    @JvmName("setDialogTitle")
    @NonNull
    fun setDialogTitle(fTitle: String): SettingDialogRequest {
        this.mTitle = fTitle
        return this
    }

    @JvmName("setDialogMessage")
    @NonNull
    fun setDialogMessage(fMessage: String): SettingDialogRequest {
        this.mMessage = fMessage
        return this
    }

    @JvmName("setDialogPositiveText")
    @NonNull
    fun setDialogPositiveText(fPositiveText: String): SettingDialogRequest {
        this.mPositiveText = fPositiveText
        return this
    }

    @JvmName("setDialogNegativeText")
    @NonNull
    fun setDialogNegativeText(fNegativeText: String): SettingDialogRequest {
        this.mNegativeText = fNegativeText
        return this
    }
    //</editor-fold>

    //<editor-fold desc="Set Dialog Color">
    @JvmName("setDialogTitleColor")
    @NonNull
    fun setDialogTitleColor(@ColorInt fTitleColor: Int): SettingDialogRequest {
        this.mTitleColor = fTitleColor
        return this
    }

    @JvmName("setDialogMessageColor")
    @NonNull
    fun setDialogMessageColor(@ColorInt fMessageColor: Int): SettingDialogRequest {
        this.mMessageColor = fMessageColor
        return this
    }

    @JvmName("setDialogPositiveColor")
    @NonNull
    fun setDialogPositiveColor(@ColorInt fPositiveColor: Int): SettingDialogRequest {
        this.mPositiveColor = fPositiveColor
        return this
    }

    @JvmName("setDialogNegativeColor")
    @NonNull
    fun setDialogNegativeColor(@ColorInt fNegativeColor: Int): SettingDialogRequest {
        this.mNegativeColor = fNegativeColor
        return this
    }
    //</editor-fold>

    //<editor-fold desc="Set Dialog Typeface">
    @JvmName("setDialogTitleTypeface")
    @NonNull
    fun setDialogTitleTypeface(fTitleTypeface: Typeface): SettingDialogRequest {
        this.mTitleTypeface = fTitleTypeface
        return this
    }

    @JvmName("setDialogMessageTypeface")
    @NonNull
    fun setDialogMessageTypeface(fMessageTypeface: Typeface): SettingDialogRequest {
        this.mMessageTypeface = fMessageTypeface
        return this
    }

    @JvmName("setDialogPositiveTypeface")
    @NonNull
    fun setDialogPositiveTypeface(fPositiveTypeface: Typeface): SettingDialogRequest {
        this.mPositiveTypeface = fPositiveTypeface
        return this
    }

    @JvmName("setDialogNegativeTypeface")
    @NonNull
    fun setDialogNegativeTypeface(fNegativeTypeface: Typeface): SettingDialogRequest {
        this.mNegativeTypeface = fNegativeTypeface
        return this
    }
    //</editor-fold>

    //<editor-fold desc="Get Dialog Text">
    @JvmName("getDialogTitle")
    fun getDialogTitle(): String? {
        return this.mTitle
    }

    @JvmName("getDialogMessage")
    fun getDialogMessage(): String? {
        return this.mMessage
    }

    @JvmName("getDialogPositiveText")
    fun getDialogPositiveText(): String? {
        return this.mPositiveText
    }

    @JvmName("getDialogNegativeText")
    fun getDialogNegativeText(): String? {
        return this.mNegativeText
    }
    //</editor-fold>

    //<editor-fold desc="Get Dialog Color">
    @JvmName("getDialogTitleColor")
    @ColorInt
    fun getDialogTitleColor(): Int? {
        return this.mTitleColor
    }

    @JvmName("getDialogMessageColor")
    @ColorInt
    fun getDialogMessageColor(): Int? {
        return this.mMessageColor
    }

    @JvmName("getDialogPositiveColor")
    @ColorInt
    fun getDialogPositiveColor(): Int? {
        return this.mPositiveColor
    }

    @JvmName("getDialogNegativeColor")
    @ColorInt
    fun getDialogNegativeColor(): Int? {
        return this.mNegativeColor
    }
    //</editor-fold>

    //<editor-fold desc="Get Dialog Typeface">
    @JvmName("getDialogTitleTypeface")
    fun getDialogTitleTypeface(): Typeface? {
        return this.mTitleTypeface
    }

    @JvmName("getDialogMessageTypeface")
    fun getDialogMessageTypeface(): Typeface? {
        return this.mMessageTypeface
    }

    @JvmName("getDialogPositiveTypeface")
    fun getDialogPositiveTypeface(): Typeface? {
        return this.mPositiveTypeface
    }

    @JvmName("getDialogNegativeTypeface")
    fun getDialogNegativeTypeface(): Typeface? {
        return this.mNegativeTypeface
    }
    //</editor-fold>

}