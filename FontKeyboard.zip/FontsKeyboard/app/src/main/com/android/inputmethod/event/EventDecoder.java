package com.android.inputmethod.event;

/**
 * A generic interface for event decoders.
 */
public interface EventDecoder {

}
