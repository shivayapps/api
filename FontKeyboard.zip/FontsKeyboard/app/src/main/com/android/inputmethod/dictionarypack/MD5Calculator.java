

package com.android.inputmethod.dictionarypack;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;

public final class MD5Calculator {
    private MD5Calculator() {} // This helper class is not instantiable

    public static String checksum(final InputStream in) throws IOException {
        // This code from the Android documentation for MessageDigest. Nearly verbatim.
        MessageDigest digester;
        try {
            digester = MessageDigest.getInstance("MD5");
        } catch (java.security.NoSuchAlgorithmException e) {
            return null; // Platform does not support MD5 : can't check, so return null
        }
        final byte[] bytes = new byte[8192];
        int byteCount;
        while ((byteCount = in.read(bytes)) > 0) {
            digester.update(bytes, 0, byteCount);
        }
        final byte[] digest = digester.digest();
        final StringBuilder s = new StringBuilder();
        for (int i = 0; i < digest.length; ++i) {
            s.append(String.format("%1$02x", digest[i]));
        }
        return s.toString();
    }
}
