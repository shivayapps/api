

package com.android.inputmethod.dictionarypack;

/**
 * A simple interface to report problems.
 */
public interface ProblemReporter {
    public void report(Exception e);
}
