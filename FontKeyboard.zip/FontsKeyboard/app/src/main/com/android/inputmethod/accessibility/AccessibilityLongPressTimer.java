package com.android.inputmethod.accessibility;

import android.content.Context;
import android.os.Handler;
import android.os.Message;

import com.fancy.fonts.style.keyboard.emojis.screen.number.R;
import com.android.inputmethod.keyboard.Key;

final class AccessibilityLongPressTimer extends Handler {

    public interface LongPressTimerCallback {

        void performLongClickOn(Key key);

    }

    private static final int MSG_LONG_PRESS = 1;

    private final LongPressTimerCallback mCallback;
    private final long mConfigAccessibilityLongPressTimeout;

    public AccessibilityLongPressTimer(final LongPressTimerCallback callback,
                                       final Context context) {
        super();
        mCallback = callback;
        mConfigAccessibilityLongPressTimeout = context.getResources().getInteger(
                R.integer.config_accessibility_long_press_key_timeout);
    }

    @Override
    public void handleMessage(final Message msg) {
        if (msg.what == MSG_LONG_PRESS) {
            cancelLongPress();
            mCallback.performLongClickOn((Key) msg.obj);
            return;
        }
        super.handleMessage(msg);
    }

    public void startLongPress(final Key key) {
        cancelLongPress();
        final Message longPressMessage = obtainMessage(MSG_LONG_PRESS, key);
        sendMessageDelayed(longPressMessage, mConfigAccessibilityLongPressTimeout);
    }

    public void cancelLongPress() {
        removeMessages(MSG_LONG_PRESS);
    }
}
