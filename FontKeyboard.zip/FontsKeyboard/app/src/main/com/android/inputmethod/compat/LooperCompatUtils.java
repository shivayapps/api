package com.android.inputmethod.compat;

import android.os.Looper;

import java.lang.reflect.Method;


public final class LooperCompatUtils {
    private static final Method METHOD_quitSafely = CompatUtils.getMethod(
            Looper.class, "quitSafely");

    public static void quitSafely(final Looper looper) {
        if (null != METHOD_quitSafely) {
            CompatUtils.invoke(looper, null , METHOD_quitSafely);
        } else {
            looper.quit();
        }
    }
}
