package com.android.inputmethod.compat;

import android.os.Build;

public final class BuildCompatUtils {

    private BuildCompatUtils() {
    }

    private static final boolean IS_RELEASE_BUILD = Build.VERSION.CODENAME.equals("REL");


    public static final int EFFECTIVE_SDK_INT = IS_RELEASE_BUILD ? Build.VERSION.SDK_INT : Build.VERSION.SDK_INT + 1;


}
