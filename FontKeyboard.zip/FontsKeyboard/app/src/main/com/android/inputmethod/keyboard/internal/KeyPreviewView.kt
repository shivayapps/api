package com.android.inputmethod.keyboard.internal

import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.widget.TextView
import androidx.core.graphics.BlendModeColorFilterCompat
import androidx.core.graphics.BlendModeCompat
import androidx.core.graphics.ColorUtils
import com.android.inputmethod.keyboard.Key
import com.android.inputmethod.keyboard.Keyboard
import com.fancy.fonts.style.keyboard.emojis.screen.number.R
import com.fancy.fonts.style.keyboard.emojis.screen.number.ThemeDataclass.getthemetext
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.SharedPrefs
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.SharedPrefs.getChar1a
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.SharedPreftheme



import java.util.ArrayList
import java.util.HashSet
import kotlin.jvm.JvmOverloads

class KeyPreviewView @JvmOverloads constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int = 0) : TextView(context, attrs, defStyleAttr) {
    private val mBackgroundPadding = Rect()
    var mKeyboard: Keyboard? = null
    var mcontext: Context
    private val TAG = "KeyPreviewView"
    fun setPreviewVisual(key: Key, iconsSet: KeyboardIconsSet?, drawParams: KeyDrawParams?, keyboard: Keyboard) {
        mKeyboard = keyboard
        val iconId = key.iconId
        if (iconId != KeyboardIconsSet.ICON_UNDEFINED) {
            setCompoundDrawables(null, null, null, key.getPreviewIcon(iconsSet))
            text = null
            return
        }

        setCompoundDrawables(null, null, null, null)
//        setTextColor(context.resources.getColor(R.color.black))
        if (SharedPrefs.getBoolean(mcontext, "iscustomtheme", false) && SharedPreftheme.getthemevalue(mcontext, 1) == 1111) {
            //  setBackgroundColor();
            setTextColor(SharedPrefs.getInt(mcontext, "KeyPopuptextcolor", Color.parseColor(SharedPrefs.getcolr(R.color.defaultfunctional, mcontext))));
            background.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(SharedPrefs.getInt(mcontext, "keypopupColor", Color.parseColor(SharedPrefs.getcolr(R.color.trans1k, mcontext))), BlendModeCompat.SRC_ATOP)
        } else {
            // background.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(Color.parseColor(SharedPrefs.getcolr(R.color.trans1k, mcontext)), BlendModeCompat.SRC_ATOP)

            getthemetext(SharedPreftheme.getthemevalue(context, 1), context).let {
                setTextColor(ColorUtils.setAlphaComponent(it.int, it.int1))
                background.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(ColorUtils.setAlphaComponent(it.int2, it.int3), BlendModeCompat.SRC_ATOP)
            }

        }


        if (SharedPreftheme.getthemevalue(mcontext, 1) == 2222) {
            for (i in 0 until mKeyboard!!.sortedKeys.size) {
                if (mKeyboard!!.sortedKeys[i].code == key.code) {
                    background.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(Color.parseColor(arraylistdata()[i]), BlendModeCompat.SRC_ATOP)
                    setTextColor(context.resources.getColor(R.color.black))
                }
            }
        }
        setTextSize(TypedValue.COMPLEX_UNIT_PX, (key.selectPreviewTextSize(drawParams) - 17).toFloat())
        typeface = key.selectPreviewTypeface(drawParams)

        setTextAndScaleX(key.previewLabel, key)
    }

    fun arraylistdata(): ArrayList<String> {

        var arrayList = ArrayList<String>()
        arrayList.clear()
        arrayList.add("#00cc00")
        arrayList.add("#00e6e6")
        arrayList.add("#006600")
        arrayList.add("#4d79ff")
        arrayList.add("#7300e6")
        arrayList.add("#d633ff")
        arrayList.add("#cc0099")
        arrayList.add("#e62e00")
        arrayList.add("#e65c00")
        arrayList.add("#ffcc33")
        arrayList.add("#00e6e6")
        arrayList.add("#006600")
        arrayList.add("#4d79ff")
        arrayList.add("#7300e6")
        arrayList.add("#d633ff")
        arrayList.add("#cc0099")
        arrayList.add("#e62e00")
        arrayList.add("#e65c00")
        arrayList.add("#ffcc33")
        arrayList.add("#00e6e6")
        arrayList.add("#006600")
        arrayList.add("#4d79ff")
        arrayList.add("#7300e6")
        arrayList.add("#d633ff")
        arrayList.add("#cc0099")
        arrayList.add("#e62e00")
        arrayList.add("#e65c00")
        arrayList.add("#ffcc33")
        arrayList.add("#006600")
        arrayList.add("#4d79ff")
        arrayList.add("#7300e6")
        arrayList.add("#d633ff")
        arrayList.add("#cc0099")
        arrayList.add("#e62e00")
        arrayList.add("#e65c00")
        arrayList.add("#ffcc33")
        return arrayList
    }

    private fun setTextAndScaleX(text: String, key: Key) {
        var text1 = text
        // text = getChar(text, context)
        text1 = if (SharedPrefs.getBoolean(context, "iscustomtheme", false) && SharedPrefs.getInt(context, "keyboardSet", 0) == 0 && SharedPreftheme.getthemevalue(context, 1) == 1111) {
            getChar1a(text1, SharedPrefs.getInt(context, "selectedfontstyle", 0), context)!!
        } else {
            SharedPrefs.getChar(text1, context)!!
        }





        textScaleX = 1.0f
        setText(text1)
        if (sNoScaleXTextSet.contains(text1)) {
            return
        }
        // TODO: Override {@link #setBackground(Drawable)} that is supported from API 16 and
        // calculate maximum text width.
        val background = background ?: return
        background.getPadding(mBackgroundPadding)
        //  background.setColorFilter(context.resources.getColor(R.color.trans1k), PorterDuff.Mode.OVERLAY)


        if (SharedPrefs.getBoolean(mcontext, "iscustomtheme", false) && SharedPreftheme.getthemevalue(mcontext, 1) == 1111) {
//            Log.e(TAG, "setTextAndScaleX: 1101")
            //  setBackgroundColor();
            // setTextColor(SharedPrefs.getInt(mcontext, "KeyPopuptextcolor", Color.parseColor(SharedPrefs.getcolr(R.color.defaultfunctional, mcontext))));
            //SharedPrefs.getInt(mcontext, "keypopupColor", Color.parseColor(SharedPrefs.getcolr(R.color.defaultfunctional, mcontext)))
            background.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(SharedPrefs.getInt(mcontext, "keypopupColor", Color.parseColor(SharedPrefs.getcolr(R.color.trans1k, mcontext))), BlendModeCompat.SRC_ATOP)
        } else {

            getthemetext(SharedPreftheme.getthemevalue(context, 1), context).let {
                setTextColor(ColorUtils.setAlphaComponent(it.int, it.int1))
                background.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(ColorUtils.setAlphaComponent(it.int2, it.int3), BlendModeCompat.SRC_ATOP)
            }


        }

        if (SharedPreftheme.getthemevalue(mcontext, 1) == 2222) {
            for (i in 0 until mKeyboard!!.sortedKeys.size) {
                if (mKeyboard!!.sortedKeys[i].code == key.code) {
                    background.colorFilter = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(Color.parseColor(arraylistdata()[i]), BlendModeCompat.SRC_ATOP)
                    setTextColor(context.resources.getColor(R.color.black))
                }
            }
        }
        val maxWidth = (background.intrinsicWidth - mBackgroundPadding.left
                - mBackgroundPadding.right)
        val width = getTextWidth(text1, paint)
        if (width <= maxWidth) {
            sNoScaleXTextSet.add(text1)
            return
        }
        textScaleX = maxWidth / width
    }

    companion object {
        private val sNoScaleXTextSet = HashSet<String?>()

        @JvmStatic
        fun clearTextCache() {
            sNoScaleXTextSet.clear()
        }

        private fun getTextWidth(text: String?, paint: TextPaint): Float {
            if (TextUtils.isEmpty(text)) {
                return 0.0f
            }
            val len = text!!.length
            val widths = FloatArray(len)
            val count = paint.getTextWidths(text, 0, len, widths)
            var width = 0f
            for (i in 0 until count) {
                width += widths[i]
            }
            return width
        }
        /*public void setPreviewBackground(boolean customColorEnabled, int customColor) {
            final Drawable background = getBackground();
            if (customColorEnabled)
                background.setColorFilter(customColor, PorterDuff.Mode.OVERLAY);
        }*/
    }

    init {
        gravity = Gravity.CENTER
        mcontext = context
    }
}