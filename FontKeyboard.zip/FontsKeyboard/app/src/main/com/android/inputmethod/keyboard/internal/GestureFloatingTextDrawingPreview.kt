package com.android.inputmethod.keyboard.internal

import android.content.Context
import android.content.SharedPreferences
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.TextUtils
import com.android.inputmethod.keyboard.PointerTracker
import com.android.inputmethod.latin.SuggestedWords
import com.android.inputmethod.latin.common.CoordinateUtils
import com.fancy.fonts.style.keyboard.emojis.screen.number.R
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.SharedPrefs
import javax.annotation.Nonnull


open class GestureFloatingTextDrawingPreview(
    mainKeyboardViewAttr: TypedArray,
    var context: Context
) :
    AbstractDrawingPreview() {
    private lateinit var shareSound: SharedPreferences


    protected class GesturePreviewTextParams(mainKeyboardViewAttr: TypedArray) {
        val mGesturePreviewTextOffset: Int
        val mGesturePreviewTextHeight: Int
        val mGesturePreviewHorizontalPadding: Float
        val mGesturePreviewVerticalPadding: Float
        val mGesturePreviewRoundRadius: Float

        val mDisplayWidth: Int
        private val mGesturePreviewTextSize: Int
        private val mGesturePreviewTextColor: Int
        private val mGesturePreviewColor: Int
        private val mPaint = Paint()
        val textPaint: Paint
            get() {
                mPaint.isAntiAlias = true
                mPaint.textAlign = Paint.Align.CENTER
                mPaint.textSize = mGesturePreviewTextSize.toFloat()
                mPaint.color = mGesturePreviewTextColor
                return mPaint
            }
        val backgroundPaint: Paint
            get() {
                mPaint.color = mGesturePreviewColor
                return mPaint
            }

        companion object {
            private val TEXT_HEIGHT_REFERENCE_CHAR = charArrayOf('M')
        }

        init {

            mGesturePreviewTextSize = mainKeyboardViewAttr.getDimensionPixelSize(
                R.styleable.MainKeyboardView_gestureFloatingPreviewTextSize, 0
            )
            mGesturePreviewTextColor = mainKeyboardViewAttr.getColor(
                R.styleable.MainKeyboardView_gestureFloatingPreviewTextColor, 0
            )
            mGesturePreviewTextOffset = mainKeyboardViewAttr.getDimensionPixelOffset(
                R.styleable.MainKeyboardView_gestureFloatingPreviewTextOffset, 0
            )
            mGesturePreviewColor = mainKeyboardViewAttr.getColor(
                R.styleable.MainKeyboardView_gestureFloatingPreviewColor, 0
            )
            mGesturePreviewHorizontalPadding = mainKeyboardViewAttr.getDimension(
                R.styleable.MainKeyboardView_gestureFloatingPreviewHorizontalPadding, 0.0f
            )
            mGesturePreviewVerticalPadding = mainKeyboardViewAttr.getDimension(
                R.styleable.MainKeyboardView_gestureFloatingPreviewVerticalPadding, 0.0f
            )
            mGesturePreviewRoundRadius = mainKeyboardViewAttr.getDimension(
                R.styleable.MainKeyboardView_gestureFloatingPreviewRoundRadius, 0.0f
            )
            mDisplayWidth = mainKeyboardViewAttr.resources.displayMetrics.widthPixels
            val textPaint = textPaint
            val textRect = Rect()
            textPaint.getTextBounds(TEXT_HEIGHT_REFERENCE_CHAR, 0, 1, textRect)
            mGesturePreviewTextHeight = textRect.height()
        }
    }

    private val mParams: GesturePreviewTextParams
    private val mGesturePreviewRectangle = RectF()
    private var mPreviewTextX = 0
    private var mPreviewTextY = 0
    private var mSuggestedWords = SuggestedWords.getEmptyInstance()
    private val mLastPointerCoords = CoordinateUtils.newInstance()
    override fun onDeallocateMemory() {
        // Nothing to do here.
    }

    fun dismissGestureFloatingPreviewText() {
        setSuggetedWords(SuggestedWords.getEmptyInstance())
    }

    fun setSuggetedWords(@Nonnull suggestedWords: SuggestedWords) {
        if (!isPreviewEnabled) {
            return
        }
        mSuggestedWords = suggestedWords
        updatePreviewPosition()
    }

    override fun setPreviewPosition(tracker: PointerTracker) {
        if (!isPreviewEnabled) {
            return
        }
        tracker.getLastCoordinates(mLastPointerCoords)
        updatePreviewPosition()
    }

    /**
     * Draws gesture preview text
     * @param canvas The canvas where preview text is drawn.
     */
    override fun drawPreview(canvas: Canvas) {
        if (!isPreviewEnabled || mSuggestedWords.isEmpty
            || TextUtils.isEmpty(mSuggestedWords.getWord(0))
        ) {
            return
        }
        val round = mParams.mGesturePreviewRoundRadius
        canvas.drawRoundRect(
            mGesturePreviewRectangle, round, round, mParams.backgroundPaint
        )
        var text = mSuggestedWords.getWord(0)

        shareSound = context.getSharedPreferences("soundPref", Context.MODE_PRIVATE)
        if (!shareSound.getBoolean("suggationswt", true)) {
            text = ""

        }

        var string = ""
        val charArray: CharArray = text.toCharArray()
        for (element in charArray)
            string += SharedPrefs.getChar(element.toString(), context)


        canvas.drawText(string, mPreviewTextX.toFloat(), mPreviewTextY.toFloat(), mParams.textPaint)
    }

    /**
     * Updates gesture preview text position based on mLastPointerCoords.
     */
    protected fun updatePreviewPosition() {
        shareSound = context.getSharedPreferences("soundPref", Context.MODE_PRIVATE)



        if (mSuggestedWords.isEmpty || TextUtils.isEmpty(mSuggestedWords.getWord(0)) || !shareSound.getBoolean(
                "suggationswt",
                true
            )
        ) {
            invalidateDrawingView()
            return
        }

        var text = mSuggestedWords.getWord(0)

        if (!shareSound.getBoolean("suggationswt", true)) {
            text = ""
        }

        var string = ""
        val charArray: CharArray = text.toCharArray()
        for (element in charArray)
            string += SharedPrefs.getChar(element.toString(), context)


        val rectangle = mGesturePreviewRectangle
        val textHeight = mParams.mGesturePreviewTextHeight
        val textWidth = mParams.textPaint.measureText(string)


        val hPad = mParams.mGesturePreviewHorizontalPadding
        val vPad = mParams.mGesturePreviewVerticalPadding
        val rectWidth = textWidth + hPad * 2.0f
        val rectHeight = textHeight + vPad * 2.0f
        val rectX = Math.min(
            Math.max(CoordinateUtils.x(mLastPointerCoords) - rectWidth / 2.0f, 0.0f),
            mParams.mDisplayWidth - rectWidth
        )
        val rectY = (CoordinateUtils.y(mLastPointerCoords)
                - mParams.mGesturePreviewTextOffset - rectHeight)
        rectangle[rectX, rectY, rectX + rectWidth] = rectY + rectHeight
        mPreviewTextX = (rectX + hPad + textWidth / 2.0f).toInt()
        mPreviewTextY = (rectY + vPad).toInt() + textHeight
        // TODO: Should narrow the invalidate region.
        invalidateDrawingView()
    }

    init {
        mParams = GesturePreviewTextParams(mainKeyboardViewAttr)
    }
}