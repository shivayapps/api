package com.android.inputmethod.event

import android.content.Context
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.util.Log
import com.android.inputmethod.latin.common.Constants
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.Share
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.Share.isrestneed
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.SharedPrefs
import com.fancy.fonts.style.keyboard.emojis.screen.number.comman.SharedPreftheme
import java.util.*
import javax.annotation.Nonnull


class CombinerChain(initialText: String?) {

    val mCombinedText: StringBuilder

    // The feedback on the composing state, as described above
    private val mStateFeedback: SpannableStringBuilder
    private val mCombiners: ArrayList<Combiner> = ArrayList()
    fun reset() {
        if (isrestneed) {
           // isrestneed = false
        } else {
            mCombinedText.setLength(0)
            mStateFeedback.clear()
            for (c in mCombiners) {
                c.reset()
            }
        }
    }

    private fun updateStateFeedback() {
        mStateFeedback.clear()
        for (i in mCombiners.indices.reversed()) {
            mStateFeedback.append(mCombiners[i].combiningStateFeedback)
        }
    }

    /**
     * Process an event through the combining chain, and return a processed event to apply.
     * @param previousEvents the list of previous events in this composition
     * @param newEvent the new event to process
     * @return the processed event. It may be the same event, or a consumed event, or a completely
     * new event. However it may never be null.
     */
    @Nonnull
    fun processEvent(
        previousEvents: ArrayList<Event>?,
        @Nonnull newEvent: Event
    ): Event {
        val modifiablePreviousEvents = ArrayList(previousEvents)
        var event = newEvent
        for (combiner in mCombiners) {
            // A combiner can never return more than one event; it can return several
            // code points, but they should be encapsulated within one event.
            event = combiner.processEvent(modifiablePreviousEvents, event)
            if (event.isConsumed) {
                // If the event is consumed, then we don't pass it to subsequent combiners:
                // they should not see it at all.
                break
            }
        }
        updateStateFeedback()
        return event
    }

    /**
     * Apply a processed event.
     * @param event the event to be applied
     */
    fun applyProcessedEvent(event: Event, context: Context, b: Boolean) {
        // Log.e("TAG", "applyProcessedEvent: 3 $event")

        if (Constants.CODE_DELETE == event.mKeyCode) {

            val length = mCombinedText.length
            if (length > 0) {
                val lastCodePoint = mCombinedText.codePointBefore(length)
                mCombinedText.delete(length - Character.charCount(lastCodePoint), length)
            }

        } else {

            var string = event.textToCommit.toString()

            // Log.e("TAG", "applyProcessedEvent: 1 $string")

            if (b) {
                if (SharedPrefs.getBoolean(
                        context,
                        "iscustomtheme",
                        false
                    ) && SharedPrefs.getInt(
                        context,
                        "keyboardSet",
                        0
                    ) == 0 && SharedPreftheme.getthemevalue(context, 1) == 1111
                ) {
                    string = SharedPrefs.getChar1a1(
                        string,
                        SharedPrefs.getInt(context, "selectedfontstyle", 0)
                    )!!
//
                } else {
//
                    string = SharedPrefs.getChar1(
                        string,
                        context
                    )!!

                }
            }


            Log.e("TAG", "applyProcessedEvent:123 --- $string")


            if (!TextUtils.isEmpty(string)) {
                mCombinedText.append(string)
            }

            //  Log.e("TAG", "applyProcessedEvent: 2 $mCombinedText")

        }
        updateStateFeedback()
    }


    fun getComposingWordWithCombiningFeedback(): CharSequence {

        val s = SpannableStringBuilder(mCombinedText)

//        if (SharedPrefs.getBoolean(baseContext!!, "iscustomtheme", false) && SharedPrefs.getInt(baseContext!!, "keyboardSet", 0) == 0 && SharedPreftheme.getthemevalue(baseContext!!, 1) == 1111) {
//            string = SharedPrefs.getChar1a1(
//                string,
//                SharedPrefs.getInt(baseContext!!, "selectedfontstyle", 0)
//            )!!
////            Log.e(TAG, "sendKeyCodePoint: 1" + SharedPrefs.getInt(baseContext!!, "selectedfontstyle", 0))
//        } else {
////            Log.e(TAG, "sendKeyCodePoint: 2")
//            string = SharedPrefs.getChar1(
//                StringUtils.newSingleCodePointString(codePoint),
//                baseContext!!
//            )!!
//
//        }

        // Log.e("asd", "getComposingWordWithCombiningFeedback: 1 $s")
        // Log.e("asd", "getComposingWordWithCombiningFeedback: 2 $mStateFeedback")
        // Log.e("asd", "getComposingWordWithCombiningFeedback: 3 $mCombinedText")

        return s.append(mStateFeedback)
    }


    init {

        mCombiners.add(DeadKeyCombiner())
        mCombinedText = StringBuilder(initialText!!)
        mStateFeedback = SpannableStringBuilder()
    }
}