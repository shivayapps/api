

package com.android.inputmethod.compat;

import java.lang.reflect.Field;

public final class SettingsSecureCompatUtils {
    private static final Field FIELD_ACCESSIBILITY_SPEAK_PASSWORD = CompatUtils.getField(
            android.provider.Settings.Secure.class, "ACCESSIBILITY_SPEAK_PASSWORD");

    private SettingsSecureCompatUtils() {
        // This class is non-instantiable.
    }

    /**
     * Whether to speak passwords while in accessibility mode.
     */
    public static final String ACCESSIBILITY_SPEAK_PASSWORD = (String) CompatUtils.getFieldValue(
            null , null , FIELD_ACCESSIBILITY_SPEAK_PASSWORD);
}
