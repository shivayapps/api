#include <jni.h>
#include <string>

std::string xyz(std::string basicString);



extern "C" JNIEXPORT jstring JNICALL
Java_com_fancy_fonts_style_keyboard_emojis_screen_number_Adactvity_SplashscreenActivity_getSign(JNIEnv *env, jobject /* this */) {
    std::string hello = "frerterteetrtds";
    std::string decoded = xyz(hello);
    return env->NewStringUTF(decoded.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_free_home_workout_exercise_loseweight_no_equipment_retrofit_ApiClient_getBaseURL(JNIEnv *env, jobject /* this */) {
    std::string hello = "aHR0cDovL3Rlc3QudmFzdW5kaGFyYWFwcHMuY29tL2hvbWUtd29ya291dC9hcGkv";
    std::string decoded = xyz(hello);
    return env->NewStringUTF(decoded.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_free_home_workout_exercise_loseweight_no_equipment_Adactvity_SplashscreenActivity_getHeader(JNIEnv *env, jobject /* this */) {
    //std::string hello = "VCsyTm1QWkpvaWh3cnA1OUQ0MndyVWhEUVNJPQ=="; // debuge key
    std::string hello = "K3JNSmFTRjk2Nk5BejhTSVBOYU40cDV1TzhNPQ=="; // release key
    std::string decoded = xyz(hello);
    return env->NewStringUTF(decoded.c_str());
}


extern "C" JNIEXPORT jstring JNICALL
Java_com_example_secureapi_MainJavaActivity_getHeader(JNIEnv *env, jobject /* this */) {
    std::string hello = "VTA5TlNWTklTMEZMUVVSSldVRT0=";
    std::string decoded = xyz(hello);
    return env->NewStringUTF(decoded.c_str());
}




static const std::string xyz_chars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789+/";


static inline bool isXyz(unsigned char c) {
    return (isalnum(c) || (c == '+') || (c == '/'));
}



std::string xyz(std::string basicString) {
    int in_len = basicString.size();
    int i = 0;
    int j = 0;
    int in_ = 0;
    unsigned char char_array_4[4], char_array_3[3];
    std::string ret;

    while (in_len-- && (basicString[in_] != '=') && isXyz(basicString[in_])) {
        char_array_4[i++] = basicString[in_];
        in_++;
        if (i == 4) {
            for (i = 0; i < 4; i++)
                char_array_4[i] = xyz_chars.find(char_array_4[i]);

            char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
            char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
            char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

            for (i = 0; (i < 3); i++)
                ret += char_array_3[i];
            i = 0;
        }
    }

    if (i) {
        for (j = i; j < 4; j++)
            char_array_4[j] = 0;

        for (j = 0; j < 4; j++)
            char_array_4[j] = xyz_chars.find(char_array_4[j]);

        char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
        char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
        char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

        for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
    }

    return ret;
}

