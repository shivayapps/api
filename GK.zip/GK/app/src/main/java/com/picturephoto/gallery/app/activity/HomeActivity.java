package com.picturephoto.gallery.app.activity;

import static com.android.billingclient.api.BillingClient.SkuType.SUBS;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryPurchasesParams;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.appbar.AppBarLayout;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.picturephoto.gallery.app.BuildConfig;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdEvenNativetListener;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.custom.ClickListener;
import com.picturephoto.gallery.app.databinding.ActivityHomeBinding;
import com.picturephoto.gallery.app.databinding.DialogPurchaseBinding;
import com.picturephoto.gallery.app.dialog.ChooseFolderDialog;
import com.picturephoto.gallery.app.event.CopyMoveEvent;
import com.picturephoto.gallery.app.event.CountShowEvent;
import com.picturephoto.gallery.app.event.ImageCloseEvent;
import com.picturephoto.gallery.app.event.ImageShareDeleteEvent;
import com.picturephoto.gallery.app.fragment.AlbumFragment;
import com.picturephoto.gallery.app.fragment.PhotoFragment;
import com.picturephoto.gallery.app.interfaces.LongClickListener;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.FilterSettingUpdate;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.ImageColor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


public class HomeActivity extends AppCompatActivity implements LongClickListener {

    ActivityHomeBinding binding;

    HomePagerAdapter homePagerAdapter;

    PhotoFragment photoFragment;

    AlbumFragment albumFragment;

    boolean isSelectAll = false;

    PreferencesManager preferencesManager;

    String imageFilePath;

    ActivityResultLauncher<Intent> captureImageActivityResultLauncher;

    ActivityResultLauncher<Intent> settingImageActivityResultLauncher;

    int tabPos = 0;

    int appBarType = 0;

    boolean isOpenToSplash = false;

    private static final List<String> SKUS = Arrays.asList("android.test.purchased");

    List<SkuDetails> skuDetailsList = new ArrayList<>();

    private BillingClient billingClient;

    String PRODUCT_ID = "";
    private AdmobAdManager admobAdManager;
    private Dialog exitDialogs;
    Boolean isNativeLoad = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        preferencesManager = PreferencesManager.getInstance(this);
        changeLanguage();
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
        showCount();
        if (getIntent() != null && getIntent().hasExtra("isCallDorado")) {
            int type = getIntent().getIntExtra("type", 0);
            switch (type) {
                case 1:
                    startActivity(new Intent(this, WpStatusActivity.class));
                    break;
                case 2:
                    startActivity(new Intent(this, FavoriteListActivity.class));
                    break;
                case 3:
                    startActivity(new Intent(this, MediaColorActivity.class));
                    break;
                case 4:
                    startActivity(new Intent(this, RecentActivity.class));
                    break;
                case 5:
                    startActivity(
                            new Intent(this, PasswordActivity.class).putExtra(
                                    "isOpenPrivate", true));
                    break;
            }
        }
        exitDialog();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.contentData.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.contentData.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.contentData.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.contentData.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void exitDialog() {
        exitDialogs = new Dialog(this, R.style.WideDialogSecondExit);
        exitDialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
        exitDialogs.setContentView(R.layout.bottom_navigation_exit);
        exitDialogs.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Window window = exitDialogs.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        window.setAttributes(wlp);
        loadNativeAdExit();
        exitDialogs.setOnDismissListener(dialogInterface -> {
            exitDialog();
        });
        exitDialogs.setOnCancelListener(dialogInterface -> {
            exitDialog();
        });
    }

    private void loadNativeAdExit() {
        AdmobAdManager.getInstance(this).loadNativeAdExit(
                this, new AdEvenNativetListener() {
                    @Override
                    public void onAdLoaded(boolean isLoadNative) {
                        isNativeLoad = isLoadNative;
                    }

                    @Override
                    public void onAdClosed() {

                    }

                    @Override
                    public void onLoadError(String errorCode) {

                    }

                    @Override
                    public void onAdLoaded(Object object) {

                    }
                });
    }


    private void hidePurchase() {
        binding.drawerContent.btnDrawerPurchase.setVisibility(View.GONE);
    }

    private void showPurchase() {
        binding.drawerContent.btnDrawerPurchase.setVisibility(View.VISIBLE);
    }

    private void intView() {
        if (getIntent() != null) {
            isOpenToSplash = getIntent().getBooleanExtra("isOpenToSplash", false);
        }
        photoFragment = new PhotoFragment(HomeActivity.this);
        albumFragment = AlbumFragment.newInstance(this);
        photoFragment.setLongClickListener(this);
        homePagerAdapter =
                new HomePagerAdapter(getSupportFragmentManager(), 2, photoFragment, albumFragment);
        binding.contentData.viewpager.setAdapter(homePagerAdapter);
        unSelect();
        tabPos = preferencesManager.getStartPage();
        binding.contentData.viewpager.setCurrentItem(preferencesManager.getStartPage());
        if (preferencesManager.getStartPage() == 0)
            setTabBottomSelect(binding.contentData.ivBottomTab1,
                    binding.contentData.txtBottomTab1);
        else if (preferencesManager.getStartPage() == 1)
            setTabBottomSelect(binding.contentData.ivBottomTab2,
                    binding.contentData.txtBottomTab2);
        purchaseInti();
        setClickListener();
        setDrawerClickListener();
        binding.contentData.ivSearch.setVisibility(View.VISIBLE);
        binding.contentData.ivDrawer.setVisibility(View.VISIBLE);
        binding.contentData.ivSearchClose.setVisibility(View.GONE);
        binding.contentData.loutSearch.setVisibility(View.GONE);
        binding.drawerContent.txtVersion.setText(
                getResources().getString(R.string.version2) + " " + BuildConfig.VERSION_NAME);
        binding.drawerContent.layPhotos.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                filterBy = 1;
                preferencesManager.setFilterTypePhoto(filterBy);
                RxBus.getInstance().post(new FilterSettingUpdate(true));
                binding.contentData.viewpager.setCurrentItem(0);
                binding.drawerLay.closeDrawer(GravityCompat.START);
                setTabTitle();
            });

        });
        binding.drawerContent.layVideos.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                filterBy = 2;
                preferencesManager.setFilterTypePhoto(filterBy);
                RxBus.getInstance().post(new FilterSettingUpdate(true));
                binding.contentData.viewpager.setCurrentItem(0);
                binding.drawerLay.closeDrawer(GravityCompat.START);
                setTabTitle();
            });
        });
        binding.drawerContent.layAlbums.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                binding.contentData.viewpager.setCurrentItem(1);
                binding.drawerLay.closeDrawer(GravityCompat.START);
            });
        });
        setActivityResultLauncher();
        new Thread(() -> {
            new ImageColor().getImages(HomeActivity.this);
            runOnUiThread(() -> Log.e("", "Image is getting"));
        }).start();
        setPurchased();
        if (isOpenToSplash) {
            Random random = new Random();
            int num = random.nextInt(6);
            if (num == 1)
                showRate();
        }
        setTabTitle();
        int statusHeight = getStatusBarHeight(this);
        binding.contentData.loutSelect.setPadding(0, statusHeight, 0, 0);
        binding.contentData.loutSelect.requestLayout();
        binding.contentData.appBar.addOnOffsetChangedListener(
                new AppBarLayout.OnOffsetChangedListener() {
                    @Override
                    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                        if (verticalOffset == 0) {
                            //Expanded
                            if (appBarType != 0) {
                                appBarType = 0;
                                setStatusBar();
                            }
                        } else if (Math.abs(verticalOffset) >= appBarLayout.getTotalScrollRange()) {
                            //  Collapsed
                            if (appBarType != 1) {
                                appBarType = 1;
                                setStatusBar();
                            }
                        } else {
                            if (appBarType != 1) {
                                appBarType = 1;
                                setStatusBar();
                            }
                            //                    if (verticalOffset < 180) {
                            //                        if (appBarType != 1) {
                            //                            appBarType = 1;
                            //                            setStatusBar();
                            //                        }
                            //                    } else {
                            //                        if (appBarType != 0) {
                            //                            appBarType = 0;
                            //                            setStatusBar();
                            //                        }
                            //                    }
                        }
                        //                Log.e("AppBarLayout", " verticalOffset===>>> " +
                        //                verticalOffset + " 1Height==>>  " + (Math.abs
                        //                (verticalOffset) - appBarLayout.getTotalScrollRange())
                        //                        + " 2Height==>>  " + (Math.abs(verticalOffset) -
                        //                        appBarLayout.getTotalScrollRange() / 2));
                        //                if (Math.abs(verticalOffset) - appBarLayout
                        //                .getTotalScrollRange() == 0) {
                        //                    //  Collapsed
                        //                    Log.e("AppBarLayout", "Collapsed");
                        //                    if (appBarType != 1) {
                        //                        appBarType = 1;
                        //                        setStatusBar();
                        //                    }
                        //
                        //                } else if (Math.abs(verticalOffset) - appBarLayout
                        //                .getTotalScrollRange() / 2 == 0) {
                        //                    if (appBarType != 1) {
                        //                        appBarType = 1;
                        //                        setStatusBar();
                        //                    }
                        //                } else {
                        //                    //Expanded
                        //                    if (appBarType != 0) {
                        //                        appBarType = 0;
                        //                        setStatusBar();
                        //                    }
                        //                    Log.e("AppBarLayout", "Expanded");
                        //
                        //
                        //                }
                    }
                });
    }

    private void setPurchased() {
        if (preferencesManager.getSubscription(this))
            binding.drawerContent.btnDrawerPurchase.setVisibility(View.GONE);
        else
            binding.drawerContent.btnDrawerPurchase.setVisibility(View.VISIBLE);
    }

    private void setTabTitle() {
        int type = preferencesManager.getFilterTypePhoto();
        if (type == 0)
            binding.contentData.txtBottomTab1.setText(getString(R.string.All));
        else if (type == 1)
            binding.contentData.txtBottomTab1.setText(getString(R.string.Photos));
        else if (type == 2)
            binding.contentData.txtBottomTab1.setText(getString(R.string.Videos));
    }

    private void purchaseInti() {
        billingClient = BillingClient.newBuilder(this).setListener(
                purchasesUpdatedListener).enablePendingPurchases().build();
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    // The BillingClient is ready. You can query purchases here.
                    initiatePurchase();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.
            }
        });
    }

    private void changeLanguage() {
        ArrayList<String> languageCodes = new ArrayList<>();
        languageCodes.add("en");
        languageCodes.add("hi");
        languageCodes.add("zh");
        languageCodes.add("es");
        languageCodes.add("de");
        languageCodes.add("ru");
        languageCodes.add("pt");
        languageCodes.add("fi");
        languageCodes.add("ja");
        languageCodes.add("tr");
        languageCodes.add("no");
        languageCodes.add("in");
        languageCodes.add("it");
        languageCodes.add("fr");
        languageCodes.add("nl");
        languageCodes.add("ko");
        languageCodes.add("ka");
        languageCodes.add("ga");
        languageCodes.add("pl");
        languageCodes.add("ca");
        Locale locale = new Locale(languageCodes.get(preferencesManager.getLanguage()));
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getBaseContext().getResources().updateConfiguration(config,
                getBaseContext().getResources().getDisplayMetrics());
    }

    private void setStatusBar() {
        if (appBarType == 0)
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        else
            getWindow().setStatusBarColor(ContextCompat.getColor(HomeActivity.this,
                    R.color.black));
    }

    private void showRate() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_rate);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView cancel = dialog.findViewById(R.id.cancel);
        TextView rateApp = dialog.findViewById(R.id.rateApp);
        rateApp.setOnClickListener(view -> {
            dialog.dismiss();
            rateUS();
        });
        cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    private void setDrawerClickListener() {
        binding.drawerContent.loutDrawerMain.setOnClickListener(view -> {
        });
        binding.drawerContent.btnDrawerFavourites.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                startActivity(new Intent(HomeActivity.this, FavoriteListActivity.class));
            });
            closeDrawer();
        });
        binding.drawerContent.btnDrawerMediaVault.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                startActivity(
                        new Intent(HomeActivity.this, PasswordActivity.class).putExtra(
                                "isOpenPrivate", true));
            });
            closeDrawer();
        });
        binding.drawerContent.btnDrawerStatusSaver.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                startActivity(new Intent(HomeActivity.this, WpStatusActivity.class));
            });
            closeDrawer();
        });
        binding.drawerContent.btnDrawerSettings.setOnClickListener(view -> {
            openSetting();
            closeDrawer();
        });
        binding.drawerContent.btnDrawerRecentMedia.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                startActivity(new Intent(HomeActivity.this, RecentActivity.class));
            });
            closeDrawer();
        });
        binding.drawerContent.btnDrawerHome.setOnClickListener(view -> {
            closeDrawer();
        });
        binding.drawerContent.btnDrawerAbout.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                startActivity(new Intent(HomeActivity.this, AboutActivity.class));
            });
            closeDrawer();
        });
        binding.drawerContent.btnDrawerMediaColor.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, 2, () -> {
                startActivity(new Intent(HomeActivity.this, MediaColorActivity.class));
            });
            closeDrawer();
        });
        binding.drawerContent.btnDrawerRate5star.setOnClickListener(view -> {
            rateUS();
            closeDrawer();
        });
        binding.drawerContent.btnDrawerPurchase.setOnClickListener(view -> {
            closeDrawer();
            showPurchaseDialog();
        });
    }

    private void rateUS() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    private void showPurchaseDialog() {
        DialogPurchaseBinding purchaseBinding;
        purchaseBinding = DialogPurchaseBinding.inflate(getLayoutInflater());
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(purchaseBinding.getRoot());
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        purchaseBinding.btnOk.setOnClickListener(view -> {
            dialog.dismiss();
            SkuDetails skuDetails = null;
            for (int i = 0; i < skuDetailsList.size(); i++) {
                if (i == 0) {
                    skuDetails = skuDetailsList.get(i);
                    break;
                }
            }
            if (skuDetails != null) {
                //                        mCheckout.startPurchaseFlow(sku, null, new
                //                        PurchaseListener());
                PRODUCT_ID = skuDetails.getSku();
                BillingFlowParams billingFlowParams =
                        BillingFlowParams.newBuilder().setSkuDetails(skuDetails).build();
                int responseCode = billingClient.launchBillingFlow(HomeActivity.this,
                        billingFlowParams).getResponseCode();
            }
        });
        purchaseBinding.btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    private void closeDrawer() {
        binding.drawerLay.closeDrawer(GravityCompat.START);
    }

    private void setActivityResultLauncher() {
        settingImageActivityResultLauncher =
                registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                setThemeScreen();
                            }
                        });
        captureImageActivityResultLauncher =
                registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                        new ActivityResultCallback<ActivityResult>() {
                            @Override
                            public void onActivityResult(ActivityResult result) {
                                if (result.getResultCode() == Activity.RESULT_OK) {
                                    // There are no request codes
                                    MediaScannerConnection.scanFile(HomeActivity.this,
                                            new String[]{imageFilePath}, null, (path, uri) -> {
                                                // Log.i("ExternalStorage", "Scanned " + path +
                                                // ":" + uri);
                                            });
                                    Log.e("", "imageFilePath: " + imageFilePath);
                                    //                            RxBus.getInstance().post(new
                                    //                            EditImageEvent(imageFilePath,
                                    //                            "Camera"));
                                    ArrayList<String> list = new ArrayList<>();
                                    list.add(imageFilePath);
                                    File file = new File(imageFilePath);
                                    RxBus.getInstance().post(new CopyMoveEvent(list, "Camera",
                                            file.getParentFile().getPath(), new ArrayList<>()));
                                }
                            }
                        });
    }

    private void setThemeScreen() {
        int theme = preferencesManager.getTheme();
        if (theme == 0)
            startActivity(new Intent(this, HomeActivity.class));
        else if (theme == 1)
            startActivity(new Intent(this, HomeFlatActivity.class));
        else if (theme == 2)
            startActivity(new Intent(this, HomeClassicActivity.class));
        finish();
    }

    private void showImageCount() {
        if (binding.contentData.viewpager.getCurrentItem() == 0) {
            binding.contentData.cameraFloatinButton.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.icn_camera));
            if (photoFragment != null) {
                binding.contentData.txtItemCounts.setText(
                        photoFragment.imageCount + " " + getString(
                                R.string.Photos) + " | " + photoFragment.videoCount + " " + getString(
                                R.string.Videos));
                Log.e("gettingListPhoto",
                        "showImageCount photos " + photoFragment.imageCount + "  video  " + photoFragment.videoCount);
            }
            binding.contentData.txtSelection.setText(getString(R.string.All));
        } else {
            binding.contentData.cameraFloatinButton.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.ic_add));
            if (albumFragment != null) {
                binding.contentData.txtItemCounts.setText(
                        albumFragment.albumCount + " " + getString(R.string.Albums));
                Log.e("gettingListPhoto", "showImageCount album " + photoFragment.imageCount);
            }
            binding.contentData.txtSelection.setText(getString(R.string.Albums));
        }
        if (photoFragment != null) {
            binding.drawerContent.txtDrawerPhoto.setText(photoFragment.imageCount + "");
            binding.drawerContent.txtDrawerVideos.setText(photoFragment.videoCount + "");
        }
        if (albumFragment != null)
            binding.drawerContent.txtDrawerAlbum.setText(albumFragment.albumCount + "");
    }

    private void setClickListener() {
        binding.contentData.ivDrawer.setOnClickListener(view -> {
            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
                binding.drawerLay.closeDrawer(GravityCompat.START);
            else
                binding.drawerLay.openDrawer(GravityCompat.START);
        });
        binding.contentData.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset,
                                       int positionOffsetPixels) {
                if (binding.contentData.loutSelect.getVisibility() == View.VISIBLE)
                    setClose();
                else if (binding.contentData.loutSearch.getVisibility() == View.VISIBLE) {
                    //                    setSearch("");
                    closeSearch();
                }
                tabPos = position;
                unSelect();
                if (position == 0)
                    setTabBottomSelect(binding.contentData.ivBottomTab1,
                            binding.contentData.txtBottomTab1);
                else
                    setTabBottomSelect(binding.contentData.ivBottomTab2,
                            binding.contentData.txtBottomTab2);
                showImageCount();
                binding.contentData.cameraFloatinButton.hide();
                binding.contentData.cameraFloatinButton.show();
            }

            @Override
            public void onPageSelected(int position) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
        binding.contentData.btnBottomTab1.setOnClickListener(view -> {
            binding.contentData.viewpager.setCurrentItem(0);
        });
        binding.contentData.btnBottomTab2.setOnClickListener(view -> {
            binding.contentData.viewpager.setCurrentItem(1);
        });
        binding.contentData.ivMenu.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(HomeActivity.this, view);
            if (binding.contentData.viewpager.getCurrentItem() == 0) {
                popup.getMenuInflater().inflate(R.menu.menu_home, popup.getMenu());
                popup.getMenu().findItem(R.id.nav_DisplayMediaName).setChecked(
                        preferencesManager.getLabelShow());
            } else if (binding.contentData.viewpager.getCurrentItem() == 1) {
                popup.getMenuInflater().inflate(R.menu.menu_album_home, popup.getMenu());
                int albumType = preferencesManager.getAlbumType();
                if (albumType == 1)
                    popup.getMenu().findItem(R.id.viewAlbumList).setChecked(true);
                else if (albumType == 2)
                    popup.getMenu().findItem(R.id.viewAlbumGrid).setChecked(true);
                else if (albumType == 3)
                    popup.getMenu().findItem(R.id.viewAlbumGridCard).setChecked(true);
                else if (albumType == 4)
                    popup.getMenu().findItem(R.id.viewAlbumParallax).setChecked(true);
                else
                    popup.getMenu().findItem(R.id.viewAlbumGrid).setChecked(true);
            }
            popup.show();
            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_DisplayMediaName) {
                    //                    boolean isChecked = popup.getMenu().findItem(R.id
                    //                    .nav_DisplayMediaName).isChecked();
                    preferencesManager.putLabelShow(!preferencesManager.getLabelShow());
                    if (photoFragment != null)
                        photoFragment.setLabel();
                } else if (item.getItemId() == R.id.nav_settings || item.getItemId() == R.id.setting) {
                    openSetting();
                } else if (item.getItemId() == R.id.viewAlbumList || item.getItemId() == R.id.viewAlbumGrid || item.getItemId() == R.id.viewAlbumGridCard || item.getItemId() == R.id.viewAlbumParallax) {
                    int albumType = 2;
                    boolean isChecked = popup.getMenu().findItem(item.getItemId()).isChecked();
                    if (item.getItemId() == R.id.viewAlbumList)
                        albumType = 1;
                    else if (item.getItemId() == R.id.viewAlbumGrid)
                        albumType = 2;
                    else if (item.getItemId() == R.id.viewAlbumGridCard)
                        albumType = 3;
                    else if (item.getItemId() == R.id.viewAlbumParallax)
                        albumType = 4;
                    else
                        albumType = 1;
                    preferencesManager.setAlbumType(albumType);
                    if (albumFragment != null)
                        albumFragment.setGridType();
                }
                return true;
            });
        });
        binding.contentData.ivSearch.setOnClickListener(view -> {
            binding.contentData.ivSearch.setVisibility(View.GONE);
            binding.contentData.ivDrawer.setVisibility(View.GONE);
            binding.contentData.ivSearchClose.setVisibility(View.GONE);
            binding.contentData.ivBack.setVisibility(View.VISIBLE);
            binding.contentData.loutSearch.setVisibility(View.VISIBLE);
            showKeyboard(binding.contentData.edtSearch);
        });
        binding.contentData.ivSearchClose.setOnClickListener(view -> {
            binding.contentData.edtSearch.getText().clear();
        });
        binding.contentData.ivBack.setOnClickListener(view -> {
            closeSearch();
        });
        binding.contentData.ivSort.setOnClickListener(view -> {
            if (binding.contentData.viewpager.getCurrentItem() == 0)
                showSortPhotosDialog();
            else
                showSortAlbumDialog();
        });
        binding.contentData.ivClose.setOnClickListener(view -> {
            setClose();
        });
        binding.contentData.ivDelete.setOnClickListener(view -> {
            int tabPos1 = binding.contentData.viewpager.getCurrentItem();
            RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "delete"));
        });
        binding.contentData.ivShare.setOnClickListener(view -> {
            int tabPos = binding.contentData.viewpager.getCurrentItem();
            RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos, "share"));
            //            setClose();
        });
        binding.contentData.ivMenuSelect.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(HomeActivity.this, view);
            popup.getMenuInflater().inflate(R.menu.menu_select_option, popup.getMenu());
            if (isSelectAll)
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.DeselectAll));
            else
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.SelectAll));
            popup.show();
            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_move_private) {
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "MediaVault"));
                } else if (item.getItemId() == R.id.nav_copy) {
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    ArrayList<AlbumData> albumList = new ArrayList<>();
                    if (albumFragment != null)
                        albumList.addAll(albumFragment.albumBackUpList);
                    RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "copy",
                            albumList));
                } else if (item.getItemId() == R.id.nav_move) {
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    ArrayList<AlbumData> albumList = new ArrayList<>();
                    if (albumFragment != null)
                        albumList.addAll(albumFragment.albumBackUpList);
                    RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "move",
                            albumList));
                } else if (item.getItemId() == R.id.nav_select) {
                    if (isSelectAll)
                        isSelectAll = false;
                    else
                        isSelectAll = true;
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    RxBus.getInstance().post(
                            new ImageShareDeleteEvent(tabPos1, "Select", isSelectAll));
                }
                return true;
            });
        });
        binding.contentData.edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String strSearch = charSequence.toString();
                Log.e("searchText addChange: ", strSearch);
                setSearch(strSearch);
                if (i2 == 0) {
                    binding.contentData.ivSearchClose.setVisibility(View.GONE);
                } else {
                    binding.contentData.ivSearchClose.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        binding.contentData.edtSearch.setOnEditorActionListener((textView, actionId, keyEvent) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if (!binding.contentData.edtSearch.getText().toString().isEmpty() && binding.contentData.edtSearch.getText().toString().trim().length() != 0) {
                    String strSearch = binding.contentData.edtSearch.getText().toString().trim();
                    setSearch(strSearch);
                }
                hideKeyboard(binding.contentData.edtSearch);
                return true;
            }
            return false;
        });
        binding.contentData.cameraFloatinButton.setOnClickListener(new ClickListener(this, admobAdManager, () -> {
            if (binding.contentData.viewpager.getCurrentItem() == 0) {
                Dexter.withContext(HomeActivity.this).withPermission(Manifest.permission.CAMERA).withListener(
                        new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse response) {
                                openCamera();
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse response) {
                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(
                                    PermissionRequest permission, PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        }).check();
            } else {
                ChooseFolderDialog albumDialog = new ChooseFolderDialog(HomeActivity.this, selectPath -> {
                    showCreateDialog(selectPath);
                });
                albumDialog.show();
            }
        }));
    }

    private void openSetting() {
        admobAdManager.loadInterstitialAd(this, 2, () -> {
            Intent intent = new Intent(HomeActivity.this, SettingsActivity.class);
            settingImageActivityResultLauncher.launch(intent);
        });
    }

    private void showCreateDialog(String selectPath) {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_create_album);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_ok = dialog.findViewById(R.id.btn_ok);
        TextView txt_path = dialog.findViewById(R.id.txt_path);
        EditText editText = dialog.findViewById(R.id.edtAlbumName);
        txt_path.setText(selectPath);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.img_newalbum);
        btn_ok.setOnClickListener(view -> {
            String albumName = editText.getText().toString().trim();
            if (!albumName.isEmpty()) {
                File file = new File(selectPath + File.separator + albumName);
                if (!file.exists()) {
                    file.mkdirs();
                    String outputPath = file.getPath() + File.separator + albumName + ".png";
                    dialog.dismiss();
                    new Thread(() -> {
                        try {
                            OutputStream fOut = null;
                            File file1 = new File(outputPath);
                            if (file1.exists()) {
                                file1.delete();// the File to save , append increasing numeric
                                // counter to prevent files from getting overwritten.
                            }
                            fOut = new FileOutputStream(file1);
                            Bitmap pictureBitmap = bitmap; // obtaining the Bitmap
                            pictureBitmap.compress(Bitmap.CompressFormat.JPEG, 100,
                                    fOut); // saving the Bitmap to a file compressed as a JPEG
                            // with 85% compression rate
                            fOut.flush(); // Not really required
                            fOut.close(); // do not forget to close the stream
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        runOnUiThread(() -> {
                            ArrayList<String> list = new ArrayList<>();
                            list.add(outputPath);
                            RxBus.getInstance().post(
                                    new CopyMoveEvent(list, albumName, file.getAbsolutePath(),
                                            new ArrayList<>()));
                        });
                    }).start();
                } else
                    Toast.makeText(HomeActivity.this, getString(R.string.create_validation2),
                            Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(HomeActivity.this, getString(R.string.create_validation),
                        Toast.LENGTH_SHORT).show();
        });
        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    public int getStatusBarHeight(final Context context) {
        final Resources resources = context.getResources();
        final int resourceId = resources.getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0)
            return resources.getDimensionPixelSize(resourceId);
        else
            return (int) Math.ceil(
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? 24 : 25) * resources.getDisplayMetrics().density);
    }

    private void closeSearch() {
        binding.contentData.edtSearch.getText().clear();
        hideKeyboard(binding.contentData.edtSearch);
        binding.contentData.ivSearch.setVisibility(View.VISIBLE);
        binding.contentData.ivDrawer.setVisibility(View.VISIBLE);
        binding.contentData.ivSearchClose.setVisibility(View.GONE);
        binding.contentData.ivBack.setVisibility(View.GONE);
        binding.contentData.loutSearch.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (binding.contentData.loutSelect.getVisibility() == View.VISIBLE) {
            setClose();
        }else if (binding.contentData.loutSearch.getVisibility() == View.VISIBLE) {
            closeSearch();
        }else /*if (preferencesManager.getExitDialogShow()) */{
            if (isNativeLoad) {
                isNativeLoad = false;
                FrameLayout adLayout = exitDialogs.findViewById(R.id.adLayout);
                if (admobAdManager.mNativeRateAd != null) {
                    admobAdManager.populateExitUnifiedNativeAdView(
                            this,
                            adLayout,
                            admobAdManager.mNativeRateAd,
                            true
                    );
                }
                exitDialogs.show();
            } else {
                showExitDialog();
            }

        }/* else {
            super.onBackPressed();
        }*/
    }

    private void showExitDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.exit_dialog);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView exitApp = dialog.findViewById(R.id.exitApp);
        TextView btn_cancel = dialog.findViewById(R.id.cancel);
        exitApp.setOnClickListener(view -> {
            dialog.dismiss();
            finish();
        });
        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    private void openCamera() {
        String fileType;
        fileType = ".png";
        String dir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DCIM) + File.separator + "Camera";
        File newdir = new File(dir);
        String time_stamp =
                new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(System.currentTimeMillis());
        imageFilePath = newdir.getPath() + File.separator + time_stamp + fileType;
        if (!newdir.exists())
            newdir.mkdirs();
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider",
                new File(imageFilePath));
        try {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            captureImageActivityResultLauncher.launch(cameraIntent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, getString(R.string.not_found), Toast.LENGTH_SHORT).show();
        }
    }

    private void setSearch(String strSearch) {
        if (tabPos == 0) {
            if (photoFragment != null)
                photoFragment.setSearch(strSearch);
        } else if (tabPos == 1) {
            if (albumFragment != null)
                albumFragment.setSearch(strSearch);
        }
    }

    public void hideKeyboard(EditText view) {
        view.clearFocus();
        InputMethodManager methodManager =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert methodManager != null;
        methodManager.hideSoftInputFromWindow(view.getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }

    private void showKeyboard(EditText view) {
        view.requestFocus();
        InputMethodManager methodManager =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert methodManager != null;
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
    }

    private void setClose() {
        RxBus.getInstance().post(new ImageCloseEvent(tabPos));
        binding.contentData.loutSelect.setVisibility(View.GONE);
        binding.contentData.toolbar.setVisibility(View.VISIBLE);
    }

    private void setTabBottomSelect(ImageView ivTab1, TextView txtTab1) {
        ivTab1.setColorFilter(ContextCompat.getColor(this, R.color.theme_color),
                PorterDuff.Mode.SRC_IN);
        txtTab1.setTextColor(ContextCompat.getColor(this, R.color.theme_color));
    }

    private void unSelect() {
        binding.contentData.ivBottomTab1.setColorFilter(
                ContextCompat.getColor(this, R.color.tab_unselect), PorterDuff.Mode.SRC_IN);
        binding.contentData.ivBottomTab2.setColorFilter(
                ContextCompat.getColor(this, R.color.tab_unselect), PorterDuff.Mode.SRC_IN);
        binding.contentData.txtBottomTab1.setTextColor(
                ContextCompat.getColor(this, R.color.tab_unselect));
        binding.contentData.txtBottomTab2.setTextColor(
                ContextCompat.getColor(this, R.color.tab_unselect));
    }

    int sortByAlbum;

    boolean sortTypeAlbum;

    private void showSortAlbumDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_sort_album);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_apply = dialog.findViewById(R.id.btn_apply);
        RadioGroup grp_type = dialog.findViewById(R.id.grp_type);
        RadioGroup grp_sort_type = dialog.findViewById(R.id.grp_sort_type);
        RadioButton radio_name = dialog.findViewById(R.id.radio_name);
        RadioButton radio_size = dialog.findViewById(R.id.radio_size);
        RadioButton radio_date = dialog.findViewById(R.id.radio_date);
        RadioButton radio_Descending = dialog.findViewById(R.id.radio_Descending);
        RadioButton radio_Ascending = dialog.findViewById(R.id.radio_Ascending);
        sortByAlbum = preferencesManager.getSortAlbum();
        sortTypeAlbum = preferencesManager.getSortTypeAlbum();
        if (sortByAlbum == 0)
            radio_name.setChecked(true);
        else if (sortByAlbum == 1)
            radio_size.setChecked(true);
        else if (sortByAlbum == 2)
            radio_date.setChecked(true);
        if (sortTypeAlbum)
            radio_Descending.setChecked(true);
        else
            radio_Ascending.setChecked(true);
        grp_type.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.radio_name)
                sortByAlbum = 0;
            else if (i == R.id.radio_size)
                sortByAlbum = 1;
            else if (i == R.id.radio_date)
                sortByAlbum = 2;
        });
        grp_sort_type.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.radio_Descending)
                sortTypeAlbum = true;
            else if (i == R.id.radio_Ascending)
                sortTypeAlbum = false;
        });
        btn_apply.setOnClickListener(view -> {
            preferencesManager.setSortTypeAlbum(sortTypeAlbum);
            preferencesManager.setSortAlbum(sortByAlbum);
            dialog.dismiss();
            RxBus.getInstance().post(new FilterSettingUpdate(false));
        });
        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    int gridCount = 3;

    int filterBy = 0;

    int sortBy = 0;

    boolean sortType = true;

    private void showSortPhotosDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_sort);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_apply = dialog.findViewById(R.id.btn_apply);
        TextView btn_grid_one = dialog.findViewById(R.id.btn_grid_one);
        TextView btn_grid_two = dialog.findViewById(R.id.btn_grid_two);
        TextView btn_grid_three = dialog.findViewById(R.id.btn_grid_three);
        TextView btn_grid_four = dialog.findViewById(R.id.btn_grid_four);
        SwitchCompat switchShowLabel = dialog.findViewById(R.id.switch_show_label);
        TextView btnFilterAll = dialog.findViewById(R.id.btn_filter_all);
        TextView btnFilterPhotos = dialog.findViewById(R.id.btn_filter_photos);
        TextView btnFilterVideos = dialog.findViewById(R.id.btn_filter_videos);
        TextView btnSortName = dialog.findViewById(R.id.btn_sort_name);
        TextView btnSortDate = dialog.findViewById(R.id.btn_sort_date);
        TextView btnAscending = dialog.findViewById(R.id.btn_Ascending);
        TextView btnDescending = dialog.findViewById(R.id.btn_Descending);
        gridCount = preferencesManager.getGridPhoto();
        filterBy = preferencesManager.getFilterTypePhoto();
        sortBy = preferencesManager.getSortPhoto();
        sortType = preferencesManager.getSortTypePhoto();
        switchShowLabel.setChecked(preferencesManager.getLabelShow());
        if (gridCount == 1)
            selectGrid(btn_grid_one, btn_grid_two, btn_grid_three, btn_grid_four);
        else if (gridCount == 2)
            selectGrid(btn_grid_two, btn_grid_one, btn_grid_three, btn_grid_four);
        else if (gridCount == 3)
            selectGrid(btn_grid_three, btn_grid_two, btn_grid_one, btn_grid_four);
        else if (gridCount == 4)
            selectGrid(btn_grid_four, btn_grid_two, btn_grid_three, btn_grid_one);
        if (filterBy == 0)
            selectFilter(btnFilterAll, btnFilterPhotos, btnFilterVideos);
        else if (filterBy == 1)
            selectFilter(btnFilterPhotos, btnFilterAll, btnFilterVideos);
        else if (filterBy == 2)
            selectFilter(btnFilterVideos, btnFilterPhotos, btnFilterAll);
        if (sortBy == 0)
            selectSort(btnSortName, btnSortDate);
        else if (sortBy == 1)
            selectSort(btnSortDate, btnSortName);
        if (sortType)
            selectSort(btnDescending, btnAscending);
        else
            selectSort(btnAscending, btnDescending);
        btn_apply.setOnClickListener(view -> {
            preferencesManager.setFilterTypePhoto(filterBy);
            preferencesManager.setSortPhoto(sortBy);
            preferencesManager.setSortTypePhoto(sortType);
            preferencesManager.setGridPhoto(gridCount);
            preferencesManager.putLabelShow(switchShowLabel.isChecked());
            dialog.dismiss();
            setTabTitle();
            RxBus.getInstance().post(new FilterSettingUpdate(true));
        });
        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        btnFilterAll.setOnClickListener(view -> {
            filterBy = 0;
            selectFilter(btnFilterAll, btnFilterPhotos, btnFilterVideos);
        });
        btnFilterPhotos.setOnClickListener(view -> {
            filterBy = 1;
            selectFilter(btnFilterPhotos, btnFilterAll, btnFilterVideos);
        });
        btnFilterVideos.setOnClickListener(view -> {
            filterBy = 2;
            selectFilter(btnFilterVideos, btnFilterPhotos, btnFilterAll);
        });
        btn_grid_one.setOnClickListener(view -> {
            gridCount = 1;
            selectGrid(btn_grid_one, btn_grid_two, btn_grid_three, btn_grid_four);
        });
        btn_grid_two.setOnClickListener(view -> {
            gridCount = 2;
            selectGrid(btn_grid_two, btn_grid_one, btn_grid_three, btn_grid_four);
        });
        btn_grid_three.setOnClickListener(view -> {
            gridCount = 3;
            selectGrid(btn_grid_three, btn_grid_two, btn_grid_one, btn_grid_four);
        });
        btn_grid_four.setOnClickListener(view -> {
            gridCount = 4;
            selectGrid(btn_grid_four, btn_grid_two, btn_grid_three, btn_grid_one);
        });
        btnSortName.setOnClickListener(view -> {
            sortBy = 0;
            selectSort(btnSortName, btnSortDate);
        });
        btnSortDate.setOnClickListener(view -> {
            sortBy = 1;
            selectSort(btnSortDate, btnSortName);
        });
        btnDescending.setOnClickListener(view -> {
            sortType = true;
            selectSort(btnDescending, btnAscending);
        });
        btnAscending.setOnClickListener(view -> {
            sortType = false;
            selectSort(btnAscending, btnDescending);
        });
        dialog.show();
    }

    private void selectSort(TextView btnSortName, TextView btnSortDate) {
        btnSortName.setTextColor(ContextCompat.getColor(this, R.color.white));
        btnSortDate.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btnSortName.setBackground(
                ContextCompat.getDrawable(this, R.drawable.filter_option_box_select));
        btnSortDate.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
    }

    private void selectFilter(TextView btnFilterAll, TextView btnFilterPhotos,
                              TextView btnFilterVideos) {
        btnFilterAll.setTextColor(ContextCompat.getColor(this, R.color.white));
        btnFilterPhotos.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btnFilterVideos.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btnFilterAll.setBackground(
                ContextCompat.getDrawable(this, R.drawable.filter_option_box_select));
        btnFilterPhotos.setBackground(
                ContextCompat.getDrawable(this, R.drawable.filter_option_box));
        btnFilterVideos.setBackground(
                ContextCompat.getDrawable(this, R.drawable.filter_option_box));
    }

    private void selectGrid(TextView btn_grid_one, TextView btn_grid_two, TextView btn_grid_three,
                            TextView btn_grid_four) {
        btn_grid_one.setTextColor(ContextCompat.getColor(this, R.color.white));
        btn_grid_two.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btn_grid_three.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btn_grid_four.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btn_grid_one.setBackground(
                ContextCompat.getDrawable(this, R.drawable.filter_option_box_select));
        btn_grid_two.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
        btn_grid_three.setBackground(ContextCompat.getDrawable(this,
                R.drawable.filter_option_box));
        btn_grid_four.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
    }

    private void showCount() {
        Subscription subscription =
                RxBus.getInstance().toObservable(CountShowEvent.class).subscribeOn(
                        Schedulers.io()).observeOn(
                        AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(
                        new Action1<CountShowEvent>() {
                            @Override
                            public void call(CountShowEvent event) {
                                showImageCount();
                                if (photoFragment != null)
                                    if (photoFragment.pictures != null && photoFragment.pictures.size() != 0)
                                        try {
                                            if (photoFragment.pictures.get(
                                                    1) instanceof PictureData) {
                                                PictureData pictureData =
                                                        (PictureData) photoFragment.pictures.get(1);
                                                Glide.with(HomeActivity.this).load(
                                                        pictureData.getFilePath()).diskCacheStrategy(
                                                        DiskCacheStrategy.NONE).skipMemoryCache(
                                                        true).into(binding.contentData.imgToolbar);
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                            }
                        }, new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                            }
                        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    @Override
    public void longClick(boolean isShowToolbar, boolean isShowSelected, int selected, long size) {
        if (isShowToolbar) {
            binding.contentData.toolbar.setVisibility(View.VISIBLE);
        } else {
            binding.contentData.toolbar.setVisibility(View.GONE);
        }
        if (isShowSelected) {
            binding.contentData.loutSelect.setVisibility(View.VISIBLE);
        } else {
            binding.contentData.loutSelect.setVisibility(View.GONE);
        }
        binding.contentData.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.contentData.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
        if (size == 0)
            isSelectAll = false;
    }

    private class HomePagerAdapter extends FragmentPagerAdapter {

        PhotoFragment pictureFragment;

        AlbumFragment albumFragment;

        int size = 0;

        public HomePagerAdapter(@NonNull FragmentManager fm, int size,
                                PhotoFragment pictureFragment, AlbumFragment albumFragment) {
            super(fm);
            this.pictureFragment = pictureFragment;
            this.albumFragment = albumFragment;
            this.size = size;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            if (position == 0)
                return pictureFragment;
            else if (position == 1)
                return albumFragment;
            return pictureFragment;
        }

        @Override
        public int getCount() {
            return size;
        }

    }

    private PurchasesUpdatedListener purchasesUpdatedListener = new PurchasesUpdatedListener() {
        @Override
        public void onPurchasesUpdated(BillingResult billingResult,
                                       List<com.android.billingclient.api.Purchase> purchases) {
            // To be implemented in a later section.
            //            Toast.makeText(Prefrancemanager.this, "Changed", Toast.LENGTH_LONG)
            //            .show();
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                for (com.android.billingclient.api.Purchase purchase : purchases) {
                    handlePurchase(purchase);
                }
            } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
                billingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(
                                BillingClient.ProductType.SUBS)//or SUBS
                        .build(), new PurchasesResponseListener() {
                    @Override
                    public void onQueryPurchasesResponse(BillingResult billingResult,
                                                         List<Purchase> purchases) {
                        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                            if (purchases != null)
                                for (Purchase purchase : purchases) {
                                    handlePurchase(purchase);
                                }
                        }
                    }
                });
            } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
                // Handle an error caused by a user cancelling the purchase flow.
                //                binding.continuePayment.setClickable(true);
                Toast.makeText(getApplicationContext(), getString(R.string.PurchaseCanceled),
                        Toast.LENGTH_SHORT).show();
            } else {
                // Handle any other error codes.
                //                binding.continuePayment.setClickable(true);
                Toast.makeText(getApplicationContext(),
                        getString(R.string.Error) + billingResult.getDebugMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        }
    };

    void handlePurchase(com.android.billingclient.api.Purchase purchasee) {
        com.android.billingclient.api.Purchase purchase = purchasee;
        if (purchase.getPurchaseState() == com.android.billingclient.api.Purchase.PurchaseState.PURCHASED) {
            if (!purchase.isAcknowledged()) {
                AcknowledgePurchaseParams acknowledgePurchaseParams =
                        AcknowledgePurchaseParams.newBuilder().setPurchaseToken(
                                purchase.getPurchaseToken()).build();
                //                binding.continuePayment.setClickable(true);
                billingClient.acknowledgePurchase(acknowledgePurchaseParams,
                        acknowledgePurchaseResponseListener);
            } else {
                //                binding.continuePayment.setClickable(true);
                if (!preferencesManager.getSubscription(HomeActivity.this)) {
                    preferencesManager.putSubscription(HomeActivity.this, true);
                    setPurchased();
                    //                    Toast.makeText(getApplicationContext(), "Item
                    //                    Purchased", Toast.LENGTH_SHORT).show();
                }
            }
        }//if purchase is pending
        else if (purchase.getPurchaseState() == com.android.billingclient.api.Purchase.PurchaseState.PENDING) {
            //            binding.continuePayment.setClickable(true);
            Toast.makeText(getApplicationContext(), getString(R.string.PurchasePending),
                    Toast.LENGTH_SHORT).show();
        }//if purchase is unknown
        else if (purchase.getPurchaseState() == com.android.billingclient.api.Purchase.PurchaseState.UNSPECIFIED_STATE) {
            preferencesManager.putSubscription(HomeActivity.this, false);
            //            binding.continuePayment.setClickable(true);
            Toast.makeText(HomeActivity.this, getString(R.string.PurchaseFailed),
                    Toast.LENGTH_SHORT).show();
        }
    }

    AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener =
            new AcknowledgePurchaseResponseListener() {
                @Override
                public void onAcknowledgePurchaseResponse(@NonNull BillingResult billingResult) {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        preferencesManager.putSubscription(HomeActivity.this, true);
                        Calendar calendar = Calendar.getInstance();
                        //                preferencesManager.putPurchaseDate(HomeActivity.this,
                        //                getDate(calendar.getTimeInMillis()));
                        setPurchased();
                        Toast.makeText(getApplicationContext(),
                                getString(R.string.PurchaseSuccessfully),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            };

    private void initiatePurchase() {
        SkuDetailsParams.Builder params = SkuDetailsParams.newBuilder();
        params.setSkusList(SKUS).setType(SUBS);
        billingClient.querySkuDetailsAsync(params.build(), new SkuDetailsResponseListener() {
            @Override
            public void onSkuDetailsResponse(BillingResult billingResult,
                                             List<SkuDetails> skuDetailList) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    // Process the result.
                    if (skuDetailList != null && skuDetailList.size() > 0) {
                        for (SkuDetails sku : skuDetailList) {
                            skuDetailsList.add(sku);
                        }
                    } else {
                        //try to add item/product id "purchase" inside managed product in google
                        // play console
                        Toast.makeText(getApplicationContext(),
                                getString(R.string.PurchaseNotFound), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(),
                            getString(R.string.Error) + " " + billingResult.getDebugMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}