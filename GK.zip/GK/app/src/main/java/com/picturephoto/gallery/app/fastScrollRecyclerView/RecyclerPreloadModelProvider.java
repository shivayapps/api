package com.picturephoto.gallery.app.fastScrollRecyclerView;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.ListPreloader;
import com.bumptech.glide.RequestBuilder;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.model.PictureData;

import java.io.File;
import java.util.Collections;
import java.util.List;

public class RecyclerPreloadModelProvider implements ListPreloader.PreloadModelProvider<PictureData> {

    private List<PictureData> urisToLoad;
    RequestBuilder<Bitmap> request;
    //RequestBuilder<Drawable> request;

    public RecyclerPreloadModelProvider(@NonNull Context fragment, @NonNull List<PictureData> uris) {
        urisToLoad = uris;
        Display defaultDisplay = ((WindowManager) fragment.getSystemService("window")).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        int i2 = displayMetrics.widthPixels;
        int i3 = displayMetrics.heightPixels;
        int h = (int) ((19.0f * ((float) i2)) / 100.0f);
        int w = (int) ((11.0f * ((float) i3)) / 100.0f);

        //request = Glide.with(fragment).asDrawable().diskCacheStrategy(DiskCacheStrategy.ALL).thumbnail(0.5f).placeholder(R.drawable.iv_placeholder).centerCrop();
       // request = Glide.with(fragment).asDrawable().override(h,w).thumbnail(0.5f).placeholder(R.drawable.iv_placeholder).centerCrop();
    //    request = Glide.with(fragment).asDrawable().override(h,w).placeholder(R.drawable.iv_placeholder).centerCrop();
//        request = Glide.with(fragment).asBitmap().apply(new RequestOptions().centerCrop()).override(h,w).placeholder(R.drawable.iv_placeholder).centerCrop();


    }

    @Override
    @NonNull
    public List<PictureData> getPreloadItems(int position) {
        if(urisToLoad.size()>position)
        {
            PictureData iconData = urisToLoad.get(position);
            if (iconData == null) return Collections.emptyList();
            return Collections.singletonList(iconData);
        }
        else
        {
            return Collections.emptyList();
        }
    }

    @Override
    @Nullable
    public RequestBuilder<Bitmap> getPreloadRequestBuilder(PictureData iconData) {
        RequestBuilder<Bitmap> requestBuilder;
        Uri uri = Uri.fromFile(new File(iconData.getFilePath()));
            requestBuilder = request.load(uri);
        return requestBuilder;
    }
    /*
    @Override
    @Nullable
    public RequestBuilder<Drawable> getPreloadRequestBuilder(Media_Data iconData) {
        RequestBuilder<Drawable> requestBuilder;
        Uri uri = Uri.fromFile(new File(iconData.getPath()));
            requestBuilder = request.load(uri);
        return requestBuilder;
    }*/
}
