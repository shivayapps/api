package com.picturephoto.gallery.app.activity;

import static android.os.Build.VERSION.SDK_INT;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityWpStatusBinding;
import com.picturephoto.gallery.app.fragment.RecentStatusFragment;
import com.picturephoto.gallery.app.fragment.SavedStatusFragment;
import com.picturephoto.gallery.app.interfaces.LongClickListener;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

import java.io.File;

public class WpStatusActivity extends AppCompatActivity implements LongClickListener {

    ActivityWpStatusBinding binding;
    ActivityResultLauncher<Intent> permiisionActivityResultLauncher;
    PreferencesManager preferencesManager;
    RecentStatusFragment statusFragment;
    SavedStatusFragment savedFragment;
    WPPagerAdapter adapter;
    boolean isSelectAll = false;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWpStatusBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        onActivityResult();
        if (SDK_INT >= Build.VERSION_CODES.Q && !preferencesManager.getStoragePermission11()) {
            if (preferencesManager.getUriWp() == null || preferencesManager.getUriWp().equals("") || !preferencesManager.getUriWp().endsWith(".Statuses"))
                if (isAppInstalled())
                    askPermission();
        }
        setTab();
        setClickListener();
    }

    private void setClickListener() {
        binding.ivBack.setOnClickListener(view -> {
            onBackPressed();
        });
        binding.ivWhatsApp.setOnClickListener(view -> {
            try {
                PackageManager pm = getPackageManager();
                Intent launchIntent = pm.getLaunchIntentForPackage("com.whatsapp");
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(launchIntent);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Whatsapp is not install", Toast.LENGTH_SHORT).show();
            }

        });

        binding.ivClose.setOnClickListener(view -> {
            setClose();
        });
        binding.ivDownload.setOnClickListener(view -> {
            int tabPos1 = binding.viewpager.getCurrentItem();
            if (tabPos1 == 0)
                statusFragment.downloadFile();
        });

        binding.ivDelete.setOnClickListener(view -> {
            int tabPos1 = binding.viewpager.getCurrentItem();
            if (tabPos1 == 1)
                savedFragment.ShowDelete();
        });
        binding.ivShare.setOnClickListener(view -> {
            int tabPos1 = binding.viewpager.getCurrentItem();
            if (tabPos1 == 0)
                statusFragment.shareFile();
            else if (tabPos1 == 1)
                savedFragment.shareFile();

        });
        binding.ivMenuSelect.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(WpStatusActivity.this, view);
            popup.getMenuInflater().inflate(R.menu.menu_select_option, popup.getMenu());
            if (isSelectAll)
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.DeselectAll));
            else
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.SelectAll));
            popup.getMenu().findItem(R.id.nav_move_private).setVisible(false);
            popup.getMenu().findItem(R.id.nav_copy).setVisible(false);
            popup.getMenu().findItem(R.id.nav_move).setVisible(false);
            popup.show();

            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_select) {
                    if (isSelectAll)
                        isSelectAll = false;
                    else
                        isSelectAll = true;
                    int tabPos1 = binding.viewpager.getCurrentItem();
                    if (tabPos1 == 0)
                        statusFragment.setAllSelect(isSelectAll);
                    else if (tabPos1 == 1)
                        savedFragment.setAllSelect(isSelectAll);
                }
                return true;
            });
        });
    }

    @Override
    public void onBackPressed() {
        if (binding.loutSelect.getVisibility() == View.VISIBLE)
            setClose();
        else {
            admobAdManager.loadInterstitialBackAd(this, 2, () -> finish());
        }
    }

    private void setClose() {
        if (binding.viewpager.getCurrentItem() == 0) {
            if (statusFragment != null)
                statusFragment.setClose();
        } else if (binding.viewpager.getCurrentItem() == 1) {
            if (savedFragment != null)
                savedFragment.setClose();
        }

        binding.toolbar.setVisibility(View.VISIBLE);
        binding.tablayout.setVisibility(View.VISIBLE);
        binding.loutSelect.setVisibility(View.GONE);
    }

    private void setTab() {
        binding.tablayout.addTab(binding.tablayout.newTab().setText(getString(R.string.RecentStatus)));
        binding.tablayout.addTab(binding.tablayout.newTab().setText(getString(R.string.SavedStatus)));

        statusFragment = RecentStatusFragment.newInstance();
        savedFragment = SavedStatusFragment.newInstance();

        statusFragment.setLongClickListener(this);
        savedFragment.setLongClickListener(this);
        binding.viewpager.setOffscreenPageLimit(2);
        adapter = new WPPagerAdapter(getSupportFragmentManager(), 2, statusFragment, savedFragment);
        binding.viewpager.setAdapter(adapter);

        binding.viewpager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(binding.tablayout));

        binding.tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewpager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        binding.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (binding.loutSelect.getVisibility() == View.VISIBLE)
                    setClose();
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    private void onActivityResult() {
        permiisionActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getData() != null) {
                        Uri treeUri = result.getData().getData();
                        getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        Log.e("onActivityResult", "treeUri--->> " + treeUri.toString());
                        preferencesManager.putUriWp(treeUri.toString());
//                        Intent intent = getIntent();
//                        overridePendingTransition(0, 0);
//                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        finish();
//                        overridePendingTransition(0, 0);
//                        startActivity(intent);
                        if (statusFragment != null)
                            statusFragment.getData();
                    }
                });
    }

    public boolean isAppInstalled() {
        File folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/media/com.whatsapp/WhatsApp/Media/.Statuses");
        if (folder.isDirectory())
            return true;
        else
            return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void askPermission() {
        StorageManager storageManager = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        Intent intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();

        String targetDirectory = "Android%2FMedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses";
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString();
        scheme = scheme.replace("/root/", "/document/");
        scheme += "%3A" + targetDirectory;
        uri = Uri.parse(scheme);
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        permiisionActivityResultLauncher.launch(intent);
    }

    @Override
    public void longClick(boolean isShowToolbar, boolean isShowSelected, int selected, long size) {
        if (isShowToolbar) {
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.tablayout.setVisibility(View.VISIBLE);
        } else {
            binding.toolbar.setVisibility(View.GONE);
            binding.tablayout.setVisibility(View.GONE);
        }

        if (isShowSelected) {
            if (binding.viewpager.getCurrentItem() == 0) {
                binding.ivDelete.setVisibility(View.GONE);
                binding.ivDownload.setVisibility(View.VISIBLE);
            } else {
                binding.ivDelete.setVisibility(View.VISIBLE);
                binding.ivDownload.setVisibility(View.GONE);
            }
            binding.loutSelect.setVisibility(View.VISIBLE);
        } else {
            binding.loutSelect.setVisibility(View.GONE);
        }
        binding.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
        if (size == 0)
            isSelectAll = false;
    }

    private class WPPagerAdapter extends FragmentPagerAdapter {
        RecentStatusFragment statusFragment;
        SavedStatusFragment savedStatusFragment;
        int size = 0;

        public WPPagerAdapter(@NonNull FragmentManager fm, int size, RecentStatusFragment statusFragment, SavedStatusFragment savedStatusFragment) {
            super(fm);
            this.statusFragment = statusFragment;
            this.savedStatusFragment = savedStatusFragment;
            this.size = size;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            if (position == 0)
                return statusFragment;
            else if (position == 1)
                return savedStatusFragment;
            return statusFragment;
        }

        @Override
        public int getCount() {
            return size;
        }
    }
}