package com.picturephoto.gallery.app.ads;

public interface AdEventListener {
    void onAdLoaded();
    void onAdClosed();
    void onLoadError(String errorCode);
    void onAdLoaded(Object object);
}
