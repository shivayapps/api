package com.picturephoto.gallery.app.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.SelectAlbumAdapter;
import com.picturephoto.gallery.app.databinding.DialogSelectAlbumBinding;
import com.picturephoto.gallery.app.interfaces.SelectPathListener;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;

import java.io.File;
import java.util.ArrayList;

public class SelectAlbumDialog extends Dialog {
    DialogSelectAlbumBinding binding;
    String type;
    ArrayList<AlbumData> albumList = new ArrayList<>();
    SelectAlbumAdapter albumAdapter;
    Context context;
    SelectPathListener pathListener;

    public SelectAlbumDialog(@NonNull Context context, String type, ArrayList<AlbumData> albumList, SelectPathListener pathListener) {
        super(context);
        this.context = context;
        this.type = type;
        this.albumList = albumList;
        this.pathListener = pathListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        binding = DialogSelectAlbumBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (type.equalsIgnoreCase("copy"))
            binding.txtTitle.setText(context.getText(R.string.Copy));
        else if (type.equalsIgnoreCase("move"))
            binding.txtTitle.setText(context.getText(R.string.Move));

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
            for (int i = albumList.size() - 1; i > 0; i--) {
                ArrayList<PictureData> photoData = albumList.get(i).getPictureData();
                if (!photoData.get(0).getFilePath().contains(Environment.DIRECTORY_PICTURES) && !photoData.get(0).getFilePath().contains(Environment.DIRECTORY_DCIM)) {
                    albumList.remove(i);
                }
            }
        }
        initAdapter();
        binding.btnCancel.setOnClickListener(view -> {
            dismiss();
        });

        binding.ivNewAdd.setOnClickListener(view -> {
            ChooseFolderDialog albumDialog = new ChooseFolderDialog(context, selectPath -> {
                dismiss();
                showCreateDialog(selectPath);
            });
            albumDialog.show();
        });
    }

    private void initAdapter() {
        albumAdapter = new SelectAlbumAdapter(context, albumList, pos -> {
            pathListener.selectPath(albumList.get(pos).getFolderPath());
            dismiss();
//            albumData = albumList.get(pos);
//            startActivity(new Intent(getActivity(), AlbumImageActivity.class));
        });
        binding.albumRecycler.setLayoutManager(new GridLayoutManager(context, 3, RecyclerView.VERTICAL, false));
        binding.albumRecycler.setAdapter(albumAdapter);
    }

    private void showCreateDialog(String selectPath) {
        final Dialog dialog = new Dialog(context, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_create_album);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_ok = dialog.findViewById(R.id.btn_ok);
        TextView txt_path = dialog.findViewById(R.id.txt_path);
        EditText editText = dialog.findViewById(R.id.edtAlbumName);

        txt_path.setText(selectPath);

        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(),
                R.drawable.img_newalbum);


        btn_ok.setOnClickListener(view -> {
            String albumName = editText.getText().toString().trim();
            if (!albumName.isEmpty()) {
                File file = new File(selectPath + File.separator + albumName);
                if (!file.exists()) {
                    file.mkdirs();
                    dialog.dismiss();
                    pathListener.selectPath(file.getPath());
                } else
                    Toast.makeText(context, context.getString(R.string.create_validation2), Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(context, context.getString(R.string.create_validation), Toast.LENGTH_SHORT).show();
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }
}
