package com.picturephoto.gallery.app.ads;


import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.picturephoto.gallery.app.preferences.PreferencesManager;


public class AppOpenManager implements LifecycleObserver, Application.ActivityLifecycleCallbacks {

    private final PreferencesManager preferencesManager;
    AppOpenAd appOpenAd;
    AppOpenAd.AppOpenAdLoadCallback loadCallback;
    Activity currentActivity;
    Boolean isLoading = false;

    int activityReferences = 0;
    Boolean isActivityChangingConfigurations = false;
    public static Boolean isShowingAd = false;
    Application myApplication;

    public static AppOpenManager appOpenManager = null;

    public static AppOpenManager getInstance(Application appClass) {
        if (appOpenManager == null) {
            appOpenManager = new AppOpenManager(appClass);
        }
        return appOpenManager;
    }

    public AppOpenManager(Application appClass) {
        this.myApplication = appClass;
        preferencesManager = PreferencesManager.getInstance(myApplication);
        myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    void onStart() {
        showAppOpenAd();
    }

    public void showAppOpenAd() {
        if (currentActivity.getLocalClassName() != null)
            if (!Variables.isSplashScreen && !Variables.isSPermissionScreen && !currentActivity.getLocalClassName().equals("com.calldorado.ui.settings.SettingsActivity") && !currentActivity.getLocalClassName().equals("com.calldorado.ui.aftercall.CallerIdActivity")) {
                if (isAdAvailable()) {
                    showAdIfAvailable();
                } else {
                    fetchAd(true, null);
                }
            }
    }

    public void loadAppOpenAd(AdmobAdManager.OnAdClosedListener adClosedListener) {
        if (Variables.isSplashScreen) {
            if (!isAdAvailable()) {
                fetchAd(false, adClosedListener);
            } else {
                if (adClosedListener != null) {
                    adClosedListener.onAdClosed();
                }
            }
        }
    }

    private void fetchAd(Boolean b, AdmobAdManager.OnAdClosedListener adClosedListener) {
        if (preferencesManager.getOpenAdEnable()) {
            if (isAdAvailable() || isLoading) {
                if (adClosedListener != null) {
                    adClosedListener.onAdClosed();
                }
                return;
            }
            isLoading = true;
            loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(AppOpenAd appOpenAds) {
                    super.onAdLoaded(appOpenAds);
                    appOpenAd = appOpenAds;
                    isLoading = false;
                    if (b) {
                        showAdIfAvailable();
                    } else {
                        if (adClosedListener != null) {
                            adClosedListener.onAdClosed();
                        }
                    }
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    isLoading = false;
                    if (adClosedListener != null) {
                        adClosedListener.onAdClosed();
                    }
                }

            };
            AdRequest request = get();
            AppOpenAd.load(
                    myApplication, preferencesManager.getOpenAdId(), request,
                    AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback
            );
        } else {
            if (adClosedListener != null) {
                adClosedListener.onAdClosed();
            }
        }
    }


    void showAdIfAvailable() {
        if (!isShowingAd) {
            if (isAdAvailable()) {
                FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        super.onAdFailedToShowFullScreenContent(adError);
                        Log.d("LOG_TAG", "Error display show ad." + adError.getMessage());
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent();
                        isShowingAd = true;
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent();
                        appOpenAd = null;
                        isShowingAd = false;
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                    }
                };
                appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
                appOpenAd.show(currentActivity);
            } else {
                fetchAd(true, null);
            }
        }
    }

    public void showAdIfAvailable(AdmobAdManager.OnAdClosedListener onAdClosedListener) {
        Variables.isSPermissionScreen = false;
        if (!isShowingAd) {
            if (isAdAvailable()) {
                FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        super.onAdFailedToShowFullScreenContent(adError);
                        onAdClosedListener.onAdClosed();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent();
                        isShowingAd = true;
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent();
                        appOpenAd = null;
                        isShowingAd = false;
                        onAdClosedListener.onAdClosed();
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                    }
                };
                appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
                appOpenAd.show(currentActivity);
            } else {
                fetchAd(true, null);
                onAdClosedListener.onAdClosed();
            }
        } else
            onAdClosedListener.onAdClosed();
    }


    AdRequest get() {
        return new AdRequest.Builder().build();
    }

    public Boolean isAdAvailable() {
        return appOpenAd != null;
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        currentActivity = activity;
        if (currentActivity.getLocalClassName() != null)
            Log.d("Data", "onActivityStarted: ====>" + currentActivity.getLocalClassName());
        if (++activityReferences == 1 && !isActivityChangingConfigurations) {

        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        isActivityChangingConfigurations = activity.isChangingConfigurations();
        if (--activityReferences == 0 && !isActivityChangingConfigurations) {
            if (currentActivity.getLocalClassName() != null)
                if (!isAdAvailable() && !Variables.isSplashScreen && !Variables.isSPermissionScreen && !currentActivity.getLocalClassName().equals("com.calldorado.ui.settings.SettingsActivity") && !currentActivity.getLocalClassName().equals("com.calldorado.ui.aftercall.CallerIdActivity")) {
                    fetchAd(false, null);
                }
        }
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        currentActivity = null;
    }
}
