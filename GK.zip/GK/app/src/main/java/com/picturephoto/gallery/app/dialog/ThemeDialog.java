package com.picturephoto.gallery.app.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Window;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.databinding.DialogThemeBinding;
import com.picturephoto.gallery.app.fragment.ThemeFragment;
import com.picturephoto.gallery.app.interfaces.SelectPathListener;
import com.picturephoto.gallery.app.model.ThemeModel;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

import java.util.ArrayList;

public class ThemeDialog extends Dialog {

    Context context;
    DialogThemeBinding binding;
    FragmentManager fragmentManager;
    ArrayList<ThemeModel> themeList = new ArrayList<>();
    ThemePagerAdapter adapter;
    PreferencesManager preferencesManager;
    SelectPathListener listener;

    public ThemeDialog(@NonNull Context context, FragmentManager fm, SelectPathListener listener) {
        super(context);
        this.context = context;
        this.fragmentManager = fm;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        binding = DialogThemeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//

//
        preferencesManager = PreferencesManager.getInstance(context);
//        adapter = new ThemePagerAdapter(fragmentManager, themeList);
//        binding.viewpager.setAdapter(adapter);
//        binding.viewpager.setCurrentItem(preferencesManager.getTheme());

        binding.btnSet.setOnClickListener(view -> {
            int p = preferencesManager.getTheme();
            if (p != binding.viewpager.getCurrentItem()){
                preferencesManager.setTheme(p);
                listener.selectPath("");
            }
            Toast.makeText(context, context.getString(R.string.Theme)+" "
                    +themeList.get(binding.viewpager.getCurrentItem()).getName()
                    +" " +context.getString(R.string.selected), Toast.LENGTH_SHORT).show();
            dismiss();
        });

        binding.btnCancel.setOnClickListener(view -> {
            dismiss();
        });
    }

    private class ThemePagerAdapter extends FragmentPagerAdapter {
        ArrayList<ThemeModel> themeList = new ArrayList<>();

        public ThemePagerAdapter(@NonNull FragmentManager fm, ArrayList<ThemeModel> themeList) {
            super(fm);
            this.themeList = themeList;
        }


        @NonNull
        @Override
        public Fragment getItem(int position) {
            return ThemeFragment.newInstance(position);
        }

        @Override
        public int getCount() {
            return themeList.size();
        }

//        @Override
//        public float getPageWidth(int position) {
//            DisplayMetrics metrics = context.getResources().getDisplayMetrics();
//            if ((metrics.widthPixels / metrics.density) > 900) {
//                return (0.5f);
//            }
//            return super.getPageWidth(position);
//        }
    }

}
