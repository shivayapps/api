package com.picturephoto.gallery.app.preferences;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.picturephoto.gallery.app.BuildConfig;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.utils.Constant;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PreferencesManager {
    SharedPreferences preferences;
    Context context;
    private static PreferencesManager sInstance;

    public static PreferencesManager getInstance(final Context context) {
        if (sInstance == null) {
            synchronized (PreferencesManager.class) {
                if (sInstance == null) {
                    sInstance = new PreferencesManager(context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    public PreferencesManager(Context context1) {
        context = context1;
        preferences = context.getSharedPreferences(Constant.SHARED_PREFS, Context.MODE_PRIVATE);
    }


    public void putRate(boolean rate) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Constant.SHARED_PREFS_RATE, rate);
        editor.apply();
    }

    public boolean getRate() {
        return preferences.getBoolean(Constant.SHARED_PREFS_RATE, false);
    }

    public void putSubscription(Context context, boolean value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Constant.SHARED_PREFS_SUBSCRIPTION, value);
        editor.apply();
    }

    public boolean getSubscription(Context context) {
        return preferences.getBoolean(Constant.SHARED_PREFS_SUBSCRIPTION, false);
    }

    public void saveLanguage(int value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_LANGUAGE, value);
        editor.apply();
    }

    public int getLanguage() {
        return preferences.getInt(Constant.SHARED_PREFS_LANGUAGE, 0);
    }

    public void putPurchaseDate(Context context, String value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(Constant.SHARED_PREFS_SUBSCRIPTION_DATE, value);
        editor.commit();

    }

    public String getPurchaseDate(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(
                Constant.SHARED_PREFS, Context.MODE_PRIVATE);
        return preferences.getString(Constant.SHARED_PREFS_SUBSCRIPTION_DATE, "");
    }


    public void setTheme(int theme) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_THEME, theme);
        editor.apply();
    }

    public int getTheme() {
        return preferences.getInt(Constant.SHARED_PREFS_THEME, 0);
    }


    public void setGridPhoto(int grid) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_GRID, grid);
        editor.apply();
    }

    public int getGridPhoto() {
        return preferences.getInt(Constant.SHARED_PREFS_GRID, 3);
    }

    public void setAlbumType(int type) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_Album_type, type);
        editor.apply();
    }

    public int getAlbumType() {
        return preferences.getInt(Constant.SHARED_PREFS_Album_type, 2);
    }

    public void setSlideShowTime(int time) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_SLIDESHOW_TIME, time);
        editor.apply();
    }

    public int getSlideShowTime() {
        return preferences.getInt(Constant.SHARED_PREFS_SLIDESHOW_TIME, 3 * 1000);
    }

    public void setGridAlbum(int grid) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_ALBUM_GRID, grid);
        editor.apply();
    }

    public int getGridAlbum() {
        return preferences.getInt(Constant.SHARED_PREFS_ALBUM_GRID, 2);
    }

    public void putLabelShow(boolean show) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Constant.SHARED_PREFS_LABEL, show);
        editor.apply();
    }

    public boolean getLabelShow() {
        return preferences.getBoolean(Constant.SHARED_PREFS_LABEL, false);
    }

    public void putExitDialogShow(boolean show) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Constant.SHARED_PREFS_EXIT_DIALOG, show);
        editor.apply();
    }

    public boolean getExitDialogShow() {
        return preferences.getBoolean(Constant.SHARED_PREFS_EXIT_DIALOG, true);
    }


    public void putFastScroll(boolean show) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Constant.SHARED_PREFS_FAST_SCROLL, show);
        editor.apply();
    }

    public boolean getFastScroll() {
        return preferences.getBoolean(Constant.SHARED_PREFS_FAST_SCROLL, true);
    }

    public void setFilterTypePhoto(int filterType) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_FILTER_PHOTOS, filterType);
        editor.apply();
    }

    public int getFilterTypePhoto() {
        return preferences.getInt(Constant.SHARED_PREFS_FILTER_PHOTOS, 0);
    }

    public void setSortPhoto(int sortType) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_SORT_PHOTOS, sortType);
        editor.apply();
    }

    public int getSortPhoto() {
        return preferences.getInt(Constant.SHARED_PREFS_SORT_PHOTOS, 1);
    }

    public void setSortTypePhoto(boolean isDescending) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Constant.SHARED_PREFS_SORT_TYPE_PHOTOS, isDescending);
        editor.apply();
    }

    public boolean getSortTypePhoto() {
        return preferences.getBoolean(Constant.SHARED_PREFS_SORT_TYPE_PHOTOS, true);
    }

    public void setSortAlbum(int sortType) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_SORT_ALBUM, sortType);
        editor.apply();
    }

    public int getSortAlbum() {
        return preferences.getInt(Constant.SHARED_PREFS_SORT_ALBUM, 2);
    }

    public void setSortTypeAlbum(boolean isDescending) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Constant.SHARED_PREFS_SORT_TYPE_ALBUM, isDescending);
        editor.apply();
    }

    public boolean getSortTypeAlbum() {
        return preferences.getBoolean(Constant.SHARED_PREFS_SORT_TYPE_ALBUM, true);
    }

    public List<String> getFavoriteList() {
        List<String> list = new ArrayList<>();
        try {
            String response = preferences.getString(Constant.SHARED_PREFS_FAVORITE_LIST, "");
            Gson gson = new Gson();
            Type type = new TypeToken<List<String>>() {
            }.getType();
            list = gson.fromJson(response, type);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void setFavoriteList(List<String> list) {
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(Constant.SHARED_PREFS_FAVORITE_LIST, json);
        editor.apply();
    }

    public List<String> getExcludeFolderList() {
        List<String> list = new ArrayList<>();
        try {
            String response = preferences.getString(Constant.SHARED_PREFS_ExcludeFolder_LIST, "");
            Gson gson = new Gson();
            Type type = new TypeToken<List<String>>() {
            }.getType();
            list = gson.fromJson(response, type);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (list == null)
            list = new ArrayList<>();
        return list;
    }

    public void setExcludeFolderList(List<String> list) {
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(Constant.SHARED_PREFS_ExcludeFolder_LIST, json);
        editor.apply();
    }

    public List<String> getPinFolderList() {
        List<String> list = new ArrayList<>();
        try {
            String response = preferences.getString(Constant.SHARED_PREFS_PIN_ALBUM_LIST, "");
            Gson gson = new Gson();
            Type type = new TypeToken<List<String>>() {
            }.getType();
            list = gson.fromJson(response, type);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (list == null)
            list = new ArrayList<>();
        return list;
    }

    public void setPinFolderList(List<String> list) {
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(Constant.SHARED_PREFS_PIN_ALBUM_LIST, json);
        editor.apply();
    }

    public String getPass() {
        return preferences.getString(Constant.PREF_PASSCODE, "");
    }

    public void putPass(String security_answer) {
        preferences.edit().putString(Constant.PREF_PASSCODE, security_answer).apply();
    }

    public boolean getSetPass() {
        return preferences.getBoolean(Constant.PREF_PASSCODE_SET, false);
    }

    public void putSetPass(boolean set_pass) {
        preferences.edit().putBoolean(Constant.PREF_PASSCODE_SET, set_pass).apply();
    }

    public boolean getSetLockApp() {
        return preferences.getBoolean(Constant.PREF_LOCK_APP, false);
    }

    public void putSetLockApp(boolean set_pass) {
        preferences.edit().putBoolean(Constant.PREF_LOCK_APP, set_pass).apply();
    }

    public boolean getFingerprint() {
        return preferences.getBoolean(Constant.PREF_Fingerprint, false);
    }

    public void putFingerprint(boolean set_pass) {
        preferences.edit().putBoolean(Constant.PREF_Fingerprint, set_pass).apply();
    }

    public boolean getStoragePermission11() {
        return preferences.getBoolean(Constant.PREF_STORAGE_PERMISSION, false);
    }

    public void putStoragePermission11(boolean isPermission) {
        preferences.edit().putBoolean(Constant.PREF_STORAGE_PERMISSION, isPermission).apply();
    }

    public boolean getSetQuestion() {
        return preferences.getBoolean(Constant.PREF_SECURITY_SET, false);
    }

    public void putSetQuestion(boolean set_question) {
        preferences.edit().putBoolean(Constant.PREF_SECURITY_SET, set_question).apply();
    }

    public String getSecurityQuestion() {
        return preferences.getString(Constant.PREF_SECURITY_QUESTION, "");
    }

    public void putSecurityQuestion(String security_question) {
        preferences.edit().putString(Constant.PREF_SECURITY_QUESTION, security_question).apply();
    }

    public String getAnswerQuestion() {
        return preferences.getString(Constant.PREF_SECURITY_ANS, "");
    }

    public void putAnswerQuestion(String security_answer) {
        preferences.edit().putString(Constant.PREF_SECURITY_ANS, security_answer).apply();
    }

    public String getHideUri() {
        return preferences.getString(Constant.PREF_HIDDEN_URI, "");
    }

    public void putHideUri(String value) {
        preferences.edit().putString(Constant.PREF_HIDDEN_URI, value).apply();
    }

    public boolean getPrivacy() {
        return preferences.getBoolean(Constant.PREF_PRIVACY, false);
    }

    public void putPrivacy(boolean set_pass) {
        preferences.edit().putBoolean(Constant.PREF_PRIVACY, set_pass).apply();
    }

    public void putUriWp(String location) {
        preferences.edit().putString(Constant.PREF_WP_STATUS, location).apply();
    }

    public String getUriWp() {
        return preferences.getString(Constant.PREF_WP_STATUS, "");
    }

    public void setStartPage(int pageNo) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(Constant.SHARED_PREFS_START_PAGE, pageNo);
        editor.apply();
    }

    public int getStartPage() {
        return preferences.getInt(Constant.SHARED_PREFS_START_PAGE, 0);
    }

    public List<PictureData> getRecentList() {

        List<PictureData> list = new ArrayList<>();
        try {
            String response = preferences.getString(Constant.SHARED_PREFS_RECENT_LIST, "");
            Gson gson = new Gson();
            Type type = new TypeToken<List<PictureData>>() {
            }.getType();
            list = gson.fromJson(response, type);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (list == null)
            list = new ArrayList<>();
        return list;
    }

    public void setRecentList(List<PictureData> list) {
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(Constant.SHARED_PREFS_RECENT_LIST, json);
        editor.apply();
    }

    public void saveAdIds(JSONObject json) {
        SharedPreferences.Editor editor = preferences.edit();
        try {
            editor.putString(Constant.SHARED_PREFS_APP_ID, json.getString(Constant.SHARED_PREFS_APP_ID));
            editor.putBoolean(Constant.BANNER_ADS_ENABLE, json.getBoolean(Constant.BANNER_ADS_ENABLE));
            editor.putString(Constant.BANNER_ONE, json.getString(Constant.BANNER_ONE));
            editor.putString(Constant.BANNER_TWO, json.getString(Constant.BANNER_TWO));
            editor.putString(Constant.BANNER_THREE, json.getString(Constant.BANNER_THREE));
            editor.putBoolean(Constant.INTERSTITIAL_ADS_ENABLE, json.getBoolean(Constant.INTERSTITIAL_ADS_ENABLE));
            editor.putBoolean(Constant.INTERSTITIAL_BACK_ADS_ENABLE, json.has(Constant.INTERSTITIAL_BACK_ADS_ENABLE) ? json.getBoolean(Constant.INTERSTITIAL_BACK_ADS_ENABLE) : true);
            editor.putString(Constant.INTERSTITIAL_ONE, json.getString(Constant.INTERSTITIAL_ONE));
            editor.putString(Constant.INTERSTITIAL_TWO, json.getString(Constant.INTERSTITIAL_TWO));
            editor.putInt(Constant.ADMOB_INTERSTITIAL_FREQUENCY, json.getInt(Constant.ADMOB_INTERSTITIAL_FREQUENCY));
            editor.putInt(Constant.ADMOB_INTERSTITIAL_FREQUENCY_BACK, json.getInt(Constant.ADMOB_INTERSTITIAL_FREQUENCY_BACK));
            editor.putBoolean(Constant.SPLASH_ADS_ENABLE, json.getBoolean(Constant.SPLASH_ADS_ENABLE));
            editor.putString(Constant.SPLASH, json.getString(Constant.SPLASH));
            editor.putString(Constant.INTERSTITIAL_SPLASH_ID, json.getString(Constant.INTERSTITIAL_SPLASH_ID));
            editor.putBoolean(Constant.OPENAPP_ADS_ENABLE, json.getBoolean(Constant.OPENAPP_ADS_ENABLE));
            editor.putString(Constant.OPEN_APP_ID, json.getString(Constant.OPEN_APP_ID));
            editor.putBoolean(Constant.NATIVE, json.getBoolean(Constant.NATIVE));
            editor.putString(Constant.NATIVE_ID, json.getString(Constant.NATIVE_ID));
            editor.putInt(Constant.NATIVE_ADS_FREQUENCY, json.getInt(Constant.NATIVE_ADS_FREQUENCY));
            editor.apply();
        } catch (JSONException ignored) {
        }
    }

    public String getAppId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_app_id) : preferences.getString(Constant.SHARED_PREFS_APP_ID, context.getResources().getString(R.string.admob_app_id));
    }

    public Boolean getBannerAdEnable() {
        return preferences.getBoolean(Constant.BANNER_ADS_ENABLE, true);
    }

    public String getBannerOneId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_banner) : preferences.getString(Constant.BANNER_ONE, context.getResources().getString(R.string.admob_banner));
    }

    public String getBannerTwoId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_banner) : preferences.getString(Constant.BANNER_TWO, context.getResources().getString(R.string.admob_banner));
    }

    public String getBannerThreeId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_banner) : preferences.getString(Constant.BANNER_THREE, context.getResources().getString(R.string.admob_banner));
    }

    public Boolean getInterstitialAdEnable() {
        return preferences.getBoolean(Constant.INTERSTITIAL_ADS_ENABLE, true);
    }

    public Boolean getInterstitialBackAdEnable() {
        return preferences.getBoolean(Constant.INTERSTITIAL_BACK_ADS_ENABLE, true);
    }

    public String getInterstitialOneId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_interstitial) : preferences.getString(Constant.INTERSTITIAL_ONE, context.getResources().getString(R.string.admob_interstitial));
    }

    public String getInterstitialTwoId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_interstitial) : preferences.getString(Constant.INTERSTITIAL_TWO, context.getResources().getString(R.string.admob_interstitial));
    }

    public int getInterstitialFrequency() {
        return preferences.getInt(Constant.ADMOB_INTERSTITIAL_FREQUENCY, 3);
    }

    public int getInterstitialFrequencyBack() {
        return preferences.getInt(Constant.ADMOB_INTERSTITIAL_FREQUENCY_BACK, 3);
    }

    public Boolean getSplashAdEnable() {
        return preferences.getBoolean(Constant.SPLASH_ADS_ENABLE, true);
    }

    public String getSplashAdType() {
        return preferences.getString(Constant.SPLASH, "openapp");
    }

    public String getInterstitialSplashId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_interstitial) : preferences.getString(Constant.INTERSTITIAL_SPLASH_ID, context.getResources().getString(R.string.admob_interstitial));
    }

    public Boolean getOpenAdEnable() {
        return preferences.getBoolean(Constant.OPENAPP_ADS_ENABLE, true);
    }

    public String getOpenAdId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_open) : preferences.getString(Constant.OPEN_APP_ID, context.getResources().getString(R.string.admob_open));
    }

    public Boolean getNativeAdEnable() {
        return preferences.getBoolean(Constant.NATIVE, true);
    }

    public String getNativeAdId() {
        return BuildConfig.DEBUG ? context.getResources().getString(R.string.admob_native) : preferences.getString(Constant.NATIVE_ID, context.getResources().getString(R.string.admob_native));
    }

    public int getNativeFrequency() {
        return preferences.getInt(Constant.NATIVE_ADS_FREQUENCY, 3);
    }
}
