package com.picturephoto.gallery.app.event;

public class AlbumDataEvent {
}
