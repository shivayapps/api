package com.picturephoto.gallery.app.custom;

import android.app.Activity;
import android.view.View;

import com.picturephoto.gallery.app.ads.AdmobAdManager;

public class BackClickListener implements View.OnClickListener {
    AdmobAdManager admobAdManager;
    Activity activity;
    AdmobAdManager.OnAdClosedListener onAdClosedListener;

    public BackClickListener(Activity activity, AdmobAdManager admobAdManager, AdmobAdManager.OnAdClosedListener onAdClosedListener) {
        this.activity = activity;
        this.admobAdManager = admobAdManager;
        this.onAdClosedListener = onAdClosedListener;
    }

    @Override
    public void onClick(View view) {
        admobAdManager.loadInterstitialBackAd(activity, 2, () -> onAdClosedListener.onAdClosed());
    }
}