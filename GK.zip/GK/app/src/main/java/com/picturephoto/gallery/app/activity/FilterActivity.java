package com.picturephoto.gallery.app.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.FilterAdapter;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityFilterBinding;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import iamutkarshtiwari.github.io.ananas.editimage.fliter.PhotoProcessing;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FilterActivity extends AppCompatActivity {

    ActivityFilterBinding binding;
    FilterAdapter filterAdapter;
    String imagePath = "";
    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    int apply = 0;

    Bitmap imageBitmap;
    private Bitmap filterBitmap;
    PreferencesManager preferencesManager;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFilterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        imagePath = getIntent().getStringExtra("EditImage");
        Glide.with(this)
                .load(imagePath)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into(binding.ivDisplay);

        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inMutable = true;
        imageBitmap = BitmapFactory.decodeFile(imagePath, bmOptions);

        intAdapter();
        intClickListener();
        setFilter(apply);
    }


    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialBackAd(this, 2, () ->  finish());
    }

    private void intClickListener() {
        binding.icBack.setOnClickListener(view -> {
            onBackPressed();
        });

        binding.icDone.setOnClickListener(view -> {
            String imagePath = saveImage();
            if (imagePath != null) {
                Intent intent = new Intent();
                intent.putExtra("imagePath", imagePath);
                setResult(RESULT_OK, intent);
            }
            finish();
        });
    }

    private String saveImage() {
        File dir = new File(getCacheDir().getAbsolutePath());
        if (!dir.exists())
            dir.mkdirs();

        Bitmap bitmap;
        if (filterBitmap != null) {
            bitmap = filterBitmap;
        } else {
            bitmap = imageBitmap;
        }

        String timeStamp = new SimpleDateFormat("HHmmss_dMyy").format(new Date());
        String imageName = "IMG_" + timeStamp + ".jpg";
        File pictureFile = new File(dir.getPath() + "/" + imageName);

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(pictureFile.getPath());
            bitmap.compress(Bitmap.CompressFormat.WEBP, 70, out);

            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            Uri contentUri = Uri.fromFile(pictureFile);
            mediaScanIntent.setData(contentUri);
            sendBroadcast(mediaScanIntent);

            MediaScannerConnection.scanFile(FilterActivity.this, new String[]{pictureFile.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });
            return pictureFile.getPath();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }


    private void intAdapter() {
        filterAdapter = new FilterAdapter(getApplicationContext());
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        binding.recyclerView.setLayoutManager(layoutManager);
        binding.recyclerView.setAdapter(filterAdapter);

        filterAdapter.setListner(position -> {
            if (binding.ivLoading.getVisibility() == View.GONE)
                setFilter(position);
            else
                filterAdapter.setSelect(apply);
        });
    }

    private void setFilter(int position) {
        compositeDisposable.clear();
        apply = position;
        Disposable applyFilterDisposable = applyFilter(position, imageBitmap)
                .subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(subscriber -> binding.ivLoading.setVisibility(View.VISIBLE))
                .doFinally(() -> binding.ivLoading.setVisibility(View.GONE))
                .subscribe(
                        bitmap -> {
                            updatePreviewWithFilter(bitmap);
                        },
                        e -> showSaveErrorToast(e)
                );

        compositeDisposable.add(applyFilterDisposable);
    }

    private void updatePreviewWithFilter(Bitmap bitmapWithFilter) {
        if (bitmapWithFilter == null) return;

        if (filterBitmap != null && (!filterBitmap.isRecycled())) {
            filterBitmap.recycle();
        }

        filterBitmap = bitmapWithFilter;
        binding.ivDisplay.setImageBitmap(filterBitmap);
    }

    private void showSaveErrorToast(Throwable e) {
        Toast.makeText(getApplicationContext(), getString(R.string.Save_error), Toast.LENGTH_SHORT).show();
    }

    private Single<Bitmap> applyFilter(int filterIndex, Bitmap mainBitmao) {
        return Single.fromCallable(() -> {

            Bitmap srcBitmap = Bitmap.createBitmap(mainBitmao.copy(
                    Bitmap.Config.RGB_565, true));
            return PhotoProcessing.filterPhoto(srcBitmap, filterIndex);
        });
    }
}