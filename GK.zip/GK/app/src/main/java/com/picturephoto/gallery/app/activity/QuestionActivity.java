package com.picturephoto.gallery.app.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.Spinner_Adapter;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityQuestionBinding;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

public class QuestionActivity extends AppCompatActivity {

    ActivityQuestionBinding binding;
    int type = 0;
    PreferencesManager preferencesManager;
    boolean isOpenPrivate = false;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuestionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this,  binding.loutBanner, true, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.view.setVisibility(View.GONE);
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
                binding.view.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
                binding.view.setVisibility(View.GONE);
            }
        });
    }
    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        if (getIntent() != null) {
            isOpenPrivate = getIntent().getBooleanExtra("isOpenPrivate", false);
            type = getIntent().getIntExtra("type", 0);
        }

        Spinner_Adapter spinner_adapter = new Spinner_Adapter(this, getResources().getStringArray(R.array.security_question));
        binding.questionSpinner.setAdapter(spinner_adapter);
        if (type == 1) {
            if (!preferencesManager.getSecurityQuestion().equals(""))
                binding.questionSpinner.setSelection(Integer.parseInt(preferencesManager.getSecurityQuestion()));
            binding.title.setText(getString(R.string.ChangePassword));
        }


        binding.ivBack.setOnClickListener(view -> {
            onBackPressed();
        });
        binding.saveQuestion.setOnClickListener(view -> {
            String answer = binding.securityAnswer.getText().toString();
            if (binding.questionSpinner.getSelectedItemPosition() == 0)
                Toast.makeText(QuestionActivity.this, getString(R.string.PleaseSelectQue), Toast.LENGTH_SHORT).show();
            else if (TextUtils.isEmpty(answer)) {
                Toast.makeText(QuestionActivity.this, getString(R.string.PleaseSelectQue), Toast.LENGTH_SHORT).show();
            } else {
                hideSoftKeyboard();
                if (!preferencesManager.getSetQuestion()) {
                    preferencesManager.putSetQuestion(true);
                    preferencesManager.putSecurityQuestion(String.valueOf(binding.questionSpinner.getSelectedItemPosition()));
                    preferencesManager.putAnswerQuestion(answer);
                    preferencesManager.putSetPass(true);
//                    setImage();
                    if (isOpenPrivate)
                        startActivity(new Intent(this, PrivateActivity.class));
                    setResult(RESULT_OK);
                    finish();
                } else {
                    if (binding.questionSpinner.getSelectedItemPosition() == Integer.parseInt(preferencesManager.getSecurityQuestion())) {
                        if (preferencesManager.getAnswerQuestion().equals(answer)) {
                            preferencesManager.putSetPass(false);
                            preferencesManager.putPass("");

                            startActivity(new Intent(this, PasswordActivity.class).putExtra("resetPass", true));
                            setResult(RESULT_OK);
                            finish();
                        } else {
                            Toast.makeText(QuestionActivity.this, R.string.msg_security_ans, Toast.LENGTH_SHORT).show();
                        }
                    } else
                        Toast.makeText(QuestionActivity.this, R.string.msg_security_que, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialBackAd(this, 2, () ->  finish());
    }


    public void hideSoftKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(binding.securityAnswer.getWindowToken(), 0);
    }

}