package com.picturephoto.gallery.app.utils

import java.io.IOException

class DirectoryHierarchyBroken(message: String?): IOException(message) {
}