package com.picturephoto.gallery.app.fragment;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.activity.AlbumImageActivity;
import com.picturephoto.gallery.app.activity.ImageShowActivity;
import com.picturephoto.gallery.app.adapter.AlbumAdapter;
import com.picturephoto.gallery.app.databinding.FragmentAlbumBinding;
import com.picturephoto.gallery.app.event.AlbumDataEvent;
import com.picturephoto.gallery.app.event.CopyMoveEvent;
import com.picturephoto.gallery.app.event.CountShowEvent;
import com.picturephoto.gallery.app.event.DeleteEvent;
import com.picturephoto.gallery.app.event.DisplayDeleteEvent;
import com.picturephoto.gallery.app.event.EditImageEvent;
import com.picturephoto.gallery.app.event.SettingEvent;
import com.picturephoto.gallery.app.event.UnHideDataEvent;
import com.picturephoto.gallery.app.event.UnHideEvent;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.FilterSettingUpdate;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.model.RenameEvent;
import com.picturephoto.gallery.app.model.RenameModel;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.Constant;

import java.io.File;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import io.reactivex.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class AlbumFragment extends Fragment {

    FragmentAlbumBinding binding;
    public ArrayList<AlbumData> albumList = new ArrayList<>();
    public ArrayList<AlbumData> albumBackUpList = new ArrayList<>();
    AlbumAdapter albumAdapter;
    public int albumCount = 0;
    PreferencesManager preferencesManager;
    int sortBy = 0;
    boolean sortType = true;
    Activity context;

    public AlbumFragment() {
    }

    public AlbumFragment(Activity c) {
        context = c;
    }

    public static AlbumFragment newInstance(Activity c) {
        AlbumFragment fragment = new AlbumFragment(c);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        filterAndSortEvent();
        CopyMoveEvent();
        UnHideEvent();
        DisplayDeleteEvent();
        DeleteEvent();
        albumDataEvent();
        settingEvent();
        renameEvent();
        editEvent();
    }

    private void editEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(EditImageEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<EditImageEvent>() {
            @Override
            public void call(EditImageEvent event) {
                requireActivityContext().runOnUiThread(() -> {
                    if (albumAdapter != null)
                        albumAdapter.notifyDataSetChanged();
                    else
                        initAdapter();
                });
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAlbumBinding.inflate(getLayoutInflater(), container, false);
        intView();
        return binding.getRoot();
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(requireActivityContext());
        intSortValue();
        initAdapter();
        getData();
        binding.swipeRefreshLayout.setOnRefreshListener(this::getData);
    }

    private void intSortValue() {
        sortBy = preferencesManager.getSortAlbum();
        sortType = preferencesManager.getSortTypeAlbum();
    }

    private void initAdapter() {
        binding.swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_orange_light,
                android.R.color.holo_green_light);
        albumAdapter = new AlbumAdapter(requireActivity(), albumList, new AlbumAdapter.OnSelectAlbum() {
            @Override
            public void onClickAlbum(int pos) {
                Constant.albumData = albumList.get(pos);
                startActivity(new Intent(context, AlbumImageActivity.class));
                Constant.albumList = new ArrayList<>();
                Constant.albumList.addAll(albumList);
            }

            @Override
            public void onClickMenu(int pos, View view) {
                openAlbumMenu(pos, view);
            }
        });

        int grid = preferencesManager.getAlbumType();
        if (grid == 1 || grid == 4)
            grid = 1;
        else
            grid = preferencesManager.getGridAlbum();
        binding.albumRecycler.setLayoutManager(new GridLayoutManager(context, grid, RecyclerView.VERTICAL, false));
        binding.albumRecycler.setAdapter(albumAdapter);
    }

    private void openAlbumMenu(int pos, View view) {
        PopupMenu popup = new PopupMenu(context, view);
        popup.getMenuInflater().inflate(R.menu.menu_album, popup.getMenu());
        if (albumList.get(pos).isPin())
            popup.getMenu().findItem(R.id.menu_PinAlbum).setTitle(getString(R.string.UnpinAlbum));
        else
            popup.getMenu().findItem(R.id.menu_PinAlbum).setTitle(getString(R.string.PinAlbum));
        popup.show();

        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.menu_PinAlbum) {
                List<String> pinList = new ArrayList<>();
                pinList.addAll(preferencesManager.getPinFolderList());

                if (albumList.get(pos).isPin()) {
                    pinList.remove(albumList.get(pos).getFolderPath());
                    albumList.get(pos).setPin(false);
                } else {
                    pinList.add(albumList.get(pos).getFolderPath());
                    albumList.get(pos).setPin(true);
                }

                setPinData(albumList.get(pos));
                preferencesManager.setPinFolderList(pinList);

            } else if (item.getItemId() == R.id.menu_Slideshow) {
                AlbumData albumData = albumList.get(pos);
                Constant.displayImageList = new ArrayList<>();
                Constant.displayImageList.addAll(albumData.getPictureData());
                Intent intent = new Intent(context, ImageShowActivity.class);
                intent.putExtra("pos", 0);
                intent.putExtra("IsPrivateList", false);
                intent.putExtra("IsFavList", false);
                intent.putExtra("IsShowSlideShow", true);
                startActivity(intent);
            } else if (item.getItemId() == R.id.menu_ExcludeFolder) {
                showExcludeFolder(pos);
            }
            return true;
        });
    }

    private void setPinData(AlbumData albumData) {
        if (albumData.isPin()) {
            Collections.sort(albumList, (p1, p2) -> {
                return Boolean.compare(p2.isPin(), p1.isPin());
            });
        } else {
            sortAlbumMain();
        }

        if (albumAdapter != null)
            albumAdapter.notifyDataSetChanged();
        else
            initAdapter();

        for (AlbumData data : albumBackUpList) {
            if (data.getFolderPath().equals(albumData.getFolderPath())) {
                data.setPin(albumData.isPin());
                break;
            }
        }
        Collections.sort(albumBackUpList, (p1, p2) -> {
            return Boolean.compare(p2.isPin(), p1.isPin());
        });
    }

    private void showExcludeFolder(int pos) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.ExcludeFolder);
        builder.setMessage(R.string.ExcludeFolderMsg);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.action_Exclude, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                List<String> folderList = new ArrayList();
                folderList.addAll(preferencesManager.getExcludeFolderList());
                String folderPath = albumList.get(pos).getFolderPath();
                if (!folderList.contains(folderPath))
                    folderList.add(folderPath);

                preferencesManager.setExcludeFolderList(folderList);
                albumList.remove(pos);
                if (albumAdapter != null)
                    albumAdapter.notifyDataSetChanged();
                else initAdapter();
                removeAlbum(folderPath);

                RxBus.getInstance().post(new SettingEvent(1, true));
            }
        });
        builder.setNegativeButton(getString(R.string.action_Cancel), (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(context, R.color.gray_600));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(context, R.color.theme_color));
    }

    private void removeAlbum(String folderPath) {
        for (AlbumData albumData : albumBackUpList) {
            if (albumData.getFolderPath().equals(folderPath)) {
                albumBackUpList.remove(albumData);
                break;
            }
        }
    }

    private void setData() {
        binding.swipeRefreshLayout.setRefreshing(false);
        if (albumAdapter != null)
            albumAdapter.notifyDataSetChanged();
        else
            initAdapter();
        RxBus.getInstance().post(new CountShowEvent());
        setEmptyData();
    }

    private void setEmptyData() {
        if (albumList != null && albumList.size() != 0) {
            binding.albumRecycler.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.albumRecycler.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    public Activity requireActivityContext() {
        return context;
    }


    private void sortData() {
        binding.swipeRefreshLayout.setRefreshing(true);
        Observable.fromCallable(() -> {
                    sortAlbum();
                    return true;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    context.runOnUiThread(() -> {
                        setData();
                    });
                })
                .subscribe((result) -> {
                    requireActivityContext().runOnUiThread(() -> {
                        setData();
                    });
                });
    }

    private void getData() {
        binding.swipeRefreshLayout.setRefreshing(true);
        Observable.fromCallable(() -> {
                    getImages();
//                    getVideos();
//                    getImageOrVideo();
                    return true;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    requireActivityContext().runOnUiThread(() -> {
                        setData();
                    });
                })
                .subscribe((result) -> {
                    requireActivityContext().runOnUiThread(() -> {
                        setData();
                    });
                });
    }

    private void filterAndSortEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(FilterSettingUpdate.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<FilterSettingUpdate>() {
            @Override
            public void call(FilterSettingUpdate event) {
                if (!event.isPhotos()) {
                    intSortValue();
                    sortData();
                }
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void DeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DeleteEvent>() {
            @Override
            public void call(DeleteEvent event) {

                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();
                    updateDeleteImageData(deleteList);
                }
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void renameEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(RenameEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<RenameEvent>() {
            @Override
            public void call(RenameEvent event) {
                ArrayList<RenameModel> renameList = event.getRenameModels();
                if (renameList != null && renameList.size() != 0) {
                    for (RenameModel renameModel : renameList) {
                        if (renameModel.getRenameFile().exists()) {
                            boolean isChange = false;
                            for (AlbumData albumData : albumList) {
                                if (albumData.getPictureData() != null && albumData.getPictureData().size() != 0) {
                                    for (PictureData model : albumData.getPictureData()) {
                                        if (model.getFilePath().equalsIgnoreCase(renameModel.getOldFile().getPath())) {
                                            model.setFolderPath(renameModel.getRenameFile().getPath());
                                            model.setFileName(renameModel.getRenameFile().getName());
                                            isChange = true;
                                            break;
                                        }
                                    }
                                    if (isChange)
                                        break;
                                }
                            }

                            for (AlbumData albumData : albumBackUpList) {
                                if (albumData.getPictureData() != null && albumData.getPictureData().size() != 0) {
                                    for (PictureData model : albumData.getPictureData()) {
                                        if (model.getFilePath().equalsIgnoreCase(renameModel.getOldFile().getPath())) {
                                            model.setFolderPath(renameModel.getRenameFile().getPath());
                                            model.setFileName(renameModel.getRenameFile().getName());
                                            isChange = true;
                                            break;
                                        }
                                    }
                                    if (isChange)
                                        break;
                                }
                            }
                        }
                    }

                    requireActivityContext().runOnUiThread(() -> {
                        if (albumAdapter != null)
                            albumAdapter.notifyDataSetChanged();
                        else
                            initAdapter();
                    });
                }
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void settingEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(SettingEvent.class).subscribeOn(Schedulers.io()).
                observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<SettingEvent>() {
                    @Override
                    public void call(SettingEvent event) {
                        if (event.getType() == 1) {
                            setGridType();
                        } else if (event.getType() == 2 && !event.isAlbum()) {
                            getData();
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                    }
                });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    public void setGridType() {
//        int grid = preferencesManager.getAlbumType();
//        if (grid == 1 || grid == 4)
//            grid = 1;
//        else
//            grid = preferencesManager.getGridAlbum();
//        binding.albumRecycler.setLayoutManager(new GridLayoutManager(context, grid, RecyclerView.VERTICAL, false));
//
//        if (albumAdapter != null) {
//            albumAdapter.setAlbumType(preferencesManager.getAlbumType());
//        } else
        initAdapter();
    }

    private void albumDataEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(AlbumDataEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<AlbumDataEvent>() {
            @Override
            public void call(AlbumDataEvent event) {
                Constant.albumList = new ArrayList<>();
                Constant.albumList.addAll(albumList);
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void DisplayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {

            if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                ArrayList<String> deleteList;
                deleteList = event.getDeleteList();
                updateDeleteImageData(deleteList);
            }

        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void updateDeleteImageData(ArrayList<String> deleteList) {
        if (albumBackUpList != null && albumBackUpList.size() != 0) {
            for (int d = 0; d < deleteList.size(); d++) {
                for (int i = 0; i < albumBackUpList.size(); i++) {
                    if (albumBackUpList.get(i) != null) {
                        AlbumData photoHeader = albumBackUpList.get(i);
                        ArrayList<PictureData> photoList;
                        photoList = photoHeader.getPictureData();
                        if (photoList != null && photoList.size() != 0) {
                            for (int p = 0; p < photoList.size(); p++) {
                                if (deleteList.get(d).equalsIgnoreCase(photoList.get(p).getFilePath())) {
                                    photoList.remove(p);
                                    if (photoList.size() == 0) {
                                        albumBackUpList.remove(i);
                                        if (i != 0) {
                                            i--;
                                        }
                                    } else {
                                        photoHeader.setPictureData(photoList);
                                        albumBackUpList.set(i, photoHeader);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        if (albumList != null && albumList.size() != 0) {
            for (int d = 0; d < deleteList.size(); d++) {
                for (int i = 0; i < albumList.size(); i++) {
                    if (albumList.get(i) != null) {
                        AlbumData photoHeader = albumList.get(i);
                        ArrayList<PictureData> photoList;
                        photoList = photoHeader.getPictureData();
                        if (photoList != null && photoList.size() != 0) {
                            for (int p = 0; p < photoList.size(); p++) {
                                if (deleteList.get(d).equalsIgnoreCase(photoList.get(p).getFilePath())) {
                                    photoList.remove(p);
                                    if (photoList.size() == 0) {
                                        if (albumList.get(i).getFolderPath() != null) {
                                            File file = new File(albumList.get(i).getFolderPath());
                                            file.delete();
                                            MediaScannerConnection.scanFile(requireActivityContext(), new String[]{file.getPath()}, null, (path, uri) -> {
                                            });
                                        }
                                        albumList.remove(i);
                                        if (i != 0) {
                                            i--;
                                        }
                                    } else {
                                        photoHeader.setPictureData(photoList);
                                        albumList.set(i, photoHeader);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (albumAdapter != null) {
                albumAdapter.notifyDataSetChanged();
            }
            setEmptyData();
        }


    }

    private void CopyMoveEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(CopyMoveEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<CopyMoveEvent>() {
            @Override
            public void call(CopyMoveEvent event) {
                if (event.getCopyMoveList() != null && event.getCopyMoveList().size() != 0) {
                    ArrayList<String> imageList = new ArrayList<>();
                    imageList = event.getCopyMoveList();

                    if (imageList == null) {
                        imageList = new ArrayList<>();
                    }
                    File file = new File(event.getAlbumPath());

                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();
                    if (deleteList != null && deleteList.size() != 0) {
                        updateDeleteImageData(deleteList);
                    }
                    if (file.exists()) {
                        ArrayList<PictureData> imagesData1 = new ArrayList<>();
                        for (int i = 0; i < imageList.size(); i++) {
                            File file1 = new File(imageList.get(i));
                            if (file1.exists()) {
                                PictureData pictureData = new PictureData();
                                pictureData.setFilePath(file1.getPath());
                                pictureData.setFileName(file1.getName());
                                pictureData.setFolderName(file1.getParentFile().getName());
                                pictureData.setDate(file1.lastModified());
                                pictureData.setVideo(isVideoFile(file1.getPath()));
                                pictureData.setFileSize(file1.length());
                                imagesData1.add(pictureData);
                            }
                        }
                        boolean isAdd = false;
                        for (AlbumData albumData : albumBackUpList) {
                            if (albumData.getTitle().equalsIgnoreCase(file.getName())) {
                                ArrayList<PictureData> image = albumData.getPictureData();
                                if (image == null)
                                    image = new ArrayList<>();
                                image.addAll(imagesData1);
                                isAdd = true;
                            }
                        }

                        if (!isAdd) {
                            List<String> folderList = preferencesManager.getExcludeFolderList();
                            if (!folderList.contains(file.getPath())) {
                                List<String> pinList = preferencesManager.getPinFolderList();
                                AlbumData albumData = new AlbumData();
                                albumData.setTitle(file.getName());
                                albumData.setFolderPath(file.getPath());
                                albumData.setPictureData(imagesData1);
                                albumData.setPin(pinList.contains(file.getPath()));
                                albumBackUpList.add(albumData);
                            }
                        }

                        albumList.clear();
                        albumList.addAll(albumBackUpList);
                        sortData();
                    }
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void UnHideEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(UnHideDataEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<UnHideDataEvent>() {
            @Override
            public void call(UnHideDataEvent event) {
                if (event.getCopyMoveList() != null && event.getCopyMoveList().size() != 0) {
                    ArrayList<UnHideEvent> imageList = new ArrayList<>();
                    imageList = event.getCopyMoveList();

                    if (imageList == null) {
                        imageList = new ArrayList<>();
                    }


                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();
                    if (deleteList != null && deleteList.size() != 0) {
                        updateDeleteImageData(deleteList);
                    }
                    ArrayList<PictureData> imagesData1 = new ArrayList<>();
                    for (int i = 0; i < imageList.size(); i++) {
                        File file1 = new File(imageList.get(i).getCopyMoveList());
                        File file = new File(imageList.get(i).getAlbumPath());
                        if (file.exists())
                            if (file1.exists()) {
                                PictureData pictureData = new PictureData();
                                pictureData.setFilePath(file1.getPath());
                                pictureData.setFileName(file1.getName());
                                pictureData.setFolderName(file1.getParentFile().getName());
                                pictureData.setDate(file1.lastModified());
                                pictureData.setVideo(isVideoFile(file1.getPath()));
                                pictureData.setFileSize(file1.length());
                                imagesData1.add(pictureData);
                            }
                        boolean isAdd = false;
                        for (AlbumData albumData : albumBackUpList) {
                            if (albumData.getTitle().equalsIgnoreCase(file.getName())) {
                                ArrayList<PictureData> image = albumData.getPictureData();
                                if (image == null)
                                    image = new ArrayList<>();
                                image.addAll(imagesData1);
                                isAdd = true;
                            }
                        }

                        if (!isAdd) {
                            List<String> folderList = preferencesManager.getExcludeFolderList();
                            if (!folderList.contains(file.getPath())) {
                                List<String> pinList = preferencesManager.getPinFolderList();
                                AlbumData albumData = new AlbumData();
                                albumData.setTitle(file.getName());
                                albumData.setFolderPath(file.getPath());
                                albumData.setPictureData(imagesData1);
                                albumData.setPin(pinList.contains(file.getPath()));
                                albumBackUpList.add(albumData);
                            }
                        }

                        albumList.clear();
                        albumList.addAll(albumBackUpList);
                    }
                    sortData();
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    public boolean isVideoFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("video");
    }

    private void getImages() {
        albumBackUpList.clear();
        albumList.clear();
        albumWisePictures.clear();

        List<String> folderList = new ArrayList();
        folderList.addAll(preferencesManager.getExcludeFolderList());

        albumCount = 0;
        Cursor mCursor;
        try {
            String BUCKET_DISPLAY_NAME;
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME;

            String[] projection = {MediaStore.Images.Media.DATA
                    , BUCKET_DISPLAY_NAME
                    , MediaStore.MediaColumns.DATE_MODIFIED
                    , MediaStore.MediaColumns.DISPLAY_NAME
                    , MediaStore.MediaColumns.SIZE
            };

            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
            } else {
                uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            }

            mCursor = requireActivityContext().getContentResolver().query(
                    uri, // Uri
                    projection, // Projection
                    null,
                    null,
                    MediaStore.MediaColumns.DATE_MODIFIED + " DESC");

            if (mCursor != null) {
                mCursor.moveToFirst();
                for (mCursor.moveToFirst(); !mCursor.isAfterLast(); mCursor.moveToNext()) { //2sec

                    String path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                    String title = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME));

                    String bucketPath = "";

                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1);

                    if (!folderList.contains(bucketPath)) {

                        String bucketName = mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME));
                        if (bucketName != null && !bucketName.isEmpty()) {
                            long d = mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED));
                            d = d * 1000;

                            long fileSizeLength = mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE));


//                            Log.e("image", "bucketPath==>> " + bucketPath);
//                            Log.e("image", "path      ==>> " + path);

                            PictureData pictureData = new PictureData();
                            pictureData.setFilePath(path);
                            pictureData.setFileName(title);
                            pictureData.setFolderName(bucketName);
                            pictureData.setFolderPath(bucketPath);
                            pictureData.setDate(d);
                            pictureData.setVideo(false);
                            pictureData.setFileSize(fileSizeLength);

                            ArrayList<PictureData> imagesData2;
                            if (albumWisePictures.containsKey(bucketPath)) {
                                imagesData2 = albumWisePictures.get(bucketPath);
                                if (imagesData2 == null)
                                    imagesData2 = new ArrayList<>();

                            } else {
                                imagesData2 = new ArrayList<>();
                            }
                            imagesData2.add(pictureData);
                            albumWisePictures.put(bucketPath, imagesData2);
                        }
                    }
                }
                mCursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        getVideos();
    }

    private void getVideos() {
        String absolutePathOfImage;
        String path;
        int duration;

        List<String> folderList = new ArrayList();
        folderList.addAll(preferencesManager.getExcludeFolderList());

        Uri uri;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            uri = android.provider.MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else
            uri = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;


        String[] projection = {MediaStore.Video.VideoColumns.DATA,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.VideoColumns.SIZE,
                MediaStore.Video.VideoColumns.DURATION,
                MediaStore.Video.VideoColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME};

        try {
            Cursor cursor = requireActivityContext().getContentResolver().query(uri, projection, null, null, MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC");
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION);

                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                    path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA));
                    absolutePathOfImage = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME));
                    String bucketName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME));
                    String bucketPath = "";

                    bucketPath = path.substring(0, path.lastIndexOf(absolutePathOfImage) - 1);
                    if (!folderList.contains(bucketPath)) {
//                        Log.e("image", "bucketPath==>> " + bucketPath);
//                        Log.e("image", "path      ==>> " + path);

                        long d = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED));
                        d = d * 1000;
                        long fileSizeLength = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE));

                        PictureData pictureData = new PictureData();
                        pictureData.setFilePath(path);
                        pictureData.setFileName(absolutePathOfImage);
                        pictureData.setFolderName(bucketName);
                        pictureData.setFolderPath(bucketPath);
                        pictureData.setDate(d);
                        pictureData.setVideo(true);
                        pictureData.setVideoDuration(cursor.getLong(duration));
                        pictureData.setFileSize(fileSizeLength);


                        ArrayList<PictureData> imagesData2;
                        if (albumWisePictures.containsKey(bucketPath)) {
                            imagesData2 = albumWisePictures.get(bucketPath);
                            if (imagesData2 == null)
                                imagesData2 = new ArrayList<>();

                        } else {
                            imagesData2 = new ArrayList<>();
                        }
                        imagesData2.add(pictureData);
                        albumWisePictures.put(bucketPath, imagesData2);
                    }
                }
                cursor.close();
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        }

        Set<String> folderKeys = albumWisePictures.keySet();
        ArrayList<String> listFolderkeys = new ArrayList<>(folderKeys);

        List<String> pinList = new ArrayList<>();
        pinList.addAll(preferencesManager.getPinFolderList());

        for (int i = 0; i < listFolderkeys.size(); i++) {
            ArrayList<PictureData> imagesData = albumWisePictures.get(listFolderkeys.get(i));

            if (imagesData != null && imagesData.size() != 0
                    && imagesData.get(0).getFolderName() != null && !imagesData.get(0).getFolderName().isEmpty()) {
                AlbumData albumData = new AlbumData();
                albumCount++;
                albumData.setTitle(imagesData.get(0).getFolderName());
                albumData.setPictureData(imagesData);

//                File file = new File(imagesData.get(0).getFilePath());
                String folderPath = listFolderkeys.get(i);
                albumData.setPin(pinList.contains(folderPath));
                albumData.setFolderPath(folderPath);
                albumData.setDate(new File(folderPath).lastModified());

                albumList.add(albumData);
                albumBackUpList.add(albumData);
            }
        }

        sortAlbum();
    }

    LinkedHashMap<String, ArrayList<PictureData>> albumWisePictures = new LinkedHashMap<>();

    private void getImageOrVideo() {
        albumBackUpList.clear();
        albumList.clear();
        albumWisePictures.clear();

        albumCount = 0;

        final String[] projection = {MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MIME_TYPE, MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME,
                MediaStore.Files.FileColumns.DURATION};

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;


        Cursor cursor = requireActivityContext().getContentResolver().query(MediaStore.Files
                        .getContentUri("external"), projection,
                selection,
                null, "LOWER(" + MediaStore.Files.FileColumns.DATE_MODIFIED + ") DESC");
        String androidPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Android";
        if (cursor != null) {
            cursor.moveToFirst();

            ArrayList<PictureData> photoDataArrayList = new ArrayList<>();
            SimpleDateFormat format = new SimpleDateFormat("EEEE, MMM dd yyyy");
            SimpleDateFormat format2 = new SimpleDateFormat("MMM yyyy");
            Calendar calendar = Calendar.getInstance();
            String today = format.format(calendar.getTimeInMillis());
            calendar.add(Calendar.DATE, -1);
            String yesterday = format.format(calendar.getTimeInMillis());

            // video image
            for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) { //2sec
                String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA));
                String mineType = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE));

                if (path != null && !androidPath.toLowerCase().contains(path.toLowerCase())
                        && !path.toLowerCase().contains(androidPath.toLowerCase())
                        && mineType != null) {
//                    Log.e("getImageOrVideo", "mineType: " + mineType);
                    String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME));
                    String bucketName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME));
                    long fileSizeLength = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE));

                    long d = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED));
                    d = d * 1000;

//                    Log.e("getImageOrVideo", "bucketName==>> " + bucketName);

                    String strDate = format.format(d);
                    if (strDate.equals(today)) {
                        strDate = "Today";
                    } else if (strDate.equals(yesterday)) {
                        strDate = "Yesterday";
                    }
                    try {
                        if (bucketName.isEmpty())
                            bucketName = new File(path).getParentFile().getName();

                        if (!bucketName.isEmpty()) {
                            PictureData pictureData = new PictureData();
                            pictureData.setFilePath(path);
                            pictureData.setFileName(title);
                            pictureData.setFolderName(bucketName);
                            pictureData.setDate(d);
                            pictureData.setVideo(mineType.contains("video"));
                            pictureData.setFileSize(fileSizeLength);
                            if (mineType.contains("video")) {
//                                int duration = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DURATION);
//                                pictureData.setVideoDuration(duration);
                                try {
                                    MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                                    mmr.setDataSource(requireActivityContext(), Uri.parse(path));
                                    String durations = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                                    mmr.release();
                                    pictureData.setVideoDuration(Long.parseLong(durations));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                            photoDataArrayList.add(pictureData);

                            ArrayList<PictureData> imagesData2;
                            if (albumWisePictures.containsKey(bucketName)) {
                                imagesData2 = albumWisePictures.get(bucketName);
                                if (imagesData2 == null)
                                    imagesData2 = new ArrayList<>();

                            } else {
                                imagesData2 = new ArrayList<>();
                            }
                            imagesData2.add(pictureData);
                            albumWisePictures.put(bucketName, imagesData2);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            cursor.close();

            Set<String> folderKeys = albumWisePictures.keySet();
            ArrayList<String> listFolderkeys = new ArrayList<>(folderKeys);

            for (int i = 0; i < listFolderkeys.size(); i++) {
                ArrayList<PictureData> imagesData = albumWisePictures.get(listFolderkeys.get(i));

                if (imagesData != null && imagesData.size() != 0) {
                    AlbumData albumData = new AlbumData();
                    albumCount++;
                    albumData.setTitle(listFolderkeys.get(i));
                    albumData.setPictureData(imagesData);
                    File file = new File(imagesData.get(0).getFilePath());
                    String folderPath = file.getParentFile().getPath();
                    albumData.setFolderPath(folderPath);
                    albumData.setDate(new File(folderPath).length());

                    albumList.add(albumData);
                    albumBackUpList.add(albumData);
                }
            }
        }

        sortAlbum();
    }

    private void sortAlbum() {

        sortAlbumMain();
        sortPhotos();
    }

    private void sortAlbumMain() {
        Collections.sort(albumList, (p1, p2) -> {
            if (sortBy == 0) {
                if (sortType)
                    return p2.getTitle().compareToIgnoreCase(p1.getTitle());
                else
                    return p1.getTitle().compareToIgnoreCase(p2.getTitle());
            } else if (sortBy == 1) {
                if (sortType)
                    return Integer.compare(p2.getPictureData().size(), p1.getPictureData().size());
                else
                    return Integer.compare(p1.getPictureData().size(), p2.getPictureData().size());
            } else if (sortBy == 2) {
                if (sortType)
                    return Long.compare(p2.getDate(), p1.getDate());
                else
                    return Long.compare(p1.getDate(), p2.getDate());
            } else
                return Long.compare(p2.getDate(), p1.getDate());
        });

        Collections.sort(albumBackUpList, (p1, p2) -> {
            if (sortBy == 0) {
                if (sortType)
                    return p2.getTitle().compareToIgnoreCase(p1.getTitle());
                else
                    return p1.getTitle().compareToIgnoreCase(p2.getTitle());
            } else if (sortBy == 1) {
                if (sortType)
                    return Integer.compare(p2.getPictureData().size(), p1.getPictureData().size());
                else
                    return Integer.compare(p1.getPictureData().size(), p2.getPictureData().size());
            } else if (sortBy == 2) {
                if (sortType)
                    return Long.compare(p2.getDate(), p1.getDate());
                else
                    return Long.compare(p1.getDate(), p2.getDate());
            } else
                return Long.compare(p2.getDate(), p1.getDate());
        });
        Collections.sort(albumList, (p1, p2) -> {
            return Boolean.compare(p2.isPin(), p1.isPin());
        });

        Collections.sort(albumBackUpList, (p1, p2) -> {
            return Boolean.compare(p2.isPin(), p1.isPin());
        });
    }

    private void sortPhotos() {
        int sortByPhotos = preferencesManager.getSortPhoto();
        boolean sortTypePhotos = preferencesManager.getSortTypePhoto();
        for (AlbumData albumData : albumList) {
            Collections.sort(albumData.getPictureData(), (p1, p2) -> {
                if (sortByPhotos == 0) {
                    if (sortTypePhotos)
                        return p2.getFileName().compareToIgnoreCase(p1.getFileName());
                    else
                        return p1.getFileName().compareToIgnoreCase(p2.getFileName());
                } else if (sortByPhotos == 1) {
                    if (sortTypePhotos)
                        return Long.compare(p2.getDate(), p1.getDate());
                    else
                        return Long.compare(p1.getDate(), p2.getDate());
                } else
                    return Long.compare(p2.getDate(), p1.getDate());
            });
        }
    }

    public void setSearch(String strSearch) {
        albumList.clear();
        if (strSearch.isEmpty()) {
            albumList.addAll(albumBackUpList);
        } else {
            for (AlbumData albumData : albumBackUpList) {
                if (albumData.getTitle().toLowerCase().contains(strSearch.toLowerCase())) {
                    albumList.add(albumData);
                }
            }
        }

        if (albumAdapter != null)
            albumAdapter.notifyDataSetChanged();
        else
            initAdapter();

        setEmptyData();
    }


}