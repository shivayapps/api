package com.picturephoto.gallery.app.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.FavoriteAdapter;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityFavoriteListBinding;
import com.picturephoto.gallery.app.event.DisplayDeleteEvent;
import com.picturephoto.gallery.app.event.DisplayUnFavoriteEvent;
import com.picturephoto.gallery.app.event.EditImageEvent;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.Constant;

import java.io.File;
import java.io.IOException;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class FavoriteListActivity extends AppCompatActivity {

    ActivityFavoriteListBinding binding;
    PreferencesManager preferencesManager;
    ArrayList<Object> photoList = new ArrayList<>();
    private FavoriteAdapter favoriteAdapter;
    boolean isSelectAll = false;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFavoriteListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
        DisplayUnFavoriteEvent();
        DisplayDeleteEvent();
        editEvent();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void editEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(EditImageEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<EditImageEvent>() {
            @Override
            public void call(EditImageEvent event) {
                runOnUiThread(() -> {
                    if (favoriteAdapter != null)
                        favoriteAdapter.notifyDataSetChanged();
                    else
                        setAdapter();
                });
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        new Thread(this::getData).start();
        initListener();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 909) {
            setClose();
        }
    }

    private void setAdapter() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3, LinearLayoutManager.VERTICAL, false);
        binding.favRecycler.setLayoutManager(gridLayoutManager);
        favoriteAdapter = new FavoriteAdapter(this, photoList, preferencesManager.getLabelShow(), new FavoriteAdapter.OnSelectPicture() {
            @Override
            public void onSelectPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    if (imageList.isCheckboxVisible()) {
                        imageList.setSelected(!imageList.isSelected());
                        favoriteAdapter.notifyItemChanged(pos);
                        setSelectedFile();
                    } else {
                        int temp_pos = -1;
                        ArrayList<PictureData> dataList = new ArrayList<>();
                        for (int i = 0; i < photoList.size(); i++) {
                            if (photoList.get(i) instanceof PictureData) {
                                dataList.add((PictureData) photoList.get(i));
                                if (pos == i) {
                                    temp_pos = dataList.size() - 1;
                                }
                            }
                        }
                        Constant.displayImageList = new ArrayList<>();
                        Constant.displayImageList.addAll(dataList);
                        Intent intent = new Intent(FavoriteListActivity.this, ImageShowActivity.class);
                        intent.putExtra("pos", temp_pos);
                        intent.putExtra("IsPrivateList", false);
                        intent.putExtra("IsShowSlideShow", false);
                        intent.putExtra("IsFavList", true);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onLongClickPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                model.setCheckboxVisible(true);
                            }
                    }
                    imageList.setCheckboxVisible(true);
                    imageList.setSelected(true);
                    favoriteAdapter.notifyDataSetChanged();
                    setSelectedFile();
                }
            }
        });
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(final int position) {
                if (favoriteAdapter.getItemViewType(position) == FavoriteAdapter.ITEM_HEADER_TYPE) {
                    return 3;
                }
                return 1;
            }
        });
        binding.favRecycler.setAdapter(favoriteAdapter);
        if (photoList != null && photoList.size() != 0) {
            binding.favRecycler.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
            binding.ivMenu.setVisibility(View.VISIBLE);
        } else {
            binding.favRecycler.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
            binding.ivMenu.setVisibility(View.GONE);
        }
    }


    private void initListener() {
        binding.ivBack.setOnClickListener(v -> onBackPressed());
        binding.ivClose.setOnClickListener(v -> {
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        model.setCheckboxVisible(false);
                        model.setSelected(false);
                    }
            }
            if (favoriteAdapter != null) {
                favoriteAdapter.notifyDataSetChanged();
            }
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
        });
        binding.ivShare.setOnClickListener(v -> {
            ArrayList<Uri> uris = new ArrayList<>();
            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.isSelected()) {
                            Uri uri = FileProvider.getUriForFile(FavoriteListActivity.this, getPackageName() + ".provider", new File(model.getFilePath()));
                            uris.add(uri);
                        }
                    }
            }
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(Intent.createChooser(intent, getString(R.string.share_with)), 909);
        });

        binding.ivFav.setOnClickListener(v -> {
            setUnFav();
        });

        binding.ivMenuSelect.setOnClickListener(view -> {
            showMenu(view);
        });

        binding.ivMenu.setOnClickListener(view -> {
            showMenu(view);
        });
    }

    private void showMenu(View view) {
        PopupMenu popup = new PopupMenu(FavoriteListActivity.this, view);
        popup.getMenuInflater().inflate(R.menu.menu_select_option, popup.getMenu());
        popup.getMenu().findItem(R.id.nav_move_private).setVisible(false);
        popup.getMenu().findItem(R.id.nav_copy).setVisible(false);
        popup.getMenu().findItem(R.id.nav_move).setVisible(false);
        if (binding.selectToolbar.getVisibility() == View.VISIBLE) {
            if (isSelectAll)
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.DeselectAll));
            else
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.SelectAll));
        } else
            popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.Clear));

        popup.show();

        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.nav_select) {
                if (binding.selectToolbar.getVisibility() == View.VISIBLE) {
                    if (isSelectAll)
                        isSelectAll = false;
                    else
                        isSelectAll = true;
                    setAllSelection();
                } else {
                    showClearDialog();

                }
            }
            return true;
        });
    }

    private void showClearDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.clearFavorites);
        builder.setMessage(R.string.fav_clear_msg);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.action_Clear, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                List<String> favList = preferencesManager.getFavoriteList();
                setUnFavorite(favList);
                photoList.clear();
                if (favoriteAdapter != null)
                    favoriteAdapter.notifyDataSetChanged();
                setEmptyData();
            }
        });
        builder.setNegativeButton(getString(R.string.action_Cancel), (dialog, which) -> dialog.dismiss());
//        builder.show();
        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(this, R.color.gray_600));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, R.color.theme_color));
    }

    private void setUnFav() {
        List<String> favList = new ArrayList<>();
        for (int i = photoList.size() - 1; i >= 0; i--) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        favList.add(model.getFilePath());
                        photoList.remove(i);
                    } else {
                        model.setSelected(false);
                        model.setCheckboxVisible(false);
                    }
                }
        }
//        for (int i = 0; i < photoList.size(); i++) {
//            if (photoList.get(i) != null)
//                if (photoList.get(i) instanceof PictureData) {
//                    PictureData model = (PictureData) photoList.get(i);
//                    if (model.isSelected())
//                        favList.add(model.getFilePath());
//                    model.setSelected(false);
//                    model.setCheckboxVisible(false);
//                }
//        }
        if (favList != null && favList.size() != 0)
            setUnFavorite(favList);
        if (favoriteAdapter != null)
            favoriteAdapter.notifyDataSetChanged();
        binding.toolbar.setVisibility(View.VISIBLE);
        binding.selectToolbar.setVisibility(View.GONE);
        setEmptyData();
    }

    private void setUnFavorite(List<String> list) {
        List<String> favList = preferencesManager.getFavoriteList();
        if (favList == null) {
            favList = new ArrayList<>();
        }
        for (String filepath : list) {
            if (favList.contains(filepath))
                favList.remove(filepath);

        }
//        for (int f = 0; f < favList.size(); f++) {
//            if (favList.get(f) != null && !favList.get(f).equalsIgnoreCase("")) {
//                if (favList.get(f).equalsIgnoreCase(filePath)) {
//                    favList.remove(f);
//                    break;
//                }
//            }
//        }
        preferencesManager.setFavoriteList(favList);
    }

    private void setAllSelection() {
        if (isSelectAll) {
            int selected = 0;
            long size = 0;
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        selected++;
                        size += model.getFileSize();
                        model.setSelected(true);
                    }
            }
            showSelectCount(selected, size);
            if (favoriteAdapter != null)
                favoriteAdapter.notifyDataSetChanged();
            setEmptyData();
        } else {
            setClose();
            showSelectCount(0, 0);
        }
    }

    private void setSelectedFile() {
        int selected = 0;
        long size = 0;
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                        size += model.getFileSize();
                    }
                }
        }
        if (selected == 0) {
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
            setRefreshData(false);
            setClose();
        } else {
            binding.toolbar.setVisibility(View.GONE);
            binding.selectToolbar.setVisibility(View.VISIBLE);
            setRefreshData(true);
        }
        showSelectCount(selected, size);

        if (selected == 0)
            isSelectAll = false;
    }

    public void setRefreshData(boolean isEnable) {
//        if (isEnable)
//            binding.swipeRefreshLayout.setEnabled(true);
//        else
//            binding.swipeRefreshLayout.setEnabled(false);
    }

    private void showSelectCount(int selected, long size) {
        binding.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
    }

    @Override
    public void onBackPressed() {
        if (binding.selectToolbar.getVisibility() == View.VISIBLE) {
            setClose();
        } else {
            admobAdManager.loadInterstitialBackAd(this, 2, () ->  finish());
        }
    }


    private void setClose() {
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);
                }
        }
        if (favoriteAdapter != null) {
            favoriteAdapter.notifyDataSetChanged();
        }
        binding.toolbar.setVisibility(View.VISIBLE);
        binding.selectToolbar.setVisibility(View.GONE);
    }

    private void getData() {
        List<String> favList = preferencesManager.getFavoriteList();
        LinkedHashMap<String, ArrayList<PictureData>> bucketImagesDataPhotoHashMap = new LinkedHashMap<>();
        if (favList == null) {
            favList = new ArrayList<>();
        }
        Collections.sort(favList, (i1, i2) -> {
            File file1 = new File(i1);
            File file2 = new File(i2);

            SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.ENGLISH);
            String strDate1 = format.format(file1.lastModified());
            String strDate2 = format.format(file2.lastModified());

            int compareResult;

            Date date1 = null;
            Date date2 = null;
            try {
                date1 = format.parse(strDate1);
                date2 = format.parse(strDate2);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            compareResult = Objects.requireNonNull(date2).compareTo(date1);

            return compareResult;
        });

        for (int f = 0; f < favList.size(); f++) {

            File file = new File(favList.get(f));
            if (file.exists()) {
                SimpleDateFormat format = new SimpleDateFormat("EEEE, MMM dd yyyy");
                PictureData imagesData = new PictureData();
                imagesData.setFilePath(file.getPath());
                imagesData.setFileName(file.getName());
                imagesData.setFavorite(true);
                if (isImageFile(file.getPath())) {
                    imagesData.setVideo(false);
                } else {
                    imagesData.setVideo(true);
                    MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                    mmr.setDataSource(file.getPath());
                    String durations = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                    try {
                        mmr.release();
                    } catch (IOException ignored) {

                    }
                    imagesData.setVideoDuration(Integer.parseInt(durations));
                    //                    String temp_duration = Utils.setDuration(Integer.parseInt(durations));
//                    imagesData.setDuration(temp_duration);
                }

                photoList.add(imagesData);
            }
        }

        runOnUiThread(() -> {
            setAdapter();
            setEmptyData();
        });
    }

    private void setEmptyData() {
        if (photoList != null && photoList.size() != 0) {
            binding.favRecycler.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
            binding.ivMenu.setVisibility(View.VISIBLE);
        } else {
            binding.favRecycler.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
            binding.ivMenu.setVisibility(View.GONE);
        }
    }

    public boolean isImageFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("image");
    }

    private void DisplayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {
            if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                deleteDataList(event.getDeleteList());

            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void DisplayUnFavoriteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayUnFavoriteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {
            if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                ArrayList<String> deleteList;
                deleteList = event.getDeleteList();
                deleteDataList(deleteList);
            }

        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void deleteDataList(ArrayList<String> deleteList) {
        if (photoList != null && photoList.size() != 0) {
            for (int d = 0; d < deleteList.size(); d++) {
                for (int i = 0; i < photoList.size(); i++) {
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {
                            boolean isPre = false, isNext = false;
                            if (i != 0) {
                                isPre = photoList.get(i - 1) instanceof AlbumData;
                            }
                            if (i < (photoList.size() - 2)) {
                                isNext = photoList.get(i + 1) instanceof AlbumData;
                            }
                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                photoList.remove(i);
                                photoList.remove(i - 1);
                            } else if (i == (photoList.size() - 1)) {
                                photoList.remove(i);
                                if (isPre) {
                                    photoList.remove(i - 1);
                                }
                            } else {
                                photoList.remove(i);
                            }
                            if (i != 0) {
                                i--;
                            }
                            if (d == deleteList.size() - 1) {
                                break;
                            }
                        }
                    }
                }
            }
            if (favoriteAdapter != null) {
                favoriteAdapter.notifyDataSetChanged();
            }
            if (photoList != null && photoList.size() != 0) {
                binding.favRecycler.setVisibility(View.VISIBLE);
                binding.loutNoData.setVisibility(View.GONE);
            } else {
                binding.favRecycler.setVisibility(View.GONE);
                binding.loutNoData.setVisibility(View.VISIBLE);
            }
        }
    }
}