package com.picturephoto.gallery.app.ads;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.preferences.PreferencesManager;


public class AdmobAdManager {
    private static PreferencesManager preferencesManager;
    ProgressDialog progressDialog;
    public Boolean isAdLoadProcessing = false;
    public Boolean isBackAdLoadProcessing = false;

    public static AdmobAdManager singleton;
    com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd;
    com.google.android.gms.ads.interstitial.InterstitialAd interstitialBackAd;
    Context context;
    public Boolean isNAtiveAdLoadProcessing = false;
    public NativeAd mNativeRateAd;

    static int interCount = 1;
    static int interBackCount = 1;

    public AdmobAdManager(Context context) {
        this.context = context;
    }

    public static AdmobAdManager getInstance(Context context) {
        if (singleton == null) {
            preferencesManager = PreferencesManager.getInstance(context);
            interCount = preferencesManager.getInterstitialFrequency();
            interBackCount = preferencesManager.getInterstitialFrequencyBack();
            singleton = new AdmobAdManager(context);
        }
        return singleton;
    }

    private void setUpProgress(Context context) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Ad showing");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
    }

    public void showProgress(Activity activity) {
        try {
            activity.runOnUiThread(() -> {
                setUpProgress(activity);
                if (progressDialog != null && !progressDialog.isShowing()) {
                    progressDialog.show();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dismissProgress(Activity activity) {
        try {
            activity.runOnUiThread(() -> {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadInterstitialSplashAd(Activity context, OnAdClosedListener onAdClosedListener) {
        if (isNetworkAvailable(context)) {
            AdRequest adRequest = new AdRequest.Builder().build();
            com.google.android.gms.ads.interstitial.InterstitialAd.load(
                    context,
                    preferencesManager.getInterstitialSplashId(),
                    adRequest,
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAds) {
                            super.onAdLoaded(interstitialAds);
                            interstitialAds.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                    super.onAdFailedToShowFullScreenContent(adError);
                                    onAdClosedListener.onAdClosed();
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                    super.onAdShowedFullScreenContent();
                                }

                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    super.onAdDismissedFullScreenContent();
                                    onAdClosedListener.onAdClosed();
                                }

                                @Override
                                public void onAdImpression() {
                                    super.onAdImpression();
                                }

                                @Override
                                public void onAdClicked() {
                                    super.onAdClicked();
                                }
                            });
                            interstitialAds.show(context);
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            super.onAdFailedToLoad(loadAdError);
                            onAdClosedListener.onAdClosed();
                        }
                    });
        } else {
            onAdClosedListener.onAdClosed();
        }
    }

    public void loadInterstitialAd(Context context) {
        if (isNetworkAvailable(context) && preferencesManager.getInterstitialAdEnable()) {
            if (interstitialAd == null && !isAdLoadProcessing) {
                isAdLoadProcessing = true;
                AdRequest adRequest = new AdRequest.Builder().build();
                com.google.android.gms.ads.interstitial.InterstitialAd.load(
                        context,
                        preferencesManager.getInterstitialOneId(),
                        adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAds) {
                                super.onAdLoaded(interstitialAds);
                                Variables.isAdLoad = true;
                                Variables.isAdLoadFailed = false;
                                isAdLoadProcessing = false;
                                interstitialAd = interstitialAds;
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                super.onAdFailedToLoad(loadAdError);
                                Variables.isAdLoad = false;
                                Variables.isAdLoadFailed = true;
                                isAdLoadProcessing = false;
                            }
                        });
            }
        }
    }

    public void loadInterstitialBackAd(Context context) {
        if (isNetworkAvailable(context) && preferencesManager.getInterstitialBackAdEnable()) {
            if (interstitialBackAd == null && !isBackAdLoadProcessing) {
                isBackAdLoadProcessing = true;
                AdRequest adRequest = new AdRequest.Builder().build();
                com.google.android.gms.ads.interstitial.InterstitialAd.load(
                        context,
                        preferencesManager.getInterstitialTwoId(),
                        adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAds) {
                                super.onAdLoaded(interstitialAds);
                                Variables.isBackAdLoad = true;
                                Variables.isBackAdLoadFailed = false;
                                isBackAdLoadProcessing = false;
                                interstitialBackAd = interstitialAds;
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                super.onAdFailedToLoad(loadAdError);
                                Variables.isBackAdLoad = false;
                                Variables.isBackAdLoadFailed = true;
                                isBackAdLoadProcessing = false;
                            }
                        });
            }
        }
    }


    public void loadInterstitialAd(
            Activity context,
            int number,
            OnAdClosedListener onAdClosedListener) {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        if ((number == 1 || interCount == preferencesManager.getInterstitialFrequency()) && preferencesManager.getInterstitialAdEnable()) {
            if (interstitialAd != null) {
                if (Variables.isAdLoad && !Variables.isAdLoadFailed && !isAdLoadProcessing) {
                    interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                            super.onAdFailedToShowFullScreenContent(adError);
                            if (progressDialog != null && progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            interstitialAd = null;
                            Variables.isAdLoad = false;
                            isAdLoadProcessing = false;
                            Variables.isAdLoadFailed = false;
                            onAdClosedListener.onAdClosed();
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                            super.onAdShowedFullScreenContent();
                        }

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent();
                            if (progressDialog != null && progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            interCount = 1;
                            Variables.isAdLoad = false;
                            isAdLoadProcessing = false;
                            Variables.isAdLoadFailed = false;
                            interstitialAd = null;
                            loadInterstitialAd(context);
                            onAdClosedListener.onAdClosed();
                        }

                        @Override
                        public void onAdImpression() {
                            super.onAdImpression();
                        }

                        @Override
                        public void onAdClicked() {
                            super.onAdClicked();
                        }
                    });
                    interstitialAd.show(context);
                } else {
                    Log.e("Ads", "Ads still loading!");
                    onAdClosedListener.onAdClosed();
                }
            } else {
                onAdClosedListener.onAdClosed();
            }
        } else {
            interCount++;
            onAdClosedListener.onAdClosed();
        }
    }

    public void loadInterstitialBackAd(
            Activity context,
            int number,
            OnAdClosedListener onAdClosedListener) {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        if ((number == 1 || interBackCount == preferencesManager.getInterstitialFrequencyBack()) && preferencesManager.getInterstitialBackAdEnable()) {
            if (interstitialBackAd != null) {
                if (Variables.isBackAdLoad && !Variables.isBackAdLoadFailed && !isBackAdLoadProcessing) {
                    interstitialBackAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                            super.onAdFailedToShowFullScreenContent(adError);
                            if (progressDialog != null && progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            interstitialBackAd = null;
                            Variables.isBackAdLoad = false;
                            isBackAdLoadProcessing = false;
                            Variables.isBackAdLoadFailed = false;
                            onAdClosedListener.onAdClosed();
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                            super.onAdShowedFullScreenContent();
                        }

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent();
                            if (progressDialog != null && progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            interBackCount = 1;
                            Variables.isBackAdLoad = false;
                            isBackAdLoadProcessing = false;
                            Variables.isBackAdLoadFailed = false;
                            interstitialBackAd = null;
                            loadInterstitialBackAd(context);
                            onAdClosedListener.onAdClosed();
                        }

                        @Override
                        public void onAdImpression() {
                            super.onAdImpression();
                        }

                        @Override
                        public void onAdClicked() {
                            super.onAdClicked();
                        }
                    });
                    interstitialBackAd.show(context);
                } else {
                    Log.e("Ads", "Ads still loading!");
                    onAdClosedListener.onAdClosed();
                }
            } else {
                onAdClosedListener.onAdClosed();
            }
        } else {
            interBackCount++;
            onAdClosedListener.onAdClosed();
        }
    }


    public void showNativeAds(Context context,
                              FrameLayout frameLayout,
                              Boolean isShowMedia,
                              Boolean isSmallAd,
                              AdEventListener adEventListener) {
        AdLoader.Builder builder = new AdLoader.Builder(context, preferencesManager.getNativeAdId());
        builder.forNativeAd(nativeAd -> {
            adEventListener.onAdLoaded(nativeAd);
            int layout;
            if (isSmallAd) {
                layout = R.layout.layout_samll_banner_native_ad_mob;
            } else {
                layout = R.layout.layout_big_native_ad_mob;
            }
            populateUnifiedNativeAdView(context, frameLayout, nativeAd, isShowMedia, layout);
        }).withAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                isNAtiveAdLoadProcessing = false;
                Variables.isNativeAdLoad = false;
                Variables.isNativeAdLoadFailed = true;
                adEventListener.onLoadError("");
                Log.e("Data", "onAdFailedToLoadNative:" + loadAdError.getCode());
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(true)
                .build();
        NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public interface OnAdClosedListener {
        void onAdClosed();

    }

    public void loadAdaptiveBanner(
            Context context,
            FrameLayout adContainerView,
            AdEventListener adEventListener) {
        try {
            com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(context);
            adView.setAdUnitId(preferencesManager.getBannerOneId());
            adContainerView.removeAllViews();
            adContainerView.addView(adView);
            AdSize adSize = getAdSize(context, adContainerView);
            adView.setAdSize(adSize);
            AdRequest adRequest = new AdRequest.Builder().build();
            adView.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    adEventListener.onAdClosed();
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    Log.e("onAdFailedToLoad", "getMessage: " + loadAdError.getMessage());
                    adEventListener.onLoadError(loadAdError.getMessage());
                }

                @Override
                public void onAdOpened() {
                    super.onAdOpened();
                }

                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    adEventListener.onAdLoaded();
                }

                @Override
                public void onAdClicked() {
                    super.onAdClicked();
                }

                @Override
                public void onAdImpression() {
                    super.onAdImpression();
                }
            });
            adView.loadAd(adRequest);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("Data", "LoadAdaptiveBanner: $e");
            adEventListener.onAdLoaded();
        }
    }

    private AdSize getAdSize(Context context, FrameLayout adContainerView) {
        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float density = outMetrics.density;
        int adWidthPixels = adContainerView.getWidth();
        if (adWidthPixels == 0f) {
            adWidthPixels = outMetrics.widthPixels;
        }
        float adWidth = (adWidthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, (int) adWidth);
    }

    private void populateUnifiedNativeAdView(
            Context context,
            FrameLayout frameLayout,
            NativeAd nativeAd,
            Boolean isShowMedia,
            int ads_unified) {
        if (isNetworkAvailable(context)) {
            LayoutInflater inflater = LayoutInflater.from(context);
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            NativeAdView adView = (NativeAdView)
                    inflater.inflate(ads_unified, null);
            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
                frameLayout.setVisibility(View.VISIBLE);
            }
            try {
                if (isShowMedia) {
                    MediaView mediaView = adView.findViewById(R.id.mediaView);
                    mediaView.setMediaContent(nativeAd.getMediaContent());
                    mediaView.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                        @Override
                        public void onChildViewAdded(View parent, View child) {
                            if (child instanceof ImageView) {
                                ImageView imageView = (ImageView) child;
                                imageView.setAdjustViewBounds(true);
                            }
                        }

                        @Override
                        public void onChildViewRemoved(View parent, View child) {
                        }
                    });
                    adView.setMediaView(mediaView);
                    if (adView.getMediaView() != null) {
                        adView.getMediaView().setVisibility(View.VISIBLE);
                        VideoController vc = nativeAd.getMediaContent().getVideoController();
                        vc.mute(true);
                        if (vc.hasVideoContent()) {
                            vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                                @Override
                                public void onVideoStart() {
                                    super.onVideoStart();
                                }

                                @Override
                                public void onVideoPlay() {
                                    super.onVideoPlay();
                                }

                                @Override
                                public void onVideoPause() {
                                    super.onVideoPause();
                                }

                                @Override
                                public void onVideoEnd() {
                                    super.onVideoEnd();
                                }

                                @Override
                                public void onVideoMute(boolean b) {
                                    super.onVideoMute(b);
                                }
                            });
                        }
                    }
                }
                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setIconView(adView.findViewById(R.id.adIcon));
                adView.setCallToActionView(adView.findViewById(R.id.callToAction));
                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);
                    ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
                }
                if (nativeAd.getIcon() == null) {
                    adView.getIconView().setVisibility(View.GONE);
                } else {
                    ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                    adView.getIconView().setVisibility(View.VISIBLE);
                }

                adView.setNativeAd(nativeAd);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("TAG", "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }
        }
    }

    public void loadNativeAdExit(
            Context context,
            AdEvenNativetListener adEventListener) {
        if (isNetworkAvailable(context)) {
            AdLoader.Builder builder = new AdLoader.Builder(context, preferencesManager.getNativeAdId());
            builder.forNativeAd(nativeAd -> {
                mNativeRateAd = nativeAd;
                if (adEventListener != null) {
                    adEventListener.onAdLoaded(nativeAd);
                    adEventListener.onAdLoaded(true);
                }

            }).withAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    if (adEventListener != null) {
                        adEventListener.onLoadError(loadAdError.getMessage());
                        adEventListener.onAdLoaded(false);
                    }
                    Log.e("Data", "onAdFailedToLoadNative:" + loadAdError.getCode());
                }

                @Override
                public void onAdOpened() {
                    super.onAdOpened();
                }

                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                }

                @Override
                public void onAdClicked() {
                    super.onAdClicked();
                }

                @Override
                public void onAdImpression() {
                    super.onAdImpression();
                }
            });
            VideoOptions videoOptions = new VideoOptions.Builder()
                    .setStartMuted(true)
                    .build();
            NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
            builder.withNativeAdOptions(adOptions);
            AdLoader adLoader = builder.build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else if (adEventListener != null)
            adEventListener.onAdLoaded(false);
    }

    public void populateExitUnifiedNativeAdView(Activity context, FrameLayout frameLayout, NativeAd nativeAd, boolean isShowMedia) {
        if (isNetworkAvailable(context)) {
            mNativeRateAd = nativeAd;
            LayoutInflater inflater = LayoutInflater.from(context);
            NativeAdView adView;
            adView = (NativeAdView) inflater.inflate(R.layout.ads_unified_exit, null);
            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
            }
            try {
                if (isShowMedia) {
                    MediaView mediaView = adView.findViewById(R.id.mediaView);
                    mediaView.setMediaContent(nativeAd.getMediaContent());
                    mediaView.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                        @Override
                        public void onChildViewAdded(View parent, View child) {
                            if (child instanceof ImageView) {
                                ImageView imageView = (ImageView) child;
                                imageView.setAdjustViewBounds(true);
                            }
                        }

                        @Override
                        public void onChildViewRemoved(View parent, View child) {
                        }
                    });

                    adView.setMediaView(mediaView);
                    adView.getMediaView().setVisibility(View.VISIBLE);
                    VideoController vc = nativeAd.getMediaContent().getVideoController();
                    vc.mute(true);
                    if (vc.hasVideoContent()) {
                        vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                            @Override
                            public void onVideoEnd() {
                                super.onVideoEnd();
                            }
                        });
                    }
                }

                Button exitBtn = adView.findViewById(R.id.btnExit);
                exitBtn.setOnClickListener(v -> {
                    context.finishAffinity();
                });
                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setIconView(adView.findViewById(R.id.adIcon));
                adView.setCallToActionView(adView.findViewById(R.id.callToAction));
                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);
                    ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
                }
                if (nativeAd.getIcon() == null) {
                    adView.getIconView().setVisibility(View.GONE);
                } else {
                    ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                    adView.getIconView().setVisibility(View.VISIBLE);
                }

                if (nativeAd.getCallToAction() == null && adView.getCallToActionView() != null) {
                    adView.getCallToActionView().setVisibility(View.INVISIBLE);
                } else if (adView.getCallToActionView() != null) {
                    adView.getCallToActionView().setVisibility(View.VISIBLE);
                    ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
                }

                if (frameLayout != null) {
                    frameLayout.setVisibility(View.VISIBLE);
                }


                adView.setNativeAd(nativeAd);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("TAG", "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }
        }
    }

    public Boolean isNetworkAvailable(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

}
