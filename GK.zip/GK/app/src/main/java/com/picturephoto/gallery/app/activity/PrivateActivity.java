package com.picturephoto.gallery.app.activity;

import static android.os.Build.VERSION.SDK_INT;
import static com.picturephoto.gallery.app.utils.Constant.HIDE_PATH;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.FavoriteAdapter;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.database.Database;
import com.picturephoto.gallery.app.databinding.ActivityPrivateBinding;
import com.picturephoto.gallery.app.event.DeleteEvent;
import com.picturephoto.gallery.app.event.DisplayDeleteEvent;
import com.picturephoto.gallery.app.event.UnHideDataEvent;
import com.picturephoto.gallery.app.event.UnHideEvent;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.Constant;
import com.picturephoto.gallery.app.utils.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLConnection;
import java.nio.channels.FileChannel;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

import io.reactivex.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class PrivateActivity extends AppCompatActivity {

    ActivityPrivateBinding binding;
    List<Object> photoList = new ArrayList<>();
    private FavoriteAdapter favoriteAdapter;
    Database database;
    PreferencesManager preferencesManager;
    int selected_Item = 0;
    boolean isSelectAll = false;
    private int REQUEST_HIDE_PERMISSION = 5555;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPrivateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        database = new Database(this);
        preferencesManager = PreferencesManager.getInstance(this);
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        initView();
        setListener();
        DisplayDeleteEvent();
        DeleteEvent();

    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void initView() {
        if (isPermissionFolder()) {
            binding.swipeRefreshLayout.setOnRefreshListener(() -> {
                new Thread(this::getHideData).start();
            });
            binding.swipeRefreshLayout.setRefreshing(true);
            new Thread(this::getHideData).start();
        } else {
            if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                File file = new File(HIDE_PATH);
                if (!file.exists()) {
                    file.mkdirs();
                }
                askPermissionHideUri();
            }
        }
    }

    private boolean isPermissionFolder() {
        if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
            File file = new File(HIDE_PATH);
            if (!file.exists()) {
                file.mkdirs();
            }
            String hidden_URI = preferencesManager.getHideUri();
            if (!hidden_URI.equals("") && hidden_URI != null && hidden_URI.endsWith(Constant.HIDE_FOLDER_NAME))
                return true;
        } else
            return true;
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void askPermissionHideUri() {
        File f = new File(Constant.HIDE_PATH);
        if (f.exists() && f.isDirectory()) {
            if (preferencesManager.getHideUri() == null || preferencesManager.getHideUri() == "" || !preferencesManager.getHideUri().endsWith(Constant.HIDE_FOLDER_NAME)) {
                askPermission(this, "Pictures%2F" + Constant.HIDE_FOLDER_NAME);
            }
        } else {
            boolean success = f.mkdir();
            if (success) {
                if (f.exists() && f.isDirectory()) {
                    if (preferencesManager.getHideUri() == null || preferencesManager.getHideUri() == "" || !preferencesManager.getHideUri().endsWith(Constant.HIDE_FOLDER_NAME)) {
                        askPermission(this, "Pictures%2F" + Constant.HIDE_FOLDER_NAME);
                    }
                }
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void askPermission(Activity context, String targetDirectory) {
        StorageManager storageManager = (StorageManager) context.getSystemService(STORAGE_SERVICE);
        Intent intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString();
        scheme = scheme.replace("/root/", "/document/");
        scheme += "%3A" + targetDirectory;
        uri = Uri.parse(scheme);
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        startActivityForResult(intent, REQUEST_HIDE_PERMISSION);
        Log.e("come", "==> at askPermission;");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_HIDE_PERMISSION) {
            if (resultCode == RESULT_OK && data != null) {
                Uri treeUri = data.getData();
                getContentResolver().takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
                preferencesManager.putHideUri(treeUri.toString());
                initView();
            }
        }

        if (requestCode == 909) {
            setClose();
        }
    }

    @Override
    public void onBackPressed() {
        if (binding.selectToolbar.getVisibility() == View.VISIBLE) {
            setClose();
        } else {
            admobAdManager.loadInterstitialBackAd(this, 2, () ->  finish());
        }
    }

    private void setListener() {
        binding.ivBack.setOnClickListener(v -> finish());
        binding.ivClose.setOnClickListener(v -> {
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        model.setCheckboxVisible(false);
                        model.setSelected(false);
                    }
            }
            if (favoriteAdapter != null) {
                favoriteAdapter.notifyDataSetChanged();
            }
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
        });
        binding.ivShare.setOnClickListener(v -> {
            ArrayList<Uri> uris = new ArrayList<>();
            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.isSelected()) {
                            Uri uri;
                            if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                                uri = Uri.parse(model.getFilePath());
                            } else {
                                uri = FileProvider.getUriForFile(PrivateActivity.this, getPackageName() + ".provider", new File(model.getFilePath()));
                            }
                            uris.add(uri);
                        }
                    }
            }
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(Intent.createChooser(intent, getString(R.string.share_with)), 909);
        });
        binding.ivDelete.setOnClickListener(v -> {
            showDeleteDialog();
        });

        binding.ivMenuSelect.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(PrivateActivity.this, view);
            popup.getMenuInflater().inflate(R.menu.menu_private_select_option, popup.getMenu());
            if (isSelectAll)
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.DeselectAll));
            else
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.SelectAll));
            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_restore) {
//                    if (loadingDialog != null) {
//                        loadingDialog.setMessage(getString(R.string.UnHide));
//                        loadingDialog.show();
//                    }
                    showUnHideDialog();

                } else if (item.getItemId() == R.id.nav_select) {
                    if (isSelectAll)
                        isSelectAll = false;
                    else
                        isSelectAll = true;
                    setAllSelection();
                }
                return true;
            });
            popup.show();
        });
    }

    private void showUnHideDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.UnlockMedia);
        builder.setMessage(R.string.UnlockMediaMsg);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.Unlock, (dialog, which) -> {
            dialog.dismiss();
            unhideData();
        });
        builder.setNegativeButton(getString(R.string.action_Cancel), (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(this, R.color.gray_600));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, R.color.theme_color));
    }


    private void setAllSelection() {
        if (isSelectAll) {
            int selected = 0;
            long size = 0;
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        selected++;
                        size += model.getFileSize();
                        model.setSelected(true);
                    }
            }
            showSelectCount(selected, size);
            if (favoriteAdapter != null)
                favoriteAdapter.notifyDataSetChanged();
            setEmptyData();
        } else {
            setClose();
            showSelectCount(0, 0);
        }
    }

    private void showSelectCount(int selected, long size) {
        binding.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
    }

    private void setEmptyData() {
        if (photoList != null && photoList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void setAdapter() {
        Log.e("getHideData", "setAdapter  ");
        binding.swipeRefreshLayout.setRefreshing(false);
        binding.recyclerView.setVisibility(View.VISIBLE);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3, LinearLayoutManager.VERTICAL, false);
        binding.recyclerView.setLayoutManager(gridLayoutManager);
        favoriteAdapter = new FavoriteAdapter(this, photoList, preferencesManager.getLabelShow(), new FavoriteAdapter.OnSelectPicture() {
            @Override
            public void onSelectPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    if (imageList.isCheckboxVisible()) {
                        imageList.setSelected(!imageList.isSelected());
                        favoriteAdapter.notifyItemChanged(pos);
                        setSelectedFile();
                    } else {
                        int temp_pos = -1;
                        ArrayList<PictureData> dataList = new ArrayList<>();
                        for (int i = 0; i < photoList.size(); i++) {
                            if (photoList.get(i) instanceof PictureData) {
                                dataList.add((PictureData) photoList.get(i));
                                if (pos == i) {
                                    temp_pos = dataList.size() - 1;
                                }
                            }
                        }
                        Constant.displayImageList = new ArrayList<>();
                        Constant.displayImageList.addAll(dataList);
                        Intent intent = new Intent(PrivateActivity.this, ImageShowActivity.class);
                        intent.putExtra("pos", temp_pos);
                        intent.putExtra("IsPrivateList", true);
                        intent.putExtra("IsFavList", true);
                        intent.putExtra("IsShowSlideShow", false);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onLongClickPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                model.setCheckboxVisible(true);
                            }
                    }
                    imageList.setCheckboxVisible(true);
                    imageList.setSelected(true);
                    favoriteAdapter.notifyDataSetChanged();
                    setSelectedFile();
                }
            }
        });
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(final int position) {
                if (favoriteAdapter.getItemViewType(position) == FavoriteAdapter.ITEM_HEADER_TYPE) {
                    return 3;
                }
                return 1;
            }
        });
        binding.recyclerView.setAdapter(favoriteAdapter);
        if (photoList != null && photoList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void showDeleteDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_delete);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_delete = dialog.findViewById(R.id.btn_delete);

        btn_delete.setOnClickListener(view -> {
            dialog.dismiss();
            deletePhoto();
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    String databasePath;

    private void unhideData() {

        ArrayList<String> deleteList = new ArrayList<>();
        Dialog dialog = new Dialog(this, R.style.WideDialog);
        TextView btnCancel, txtProgressCount, txtTitle, txt_top_title;
        ProgressBar progressBar;

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dilaog_delete_progress);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        btnCancel = dialog.findViewById(R.id.btnCancel);
        txt_top_title = dialog.findViewById(R.id.txt_top_title);
        txtTitle = dialog.findViewById(R.id.txt_title);
        txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
        progressBar = dialog.findViewById(R.id.progress_bar);
        progressBar.setMax(selected_Item);

        runOnUiThread(() -> {
            txt_top_title.setText(getText(R.string.Unhide));
            int progress = (deleteList.size() / 100) * selected_Item;
            txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
            progressBar.setProgress(deleteList.size());
        });

        btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();

        Observable.fromCallable(() -> {
                    HashMap<String, String> map = new HashMap<>();
                    ArrayList<String> newImageList = new ArrayList<>();
                    ArrayList<UnHideEvent> unHideList = new ArrayList<>();
                    map = database.getHideMainPath();
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                if (model.isSelected()) {
                                    runOnUiThread(() -> {
                                        txtTitle.setText(model.getFileName());
                                    });
                                    if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                                        String path = null;
                                        String fileName = model.getFileName();
                                        Set<String> keys = map.keySet();
                                        for (String k : keys) {
                                            if (k.contains(fileName)) {
                                                databasePath = k;
                                                path = map.get(k);
                                                break;
                                            }
                                        }
                                        if (path != null) {
                                            if (!path.contains(Constant.DIRECTORY_PICTURES_PATH) && !path.contains(Constant.DIRECTORY_DCIM_PATH)) {
                                                path = Constant.UNHIDE_PATH_11;
                                            } else if (path.contains(Constant.DIRECTORY_PICTURES_PATH)) {
                                                String mainPath = path;
                                                mainPath = mainPath.replace(Constant.DIRECTORY_PICTURES_PATH, "");
                                                path = Environment.DIRECTORY_PICTURES + mainPath;
                                            } else if (path.contains(Constant.DIRECTORY_DCIM_PATH)) {
                                                String mainPath = path;
                                                mainPath = mainPath.replace(Constant.DIRECTORY_DCIM_PATH, "");
                                                path = Environment.DIRECTORY_DCIM + mainPath;
                                            }
                                        }
                                        if (path == null || path.equals("")) {
                                            path = Constant.UNHIDE_PATH_11;
                                        }

                                        File file = new File(path);
                                        String folderName = file.getName();
                                        String folderPath = file.getPath();

                                        if (!file.exists())
                                            file.mkdirs();

                                        String hidden_URI = preferencesManager.getHideUri();
                                        if (!hidden_URI.equals("") && hidden_URI != null && hidden_URI.endsWith(Constant.HIDE_FOLDER_NAME)) {

                                            String selectFolderPath = folderPath;
                                            String selectFolderName = folderName;
                                            File to = new File(model.getFilePath());
                                            Uri treeUri = Uri.parse(preferencesManager.getHideUri());
                                            if (treeUri != null) {
                                                getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                                                DocumentFile tree = DocumentFile.fromTreeUri(this, treeUri);
                                                for (DocumentFile documentFile : tree.listFiles()) {
                                                    Log.e("DocumentFile", "DocumentFileNAme: " + documentFile.getName());
                                                    if (documentFile.getName().equals(model.getFileName())) {
                                                        boolean isUnHide = unhideFileOnAboveQ(this, documentFile.getUri(), model.getFileName(), folderPath);
                                                        if (isUnHide) {
                                                            documentFile.delete();
                                                            if (databasePath != null) {
                                                                database.deletePrivate(databasePath);
                                                                databasePath = null;
                                                            }
                                                            String imageFolderPath;
                                                            imageFolderPath = folderPath;
                                                            if (folderPath.contains(Environment.DIRECTORY_PICTURES)) {
                                                                imageFolderPath = imageFolderPath.replace(Environment.DIRECTORY_PICTURES,
                                                                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath());
                                                            } else if (folderPath.contains(Environment.DIRECTORY_DCIM)) {
                                                                imageFolderPath = imageFolderPath.replace(Environment.DIRECTORY_DCIM,
                                                                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getPath());
                                                            }
                                                            newImageList = new ArrayList<>();
                                                            newImageList.add(imageFolderPath + "/" + model.getFileName());
                                                            unHideList.add(new UnHideEvent(imageFolderPath + "/" + model.getFileName(), selectFolderName, imageFolderPath));
                                                            deleteList.add(model.getFilePath());
                                                            setUnFavorite(to.getPath());
                                                            MediaScannerConnection.scanFile(PrivateActivity.this, new String[]{to.getPath()}, null, (path1, uri) -> {
                                                            });
                                                            // RxBus.getInstance().post(new CopyMoveEvent(newImageList, selectFolderName, imageFolderPath, deleteList));

                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        runOnUiThread(() -> {
                                            int progress = (deleteList.size() / 100) * selected_Item;
                                            txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
                                            progressBar.setProgress(deleteList.size());
                                        });


                                    } else {
                                        File to = new File(model.getFilePath());
                                        try {
                                            databasePath = model.getFilePath();
                                            String path = map.get(model.getFilePath());
                                            if (path == null) {
                                                path = Constant.UNHIDE_PATH;
                                            }
                                            File unHidePath = new File(path);
                                            String selectFolderName = unHidePath.getParentFile().getName();
                                            String imageFolderPath = unHidePath.getParentFile().getPath();

                                            File hidePath = moveFile(to, new File(path));
                                            if (hidePath != null) {
                                                if (databasePath != null) {
                                                    database.deletePrivate(databasePath);
                                                    databasePath = null;
                                                }
//                                                database.addPrivate(hidePath.getPath(), to.getParent());

                                                deleteList.add(to.getPath());
                                                newImageList.add(path + "/" + to.getName());
                                                unHideList.add(new UnHideEvent(path + "/" + to.getName(), selectFolderName, imageFolderPath));
                                                setUnFavorite(to.getPath());
                                                MediaScannerConnection.scanFile(PrivateActivity.this, new String[]{to.getPath()}, null, (path1, uri) -> {
                                                });
//                                                RxBus.getInstance().post(new CopyMoveEvent(newImageList, selectFolderName, imageFolderPath, deleteList));
                                            }
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }

                                        runOnUiThread(() -> {
                                            int progress = (deleteList.size() / 100) * selected_Item;
                                            txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
                                            progressBar.setProgress(deleteList.size());
                                        });
                                    }
                                } else {
                                    model.setCheckboxVisible(false);
                                }
                            }
                    }
                    RxBus.getInstance().post(new UnHideDataEvent(unHideList, deleteList));
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                if (model.isSelected()) {
                                    boolean isPre = false, isNext = false;

                                    if (i != 0) {
                                        isPre = photoList.get(i - 1) instanceof AlbumData;
                                    }

                                    if (i < (photoList.size() - 2)) {
                                        isNext = photoList.get(i + 1) instanceof AlbumData;
                                    }

                                    if (isPre && isNext) {
                                        //  objectList.remove(i + 1);
                                        photoList.remove(i);
                                        photoList.remove(i - 1);

                                    } else if (i == (photoList.size() - 1)) {
                                        photoList.remove(i);
                                        if (isPre) {
                                            photoList.remove(i - 1);
                                        }
                                    } else {
                                        photoList.remove(i);
                                    }

                                    if (i != 0) {
                                        i--;
                                    }
                                }
                            }
                    }

                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    runOnUiThread(() -> {
                        RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));

                        binding.toolbar.setVisibility(View.VISIBLE);
                        binding.selectToolbar.setVisibility(View.GONE);
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        favoriteAdapter.notifyDataSetChanged();
                        if (photoList != null && photoList.size() != 0) {
                            binding.recyclerView.setVisibility(View.VISIBLE);
                            binding.loutNoData.setVisibility(View.GONE);
                        } else {
                            binding.recyclerView.setVisibility(View.GONE);
                            binding.loutNoData.setVisibility(View.VISIBLE);
                        }
                    });

                })
                .subscribe((result) -> {
                    runOnUiThread(() -> {
                        RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));

                        binding.toolbar.setVisibility(View.VISIBLE);
                        binding.selectToolbar.setVisibility(View.GONE);
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        favoriteAdapter.notifyDataSetChanged();
                        if (photoList != null && photoList.size() != 0) {
                            binding.recyclerView.setVisibility(View.VISIBLE);
                            binding.loutNoData.setVisibility(View.GONE);
                        } else {
                            binding.recyclerView.setVisibility(View.GONE);
                            binding.loutNoData.setVisibility(View.VISIBLE);
                        }
                    });
                });

    }

    private File moveFile(File file, File dir) throws IOException {
        File newFile = getFileName(0, dir, file.getName());

        try (FileChannel outputChannel = new FileOutputStream(newFile).getChannel(); FileChannel inputChannel = new FileInputStream(file).getChannel()) {
            inputChannel.transferTo(0, inputChannel.size(), outputChannel);
            inputChannel.close();
            file.delete();

            MediaScannerConnection.scanFile(PrivateActivity.this, new String[]{file.getPath()}, null, (path, uri) -> {
                // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
            });

            MediaScannerConnection.scanFile(PrivateActivity.this, new String[]{newFile.getPath()}, null, (path, uri) -> {
                // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
            });
        }

        return newFile;
    }

    private File getFileName(int i, File dir, String name) {
        File check = new File(dir, name);
        if (check.exists()) {
            i++;
            if (name.indexOf(".") > 0) {
                String extension = name.substring(name.lastIndexOf(".") - 1);
                name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + extension;
            }
            check = getFileName(i, dir, name);
        }
        return check;
    }

    public boolean unhideFileOnAboveQ(Context context, Uri uri, String name, String relativePath) {
        Log.e("unhideFileOnAboveQ", "relativePath: " + relativePath);
        ContentResolver contentResolver = context.getContentResolver();
        FileOutputStream fos = null;
        String folderName = "";

//        String relativePath = Environment.DIRECTORY_PICTURES + File.separator +
//                "Secret Folder Unhide";

        String mimeType = Utils.getFileType(name);

        try {
            if (Utils.isImage(name.split("\\.")[1])) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, name.split("\\.")[0]);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                FileInputStream inputStream = (FileInputStream) contentResolver.openInputStream(uri);
                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                FileChannel inChannel = inputStream.getChannel();
                FileChannel outChannel = fos.getChannel();
                outChannel.transferFrom(inChannel, 0, inChannel.size());
                inChannel.close();
                outChannel.close();
                return true;

            } else {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, name.split("\\.")[0]);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "video/" + mimeType);
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);

                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                FileInputStream inStream = (FileInputStream) contentResolver.openInputStream(uri);
                FileChannel inChannel = inStream.getChannel();
                FileChannel outChannel = fos.getChannel();
                inChannel.transferTo(0, inChannel.size(), outChannel);
                inStream.close();
                fos.close();
                return true;

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Log.e("TAG121", "unhideFileOnAboveQ: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("TAG121", "unhideFileOnAboveQ: " + e.getMessage());
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    private void setUnFavorite(String filePath) {
        List<String> favList = preferencesManager.getFavoriteList();
        if (favList == null) {
            favList = new ArrayList<>();
        }
        for (int f = 0; f < favList.size(); f++) {
            if (favList.get(f) != null && !favList.get(f).equalsIgnoreCase("")) {
                if (favList.get(f).equalsIgnoreCase(filePath)) {
                    favList.remove(f);
                    break;
                }
            }
        }
        preferencesManager.setFavoriteList(favList);
    }

    private void deletePhoto() {
        ArrayList<String> deleteList = new ArrayList<>();
        Dialog dialog = new Dialog(this, R.style.WideDialog);
        TextView btnCancel, txtProgressCount, txtTitle;
        ProgressBar progressBar;

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dilaog_delete_progress);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        btnCancel = dialog.findViewById(R.id.btnCancel);
        txtTitle = dialog.findViewById(R.id.txt_title);
        txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
        progressBar = dialog.findViewById(R.id.progress_bar);
        progressBar.setMax(selected_Item);
        runOnUiThread(() -> {
            int progress = (deleteList.size() / 100) * selected_Item;
            txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
            progressBar.setProgress(deleteList.size());

        });
        btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();

        Observable.fromCallable(() -> {
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                if (model.isSelected()) {

                                    runOnUiThread(() -> {
                                        txtTitle.setText(model.getFileName());
                                    });

                                    if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                                        DocumentFile file = DocumentFile.fromSingleUri(PrivateActivity.this, Uri.parse(model.getFilePath()));
                                        file.delete();
                                    } else {
                                        File file = new File(model.getFilePath());
                                        Uri deleteUrl = FileProvider.getUriForFile(PrivateActivity.this, getApplicationContext().getPackageName() + ".provider", file);
                                        ContentResolver contentResolver = getContentResolver();
                                        contentResolver.delete(deleteUrl, null, null);
                                        try {
                                            file.delete();
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                        MediaScannerConnection.scanFile(PrivateActivity.this, new String[]{model.getFilePath()}, null, (path, uri) -> {
                                            // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                                        });
                                    }
                                    deleteList.add(model.getFilePath());
                                    runOnUiThread(() -> {
                                        int progress = (deleteList.size() / 100) * selected_Item;
                                        txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
                                        progressBar.setProgress(deleteList.size());
                                    });
                                } else {
                                    model.setCheckboxVisible(false);
                                }
                            }
                    }

                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                if (model.isSelected()) {
                                    boolean isPre = false, isNext = false;

                                    if (i != 0) {
                                        isPre = photoList.get(i - 1) instanceof AlbumData;
                                    }

                                    if (i < (photoList.size() - 2)) {
                                        isNext = photoList.get(i + 1) instanceof AlbumData;
                                    }

                                    if (isPre && isNext) {
                                        //  objectList.remove(i + 1);
                                        photoList.remove(i);
                                        photoList.remove(i - 1);

                                    } else if (i == (photoList.size() - 1)) {
                                        photoList.remove(i);
                                        if (isPre) {
                                            photoList.remove(i - 1);
                                        }
                                    } else {
                                        photoList.remove(i);
                                    }

                                    if (i != 0) {
                                        i--;
                                    }
                                }
                            }
                    }

                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    runOnUiThread(() -> {
                        RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                        binding.toolbar.setVisibility(View.VISIBLE);
                        binding.selectToolbar.setVisibility(View.GONE);
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        selected_Item = 0;
                        favoriteAdapter.notifyDataSetChanged();
                        if (photoList != null && photoList.size() != 0) {
                            binding.recyclerView.setVisibility(View.VISIBLE);
                            binding.loutNoData.setVisibility(View.GONE);
                        } else {
                            binding.recyclerView.setVisibility(View.GONE);
                            binding.loutNoData.setVisibility(View.VISIBLE);
                        }
                        Toast.makeText(PrivateActivity.this, getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
                    });
                })
                .subscribe((result) -> {
                    runOnUiThread(() -> {
                        RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                        binding.toolbar.setVisibility(View.VISIBLE);
                        binding.selectToolbar.setVisibility(View.GONE);
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        selected_Item = 0;
                        favoriteAdapter.notifyDataSetChanged();
                        if (photoList != null && photoList.size() != 0) {
                            binding.recyclerView.setVisibility(View.VISIBLE);
                            binding.loutNoData.setVisibility(View.GONE);
                        } else {
                            binding.recyclerView.setVisibility(View.GONE);
                            binding.loutNoData.setVisibility(View.VISIBLE);
                        }
                        Toast.makeText(PrivateActivity.this, getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
                    });
                });

    }

    private void setSelectedFile() {
        int selected = 0;
        long size = 0;
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                        size += model.getFileSize();
                    }
                }
        }
        if (selected == 0) {
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
            setRefreshData(true);
            setClose();
        } else {
            binding.toolbar.setVisibility(View.GONE);
            binding.selectToolbar.setVisibility(View.VISIBLE);
            setRefreshData(false);
        }
        binding.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
        if (size == 0)
            isSelectAll = false;
        selected_Item = selected;
    }

    public void setRefreshData(boolean isEnable) {
        if (isEnable)
            binding.swipeRefreshLayout.setEnabled(true);
        else
            binding.swipeRefreshLayout.setEnabled(false);
    }

    private void setClose() {
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);
                }
        }
        if (favoriteAdapter != null) {
            favoriteAdapter.notifyDataSetChanged();
        }
        isSelectAll = false;
        setRefreshData(true);
        binding.toolbar.setVisibility(View.VISIBLE);
        binding.selectToolbar.setVisibility(View.GONE);
    }

    public boolean isImageFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("image");
    }

    private void getHideData() {
        Log.e("getHideData", " call");
        photoList.clear();
        LinkedHashMap<String, ArrayList<PictureData>> bucketImagesDataPhotoHashMap = new LinkedHashMap<>();
        if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
            Log.e("getHideData", "hide uri " + preferencesManager.getHideUri());
            Uri treeUri = Uri.parse(preferencesManager.getHideUri());
            if (treeUri != null)
                if (!treeUri.equals("")) {
                    try {
                        getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        DocumentFile tree = DocumentFile.fromTreeUri(this, treeUri);
                        Log.e("getHideData", " tree files");
                        if (tree != null && tree.isDirectory()) {
                            SimpleDateFormat format = new SimpleDateFormat("EEEE, MMM dd yyyy");
//                            Calendar calendar = Calendar.getInstance();
//                            String today = format.format(calendar.getTimeInMillis());
//                            calendar.add(Calendar.DATE, -1);
//                            String yesterday = format.format(calendar.getTimeInMillis());
                            List<String> favList = preferencesManager.getFavoriteList();

                            for (DocumentFile file : tree.listFiles()) {
                                Log.e("getHideData", " checking image or video");
                                if (Utils.isImage(Utils.getFileType(file.getName())) ||
                                        Utils.isVideo(Utils.getFileType(file.getName()))) {

                                    String strDate = format.format(file.lastModified());
//                                    if (strDate.equals(today)) {
//                                        strDate = getString(R.string.Today);
//                                    } else if (strDate.equals(yesterday)) {
//                                        strDate = getString(R.string.Yesterday);
//                                    }

                                    PictureData imagesData = new PictureData();
                                    imagesData.setFilePath(file.getUri().toString());
                                    imagesData.setFileName(file.getName());
                                    imagesData.setFavorite(false);
                                    imagesData.setFileSize(file.length());
                                    imagesData.setDate(file.lastModified());
                                    if (favList != null && favList.size() != 0) {
                                        for (int i = 0; i < favList.size(); i++) {
                                            if (favList.get(i).equalsIgnoreCase(file.getUri().toString())) {
                                                imagesData.setFavorite(true);
                                                break;
                                            }
                                        }
                                    }
                                    if (Utils.isImage(Utils.getFileType(file.getName()))) {
                                        imagesData.setVideo(false);
                                    } else {
                                        Log.e("getHideData", "get video duration");
                                        imagesData.setVideo(true);
                                        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
//                                mmr.setDataSource(file.getUri().toString());
                                        mmr.setDataSource(PrivateActivity.this, file.getUri());
                                        String durations = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                                        mmr.release();
//                                        String temp_duration = Utils.setDuration(Integer.parseInt(durations));
                                        imagesData.setVideoDuration(Long.parseLong(durations));
                                        Log.e("getHideData", "get video duration end");
                                    }

                                    ArrayList<PictureData> imagesData1;
                                    if (bucketImagesDataPhotoHashMap.containsKey(strDate)) {
                                        imagesData1 = bucketImagesDataPhotoHashMap.get(strDate);
                                        if (imagesData1 == null)
                                            imagesData1 = new ArrayList<>();

                                    } else {
                                        imagesData1 = new ArrayList<>();
                                    }
                                    imagesData1.add(imagesData);
                                    bucketImagesDataPhotoHashMap.put(strDate, imagesData1);
                                }
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e("getHideData", "Exception  " + e.getMessage());
                        runOnUiThread(this::setAdapter);
                    }
                }
        } else {
            if (new File(Constant.HIDE_PATH).exists()) {
                List<File> listFile = Arrays.asList(Objects.requireNonNull(new File(Constant.HIDE_PATH).listFiles()));
                Collections.sort(listFile, (file1, file2) -> {
                    SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.ENGLISH);
                    String strDate1 = format.format(file1.lastModified());
                    String strDate2 = format.format(file2.lastModified());
                    int compareResult;
                    Date date1 = null;
                    Date date2 = null;
                    try {
                        date1 = format.parse(strDate1);
                        date2 = format.parse(strDate2);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    compareResult = Objects.requireNonNull(date2).compareTo(date1);
                    return compareResult;
                });
                List<String> favList = preferencesManager.getFavoriteList();
                SimpleDateFormat format = new SimpleDateFormat("dd MMMM yyyy");
                Calendar calendar = Calendar.getInstance();
                String today = format.format(calendar.getTimeInMillis());
                calendar.add(Calendar.DATE, -1);
                String yesterday = format.format(calendar.getTimeInMillis());
                for (int f = 0; f < listFile.size(); f++) {
                    File file = listFile.get(f);
                    if (file != null && file.exists()) {
                        String strDate = format.format(file.lastModified());
//                        if (strDate.equals(today)) {
//                            strDate = getString(R.string.Today);
//                        } else if (strDate.equals(yesterday)) {
//                            strDate = getString(R.string.Yesterday);
//                        }
                        PictureData imagesData = new PictureData();
                        imagesData.setFilePath(file.getPath());
                        imagesData.setFileName(file.getName());
                        imagesData.setFileSize(file.length());
                        imagesData.setFavorite(false);
                        if (favList != null && favList.size() != 0) {
                            for (int i = 0; i < favList.size(); i++) {
                                if (favList.get(i).equalsIgnoreCase(file.getPath())) {
                                    imagesData.setFavorite(true);
                                    break;
                                }
                            }
                        }
                        if (isImageFile(file.getPath())) {
                            imagesData.setVideo(false);
                        } else {
                            imagesData.setVideo(true);
                            try {
                                MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                                mmr.setDataSource(file.getPath());
                                String durations = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                                mmr.release();
//                                String temp_duration = Utils.setDuration(Integer.parseInt(durations));
                                imagesData.setVideoDuration(Long.parseLong(durations));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        ArrayList<PictureData> imagesData1;
                        if (bucketImagesDataPhotoHashMap.containsKey(strDate)) {
                            imagesData1 = bucketImagesDataPhotoHashMap.get(strDate);
                            if (imagesData1 == null)
                                imagesData1 = new ArrayList<>();

                        } else {
                            imagesData1 = new ArrayList<>();
                        }
                        imagesData1.add(imagesData);
                        bucketImagesDataPhotoHashMap.put(strDate, imagesData1);
                    }

                }


            } else {
                runOnUiThread(() -> new File(Constant.HIDE_PATH).mkdirs());
            }
        }

        Set<String> keys = bucketImagesDataPhotoHashMap.keySet();
        ArrayList<String> listKeys = new ArrayList<>(keys);
        Log.e("getHideData", "set list   ");
        if (listKeys.size() != 0)
            for (int i = 0; i < listKeys.size(); i++) {
                ArrayList<PictureData> imagesData = bucketImagesDataPhotoHashMap.get(listKeys.get(i));
                if (imagesData != null && imagesData.size() != 0) {
                    AlbumData bucketData = new AlbumData();
                    bucketData.setTitle(listKeys.get(i));
                    bucketData.setPictureData(imagesData);
                    photoList.add(bucketData);
                    photoList.addAll(imagesData);
                }
            }
        runOnUiThread(this::setAdapter);
    }

    private void DeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {
            if (event.getPos() != -1) {
                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList;
                    deleteList = event.getDeleteList();
                    if (photoList != null && photoList.size() != 0) {
                        for (int d = 0; d < deleteList.size(); d++) {
                            for (int i = 0; i < photoList.size(); i++) {
                                if (photoList.get(i) instanceof PictureData) {
                                    PictureData model = (PictureData) photoList.get(i);
                                    if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {
                                        boolean isPre = false, isNext = false;
                                        if (i != 0) {
                                            isPre = photoList.get(i - 1) instanceof AlbumData;
                                        }
                                        if (i < (photoList.size() - 2)) {
                                            isNext = photoList.get(i + 1) instanceof AlbumData;
                                        }
                                        if (isPre && isNext) {
                                            //  objectList.remove(i + 1);
                                            photoList.remove(i);
                                            photoList.remove(i - 1);
                                        } else if (i == (photoList.size() - 1)) {
                                            photoList.remove(i);
                                            if (isPre) {
                                                photoList.remove(i - 1);
                                            }
                                        } else {
                                            photoList.remove(i);
                                        }
                                        if (i != 0) {
                                            i--;
                                        }
                                        if (d == deleteList.size() - 1) {
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        if (favoriteAdapter != null) {
                            favoriteAdapter.notifyDataSetChanged();
                        }
                        if (photoList != null && photoList.size() != 0) {
                            binding.recyclerView.setVisibility(View.VISIBLE);
                            binding.loutNoData.setVisibility(View.GONE);
                        } else {
                            binding.recyclerView.setVisibility(View.GONE);
                            binding.loutNoData.setVisibility(View.VISIBLE);
                        }
                    }
                }
            }

        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void DisplayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {
            if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                ArrayList<String> deleteList;
                deleteList = event.getDeleteList();
                if (photoList != null && photoList.size() != 0) {
                    for (int d = 0; d < deleteList.size(); d++) {
                        for (int i = 0; i < photoList.size(); i++) {
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {
                                    boolean isPre = false, isNext = false;
                                    if (i != 0) {
                                        isPre = photoList.get(i - 1) instanceof AlbumData;
                                    }
                                    if (i < (photoList.size() - 2)) {
                                        isNext = photoList.get(i + 1) instanceof AlbumData;
                                    }
                                    if (isPre && isNext) {
                                        //  objectList.remove(i + 1);
                                        photoList.remove(i);
                                        photoList.remove(i - 1);

                                    } else if (i == (photoList.size() - 1)) {
                                        photoList.remove(i);
                                        if (isPre) {
                                            photoList.remove(i - 1);
                                        }
                                    } else {
                                        photoList.remove(i);
                                    }
                                    if (i != 0) {
                                        i--;
                                    }
                                    if (d == deleteList.size() - 1) {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (favoriteAdapter != null) {
                        favoriteAdapter.notifyDataSetChanged();
                    }
                    if (photoList != null && photoList.size() != 0) {
                        binding.recyclerView.setVisibility(View.VISIBLE);
                        binding.loutNoData.setVisibility(View.GONE);
                    } else {
                        binding.recyclerView.setVisibility(View.GONE);
                        binding.loutNoData.setVisibility(View.VISIBLE);
                    }
                }
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }
}