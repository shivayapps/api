package com.picturephoto.gallery.app.custom;

import android.app.Activity;
import android.view.View;

import com.picturephoto.gallery.app.ads.AdmobAdManager;

public class ClickListener implements View.OnClickListener {
    AdmobAdManager admobAdManager;
    Activity activity;
    AdmobAdManager.OnAdClosedListener onAdClosedListener;

    public ClickListener(Activity activity, AdmobAdManager admobAdManager, AdmobAdManager.OnAdClosedListener onAdClosedListener) {
        this.activity = activity;
        this.admobAdManager = admobAdManager;
        this.onAdClosedListener = onAdClosedListener;
    }

    @Override
    public void onClick(View view) {
        admobAdManager.loadInterstitialAd(activity, 2, () -> onAdClosedListener.onAdClosed());
    }
}