package com.picturephoto.gallery.app.event;

import com.picturephoto.gallery.app.model.AlbumData;

import java.util.ArrayList;

public class ImageShareDeleteEvent {

    String type;
    int pos;
    boolean isSelectAll = false;
    ArrayList<AlbumData> albumList = new ArrayList<>();

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public String getType() {
        return type;
    }

    public ArrayList<AlbumData> getAlbumList() {
        return albumList;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isSelectAll() {
        return isSelectAll;
    }

    public ImageShareDeleteEvent(int pos, String type) {
        this.type = type;
        this.pos = pos;
    }

    public ImageShareDeleteEvent(int pos, String type, boolean isSelectAll) {
        this.type = type;
        this.pos = pos;
        this.isSelectAll = isSelectAll;
    }

    public ImageShareDeleteEvent(int pos, String type, ArrayList<AlbumData> albumList) {
        this.type = type;
        this.pos = pos;
        this.albumList = albumList;
    }
}
