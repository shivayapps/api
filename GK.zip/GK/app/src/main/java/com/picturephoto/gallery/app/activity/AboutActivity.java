package com.picturephoto.gallery.app.activity;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.picturephoto.gallery.app.BuildConfig;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityAboutBinding;
import com.picturephoto.gallery.app.databinding.FeedbackDialogBinding;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

public class AboutActivity extends AppCompatActivity {

    ActivityAboutBinding binding;
    PreferencesManager preferencesManager;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAboutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        setSupportActionBar(binding.toolbar);

        binding.tvAppVersion.setText(getResources().getString(R.string.version2) + " " + BuildConfig.VERSION_NAME);
        binding.rateUs.setOnClickListener(view -> {
            rateUS();
        });

        binding.loutRate.btnRate.setOnClickListener(view -> {
            rateUS();
        });

        binding.ShareApp.setOnClickListener(view -> {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    getString(R.string.share_msg) + " https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        });
        binding.instagram.setOnClickListener(view -> {

        });
        binding.Contactus.setOnClickListener(view -> {
            showEmailDialog(getString(R.string.contact_msg), getString(R.string.contact_msg));
        });
        binding.reportBug.setOnClickListener(view -> {
            showEmailDialog(getString(R.string.report_bugs_title), getString(R.string.report_msg));
        });
        binding.feedback.setOnClickListener(view -> {
            showEmailDialog(getString(R.string.feedback_msg), getString(R.string.feedback_msg));
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialBackAd(this, 2, () -> finish());

    }

    private void rateUS() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    private void showEmailDialog(String title, String dec) {
        FeedbackDialogBinding feedBinding;
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        feedBinding = FeedbackDialogBinding.inflate(getLayoutInflater());
        dialog.setContentView(feedBinding.getRoot());
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        feedBinding.txtTitle.setText(title);
        feedBinding.txtDec.setText(dec);
        feedBinding.btnOk.setOnClickListener(view -> {
            if (!feedBinding.edtMsg.getText().toString().trim().isEmpty()) {
                Intent sendIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(getResources().getString(R.string.feedback_email))));
                sendIntent.putExtra(Intent.EXTRA_TEXT, feedBinding.edtMsg.getText().toString());
                sendIntent.putExtra(Intent.EXTRA_SUBJECT, title + ": " + getString(R.string.in_app_name));
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
                dialog.dismiss();
            } else {
                Toast.makeText(AboutActivity.this, getString(R.string.feedback_validation), Toast.LENGTH_SHORT).show();
            }
        });

        feedBinding.btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }
}