package com.picturephoto.gallery.app.fragment;

import static android.os.Build.VERSION.SDK_INT;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.activity.ImageShowActivity;
import com.picturephoto.gallery.app.adapter.FavoriteAdapter;
import com.picturephoto.gallery.app.databinding.FragmentRecentStatusBinding;
import com.picturephoto.gallery.app.event.CopyMoveEvent;
import com.picturephoto.gallery.app.interfaces.LongClickListener;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.Constant;
import com.picturephoto.gallery.app.utils.FileUtils;
import com.picturephoto.gallery.app.utils.StorageUtils;
import com.picturephoto.gallery.app.utils.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import io.reactivex.Observable;

public class RecentStatusFragment extends Fragment {

    FragmentRecentStatusBinding binding;
    PreferencesManager preferencesManager;
    List<Object> photoList = new ArrayList<>();
    private FavoriteAdapter favoriteAdapter;
    static LongClickListener longClickListener;
    int selected_Item = 0;

    public RecentStatusFragment() {
    }

    public static RecentStatusFragment newInstance() {
        RecentStatusFragment fragment = new RecentStatusFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentRecentStatusBinding.inflate(inflater, container, false);
        intView();
        return binding.getRoot();
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(requireActivity());
        getData();
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            getData();
        });

        binding.btnOpenWp.setOnClickListener(view -> {
            try {
                PackageManager pm = requireActivity().getPackageManager();
                Intent launchIntent = pm.getLaunchIntentForPackage("com.whatsapp");
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(launchIntent);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(requireActivity(), "Whatsapp is not install", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setLongClickListener(LongClickListener longClickListener) {
        this.longClickListener = longClickListener;
    }

    public void getData() {
        binding.swipeRefreshLayout.setRefreshing(true);
        Observable.fromCallable(() -> {
                    getImages();
                    return true;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .subscribe((result) -> {
                    try {
                        requireActivity().runOnUiThread(this::setData);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });

    }

    private void setData() {
        Log.e("getStatus", "setData");
        binding.swipeRefreshLayout.setRefreshing(false);
        binding.recyclerView.setVisibility(View.VISIBLE);
        if (favoriteAdapter != null)
            favoriteAdapter.notifyDataSetChanged();
        else
            setAdapter();

        setEmptyView();
    }

    private void setEmptyView() {
        if (photoList != null && photoList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void setAdapter() {
        binding.swipeRefreshLayout.setRefreshing(false);
        binding.recyclerView.setVisibility(View.VISIBLE);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(requireActivity(), 3, LinearLayoutManager.VERTICAL, false);
        binding.recyclerView.setLayoutManager(gridLayoutManager);
        favoriteAdapter = new FavoriteAdapter(requireActivity(), photoList, false, new FavoriteAdapter.OnSelectPicture() {
            @Override
            public void onSelectPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    if (imageList.isCheckboxVisible()) {
                        imageList.setSelected(!imageList.isSelected());
                        favoriteAdapter.notifyItemChanged(pos);
                        setSelectedFile();
                    } else {
                        int temp_pos = -1;
                        ArrayList<PictureData> dataList = new ArrayList<>();
                        for (int i = 0; i < photoList.size(); i++) {
                            if (photoList.get(i) instanceof PictureData) {
                                dataList.add((PictureData) photoList.get(i));
                                if (pos == i) {
                                    temp_pos = dataList.size() - 1;
                                }
                            }
                        }
                        Constant.displayImageList = new ArrayList<>();
                        Constant.displayImageList.addAll(dataList);
                        Intent intent = new Intent(requireActivity(), ImageShowActivity.class);
                        intent.putExtra("pos", temp_pos);
                        intent.putExtra("IsPrivateList", true);
                        intent.putExtra("IsFavList", false);
                        intent.putExtra("IsShowSlideShow", false);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onLongClickPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                model.setCheckboxVisible(true);
                            }
                    }
                    imageList.setCheckboxVisible(true);
                    imageList.setSelected(true);
                    favoriteAdapter.notifyDataSetChanged();
                    setSelectedFile();
                }
            }
        });
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(final int position) {
                if (favoriteAdapter.getItemViewType(position) == FavoriteAdapter.ITEM_HEADER_TYPE) {
                    return 3;
                }
                return 1;
            }
        });
        binding.recyclerView.setAdapter(favoriteAdapter);
    }

    private void setSelectedFile() {
        int selected = 0;
        long size = 0;
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                        size += model.getFileSize();
                    }
                }
        }

        if (selected == 0) {
            longClickListener.longClick(true, false, selected, size);
            setClose();
            setRefreshData(true);
        } else {
            setRefreshData(false);
            longClickListener.longClick(false, true, selected, size);
        }
        selected_Item = selected;
    }

    public void setRefreshData(boolean isEnable) {
        if (isEnable)
            binding.swipeRefreshLayout.setEnabled(true);
        else
            binding.swipeRefreshLayout.setEnabled(false);
    }

    public void setClose() {
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);
                }
        }
        if (favoriteAdapter != null) {
            favoriteAdapter.notifyDataSetChanged();
        }
        setRefreshData(true);
        selected_Item = 0;
    }

    public void getImages() {
        Log.e("getStatus", "call getImages");
        photoList.clear();
        File folder;
        LinkedHashMap<String, ArrayList<PictureData>> bucketImagesDataPhotoHashMap = new LinkedHashMap<>();
        List<String> favList = preferencesManager.getFavoriteList();
        SimpleDateFormat format = new SimpleDateFormat("EEEE, MMM dd yyyy");

        String FILE_TYPE_NO_MEDIA = ".";
        if (SDK_INT >= Build.VERSION_CODES.Q && !preferencesManager.getStoragePermission11()) {

            if (preferencesManager.getUriWp() != null && preferencesManager.getUriWp().endsWith(".Statuses")) {
                Uri treeUri = Uri.parse(preferencesManager.getUriWp());
                Log.e("getStatus", "get treeUri");
                if (treeUri != null) {
                    getActivity().getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                    DocumentFile tree = DocumentFile.fromTreeUri(getActivity(), treeUri);
//                    Log.e("getStatus", "get doc file");
                    if (tree.isDirectory()) {
                        DocumentFile[] documentFiles = tree.listFiles();
                        ArrayList<DocumentFile> list = new ArrayList(Arrays.asList(documentFiles));
                        Collections.sort(list, (p1, p2) -> {
                            return Long.compare(p2.lastModified(), p1.lastModified());
                        });
                        for (DocumentFile file : list) {
//                            Log.e("getStatus", "call get file ");
                            if (Utils.isWpFile(file.getName())) {
                                String strDate = format.format(file.lastModified());
                                Log.e("getStatus", "call check file validation strDate: " + strDate);
                                PictureData imagesData = new PictureData();
                                imagesData.setFilePath(file.getUri().toString());
//                                imagesData.setrFilePath(FileUtils.getRealPath(getActivity(), file.getUri()));
                                imagesData.setFileName(file.getName());
                                imagesData.setFavorite(false);
                                imagesData.setFileSize(file.length());
                                imagesData.setDate(file.lastModified());
                                imagesData.setFavorite(false);
//                                if (favList != null && favList.size() != 0) {
//                                    for (int i = 0; i < favList.size(); i++) {
//                                        if (favList.get(i).equalsIgnoreCase(file.getUri().toString())) {
//                                            imagesData.setFavorite(true);
//                                            break;
//                                        }
//                                    }
//                                }

//                                Log.e("getStatus", "call check file sec validation");
                                if (!Utils.isWpVideo(file.getName())) {
                                    imagesData.setVideo(false);
                                } else {
                                    imagesData.setVideo(true);
                                    MediaMetadataRetriever mmr = new MediaMetadataRetriever();
//                                mmr.setDataSource(file.getUri().toString());
                                    try {

                                        mmr.setDataSource(requireActivity(), file.getUri());
                                        String durations = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                                        mmr.release();
//                                        String temp_duration = Utils.setDuration(Integer.parseInt(durations));
                                        imagesData.setVideoDuration(Long.parseLong(durations));
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

                                ArrayList<PictureData> imagesData1;
                                if (bucketImagesDataPhotoHashMap.containsKey(strDate)) {
                                    imagesData1 = bucketImagesDataPhotoHashMap.get(strDate);
                                    if (imagesData1 == null)
                                        imagesData1 = new ArrayList<>();

                                } else {
                                    imagesData1 = new ArrayList<>();
                                    AlbumData bucketData = new AlbumData();
                                    bucketData.setTitle(strDate);
                                    photoList.add(bucketData);
                                    try {
                                        requireActivity().runOnUiThread(() -> {
                                            if (favoriteAdapter != null)
                                                favoriteAdapter.notifyItemInserted(photoList.size());
                                            else
                                                setAdapter();
                                            binding.swipeRefreshLayout.setRefreshing(false);
                                            binding.recyclerView.setVisibility(View.VISIBLE);
                                        });
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }

                                photoList.add(imagesData);
                                try {
                                    requireActivity().runOnUiThread(() -> {
                                        if (favoriteAdapter != null)
                                            favoriteAdapter.notifyItemInserted(photoList.size());
                                        else
                                            setAdapter();
                                        binding.swipeRefreshLayout.setRefreshing(false);
                                        binding.recyclerView.setVisibility(View.VISIBLE);
                                    });
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                imagesData1.add(imagesData);
                                bucketImagesDataPhotoHashMap.put(strDate, imagesData1);
                            }
                        }
                    }
                }
            }

        } else {
            if (SDK_INT >= Build.VERSION_CODES.Q)
                folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/Media/com.whatsapp/WhatsApp/Media/.Statuses");
            else
                folder = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp/Media/.Statuses");

            if (folder.isDirectory()) {
//                File[] allFiles = folder.listFiles((dir, name) -> (Utils.isImage(Utils.getFileType(name)) ||
//                        Utils.isVideo(Utils.getFileType(name))));
                File[] allFiles = folder.listFiles();

                if (allFiles != null) {
                    if (allFiles.length > 0) {
                        for (File file : allFiles) {
                            if (Utils.isImage(Utils.getFileType(file.getName())) || Utils.isVideo(Utils.getFileType(file.getName()))) {
                                String strDate = format.format(file.lastModified());
                                PictureData imagesData = new PictureData();
                                imagesData.setFilePath(file.getPath());
                                imagesData.setFileName(file.getName());
                                imagesData.setFavorite(false);
                                imagesData.setFileSize(file.length());
                                imagesData.setDate(file.lastModified());
                                if (favList != null && favList.size() != 0) {
                                    for (int i = 0; i < favList.size(); i++) {
                                        if (favList.get(i).equalsIgnoreCase(file.getPath())) {
                                            imagesData.setFavorite(true);
                                            break;
                                        }
                                    }
                                }

                                if (Utils.isImage(Utils.getFileType(file.getName()))) {
                                    imagesData.setVideo(false);
                                } else {
                                    imagesData.setVideo(true);
                                    MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                                    mmr.setDataSource(file.getPath());
                                    String durations = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                                    try {
                                        mmr.release();
                                    } catch (IOException ignored) {

                                    }
                                    imagesData.setVideoDuration(Long.parseLong(durations));
                                }

                                ArrayList<PictureData> imagesData1;
                                if (bucketImagesDataPhotoHashMap.containsKey(strDate)) {
                                    imagesData1 = bucketImagesDataPhotoHashMap.get(strDate);
                                    if (imagesData1 == null)
                                        imagesData1 = new ArrayList<>();

                                } else {
                                    imagesData1 = new ArrayList<>();
                                }
                                imagesData1.add(imagesData);
                                bucketImagesDataPhotoHashMap.put(strDate, imagesData1);
                            }
                        }
                    }
                }
            }

            Log.e("getStatus", "get listKeys");
            Set<String> keys = bucketImagesDataPhotoHashMap.keySet();
            ArrayList<String> listKeys = new ArrayList<>(keys);

            for (int i = 0; i < listKeys.size(); i++) {
                ArrayList<PictureData> imagesData = bucketImagesDataPhotoHashMap.get(listKeys.get(i));
                if (imagesData != null && imagesData.size() != 0) {
                    AlbumData bucketData = new AlbumData();
                    bucketData.setTitle(listKeys.get(i));
                    bucketData.setPictureData(imagesData);
                    photoList.add(bucketData);
                    photoList.addAll(imagesData);
                }
            }
        }

    }

    public void setAllSelect(boolean isSelectAll) {
        if (isSelectAll) {
            int selected = 0;
            long size = 0;
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        selected++;
                        size += model.getFileSize();
                        model.setSelected(true);
                    }
            }
            if (favoriteAdapter != null)
                favoriteAdapter.notifyDataSetChanged();
            longClickListener.longClick(false, true, selected, size);
            selected_Item = selected;
        } else {
            longClickListener.longClick(true, false, 0, 0);
            setClose();
        }
    }

    public void shareFile() {
        if (selected_Item != 0) {
            ArrayList<Uri> uris = new ArrayList<>();
            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.isSelected()) {
                            Uri uri;
                            if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                                uri = Uri.parse(model.getFilePath());
                            } else {
                                uri = FileProvider.getUriForFile(requireActivity(), requireActivity().getPackageName() + ".provider", new File(model.getFilePath()));
                            }
                            uris.add(uri);
                        }
                    }
            }
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(Intent.createChooser(intent,getString(R.string.share_with)), 909);
        } else
            Toast.makeText(getActivity(), getActivity().getString(R.string.Pleaseselectimage), Toast.LENGTH_SHORT).show();

    }

    public void downloadFile() {
        if (selected_Item != 0) {
            copyFiles();
        } else
            Toast.makeText(getActivity(), getActivity().getString(R.string.Pleaseselectimage), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 909) {
            setClose();
            longClickListener.longClick(true, false, 0, 0);
        }
    }

    private void copyFiles() {
        ArrayList<PictureData> copyMoveList = new ArrayList<>();

        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        copyMoveList.add(model);
                    }
                }
        }

        File targetFolder = new File(Constant.DOWNLOAD_WP_PATH);
        if (!targetFolder.exists())
            targetFolder.mkdirs();

        ArrayList<String> copyFiles = new ArrayList<>();
        Dialog dialog = new Dialog(requireActivity(), R.style.WideDialog);
        TextView btnCancel, txtProgressCount, txtTitle, txt_top_title;
        ProgressBar progressBar;

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dilaog_delete_progress);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        btnCancel = dialog.findViewById(R.id.btnCancel);
        txt_top_title = dialog.findViewById(R.id.txt_top_title);
        txtTitle = dialog.findViewById(R.id.txt_title);
        txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
        progressBar = dialog.findViewById(R.id.progress_bar);
        progressBar.setMax(selected_Item);

        requireActivity().runOnUiThread(() -> {
            txt_top_title.setText(getText(R.string.Downloading));
            int progress = (copyFiles.size() / 100) * selected_Item;
            txtProgressCount.setText(copyFiles.size() + "/" + selected_Item);
            progressBar.setProgress(copyFiles.size());
        });

        btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();

        Observable.fromCallable(() -> {
                    try {
                        for (int i = 0; i < copyMoveList.size(); i++) {
                            int finalI = i;
                            requireActivity().runOnUiThread(() -> {
                                txtTitle.setText(copyMoveList.get(finalI).getFileName());
                            });
//                            File copyFile = new File(copyMoveList.get(i).getrFilePath());
////                            if (copyFile.exists()) {
//                            String copyFileName = copyMoveList.get(i).getFileName();
//                            String targetPath = targetFolder.getPath() + File.separator + copyFileName;
//                            File targetFile = new File(targetPath);

                            String sourcePath = "";
                            if (SDK_INT >= Build.VERSION_CODES.Q && !preferencesManager.getStoragePermission11()) {
                                copyMoveList.get(i).setrFilePath(FileUtils.getRealPath(getActivity(), Uri.parse(copyMoveList.get(i).getFilePath())));
                                sourcePath = copyMoveList.get(i).getrFilePath();
                            } else
                                sourcePath = copyMoveList.get(i).getFilePath();

                            File source = new File(sourcePath);
                            String destinationPath = Constant.DOWNLOAD_WP_PATH + "/" + copyMoveList.get(i).getFileName();
                            File destination = new File(destinationPath);

                            if (SDK_INT >= Build.VERSION_CODES.Q && !preferencesManager.getStoragePermission11()) {
                                String savePath = copyFileOnAboveQ(sourcePath, Uri.parse(copyMoveList.get(i).getFilePath()), source.getName(), destination.getParentFile(), requireActivity());
                                if (savePath != null && !savePath.equals(""))
                                    copyFiles.add(savePath);
                            } else {
                                try {
                                    boolean isCopied = StorageUtils.copyFile(source, destination, requireActivity());
                                    if (isCopied) {
                                        copyFiles.add(destinationPath);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

//                            if (targetFile.exists()) {
//                                String[] separated = copyMoveList.get(i).getFileName().split("\\.");
//                                String name = separated[0];
//                                String type = separated[1];
//
//                                String newName = name + "_" + System.currentTimeMillis() + "." + type;
//                                String newPath2 =
//                                        targetFolder.getPath() + "/" + name + "_" + System.currentTimeMillis() + "." + type;
//                                File file2 = new File(newPath2);
//
//
//                                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
//                                    String filePath = copyFileOnAboveQ(copyMoveList.get(i).getrFilePath(), Uri.parse(copyMoveList.get(i).getFilePath()), newName, targetFolder, requireActivity());
//                                    if (filePath != null) {
//                                        copyFiles.add(filePath);
//                                    }
//
//                                } else {
//                                    boolean isCopied = StorageUtils.copyFile(copyFile, file2, requireActivity());
//                                    if (isCopied) {
//                                        copyFiles.add(file2.getPath());
//                                    }
//                                }
//                            } else {
//                                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
//                                    String[] separated = copyFileName.split("\\.");
//                                    String name = separated[0];
//                                    String filePath = copyFileOnAboveQ(copyMoveList.get(i).getrFilePath(), Uri.parse(copyMoveList.get(i).getFilePath()), name, targetFolder, requireActivity());
//                                    if (filePath != null) {
//                                        copyFiles.add(filePath);
//                                    }
//                                } else {
//                                    boolean isCopied = StorageUtils.copyFile(copyFile, targetFile, requireActivity());
//                                    if (isCopied) {
//                                        copyFiles.add(targetFile.getPath());
//                                    }
//                                }
//                            }

                            requireActivity().runOnUiThread(() -> {
                                int progress = (copyFiles.size() / 100) * selected_Item;
                                txtProgressCount.setText(copyFiles.size() + "/" + selected_Item);
                                progressBar.setProgress(copyFiles.size());
                            });

//                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    requireActivity().runOnUiThread(() -> {
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        RxBus.getInstance().post(new CopyMoveEvent(copyFiles, targetFolder.getName(), targetFolder.getAbsolutePath(), new ArrayList<>()));
                        Toast.makeText(getActivity(), getString(R.string.download_successfully), Toast.LENGTH_SHORT).show();
                        selected_Item = 0;
                        longClickListener.longClick(true, false, 0, 0);
                        setClose();
                    });
                })
                .subscribe((result) -> {
                    requireActivity().runOnUiThread(() -> {
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        RxBus.getInstance().post(new CopyMoveEvent(copyFiles, targetFolder.getName(), targetFolder.getAbsolutePath(), new ArrayList<>()));
                        Toast.makeText(getActivity(), getString(R.string.download_successfully), Toast.LENGTH_SHORT).show();
                        selected_Item = 0;
                        longClickListener.longClick(true, false, 0, 0);
                        setClose();
                    });
                });
    }

    public String getPath(Uri uri, Context context) {
        String[] projection = {MediaStore.Files.FileColumns.DATA};
        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
        if (cursor == null) return null;
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
        cursor.moveToFirst();
        String s = cursor.getString(column_index);
        cursor.close();
        return s;
    }

    public String copyFileOnAboveQ(@NonNull final String filePath, Uri uri, String newName, File targetFolder, Activity context) {
        ContentResolver contentResolver = context.getContentResolver();
        FileOutputStream fos = null;
        String folderName = targetFolder.getName();
        String relativePath = null;

        String fileName = new File(filePath).getName();
        String mimeType = getFileType(fileName);
        if (targetFolder.getPath().contains(Environment.DIRECTORY_PICTURES)) {
            relativePath = Environment.DIRECTORY_PICTURES + File.separator + "Gallery" + File.separator + folderName;

        } else if (targetFolder.getPath().contains(Environment.DIRECTORY_DCIM)) {
            relativePath = Environment.DIRECTORY_DCIM + File.separator + "Gallery" + File.separator + folderName;
        } else {
            relativePath = Environment.DIRECTORY_PICTURES + File.separator + "Gallery" + File.separator + folderName;
        }

        try {
            if (filePath.endsWith(".jpg") || filePath.endsWith(".png")) {

//                Bitmap bitmap = getBitmap(filePath);
                Bitmap bitmap = getBitmapFormUri(context, uri);
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/" + mimeType);
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);

                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)) {
                    fos.flush();
                }
                return getPath(imageUri, context);

            } else {

                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "video/" + mimeType);
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);


                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                FileInputStream inStream = new FileInputStream(context.getContentResolver().openFileDescriptor(uri, "r").getFileDescriptor());
//                inStream = new FileInputStream(filePath);
                FileChannel inChannel = inStream.getChannel();
                FileChannel outChannel = fos.getChannel();
                inChannel.transferTo(0, inChannel.size(), outChannel);
                inStream.close();
                fos.close();
                return getPath(imageUri, context);

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }


    public String getFileType(String fileName) {
        if (fileName != null) {
            int typeIndex = fileName.lastIndexOf(".");
            if (typeIndex != -1) {
                String fileType = fileName.substring(typeIndex + 1)
                        .toLowerCase();
                return fileType;
            }
        }
        return "";
    }

    public Bitmap getBitmapFormUri(Activity ac, Uri uri) throws FileNotFoundException, IOException {
        InputStream input = ac.getContentResolver().openInputStream(uri);
        BitmapFactory.Options onlyBoundsOptions = new BitmapFactory.Options();
        onlyBoundsOptions.inJustDecodeBounds = true;
        onlyBoundsOptions.inDither = true;//optional
        onlyBoundsOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;//optional
        BitmapFactory.decodeStream(input, null, onlyBoundsOptions);
        input.close();
        int originalWidth = onlyBoundsOptions.outWidth;
        int originalHeight = onlyBoundsOptions.outHeight;
        if ((originalWidth == -1) || (originalHeight == -1))
            return null;
        //Image resolution is based on 480x800
        float hh = 800f;//The height is set as 800f here
        float ww = 480f;//Set the width here to 480f
        //Zoom ratio. Because it is a fixed scale, only one data of height or width is used for calculation
        int be = 1;//be=1 means no scaling
        if (originalWidth > originalHeight && originalWidth > ww) {//If the width is large, scale according to the fixed size of the width
            be = (int) (originalWidth / ww);
        } else if (originalWidth < originalHeight && originalHeight > hh) {//If the height is high, scale according to the fixed size of the width
            be = (int) (originalHeight / hh);
        }
        if (be <= 0)
            be = 1;
        //Proportional compression
        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inSampleSize = be;//Set scaling
        bitmapOptions.inDither = true;//optional
        bitmapOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;//optional
        input = ac.getContentResolver().openInputStream(uri);
        Bitmap bitmap = BitmapFactory.decodeStream(input, null, bitmapOptions);
        input.close();

        return bitmap;//Mass compression again
    }

}