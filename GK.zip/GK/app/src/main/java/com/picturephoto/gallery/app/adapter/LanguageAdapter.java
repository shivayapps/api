package com.picturephoto.gallery.app.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.picturephoto.gallery.app.R;

import java.util.ArrayList;

public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.ViewHolder> {

    FragmentActivity activity;
    ArrayList<String> folderList;
    OnSelectAlbum onSelectAlbum;
    int selectedLanguage;

    public LanguageAdapter(FragmentActivity activity, ArrayList<String> albums, int selectedLanguage, OnSelectAlbum onSelectAlbum) {
        this.activity = activity;
        this.onSelectAlbum = onSelectAlbum;
        this.folderList = albums;
        this.selectedLanguage = selectedLanguage;
    }


    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_langunge, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.txt_name.setText(folderList.get(position));
        if (selectedLanguage == position)
            holder.iv_select.setVisibility(View.VISIBLE);
        else
            holder.iv_select.setVisibility(View.INVISIBLE);
        holder.lout_row.setOnClickListener(view -> {
            selectedLanguage = position;
            onSelectAlbum.onClickAlbum(position);
        });
    }

    @Override
    public int getItemCount() {
        return folderList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_name;
        ImageView iv_select;
        LinearLayout lout_row;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_name = itemView.findViewById(R.id.txt_name);
            iv_select = itemView.findViewById(R.id.iv_select);
            lout_row = itemView.findViewById(R.id.lout_row);
        }
    }

    public interface OnSelectAlbum {
        void onClickAlbum(int pos);
    }
}
