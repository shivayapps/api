package com.picturephoto.gallery.app.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.custom.TwoLineSeekBar;
import com.picturephoto.gallery.app.databinding.ActivityEditPhotoBinding;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RotateActivity extends AppCompatActivity {

    ActivityEditPhotoBinding binding;
    String imagePath = "";
    int rotate = 0;
    PreferencesManager preferencesManager;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditPhotoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void onBackPressed() {

        admobAdManager.loadInterstitialBackAd(this, 2, () ->  finish());
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        imagePath = getIntent().getStringExtra("EditImage");
        binding.loutCountRotation.setVisibility(View.GONE);
        binding.txtTitle.setText(getString(R.string.Rotate));
        binding.txtType.setText(getString(R.string.Rotate));

        binding.ivDisplay.setRotation(rotate);
        binding.txtCount.setText(String.valueOf(rotate));

        binding.twoLine.setSeekLength(0, 360, 0, 0.5f);
        binding.twoLine.setValue(rotate);

        Glide.with(this)
                .load(imagePath)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .into(binding.ivDisplay);

        intClickListener();
    }



    private void intClickListener() {
        binding.icBack.setOnClickListener(view -> {
            onBackPressed();
        });

        binding.icDone.setOnClickListener(view -> {
            String imagePath = saveImage();
            if (imagePath != null) {
                Intent intent = new Intent();
                intent.putExtra("imagePath",imagePath);
                setResult(RESULT_OK,intent);
            }
            finish();
        });

        binding.twoLine.setOnSeekChangeListener(new TwoLineSeekBar.OnSeekChangeListener() {
            @Override
            public void onSeekChanged(float value, float step) {
                if (binding.loutCountRotation.getVisibility() == View.GONE)
                    binding.loutCountRotation.setVisibility(View.VISIBLE);

                rotate = (int) value;
                binding.ivDisplay.setRotation(rotate);
                binding.txtCount.setText(String.valueOf(rotate));

            }

            @Override
            public void onSeekStopped(float value, float step) {
                binding.loutCountRotation.setVisibility(View.GONE);
            }
        });

    }

    private String saveImage() {
        File dir = new File(getCacheDir().getAbsolutePath());
        if (!dir.exists())
            dir.mkdirs();

        Bitmap myBitmap = BitmapFactory.decodeFile(imagePath);
        Bitmap bitmap = rotateBitmap(myBitmap, rotate);

        String timeStamp = new SimpleDateFormat("HHmmss_dMyy").format(new Date());
        String imageName = "IMG_" + timeStamp + ".jpg";
        File pictureFile = new File(dir.getPath() + "/" + imageName);

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(pictureFile.getPath());
            bitmap.compress(Bitmap.CompressFormat.WEBP, 70, out);

            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            Uri contentUri = Uri.fromFile(pictureFile);
            mediaScanIntent.setData(contentUri);
            sendBroadcast(mediaScanIntent);

            MediaScannerConnection.scanFile(RotateActivity.this, new String[]{pictureFile.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });
            return pictureFile.getPath();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public Bitmap rotateBitmap(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, false);
    }
}