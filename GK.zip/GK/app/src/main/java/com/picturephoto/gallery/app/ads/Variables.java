package com.picturephoto.gallery.app.ads;


public class Variables {
    public static boolean  isSplashScreen = false;
    public static boolean  isSPermissionScreen = false;
    public static boolean  isAdLoad = false;
    public static boolean  isBackAdLoad = false;
    public static boolean  isAdLoadFailed = false;
    public static boolean  isBackAdLoadFailed = false;
    public static boolean  isNativeAdLoad = false;
    public static boolean  isNativeAdLoadFailed = false;

}
