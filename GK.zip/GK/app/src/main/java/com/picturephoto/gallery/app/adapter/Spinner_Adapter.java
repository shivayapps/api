package com.picturephoto.gallery.app.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.picturephoto.gallery.app.R;


public class Spinner_Adapter extends BaseAdapter {
    Activity activity;
    String[] home_mdual_name;
    LayoutInflater inflater;

    public Spinner_Adapter(Activity activity, String[] home_mdual_name) {
        this.activity = activity;
        this.home_mdual_name = home_mdual_name;
        inflater = LayoutInflater.from(activity);
    }

    @Override
    public int getCount() {
        return home_mdual_name.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.item_spinner, parent, false);
        TextView spinner_item = (TextView) convertView.findViewById(R.id.spinner_item);
        spinner_item.setText(home_mdual_name[position]);
        return convertView;
    }
}
