package com.picturephoto.gallery.app.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.custom.TwoLineSeekBar;
import com.picturephoto.gallery.app.databinding.ActivityEditPhotoBinding;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class OtherEditActivity extends AppCompatActivity {

    ActivityEditPhotoBinding binding;
    String imagePath = "";
    int type = 1;
    int progress = 0;
    float bri = 0.0f;
    Bitmap imageBitmap;
    Bitmap temp;
    PreferencesManager preferencesManager;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditPhotoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void intView() {
        imagePath = getIntent().getStringExtra("EditImage");
        type = getIntent().getIntExtra("Type", 1);
        preferencesManager = PreferencesManager.getInstance(this);
        binding.loutCountRotation.setVisibility(View.GONE);
        String title = "";
        if (type == 1) {
            title = getString(R.string.Saturation);
            progress = 100;
            binding.twoLine.setSeekLength(0, 100, 0, 0.5f);

        } else if (type == 2) {
            title = getString(R.string.Brightness);
            binding.twoLine.setSeekLength(-100, 100, 0, 0.5f);
        } else if (type == 3) {
            title = getString(R.string.Contrast);
            binding.twoLine.setSeekLength(-50, 50, 0, 0.5f);
        }

        binding.txtTitle.setText(title);
        binding.txtType.setText(title);

        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inMutable = true;
        imageBitmap = BitmapFactory.decodeFile(imagePath, bmOptions);

        binding.twoLine.setValue(progress);

        binding.txtCount.setText(String.valueOf(progress));
        Glide.with(this).load(imagePath).diskCacheStrategy(DiskCacheStrategy.NONE).skipMemoryCache(true).into(binding.ivDisplay);

        intClickListener();
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialBackAd(this, 2, () -> finish());
    }

    private void intClickListener() {
        binding.icBack.setOnClickListener(view -> {
            onBackPressed();
        });

        binding.icDone.setOnClickListener(view -> {
            String imagePath = saveImage();
            if (imagePath != null) {
                Intent intent = new Intent();
                intent.putExtra("imagePath", imagePath);
                setResult(RESULT_OK, intent);
            }
            finish();
        });

        binding.twoLine.setOnSeekChangeListener(new TwoLineSeekBar.OnSeekChangeListener() {
            @Override
            public void onSeekChanged(float value, float step) {
                if (binding.loutCountRotation.getVisibility() == View.GONE)
                    binding.loutCountRotation.setVisibility(View.VISIBLE);

                Log.e("onSeekChanged", "progress==>> " + (value * 2) + " value==>> " + value + " step==>> " + step);

                progress = (int) value;
                if (type == 1) temp = saturation(imageBitmap, (progress) / 100.0f);
                else if (type == 2) {
                    bri = (progress / 2);
                    temp = brightnessImage(imageBitmap, 1.0f, (int) bri);
                } else if (type == 3) {
                    temp = contrastBitmap(imageBitmap, (value + 100) / 100.0f);
                    progress = (int) (value * 2);
                }

                binding.txtCount.setText(String.valueOf(progress));
                binding.ivDisplay.setImageBitmap(temp);
            }

            @Override
            public void onSeekStopped(float value, float step) {
                binding.loutCountRotation.setVisibility(View.GONE);
            }
        });
    }

    private String saveImage() {
        File dir = new File(getCacheDir().getAbsolutePath());
        if (!dir.exists()) dir.mkdirs();

        Bitmap bitmap;
        if (temp != null) {
            bitmap = temp;
        } else {
            bitmap = imageBitmap;
        }

        String timeStamp = new SimpleDateFormat("HHmmss_dMyy").format(new Date());
        String imageName = "IMG_" + timeStamp + ".jpg";
        File pictureFile = new File(dir.getPath() + "/" + imageName);

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(pictureFile.getPath());
            bitmap.compress(Bitmap.CompressFormat.WEBP, 70, out);

            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            Uri contentUri = Uri.fromFile(pictureFile);
            mediaScanIntent.setData(contentUri);
            sendBroadcast(mediaScanIntent);

            MediaScannerConnection.scanFile(OtherEditActivity.this, new String[]{pictureFile.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });
            return pictureFile.getPath();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }


    private Bitmap saturation(Bitmap src, float settingSat) {
        Bitmap bitmapResult = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvasResult = new Canvas(bitmapResult);
        Paint paint = new Paint();
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(settingSat);
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        canvasResult.drawBitmap(src, 0.0f, 0.0f, paint);
        return bitmapResult;
    }

    public Bitmap brightnessImage(Bitmap mBitmap, float contrast, int brightness) {

        ColorMatrix cm = new ColorMatrix(new float[]{1, 0, 0, 0, brightness, 0, 1, 0, 0, brightness, 0, 0, 1, 0, brightness, 0, 0, 0, 1, 0});

        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.set(new float[]{contrast, 0, 0, 0, brightness, // Red
                0, contrast, 0, 0, brightness, // Green
                0, 0, contrast, 0, brightness, // Blue
                0, 0, 0, 1, 0}); // Alpha

        Bitmap mEnhancedBitmap = Bitmap.createBitmap(mBitmap.getWidth(), mBitmap.getHeight(), mBitmap.getConfig());
        Canvas canvas = new Canvas(mEnhancedBitmap);
        Paint paint = new Paint();
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(mBitmap, 0.0f, 0.0f, paint);
        /*Bitmap bitmapResult = Bitmap.createBitmap(mBitmap.getWidth(), mBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvasResult = new Canvas(bitmapResult);
        Paint paint = new Paint();
        paint.setAlpha(brightness);
        canvasResult.drawBitmap(mBitmap, 0.0f, 0.0f, paint);*/
        return mEnhancedBitmap;
    }

    Bitmap contrastBitmap(Bitmap bitmap, float contrast) {
        float[] colorTransform = new float[]{contrast, 0, 0, 0, 0, 0, contrast, 0, 0, 0, 0, 0, contrast, 0, 0, 0, 0, 0, 1, 0};

        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0f);
        colorMatrix.set(colorTransform);


        ColorMatrixColorFilter colorFilter = new ColorMatrixColorFilter(colorMatrix);
        Paint paint = new Paint();
        paint.setColorFilter(colorFilter);

        Bitmap resultBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(resultBitmap);
        canvas.drawBitmap(resultBitmap, 0, 0, paint);

        return resultBitmap;
    }
}