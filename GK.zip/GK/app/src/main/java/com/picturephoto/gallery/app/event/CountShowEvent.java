package com.picturephoto.gallery.app.event;

public class CountShowEvent {
    public CountShowEvent() {

    }
}
