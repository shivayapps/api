package com.picturephoto.gallery.app.activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityEditBinding;
import com.picturephoto.gallery.app.event.CopyMoveEvent;
import com.picturephoto.gallery.app.event.EditImageEvent;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.StorageUtils;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

import io.reactivex.Observable;

public class EditActivity extends AppCompatActivity {

    ActivityEditBinding binding;
    String imagePath = "";
    String mainImagePath = "";
    String cropOutputPath = "";
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        intView();
    }

    private void intView() {
        imagePath = getIntent().getStringExtra("EditImage");
        mainImagePath = getIntent().getStringExtra("EditImage");
        preferencesManager = PreferencesManager.getInstance(this);
        loadNativeBanner();
        imageLoad();
        intClickListener();
    }

    private void loadNativeBanner() {

        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void imageLoad() {
        final RequestOptions options = new RequestOptions()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .override(900, 900).dontTransform();
        binding.ivDisplay.getController().getSettings()
                .setMaxZoom(6f)
                .setDoubleTapZoom(3f);
        Glide.with(this).setDefaultRequestOptions(options)
                .load(imagePath)
                .into(binding.ivDisplay);
    }

    PreferencesManager preferencesManager;

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialBackAd(this, 2, () -> finish());
    }

    private void intClickListener() {
        binding.icBack.setOnClickListener(view -> {
            onBackPressed();
        });
        binding.icDone.setOnClickListener(view -> {
            if (mainImagePath != null && imagePath != null) {
                saveImage();
            }
        });

        binding.btnCrop.setOnClickListener(view -> {
            File output = new File(getCacheDir().getAbsolutePath());
            if (!output.exists()) {
                output.mkdirs();
            }
            String timeStamp = new SimpleDateFormat("HHmmss_dMyy", Locale.ENGLISH).format(new Date());
            String fileName = "IMG_" + timeStamp + ".png";
            cropOutputPath = output.getPath() + "/" + fileName;

            UCrop.Options options = new UCrop.Options();
            options.setToolbarColor(ContextCompat.getColor(this, R.color.theme_color));
            options.setStatusBarColor(ContextCompat.getColor(this, R.color.theme_color));
            options.setToolbarWidgetColor(ContextCompat.getColor(this, R.color.white));
            options.setCropFrameColor(ContextCompat.getColor(this, R.color.white));
            options.setActiveControlsWidgetColor(ContextCompat.getColor(this, R.color.theme_color));
            options.setRootViewBackgroundColor(ContextCompat.getColor(this, R.color.white));
            options.setCropFrameColor(ContextCompat.getColor(this, R.color.white));

            UCrop.of(Uri.fromFile(new File(imagePath)), Uri.fromFile(new File(cropOutputPath)))
                    .withOptions(options)
                    .start(EditActivity.this);

//            UCrop uCrop = new UCrop(Uri.fromFile(new File(imagePath)), Uri.fromFile(new File(cropOutputPath)));
//            uCrop.withOptions(options);
//            uCrop.start(EditActivity.this);
        });
        binding.btnRotate.setOnClickListener(view -> {
            Intent intent = new Intent(this, RotateActivity.class).putExtra("EditImage", imagePath);
            editActivityResultLauncher.launch(intent);
        });

        binding.btnFilter.setOnClickListener(view -> {
            Intent intent = new Intent(this, FilterActivity.class).putExtra("EditImage", imagePath);
            editActivityResultLauncher.launch(intent);
        });

        binding.btnSaturation.setOnClickListener(view -> {
            Intent intent = new Intent(this, OtherEditActivity.class)
                    .putExtra("EditImage", imagePath)
                    .putExtra("Type", 1);
            editActivityResultLauncher.launch(intent);
        });

        binding.btnBrightness.setOnClickListener(view -> {
            Intent intent = new Intent(this, OtherEditActivity.class)
                    .putExtra("EditImage", imagePath)
                    .putExtra("Type", 2);
            editActivityResultLauncher.launch(intent);
        });

        binding.btnContrast.setOnClickListener(view -> {
            Intent intent = new Intent(this, OtherEditActivity.class)
                    .putExtra("EditImage", imagePath)
                    .putExtra("Type", 3);
            editActivityResultLauncher.launch(intent);
        });


    }

    boolean isSave = false;

    private void saveImage() {
        isSave = false;
        ArrayList<String> copyFiles = new ArrayList<>();

        Observable.fromCallable(() -> {
                    File copyFile = new File(imagePath);
                    String targetPath = mainImagePath;
                    File targetFile = new File(mainImagePath);
                    File targetFolder = new File(targetFile.getParent());
                    String newName = targetFile.getName();

                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q && !PreferencesManager.getInstance(EditActivity.this).getStoragePermission11()) {
                        String filePath = copyFileOnAboveQ(copyFile.getPath(), newName, targetFolder, EditActivity.this);
                        if (filePath != null) {
                            isSave = true;
                            copyFiles.add(filePath);
                        }
                    } else {
                        boolean isCopied = StorageUtils.copyFile(copyFile, targetFile, EditActivity.this);
                        isSave = isCopied;
                    }
                    if (isSave) {
//                        Glide.get(EditActivity.this).clearMemory();
                        Glide.get(EditActivity.this).clearDiskCache();
                    }
                    return true;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    runOnUiThread(() -> {
                        if (isSave) {
                            setResult(RESULT_OK);
                            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q && !PreferencesManager.getInstance(EditActivity.this).getStoragePermission11()) {
                                String path = Environment.DIRECTORY_PICTURES + File.separator + getString(R.string.in_app_name);
                                RxBus.getInstance().post(new CopyMoveEvent(copyFiles, getString(R.string.in_app_name), path, new ArrayList<>()));
                            } else
                                RxBus.getInstance().post(new EditImageEvent());
                        }
                        finish();
                    });
                })
                .subscribe((result) -> {
                    runOnUiThread(() -> {
                        if (isSave) {
                            setResult(RESULT_OK);
                            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q && !PreferencesManager.getInstance(EditActivity.this).getStoragePermission11()) {
                                String path = Environment.DIRECTORY_PICTURES + File.separator + getString(R.string.in_app_name);
                                RxBus.getInstance().post(new CopyMoveEvent(copyFiles, getString(R.string.in_app_name), path, new ArrayList<>()));
                            } else
                                RxBus.getInstance().post(new EditImageEvent());
                        }
                        finish();
                    });
                });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(Objects.requireNonNull(data));
            if (cropOutputPath != null && !cropOutputPath.isEmpty()) {
                imagePath = cropOutputPath;
                imageLoad();
            }
        }
    }

    ActivityResultLauncher<Intent> editActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        if (result.getData() != null) {
                            String path = result.getData().getStringExtra("imagePath");
                            if (path != null)
                                imagePath = path;
                            imageLoad();
                        }
                    }
                }
            });

    public final String copyFileOnAboveQ(@NonNull final String filePath, String newName, File targetFolder, Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        FileOutputStream fos = null;
        String folderName = targetFolder.getName();
        String relativePath = null;

        relativePath = Environment.DIRECTORY_PICTURES + File.separator + getString(R.string.in_app_name);

        try {
            if (StorageUtils.isVideo(new File(filePath).getName())) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);


                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                FileInputStream inStream = new FileInputStream(filePath);
                FileChannel inChannel = inStream.getChannel();
                FileChannel outChannel = fos.getChannel();
                inChannel.transferTo(0, inChannel.size(), outChannel);
                inStream.close();
                fos.close();

                String copyFilePath = getPath(imageUri, context);

                MediaScannerConnection.scanFile(context, new String[]{copyFilePath}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                    }
                });
                return copyFilePath;
            } else {

                Bitmap bitmap = getBitmap(filePath);
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);

                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)) {
                    fos.flush();
                }

                String copyFilePath = getPath(imageUri, context);

                MediaScannerConnection.scanFile(context, new String[]{copyFilePath}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                    }
                });
                return copyFilePath;
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public String getPath(Uri uri, Context context) {
        String[] projection = {MediaStore.Files.FileColumns.DATA};
        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
        if (cursor == null) return null;
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
        cursor.moveToFirst();
        String s = cursor.getString(column_index);
        cursor.close();
        return s;
    }

    public static Bitmap getBitmap(String path1) {
        Bitmap bitmap = null;
        try {
            File f = new File(path1);
            bitmap = decodeSampledBitmap(f, 1080, 768);

            android.media.ExifInterface exif = new android.media.ExifInterface(path1);
            int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
            Log.d("EXIF", "Exif: " + orientation);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                        matrix, true);
            } else if (orientation == 3) {
                matrix.postRotate(180);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                        matrix, true);
            } else if (orientation == 8) {
                matrix.postRotate(270);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                        matrix, true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    public static Bitmap decodeSampledBitmap(File f, int reqWidth, int reqHeight) throws FileNotFoundException {

        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(new FileInputStream(f), null, options);

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(new FileInputStream(f), null, options);
    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;


            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }
}