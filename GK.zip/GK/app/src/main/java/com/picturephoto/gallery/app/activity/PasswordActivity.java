package com.picturephoto.gallery.app.activity;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityPasswordBinding;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.Executor;

public class PasswordActivity extends AppCompatActivity implements TextWatcher {

    ActivityPasswordBinding binding;
    private String passcode = "";
    private int temp = 0;
    boolean isResetPass = false;
    PreferencesManager preferencesManager;
    boolean isOpenPrivate = false;
    ActivityResultLauncher<Intent> lockActivityResultLauncher;

    BiometricManager biometricManager;
    BiometricPrompt biometricPrompt;
    private boolean isSplash = false;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferencesManager = PreferencesManager.getInstance(this);
        changeLanguage();
        binding = ActivityPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        initView();
    }

    @Override
    public void onBackPressed() {
        if(!isSplash){
            admobAdManager.loadInterstitialBackAd(this, 2, () ->  finish());
        } else {
            finish();
        }
    }

    private void initView() {
        preferencesManager = PreferencesManager.getInstance(this);
        if (getIntent() != null) {
            isOpenPrivate = getIntent().getBooleanExtra("isOpenPrivate", false);
            isSplash = getIntent().getBooleanExtra("isSplash", false);
            try {
                isResetPass = getIntent().getBooleanExtra("resetPass", false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        binding.pass.addTextChangedListener(this);
        binding.pass.setText("");
        biometricManager = BiometricManager.from(PasswordActivity.this);


        if (preferencesManager.getSetPass()) {
            binding.title.setText(R.string.EnterPasscode);
            binding.forgot.setVisibility(View.VISIBLE);
            if (isResetPass)
                binding.imgFigerprint.setVisibility(View.GONE);
            else if (preferencesManager.getFingerprint())
                binding.imgFigerprint.setVisibility(View.VISIBLE);
            else
                binding.imgFigerprint.setVisibility(View.GONE);

            Executor executor = ContextCompat.getMainExecutor(this);
            biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    Toast.makeText(PasswordActivity.this, errString.toString(), Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    setPasswordSuccess();
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                }
            });

            if (preferencesManager.getFingerprint())
                biometricPrompt.authenticate(buildBiometricPrompt());
        } else {
            binding.title.setText(R.string.CreatePassword);
            preferencesManager.putPass("");
            preferencesManager.putSetPass(false);
            preferencesManager.putSetQuestion(false);
            binding.forgot.setVisibility(View.GONE);
        }
        initListener();
        setActivityResultLauncher();
    }

    private BiometricPrompt.PromptInfo buildBiometricPrompt() {
        return new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Verify your identity")
                .setDescription("Confirm your identity so we can verify it's you")
                .setNegativeButtonText("Cancel")
                .setConfirmationRequired(false)
                .build();
    }

    private void changeLanguage() {
        ArrayList<String> languageCodes = new ArrayList<>();
        languageCodes.add("en");
        languageCodes.add("hi");
        languageCodes.add("zh");
        languageCodes.add("es");
        languageCodes.add("de");
        languageCodes.add("ru");
        languageCodes.add("pt");
        languageCodes.add("fi");
        languageCodes.add("ja");
        languageCodes.add("tr");
        languageCodes.add("no");
        languageCodes.add("in");
        languageCodes.add("it");
        languageCodes.add("fr");
        languageCodes.add("nl");
        languageCodes.add("ko");
        languageCodes.add("ka");
        languageCodes.add("ga");
        languageCodes.add("pl");
        languageCodes.add("ca");

        Locale locale = new Locale(languageCodes.get(preferencesManager.getLanguage()));
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

    }

    private void setActivityResultLauncher() {
        lockActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK)
                        setResult(RESULT_OK);
                    finish();
                });
    }

    private void initListener() {

        binding.forgot.setOnClickListener(view -> setQuestion(1));

        binding.b0.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "0"));
        binding.b1.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "1"));
        binding.b2.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "2"));
        binding.b3.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "3"));
        binding.b4.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "4"));
        binding.b5.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "5"));
        binding.b6.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "6"));
        binding.b7.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "7"));
        binding.b8.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "8"));
        binding.b9.setOnClickListener(v -> binding.pass.setText(binding.pass.getText().toString().trim() + "9"));

        binding.clear.setOnClickListener(v -> {
            if (binding.pass.getText().length() > 0) {
                binding.pass.setText(binding.pass.getText().toString().substring(0, binding.pass.length() - 1));
                binding.pass.setSelection(binding.pass.getText().length());
            }
        });

//        binding.close.setOnClickListener(v -> finish());
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence s, int i, int i1, int i2) {
        if (s.length() == 0) {
            binding.p1.setVisibility(View.GONE);
            binding.p2.setVisibility(View.GONE);
            binding.p3.setVisibility(View.GONE);
            binding.p4.setVisibility(View.GONE);

        } else if (s.length() == 1) {
            passSelectDot(binding.p1);
            binding.p1.setVisibility(View.VISIBLE);
            passUnselectDot(binding.p2, binding.p3, binding.p4);
            binding.p2.setVisibility(View.GONE);
            binding.p3.setVisibility(View.GONE);
            binding.p4.setVisibility(View.GONE);


        } else if (s.length() == 2) {
            passSelectDot(binding.p2);
            binding.p2.setVisibility(View.VISIBLE);
            passUnselectDot(binding.p1, binding.p3, binding.p4);
            binding.p1.setVisibility(View.VISIBLE);
            binding.p3.setVisibility(View.GONE);
            binding.p4.setVisibility(View.GONE);

        } else if (s.length() == 3) {
            passSelectDot(binding.p3);
            binding.p3.setVisibility(View.VISIBLE);
            passUnselectDot(binding.p1, binding.p2, binding.p4);
            binding.p1.setVisibility(View.VISIBLE);
            binding.p2.setVisibility(View.VISIBLE);
            binding.p4.setVisibility(View.GONE);

        } else if (s.length() == 4) {
            passSelectDot(binding.p4);
            binding.p4.setVisibility(View.VISIBLE);
            passUnselectDot(binding.p1, binding.p2, binding.p3);
            binding.p1.setVisibility(View.VISIBLE);
            binding.p2.setVisibility(View.VISIBLE);
            binding.p3.setVisibility(View.VISIBLE);


            if (!preferencesManager.getSetPass()) {
                if (temp == 0) {
                    passcode = String.valueOf(s);
                    temp = 1;
                    new Handler(Looper.myLooper()).postDelayed(() -> {
                        binding.title.setText(R.string.Enter_confirm_passcode);
                        binding.pass.setText("");
                    }, 30);

                } else {
                    if (passcode.equals(s.toString())) {
                        preferencesManager.putPass(passcode);
//                        preferencesManager.putSetPass( true);
                        setPasswordSuccess();
//                        binding.pass.setText("");
                        Toast.makeText(PasswordActivity.this, R.string.Passcode_set_successfully, Toast.LENGTH_SHORT).show();
                    } else {
                        new Handler(Looper.myLooper()).postDelayed(() -> {
                            binding.pass.setText("");
                            temp = 0;
                            binding.title.setText(R.string.Enter_new_Passcode);
                        }, 30);
                        Toast.makeText(PasswordActivity.this, getString(R.string.Please_confirm_password_as_same), Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                if (preferencesManager.getPass().equals(s.toString())) {
                    setPasswordSuccess();
//                    binding.pass.setText("");
                } else {
                    new Handler(Looper.myLooper()).postDelayed(() -> {
                        binding.pass.setText("");
                    }, 30);
                    Toast.makeText(PasswordActivity.this, getString(R.string.Please_enter_correct_passcode), Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }


    private void passSelectDot(AppCompatImageView p1) {
        p1.setColorFilter(ContextCompat.getColor(PasswordActivity.this, R.color.white));
    }

    private void passUnselectDot(AppCompatImageView p2, AppCompatImageView p3, AppCompatImageView p4) {
//        p2.setColorFilter(ContextCompat.getColor(PasswordActivity.this, R.color.black));
//        p3.setColorFilter(ContextCompat.getColor(PasswordActivity.this, R.color.black));
//        p4.setColorFilter(ContextCompat.getColor(PasswordActivity.this, R.color.black));
    }

    private void setPasswordSuccess() {
        if (isResetPass) {
            preferencesManager.putSetPass(true);
            preferencesManager.putSetQuestion(true);
        }
        if (preferencesManager.getSetQuestion()) {
            setResult(RESULT_OK);
            if (isOpenPrivate) {
                startActivity(new Intent(PasswordActivity.this, PrivateActivity.class));
            }
            finish();
        } else {
            setQuestion(0);
        }
    }

    private void setQuestion(int i) {
        Intent intent = new Intent(this, QuestionActivity.class);
        intent.putExtra("type", i);
        intent.putExtra("isOpenPrivate", isOpenPrivate);
        lockActivityResultLauncher.launch(intent);
    }
}