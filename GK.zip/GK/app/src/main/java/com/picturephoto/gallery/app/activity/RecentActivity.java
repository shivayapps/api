package com.picturephoto.gallery.app.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.RecentAdapter;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityRecentBinding;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.utils.Constant;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import io.reactivex.Observable;

public class RecentActivity extends AppCompatActivity {

    ActivityRecentBinding binding;
    PreferencesManager preferencesManager;
    public ArrayList<AlbumData> recentList = new ArrayList<>();
    RecentAdapter adapter;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRecentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();

    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        getData();
        intClickListener();
    }

    @Override
    public void onBackPressed() {

        admobAdManager.loadInterstitialBackAd(this, 2, () -> finish());
    }

    private void setData() {
        if (adapter != null)
            adapter.notifyDataSetChanged();
        else
            initAdapter();
        setEmptyData();
    }

    private void initAdapter() {
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecentAdapter(this, recentList, new RecentAdapter.OnSelectAlbum() {
            @Override
            public void onClickImageShow(int mainPos, int pos) {
                AlbumData albumData = recentList.get(mainPos);
                Constant.displayImageList = new ArrayList<>();
                Constant.displayImageList.addAll(albumData.getPictureData());
                Intent intent = new Intent(RecentActivity.this, ImageShowActivity.class);
                intent.putExtra("pos", pos);
                intent.putExtra("IsPrivateList", false);
                intent.putExtra("IsShowSlideShow", false);
                intent.putExtra("isFavList", true);
                startActivity(intent);
            }

            @Override
            public void onClickMore(int mainPos) {
                Constant.recentData = recentList.get(mainPos);
                startActivity(new Intent(RecentActivity.this, RecentFilesActivity.class));
            }

        });
        binding.recyclerView.setAdapter(adapter);
    }

    private void setEmptyData() {
        if (recentList != null && recentList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void getData() {
        recentList.clear();
        Observable.fromCallable(() -> {
                    getRecentData();
                    return true;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    runOnUiThread(() -> {
                        setData();
                    });
                })
                .subscribe((result) -> {
                    runOnUiThread(() -> {
                        setData();
                    });
                });
    }

    private void getRecentData() {
        ArrayList<PictureData> list = new ArrayList<>();
        list.addAll(preferencesManager.getRecentList());

        if (list.size() != 0) {
            LinkedHashMap<String, ArrayList<PictureData>> dateWisePictures = new LinkedHashMap<>();
            SimpleDateFormat format = new SimpleDateFormat("EEEE, MMM dd yyyy");
            Collections.sort(list, (p1, p2) -> {
                return Long.compare(p2.getLastDisplayDate(), p1.getLastDisplayDate());
            });

            for (PictureData pictureData : list) {
                File file = new File(pictureData.getFilePath());
                if (file.exists()) {
                    String strDate = format.format(pictureData.getLastDisplayDate());
                    ArrayList<PictureData> imagesData1;
                    if (dateWisePictures.containsKey(strDate)) {
                        imagesData1 = dateWisePictures.get(strDate);
                        if (imagesData1 == null)
                            imagesData1 = new ArrayList<>();

                    } else {
                        imagesData1 = new ArrayList<>();
                    }
                    imagesData1.add(pictureData);
                    dateWisePictures.put(strDate, imagesData1);
                }
            }
//            for (int i = list.size() - 1; i >= 0; i--) {
//                File file = new File(list.get(i).getFilePath());
//                if (!file.exists())
//                    list.remove(i);
//            }

            Set<String> keys = dateWisePictures.keySet();
            ArrayList<String> listKeys = new ArrayList<>(keys);
            for (int i = 0; i < listKeys.size(); i++) {

                if (listKeys.get(i) != null && !listKeys.get(i).isEmpty()) {
                    ArrayList<PictureData> imagesData = dateWisePictures.get(listKeys.get(i));

                    if (imagesData != null && imagesData.size() != 0) {
                        AlbumData bucketData = new AlbumData();
                        bucketData.setTitle(listKeys.get(i));
                        bucketData.setPictureData(imagesData);
                        recentList.add(bucketData);
                    }
                }
            }
        }
    }


    private void intClickListener() {
        binding.ivBack.setOnClickListener(view -> {
            onBackPressed();
        });

        binding.ivMenu.setOnClickListener(view -> {
            showMenu(view);
        });
    }

    private void showMenu(View view) {
        PopupMenu popup = new PopupMenu(RecentActivity.this, view);
        popup.getMenuInflater().inflate(R.menu.menu_select_option, popup.getMenu());
        popup.getMenu().findItem(R.id.nav_move_private).setVisible(false);
        popup.getMenu().findItem(R.id.nav_copy).setVisible(false);
        popup.getMenu().findItem(R.id.nav_move).setVisible(false);
        popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.Clear));
        popup.show();

        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.nav_select) {
                showClearDialog();
            }
            return true;
        });
    }

    private void showClearDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.ClearHistory);
        builder.setMessage(R.string.ClearHistoryMsg);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.action_Clear, (dialog, which) -> {
            dialog.dismiss();
            List<PictureData> list = preferencesManager.getRecentList();
            list.clear();
            preferencesManager.setRecentList(list);
            recentList.clear();
            if (adapter != null)
                adapter.notifyDataSetChanged();
        });
        builder.setNegativeButton(getString(R.string.action_Cancel), (dialog, which) -> dialog.dismiss());
//        builder.show();
        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(this, R.color.gray_600));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, R.color.theme_color));
    }
}