package com.picturephoto.gallery.app.activity;

import static android.os.Build.VERSION.SDK_INT;
import static com.picturephoto.gallery.app.utils.Constant.HIDE_PATH;
import static com.picturephoto.gallery.app.utils.Utils.isVideo;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.storage.StorageManager;
import android.provider.BaseColumns;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.SpannableString;
import android.text.format.Formatter;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;
import androidx.print.PrintHelper;
import androidx.viewpager.widget.ViewPager;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.DisplayImageAdapter;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.database.Database;
import com.picturephoto.gallery.app.databinding.ActivityImageShowBinding;
import com.picturephoto.gallery.app.databinding.DialogInfoBinding;
import com.picturephoto.gallery.app.databinding.DialogSlideShowTimeBinding;
import com.picturephoto.gallery.app.event.DisplayDeleteEvent;
import com.picturephoto.gallery.app.event.DisplayUnFavoriteEvent;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.model.RenameEvent;
import com.picturephoto.gallery.app.model.RenameModel;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.Constant;
import com.picturephoto.gallery.app.utils.CreateFile;
import com.picturephoto.gallery.app.utils.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import io.reactivex.Observable;

public class ImageShowActivity extends AppCompatActivity {

    ActivityImageShowBinding binding;
    List<PictureData> displayImageList = new ArrayList<>();
    private DisplayImageAdapter displayImageAdapter;
    private int position;
    private boolean isFavList = false;
    private boolean isPrivateList = false, isShowHome = false;
    PreferencesManager preferencesManager;
    List<PictureData> recentList = new ArrayList<>();
    private static final int RENAME_FILE = 33;
    Handler mHandler = new Handler();
    Handler updateHandler = new Handler();
    int slideShowTime = 3000;
    int updateTime = 100;
    boolean isSlideShow = false;
    int progress = 0;
    Database database;
    private final int Hide_FILE = 1001;
    private int REQUEST_HIDE_PERMISSION = 5555;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityImageShowBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        intView();
//        startSlideShow();
    }

    private void startSlideShow() {
        isSlideShow = true;
        progress = 0;
        binding.toolbar.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.progressBar.setProgress(progress);
        binding.progressBar.setMax(slideShowTime);
        if (mHandler != null)
            mHandler.removeCallbacks(slideShowTask);
        if (updateHandler != null)
            updateHandler.removeCallbacks(updateProgress);
        mHandler.postDelayed(slideShowTask, slideShowTime);
        updateTime();
    }

    private Runnable slideShowTask = new Runnable() {
        public void run() {
            binding.progressBar.setProgress(slideShowTime);
            int pos = binding.imagePager.getCurrentItem();
            if (pos < displayImageList.size() - 1) {
                pos++;
                binding.imagePager.setCurrentItem(pos);
                mHandler.postDelayed(this, slideShowTime);
            } else {
                stopSlideShow();
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHandler != null)
            mHandler.removeCallbacks(slideShowTask);
        if (updateHandler != null)
            updateHandler.removeCallbacks(updateProgress);
    }

    private void stopSlideShow() {
        isSlideShow = false;
        if (mHandler != null)
            mHandler.removeCallbacks(slideShowTask);
        if (updateHandler != null)
            updateHandler.removeCallbacks(updateProgress);
        binding.progressBar.setVisibility(View.GONE);
        binding.toolbar.setVisibility(View.VISIBLE);
    }

    private void updateTime() {
        updateHandler.postDelayed(updateProgress, updateTime);
    }

    private Runnable updateProgress = new Runnable() {
        public void run() {
            if (progress == slideShowTime)
                progress = 0;
            else
                progress = progress + updateTime;
            binding.progressBar.setProgress(progress);
            updateHandler.postDelayed(this, updateTime);
        }
    };


    private void intView() {
        database = new Database(this);
        preferencesManager = PreferencesManager.getInstance(this);
        displayImageList.addAll(Constant.displayImageList);
        position = getIntent().getIntExtra("pos", 0);
        isSlideShow = getIntent().getBooleanExtra("IsShowSlideShow", false);
        isFavList = getIntent().getBooleanExtra("IsFavList", false);
        isPrivateList = getIntent().getBooleanExtra("IsPrivateList", false);
        isShowHome = getIntent().getBooleanExtra("IsShowHome", false);

        slideShowTime = preferencesManager.getSlideShowTime();
        if (isPrivateList)
            binding.ivFav.setVisibility(View.GONE);

        recentList.addAll(preferencesManager.getRecentList());
        serFavoriteData();
        initListener();

        if (isSlideShow)
            startSlideShow();
    }


    private void serFavoriteData() {
        List<String> favList = preferencesManager.getFavoriteList();
        for (int i = 0; i < displayImageList.size(); i++) {
            displayImageList.get(i).setFavorite(false);
        }
        if (favList != null && favList.size() != 0) {
            for (int f = 0; f < favList.size(); f++) {
                for (int i = 0; i < displayImageList.size(); i++) {
                    if (displayImageList.get(i).getFilePath() != null && !displayImageList.get(i).getFilePath().equalsIgnoreCase(""))
                        if (favList.get(f).equalsIgnoreCase(displayImageList.get(i).getFilePath())) {
                            displayImageList.get(i).setFavorite(true);
                            break;
                        }
                }
            }
        }
        runOnUiThread(() -> {
            initAdapter();
            updateFavData();
            if (position < displayImageList.size())
                updateRecent(displayImageList.get(position));
        });
    }

    private void initAdapter() {
        try {
            displayImageAdapter = new DisplayImageAdapter(this, displayImageList, isPrivateList, new DisplayImageAdapter.ImageToolbar() {
                @Override
                public void OnImageToolbar(View v) {
                    if (isSlideShow) {
                        stopSlideShow();
                    } else {
                        if (binding.toolbar.getVisibility() == View.VISIBLE) {
                            binding.toolbar.setVisibility(View.GONE);
                        } else {
                            binding.toolbar.setVisibility(View.VISIBLE);
                        }
                    }
                }

                @Override
                public void OnVideoShow(int pos) {
                    Uri shareUri;
                    if (isPrivateList && SDK_INT >= Build.VERSION_CODES.R && isPrivateList)
                        shareUri = Uri.parse(displayImageList.get(position).getFilePath());
                    else
                        shareUri = FileProvider.getUriForFile(ImageShowActivity.this, getApplicationContext().getPackageName() +
                                ".provider", new File(displayImageList.get(position).getFilePath()));

                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.setDataAndType(shareUri, Constant.getMimeTypeFromFilePath(displayImageList.get(position).getFilePath()));
                    startActivity(intent);
                }
            });
            binding.imagePager.setAdapter(displayImageAdapter);
            binding.imagePager.setCurrentItem(position);
            binding.imageTitle.setText(displayImageList.get(position).getFileName());
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    ActivityResultLauncher<Intent> editActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
//                        if (displayImageAdapter != null)
//                            displayImageAdapter.notifyDataSetChanged();
//                        binding.imagePager.setCurrentItem(binding.imagePager.getCurrentItem());
                        initAdapter();
                    }
                }
            });

    private void initListener() {
        binding.imagePager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                Log.e("onPageScrolled", "position " + position);
            }

            @Override
            public void onPageSelected(int pos) {
                Log.e("onPageSelected", "position " + pos);
                position = pos;
                binding.imageTitle.setText(displayImageList.get(position).getFileName());
                updateFavData();
                updateRecent(displayImageList.get(position));
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                Log.e("PageScrollStateChanged", "position " + state);
            }
        });
        binding.ivBack.setOnClickListener(v -> onBackPressed());

        binding.ivFav.setOnClickListener(v -> {
            if (displayImageList.get(binding.imagePager.getCurrentItem()).isFavorite()) {
                binding.ivFav.setImageDrawable(ContextCompat.getDrawable(ImageShowActivity.this, R.drawable.ic_heart_unfill));
//                binding.ivFav.setColorFilter(ContextCompat.getColor(this, R.color.icon_gray_tab), PorterDuff.Mode.SRC_IN);
                displayImageList.get(binding.imagePager.getCurrentItem()).setFavorite(false);
                setUnFavorite(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                if (isFavList) {
                    int finalI1 = binding.imagePager.getCurrentItem();
                    ArrayList<String> deleteList1 = new ArrayList<>();
                    deleteList1.add(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());

                    displayImageList.remove(binding.imagePager.getCurrentItem());
                    displayImageAdapter.notifyDataSetChanged();
                    initAdapter();

                    RxBus.getInstance().post(new DisplayUnFavoriteEvent(deleteList1));

                    if (finalI1 < displayImageList.size() - 1) {
                        position = finalI1;
                        binding.imagePager.setCurrentItem(finalI1);
                        int pos = binding.imagePager.getCurrentItem();
                        pos++;
                        updateFavData();
                        binding.imageTitle.setText(displayImageList.get(pos).getFileName());

                    } else {
                        if (displayImageList.size() == 0) {
                            onBackPressed();
                        } else {
                            try {
                                binding.imagePager.setCurrentItem(finalI1 - 1);
                                int pos = binding.imagePager.getCurrentItem();
                                pos++;
                                updateFavData();
                                binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }
                }
            } else {
                binding.ivFav.setImageDrawable(ContextCompat.getDrawable(ImageShowActivity.this, R.drawable.ic_heart_fill));
//                binding.ivFav.setColorFilter(ContextCompat.getColor(this, R.color.colorAccent), PorterDuff.Mode.SRC_IN);
                displayImageList.get(binding.imagePager.getCurrentItem()).setFavorite(true);
                setFavorite(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
            }
        });
        binding.ivMenu.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(ImageShowActivity.this, view);
            //Inflating the Popup using xml file
            popup.getMenuInflater().inflate(R.menu.menu_image, popup.getMenu());
//            popup.getMenu().findItem(R.id.nav_move_private).setVisible(false);
            if (isPrivateList) {
                popup.getMenu().findItem(R.id.nav_Delete).setVisible(false);
                popup.getMenu().findItem(R.id.nav_media_vault).setVisible(false);
            } else {
                popup.getMenu().findItem(R.id.nav_Delete).setVisible(true);
                popup.getMenu().findItem(R.id.nav_media_vault).setVisible(true);
            }

            if (displayImageList.get(binding.imagePager.getCurrentItem()).isVideo()) {
                popup.getMenu().findItem(R.id.nav_Print).setVisible(false);
                popup.getMenu().findItem(R.id.nav_Edit).setVisible(false);
                popup.getMenu().findItem(R.id.nav_Slideshow).setVisible(false);
                popup.getMenu().findItem(R.id.nav_SlideshowTimeout).setVisible(false);
                popup.getMenu().findItem(R.id.nav_SetPictureAs).setVisible(false);
            } else {
                popup.getMenu().findItem(R.id.nav_Print).setVisible(true);
                popup.getMenu().findItem(R.id.nav_Edit).setVisible(true);
                popup.getMenu().findItem(R.id.nav_Slideshow).setVisible(true);
                popup.getMenu().findItem(R.id.nav_SlideshowTimeout).setVisible(true);
                popup.getMenu().findItem(R.id.nav_SetPictureAs).setVisible(true);
            }

            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_Details) {
                    infoDialog();
                } else if (item.getItemId() == R.id.nav_Delete) {
                    if (isPrivateList)
                        deleteDialog();
                    else if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                        deleteFileOnAboveQ();
                    } else
                        deleteDialog();
                } else if (item.getItemId() == R.id.nav_Edit) {
                    admobAdManager.loadInterstitialAd(this, 2, () -> {
                        Intent intent = new Intent(this, EditActivity.class).putExtra("EditImage", displayImageList.get(position).getFilePath());
                        editActivityResultLauncher.launch(intent);
                    });
                } else if (item.getItemId() == R.id.nav_Rename) {
                    showRenameDialog(displayImageList.get(binding.imagePager.getCurrentItem()));
                } else if (item.getItemId() == R.id.nav_Share) {
                    File file = new File(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                    Uri shareUri;
                    if (isPrivateList && SDK_INT >= Build.VERSION_CODES.R)
                        shareUri = Uri.parse(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                    else
                        shareUri = FileProvider.getUriForFile(ImageShowActivity.this, getApplicationContext().getPackageName() + ".provider", file);
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType(Constant.getMimeTypeFromFilePath(file.getPath()));
                    intent.putExtra(Intent.EXTRA_STREAM, shareUri);
                    try {
                        startActivity(Intent.createChooser(intent, getString(R.string.share_with)));
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(ImageShowActivity.this, getString(R.string.no_supported_image), Toast.LENGTH_SHORT).show();
                    }
                } else if (item.getItemId() == R.id.nav_Slideshow) {
                    startSlideShow();
                } else if (item.getItemId() == R.id.nav_SlideshowTimeout) {
                    showSlideShowTime();
                } else if (item.getItemId() == R.id.nav_SetPictureAs) {
                    File file = new File(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                    Uri shareUri;
                    if (isPrivateList && SDK_INT >= Build.VERSION_CODES.R)
                        shareUri = Uri.parse(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                    else
                        shareUri = FileProvider.getUriForFile(ImageShowActivity.this, getApplicationContext().getPackageName() + ".provider", file);

                    Intent intent = new Intent(Intent.ACTION_ATTACH_DATA);
                    intent.setDataAndType(shareUri, "image/*");
                    intent.addCategory(Intent.CATEGORY_DEFAULT);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.putExtra("mimeType", "image/*");
                    startActivityForResult(Intent.createChooser(intent, "Set As"), 200);
                } else if (item.getItemId() == R.id.nav_Print) {
                    try {
                        PrintHelper photoPrinter = new PrintHelper(ImageShowActivity.this);
                        photoPrinter.setScaleMode(PrintHelper.SCALE_MODE_FIT);
                        Bitmap bitmap = BitmapFactory.decodeFile(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                        photoPrinter.printBitmap("droids.jpg - test print", bitmap);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, getString(R.string.NotSupported), Toast.LENGTH_SHORT).show();
                    }
                } else if (item.getItemId() == R.id.nav_media_vault) {
                    if (preferencesManager.getSetPass()) {
                        showHideDialog();
                    } else {
                        admobAdManager.loadInterstitialAd(this, 2, () -> {
                            startActivity(new Intent(this, LockSettingActivity.class).putExtra("IsFromSetting", false));
                        });
                    }
                }
                return true;
            });
            popup.show();
        });
    }

    private void showHideDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.Are_you_sure_want_to_lock_this);
        builder.setMessage(R.string.lock_msg);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.action_lock, (dialog, which) -> {
            dialog.dismiss();
            hideMedia();
        });
        builder.setNegativeButton(getString(R.string.action_Cancel), (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(this, R.color.gray_600));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, R.color.theme_color));
    }

    private void hideMedia() {
        if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
            File file = new File(HIDE_PATH);
            if (!file.exists()) {
                file.mkdirs();
            }
            String hidden_URI = preferencesManager.getHideUri();
            if (!hidden_URI.equals("") && hidden_URI != null && hidden_URI.endsWith(Constant.HIDE_FOLDER_NAME)) {
                new Thread(() -> moveToPrivateAboveR()).start();
            } else {
                askPermissionHideUri();
            }
        } else
            moveToPrivate();
    }

    private void moveToPrivate() {
        int i = binding.imagePager.getCurrentItem();
        ArrayList<String> deleteList = new ArrayList<>();

        Observable.fromCallable(() -> {
                    PictureData model = displayImageList.get(binding.imagePager.getCurrentItem());
                    File to;
                    try {
                        to = new File(model.getFilePath());
                    } catch (Exception e) {
                        e.printStackTrace();
                        to = new File(model.getFilePath());
                    }

                    try {
                        String hidePath = moveFile(to, new File(HIDE_PATH));
                        if (hidePath != null) {
                            database.addPrivate(hidePath, to.getParent());
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    deleteList.add(to.getPath());
//        setUnFavorite(to.getPath());
                    MediaScannerConnection.scanFile(this, new String[]{to.getPath()}, null, (path, uri) -> {
                    });

                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    runOnUiThread(() -> {
                        displayImageList.remove(binding.imagePager.getCurrentItem());
                        displayImageAdapter.notifyDataSetChanged();
                        initAdapter();
                        RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));
                        if (i < displayImageList.size() - 1) {
                            position = i;
                            binding.imagePager.setCurrentItem(i);
                            int pos = binding.imagePager.getCurrentItem();
                            binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                        } else {
                            if (displayImageList.size() == 0) {
                                onBackPressed();
                            } else {
                                try {
                                    binding.imagePager.setCurrentItem(i - 1);
                                    int pos = binding.imagePager.getCurrentItem();
                                    binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        }

                    });
                })
                .subscribe((result) -> {
                    runOnUiThread(() -> {
                        displayImageList.remove(binding.imagePager.getCurrentItem());
                        displayImageAdapter.notifyDataSetChanged();
                        initAdapter();
                        RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));
                        if (i < displayImageList.size() - 1) {
                            position = i;
                            binding.imagePager.setCurrentItem(i);
                            int pos = binding.imagePager.getCurrentItem();
                            binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                        } else {
                            if (displayImageList.size() == 0) {
                                onBackPressed();
                            } else {
                                try {
                                    binding.imagePager.setCurrentItem(i - 1);
                                    int pos = binding.imagePager.getCurrentItem();
                                    binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        }
                    });
                });
    }

    ArrayList<Uri> mUris = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void moveToPrivateAboveR() {
        mUris = new ArrayList<>();

        PictureData model = displayImageList.get(binding.imagePager.getCurrentItem());
        File source = new File(model.getFilePath());
        String destinationPath = HIDE_PATH + "/" + source.getName();
        File destination = new File(destinationPath);
        try {
            destinationPath = Constant.HIDE_PATH;
            destination = new File(destinationPath);
            File hidePath = new File(destination + File.separator + source.getName());
            boolean isMove = moveFileonAboveR(source, hidePath);

            if (isMove) {
                database.addPrivate(hidePath.getPath(), source.getParent());
            }
            if (model.isVideo())
                mUris.add(getVideoUriFromFile(source.getPath(), this));
            else
                mUris.add(getImageUriFromFile(source.getPath(), this));
//                            setUnFavorite(source.getPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        runOnUiThread(() ->
        {
            requestDeletePermission(mUris);
            // delete image before
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void askPermissionHideUri() {
        File f = new File(Constant.HIDE_PATH);
        if (f.exists() && f.isDirectory()) {
            if (preferencesManager.getHideUri() == null || preferencesManager.getHideUri() == "" || !preferencesManager.getHideUri().endsWith(Constant.HIDE_FOLDER_NAME)) {
                askPermission(this, "Pictures%2F" + Constant.HIDE_FOLDER_NAME);
            }
        } else {
            boolean success = f.mkdir();
            if (success) {
                if (f.exists() && f.isDirectory()) {
                    if (preferencesManager.getHideUri() == null || preferencesManager.getHideUri() == "" || !preferencesManager.getHideUri().endsWith(Constant.HIDE_FOLDER_NAME)) {
                        askPermission(this, "Pictures%2F" + Constant.HIDE_FOLDER_NAME);
                    }
                }
            }
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void askPermission(Activity context, String targetDirectory) {
        StorageManager storageManager = (StorageManager) context.getSystemService(STORAGE_SERVICE);
        Intent intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString();
        scheme = scheme.replace("/root/", "/document/");
        targetDirectory = targetDirectory.replace("/", "%2F");
        scheme += "%3A$targetDirectory";
        uri = Uri.parse(scheme);
        Log.e("uri", "3 ==> $uri");
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        startActivityForResult(intent, REQUEST_HIDE_PERMISSION);
        Log.e("come", "==> at askPermission;");
    }

    private void requestDeletePermission(List<Uri> uriList) {
        try {
            PendingIntent pi = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                pi = MediaStore.createDeleteRequest(getContentResolver(), uriList);
            }
            startIntentSenderForResult(pi.getIntentSender(), Hide_FILE, null, 0, 0,
                    0, null);
        } catch (Exception e) {
            System.out.println("AFTER HIDE : " + e.getMessage());
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private boolean moveFileonAboveR(File source, File destination) throws IOException {
        boolean isMove = false;
        if (!destination.getParentFile().exists())
            destination.getParentFile().mkdirs();
        FileChannel source_channel = null;
        FileChannel destination_channel = null;
        try {
            Boolean isRename = source.renameTo(destination);
            if (isRename) {
                if (!source.getPath().contains("'")) {
                    isMove = true;
//                    getContentResolver().delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, MediaStore.Images.Media.DATA + "='" + source.getPath() + "'", null);
                }
            } else {
                if (!destination.exists()) {
                    ContentResolver contentResolver = getContentResolver();
                    Uri rootUri = Uri.parse(preferencesManager.getHideUri());
                    contentResolver.takePersistableUriPermission(
                            rootUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );
                    String rootDocumentId = DocumentsContract.getTreeDocumentId(rootUri);

                    CreateFile createFile = new CreateFile(this, contentResolver, File.separator + source.getName()
                            , rootUri, rootDocumentId, true, source.getAbsolutePath(), true,
                            Utils.getMimeType(source.getName()));
                    boolean isFileCreated = createFile.createNewFile(false, true);
                    isMove = true;
                }
                source.delete();
            }
            MediaScannerConnection.scanFile(this, new String[]{source.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });
            MediaScannerConnection.scanFile(this, new String[]{destination.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });
        } finally {
            if (source_channel != null) {
                source_channel.close();
            }
            if (destination_channel != null) {
                destination_channel.close();
            }
        }
        return isMove;
    }


    private String moveFile(File file, File dir) throws IOException {
        File newFile = getFileName(0, dir, file.getName());

        try (FileChannel outputChannel = new FileOutputStream(newFile).getChannel(); FileChannel inputChannel = new FileInputStream(file).getChannel()) {
            inputChannel.transferTo(0, inputChannel.size(), outputChannel);
            inputChannel.close();
            file.delete();

            MediaScannerConnection.scanFile(this, new String[]{file.getPath()}, null, (path, uri) -> {
            });

            MediaScannerConnection.scanFile(this, new String[]{newFile.getPath()}, null, (path, uri) -> {
            });
            return newFile.getPath();
        }
    }

    private File getFileName(int i, File dir, String name) {
        File check = new File(dir, name);
        if (check.exists()) {
            i++;
            if (name.indexOf(".") > 0) {
                String extension = name.substring(name.lastIndexOf("."));
                name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + extension;
            }
            check = getFileName(i, dir, name);
        }
        return check;
    }

    int slideT = 0;

    private void showSlideShowTime() {
        DialogSlideShowTimeBinding dialogBinding = DialogSlideShowTimeBinding.inflate(getLayoutInflater());
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(dialogBinding.getRoot());
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        slideT = preferencesManager.getSlideShowTime();
        if (slideT == 3 * 1000)
            dialogBinding.radioSec3.setChecked(true);
        else if (slideT == 5 * 1000)
            dialogBinding.radioSec5.setChecked(true);
        else if (slideT == 10 * 1000)
            dialogBinding.radioSec10.setChecked(true);
        else if (slideT == 15 * 1000)
            dialogBinding.radioSec15.setChecked(true);
        else if (slideT == 20 * 1000)
            dialogBinding.radioSec20.setChecked(true);
        else if (slideT == 30 * 1000)
            dialogBinding.radioSec30.setChecked(true);
        else if (slideT == 60 * 1000)
            dialogBinding.radioMinutes1.setChecked(true);
        else if (slideT == (60 * 2) * 1000)
            dialogBinding.radioMinutes2.setChecked(true);
        else if (slideT == (60 * 3) * 1000)
            dialogBinding.radioMinutes3.setChecked(true);
        else
            dialogBinding.radioSec3.setChecked(true);

        dialogBinding.grpType.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.radio_sec_3)
                slideT = 3 * 1000;
            else if (i == R.id.radio_sec_5)
                slideT = 5 * 1000;
            else if (i == R.id.radio_sec_10)
                slideT = 10 * 1000;
            else if (i == R.id.radio_sec_15)
                slideT = 15 * 1000;
            else if (i == R.id.radio_sec_20)
                slideT = 20 * 1000;
            else if (i == R.id.radio_sec_30)
                slideT = 30 * 1000;
            else if (i == R.id.radio_minutes_1)
                slideT = 60 * 1000;
            else if (i == R.id.radio_minutes_2)
                slideT = (60 * 2) * 1000;
            else if (i == R.id.radio_minutes_3)
                slideT = (60 * 3) * 1000;
        });

        dialogBinding.btnApply.setOnClickListener(view -> {
            preferencesManager.setSlideShowTime(slideT);
            slideShowTime = slideT;
            dialog.dismiss();
        });
        dialogBinding.btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    String strNewFileName;

    private void showRenameDialog(PictureData pictureData) {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_create_album);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_ok = dialog.findViewById(R.id.btn_ok);
        TextView txt_path = dialog.findViewById(R.id.txt_path);
        TextView tvGeneral = dialog.findViewById(R.id.tvGeneral);
        EditText editText = dialog.findViewById(R.id.edtAlbumName);
        txt_path.setVisibility(View.GONE);

        btn_ok.setText(getString(R.string.action_Done));
        tvGeneral.setText(getString(R.string.Rename));

        String[] separated = pictureData.getFileName().split("\\.");
        String oldName = separated[0];
        editText.setText(oldName);
        editText.requestFocus();

        String selectPath = "";
        selectPath = pictureData.getFilePath().substring(0, pictureData.getFilePath().lastIndexOf(pictureData.getFileName()) - 1);

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        btn_ok.setOnClickListener(view -> {
            strNewFileName = editText.getText().toString().trim();
            if (!strNewFileName.isEmpty()) {
                File renameFile = new File(pictureData.getFilePath().replace(separated[0], strNewFileName));
                if (!renameFile.exists()) {
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                        if (renamefileAboveQ(this, pictureData.getFilePath(), strNewFileName)) {
                            int position = binding.imagePager.getCurrentItem();
                            setRename(renameFile.getPath(), pictureData.getFilePath(), position);
                        }
                    } else {
                        if (renameFile(pictureData.getFilePath(), strNewFileName)) {
                            imm.hideSoftInputFromWindow(editText.getWindowToken(), InputMethodManager.HIDE_IMPLICIT_ONLY);
                            dialog.dismiss();
                            int position = binding.imagePager.getCurrentItem();
                            setRename(renameFile.getPath(), pictureData.getFilePath(), position);
                        }
                    }
                    imm.hideSoftInputFromWindow(editText.getWindowToken(), InputMethodManager.HIDE_IMPLICIT_ONLY);
                    dialog.dismiss();

                } else
                    Toast.makeText(ImageShowActivity.this, getString(R.string.rename_validation2), Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(ImageShowActivity.this, getString(R.string.rename_validation), Toast.LENGTH_SHORT).show();

        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    private void setRename(String newPath, String oldPath, int position) {
        File renameFile = new File(newPath);
        PictureData model = displayImageList.get(position);
        model.setFilePath(newPath);
        model.setFileName(renameFile.getName());
        ArrayList<RenameModel> renameModels = new ArrayList<>();
        renameModels.add(new RenameModel(new File(oldPath), renameFile));
        RxBus.getInstance().post(new RenameEvent(renameModels));

        runOnUiThread(() -> {
            binding.imageTitle.setText(displayImageList.get(position).getFileName());
            displayImageAdapter.notifyDataSetChanged();
        });
        List<String> favoriteList = preferencesManager.getFavoriteList();
        if (favoriteList != null) {
            if (favoriteList.contains(oldPath)) {
                favoriteList.remove(oldPath);
                favoriteList.add(0, newPath);
                preferencesManager.setFavoriteList(favoriteList);
            }
        }
    }

    private void updateRecent(PictureData pictureData) {
        if (!isPrivateList && !isFavList) {
            boolean isAdd = false;
            for (int i = 0; i < recentList.size(); i++) {
                if (pictureData.getFilePath().equalsIgnoreCase(recentList.get(i).getFilePath())) {
                    recentList.get(i).setLastDisplayDate(Calendar.getInstance().getTimeInMillis());
                    isAdd = true;
                    break;
                }
            }
            if (!isAdd) {
                pictureData.setLastDisplayDate(Calendar.getInstance().getTimeInMillis());
                recentList.add(pictureData);
            }
            preferencesManager.setRecentList(recentList);
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.R)
    private void deleteFileOnAboveQ() {
        ArrayList<Uri> uries = new ArrayList<>();
        File file1 = new File(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
        if (displayImageList.get(binding.imagePager.getCurrentItem()).isVideo())
            uries.add(getVideoUriFromFile(file1.getPath(), getApplication()));
        else
            uries.add(getImageUriFromFile(file1.getPath(), getApplication()));

        ContentResolver contentResolver = getContentResolver();
        try {

            IntentSender intentSender = MediaStore.createDeleteRequest(contentResolver, uries).getIntentSender();
            try {
                startIntentSenderForResult(intentSender, 2222, null, 0, 0, 0, null);
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }
        } catch (SecurityException securityException) {
            securityException.printStackTrace();
            RecoverableSecurityException exception = (RecoverableSecurityException) securityException;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                IntentSender intentSender = exception.getUserAction().getActionIntent().getIntentSender();
                try {
                    startIntentSenderForResult(intentSender, 2221, null, 0, 0, 0, null);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 2222 && resultCode == RESULT_OK) {
            int i = binding.imagePager.getCurrentItem();
            if (displayImageList.size() > i) {
                ArrayList<String> deleteList = new ArrayList<>();
                deleteList.add(displayImageList.get(i).getFilePath());
                displayImageList.remove(binding.imagePager.getCurrentItem());
                displayImageAdapter.notifyDataSetChanged();
                initAdapter();
                RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));
                if (i < displayImageList.size() - 1) {
                    position = i;
                    binding.imagePager.setCurrentItem(i);
                    int pos = binding.imagePager.getCurrentItem();
                    binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                } else {
                    if (displayImageList.size() == 0) {
                        onBackPressed();
                    } else {
                        try {
                            binding.imagePager.setCurrentItem(i - 1);
                            int pos = binding.imagePager.getCurrentItem();
                            binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }
            }
        } else if (requestCode == RENAME_FILE && resultCode == RESULT_OK) {
            int position = binding.imagePager.getCurrentItem();
            File oldFile = new File(displayImageList.get(position).getFilePath());

            if (SDK_INT >= Build.VERSION_CODES.Q) {
                if (renamefileAboveQ(this, oldFile.getPath(), strNewFileName)) {

                    String[] separated = oldFile.getName().split("\\.");
                    File renameFile = new File(oldFile.getPath().replace(separated[0], strNewFileName));

                    MediaScannerConnection.scanFile(this, new String[]{renameFile.getPath()}, null, (path, uri) -> {
                    });

                    MediaScannerConnection.scanFile(this, new String[]{oldFile.getPath()}, null, (path, uri) -> {
                    });

                    setRename(renameFile.getPath(), oldFile.getPath(), position);
                }
            }
        } else if (requestCode == Hide_FILE) {
            if (resultCode == RESULT_OK) {
                ArrayList<String> deleteList = new ArrayList<>();
                int i = binding.imagePager.getCurrentItem();
                displayImageList.remove(binding.imagePager.getCurrentItem());
                displayImageAdapter.notifyDataSetChanged();
                initAdapter();
                RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));
                if (i < displayImageList.size() - 1) {
                    position = i;
                    binding.imagePager.setCurrentItem(i);
                    int pos = binding.imagePager.getCurrentItem();
                    binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                } else {
                    if (displayImageList.size() == 0) {
                        onBackPressed();
                    } else {
                        try {
                            binding.imagePager.setCurrentItem(i - 1);
                            int pos = binding.imagePager.getCurrentItem();
                            binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }
            }
        }

        if (requestCode == REQUEST_HIDE_PERMISSION) {
            if (resultCode == RESULT_OK && data != null) {
                Uri treeUri = data.getData();
                getContentResolver().takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
                preferencesManager.putHideUri(treeUri.toString());
                hideMedia();
            }
        }
    }

    public static Uri getVideoUriFromFile(final String path, Context context) {
        ContentResolver resolver = context.getContentResolver();

        Cursor filecursor = resolver.query(MediaStore.Video.Media.getContentUri("external"),
                new String[]{BaseColumns._ID}, MediaStore.Video.VideoColumns.DATA + " = ?",
                new String[]{path}, MediaStore.Video.VideoColumns.DATE_ADDED + " desc");
        filecursor.moveToFirst();

        if (filecursor.isAfterLast()) {
            filecursor.close();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.VideoColumns.DATA, path);
            return resolver.insert(MediaStore.Video.Media.getContentUri("external"), values);
        } else {
            int imageId = filecursor.getInt(filecursor.getColumnIndexOrThrow(BaseColumns._ID));
            Uri uri = MediaStore.Video.Media.getContentUri("external").buildUpon().appendPath(
                    Integer.toString(imageId)).build();
            filecursor.close();
            return uri;
        }
    }

    public Uri getImageUriFromFile(final String path, Context context) {
        ContentResolver resolver = context.getContentResolver();

        Cursor filecursor = resolver.query(MediaStore.Images.Media.getContentUri("external"),
                new String[]{BaseColumns._ID}, MediaStore.Images.ImageColumns.DATA + " = ?",
                new String[]{path}, MediaStore.Images.ImageColumns.DATE_ADDED + " desc");
        filecursor.moveToFirst();

        if (filecursor.isAfterLast()) {
            filecursor.close();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.ImageColumns.DATA, path);
            return resolver.insert(MediaStore.Images.Media.getContentUri("external"), values);
        } else {
            int imageId = filecursor.getInt(filecursor.getColumnIndexOrThrow(BaseColumns._ID));
            Uri uri = MediaStore.Images.Media.getContentUri("external").buildUpon().appendPath(
                    Integer.toString(imageId)).build();
            filecursor.close();
            return uri;
        }
    }

    private void infoDialog() {
        DialogInfoBinding infoBinding = DialogInfoBinding.inflate(getLayoutInflater());
        final Dialog dialog = new Dialog(this, R.style.WideDialog2);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(infoBinding.getRoot());
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams wlp = dialog.getWindow().getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        dialog.getWindow().setAttributes(wlp);

        PictureData pictureData = displayImageList.get(binding.imagePager.getCurrentItem());
        infoBinding.txtFileName.setText(setTextInfo(getString(R.string.FileName), " ", pictureData.getFileName()));
        SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss a", Locale.ENGLISH);
        String strDate = format.format(pictureData.getDate());
        infoBinding.txtLastModified.setText(setTextInfo(getString(R.string.LastModified), " ", strDate));
        infoBinding.txtSize.setText(setTextInfo(getString(R.string.size), " ", Formatter.formatShortFileSize(this, pictureData.getFileSize())));
        String type = Constant.getMimeTypeFromFilePath(pictureData.getFilePath());
        infoBinding.txtFileType.setText(setTextInfo(getString(R.string.File_type), " ", type));
        String resolution = "";
        if (pictureData.isVideo()) {
            try {
                MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                metaRetriever.setDataSource(pictureData.getFilePath());
                int height = Integer.parseInt(Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)));
                int width = Integer.parseInt(Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)));
                resolution = width + " * " + height;
            } catch (Exception e) {
                e.printStackTrace();
                resolution = "--";
            }
        } else {
            try {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(pictureData.getFilePath(), options);
                int imageHeight = options.outHeight;
                int imageWidth = options.outWidth;
                resolution = imageWidth + " * " + imageHeight;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        File file = new File(pictureData.getFilePath());
        infoBinding.txtResolution.setText(setTextInfo(getString(R.string.Resolution), " ", resolution));
        infoBinding.txtAlbumName.setText(setTextInfo(getString(R.string.AlbumName), " ", file.getParentFile().getName()));
        infoBinding.txtPath.setText(setTextInfo(getString(R.string.Path), " ", pictureData.getFilePath()));

        dialog.show();
    }

    private SpannableString setTextInfo(String title, String empty, String value) {
        SpannableString ss1 = new SpannableString(title + empty + value);
        ss1.setSpan(new StyleSpan(Typeface.BOLD), 0, title.length(), 0);
//        tv.append(ss1);
//        tv.append("\n");
//        tv.append(steps);
        return ss1;
    }


    private void deleteDialog() {
        int i = binding.imagePager.getCurrentItem();
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_delete);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_delete = dialog.findViewById(R.id.btn_delete);

        btn_delete.setOnClickListener(view -> {
            dialog.dismiss();
            ArrayList<String> deleteList = new ArrayList<>();
            if (isPrivateList && SDK_INT >= Build.VERSION_CODES.R) {
                DocumentFile file = DocumentFile.fromSingleUri(ImageShowActivity.this, Uri.parse(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath()));
                file.delete();
                deleteList.add(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                MediaScannerConnection.scanFile(ImageShowActivity.this, new String[]{displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath()}, null, (path, uri) -> {
                });
            } else {
                File file1 = new File(displayImageList.get(binding.imagePager.getCurrentItem()).getFilePath());
                file1.delete();
                Uri deleteUrl = FileProvider.getUriForFile(ImageShowActivity.this, getPackageName() + ".provider", file1);
                ContentResolver contentResolver = getContentResolver();
                contentResolver.delete(deleteUrl, null, null);

                deleteList.add(file1.getPath());
                MediaScannerConnection.scanFile(ImageShowActivity.this, new String[]{file1.getPath()}, null, (path, uri) -> {
                });
            }
            displayImageList.remove(binding.imagePager.getCurrentItem());
            displayImageAdapter.notifyDataSetChanged();
            initAdapter();
            RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));
            if (i < displayImageList.size() - 1) {
                position = i;
                binding.imagePager.setCurrentItem(i);
                int pos = binding.imagePager.getCurrentItem();
                binding.imageTitle.setText(displayImageList.get(pos).getFileName());
            } else {
                if (displayImageList.size() == 0) {
                    onBackPressed();
                } else {
                    try {
                        binding.imagePager.setCurrentItem(i - 1);
                        int pos = binding.imagePager.getCurrentItem();
                        binding.imageTitle.setText(displayImageList.get(pos).getFileName());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialBackAd(this, 2, () -> finish());
    }

    private void updateFavData() {
        if (displayImageList != null && displayImageList.size() != 0 && displayImageList.size() > binding.imagePager.getCurrentItem())
            if (displayImageList.get(binding.imagePager.getCurrentItem()).isFavorite()) {
                binding.ivFav.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_heart_fill));
            } else {
                binding.ivFav.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_heart_unfill));
            }
    }

    private void setFavorite(String filePath) {
        List<String> favList = preferencesManager.getFavoriteList();
        if (favList == null) {
            favList = new ArrayList<>();
        }
        favList.add(0, filePath);
        preferencesManager.setFavoriteList(favList);
    }

    private void setUnFavorite(String filePath) {
        List<String> favList = preferencesManager.getFavoriteList();
        if (favList == null) {
            favList = new ArrayList<>();
        }
        for (int f = 0; f < favList.size(); f++) {
            if (favList.get(f) != null && !favList.get(f).equalsIgnoreCase("")) {
                if (favList.get(f).equalsIgnoreCase(filePath)) {
                    favList.remove(f);
                    break;
                }
            }
        }
        preferencesManager.setFavoriteList(favList);
    }

    private boolean renameFile(String filePath, String strNewFileName) {
        String[] separated = new File(filePath).getName().split("\\.");
        boolean renamed = false;
        String type = separated[1];
        String renameFilePath = new File(filePath).getParent() + File.separator + strNewFileName + "." + type;
        File oldFile = new File(filePath);
        File renameFile = new File(renameFilePath);

        if (renameFile.exists()) {
        } else {
            renamed = oldFile.renameTo(renameFile);
            boolean finalRenamed = renamed;

            new Thread(() -> {
                if (finalRenamed) {
                    final boolean[] isOldFileScan = {false};
                    final boolean[] isNewFileScan = {false};

                    MediaScannerConnection.scanFile(this, new String[]{renameFile.getPath()}, null, (path, uri) -> {
                        isNewFileScan[0] = true;
                    });

                    MediaScannerConnection.scanFile(this, new String[]{oldFile.getPath()}, null, (path, uri) -> {
                        isOldFileScan[0] = true;
                    });

                    while (!isOldFileScan[0] && !isNewFileScan[0]) {
                        Log.d("", "showRenameDialog: ");
                    }
                }
            }).start();
        }
        return renamed;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public boolean renamefileAboveQ(Context context, String filePath, String newName) {
        Uri mUri = null;
        ContentResolver contentResolver = context.getContentResolver();

        try {
            if (isVideo(new File(filePath).getName())) {

                mUri = getVideoUriFromFile(filePath, context);
                ContentValues contentValues = new ContentValues();

                contentValues.put(MediaStore.Video.Media.IS_PENDING, 1);
                contentResolver.update(mUri, contentValues, null, null);

                contentValues.clear();
                contentValues.put(MediaStore.Video.Media.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.Video.Media.IS_PENDING, 0);
                contentResolver.update(mUri, contentValues, null, null);
                return true;
            } else {
                mUri = getImageUriFromFile(filePath, context);
                ContentValues contentValues = new ContentValues();

                contentValues.put(MediaStore.Images.Media.IS_PENDING, 1);
                contentResolver.update(mUri, contentValues, null, null);

                contentValues.clear();
                contentValues.put(MediaStore.Images.Media.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0);
                int count = contentResolver.update(mUri, contentValues, null, null);
                return true;
            }


        } catch (SecurityException ex) {
            RecoverableSecurityException exception = (RecoverableSecurityException) ex;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                IntentSender intentSender = exception.getUserAction().getActionIntent().getIntentSender();
                try {
                    startIntentSenderForResult(intentSender, RENAME_FILE, null, 0, 0, 0, null);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }
            }
            ex.printStackTrace();
            return false;
        }
    }
}