package com.picturephoto.gallery.app.adapter;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.fastScrollRecyclerView.FastScroller;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class PictureAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements FastScroller.SectionIndexer {
    private static final int ITEM_PHOTOS_TYPE = 2;
    public static final int ITEM_HEADER_TYPE = 1;
    FragmentActivity activity;
    ArrayList<Object> pictures;
    OnSelectPicture onSelectPicture;
    public boolean isShowLabel = false;
    SimpleDateFormat format;
    String yesterday;
    String today;

    public PictureAdapter(FragmentActivity activity, ArrayList<Object> pictures, boolean isShowLabel, OnSelectPicture onSelectPicture) {
        this.activity = activity;
        this.pictures = pictures;
        this.onSelectPicture = onSelectPicture;
        this.isShowLabel = isShowLabel;
        format = new SimpleDateFormat("EEEE, MMM dd yyyy");

        Calendar calendar = Calendar.getInstance();
        today = format.format(calendar.getTimeInMillis());
        calendar.add(Calendar.DATE, -1);
        yesterday = format.format(calendar.getTimeInMillis());
    }

    public void setShowLabel(boolean showLabel) {
        isShowLabel = showLabel;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        try {
            if (pictures.get(position) instanceof AlbumData) {
                return ITEM_HEADER_TYPE;
            } else {
                return ITEM_PHOTOS_TYPE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ITEM_PHOTOS_TYPE;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        switch (viewType) {
            case ITEM_HEADER_TYPE:
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_header, parent, false);
                viewHolder = new HeaderViewHolder(view);
                break;
            case ITEM_PHOTOS_TYPE:
                View view1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_picture, parent, false);
                viewHolder = new PictureViewHolder(view1);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (getItemViewType(position)) {
            case ITEM_HEADER_TYPE:
                HeaderViewHolder headerViewHolder = (HeaderViewHolder) holder;
                AlbumData albumData = (AlbumData) pictures.get(position);

                Calendar calendar = Calendar.getInstance();
                String today = format.format(calendar.getTimeInMillis());
                calendar.add(Calendar.DATE, -1);
                String yesterday = format.format(calendar.getTimeInMillis());
                String strDate = albumData.getTitle();
                if (albumData.getTitle().equals(today))
                    strDate = activity.getString(R.string.Today);
                else if (albumData.getTitle().equals(yesterday))
                    strDate = activity.getString(R.string.Yesterday);

                headerViewHolder.headerText.setText(strDate);

                break;
            case ITEM_PHOTOS_TYPE:
                PictureViewHolder pictureViewHolder = (PictureViewHolder) holder;
                PictureData pictureData = (PictureData) pictures.get(position);
                Glide.with(activity).load(pictureData.getFilePath()).diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true).into(pictureViewHolder.image);

                if (isShowLabel) {
                    pictureViewHolder.txtName.setText(pictureData.getFileName());
                    pictureViewHolder.loutName.setVisibility(View.VISIBLE);
                } else
                    pictureViewHolder.loutName.setVisibility(View.GONE);

                if (pictureData.isVideo()) {
                    pictureViewHolder.loutDuration.setVisibility(View.VISIBLE);
                    pictureViewHolder.txtDuration.setText(getDurationString(pictureData.getVideoDuration()));
                    Log.e("pictureData", "txt duration :" + pictureViewHolder.txtDuration.getText() + " duration: " + pictureData.getVideoDuration());
                } else
                    pictureViewHolder.loutDuration.setVisibility(View.GONE);

//                if (pictureData.isCheckboxVisible()) {
//                    pictureViewHolder.iv_select.setVisibility(View.VISIBLE);
//                    if (pictureData.isSelected()) {
//                        pictureViewHolder.iv_select.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_done_select));
//                    } else {
//                        pictureViewHolder.iv_select.setImageDrawable(ContextCompat.getDrawable(activity, R.drawable.ic_done_unselect));
//                    }
//                } else {
//                    pictureViewHolder.iv_select.setVisibility(View.GONE);
//                }

                if (pictureData.isSelected()) {
                    pictureViewHolder.frame_layout.setBackgroundColor(activity.getResources().getColor(R.color.selected_image));

                    FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(pictureViewHolder.ll_main.getLayoutParams());
                    int margin = activity.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._6sdp);
                    layout.setMargins(margin, margin, margin, margin);
                    pictureViewHolder.ll_main.setLayoutParams(layout);
                    pictureViewHolder.lout_select.setVisibility(View.VISIBLE);
                    pictureViewHolder.iv_select.setVisibility(View.VISIBLE);
                } else {
                    pictureViewHolder.lout_select.setVisibility(View.GONE);
                    pictureViewHolder.iv_select.setVisibility(View.GONE);
                    FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(pictureViewHolder.ll_main.getLayoutParams());
                    int margin = 0;
                    layout.setMargins(margin, margin, margin, margin);
                    pictureViewHolder.ll_main.setLayoutParams(layout);
                    pictureViewHolder.frame_layout.setBackgroundColor(activity.getResources().getColor(R.color.white));
                }

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onSelectPicture.onSelectPicture(position);
                    }
                });
                holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        onSelectPicture.onLongClickPicture(position);
                        return true;
                    }
                });
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + getItemViewType(position));
        }
    }

    public String getDurationString(long duration) {
        long hours = TimeUnit.MILLISECONDS.toHours(duration);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration));

        String strMin;
        if (minutes < 10) {
            strMin = "0" + minutes;
        } else if (minutes >= 60) {
            long temp = minutes % 60;
            if (temp < 10) {
                strMin = "0" + temp;
            } else {
                strMin = String.valueOf(temp);
            }
        } else {
            strMin = String.valueOf(minutes);
        }

        String strSec;
        if (seconds < 10) {
            strSec = "0" + seconds;
        } else {
            strSec = String.valueOf(seconds);
        }

        String strHour;
        if (hours < 10) {
            strHour = "0" + hours;
        } else {
            strHour = String.valueOf(hours);
        }

        if (hours == 0) {
            return strMin + ":" + strSec;
        } else
            return strHour + ":" + strMin + ":" + strSec;
    }

    @Override
    public int getItemCount() {
        return pictures.size();
    }

    public void addData(ArrayList<Object> pictures) {
        this.pictures = pictures;
        notifyDataSetChanged();
    }

    @Override
    public CharSequence getSectionText(int position) {
        String valueSection = "k";
        String date;
        if (pictures != null && position < pictures.size()) {
            if (pictures.get(position) instanceof AlbumData) {
                AlbumData dateHeader = (AlbumData) pictures.get(position);
                date = dateHeader.getTitle();

            } else {
                PictureData dateHeader = (PictureData) pictures.get(position);
                date = format.format(dateHeader.getDate());
            }

            if (today.equals(date)) {
                valueSection = activity.getString(R.string.Today);
            } else if (yesterday.equals(date)) {
                valueSection = activity.getString(R.string.Yesterday);
            } else {
                valueSection = date;
//            if (date.contains(", " + Calendar.getInstance().get(Calendar.YEAR))) {
//                valueSection = date.replace(", " + Calendar.getInstance().get(Calendar.YEAR), "");
//
//            } else {
//                valueSection = date;
//            }
            }
        }
        return valueSection;
    }

    class HeaderViewHolder extends RecyclerView.ViewHolder {

        TextView headerText;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            headerText = itemView.findViewById(R.id.headerText);
        }
    }

    class PictureViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        RelativeLayout lout_select;
        AppCompatImageView iv_select;
        FrameLayout ll_main;
        FrameLayout frame_layout;
        LinearLayout loutName, loutDuration;
        TextView txtName, txtDuration;

        public PictureViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image);
            iv_select = itemView.findViewById(R.id.iv_select);
            frame_layout = itemView.findViewById(R.id.frame_layout);
            txtName = itemView.findViewById(R.id.txt_name);
            txtDuration = itemView.findViewById(R.id.txt_duration);
            loutName = itemView.findViewById(R.id.lout_name);
            loutDuration = itemView.findViewById(R.id.lout_duration);
            ll_main = itemView.findViewById(R.id.ll_main);
            lout_select = itemView.findViewById(R.id.lout_select);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

//            float radius = 0;
//            ShapeAppearanceModel shapeAppearanceModel = image.getShapeAppearanceModel().toBuilder()
//                    .setAllCornerSizes(radius)
//                    .build();
//            image.setShapeAppearanceModel(shapeAppearanceModel);
        }
    }

    public interface OnSelectPicture {
        void onSelectPicture(int pos);

        void onLongClickPicture(int pos);
    }
}
