package com.picturephoto.gallery.app.custom;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import com.calldorado.ui.views.custom.CalldoradoCustomView;
import com.picturephoto.gallery.app.activity.FavoriteListActivity;
import com.picturephoto.gallery.app.activity.HomeActivity;
import com.picturephoto.gallery.app.activity.HomeClassicActivity;
import com.picturephoto.gallery.app.activity.HomeFlatActivity;
import com.picturephoto.gallery.app.activity.MediaColorActivity;
import com.picturephoto.gallery.app.activity.PasswordActivity;
import com.picturephoto.gallery.app.activity.RecentActivity;
import com.picturephoto.gallery.app.activity.WpStatusActivity;
import com.picturephoto.gallery.app.databinding.AftercallNativeLayoutBinding;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AftercallCustomView extends CalldoradoCustomView {
    private Context context;
        HashMap<String,String> bucket = new HashMap<>();
    public AftercallCustomView(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public View getRootView() {
        AftercallNativeLayoutBinding binding = AftercallNativeLayoutBinding.inflate(LayoutInflater.from(context), getLinearViewGroup(), false);
        binding.photoCountTxt.setText(String.valueOf(getImages(context)));
        binding.videoCountTxt.setText(String.valueOf(getVideos(context)));
        binding.albumCountTxt.setText(String.valueOf(bucket.size()));
        binding.homeBtn.setOnClickListener(view -> openHomeScreenRedirect(0));
        binding.statusBtn.setOnClickListener(view -> openHomeScreenRedirect(1));
        binding.favoriteBtn.setOnClickListener(view -> openHomeScreenRedirect(2));
        binding.mediaColorBtn.setOnClickListener(view -> openHomeScreenRedirect(3));
        binding.recentBtn.setOnClickListener(view -> openHomeScreenRedirect(4));
        binding.vaultBtn.setOnClickListener(view -> openHomeScreenRedirect(5));
        return binding.getRoot();
    }

    private int getImages(Context context) {
        PreferencesManager preferencesManager = PreferencesManager.getInstance(context);
        Cursor mCursor;
        ArrayList<PictureData> allList = new ArrayList<>();
        List<String> folderList = new ArrayList();
        folderList.addAll(preferencesManager.getExcludeFolderList());

        try {
            String BUCKET_DISPLAY_NAME;
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME;

            String[] projection = {MediaStore.Images.Media.DATA
                    , BUCKET_DISPLAY_NAME
                    , MediaStore.MediaColumns.DATE_MODIFIED
                    , MediaStore.MediaColumns.DISPLAY_NAME
                    , MediaStore.MediaColumns.SIZE
            };

            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
            } else {
                uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            }

            mCursor = context.getContentResolver().query(
                    uri, // Uri
                    projection, // Projection
                    null,
                    null,
                    MediaStore.MediaColumns.DATE_MODIFIED + " DESC");


            if (mCursor != null) {
                mCursor.moveToFirst();
                for (mCursor.moveToFirst(); !mCursor.isAfterLast(); mCursor.moveToNext()) { //2sec

                    String path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                    String title = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME));

                    String bucketPath = "";
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1);

                    if (!folderList.contains(bucketPath)) {
                        if(!bucket.containsKey(bucketPath)){
                            bucket.put(bucketPath,bucketPath);
                        }
                        String bucketName = mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME));
                        long d = mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED));
                        d = d * 1000;

                        long fileSizeLength = mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE));

                        PictureData pictureData = new PictureData();
                        pictureData.setFilePath(path);
                        pictureData.setFileName(title);
                        pictureData.setFolderName(bucketName);
                        pictureData.setDate(d);
                        pictureData.setVideo(false);
                        pictureData.setFileSize(fileSizeLength);
                        allList.add(pictureData);
                    }
                }
                mCursor.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return allList.size();
    }

    private int getVideos(Context context) {
        PreferencesManager preferencesManager = PreferencesManager.getInstance(context);
        ArrayList<PictureData> allList = new ArrayList<>();
        String absolutePathOfImage;
        String path;
        int duration;

        Uri uri;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            uri = android.provider.MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else
            uri = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;


        String[] projection = {MediaStore.Video.VideoColumns.DATA,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.VideoColumns.SIZE,
                MediaStore.Video.VideoColumns.DURATION,
                MediaStore.Video.VideoColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME};

        List<String> folderList = new ArrayList();
        folderList.addAll(preferencesManager.getExcludeFolderList());

        try {
            Cursor cursor = context.getContentResolver().query(uri, projection, null, null, MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC");
            if (cursor != null) {
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION);

                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                    path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA));
                    absolutePathOfImage = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME));
                    String bucketName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME));

                    String bucketPath = "";
                    bucketPath = path.substring(0, path.lastIndexOf(absolutePathOfImage) - 1);

                    if (!folderList.contains(bucketPath)) {
                        if(!bucket.containsKey(bucketPath)){
                            bucket.put(bucketPath,bucketPath);
                        }
                        long d = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED));
                        d = d * 1000;
                        long fileSizeLength = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE));

                        PictureData pictureData = new PictureData();
                        pictureData.setFilePath(path);
                        pictureData.setFileName(absolutePathOfImage);
                        pictureData.setFolderName(bucketName);
                        pictureData.setDate(d);
                        pictureData.setVideo(true);
                        pictureData.setVideoDuration(cursor.getLong(duration));
                        pictureData.setFileSize(fileSizeLength);

                        allList.add(pictureData);
                    }
                }
                cursor.close();
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return allList.size();
    }

    private void openHomeScreenRedirect(int type) {
        PreferencesManager preferencesManager = PreferencesManager.getInstance(context);
        int theme = preferencesManager.getTheme();
        if (theme == 0) {
            startActivity(new Intent(context, HomeActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("isCallDorado", true).putExtra("type", type));
        } else if (theme == 1) {
            startActivity(
                    new Intent(context, HomeFlatActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("isCallDorado", true).putExtra("type", type));
        } else if (theme == 2) {
            startActivity(
                    new Intent(context, HomeClassicActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("isCallDorado", true).putExtra("type", type));
        }
    }
}