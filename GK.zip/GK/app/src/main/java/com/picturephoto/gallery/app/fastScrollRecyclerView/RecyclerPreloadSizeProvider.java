package com.picturephoto.gallery.app.fastScrollRecyclerView;

import android.util.SparseArray;
import android.view.View;

import androidx.annotation.Nullable;

import com.bumptech.glide.ListPreloader;
import com.bumptech.glide.request.target.SizeReadyCallback;
import com.bumptech.glide.request.target.ViewTarget;
import com.bumptech.glide.request.transition.Transition;
import com.picturephoto.gallery.app.model.PictureData;


public class RecyclerPreloadSizeProvider implements ListPreloader.PreloadSizeProvider<PictureData> {

    private RecyclerPreloadSizeProviderCallback callback;
    private SparseArray<int[]> viewSizes = new SparseArray<>();
    private boolean isAdditionClosed = false;

    public RecyclerPreloadSizeProvider(RecyclerPreloadSizeProviderCallback c) {
        callback = c;
    }

    /**
     * Adds one of the views that can be used to put an image inside.
     * If the id is already inserted the call will be ignored,
     * but for performance you should call {@link #closeOffAddition()} once you are done.
     *
     * @param id a unique number for each view loaded to this object
     * @param v the ciew to load
     */
    public void addView(int id, View v) {
        if(!isAdditionClosed && viewSizes.get(id, null) != null) return;

        final int viewNumber = id;
        new SizeViewTarget(v, (width, height) -> viewSizes.append(viewNumber, new int[] {width, height}));
    }

    /**
     * Calls to {@link #addView(int, View)} will be ignored
     */
    public void closeOffAddition() {
        isAdditionClosed = true;
    }

    @Nullable
    @Override
    public int[] getPreloadSize(PictureData item, int adapterPosition, int perItemPosition) {
        return viewSizes.get(callback.getCorrectView(item, adapterPosition), null);
    }

    public interface RecyclerPreloadSizeProviderCallback {

        /**
         * Get the id for the view in which the image will be loaded.
         * @return the view's id
         */
        int getCorrectView(PictureData item, int adapterPosition);
    }

    private static final class SizeViewTarget extends ViewTarget<View, Object> {
        public SizeViewTarget(View view, SizeReadyCallback callback) {
            super(view);
            getSize(callback);
        }

        @Override
        public void onResourceReady(Object resource, Transition<? super Object> transition) {
            // Do nothing
        }
    }
}
