package com.picturephoto.gallery.app.ads;

public interface AdEvenNativetListener {
    void onAdLoaded(boolean isLoadNative);
    void onAdClosed();
    void onLoadError(String errorCode);
    void onAdLoaded(Object object);
}
