package com.picturephoto.gallery.app.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.HashMap;

public class Database extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "gallery_stories.db";


    private static final String TABLE_PRIVATE = "Private";
    private static final String PRIVATE_ID = "private_id";
    private static final String PRIVATE_DATA_PATH = "private_data_path";
    private static final String PRIVATE_MAIN_DATA_PATH = "private_main_data_path";

    private String CREATE_PRIVATE_TABLE = "CREATE TABLE " + TABLE_PRIVATE + "(" + PRIVATE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + PRIVATE_DATA_PATH + " TEXT," + PRIVATE_MAIN_DATA_PATH + " TEXT" + ")";

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_PRIVATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(CREATE_PRIVATE_TABLE);
        onCreate(db);
    }

    public void addPrivate(String hidePath, String imagePath) {
        Log.e("addPrivate","hidePath: "+hidePath + " imagePath: "+imagePath);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PRIVATE_DATA_PATH, hidePath);
        values.put(PRIVATE_MAIN_DATA_PATH, imagePath);
        db.insert(TABLE_PRIVATE, null, values);
        db.close();
    }

    public Integer deletePrivate(String hidePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_PRIVATE, PRIVATE_DATA_PATH + " = ?", new String[]{hidePath});
    }

    public HashMap<String, String> getHideMainPath() {
        HashMap<String, String> hideList = new HashMap<>();
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("select * from " + TABLE_PRIVATE, null);
            if (cursor.moveToFirst()) {
                do {
                    String hidePath = cursor.getString(cursor.getColumnIndexOrThrow(PRIVATE_DATA_PATH));
                    String mainPath = cursor.getString(cursor.getColumnIndexOrThrow(PRIVATE_MAIN_DATA_PATH));
                    hideList.put(hidePath, mainPath);
                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
        } catch (Exception exp) {

        }

        return hideList;
    }

}
