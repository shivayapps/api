package com.picturephoto.gallery.app.fragment;

import static android.app.Activity.RESULT_OK;
import static android.os.Build.VERSION.SDK_INT;

import android.app.Dialog;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.activity.ImageShowActivity;
import com.picturephoto.gallery.app.adapter.SaveAdapter;
import com.picturephoto.gallery.app.databinding.FragmentRecentStatusBinding;
import com.picturephoto.gallery.app.event.CopyMoveEvent;
import com.picturephoto.gallery.app.event.DeleteEvent;
import com.picturephoto.gallery.app.event.DisplayDeleteEvent;
import com.picturephoto.gallery.app.interfaces.LongClickListener;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.rx.RxBus;
import com.picturephoto.gallery.app.utils.Constant;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import io.reactivex.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class SavedStatusFragment extends Fragment {

    FragmentRecentStatusBinding binding;
    PreferencesManager preferencesManager;
    List<Object> photoList = new ArrayList<>();
    private SaveAdapter favoriteAdapter;
    static LongClickListener longClickListener;
    int selected_Item = 0;

    public SavedStatusFragment() {
    }

    public void setLongClickListener(LongClickListener longClickListener) {
        this.longClickListener = longClickListener;
    }

    public static SavedStatusFragment newInstance() {
        SavedStatusFragment fragment = new SavedStatusFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CopyMoveEvent();
        DisplayDeleteEvent();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentRecentStatusBinding.inflate(inflater, container, false);
        intView();
        return binding.getRoot();
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(requireActivity());
        setAdapter();
        getData();
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            getData();
        });

        binding.txtMsg.setText(getString(R.string.NoSavedStatusFound));
        binding.txtMsg2.setText(getString(R.string.saveStatusMsg));

        binding.btnOpenWp.setOnClickListener(view -> {
            try {
                PackageManager pm = requireActivity().getPackageManager();
                Intent launchIntent = pm.getLaunchIntentForPackage("com.whatsapp");
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(launchIntent);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(requireActivity(), "Whatsapp is not install", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setData() {
        binding.swipeRefreshLayout.setRefreshing(false);
        binding.recyclerView.setVisibility(View.VISIBLE);
        if (favoriteAdapter != null)
            favoriteAdapter.notifyDataSetChanged();
        else
            setAdapter();

        setEmptyView();
    }

    private void setEmptyView() {
        if (photoList != null && photoList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void setAdapter() {
        binding.swipeRefreshLayout.setRefreshing(false);
        binding.recyclerView.setVisibility(View.VISIBLE);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(requireActivity(), 3, LinearLayoutManager.VERTICAL, false);
        binding.recyclerView.setLayoutManager(gridLayoutManager);
        favoriteAdapter = new SaveAdapter(requireActivity(), photoList, false, new SaveAdapter.OnSelectPicture() {
            @Override
            public void onSelectPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    if (imageList.isCheckboxVisible()) {
                        imageList.setSelected(!imageList.isSelected());
                        favoriteAdapter.notifyItemChanged(pos);
                        setSelectedFile();
                    } else {
                        int temp_pos = -1;
                        ArrayList<PictureData> dataList = new ArrayList<>();
                        for (int i = 0; i < photoList.size(); i++) {
                            if (photoList.get(i) instanceof PictureData) {
                                dataList.add((PictureData) photoList.get(i));
                                if (pos == i) {
                                    temp_pos = dataList.size() - 1;
                                }
                            }
                        }
                        Constant.displayImageList = new ArrayList<>();
                        Constant.displayImageList.addAll(dataList);
                        Intent intent = new Intent(requireActivity(), ImageShowActivity.class);
                        intent.putExtra("pos", temp_pos);
                        intent.putExtra("IsPrivateList", false);
                        intent.putExtra("IsFavList", false);
                        intent.putExtra("IsShowSlideShow", false);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onLongClickPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                model.setCheckboxVisible(true);
                            }
                    }
                    imageList.setCheckboxVisible(true);
                    imageList.setSelected(true);
                    favoriteAdapter.notifyDataSetChanged();
                    setSelectedFile();
                }
            }
        });
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(final int position) {
                if (favoriteAdapter.getItemViewType(position) == SaveAdapter.ITEM_HEADER_TYPE) {
                    return 3;
                }
                return 1;
            }
        });
        binding.recyclerView.setAdapter(favoriteAdapter);
    }

    private void setSelectedFile() {
        int selected = 0;
        long size = 0;
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                        size += model.getFileSize();
                    }
                }
        }

        if (selected == 0) {
            setRefreshData(true);
            longClickListener.longClick(true, false, selected, size);
            setClose();
        } else {
            setRefreshData(false);
            longClickListener.longClick(false, true, selected, size);
        }
        selected_Item = selected;
    }


    public void setRefreshData(boolean isEnable) {
        if (isEnable)
            binding.swipeRefreshLayout.setEnabled(true);
        else
            binding.swipeRefreshLayout.setEnabled(false);
    }

    public void setClose() {
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);
                }
        }
        if (favoriteAdapter != null) {
            favoriteAdapter.notifyDataSetChanged();
        }
        setRefreshData(true);
        selected_Item = 0;
    }

    public void setAllSelect(boolean isSelectAll) {
        if (isSelectAll) {
            int selected = 0;
            long size = 0;
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        selected++;
                        size += model.getFileSize();
                        model.setSelected(true);
                    }
            }
            if (favoriteAdapter != null)
                favoriteAdapter.notifyDataSetChanged();
            longClickListener.longClick(false, true, selected, size);
            selected_Item = selected;
        } else {
            longClickListener.longClick(true, false, 0, 0);
            setClose();
        }
    }

    public void shareFile() {
        if (selected_Item != 0) {
            ArrayList<Uri> uris = new ArrayList<>();
            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.isSelected()) {
                            Uri uri;
                            uri = FileProvider.getUriForFile(requireActivity(), requireActivity().getPackageName() + ".provider", new File(model.getFilePath()));
                            uris.add(uri);
                        }
                    }
            }
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(Intent.createChooser(intent, getActivity().getString(R.string.share_with)));
            startActivityForResult(Intent.createChooser(intent,getString(R.string.share_with)), 909);
        } else
            Toast.makeText(getActivity(), getActivity().getString(R.string.Pleaseselectimage), Toast.LENGTH_SHORT).show();

    }


    private void getData() {
        binding.swipeRefreshLayout.setRefreshing(true);
        Observable.fromCallable(() -> {
                    getImageOrVideo();
                    return true;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    try {
                        requireActivity().runOnUiThread(() -> {
                            setData();
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                })
                .subscribe((result) -> {
                    try {
                        requireActivity().runOnUiThread(() -> {
                            setData();
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
    }

    private void getImageOrVideo() {
        photoList.clear();
        LinkedHashMap<String, ArrayList<PictureData>> bucketImagesDataPhotoHashMap = new LinkedHashMap<>();
        LinkedHashMap<String, ArrayList<PictureData>> dateWisephotoList = new LinkedHashMap<>();
        SimpleDateFormat format = new SimpleDateFormat("EEEE, MMM dd yyyy");

        final String[] projection = {MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MIME_TYPE, MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME,
                MediaStore.Files.FileColumns.DURATION};

        String selection = MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE
                + " OR "
                + MediaStore.Files.FileColumns.MEDIA_TYPE + "="
                + MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;


        try {
            Cursor cursor = requireActivity().getContentResolver().query(MediaStore.Files
                            .getContentUri("external"), projection,
                    selection,
                    null, "LOWER(" + MediaStore.Files.FileColumns.DATE_MODIFIED + ") DESC");
            String androidPath = Constant.DOWNLOAD_WP_PATH;
            if (cursor != null) {
                cursor.moveToFirst();

                // video image
                for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) { //2sec
                    String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA));
                    String mineType = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE));

                    if (path != null /*&& androidPath.toLowerCase().contains(path.toLowerCase())*/
                            && path.toLowerCase().contains(androidPath.toLowerCase())
                            && mineType != null) {
//                    Log.e("getImageOrVideo", "mineType: " + mineType);
                        String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME));
                        String bucketName = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME));
                        long fileSizeLength = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE));

                        long d = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED));
                        d = d * 1000;

                        String strDate = format.format(d);
                        PictureData pictureData = new PictureData();
                        pictureData.setFilePath(path);
                        pictureData.setFileName(title);
                        pictureData.setFolderName(bucketName);
                        pictureData.setDate(d);
                        pictureData.setVideo(mineType.contains("video"));
                        pictureData.setFileSize(fileSizeLength);
                        if (mineType.contains("video")) {
//                        int duration = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DURATION);
//                        pictureData.setVideoDuration(duration);
                            try {
                                MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                                mmr.setDataSource(requireActivity(), Uri.parse(path));
                                String durations = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                                mmr.release();
                                pictureData.setVideoDuration(Long.parseLong(durations));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        ArrayList<PictureData> imagesData1;
                        if (bucketImagesDataPhotoHashMap.containsKey(strDate)) {
                            imagesData1 = bucketImagesDataPhotoHashMap.get(strDate);
                            if (imagesData1 == null)
                                imagesData1 = new ArrayList<>();

                        } else {
                            imagesData1 = new ArrayList<>();
                        }
                        imagesData1.add(pictureData);
                        bucketImagesDataPhotoHashMap.put(strDate, imagesData1);
                    }
                }

                cursor.close();

            }

            Set<String> keys = bucketImagesDataPhotoHashMap.keySet();
            ArrayList<String> listKeys = new ArrayList<>(keys);

            for (int i = 0; i < listKeys.size(); i++) {
                ArrayList<PictureData> imagesData = bucketImagesDataPhotoHashMap.get(listKeys.get(i));
                if (imagesData != null && imagesData.size() != 0) {
                    AlbumData bucketData = new AlbumData();
                    bucketData.setTitle(listKeys.get(i));
                    bucketData.setPictureData(imagesData);
                    photoList.add(bucketData);
                    photoList.addAll(imagesData);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void ShowDelete() {
        if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
            deleteFileOnAboveQ();
        } else
            showDeleteDialog();
    }

    private void showDeleteDialog() {
        final Dialog dialog = new Dialog(requireActivity(), R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_delete);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_delete = dialog.findViewById(R.id.btn_delete);

        btn_delete.setOnClickListener(view -> {
            dialog.dismiss();
            deletePhoto();
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    private void deletePhoto() {
        ArrayList<String> deleteList = new ArrayList<>();
        Dialog dialog = new Dialog(requireActivity(), R.style.WideDialog);
        TextView btnCancel, txtProgressCount, txtTitle;
        ProgressBar progressBar;

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dilaog_delete_progress);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        btnCancel = dialog.findViewById(R.id.btnCancel);
        txtTitle = dialog.findViewById(R.id.txt_title);
        txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
        progressBar = dialog.findViewById(R.id.progress_bar);
        progressBar.setMax(selected_Item);
        requireActivity().runOnUiThread(() -> {
            int progress = (deleteList.size() / 100) * selected_Item;
            txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
            progressBar.setProgress(deleteList.size());

        });

        btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();

        Observable.fromCallable(() -> {
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                if (model.isSelected()) {
                                    File file = new File(model.getFilePath());

                                    requireActivity().runOnUiThread(() -> {
                                        txtTitle.setText(model.getFileName());
                                    });
                                    try {
                                        file.delete();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    Uri deleteUrl = FileProvider.getUriForFile(getActivity(), getActivity().getApplicationContext().getPackageName() + ".provider", file);
                                    ContentResolver contentResolver = getActivity().getContentResolver();
                                    contentResolver.delete(deleteUrl, null, null);

                                    MediaScannerConnection.scanFile(getActivity(), new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                        public void onScanCompleted(String path, Uri uri) {
                                            // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                                        }
                                    });
                                    deleteList.add(file.getPath());

                                    requireActivity().runOnUiThread(() -> {
                                        int progress = (deleteList.size() / 100) * selected_Item;
                                        txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
                                        progressBar.setProgress(deleteList.size());
                                    });
                                } else {
                                    model.setCheckboxVisible(false);
                                }
                            }
                    }
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                if (model.isSelected()) {
                                    boolean isPre = false, isNext = false;

                                    if (i != 0) {
                                        if (photoList.get(i - 1) instanceof AlbumData) {
                                            isPre = true;
                                        } else {
                                            isPre = false;
                                        }
                                    }

                                    if (i < (photoList.size() - 2)) {
                                        if (photoList.get(i + 1) instanceof AlbumData) {
                                            isNext = true;
                                        } else {
                                            isNext = false;
                                        }
                                    }

                                    if (isPre && isNext) {
                                        //  objectList.remove(i + 1);
                                        photoList.remove(i);
                                        photoList.remove(i - 1);

                                    } else if (i == (photoList.size() - 1)) {
                                        photoList.remove(i);
                                        if (isPre) {
                                            photoList.remove(i - 1);
                                        }
                                    } else {
                                        photoList.remove(i);
                                    }

                                    if (i != 0) {
                                        i--;
                                    }
                                }
                            }
                    }
                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    requireActivity().runOnUiThread(() -> {
                        requireActivity().runOnUiThread(() -> {
                            RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                            if (dialog != null)
                                if (dialog.isShowing()) {
                                    dialog.dismiss();
                                }
                            selected_Item = 0;
                            longClickListener.longClick(true, false, 0, 0);
                            favoriteAdapter.notifyDataSetChanged();
                            setEmptyView();
                            Toast.makeText(getActivity(), getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
                        });
                    });
                })
                .subscribe((result) -> {
                    requireActivity().runOnUiThread(() -> {
                        requireActivity().runOnUiThread(() -> {
                            RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                            if (dialog != null)
                                if (dialog.isShowing()) {
                                    dialog.dismiss();
                                }
                            selected_Item = 0;
                            longClickListener.longClick(true, false, 0, 0);
                            favoriteAdapter.notifyDataSetChanged();
                            setEmptyView();
                            Toast.makeText(getActivity(), getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
                        });
                    });
                });
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    public void deleteFileOnAboveQ() {
        ArrayList<Uri> uries = new ArrayList<>();
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        File file = new File(model.getFilePath());
                        if (model.isVideo())
                            uries.add(getVideoUriFromFile(file.getPath(), getActivity()));
                        else
                            uries.add(getImageUriFromFile(file.getPath(), getActivity()));
                    }
                }
        }

        ContentResolver contentResolver = getActivity().getContentResolver();
        try {
            IntentSender intentSender = MediaStore.createDeleteRequest(contentResolver, uries).getIntentSender();
            try {
                startIntentSenderForResult(intentSender, 2222, null, 0, 0, 0, null);
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }
        } catch (SecurityException securityException) {
            securityException.printStackTrace();
            RecoverableSecurityException exception = (RecoverableSecurityException) securityException;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                IntentSender intentSender = exception.getUserAction().getActionIntent().getIntentSender();
                try {
                    startIntentSenderForResult(intentSender, 2221, null, 0, 0, 0, null);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    public Uri getVideoUriFromFile(final String path, Context context) {
        ContentResolver resolver = context.getContentResolver();

        Cursor filecursor = resolver.query(MediaStore.Video.Media.getContentUri("external"),
                new String[]{BaseColumns._ID}, MediaStore.Video.VideoColumns.DATA + " = ?",
                new String[]{path}, MediaStore.Video.VideoColumns.DATE_ADDED + " desc");
        filecursor.moveToFirst();

        if (filecursor.isAfterLast()) {
            filecursor.close();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.VideoColumns.DATA, path);
            return resolver.insert(MediaStore.Video.Media.getContentUri("external"), values);
        } else {
            int imageId = filecursor.getInt(filecursor.getColumnIndexOrThrow(BaseColumns._ID));
            Uri uri = MediaStore.Video.Media.getContentUri("external").buildUpon().appendPath(
                    Integer.toString(imageId)).build();
            filecursor.close();
            return uri;
        }
    }

    public Uri getImageUriFromFile(final String path, Context context) {
        ContentResolver resolver = context.getContentResolver();

        Cursor filecursor = resolver.query(MediaStore.Images.Media.getContentUri("external"),
                new String[]{BaseColumns._ID}, MediaStore.Images.ImageColumns.DATA + " = ?",
                new String[]{path}, MediaStore.Images.ImageColumns.DATE_ADDED + " desc");
        filecursor.moveToFirst();

        if (filecursor.isAfterLast()) {
            filecursor.close();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.ImageColumns.DATA, path);
            return resolver.insert(MediaStore.Images.Media.getContentUri("external"), values);
        } else {
            int imageId = filecursor.getInt(filecursor.getColumnIndexOrThrow(BaseColumns._ID));
            Uri uri = MediaStore.Images.Media.getContentUri("external").buildUpon().appendPath(
                    Integer.toString(imageId)).build();
            filecursor.close();
            return uri;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2222 && resultCode == RESULT_OK) {
            ArrayList<String> deleteList = new ArrayList<>();
            deleteList.addAll(getDeleteListOnResult());


            requireActivity().runOnUiThread(() -> {
                RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                selected_Item = 0;
                longClickListener.longClick(true, false, 0, 0);
                favoriteAdapter.notifyDataSetChanged();
                setEmptyView();
                Toast.makeText(getActivity(), getActivity().getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
            });
        }

        if (requestCode == 909) {
            setClose();
            longClickListener.longClick(true, false, 0, 0);
        }
    }

    private ArrayList<String> getDeleteListOnResult() {
        ArrayList<String> deleteList = new ArrayList<>();
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    if (model.isSelected()) {
                        deleteList.add(model.getFilePath());
                        boolean isPre = false, isNext = false;

                        if (i != 0) {
                            if (photoList.get(i - 1) instanceof AlbumData) {
                                isPre = true;
                            } else {
                                isPre = false;
                            }
                        }

                        if (i < (photoList.size() - 2)) {
                            if (photoList.get(i + 1) instanceof AlbumData) {
                                isNext = true;
                            } else {
                                isNext = false;
                            }
                        }

                        if (isPre && isNext) {
                            //  objectList.remove(i + 1);
                            photoList.remove(i);
                            photoList.remove(i - 1);

                        } else if (i == (photoList.size() - 1)) {
                            photoList.remove(i);
                            if (isPre) {
                                photoList.remove(i - 1);
                            }
                        } else {
                            photoList.remove(i);
                        }

                        if (i != 0) {
                            i--;
                        }
                    }
                }
        }
        return deleteList;
    }


    private void CopyMoveEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(CopyMoveEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<CopyMoveEvent>() {
            @Override
            public void call(CopyMoveEvent event) {
                if (event.getCopyMoveList() != null && event.getCopyMoveList().size() != 0) {
                    requireActivity().runOnUiThread(() -> {
                        getData();
                    });
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void DisplayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {
            if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                getData();
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }
}