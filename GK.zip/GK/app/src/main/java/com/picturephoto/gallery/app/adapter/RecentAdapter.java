package com.picturephoto.gallery.app.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class RecentAdapter extends RecyclerView.Adapter<RecentAdapter.ViewHolder> {

    FragmentActivity activity;
    ArrayList<AlbumData> albums;
    OnSelectAlbum onSelectAlbum;
    SimpleDateFormat format;

    public RecentAdapter(FragmentActivity activity, ArrayList<AlbumData> albums, OnSelectAlbum onSelectAlbum) {
        this.activity = activity;
        this.onSelectAlbum = onSelectAlbum;
        this.albums = albums;
        format = new SimpleDateFormat("EEEE, MMM dd yyyy");
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_recent, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        AlbumData albumData = albums.get(position);

        Calendar calendar = Calendar.getInstance();
        String today = format.format(calendar.getTimeInMillis());
        calendar.add(Calendar.DATE, -1);
        String yesterday = format.format(calendar.getTimeInMillis());

        String strDate = albumData.getTitle();
        if (albumData.getTitle().equals(today))
            strDate = activity.getString(R.string.Today);
        else if (albumData.getTitle().equals(yesterday))
            strDate = activity.getString(R.string.Yesterday);

        holder.imagesDate.setText(strDate);

        ArrayList<PictureData> list = albumData.getPictureData();
        if (list != null) {
            if (list.size() == 0) {
                holder.imagesRow1.setVisibility(View.GONE);
                holder.imagesRow2.setVisibility(View.GONE);
            } else {
                for (int p = 0; p < list.size(); p++) {
                    if (6 < list.size()) {
                        holder.txtMore.setVisibility(View.VISIBLE);
                    } else
                        holder.txtMore.setVisibility(View.GONE);

                    if (p == 0) {
                        holder.imagesRow1.setVisibility(View.VISIBLE);
                        Glide.with(activity).load(list.get(p).getFilePath())
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true).into(holder.aspectImage0);
                    } else if (p == 1)
                        Glide.with(activity).load(list.get(p).getFilePath())
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true).into(holder.aspectImage1);
                    else if (p == 2)
                        Glide.with(activity).load(list.get(p).getFilePath())  .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true).into(holder.aspectImage2);
                    else if (p == 3) {
                        holder.imagesRow2.setVisibility(View.VISIBLE);
                        Glide.with(activity).load(list.get(p).getFilePath())  .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true).into(holder.aspectImage3);
                    } else if (p == 4)
                        Glide.with(activity).load(list.get(p).getFilePath())  .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true).into(holder.aspectImage4);
                    else if (p == 5) {
                        Glide.with(activity).load(list.get(p).getFilePath())  .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true).into(holder.aspectImage5);
                        break;
                    }
                }

//                holder.time_marker.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, holder.lout_main.getHeight()));
//                holder.time_marker.requestLayout();

                holder.aspectImage0.setOnClickListener(view -> onSelectAlbum.onClickImageShow(position,0));
                holder.aspectImage1.setOnClickListener(view -> onSelectAlbum.onClickImageShow(position,1));
                holder.aspectImage2.setOnClickListener(view -> onSelectAlbum.onClickImageShow(position,2));
                holder.aspectImage3.setOnClickListener(view -> onSelectAlbum.onClickImageShow(position,3));
                holder.aspectImage4.setOnClickListener(view -> onSelectAlbum.onClickImageShow(position,4));
                holder.aspectImage5.setOnClickListener(view -> {
                    if (holder.txtMore.getVisibility() == View.VISIBLE)
                        onSelectAlbum.onClickMore(position);
                    else
                        onSelectAlbum.onClickImageShow(position,5);
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        return albums.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView imagesDate;
        LinearLayout imagesRow1, imagesRow2;
        ImageView aspectImage0, aspectImage1, aspectImage2, aspectImage3, aspectImage4, aspectImage5;
        TextView txtMore;

        RelativeLayout lout_main;
        LinearLayout time_marker;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imagesDate = itemView.findViewById(R.id.imagesDate);
            imagesRow1 = itemView.findViewById(R.id.imagesRow1);
            imagesRow2 = itemView.findViewById(R.id.imagesRow2);

            aspectImage0 = itemView.findViewById(R.id.aspectImage0);
            aspectImage1 = itemView.findViewById(R.id.aspectImage1);
            aspectImage2 = itemView.findViewById(R.id.aspectImage2);
            aspectImage3 = itemView.findViewById(R.id.aspectImage3);
            aspectImage4 = itemView.findViewById(R.id.aspectImage4);
            aspectImage5 = itemView.findViewById(R.id.aspectImage5);
            time_marker = itemView.findViewById(R.id.time_marker);
            lout_main = itemView.findViewById(R.id.lout_main);

            txtMore = itemView.findViewById(R.id.txtMore);

        }
    }

    public interface OnSelectAlbum {
        void onClickImageShow(int mainPos,int pos);

        void onClickMore(int mainPos);
    }
}
