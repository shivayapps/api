package com.picturephoto.gallery.app.utils;

import android.webkit.MimeTypeMap;

public class Utils {
    public static String setDuration(long timeMs) {
        String hourString = "";
        String minuteString = "00";
        String secondString = "00";
        int hours = (int) (timeMs / 3600000);
        int minutes = ((int) (timeMs % 3600000)) / 60000;
        int seconds = (int) (((timeMs % 3600000) % 60000) / 1000);

        if (hours < 10 && hours != 0) {
            hourString = "0" + hours + ":";
        } else if (hours >= 10) {
            hourString = hours + ":";
        }

        if (minutes < 10) {
            minuteString = "0" + minutes;
        } else {
            minuteString = minutes + "";
        }

        if (seconds < 10) {
            secondString = "0" + seconds;
        } else {
            secondString = seconds + "";
        }

        return hourString + minuteString + ":" + secondString;
    }

    public static String getMimeType(String path) {
        String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(getExtension(path.toLowerCase()));
        if (mimeType == null) {
            return "";
        }
        return mimeType;
    }

    public static String getExtension(String path) {
        String extension = "";
        if (path != null) {
            int i = path.lastIndexOf('.');
            if (i > 0) {
                extension = path.substring(i + 1);
            }
        }
        return extension;
    }

    public static boolean isWpFile(String type) {
        if (type != null
                && (type.endsWith("jpg") || type.endsWith("gif")
                || type.endsWith("png") || type.endsWith("jpeg")
                || type.endsWith("bmp") || type.endsWith("wbmp")
                || type.endsWith("ico") || type.endsWith("jpe")
                || type.endsWith("mp4") || type.endsWith("mov")
                || type.endsWith("wmv") || type.endsWith("avi")
                || type.endsWith("avchd") || type.endsWith("mkv")
                || type.endsWith("webm") || type.endsWith("flv"))) {
            return true;
        }
        return false;
    }

    public static boolean isWpVideo(String type) {
        if (type != null
                && (type.endsWith("mp4") || type.endsWith("mov")
                || type.endsWith("wmv") || type.endsWith("avi")
                || type.endsWith("avchd") || type.endsWith("mkv")
                || type.endsWith("webm") || type.endsWith("flv"))) {
            return true;
        }
        return false;
    }

    public static boolean isImage(String type) {
        if (type != null
                && (type.equals("jpg") || type.equals("gif")
                || type.equals("png") || type.equals("jpeg")
                || type.equals("bmp") || type.equals("wbmp")
                || type.equals("ico") || type.equals("jpe"))) {
            return true;
        }
        return false;
    }

    public static boolean isVideo(String type) {
        if (type != null
                && (type.equals("mp4") || type.equals("mov")
                || type.equals("wmv") || type.equals("avi")
                || type.equals("avchd") || type.equals("mkv")
                || type.equals("webm") || type.equals("flv"))) {
            return true;
        }
        return false;
    }

    public static String getFileType(String fileName) {
        if (fileName != null) {
            int typeIndex = fileName.lastIndexOf(".");
            if (typeIndex != -1) {
                String fileType = fileName.substring(typeIndex + 1)
                        .toLowerCase();
                return fileType;
            }
        }
        return "";
    }
}
