package com.picturephoto.gallery.app.utils;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

public class ManageExternalPermissionManager {
    public static final int LISTEN_TIMEOUT = 5 * 20;
    private static final int THREAD_SLEEP_TIME = 200;
    private Activity activity;
    private Thread thread;
    private boolean shouldContinueThread = true;

    public ManageExternalPermissionManager(Activity activity) {
        this.activity = activity;
    }

    public void requestOverlay(ActivityResultLauncher<Intent> resultIntentForOverlay) {
        shouldContinueThread = true;
        sendToSettings(resultIntentForOverlay);
        startGrantedCheckThread();
    }

    private void sendToSettings(ActivityResultLauncher<Intent> resultIntentForOverlay) {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + activity.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            resultIntentForOverlay.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void startGrantedCheckThread() {
        thread = new Thread() {
            @RequiresApi(api = Build.VERSION_CODES.R)
            @Override
            public void run() {
                int counter = 0;
                while (!Environment.isExternalStorageManager() && shouldContinueThread
                        && counter < LISTEN_TIMEOUT) {
                    try {
                        counter++;
                        sleep(THREAD_SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if (shouldContinueThread && counter < LISTEN_TIMEOUT) {
                    Intent intent = new Intent(activity, activity.getClass());
                    intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    intent.putExtra("from", 1);
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                        activity.startActivity(intent);
                    } else {
                        activity.startActivityIfNeeded(intent, 0);
                    }
                }
            }
        };
        thread.start();
    }

    public boolean isGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        return true;
    }
}