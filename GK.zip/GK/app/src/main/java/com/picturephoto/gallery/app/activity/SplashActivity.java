package com.picturephoto.gallery.app.activity;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION.SDK_INT;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryPurchasesParams;
import com.calldorado.Calldorado;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.ads.AppOpenManager;
import com.picturephoto.gallery.app.ads.Variables;
import com.picturephoto.gallery.app.network.JSONParser;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.utils.Application;
import com.picturephoto.gallery.app.utils.ManageExternalPermissionManager;
import com.picturephoto.gallery.app.utils.OverlayPermissionManager;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;


public class SplashActivity extends AppCompatActivity {

    com.picturephoto.gallery.app.databinding.ActivitySplashBinding binding;

    private static final int PERMISSION_CALL_LOG_CODE = 333;

    PreferencesManager preferencesManager;

    ActivityResultLauncher<Intent> lockActivityResultLauncher;

    private BillingClient billingClient;
    private AppOpenManager appOpenManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Variables.isSplashScreen = true;
        preferencesManager = PreferencesManager.getInstance(this);
        changeLanguage();
        binding = com.picturephoto.gallery.app.databinding.ActivitySplashBinding.inflate(
                getLayoutInflater());
        setContentView(binding.getRoot());
        binding.privacyPolicyLayout.setVisibility(View.GONE);
        preferencesManager.putStoragePermission11(true);
        appOpenManager = AppOpenManager.getInstance(Application.myApplication);
        intView();
    }

    private void changeLanguage() {
        ArrayList<String> languageCodes = new ArrayList<>();
        languageCodes.add("en");
        languageCodes.add("hi");
        languageCodes.add("zh");
        languageCodes.add("es");
        languageCodes.add("de");
        languageCodes.add("ru");
        languageCodes.add("pt");
        languageCodes.add("fi");
        languageCodes.add("ja");
        languageCodes.add("tr");
        languageCodes.add("no");
        languageCodes.add("in");
        languageCodes.add("it");
        languageCodes.add("fr");
        languageCodes.add("nl");
        languageCodes.add("ko");
        languageCodes.add("ka");
        languageCodes.add("ga");
        languageCodes.add("pl");
        languageCodes.add("ca");
        Locale locale = new Locale(languageCodes.get(preferencesManager.getLanguage()));
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getBaseContext().getResources().updateConfiguration(config,
                getBaseContext().getResources().getDisplayMetrics());
    }

    private void showNext() {
        if (checkPermission()) {
            showNextScreen();
        } else {
            requestPermission();
        }
    }

    private void intView() {
        setActivityResultLauncher();
        billingClient = BillingClient.newBuilder(this).enablePendingPurchases().setListener(
                purchasesUpdatedListener).build();
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    billingClient.queryPurchasesAsync(
                            QueryPurchasesParams.newBuilder().setProductType(
                                            BillingClient.ProductType.SUBS)//or SUBS
                                    .build(), (billingResult1, purchases) -> {
                                if (billingResult1.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                                    if (purchases != null && purchases.size() > 0) {
                                        for (Purchase purchase : purchases) {
                                            if (purchase.isAcknowledged())
                                                preferencesManager.putSubscription(
                                                        SplashActivity.this, true);
                                        }
                                    } else
                                        preferencesManager.putSubscription(SplashActivity.this,
                                                false);
                                }
                            });
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
            }
        });
        if (isInternetAvailable()) {
            apiCall();
        } else {
            callNext();
        }
        binding.checkPolicy.setOnClickListener(view -> {
            try{
                String url = "https://sites.google.com/view/gallerypolicyapp/home";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }catch (Exception exp){

            }
        });
        binding.btnGetStarted.setOnClickListener(view -> {
            if (binding.signupPolicy.isChecked()) {
                preferencesManager.putPrivacy(true);
                HashMap<Calldorado.Condition, Boolean> conditionsMap = new HashMap<>();
                conditionsMap.put(Calldorado.Condition.EULA, true);
                conditionsMap.put(Calldorado.Condition.PRIVACY_POLICY, true);
                Calldorado.acceptConditions(this, conditionsMap);
                showNext();
            } else
                Toast.makeText(this, getString(R.string.privacy_policy_validation),
                        Toast.LENGTH_SHORT).show();
        });
    }

    private void callNext() {
        if (checkPermission() && permissionCallLog(PERMISSION_CALL_LOG_CODE) && isDrawOverlayPermission(false)) {
            showNext();
        } else {
            binding.titlePermission.setVisibility(View.VISIBLE);
            binding.titlePermission1.setVisibility(View.VISIBLE);
            binding.titlePermission2.setVisibility(View.VISIBLE);
            binding.titlePermission3.setVisibility(View.VISIBLE);
            binding.desPermission1.setVisibility(View.VISIBLE);
            binding.desPermission2.setVisibility(View.VISIBLE);
            binding.desPermission3.setVisibility(View.VISIBLE);
            binding.privacyPolicyLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.hasExtra("from")) {
            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    showNextScreen();
                }
            }
        }

    }

    private void apiCall() {
        new Thread(() -> {
            JSONParser jsonParser = new JSONParser();
            JSONObject json = jsonParser.makeHttpRequest(
                    "https://bigzbet.com/gallery/gallery.php?pkg=com.photo.gallery.lockgallery.albums",
                    "GET");
            try {
                if (json.getInt("status") == 1) {
                    preferencesManager.saveAdIds(json);
                }
            } catch (Exception ignored) {

            } finally {
                runOnUiThread(() -> callNext());
            }
        }).start();
    }


    public boolean isInternetAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    private void setActivityResultLauncher() {
        lockActivityResultLauncher =
                registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                        result -> {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                initAds();
                            } else {
                                finish();
                            }
                        });
    }

    ActivityResultLauncher<Intent> permissionActivityResultLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (SDK_INT >= Build.VERSION_CODES.R) {
                            if (Environment.isExternalStorageManager()) {
                                showNextScreen();
                            } else {
                                Toast.makeText(SplashActivity.this,
                                        getString(R.string.permission_toast_msg),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

    private boolean permissionCallLog(int code) {
        if (ContextCompat.checkSelfPermission(this, READ_PHONE_STATE) == 0) {
            return true;
        }
        ActivityCompat.requestPermissions(this, new String[]{READ_PHONE_STATE}, code);
        return false;
    }

    private void requestPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R /*&& preferencesManager.getStoragePermission11()*/) {
            ManageExternalPermissionManager overlayPermissionManager = new ManageExternalPermissionManager(this);
            overlayPermissionManager.requestOverlay(permissionActivityResultLauncher);
            /*try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(Uri.parse(
                        String.format("package:%s", getApplicationContext().getPackageName())));
                permissionActivityResultLauncher.launch(intent);
            } catch (Exception e) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                permissionActivityResultLauncher.launch(intent);
            }*/
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.MANAGE_EXTERNAL_STORAGE}, 100);
        } else {
            ActivityCompat.requestPermissions(SplashActivity.this,
                    new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.ACCESS_MEDIA_LOCATION, Manifest.permission.CAMERA},
                    100);
        }
    }

    private boolean isDrawOverlayPermission(boolean isNeedToOpenSetting) {
        OverlayPermissionManager overlayPermissionManager = new OverlayPermissionManager(this);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        if (isNeedToOpenSetting) {
            if (!overlayPermissionManager.isGranted()) {
                overlayPermissionManager.requestOverlay(resultIntentForOverlay);
                return false;
            } else {
                return true;
            }
        } else {
            return overlayPermissionManager.isGranted();
        }
    }

    private ActivityResultLauncher<Intent> resultIntentForOverlay =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> checkOverlayPermission(false));

    private void showNextScreen() {
        if (permissionCallLog(PERMISSION_CALL_LOG_CODE)) {
            checkOverlayPermission(true);
        }
    }

    private void initAds() {
        AdmobAdManager admobAdManager = AdmobAdManager.getInstance(this);
        admobAdManager.loadInterstitialAd(this);
        admobAdManager.loadInterstitialBackAd(this);
        if (preferencesManager.getSplashAdEnable()) {
            if (preferencesManager.getSplashAdType().equals("openapp")) {
                appOpenManager.loadAppOpenAd(() -> {
                    if (appOpenManager.isAdAvailable()) {
                        appOpenManager.showAdIfAvailable(() -> {
                            startHomeScreen();
                        });
                    } else {
                        startHomeScreen();
                    }
                });
            } else {
                admobAdManager.loadInterstitialSplashAd(this, () -> startHomeScreen());
            }
        } else {
            startHomeScreen();
        }
    }

    private void startHomeScreen() {
        int theme = preferencesManager.getTheme();
        if (theme == 0) {
            startActivity(new Intent(this, HomeActivity.class).putExtra("isOpenToSplash", true));
        } else if (theme == 1) {
            startActivity(
                    new Intent(this, HomeFlatActivity.class).putExtra("isOpenToSplash", true));
        } else if (theme == 2) {
            startActivity(
                    new Intent(this, HomeClassicActivity.class).putExtra("isOpenToSplash", true));
        }
        Variables.isSplashScreen = false;
        finish();
    }

    private boolean checkPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R /*&& preferencesManager.getStoragePermission11()*/) {
            return Environment.isExternalStorageManager();
        } else {
            int result =
                    ContextCompat.checkSelfPermission(SplashActivity.this, READ_EXTERNAL_STORAGE);
            int result1 =
                    ContextCompat.checkSelfPermission(SplashActivity.this, WRITE_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (checkPermission()) {
                showNextScreen();
            } else {
                Toast.makeText(this, getString(R.string.permission_toast_msg),
                        Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == PERMISSION_CALL_LOG_CODE) {
            if (checkPermission(SplashActivity.this, READ_PHONE_STATE)) {
                checkOverlayPermission(true);
            } else {
                Toast.makeText(this, getString(R.string.permission_call_log),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void checkOverlayPermission(boolean isNeedToOpenSetting) {
        if (isDrawOverlayPermission(isNeedToOpenSetting)) {
            if (preferencesManager.getSetLockApp()) {
                lockActivityResultLauncher.launch(new Intent(SplashActivity.this, PasswordActivity.class).putExtra(
                        "isOpenPrivate", false).putExtra("isSplash", true));
            } else {
                initAds();
            }
        }
    }

    public boolean checkPermission(Activity activity, String permissionName) {
        return PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(activity,
                permissionName);
    }

    private PurchasesUpdatedListener purchasesUpdatedListener = (billingResult, purchases) -> {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
        } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
        } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
        } else {
        }
    };


}