package com.picturephoto.gallery.app.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.adapter.FavoriteAdapter;
import com.picturephoto.gallery.app.ads.AdEventListener;
import com.picturephoto.gallery.app.ads.AdmobAdManager;
import com.picturephoto.gallery.app.databinding.ActivityFavoriteListBinding;
import com.picturephoto.gallery.app.model.AlbumData;
import com.picturephoto.gallery.app.model.PictureData;
import com.picturephoto.gallery.app.preferences.PreferencesManager;
import com.picturephoto.gallery.app.utils.Constant;

import java.io.File;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class RecentFilesActivity extends AppCompatActivity {

    ActivityFavoriteListBinding binding;
    PreferencesManager preferencesManager;
    ArrayList<Object> photoList = new ArrayList<>();
    private FavoriteAdapter favoriteAdapter;
    boolean isSelectAll = false;
    SimpleDateFormat format;
    private AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFavoriteListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        admobAdManager = AdmobAdManager.getInstance(this);
        loadNativeBanner();
        intView();
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void intView() {
        preferencesManager = PreferencesManager.getInstance(this);
        AlbumData albumData = Constant.recentData;
        Constant.recentData = null;
        photoList.addAll(albumData.getPictureData());
        initListener();
        setAdapter();
        setEmptyData();

        format = new SimpleDateFormat("EEEE, MMM dd yyyy");
        Calendar calendar = Calendar.getInstance();
        String today = format.format(calendar.getTimeInMillis());
        calendar.add(Calendar.DATE, -1);
        String yesterday = format.format(calendar.getTimeInMillis());

        String strDate = albumData.getTitle();
        if (albumData.getTitle().equals(today))
            strDate = getString(R.string.Today);
        else if (albumData.getTitle().equals(yesterday))
            strDate = getString(R.string.Yesterday);

        binding.txtTitle.setText(strDate);

        binding.ivFav.setVisibility(View.GONE);
        binding.ivMenu.setVisibility(View.GONE);
    }


    private void setAdapter() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3, LinearLayoutManager.VERTICAL, false);
        binding.favRecycler.setLayoutManager(gridLayoutManager);
        favoriteAdapter = new FavoriteAdapter(this, photoList, preferencesManager.getLabelShow(), new FavoriteAdapter.OnSelectPicture() {
            @Override
            public void onSelectPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    if (imageList.isCheckboxVisible()) {
                        imageList.setSelected(!imageList.isSelected());
                        favoriteAdapter.notifyItemChanged(pos);
                        setSelectedFile();
                    } else {
                        int temp_pos = -1;
                        ArrayList<PictureData> dataList = new ArrayList<>();
                        for (int i = 0; i < photoList.size(); i++) {
                            if (photoList.get(i) instanceof PictureData) {
                                dataList.add((PictureData) photoList.get(i));
                                if (pos == i) {
                                    temp_pos = dataList.size() - 1;
                                }
                            }
                        }
                        Constant.displayImageList = new ArrayList<>();
                        Constant.displayImageList.addAll(dataList);
                        Intent intent = new Intent(RecentFilesActivity.this, ImageShowActivity.class);
                        intent.putExtra("pos", temp_pos);
                        intent.putExtra("IsPrivateList", false);
                        intent.putExtra("IsFavList", true);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onLongClickPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) photoList.get(i);
                                model.setCheckboxVisible(true);
                            }
                    }
                    imageList.setCheckboxVisible(true);
                    imageList.setSelected(true);
                    favoriteAdapter.notifyDataSetChanged();
                    setSelectedFile();
                }
            }
        });
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(final int position) {
                if (favoriteAdapter.getItemViewType(position) == FavoriteAdapter.ITEM_HEADER_TYPE) {
                    return 3;
                }
                return 1;
            }
        });
        binding.favRecycler.setAdapter(favoriteAdapter);
        if (photoList != null && photoList.size() != 0) {
            binding.favRecycler.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.favRecycler.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void initListener() {
        binding.ivBack.setOnClickListener(v -> onBackPressed());
        binding.ivClose.setOnClickListener(v -> {
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        model.setCheckboxVisible(false);
                        model.setSelected(false);
                    }
            }
            if (favoriteAdapter != null) {
                favoriteAdapter.notifyDataSetChanged();
            }
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
        });
        binding.ivShare.setOnClickListener(v -> {
            ArrayList<Uri> uris = new ArrayList<>();
            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.isSelected()) {
                            Uri uri = FileProvider.getUriForFile(RecentFilesActivity.this, getPackageName() + ".provider", new File(model.getFilePath()));
                            uris.add(uri);
                        }
                    }
            }
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(Intent.createChooser(intent, getString(R.string.share_with)), 909);
//            startActivity(Intent.createChooser(intent, getString(R.string.share_with)));
        });


        binding.ivMenuSelect.setOnClickListener(view -> {
            showMenu(view);
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 909) {
            setClose();
        }
    }

    private void showMenu(View view) {
        PopupMenu popup = new PopupMenu(RecentFilesActivity.this, view);
        popup.getMenuInflater().inflate(R.menu.menu_select_option, popup.getMenu());
        popup.getMenu().findItem(R.id.nav_move_private).setVisible(false);
        popup.getMenu().findItem(R.id.nav_copy).setVisible(false);
        popup.getMenu().findItem(R.id.nav_move).setVisible(false);
        if (binding.selectToolbar.getVisibility() == View.VISIBLE) {
            if (isSelectAll)
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.DeselectAll));
            else
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.SelectAll));
        }

        popup.show();

        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.nav_select) {
                if (binding.selectToolbar.getVisibility() == View.VISIBLE) {
                    if (isSelectAll)
                        isSelectAll = false;
                    else
                        isSelectAll = true;
                    setAllSelection();
                }
            }
            return true;
        });
    }


    private void setAllSelection() {
        if (isSelectAll) {
            int selected = 0;
            long size = 0;
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        selected++;
                        size += model.getFileSize();
                        model.setSelected(true);
                    }
            }
            showSelectCount(selected, size);
            if (favoriteAdapter != null)
                favoriteAdapter.notifyDataSetChanged();
            setEmptyData();
        } else {
            setClose();
            showSelectCount(0, 0);
        }
    }

    private void setSelectedFile() {
        int selected = 0;
        long size = 0;
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                        size += model.getFileSize();
                    }
                }
        }
        if (selected == 0) {
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
            setClose();
        } else {
            binding.toolbar.setVisibility(View.GONE);
            binding.selectToolbar.setVisibility(View.VISIBLE);
        }
        showSelectCount(selected, size);

        if (selected == 0)
            isSelectAll = false;
    }

    private void showSelectCount(int selected, long size) {
        binding.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
    }

    @Override
    public void onBackPressed() {
        if (binding.selectToolbar.getVisibility() == View.VISIBLE) {
            setClose();
        } else {

            admobAdManager.loadInterstitialBackAd(this, 2, () ->  finish());
        }
    }


    private void setClose() {
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);
                }
        }
        if (favoriteAdapter != null) {
            favoriteAdapter.notifyDataSetChanged();
        }
        binding.toolbar.setVisibility(View.VISIBLE);
        binding.selectToolbar.setVisibility(View.GONE);
    }

    private void setEmptyData() {
        if (photoList != null && photoList.size() != 0) {
            binding.favRecycler.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.favRecycler.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    public boolean isImageFile(String path) {
        String mimeType = URLConnection.guessContentTypeFromName(path);
        return mimeType != null && mimeType.startsWith("image");
    }
}