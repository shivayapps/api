package com.picturephoto.gallery.app.utils;

import androidx.multidex.MultiDexApplication;

import com.calldorado.Calldorado;


public class Application extends MultiDexApplication {
	
	public static android.app.Application myApplication;
	
	@Override
	public void onCreate() {
		super.onCreate();
		myApplication = this;
		Calldorado.start(this);
		
	}
	
}
