package com.picturephoto.gallery.app.model;

public class FilterSettingUpdate {
    boolean isPhotos = false;

    public FilterSettingUpdate(boolean isPhotos) {
        this.isPhotos = isPhotos;
    }

    public boolean isPhotos() {
        return isPhotos;
    }
}
