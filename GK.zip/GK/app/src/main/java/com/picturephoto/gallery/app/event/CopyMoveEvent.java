package com.picturephoto.gallery.app.event;

import java.util.ArrayList;

public class CopyMoveEvent {
    //move & copy file list
    ArrayList<String> copyMoveList = new ArrayList<>();

    // delete file list
    ArrayList<String> deleteList = new ArrayList<>();
    String albumName,albumPath;
    public CopyMoveEvent(ArrayList<String> copyMoveList, String albumName, String albumPath, ArrayList<String>  deleteList) {
        this.deleteList = deleteList;
        this.albumName = albumName;
        this.albumPath = albumPath;
        this.copyMoveList = copyMoveList;
    }

    public ArrayList<String> getCopyMoveList() {
        return copyMoveList;
    }

    public void setCopyMoveList(ArrayList<String> copyMoveList) {
        this.copyMoveList = copyMoveList;
    }

    public ArrayList<String> getDeleteList() {
        return deleteList;
    }

    public void setDeleteList(ArrayList<String> deleteList) {
        this.deleteList = deleteList;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumPath() {
        return albumPath;
    }

    public void setAlbumPath(String albumPath) {
        this.albumPath = albumPath;
    }
}
