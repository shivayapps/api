package com.picturephoto.gallery.app.interfaces;

public interface SelectPathListener {
    void selectPath(String path);
}