package com.picturephoto.gallery.app.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.imageview.ShapeableImageView;
import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.model.AlbumData;

import java.util.ArrayList;

public class SelectAlbumAdapter extends RecyclerView.Adapter<SelectAlbumAdapter.ViewHolder> {

    Context activity;
    ArrayList<AlbumData> albums;
    OnSelectAlbum onSelectAlbum;

    public SelectAlbumAdapter(Context activity, ArrayList<AlbumData> albums, OnSelectAlbum onSelectAlbum) {
        this.activity = activity;
        this.onSelectAlbum = onSelectAlbum;
        this.albums = albums;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_album, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            if (albums.get(position).getPictureData() != null && albums.get(position).getPictureData().size() != 0)
                Glide.with(activity).load(albums.get(position).getPictureData().get(0).getFilePath())
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true).into(holder.albumImage);

            holder.albumCount.setText(albums.get(position).getPictureData().size() + " " + activity.getString(R.string.items));
            holder.albumName.setText(albums.get(position).getTitle());
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onSelectAlbum.onClickAlbum(position);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return albums.size();
    }

    public void addData(ArrayList<AlbumData> albums) {
        this.albums = albums;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView albumName;
        TextView albumCount;
        ImageView iv_menu;
        ShapeableImageView albumImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            albumImage = itemView.findViewById(R.id.albumImage);
            albumName = itemView.findViewById(R.id.albumName);
            albumCount = itemView.findViewById(R.id.albumCount);
            iv_menu = itemView.findViewById(R.id.iv_menu);
//            DisplayMetrics displayMetrics = new DisplayMetrics();
//            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

//            float radius = activity.getResources().getDimension(R.dimen._6sdp);
//            ShapeAppearanceModel shapeAppearanceModel = albumImage.getShapeAppearanceModel().toBuilder()
//                    .setAllCornerSizes(radius)
//                    .build();
//            albumImage.setShapeAppearanceModel(shapeAppearanceModel);
        }
    }

    public interface OnSelectAlbum {
        void onClickAlbum(int pos);
    }
}
