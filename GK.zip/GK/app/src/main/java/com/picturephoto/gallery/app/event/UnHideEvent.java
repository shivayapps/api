package com.picturephoto.gallery.app.event;

public class UnHideEvent {
    //move & copy file list
    String copyMoveList ;

    // delete file list
    String albumName,albumPath;
    public UnHideEvent(String copyMoveList, String albumName, String albumPath) {
        this.albumName = albumName;
        this.albumPath = albumPath;
        this.copyMoveList = copyMoveList;
    }

    public String getCopyMoveList() {
        return copyMoveList;
    }

    public void setCopyMoveList(String copyMoveList) {
        this.copyMoveList = copyMoveList;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumPath() {
        return albumPath;
    }

    public void setAlbumPath(String albumPath) {
        this.albumPath = albumPath;
    }
}
