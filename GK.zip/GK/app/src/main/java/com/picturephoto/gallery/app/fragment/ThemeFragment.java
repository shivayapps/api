package com.picturephoto.gallery.app.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.picturephoto.gallery.app.R;
import com.picturephoto.gallery.app.databinding.FragmentThemeBinding;

public class ThemeFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    FragmentThemeBinding binding;
    int position = 0;

    public ThemeFragment() {

    }

    public static ThemeFragment newInstance(int param1) {
        ThemeFragment fragment = new ThemeFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            position = getArguments().getInt(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentThemeBinding.inflate(inflater, container, false);
        intView();
        return binding.getRoot();
    }

    private void intView() {
//        if (position == 0) {
//            binding.txtTitle.setText(getString(R.string.Material));
//            binding.image.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ss_material));
//        } else if (position == 1) {
//            binding.txtTitle.setText(getString(R.string.Flat));
//            binding.image.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ss_flat));
//        } else if (position == 2) {
//            binding.txtTitle.setText(getString(R.string.Classic));
//            binding.image.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ss_classic));
//        }
    }
}