package com.photo.video.vault.gallery.activity;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.adapter.ThemeViewpagerAdapter;
import com.photo.video.vault.gallery.ads.AdEventListener;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.databinding.ActivitySettingsBinding;
import com.photo.video.vault.gallery.databinding.DialogThemeBinding;
import com.photo.video.vault.gallery.event.SettingEvent;
import com.photo.video.vault.gallery.fragment.ThemeFragment;
import com.photo.video.vault.gallery.model.ThemeModel;
import com.photo.video.vault.gallery.preferences.PreferencesManager;
import com.photo.video.vault.gallery.rx.RxBus;
import com.warkiz.widget.IndicatorSeekBar;

import java.util.ArrayList;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class SettingsActivity extends AppCompatActivity {

    ActivitySettingsBinding binding;
    PreferencesManager preferencesManager;
    ActivityResultLauncher<Intent> lockPrivacyActivityResultLauncher;
    ArrayList<ThemeModel> themeList = new ArrayList<>();
    AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();
        settingEvent();
    }

    private void settingEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(SettingEvent.class).subscribeOn(Schedulers.io()).
                observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<SettingEvent>() {
                    @Override
                    public void call(SettingEvent event) {
                        if (event.getType() == 4) {
//                            recreate();
                            setResult(RESULT_OK);
                            setScreenString();

                        }
                    }
                }, throwable -> {
                });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void setScreenString() {
        binding.txtTitle.setText(getString(R.string.Settings));
        binding.txtOpTitle1.setText(getString(R.string.General));
        binding.txtOpTitle2.setText(getString(R.string.Advance));
        binding.txtOpTitle3.setText(getString(R.string.Extra));

        binding.txtOp1.setText(getString(R.string.Theme));
        binding.txtSub1.setText(getString(R.string.Customizable_gallery_theme));
        binding.txtOp2.setText(getString(R.string.Security));
        binding.txtSub2.setText(getString(R.string.Protect_your_media_with_password));
        binding.txtOp3.setText(getString(R.string.MediaGrid));
        binding.txtSub3.setText(getString(R.string.Choose_number_of_columns_to_show_media));
        binding.txtOp4.setText(getString(R.string.Language));
        binding.txtSub4.setText(getString(R.string.Change_app_language));
        binding.txtOp5.setText(getString(R.string.ExcludeFolders));
        binding.txtSub5.setText(getString(R.string.Manage_exclude_folder_albums));
        binding.txtOp6.setText(getString(R.string.StartPage));
        binding.txtSub6.setText(getString(R.string.Choose_the_start_page_to_be_displayed_on_launch));
        binding.txtOp7.setText(getString(R.string.FastScroller));
        binding.txtSub7.setText(getString(R.string.Display_scroll_icon_on_right_side));
        binding.txtOp8.setText(getString(R.string.ExitDialog));
        binding.txtSub8.setText(getString(R.string.Would_show_exit_dialog_on_app_exit));

    }

    ActivityResultLauncher<Intent> languageActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    setResult(RESULT_OK);
                }
            });

    private void intView() {
        admobAdManager = AdmobAdManager.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);

        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 1, () -> {
        });
        binding.exitdialogSwitch.setChecked(preferencesManager.getExitDialogShow());
        binding.fastScrollSwitch.setChecked(preferencesManager.getFastScroll());
        setClickListener();
        setActivityResultLauncher();
        loadNativeBanner();

        themeList.add(new ThemeModel(getString(R.string.Material), R.drawable.ss_material));
        themeList.add(new ThemeModel(getString(R.string.Flat), R.drawable.ss_flat));
        themeList.add(new ThemeModel(getString(R.string.Classic), R.drawable.ss_classic));
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, preferencesManager.getNativeId(), binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
            finish();
        });
    }

    private void setClickListener() {
        binding.ivBack.setOnClickListener(view -> onBackPressed());
        binding.btnSecurity.setOnClickListener(view -> {
            if (preferencesManager.getSetPass()) {
                admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
                    lockPrivacyActivityResultLauncher.launch(new Intent(SettingsActivity.this, PasswordActivity.class));
                });
            } else {
                admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 1, () -> {
                    startActivity(new Intent(SettingsActivity.this, LockSettingActivity.class).putExtra("IsFromSetting", true));
                });
            }
        });

        binding.btnStartPage.setOnClickListener(view -> {
            showStartPage();
        });

        binding.btnMediaGrid.setOnClickListener(view -> {
            showMediaGridPage();
        });

        binding.btnLanguage.setOnClickListener(view -> {
            languageActivityResultLauncher.launch(new Intent(this, LanguageActivity.class));
        });

        binding.exitdialogSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            preferencesManager.putExitDialogShow(isChecked);
        });

        binding.fastScrollSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            preferencesManager.putFastScroll(isChecked);
            RxBus.getInstance().post(new SettingEvent(3));
        });

        binding.btnExcludeFolders.setOnClickListener(view -> {
            startActivity(new Intent(this, ExcludeFolderActivity.class));
        });

        binding.btnTheme.setOnClickListener(view -> {
//            ThemeDialog themeDialog = new ThemeDialog(this,getSupportFragmentManager(),path -> {
//                setResult(RESULT_OK);
//            });
//            themeDialog.show();
            showThemeDialog();
        });
    }

    private void showThemeDialog() {
        DialogThemeBinding themeBinding;
        themeBinding = DialogThemeBinding.inflate(getLayoutInflater());
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(themeBinding.getRoot());
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        ArrayList<ThemeFragment> fragmentList = new ArrayList<>();
        fragmentList.add(ThemeFragment.newInstance(0));
        fragmentList.add(ThemeFragment.newInstance(1));
        fragmentList.add(ThemeFragment.newInstance(2));

        ThemeViewpagerAdapter adapter = new ThemeViewpagerAdapter(SettingsActivity.this, themeList);
        themeBinding.viewpager.setAdapter(adapter);
        themeBinding.viewpager.setCurrentItem(preferencesManager.getTheme());

        themeBinding.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (position == 0) {
                    themeBinding.icArrowLeft.setVisibility(View.GONE);
                    themeBinding.icArrowRight.setVisibility(View.VISIBLE);

                } else if (position == fragmentList.size() - 1) {
                    themeBinding.icArrowLeft.setVisibility(View.VISIBLE);
                    themeBinding.icArrowRight.setVisibility(View.GONE);
                } else {
                    themeBinding.icArrowLeft.setVisibility(View.VISIBLE);
                    themeBinding.icArrowRight.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        themeBinding.icArrowRight.setOnClickListener(view -> {
            int c = themeBinding.viewpager.getCurrentItem();
            if (c < fragmentList.size() - 1) {
                c++;
                themeBinding.viewpager.setCurrentItem(c);
            }
        });

        themeBinding.icArrowLeft.setOnClickListener(view -> {
            int c = themeBinding.viewpager.getCurrentItem();
            if (c != 0) {
                c--;
                themeBinding.viewpager.setCurrentItem(c);
            }
        });

        themeBinding.btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        themeBinding.btnSet.setOnClickListener(view -> {
            int p = preferencesManager.getTheme();
            if (p != themeBinding.viewpager.getCurrentItem()) {
                preferencesManager.setTheme(themeBinding.viewpager.getCurrentItem());
                setResult(RESULT_OK);
            }
            Toast.makeText(this, getString(R.string.Theme) + " "
                    + themeList.get(themeBinding.viewpager.getCurrentItem()).getName()
                    + " " + getString(R.string.selected), Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        dialog.show();
    }

    int pageStart = 0;

    private void showStartPage() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_start_page);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView btn_apply = dialog.findViewById(R.id.btn_apply);

        RadioGroup grp_type = dialog.findViewById(R.id.grp_type);
        RadioButton radio_photo = dialog.findViewById(R.id.radio_photo);
        RadioButton radio_album = dialog.findViewById(R.id.radio_album);
        pageStart = preferencesManager.getStartPage();

        if (pageStart == 0)
            radio_photo.setChecked(true);
        else if (pageStart == 1)
            radio_album.setChecked(true);

        grp_type.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.radio_photo)
                pageStart = 0;
            else if (i == R.id.radio_album)
                pageStart = 1;
        });

        btn_apply.setOnClickListener(view -> {
            preferencesManager.setStartPage(pageStart);
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showMediaGridPage() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_media_grid);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView btn_apply = dialog.findViewById(R.id.btn_set);
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);

        IndicatorSeekBar material_media_seekbar = dialog.findViewById(R.id.material_media_seekbar);
        IndicatorSeekBar material_album_seekbar = dialog.findViewById(R.id.material_album_seekbar);

        material_media_seekbar.setProgress(preferencesManager.getGridPhoto());
        material_album_seekbar.setProgress(preferencesManager.getGridAlbum());

        btn_apply.setOnClickListener(view -> {
            Log.e("BubbleSeekBar", "media== >> " + material_media_seekbar.getProgress() + " album== >> " + material_album_seekbar.getProgress());
//            preferencesManager.setStartPage(pageStart);
            preferencesManager.setGridPhoto(material_media_seekbar.getProgress());
            preferencesManager.setGridAlbum(material_album_seekbar.getProgress());
            dialog.dismiss();
            RxBus.getInstance().post(new SettingEvent(1));
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    private void setActivityResultLauncher() {
        lockPrivacyActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        startActivity(new Intent(SettingsActivity.this, LockSettingActivity.class).putExtra("IsFromSetting", true));
                    }
                });

    }

    private class ThemePagerAdapter extends FragmentPagerAdapter {
        ArrayList<ThemeModel> themeList = new ArrayList<>();
        ArrayList<ThemeFragment> fragmentList = new ArrayList<>();

        public ThemePagerAdapter(@NonNull FragmentManager fm, ArrayList<ThemeModel> themeList, ArrayList<ThemeFragment> fragmentList) {
            super(fm);
            this.themeList = themeList;
            this.fragmentList = fragmentList;
        }


        @NonNull
        @Override
        public Fragment getItem(int position) {
//            return ThemeFragment.newInstance(position);
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return themeList.size();
        }

//        @Override
//        public float getPageWidth(int position) {
//            DisplayMetrics metrics = context.getResources().getDisplayMetrics();
//            if ((metrics.widthPixels / metrics.density) > 900) {
//                return (0.5f);
//            }
//            return super.getPageWidth(position);
//        }
    }
}