package com.photo.video.vault.gallery.event;

public class SettingEvent {

    // 1- gridCount ,2 ExcludeFolder
    int type;
    boolean isAlbum = false;

    public SettingEvent(int type) {
        this.type = type;
    }
    public SettingEvent(int type,boolean isAlbum) {
        this.type = type;
        this.isAlbum = isAlbum;
    }

    public int getType() {
        return type;
    }

    public boolean isAlbum() {
        return isAlbum;
    }
}
