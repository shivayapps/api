package com.photo.video.vault.gallery.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.model.Storage;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class ChooseFolderAdapter extends RecyclerView.Adapter<ChooseFolderAdapter.ViewHolder> {

    Context activity;
    ArrayList<Storage> folderList;
    OnSelectAlbum onSelectAlbum;
    SimpleDateFormat format;

    public ChooseFolderAdapter(Context activity, ArrayList<Storage> albums, OnSelectAlbum onSelectAlbum) {
        this.activity = activity;
        this.onSelectAlbum = onSelectAlbum;
        this.folderList = albums;
        format = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ENGLISH);
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_storage, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        if (folderList.get(position).isBack()) {
            holder.txt_folder_name.setText("..");
            holder.txt_folder_path.setVisibility(View.GONE);
        } else {
            File file = new File(folderList.get(position).getFilePath());
            holder.txt_folder_name.setText(file.getName());
            String strDate = format.format(file.lastModified());
            holder.txt_folder_path.setText(strDate);
            holder.txt_folder_path.setVisibility(View.VISIBLE);
        }
        holder.lout_row.setOnClickListener(view -> onSelectAlbum.onClickAlbum(position));
    }

    @Override
    public int getItemCount() {
        return folderList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_folder_name;
        TextView txt_folder_path;
        LinearLayout lout_row;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_folder_name = itemView.findViewById(R.id.txt_folder_name);
            txt_folder_path = itemView.findViewById(R.id.txt_folder_path);
            lout_row = itemView.findViewById(R.id.lout_row);
        }
    }

    public interface OnSelectAlbum {
        void onClickAlbum(int pos);
    }
}
