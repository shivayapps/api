package com.photo.video.vault.gallery.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.snackbar.Snackbar;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.adapter.ExcludeFolderAdapter;
import com.photo.video.vault.gallery.ads.AdEventListener;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.databinding.ActivityExcludeFolderBinding;
import com.photo.video.vault.gallery.event.SettingEvent;
import com.photo.video.vault.gallery.preferences.PreferencesManager;
import com.photo.video.vault.gallery.rx.RxBus;

import java.util.ArrayList;

public class ExcludeFolderActivity extends AppCompatActivity {

    ActivityExcludeFolderBinding binding;
    PreferencesManager preferencesManager;
    ArrayList<String> folderList = new ArrayList<>();
    ExcludeFolderAdapter adapter;
    AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityExcludeFolderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        intView();
    }

    private void intView() {
        admobAdManager =AdmobAdManager.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        folderList.addAll(preferencesManager.getExcludeFolderList());
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {});
        intAdapter();
        setEmptyData();
        loadNativeBanner();

        binding.ivBack.setOnClickListener(view ->
                onBackPressed());
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
            finish();
        });
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, preferencesManager.getNativeId(), binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void intAdapter() {

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ExcludeFolderAdapter(this, folderList, pos -> {
//            ArrayList<String> backupList = new ArrayList<>();
//            backupList.addAll(folderList);
//
//            folderList.re
            String path = folderList.get(pos);
            folderList.remove(pos);
            adapter.notifyDataSetChanged();
            preferencesManager.setExcludeFolderList(folderList);
            setEmptyData();
            RxBus.getInstance().post(new SettingEvent(2));
            Snackbar snackbar = Snackbar
                    .make(binding.loutMain, getString(R.string.exclude_folder_remove_msg), Snackbar.LENGTH_LONG)
                    .setAction("UNDO", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            folderList.add(pos, path);
                            adapter.notifyDataSetChanged();
                            setEmptyData();
                            Snackbar snackbar1 = Snackbar.make(binding.loutMain, getString(R.string.exclude_folder_restore_msg), Snackbar.LENGTH_SHORT);
                            snackbar1.show();
                            preferencesManager.setExcludeFolderList(folderList);
                            RxBus.getInstance().post(new SettingEvent(2));
                        }
                    });

            snackbar.show();
        });
        binding.recyclerView.setAdapter(adapter);
    }

    private void setEmptyData() {
        if (folderList != null && folderList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }
}