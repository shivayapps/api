package com.photo.video.vault.gallery.model;

import java.io.File;

public class RenameModel {
    File oldFile  , renameFile;

    public RenameModel(File oldFile, File renameFile) {
        this.oldFile = oldFile;
        this.renameFile = renameFile;
    }

    public File getOldFile() {
        return oldFile;
    }

    public void setOldFile(File oldFile) {
        this.oldFile = oldFile;
    }

    public File getRenameFile() {
        return renameFile;
    }

    public void setRenameFile(File renameFile) {
        this.renameFile = renameFile;
    }

}
