package com.photo.video.vault.gallery.ads;

public interface AdEventListener {
    void onAdLoaded();
    void onAdClosed();
    void onLoadError(String errorCode);
    void onAdLoaded(Object object);
}
