package com.photo.video.vault.gallery.activity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.adapter.FavoriteAdapter;
import com.photo.video.vault.gallery.ads.AdEventListener;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.databinding.ActivityMediaColorBinding;
import com.photo.video.vault.gallery.event.DisplayDeleteEvent;
import com.photo.video.vault.gallery.event.EditImageEvent;
import com.photo.video.vault.gallery.model.AlbumData;
import com.photo.video.vault.gallery.model.PictureData;
import com.photo.video.vault.gallery.model.RenameEvent;
import com.photo.video.vault.gallery.model.RenameModel;
import com.photo.video.vault.gallery.preferences.PreferencesManager;
import com.photo.video.vault.gallery.rx.RxBus;
import com.photo.video.vault.gallery.utils.Constant;
import com.photo.video.vault.gallery.utils.ImageColor;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Set;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class MediaColorActivity extends AppCompatActivity {

    ActivityMediaColorBinding binding;
    ArrayList<Object> photoList = new ArrayList<>();
    ArrayList<Object> photoMainList = new ArrayList<>();
    private FavoriteAdapter favoriteAdapter;
    PreferencesManager preferencesManager;
    boolean isSelectAll = false;
    int chooseColor = 0;
    AdmobAdManager admobAdManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMediaColorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        intView();
        DisplayDeleteEvent();
        editEvent();
        renameEvent();
    }

    private void intView() {
        admobAdManager = AdmobAdManager.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        binding.swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_orange_light,
                android.R.color.holo_green_light);
        chooseColor = ContextCompat.getColor(this, R.color.white);
        binding.swipeRefreshLayout.setRefreshing(true);
        new Thread(this::getImages).start();
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {});
        initListener();
        loadNativeBanner();

    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
            finish();
        });
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, preferencesManager.getNativeId(), binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void initListener() {
        binding.ivBack.setOnClickListener(v -> onBackPressed());
        binding.ivClose.setOnClickListener(v -> {
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        model.setCheckboxVisible(false);
                        model.setSelected(false);
                    }
            }
            if (favoriteAdapter != null) {
                favoriteAdapter.notifyDataSetChanged();
            }
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
        });

        binding.ivColor.setOnClickListener(view -> {
            openColorPickerDialog();
        });

        binding.ivShare.setOnClickListener(v -> {
            ArrayList<Uri> uris = new ArrayList<>();
            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.isSelected()) {
                            Uri uri = FileProvider.getUriForFile(MediaColorActivity.this, getPackageName() + ".provider", new File(model.getFilePath()));
                            uris.add(uri);
                        }
                    }
            }
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(Intent.createChooser(intent, getString(R.string.share_with)), 909); });
//        binding.ivFav.setOnClickListener(v -> {
//            setUnFav();
//        });
//
//        binding.ivMenuSelect.setOnClickListener(view -> {
//            showMenu(view);
//        });
//
//        binding.ivMenu.setOnClickListener(view -> {
//            showMenu(view);
//        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 909) {
            setClose();
        }
    }

    public void setRefreshData(boolean isEnable) {
        if (isEnable)
            binding.swipeRefreshLayout.setEnabled(true);
        else
            binding.swipeRefreshLayout.setEnabled(false);
    }

    private void openColorPickerDialog() {
        ColorPickerDialogBuilder
                .with(MediaColorActivity.this)
                .setTitle(getString(R.string.ChooseColor))
                .initialColor(chooseColor)
                .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
                .density(12)
                .setPositiveButton(getString(R.string.action_ok), (dialog, selectedColor, allColors) -> {
                    chooseColor = selectedColor;
                    Log.d("Data", "onClick: ====>" + selectedColor);
                    setFilterColor();

                })
                .setNegativeButton("cancel", (dialog, which) -> {
                })
                .build()
                .show();
    }

    private void setFilterColor() {
        binding.swipeRefreshLayout.setRefreshing(true);
        photoList.clear();
        if (favoriteAdapter != null)
            favoriteAdapter.notifyDataSetChanged();
        AlbumData albumData = null;
        ArrayList<PictureData> list = new ArrayList<>();

        int red = Color.red(chooseColor);
        int green = Color.green(chooseColor);
        int blue = Color.blue(chooseColor);
        int alpha = Color.alpha(chooseColor);

        for (int i = 0; i < photoMainList.size(); i++) {
            if (photoMainList.get(i) != null)
                if (photoMainList.get(i) instanceof AlbumData) {
                    if (albumData != null && list.size() != 0) {
                        photoList.add(albumData);
                        photoList.addAll(list);
                        list.clear();
                    }
                    albumData = (AlbumData) photoMainList.get(i);

                } else if (photoMainList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoMainList.get(i);
                    ArrayList<Integer> colorList = new ArrayList<>(model.getColorList());
                    for (Integer colorCode : colorList) {
                        if (isSimilar(colorCode, red, green, blue, alpha)) {
//                        if (colorCode.contains(selectHexColor)) {
                            list.add(model);
                            break;
                        }
                    }
//                    if (model.getColorList().contains(selectColor))
//                        list.add(model);
                }
        }

        if (albumData != null && list.size() != 0) {
            photoList.add(albumData);
            photoList.addAll(list);
        }

        binding.swipeRefreshLayout.setRefreshing(false);
        if (favoriteAdapter != null)
            favoriteAdapter.notifyDataSetChanged();
        else
            setAdapter();
        if (photoList != null && photoList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private boolean isSimilar(Integer colorCode, int red, int green, int blue, int alpha) {
        int red1 = Color.red(colorCode);
        int green1 = Color.green(colorCode);
        int blue1 = Color.blue(colorCode);
//        int alpha1 = Color.alpha(colorCode);

        int diffRed = Math.abs(red - red1);
        int diffGreen = Math.abs(green - green1);
        int diffBlue = Math.abs(blue - blue1);


        float pctDiffRed = (float) diffRed / 255;
        float pctDiffGreen = (float) diffGreen / 255;
        float pctDiffBlue = (float) diffBlue / 255;

        float pct = (pctDiffRed + pctDiffGreen + pctDiffBlue) / 3 * 100;
//        int pct = (diffRed + diffGreen + diffBlue) / 3 * 100;

        return pct < 15;
    }

    private void DisplayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {
            if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                deleteDataList(event.getDeleteList());
                ImageColor.deleteList.addAll(event.getDeleteList());

            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void editEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(EditImageEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<EditImageEvent>() {
            @Override
            public void call(EditImageEvent event) {
                runOnUiThread(() -> {
                    if (favoriteAdapter != null)
                        favoriteAdapter.notifyDataSetChanged();
                    else
                        setAdapter();
                });
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void renameEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(RenameEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<RenameEvent>() {
            @Override
            public void call(RenameEvent event) {
                ArrayList<RenameModel> renameList = event.getRenameModels();
                if (renameList != null && renameList.size() != 0) {
                    for (RenameModel renameModel : renameList) {
                        if (renameModel.getRenameFile().exists()) {
                            for (int i = 0; i < photoList.size(); i++) {
                                if (photoList.get(i) != null)
                                    if (photoList.get(i) instanceof PictureData) {
                                        PictureData model = (PictureData) photoList.get(i);
                                        if (model.getFilePath().equalsIgnoreCase(renameModel.getOldFile().getPath())) {
                                            model.setFolderPath(renameModel.getRenameFile().getPath());
                                            model.setFileName(renameModel.getRenameFile().getName());
                                            break;
                                        }
                                    }
                            }

                            for (int i = 0; i < photoMainList.size(); i++) {
                                if (photoMainList.get(i) != null)
                                    if (photoMainList.get(i) instanceof PictureData) {
                                        PictureData model = (PictureData) photoMainList.get(i);
                                        if (model.getFilePath().equalsIgnoreCase(renameModel.getOldFile().getPath())) {
                                            model.setFolderPath(renameModel.getRenameFile().getPath());
                                            model.setFileName(renameModel.getRenameFile().getName());
                                            break;
                                        }
                                    }
                            }

                        }
                    }
                    runOnUiThread(() -> {
                        if (favoriteAdapter != null)
                            favoriteAdapter.notifyDataSetChanged();
                        else
                            setAdapter();
                    });
                }
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void deleteDataList(ArrayList<String> deleteList) {
        if (photoList != null && photoList.size() != 0) {
            for (int d = 0; d < deleteList.size(); d++) {
                for (int i = 0; i < photoList.size(); i++) {
                    if (photoList.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) photoList.get(i);
                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {
                            boolean isPre = false, isNext = false;
                            if (i != 0) {
                                isPre = photoList.get(i - 1) instanceof AlbumData;
                            }
                            if (i < (photoList.size() - 2)) {
                                isNext = photoList.get(i + 1) instanceof AlbumData;
                            }
                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                photoList.remove(i);
                                photoList.remove(i - 1);
                            } else if (i == (photoList.size() - 1)) {
                                photoList.remove(i);
                                if (isPre) {
                                    photoList.remove(i - 1);
                                }
                            } else {
                                photoList.remove(i);
                            }
                            if (i != 0) {
                                i--;
                            }
                            if (d == deleteList.size() - 1) {
                                break;
                            }
                        }
                    }
                }
            }
            if (favoriteAdapter != null) {
                favoriteAdapter.notifyDataSetChanged();
            }
            if (photoList != null && photoList.size() != 0) {
                binding.recyclerView.setVisibility(View.VISIBLE);
                binding.loutNoData.setVisibility(View.GONE);
            } else {
                binding.recyclerView.setVisibility(View.GONE);
                binding.loutNoData.setVisibility(View.VISIBLE);
            }
        }
    }

    private void getImages() {
        while (ImageColor.isColorImageGettingRunning) {
            break;
        }

        runOnUiThread(() -> {
            setDataList();
        });
    }

    private void setDataList() {
        ArrayList<PictureData> photoColorList = new ArrayList<>(ImageColor.photoColorList);
        if (ImageColor.deleteList != null && ImageColor.deleteList.size() != 0) {
            for (String deletePath : ImageColor.deleteList) {
                for (PictureData pictureData : photoColorList) {
                    if (pictureData.getFilePath().equals(deletePath)) {
                        photoColorList.remove(pictureData);
                        break;
                    }
                }
            }
        }

        if (ImageColor.copyMoveImageList != null && ImageColor.copyMoveImageList.size() != 0) {
            photoColorList.addAll(ImageColor.copyMoveImageList);
            Collections.sort(photoColorList, (d1, d2) -> {
                return Long.compare(d2.getDate(), d1.getDate());
            });
        }
        LinkedHashMap<String, ArrayList<PictureData>> dateWisePictures = new LinkedHashMap<>();
        SimpleDateFormat format = new SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH);
        Calendar calendar = Calendar.getInstance();
        String today = format.format(calendar.getTimeInMillis());
        calendar.add(Calendar.DATE, -1);
        String yesterday = format.format(calendar.getTimeInMillis());

        for (PictureData pictureData : photoColorList) {

            String strDate = format.format(pictureData.getDate());
            if (strDate.equals(today)) {
                strDate = "Today";
            } else if (strDate.equals(yesterday)) {
                strDate = "Yesterday";
            }

            ArrayList<PictureData> imagesData1;
            if (dateWisePictures.containsKey(strDate)) {
                imagesData1 = dateWisePictures.get(strDate);
                if (imagesData1 == null)
                    imagesData1 = new ArrayList<>();

            } else {
                imagesData1 = new ArrayList<>();
            }
            imagesData1.add(pictureData);
            dateWisePictures.put(strDate, imagesData1);
        }

        Set<String> keys = dateWisePictures.keySet();
        ArrayList<String> listkeys = new ArrayList<>(keys);

        for (int i = 0; i < listkeys.size(); i++) {
            ArrayList<PictureData> imagesData = dateWisePictures.get(listkeys.get(i));
            if (imagesData != null && imagesData.size() != 0) {
                AlbumData bucketData = new AlbumData();
                bucketData.setTitle(listkeys.get(i));
                bucketData.setPictureData(imagesData);
                photoList.add(bucketData);
                photoMainList.add(bucketData);
                photoList.addAll(imagesData);
                photoMainList.addAll(imagesData);
            }
        }

        runOnUiThread(() -> {
            binding.swipeRefreshLayout.setRefreshing(false);
            setAdapter();
            setEmptyData();
        });
    }

    private void setEmptyData() {
        if (photoList != null && photoList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
            binding.ivColor.setVisibility(View.VISIBLE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
            binding.ivColor.setVisibility(View.GONE);
        }
    }

    private void setAdapter() {
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3, LinearLayoutManager.VERTICAL, false);
        binding.recyclerView.setLayoutManager(gridLayoutManager);
        favoriteAdapter = new FavoriteAdapter(this, photoList, preferencesManager.getLabelShow(), new FavoriteAdapter.OnSelectPicture() {
            @Override
            public void onSelectPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) photoList.get(pos);
//                    if (imageList.isCheckboxVisible()) {
//                        imageList.setSelected(!imageList.isSelected());
//                        favoriteAdapter.notifyItemChanged(pos);
//                        setSelectedFile();
//                    } else {
                    int temp_pos = -1;
                    ArrayList<PictureData> dataList = new ArrayList<>();
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) instanceof PictureData) {
                            dataList.add((PictureData) photoList.get(i));
                            if (pos == i) {
                                temp_pos = dataList.size() - 1;
                            }
                        }
                    }
                    Constant.displayImageList = new ArrayList<>();
                    Constant.displayImageList.addAll(dataList);
                    Intent intent = new Intent(MediaColorActivity.this, ImageShowActivity.class);
                    intent.putExtra("pos", temp_pos);
                    intent.putExtra("IsPrivateList", false);
                    intent.putExtra("IsShowSlideShow", false);
                    intent.putExtra("IsFavList", false);
                    startActivity(intent);
//                    }
                }
            }

            @Override
            public void onLongClickPicture(int pos) {
                if (photoList.get(pos) instanceof PictureData) {
//                    PictureData imageList = (PictureData) photoList.get(pos);
//                    for (int i = 0; i < photoList.size(); i++) {
//                        if (photoList.get(i) != null)
//                            if (photoList.get(i) instanceof PictureData) {
//                                PictureData model = (PictureData) photoList.get(i);
//                                model.setCheckboxVisible(true);
//                            }
//                    }
//                    imageList.setCheckboxVisible(true);
//                    imageList.setSelected(true);
//                    favoriteAdapter.notifyDataSetChanged();
//                    setSelectedFile();
                    int temp_pos = -1;
                    ArrayList<PictureData> dataList = new ArrayList<>();
                    for (int i = 0; i < photoList.size(); i++) {
                        if (photoList.get(i) instanceof PictureData) {
                            dataList.add((PictureData) photoList.get(i));
                            if (pos == i) {
                                temp_pos = dataList.size() - 1;
                            }
                        }
                    }
                    Constant.displayImageList = new ArrayList<>();
                    Constant.displayImageList.addAll(dataList);
                    Intent intent = new Intent(MediaColorActivity.this, ImageShowActivity.class);
                    intent.putExtra("pos", temp_pos);
                    intent.putExtra("IsPrivateList", false);
                    intent.putExtra("IsShowSlideShow", false);
                    intent.putExtra("IsFavList", false);
                    startActivity(intent);
                }
            }
        });
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(final int position) {
                if (favoriteAdapter.getItemViewType(position) == FavoriteAdapter.ITEM_HEADER_TYPE) {
                    return 3;
                }
                return 1;
            }
        });
        binding.recyclerView.setAdapter(favoriteAdapter);
        if (photoList != null && photoList.size() != 0) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
            binding.ivColor.setVisibility(View.VISIBLE);
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
            binding.ivColor.setVisibility(View.GONE);
        }
    }

    private void setSelectedFile() {
        int selected = 0;
        long size = 0;
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                        size += model.getFileSize();
                    }
                }
        }
        if (selected == 0) {
            binding.toolbar.setVisibility(View.VISIBLE);
            binding.selectToolbar.setVisibility(View.GONE);
            setClose();
        } else {
            binding.toolbar.setVisibility(View.GONE);
            binding.selectToolbar.setVisibility(View.VISIBLE);
        }
        showSelectCount(selected, size);

        if (selected == 0)
            isSelectAll = false;
    }

    private void setClose() {
        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);
                }
        }
        if (favoriteAdapter != null) {
            favoriteAdapter.notifyDataSetChanged();
        }
        binding.toolbar.setVisibility(View.VISIBLE);
        binding.selectToolbar.setVisibility(View.GONE);
    }

    private void showSelectCount(int selected, long size) {
        binding.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
    }
}