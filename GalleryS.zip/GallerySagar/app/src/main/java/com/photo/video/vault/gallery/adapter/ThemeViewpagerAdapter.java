package com.photo.video.vault.gallery.adapter;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.model.ThemeModel;

import java.util.ArrayList;


public class ThemeViewpagerAdapter extends PagerAdapter {
    Context activity;
    LayoutInflater inflater;
    ArrayList<ThemeModel> themeList;

    public ThemeViewpagerAdapter(Context activity, ArrayList<ThemeModel> themeList) {
        this.activity = activity;
        this.themeList = themeList;
        inflater = LayoutInflater.from(activity);
    }

    @Override
    public int getCount() {
        return themeList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public Object instantiateItem(ViewGroup view, int position) {
        View view1 = inflater.inflate(R.layout.fragment_theme, view, false);
        TextView premium_title = view1.findViewById(R.id.txt_title);
        ImageView image = view1.findViewById(R.id.image);
        premium_title.setText(themeList.get(position).getName());
        image.setImageResource(themeList.get(position).getImage());
        view.addView(view1);
        return view1;
    }

    @Override
    public int getItemPosition(Object object) {
        return PagerAdapter.POSITION_NONE;
    }

    @Override
    public float getPageWidth(int position) {
//        return super.getPageWidth(position);
        DisplayMetrics metrics = activity.getResources().getDisplayMetrics();
        if ((metrics.widthPixels / metrics.density) > 500) {
            return (0.5f);
        }
//        return (0.9f);
        return super.getPageWidth(position);
    }
}
