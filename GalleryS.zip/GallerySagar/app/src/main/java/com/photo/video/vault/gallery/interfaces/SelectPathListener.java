package com.photo.video.vault.gallery.interfaces;

public interface SelectPathListener {
    void selectPath(String path);
}