package com.photo.video.vault.gallery.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;

import com.photo.video.vault.gallery.adapter.LanguageAdapter;
import com.photo.video.vault.gallery.ads.AdEventListener;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.databinding.ActivityLanguageBinding;
import com.photo.video.vault.gallery.event.SettingEvent;
import com.photo.video.vault.gallery.preferences.PreferencesManager;
import com.photo.video.vault.gallery.rx.RxBus;

import java.util.ArrayList;
import java.util.Locale;

public class LanguageActivity extends AppCompatActivity {

    ActivityLanguageBinding binding;
    ArrayList<String> language = new ArrayList<>();
    ArrayList<String> languageCodes = new ArrayList<>();
    LanguageAdapter adapter;
    PreferencesManager preferencesManager;
    int selectedLanguage = 0;
    AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLanguageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();
    }

    private void intView() {
        admobAdManager = AdmobAdManager.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        selectedLanguage = preferencesManager.getLanguage();
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {});
        getLanguageList();
        getLanguageCodeList();
        intAdapter();
        loadNativeBanner();
        binding.ivBack.setOnClickListener(view -> onBackPressed());
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, preferencesManager.getNativeId(), binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
            finish();
        });
    }

    private void intAdapter() {
        adapter = new LanguageAdapter(this, language, selectedLanguage,pos -> {
            int p = selectedLanguage;
            selectedLanguage = pos;
            if (p != -1)
                adapter.notifyItemChanged(p);
            adapter.notifyItemChanged(selectedLanguage);
            preferencesManager.saveLanguage(selectedLanguage);
            Locale locale = new Locale(languageCodes.get(selectedLanguage));
            Locale.setDefault(locale);
            Configuration config = new  Configuration();
            config.setLocale(locale);
            getBaseContext().getResources().updateConfiguration(config,getBaseContext().getResources().getDisplayMetrics());
            RxBus.getInstance().post(new SettingEvent(4));
            recreate();
        });
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);
    }

    private void getLanguageList() {
        language.add("English");
        language.add("Hindi");
        language.add("Chinese");
        language.add("Spanish");
        language.add("German");
        language.add("Russian");
        language.add("Portuguese");
        language.add("Finnish");
        language.add("Japanese");
        language.add("Turkish");
        language.add("Norwegian");
        language.add("Indonesian");
        language.add("Italian");
        language.add("French");
        language.add("Dutch");
        language.add("Korean");
        language.add("Georgian");
        language.add("Irish");
        language.add("Polish");
        language.add("Catalan");
    }

    private void getLanguageCodeList() {
        languageCodes.add("en");
        languageCodes.add("hi");
        languageCodes.add("zh");
        languageCodes.add("es");
        languageCodes.add("de");
        languageCodes.add("ru");
        languageCodes.add("pt");
        languageCodes.add("fi");
        languageCodes.add("ja");
        languageCodes.add("tr");
        languageCodes.add("no");
        languageCodes.add("in");
        languageCodes.add("it");
        languageCodes.add("fr");
        languageCodes.add("nl");
        languageCodes.add("ko");
        languageCodes.add("ka");
        languageCodes.add("ga");
        languageCodes.add("pl");
        languageCodes.add("ca");
    }
}