package com.photo.video.vault.gallery.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.photo.video.vault.gallery.adapter.ChooseFolderAdapter;
import com.photo.video.vault.gallery.databinding.DialogChooseFolderBinding;
import com.photo.video.vault.gallery.databinding.DialogSelectAlbumBinding;
import com.photo.video.vault.gallery.interfaces.SelectPathListener;
import com.photo.video.vault.gallery.model.Storage;

import java.io.File;
import java.util.ArrayList;

public class ChooseFolderDialog extends Dialog {
    DialogChooseFolderBinding binding;

    Context context;
    SelectPathListener pathListener;
    ChooseFolderAdapter adapter;
    ArrayList<Storage> storageList = new ArrayList<>();
    ArrayList<String> arrayListFilePaths = new ArrayList<>();
    String rootPath;
    String storagePath;

    public ChooseFolderDialog(@NonNull Context context, SelectPathListener pathListener) {
        super(context);
        this.context = context;
        this.pathListener = pathListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        binding = DialogChooseFolderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        rootPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        storagePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        arrayListFilePaths.add(rootPath);
        getList(rootPath);
        initAdapter();


        binding.btnChoose.setOnClickListener(view -> {
            pathListener.selectPath(rootPath);
            dismiss();
        });

        binding.btnCancel.setOnClickListener(view -> {
            dismiss();
        });

    }

    private void initAdapter() {
        adapter = new ChooseFolderAdapter(context, storageList, pos -> {
            if (storageList.get(pos).isBack()) {
                arrayListFilePaths.remove(arrayListFilePaths.size() - 1);
                storageList.clear();
                rootPath = arrayListFilePaths.get(arrayListFilePaths.size() - 1);
                if (arrayListFilePaths.size() > 1)
                    storageList.add(new Storage(true));
            } else {
                rootPath = storageList.get(pos).getFilePath();
                arrayListFilePaths.add(storageList.get(pos).getFilePath());
                storageList.clear();
                storageList.add(new Storage(true));
            }
            getList(rootPath);
            adapter.notifyDataSetChanged();
        });
        binding.albumRecycler.setLayoutManager(new LinearLayoutManager(context));
        binding.albumRecycler.setAdapter(adapter);
    }

    private void getList(String filePath) {
        rootPath = filePath;
        if (rootPath.equals(storagePath) && Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
            File file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            Storage model = new Storage();
            model.setFileName(Environment.DIRECTORY_DCIM);
            model.setFilePath(file.getPath());
            if (file.exists())
                storageList.add(model);

            file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            model = new Storage();
            model.setFileName(Environment.DIRECTORY_DOWNLOADS);
            model.setFilePath(file.getPath());
            if (file.exists())
                storageList.add(model);

            file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
            model = new Storage();
            model.setFileName(Environment.DIRECTORY_MOVIES);
            model.setFilePath(file.getPath());
            if (file.exists())
                storageList.add(model);

            file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
            model = new Storage();
            model.setFileName(Environment.DIRECTORY_MUSIC);
            model.setFilePath(file.getPath());
            if (file.exists())
                storageList.add(model);

            file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
            model = new Storage();
            model.setFileName(Environment.DIRECTORY_PICTURES);
            model.setFilePath(file.getPath());
            if (file.exists())
                storageList.add(model);

        } else {
            File f = new File(filePath);
            File[] files = f.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory())
                        if (!file.getName().startsWith(".")) {
                            Storage model = new Storage();
                            model.setFileName(file.getName());
                            model.setFilePath(file.getPath());

                            storageList.add(model);
                        }
                }
            }
        }
    }
}
