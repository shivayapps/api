package com.photo.video.vault.gallery.event;

import java.util.ArrayList;

public class UnHideDataEvent {

    ArrayList<String> deleteList = new ArrayList<>();
    ArrayList<UnHideEvent> copyMoveList = new ArrayList<>();

    public UnHideDataEvent(ArrayList<UnHideEvent> copyMoveList,ArrayList<String> deleteList) {
        this.deleteList = deleteList;
        this.copyMoveList = copyMoveList;
    }

    public void setCopyMoveList(ArrayList<UnHideEvent> copyMoveList) {
        this.copyMoveList = copyMoveList;
    }

    public ArrayList<UnHideEvent> getCopyMoveList() {
        return copyMoveList;
    }

    public ArrayList<String> getDeleteList() {
        return deleteList;
    }

    public void setDeleteList(ArrayList<String> deleteList) {
        this.deleteList = deleteList;
    }
}
