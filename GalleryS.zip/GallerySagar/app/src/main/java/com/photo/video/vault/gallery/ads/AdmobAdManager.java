package com.photo.video.vault.gallery.ads;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.preferences.PreferencesManager;
import com.photo.video.vault.gallery.utils.Constant;

import java.util.Random;


public class AdmobAdManager {
    ProgressDialog progressDialog;
    public Boolean isAdLoadProcessing = false;

    public static AdmobAdManager singleton;
    com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd;
    Context context;
    public NativeAd mNativeRateAd;
    public NativeAd mNativeAd;
    public Boolean isNAtiveAdLoadProcessing = false;

    public AdmobAdManager(Context context) {
        this.context = context;
    }

    public static AdmobAdManager getInstance(Context context) {
        if (singleton == null) {
            singleton = new AdmobAdManager(context);
        }
        return singleton;
    }

    private void setUpProgress(Context context) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Ad showing");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
    }

    public void showProgress(Activity activity) {
        try {
            activity.runOnUiThread(() -> {
                setUpProgress(activity);
                if (progressDialog != null && !progressDialog.isShowing()) {
                    progressDialog.show();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dismissProgress(Activity activity) {
        try {
            activity.runOnUiThread(() -> {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadInterstitialAd(Context context, String interstitialAdID) {
        if (isNetworkAvailable(context) && !PreferencesManager.getInstance(context).getSubscription(context))
            if (interstitialAd == null && !isAdLoadProcessing) {
                isAdLoadProcessing = true;
                AdRequest adRequest = new AdRequest.Builder().build();
                com.google.android.gms.ads.interstitial.InterstitialAd.load(
                        context,
                        interstitialAdID,
                        adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAds) {
                                super.onAdLoaded(interstitialAds);
                                Variables.isAdLoad = true;
                                Variables.isAdLoadFailed = false;
                                isAdLoadProcessing = false;
                                interstitialAd = interstitialAds;
                                Log.e("TAG", "onAdLoaded: ");
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                super.onAdFailedToLoad(loadAdError);
                                Variables.isAdLoad = false;
                                Variables.isAdLoadFailed = true;
                                isAdLoadProcessing = false;
                                Log.e("TAG", "onAdFailedToLoad: " + loadAdError.getMessage());

                            }
                        });
            }
    }

    public void loadNativeAd(
            Context context,
            String nativeAdID) {
        if (isNetworkAvailable(context) && PreferencesManager.getInstance(context).getNativeAdsEnabled())
            if (mNativeAd == null && !isNAtiveAdLoadProcessing) {
                isNAtiveAdLoadProcessing = true;
                if (!PreferencesManager.getInstance(context).getSubscription(context)) {
                    AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);
                    builder.forNativeAd(nativeAd -> {
                        mNativeAd = nativeAd;
                        isNAtiveAdLoadProcessing = false;
                        Variables.isNativeAdLoad = true;
                        Variables.isNativeAdLoadFailed = false;
                    }).withAdListener(new AdListener() {
                        @Override
                        public void onAdClosed() {
                            super.onAdClosed();
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            super.onAdFailedToLoad(loadAdError);
                            isNAtiveAdLoadProcessing = false;
                            Variables.isNativeAdLoad = false;
                            Variables.isNativeAdLoadFailed = true;
                        }

                        @Override
                        public void onAdOpened() {
                            super.onAdOpened();
                        }

                        @Override
                        public void onAdLoaded() {
                            super.onAdLoaded();
                        }

                        @Override
                        public void onAdClicked() {
                            super.onAdClicked();
                        }

                        @Override
                        public void onAdImpression() {
                            super.onAdImpression();
                        }
                    });
                    VideoOptions videoOptions = new VideoOptions.Builder()
                            .setStartMuted(true)
                            .build();
                    NativeAdOptions adOptions = new NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
                    builder.withNativeAdOptions(adOptions);
                    AdLoader adLoader = builder.build();
                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
    }

    OnAdClosedListener adClosedListenerInterstitialAd;

    public void loadInterstitialAd(
            Activity context,
            String interstitialAdID,
            int number,
            OnAdClosedListener onAdClosedListener) {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        adClosedListenerInterstitialAd = onAdClosedListener;
        if (!PreferencesManager.getInstance(context).getSubscription(context)) {
            Random random = new Random();
            int count = PreferencesManager.getInstance(context).getAdClickCount();
            int r = Constant.adCount;
            r++;
            if (r == count)
                Constant.adCount = 0;
            else
                Constant.adCount = r;

//            int r = random.nextInt(count - 1) + 1;
            Log.e("AdCount", "AdCunt " + count + " random " + r);
            if (number == 1 || r == 1) {
                if (interstitialAd != null) {
                    if (Variables.isAdLoad && !Variables.isAdLoadFailed && !isAdLoadProcessing) {
                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                super.onAdFailedToShowFullScreenContent(adError);
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }
                                interstitialAd = null;
                                Variables.isAdLoad = false;
                                isAdLoadProcessing = false;
                                Variables.isAdLoadFailed = false;
                                Variables.isSplashScreen = false;
                                onAdClosedListener.onAdClosed();
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent();
                            }

                            @Override
                            public void onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent();
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }
                                Variables.isAdLoad = false;
                                isAdLoadProcessing = false;
                                Variables.isAdLoadFailed = false;
                                interstitialAd = null;
                                loadInterstitialAd(context, interstitialAdID);
                                onAdClosedListener.onAdClosed();
                                Variables.isSplashScreen = false;
                            }

                            @Override
                            public void onAdImpression() {
                                super.onAdImpression();
                            }

                            @Override
                            public void onAdClicked() {
                                super.onAdClicked();
                            }
                        });
                        Variables.isSplashScreen = true;
                        interstitialAd.show(context);
                    } else {
                        Log.e("Ads", "Ads still loading!");
                        onAdClosedListener.onAdClosed();
                    }
                } else {
                    onAdClosedListener.onAdClosed();
                }
            } else {
                onAdClosedListener.onAdClosed();
            }
        } else {
            onAdClosedListener.onAdClosed();
        }
    }

    public void loadInterstitialAdPhoto(
            Activity context,
            String interstitialAdID,
            int number,
            OnAdClosedListener onAdClosedListener) {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        adClosedListenerInterstitialAd = onAdClosedListener;
        if (!PreferencesManager.getInstance(context).getSubscription(context)) {
            Random random = new Random();
            int count = PreferencesManager.getInstance(context).getAdClickCountPhoto();
            int r = Constant.adCountPhoto;
            r++;
            if (r == count)
                Constant.adCountPhoto = 0;
            else
                Constant.adCountPhoto = r;

//            int r = random.nextInt(count - 1) + 1;
            Log.e("AdCount", "AdCunt " + count + " random " + r);

            if (number == 1 || r == 1) {
                if (interstitialAd != null) {
                    if (Variables.isAdLoad && !Variables.isAdLoadFailed && !isAdLoadProcessing) {
                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                super.onAdFailedToShowFullScreenContent(adError);
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }
                                interstitialAd = null;
                                Variables.isAdLoad = false;
                                isAdLoadProcessing = false;
                                Variables.isAdLoadFailed = false;
                                Variables.isSplashScreen = false;
                                onAdClosedListener.onAdClosed();
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent();
                            }

                            @Override
                            public void onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent();
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }
                                Variables.isAdLoad = false;
                                isAdLoadProcessing = false;
                                Variables.isAdLoadFailed = false;
                                interstitialAd = null;
                                loadInterstitialAd(context, interstitialAdID);
                                onAdClosedListener.onAdClosed();
                                Variables.isSplashScreen = false;
                            }

                            @Override
                            public void onAdImpression() {
                                super.onAdImpression();
                            }

                            @Override
                            public void onAdClicked() {
                                super.onAdClicked();
                            }
                        });
                        Variables.isSplashScreen = true;
                        interstitialAd.show(context);
                    } else {
                        Log.e("Ads", "Ads still loading!");
                        onAdClosedListener.onAdClosed();
                    }
                } else {
                    onAdClosedListener.onAdClosed();
                }
            } else {
                onAdClosedListener.onAdClosed();
            }
        } else {
            onAdClosedListener.onAdClosed();
        }
    }

    public void showNativeAds(Context context,
                              String nativeAdID,
                              FrameLayout frameLayout,
                              Boolean isShowMedia,
                              Boolean isSmallAd,
                              AdEventListener adEventListener) {
        if (mNativeAd != null && PreferencesManager.getInstance(context).getNativeAdsEnabled())
            if (Variables.isNativeAdLoad && !Variables.isNativeAdLoadFailed && !isNAtiveAdLoadProcessing) {
                adEventListener.onAdLoaded(mNativeAd);
                int layout;
                if (isSmallAd) {
                    layout = R.layout.layout_samll_banner_native_ad_mob;
                } else
                    layout = R.layout.layout_big_native_ad_mob;
                populateUnifiedNativeAdView(context, nativeAdID, frameLayout, mNativeAd, isShowMedia, layout);
            } else {
                adEventListener.onLoadError("");
                if (Variables.isNativeAdLoadFailed && !isNAtiveAdLoadProcessing)
                    loadNativeAd(context, nativeAdID);
            }
        else {
            adEventListener.onLoadError("");
            if (Variables.isNativeAdLoadFailed && !isNAtiveAdLoadProcessing)
                loadNativeAd(context, nativeAdID);
        }
    }

    public interface OnAdClosedListener {
        void onAdClosed();
    }

    public void loadAdaptiveBanner(
            Context context,
            FrameLayout adContainerView,
            String bannerAdID,
            AdEventListener adEventListener) {

        if (!PreferencesManager.getInstance(context).getSubscription(context)) {
            try {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(context);
                adView.setAdUnitId(context.getString(R.string.admob_banner));
                adContainerView.removeAllViews();
                adContainerView.addView(adView);
                AdSize adSize = getAdSize(context, adContainerView);
                adView.setAdSize(adSize);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        adEventListener.onAdClosed();
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        Log.e("onAdFailedToLoad", "getMessage: " + loadAdError.getMessage());
                        adEventListener.onLoadError(loadAdError.getMessage());
                    }

                    @Override
                    public void onAdOpened() {
                        super.onAdOpened();
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        adEventListener.onAdLoaded();
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                    }
                });
                adView.loadAd(adRequest);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("Data", "LoadAdaptiveBanner: $e");
                adEventListener.onAdLoaded();
            }
        } else {
            adEventListener.onAdLoaded();
        }
    }

    private AdSize getAdSize(Context context, FrameLayout adContainerView) {
        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float density = outMetrics.density;
        int adWidthPixels = adContainerView.getWidth();
        if (adWidthPixels == 0f) {
            adWidthPixels = outMetrics.widthPixels;
        }
        float adWidth = (adWidthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, (int) adWidth);
    }

    private void populateUnifiedNativeAdView(
            Context context,
            String nativeAdID,
            FrameLayout frameLayout,
            NativeAd nativeAd,
            Boolean isShowMedia,
            int ads_unified) {
        if (isNetworkAvailable(context) && PreferencesManager.getInstance(context).getNativeAdsEnabled()) {
            LayoutInflater inflater = LayoutInflater.from(context);
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            NativeAdView adView = (NativeAdView)
                    inflater.inflate(ads_unified, null);
            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
                frameLayout.setVisibility(View.VISIBLE);
            }
            try {
                if (isShowMedia) {
                    MediaView mediaView = adView.findViewById(R.id.mediaView);
                    mediaView.setMediaContent(nativeAd.getMediaContent());
                    adView.setMediaView(mediaView);
                }
                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setIconView(adView.findViewById(R.id.adIcon));
                adView.setCallToActionView(adView.findViewById(R.id.callToAction));
                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);
                    ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
                }
                if (nativeAd.getIcon() == null) {
                    adView.getIconView().setVisibility(View.GONE);
                } else {
                    ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                    adView.getIconView().setVisibility(View.VISIBLE);
                }
                if (isShowMedia) {
                    if (adView.getMediaView() != null) {
                        if (isShowMedia) {
                            adView.getMediaView().setVisibility(View.VISIBLE);
                        } else {
                            adView.getMediaView().setVisibility(View.GONE);
                        }
                    }
                } else {
                    adView.getMediaView().setVisibility(View.GONE);
                }
                adView.setNativeAd(nativeAd);
                VideoController vc = nativeAd.getMediaContent().getVideoController();
                vc.mute(true);
                if (vc.hasVideoContent()) {
                    vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                        @Override
                        public void onVideoStart() {
                            super.onVideoStart();
                        }

                        @Override
                        public void onVideoPlay() {
                            super.onVideoPlay();
                        }

                        @Override
                        public void onVideoPause() {
                            super.onVideoPause();
                        }

                        @Override
                        public void onVideoEnd() {
                            super.onVideoEnd();
                        }

                        @Override
                        public void onVideoMute(boolean b) {
                            super.onVideoMute(b);
                        }
                    });
                }
                adView.setNativeAd(nativeAd);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("TAG", "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }

            mNativeAd = null;
            loadNativeAd(context, nativeAdID);
        }
    }

    public Boolean isNetworkAvailable(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }
}