package com.photo.video.vault.gallery.model;

import java.util.ArrayList;

public class RenameEvent {
    ArrayList<RenameModel> renameModels = new ArrayList<>();

    public RenameEvent(ArrayList<RenameModel> renameModels) {
        this.renameModels = renameModels;
    }

    public ArrayList<RenameModel> getRenameModels() {
        return renameModels;
    }

    public void setRenameModels(ArrayList<RenameModel> renameModels) {
        this.renameModels = renameModels;
    }
}
