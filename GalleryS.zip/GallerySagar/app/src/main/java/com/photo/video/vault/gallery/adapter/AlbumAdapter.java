package com.photo.video.vault.gallery.adapter;

import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.imageview.ShapeableImageView;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.model.AlbumData;
import com.photo.video.vault.gallery.preferences.PreferencesManager;

import java.util.ArrayList;

public class AlbumAdapter extends RecyclerView.Adapter<AlbumAdapter.ViewHolder> {

    FragmentActivity activity;
    ArrayList<AlbumData> albums;
    OnSelectAlbum onSelectAlbum;
    int albumType = 2;

    public AlbumAdapter(FragmentActivity activity, ArrayList<AlbumData> albums, OnSelectAlbum onSelectAlbum) {
        this.activity = activity;
        this.onSelectAlbum = onSelectAlbum;
        this.albums = albums;
        albumType = PreferencesManager.getInstance(activity).getAlbumType();
    }

    public void setAlbumType(int albumType) {
        this.albumType = albumType;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (albumType == 1)
            view = LayoutInflater.from(activity).inflate(R.layout.item_album_list, parent, false);
        else if (albumType == 2)
            view = LayoutInflater.from(activity).inflate(R.layout.item_album, parent, false);
        else if (albumType == 3)
            view = LayoutInflater.from(activity).inflate(R.layout.item_album_card, parent, false);
        else if (albumType == 4)
            view = LayoutInflater.from(activity).inflate(R.layout.item_album_parallax, parent, false);
        else
            view = LayoutInflater.from(activity).inflate(R.layout.item_album, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        try {
            if (albums.get(position).getPictureData() != null && albums.get(position).getPictureData().size() != 0)
                Glide.with(activity).load(albums.get(position).getPictureData().get(0).getFilePath())
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true).into(holder.albumImage);

            holder.albumCount.setText(albums.get(position).getPictureData().size() + " " + activity.getString(R.string.items));
            holder.albumName.setText(albums.get(position).getTitle());
            if (albums.get(position).isPin())
                holder.iv_pin.setVisibility(View.VISIBLE);
            else
                holder.iv_pin.setVisibility(View.GONE);

            holder.itemView.setOnClickListener(v -> onSelectAlbum.onClickAlbum(position));
            holder.iv_menu.setOnClickListener(v -> onSelectAlbum.onClickMenu(position, v));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return albums.size();
    }

    public void addData(ArrayList<AlbumData> albums) {
        this.albums = albums;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView albumName;
        TextView albumCount;
        ImageView iv_menu, iv_pin;
        ShapeableImageView albumImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            albumImage = itemView.findViewById(R.id.albumImage);
            albumName = itemView.findViewById(R.id.albumName);
            albumCount = itemView.findViewById(R.id.albumCount);
            iv_menu = itemView.findViewById(R.id.iv_menu);
            iv_pin = itemView.findViewById(R.id.iv_pin);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

//            float radius = activity.getResources().getDimension(R.dimen._6sdp);
//            ShapeAppearanceModel shapeAppearanceModel = albumImage.getShapeAppearanceModel().toBuilder()
//                    .setAllCornerSizes(radius)
//                    .build();
//            albumImage.setShapeAppearanceModel(shapeAppearanceModel);
        }
    }

    public interface OnSelectAlbum {
        void onClickAlbum(int pos);

        void onClickMenu(int pos, View view);
    }
}
