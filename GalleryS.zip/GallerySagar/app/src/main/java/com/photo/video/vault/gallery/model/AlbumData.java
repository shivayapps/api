package com.photo.video.vault.gallery.model;

import java.io.Serializable;
import java.util.ArrayList;

public class AlbumData implements Serializable {
    String title="", folderPath;
    int dateCounter;
    ArrayList<PictureData> pictureData = new ArrayList<>();
    boolean isSelect = false;
    boolean isPin = false;
    long date;

    public int getDateCounter() {
        return dateCounter;
    }

    public void setDateCounter(int dateCounter) {
        this.dateCounter = dateCounter;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFolderPath() {
        return folderPath;
    }

    public void setFolderPath(String folderPath) {
        this.folderPath = folderPath;
    }

    public ArrayList<PictureData> getPictureData() {
        return pictureData;
    }

    public boolean isPin() {
        return isPin;
    }

    public void setPin(boolean pin) {
        isPin = pin;
    }

    public void setPictureData(ArrayList<PictureData> pictureData) {
        this.pictureData = pictureData;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }
}
