package com.photo.video.vault.gallery.ads;

import android.app.Application;

public class Variables {
    public  static Application myApplication;
    public static boolean  isSplashScreen = false;
    public static boolean  isSPermissionScreen = false;
    public static boolean  isAdLoad = false;
    public static boolean  isAdLoadFailed = false;
    public static boolean  isNativeAdLoad = false;
    public static boolean  isNativeAdLoadFailed = false;
}