package com.photo.video.vault.gallery.model;

import java.io.Serializable;
import java.util.ArrayList;

public class PictureData implements Serializable {

    String fileName;
    String filePath, rFilePath;
    public String folderName = "";
    public String folderPath = "";
    String thumbnails;
    String lat;
    String longs;
    long date = 0;
    long fileSize;
    boolean isVideo = false;
    long videoDuration = 0;
    long lastDisplayDate = 0;
    ArrayList<Integer> colorList = new ArrayList<>();

    public ArrayList<Integer> getColorList() {
        return colorList;
    }

    public void setColorList(ArrayList<Integer> colorList) {
        this.colorList = colorList;
    }

    public long getLastDisplayDate() {
        return lastDisplayDate;
    }

    public void setLastDisplayDate(long lastDisplayDate) {
        this.lastDisplayDate = lastDisplayDate;
    }

    public long getVideoDuration() {
        return videoDuration;
    }

    public void setVideoDuration(long videoDuration) {
        this.videoDuration = videoDuration;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getrFilePath() {
        return rFilePath;
    }

    public void setrFilePath(String rFilePath) {
        this.rFilePath = rFilePath;
    }

    boolean isSelected;
    boolean isCheckboxVisible = false;

    boolean isFavorite = false;

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void setFavorite(boolean favorite) {
        isFavorite = favorite;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public boolean isCheckboxVisible() {
        return isCheckboxVisible;
    }

    public void setCheckboxVisible(boolean checkboxVisible) {
        isCheckboxVisible = checkboxVisible;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }


    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public String getFolderPath() {
        return folderPath;
    }

    public void setFolderPath(String folderPath) {
        this.folderPath = folderPath;
    }

    public String getThumbnails() {
        return thumbnails;
    }

    public void setThumbnails(String thumbnails) {
        this.thumbnails = thumbnails;
    }


    public boolean isVideo() {
        return isVideo;
    }

    public void setVideo(boolean video) {
        isVideo = video;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLongs() {
        return longs;
    }

    public void setLongs(String longs) {
        this.longs = longs;
    }
}
