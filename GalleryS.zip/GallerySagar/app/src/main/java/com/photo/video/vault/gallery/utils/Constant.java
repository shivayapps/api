package com.photo.video.vault.gallery.utils;

import android.os.Environment;
import android.webkit.MimeTypeMap;

import com.photo.video.vault.gallery.model.AlbumData;
import com.photo.video.vault.gallery.model.PictureData;

import java.util.ArrayList;

public class Constant {

    public static int adCount = 0;
    public static int adCountPhoto = 0;

    public static ArrayList<PictureData> displayImageList = new ArrayList<>();
    public static ArrayList<AlbumData> albumList = new ArrayList<>();

    public final static String SHARED_PREFS = "Gallery";
    public final static String SHARED_PREFS_RATE = "Gallery_rate";
    public final static String SHARED_PREFS_SUBSCRIPTION = "Gallery_subcription";
    public static final String SHARED_PREFS_LANGUAGE = "pref_language";
    public final static String SHARED_PREFS_SUBSCRIPTION_DATE = "Gallery_subcription_date";
    public final static String SHARED_PREFS_GRID = "Gallery_grid";
    public final static String SHARED_PREFS_Album_type = "Gallery_Album_type";
    public final static String SHARED_PREFS_ALBUM_GRID = "Gallery_album_grid";
    public final static String SHARED_PREFS_LABEL = "Gallery_label_display";
    public final static String SHARED_PREFS_EXIT_DIALOG = "Gallery_exit_dialog";
    public final static String SHARED_PREFS_FAST_SCROLL = "Gallery_scroll";
    public final static String SHARED_PREFS_FILTER_PHOTOS = "Gallery_filter_photos";
    public final static String SHARED_PREFS_SORT_PHOTOS = "Gallery_sort_photos";
    public final static String SHARED_PREFS_START_PAGE = "Gallery_start_page";
    public final static String SHARED_PREFS_SORT_TYPE_PHOTOS = "Gallery_sort_type_photos";
    public final static String SHARED_PREFS_SLIDESHOW_TIME = "Gallery_slideShow_Time_photos";
    public final static String SHARED_PREFS_THEME = "Gallery_theme";
    public static final String PREF_PRIVACY = "Privacy";
    public static final String PREF_WP_STATUS = "Gallery_wp_status";

    public final static String SHARED_PREFS_FAVORITE_LIST = "pref_favorite_list";
    public final static String SHARED_PREFS_RECENT_LIST = "pref_recent_list";
    public final static String SHARED_PREFS_ExcludeFolder_LIST = "pref_ExcludeFolder_list";
    public final static String SHARED_PREFS_PIN_ALBUM_LIST = "pref_pin_album_list";
    public final static String SHARED_PREFS_SORT_ALBUM = "Gallery_sort_album";
    public final static String SHARED_PREFS_SORT_TYPE_ALBUM = "Gallery_sort_type_album";
    public static final String PREF_PASSCODE_SET = "passcode_set";
    public static final String PREF_Fingerprint = "set_Fingerprint";
    public static final String PREF_LOCK_APP = "lock_app";
    public static final String PREF_STORAGE_PERMISSION = "storage_permission";

    public static final String PREF_SECURITY_SET = "security_set";
    public static final String PREF_PASSCODE = "passcode";
    public static final String PREF_SECURITY_ANS = "security_ans";
    public static final String PREF_HIDDEN_URI = "hidden_uri";
    public static final String PREF_SECURITY_QUESTION = "security_question";

    public final static String SHARED_PREFS_APP_ID = "app_id";
    public final static String SHARED_PREFS_BANNER = "banner";
    public final static String SHARED_PREFS_INTERSTITIAL = "interstitial";
    public final static String SHARED_PREFS_NATIVE = "native";
    public final static String SHARED_PREFS_OPEN = "app_open";
    public final static String SHARED_PREFS_OPENAPP_ENABLE = "openapp_ads_enabled";
    public final static String SHARED_PREFS_NATIVE_ADS_ENABLE = "native_ads_enabled";
    public final static String SHARED_PREFS_AD_TYPE = "ad_type";
    public final static String SHARED_PREFS_AD_COUNT = "ad_count";
    public final static String SHARED_PREFS_AD_COUNT_PHOTO = "ad_count_photo";

    public final static String SHARED_PREFS_IS_VIP = "isVIP";
    public final static String SHARED_PREFS_VIP_COUNTRY = "country";
    public final static String SHARED_PREFS_VIP_REGION_NAME = "regionName";
    public final static String SHARED_PREFS_VIP_CITY = "city";

    public static final String HIDE_FOLDER_NAME = ".PrivateData";
    //    public static final String HIDE_FOLDER_NAME = ".LockMedia";
    public static final String WP_FOLDER_NAME = "Saved Status";
    public static final String HIDE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/Gallery/" + HIDE_FOLDER_NAME;
    public static final String DOWNLOAD_WP_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/Gallery/" + WP_FOLDER_NAME;
    public static final String DIRECTORY_PICTURES_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath();
    public static final String DIRECTORY_DCIM_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getPath();
    public static final String UNHIDE_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/Gallery";
    public static final String UNHIDE_PATH_11 = Environment.DIRECTORY_PICTURES + "/Gallery";

    public static AlbumData albumData = new AlbumData();
    public static AlbumData recentData = new AlbumData();


    public static String getMimeTypeFromFilePath(String filePath) {
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(getFilenameExtension(filePath));
    }

    public static String getFilenameExtension(String path) {
        return path.substring(path.lastIndexOf(".") + 1);
    }
}
