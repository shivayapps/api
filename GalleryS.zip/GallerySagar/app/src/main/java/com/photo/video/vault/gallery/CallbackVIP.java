package com.photo.video.vault.gallery;

public interface CallbackVIP {
    void close();
}
