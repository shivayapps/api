package com.photo.video.vault.gallery.utils;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import androidx.palette.graphics.Palette;

import com.photo.video.vault.gallery.model.PictureData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

public class ImageColor {

    //    public static ArrayList<Object> photoList = new ArrayList<>();
    public static ArrayList<PictureData> photoColorList = new ArrayList<>();
    public static ArrayList<String> deleteList = new ArrayList<>();
    public static ArrayList<PictureData> copyMoveImageList = new ArrayList<>();

    public static boolean isImageGettingRunning = false;
    public static boolean isColorImageGettingRunning = false;

    public static void getImages(Context context) {
        isImageGettingRunning = true;
        photoColorList.clear();
        deleteList.clear();
        copyMoveImageList.clear();
//        if (checkStoragePermission(MediaColorActivity.this)) {
        LinkedHashMap<String, ArrayList<PictureData>> dateWisePictures = new LinkedHashMap<>();
        Cursor mCursor;
        try {
            String BUCKET_DISPLAY_NAME;
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME;

            String[] projection = {MediaStore.Images.Media.DATA/*, MediaStore.Images.Media.TITLE*/
                    , BUCKET_DISPLAY_NAME
                    , MediaStore.MediaColumns.DATE_MODIFIED
                    , MediaStore.MediaColumns.DISPLAY_NAME
            };

            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
            } else {
                uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            }

            mCursor = context.getContentResolver().query(
                    uri, // Uri
                    projection, // Projection
                    null,
                    null,
                    MediaStore.MediaColumns.DATE_MODIFIED + " DESC");

            SimpleDateFormat format = new SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH);
            SimpleDateFormat format2 = new SimpleDateFormat("MMM yyyy", Locale.ENGLISH);
            Calendar calendar = Calendar.getInstance();
            String today = format.format(calendar.getTimeInMillis());
            calendar.add(Calendar.DATE, -1);
            String yesterday = format.format(calendar.getTimeInMillis());

            if (mCursor != null) {
                mCursor.moveToFirst();
                for (mCursor.moveToFirst(); !mCursor.isAfterLast(); mCursor.moveToNext()) { //2sec

                    String path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                    String title = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME));

                    String bucketName = mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME));
                    long d = mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED));
                    d = d * 1000;

                    PictureData pictureData = new PictureData();
                    pictureData.setFilePath(path);
                    pictureData.setFileName(title);
                    pictureData.setFolderName(bucketName);
                    pictureData.setDate(d);
                    photoColorList.add(pictureData);

                }
                mCursor.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        gettingColorImages(context);
    }

    private static void gettingColorImages(Context context) {
//        isColorImageGettingRunning = true;
        isImageGettingRunning = false;
        for (int i = 0; i < photoColorList.size(); i++) {
            if (photoColorList.get(i) instanceof PictureData) {
                PictureData model = (PictureData) photoColorList.get(i);
                model.setColorList(getAllColorInImages(model.getFilePath()));
            }
        }

        isColorImageGettingRunning = true;
    }

    private static ArrayList<Integer> getAllColorInImages(String path) {
        ArrayList<Integer> colorList = new ArrayList<>();
        try {
            Bitmap bitmap = BitmapFactory.decodeFile(path);
            if (bitmap == null)
                return colorList;

            Palette.from(bitmap).generate(palette -> {

                List<Palette.Swatch> swatchList = palette.getSwatches();
                if (swatchList != null && swatchList.size() != 0) {
                    for (Palette.Swatch swatch : swatchList) {
                        colorList.add(swatch.getRgb());
                    }
                }

            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        return colorList;
    }
}
