package com.photo.video.vault.gallery.event;

public class AlbumDataEvent {
}
