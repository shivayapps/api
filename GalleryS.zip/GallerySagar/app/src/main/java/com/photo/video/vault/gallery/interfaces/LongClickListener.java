package com.photo.video.vault.gallery.interfaces;

public interface LongClickListener {
    void longClick(boolean isShowToolbar, boolean isShowSelected, int selected, long size);
}