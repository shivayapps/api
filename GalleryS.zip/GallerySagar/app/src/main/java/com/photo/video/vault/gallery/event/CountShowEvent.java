package com.photo.video.vault.gallery.event;

public class CountShowEvent {
    public CountShowEvent() {

    }
}
