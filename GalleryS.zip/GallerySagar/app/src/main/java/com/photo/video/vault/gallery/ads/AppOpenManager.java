package com.photo.video.vault.gallery.ads;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.photo.video.vault.gallery.preferences.PreferencesManager;


public class AppOpenManager implements LifecycleObserver, Application.ActivityLifecycleCallbacks {

    AppOpenAd appOpenAd;
    AppOpenAd.AppOpenAdLoadCallback loadCallback;
    Activity currentActivity;
    Boolean isLoading = false;

    int activityReferences = 0;
    Boolean isActivityChangingConfigurations = false;
    public static Boolean isShowingAd = false;
    Application myApplication;
    PreferencesManager preferencesManager;

    public AppOpenManager(Application appClass) {
        this.myApplication = appClass;
        preferencesManager = PreferencesManager.getInstance(myApplication.getApplicationContext());
        myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);

    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    void onStart() {
        if (!Variables.isSplashScreen && !Variables.isSPermissionScreen) {
            if (isAdAvailable()) {
                showAdIfAvailable();
            } else {
                fetchAd(true);
            }
        }
    }

    public void loadAppOpenAd() {
        Log.e("appOpenManager", "loadAppOpenAd  isSplashScreen===>>  "+ Variables.isSplashScreen);
        if (Variables.isSplashScreen) {
            if (!isAdAvailable()) {
                fetchAd(false);
            }
        }
    }

    private void fetchAd(Boolean b) {
        Log.e("appOpenManager", "fetchAd");
        if (isAdAvailable() || isLoading) {
            return;
        }

        isLoading = true;
        Log.d("LOG_TAG", "onLOadStart");
        Log.e("appOpenManager", "open ad loading");
        loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(AppOpenAd appOpenAds) {
                super.onAdLoaded(appOpenAds);
                appOpenAd = appOpenAds;
                isLoading = false;
                Log.e("appOpenManager", "open ad onAdLoaded");
                if (b) {
                    showAdIfAvailable();
                }
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                Log.e("appOpenManager", "open ad onAdFailedToLoad");
                Log.e("LOG_TAG", "::ERRR" + loadAdError.getMessage() + "::" + loadAdError.getCode());
            }

        };
        AdRequest request = get();
        Log.d("Data", "apiCall: =====> " + preferencesManager.getOpenId());
        AppOpenAd.load(
                myApplication, preferencesManager.getOpenId(), request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback
        );
    }

    void showAdIfAvailable() {
        Log.d("LOG_TAG", "ADSSSS:$isShowingAd::::$isAdAvailable");
        if (!isShowingAd) {
            if (isAdAvailable()) {
                Log.d("LOG_TAG", "Will show ad.");
                FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        super.onAdFailedToShowFullScreenContent(adError);
                        Log.d("LOG_TAG", "Error display show ad." + adError.getMessage());
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent();
                        isShowingAd = true;
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent();
                        appOpenAd = null;
                        isShowingAd = false;
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                    }
                };
                Log.d("LOG_TAG", currentActivity.toString());
                appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
                appOpenAd.show(currentActivity);
            } else {
                Log.d("LOG_TAG", "Can not show ad.");
                fetchAd(true);
            }
        }
    }

    public void showAdIfAvailable(AdmobAdManager.OnAdClosedListener onAdClosedListener) {
        Log.d("LOG_TAG", "ADSSSS:$isShowingAd::::$isAdAvailable");
        Log.e("appOpenManager", "showAdIfAvailable isShowingAd ==>> " + isShowingAd);
        Variables.isSPermissionScreen =false;
        if (!isShowingAd) {
            if (isAdAvailable()) {
                Log.e("appOpenManager", "show Open Ad ==>> ");
                Log.d("LOG_TAG", "Will show ad.");
                FullScreenContentCallback fullScreenContentCallback = new FullScreenContentCallback() {
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        super.onAdFailedToShowFullScreenContent(adError);
                        Log.d("LOG_TAG", "Error display show ad." + adError.getMessage());
                        onAdClosedListener.onAdClosed();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent();
                        isShowingAd = true;
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent();
                        appOpenAd = null;
                        isShowingAd = false;
                        onAdClosedListener.onAdClosed();
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                    }
                };
//                Log.e("LOG_TAG", currentActivity.toString());
                appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
                appOpenAd.show(currentActivity);
            } else {
                Log.e("LOG_TAG", "Can not show ad.");
                fetchAd(true);
                onAdClosedListener.onAdClosed();
            }
        }else
            onAdClosedListener.onAdClosed();
    }


    AdRequest get() {
        return new AdRequest.Builder().build();
    }

    public Boolean isAdAvailable() {
        return appOpenAd != null;
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        currentActivity = activity;
        if (++activityReferences == 1 && !isActivityChangingConfigurations) {

        }
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
        currentActivity = activity;
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        isActivityChangingConfigurations = activity.isChangingConfigurations();
        if (--activityReferences == 0 && !isActivityChangingConfigurations) {
            if (!isAdAvailable()) {
                fetchAd(false);
            }
        }
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {

    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        currentActivity = null;
    }
}
