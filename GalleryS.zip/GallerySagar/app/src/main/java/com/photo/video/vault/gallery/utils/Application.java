package com.photo.video.vault.gallery.utils;

import com.google.android.gms.ads.MobileAds;
import com.photo.video.vault.gallery.BuildConfig;
import com.yandex.metrica.YandexMetrica;
import com.yandex.metrica.YandexMetricaConfig;

//import unified.vpn.sdk.ClientInfo;
//import unified.vpn.sdk.CompletableCallback;
//import unified.vpn.sdk.HydraTransportConfig;
//import unified.vpn.sdk.OpenVpnTransportConfig;
//import unified.vpn.sdk.TransportConfig;
//import unified.vpn.sdk.UnifiedSdk;
//import unified.vpn.sdk.UnifiedSdkConfig;

public class Application extends android.app.Application {

    public static Application myApplication;
//    UnifiedSdk unifiedSDK;
    @Override
    public void onCreate() {
        super.onCreate();
        myApplication = this;
        MobileAds.initialize(this, initializationStatus -> {
        });

        YandexMetricaConfig config = YandexMetricaConfig.newConfigBuilder("c6faf21e-fd18-43b3-b7fc-69356fd232c6").build();
        YandexMetrica.activate(getApplicationContext(), config);
        YandexMetrica.enableActivityAutoTracking(this);

//        initHydraSdk();
    }
//    public SharedPreferences getPrefs() {
//        return getSharedPreferences(BuildConfig.SHARED_PREFS, Context.MODE_PRIVATE);
//    }

//    public void initHydraSdk() {
//        SharedPreferences prefs = getPrefs();
//        ClientInfo clientInfo = ClientInfo.newBuilder()
//                .addUrl(prefs.getString("com.northghost.afvclient.STORED_HOST_KEY", BuildConfig.BASE_HOST))
//                .carrierId(prefs.getString("com.northghost.afvclient.CARRIER_ID_KEY", BuildConfig.BASE_CARRIER_ID))
//                .build();
//        List<TransportConfig> transportConfigList = new ArrayList<>();
//        transportConfigList.add(HydraTransportConfig.create());
//        transportConfigList.add(OpenVpnTransportConfig.tcp());
//        transportConfigList.add(OpenVpnTransportConfig.udp());
//        UnifiedSdk.update(transportConfigList, CompletableCallback.EMPTY);
//        UnifiedSdkConfig config = UnifiedSdkConfig.newBuilder().build();
//        unifiedSDK = UnifiedSdk.getInstance(clientInfo, config);
//
//        UnifiedSdk.setLoggingLevel(Log.VERBOSE);
//    }
}
