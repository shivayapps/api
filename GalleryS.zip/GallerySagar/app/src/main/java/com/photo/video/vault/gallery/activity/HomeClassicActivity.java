package com.photo.video.vault.gallery.activity;


import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.photo.video.vault.gallery.BuildConfig;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.ads.AdEventListener;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.databinding.ActivityHomeClassicBinding;
import com.photo.video.vault.gallery.dialog.ChooseFolderDialog;
import com.photo.video.vault.gallery.event.CopyMoveEvent;
import com.photo.video.vault.gallery.event.CountShowEvent;
import com.photo.video.vault.gallery.event.ImageCloseEvent;
import com.photo.video.vault.gallery.event.ImageShareDeleteEvent;
import com.photo.video.vault.gallery.fragment.AlbumFragment;
import com.photo.video.vault.gallery.fragment.PhotoFragment;
import com.photo.video.vault.gallery.interfaces.LongClickListener;
import com.photo.video.vault.gallery.model.AlbumData;
import com.photo.video.vault.gallery.model.FilterSettingUpdate;
import com.photo.video.vault.gallery.model.PictureData;
import com.photo.video.vault.gallery.preferences.PreferencesManager;
import com.photo.video.vault.gallery.rx.RxBus;
import com.photo.video.vault.gallery.utils.ImageColor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class HomeClassicActivity extends AppCompatActivity implements LongClickListener {

    ActivityHomeClassicBinding binding;
    HomePagerAdapter homePagerAdapter;
    PhotoFragment photoFragment;
    AlbumFragment albumFragment;
    boolean isSelectAll = false;
    PreferencesManager preferencesManager;
    String imageFilePath;
    ActivityResultLauncher<Intent> captureImageActivityResultLauncher;
    ActivityResultLauncher<Intent> settingImageActivityResultLauncher;
    int tabPos = 0;
    boolean isOpenToSplash = false;

    AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(getResources().getColor(R.color.white));
        preferencesManager = PreferencesManager.getInstance(this);
        changeLanguage();
        binding = ActivityHomeClassicBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        intView();
        showCount();
    }

    private void openSetting() {
        Intent intent = new Intent(HomeClassicActivity.this, SettingsActivity.class);
        settingImageActivityResultLauncher.launch(intent);
    }

    private void intView() {
        if (getIntent() != null)
            isOpenToSplash = getIntent().getBooleanExtra("isOpenToSplash", false);
        admobAdManager = AdmobAdManager.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        photoFragment = new PhotoFragment(this);
        albumFragment = AlbumFragment.newInstance(this);
        photoFragment.setLongClickListener(this);

        binding.contentData.tablayout.addTab(binding.contentData.tablayout.newTab().setText(getString(R.string.Photos)));
        binding.contentData.tablayout.addTab(binding.contentData.tablayout.newTab().setText(getString(R.string.Albums)));

        homePagerAdapter = new HomePagerAdapter(getSupportFragmentManager(), 2, photoFragment, albumFragment);
        binding.contentData.viewpager.setAdapter(homePagerAdapter);
        tabPos = preferencesManager.getStartPage();
        binding.contentData.viewpager.setCurrentItem(preferencesManager.getStartPage());

        binding.contentData.viewpager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(binding.contentData.tablayout));

        binding.contentData.tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.contentData.viewpager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        binding.drawerContent.txtVersion.setText(getResources().getString(R.string.version2) + " " + BuildConfig.VERSION_NAME);
        setClickListener();
        setDrawerClickListener();

        new Thread(() -> {
            ImageColor.getImages(HomeClassicActivity.this);
            runOnUiThread(() -> Log.e("", "Image is getting"));
        }).start();

        binding.contentData.ivSearch.setVisibility(View.VISIBLE);
        binding.contentData.ivDrawer.setVisibility(View.VISIBLE);
        binding.contentData.txtTitle.setVisibility(View.VISIBLE);
        binding.contentData.ivSearchClose.setVisibility(View.GONE);
        binding.contentData.loutSearch.setVisibility(View.GONE);
        setActivityResultLauncher();

        if (isOpenToSplash) {
            Random random = new Random();
            int num = random.nextInt(6);
            if (num == 1)
                showRate();
        }

        setTabTitle();
    }

    private void changeLanguage() {
        ArrayList<String> languageCodes = new ArrayList<>();
        languageCodes.add("en");
        languageCodes.add("hi");
        languageCodes.add("zh");
        languageCodes.add("es");
        languageCodes.add("de");
        languageCodes.add("ru");
        languageCodes.add("pt");
        languageCodes.add("fi");
        languageCodes.add("ja");
        languageCodes.add("tr");
        languageCodes.add("no");
        languageCodes.add("in");
        languageCodes.add("it");
        languageCodes.add("fr");
        languageCodes.add("nl");
        languageCodes.add("ko");
        languageCodes.add("ka");
        languageCodes.add("ga");
        languageCodes.add("pl");
        languageCodes.add("ca");

        Locale locale = new Locale(languageCodes.get(preferencesManager.getLanguage()));
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

    }

    private void showRate() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_rate);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView cancel = dialog.findViewById(R.id.cancel);
        TextView rateApp = dialog.findViewById(R.id.rateApp);

        rateApp.setOnClickListener(view -> {
            dialog.dismiss();
            rateUS();
        });


        cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    private void setDrawerClickListener() {
        binding.drawerContent.loutDrawerMain.setOnClickListener(view -> {

        });
        binding.drawerContent.btnDrawerFavourites.setOnClickListener(view -> {
            startActivity(new Intent(HomeClassicActivity.this, FavoriteListActivity.class));
            closeDrawer();
        });
        binding.drawerContent.btnDrawerMediaVault.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
                startActivity(new Intent(HomeClassicActivity.this, PasswordActivity.class).putExtra("isOpenPrivate", true));
            });
            closeDrawer();
        });
        binding.drawerContent.btnDrawerStatusSaver.setOnClickListener(view -> {
            startActivity(new Intent(HomeClassicActivity.this, WpStatusActivity.class));
            closeDrawer();
        });
        binding.drawerContent.btnDrawerSettings.setOnClickListener(view -> {
            openSetting();
            closeDrawer();
        });
        binding.drawerContent.btnDrawerRecentMedia.setOnClickListener(view -> {
            startActivity(new Intent(HomeClassicActivity.this, RecentActivity.class));
            closeDrawer();
        });
        binding.drawerContent.btnDrawerHome.setOnClickListener(view -> {
            closeDrawer();
        });
        binding.drawerContent.btnDrawerShare.setOnClickListener(view -> {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    getString(R.string.share_msg) + " https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
            closeDrawer();
        });

        binding.drawerContent.btnDrawerRate5star.setOnClickListener(view -> {
            rateUS();
            closeDrawer();
        });

        binding.drawerContent.btnDrawerMediaColor.setOnClickListener(view -> {
            startActivity(new Intent(HomeClassicActivity.this, MediaColorActivity.class));
            closeDrawer();
        });
    }

    private void rateUS() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    private void closeDrawer() {
        binding.drawerLay.closeDrawer(GravityCompat.START);
    }

    private void setThemeScreen() {
        int theme = preferencesManager.getTheme();
        if (theme == 0)
            startActivity(new Intent(this, HomeActivity.class));
        else if (theme == 1)
            startActivity(new Intent(this, HomeFlatActivity.class));
        else if (theme == 2)
            startActivity(new Intent(this, HomeClassicActivity.class));
        finish();
    }

    private void setActivityResultLauncher() {
        settingImageActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        setThemeScreen();
                    }
                });

        captureImageActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            // There are no request codes
                            MediaScannerConnection.scanFile(HomeClassicActivity.this, new String[]{imageFilePath}, null, (path, uri) -> {
                                // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                            });
                            Log.e("", "imageFilePath: " + imageFilePath);
//                            RxBus.getInstance().post(new EditImageEvent(imageFilePath, "Camera"));
                            ArrayList<String> list = new ArrayList<>();
                            list.add(imageFilePath);
                            File file = new File(imageFilePath);
                            RxBus.getInstance().post(new CopyMoveEvent(list, "Camera", file.getParentFile().getPath(), new ArrayList<>()));
                        }
                    }
                });

    }

    private void setClickListener() {
        binding.contentData.ivDrawer.setOnClickListener(view -> {
            if (binding.drawerLay.isDrawerOpen(GravityCompat.START))
                binding.drawerLay.closeDrawer(GravityCompat.START);
            else
                binding.drawerLay.openDrawer(GravityCompat.START);
        });

        binding.contentData.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (binding.contentData.loutSelect.getVisibility() == View.VISIBLE)
                    setClose();
                else if (binding.contentData.loutSearch.getVisibility() == View.VISIBLE) {
//                    setSearch("");
                    closeSearch();
                }
                tabPos = position;
                showImageCount();
                binding.contentData.cameraFloatinButton.hide();
                binding.contentData.cameraFloatinButton.show();

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        binding.contentData.ivMenu.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(HomeClassicActivity.this, view);
            if (binding.contentData.viewpager.getCurrentItem() == 0) {
                popup.getMenuInflater().inflate(R.menu.menu_home, popup.getMenu());
                popup.getMenu().findItem(R.id.nav_DisplayMediaName).setChecked(preferencesManager.getLabelShow());

            } else if (binding.contentData.viewpager.getCurrentItem() == 1) {
                popup.getMenuInflater().inflate(R.menu.menu_album_home, popup.getMenu());
                int albumType = preferencesManager.getAlbumType();
                if (albumType == 1)
                    popup.getMenu().findItem(R.id.viewAlbumList).setChecked(true);
                else if (albumType == 2)
                    popup.getMenu().findItem(R.id.viewAlbumGrid).setChecked(true);
                else if (albumType == 3)
                    popup.getMenu().findItem(R.id.viewAlbumGridCard).setChecked(true);
                else if (albumType == 4)
                    popup.getMenu().findItem(R.id.viewAlbumParallax).setChecked(true);
                else popup.getMenu().findItem(R.id.viewAlbumGrid).setChecked(true);
            }
            popup.show();

            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_DisplayMediaName) {
//                    boolean isChecked = popup.getMenu().findItem(R.id.nav_DisplayMediaName).isChecked();
                    preferencesManager.putLabelShow(!preferencesManager.getLabelShow());
                    if (photoFragment != null)
                        photoFragment.setLabel();
                } else if (item.getItemId() == R.id.nav_settings || item.getItemId() == R.id.setting) {
                    openSetting();
                } else if (item.getItemId() == R.id.viewAlbumList ||
                        item.getItemId() == R.id.viewAlbumGrid ||
                        item.getItemId() == R.id.viewAlbumGridCard ||
                        item.getItemId() == R.id.viewAlbumParallax) {
                    int albumType = 2;
                    boolean isChecked = popup.getMenu().findItem(item.getItemId()).isChecked();
                    if (item.getItemId() == R.id.viewAlbumList)
                        albumType = 1;
                    else if (item.getItemId() == R.id.viewAlbumGrid)
                        albumType = 2;
                    else if (item.getItemId() == R.id.viewAlbumGridCard)
                        albumType = 3;
                    else if (item.getItemId() == R.id.viewAlbumParallax)
                        albumType = 4;
                    else
                        albumType = 1;
                    preferencesManager.setAlbumType(albumType);
                    if (albumFragment != null)
                        albumFragment.setGridType();
                }
                return true;
            });
        });

        binding.contentData.ivSearch.setOnClickListener(view -> {
            binding.contentData.ivSearch.setVisibility(View.GONE);
            binding.contentData.ivDrawer.setVisibility(View.GONE);
            binding.contentData.txtTitle.setVisibility(View.GONE);
            binding.contentData.ivSearchClose.setVisibility(View.GONE);
            binding.contentData.ivBack.setVisibility(View.VISIBLE);
            binding.contentData.loutSearch.setVisibility(View.VISIBLE);
            showKeyboard(binding.contentData.edtSearch);
        });

        binding.contentData.ivSearchClose.setOnClickListener(view -> {
            binding.contentData.edtSearch.getText().clear();
        });

        binding.contentData.ivBack.setOnClickListener(view -> {
            closeSearch();
        });

        binding.contentData.ivSort.setOnClickListener(view -> {
            if (binding.contentData.viewpager.getCurrentItem() == 0)
                showSortPhotosDialog();
            else
                showSortAlbumDialog();
        });

        binding.contentData.ivClose.setOnClickListener(view -> {
            setClose();
        });

        binding.contentData.ivDelete.setOnClickListener(view -> {
            int tabPos1 = binding.contentData.viewpager.getCurrentItem();
            RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "delete"));
        });

        binding.contentData.ivShare.setOnClickListener(view -> {
            int tabPos = binding.contentData.viewpager.getCurrentItem();
            RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos, "share"));
//            setClose();
        });

        binding.contentData.ivMenuSelect.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(HomeClassicActivity.this, view);
            popup.getMenuInflater().inflate(R.menu.menu_select_option, popup.getMenu());
            if (isSelectAll)
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.DeselectAll));
            else
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.SelectAll));
            popup.show();

            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_move_private) {
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "MediaVault"));
                } else if (item.getItemId() == R.id.nav_copy) {
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    ArrayList<AlbumData> albumList = new ArrayList<>();
                    if (albumFragment != null)
                        albumList.addAll(albumFragment.albumBackUpList);
                    RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "copy", albumList));
                } else if (item.getItemId() == R.id.nav_move) {
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    ArrayList<AlbumData> albumList = new ArrayList<>();
                    if (albumFragment != null)
                        albumList.addAll(albumFragment.albumBackUpList);
                    RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "move", albumList));
                } else if (item.getItemId() == R.id.nav_select) {
                    if (isSelectAll)
                        isSelectAll = false;
                    else
                        isSelectAll = true;
                    int tabPos1 = binding.contentData.viewpager.getCurrentItem();
                    RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, "Select", isSelectAll));
                }
                return true;
            });
        });

        binding.contentData.edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String strSearch = charSequence.toString();
                Log.e("searchText addChange: ", strSearch);
                setSearch(strSearch);

                if (i2 == 0) {
                    binding.contentData.ivSearchClose.setVisibility(View.GONE);
                } else {
                    binding.contentData.ivSearchClose.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        binding.contentData.edtSearch.setOnEditorActionListener((textView, actionId, keyEvent) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                if (!binding.contentData.edtSearch.getText().toString().isEmpty() && binding.contentData.edtSearch.getText().toString().trim().length() != 0) {
                    String strSearch = binding.contentData.edtSearch.getText().toString().trim();
                    setSearch(strSearch);
                }
                hideKeyboard(binding.contentData.edtSearch);
                return true;
            }
            return false;
        });

        binding.contentData.cameraFloatinButton.setOnClickListener(view -> {
            if (binding.contentData.viewpager.getCurrentItem() == 0)
                Dexter.withContext(this)
                        .withPermission(Manifest.permission.CAMERA)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse response) {
                                openCamera();
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse response) {
                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                                token.continuePermissionRequest();
                            }
                        }).check();
            else {
                ChooseFolderDialog albumDialog = new ChooseFolderDialog(this, selectPath -> {
                    showCreateDialog(selectPath);
                });
                albumDialog.show();
            }
        });

        binding.drawerContent.layPhotos.setOnClickListener(view -> {
            filterBy = 1;
            preferencesManager.setFilterTypePhoto(filterBy);
            RxBus.getInstance().post(new FilterSettingUpdate(true));
            binding.contentData.viewpager.setCurrentItem(0);
            binding.drawerLay.closeDrawer(GravityCompat.START);
            setTabTitle();
        });

        binding.drawerContent.layVideos.setOnClickListener(view -> {
            filterBy = 2;
            preferencesManager.setFilterTypePhoto(filterBy);
            RxBus.getInstance().post(new FilterSettingUpdate(true));
            binding.contentData.viewpager.setCurrentItem(0);
            binding.drawerLay.closeDrawer(GravityCompat.START);
            setTabTitle();
        });

        binding.drawerContent.layAlbums.setOnClickListener(view -> {
            binding.contentData.viewpager.setCurrentItem(1);
            binding.drawerLay.closeDrawer(GravityCompat.START);
        });

    }

    private void showCreateDialog(String selectPath) {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_create_album);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_ok = dialog.findViewById(R.id.btn_ok);
        TextView txt_path = dialog.findViewById(R.id.txt_path);
        EditText editText = dialog.findViewById(R.id.edtAlbumName);

        txt_path.setText(selectPath);

        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.img_newalbum);


        btn_ok.setOnClickListener(view -> {
            String albumName = editText.getText().toString().trim();
            if (!albumName.isEmpty()) {
                File file = new File(selectPath + File.separator + albumName);
                if (!file.exists()) {
                    file.mkdirs();
                    String outputPath = file.getPath() + File.separator + albumName + ".png";
                    dialog.dismiss();
                    new Thread(() -> {
                        try {
                            OutputStream fOut = null;
                            File file1 = new File(outputPath);
                            if (file1.exists()) {
                                file1.delete();// the File to save , append increasing numeric counter to prevent files from getting overwritten.
                            }
                            fOut = new FileOutputStream(file1);

                            Bitmap pictureBitmap = bitmap; // obtaining the Bitmap
                            pictureBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut); // saving the Bitmap to a file compressed as a JPEG with 85% compression rate
                            fOut.flush(); // Not really required
                            fOut.close(); // do not forget to close the stream

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        runOnUiThread(() -> {
                            ArrayList<String> list = new ArrayList<>();
                            list.add(outputPath);
                            RxBus.getInstance().post(new CopyMoveEvent(list, albumName,
                                    file.getAbsolutePath(), new ArrayList<>()));
                        });
                    }).start();
                } else
                    Toast.makeText(HomeClassicActivity.this, getString(R.string.create_validation2), Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(HomeClassicActivity.this, getString(R.string.create_validation), Toast.LENGTH_SHORT).show();

        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    private void closeSearch() {
        binding.contentData.edtSearch.getText().clear();
        hideKeyboard(binding.contentData.edtSearch);
        binding.contentData.ivSearch.setVisibility(View.VISIBLE);
        binding.contentData.ivDrawer.setVisibility(View.VISIBLE);
        binding.contentData.txtTitle.setVisibility(View.VISIBLE);
        binding.contentData.ivSearchClose.setVisibility(View.GONE);
        binding.contentData.ivBack.setVisibility(View.GONE);
        binding.contentData.loutSearch.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (binding.contentData.loutSelect.getVisibility() == View.VISIBLE)
            setClose();
        else if (binding.contentData.loutSearch.getVisibility() == View.VISIBLE)
            closeSearch();
        else if (preferencesManager.getExitDialogShow())
            showExitDialog();
        else {

//            Intent a = new Intent(Intent.ACTION_MAIN);
//            a.addCategory(Intent.CATEGORY_HOME);
//            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(a);
            finishAffinity();
            finish();
        }
    }

    private void showExitDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.exit_dialog);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView exitApp = dialog.findViewById(R.id.exitApp);
        TextView btn_cancel = dialog.findViewById(R.id.cancel);
        FrameLayout loutAds = dialog.findViewById(R.id.loutAds);

        AdmobAdManager.getInstance(this).showNativeAds(this, preferencesManager.getNativeId(), loutAds, true, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                loutAds.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {

            }

            @Override
            public void onLoadError(String errorCode) {
                loutAds.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                loutAds.setVisibility(View.VISIBLE);
            }
        });


        exitApp.setOnClickListener(view -> {
            dialog.dismiss();
//            Intent a = new Intent(Intent.ACTION_MAIN);
//            a.addCategory(Intent.CATEGORY_HOME);
//            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(a);
            finishAffinity();
            finish();
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });
        dialog.show();
    }

    private void openCamera() {
        String fileType;
        fileType = ".png";

        String dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + "Camera";
        File newdir = new File(dir);
        String time_stamp = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(System.currentTimeMillis());
        imageFilePath = newdir.getPath() + File.separator + time_stamp + fileType;
        if (!newdir.exists())
            newdir.mkdirs();
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(imageFilePath));

        try {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            captureImageActivityResultLauncher.launch(cameraIntent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, getString(R.string.not_found), Toast.LENGTH_SHORT).show();
        }

    }

    private void setSearch(String strSearch) {
        if (tabPos == 0) {
            if (photoFragment != null)
                photoFragment.setSearch(strSearch);
        } else if (tabPos == 1) {
            if (albumFragment != null)
                albumFragment.setSearch(strSearch);
        }
    }

    public void hideKeyboard(EditText view) {
        view.clearFocus();
        InputMethodManager methodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert methodManager != null;
        methodManager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    private void showKeyboard(EditText view) {
        view.requestFocus();
        InputMethodManager methodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert methodManager != null;
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
    }

    private void setClose() {
        RxBus.getInstance().post(new ImageCloseEvent(tabPos));
        binding.contentData.loutSelect.setVisibility(View.GONE);
        binding.contentData.toolbar.setVisibility(View.VISIBLE);
    }

    int sortByAlbum;
    boolean sortTypeAlbum;

    private void showSortAlbumDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_sort_album);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_apply = dialog.findViewById(R.id.btn_apply);

        RadioGroup grp_type = dialog.findViewById(R.id.grp_type);
        RadioGroup grp_sort_type = dialog.findViewById(R.id.grp_sort_type);

        RadioButton radio_name = dialog.findViewById(R.id.radio_name);
        RadioButton radio_size = dialog.findViewById(R.id.radio_size);
        RadioButton radio_date = dialog.findViewById(R.id.radio_date);
        RadioButton radio_Descending = dialog.findViewById(R.id.radio_Descending);
        RadioButton radio_Ascending = dialog.findViewById(R.id.radio_Ascending);

        sortByAlbum = preferencesManager.getSortAlbum();
        sortTypeAlbum = preferencesManager.getSortTypeAlbum();

        if (sortByAlbum == 0)
            radio_name.setChecked(true);
        else if (sortByAlbum == 1)
            radio_size.setChecked(true);
        else if (sortByAlbum == 2)
            radio_date.setChecked(true);

        if (sortTypeAlbum)
            radio_Descending.setChecked(true);
        else
            radio_Ascending.setChecked(true);

        grp_type.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.radio_name)
                sortByAlbum = 0;
            else if (i == R.id.radio_size)
                sortByAlbum = 1;
            else if (i == R.id.radio_date)
                sortByAlbum = 2;
        });

        grp_sort_type.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.radio_Descending)
                sortTypeAlbum = true;
            else if (i == R.id.radio_Ascending)
                sortTypeAlbum = false;
        });

        btn_apply.setOnClickListener(view -> {
            preferencesManager.setSortTypeAlbum(sortTypeAlbum);
            preferencesManager.setSortAlbum(sortByAlbum);
            dialog.dismiss();
            RxBus.getInstance().post(new FilterSettingUpdate(false));
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    private void setTabTitle() {
        int type = preferencesManager.getFilterTypePhoto();
        TabLayout.Tab tab = binding.contentData.tablayout.getTabAt(0);
        if (type == 0)
            tab.setText(getString(R.string.All));
        else if (type == 1)
            tab.setText(getString(R.string.Photos));
        else if (type == 2)
            tab.setText(getString(R.string.Videos));
    }


    int gridCount = 3;
    int filterBy = 0;
    int sortBy = 0;
    boolean sortType = true;

    private void showSortPhotosDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_sort);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_apply = dialog.findViewById(R.id.btn_apply);
        TextView btn_grid_one = dialog.findViewById(R.id.btn_grid_one);
        TextView btn_grid_two = dialog.findViewById(R.id.btn_grid_two);
        TextView btn_grid_three = dialog.findViewById(R.id.btn_grid_three);
        TextView btn_grid_four = dialog.findViewById(R.id.btn_grid_four);

        SwitchCompat switchShowLabel = dialog.findViewById(R.id.switch_show_label);

        TextView btnFilterAll = dialog.findViewById(R.id.btn_filter_all);
        TextView btnFilterPhotos = dialog.findViewById(R.id.btn_filter_photos);
        TextView btnFilterVideos = dialog.findViewById(R.id.btn_filter_videos);

        TextView btnSortName = dialog.findViewById(R.id.btn_sort_name);
        TextView btnSortDate = dialog.findViewById(R.id.btn_sort_date);
        TextView btnAscending = dialog.findViewById(R.id.btn_Ascending);
        TextView btnDescending = dialog.findViewById(R.id.btn_Descending);

        gridCount = preferencesManager.getGridPhoto();
        filterBy = preferencesManager.getFilterTypePhoto();
        sortBy = preferencesManager.getSortPhoto();
        sortType = preferencesManager.getSortTypePhoto();

        switchShowLabel.setChecked(preferencesManager.getLabelShow());

        if (gridCount == 1)
            selectGrid(btn_grid_one, btn_grid_two, btn_grid_three, btn_grid_four);
        else if (gridCount == 2)
            selectGrid(btn_grid_two, btn_grid_one, btn_grid_three, btn_grid_four);
        else if (gridCount == 3)
            selectGrid(btn_grid_three, btn_grid_two, btn_grid_one, btn_grid_four);
        else if (gridCount == 4)
            selectGrid(btn_grid_four, btn_grid_two, btn_grid_three, btn_grid_one);

        if (filterBy == 0)
            selectFilter(btnFilterAll, btnFilterPhotos, btnFilterVideos);
        else if (filterBy == 1)
            selectFilter(btnFilterPhotos, btnFilterAll, btnFilterVideos);
        else if (filterBy == 2)
            selectFilter(btnFilterVideos, btnFilterPhotos, btnFilterAll);

        if (sortBy == 0)
            selectSort(btnSortName, btnSortDate);
        else if (sortBy == 1)
            selectSort(btnSortDate, btnSortName);

        if (sortType)
            selectSort(btnDescending, btnAscending);
        else
            selectSort(btnAscending, btnDescending);

        btn_apply.setOnClickListener(view -> {
            preferencesManager.setFilterTypePhoto(filterBy);
            preferencesManager.setSortPhoto(sortBy);
            preferencesManager.setSortTypePhoto(sortType);
            preferencesManager.setGridPhoto(gridCount);
            preferencesManager.putLabelShow(switchShowLabel.isChecked());
            dialog.dismiss();
            setTabTitle();
            RxBus.getInstance().post(new FilterSettingUpdate(true));
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        btnFilterAll.setOnClickListener(view -> {
            filterBy = 0;
            selectFilter(btnFilterAll, btnFilterPhotos, btnFilterVideos);
        });

        btnFilterPhotos.setOnClickListener(view -> {
            filterBy = 1;
            selectFilter(btnFilterPhotos, btnFilterAll, btnFilterVideos);
        });

        btnFilterVideos.setOnClickListener(view -> {
            filterBy = 2;
            selectFilter(btnFilterVideos, btnFilterPhotos, btnFilterAll);
        });

        btn_grid_one.setOnClickListener(view -> {
            gridCount = 1;
            selectGrid(btn_grid_one, btn_grid_two, btn_grid_three, btn_grid_four);
        });

        btn_grid_two.setOnClickListener(view -> {
            gridCount = 2;
            selectGrid(btn_grid_two, btn_grid_one, btn_grid_three, btn_grid_four);
        });

        btn_grid_three.setOnClickListener(view -> {
            gridCount = 3;
            selectGrid(btn_grid_three, btn_grid_two, btn_grid_one, btn_grid_four);
        });

        btn_grid_four.setOnClickListener(view -> {
            gridCount = 4;
            selectGrid(btn_grid_four, btn_grid_two, btn_grid_three, btn_grid_one);
        });

        btnSortName.setOnClickListener(view -> {
            sortBy = 0;
            selectSort(btnSortName, btnSortDate);
        });
        btnSortDate.setOnClickListener(view -> {
            sortBy = 1;
            selectSort(btnSortDate, btnSortName);
        });

        btnDescending.setOnClickListener(view -> {
            sortType = true;
            selectSort(btnDescending, btnAscending);
        });
        btnAscending.setOnClickListener(view -> {
            sortType = false;
            selectSort(btnAscending, btnDescending);
        });

        dialog.show();
    }

    private void selectSort(TextView btnSortName, TextView btnSortDate) {
        btnSortName.setTextColor(ContextCompat.getColor(this, R.color.white));
        btnSortDate.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));

        btnSortName.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box_select));
        btnSortDate.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));

    }

    private void selectFilter(TextView btnFilterAll, TextView btnFilterPhotos, TextView btnFilterVideos) {
        btnFilterAll.setTextColor(ContextCompat.getColor(this, R.color.white));
        btnFilterPhotos.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btnFilterVideos.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));

        btnFilterAll.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box_select));
        btnFilterPhotos.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
        btnFilterVideos.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
    }

    private void selectGrid(TextView btn_grid_one, TextView btn_grid_two, TextView btn_grid_three, TextView btn_grid_four) {
        btn_grid_one.setTextColor(ContextCompat.getColor(this, R.color.white));
        btn_grid_two.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btn_grid_three.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));
        btn_grid_four.setTextColor(ContextCompat.getColor(this, R.color.gray_sub_title));

        btn_grid_one.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box_select));
        btn_grid_two.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
        btn_grid_three.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
        btn_grid_four.setBackground(ContextCompat.getDrawable(this, R.drawable.filter_option_box));
    }

    private void showImageCount() {
        if (binding.contentData.viewpager.getCurrentItem() == 0)
            binding.contentData.cameraFloatinButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.icn_camera));
        else
            binding.contentData.cameraFloatinButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_add));

        if (photoFragment != null) {
            binding.drawerContent.txtDrawerPhoto.setText(photoFragment.imageCount + "");
            binding.drawerContent.txtDrawerVideos.setText(photoFragment.videoCount + "");
        }
        if (albumFragment != null)
            binding.drawerContent.txtDrawerAlbum.setText(albumFragment.albumCount + "");
    }

    private void showCount() {
        Subscription subscription = RxBus.getInstance().toObservable(CountShowEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<CountShowEvent>() {
            @Override
            public void call(CountShowEvent event) {
                showImageCount();
                if (photoFragment != null)
                    if (photoFragment.pictures != null && photoFragment.pictures.size() != 0)
                        try {
                            if (photoFragment.pictures.get(1) instanceof PictureData) {
                                PictureData pictureData = (PictureData) photoFragment.pictures.get(1);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    @Override
    public void longClick(boolean isShowToolbar, boolean isShowSelected, int selected, long size) {
        if (isShowToolbar) {
            binding.contentData.toolbar.setVisibility(View.VISIBLE);
        } else {
            binding.contentData.toolbar.setVisibility(View.GONE);
        }

        if (isShowSelected) {
            binding.contentData.loutSelect.setVisibility(View.VISIBLE);
        } else {
            binding.contentData.loutSelect.setVisibility(View.GONE);
        }
        binding.contentData.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.contentData.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
        if (size == 0)
            isSelectAll = false;
    }

    private class HomePagerAdapter extends FragmentPagerAdapter {
        PhotoFragment pictureFragment;
        AlbumFragment albumFragment;
        int size = 0;

        public HomePagerAdapter(@NonNull FragmentManager fm, int size, PhotoFragment pictureFragment, AlbumFragment albumFragment) {
            super(fm);
            this.pictureFragment = pictureFragment;
            this.albumFragment = albumFragment;
            this.size = size;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            if (position == 0)
                return pictureFragment;
            else if (position == 1)
                return albumFragment;
            return pictureFragment;
        }

        @Override
        public int getCount() {
            return size;
        }
    }
}