package com.photo.video.vault.gallery.ads;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AdsResponse {
    @SerializedName("success")
    @Expose
    private Integer success;
    @SerializedName("newversion")
    @Expose
    private String newversion;
    @SerializedName("newappurl")
    @Expose
    private String newappurl;
    @SerializedName("app_id_ad_unit_id")
    @Expose
    private String appIdAdUnitId;
    @SerializedName("banner")
    @Expose
    private String banner;
    @SerializedName("bannermain")
    @Expose
    private String bannermain;
    @SerializedName("bannermains")
    @Expose
    private String bannermains;
    @SerializedName("bannermainr")
    @Expose
    private String bannermainr;
    @SerializedName("bannermainrs")
    @Expose
    private String bannermainrs;
    @SerializedName("interstitial")
    @Expose
    private String interstitial;
    @SerializedName("interstitialmain")
    @Expose
    private String interstitialmain;
    @SerializedName("interstitialmains")
    @Expose
    private String interstitialmains;
    @SerializedName("interstitialmainr")
    @Expose
    private String interstitialmainr;
    @SerializedName("splash")
    @Expose
    private String splash;
    @SerializedName("interstitialsplashid")
    @Expose
    private String interstitialsplashid;
    @SerializedName("openapp_ads_enabled")
    @Expose
    private String openappAdsEnabled;
    @SerializedName("openappid")
    @Expose
    private String openappid;
    @SerializedName("native_ads_enabled")
    @Expose
    private String nativeAdsEnabled;
    @SerializedName("native")
    @Expose
    private String _native;
    @SerializedName("nativeid")
    @Expose
    private String nativeid;
    @SerializedName("nativeidd")
    @Expose
    private String nativeidd;
    @SerializedName("NATIVE_ADS_FREQUENCY")
    @Expose
    private Integer nativeAdsFrequency;
    @SerializedName("NATIVE_ADS_FREQUENCY_MAX")
    @Expose
    private Integer nativeAdsFrequencyMax;
    @SerializedName("ADMOB_INTERSTITIAL_FREQUENCY")
    @Expose
    private Integer admobInterstitialFrequency;
    @SerializedName("ADMOB_INTERSTITIAL_FREQUENCY_PHOTO")
    @Expose
    private Integer admobInterstitialFrequencyPhoto;
    @SerializedName("rd")
    @Expose
    private Integer rd;
    @SerializedName("interstitialsplash")
    @Expose
    private String interstitialsplash;
    @SerializedName("vpn")
    @Expose
    private String vpn;
    @SerializedName("WHATSAPP_SHARE_FREQUENCY")
    @Expose
    private Integer whatsappShareFrequency;
    @SerializedName("startclicktext")
    @Expose
    private String startclicktext;
    @SerializedName("startvisible")
    @Expose
    private Integer startvisible;
    @SerializedName("skipfirstscreen")
    @Expose
    private Integer skipfirstscreen;
    @SerializedName("message")
    @Expose
    private String message;

    public Integer getSuccess() {
        return success;
    }

    public void setSuccess(Integer success) {
        this.success = success;
    }

    public String getNewversion() {
        return newversion;
    }

    public void setNewversion(String newversion) {
        this.newversion = newversion;
    }

    public String getNewappurl() {
        return newappurl;
    }

    public void setNewappurl(String newappurl) {
        this.newappurl = newappurl;
    }

    public String getAppIdAdUnitId() {
        return appIdAdUnitId;
    }

    public void setAppIdAdUnitId(String appIdAdUnitId) {
        this.appIdAdUnitId = appIdAdUnitId;
    }

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    public String getBannermain() {
        return bannermain;
    }

    public void setBannermain(String bannermain) {
        this.bannermain = bannermain;
    }

    public String getBannermains() {
        return bannermains;
    }

    public void setBannermains(String bannermains) {
        this.bannermains = bannermains;
    }

    public String getBannermainr() {
        return bannermainr;
    }

    public void setBannermainr(String bannermainr) {
        this.bannermainr = bannermainr;
    }

    public String getBannermainrs() {
        return bannermainrs;
    }

    public void setBannermainrs(String bannermainrs) {
        this.bannermainrs = bannermainrs;
    }

    public String getInterstitial() {
        return interstitial;
    }

    public void setInterstitial(String interstitial) {
        this.interstitial = interstitial;
    }

    public String getInterstitialmain() {
        return interstitialmain;
    }

    public void setInterstitialmain(String interstitialmain) {
        this.interstitialmain = interstitialmain;
    }

    public String getInterstitialmains() {
        return interstitialmains;
    }

    public void setInterstitialmains(String interstitialmains) {
        this.interstitialmains = interstitialmains;
    }

    public String getInterstitialmainr() {
        return interstitialmainr;
    }

    public void setInterstitialmainr(String interstitialmainr) {
        this.interstitialmainr = interstitialmainr;
    }

    public String getSplash() {
        return splash;
    }

    public void setSplash(String splash) {
        this.splash = splash;
    }

    public String getInterstitialsplashid() {
        return interstitialsplashid;
    }

    public void setInterstitialsplashid(String interstitialsplashid) {
        this.interstitialsplashid = interstitialsplashid;
    }

    public String getOpenappAdsEnabled() {
        return openappAdsEnabled;
    }

    public void setOpenappAdsEnabled(String openappAdsEnabled) {
        this.openappAdsEnabled = openappAdsEnabled;
    }

    public String getOpenappid() {
        return openappid;
    }

    public void setOpenappid(String openappid) {
        this.openappid = openappid;
    }

    public String getNativeAdsEnabled() {
        return nativeAdsEnabled;
    }

    public void setNativeAdsEnabled(String nativeAdsEnabled) {
        this.nativeAdsEnabled = nativeAdsEnabled;
    }

    public String getNative() {
        return _native;
    }

    public void setNative(String _native) {
        this._native = _native;
    }

    public String getNativeid() {
        return nativeid;
    }

    public void setNativeid(String nativeid) {
        this.nativeid = nativeid;
    }

    public String getNativeidd() {
        return nativeidd;
    }

    public void setNativeidd(String nativeidd) {
        this.nativeidd = nativeidd;
    }

    public Integer getNativeAdsFrequency() {
        return nativeAdsFrequency;
    }

    public void setNativeAdsFrequency(Integer nativeAdsFrequency) {
        this.nativeAdsFrequency = nativeAdsFrequency;
    }

    public Integer getNativeAdsFrequencyMax() {
        return nativeAdsFrequencyMax;
    }

    public void setNativeAdsFrequencyMax(Integer nativeAdsFrequencyMax) {
        this.nativeAdsFrequencyMax = nativeAdsFrequencyMax;
    }

    public Integer getAdmobInterstitialFrequency() {
        return admobInterstitialFrequency;
    }

    public void setAdmobInterstitialFrequency(Integer admobInterstitialFrequency) {
        this.admobInterstitialFrequency = admobInterstitialFrequency;
    }

    public Integer getAdmobInterstitialFrequencyPhoto() {
        return admobInterstitialFrequencyPhoto;
    }

    public void setAdmobInterstitialFrequencyPhoto(Integer admobInterstitialFrequencyPhoto) {
        this.admobInterstitialFrequencyPhoto = admobInterstitialFrequencyPhoto;
    }

    public Integer getRd() {
        return rd;
    }

    public void setRd(Integer rd) {
        this.rd = rd;
    }

    public String getInterstitialsplash() {
        return interstitialsplash;
    }

    public void setInterstitialsplash(String interstitialsplash) {
        this.interstitialsplash = interstitialsplash;
    }

    public String getVpn() {
        return vpn;
    }

    public void setVpn(String vpn) {
        this.vpn = vpn;
    }

    public Integer getWhatsappShareFrequency() {
        return whatsappShareFrequency;
    }

    public void setWhatsappShareFrequency(Integer whatsappShareFrequency) {
        this.whatsappShareFrequency = whatsappShareFrequency;
    }

    public String getStartclicktext() {
        return startclicktext;
    }

    public void setStartclicktext(String startclicktext) {
        this.startclicktext = startclicktext;
    }

    public Integer getStartvisible() {
        return startvisible;
    }

    public void setStartvisible(Integer startvisible) {
        this.startvisible = startvisible;
    }

    public Integer getSkipfirstscreen() {
        return skipfirstscreen;
    }

    public void setSkipfirstscreen(Integer skipfirstscreen) {
        this.skipfirstscreen = skipfirstscreen;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
