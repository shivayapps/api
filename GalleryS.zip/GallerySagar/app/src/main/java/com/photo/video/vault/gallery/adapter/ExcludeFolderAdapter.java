package com.photo.video.vault.gallery.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.vault.gallery.R;

import java.io.File;
import java.util.ArrayList;

public class ExcludeFolderAdapter extends RecyclerView.Adapter<ExcludeFolderAdapter.ViewHolder> {

    FragmentActivity activity;
    ArrayList<String> folderList;
    OnSelectAlbum onSelectAlbum;

    public ExcludeFolderAdapter(FragmentActivity activity, ArrayList<String> albums, OnSelectAlbum onSelectAlbum) {
        this.activity = activity;
        this.onSelectAlbum = onSelectAlbum;
        this.folderList = albums;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(activity).inflate(R.layout.item_exclude_folder, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        File file = new File(folderList.get(position));
        holder.txt_folder_path.setText(file.getPath());
        holder.txt_folder_name.setText(file.getName());
        holder.ic_close.setOnClickListener(view -> {
            onSelectAlbum.onClickAlbum(position);
        });
    }

    @Override
    public int getItemCount() {
        return folderList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_folder_name;
        TextView txt_folder_path;
        ImageView ic_close;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ic_close = itemView.findViewById(R.id.ic_close);
            txt_folder_name = itemView.findViewById(R.id.txt_folder_name);
            txt_folder_path = itemView.findViewById(R.id.txt_folder_path);
        }
    }

    public interface OnSelectAlbum {
        void onClickAlbum(int pos);
    }
}
