package com.photo.video.vault.gallery.event;

public class EditImageEvent {

//    String imagePath;
//    String folderName;
//    public EditImageEvent(String imagePath, String folderName) {
//
//        this.imagePath = imagePath;
//        this.folderName = folderName;
//    }
//
//    public String getFolderName() {
//        return folderName;
//    }
//
//    public void setFolderName(String folderName) {
//        this.folderName = folderName;
//    }
//
//    public String getImagePath() {
//        return imagePath;
//    }
//
//    public void setImagePath(String imagePath) {
//        this.imagePath = imagePath;
//    }
}
