package com.photo.video.vault.gallery.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;

import com.photo.video.vault.gallery.ads.AdEventListener;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.databinding.ActivityLockSettingBinding;
import com.photo.video.vault.gallery.preferences.PreferencesManager;

public class LockSettingActivity extends AppCompatActivity {

    ActivityLockSettingBinding binding;
    PreferencesManager preferencesManager;
    boolean isFromSetting = false;
    ActivityResultLauncher<Intent> lockActivityResultLauncher;
    BiometricManager biometricManager;
    AdmobAdManager admobAdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLockSettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();
    }

    private void intView() {
        admobAdManager = AdmobAdManager.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        isFromSetting = getIntent().getBooleanExtra("IsFromSetting", false);
        biometricManager = BiometricManager.from(LockSettingActivity.this);
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
        });
        setLockData();
        setClickListener();
        setActivityResultLauncher();
        loadNativeBanner();
    }

    @Override
    public void onBackPressed() {
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
            finish();
        });
    }

    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, preferencesManager.getNativeId(), binding.loutBanner, true, false, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setActivityResultLauncher() {
        lockActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        setLockData();
                    } else {
                        binding.switchPin.setChecked(false);
                        binding.switchLock.setChecked(false);
                        binding.switchLockGalleryApp.setChecked(false);
                        binding.switchFingerprint.setChecked(false);
                        preferencesManager.putSetPass(false);
                        preferencesManager.putSetLockApp(false);
                        preferencesManager.putFingerprint(false);
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
//        setLockData();

    }

    private void setLockData() {
        binding.switchLock.setChecked(preferencesManager.getSetPass());
        binding.switchPin.setChecked(preferencesManager.getSetPass());
        binding.switchFingerprint.setChecked(preferencesManager.getFingerprint());

        binding.switchLockGalleryApp.setChecked(preferencesManager.getSetLockApp());
        boolean isBiometricFeatureAvailable = biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        if (preferencesManager.getSetPass()) {
            binding.btnChangePassword.setVisibility(View.VISIBLE);
        } else
            binding.btnChangePassword.setVisibility(View.GONE);

        if (isBiometricFeatureAvailable)
            binding.btnFingerprint.setVisibility(View.VISIBLE);
        else
            binding.btnFingerprint.setVisibility(View.GONE);

    }

    private void setClickListener() {
        binding.ivBack.setOnClickListener(view -> {
            onBackPressed();
        });

        binding.switchLock.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed())
                setLockSwitch(isChecked, true);
        });

        binding.switchPin.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed())
                setLockSwitch(isChecked, false);
        });

        binding.switchFingerprint.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed())
                setFingerprintLockSwitch(isChecked, binding.switchLock.isChecked());
        });

        binding.switchLockGalleryApp.setOnCheckedChangeListener((buttonView, isChecked) -> {
            preferencesManager.putSetLockApp(isChecked);
            if (buttonView.isPressed()) {
                if (!binding.switchLock.isChecked() && isChecked) {
                    binding.switchPin.setChecked(true);
                    binding.switchLock.setChecked(true);
                    lockActivityResultLauncher.launch(new Intent(LockSettingActivity.this, PasswordActivity.class));
                }
            }
        });

        binding.btnChangePassword.setOnClickListener(view -> {
            admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
                Intent intent = new Intent(this, QuestionActivity.class);
                intent.putExtra("type", 1);
                intent.putExtra("isOpenPrivate", false);
                startActivity(intent);
            });
        });

    }

    private void setFingerprintLockSwitch(boolean isChecked, boolean isLock) {
        preferencesManager.putFingerprint(isChecked);
        if (!isLock) {
            lockActivityResultLauncher.launch(new Intent(LockSettingActivity.this, PasswordActivity.class));
        }
    }

    private void setLockSwitch(boolean isChecked, boolean isLock) {
        if (isLock)
            binding.switchPin.setChecked(isChecked);
        else
            binding.switchLock.setChecked(isChecked);

        if (isChecked) {
            binding.switchLockGalleryApp.setChecked(true);
            lockActivityResultLauncher.launch(new Intent(LockSettingActivity.this, PasswordActivity.class));
        } else {
            preferencesManager.putSetPass(false);
            binding.switchLockGalleryApp.setChecked(false);
            binding.switchFingerprint.setChecked(false);
        }
    }
}