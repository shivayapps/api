package com.photo.video.vault.gallery.event;

import java.util.ArrayList;

public class DisplayUnFavoriteEvent {
    ArrayList<String> deleteList = new ArrayList<>();

    public DisplayUnFavoriteEvent(ArrayList<String> deleteList) {
        this.deleteList = deleteList;
    }

    public ArrayList<String> getDeleteList() {
        return deleteList;
    }

    public void setDeleteList(ArrayList<String> deleteList) {
        this.deleteList = deleteList;
    }
}
