package com.photo.video.vault.gallery.activity;

import static android.os.Build.VERSION.SDK_INT;

import static com.photo.video.vault.gallery.utils.Constant.HIDE_PATH;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.BaseColumns;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.appbar.AppBarLayout;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.adapter.PictureAdapter;
import com.photo.video.vault.gallery.ads.AdEventListener;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.database.Database;
import com.photo.video.vault.gallery.databinding.ActivityAlbumImageBinding;
import com.photo.video.vault.gallery.databinding.DialogMoveVersion11Binding;
import com.photo.video.vault.gallery.dialog.SelectAlbumDialog;
import com.photo.video.vault.gallery.event.AlbumDataEvent;
import com.photo.video.vault.gallery.event.CopyMoveEvent;
import com.photo.video.vault.gallery.event.DeleteEvent;
import com.photo.video.vault.gallery.event.DisplayDeleteEvent;
import com.photo.video.vault.gallery.model.AlbumData;
import com.photo.video.vault.gallery.model.PictureData;
import com.photo.video.vault.gallery.model.RenameEvent;
import com.photo.video.vault.gallery.model.RenameModel;
import com.photo.video.vault.gallery.preferences.PreferencesManager;
import com.photo.video.vault.gallery.rx.RxBus;
import com.photo.video.vault.gallery.utils.Constant;
import com.photo.video.vault.gallery.utils.CreateFile;
import com.photo.video.vault.gallery.utils.StorageUtils;
import com.photo.video.vault.gallery.utils.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import io.reactivex.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class AlbumImageActivity extends AppCompatActivity {

    ActivityAlbumImageBinding binding;
    ArrayList<Object> pictures = new ArrayList<>();
    //    ArrayList<Object> pictureData = new ArrayList<>();
    ArrayList<PictureData> allList = new ArrayList<>();
    ArrayList<PictureData> filterList = new ArrayList<>();
    private PictureAdapter pictureAdapter;
    private ProgressDialog loadingDialog;
    AlbumData albumData;
    int selected_Item = 0;
    int gridCount = 3;
    int filterBy = 0;
    int sortBy = 0;
    boolean sortType = true, isShowLabel = false;
    boolean isSelectAll = false;
    private final int DELETE_FILE = 3;
    private final int Hide_FILE = 1001;
    Database database;
    private int REQUEST_HIDE_PERMISSION = 5555;
    PreferencesManager preferencesManager;
    AdmobAdManager admobAdManager;
    int appBarType = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            getWindow().setStatusBarColor(Color.TRANSPARENT);
//        }
//        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        binding = ActivityAlbumImageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        albumData = Constant.albumData;
        Constant.albumData = null;
        if (albumData != null) {
            binding.txtSelection.setText(Objects.requireNonNull(albumData).getTitle());
            allList.addAll(albumData.getPictureData());
            binding.txtItemCounts.setText(allList.size() + " " + getString(R.string.Items));
        }

        intView();
        renameEvent();
        DeleteEvent();
        DisplayDeleteEvent();
    }

    private void intView() {
        admobAdManager = AdmobAdManager.getInstance(this);
        preferencesManager = PreferencesManager.getInstance(this);
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 1, () -> {
        });
        database = new Database(requireActivity());
        sortBy = preferencesManager.getSortPhoto();
        sortType = preferencesManager.getSortTypePhoto();
        getData();
        initListener();
        loadNativeBanner();
        binding.swipeRefreshLayout.setOnRefreshListener(() -> {
            getData();
        });

        int statusHeight = getStatusBarHeight(this);
        binding.loutSelect.setPadding(0, statusHeight, 0, 0);
        binding.loutSelect.requestLayout();

        binding.demoAppBar.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (verticalOffset == 0) {
                    //Expanded
                    if (appBarType != 0) {
                        appBarType = 0;
                        setStatusBar();
                    }
                } else if (Math.abs(verticalOffset) >= appBarLayout.getTotalScrollRange()) {
                    //  Collapsed
                    if (appBarType != 1) {
                        appBarType = 1;
                        setStatusBar();
                    }
                } else {
                    if (appBarType != 1) {
                        appBarType = 1;
                        setStatusBar();
                    }
                }
            }
        });
    }


    private void loadNativeBanner() {
        admobAdManager.showNativeAds(this, preferencesManager.getNativeId(), binding.loutBanner, false, true, new AdEventListener() {
            @Override
            public void onAdLoaded() {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                binding.loutBanner.setVisibility(View.GONE);
            }

            @Override
            public void onAdLoaded(Object object) {
                binding.loutBanner.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setStatusBar() {
        if (appBarType == 0)
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        else
            getWindow().setStatusBarColor(ContextCompat.getColor(AlbumImageActivity.this, R.color.black));
    }

    public int getStatusBarHeight(final Context context) {
        final Resources resources = context.getResources();
        final int resourceId = resources.getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0)
            return resources.getDimensionPixelSize(resourceId);
        else
            return (int) Math.ceil((Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? 24 : 25) * resources.getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (binding.loutSelect.getVisibility() == View.VISIBLE)
            setClose();
        else
            admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId(), 0, () -> {
                finish();
            });
    }

    private void initListener() {
        binding.ivBack.setOnClickListener(v -> onBackPressed());
        binding.ivClose.setOnClickListener(v -> {
            setClose();
        });

        binding.ivDelete.setOnClickListener(view -> {
            if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                deleteFileOnAboveQ();
            } else
                showDeleteDialog();
        });

        binding.ivShare.setOnClickListener(view -> {
            setShare();

        });

        binding.ivMenuSelect.setOnClickListener(view -> {
            PopupMenu popup = new PopupMenu(AlbumImageActivity.this, view);
            popup.getMenuInflater().inflate(R.menu.menu_select_option, popup.getMenu());
            if (isSelectAll)
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.DeselectAll));
            else
                popup.getMenu().findItem(R.id.nav_select).setTitle(getString(R.string.SelectAll));
            popup.show();

            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.nav_move_private) {
                    if (preferencesManager.getSetPass()) {
                        showHideDialog();
                    } else
                        startActivity(new Intent(getActivity(), LockSettingActivity.class).putExtra("IsFromSetting", false));
                } else if (item.getItemId() == R.id.nav_move) {
                    setCopyMove("move");
                } else if (item.getItemId() == R.id.nav_copy) {
                    setCopyMove("copy");
                } else if (item.getItemId() == R.id.nav_select) {
                    if (isSelectAll)
                        isSelectAll = false;
                    else
                        isSelectAll = true;
                    setAllSelecte();
                }
                return true;
            });
        });
    }

    private void setCopyMove(String type) {
        RxBus.getInstance().post(new AlbumDataEvent());
        ArrayList<PictureData> selectImage = new ArrayList<>();
        for (int i = 0; i < pictures.size(); i++) {
            if (pictures.get(i) != null)
                if (pictures.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) pictures.get(i);
                    if (model.isSelected()) {
                        selectImage.add(model);
                    }
                }
        }
        showAlbumSelectDialog(type, selectImage);
    }

    private void setShare() {
        ArrayList<Uri> uris = new ArrayList<>();
        Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
        for (int i = 0; i < pictures.size(); i++) {
            if (pictures.get(i) != null)
                if (pictures.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) pictures.get(i);
                    if (model.isSelected()) {
                        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(model.getFilePath()));
                        uris.add(uri);
                    }
                }
        }
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityForResult(Intent.createChooser(intent, getActivity().getString(R.string.share_with)), 909);
//        startActivity(Intent.createChooser(intent, getString(R.string.share_with)));
//        setClose();
    }

    private void setAllSelecte() {
        if (isSelectAll) {
            int selected = 0;
            long size = 0;
            for (int i = 0; i < pictures.size(); i++) {
                if (pictures.get(i) != null)
                    if (pictures.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) pictures.get(i);
                        selected++;
                        size += model.getFileSize();
                        model.setSelected(true);
                    }
            }
            if (pictureAdapter != null)
                pictureAdapter.notifyDataSetChanged();
            longClick(false, true, selected, size);
            selected_Item = selected;
        } else {
            setClose();
        }
    }

    private void showAlbumSelectDialog(String type, ArrayList<PictureData> selectImage) {
        SelectAlbumDialog albumDialog = new SelectAlbumDialog(this, type, Constant.albumList, selectPath -> {
            if (type.equals("copy")) {
                copyFiles(selectPath, selectImage);
            } else if (type.equals("move")) {
                moveFiles(selectPath, selectImage);
            }
        });
        albumDialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2222 && resultCode == RESULT_OK) {
            ArrayList<String> deleteList = new ArrayList<>();
            deleteList.addAll(getDeleteListOnResult());


            runOnUiThread(() -> {
                RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                selected_Item = 0;
                longClick(true, false, 0, 0);
                pictureAdapter.notifyDataSetChanged();
                setEmptyData();
                Toast.makeText(getActivity(), getActivity().getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
                deleteMainList(deleteList);

                binding.txtItemCounts.setText(allList.size() + " " + getString(R.string.Items));
                setAlbumImage();
                if (pictures.size() == 0)
                    if (albumData.getFolderPath() != null) {
                        File file = new File(albumData.getFolderPath());
                        file.delete();
                        MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{albumData.getFolderPath()}, null, (path, uri) -> {
                        });
                    }
            });
        } else if (requestCode == DELETE_FILE) {
            if (resultCode == RESULT_OK) {
                removeFiles(deleteFilePaths);
                Toast.makeText(requireActivity(), getString(R.string.move_successfully), Toast.LENGTH_SHORT).show();
                RxBus.getInstance().post(new CopyMoveEvent(moveFiles, moveFolder.getName(),
                        moveFolder.getAbsolutePath(), deleteFilePaths));
            } else {
                RxBus.getInstance().post(new CopyMoveEvent(moveFiles, moveFolder.getName(),
                        moveFolder.getAbsolutePath(), new ArrayList<>()));
            }
            selected_Item = 0;
            longClick(true, false, 0, 0);
            setClose();
            setAlbumImage();
        } else if (requestCode == Hide_FILE) {
            if (resultCode == RESULT_OK) {
                setDeleteRBeforeMovePrivate();
                setAlbumImage();
            }
        }

        if (requestCode == REQUEST_HIDE_PERMISSION) {
            if (resultCode == RESULT_OK && data != null) {
                Uri treeUri = data.getData();
                requireActivity().getContentResolver().takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                );
                preferencesManager.putHideUri(treeUri.toString());
                hideMedia();
            }
        }

        if (requestCode == 909) {
            setClose();
            longClick(true, false, 0, 0);
        }
    }

    private void removeFiles(ArrayList<String> deleteFilePaths) {
        for (String deleteFilePath : deleteFilePaths) {
            for (int i = 0; i < pictures.size(); i++) {
                if (pictures.get(i) != null)
                    if (pictures.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) pictures.get(i);
                        if (model.getFilePath().equalsIgnoreCase(deleteFilePath)) {
                            boolean isPre = false, isNext = false;

                            if (i != 0) {
                                if (pictures.get(i - 1) instanceof AlbumData) {
                                    isPre = true;
                                } else {
                                    isPre = false;
                                }
                            }

                            if (i < (pictures.size() - 2)) {
                                if (pictures.get(i + 1) instanceof AlbumData) {
                                    isNext = true;
                                } else {
                                    isNext = false;
                                }
                            }

                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                pictures.remove(i);
                                pictures.remove(i - 1);

                            } else if (i == (pictures.size() - 1)) {
                                pictures.remove(i);
                                if (isPre) {
                                    pictures.remove(i - 1);
                                }
                            } else {
                                pictures.remove(i);
                            }

//                            if (i != 0) {
//                                i--;
//                            }
                            break;
                        }
                    }
            }
        }

        deleteMainList(deleteFilePaths);

    }

    private void renameEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(RenameEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<RenameEvent>() {
            @Override
            public void call(RenameEvent event) {
                ArrayList<RenameModel> renameList = event.getRenameModels();
                if (renameList != null && renameList.size() != 0) {
                    for (RenameModel renameModel : renameList) {
                        if (renameModel.getRenameFile().exists()) {
                            for (int i = 0; i < pictures.size(); i++) {
                                if (pictures.get(i) != null)
                                    if (pictures.get(i) instanceof PictureData) {
                                        PictureData model = (PictureData) pictures.get(i);
                                        if (model.getFilePath().equalsIgnoreCase(renameModel.getOldFile().getPath())) {
                                            model.setFolderPath(renameModel.getRenameFile().getPath());
                                            model.setFileName(renameModel.getRenameFile().getName());
                                            break;
                                        }
                                    }
                            }
                            for (PictureData model : filterList) {
                                if (model.getFilePath().equalsIgnoreCase(renameModel.getOldFile().getPath())) {
                                    model.setFolderPath(renameModel.getRenameFile().getPath());
                                    model.setFileName(renameModel.getRenameFile().getName());
                                    break;
                                }
                            }

                            for (PictureData model : allList) {
                                if (model.getFilePath().equalsIgnoreCase(renameModel.getOldFile().getPath())) {
                                    model.setFolderPath(renameModel.getRenameFile().getPath());
                                    model.setFileName(renameModel.getRenameFile().getName());
                                    break;
                                }
                            }
                        }
                    }

                    requireActivity().runOnUiThread(() -> {
                        if (pictureAdapter != null)
                            pictureAdapter.notifyDataSetChanged();
                        else
                            initAdapter();
                    });
                }
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void DisplayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(event -> {
            if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                ArrayList<String> deleteList;
                deleteList = event.getDeleteList();
                deleteMainList(deleteList);
                UpdateDeleteImageData(deleteList);

                if (pictures.size() == 0)
                    if (albumData.getFolderPath() != null) {
                        File file = new File(albumData.getFolderPath());
                        file.delete();
                        MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{albumData.getFolderPath()}, null, (path, uri) -> {
                        });
                    }
            }
        }, throwable -> {
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void DeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DeleteEvent>() {
            @Override
            public void call(DeleteEvent event) {
                if (event.getPos() != 0) {
                    if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                        ArrayList<String> deleteList = new ArrayList<>();
                        deleteList = event.getDeleteList();
                        deleteMainList(deleteList);
                        UpdateDeleteImageData(deleteList);

                        if (pictures.size() == 0)
                            if (albumData.getFolderPath() != null) {
                                File file = new File(albumData.getFolderPath());
                                file.delete();
                                MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{albumData.getFolderPath()}, null, (path, uri) -> {
                                });
                            }
                    }
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }


    private void UpdateDeleteImageData(ArrayList<String> deleteList) {
        if (pictures != null && pictures.size() != 0) {
            for (int d = 0; d < deleteList.size(); d++) {
                for (int i = 0; i < pictures.size(); i++) {
                    if (pictures.get(i) instanceof PictureData) {
                        PictureData model = (PictureData) pictures.get(i);
                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {
                            boolean isPre = false, isNext = false;
                            if (i != 0) {
                                isPre = pictures.get(i - 1) instanceof AlbumData;
                            }
                            if (i < (pictures.size() - 2)) {
                                isNext = pictures.get(i + 1) instanceof AlbumData;
                            }
                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                pictures.remove(i);
                                pictures.remove(i - 1);

                            } else if (i == (pictures.size() - 1)) {
                                pictures.remove(i);
                                if (isPre) {
                                    pictures.remove(i - 1);
                                }
                            } else {
                                pictures.remove(i);
                            }
                            if (i != 0) {
                                i--;
                            }
                            if (d == deleteList.size() - 1) {
                                break;
                            }
                        }
                    }
                }
            }
            if (pictureAdapter != null) {
                pictureAdapter.notifyDataSetChanged();
            }
            setEmptyData();
        }
    }

    private void showHideDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle(R.string.Are_you_sure_want_to_lock_this);
        builder.setMessage(R.string.lock_msg);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.action_lock, (dialog, which) -> {
            dialog.dismiss();
            hideMedia();
        });
        builder.setNegativeButton(getString(R.string.action_Cancel), (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(this, R.color.gray_600));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(this, R.color.theme_color));
    }

    private void setDeleteRBeforeMovePrivate() {
        ArrayList<String> deleteList = new ArrayList<>();
        deleteList.addAll(getDeleteListOnResult());

        requireActivity().runOnUiThread(() -> {
            RxBus.getInstance().post(new DeleteEvent(1, deleteList));
            selected_Item = 0;
            longClick(true, false, 0, 0);
            pictureAdapter.notifyDataSetChanged();
            setEmptyData();
            deleteMainList(deleteList);
        });
    }


    private void hideMedia() {
        if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
            File file = new File(HIDE_PATH);
            if (!file.exists()) {
                file.mkdirs();
            }
            String hidden_URI = preferencesManager.getHideUri();
            if (!hidden_URI.equals("") && hidden_URI != null && hidden_URI.endsWith(Constant.HIDE_FOLDER_NAME)) {
                new Thread(() -> moveToPrivateAboveR()).start();
            } else {
                askPermissionHideUri();
            }
        } else
            moveToPrivate();
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void askPermissionHideUri() {
        File f = new File(Constant.HIDE_PATH);
        if (f.exists() && f.isDirectory()) {
            if (preferencesManager.getHideUri() == null || preferencesManager.getHideUri() == "" || !preferencesManager.getHideUri().endsWith(Constant.HIDE_FOLDER_NAME)) {
                askPermission(requireActivity(), "Pictures%2F" + Constant.HIDE_FOLDER_NAME);
            }
        } else {
            boolean success = f.mkdir();
            if (success) {
                if (f.exists() && f.isDirectory()) {
                    if (preferencesManager.getHideUri() == null || preferencesManager.getHideUri() == "" || !preferencesManager.getHideUri().endsWith(Constant.HIDE_FOLDER_NAME)) {
                        askPermission(requireActivity(), "Pictures%2F" + Constant.HIDE_FOLDER_NAME);
                    }
                }
            }
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void askPermission(Activity context, String targetDirectory) {
        StorageManager storageManager = (StorageManager) context.getSystemService(STORAGE_SERVICE);
        Intent intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
        Uri uri = intent.getParcelableExtra("android.provider.extra.INITIAL_URI");
        String scheme = uri.toString();
        scheme = scheme.replace("/root/", "/document/");
        targetDirectory = targetDirectory.replace("/", "%2F");
        scheme += "%3A$targetDirectory";
        uri = Uri.parse(scheme);
        Log.e("uri", "3 ==> $uri");
        intent.putExtra("android.provider.extra.INITIAL_URI", uri);
        startActivityForResult(intent, REQUEST_HIDE_PERMISSION);
        Log.e("come", "==> at askPermission;");
    }

    private void showDeleteDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_delete);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_delete = dialog.findViewById(R.id.btn_delete);

        btn_delete.setOnClickListener(view -> {
            dialog.dismiss();
            deletePhoto();
        });

        btn_cancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    private void deleteMainList(ArrayList<String> deleteList) {
        if (deleteList.size() != 0) {
            for (String path : deleteList) {
                for (PictureData pictureData : filterList) {
                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
                        filterList.remove(pictureData);
                        break;
                    }
                }
            }

            for (String path : deleteList) {
                for (PictureData pictureData : allList) {
                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
                        allList.remove(pictureData);
                        break;
                    }
                }
            }
        }
    }

    private ArrayList<String> getDeleteListOnResult() {
        ArrayList<String> deleteList = new ArrayList<>();
        for (int i = 0; i < pictures.size(); i++) {
            if (pictures.get(i) != null)
                if (pictures.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) pictures.get(i);
                    model.setCheckboxVisible(false);
                    if (model.isSelected()) {
                        deleteList.add(model.getFilePath());
                        boolean isPre = false, isNext = false;

                        if (i != 0) {
                            if (pictures.get(i - 1) instanceof AlbumData) {
                                isPre = true;
                            } else {
                                isPre = false;
                            }
                        }

                        if (i < (pictures.size() - 2)) {
                            if (pictures.get(i + 1) instanceof AlbumData) {
                                isNext = true;
                            } else {
                                isNext = false;
                            }
                        }

                        if (isPre && isNext) {
                            //  objectList.remove(i + 1);
                            pictures.remove(i);
                            pictures.remove(i - 1);

                        } else if (i == (pictures.size() - 1)) {
                            pictures.remove(i);
                            if (isPre) {
                                pictures.remove(i - 1);
                            }
                        } else {
                            pictures.remove(i);
                        }

                        if (i != 0) {
                            i--;
                        }
                    }
                }
        }
        return deleteList;
    }

    private void moveToPrivate() {
        ArrayList<String> deleteList = new ArrayList<>();

        Observable.fromCallable(() -> {
                    for (int i = 0; i < pictures.size(); i++) {
                        if (pictures.get(i) != null)
                            if (pictures.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) pictures.get(i);
                                if (model.isSelected()) {
                                    File to;
                                    try {
                                        to = new File(model.getFilePath());
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        to = new File(model.getFilePath());
                                    }

                                    try {
                                        String hidePath = moveFile(to, new File(HIDE_PATH));
                                        if (hidePath != null) {
                                            database.addPrivate(hidePath, to.getParent());
                                        }
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    deleteList.add(to.getPath());
//        setUnFavorite(to.getPath());
                                    MediaScannerConnection.scanFile(requireActivity(), new String[]{to.getPath()}, null, (path, uri) -> {
                                    });

                                }
                            }
                    }
                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    requireActivity().runOnUiThread(() -> {
                        getDeleteListOnResult();
                        RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                        RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));
                        selected_Item = 0;
                        longClick(true, false, 0, 0);
                        setEmptyData();
                        deleteMainList(deleteList);
                        setAlbumImage();
                    });
                })
                .subscribe((result) -> {
                    requireActivity().runOnUiThread(() -> {
                        getDeleteListOnResult();
                        RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                        RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));
                        selected_Item = 0;
                        longClick(true, false, 0, 0);
                        setEmptyData();
                        deleteMainList(deleteList);
                        setAlbumImage();
                    });
                });
    }

    ArrayList<Uri> mUris = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void moveToPrivateAboveR() {
        mUris = new ArrayList<>();
        for (int i = 0; i < pictures.size(); i++) {
            if (pictures.get(i) != null)
                if (pictures.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) pictures.get(i);
                    if (model.isSelected()) {
                        File source = new File(model.getFilePath());
                        String destinationPath = HIDE_PATH + "/" + source.getName();
                        File destination = new File(destinationPath);
                        try {
                            destinationPath = Constant.HIDE_PATH;
                            destination = new File(destinationPath);
                            File hidePath = new File(destination + File.separator + source.getName());
                            boolean isMove = moveFileonAboveR(source, hidePath);

                            if (isMove) {
                                database.addPrivate(hidePath.getPath(), source.getParent());
                            }
                            if (model.isVideo())
                                mUris.add(getVideoUriFromFile(source.getPath(), requireActivity()));
                            else
                                mUris.add(getImageUriFromFile(source.getPath(), requireActivity()));
//                            setUnFavorite(source.getPath());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

        }

        requireActivity().runOnUiThread(() -> {
            requestDeletePermission(mUris);
            // delete image before
        });
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private boolean moveFileonAboveR(File source, File destination) throws IOException {
        boolean isMove = false;
        if (!destination.getParentFile().exists())
            destination.getParentFile().mkdirs();
        FileChannel source_channel = null;
        FileChannel destination_channel = null;
        try {
            Boolean isRename = source.renameTo(destination);
            if (isRename) {
                if (!source.getPath().contains("'")) {
                    isMove = true;
//                    getContentResolver().delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, MediaStore.Images.Media.DATA + "='" + source.getPath() + "'", null);
                }
            } else {
                if (!destination.exists()) {
                    ContentResolver contentResolver = requireActivity().getContentResolver();
                    Uri rootUri = Uri.parse(preferencesManager.getHideUri());
                    contentResolver.takePersistableUriPermission(
                            rootUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );
                    String rootDocumentId = DocumentsContract.getTreeDocumentId(rootUri);

                    CreateFile createFile = new CreateFile(requireActivity(), contentResolver, File.separator + source.getName()
                            , rootUri, rootDocumentId, true, source.getAbsolutePath(), true,
                            Utils.getMimeType(source.getName()));
                    boolean isFileCreated = createFile.createNewFile(false, true);
                    isMove = true;
                }
                source.delete();
            }
            MediaScannerConnection.scanFile(requireActivity(), new String[]{source.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });
            MediaScannerConnection.scanFile(requireActivity(), new String[]{destination.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });
        } finally {
            if (source_channel != null) {
                source_channel.close();
            }
            if (destination_channel != null) {
                destination_channel.close();
            }
        }
        return isMove;
    }

    private void requestDeletePermission(List<Uri> uriList) {
        try {
            PendingIntent pi = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                pi = MediaStore.createDeleteRequest(requireActivity().getContentResolver(), uriList);
            }
            startIntentSenderForResult(pi.getIntentSender(), Hide_FILE, null, 0, 0,
                    0, null);
        } catch (Exception e) {
            System.out.println("AFTER HIDE : " + e.getMessage());
        }
    }

    private String moveFile(File file, File dir) throws IOException {
        File newFile = getFileName(0, dir, file.getName());

        try (FileChannel outputChannel = new FileOutputStream(newFile).getChannel(); FileChannel inputChannel = new FileInputStream(file).getChannel()) {
            inputChannel.transferTo(0, inputChannel.size(), outputChannel);
            inputChannel.close();
            file.delete();

            MediaScannerConnection.scanFile(requireActivity(), new String[]{file.getPath()}, null, (path, uri) -> {
            });

            MediaScannerConnection.scanFile(requireActivity(), new String[]{newFile.getPath()}, null, (path, uri) -> {
            });
            return newFile.getPath();
        }
    }

    private File getFileName(int i, File dir, String name) {
        File check = new File(dir, name);
        if (check.exists()) {
            i++;
            if (name.indexOf(".") > 0) {
                String extension = name.substring(name.lastIndexOf("."));
                name = name.substring(0, name.lastIndexOf(".")) + "(" + i + ")" + extension;
            }
            check = getFileName(i, dir, name);
        }
        return check;
    }

    private void copyFiles(String selectPath, ArrayList<PictureData> copyMoveList) {
        File targetFolder = new File(selectPath);
        ArrayList<String> copyFiles = new ArrayList<>();
        Dialog dialog = new Dialog(this, R.style.WideDialog);
        TextView btnCancel, txtProgressCount, txtTitle, txt_top_title;
        ProgressBar progressBar;

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dilaog_delete_progress);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        btnCancel = dialog.findViewById(R.id.btnCancel);
        txt_top_title = dialog.findViewById(R.id.txt_top_title);
        txtTitle = dialog.findViewById(R.id.txt_title);
        txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
        progressBar = dialog.findViewById(R.id.progress_bar);
        progressBar.setMax(selected_Item);

        runOnUiThread(() -> {
            txt_top_title.setText(getText(R.string.Copying));
            int progress = (copyFiles.size() / 100) * selected_Item;
            txtProgressCount.setText(copyFiles.size() + "/" + selected_Item);
            progressBar.setProgress(copyFiles.size());
        });

        btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();

        Observable.fromCallable(() -> {
                    try {
                        for (int i = 0; i < copyMoveList.size(); i++) {
                            int finalI = i;
                            runOnUiThread(() -> {
                                txtTitle.setText(copyMoveList.get(finalI).getFileName());
                            });
                            File copyFile = new File(copyMoveList.get(i).getFilePath());
                            if (copyFile.exists()) {
                                String copyFileName = copyFile.getName();
                                String targetPath = targetFolder.getPath() + File.separator + copyFileName;
                                File targetFile = new File(targetPath);

                                if (targetFile.exists()) {
                                    String[] separated = copyFile.getName().split("\\.");
                                    String name = separated[0];
                                    String type = separated[1];

                                    String newName = name + "_" + System.currentTimeMillis() + "." + type;
                                    String newPath2 =
                                            targetFolder.getPath() + "/" + name + "_" + System.currentTimeMillis() + "." + type;
                                    File file2 = new File(newPath2);


                                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                                        String filePath = copyFileOnAboveQ(copyFile.getPath(), newName, targetFolder, requireActivity());
                                        if (filePath != null) {
                                            copyFiles.add(filePath);
                                        }

                                    } else {
                                        boolean isCopied = StorageUtils.copyFile(copyFile, file2, this);
                                        if (isCopied) {
                                            copyFiles.add(file2.getPath());
                                        }
                                    }
                                } else {
                                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
                                        String[] separated = copyFileName.split("\\.");
                                        String name = separated[0];
                                        String filePath = copyFileOnAboveQ(copyFile.getPath(), name, targetFolder, requireActivity());
                                        if (filePath != null) {
                                            copyFiles.add(filePath);
                                        }
                                    } else {
                                        boolean isCopied = StorageUtils.copyFile(copyFile, targetFile, requireActivity());
                                        if (isCopied) {
                                            copyFiles.add(targetFile.getPath());
                                        }
                                    }
                                }

                                requireActivity().runOnUiThread(() -> {
                                    int progress = (copyFiles.size() / 100) * selected_Item;
                                    txtProgressCount.setText(copyFiles.size() + "/" + selected_Item);
                                    progressBar.setProgress(copyFiles.size());
                                });

                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    requireActivity().runOnUiThread(() -> {
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        RxBus.getInstance().post(new CopyMoveEvent(copyFiles, targetFolder.getName(), targetFolder.getAbsolutePath(), new ArrayList<>()));
                        Toast.makeText(getActivity(), getString(R.string.copy_successfully), Toast.LENGTH_SHORT).show();
                        selected_Item = 0;
                        longClick(true, false, 0, 0);
                        setClose();
                        setAlbumImage();
                    });
                })
                .subscribe((result) -> {
                    requireActivity().runOnUiThread(() -> {
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        RxBus.getInstance().post(new CopyMoveEvent(copyFiles, targetFolder.getName(), targetFolder.getAbsolutePath(), new ArrayList<>()));
                        Toast.makeText(getActivity(), getString(R.string.copy_successfully), Toast.LENGTH_SHORT).show();
                        selected_Item = 0;
                        longClick(true, false, 0, 0);
                        setClose();
                        setAlbumImage();
                    });
                });

    }

    private Activity requireActivity() {
        return AlbumImageActivity.this;
    }

    private void moveFiles(String selectPath, ArrayList<PictureData> copyMoveList) {
        File targetFolder = new File(selectPath);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
            showMoveAlertDialog(targetFolder, copyMoveList);
        } else {
            ArrayList<String> moveList = new ArrayList<>();
            ArrayList<String> deleteList = new ArrayList<>();
            Dialog dialog = new Dialog(requireActivity(), R.style.WideDialog);
            TextView btnCancel, txtProgressCount, txtTitle, txt_top_title;
            ProgressBar progressBar;

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setCancelable(false);
            dialog.setContentView(R.layout.dilaog_delete_progress);
            dialog.setCanceledOnTouchOutside(false);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            btnCancel = dialog.findViewById(R.id.btnCancel);
            txt_top_title = dialog.findViewById(R.id.txt_top_title);
            txtTitle = dialog.findViewById(R.id.txt_title);
            txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
            progressBar = dialog.findViewById(R.id.progress_bar);
            progressBar.setMax(selected_Item);

            requireActivity().runOnUiThread(() -> {
                txt_top_title.setText(getText(R.string.Moving));
                int progress = (moveList.size() / 100) * selected_Item;
                txtProgressCount.setText(moveList.size() + "/" + selected_Item);
                progressBar.setProgress(moveList.size());
            });

            btnCancel.setOnClickListener(view -> {
                dialog.dismiss();
            });

            dialog.show();

            Observable.fromCallable(() -> {
                        try {
                            for (int i = 0; i < copyMoveList.size(); i++) {
                                File moveFile = new File(copyMoveList.get(i).getFilePath());
                                if (moveFile.exists()) {
                                    String moveFileName = moveFile.getName();
                                    String targetPath = targetFolder.getPath() + File.separator + moveFileName;

                                    File targetFile = new File(targetPath);
                                    if (targetFile.exists()) {


                                        String[] separated = moveFileName.split("\\.");
                                        String name = separated[0];
                                        String type = separated[1];

                                        String newPath2 =
                                                targetFolder.getPath() + "/" + name + "_" + System.currentTimeMillis() + "." + type;

                                        File file2 = new File(newPath2);
                                        boolean isMove = StorageUtils.moveFile(moveFile, file2, requireActivity());

                                        if (isMove) {
                                            moveList.add(file2.getPath());
                                            deleteList.add(moveFile.getPath());

                                        }

                                    } else {
                                        boolean isMove = StorageUtils.moveFile(moveFile, targetFile, requireActivity());
                                        if (isMove) {
                                            moveList.add(targetFile.getPath());
                                            deleteList.add(moveFile.getPath());

                                        }
                                    }
                                    requireActivity().runOnUiThread(() -> {
                                        txtProgressCount.setText(moveList.size() + "/" + selected_Item);
                                        progressBar.setProgress(moveList.size());
                                    });
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return false;
                    }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                    .doOnError(throwable -> {
                        requireActivity().runOnUiThread(() -> {
                            if (dialog != null)
                                if (dialog.isShowing()) {
                                    dialog.dismiss();
                                }
                            removeFiles(deleteList);
                            RxBus.getInstance().post(new CopyMoveEvent(moveList, targetFolder.getName(), targetFolder.getAbsolutePath(), deleteList));
                            Toast.makeText(getActivity(), getString(R.string.move_successfully), Toast.LENGTH_SHORT).show();
                            selected_Item = 0;
                            longClick(true, false, 0, 0);
                            pictureAdapter.notifyDataSetChanged();
                            setEmptyData();
                            setAlbumImage();
                        });
                    })
                    .subscribe((result) -> {
                        requireActivity().runOnUiThread(() -> {
                            if (dialog != null)
                                if (dialog.isShowing()) {
                                    dialog.dismiss();
                                }
                            RxBus.getInstance().post(new CopyMoveEvent(moveList, targetFolder.getName(), targetFolder.getAbsolutePath(), deleteList));
                            Toast.makeText(getActivity(), getString(R.string.move_successfully), Toast.LENGTH_SHORT).show();
                            selected_Item = 0;
                            longClick(true, false, 0, 0);
                            pictureAdapter.notifyDataSetChanged();
                            setEmptyData();
                            setAlbumImage();
                        });
                    });
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    public void deleteFileOnAboveQ() {
        ArrayList<Uri> uries = new ArrayList<>();
        for (int i = 0; i < pictures.size(); i++) {
            if (pictures.get(i) != null)
                if (pictures.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) pictures.get(i);
                    if (model.isSelected()) {
                        File file = new File(model.getFilePath());
                        if (model.isVideo())
                            uries.add(getVideoUriFromFile(file.getPath(), getActivity()));
                        else
                            uries.add(getImageUriFromFile(file.getPath(), getActivity()));
                    }
                }
        }

        ContentResolver contentResolver = getActivity().getContentResolver();
        try {
            IntentSender intentSender = MediaStore.createDeleteRequest(contentResolver, uries).getIntentSender();
            try {
                startIntentSenderForResult(intentSender, 2222, null, 0, 0, 0, null);
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }
        } catch (SecurityException securityException) {
            securityException.printStackTrace();
            RecoverableSecurityException exception = (RecoverableSecurityException) securityException;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                IntentSender intentSender = exception.getUserAction().getActionIntent().getIntentSender();
                try {
                    startIntentSenderForResult(intentSender, 2221, null, 0, 0, 0, null);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }

            }
        }
    }


    private void getData() {
        binding.swipeRefreshLayout.setRefreshing(true);
        Observable.fromCallable(() -> {
                    setFilter();
                    return true;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    runOnUiThread(() -> {
                        setData();
                    });
                })
                .subscribe((result) -> {
                    runOnUiThread(() -> {
                        setData();
                    });
                });
    }

    private void setData() {
        binding.swipeRefreshLayout.setRefreshing(false);
        if (pictureAdapter != null)
            pictureAdapter.notifyDataSetChanged();
        else initAdapter();

        setEmptyData();
    }

    private void setEmptyData() {
        if (pictures != null && pictures.size() != 0) {
            binding.imageRecycler.setVisibility(View.VISIBLE);
            binding.loutNoData.setVisibility(View.GONE);
        } else {
            binding.imageRecycler.setVisibility(View.GONE);
            binding.loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void initAdapter() {
        pictureAdapter = new PictureAdapter(this, pictures, isShowLabel, new PictureAdapter.OnSelectPicture() {
            @Override
            public void onSelectPicture(int pos) {
                if (pictures.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) pictures.get(pos);
                    if (imageList.isCheckboxVisible()) {
                        imageList.setSelected(!imageList.isSelected());
                        pictureAdapter.notifyItemChanged(pos);
                        setSelectedFile();
                    } else {
                        int temp_pos = -1;
                        ArrayList<PictureData> dataList = new ArrayList<>();
                        for (int i = 0; i < pictures.size(); i++) {
                            if (pictures.get(i) instanceof PictureData) {
                                dataList.add((PictureData) pictures.get(i));
                                if (pos == i) {
                                    temp_pos = dataList.size() - 1;
                                }
                            }
                        }
                        Constant.displayImageList = new ArrayList<>();
                        Constant.displayImageList.addAll(dataList);
                        Intent intent = new Intent(AlbumImageActivity.this, ImageShowActivity.class);
                        intent.putExtra("pos", temp_pos);
                        intent.putExtra("IsPrivateList", false);
                        intent.putExtra("IsShowSlideShow", false);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void onLongClickPicture(int pos) {
                if (pictures.get(pos) instanceof PictureData) {
                    PictureData imageList = (PictureData) pictures.get(pos);
                    for (int i = 0; i < pictures.size(); i++) {
                        if (pictures.get(i) != null)
                            if (pictures.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) pictures.get(i);
                                model.setCheckboxVisible(true);
                            }
                    }
                    imageList.setCheckboxVisible(true);
                    imageList.setSelected(true);
                    pictureAdapter.notifyDataSetChanged();
                    setSelectedFile();
                }
            }
        });
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3, RecyclerView.VERTICAL, false);
        binding.imageRecycler.setLayoutManager(gridLayoutManager);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(final int position) {
                if (pictureAdapter.getItemViewType(position) == PictureAdapter.ITEM_HEADER_TYPE) {
                    return 3;
                }
                return 1;
            }
        });
        binding.imageRecycler.setAdapter(pictureAdapter);
    }

    private void setSelectedFile() {
        int selected = 0;
        long size = 0;
        for (int i = 0; i < pictures.size(); i++) {
            if (pictures.get(i) != null)
                if (pictures.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) pictures.get(i);
                    if (model.isSelected()) {
                        selected++;
                        size += model.getFileSize();
                    }
                }
        }
        if (selected == 0) {
            longClick(true, false, selected, size);
            setRefreshData(true);
            setClose();
        } else {
            setRefreshData(false);
            longClick(false, true, selected, size);
        }
        binding.swipeRefreshLayout.setEnabled(selected == 0);
        selected_Item = selected;
    }

    public void setRefreshData(boolean isEnable) {
        if (isEnable)
            binding.swipeRefreshLayout.setEnabled(true);
        else
            binding.swipeRefreshLayout.setEnabled(false);
    }

    public void longClick(boolean isShowToolbar, boolean isShowSelected, int selected, long size) {
        if (isShowToolbar) {
            binding.toolbar.setVisibility(View.VISIBLE);
        } else {
            binding.toolbar.setVisibility(View.GONE);
        }

        if (isShowSelected) {
            binding.loutSelect.setVisibility(View.VISIBLE);
        } else {
            binding.loutSelect.setVisibility(View.GONE);
        }
        binding.txtSelectCount.setText(selected + " " + getString(R.string.Selected));
        binding.txtSelectSize.setText(Formatter.formatShortFileSize(this, size));
        if (size == 0)
            isSelectAll = false;
    }

    private void setClose() {
        for (int i = 0; i < pictures.size(); i++) {
            if (pictures.get(i) != null)
                if (pictures.get(i) instanceof PictureData) {
                    PictureData model = (PictureData) pictures.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);
                }
        }
        if (pictureAdapter != null) {
            pictureAdapter.notifyDataSetChanged();
        }
        selected_Item = 0;
        isSelectAll = false;
        setRefreshData(true);
        longClick(true, false, 0, 0);
    }

    private void setFilter() {
        filterList.clear();
        pictures.clear();
        for (PictureData pictureData : allList) {
            pictureData.setSelected(false);
            pictureData.setCheckboxVisible(false);
        }

        if (filterBy == 0)
            filterList.addAll(allList);
        else if (filterBy == 1)
            for (PictureData pictureData : allList) {
                if (!pictureData.isVideo())
                    filterList.add(pictureData);
            }
        else if (filterBy == 2)
            for (PictureData pictureData : allList) {
                if (pictureData.isVideo())
                    filterList.add(pictureData);

            }
        else
            filterList.addAll(allList);

        setSort();

    }

    private void setSort() {
        if (filterList.size() != 0) {
            Collections.sort(filterList, (p1, p2) -> {
                if (sortBy == 0) {
                    if (sortType)
                        return p2.getFileName().compareToIgnoreCase(p1.getFileName());
                    else
                        return p1.getFileName().compareToIgnoreCase(p2.getFileName());
                } else if (sortBy == 1) {
                    if (sortType)
                        return Long.compare(p2.getDate(), p1.getDate());
                    else
                        return Long.compare(p1.getDate(), p2.getDate());
                } else
                    return Long.compare(p2.getDate(), p1.getDate());
            });

            setList();
        }
    }

    private void setList() {
        pictures.clear();
        LinkedHashMap<String, ArrayList<PictureData>> dateWisePictures = new LinkedHashMap<>();
        SimpleDateFormat format = new SimpleDateFormat("EEEE, MMM dd yyyy");

        for (PictureData pictureData : filterList) {
            String strDate = format.format(pictureData.getDate());
//            if (strDate.equals(today)) {
//                strDate = "Today";
//            } else if (strDate.equals(yesterday)) {
//                strDate = "Yesterday";
//            }

            ArrayList<PictureData> imagesData1;
            if (dateWisePictures.containsKey(strDate)) {
                imagesData1 = dateWisePictures.get(strDate);
                if (imagesData1 == null)
                    imagesData1 = new ArrayList<>();

            } else {
                imagesData1 = new ArrayList<>();
            }
            imagesData1.add(pictureData);
            dateWisePictures.put(strDate, imagesData1);
        }


        Set<String> keys = dateWisePictures.keySet();
        ArrayList<String> listKeys = new ArrayList<>(keys);

        for (int i = 0; i < listKeys.size(); i++) {
            ArrayList<PictureData> imagesData = dateWisePictures.get(listKeys.get(i));

            if (imagesData != null && imagesData.size() != 0) {
                AlbumData bucketData = new AlbumData();

                bucketData.setTitle(listKeys.get(i));
                bucketData.setPictureData(imagesData);

                pictures.add(bucketData);
                pictures.addAll(imagesData);
            }
        }

        runOnUiThread(() -> {
            setAlbumImage();

        });
    }

    private void setAlbumImage() {
        binding.txtItemCounts.setText(allList.size() + " " + getString(R.string.Items));
        if (pictures != null && pictures.size() != 0) {
            try {
                if (pictures.get(1) instanceof PictureData) {
                    PictureData pictureData = (PictureData) pictures.get(1);
                    Glide.with(AlbumImageActivity.this).load(pictureData.getFilePath()).diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true)
                            .into(binding.imgToolbar);
                } else {
                    binding.imgToolbar.setImageDrawable(null);
                }
            } catch (Exception e) {
                e.printStackTrace();
                binding.imgToolbar.setImageDrawable(null);
            }
        } else
            binding.imgToolbar.setImageDrawable(null);
    }

    private void deletePhoto() {
        ArrayList<String> deleteList = new ArrayList<>();
        Dialog dialog = new Dialog(this, R.style.WideDialog);
        TextView btnCancel, txtProgressCount, txtTitle;
        ProgressBar progressBar;

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dilaog_delete_progress);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        btnCancel = dialog.findViewById(R.id.btnCancel);
        txtTitle = dialog.findViewById(R.id.txt_title);
        txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
        progressBar = dialog.findViewById(R.id.progress_bar);
        progressBar.setMax(selected_Item);
        runOnUiThread(() -> {
            int progress = (deleteList.size() / 100) * selected_Item;
            txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
            progressBar.setProgress(deleteList.size());

        });

        btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();

        Observable.fromCallable(() -> {
                    for (int i = 0; i < pictures.size(); i++) {
                        if (pictures.get(i) != null)
                            if (pictures.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) pictures.get(i);
                                if (model.isSelected()) {
                                    File file = new File(model.getFilePath());

                                    runOnUiThread(() -> {
                                        txtTitle.setText(model.getFileName());
                                    });
                                    try {
                                        file.delete();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    Uri deleteUrl = FileProvider.getUriForFile(AlbumImageActivity.this, getApplicationContext().getPackageName() + ".provider", file);
                                    ContentResolver contentResolver = getContentResolver();
                                    contentResolver.delete(deleteUrl, null, null);

                                    MediaScannerConnection.scanFile(getActivity(), new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                        public void onScanCompleted(String path, Uri uri) {
                                            // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                                        }
                                    });
                                    deleteList.add(file.getPath());

                                    runOnUiThread(() -> {
                                        int progress = (deleteList.size() / 100) * selected_Item;
                                        txtProgressCount.setText(deleteList.size() + "/" + selected_Item);
                                        progressBar.setProgress(deleteList.size());
                                    });
                                } else {
                                    model.setCheckboxVisible(false);
                                }
                            }
                    }
                    for (int i = 0; i < pictures.size(); i++) {
                        if (pictures.get(i) != null)
                            if (pictures.get(i) instanceof PictureData) {
                                PictureData model = (PictureData) pictures.get(i);
                                if (model.isSelected()) {
                                    boolean isPre = false, isNext = false;

                                    if (i != 0) {
                                        if (pictures.get(i - 1) instanceof AlbumData) {
                                            isPre = true;
                                        } else {
                                            isPre = false;
                                        }
                                    }

                                    if (i < (pictures.size() - 2)) {
                                        if (pictures.get(i + 1) instanceof AlbumData) {
                                            isNext = true;
                                        } else {
                                            isNext = false;
                                        }
                                    }

                                    if (isPre && isNext) {
                                        //  objectList.remove(i + 1);
                                        pictures.remove(i);
                                        pictures.remove(i - 1);

                                    } else if (i == (pictures.size() - 1)) {
                                        pictures.remove(i);
                                        if (isPre) {
                                            pictures.remove(i - 1);
                                        }
                                    } else {
                                        pictures.remove(i);
                                    }

                                    if (i != 0) {
                                        i--;
                                    }
                                }
                            }
                    }
                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    runOnUiThread(() -> {
                        RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        selected_Item = 0;
                        longClick(true, false, 0, 0);
                        pictureAdapter.notifyDataSetChanged();
                        setEmptyData();
                        Toast.makeText(getActivity(), getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
                        deleteMainList(deleteList);
                        binding.txtItemCounts.setText(allList.size() + " " + getString(R.string.Items));
                        setAlbumImage();
                        if (pictures.size() == 0)
                            if (albumData.getFolderPath() != null) {
                                File file = new File(albumData.getFolderPath());
                                file.delete();
                                MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{albumData.getFolderPath()}, null, (path, uri) -> {
                                });
                            }
                    });
                })
                .subscribe((result) -> {
                    runOnUiThread(() -> {
                        RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        selected_Item = 0;
                        longClick(true, false, 0, 0);
                        pictureAdapter.notifyDataSetChanged();
                        setEmptyData();
                        Toast.makeText(getActivity(), getString(R.string.Delete_successfully), Toast.LENGTH_SHORT).show();
                        deleteMainList(deleteList);
                        binding.txtItemCounts.setText(allList.size() + " " + getString(R.string.Items));
                        setAlbumImage();
                        if (pictures.size() == 0)
                            if (albumData.getFolderPath() != null) {
                                File file = new File(albumData.getFolderPath());
                                file.delete();
                                MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{albumData.getFolderPath()}, null, (path, uri) -> {
                                });
                            }
                    });
                });
    }

    private Activity getActivity() {
        return AlbumImageActivity.this;
    }

    public Uri getVideoUriFromFile(final String path, Context context) {
        ContentResolver resolver = context.getContentResolver();

        Cursor filecursor = resolver.query(MediaStore.Video.Media.getContentUri("external"),
                new String[]{BaseColumns._ID}, MediaStore.Video.VideoColumns.DATA + " = ?",
                new String[]{path}, MediaStore.Video.VideoColumns.DATE_ADDED + " desc");
        filecursor.moveToFirst();

        if (filecursor.isAfterLast()) {
            filecursor.close();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.VideoColumns.DATA, path);
            return resolver.insert(MediaStore.Video.Media.getContentUri("external"), values);
        } else {
            int imageId = filecursor.getInt(filecursor.getColumnIndexOrThrow(BaseColumns._ID));
            Uri uri = MediaStore.Video.Media.getContentUri("external").buildUpon().appendPath(
                    Integer.toString(imageId)).build();
            filecursor.close();
            return uri;
        }
    }

    public Uri getImageUriFromFile(final String path, Context context) {
        ContentResolver resolver = context.getContentResolver();

        Cursor filecursor = resolver.query(MediaStore.Images.Media.getContentUri("external"),
                new String[]{BaseColumns._ID}, MediaStore.Images.ImageColumns.DATA + " = ?",
                new String[]{path}, MediaStore.Images.ImageColumns.DATE_ADDED + " desc");
        filecursor.moveToFirst();

        if (filecursor.isAfterLast()) {
            filecursor.close();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.ImageColumns.DATA, path);
            return resolver.insert(MediaStore.Images.Media.getContentUri("external"), values);
        } else {
            int imageId = filecursor.getInt(filecursor.getColumnIndexOrThrow(BaseColumns._ID));
            Uri uri = MediaStore.Images.Media.getContentUri("external").buildUpon().appendPath(
                    Integer.toString(imageId)).build();
            filecursor.close();
            return uri;
        }
    }

    public final String copyFileOnAboveQ(@NonNull final String filePath, String newName, File targetFolder, Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        FileOutputStream fos = null;
        String folderName = targetFolder.getName();
        String relativePath = null;
        if (targetFolder.getPath().contains(Environment.DIRECTORY_PICTURES)) {
            relativePath = Environment.DIRECTORY_PICTURES + File.separator + folderName;

        } else if (targetFolder.getPath().contains(Environment.DIRECTORY_DCIM)) {
            relativePath = Environment.DIRECTORY_DCIM + File.separator + folderName;
        }

        try {
            if (StorageUtils.isVideo(new File(filePath).getName())) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);


                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                FileInputStream inStream = new FileInputStream(filePath);
                FileChannel inChannel = inStream.getChannel();
                FileChannel outChannel = fos.getChannel();
                inChannel.transferTo(0, inChannel.size(), outChannel);
                inStream.close();
                fos.close();

                String copyFilePath = getPath(imageUri, context);

                MediaScannerConnection.scanFile(context, new String[]{copyFilePath}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                    }
                });
                return copyFilePath;
            } else {

                Bitmap bitmap = getBitmap(filePath);
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, newName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath);

                Uri imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);

                fos = (FileOutputStream) contentResolver.openOutputStream(imageUri);
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)) {
                    fos.flush();
                }

                String copyFilePath = getPath(imageUri, context);

                MediaScannerConnection.scanFile(context, new String[]{copyFilePath}, null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                    }
                });
                return copyFilePath;
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public String getPath(Uri uri, Context context) {
        String[] projection = {MediaStore.Files.FileColumns.DATA};
        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
        if (cursor == null) return null;
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
        cursor.moveToFirst();
        String s = cursor.getString(column_index);
        cursor.close();
        return s;
    }

    public static Bitmap getBitmap(String path1) {
        Bitmap bitmap = null;
        try {
            File f = new File(path1);
            bitmap = decodeSampledBitmap(f, 1080, 768);

            android.media.ExifInterface exif = new android.media.ExifInterface(path1);
            int orientation = exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
            Log.d("EXIF", "Exif: " + orientation);
            Matrix matrix = new Matrix();
            if (orientation == 6) {
                matrix.postRotate(90);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                        matrix, true);
            } else if (orientation == 3) {
                matrix.postRotate(180);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                        matrix, true);
            } else if (orientation == 8) {
                matrix.postRotate(270);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                        matrix, true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    public static Bitmap decodeSampledBitmap(File f, int reqWidth, int reqHeight) throws FileNotFoundException {

        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(new FileInputStream(f), null, options);

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(new FileInputStream(f), null, options);
    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;


            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    ArrayList<String> deleteFilePaths = new ArrayList<>();
    ArrayList<String> moveFiles = new ArrayList<>();
    File moveFolder;

    @RequiresApi(api = Build.VERSION_CODES.R)
    private void showMoveAlertDialog(File targetFolder, ArrayList<PictureData> copyMoveList) {
        moveFolder = new File(targetFolder.getAbsolutePath());
        final Dialog alterDialog = new Dialog(requireActivity(), R.style.WideDialog);
        alterDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alterDialog.setCancelable(true);
        alterDialog.setCanceledOnTouchOutside(true);

        DialogMoveVersion11Binding binding =
                DataBindingUtil.inflate(getLayoutInflater(), R.layout.dialog_move_version_11, null,
                        false);
        alterDialog.setContentView(binding.getRoot());
        alterDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alterDialog.getWindow().setGravity(Gravity.CENTER);

        alterDialog.show();


        binding.btnDeny.setOnClickListener(view -> {
            alterDialog.dismiss();
        });


        binding.btnAllow.setOnClickListener(view -> {
            moveFilesAboveQ(targetFolder, copyMoveList);
            alterDialog.dismiss();
        });

    }

    private void moveFilesAboveQ(File targetFolder, ArrayList<PictureData> copyMoveList) {
        moveFiles = new ArrayList<>();
        deleteFilePaths = new ArrayList<>();
        Dialog dialog = new Dialog(requireActivity(), R.style.WideDialog);
        TextView btnCancel, txtProgressCount, txtTitle, txt_top_title;
        ProgressBar progressBar;

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dilaog_delete_progress);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        btnCancel = dialog.findViewById(R.id.btnCancel);
        txt_top_title = dialog.findViewById(R.id.txt_top_title);
        txtTitle = dialog.findViewById(R.id.txt_title);
        txtProgressCount = dialog.findViewById(R.id.txt_progress_count);
        progressBar = dialog.findViewById(R.id.progress_bar);
        progressBar.setMax(selected_Item);

        requireActivity().runOnUiThread(() -> {
            txt_top_title.setText(getText(R.string.Moving));
//            int progress = (moveFiles.size() / selected_Item) * 100;
//            Log.e("Move", "progress==>> " + progress + " fileSize==>>> " +moveFiles.size());
            txtProgressCount.setText(moveFiles.size() + "/" + selected_Item);
            progressBar.setProgress(moveFiles.size());
        });

        btnCancel.setOnClickListener(view -> {
            dialog.dismiss();
        });

        dialog.show();
        Observable.fromCallable(() -> {
                    try {
                        for (int i = 0; i < copyMoveList.size(); i++) {
                            deleteFilePaths.add(copyMoveList.get(i).getFilePath());
                            File moveFile = new File(copyMoveList.get(i).getFilePath());
                            if (moveFile.exists()) {
                                requireActivity().runOnUiThread(() -> {
                                    txtTitle.setText(moveFile.getName());
                                });
                                String moveFileName = moveFile.getName();

                                String targetPath = targetFolder.getPath() + File.separator + moveFileName;

                                File targetFile = new File(targetPath);

                                if (targetFile.exists()) {

                                    String[] separated = moveFileName.split("\\.");
                                    String name = separated[0];
                                    String copyFilPath = copyFileOnAboveQ(moveFile.getPath(), name, targetFolder, requireActivity());
                                    if (copyFilPath != null) {
                                        moveFiles.add(copyFilPath);
                                    }
                                } else {
                                    String[] separated = targetFile.getName().split("\\.");
                                    String name = separated[0];

                                    String copyFilPath = copyFileOnAboveQ(moveFile.getPath(), name, targetFolder, requireActivity());

                                    if (copyFilPath != null) {
                                        moveFiles.add(copyFilPath);
                                    }
                                }
                                requireActivity().runOnUiThread(() -> {
                                    int progress = (moveFiles.size() / selected_Item) * 100;
                                    Log.e("Move", "progress==>> " + progress + " fileSize==>>> " + moveFiles.size());
                                    txtProgressCount.setText(moveFiles.size() + "/" + selected_Item);
                                    progressBar.setProgress(moveFiles.size());
                                });
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return false;
                }).subscribeOn(io.reactivex.schedulers.Schedulers.io())
                .doOnError(throwable -> {
                    requireActivity().runOnUiThread(() -> {
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        //for delete
                        if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                            deleteFileOnAboveQMoves(deleteFilePaths, requireActivity());
                        }
                    });
                })
                .subscribe((result) -> {
                    requireActivity().runOnUiThread(() -> {
                        if (dialog != null)
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                        //for delete
                        if (SDK_INT >= Build.VERSION_CODES.R && !preferencesManager.getStoragePermission11()) {
                            deleteFileOnAboveQMoves(deleteFilePaths, requireActivity());
                        }
                    });
                });


    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    public final void deleteFileOnAboveQMoves(@NonNull final ArrayList<String> filePaths, Context context) {
        ArrayList<Uri> uries = new ArrayList<>();
        for (int i = 0; i < filePaths.size(); i++) {
            if (StorageUtils.isVideo(filePaths.get(i))) {
                uries.add(getVideoUriFromFile(filePaths.get(i), requireActivity()));
            } else {
                uries.add(getImageUriFromFile(filePaths.get(i), requireActivity()));
            }
        }

        ContentResolver contentResolver = context.getContentResolver();

        try {

            IntentSender intentSender = MediaStore.createDeleteRequest(contentResolver, uries).getIntentSender();
            try {
                startIntentSenderForResult(intentSender, DELETE_FILE, null, 0, 0, 0, null);
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }

        } catch (SecurityException securityException) {
            securityException.printStackTrace();
            RecoverableSecurityException exception = (RecoverableSecurityException) securityException;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                IntentSender intentSender = exception.getUserAction().getActionIntent().getIntentSender();
                try {
                    startIntentSenderForResult(intentSender, DELETE_FILE, null, 0, 0, 0, null);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }

            }
        }
    }


}