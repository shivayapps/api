package com.photo.video.vault.gallery.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.alexvasilkov.gestures.views.GestureImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.model.PictureData;

import java.util.ArrayList;
import java.util.List;


public class DisplayImageAdapter extends PagerAdapter {

    List<PictureData> imageList = new ArrayList<>();
    Context context;
    LayoutInflater layoutInflater;
    boolean isFirst = false;
    boolean isPrivateList = false;
    ImageToolbar imageToolbar;

    public DisplayImageAdapter(Context context, List<PictureData> imageList, boolean isPrivateList, ImageToolbar imageToolbar) {
        this.context = context;
        this.imageList = imageList;
        this.isPrivateList = isPrivateList;
        this.imageToolbar = imageToolbar;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return imageList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == ((RelativeLayout) object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View itemView = layoutInflater.inflate(R.layout.item_full_screen_image, container, false);
        GestureImageView imageView = itemView.findViewById(R.id.iv_display);
        ImageView ic_video = itemView.findViewById(R.id.ic_video);
        final RequestOptions options = new RequestOptions()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .override(900, 900).dontTransform();
        imageView.getController().getSettings()
                .setMaxZoom(6f)
                .setDoubleTapZoom(3f);
        Glide.with(context).setDefaultRequestOptions(options)
                .load(imageList.get(position).getFilePath())
                .into(imageView);
        if (imageList.get(position).isVideo())
            ic_video.setVisibility(View.VISIBLE);
        else
            ic_video.setVisibility(View.GONE);

        imageView.setOnClickListener(view -> {
            imageToolbar.OnImageToolbar(view);
        });

        ic_video.setOnClickListener(view -> {
            imageToolbar.OnVideoShow(position);
//            Uri shareUri ;
//            if (isPrivateList && SDK_INT >= Build.VERSION_CODES.R)
//                shareUri = Uri.parse(imageList.get(position).getFilePath());
//            else
//                shareUri = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() +
//                        ".provider", new File(imageList.get(position).getFilePath()));
//
//            Intent intent = new Intent(Intent.ACTION_VIEW);
//            intent.setDataAndType(shareUri, Constant.getMimeTypeFromFilePath(imageList.get(position).getFilePath()));
//            context.startActivity(intent);
        });
        container.addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout) object);
    }

    public interface ImageToolbar {
        public void OnImageToolbar(View v);
        public void OnVideoShow(int pos);
    }
}
