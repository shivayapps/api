package com.photo.video.vault.gallery.activity;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION.SDK_INT;
import static com.photo.video.vault.gallery.utils.Application.myApplication;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.photo.video.vault.gallery.BuildConfig;
import com.photo.video.vault.gallery.CallbackVIP;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.ads.AdmobAdManager;
import com.photo.video.vault.gallery.ads.AppOpenManager;
import com.photo.video.vault.gallery.ads.Variables;
import com.photo.video.vault.gallery.network.JSONParser;
import com.photo.video.vault.gallery.preferences.PreferencesManager;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class SplashActivity extends AppCompatActivity {

    com.photo.video.vault.gallery.databinding.ActivitySplashBinding binding;
    PreferencesManager preferencesManager;
    ActivityResultLauncher<Intent> lockActivityResultLauncher;
    AdmobAdManager admobAdManager;
    AppOpenManager appOpenManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Variables.isSplashScreen = true;
        preferencesManager = PreferencesManager.getInstance(this);
        changeLanguage();
        Variables.isSPermissionScreen = false;
        binding = com.photo.video.vault.gallery.databinding.ActivitySplashBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        binding.privacyPolicyLayout.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        preferencesManager.putStoragePermission11(true);

        intView();
    }

    private void changeLanguage() {
        ArrayList<String> languageCodes = new ArrayList<>();
        languageCodes.add("en");
        languageCodes.add("hi");
        languageCodes.add("zh");
        languageCodes.add("es");
        languageCodes.add("de");
        languageCodes.add("ru");
        languageCodes.add("pt");
        languageCodes.add("fi");
        languageCodes.add("ja");
        languageCodes.add("tr");
        languageCodes.add("no");
        languageCodes.add("in");
        languageCodes.add("it");
        languageCodes.add("fr");
        languageCodes.add("nl");
        languageCodes.add("ko");
        languageCodes.add("ka");
        languageCodes.add("ga");
        languageCodes.add("pl");
        languageCodes.add("ca");

        Locale locale = new Locale(languageCodes.get(preferencesManager.getLanguage()));
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

    }

    private void showNext() {
        if (checkPermission()) {
            showNextScreen();
        } else {
            requestPermission();
        }
    }

    private void intView() {
        admobAdManager = AdmobAdManager.getInstance(this);
        setActivityResultLauncher();

        binding.txtAppVersion.setText(getResources().getString(R.string.version) + " " + BuildConfig.VERSION_NAME);

        if (isInternetAvailable())
            apiCall();
        else {
            intAds();
            callNext(3000);
        }
        binding.btnGetStarted.setOnClickListener(view -> {
            if (binding.signupPolicy.isChecked()) {
                preferencesManager.putPrivacy(true);
                showNext();
            } else
                Toast.makeText(this, getString(R.string.privacy_policy_validation), Toast.LENGTH_SHORT).show();
        });
    }

    private void callNext(int delay) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (preferencesManager.getPrivacy())
                showNext();
            else {
                binding.privacyPolicyLayout.setVisibility(View.VISIBLE);
                binding.progressBar.setVisibility(View.GONE);
            }
        }, delay);
    }

    private void apiCall() {
        new Thread(() -> {
            JSONParser jsonParser = new JSONParser();
            JSONObject json = jsonParser.makeHttpRequest("https://nekeeinfotech.com/jsons/Sagar/Gallery/gallery", "GET");
            try {
                int success = json.getInt("success");
                if (success == 1) {
                    Log.d("Data", "apiCall: =====> " + json);
                    preferencesManager.saveAdIds(SplashActivity.this, json);
                }
            } catch (Exception ignored) {
                Log.e("catching", ignored.getMessage());
            } finally {
                runOnUiThread(() -> {
                    intAds();
                    callNext(2000);
                });
            }
        }).start();
    }

    private void intAds() {
        appOpenManager = new AppOpenManager(myApplication);
        if (preferencesManager.getOpenAppAdsEnabled()) {
            appOpenManager.loadAppOpenAd();
        }
    }

    public boolean isInternetAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    private void setActivityResultLauncher() {
        lockActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK)
                        showHomeScreen();
                    else
                        finish();
                });
    }

    ActivityResultLauncher<Intent> permissionActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (SDK_INT >= Build.VERSION_CODES.R && preferencesManager.getStoragePermission11())
                        if (Environment.isExternalStorageManager()) {
                            showNextScreen();
                        } else {
                            Toast.makeText(SplashActivity.this, getString(R.string.permission_toast_msg), Toast.LENGTH_SHORT).show();
                        }
                }
            });

    private void requestPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R && preferencesManager.getStoragePermission11()) {
            Variables.isSPermissionScreen = true;
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(Uri.parse(String.format("package:%s", getApplicationContext().getPackageName())));
                permissionActivityResultLauncher.launch(intent);
            } catch (Exception e) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                permissionActivityResultLauncher.launch(intent);
            }
        } else
            ActivityCompat.requestPermissions(SplashActivity.this, new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_MEDIA_LOCATION, Manifest.permission.CAMERA}, 100);
    }

    private void showNextScreen() {
        if (appOpenManager.isAdAvailable()) {
            appOpenManager.showAdIfAvailable(() -> {
                if (preferencesManager.getSetLockApp()) {
                    lockActivityResultLauncher.launch(new Intent(SplashActivity.this, PasswordActivity.class).putExtra("isOpenPrivate", false));
                } else {
                    showHomeScreen();
                }
            });
        } else {
            Log.e("appOpenManager", "show next screen");
            if (preferencesManager.getSetLockApp()) {
                lockActivityResultLauncher.launch(new Intent(SplashActivity.this, PasswordActivity.class).putExtra("isOpenPrivate", false));
            } else {
                showHomeScreen();
            }
        }
    }

    private void showHomeScreen() {
        admobAdManager.loadInterstitialAd(this, preferencesManager.getInterstitialId());
        admobAdManager.loadNativeAd(this, preferencesManager.getNativeId());

        int theme = preferencesManager.getTheme();
        if (theme == 0)
            startActivity(new Intent(this, HomeActivity.class).putExtra("isOpenToSplash", true));
        else if (theme == 1)
            startActivity(new Intent(this, HomeFlatActivity.class).putExtra("isOpenToSplash", true));
        else if (theme == 2)
            startActivity(new Intent(this, HomeClassicActivity.class).putExtra("isOpenToSplash", true));
        Variables.isSplashScreen = false;
    }

    private boolean checkPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R && preferencesManager.getStoragePermission11()) {
            return Environment.isExternalStorageManager();
        } else {
            int result = ContextCompat.checkSelfPermission(SplashActivity.this, READ_EXTERNAL_STORAGE);
            int result1 = ContextCompat.checkSelfPermission(SplashActivity.this, WRITE_EXTERNAL_STORAGE);
//        int result2 = ContextCompat.checkSelfPermission(SplashActivity.this, CAMERA);
            return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED /*&& result2 == PackageManager.PERMISSION_GRANTED*/;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (checkPermission(SplashActivity.this, READ_EXTERNAL_STORAGE) && checkPermission(SplashActivity.this, WRITE_EXTERNAL_STORAGE)) {
                showNextScreen();
            } else {
                Toast.makeText(this, getString(R.string.permission_toast_msg), Toast.LENGTH_SHORT).show();
            }
        }
    }

    public boolean checkPermission(Activity activity, String permissionName) {
        return PackageManager.PERMISSION_GRANTED == ContextCompat.checkSelfPermission(activity, permissionName);
    }


    protected void showMessage(String msg) {
        Toast.makeText(SplashActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    private String selectedCountry = "us";
    private String ServerIPaddress = "00.000.000.00";
    boolean connected = false;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.e("viiippppp", "destroy");
    }
}