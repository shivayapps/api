package com.photo.video.vault.gallery.utils

import java.io.IOException

class DirectoryHierarchyBroken(message: String?): IOException(message) {
}