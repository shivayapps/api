package com.photo.video.vault.gallery.adapter;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.photo.video.vault.gallery.R;
import com.photo.video.vault.gallery.model.AlbumData;
import com.photo.video.vault.gallery.model.PictureData;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class FavoriteAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Activity activity;
    List<Object> photoList = new ArrayList<>();
    private static final int ITEM_PHOTOS_TYPE = 2;
    private static final int ITEM_VIDEOS_TYPE = 3;
    public static final int ITEM_HEADER_TYPE = 1;
    OnSelectPicture onSelectPicture;
    public boolean isShowLabel;
    SimpleDateFormat format;


    public FavoriteAdapter(Activity activity, List<Object> photoList, boolean isShowLabel, OnSelectPicture onSelectPicture) {
        this.activity = activity;
        this.photoList = photoList;
        this.onSelectPicture = onSelectPicture;
        this.isShowLabel = isShowLabel;
        format = new SimpleDateFormat("EEEE, MMM dd yyyy");
    }


    @Override
    public int getItemViewType(int position) {
        try {
            if (photoList.get(position) instanceof PictureData) {
                PictureData data = (PictureData) photoList.get(position);
//            if (data.isVideo()) {
//                return ITEM_VIDEOS_TYPE;
//            } else {
                return ITEM_PHOTOS_TYPE;
//            }
            } else {
                return ITEM_HEADER_TYPE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ITEM_PHOTOS_TYPE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        switch (viewType) {
            case ITEM_HEADER_TYPE:
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_header, parent, false);
                viewHolder = new HeaderViewHolder(v);
                break;
            case ITEM_PHOTOS_TYPE:
                View v1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_picture, parent, false);
                viewHolder = new ImageViewHolder(v1);
                break;
//            case ITEM_VIDEOS_TYPE:
//                View v2 = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video, parent, false);
//                viewHolder = new VideoViewHolder(v2);
//                break;

        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (getItemViewType(position)) {
            case ITEM_HEADER_TYPE:
                final HeaderViewHolder viewHolder = (HeaderViewHolder) holder;
                AlbumData imageHeader = (AlbumData) photoList.get(position);
                Calendar calendar = Calendar.getInstance();

                String today = format.format(calendar.getTimeInMillis());
                calendar.add(Calendar.DATE, -1);
                String yesterday = format.format(calendar.getTimeInMillis());
                String strDate = imageHeader.getTitle();
                if (imageHeader.getTitle().equals(today))
                    strDate = activity.getString(R.string.Today);
                else if (imageHeader.getTitle().equals(yesterday))
                    strDate = activity.getString(R.string.Yesterday);

                viewHolder.headerText.setText(strDate);
                break;

            case ITEM_PHOTOS_TYPE:
                final ImageViewHolder pictureViewHolder = (ImageViewHolder) holder;
                PictureData pictureData = (PictureData) photoList.get(position);
                File file = new File(pictureData.getFilePath());
//                Uri imageUri = Uri.fromFile(file);
                Glide.with(activity).load(pictureData.getFilePath())  .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true).into(pictureViewHolder.image);

                if (isShowLabel) {
                    pictureViewHolder.txtName.setText(pictureData.getFileName());
                    pictureViewHolder.loutName.setVisibility(View.VISIBLE);
                } else
                    pictureViewHolder.loutName.setVisibility(View.GONE);

                if (pictureData.isVideo()) {
                    pictureViewHolder.loutDuration.setVisibility(View.VISIBLE);
                    pictureViewHolder.txtDuration.setText(getDurationString(pictureData.getVideoDuration()));
                    Log.e("pictureData", "txt duration :" + pictureViewHolder.txtDuration.getText() + " duration: " + pictureData.getVideoDuration());
                } else
                    pictureViewHolder.loutDuration.setVisibility(View.GONE);

                if (pictureData.isSelected()) {
                    pictureViewHolder.frame_layout.setBackgroundColor(activity.getResources().getColor(R.color.selected_image));

                    FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(pictureViewHolder.ll_main.getLayoutParams());
                    int margin = activity.getResources().getDimensionPixelSize(com.intuit.sdp.R.dimen._6sdp);
                    layout.setMargins(margin, margin, margin, margin);
                    pictureViewHolder.ll_main.setLayoutParams(layout);
                    pictureViewHolder.lout_select.setVisibility(View.VISIBLE);
                    pictureViewHolder.iv_select.setVisibility(View.VISIBLE);
                } else {
                    pictureViewHolder.lout_select.setVisibility(View.GONE);
                    pictureViewHolder.iv_select.setVisibility(View.GONE);
                    FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(pictureViewHolder.ll_main.getLayoutParams());
                    int margin = 0;
                    layout.setMargins(margin, margin, margin, margin);
                    pictureViewHolder.ll_main.setLayoutParams(layout);
                    pictureViewHolder.frame_layout.setBackgroundColor(activity.getResources().getColor(R.color.white));
                }

                holder.itemView.setOnClickListener(v -> onSelectPicture.onSelectPicture(position));
                holder.itemView.setOnLongClickListener(v -> {
                    onSelectPicture.onLongClickPicture(position);
                    return true;
                });
                break;
        }
    }

    public String getDurationString(long duration) {
        long hours = TimeUnit.MILLISECONDS.toHours(duration);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration));

        String strMin;
        if (minutes < 10) {
            strMin = "0" + minutes;
        } else if (minutes >= 60) {
            long temp = minutes % 60;
            if (temp < 10) {
                strMin = "0" + temp;
            } else {
                strMin = String.valueOf(temp);
            }
        } else {
            strMin = String.valueOf(minutes);
        }

        String strSec;
        if (seconds < 10) {
            strSec = "0" + seconds;
        } else {
            strSec = String.valueOf(seconds);
        }

        String strHour;
        if (hours < 10) {
            strHour = "0" + hours;
        } else {
            strHour = String.valueOf(hours);
        }

        if (hours == 0) {
            return strMin + ":" + strSec;
        } else
            return strHour + ":" + strMin + ":" + strSec;
    }

    @Override
    public int getItemCount() {
        return photoList.size();
    }

    public class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView headerText;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            headerText = itemView.findViewById(R.id.headerText);
        }
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        RelativeLayout lout_select;
        AppCompatImageView iv_select;
        FrameLayout ll_main;
        FrameLayout frame_layout;
        LinearLayout loutName, loutDuration;
        TextView txtName, txtDuration;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image);
            iv_select = itemView.findViewById(R.id.iv_select);
            frame_layout = itemView.findViewById(R.id.frame_layout);
            txtName = itemView.findViewById(R.id.txt_name);
            txtDuration = itemView.findViewById(R.id.txt_duration);
            loutName = itemView.findViewById(R.id.lout_name);
            loutDuration = itemView.findViewById(R.id.lout_duration);
            ll_main = itemView.findViewById(R.id.ll_main);
            lout_select = itemView.findViewById(R.id.lout_select);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

//            int width = displayMetrics.widthPixels;
//            frame_layout.getLayoutParams().height = width / 3;

//            float radius = activity.getResources().getDimension(R.dimen._8sdp);
//            ShapeAppearanceModel shapeAppearanceModel = image.getShapeAppearanceModel().toBuilder()
//                    .setAllCornerSizes(radius)
//                    .build();
//            image.setShapeAppearanceModel(shapeAppearanceModel);
        }
    }


    public interface OnSelectPicture {
        void onSelectPicture(int pos);

        void onLongClickPicture(int pos);
    }
}
