package messages.sms.text.chat.messanger.app.feature.blocking.messages

import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.rxkotlin.withLatestFrom
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.blocking.BlockingClient
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkPresenter
import messages.sms.text.chat.messanger.app.interactor.DeleteConversations
import messages.sms.text.chat.messanger.app.repository.ConversationRepository
import javax.inject.Inject

class BlockedMessagesPresenter @Inject constructor(
    conversationRepo: ConversationRepository,
    private val blockingClient: BlockingClient,
    private val deleteConversations: DeleteConversations,
    private val navigator: Navigator,
) : QkPresenter<BlockedMessagesView, BlockedMessagesState>(
    BlockedMessagesState(
        data = conversationRepo.getBlockedConversationsAsync()
    )
) {

    override fun bindIntents(view: BlockedMessagesView) {
        super.bindIntents(view)

        view.menuReadyIntent
            .autoDisposable(view.scope())
            .subscribe { newState { copy() } }

        view.optionsItemIntent
            .withLatestFrom(view.selectionChanges) { itemId, conversations ->
                when (itemId) {
                    R.id.block -> {
                        view.showBlockingDialog(conversations, false)
                        view.clearSelection()
                    }

                    R.id.delete -> {
                        view.showDeleteDialog(conversations)
                    }
                }

            }
            .autoDisposable(view.scope())
            .subscribe()

        view.confirmDeleteIntent
            .autoDisposable(view.scope())
            .subscribe { conversations ->
                deleteConversations.execute(conversations)
                view.clearSelection()
            }

        view.conversationClicks
            .autoDisposable(view.scope())
            .subscribe { threadId -> navigator.showConversation(threadId) }

        view.selectionChanges
            .autoDisposable(view.scope())
            .subscribe { selection -> newState { copy(selected = selection.size) } }

        view.backClicked
            .withLatestFrom(state) { _, state ->
                when (state.selected) {
                    0 -> view.goBack()
                    else -> view.clearSelection()
                }
            }
            .autoDisposable(view.scope())
            .subscribe()
    }

}
