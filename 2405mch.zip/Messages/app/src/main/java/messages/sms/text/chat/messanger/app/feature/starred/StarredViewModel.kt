package messages.sms.text.chat.messanger.app.feature.starred

import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import messages.sms.text.chat.messanger.app.common.Navigator
import messages.sms.text.chat.messanger.app.common.base.QkViewModel
import messages.sms.text.chat.messanger.app.manager.PermissionManager
import messages.sms.text.chat.messanger.app.repository.StarredMessageRepository

import javax.inject.Inject

class StarredViewModel @Inject constructor(
    private val navigator: Navigator,
    scheduledMessageRepo: StarredMessageRepository,
    private val permissionManager: PermissionManager,
) : QkViewModel<StarredMessagesView, StarredMessagesState>(
    StarredMessagesState(
        data = scheduledMessageRepo.getStarredMessages()
    )
) {
    override fun bindView(view: StarredMessagesView) {
        super.bindView(view)
        view.conversationClicks
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDisposable(view.scope())
            .subscribe { it -> navigator.showConversation(it.threadId, null, it.id) }
    }
}