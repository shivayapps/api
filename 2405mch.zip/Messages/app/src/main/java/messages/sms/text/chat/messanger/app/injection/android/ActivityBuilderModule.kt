package messages.sms.text.chat.messanger.app.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import messages.sms.text.chat.messanger.app.appmanager.FindAppActivity
import messages.sms.text.chat.messanger.app.appmanager.ManageAppActivity
import messages.sms.text.chat.messanger.app.feature.backup.BackupActivity
import messages.sms.text.chat.messanger.app.feature.blocking.BlockingActivity
import messages.sms.text.chat.messanger.app.feature.compose.ComposeActivity
import messages.sms.text.chat.messanger.app.feature.compose.ComposeActivityModule
import messages.sms.text.chat.messanger.app.feature.contacts.ContactsActivity
import messages.sms.text.chat.messanger.app.feature.contacts.ContactsActivityModule
import messages.sms.text.chat.messanger.app.feature.contacts.GroupsActivity
import messages.sms.text.chat.messanger.app.feature.conversationinfo.ConversationInfoActivity
import messages.sms.text.chat.messanger.app.feature.gallery.GalleryActivity
import messages.sms.text.chat.messanger.app.feature.gallery.GalleryActivityModule
import messages.sms.text.chat.messanger.app.feature.main.ArchiveActivity
import messages.sms.text.chat.messanger.app.feature.main.ConversationsPickerActivity
import messages.sms.text.chat.messanger.app.feature.main.MainActivity
import messages.sms.text.chat.messanger.app.feature.main.MainActivityModule
import messages.sms.text.chat.messanger.app.feature.main.PermissionActivity
import messages.sms.text.chat.messanger.app.feature.main.PrivateContactActivity
import messages.sms.text.chat.messanger.app.feature.main.PrivateConversationsActivity
import messages.sms.text.chat.messanger.app.feature.main.SplashActivity
import messages.sms.text.chat.messanger.app.feature.notificationprefs.NotificationPrefsActivity
import messages.sms.text.chat.messanger.app.feature.notificationprefs.NotificationPrefsActivityModule
import messages.sms.text.chat.messanger.app.feature.personalize.BubbleActivity
import messages.sms.text.chat.messanger.app.feature.personalize.CropImageThemeActivity
import messages.sms.text.chat.messanger.app.feature.personalize.FontActivity
import messages.sms.text.chat.messanger.app.feature.personalize.RingtonesListActivity
import messages.sms.text.chat.messanger.app.feature.personalize.ThemeActivity
import messages.sms.text.chat.messanger.app.feature.personalize.ThemeImagePreviewActivity
import messages.sms.text.chat.messanger.app.feature.personalize.ThemePreviewActivity
import messages.sms.text.chat.messanger.app.feature.qkreply.QkReplyActivity
import messages.sms.text.chat.messanger.app.feature.qkreply.QkReplyActivityModule
import messages.sms.text.chat.messanger.app.feature.scheduled.ScheduledActivity
import messages.sms.text.chat.messanger.app.feature.scheduled.ScheduledActivityModule
import messages.sms.text.chat.messanger.app.feature.settings.AdvanceSettingsActivity
import messages.sms.text.chat.messanger.app.feature.settings.SettingsActivity
import messages.sms.text.chat.messanger.app.feature.settings.SwipeActionsActivity
import messages.sms.text.chat.messanger.app.feature.starred.StarredActivity
import messages.sms.text.chat.messanger.app.feature.starred.StarredActivityModule
import messages.sms.text.chat.messanger.app.injection.scope.ActivityScope
import messages.sms.text.chat.messanger.app.password.ChangePasswordActivity
import messages.sms.text.chat.messanger.app.password.ForgetPasswordActivity
import messages.sms.text.chat.messanger.app.password.HideEntranceActivity
import messages.sms.text.chat.messanger.app.password.PasswordActivity
import messages.sms.text.chat.messanger.app.password.PrivateSettingsActivity

@Module
abstract class ActivityBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindMainActivity(): MainActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindArchiveActivity(): ArchiveActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindConversionPickerActivity(): ConversationsPickerActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPrivateConversationsActivity(): PrivateConversationsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPrivateContactActivity(): PrivateContactActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPasswordActivity(): PasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindChangePasswordActivity(): ChangePasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindForgetPasswordActivity(): ForgetPasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPrivateSettingsActivity(): PrivateSettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindHideEntranceActivity(): HideEntranceActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBackupActivity(): BackupActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [StarredActivityModule::class])
    abstract fun bindStarredActivity(): StarredActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindFontActivity(): FontActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemeActivity(): ThemeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindCropImageThemeActivity(): CropImageThemeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBubbleActivity(): BubbleActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindRingtonesListActivity(): RingtonesListActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemePreviewActivity(): ThemePreviewActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindThemeImagePreviewActivity(): ThemeImagePreviewActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindFindAppActivity(): FindAppActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindManageAppActivity(): ManageAppActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ComposeActivityModule::class])
    abstract fun bindComposeActivity(): ComposeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ContactsActivityModule::class])
    abstract fun bindContactsActivity(): ContactsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindConversationInfoActivity(): ConversationInfoActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [GalleryActivityModule::class])
    abstract fun bindGalleryActivity(): GalleryActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [NotificationPrefsActivityModule::class])
    abstract fun bindNotificationPrefsActivity(): NotificationPrefsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [QkReplyActivityModule::class])
    abstract fun bindQkReplyActivity(): QkReplyActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ScheduledActivityModule::class])
    abstract fun bindScheduledActivity(): ScheduledActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSettingsActivity(): SettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindNewSettingsActivity(): AdvanceSettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSwipeActionsActivity(): SwipeActionsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSplashActivity(): SplashActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindPermissionActivity(): PermissionActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBlockingActivity(): BlockingActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindGroupsActivity(): GroupsActivity

}
