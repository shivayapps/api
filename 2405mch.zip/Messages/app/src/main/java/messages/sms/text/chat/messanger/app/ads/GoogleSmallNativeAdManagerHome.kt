package  messages.sms.text.chat.messanger.app.ads

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import androidx.core.content.res.ResourcesCompat
import com.applovin.mediation.MaxAd
import com.applovin.mediation.MaxError
import com.applovin.mediation.nativeAds.MaxNativeAdListener
import com.applovin.mediation.nativeAds.MaxNativeAdLoader
import com.applovin.mediation.nativeAds.MaxNativeAdView
import com.applovin.mediation.nativeAds.MaxNativeAdViewBinder
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import messages.sms.text.chat.messanger.app.R
import messages.sms.text.chat.messanger.app.commons.extensions.baseConfig

object GoogleSmallNativeAdManagerHome {
    private var mSmallNativeAd: NativeAd? = null
    private var mSmallNativeAdShow = false
    private var nativeAdViewLovinAdShow = false
    private var mSmallNativeAd8: NativeAd? = null
    private var mSmallNativeAd8Show = false
    fun loadSmallNativeHome(context: Context, mAdId: String, listener: (NativeAd?) -> Unit) {
        loadNativeHome(context, mAdId) {
            mSmallNativeAd = it
            listener(it)
        }
    }

    fun showNativeHome(context: Context, parentView: ViewGroup) {
        mSmallNativeAd?.let {
            AdmobNative.populateSmallNativeAd(context, parentView, it)
        } ?: manageShowNativeSmallHome(context, parentView)
    }

    private fun loadNativeHome(context: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected() || !AdsPreferences(context).adsEnable || AdsPreferences(
                context
            ).isPro
        ) {
            listener(null)
            return
        }
        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { listener(it) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener(null)
                    mSmallNativeAdShow = false
                }

                override fun onAdImpression() {
                    mSmallNativeAdShow = true
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    private var nativeAdLoader: MaxNativeAdLoader? = null
    private var nativeAd: MaxAd? = null
    var nativeAdViewLovin: MaxNativeAdView? = null
    fun loadApplovinSmallNative(context: Context, listener: (MaxNativeAdView?) -> Unit) {
        nativeAdLoader = MaxNativeAdLoader("2cb859026da47f4d", context).apply {
            setNativeAdListener(object : MaxNativeAdListener() {
                override fun onNativeAdLoaded(nativeAdView: MaxNativeAdView?, ad: MaxAd) {
                    nativeAd = ad
                    nativeAdViewLovin = nativeAdView
                    listener(nativeAdView)
                    nativeAdViewLovinAdShow = true
                    Log.e("loadApplovinSmallNative", "onNativeAdLoaded")
                }
                override fun onNativeAdLoadFailed(adUnitId: String, error: MaxError) {
                    listener(null)
                    nativeAdViewLovinAdShow = false
                    Log.e("loadApplovinSmallNative", "onNativeAdLoadFailed")
                }
                override fun onNativeAdExpired(ad: MaxAd) {
//                    loadApplovinSmallNative(context, listener)
                    Log.e("loadApplovinSmallNative", "onNativeAdExpired")
                }
            })
        }
        nativeAdLoader?.loadAd(createNativeAdViewHome(context))
    }

    fun showAdAppLovinHome(context: Context, parentView: ViewGroup) {
        if (nativeAd == null || nativeAdViewLovin == null || nativeAd?.nativeAd?.isExpired == true) {
            manageShowNativeSmallHome(context, parentView)
        } else {
            try {
                (nativeAdViewLovin?.parent as? ViewGroup)?.removeView(nativeAdViewLovin)
                parentView.removeAllViews()
                parentView.addView(nativeAdViewLovin)
            } catch (e: Exception) {
                manageShowNativeSmallHome(context, parentView)
            }
        }
    }

    fun loadSmallNative8Home(context: Context, mAdId: String, listener: (NativeAd?) -> Unit) {
        loadNative8Home(context, mAdId) {
            mSmallNativeAd8 = it
            listener(it)
        }
    }

    fun showNative8Home(context: Context, parentView: ViewGroup) {
        mSmallNativeAd8?.let {
            AdmobNative.populateSmallNativeAd(context, parentView, it)
        } ?: manageShowNativeSmallHome(context, parentView)
    }

    private fun manageShowNativeSmallHome(context: Context, parentView: ViewGroup) {
        val adsToShow = listOfNotNull(
            mSmallNativeAd.takeIf { mSmallNativeAdShow },
            mSmallNativeAd8.takeIf { mSmallNativeAd8Show },
            nativeAd.takeIf { nativeAdViewLovinAdShow }
        )

        if (adsToShow.isNotEmpty()) {
            if (nativeAdViewLovinAdShow) {

                try {
                    (nativeAdViewLovin?.parent as? ViewGroup)?.removeView(nativeAdViewLovin)
                    nativeAdViewLovin?.removeAllViews()
                    parentView.addView(nativeAdViewLovin)
                } catch (e: Exception) {
                    // manageShowNativeSmall(context,parentView)
                }
            } else {
                AdmobNative.populateSmallNativeAd(
                    context,
                    parentView,
                    adsToShow.first() as NativeAd
                )
            }
        }
    }

    private fun loadNative8Home(context: Context, adId: String, listener: (NativeAd?) -> Unit) {
        if (!context.isInternetConnected() || !AdsPreferences(context).adsEnable || AdsPreferences(
                context
            ).isPro
        ) {
            listener(null)
            return
        }

        val adLoader = AdLoader.Builder(context, adId)
            .forNativeAd { listener(it) }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    listener(null)
                    mSmallNativeAd8Show = false
                }

                override fun onAdImpression() {
                    mSmallNativeAd8Show = true
                }
            })
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    fun onDestroy() {
        mSmallNativeAd?.destroy()
        mSmallNativeAd = null
        nativeAd?.let { nativeAdLoader?.destroy(it) }
        nativeAdLoader?.destroy()
        mSmallNativeAd8?.destroy()
        mSmallNativeAd8 = null
    }

    private fun createNativeAdViewHome(context: Context): MaxNativeAdView {
        val binder = MaxNativeAdViewBinder.Builder(R.layout.layout_list_item_native_applovin)
            .setTitleTextViewId(R.id.title_text_view)
            .setBodyTextViewId(R.id.body_text_view)
            .setIconImageViewId(R.id.icon_image_view)
            .setCallToActionButtonId(R.id.cta_button)
            .build()

        val nativeAdView = MaxNativeAdView(binder, context)

        // Get the CTA button from the native ad view
        val ctaButton = nativeAdView.findViewById<Button>(R.id.cta_button)

        // Set the text color of the CTA button
        ctaButton.setTextColor(context.baseConfig.primaryColor)


        val applyBackground = ResourcesCompat.getDrawable(
            context.resources,
            R.drawable.ads_item_gradiant_rounded,
            null
        ) as LayerDrawable
        val strokeDrawable =
            applyBackground.findDrawableByLayerId(R.id.button_background_ads) as GradientDrawable
        strokeDrawable.setStroke(2, context.baseConfig.primaryColor)

        ctaButton.background = applyBackground

        return nativeAdView
    }
}