package  messages.sms.text.chat.messanger.app.ads

import androidx.multidex.MultiDexApplication
import com.applovin.sdk.AppLovinMediationProvider
import com.applovin.sdk.AppLovinSdk
import com.applovin.sdk.AppLovinSdkInitializationConfiguration
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

var isAdsNotShowOnResume = false
var isAppLovinSdkInt = false

open class AdsApplication : MultiDexApplication() {

    override fun onCreate() {
        super.onCreate()
        val backgroundScope = CoroutineScope(Dispatchers.IO)
        backgroundScope.launch {
            MobileAds.initialize(this@AdsApplication) {}
        }

        val intcong = AppLovinSdkInitializationConfiguration.builder(
            "ZJCSWEvZAV59lz75guAB1XnGS_SzloZrAtKNCdUcoM_2b95xxZbdKkvzqFIWsPi0G2who73BM9I75NeZQ1kqFe",
            this
        )
            .setMediationProvider(AppLovinMediationProvider.MAX)
            .build()

        AppLovinSdk.getInstance(this).initialize(intcong) {
            isAppLovinSdkInt = true
        }

//        AppLovinSdk.getInstance( this ).setMediationProvider( "max" )
//        AppLovinSdk.getInstance( this ).initializeSdk({ configuration: AppLovinSdkConfiguration ->
//            // AppLovin SDK is initialized, start loading ads
//            registerActivityLifecycleCallbacks(AdjustLifecycleCallbacks())
//        })


    }


}