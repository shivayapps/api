package com.bankbalanceinquiry.ministatement.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.AccountHistoryAdapter1;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.shuhart.stickyheader.StickyHeaderItemDecorator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class AccountHisotryFragment extends Fragment {

    private Activity activity;

    private RecyclerView rvAccountList;
    private ProgressBar pbLoading;
    private HomeAccoutList allAccountModel;

    private LinearLayout llEmpty;
    private TextView tvEmptyMessage;


    private DBHelperAccountNew dbHelperAccountHistory;
    private final ArrayList<HomeAccoutList> allAccountModelHistories = new ArrayList<>();
    private final ArrayList<HomeAccoutList> allData = new ArrayList<>();
    private AccountHistoryAdapter1 accountHistoryAdapter;
    int color, colorTransparent;

    View root;
    private Context context;
    String type = "All";
    private String balance = "", bankName = "";

    public AccountHisotryFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.activity_account_hisotry_test_fragment, container, false);
        context = getActivity();
        initView();
        return root;
    }

    private void initView() {
        pbLoading = root.findViewById(R.id.pbLoading);
        activity = getActivity();
        dbHelperAccountHistory = new DBHelperAccountNew(activity);

        pbLoading.setVisibility(View.VISIBLE);
        if (getArguments() != null) {
            allAccountModel = (HomeAccoutList) getArguments().getSerializable("OBJ");
            color = getArguments().getInt("color", ContextCompat.getColor(getContext(), R.color.colorPrimary));
            colorTransparent = getArguments().getInt("colorTransparent", ContextCompat.getColor(getContext(), R.color.colorPrimary));
            type = getArguments().getString("type", "All");
            balance = getArguments().getString("balance", "All");
            bankName = getArguments().getString("bankName", "All");
            if (color == 0 || color == -1) {
                color = ContextCompat.getColor(getContext(), R.color.colorPrimary);
            }
            if (colorTransparent == 0 || colorTransparent == -1) {
                colorTransparent = ContextCompat.getColor(getContext(), R.color.app_color_transparant1);
            }
            if (allAccountModel != null) {
                String name = allAccountModel.full_name.replace(" Bank", "");
            }
            //InitComponent();
            InitComponentNew();


        }

    }


    private void InitComponentNew() {
        rvAccountList = root.findViewById(R.id.rvAccountList);

//        NestedScrollView nestedScrollView = root.findViewById(R.id.nested);

        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        llEmpty = root.findViewById(R.id.llEmpty);
        tvEmptyMessage = root.findViewById(R.id.tvEmptyMessage);
        tvEmptyMessage.setText(getString(R.string.empty_transaction_history));

        accountHistoryAdapter = new AccountHistoryAdapter1(activity, allAccountModelHistories, color, colorTransparent, type, balance, bankName);
        StickyHeaderItemDecorator decorator = new StickyHeaderItemDecorator(accountHistoryAdapter);
        decorator.attachToRecyclerView(rvAccountList);
        rvAccountList.setAdapter(accountHistoryAdapter);

//        rvAccountList.setdec

        CheckDataNotifyOrNot();
        CallDb();

        /*
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (v.getChildAt(v.getChildCount() - 1) != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                            scrollY > oldScrollY) {
                        int size = allAccountModelHistories.size();
                        if (allData.size() > (size + 50)) {
                            for (int i = size; i < (size + 50); i++) {
                                allAccountModelHistories.add(allData.get(i));
                            }
                        } else if (allAccountModelHistories.size() != allData.size()) {
                            for (int i = size; i < allData.size(); i++) {
                                allAccountModelHistories.add(allData.get(i));
                            }
                        }
                        accountHistoryAdapter.notifyDataSetChanged();
                    }
                }
            }
        });*/

    }

    private void CheckDataNotifyOrNot() {
        if (CommonFun.isIncommingSmsNotify.equalsIgnoreCase("")) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    CheckDataNotifyOrNot();
                    Log.e("NotificationYes==>", "not Incomming");
                }
            }, 2000);
        } else {
            CommonFun.isIncommingSmsNotify = "";
            CallDb();
        }
    }

    private void CallDb() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                allAccountModelHistories.clear();
                allData.clear();
                allData.addAll(dbHelperAccountHistory.GetTransactionsType(allAccountModel.FinalAccountNo, allAccountModel.full_name, type));
//                allAccountModelHistories.addAll(dbHelperAccountHistory.GetTransactions(allAccountModel.FinalAccountNo, allAccountModel.full_name));
                ArrayList<HomeAccoutList> tmpdata = new ArrayList<>();
                ArrayList<HomeAccoutList> tmpdataFinal = new ArrayList<>();
                SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);

                if (allData.size() > 0) {
                    for (HomeAccoutList allDatum : allData) {
                        try {
                            Date date3 = formatterHistory.parse(allDatum.dateValHistory);
                            allDatum.dateLongValue = date3.getTime();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                    Collections.sort(allData, new Comparator<HomeAccoutList>() {
                        @Override
                        public int compare(HomeAccoutList t1, HomeAccoutList t2) {
                            return Long.valueOf(t2.dateLongValue).compareTo(Long.valueOf(t1.dateLongValue));
                        }
                    });
                    String ModelClickAccountNo = allAccountModel.FinalAccountNo;
                    for (int i = 0; i < allData.size(); i++) {
                        String ForiAccountName = allData.get(i).FinalAccountNo;
                        if (ModelClickAccountNo.equalsIgnoreCase(ForiAccountName)) {
                            tmpdata.add(allData.get(i));
                        }
                    }
                    if (tmpdata.size() > 0) {
                        String header = "";
                        ArrayList<String> CreditData = new ArrayList<>();
                        ArrayList<String> DebitData = new ArrayList<>();
                        boolean istitlefound = false;
                        for (int i = 0; i < tmpdata.size(); i++) {
                            istitlefound = false;
                            HomeAccoutList adddata = tmpdata.get(i);
                            if (!(header.equals(adddata.DateTransactionHistory))) {

                                String CheckCreditDebit = isDebitedOrCredited(adddata);
                                CreditData = new ArrayList<>();
                                DebitData = new ArrayList<>();

                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }

                                istitlefound = true;
                                HomeAccoutList sectionCell = new HomeAccoutList();
                                sectionCell.DateTransactionHistory = adddata.DateTransactionHistory;
                                sectionCell.dateLongValue = adddata.dateLongValue;
                                sectionCell.isSectionHeader = true;
                                sectionCell.GetTitleType = 0;
                                //  sectionCell.amount = tmpdata.get(i).amount;
                                sectionCell.CreditedData = CreditData;
                                sectionCell.DebitedData = DebitData;

                                tmpdataFinal.add(sectionCell);
                                header = adddata.DateTransactionHistory;
                            }

                            if (!istitlefound) {
                                String CheckCreditDebit = isDebitedOrCredited(tmpdata.get(i));
                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }
                            }

                            adddata.GetTitleType = 1;
                            tmpdataFinal.add(adddata);
                        }
                    }

                    allData.clear();
                    allData.addAll(tmpdataFinal);
                   /* if (allData.size() > 50) {
                        for (int i = 0; i < 50; i++) {
                            allAccountModelHistories.add(allData.get(i));
                        }
                    } else {
                        allAccountModelHistories.addAll(allData);
                    }  */
                    allAccountModelHistories.addAll(allData);

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            if (allAccountModelHistories.size() > 0) {
                                rvAccountList.setVisibility(View.VISIBLE);
                                llEmpty.setVisibility(View.GONE);
                                accountHistoryAdapter.notifyDataSetChanged();
                            } else {
                                rvAccountList.setVisibility(View.GONE);
                                llEmpty.setVisibility(View.VISIBLE);
                            }
                        }
                    });

                } else {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            rvAccountList.setVisibility(View.GONE);
                            llEmpty.setVisibility(View.VISIBLE);
                        }
                    });
                }
            }
        }).start();


    }


    private String isDebitedOrCredited(HomeAccoutList homeAccount) {
        String isDebitedOrCredited = "0";
        if (homeAccount.isAtmWithDraw) {
            isDebitedOrCredited = "0";
        } else if (homeAccount.isDebited) {
            isDebitedOrCredited = "0";
        } else {
            isDebitedOrCredited = "1";
        }
        return isDebitedOrCredited;
    }
}

