package com.bankbalanceinquiry.ministatement.model;

import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class newTransactionDataEvent implements Serializable {
    //false for if it is transaction;

    private ArrayList<HomeAccoutList> homeAccoutLists1 = new ArrayList<>();
    HashMap<String, HomeAccoutList> hashData = new HashMap<>();


    boolean isAccount = true;
    boolean isUpdateBalance = false;
    String updatedKey = "";

    boolean islangChanged = false;

    public newTransactionDataEvent(ArrayList<HomeAccoutList> homeAccoutLists1, HashMap<String, HomeAccoutList> hashData,boolean islangChanged) {
        this.homeAccoutLists1.clear();
        this.homeAccoutLists1.addAll(homeAccoutLists1);
        this.hashData.clear();
        this.hashData.putAll(hashData);
        this.islangChanged = islangChanged;

    }

    public newTransactionDataEvent(boolean isAccount, boolean isUpdateBalance, String updatedKey,ArrayList<HomeAccoutList> homeAccoutLists1, HashMap<String, HomeAccoutList> hashData) {
        this.isAccount = isAccount;
        this.isUpdateBalance = isUpdateBalance;
        this.updatedKey = updatedKey;
        this.homeAccoutLists1.clear();
        this.homeAccoutLists1.addAll(homeAccoutLists1);
        this.hashData.clear();
        this.hashData.putAll(hashData);
    }

    public void setHomeAccoutLists1(ArrayList<HomeAccoutList> homeAccoutLists1) {
        this.homeAccoutLists1 = homeAccoutLists1;
    }

    public boolean isIslangChanged() {
        return islangChanged;
    }

    public void setIslangChanged(boolean islangChanged) {
        this.islangChanged = islangChanged;
    }

    public boolean isAccount() {
        return isAccount;
    }

    public void setAccount(boolean account) {
        isAccount = account;
    }

    public ArrayList<HomeAccoutList> getHomeAccoutLists1() {
        return homeAccoutLists1;
    }

    public HashMap<String, HomeAccoutList> getHashData() {
        return hashData;
    }

    public void setHashData(HashMap<String, HomeAccoutList> hashData) {
        this.hashData = hashData;
    }

    public boolean isUpdateBalance() {
        return isUpdateBalance;
    }

    public void setUpdateBalance(boolean updateBalance) {
        isUpdateBalance = updateBalance;
    }

    public String getUpdatedKey() {
        return updatedKey;
    }

    public void setUpdatedKey(String updatedKey) {
        this.updatedKey = updatedKey;
    }
}
