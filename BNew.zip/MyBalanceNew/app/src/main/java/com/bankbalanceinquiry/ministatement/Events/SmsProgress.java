package com.bankbalanceinquiry.ministatement.Events;

public class SmsProgress {
    private int progress;
    boolean isShowProgress = true;

    public boolean isShowProgress() {
        return isShowProgress;
    }

    public void setShowProgress(boolean showProgress) {
        isShowProgress = showProgress;
    }

    public SmsProgress(int progress, boolean isShowProgress) {
        this.progress = progress;
        this.isShowProgress = isShowProgress;
    }

    public SmsProgress(int progress) {
        this.progress = progress;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }
}
