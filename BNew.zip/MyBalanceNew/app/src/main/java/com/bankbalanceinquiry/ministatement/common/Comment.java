package com.bankbalanceinquiry.ministatement.common;

public class Comment {

//    if (!account_DateFormate.equals("")) {
//        SimpleDateFormat spf = new SimpleDateFormat(account_DateFormate);
//        Date newDate = null;
//        try {
//            newDate = spf.parse(FinalAccountDate);
//            spf = new SimpleDateFormat("dd-MMM-yy");
//            FinalAccountDate = spf.format(newDate);
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
//
//    }
}
