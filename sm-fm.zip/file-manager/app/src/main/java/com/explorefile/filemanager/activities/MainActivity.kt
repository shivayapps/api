package com.explorefile.filemanager.activities

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AppOpsManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.IntentSender
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.adconfig.adsutil.admob.BannerAdHelper

import com.explorefile.filemanager.App
import com.explorefile.filemanager.BuildConfig
import com.explorefile.filemanager.R
import com.explorefile.filemanager.adapters.ViewPagerAdapter
import com.explorefile.filemanager.databinding.ActivityMainBinding
import com.explorefile.filemanager.databinding.MainShareFragmentBinding
import com.explorefile.filemanager.dialogs.ChangeSortingDialog
import com.explorefile.filemanager.dialogs.ConfirmationAdvancedDialog
import com.explorefile.filemanager.dialogs.ConfirmationDialog
import com.explorefile.filemanager.dialogs.CreateNewItemDialog
import com.explorefile.filemanager.dialogs.RateDialog
import com.explorefile.filemanager.dialogs.ThemeDialog
import com.explorefile.filemanager.extensions.*
import com.explorefile.filemanager.filecleaner.StorageAnalysisActivity
import com.explorefile.filemanager.fragments.ItemsFragment
import com.explorefile.filemanager.fragments.MyViewPagerFragment
import com.explorefile.filemanager.fragments.RecentsFragment
import com.explorefile.filemanager.fragments.MainHomeFragment
import com.explorefile.filemanager.fragments.ShareFragment
import com.explorefile.filemanager.fragments.StorageAnalysisFragment
import com.explorefile.filemanager.helpers.*
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.MyTheme
import com.explorefile.filemanager.models.RadioItem
import com.explorefile.filemanager.wi_fi_direct.CryptoHelper
import com.explorefile.filemanager.wi_fi_direct.FileTransferService
import com.explorefile.filemanager.wi_fi_direct.QRCodeHelper
import com.explorefile.filemanager.wi_fi_direct.ScanDialog
import com.explorefile.filemanager.wi_fi_direct.WiFiTransferHelper
import com.filepicker.config.FilePickerManager
import com.google.android.gms.ads.AdView
import com.google.android.material.tabs.TabLayout
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.stericson.RootTools.RootTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.collections.forEach

class MainActivity : BaseActivity(), WiFiTransferHelper.TransferListener {


    val binding by viewBinding(ActivityMainBinding::inflate)
//    private var mTabsToShow = ArrayList<Int>()

    companion object {
        var onNxtPage = false
        var onChangeColum = false
        var onChangeViewType = false
        var onChangeToggleName = false
        var isSelectable = false
        private const val MANAGE_STORAGE_RC = 201
        private const val PICKED_PATH = "picked_path"
        var mLastPath = ""
        var itemMoment = false
    }

    private var mStoredDateFormat = ""
    private var mStoredTimeFormat = ""
//    private var mStoredShowTabs = 0

    private val THEME_LIGHT = 0
    private val THEME_DARK = 1
    private val THEME_AUTO = 8

    private var curTextColor = 0
    private var curBackgroundColor = 0
    private var curPrimaryColor = 0
    private var curAccentColor = 0
    private var curSelectedThemeId = 0
    private var hasUnsavedChanges = false
    private var predefinedThemes = LinkedHashMap<Int, MyTheme>()

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
        setContentView(binding.root)
//        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
        appLaunched(BuildConfig.APPLICATION_ID)
        setupOptionsMenu()
        refreshMenuItems()
//        mTabsToShow = getTabsList()
        //checkForAppUpdate(binding.root)

//        if (!config.wasStorageAnalysisTabAdded && isOreoPlus()) {
//            config.wasStorageAnalysisTabAdded = true
////            if (config.showTabs and TAB_STORAGE_ANALYSIS == 0) {
////                config.showTabs += TAB_STORAGE_ANALYSIS
////            }
//        }

        initAd()
        storeStateVariables()
        setupTabs()
        setupDrawer()

        updateMaterialActivityViews(
            binding.mainCoordinator, null, useTransparentNavigation = false, useTopSearchMenu = true
        )

        if (savedInstanceState == null) {
            initFragments()
            tryInitFileManager()
            checkIfRootAvailable()
        }

        initColorVariables()

        setupThemes()

        updateLabelColors(getProperTextColor(), getProperBackgroundColor())
    }

    var mAdView: AdView? = null
    var isAdLoaded = false
    private fun initAd() {
        val adId = getString(R.string.b_main)
        BannerAdHelper.showBanner(
            this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.bannerMain,
            { isLoaded, adView, message ->
                mAdView = adView
                AdCache.bannerMain = adView
                isAdLoaded = isLoaded
            })
    }

    private fun setupDrawer() {
        setupShowHidden()
        setupTrash()
        setupLanguage()
        setupLanguage()
        setupShareApp()
        setupRate()
        setupPrivacy()
        setupVersion()

        binding.headerAnalyseHolder.setOnClickListener {
            startActivity(Intent(this, StorageAnalysisActivity::class.java))
        }
    }


    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        //binding.mainViewPager.setPagingEnabled(false)

        refreshMenuItems()
        updateMenuColors(getProperTextColor(), getProperBackgroundColor())

        getAllFragments().forEach {
            it?.onResume(getProperTextColor())
        }

        if (mStoredDateFormat != config.dateFormat || mStoredTimeFormat != getTimeFormat()) {
            getAllFragments().forEach {
                (it as? ItemOperationsListener)?.setupDateTimeFormat()
            }
        }

        if (binding.mainViewPager.adapter == null) {
            initFragments()
        }

        updateTextColors(binding.headerScrollview)

        setTheme(getThemeId())

        updateBackgroundColor(getCurrentBackgroundColor())
        getRecentsFragment()?.refreshFragment()
        if (onChangeColum) {
            onChangeColum = false
            updateFragmentColumnCounts()
        }
        if (onChangeViewType) {
            onChangeViewType = false
            getItemsFragment()?.refreshFragment()
        }
        if (onChangeToggleName) {
            onChangeToggleName = false
            getAllFragments().forEach {
                (it as? ItemOperationsListener)?.toggleFilenameVisibility()
            }
        }
        setupLanguage()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        storeStateVariables()
        onNxtPage = false
    }

    override fun onDestroy() {
        super.onDestroy()
        config.temporarilyShowHidden = false
        try {
            unregisterReceiver(fileTransferReceiver)
        } catch (e: Exception) {
            log("onDestroy.Exception:$e")
        }
        wifiTransferHelper.cleanup()
    }

    override fun onBackPressed() {
        val currentFragment = getCurrentFragment()
        if (binding.mainMenu.isSearchOpen) {
            binding.mainMenu.closeSearch()
        } else if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        } else if (currentFragment is MainHomeFragment) {

            ConfirmationDialog(
                this,
                "",
                R.string.are_you_sure_you_want_to_exit,
                R.string.yes,
                R.string.no,
                true,
                R.string.exit
            ) {
                finishAffinity()
            }
//            }
        } else if (currentFragment is RecentsFragment) {
            binding.mainViewPager.currentItem = 0
        } else if ((currentFragment as ItemsFragment).getBreadcrumbs().getItemCount() <= 1) {
            binding.mainViewPager.currentItem = 0
        } else {
            currentFragment.getBreadcrumbs().removeBreadcrumb()
            openPath(currentFragment.getBreadcrumbs().getLastItem().path)
        }
    }

    fun refreshMenuItems() {
        val currentFragment = getCurrentFragment() ?: return
        binding.mainMenu.getToolbar().menu.apply {
            findItem(R.id.sort).isVisible = currentFragment is ItemsFragment
            //findItem(R.id.change_view_type).isVisible = currentFragment !is MainHomeFragment
            findItem(R.id.change_view_type).isVisible = false
            findItem(R.id.add).isVisible = currentFragment is ItemsFragment

            findItem(R.id.temporarily_show_hidden).isVisible =
                !config.shouldShowHidden() && currentFragment is ItemsFragment

            findItem(R.id.stop_showing_hidden).isVisible =
                config.temporarilyShowHidden && currentFragment is ItemsFragment
        }
        if (
            currentFragment !is MainHomeFragment &&
            currentFragment !is StorageAnalysisFragment &&
            currentFragment !is ShareFragment
        ) {
            binding.mainMenu.nextPage()
        } else {
            binding.mainMenu.onHomePage()
            binding.mainMenu.pageName(this.getString(R.string.app_name))
        }

        if (currentFragment is MainHomeFragment) {
            if (itemMoment) {
                itemMoment = false
                getStorageFragment()?.refreshFragment()
            }
        }
    }

    private fun setupOptionsMenu() {
        binding.mainMenu.apply {
            getToolbar().inflateMenu(R.menu.menu)
            toggleHideOnScroll(false)
            setupMenu()

//            onSearchClosedListener = {
//                getAllFragments().forEach {
//                    it?.searchQueryChanged("")
//                }
//            }

            onDrawerListener = {
                openDrawer()
            }

            onBackListener = {
                onBackPressed()
            }

//            onSearchTextChangedListener = { text ->
//                getCurrentFragment()?.searchQueryChanged(text)
//            }

            getToolbar().setOnMenuItemClickListener { menuItem ->
                if (getCurrentFragment() == null) {
                    return@setOnMenuItemClickListener true
                }

                when (menuItem.itemId) {
                    R.id.sort -> showSortingDialog()
                    R.id.toggle_filename -> toggleFilenameVisibility()
                    R.id.add -> createNewItem()
                    R.id.change_view_type -> changeViewType()
                    R.id.temporarily_show_hidden -> tryToggleTemporarilyShowHidden()
                    R.id.stop_showing_hidden -> tryToggleTemporarilyShowHidden()
                    else -> return@setOnMenuItemClickListener false
                }
                return@setOnMenuItemClickListener true
            }
        }
    }

    private fun tryToggleTemporarilyShowHidden() {
        if (config.temporarilyShowHidden) {
            toggleTemporarilyShowHidden(false)
        } else {
            toggleTemporarilyShowHidden(true)
        }
    }

    private fun openDrawer() {
        binding.drawerLayout.openDrawer(GravityCompat.START)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(PICKED_PATH, getItemsFragment()?.currentPath ?: "")

    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val path = savedInstanceState.getString(PICKED_PATH) ?: internalStoragePath

        if (binding.mainViewPager.adapter == null) {
            binding.mainViewPager.onGlobalLayout {
                restorePath(path)
            }
        } else {
            restorePath(path)
        }
    }

    @SuppressLint("NewApi")
    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        isAskingPermissions = false
        if (requestCode == MANAGE_STORAGE_RC && isRPlus()) {
            actionOnPermission?.invoke(Environment.isExternalStorageManager())
        }
        if (requestCode == FilePickerManager.REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                val paths: MutableList<String> = FilePickerManager.obtainData(release = true)
                val uris = ArrayList<Uri>()
                for (path in paths) {
                    val file = File(path)
                    val uri = Uri.fromFile(file)   // Convert path → Uri
                    uris.add(uri)
                }
                selectedFileUris = uris

                val newSecret = CryptoHelper.generateSecureSecret()
                handshakeSecret = newSecret
                qrCodeBitmap = QRCodeHelper.generateQRCode(newSecret, 400)
                updateStatus("File selected. Share secret to connect.")
                updateUIState()


//                val rv = findViewById<RecyclerView>(R.id.rv_main)
//                rv.adapter = SampleAdapter(layoutInflater, ArrayList(list))
//                rv.layoutManager = LinearLayoutManager(this@SampleActivity)
            } else {
                Toast.makeText(this@MainActivity, "No File selected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun restorePath(path: String) {
        openPath(path, true)
    }

    private fun updateMenuColors(textColor: Int, currentBackgroundColor: Int) {
        updateStatusbarColor(currentBackgroundColor)
        binding.mainMenu.updateColors(textColor, currentBackgroundColor)
        binding.navView.setBackgroundColor(currentBackgroundColor)

        arrayOf(
            binding.myTextView,
            binding.headerTrashLabel,
            binding.headerTrash,
            binding.headerAnalyseLabel,
            binding.headerThemeLabel,
            binding.headerTheme,
            binding.headerLanguage,
            binding.headerLanguageLabel,
//            binding.headerHiddenLabel,
            binding.headerShareLabel,
            binding.headerRateLabel,
//            binding.headerRate,
            binding.headerPrivacyLabel,
        ).forEach {
            it.setTextColor(textColor)
        }

        arrayOf(
            binding.imageTrash,
            binding.imageTheme,
            binding.imageAnalyse,
            binding.imageLanguage,
//            binding.imageHidden,
            binding.imageShare,
            binding.imageRate,
            binding.imagePrivacy
//            binding.imageVersion
        ).forEach {
            it.setColorFilter(textColor)
        }

    }

    private fun storeStateVariables() {
        config.apply {
            mStoredDateFormat = dateFormat
            mStoredTimeFormat = context.getTimeFormat()
//            mStoredShowTabs = showTabs
        }
    }

    private fun tryInitFileManager() {
        val hadPermission = hasStoragePermission()
        handleStoragePermission {
            checkOTGPath()
            if (it) {
                if (binding.mainViewPager.adapter == null) {
                    initFragments()
                }

                binding.mainViewPager.onGlobalLayout {
                    initFileManager(!hadPermission)
                }
            } else {
                toast(R.string.no_storage_permissions)
                finishAffinity()
            }
        }
    }

    @SuppressLint("InlinedApi")
    private fun handleStoragePermission(callback: (granted: Boolean) -> Unit) {
        actionOnPermission = null
        if (hasStoragePermission()) {
            callback(true)
        } else {
            if (isRPlus()) {
                ConfirmationAdvancedDialog(
                    this, "", R.string.access_storage_prompt, R.string.ok, 0, false
                ) { success ->
                    if (success) {
                        isAskingPermissions = true
                        actionOnPermission = callback
                        try {
                            val intent =
                                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                            intent.addCategory("android.intent.category.DEFAULT")
                            intent.data = Uri.parse("package:$packageName")
//                            if (isPermissionOpen()) {
                            App.disabledOpenAds()
//                            }
                            startActivityForResult(intent, MANAGE_STORAGE_RC)
                        } catch (e: Exception) {
                            showErrorToast(e)
                            val intent = Intent()
                            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
//                            if (isPermissionOpen()) {
                            App.disabledOpenAds()
//                            }
                            startActivityForResult(intent, MANAGE_STORAGE_RC)
                        }
                    } else {
                        finishAffinity()
                    }
                }
            } else {
                handlePermission(PERMISSION_WRITE_STORAGE, callback)
            }
        }
    }


    private fun initFileManager(refreshRecents: Boolean) {
        if (intent.action == Intent.ACTION_VIEW && intent.data != null) {
            val data = intent.data
            if (data?.scheme == "file") {
                openPath(data.path!!)
            } else {
                val path = getRealPathFromURI(data!!)
                if (path != null) {
                    openPath(path)
                } else {
                    openPath(config.homeFolder)
                }
            }

            if (!File(data.path!!).isDirectory) {
                tryOpenPathIntent(data.path!!, false, finishActivity = true)
            }

            binding.mainViewPager.currentItem = 0
        } else {
            openPath(config.homeFolder)
        }

        if (refreshRecents) {
            getStorageFragment()?.refreshFragment()
            getRecentsFragment()?.refreshFragment()
        }
    }

    var lastRealTab = 0
    private fun initFragments() {

        val fragments = arrayListOf<Pair<Int, String>>()
        fragments.add(Pair(R.layout.main_home_fragment, getString(R.string.app_name)))
        fragments.add(Pair(R.layout.main_analysis_fragment, getString(R.string.storage_analysis)))
        fragments.add(Pair(R.layout.main_share_fragment, getString(R.string.share)))

        val viewPagerAdapter = ViewPagerAdapter(this@MainActivity, fragments)
        binding.mainViewPager.apply {
            adapter = viewPagerAdapter
            offscreenPageLimit = 2
            addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
                override fun onPageScrollStateChanged(state: Int) {}

                override fun onPageScrolled(
                    position: Int, positionOffset: Float, positionOffsetPixels: Int
                ) {
                }

                override fun onPageSelected(position: Int) {
                    if (position < 3) selectTab(position)
                    lastRealTab = position
                    getAllFragments().forEach {
                        (it as? ItemOperationsListener)?.finishActMode()
                    }
                    refreshMenuItems()
                }
            })

            onGlobalLayout {
                refreshMenuItems()
                setDirectTransfer()
            }
//            binding.tabLayout.setupWithViewPager(this)
//            val extraTab = binding.tabLayout.newTab()
//            extraTab.text = "Scan"
//            binding.tabLayout.addTab(extraTab)
//            binding.tabLayout.getTabAt(0)?.setIcon(R.drawable.ic_home)
//            binding.tabLayout.getTabAt(1)?.setIcon(R.drawable.ic_folder)
//            binding.tabLayout.getTabAt(2)?.setIcon(R.drawable.ic_settings)
        }

        binding.tabScan.setOnClickListener {
            openScanner()
        }

        binding.tabHome.setData(R.drawable.ic_bottom_home, "Home")
        binding.tabStorage.setData(R.drawable.ic_bottom_storage, "Storage")
        binding.tabShare.setData(R.drawable.ic_bottom_share, "Share")
        binding.tabScan.setData(R.drawable.ic_bottom_scan, "Scan")

        val tabs = listOf(binding.tabHome, binding.tabStorage, binding.tabShare)
        tabs.forEachIndexed { index, tab ->
            tab.setOnClickListener {
                binding.mainViewPager.currentItem = index
                selectTab(index)
            }
        }
        selectTab(0)

//        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
//            override fun onTabSelected(tab: TabLayout.Tab) {
//                val clickedPosition = tab.position
//                if (tab.position >= fragments.size) {
//
//                    openScanner()
//                    binding.tabLayout.getTabAt(lastRealTab)?.select()
//                    //tabLayout.getTabAt(0)?.select()
//                } else {
//                    // Normal ViewPager tab selected
//                    lastRealTab = clickedPosition
//                }
//            }
//
//            override fun onTabUnselected(tab: TabLayout.Tab) {}
//            override fun onTabReselected(tab: TabLayout.Tab) {}
//        })
    }

    fun openLockedDir() {
        val intent = (Intent(this, LockActivity::class.java))
        lockActivityResultLauncher.launch(intent)
    }

    var lockActivityResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        Log.e("POST_NOTIFICATIONS", "lockActivityResultLauncher:${result.resultCode}")
        if (result.resultCode == RESULT_OK) {
            val intent = Intent(this@MainActivity, LockedDirActivity::class.java)
            startActivity(intent)
        }
    }

    fun openApplicationManager() {
        if (hasUsageStatsPermission()) {
            startActivity(Intent(this, AppManagerActivity::class.java))
        } else {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            usageAccessLauncher.launch(intent)
        }
    }

    val usageAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (hasUsageStatsPermission()) {
            startActivity(
                Intent(
                    this,
                    AppManagerActivity::class.java
                )
            )
        } else {
            Toast.makeText(this, "Usage Access Required", Toast.LENGTH_SHORT).show()
        }
    }

    fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
        } else {
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun selectTab(selectedIndex: Int) {
        binding.tabHome.isSelectedTab = false
        binding.tabStorage.isSelectedTab = false
        binding.tabShare.isSelectedTab = false
        binding.tabScan.isSelectedTab = false

        when (selectedIndex) {
            0 -> {
                binding.tabHome.isSelectedTab = true
            }

            1 -> {
                binding.tabStorage.isSelectedTab = true
            }

            2 -> {
                binding.tabShare.isSelectedTab = true
            }
        }
//        tabs.forEachIndexed { index, tab ->
//            tab.isSelectedTab = (index == selectedIndex)
//        }
    }

    private fun openScanner() {
        val options =
            GmsDocumentScannerOptions.Builder()
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_BASE)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setGalleryImportAllowed(true)

//        when (selectedMode) {
//            FULL_MODE -> options.setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
//            BASIC_MODE -> options.setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_BASE)
//            BASIC_MODE_WITH_FILTER -> options.setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_BASE_WITH_FILTER)
//            else -> Log.e(TAG, "Unknown selectedMode: $selectedMode")
//        }
        options.setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
//        if (selectedPage == SINGLE_PAGE) {
//            options.setPageLimit(SINGLE_PAGE)
//        }

        GmsDocumentScanning.getClient(options.build())
            .getStartScanIntent(this)
            .addOnSuccessListener { intentSender: IntentSender ->
                scannerLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
            }
            .addOnFailureListener() { e: Exception ->
                Log.e("TAG", "Exception -> $e")
            }
    }

    private var scannerLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            handleActivityResult(result)
        }

    private fun handleActivityResult(activityResult: ActivityResult) {
        val resultCode = activityResult.resultCode
        val result = GmsDocumentScanningResult.fromActivityResultIntent(activityResult.data)
        if (resultCode == Activity.RESULT_OK && result != null) {
            Log.i("TAG", "Scan Result -> $result")
            lifecycleScope.launch(Dispatchers.IO) {
                val pages = result.pages
                if (pages!!.isNotEmpty()) {
                    val files = ArrayList<File>()
                    pages.forEach { page ->
                        page.imageUri?.let { uri ->
                            val file = File(uri.path!!) // convert URI to File (adjust if needed)
                            files.add(file)
                        }
                    }

                    // Generate PDF
                    generatePdf(files)

                    withContext(Dispatchers.Main) {
                        if (pages.size > 1) {
                            toast("Images saved successfully.")
//                            callback?.showSnackBar(
//                                ,
//                                R.color.color_on_primary,
//                                R.color.color_on_secondary,
//                                2000L
//                            )
                        } else {
                            toast("Image saved successfully.")
//                            callback?.showSnackBar(
//                                "Image saved successfully.",
//                                R.color.color_on_primary,
//                                R.color.color_on_secondary,
//                                2000L
//                            )
                        }
                    }

                }
            }

        } else if (resultCode == Activity.RESULT_CANCELED) {
            Log.e("Scanner", "Scan Result -> Cancelled...")
            toast("Cancelled")

        } else {
            Log.e("Scanner", "Scan Result -> Failed...")
        }
    }

    private fun setupTabs() {
        val action = intent.action
        val isPickFileIntent =
            action == RingtoneManager.ACTION_RINGTONE_PICKER || action == Intent.ACTION_GET_CONTENT || action == Intent.ACTION_PICK
        val isCreateDocumentIntent = action == Intent.ACTION_CREATE_DOCUMENT

//        if (isPickFileIntent) {
//            mTabsToShow.remove(TAB_STORAGE_ANALYSIS)
//            if (mTabsToShow.none { it and config.showTabs != 0 }) {
//                config.showTabs = TAB_FILES
//                mStoredShowTabs = TAB_FILES
//                mTabsToShow = arrayListOf(TAB_FILES)
//            }
//        } else if (isCreateDocumentIntent) {
//            mTabsToShow.clear()
//            mTabsToShow = arrayListOf(TAB_FILES)
//        }
    }

    private fun checkOTGPath() {
        ensureBackgroundThread {
            if (!config.wasOTGHandled && hasPermission(PERMISSION_WRITE_STORAGE) && hasOTGConnected() && config.OTGPath.isEmpty()) {
                getStorageDirectories().firstOrNull {
                    it.trimEnd('/') != internalStoragePath && it.trimEnd(
                        '/'
                    ) != sdCardPath
                }?.apply {
                    config.wasOTGHandled = true
                    config.OTGPath = trimEnd('/')
                }
            }
        }
    }

    private fun openPath(path: String, forceRefresh: Boolean = false) {
        var newPath = path
        val file = File(path)
        if (config.OTGPath.isNotEmpty() && config.OTGPath == path.trimEnd('/')) {
            newPath = path
        } else if (file.exists() && !file.isDirectory) {
            newPath = file.parent!!
        } else if (!file.exists() && !isPathOnOTG(newPath)) {
            newPath = internalStoragePath
        }

        getItemsFragment()?.openPath(newPath, forceRefresh)
    }

    private fun showSortingDialog() {
        ChangeSortingDialog(this, getCurrentFragment()!!.currentPath) {
            (getCurrentFragment() as? ItemsFragment)?.refreshFragment()
        }
    }

    private fun createNewItem() {
        CreateNewItemDialog(this@MainActivity, getCurrentFragment()!!.currentPath) {
            if (it) {
                (getCurrentFragment() as? ItemsFragment)?.refreshFragment()
            } else {
                this.toast(R.string.unknown_error_occurred)
            }
        }
    }

    private fun toggleFilenameVisibility() {
        config.displayFilenames = !config.displayFilenames
        getAllFragments().forEach {
            (it as? ItemOperationsListener)?.toggleFilenameVisibility()
        }
    }

    fun updateFragmentColumnCounts() {
        getAllFragments().forEach {
            (it as? ItemOperationsListener)?.columnCountChanged()
        }
    }

    private fun changeViewType() {
        if (config.viewType == VIEW_TYPE_LIST) {
            config.viewType = VIEW_TYPE_GRID
        } else {
            config.viewType = VIEW_TYPE_LIST
        }
//        ChangeViewTypeDialog(
//            this, getCurrentFragment()!!.currentPath
//        ) {
        getAllFragments().forEach {
            it?.refreshFragment()
        }
//        }
    }

    private fun toggleTemporarilyShowHidden(show: Boolean) {
        config.temporarilyShowHidden = show
        getAllFragments().forEach {
            it?.refreshFragment()
        }
    }

    private fun checkIfRootAvailable() {
        ensureBackgroundThread {
            config.isRootAvailable = RootTools.isRootAvailable()
            if (config.isRootAvailable && config.enableRootAccess) {
                RootHelpers(this).askRootIfNeeded {
                    config.enableRootAccess = it
                }
            }
        }
    }

    fun pickedPath(path: String) {
        val resultIntent = Intent()
        val uri = getFilePublicUri(File(path), BuildConfig.APPLICATION_ID)
        val type = path.getMimeType()
        resultIntent.setDataAndType(uri, type)
        resultIntent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }


    fun pickedRingtone(path: String) {
        val uri = getFilePublicUri(File(path), BuildConfig.APPLICATION_ID)
        val type = path.getMimeType()
        Intent().apply {
            setDataAndType(uri, type)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            putExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, uri)
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    fun pickedPaths(paths: ArrayList<String>) {
        val newPaths =
            paths.map { getFilePublicUri(File(it), BuildConfig.APPLICATION_ID) } as ArrayList
        val clipData = ClipData(
            "Attachment", arrayOf(paths.getMimeType()), ClipData.Item(newPaths.removeAt(0))
        )

        newPaths.forEach {
            clipData.addItem(ClipData.Item(it))
        }

        Intent().apply {
            this.clipData = clipData
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            setResult(Activity.RESULT_OK, this)
        }
        finish()
    }

    fun openedDirectory() {
        if (binding.mainMenu.isSearchOpen) {
            binding.mainMenu.closeSearch()
        }
    }

    private fun getRecentsFragment() = findViewById<RecentsFragment>(R.id.recents_fragment)
    fun getItemsFragment() = findViewById<ItemsFragment>(R.id.items_fragment)
    private fun getStorageFragment() = findViewById<MainHomeFragment>(R.id.storage_fragment)
    private fun getAnalysisFragment() =
        findViewById<StorageAnalysisFragment>(R.id.analysis_fragment)

    private fun getShareFragment() = findViewById<ShareFragment>(R.id.share_fragment)

    //    private fun getApplicationFragment() = findViewById<StorageFragment>(R.id.application_fragment)
    private fun getAllFragments(): ArrayList<MyViewPagerFragment<*>?> =
        arrayListOf(getStorageFragment(), getAnalysisFragment(), getShareFragment())
    //arrayListOf(getStorageFragment(), getItemsFragment(), getRecentsFragment())

    fun getCurrentFragment(): MyViewPagerFragment<*>? {
//        val showTabs = config.showTabs
        val fragments = arrayListOf<MyViewPagerFragment<*>>()

        fragments.add(getStorageFragment())
        fragments.add(getAnalysisFragment())
        fragments.add(getShareFragment())

//        fragments.add(getItemsFragment())
//        fragments.add(getRecentsFragment())
        return fragments.getOrNull(binding.mainViewPager.currentItem)
    }

//    private fun getTabsList() = arrayListOf(TAB_STORAGE_ANALYSIS, TAB_RECENT_FILES, TAB_FILES)


    private fun setupShowHidden() {
//        binding.headerHidden.isChecked = config.showHidden
//        binding.headerHiddenHolder.setOnClickListener {
//            toggleShowHidden()
//        }
    }

    private fun toggleShowHidden() {
//        binding.headerHidden.toggle()
//        config.showHidden = binding.headerHidden.isChecked
    }

    private fun setupVersion() {
//        binding.headerVersion.text = BuildConfig.VERSION_NAME
    }

    private fun setupPrivacy() {
        binding.headerPrivacyHolder.setOnClickListener {
            startActivity(Intent(this@MainActivity, StorageAnalysisActivity::class.java))
//            launchViewIntent(getPrivacyPolicy())
        }
    }

    private fun setupRate() {
        binding.headerRateHolder.setOnClickListener {
            RateDialog(this) {}
        }
    }

    private fun setupShareApp() {
        binding.headerShareHolder.setOnClickListener {
            val sendIntent = Intent()
            sendIntent.action = Intent.ACTION_SEND
            sendIntent.putExtra(
                Intent.EXTRA_TEXT,
                "Hey check out my app at: https://play.google.com/store/apps/details?id=$packageName"
            )
            sendIntent.type = "text/plain"
            startActivity(sendIntent)
        }
    }

    private fun setupLanguage() {
        binding.headerLanguageHolder.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    LanguageActivity::class.java
                ).putExtra(INTENT_KEY, LANGUAGE_KEY)
            )
            finish()
        }

        binding.headerLanguage.text = when (config.languageSting) {
            "en" -> this.resources.getString(R.string.english)

            "de" -> this.resources.getString(R.string.german)

            "es" -> this.resources.getString(R.string.spanish)

            "fil" -> this.resources.getString(R.string.filipino)

            "fr" -> this.resources.getString(R.string.french)

            "hi" -> this.resources.getString(R.string.hindi)

            "in" -> this.resources.getString(R.string.indonesian)

            "it" -> this.resources.getString(R.string.italian)

            "tr" -> this.resources.getString(R.string.turkish)

            "zh" -> this.resources.getString(R.string.chinese)

            "ar" -> this.resources.getString(R.string.arabic)

            "ru" -> this.resources.getString(R.string.russian)

            "ja" -> this.resources.getString(R.string.japanese)

            else -> {
                this.resources.getString(R.string.english)
            }
        }
    }

    private fun setupTrash() {
        binding.headerTrashHolder.setOnClickListener {
            startActivity(Intent(this, TrashedActivity::class.java))
        }
    }

    private fun setupThemes() {
        predefinedThemes.apply {
            put(
                THEME_LIGHT,
                MyTheme(
                    getString(R.string.light_theme),
                    R.color.theme_light_text_color,
                    R.color.theme_light_background_color,
                    R.color.color_primary
                )
            )

            put(
                THEME_DARK,
                MyTheme(
                    getString(R.string.dark_theme),
                    R.color.theme_dark_text_color,
                    R.color.theme_dark_background_color,
                    R.color.color_primary
                )
            )
        }
        setupThemePicker()
    }

    private fun setupThemePicker() {
        curSelectedThemeId = getCurrentThemeId()
        binding.headerTheme.text = getThemeText()
        binding.headerThemeHolder.setOnClickListener {
            themePickerClicked()
        }
    }

    private fun themePickerClicked() {
        val items = arrayListOf<RadioItem>()
        for ((key, value) in predefinedThemes) {
            items.add(RadioItem(key, value.label))
        }

        ThemeDialog(this@MainActivity, items, curSelectedThemeId) {
            updateColorTheme(it as Int)
            saveChanges()
        }
    }

    private fun updateColorTheme(themeId: Int) {
        curSelectedThemeId = themeId
        binding.headerTheme.text = getThemeText()

        resources.apply {
            val theme = predefinedThemes[curSelectedThemeId]!!
            curTextColor = getColor(theme.textColorId)
            curBackgroundColor = getColor(theme.backgroundColorId)

            if (curSelectedThemeId != THEME_AUTO) {
                curPrimaryColor = getColor(theme.primaryColorId)
                curAccentColor = getColor(R.color.color_primary)
            }

            setTheme(getThemeId())
            colorChanged()
        }

        hasUnsavedChanges = true

        updateLabelColors(getCurrentTextColor(), getCurrentBackgroundColor())
        updateBackgroundColor(getCurrentBackgroundColor())
    }

    private fun getAutoThemeColors(): MyTheme {
        val isUsingSystemDarkTheme = isUsingSystemDarkTheme()
        val textColor =
            if (isUsingSystemDarkTheme) R.color.theme_dark_text_color else R.color.theme_light_text_color
        val backgroundColor =
            if (isUsingSystemDarkTheme) R.color.theme_dark_background_color else R.color.theme_light_background_color
        return MyTheme(
            getString(R.string.auto_light_dark_theme),
            textColor,
            backgroundColor,
            R.color.color_primary
        )
    }

    private fun getCurrentThemeId(): Int {
        var themeId = THEME_AUTO
        resources.apply {
            for ((key, value) in predefinedThemes.filter { it.key != THEME_AUTO }) {
                if (curTextColor == getColor(value.textColorId) &&
                    curBackgroundColor == getColor(value.backgroundColorId) &&
                    curPrimaryColor == getColor(value.primaryColorId)
                ) {
                    themeId = key
                }
            }
        }

        return themeId
    }

    private fun getThemeText(): String {
        var label = getString(R.string.custom)
        for ((key, value) in predefinedThemes) {
            if (key == curSelectedThemeId) {
                label = value.label
            }
        }
        return label
    }

    private fun saveChanges() {
        when (curSelectedThemeId) {
            THEME_DARK -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }

            THEME_LIGHT -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
        baseConfig.apply {
            textColor = curTextColor
            backgroundColor = curBackgroundColor
            primaryColor = curPrimaryColor
            accentColor = curAccentColor
        }
        hasUnsavedChanges = false
        this.recreate()
    }

    private fun initColorVariables() {
        curTextColor = baseConfig.textColor
        curBackgroundColor = baseConfig.backgroundColor
        curPrimaryColor = baseConfig.primaryColor
        curAccentColor = baseConfig.accentColor
    }

    private fun colorChanged() {
        hasUnsavedChanges = true
    }

    private fun updateLabelColors(textColor: Int, currentBackgroundColor: Int) {
        updateMenuColors(textColor, currentBackgroundColor)

        getAllFragments().forEach {
            it?.onResume(textColor)
        }
    }

    private fun getCurrentTextColor() = curTextColor

    private fun getCurrentBackgroundColor() = curBackgroundColor

    //setDirectTransfer


    private lateinit var wifiTransferHelper: WiFiTransferHelper
    private var handshakeSecret: String? = null
    private var isSender: Boolean = false
//    private var selectedFileUri: Uri? = null
    private var selectedFileUris: ArrayList<Uri>? = null

    //    private var selectedSaveDirectory: Uri? = null
    private var selectedSaveDirectory: Uri =
        Uri.fromFile(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))

    private var peerIpAddress: String? = null
    private var waitingForSecret: Boolean = false
    private var qrCodeBitmap: Bitmap? = null
    private var isSearchingDevices: Boolean = false
    private var receivedFilePath: String = ""

    // Transfer Progress Variables
    private var isTransferInProgress: Boolean = false
    private var bytesTransferred: Long = 0L
    private var totalBytes: Long = 0L

    private var status: String = "Ready to start secure file transfer"
    lateinit var shareBind: MainShareFragmentBinding
    private fun setDirectTransfer() {
        wifiTransferHelper = WiFiTransferHelper(this)
        shareBind = getShareFragment().binding

        shareBind.btnSend.setOnClickListener {
            if (!checkAndRequestPermissions()) return@setOnClickListener
            isSender = true
            updateStatus("Select a file to send")
            log("btnSend.click")
//            pickFileLauncher.launch("*/*")
            FilePickerManager
                .from(this@MainActivity)
//                .setTheme(com.filepicker.R.style.FilePickerThemeCrane)
                .maxSelectable(10)
                .forResult(FilePickerManager.REQUEST_CODE)
        }

        shareBind.btnReceive.setOnClickListener {
            if (!checkAndRequestPermissions()) return@setOnClickListener
            isSender = false
            resetState()
//            updateStatus("Select a directory to save received files")
            log("btnReceive.click")
            waitingForSecret = true
            updateStatus("Scan sender's QR code.")
            updateUIState()
//            directoryPickerLauncher.launch(null)
            ScanDialog(this) { mode ->
                if (mode == 0) {
                    showScannerDialog()
                } else if (mode == 1) {
                    showManualSecretDialog()
                }
            }
        }

        shareBind.btnCopySecret.setOnClickListener {
            copyToClipboard(handshakeSecret ?: "")
        }

        shareBind.btnShowQRCode.setOnClickListener {
            if (qrCodeBitmap == null && handshakeSecret != null) {
                qrCodeBitmap = QRCodeHelper.generateQRCode(handshakeSecret!!, 400)
            }
            showQRCodeDialog()
        }

        shareBind.btnNewSecret.setOnClickListener {
            val newSecret = CryptoHelper.generateSecureSecret()
            handshakeSecret = newSecret
            qrCodeBitmap = QRCodeHelper.generateQRCode(newSecret, 400)
            shareBind.tvSecretCode.text = newSecret
            Toast.makeText(this, "New secret generated!", Toast.LENGTH_SHORT).show()
        }

        shareBind.btnShareSecret.setOnClickListener {
            copyToClipboard(handshakeSecret ?: "")
            Toast.makeText(this, "Secret copied! Share it with the receiver.", Toast.LENGTH_LONG)
                .show()
        }

//        shareBind.btnScanQRCode.setOnClickListener {
//            showScannerDialog()
//        }
//
//        shareBind.btnManualSecret.setOnClickListener {
//            showManualSecretDialog()
//        }

//        shareBind.btnAbout.setOnClickListener {
//            showAboutDialog()
//        }

        //////////////////////
        val filter = IntentFilter().apply {
            addAction(FileTransferService.Companion.ACTION_TRANSFER_PROGRESS)
            addAction(FileTransferService.Companion.ACTION_TRANSFER_COMPLETE)
            addAction(FileTransferService.Companion.ACTION_SENDER_STATUS_UPDATE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(fileTransferReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(fileTransferReceiver, filter)
        }

        // Handle back button
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isTransferInProgress || waitingForSecret || handshakeSecret != null) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Cancel Operation?")
                        .setMessage("Do you want to stop the current operation?")
                        .setPositiveButton("Yes") { _, _ -> resetToIdle() }
                        .setNegativeButton("No", null)
                        .show()
                } else {
                    isEnabled = false
                    onBackPressed()
                }
            }
        })
    }


    private val fileTransferReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return

            log("fileTransferReceiver.onReceive")
            when (intent.action) {
                FileTransferService.Companion.ACTION_TRANSFER_PROGRESS -> {
                    val bytesProcessed =
                        intent.getLongExtra(FileTransferService.Companion.EXTRA_PROGRESS_BYTES, 0)
                    val totalBytes =
                        intent.getLongExtra(FileTransferService.Companion.EXTRA_TOTAL_BYTES, 0)
                    val speed =
                        intent.getFloatExtra(FileTransferService.Companion.EXTRA_TRANSFER_SPEED, 0f)
                    val isSending =
                        intent.getBooleanExtra(
                            FileTransferService.Companion.EXTRA_IS_SENDING,
                            false
                        )
                    val operationType =
                        intent.getStringExtra(FileTransferService.Companion.EXTRA_OPERATION_TYPE)
                            ?: ""

                    // Update local variables
                    isTransferInProgress = true
                    this@MainActivity.bytesTransferred = bytesProcessed
                    this@MainActivity.totalBytes = totalBytes

                    // Calculate progress
                    val progressFloat = if (totalBytes > 0) {
                        (bytesProcessed.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                    } else {
                        0f
                    }

                    // Construct the Status String
                    val statusText = when (operationType) {
                        "encrypting" -> "🔐 Encrypting file... ${(progressFloat * 100).toInt()}%"
                        "encrypting_and_sending" -> {
                            val speedText = if (speed > 0) " (${formatSpeed(speed)})" else ""
                            if (totalBytes > 0) {
                                val progressText =
                                    "${formatBytes(bytesProcessed)}/${formatBytes(totalBytes)}"
                                "📤 Encrypting and sending: $progressText (${(progressFloat * 100).toInt()}%)$speedText"
                            } else {
                                "📤 Encrypting and sending: ${formatBytes(bytesProcessed)}$speedText"
                            }
                        }

                        "sending" -> {
                            val speedText = if (speed > 0) " (${formatSpeed(speed)})" else ""
                            if (totalBytes > 0) {
                                val progressText =
                                    "${formatBytes(bytesProcessed)}/${formatBytes(totalBytes)}"
                                "📤 Sending: $progressText (${(progressFloat * 100).toInt()}%)$speedText"
                            } else {
                                "📤 Sending: ${formatBytes(bytesProcessed)}$speedText"
                            }
                        }

                        "waiting_for_connection" -> "⏳ Waiting for sender connection..."
                        "receiving_and_decrypting" -> {
                            val speedText = if (speed > 0) " (${formatSpeed(speed)})" else ""
                            if (totalBytes > 0) {
                                val progressText =
                                    "${formatBytes(bytesProcessed)}/${formatBytes(totalBytes)}"
                                "📥 Receiving: $progressText (${(progressFloat * 100).toInt()}%)$speedText"
                            } else {
                                "📥 Receiving: ${formatBytes(bytesProcessed)}$speedText"
                            }
                        }

                        "verifying_integrity" -> "🔍 Verifying file integrity..."
                        else -> {
                            val speedText = if (speed > 0) " (${formatSpeed(speed)})" else ""
                            if (isSending) {
                                "📤 Sending: ${formatBytes(bytesProcessed)}$speedText"
                            } else {
                                "📥 Receiving: ${formatBytes(bytesProcessed)}$speedText"
                            }
                        }
                    }

                    // --- UI UPDATES (Required for XML Views) ---
                    runOnUiThread {
                        shareBind.tvStatus.text = statusText

                        // Logic to handle Progress Bar visualization
                        // If we have total bytes, we can show a determinate progress bar
                        // Note: You might want to switch your XML ProgressBar style to horizontal for this
                        if (totalBytes > 0) {
                            shareBind.progressSearching.visibility = View.VISIBLE
                            shareBind.progressSearching.isIndeterminate = false
                            shareBind.progressSearching.max = 100
                            shareBind.progressSearching.progress = (progressFloat * 100).toInt()
                        } else {
                            // If size unknown or preparing, show indeterminate
                            shareBind.progressSearching.visibility = View.VISIBLE
                            shareBind.progressSearching.isIndeterminate = true
                        }
                    }
                }

                FileTransferService.Companion.ACTION_SENDER_STATUS_UPDATE -> {
                    val operationType =
                        intent.getStringExtra(FileTransferService.Companion.EXTRA_OPERATION_TYPE)
                            ?: ""
                    val verificationProgress =
                        intent.getIntExtra(
                            FileTransferService.Companion.EXTRA_VERIFICATION_PROGRESS,
                            0
                        )

                    runOnUiThread {
                        isTransferInProgress = true
                        shareBind.progressSearching.visibility = View.VISIBLE

                        when (operationType) {
                            "file_sent_waiting_verification" -> {
                                shareBind.tvStatus.text =
                                    "✅ File sent successfully! Waiting for receiver verification..."
                                shareBind.progressSearching.isIndeterminate = true
                            }

                            "receiver_verifying" -> {
                                shareBind.tvStatus.text =
                                    "🔍 Receiver verifying file integrity... $verificationProgress%"
                                shareBind.progressSearching.isIndeterminate = false
                                shareBind.progressSearching.max = 100
                                shareBind.progressSearching.progress = verificationProgress
                            }
                        }
                    }
                }

                FileTransferService.Companion.ACTION_TRANSFER_COMPLETE -> {
                    val success = intent.getBooleanExtra("success", false)
                    val message = intent.getStringExtra("message") ?: "Unknown result"
                    val filePath = intent.getStringExtra("file_path")

                    runOnUiThread {
                        isSearchingDevices = false
                        isTransferInProgress = false
                        bytesTransferred = 0L
                        totalBytes = 0L

                        // Hide progress bar on completion
                        shareBind.progressSearching.visibility = View.GONE

                        shareBind.tvStatus.text = message

                        if (success) {
                            Toast.makeText(
                                this@MainActivity,
                                "Transfer completed successfully!",
                                Toast.LENGTH_LONG
                            ).show()

                            // Handle Receiver Success Dialog
                            if (!isSender && filePath != null) {
                                receivedFilePath = filePath
                                showFileReceivedDialog(filePath) // Function call, not state boolean
                            } else {
                                resetToIdle()
                            }
                        } else {
                            Toast.makeText(
                                this@MainActivity,
                                "Transfer failed: $message",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        }
    }
//    private val pickFileLauncher =
//        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
//            log("pickFileLauncher.result")
//            if (uri != null) {
//                selectedFileUri = uri
//                // Generate secret immediately after picking file
//                val newSecret = CryptoHelper.generateSecureSecret()
//                handshakeSecret = newSecret
//                qrCodeBitmap = QRCodeHelper.generateQRCode(newSecret, 400)
//                updateStatus("File selected. Share secret to connect.")
//                updateUIState()
//            } else {
//                resetToIdle()
//            }
//        }
    private val directoryPickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            log("directoryPickerLauncher.result")
//            if (uri != null) {
//                selectedSaveDirectory = uri
            waitingForSecret = true
            updateStatus("Directory selected. Scan sender's QR code.")
            updateUIState()
//            } else {
//                resetToIdle()
//            }
        }

    private val qrScannerLauncher = registerForActivityResult(ScanContract()) { result ->
        log("qrScannerLauncher.result")
        if (result.contents != null) {
            handshakeSecret = result.contents
            waitingForSecret = false
            updateStatus("Secret scanned! Connecting to sender...")
            startWifiTransfer()
        } else {
            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            log("permissionLauncher.result")
            val allGranted = permissions.entries.all { it.value }
            if (allGranted) {
                Toast.makeText(this, "Permissions granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    "Permissions are required for file transfer",
                    Toast.LENGTH_LONG
                ).show()
            }
        }


    private fun log(message: String) {
        Log.e("FTPDemo", "message:$message")
    }

    private fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1_000_000_000 -> String.format("%.1f GB", bytes / 1_000_000_000.0)
            bytes >= 1_000_000 -> String.format("%.1f MB", bytes / 1_000_000.0)
            bytes >= 1_000 -> String.format("%.1f KB", bytes / 1_000.0)
            else -> "$bytes B"
        }
    }

    private fun formatSpeed(bytesPerSecond: Float): String {
        return when {
            bytesPerSecond >= 1_000_000_000 -> String.format(
                "%.1f GB/s",
                bytesPerSecond / 1_000_000_000.0
            )

            bytesPerSecond >= 1_000_000 -> String.format("%.1f MB/s", bytesPerSecond / 1_000_000.0)
            bytesPerSecond >= 1_000 -> String.format("%.1f KB/s", bytesPerSecond / 1_000.0)
            else -> String.format("%.0f B/s", bytesPerSecond)
        }
    }

    private fun updateUIState() {
        log("updateUIState.updateUIState")
        runOnUiThread {
            // Status update
            shareBind.tvStatus.text =
                if (isSearchingDevices) "🔍 Searching for devices..." else status
            shareBind.progressSearching.visibility =
                if (isSearchingDevices) View.VISIBLE else View.GONE

            // Buttons enable/disable
            shareBind.btnSend.isEnabled =
                !waitingForSecret && !isSearchingDevices && !isTransferInProgress
            shareBind.btnReceive.isEnabled =
                !waitingForSecret && !isSearchingDevices && !isTransferInProgress

            // Sender Specific UI (Secret Generation)
            if (handshakeSecret != null && isSender) {
                shareBind.cardSecret.visibility = View.VISIBLE
                shareBind.cardInfo.visibility = View.GONE
                shareBind.tvSecretCode.text = handshakeSecret

                // Show QR/Secret sharing options only for sender
                shareBind.btnShowQRCode.visibility = View.VISIBLE
                shareBind.btnNewSecret.visibility = View.VISIBLE
                shareBind.btnShareSecret.visibility = View.VISIBLE
            } else if (waitingForSecret && !isSender) {
                // Receiver Specific UI
                shareBind.cardSecret.visibility = View.GONE
                shareBind.cardInfo.visibility = View.VISIBLE
//                shareBind.btnScanQRCode.visibility = View.VISIBLE
//                shareBind.btnManualSecret.visibility = View.VISIBLE
            } else {
                // Reset/Idle state
                shareBind.cardSecret.visibility = View.GONE
                shareBind.cardInfo.visibility = View.VISIBLE
//                shareBind.btnScanQRCode.visibility = View.GONE
//                shareBind.btnManualSecret.visibility = View.GONE
            }
        }
    }

    private fun updateStatus(message: String) {
        log("updateStatus:$message")
        status = message
        runOnUiThread {
            shareBind.tvStatus.text = message
        }
    }

    // --- Dialogs ---
    private fun showQRCodeDialog() {
        val imageView = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(600, 600)
            setPadding(32, 32, 32, 32)
            qrCodeBitmap?.let { setImageBitmap(it) }
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(imageView)
            val secretText = TextView(context).apply {
                text = handshakeSecret
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                setPadding(16, 16, 16, 16)
                setTextIsSelectable(true)
            }
            addView(secretText)
        }

        AlertDialog.Builder(this)
            .setTitle("📱 Share QR Code")
            .setView(container)
            .setPositiveButton("Continue") { _, _ -> startWifiTransfer() }
            .setNegativeButton("Cancel") { _, _ -> resetToIdle() }
            .show()
    }

    private fun showScannerDialog() {
        val options = ScanOptions().apply {
            setPrompt("Scan the sender's QR code")
            setBeepEnabled(true)
            setOrientationLocked(true)
            setBarcodeImageEnabled(true)
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            setCameraId(0) // Use back camera
            setTimeout(30000)
        }
        qrScannerLauncher.launch(options)
    }

    private fun showManualSecretDialog() {
        val input = EditText(this).apply {
            hint = "Enter Secret Code"
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(48, 16, 48, 16)
            }
        }

        val container = FrameLayout(this)
        container.addView(input)

        AlertDialog.Builder(this)
            .setTitle("⌨️ Enter Secret Manually")
            .setMessage("Enter the complete secret code from the sender's device.")
            .setView(container)
            .setPositiveButton("Confirm") { _, _ ->
                val secret = input.text.toString().trim()
                if (secret.length >= 32) {
                    handshakeSecret = secret
                    status = "Secret received! Connecting to sender..."
                    waitingForSecret = false
                    updateUIState()
                    startWifiTransfer()
                } else {
                    Toast.makeText(this, "Secret code seems too short", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel") { _, _ -> }
            .show()
    }

    private fun showConfirmDialog() {
        val message = if (isSender) {
            "Connected to receiver device! Verify the secret codes match on both screens.\n\nSecret: $handshakeSecret"
        } else {
            "Connected to sender device! Verify the secret codes match on both screens.\n\nSecret: $handshakeSecret"
        }

        AlertDialog.Builder(this)
            .setTitle(if (isSender) "📤 Ready to Send" else "📥 Ready to Receive")
            .setMessage(message)
            .setPositiveButton(if (isSender) "Start Sending" else "Ready to Receive") { _, _ ->
                startFileTransfer()
            }
            .setNegativeButton("Cancel") { _, _ ->
                resetToIdle()
            }
            .setCancelable(false)
            .show()
    }

    private fun showFileReceivedDialog(filePath: String) {
        AlertDialog.Builder(this)
            .setTitle("✅ File Received Successfully")
            .setMessage("Saved at: $filePath")
            .setPositiveButton("Open Location") { _, _ ->
                openFileLocation(filePath)
            }
            .setNegativeButton("Dismiss", null)
            .show()
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("ℹ️ About Secure File Transfer")
            .setMessage("• Wi-Fi Direct: Direct device connection\n• QR Codes: Secure secret sharing\n• AES-256: Military-grade encryption\n\nDeveloped by: 4skl with AI")
            .setPositiveButton("Close", null)
            .show()
    }

    // --- Helper Functions ---

    private fun resetToIdle() {
        waitingForSecret = false
        isSender = false
        status = "Ready to start secure file transfer"
        resetState()
        updateUIState()
    }

    private fun resetState() {
        handshakeSecret = null
//        selectedFileUri = null
        selectedFileUris?.clear()
        peerIpAddress = null
        isSearchingDevices = false
        cleanupTransferData()
    }

    private fun cleanupTransferData() {
        isTransferInProgress = false
        bytesTransferred = 0L
        totalBytes = 0L
        qrCodeBitmap = null
        //System.gc()
    }

    private fun copyToClipboard(text: String) {
        log("copyToClipboard")
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("SecureTransfer Secret", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    private fun checkAndRequestPermissions(): Boolean {
        log("checkAndRequestPermissions")
        if (!hasRequiredPermissions()) {
            AlertDialog.Builder(this)
                .setTitle("🔐 Permissions Required")
                .setMessage("Location and Wi-Fi permissions are required for file transfer.")
                .setPositiveButton("Grant") { _, _ -> requestRequiredPermissions() }
                .setNegativeButton("Cancel", null)
                .show()
            return false
        }
        return true
    }

    private fun hasRequiredPermissions(): Boolean {
        val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.CHANGE_WIFI_STATE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.NEARBY_WIFI_DEVICES
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.CHANGE_WIFI_STATE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        }
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestRequiredPermissions() {
        val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.CHANGE_WIFI_STATE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.NEARBY_WIFI_DEVICES
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.CHANGE_WIFI_STATE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        }
        permissionLauncher.launch(requiredPermissions)
    }

    private fun startWifiTransfer() {
        if (handshakeSecret != null) {
            isSearchingDevices = true
            updateUIState()
            wifiTransferHelper.setTransferListener(this)
            if (isSender) {
                updateStatus("Starting as sender...")
                wifiTransferHelper.startSender(handshakeSecret!!)
            } else {
                updateStatus("Starting as receiver...")
                wifiTransferHelper.startReceiver(handshakeSecret!!)
            }
        }
    }

    private fun startFileTransfer() {
        if (isSender) {
//            if (selectedFileUri == null || peerIpAddress == null) {
            if (selectedFileUris!!.isNotEmpty() || peerIpAddress == null) {
                updateStatus("Missing file or peer connection")
                return
            }

//            val fileName = getFileNameFromUri(this, selectedFileUri!!) ?: "unknown_file"

            log("getFileNameFromUri done")
            updateStatus("Starting encrypted file transfer...")
            isTransferInProgress = true
            updateUIState()

            FileTransferService.Companion.startService(
                context = this,
                action = FileTransferService.Companion.ACTION_SEND_FILE,
                fileUris = selectedFileUris!!,
//                fileName = fileName,
                hostAddress = peerIpAddress!!,
                secret = handshakeSecret!!
            )
        } else {
            updateStatus("Ready to receive encrypted file...")
            isTransferInProgress = true
            updateUIState()

            FileTransferService.Companion.startService(
                context = this,
                action = FileTransferService.Companion.ACTION_RECEIVE_FILE,
                secret = handshakeSecret!!,
                saveDirectoryUri = selectedSaveDirectory
            )
        }
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String? {
        log("getFileNameFromUri")
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        return cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) it.getString(index) else null
            } else null
        }
    }

    private fun openFileLocation(filePath: String) {
        log("openFileLocation:$filePath")
        try {
            val file = File(filePath)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.fromFile(file.parentFile), "resource/folder")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "No file manager found.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            log("openFileLocation.Exception:$e")
            Toast.makeText(this, "Could not open location: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Transfer Listener Implementation ---

    override fun onTransferProgress(bytesTransferred: Long, totalBytes: Long) {
        log("onTransferProgress")
        runOnUiThread {
            this.bytesTransferred = bytesTransferred
            this.totalBytes = totalBytes
            val progress = if (totalBytes > 0) (bytesTransferred * 100 / totalBytes).toInt() else 0
            updateStatus("Transfer progress: $progress%")
        }
    }

    override fun onTransferComplete(success: Boolean, message: String) {
        log("onTransferComplete.success:$success")
        log("onTransferComplete.message:$message")
        runOnUiThread {
            isSearchingDevices = false
            isTransferInProgress = false
            updateStatus(message)
            if (success) {
                Toast.makeText(this, "Transfer completed successfully!", Toast.LENGTH_LONG).show()
                if (isSender) resetToIdle()
            } else {
                Toast.makeText(this, "Transfer failed: $message", Toast.LENGTH_LONG).show()
            }
            updateUIState()
        }
    }

    override fun onPeerDiscovered(peerIp: String) {
        log("onPeerDiscovered.peerIp:$peerIp")
        runOnUiThread {
            updateStatus("Found peer device: $peerIp")
            isSearchingDevices = false
            updateUIState()
        }
    }

    override fun onConnectionEstablished(peerIp: String) {
        log("onConnectionEstablished.peerIp:$peerIp")
        runOnUiThread {
            peerIpAddress = peerIp
            isSearchingDevices = false
            showConfirmDialog()
            updateUIState()
        }
    }

}
