package com.explorefile.filemanager.activities

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.explorefile.filemanager.App
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.FileViewerActivity.FileViewPagerAdapter.FileViewHolder
import com.explorefile.filemanager.databinding.ActivityFileViewerBinding
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.getFilePlaceholderDrawables
import com.explorefile.filemanager.models.ListItem
import java.util.HashMap
import kotlin.getValue

class FileViewerActivity : BaseActivity() {

    private var fileList: ArrayList<ListItem> = ArrayList()
    private val binding by viewBinding(ActivityFileViewerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        fileList.addAll(App.displayListItem)
        val startPosition = intent.getIntExtra("POSITION", 0)


        Log.e("MMMMGGGG","startPosition:${startPosition}")
        Log.e("MMMMGGGG","fileList:${fileList.size}")
        val adapter = FileViewPagerAdapter(this, fileList)
        binding.viewPager.adapter = adapter
        binding.viewPager.setCurrentItem(startPosition, false)
    }

    class FileViewPagerAdapter(
        val activity: Activity,
        private val files: List<ListItem>
    ) : RecyclerView.Adapter<FileViewHolder>() {
        private lateinit var fileDrawable: Drawable
        var fileDrawables = HashMap<String, Drawable>()

//        private val TYPE_IMAGE = 1
//        private val TYPE_VIDEO = 2
//        private val TYPE_AUDIO = 3
//        private val TYPE_OTHER = 4
        init {
            fileDrawable = activity.resources.getDrawable(R.drawable.ic_file_generic)
            fileDrawables = getFilePlaceholderDrawables(activity)
        }

        override fun getItemCount() = files.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
            val inflater = LayoutInflater.from(parent.context)

            return FileViewHolder(inflater.inflate(R.layout.items_viewpager, parent, false))

        }

        override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
            val item = files[position]
//            holder.bind(files[position])

            val drawable = fileDrawables.getOrElse(
                item.name.substringAfterLast(".").toLowerCase()
            ) { fileDrawable }

            val options = RequestOptions()
                .signature(item.getKey())
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                .error(drawable)
                .transform(CenterCrop(), RoundedCorners(10))
            Glide.with(holder.view)
                .load(item.path)
                .transition(DrawableTransitionOptions.withCrossFade())
                .apply(options)
                .into(holder.imageView)
        }

        class FileViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
            val imageView: ImageView = view.findViewById(R.id.items_preview)
        }

        private fun openWithExternalApp(context: Context, uri: Uri, type: String) {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, type)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "No app found to open file", Toast.LENGTH_SHORT).show()
            }
        }
    }


}