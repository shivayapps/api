package com.explorefile.filemanager.database

import android.content.Context

object DatabaseProvider {

    @Volatile
    private var database: MediaDatabase? = null

    fun init(context: Context) {
        if (database == null) {
            synchronized(this) {
                if (database == null) {
                    database = MediaDatabase.getDatabase(context)
                }
            }
        }
    }

    val fileDao: FileDao
        get() = database?.fileDao()
            ?: throw IllegalStateException("DatabaseProvider.init(context) must be called first")
}
