package com.explorefile.filemanager.fragments

import android.content.ContentResolver
import android.content.Context
import android.provider.MediaStore.Files
import android.provider.MediaStore.Files.FileColumns
import android.util.AttributeSet
import androidx.core.os.bundleOf
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.activities.MainActivity
import com.explorefile.filemanager.adapters.ItemsAdapter
import com.explorefile.filemanager.databinding.RecentsFragmentBinding
import com.explorefile.filemanager.extensions.areSystemAnimationsEnabled
import com.explorefile.filemanager.extensions.beVisibleIf
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getDoesFilePathExist
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getLongValue
import com.explorefile.filemanager.extensions.getStringValue
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.helpers.AdCache
import com.explorefile.filemanager.helpers.MAX_COLUMN_COUNT
import com.explorefile.filemanager.helpers.VIEW_TYPE_GRID
import com.explorefile.filemanager.helpers.VIEW_TYPE_LIST
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import com.explorefile.filemanager.helpers.isOreoPlus
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.FileDirItem
import com.explorefile.filemanager.models.ListItem
import com.explorefile.filemanager.views.MyGridLayoutManager
import com.explorefile.filemanager.views.MyRecyclerView
import com.google.android.gms.ads.AdView
import java.io.File

class RecentsFragment(context: Context, attributeSet: AttributeSet) :
    MyViewPagerFragment<MyViewPagerFragment.RecentsInnerBinding>(context, attributeSet),
    ItemOperationsListener {
    private val RECENTS_LIMIT = 50
    private var filesIgnoringSearch = ArrayList<ListItem>()
    private var lastSearchedText = ""
    private var zoomListener: MyRecyclerView.MyZoomListener? = null
    private lateinit var binding: RecentsFragmentBinding

    override fun onFinishInflate() {
        super.onFinishInflate()
        binding = RecentsFragmentBinding.bind(this)
        innerBinding = RecentsInnerBinding(binding)
    }

    var isAdLoaded = false
    var mAdView: AdView? = null

    override fun setupFragment(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
            binding.recentsSwipeRefresh.setOnRefreshListener { refreshFragment() }
        }

//        val adId =activity.getString(R.string.b_fileType)
//        BannerAdHelper.showBanner(activity,
//            binding.frameAds,
//            binding.frameAds,
//            adId,
//            AdCache.bannerFileType,
//            { isLoaded, adView, message ->
//                mAdView = adView
//                AdCache.bannerFileType = adView
//                isAdLoaded = isLoaded
//            })
//        NativeAdHelper(activity, binding.frameAds, binding.frameAds, NativeLayoutType.NativeBanner,"").loadAd()

        refreshFragment()
    }

    override fun setupCategoriesBinding(activity: BaseActivity) {

    }

    override fun refreshFragment() {

        ensureBackgroundThread {
            getRecents { recents ->
                binding.apply {
                    recentsSwipeRefresh.isRefreshing = false
                    recentsList.beVisibleIf(recents.isNotEmpty())
                    recentsPlaceholder.beVisibleIf(recents.isEmpty())
                    lytNoData.beVisibleIf(recents.isEmpty())
                    imageNoData.beVisibleIf(recents.isEmpty())
                }
                filesIgnoringSearch = recents
                addItems(recents, false)

                if (context != null && currentViewType != context!!.config.getFolderViewType("")) {
                    setupLayoutManager()
                }
            }
        }
    }

    private fun addItems(recents: ArrayList<ListItem>, forceRefresh: Boolean) {
        if (!forceRefresh && recents.hashCode() == (binding.recentsList.adapter as? ItemsAdapter)?.listItems.hashCode()) {
            return
        }

        ItemsAdapter(
            activity as BaseActivity,
            recents,
            this,
            binding.recentsList,
            isPickMultipleIntent,
            binding.recentsSwipeRefresh,
            false
        ) {
            clickedPath((it as FileDirItem).path)
        }.apply {
            setupZoomListener(zoomListener)
            binding.recentsList.adapter = this
        }

        if (context.areSystemAnimationsEnabled) {
            binding.recentsList.scheduleLayoutAnimation()
        }
    }

    override fun onResume(textColor: Int) {
        binding.recentsPlaceholder.setTextColor(textColor)

        getRecyclerAdapter()?.apply {
            updatePrimaryColor()
            updateTextColor(textColor)
            initDrawables()
        }

        binding.recentsSwipeRefresh.isEnabled =
            lastSearchedText.isEmpty() && activity?.config?.enablePullToRefresh != false
    }

    private fun setupLayoutManager() {
        if (context!!.config.getFolderViewType("") == VIEW_TYPE_GRID) {
            currentViewType = VIEW_TYPE_GRID
            setupGridLayoutManager()
        } else {
            currentViewType = VIEW_TYPE_LIST
            setupListLayoutManager()
        }

        val oldItems =
            (binding.recentsList.adapter as? ItemsAdapter)?.listItems?.toMutableList() as ArrayList<ListItem>
        binding.recentsList.adapter = null
//        initZoomListener()
        addItems(oldItems, true)
    }

    private fun setupGridLayoutManager() {
        val layoutManager = binding.recentsList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = context?.config?.fileColumnCnt ?: 3
    }

    private fun setupListLayoutManager() {
        val layoutManager = binding.recentsList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        zoomListener = null
    }

    private fun initZoomListener() {
        if (context?.config?.getFolderViewType("") == VIEW_TYPE_GRID) {
            val layoutManager = binding.recentsList.layoutManager as MyGridLayoutManager
            zoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 3) {
                        reduceColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            zoomListener = null
        }
    }

    private fun getRecents(callback: (recents: ArrayList<ListItem>) -> Unit) {
        val showHidden = context?.config?.shouldShowHidden() ?: return
        val listItems = arrayListOf<ListItem>()

        val uri = Files.getContentUri("external")
        val projection = arrayOf(
            FileColumns.DATA,
            FileColumns.DISPLAY_NAME,
            FileColumns.DATE_MODIFIED,
            FileColumns.SIZE
        )

        try {
            if (isOreoPlus()) {
                val queryArgs = bundleOf(
                    ContentResolver.QUERY_ARG_LIMIT to RECENTS_LIMIT,
                    ContentResolver.QUERY_ARG_SORT_COLUMNS to arrayOf(FileColumns.DATE_MODIFIED),
                    ContentResolver.QUERY_ARG_SORT_DIRECTION to ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                )
                context?.contentResolver?.query(uri, projection, queryArgs, null)
            } else {
                val sortOrder = "${FileColumns.DATE_MODIFIED} DESC LIMIT $RECENTS_LIMIT"
                context?.contentResolver?.query(uri, projection, null, null, sortOrder)
            }?.use { cursor ->
                if (cursor.moveToFirst()) {
                    do {
                        val path = cursor.getStringValue(FileColumns.DATA)

                        if (File(path).isDirectory) {
                            continue
                        }

                        val name = cursor.getStringValue(FileColumns.DISPLAY_NAME)
                            ?: path.getFilenameFromPath()
                        val size = cursor.getLongValue(FileColumns.SIZE)
                        val modified = cursor.getLongValue(FileColumns.DATE_MODIFIED) * 1000
                        val fileDirItem =
                            ListItem(path, name, false, 0, size, modified, false, false)

                        if (!name.startsWith(".trashed")) {
                            if ((showHidden || !name.startsWith(".")) && activity?.getDoesFilePathExist(
                                    path
                                ) == true
                            ) {
                                if (wantedMimeTypes.any { isProperMimeType(it, path, false) }) {
                                    listItems.add(fileDirItem)
                                }
                            }
                        }

                    } while (cursor.moveToNext())
                }
            }
        } catch (e: Exception) {
            activity?.showErrorToast(e)
        }

        activity?.runOnUiThread {
            callback(listItems)
        }
    }

    private fun getRecyclerAdapter() = binding.recentsList.adapter as? ItemsAdapter

    override fun toggleFilenameVisibility() {
        getRecyclerAdapter()?.updateDisplayFilenamesInGrid()
    }

    private fun increaseColumnCount() {
        if (currentViewType == VIEW_TYPE_GRID) {
            context!!.config.fileColumnCnt += 1
            (activity as? MainActivity)?.updateFragmentColumnCounts()
        }
    }

    private fun reduceColumnCount() {
        if (currentViewType == VIEW_TYPE_GRID) {
            context!!.config.fileColumnCnt -= 1
            (activity as? MainActivity)?.updateFragmentColumnCounts()
        }
    }

    override fun columnCountChanged() {
        (binding.recentsList.layoutManager as MyGridLayoutManager).spanCount =
            context!!.config.fileColumnCnt
        (activity as? MainActivity)?.refreshMenuItems()
        getRecyclerAdapter()?.apply {
            notifyItemRangeChanged(0, listItems.size)
        }
    }

    override fun setupDateTimeFormat() {
        getRecyclerAdapter()?.updateDateTimeFormat()
    }

    override fun selectedPaths(paths: ArrayList<String>) {
        (activity as MainActivity).pickedPaths(paths)
    }

    override fun deleteFiles(files: ArrayList<FileDirItem>) {
        handleFileDeleting(files, false)
    }

    fun searchQueryChanged(text: String) {
        lastSearchedText = text
        val filtered = filesIgnoringSearch.filter { it.mName.contains(text, true) }
            .toMutableList() as ArrayList<ListItem>
        binding.apply {
            (recentsList.adapter as? ItemsAdapter)?.updateItems(filtered, text)
            recentsPlaceholder.beVisibleIf(filtered.isEmpty())
            lytNoData.beVisibleIf(filtered.isEmpty())
            imageNoData.beVisibleIf(filtered.isEmpty())
            recentsSwipeRefresh.isEnabled =
                lastSearchedText.isEmpty() && activity?.config?.enablePullToRefresh != false
        }
    }

    override fun finishActMode() {
        getRecyclerAdapter()?.finishActMode()
    }
}
