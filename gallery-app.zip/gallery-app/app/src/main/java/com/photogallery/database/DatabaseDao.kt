package com.photogallery.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DatabaseDao {
    @Query("SELECT * FROM recentDeleteData")
    fun getRecentDeleteList(): List<RecentDeleteData>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRecentDelete(data: RecentDeleteData)
    @Delete
    fun removeRecentDelete(data: RecentDeleteData)
    @Query("DELETE FROM recentDeleteData")
    fun removeAllRecentDelete()
    @Query("SELECT COUNT(path) FROM recentDeleteData")
    fun getCountDelete():Int
    @Query("SELECT * FROM location")
    fun getLocationEntityList(): List<LocationEntity>

    @Delete
    fun deleteLocationEntity(data: LocationEntity)
    @Query("SELECT * FROM location")
    fun getLocationLiveEntityList(): LiveData<List<LocationEntity>>
    @Query("SELECT * FROM location WHERE path = :path")
    fun getLocationEntity(path: String): LocationEntity
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertLocationEntity(data: LocationEntity)
//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun insertImageData(data: PictureData)
//    @Query("SELECT * FROM pictureData")
//    fun getImageDataList(): LiveData<List<PictureData>>
    @Delete
    fun removeLocationEntity(data: LocationEntity)
    @Query("SELECT * FROM recoverData")
    fun getRecoverLiveEntityList(): LiveData<List<RecoverData>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRecoverEntity(data: RecoverData)
    @Delete
    fun deleteRecoverEntity(data: RecoverData)


}