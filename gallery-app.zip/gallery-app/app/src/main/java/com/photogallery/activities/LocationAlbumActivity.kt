package com.photogallery.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.photogallery.R
import com.photogallery.adapter.LocationListAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.databinding.ActivityMapAlbumBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.getPreviousActivity
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.model.PlaceData
import com.photogallery.utils.AdCache
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import java.io.File

class LocationAlbumActivity : BaseActivity() {

    lateinit var activity: Activity
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    var initialLocationTitle: String = ""

    //var albumList: ArrayList<PlaceData> = ArrayList()
    var placeList: ArrayList<PlaceData> = ArrayList()
    var albumAdapter: LocationListAdapter? = null

    lateinit var binding: ActivityMapAlbumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapAlbumBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        loadBanner()
        initialLocationTitle = intent.getStringExtra("initialLocationTitle") ?: ""
//        dataBase = AppDatabase.getInstance(this)

        initView()
        initData()
//        getAllImagesFromGallery()
    }

    private fun initView() {
        binding.loutToolbar.icMenu.beGone()
        binding.loutToolbar.icMenu.setImageBitmap(null)
        binding.loutToolbar.txtTitle.text = getString(R.string.travel_diary)
        binding.loutToolbar.icBack.setOnClickListener {
            onBackPressed()
        }

        activity = this@LocationAlbumActivity
        preferences = Preferences(activity)

        albumAdapter = LocationListAdapter(
            activity, placeList, false,
            clickListener = {
                val albumData = placeList[it]
                openImageList(albumData)
            })

        binding.recyclerViewPlace.adapter = albumAdapter

        val layoutManager = binding.recyclerViewPlace.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanCount = 2
    }

    override fun onBackPressed() {
        val previousActivity = getPreviousActivity()
        Log.e("onBackPressed", "previousActivity:${previousActivity}")
        if (previousActivity.contains("HomeActivity")) {
            Log.e("onBackPressed", "001")
            finish()
        } else {
            Log.e("onBackPressed", "002")
            val intent = Intent(this, HomeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
        }
    }

    private fun openImageList(placeData: PlaceData) {

        Constant.albumData = AlbumData(
            placeData.place,
            placeData.pictureData,
            "",
            0,
            0,
            isCustomAlbum = true
        )
        val intent = Intent(activity, ImageGalleryActivity::class.java)
        intent.putExtra("isFromMap", true)
        intent.putExtra("lati", placeData.lati)
        intent.putExtra("long", placeData.long)
        startActivity(intent)
    }

    private fun initData() {
        dataBase = AppDatabase.getInstance(activity)
        val places = dataBase.dataDao().getLocationEntityList()
        Log.i("PlacesWorker", "places:${places.size}")
        val sortedPlaces = places
            .sortedByDescending { it.locationId }

        setEmptyData(sortedPlaces)

        if (sortedPlaces.isNotEmpty()) {
            sortImage(sortedPlaces)
        }

        notifyAdapter()
        getImageOnMap()
    }

    fun sortImage(locationEntity: List<LocationEntity>) {
        Log.e("MapExploreActivity", "sortImage:::placeList.${placeList.size}")

        this.placeList.clear()
        locationEntity.forEach { data ->

            val strKey = data.title

            val imagesData1: ArrayList<MediaData> = ArrayList()

            val file = File(data.path)
            if (file.exists()) {
                val mediaData = MediaData(
                    file.path,
                    data.uri,
                    file.name,
                    file.parentFile.name,
                    file.lastModified(),
                    file.lastModified(),
                    file.length()
                )
                for (i in this.placeList.indices) {
                    if (this.placeList[i].place == strKey) {
                        this.placeList[i].pictureData.add(mediaData)
                    }
                }

                if (this.placeList.filter { it.place == strKey }.isNullOrEmpty()) {
                    imagesData1.add(mediaData)
                    val placeData = PlaceData(imagesData1, data.title, data.latitude, data.longitude)
                    this.placeList.add(placeData)
                }
            } else {
                dataBase.dataDao().deleteLocationEntity(data)
            }
        }

        Log.e("refresh_map", "placeList:${placeList.size}")
        Log.e("refresh_map", "initialLocationTitle:${initialLocationTitle}")
    }

    private fun setFilterPlace() {
        Log.e("refresh_map", "setFilterPlace")

        runOnUiThread {
            val places = dataBase.dataDao().getLocationEntityList()

            var sortedPlaces = places
                .sortedByDescending { it.locationId }
            sortedPlaces = sortedPlaces.filter { location ->
                File(location.path).exists()
            }
            if (sortedPlaces.isNotEmpty()) {
                sortImage(sortedPlaces)
            }
        }

    }

    private fun notifyAdapter() {
        if (albumAdapter != null) {
            binding.recyclerViewPlace.post {
                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    fun getData(): ArrayList<PlaceData> {
        return placeList
    }

    fun getImageOnMap() {
        Log.e("MapExploreActivity", "getImageOnMap:::albumWisePictures:${placeList.size}")
        activity.runOnUiThread {
            if (albumAdapter != null) {
                albumAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun setEmptyData() {
        if (placeList != null && placeList.size != 0) {
            binding.recyclerViewPlace.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.recyclerViewPlace.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }

    private fun setEmptyData(placeList: List<LocationEntity>) {
//        if (placeList != null && placeList.size != 0) {
//            binding.llAdPlace.visibility = View.VISIBLE
//        } else {
//            binding.llAdPlace.visibility = View.GONE
//        }
        if (placeList != null && placeList.size != 0) {
            binding.llAdPlace.visibility = View.VISIBLE
            binding.recyclerViewPlace.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
        } else {
            binding.llAdPlace.visibility = View.GONE
            binding.recyclerViewPlace.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
        }
    }


    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {
            val adId = getString(R.string.b_mapExploreActivity)
            BannerAdHelper.showBanner(
                this, binding.layoutBanner.mFLAd, binding.llAdParent, adId,
                AdCache.mapExploreAdView, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.mapExploreAdView = adView
                    isAdLoaded = isLoaded
                })
        }
    }

}