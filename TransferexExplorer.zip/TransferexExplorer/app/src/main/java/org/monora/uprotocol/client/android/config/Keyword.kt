package org.monora.uprotocol.client.android.config

object Keyword {
    const val QR_CODE_TYPE_HOTSPOT = "hs"

    const val QR_CODE_TYPE_WIFI = "wf"
}