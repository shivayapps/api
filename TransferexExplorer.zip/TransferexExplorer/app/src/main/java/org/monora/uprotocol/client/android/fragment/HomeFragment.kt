package org.monora.uprotocol.client.android.fragment

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dagger.hilt.android.AndroidEntryPoint
import org.monora.uprotocol.client.android.R
import org.monora.uprotocol.client.android.activity.ContentBrowserActivity
import org.monora.uprotocol.client.android.activity.MusicActivity
import org.monora.uprotocol.client.android.adapter.HomeAdapter
import org.monora.uprotocol.client.android.config.AppConfig
import org.monora.uprotocol.client.android.listener.HomeListener
import org.monora.uprotocol.client.android.model.HomeModel

@AndroidEntryPoint
class HomeFragment : Fragment(R.layout.layout_home_fragment), HomeListener {

    val data = ArrayList<HomeModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val homeRecyclerview = view.findViewById<RecyclerView>(R.id.homeRecyclerview)
        homeRecyclerview.layoutManager = LinearLayoutManager(context)

        homeData()
        val homeAdapter = HomeAdapter(data, this)
        homeRecyclerview.adapter = homeAdapter

//        bottomNavigationView.setOnItemSelectedListener {
//            when (it.itemId) {
//                R.id.home -> homeAdapter.notifyDataSetChanged()
//                R.id.transfer -> findNavController().navigate(HomeFragmentDirections.actionHomeTransferHistoryFragment())
//                R.id.leaf_music -> requireContext().startActivity(
//                    Intent(
//                        context,
//                        MusicActivity::class.java
//                    )
//                )
//            }
//            true
//        }
    }

    private fun homeData() {
        data.clear()
        // viewType = storage
        data.add(
                HomeModel(
                        context,
                        AppConfig.STORAGE_LOCATION,
                        getString(R.string.text_storage)
                )
        )
        // viewType = share
        data.add(HomeModel(context, AppConfig.SHARE, getString(R.string.share)))
        //viewType = categories
        data.add(
                HomeModel(
                        context,
                        AppConfig.CATEGORY,
                        getString(R.string.categories)
                )
        )
    }

    override fun onShareClicked(button: String) {
        when (button) {
            "sendButton" -> startActivity(Intent(context, ContentBrowserActivity::class.java))
            "receiveButton" -> findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToNavReceive())
            "Audios" -> findNavController().navigate(HomeFragmentDirections.actionHomeCategoryAudioFragment())
            "Downloads" -> findNavController().navigate(HomeFragmentDirections.actionHomeCategoryDownloadFragment())
            "Images" -> findNavController().navigate(HomeFragmentDirections.actionHomeCategoryImageFragment())
            "Videos" -> findNavController().navigate(HomeFragmentDirections.actionHomeCategoryVideoFragment())
            "Documents & other" -> findNavController().navigate(HomeFragmentDirections.actionHomeCategoryDocumentFragment())
            "Apps" -> findNavController().navigate(HomeFragmentDirections.actionHomeCategoryAppFragment())
            "1" -> findNavController().navigate(HomeFragmentDirections.actionHomeTransferHistoryFragment())
//            "2" -> requireContext().startActivity(Intent(context, MusicActivity::class.java))
            "2" -> findNavController().navigate(HomeFragmentDirections.actionHomeCategoryAudioFragment())
        }
    }

}