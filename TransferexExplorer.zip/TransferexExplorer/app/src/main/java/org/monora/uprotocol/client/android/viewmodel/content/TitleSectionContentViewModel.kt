package org.monora.uprotocol.client.android.viewmodel.content

import org.monora.uprotocol.client.android.model.TitleSectionContentModel

class TitleSectionContentViewModel(titleSectionContentModel: TitleSectionContentModel) {
    val title = titleSectionContentModel.title
}