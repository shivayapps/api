package org.monora.uprotocol.client.android.model

interface ListItem {
    val listId: Long
}
