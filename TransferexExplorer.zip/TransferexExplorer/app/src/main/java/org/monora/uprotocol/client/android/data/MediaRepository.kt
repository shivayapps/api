package org.monora.uprotocol.client.android.data

import android.provider.MediaStore.Audio.Media.IS_MUSIC
import org.monora.uprotocol.client.android.content.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaRepository @Inject constructor(
        private val appStore: AppStore,
        private val audioStore: AudioStore,
        private val imageStore: ImageStore,
        private val videoStore: VideoStore,
) {
    fun getAllFolders() = audioStore.getFolders(audioStore.getSongs("$IS_MUSIC = ?", arrayOf("1")))

    fun getAllPlaylists() = audioStore.getPlaylists()

    fun getAllApps() = appStore.getAll()

    fun getAllSongs() = audioStore.getSongs("$IS_MUSIC = ?", arrayOf("1"))

    fun getFolderSongs(folder: Folder) = folder.song

    fun getPlaylistSongs(playlist: Playlist) = playlist.song

    fun getImageBuckets() = imageStore.getBuckets()

    fun getImages(bucket: ImageBucket) = imageStore.getImages(bucket)

    fun getVideoBuckets() = videoStore.getBuckets()

    fun getVideos(bucket: VideoBucket) = videoStore.getVideos(bucket)
}
