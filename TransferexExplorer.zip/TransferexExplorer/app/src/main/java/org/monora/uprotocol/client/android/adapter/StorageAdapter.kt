package org.monora.uprotocol.client.android.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.three_cube.music.util.Constants
import org.monora.uprotocol.client.android.GlideApp
import org.monora.uprotocol.client.android.R
import org.monora.uprotocol.client.android.activity.ExplorerActivity
import org.monora.uprotocol.client.android.listener.HomeCategoryListener
import org.monora.uprotocol.client.android.model.StorageModel

class StorageAdapter(
    val context: Context, private val mData: List<StorageModel>,var mHomeListener: HomeCategoryListener
) : RecyclerView.Adapter<StorageAdapter.ViewHolder>() {

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.home_memory_info, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val mStorageModel = mData[position]
        // sets the text to the textview from our itemHolder class

        if (position==0) {
            holder.name.text = mStorageModel.name
            holder.llStorage.visibility = View.VISIBLE
            holder.llOption.visibility = View.GONE

            holder.free.text = mStorageModel.free
            holder.total.text = mStorageModel.total
            holder.used.text = mStorageModel.used
            holder.progressStorage.progress = mStorageModel.percentage
        }
        else if(position==1){
            holder.name.text = Constants.TRANSFER

            holder.llStorage.visibility = View.GONE
            holder.llOption.visibility = View.VISIBLE

            GlideApp.with(context)
                .load(R.drawable.ic_trebleshot)
                .into(holder.ivOption)
        }else if(position==2){
            holder.name.text = Constants.MUSIC

            holder.llStorage.visibility = View.GONE
            holder.llOption.visibility = View.VISIBLE

            GlideApp.with(context)
                .load(R.drawable.ic_music_box_white_24dp)
                .into(holder.ivOption)
        }

        holder.layout.setOnClickListener {
            if (position==0) {
                context.startActivity(Intent(context, ExplorerActivity::class.java))
            } else if(position==1){
                mHomeListener.onShareCategoryClicked(position.toString())
            }else if(position==2){
                mHomeListener.onShareCategoryClicked(position.toString())
            }

        }

    }

    override fun getItemCount(): Int {
        return mData.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val layout: LinearLayout = itemView.findViewById(R.id.layout)
        val name: TextView = itemView.findViewById(R.id.name)
        val free: TextView = itemView.findViewById(R.id.free)
        val total: TextView = itemView.findViewById(R.id.total)
        val used: TextView = itemView.findViewById(R.id.used)
        val ivOption: ImageView = itemView.findViewById(R.id.ivOption)
        val llStorage: LinearLayout = itemView.findViewById(R.id.llStorage)
        val llOption: LinearLayout = itemView.findViewById(R.id.llOption)
//        val progressStorage: ArcProgress = itemView.findViewById(R.id.progress_storage)
        val progressStorage: LinearProgressIndicator = itemView.findViewById(R.id.progress_storage)
    }
}