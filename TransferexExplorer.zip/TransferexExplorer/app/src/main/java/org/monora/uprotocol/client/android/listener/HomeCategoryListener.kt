package org.monora.uprotocol.client.android.listener

interface HomeCategoryListener {
    fun onShareCategoryClicked(button: String)
}