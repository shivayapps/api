package com.three_cube.music.util

interface PlayPauseStateNotifier {
    fun onPlayPauseStateChange()
}