package com.gallery.photo.image.video.fragment

import android.app.Activity.RESULT_OK
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.isOnline

import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.ChooseAppLanguageActivity
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.activity.SubscriptionActivity
import com.gallery.photo.image.video.bindActivity.HelpFAQActivity
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.dialog.ChangeGridSizeDialog
import com.gallery.photo.image.video.dialog.ChangeSortingDialog
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.extensions.openExternalBrowser
import com.gallery.photo.image.video.models.ThumbnailItem
import com.gallery.photo.image.video.utilities.getPrivacyPolicyUrl
import com.gallery.photo.image.video.utilities.isUnLockApp
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beVisible
import com.gallery.photo.image.video.helpers.SORT_BY_DATE_MODIFIED
import com.gallery.photo.image.video.helpers.SORT_BY_NAME
import com.gallery.photo.image.video.helpers.SORT_BY_SIZE
import com.gallery.photo.image.video.helpers.SORT_DESCENDING
import com.gallery.photo.image.video.rateandfeedback.library_feedback.sendEmail
import kotlinx.android.synthetic.main.fragment_settings.*
import kotlinx.android.synthetic.main.fragment_settings.adViewContainer


class SettingsFragment : BaseFragment() {
    public val position: Int = 0
    var title: String? = null
    override var mLastClickTime: Long = 0
    override var mMinDuration = 2000


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireContext().addEvent(javaClass.simpleName)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val v: View = inflater.inflate(R.layout.fragment_settings, container, false)
        return v
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        init()
    }


    fun init(): Unit {
        if (isAdded) {
            if (AdsManager(mContext).isNeedToShowAds() && mContext.isOnline()) {
                NativeAdvancedModelHelper(mContext).loadNativeAdvancedAd(
                    NativeAdsSize.Medium,
                    adViewContainer,
                    isNeedLayoutShow = true,
                )
            }
        }
        val sortBtn = when {
            requireContext().config.directorySorting and SORT_BY_SIZE != 0 -> getString(R.string.label_sort_by_size)
            requireContext().config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> getString(R.string.label_sort_by_date)
            requireContext().config.directorySorting and SORT_BY_NAME != 0 -> getString(R.string.label_sort_by_name)
            else -> getString(R.string.label_sort_by_date)
        }
        val sortOrder = when {
            requireContext().config.directorySorting and SORT_DESCENDING != 0 -> getString(R.string.label_sort_by_descending)
            else -> getString(R.string.label_sort_by_ascending)
        }
        var str = String.format(getString(R.string.label_sort_by_sort_by_ascending), sortBtn, sortOrder)
        tvSortBy.text = Html.fromHtml(str)
        tvGridSize.text = Html.fromHtml(getString(R.string.label_grid_size, requireContext().config.dirColumnCnt))
        clSortOption.setOnClickListener {

            isUnLockApp = true
            ChangeSortingDialog(requireActivity() as BaseSimpleActivity, true, clSortOption) {
                PhotoDirectoryFragment.isSortingChange = true
                VideoDirectoryFragment.isSortingChange = true
                VaultFragment.isSortingChange = true
                val sortBtn = when {
                    requireContext().config.directorySorting and SORT_BY_SIZE != 0 -> getString(R.string.label_sort_by_size)
                    requireContext().config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> getString(R.string.label_sort_by_date)
                    requireContext().config.directorySorting and SORT_BY_NAME != 0 -> getString(R.string.label_sort_by_name)
                    else -> getString(R.string.label_sort_by_date)
                }
                val sortOrder = when {
                    requireContext().config.directorySorting and SORT_DESCENDING != 0 -> getString(R.string.label_sort_by_descending)
                    else -> getString(R.string.label_sort_by_ascending)
                }
                var str = String.format(getString(R.string.label_sort_by_sort_by_ascending), sortBtn, sortOrder)
                tvSortBy.text = Html.fromHtml(str)
            }
        }
        clGridSize.setOnClickListener {

            isUnLockApp = true
            ChangeGridSizeDialog(requireActivity() as BaseSimpleActivity, true, clGridSize) {
                PhotoDirectoryFragment.isColumnCountChange = true
                VideoDirectoryFragment.isColumnCountChange = true
                VaultFragment.isColumnCountChange = true
                tvGridSize.text = Html.fromHtml(getString(R.string.label_grid_size, requireContext().config.dirColumnCnt))
            }
        }
        clFeedBack.setOnClickListener {

            isUnLockApp = true
            requireActivity().sendEmail()
        }
        clShareApp.setOnClickListener(this)
        clRemoveAds.setOnClickListener(this)
        clPrivacyPolicy.setOnClickListener {
            try {

                isUnLockApp = true
                requireContext().openExternalBrowser(requireContext().getPrivacyPolicyUrl())
            } catch (e: Exception) {
                if (e is ActivityNotFoundException) {
                    Toast.makeText(requireContext(), getString(R.string.msg_no_app_found), Toast.LENGTH_SHORT).show()
                }
            }
        }
        clLanguage.setOnClickListener(this)
        clHelp.setOnClickListener(this)
    }


    override fun onResume() {
        super.onResume()
        Log.d(TAG, "On Resume :: Settings")
        if (requireActivity() is MainActivity) {
            (requireActivity() as MainActivity).disableToolbarScrolling()
        }
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).visibility = VISIBLE
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).text = requireContext().getString(R.string.title_settings)
        if (AdsManager(requireActivity()).isNeedToShowAds() && requireContext().isOnline()) {
            requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = View.VISIBLE
            requireActivity().findViewById<View>(R.id.adViewContainer).visibility = View.GONE

        } else {
            requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
            requireActivity().findViewById<View>(R.id.adViewContainer).visibility = View.GONE

        }
        if (AdsManager(requireActivity()).isNeedToShowAds()) {
            clRemoveAds.visibility = VISIBLE
            dividerRemoveAd.visibility = VISIBLE
            clMoreApp.visibility = VISIBLE
            dividerMoreApp.visibility = VISIBLE
            adViewContainer.beVisible()
        } else {
            clRemoveAds.visibility = GONE
            dividerRemoveAd.visibility = GONE
            clMoreApp.visibility = GONE
            dividerMoreApp.visibility = GONE
            adViewContainer.beGone()
        }


        requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = GONE
        requireActivity().findViewById<LinearLayout>(R.id.layOpt).visibility = GONE

    }

    override fun getLayoutRes(): Int? {
        return R.layout.fragment_settings
    }


    companion object {
        var mMedia = ArrayList<ThumbnailItem>()
        fun getInstance(position: Int): Fragment {
            val f: SettingsFragment = SettingsFragment()
            val args: Bundle = Bundle()
            args.putInt("position", position)
            f.setArguments(args)
            return f
        }

        var isShareClicked = false
    }

    override fun onClick(v: View) {
        super.onClick(v)

        when (v!!.id) {
            R.id.clRemoveAds -> {

                isUnLockApp = true
                isShareClicked = true
                MainActivity.isRemoveAdClicked = true
//                GlobalScope.launch {
//                    InAppPurchaseHelper.instance!!.purchaseProduct(PRODUCT_PURCHASED, false)
//                }
                var intent = Intent(requireActivity(), SubscriptionActivity::class.java)
//                startActivity(intent)
                launchActivityForResult(intent, 2012)


            }
            R.id.clShareApp -> {

                isUnLockApp = true
                isShareClicked = true
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
                var appname = getString(R.string.app_name)
                val sAux = getString(R.string.msg_share_app, appname, requireContext().packageName)
                i.putExtra(Intent.EXTRA_TEXT, sAux)
                startActivity(Intent.createChooser(i, "Choose one"))
            }
            R.id.clLanguage -> {
                startActivity(ChooseAppLanguageActivity.newIntent(requireContext(), true))
            }
            R.id.clHelp->{
                startActivity(Intent(requireContext(), HelpFAQActivity::class.java))
            }
        }
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 2012 && resultCode == RESULT_OK) {
            clRemoveAds.visibility = GONE
            dividerRemoveAd.visibility = GONE
            clMoreApp.visibility = GONE
            dividerMoreApp.visibility = GONE
            requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
            requireActivity().findViewById<View>(R.id.adViewContainer).visibility = View.GONE
        }
    }

}