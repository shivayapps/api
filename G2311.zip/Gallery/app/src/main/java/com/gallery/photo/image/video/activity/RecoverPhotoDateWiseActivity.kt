package com.gallery.photo.image.video.activity

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.bindActivity.BaseBindingActivity
import com.gallery.photo.image.video.adapter.RecoverPhotoAdapter
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.databinding.ActivityRecoverPhotoDateWiseBinding
import com.gallery.photo.image.video.dialog.RecoverPhotoDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.MediaOperationsListener
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.helpers.VIEW_TYPE_GRID
import com.gallery.photo.image.video.helpers.VIEW_TYPE_LIST
import com.gallery.photo.image.video.helpers.ensureBackgroundThread
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import com.google.android.material.appbar.AppBarLayout
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlin.collections.ArrayList

class RecoverPhotoDateWiseActivity : BaseBindingActivity<ActivityRecoverPhotoDateWiseBinding>(), MediaOperationsListener {

    var title: String? = null
    var isFromOneSignal = false
    var isFromSettings = false
    var isScanFinished = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    //Add New
    private var mTitle = ""
    private var mPath = ""
    private var mIsGetImageIntent = false
    private var mIsGetVideoIntent = false
    private var mIsGetAnyIntent = false
    private var mIsGettingMedia = false
    private var mAllowPickingMultiple = false
    private var mShowAll = true
    private var mShowAllGroup = true
    private var mLoadedInitialPhotos = false
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mSearchMenuItem: MenuItem? = null
    private var mLastSearchedText = ""

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        try {
            mTitle = intent.getStringExtra(PATH) ?: ""
            Log.d("tag ", "Path :: $mTitle")
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mBinding.mediaEmptyTextPlaceholder.layoutParams.height = usableScreenSize.y - (statusBarHeight + navigationBarHeight)
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
        gotMedia(allMediaList, false)

    }

    override fun initActions() {

    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName() = getString(R.string.app_name)

    override fun initViews() {


        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        disableToolbarScrolling()
        mBinding.mediaRefreshLayout.setOnRefreshListener { startAsyncTask() }
        if (checkPermissionStorage(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                getMedia()
            }
        } else {
            givePermissions(mPermissionStorage)
        }
        if (getMediaAdapter() != null) {
            mBinding.imgRecover.isEnabled = getMediaAdapter()!!.getSelectedPaths().size > 0
            if (!mBinding.imgRecover.isEnabled) {
                mBinding.imgRecover.setColorFilter(resources.getColor(R.color.unSelectedNavOptColor), android.graphics.PorterDuff.Mode.SRC_IN)
                mBinding.tvTitle.text = getString(R.string.lbl_Recover_Photos)
            } else {
                mBinding.imgRecover.setColorFilter(resources.getColor(R.color.white), android.graphics.PorterDuff.Mode.SRC_IN)
                mBinding.tvTitle.text = getString(R.string.label_item_selected, getMediaAdapter()!!.getSelectedItems().size)
            }
        }
        mBinding.imgSelectAll.setOnClickListener {
            if (getMediaAdapter() != null) {
                if (getMediaAdapter()!!.getSelectedItems().size == getMediaAdapter()!!.getSelectableItemCount()) {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.INVISIBLE
                    mBinding.imgSelectAll.visibility = View.VISIBLE
                } else {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.VISIBLE
                    mBinding.imgSelectAll.visibility = View.INVISIBLE
                }

                mBinding.imgRecover.isEnabled = getMediaAdapter()!!.getSelectedItems().size > 0
                if (!mBinding.imgRecover.isEnabled) {
                    mBinding.imgRecover.setColorFilter(resources.getColor(R.color.unSelectedNavOptColor), android.graphics.PorterDuff.Mode.SRC_IN)
                    mBinding.tvTitle.text = getString(R.string.lbl_Recover_Photos)
                } else {
                    mBinding.imgRecover.setColorFilter(resources.getColor(R.color.white), android.graphics.PorterDuff.Mode.SRC_IN)
                    mBinding.tvTitle.text = getString(R.string.label_item_selected, getMediaAdapter()!!.getSelectedItems().size)
                }
            }
        }
        mBinding.imgDeSelectAll.setOnClickListener {
            if (getMediaAdapter() != null) {
                if (getMediaAdapter()!!.getSelectedItems().size == mMedia.size) {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.VISIBLE
                    mBinding.imgSelectAll.visibility = View.INVISIBLE
                } else {
                    getMediaAdapter()!!.toggleItemSelect()
                    mBinding.imgDeSelectAll.visibility = View.INVISIBLE
                    mBinding.imgSelectAll.visibility = View.VISIBLE
                }
                mBinding.imgRecover.isEnabled = getMediaAdapter()!!.getSelectedItems().size > 0
                if (!mBinding.imgRecover.isEnabled) {
                    mBinding.imgRecover.setColorFilter(resources.getColor(R.color.unSelectedNavOptColor), android.graphics.PorterDuff.Mode.SRC_IN)
                    mBinding.tvTitle.text = getString(R.string.lbl_Recover_Photos)
                } else {
                    mBinding.imgRecover.setColorFilter(resources.getColor(R.color.white), android.graphics.PorterDuff.Mode.SRC_IN)
                    mBinding.tvTitle.text = getString(R.string.label_item_selected, getMediaAdapter()!!.getSelectedItems().size)
                }

            }
        }
        mBinding.imgRecover.setOnClickListener {

            if (getMediaAdapter()!!.getSelectedPaths().size == 0) {
                toast(getString(R.string.error_please_select_one_item))
            } else {
                RecoverPhotoDialog(this) {
                    addEvent(recoverImages)
                    restorePhotos(getMediaAdapter()!!.getSelectedPaths())
                    {
                        ensureBackgroundThread {
                            updatePhotoVideoDirectoryPath(Environment.getExternalStorageDirectory().path + "/Restored Photos", true, false)
                        }
                        toast(getString(R.string.msg_restore_successfully))
                        MainActivity.isNeedToRefresh = true
                        config.recoverCountForRate++
                        finish()

                    }
                }
            }
        }
    }

    fun disableToolbarScrolling() {
        val params: AppBarLayout.LayoutParams = mBinding.toolbar.layoutParams as AppBarLayout.LayoutParams
        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
        mBinding.appBarLayout.requestLayout()
    }

    fun enableToolbarScrolling() {
        val params: AppBarLayout.LayoutParams = mBinding.toolbar.layoutParams as AppBarLayout.LayoutParams
        params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL or AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS
        mBinding.appBarLayout.requestLayout()
    }


    private fun checkPermissionStorage(mContext: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (checkPermissionabove11()) {
                return true
            }
            return false
        } else {
            return if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                isUnLockApp = true
                isAppOpenAdShow = false
                ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    101
                )
                false
            } else {
                true
            }
        }


    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                getMedia()
            } else {
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                launchActivityForResult(intent, 2296)

            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {


        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                getMedia()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {

        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(getString(R.string.msg_allow_permission_storage))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }


    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)
        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    getMedia()
                    Log.e("mTAG", "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(MainActivity.newIntent(this))
                        finish()
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getMedia()
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(MainActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        if (isFromSettings) {
            isFromSettings = false
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    getMedia()
                }
            }
        }

    }

    private fun getMedia() {
        if (allMediaList.size == 0)
            startAsyncTask()

    }

    private fun startAsyncTask() {
        mBinding.lottieProgressbar.visibility = View.VISIBLE
        disableToolbarScrolling()
        getRecoverMedia(mPath, mIsGetImageIntent, mIsGetVideoIntent, mShowAll, TYPE_IMAGES, GROUP_BY_LAST_MODIFIED_DAILY, false, mShowAllGroup, false) {
            ensureBackgroundThread {
                val newMedia = it
                try {
                    Log.d("recoverphoto1232", "setupAdapter: " + newMedia.size)

                    gotMedia(newMedia, false)
                    runOnUiThread {
                        Handler(Looper.getMainLooper()).postDelayed({
                            mBinding.lottieProgressbar.visibility = View.GONE
                        }, 500)
                    }

                } catch (e: Exception) {
                }
            }

        }


    }


    companion object {
        var mMedia = ArrayList<ThumbnailItem>()
        var allMediaList = ArrayList<ThumbnailItem>()

    }

    fun toggleToolbar(isShowActionBar: Boolean) {
//        if (isShowActionBar)
//            clToolbar.visibility = View.GONE
//        else
//            clToolbar.visibility = View.VISIBLE

    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (isFromOneSignal) {
            startActivity(Intent(this, MainActivity::class.java))
        }
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    fun gotMedia(media: ArrayList<ThumbnailItem>, isFromCache: Boolean) {
        mIsGettingMedia = false
        var filteredList = ArrayList<ThumbnailItem>()
        filteredList = media.filter {
            when (it) {
                is ThumbnailSection -> {
                    it.title == mTitle
                }
                is Medium -> {
                    it.titleForRecover == mTitle
                }
                else -> {
                    false
                }

            }
        } as ArrayList<ThumbnailItem>


        mMedia = filteredList

        runOnUiThread {
            mBinding.mediaRefreshLayout.isRefreshing = false
            mBinding.mediaEmptyTextPlaceholder.beVisibleIf(media.isEmpty() && !isFromCache)
            mBinding.mediaEmptyTextPlaceholder2.beGone()
            if (mBinding.mediaEmptyTextPlaceholder.isVisible()) {
                mBinding.mediaEmptyTextPlaceholder.text = getString(R.string.no_media_with_filters)
            }
            mBinding.mediaGrid.beVisibleIf(mBinding.mediaEmptyTextPlaceholder.isGone())

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
            mBinding.mediaVerticalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && !allowHorizontalScroll)
            mBinding.mediaHorizontalFastscroller.beVisibleIf(mBinding.mediaGrid.isVisible() && allowHorizontalScroll)
            setupAdapter()
        }

    }

    private fun getMediaAdapter() = mBinding.mediaGrid.adapter as? RecoverPhotoAdapter

    private fun setupAdapter() {

        isScanFinished = true
        mBinding.mediaRefreshLayout.isEnabled = true
        if (!mShowAll && isDirEmpty()) {
            return
        }
        Log.d("recoverphoto1232", "setupAdapter: " + mMedia.size)

        val currAdapter = mBinding.mediaGrid.adapter
        if (currAdapter == null) {
            val fastscroller = if (config.scrollHorizontally) mBinding.mediaHorizontalFastscroller else mBinding.mediaVerticalFastscroller
            RecoverPhotoAdapter(
                this, mMedia.clone() as ArrayList<ThumbnailItem>, this, mIsGetImageIntent || mIsGetVideoIntent || mIsGetAnyIntent,
                mAllowPickingMultiple, mPath, mBinding.mediaGrid, fastscroller, true
            ) {
                Log.d("ItemClick", "setupAdapter: item Position " + it)
                Log.d("ItemClick", "setupAdapter: item object " + mMedia[it as Int])
                itemClicked(mMedia[it as Int])
            }.apply {
                mBinding.mediaGrid.adapter = this
            }

            val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
            if (viewType == VIEW_TYPE_LIST) {
                mBinding.mediaGrid.scheduleLayoutAnimation()
            }

            setupLayoutManager()
            handleGridSpacing()
        } else if (mLastSearchedText.isEmpty()) {
            (currAdapter as RecoverPhotoAdapter).updateMedia(mMedia)
            handleGridSpacing()
        }

        setupScrollDirection()
        Handler(Looper.getMainLooper()).postDelayed({
            mBinding.imgRecover.isEnabled = getMediaAdapter()!!.getSelectedItems().size > 0
            if (!mBinding.imgRecover.isEnabled) {
                mBinding.imgRecover.setColorFilter(resources.getColor(R.color.unSelectedNavOptColor), android.graphics.PorterDuff.Mode.SRC_IN)
                mBinding.tvTitle.text = getString(R.string.lbl_Recover_Photos)
            } else {
                mBinding.imgRecover.setColorFilter(resources.getColor(R.color.white), android.graphics.PorterDuff.Mode.SRC_IN)
                mBinding.tvTitle.text = getString(R.string.label_item_selected, getMediaAdapter()!!.getSelectedItems().size)
            }
            mBinding.lottieProgressbar.visibility = View.GONE
        }, 500)

    }

    private fun itemClicked(item: ThumbnailItem) {
        if (getMediaAdapter() != null) {
            if (getMediaAdapter()!!.getSelectedItems().size == getMediaAdapter()!!.getSelectableItemCount()) {
                mBinding.imgDeSelectAll.visibility = View.VISIBLE
                mBinding.imgSelectAll.visibility = View.INVISIBLE
            } else {
                mBinding.imgDeSelectAll.visibility = View.INVISIBLE
                mBinding.imgSelectAll.visibility = View.VISIBLE
            }

            mBinding.imgRecover.isEnabled = getMediaAdapter()!!.getSelectedItems().size > 0
            if (!mBinding.imgRecover.isEnabled) {
                mBinding.imgRecover.setColorFilter(resources.getColor(R.color.unSelectedNavOptColor), android.graphics.PorterDuff.Mode.SRC_IN)
                mBinding.tvTitle.text = getString(R.string.lbl_Recover_Photos)
            } else {
                mBinding.imgRecover.setColorFilter(resources.getColor(R.color.white), android.graphics.PorterDuff.Mode.SRC_IN)
                mBinding.tvTitle.text = getString(R.string.label_item_selected, getMediaAdapter()!!.getSelectedItems().size)
            }
        }
    }

    private fun isDirEmpty(): Boolean {
        return mMedia.size <= 0 && config.filterMedia > 0
    }

    private fun setupLayoutManager() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            setupGridLayoutManager()
        } else {
            setupListLayoutManager()
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = 0
            bottomMargin = 0
        }

        if (config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

//        layoutManager.spanCount = config.mediaColumnCnt
        layoutManager.spanCount = 3
        val adapter = getMediaAdapter()
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupScrollDirection() {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        val allowHorizontalScroll = config.scrollHorizontally && viewType == VIEW_TYPE_GRID
        mBinding.mediaVerticalFastscroller.isHorizontal = false
        mBinding.mediaVerticalFastscroller.beGoneIf(allowHorizontalScroll)

        mBinding.mediaHorizontalFastscroller.isHorizontal = true
        mBinding.mediaHorizontalFastscroller.beVisibleIf(allowHorizontalScroll)

        val sorting = config.getFolderSorting(if (mShowAll) SHOW_ALL else mPath)
        if (allowHorizontalScroll) {
            mBinding.mediaHorizontalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaHorizontalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        } else {
            mBinding.mediaVerticalFastscroller.setViews(mBinding.mediaGrid, mBinding.mediaRefreshLayout) {
                mBinding.mediaVerticalFastscroller.updateBubbleText(getBubbleTextItem(it, sorting!!))
            }
        }
    }

    private fun handleGridSpacing(media: ArrayList<ThumbnailItem> = mMedia) {
        val viewType = config.getFolderViewType(if (mShowAll) SHOW_ALL else mPath)
        if (viewType == VIEW_TYPE_GRID) {
            val spanCount = config.mediaColumnCnt
            val spacing = config.thumbnailSpacing
            val useGridPosition = media.firstOrNull() is ThumbnailSection

            var currentGridDecoration: GridSpacingItemDecoration? = null
            if (mBinding.mediaGrid.itemDecorationCount > 0) {
                currentGridDecoration = mBinding.mediaGrid.getItemDecorationAt(0) as GridSpacingItemDecoration
                currentGridDecoration.items = media
            }

            val newGridDecoration = GridSpacingItemDecoration(spanCount, spacing, config.scrollHorizontally, config.fileRoundedCorners, media, useGridPosition)
            if (currentGridDecoration.toString() != newGridDecoration.toString()) {
                if (currentGridDecoration != null) {
                    mBinding.mediaGrid.removeItemDecoration(currentGridDecoration)
                }
                mBinding.mediaGrid.addItemDecoration(newGridDecoration)
            }
        }
    }

    private fun getBubbleTextItem(index: Int, sorting: Int): String {
        var realIndex = index
        val mediaAdapter = getMediaAdapter()
        if (mediaAdapter!!.isASectionTitle(index)) {
            realIndex++
        }
        return mediaAdapter.getItemBubbleText(realIndex, sorting, mDateFormat, mTimeFormat) ?: ""
    }


    private fun setupListLayoutManager() {
        val layoutManager = mBinding.mediaGrid.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        layoutManager.orientation = RecyclerView.VERTICAL

        val smallMargin = resources.getDimension(R.dimen.small_margin).toInt()
        (mBinding.mediaGrid.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = smallMargin
            bottomMargin = smallMargin
        }

        mZoomListener = null
    }

    override fun refreshItems() {

    }

    override fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>) {

    }

    override fun selectedPaths(paths: ArrayList<String>) {

    }

    override fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>) {

    }

    override fun setBinding(): ActivityRecoverPhotoDateWiseBinding {
        return ActivityRecoverPhotoDateWiseBinding.inflate(inflater)
    }

}