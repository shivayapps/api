package com.gallery.photo.image.video.dialog

import android.app.Activity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.views.TiledProgressView
import com.gallery.photo.image.video.extensions.setupDialogStuff
import kotlinx.android.synthetic.main.dialog_download.view.*

class DownloadDialog(val activity: Activity) {

    private var view: View = activity.layoutInflater.inflate(R.layout.dialog_download, null)
    private var pbProgress: TiledProgressView = view.pbProgress
    private var tvMessage: TextView = view.tvMessage
    var dialog: AlertDialog

    init {
        view.pbProgress.setProgress(0f)

        val builder = AlertDialog.Builder(activity, R.style.MyAlertDialogNew)

        //builder.setNegativeButton(R.string.no, null)
        //builder.setCancelable(false)
        dialog = builder.create().apply {
            activity.setupDialogStuff(view, this)
        }
//        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    private fun dialogConfirmed() {
        dialog.dismiss()
    }

    private var currGrid = 0
    private var config = activity.config

    fun setProgress(progress: Float){
        pbProgress.setProgress(progress)
        tvMessage.text=activity.getString(R.string.label_sticker_please_wait, "${progress.toInt()}%")
    }

}
