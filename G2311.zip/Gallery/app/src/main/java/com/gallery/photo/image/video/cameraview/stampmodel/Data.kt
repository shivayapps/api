package com.gallery.photo.image.video.cameraview.stampmodel

import androidx.annotation.Keep
import java.io.Serializable
@Keep
data class Data(
    val front_image: String,
    val id: Int,
    val is_premium: Boolean,
    val main_image: String,
    val zip_name: String
): Serializable