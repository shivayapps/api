package com.gallery.photo.image.video.cameraview.ui.color_picker;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;


import com.gallery.photo.image.video.R;

import java.util.List;


public class DialogColorGridViewAdapter extends BaseAdapter {
    private static final String TAG = "DialogColorGridViewAdapter";
    private List<String> colorList;
    private Context context;
    private LayoutInflater inflater;

    
    private class ViewHolder {
        View colorBubbleView;

        private ViewHolder() {
        }
    }

    public DialogColorGridViewAdapter(Context context2, List<String> list) {
        this.context = context2;
        this.inflater = LayoutInflater.from(context2);
        this.colorList = list;
    }

    public int getCount() {
        return this.colorList.size();
    }

    public Object getItem(int i) {
        return this.colorList.get(i);
    }

    public long getItemId(int i) {
        return -1;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            ViewHolder viewHolder2 = new ViewHolder();
            view = this.inflater.inflate(R.layout.dialog_color_picker_list_item, viewGroup, false);
            viewHolder2.colorBubbleView = view.findViewById(R.id.colorBubbleView);
            view.setTag(viewHolder2);
            viewHolder = viewHolder2;
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        Drawable drawable = this.context.getResources().getDrawable(R.drawable.shape_rounded);
        drawable.setColorFilter(Color.parseColor(this.colorList.get(i)), PorterDuff.Mode.SRC_ATOP);
        if (Build.VERSION.SDK_INT >= 16) {
            viewHolder.colorBubbleView.setBackground(drawable);
        } else {
            viewHolder.colorBubbleView.setBackgroundDrawable(drawable);
        }
        return view;
    }
}
