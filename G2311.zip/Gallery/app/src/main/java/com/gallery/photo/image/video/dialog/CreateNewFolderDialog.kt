package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.ViewGroup
import android.view.Window
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.*
import kotlinx.android.synthetic.main.dialog_gallery_create_new_folder.view.*
import java.io.File

class CreateNewFolderDialog(val activity: BaseSimpleActivity, val path: String, val callback: (path: String) -> Unit) {
    init {
        val view = activity.layoutInflater.inflate(R.layout.dialog_gallery_create_new_folder, null)

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
//        val font = Typeface.createFromAsset(activity.assets, "fonts/avenirltpromedium.otf")
//        view.tvTitle.typeface = font

        view.folder_path.text = "${activity.humanizePath(path).trimEnd('/')}/"
        view.ivClose.setOnClickListener {
            dialog.dismiss()
            callback("dismiss")
        }
        view.tvDone.setOnClickListener {
            val name = view.folder_name.value
            when {
                name.isEmpty() -> activity.toast(R.string.empty_name)
                name.isAValidFilename() -> {
                    val file = File(path, name)
                    if (file.exists()) {
                        activity.toast(R.string.name_taken)
                    } else
                        createFolder("$path/$name", dialog)
                }
                else -> activity.toast(R.string.invalid_name)
            }
        }
    }

    private fun createFolder(path: String, alertDialog: Dialog) {
        try {
            when {
                activity.needsStupidWritePermissions(path) -> activity.handleSAFDialog(path) {
                    if (it) {
                        try {
                            val documentFile = activity.getDocumentFile(path.getParentPath())
                            val newDir = documentFile?.createDirectory(path.getFilenameFromPath()) ?: activity.getDocumentFile(path)
                            if (newDir != null) {
                                sendSuccess(alertDialog, path)
                            } else {
                                activity.toast(R.string.unknown_error_occurred)
                            }
                        } catch (e: SecurityException) {
                            activity.showErrorToast(e)
                        }
                    }
                }
                File(path).mkdirs() -> sendSuccess(alertDialog, path)
                else -> activity.toast(R.string.unknown_error_occurred)
            }
        } catch (e: Exception) {
            activity.showErrorToast(e)
        }
    }

    private fun sendSuccess(alertDialog: Dialog, path: String) {
        callback(path.trimEnd('/'))
        alertDialog.dismiss()
    }
}
