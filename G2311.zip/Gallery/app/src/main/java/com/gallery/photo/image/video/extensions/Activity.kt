package com.gallery.photo.image.video.extensions


import android.app.Activity
import android.content.*
import android.content.Intent.EXTRA_STREAM
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.TransactionTooLargeException
import android.provider.ContactsContract
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.text.Html
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.dialog.*
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.*
import kotlinx.android.synthetic.main.dialog_title.view.*
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.*
import kotlin.collections.HashMap

import android.annotation.TargetApi
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.media.MediaScannerConnection
import android.os.Build
import android.provider.MediaStore.Files
import android.util.DisplayMetrics
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.exifinterface.media.ExifInterface
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.gallery.photo.image.video.BuildConfig
import com.gallery.photo.image.video.database.FavouriteDBHelper
import com.gallery.photo.image.video.dialog.PickDirectoryDialog
import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.models.DateTaken
import com.gallery.photo.image.video.models.Medium
import com.gallery.photo.image.video.utilities.*
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.dialog_title.view.*
import kotlinx.coroutines.launch
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

fun Activity.sharePath(path: String) {
    sharePathIntent(path, BuildConfig.APPLICATION_ID)
}

fun Activity.sharePaths(paths: ArrayList<String>) {
    sharePathsIntent(paths, BuildConfig.APPLICATION_ID)
}

fun Activity.shareMediumPath(path: String) {
    sharePath(path)
}

fun Activity.shareMediaPaths(paths: ArrayList<String>) {
    sharePaths(paths)
}

fun Activity.setAs(path: String) {
    setAsIntent(path, BuildConfig.APPLICATION_ID)
}

fun Activity.openPath(path: String, forceChooser: Boolean, extras: HashMap<String, Boolean> = HashMap()) {
    openPathIntent(path, forceChooser, BuildConfig.APPLICATION_ID, extras = extras)
}

fun BaseSimpleActivity.openEditor(path: String, forceChooser: Boolean = false) {
    val newPath = path.removePrefix("file://")
    openEditorIntent(newPath, forceChooser, BuildConfig.APPLICATION_ID)
}

fun Activity.launchCamera() {
    val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
    launchActivityIntent(intent)
}

fun AppCompatActivity.showSystemUI(toggleActionBarVisibility: Boolean) {
    if (toggleActionBarVisibility) {
        supportActionBar?.show()
    }

    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
//            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
}

fun AppCompatActivity.showSystemUIForVideo(toggleActionBarVisibility: Boolean) {
    if (toggleActionBarVisibility) {
        supportActionBar?.show()
    }

    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
}

fun AppCompatActivity.hideSystemUI(toggleActionBarVisibility: Boolean) {
    if (toggleActionBarVisibility) {
        supportActionBar?.hide()
    }

    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LOW_PROFILE or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_IMMERSIVE
}

fun BaseSimpleActivity.addNoMedia(path: String, callback: () -> Unit) {
    val file = File(path, NOMEDIA)
    if (getDoesFilePathExist(file.absolutePath)) {
        callback()
        return
    }

    if (needsStupidWritePermissions(path)) {
        handleSAFDialog(file.absolutePath) {
            if (!it) {
                return@handleSAFDialog
            }

            val fileDocument = getDocumentFile(path)
            if (fileDocument?.exists() == true && fileDocument.isDirectory) {
                fileDocument.createFile("", NOMEDIA)
                addNoMediaIntoMediaStore(file.absolutePath)
                callback()
            } else {
                toast(R.string.unknown_error_occurred)
                callback()
            }
        }
    } else {
        try {
            if (file.createNewFile()) {
                ensureBackgroundThread {
                    addNoMediaIntoMediaStore(file.absolutePath)
                }
            } else {
                toast(R.string.unknown_error_occurred)
            }
        } catch (e: Exception) {
            showErrorToast(e)
        }
        callback()
    }
}

fun BaseSimpleActivity.addNoMediaIntoMediaStore(path: String) {
    try {
        val content = ContentValues().apply {
            put(Files.FileColumns.TITLE, NOMEDIA)
            put(Files.FileColumns.DATA, path)
            put(Files.FileColumns.MEDIA_TYPE, Files.FileColumns.MEDIA_TYPE_NONE)
        }
        contentResolver.insert(Files.getContentUri("external"), content)
    } catch (e: Exception) {
        showErrorToast(e)
    }
}

fun BaseSimpleActivity.removeNoMedia(path: String, callback: (() -> Unit)? = null) {
    val file = File(path, NOMEDIA)
    if (!getDoesFilePathExist(file.absolutePath)) {
        callback?.invoke()
        return
    }

    tryDeleteFileDirItem(file.toFileDirItem(applicationContext), false, false) {
        callback?.invoke()
        /* Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).apply {
             data = Uri.fromFile(File(path))
             sendBroadcast(this)
         }*/
        MediaScannerConnection.scanFile(
            this, arrayOf(file.toString()),
            null, null
        )
        deleteFromMediaStore(file.absolutePath)
        rescanFolderMedia(path)
    }


}


fun BaseSimpleActivity.toggleFileVisibility(oldPath: String, hide: Boolean, callback: ((newPath: String) -> Unit)? = null) {
    val path = oldPath.getParentPath()
    var filename = oldPath.getFilenameFromPath()
    var favDB = FavouriteDBHelper(this)
    favDB.deleteFavDetails(oldPath)
    if ((hide && filename.startsWith('.')) || (!hide && !filename.startsWith('.'))) {
        callback?.invoke(oldPath)
        return
    }

    filename = if (hide) {
        ".${filename.trimStart('.')}"
    } else {
        filename.substring(1, filename.length)
    }

    val newPath = "$path/$filename"
    renameFile(oldPath, newPath) {
        MediaScannerConnection.scanFile(
            this, arrayOf(File(newPath).toString()),
            null, null
        )

        runOnUiThread {
            callback?.invoke(newPath)
        }

        ensureBackgroundThread {
            updateDBMediaPath(oldPath, newPath)
        }
    }
}

fun BaseSimpleActivity.tryCopyMoveFilesTo(fileDirItems: ArrayList<FileDirItem>, isCopyOperation: Boolean, callback: (destinationPath: String) -> Unit) {
    if (fileDirItems.isEmpty()) {
        toast(R.string.unknown_error_occurred)
        return
    }

    val source = fileDirItems[0].getParentPath()
    PickDirectoryDialog(this, source, true, false) {
        if (it == "None") {
            callback("None")
        } else {
            val destination = it
            handleSAFDialog(source) {
                if (it) {
                    copyMoveFilesTo(fileDirItems, source.trimEnd('/'), destination, isCopyOperation, true, config.shouldShowHidden, callback)
                }
            }
        }
    }
}

fun BaseSimpleActivity.tryDeleteFileDirItem(
    fileDirItem: FileDirItem, allowDeleteFolder: Boolean = false, deleteFromDatabase: Boolean,
    callback: ((wasSuccess: Boolean) -> Unit)? = null
) {
    deleteFile(fileDirItem, allowDeleteFolder) {
        if (deleteFromDatabase) {
            ensureBackgroundThread {
                deleteDBPath(fileDirItem.path)
                runOnUiThread {
                    callback?.invoke(it)
                }
            }
        } else {
            callback?.invoke(it)
        }
    }
}


fun BaseSimpleActivity.emptyTheRecycleBin(callback: (() -> Unit)? = null) {
    ensureBackgroundThread {
        try {
            recycleBin.deleteRecursively()
//            mediaDB.clearRecycleBin()
//            directoryDao.deleteRecycleBin()
            toast(R.string.recycle_bin_emptied)
            callback?.invoke()
        } catch (e: Exception) {
            toast(R.string.unknown_error_occurred)
        }
    }
}

fun BaseSimpleActivity.emptyAndDisableTheRecycleBin(callback: () -> Unit) {
    ensureBackgroundThread {
        emptyTheRecycleBin {
            config.useRecycleBin = false
            callback()
        }
    }
}

fun BaseSimpleActivity.showRecycleBinEmptyingDialog(callback: () -> Unit) {
    ConfirmationDialog(this, "", R.string.empty_recycle_bin_confirmation, R.string.yes, R.string.no) {
        callback()
    }
}

fun Activity.hasNavBar(): Boolean {
    val display = windowManager.defaultDisplay

    val realDisplayMetrics = DisplayMetrics()
    display.getRealMetrics(realDisplayMetrics)

    val displayMetrics = DisplayMetrics()
    display.getMetrics(displayMetrics)

    return (realDisplayMetrics.widthPixels - displayMetrics.widthPixels > 0) || (realDisplayMetrics.heightPixels - displayMetrics.heightPixels > 0)
}

fun AppCompatActivity.fixDateTaken(
    paths: ArrayList<String>,
    showToasts: Boolean,
    hasRescanned: Boolean = false,
    callback: (() -> Unit)? = null
) {
    val BATCH_SIZE = 50
    if (showToasts) {
        toast(R.string.fixing)
    }

    val pathsToRescan = ArrayList<String>()
    try {
        var didUpdateFile = false
        val operations = ArrayList<ContentProviderOperation>()

        ensureBackgroundThread {
            val dateTakens = ArrayList<DateTaken>()

            for (path in paths) {
                val dateTime = ExifInterface(path).getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                    ?: ExifInterface(path).getAttribute(ExifInterface.TAG_DATETIME) ?: continue

                // some formats contain a "T" in the middle, some don't
                // sample dates: 2015-07-26T14:55:23, 2018:09:05 15:09:05
                val t = if (dateTime.substring(10, 11) == "T") "\'T\'" else " "
                val separator = dateTime.substring(4, 5)
                val format = "yyyy${separator}MM${separator}dd${t}kk:mm:ss"
                val formatter = SimpleDateFormat(format, Locale.getDefault())
                val timestamp = formatter.parse(dateTime).time

                val uri = getFileUri(path)
                ContentProviderOperation.newUpdate(uri).apply {
                    val selection = "${MediaStore.Images.Media.DATA} = ?"
                    val selectionArgs = arrayOf(path)
                    withSelection(selection, selectionArgs)
                    withValue(MediaStore.Images.Media.DATE_TAKEN, timestamp)
                    operations.add(build())
                }

                if (operations.size % BATCH_SIZE == 0) {
                    contentResolver.applyBatch(MediaStore.AUTHORITY, operations)
                    operations.clear()
                }

//                mediaDB.updateFavoriteDateTaken(path, timestamp)
                didUpdateFile = true

                val dateTaken = DateTaken(null, path, path.getFilenameFromPath(), path.getParentPath(), timestamp, (System.currentTimeMillis() / 1000).toInt(), File(path).lastModified())
                dateTakens.add(dateTaken)
                if (!hasRescanned && getFileDateTaken(path) == 0L) {
                    pathsToRescan.add(path)
                }
            }

            if (!didUpdateFile) {
                if (showToasts) {
                    toast(R.string.no_date_takens_found)
                }

                runOnUiThread {
                    callback?.invoke()
                }
                return@ensureBackgroundThread
            }

            val resultSize = contentResolver.applyBatch(MediaStore.AUTHORITY, operations).size
            if (resultSize == 0) {
                didUpdateFile = false
            }

            if (hasRescanned || pathsToRescan.isEmpty()) {
                if (dateTakens.isNotEmpty()) {
                    dateTakensDB.insertAll(dateTakens)
                }

                runOnUiThread {
                    if (showToasts) {
                        toast(if (didUpdateFile) R.string.dates_fixed_successfully else R.string.unknown_error_occurred)
                    }

                    callback?.invoke()
                }
            } else {
                rescanPaths(pathsToRescan) {
                    fixDateTaken(paths, showToasts, true, callback)
                }
            }
        }
    } catch (e: Exception) {
        if (showToasts) {
            showErrorToast(e)
        }
    }
}

fun BaseSimpleActivity.saveRotatedImageToFile(oldPath: String, newPath: String, degrees: Int, showToasts: Boolean, callback: () -> Unit) {
    var newDegrees = degrees
    if (newDegrees < 0) {
        newDegrees += 360
    }

    if (oldPath == newPath && oldPath.isJpg()) {
        if (tryRotateByExif(oldPath, newDegrees, showToasts, callback)) {
            return
        }
    }

    val tmpPath = "$recycleBinPath/.tmp_${newPath.getFilenameFromPath()}"
    val tmpFileDirItem = FileDirItem(tmpPath, tmpPath.getFilenameFromPath())
    try {
        getFileOutputStream(tmpFileDirItem) {
            if (it == null) {
                if (showToasts) {
                    toast(R.string.unknown_error_occurred)
                }
                return@getFileOutputStream
            }

            val oldLastModified = File(oldPath).lastModified()
            if (oldPath.isJpg()) {
                copyFile(oldPath, tmpPath)
                saveExifRotation(ExifInterface(tmpPath), newDegrees)
            } else {
                val inputstream = getFileInputStreamSync(oldPath)
                val bitmap = BitmapFactory.decodeStream(inputstream)
                saveFile(tmpPath, bitmap, it as FileOutputStream, newDegrees)
            }

            copyFile(tmpPath, newPath)
            rescanPaths(arrayListOf(newPath))
            fileRotatedSuccessfully(newPath, oldLastModified)

            it.flush()
            it.close()
            callback.invoke()
        }
    } catch (e: OutOfMemoryError) {
        if (showToasts) {
            toast(R.string.out_of_memory_error)
        }
    } catch (e: Exception) {
        if (showToasts) {
            showErrorToast(e)
        }
    } finally {
        tryDeleteFileDirItem(tmpFileDirItem, false, true)
    }
}

@TargetApi(Build.VERSION_CODES.N)
fun Activity.tryRotateByExif(path: String, degrees: Int, showToasts: Boolean, callback: () -> Unit): Boolean {
    return try {
        val file = File(path)
        val oldLastModified = file.lastModified()
        if (saveImageRotation(path, degrees)) {
            fileRotatedSuccessfully(path, oldLastModified)
            callback.invoke()
            if (showToasts) {
                toast(R.string.file_saved)
            }
            true
        } else {
            false
        }
    } catch (e: Exception) {
        if (showToasts) {
            showErrorToast(e)
        }
        false
    }
}

fun Activity.fileRotatedSuccessfully(path: String, lastModified: Long) {
    if (config.keepLastModified) {
        File(path).setLastModified(lastModified)
        updateLastModified(path, lastModified)
    }

    Picasso.get().invalidate(path.getFileKey(lastModified))
    // we cannot refresh a specific image in Glide Cache, so just clear it all
    val glide = Glide.get(applicationContext)
    glide.clearDiskCache()
    runOnUiThread {
        glide.clearMemory()
    }
}

fun BaseSimpleActivity.copyFile(source: String, destination: String) {
    var inputStream: InputStream? = null
    var out: OutputStream? = null
    try {
        out = getFileOutputStreamSync(destination, source.getMimeType())
        inputStream = getFileInputStreamSync(source)
        inputStream!!.copyTo(out!!)
    } catch (e: Exception) {
        showErrorToast(e)
    } finally {
        inputStream?.close()
        out?.close()
    }
}

fun saveFile(path: String, bitmap: Bitmap, out: FileOutputStream, degrees: Int) {
    val matrix = Matrix()
    matrix.postRotate(degrees.toFloat())
    val bmp = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    bmp.compress(path.getCompressionFormat(), 90, out)
}

fun Activity.getShortcutImage(tmb: String, drawable: Drawable, callback: () -> Unit) {
    ensureBackgroundThread {
        val options = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .skipMemoryCache(true)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .fitCenter()

        val size = resources.getDimension(R.dimen.shortcut_size).toInt()
        val builder = Glide.with(this)
            .asDrawable()
            .load(tmb)
            .apply(options)
            .centerCrop()
            .into(size, size)

        try {
            (drawable as LayerDrawable).setDrawableByLayerId(R.id.shortcut_image, builder.get())
        } catch (e: Exception) {
        }

        runOnUiThread {
            callback()
        }
    }
}


@TargetApi(Build.VERSION_CODES.N)
fun Activity.showFileOnMap(path: String) {
    val exif = try {
        if (path.startsWith("content://") && isNougatPlus()) {
            ExifInterface(contentResolver.openInputStream(Uri.parse(path))!!)
        } else {
            ExifInterface(path)
        }
    } catch (e: Exception) {
        showErrorToast(e)
        return
    }

    val latLon = FloatArray(2)
    if (exif.getLatLong(latLon)) {
        showLocationOnMap("${latLon[0]}, ${latLon[1]}")
    } else {
        toast(R.string.unknown_location)
    }
}

fun BaseSimpleActivity.movePathsInRecoverTrash(paths: ArrayList<String>, isFile: Boolean = false, isFakeVaultOpen: Boolean = false, callback: ((wasSuccess: Boolean) -> Unit)?) {
    ensureBackgroundThread {
        var pathsCnt = paths.size
        val mNotificationBuilder: NotificationCompat.Builder = NotificationCompat.Builder(this)
        var mNotifId = (System.currentTimeMillis() / 1000).toInt()
        var mCurrFilename = ""
        var mCurrentProgress = 0L
        var mMaxSize = paths.size
        addEvent(moveToRecoverTrash)
        AsyncBackgroundWork({
            val channelId = "Delete"
            val title = getString(R.string.noti_deleting)
            if (isOreoPlus()) {
                val importance = NotificationManager.IMPORTANCE_LOW
                NotificationChannel(channelId, title, importance).apply {
                    enableLights(false)
                    enableVibration(false)
                    notificationManager.createNotificationChannel(this)
                }
            }

            mNotificationBuilder.setContentTitle(title)
                .setSmallIcon(com.gallery.photo.image.video.R.drawable.ic_notification)
                .setChannelId(channelId)


            mNotificationBuilder.apply {
                setContentText(mCurrFilename)
                setProgress(mMaxSize, (mCurrentProgress).toInt(), false)
                notificationManager.notify(mNotifId, build())
            }


        }, {

            for (source in paths) {
                try {
                    mCurrentProgress++
                    mCurrFilename = source.getFilenameFromPath()
                    mainscope.launch {
                        config.lastDestinationPath = source.getParentPath()
                        mNotificationBuilder.apply {
                            setContentText(mCurrFilename)
                            setProgress(mMaxSize, (mCurrentProgress).toInt(), false)
                            notificationManager.notify(mNotifId, build())
                        }
                    }
                    var inputStream: InputStream? = null
                    var out: OutputStream? = null

                    var destination = "$recoverTrashPath/${source}"
                    if (getDoesFilePathExist(destination)) {
                        destination = getAlternativeFile(File(destination)).path
                    }
                    inputStream = getFileInputStreamSync(source)
                    out = getFileOutputStreamSync(destination, source.getMimeType())

                    var copiedSize = 0L
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var bytes = inputStream!!.read(buffer)
                    while (bytes >= 0) {
                        out!!.write(buffer, 0, bytes)
                        copiedSize += bytes
                        bytes = inputStream.read(buffer)
                    }

                    out?.flush()

                    Log.d("hfdfadsfdsf", "movePathsInRecycleBin: Path -->" + source + " Count -->" + pathsCnt)
                    if (!isFile) {
                        if (isFakeVaultOpen) {
                            ensureBackgroundThread {
                                fakeVaultMediumDao.updateDeleted("$RECOVER_TRASH_BIN${source}", System.currentTimeMillis(), source)
                            }
                        } else {
                            ensureBackgroundThread {
                                var medium = mediaDB.getMediaDetailFromPath(source)
                                if (medium != null) {
                                    Log.d("hfdfadsfdsf", "movePathsInRecycleBin:Media Not null " + " Count -->" + pathsCnt)
                                    var trashImage = mediaDB.getMediaDetailFromPath("$RECOVER_TRASH_BIN${source}")
                                    if (trashImage != null) {
                                        Log.d("hfdfadsfdsf", "movePathsInRecycleBin:trash image Not null " + " Count -->" + pathsCnt)
                                        mediaDB.updateDeleted("$RECOVER_TRASH_BIN${source}", System.currentTimeMillis(), "$RECOVER_TRASH_BIN${source.getFilenameFromPath()}")
                                    } else {
                                        Log.d("hfdfadsfdsf", "movePathsInRecycleBin:trash image  null " + " Count -->" + pathsCnt)
                                        mediaDB.updateDeleted("$RECOVER_TRASH_BIN${source}", System.currentTimeMillis(), source)
                                    }
                                } else {
                                    Log.d("hfdfadsfdsf", "movePathsInRecycleBin:Media  null " + " Count -->" + pathsCnt)
                                    val type = when {
                                        source.isVideoFast() -> TYPE_VIDEOS
                                        source.isGif() -> TYPE_GIFS
                                        source.isSvg() -> TYPE_SVGS
                                        source.isRawFast() -> TYPE_RAWS
                                        source.isPortrait() -> TYPE_PORTRAITS
                                        else -> TYPE_IMAGES
                                    }
                                    val duration = if (type == TYPE_VIDEOS) getDuration(source) ?: 0 else 0
                                    val ts = System.currentTimeMillis()
                                    val medium = Medium(
                                        null,
                                        source,
                                        "$RECOVER_TRASH_BIN${source}",
                                        source,
                                        ts,
                                        ts,
                                        File(source).length(),
                                        type,
                                        duration,
                                        false,
                                        ts
                                    )
                                    mediaDB.insert(medium)
                                }
                            }
                        }
                    }
                    if (isFile) {
                        if (isFakeVaultOpen) {
                            fakeHideFileDao.updateDeleted("$RECOVER_TRASH_BIN${source}", System.currentTimeMillis(), source)
                        } else {
                            hideFileDao.updateDeleted("$RECOVER_TRASH_BIN${source}", System.currentTimeMillis(), source)
                        }
                    }
                    try {
                        var file=File(source)
                        if(file.exists())
                        {
                            file.delete()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    pathsCnt--
                } catch (e: Exception) {
                    Log.d("hfdfadsfdsf", "movePathsInRecycleBin: Error -->" + e.printStackTrace())
                    return@AsyncBackgroundWork
                }
            }

        }, {
            notificationManager.cancel(mNotifId)
            baseConfig.isAnyOperationRunning = false
            baseConfig.lastDestinationPath = ""
            callback?.invoke(pathsCnt == 0)
        })


    }
}



fun BaseSimpleActivity.movePathsInRecycleBin(paths: ArrayList<String>, isFile: Boolean = false, isFakeVaultOpen: Boolean = false, callback: ((wasSuccess: Boolean) -> Unit)?) {
    ensureBackgroundThread {
        var pathsCnt = paths.size
        val OTGPath = config.OTGPath
        AsyncBackgroundWork({}, {
            for (source in paths) {
                try {
                    var inputStream: InputStream? = null
                    var out: OutputStream? = null

                    var destination = "$recycleBinPath/${source}"
                    if (getDoesFilePathExist(destination)) {
                        destination = getAlternativeFile(File(destination)).path
                    }
                    inputStream = getFileInputStreamSync(source)
                    out = getFileOutputStreamSync(destination, source.getMimeType())

                    var copiedSize = 0L
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var bytes = inputStream!!.read(buffer)
                    while (bytes >= 0) {
                        out!!.write(buffer, 0, bytes)
                        copiedSize += bytes
                        bytes = inputStream.read(buffer)
                    }

                    out?.flush()
                    if (!isFile) {
                        if (isFakeVaultOpen) {
                            ensureBackgroundThread {
                                fakeVaultMediumDao.updateDeleted("$RECYCLE_BIN${source}", System.currentTimeMillis(), source)
                            }
                        } else {
                            ensureBackgroundThread {
                                var medium = mediaDB.getMediaDetailFromPath(source)
                                if (medium != null) {
                                    var trashImage = mediaDB.getMediaDetailFromPath("$RECYCLE_BIN${source}")
                                    if (trashImage != null) {
                                        mediaDB.updateDeleted("$RECYCLE_BIN${source}", System.currentTimeMillis(), "$RECYCLE_BIN${source.getFilenameFromPath()}")
                                    } else {
                                        mediaDB.updateDeleted("$RECYCLE_BIN${source}", System.currentTimeMillis(), source)
                                    }
                                } else {
                                    val type = when {
                                        source.isVideoFast() -> TYPE_VIDEOS
                                        source.isGif() -> TYPE_GIFS
                                        source.isSvg() -> TYPE_SVGS
                                        source.isRawFast() -> TYPE_RAWS
                                        source.isPortrait() -> TYPE_PORTRAITS
                                        else -> TYPE_IMAGES
                                    }
                                    val duration = if (type == TYPE_VIDEOS) getDuration(source) ?: 0 else 0
                                    val ts = System.currentTimeMillis()
                                    val medium = Medium(
                                        null,
                                        source,
                                        "$RECYCLE_BIN${source}",
                                        source,
                                        ts,
                                        ts,
                                        File(source).length(),
                                        type,
                                        duration,
                                        false,
                                        ts
                                    )
                                    mediaDB.insert(medium)
                                }
                            }
                        }
                    }
                    if (isFile) {
                        if (isFakeVaultOpen) {
                            fakeHideFileDao.updateDeleted("$RECYCLE_BIN${source}", System.currentTimeMillis(), source)
                        } else {
                            hideFileDao.updateDeleted("$RECYCLE_BIN${source}", System.currentTimeMillis(), source)
                        }
                    }
                    pathsCnt--
                } catch (e: Exception) {
                    Log.d("hfdfadsfdsf", "movePathsInRecycleBin: Error -->" + e.printStackTrace())
                    return@AsyncBackgroundWork
                }
            }

        }, {
            baseConfig.isAnyOperationRunning = false
            callback?.invoke(pathsCnt == 0)
        })


    }
}


fun BaseSimpleActivity.restoreRecycleBinPath(path: String, callback: () -> Unit) {
    restoreRecycleBinPaths(arrayListOf(path), false, callback)
}

fun BaseSimpleActivity.restoreRecycleBinPaths(paths: ArrayList<String>, isFakeVaultOpen: Boolean, callback: () -> Unit) {
    val newPaths = ArrayList<String>()
    AsyncBackgroundWork({}, {
        var file = File(RESTORE_TRASH_DIR_PATH)
        if (!file.exists()) {
            file.mkdir()

        }
        for (source in paths) {
            var destination = source.removePrefix(recycleBinPath)
            var destFile = File(destination.getParentPath())
            var listofFile = destFile.listFiles()
            if (destination.getParentPath().containsNoMedia() && listofFile.isNotEmpty() && !listofFile.any { it.path.contains(".nomedia") }) {
                destination = RESTORE_TRASH_DIR_PATH + File.separator + "." + source.removePrefix(recycleBinPath).getFilenameFromPath()
            } else if (!destination.getParentPath().containsNoMedia() && !source.removePrefix(recycleBinPath).getFilenameFromPath().startsWith(".")) {
                destination = RESTORE_TRASH_DIR_PATH + File.separator + "." + source.removePrefix(recycleBinPath).getFilenameFromPath()
            }
            Log.d("RestoreTrashPath", "restoreRecycleBinPaths: Destination -->$destination")
            val lastModified = File(source).lastModified()

            val isShowingSAF = handleSAFDialog(destination) {}
            if (isShowingSAF) {
//                callback()
                return@AsyncBackgroundWork
            }

            var inputStream: InputStream? = null
            var out: OutputStream? = null
            try {
                out = getFileOutputStreamSync(destination, source.getMimeType())
                inputStream = getFileInputStreamSync(source)

                var copiedSize = 0L
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var bytes = inputStream!!.read(buffer)
                while (bytes >= 0) {
                    out!!.write(buffer, 0, bytes)
                    copiedSize += bytes
                    bytes = inputStream.read(buffer)
                }

                out?.flush()

                if (File(source).length() == copiedSize) {

                    if (isFakeVaultOpen) {
                        fakeVaultMediumDao.updateDeleted(
                            destination,
                            0,
                            "$RECYCLE_BIN${source.removePrefix(recycleBinPath)}"
                        )

                    } else {
                        mediaDB.updateDeleted(
                            destination,
                            0,
                            "$RECYCLE_BIN${source.removePrefix(recycleBinPath)}"
                        )
                    }
                    File(source).delete()
                }

                newPaths.add(destination)

                if (config.keepLastModified) {
                    File(destination).setLastModified(lastModified)
                }
                if (!isFakeVaultOpen) {
                    updatePhotoVideoDirectoryPath(destination.getParentPath(), true, false, true)
                    updatePhotoVideoDirectoryPath(destination.getParentPath(), false, true, true)
                }
            } catch (e: Exception) {
            }
        }
        if (!isFakeVaultOpen) {
            updatePhotoVideoDirectoryPath(RESTORE_TRASH_DIR_PATH, true, false, true)
            updatePhotoVideoDirectoryPath(RESTORE_TRASH_DIR_PATH, false, true, true)
        }
    }, {
        runOnUiThread {
            callback()
        }

        rescanPaths(newPaths) {
            fixDateTaken(newPaths, false)
        }
    })
}


fun BaseSimpleActivity.restoreRecycleBinAudioDocPaths(paths: ArrayList<String>, isFakeVaultOpen: Boolean, callback: () -> Unit) {
    ensureBackgroundThread {
        val newPaths = ArrayList<String>()

        AsyncBackgroundWork({}, {

            for (source in paths) {
                val destination = source.removePrefix(recycleBinPath)

                val lastModified = File(source).lastModified()

                val isShowingSAF = handleSAFDialog(destination) {}
                if (isShowingSAF) {
                    return@AsyncBackgroundWork
                }

                var inputStream: InputStream? = null
                var out: OutputStream? = null
                try {
                    out = getFileOutputStreamSync(destination, source.getMimeType())
                    inputStream = getFileInputStreamSync(source)

                    var copiedSize = 0L
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var bytes = inputStream!!.read(buffer)
                    while (bytes >= 0) {
                        out!!.write(buffer, 0, bytes)
                        copiedSize += bytes
                        bytes = inputStream.read(buffer)
                    }

                    out?.flush()

//                    if (File(source).length() == copiedSize) {
                    if (isFakeVaultOpen)
                        fakeHideFileDao.updateDeleted(
                            source.removePrefix(recycleBinPath),
                            0,
                            "$RECYCLE_BIN${source.removePrefix(recycleBinPath)}"
                        )
                    else
                        hideFileDao.updateDeleted(
                            source.removePrefix(recycleBinPath),
                            0,
                            "$RECYCLE_BIN${source.removePrefix(recycleBinPath)}"
                        )

                    File(source).delete()
//                    }

                    newPaths.add(destination)

                    if (config.keepLastModified) {
                        File(destination).setLastModified(lastModified)
                    }
                } catch (e: Exception) {
                    showErrorToast(e)
                }

            }
        }, {

            rescanPaths(newPaths) {
                fixDateTaken(newPaths, false)
            }
            runOnUiThread {
                callback()
            }
        })


    }
}

fun BaseSimpleActivity.restoreRecoverTrashPaths(paths: ArrayList<String>, isFakeVaultOpen: Boolean, callback: () -> Unit) {
    val newPaths = ArrayList<String>()
    val mNotificationBuilder: NotificationCompat.Builder = NotificationCompat.Builder(this)
    var mNotifId = (System.currentTimeMillis() / 1000).toInt()
    var mCurrFilename = ""
    var mCurrentProgress = 0L
    var mMaxSize = paths.size
    AsyncBackgroundWork({
        val channelId = "Delete"
        baseConfig.isAnyOperationRunning = true
        val title = getString(R.string.label_recovering_images_progress)
        if (isOreoPlus()) {
            val importance = NotificationManager.IMPORTANCE_LOW
            NotificationChannel(channelId, title, importance).apply {
                enableLights(false)
                enableVibration(false)
                notificationManager.createNotificationChannel(this)
            }
        }
        mNotificationBuilder.setContentTitle(title)
            .setSmallIcon(com.gallery.photo.image.video.R.drawable.ic_notification)
            .setChannelId(channelId)


        mNotificationBuilder.apply {
            setContentText(mCurrFilename)
            setProgress(mMaxSize, (mCurrentProgress).toInt(), false)
            notificationManager.notify(mNotifId, build())
        }

    }, {
//        var file = File(RECOVER_DIR_PATH)
//        if (!file.exists()) {
//            file.mkdir()
//
//        }
        for (source in paths) {
            mCurrentProgress++
            mCurrFilename = source.getFilenameFromPath()
            mainscope.launch {
                config.lastDestinationPath = source.getParentPath()
                mNotificationBuilder.apply {
                    setContentText(mCurrFilename)
                    setProgress(mMaxSize, (mCurrentProgress).toInt(), false)
                    notificationManager.notify(mNotifId, build())
                }
            }
            var destination = source.removePrefix(recoverTrashPath)
            if (destination.getParentPath().containsNoMedia()) {
                destination = RESTORE_DIR_PATH + File.separator + source.removePrefix(recoverTrashPath).getFilenameFromPath()
            }

            Log.d("RestoreTrashPath", "restoreRecycleBinPaths: Destination -->$destination")
            val lastModified = File(source).lastModified()

            val isShowingSAF = handleSAFDialog(destination) {}
            if (isShowingSAF) {
                return@AsyncBackgroundWork
            }

            var inputStream: InputStream? = null
            var out: OutputStream? = null
            try {
                out = getFileOutputStreamSync(destination, source.getMimeType())
                inputStream = getFileInputStreamSync(source)

                var copiedSize = 0L
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var bytes = inputStream!!.read(buffer)
                while (bytes >= 0) {
                    out!!.write(buffer, 0, bytes)
                    copiedSize += bytes
                    bytes = inputStream.read(buffer)
                }

                out?.flush()

                if (File(source).length() == copiedSize) {

                    if (isFakeVaultOpen) {
                        fakeVaultMediumDao.updateDeleted(
                            destination,
                            0,
                            "$RECOVER_TRASH_BIN${source.removePrefix(recoverTrashPath)}"
                        )

                    } else {
                        mediaDB.updateDeleted(
                            destination,
                            0,
                            "$RECOVER_TRASH_BIN${source.removePrefix(recoverTrashPath)}"
                        )
                    }
                    File(source).delete()
                }

                newPaths.add(destination)

                if (config.keepLastModified) {
                    File(destination).setLastModified(lastModified)
                }
                if (!isFakeVaultOpen) {
                    updatePhotoVideoDirectoryPath(destination.getParentPath(), true, false, false)
                    updatePhotoVideoDirectoryPath(destination.getParentPath(), false, true, false)
                }
            } catch (e: Exception) {
            }
        }
    }, {
        notificationManager.cancel(mNotifId)
        baseConfig.isAnyOperationRunning = false
        baseConfig.lastDestinationPath = ""
        runOnUiThread {
            callback()
        }

        rescanPaths(newPaths) {
            fixDateTaken(newPaths, false)
        }
    })
}

//from Common

fun AppCompatActivity.updateActionBarTitle(text: String, color: Int = baseConfig.primaryColor) {
    supportActionBar?.title = Html.fromHtml("<font color='${color.getContrastColor().toHex()}'>$text</font>")
}

fun AppCompatActivity.updateActionBarSubtitle(text: String) {
    supportActionBar?.subtitle = Html.fromHtml("<font color='${baseConfig.primaryColor.getContrastColor().toHex()}'>$text</font>")
}

fun Activity.isAppInstalledOnSDCard(): Boolean = try {
    val applicationInfo = packageManager.getPackageInfo(packageName, 0).applicationInfo
    (applicationInfo.flags and ApplicationInfo.FLAG_EXTERNAL_STORAGE) == ApplicationInfo.FLAG_EXTERNAL_STORAGE
} catch (e: Exception) {
    false
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.isShowingSAFDialog(path: String): Boolean {
    return if (isPathOnSD(path) && !isSDCardSetAsDefaultStorage() && (baseConfig.treeUri.isEmpty() || !hasProperStoredTreeUri(false))) {
        runOnUiThread {
            if (!isDestroyed && !isFinishing) {
                WritePermissionDialog(this, false) {
                    Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        putExtra("android.content.extra.SHOW_ADVANCED", true)
                        try {
//                            startActivityForResult(this, OPEN_DOCUMENT_TREE)
                            launchActivityForResult(intent, OPEN_DOCUMENT_TREE)
                            checkedDocumentPath = path
                            return@apply
                        } catch (e: Exception) {
                            type = "*/*"
                        }

                        try {
//                            startActivityForResult(this, OPEN_DOCUMENT_TREE)
                            launchActivityForResult(intent, OPEN_DOCUMENT_TREE)
                            checkedDocumentPath = path
                        } catch (e: Exception) {
                            toast(R.string.unknown_error_occurred)
                        }
                    }
                }
            }
        }
        true
    } else {
        false
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.isShowingOTGDialog(path: String): Boolean {
    return if (isPathOnOTG(path) && (baseConfig.OTGTreeUri.isEmpty() || !hasProperStoredTreeUri(true))) {
        showOTGPermissionDialog(path)
        true
    } else {
        false
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.showOTGPermissionDialog(path: String) {
    runOnUiThread {
        if (!isDestroyed && !isFinishing) {
            WritePermissionDialog(this, true) {
                Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    try {
//                        startActivityForResult(this, OPEN_DOCUMENT_TREE_OTG)
                        launchActivityForResult(intent, OPEN_DOCUMENT_TREE_OTG)
                        checkedDocumentPath = path
                        return@apply
                    } catch (e: Exception) {
                        type = "*/*"
                    }

                    try {
//                        startActivityForResult(this, OPEN_DOCUMENT_TREE_OTG)
                        launchActivityForResult(intent, OPEN_DOCUMENT_TREE_OTG)
                        checkedDocumentPath = path
                    } catch (e: Exception) {
                        toast(R.string.unknown_error_occurred)
                    }
                }
            }
        }
    }
}


fun Activity.launchUpgradeToProIntent() {
    try {
        launchViewIntent("market://details?id=${baseConfig.appId.removeSuffix(".debug")}.pro")
    } catch (ignored: Exception) {
        launchViewIntent(getStoreUrl())
    }
}

fun Activity.launchViewIntent(id: Int) = launchViewIntent(getString(id))

fun Activity.launchViewIntent(url: String) {
    ensureBackgroundThread {
        Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            launchActivityIntent(this)
        }
    }
}

fun Activity.redirectToRateUs() {
    try {
        launchViewIntent("market://details?id=${packageName.removeSuffix(".debug")}")
    } catch (ignored: ActivityNotFoundException) {
        launchViewIntent(getStoreUrl())
    }
}

fun Activity.sharePathIntent(path: String, applicationId: String) {
    ensureBackgroundThread {
        val newUri = getFinalUriFromPath(path, applicationId) ?: return@ensureBackgroundThread
        Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, newUri)
            type = getUriMimeType(path, newUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

            try {
                startActivity(Intent.createChooser(this, getString(R.string.share_via)))
            } catch (e: ActivityNotFoundException) {
                toast(R.string.no_app_found)
            } catch (e: RuntimeException) {
                if (e.cause is TransactionTooLargeException) {
                    toast(R.string.maximum_share_reached)
                } else {
                    showErrorToast(e)
                }
            } catch (e: Exception) {
                showErrorToast(e)
            }
        }
    }
}

fun Activity.sharePathsIntent(paths: List<String>, applicationId: String) {
    ensureBackgroundThread {
        if (paths.size == 1) {
            sharePathIntent(paths.first(), applicationId)
        } else {
            val uriPaths = ArrayList<String>()
            val newUris = paths.map {
                val uri = getFinalUriFromPath(it, applicationId) ?: return@ensureBackgroundThread
                uriPaths.add(uri.path!!)
                uri
            } as ArrayList<Uri>

            var mimeType = uriPaths.getMimeType()
            if (mimeType.isEmpty() || mimeType == "*/*") {
                mimeType = paths.getMimeType()
            }

            Intent().apply {
                action = Intent.ACTION_SEND_MULTIPLE
                type = mimeType
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, newUris)

                try {
                    startActivity(Intent.createChooser(this, getString(R.string.share_via)))
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.no_app_found)
                } catch (e: RuntimeException) {
                    if (e.cause is TransactionTooLargeException) {
                        toast(R.string.maximum_share_reached)
                    } else {
                        showErrorToast(e)
                    }
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
        }
    }
}

fun Activity.shareTextIntent(text: String) {
    ensureBackgroundThread {
        Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)

            try {
                startActivity(Intent.createChooser(this, getString(R.string.share_via)))
            } catch (e: ActivityNotFoundException) {
                toast(R.string.no_app_found)
            } catch (e: RuntimeException) {
                if (e.cause is TransactionTooLargeException) {
                    toast(R.string.maximum_share_reached)
                } else {
                    showErrorToast(e)
                }
            } catch (e: Exception) {
                showErrorToast(e)
            }
        }
    }
}

fun Activity.setAsIntent(path: String, applicationId: String) {
    ensureBackgroundThread {
        val newUri = getFinalUriFromPath(path, applicationId) ?: return@ensureBackgroundThread
        Intent().apply {
            action = Intent.ACTION_ATTACH_DATA
            setDataAndType(newUri, getUriMimeType(path, newUri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(this, getString(R.string.set_as))

            try {
                startActivityForResult(chooser, REQUEST_SET_AS)
            } catch (e: ActivityNotFoundException) {
                toast(R.string.no_app_found)
            } catch (e: Exception) {
                showErrorToast(e)
            }
        }
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.openEditorIntent(path: String, forceChooser: Boolean, applicationId: String) {
    ensureBackgroundThread {
        val newUri = getFinalUriFromPath(path, applicationId) ?: return@ensureBackgroundThread
        Intent().apply {
            action = Intent.ACTION_EDIT
            setDataAndType(newUri, getUriMimeType(path, newUri))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

            val parent = path.getParentPath()
            val newFilename = "${path.getFilenameFromPath().substringBeforeLast('.')}_1"
            val extension = path.getFilenameExtension()
            val newFilePath = File(parent, "$newFilename.$extension")

            val outputUri = if (isPathOnOTG(path)) newUri else getFinalUriFromPath("$newFilePath", applicationId)
            val resInfoList = packageManager.queryIntentActivities(this, PackageManager.MATCH_DEFAULT_ONLY)
            for (resolveInfo in resInfoList) {
                val packageName = resolveInfo.activityInfo.packageName
                grantUriPermission(packageName, outputUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            putExtra(MediaStore.EXTRA_OUTPUT, outputUri)
            putExtra(REAL_FILE_PATH, path)

            try {
                val chooser = Intent.createChooser(this, getString(R.string.edit_with))
                launchActivityForResult(if (forceChooser) chooser else this, REQUEST_EDIT_IMAGE)
            } catch (e: ActivityNotFoundException) {
                toast(R.string.no_app_found)
            } catch (e: Exception) {
                showErrorToast(e)
            }
        }
    }
}

fun Activity.openPathIntent(path: String, forceChooser: Boolean, applicationId: String, forceMimeType: String = "", extras: HashMap<String, Boolean> = HashMap()) {
    ensureBackgroundThread {
        val newUri = getFinalUriFromPath(path, applicationId) ?: return@ensureBackgroundThread
        val mimeType = if (forceMimeType.isNotEmpty()) forceMimeType else getUriMimeType(path, newUri)
        Intent().apply {
            action = Intent.ACTION_VIEW
            setDataAndType(newUri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

//            if (applicationId == "com.gallery.photo.image.video") {
//                putExtra(IS_FROM_GALLERY, true)
//            }

            for ((key, value) in extras) {
                putExtra(key, value)
            }

            putExtra(REAL_FILE_PATH, path)

            try {
                val chooser = Intent.createChooser(this, getString(R.string.open_with))
                startActivity(if (forceChooser) chooser else this)
            } catch (e: ActivityNotFoundException) {
                if (!tryGenericMimeType(this, mimeType, newUri)) {
                    toast(R.string.no_app_found)
                }
            } catch (e: Exception) {
                showErrorToast(e)
            }
        }
    }
}

fun Activity.launchViewContactIntent(uri: Uri) {
    Intent().apply {
        action = ContactsContract.QuickContact.ACTION_QUICK_CONTACT
        data = uri
        launchActivityIntent(this)
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.launchCallIntent(recipient: String, handle: PhoneAccountHandle? = null) {
    handlePermission(PERMISSION_CALL_PHONE) {
        val action = if (it) Intent.ACTION_CALL else Intent.ACTION_DIAL
        Intent(action).apply {
            data = Uri.fromParts("tel", recipient, null)

            if (handle != null && isMarshmallowPlus()) {
                putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, handle)
            }

            launchActivityIntent(this)
        }
    }
}

fun Activity.launchSendSMSIntent(recipient: String) {
    Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.fromParts("smsto", recipient, null)
        launchActivityIntent(this)
    }
}

fun Activity.showLocationOnMap(coordinates: String) {
    val uriBegin = "geo:${coordinates.replace(" ", "")}"
    val encodedQuery = Uri.encode(coordinates)
    val uriString = "$uriBegin?q=$encodedQuery&z=16"
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString))
    launchActivityIntent(intent)
}

fun Activity.getFinalUriFromPath(path: String, applicationId: String): Uri? {
    val uri = try {
        ensurePublicUri(path, applicationId)
    } catch (e: Exception) {
        showErrorToast(e)
        return null
    }

    if (uri == null) {
        toast(R.string.unknown_error_occurred)
        return null
    }

    return uri
}

fun Activity.tryGenericMimeType(intent: Intent, mimeType: String, uri: Uri): Boolean {
    var genericMimeType = mimeType.getGenericMimeType()
    if (genericMimeType.isEmpty()) {
        genericMimeType = "*/*"
    }

    intent.setDataAndType(uri, genericMimeType)

    return try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}


fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFolders(folders: List<FileDirItem>, deleteMediaOnly: Boolean = true, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    ensureBackgroundThread {
        deleteFoldersBg(folders, deleteMediaOnly, callback)
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFoldersBg(folders: List<FileDirItem>, deleteMediaOnly: Boolean = true, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    var wasSuccess = false
    var needPermissionForPath = ""
    for (folder in folders) {
        if (needsStupidWritePermissions(folder.path) && baseConfig.treeUri.isEmpty()) {
            needPermissionForPath = folder.path
            break
        }
    }

    handleSAFDialog(needPermissionForPath) {
        if (!it) {
            return@handleSAFDialog
        }

        folders.forEachIndexed { index, folder ->
            deleteFolderBg(folder, deleteMediaOnly) {
                if (it)
                    wasSuccess = true

                if (index == folders.size - 1) {
                    runOnUiThread {
                        callback?.invoke(wasSuccess)
                    }
                }
            }
        }
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFolder(folder: FileDirItem, deleteMediaOnly: Boolean = true, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    ensureBackgroundThread {
        deleteFolderBg(folder, deleteMediaOnly, callback)
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFolderBg(fileDirItem: FileDirItem, deleteMediaOnly: Boolean = true, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    val folder = File(fileDirItem.path)
    if (folder.exists()) {
        val filesArr = folder.listFiles()
        if (filesArr == null) {
            runOnUiThread {
                callback?.invoke(true)
            }
            return
        }

        val files = filesArr.toMutableList().filter { !deleteMediaOnly || it.isMediaFile() }
        for (file in files) {
            deleteFileBg(file.toFileDirItem(applicationContext), false) { }
        }

        if (folder.listFiles()?.isEmpty() == true) {
            deleteFileBg(fileDirItem, true) { }
        }
    }
    runOnUiThread {
        callback?.invoke(true)
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFiles(files: List<FileDirItem>, allowDeleteFolder: Boolean = false, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    ensureBackgroundThread {
        deleteFilesBg(files, allowDeleteFolder, callback)
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFilesBg(files: List<FileDirItem>, allowDeleteFolder: Boolean = false, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    if (files.isEmpty()) {
        runOnUiThread {
            callback?.invoke(true)
        }
        return
    }

    var wasSuccess = false
    handleSAFDialog(files[0].path) {
        if (!it) {
            return@handleSAFDialog
        }

        files.forEachIndexed { index, file ->
            deleteFileBg(file, allowDeleteFolder) {
                if (it) {
                    wasSuccess = true
                }

                if (index == files.size - 1) {
                    runOnUiThread {
                        callback?.invoke(wasSuccess)
                    }
                }
            }
        }
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFile(fileDirItem: FileDirItem, allowDeleteFolder: Boolean = false, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    ensureBackgroundThread {
        deleteFileBg(fileDirItem, allowDeleteFolder, callback)
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.deleteFileBg(fileDirItem: FileDirItem, allowDeleteFolder: Boolean = false, callback: ((wasSuccess: Boolean) -> Unit)? = null) {
    val path = fileDirItem.path
    val file = File(path)
    if (file.absolutePath.startsWith(internalStoragePath) && !file.canWrite()) {
        callback?.invoke(false)
        return
    }

    var fileDeleted = !isPathOnOTG(path) && ((!file.exists() && file.length() == 0L) || file.delete())
    if (fileDeleted) {
        deleteFromMediaStore(path) { needsRescan ->
            if (needsRescan) {
                rescanAndDeletePath(path) {
                    runOnUiThread {
                        callback?.invoke(true)
                    }
                }
            } else {
                runOnUiThread {
                    callback?.invoke(true)
                }
            }
        }
    } else {
        if (getIsPathDirectory(file.absolutePath) && allowDeleteFolder) {
            fileDeleted = deleteRecursively(file)
        }

        if (!fileDeleted) {
            if (needsStupidWritePermissions(path)) {
                handleSAFDialog(path) {
                    if (it) {
                        trySAFFileDelete(fileDirItem, allowDeleteFolder, callback)
                    }
                }
            }
        }
    }
}

private fun deleteRecursively(file: File): Boolean {
    if (file.isDirectory) {
        val files = file.listFiles() ?: return file.delete()
        for (child in files) {
            deleteRecursively(child)
        }
    }

    return file.delete()
}

fun Activity.scanFileRecursively(file: File, callback: (() -> Unit)? = null) {
    applicationContext.scanFileRecursively(file, callback)
}

fun Activity.scanPathRecursively(path: String, callback: (() -> Unit)? = null) {
    applicationContext.scanPathRecursively(path, callback)
}

fun Activity.scanFilesRecursively(files: List<File>, callback: (() -> Unit)? = null) {
    applicationContext.scanFilesRecursively(files, callback)
}

fun Activity.scanPathsRecursively(paths: List<String>, callback: (() -> Unit)? = null) {
    applicationContext.scanPathsRecursively(paths, callback)
}

fun Activity.rescanPath(path: String, callback: (() -> Unit)? = null) {
    applicationContext.rescanPath(path, callback)
}

fun Activity.rescanPaths(paths: List<String>, callback: (() -> Unit)? = null) {
    applicationContext.rescanPaths(paths, callback)
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.renameFile(oldPath: String, newPath: String, callback: ((success: Boolean) -> Unit)? = null) {
    if (needsStupidWritePermissions(newPath)) {
        handleSAFDialog(newPath) {
            if (!it) {
                return@handleSAFDialog
            }

            val document = getSomeDocumentFile(oldPath)
            if (document == null || (File(oldPath).isDirectory != document.isDirectory)) {
                runOnUiThread {
                    callback?.invoke(false)
                }
                return@handleSAFDialog
            }

            try {
                ensureBackgroundThread {
                    try {
                        DocumentsContract.renameDocument(applicationContext.contentResolver, document.uri, newPath.getFilenameFromPath())
                    } catch (ignored: FileNotFoundException) {
                        // FileNotFoundException is thrown in some weird cases, but renaming works just fine
                    } catch (e: Exception) {
                        showErrorToast(e)
                        callback?.invoke(false)
                        return@ensureBackgroundThread
                    }

                    updateInMediaStore(oldPath, newPath)
                    rescanPaths(arrayListOf(oldPath, newPath)) {
                        if (!newPath.isMediaFile()) {
                            updateLastModified(newPath, System.currentTimeMillis())
                        }
                        deleteFromMediaStore(oldPath)
                        runOnUiThread {
                            callback?.invoke(true)
                        }
                    }
                }
            } catch (e: Exception) {
                showErrorToast(e)
                runOnUiThread {
                    callback?.invoke(false)
                }
            }
        }
    } else if (File(oldPath).renameTo(File(newPath))) {
        if (File(newPath).isDirectory) {
            deleteFromMediaStore(oldPath)
            rescanPath(newPath) {
                runOnUiThread {
                    callback?.invoke(true)
                }
                scanPathRecursively(newPath)
            }
        } else {
            if (!newPath.isMediaFile()) {
                File(newPath).setLastModified(System.currentTimeMillis())
            }
            deleteFromMediaStore(oldPath)
            scanPathsRecursively(arrayListOf(newPath)) {
                runOnUiThread {
                    callback?.invoke(true)
                }
            }
        }
    } else {
        runOnUiThread {
            callback?.invoke(false)
        }
    }
}

fun Activity.hideKeyboard() {
    val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    inputMethodManager.hideSoftInputFromWindow((currentFocus ?: View(this)).windowToken, 0)
    window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
    currentFocus?.clearFocus()
}

fun Activity.showKeyboard(et: EditText) {
    et.requestFocus()
    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
}

fun Activity.hideKeyboard(view: View) {
    val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
    inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.getFileOutputStream(fileDirItem: FileDirItem, allowCreatingNewFile: Boolean = false, callback: (outputStream: OutputStream?) -> Unit) {
    if (needsStupidWritePermissions(fileDirItem.path)) {
        handleSAFDialog(fileDirItem.path) {
            if (!it) {
                return@handleSAFDialog
            }

            var document = getDocumentFile(fileDirItem.path)
            if (document == null && allowCreatingNewFile) {
                document = getDocumentFile(fileDirItem.getParentPath())
            }

            if (document == null) {
                showFileCreateError(fileDirItem.path)
                callback(null)
                return@handleSAFDialog
            }

            if (!getDoesFilePathExist(fileDirItem.path)) {
                document = document.createFile("", fileDirItem.name) ?: getDocumentFile(fileDirItem.path)
            }

            if (document?.exists() == true) {
                try {
                    callback(applicationContext.contentResolver.openOutputStream(document.uri))
                } catch (e: FileNotFoundException) {
                    showErrorToast(e)
                    callback(null)
                }
            } else {
                showFileCreateError(fileDirItem.path)
                callback(null)
            }
        }
    } else {
        val file = File(fileDirItem.path)
        if (file.parentFile?.exists() == false) {
            file.parentFile.mkdirs()
        }

        try {
            callback(FileOutputStream(file))
        } catch (e: Exception) {
            callback(null)
        }
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.showFileCreateError(path: String) {
    val error = String.format(getString(R.string.could_not_create_file), path)
    baseConfig.treeUri = ""
    showErrorToast(error)
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.getFileOutputStreamSync(path: String, mimeType: String, parentDocumentFile: DocumentFile? = null): OutputStream? {
    val targetFile = File(path)

    return if (needsStupidWritePermissions(path)) {
        var documentFile = parentDocumentFile
        if (documentFile == null) {
            if (getDoesFilePathExist(targetFile.parentFile.absolutePath)) {
                documentFile = getDocumentFile(targetFile.parent)
            } else {
                documentFile = getDocumentFile(targetFile.parentFile.parent)
                documentFile = documentFile!!.createDirectory(targetFile.parentFile.name)
                    ?: getDocumentFile(targetFile.parentFile.absolutePath)
            }
        }

        if (documentFile == null) {
            showFileCreateError(targetFile.parent)
            return null
        }

        try {
            val newDocument = documentFile.createFile(mimeType, path.getFilenameFromPath()) ?: getDocumentFile(path)
            applicationContext.contentResolver.openOutputStream(newDocument!!.uri)
        } catch (e: Exception) {
            showErrorToast(e)
            null
        }
    } else {
        if (targetFile.parentFile?.exists() == false) {
            targetFile.parentFile.mkdirs()
        }

        try {
            FileOutputStream(targetFile)
        } catch (e: Exception) {
            showErrorToast(e)
            null
        }
    }
}

fun Activity.handleHiddenFolderPasswordProtection(callback: () -> Unit) {
    if (baseConfig.isHiddenPasswordProtectionOn) {
        SecurityDialog(this, baseConfig.hiddenPasswordHash, baseConfig.hiddenProtectionType) { hash, type, success ->
            if (success) {
                callback()
            }
        }
    } else {
        callback()
    }
}

fun Activity.handleAppPasswordProtection(callback: (success: Boolean) -> Unit) {
    if (baseConfig.isAppPasswordProtectionOn) {
        SecurityDialog(this, baseConfig.appPasswordHash, baseConfig.appProtectionType) { hash, type, success ->
            callback(success)
        }
    } else {
        callback(true)
    }
}

fun Activity.handleDeletePasswordProtection(callback: () -> Unit) {
    if (baseConfig.isDeletePasswordProtectionOn) {
        SecurityDialog(this, baseConfig.deletePasswordHash, baseConfig.deleteProtectionType) { hash, type, success ->
            if (success) {
                callback()
            }
        }
    } else {
        callback()
    }
}

fun Activity.handleLockedFolderOpening(path: String, callback: (success: Boolean) -> Unit) {
    if (baseConfig.isFolderProtected(path)) {
        SecurityDialog(this, baseConfig.getFolderProtectionHash(path), baseConfig.getFolderProtectionType(path)) { hash, type, success ->
            callback(success)
        }
    } else {
        callback(true)
    }
}

fun com.gallery.photo.image.video.activity.BaseSimpleActivity.createDirectorySync(directory: String): Boolean {
    if (getDoesFilePathExist(directory)) {
        return true
    }

    if (needsStupidWritePermissions(directory)) {
        val documentFile = getDocumentFile(directory.getParentPath()) ?: return false
        val newDir = documentFile.createDirectory(directory.getFilenameFromPath()) ?: getDocumentFile(directory)
        return newDir != null
    }

    return File(directory).mkdirs()
}

fun Activity.updateSharedTheme(sharedTheme: SharedTheme) {
    try {
        val contentValues = MyContentProvider.fillThemeContentValues(sharedTheme)
        applicationContext.contentResolver.update(MyContentProvider.MY_CONTENT_URI, contentValues, null, null)
    } catch (e: Exception) {
        showErrorToast(e)
    }
}

fun Activity.setupDialogStuff(view: View, dialog: AlertDialog, titleId: Int = 0, titleText: String = "", cancelOnTouchOutside: Boolean = true, callback: (() -> Unit)? = null) {
    if (isDestroyed || isFinishing) {
        return
    }

    /*val adjustedPrimaryColor = getAdjustedPrimaryColor()
    if (view is ViewGroup)
        updateTextColors(view)
    else if (view is MyTextView) {
        view.setColors(baseConfig.textColor, adjustedPrimaryColor, baseConfig.backgroundColor)
    }*/

    var title: TextView? = null
    if (titleId != 0 || titleText.isNotEmpty()) {
        title = layoutInflater.inflate(R.layout.dialog_title, null) as TextView
        title.dialog_title_textview.apply {
            if (titleText.isNotEmpty()) {
                text = titleText
            } else {
                setText(titleId)
            }
            setTextColor(view.context.resources.getColor(R.color.color_primary))
        }
    }

    dialog.apply {
        setView(view)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCustomTitle(title)
        setCanceledOnTouchOutside(cancelOnTouchOutside)
        show()
        getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(view.context.resources.getColor(R.color.color_primary))
        getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(view.context.resources.getColor(R.color.color_primary))
        getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(view.context.resources.getColor(R.color.color_primary))

        val bgDrawable = resources.getColoredDrawableWithColor(R.drawable.dialog_bg, baseConfig.backgroundColor)
        window?.setBackgroundDrawable(bgDrawable)
    }
    callback?.invoke()
}

