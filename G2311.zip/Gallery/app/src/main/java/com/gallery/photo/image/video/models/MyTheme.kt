package com.gallery.photo.image.video.models

data class MyTheme(val nameId: Int, val textColorId: Int, val backgroundColorId: Int, val primaryColorId: Int, val appIconColorId: Int)
