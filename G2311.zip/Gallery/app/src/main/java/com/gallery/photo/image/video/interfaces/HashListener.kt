package com.gallery.photo.image.video.interfaces

interface HashListener {
    fun receivedHash(hash: String, type: Int)
}
