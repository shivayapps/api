package com.gallery.photo.image.video.lock;

public class FingerLockUtils {
    public static final String INTENT_TYPE="intent_type";
    public static final int ENABLE_FINGER =1;
    public static final int REMOVE_FINGER =2;
    public static final int UNLOCK_FINGER =0;
}
