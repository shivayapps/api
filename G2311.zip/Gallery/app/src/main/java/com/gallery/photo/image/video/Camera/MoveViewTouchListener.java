package com.gallery.photo.image.video.Camera;

import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class MoveViewTouchListener
        implements View.OnTouchListener {
    private GestureDetector mGestureDetector;
    private View mView;
    private View mView1;


    public MoveViewTouchListener(View view, View view1) {
        mGestureDetector = new GestureDetector(view.getContext(), mGestureListener);
        mView = view;
        mView1 = view1;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return mGestureDetector.onTouchEvent(event);
    }

    private GestureDetector.OnGestureListener mGestureListener = new GestureDetector.SimpleOnGestureListener() {
        private float mMotionDownX, mMotionDownY;

        @Override
        public boolean onDown(MotionEvent e) {
            mMotionDownX = e.getRawX() - mView.getTranslationX();
            mMotionDownY = e.getRawY() - mView.getTranslationY();

            return true;
        }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {

            Log.e("MoveViewTouchListener ", "-----------------------------");
            Log.e("MoveViewTouchListener ", "e1.getRawX(): " + e1.getRawX());
            Log.e("MoveViewTouchListener ", "e1.getRawY(): " + e1.getRawY());
            Log.e("MoveViewTouchListener ", "-----------------------------");
            Log.e("MoveViewTouchListener ", "e2.getRawX(): " + e2.getRawX());
            Log.e("MoveViewTouchListener ", "e2.getRawY(): " + e2.getRawY());
            Log.e("MoveViewTouchListener ", "-----------------------------");
            Log.e("MoveViewTouchListener ", "mView1.getTranslationX(): " + mView1.getTranslationX());
            Log.e("MoveViewTouchListener ", "mView1.getTranslationY(): " + mView1.getTranslationY());
            Log.e("MoveViewTouchListener ", "-----------------------------");
            Log.e("MoveViewTouchListener ", "mMotionDownX " + mMotionDownX);
            Log.e("MoveViewTouchListener ", "mMotionDownY: " + mMotionDownY);
            Log.e("MoveViewTouchListener ", "-----------------------------");

            mView.setTranslationX(e2.getRawX() - mMotionDownX);
            mView.setTranslationY(e2.getRawY() - mMotionDownY);
            return true;
        }
    };
}