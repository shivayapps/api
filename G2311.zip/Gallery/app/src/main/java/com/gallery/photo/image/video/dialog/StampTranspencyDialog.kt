package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import com.gallery.photo.image.video.R
import org.jetbrains.anko.layoutInflater


class StampTranspencyDialog(
    val activity: Context, val callback: () -> Unit
) {

    private var view: View

    init {

        view = activity.layoutInflater.inflate(R.layout.dialog_stamp_transparency, null)

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)


        dialog.show()
    }
}
