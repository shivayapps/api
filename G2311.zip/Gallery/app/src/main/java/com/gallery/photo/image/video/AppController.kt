package com.gallery.photo.image.video

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Base64
import android.util.Log
import androidx.lifecycle.LifecycleOwner
import com.example.app.ads.helper.AdsConfig
import com.example.app.ads.helper.openad.AppOpenApplication
import com.example.app.ads.helper.openad.OpenAdHelper
import com.gallery.photo.image.video.activity.*
import com.gallery.photo.image.video.activity.MainActivity.Companion.isInternalCall
import com.gallery.photo.image.video.bindActivity.StampCameraTemplateActivity
import com.gallery.photo.image.video.bindActivity.TimeLineActivity
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.cameraview.ui.NetworkChangeReceiver
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.fragment.VaultFragment
import com.gallery.photo.image.video.mainduplicate.activity.scanningactivities.ScanningActivity
import com.gallery.photo.image.video.utilities.isInterstitialShown
import com.gallery.photo.image.video.vaultgallery.di.appModule
import com.gallery.photo.image.video.vaultgallery.di.repoModule
import com.gallery.photo.image.video.vaultgallery.di.viewModelModule
//import com.google.firebase.FirebaseApp
//import com.google.firebase.messaging.FirebaseMessaging
import com.onesignal.OSNotificationOpenedResult
import com.onesignal.OneSignal
//import com.yandex.metrica.YandexMetrica
//import com.yandex.metrica.YandexMetricaConfig
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


open class AppController : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {
    var LOG_TAG = AppController::class.java.simpleName

    companion object {
        @JvmField
        var context: Context? = null

        lateinit var mInstance: AppController

        @Synchronized
        fun getInstance(): AppController {
            return mInstance
        }
    }

    override fun onCreate() {
        super.onCreate()
        context = this
        mInstance = this

        setAppLifecycleListener(this)
        AdsConfig.with(this)
            .isEnableOpenAd(true)
            .needToTakeAllTestAdID(false)
            .needToBlockInterstitialAd(false)
            .setAdmobAppId(getString(R.string.app_id))
            .setAdmobBannerAdId(getString(R.string.banner_ad_unit_id))
            .setAdmobInterstitialAdId(getString(R.string.inter_ad_unit_id))
            .setAdmobNativeAdvancedAdId(getString(R.string.native_ad_unit_id))
            .setAdmobOpenAdId(getString(R.string.open_ad_unit_id))
            .setAdmobRewardVideoAdId(getString(R.string.rewarded_video_ad_unit_id))
            .setAdmobInterstitialAdRewardId(getString(R.string.rewarded_interstitial_ad_unit_id))
            .initialize()

        initMobileAds()
        OpenAdHelper.loadOpenAd(this)
//        FirebaseApp.initializeApp(this)
//        FirebaseMessaging.getInstance().subscribeToTopic("galleryAll")

//        FacebookSdk.setAutoInitEnabled(true)
//        FacebookSdk.fullyInitialize()

        // OneSignal Initialization
        OneSignal.initWithContext(this)
        OneSignal.setAppId("83584564-b515-4d9e-8e24-b3d63de85ef5")
        OneSignal.setNotificationOpenedHandler(NotificationOpenedHandler(this))
        OneSignal.unsubscribeWhenNotificationsAreDisabled(true)
        OneSignal.setLocationShared(true)
        OneSignal.addSubscriptionObserver { stateChanges ->
            Log.e("TAG", "onCreate: || =>  in ==>> ..")
            Log.e("TAG", "onCreate: || => ---3-.-3  " + stateChanges.to.userId)
            if (!stateChanges.from.isSubscribed && stateChanges.to.isSubscribed) {
                Log.e("TAG", "onCreate: || => " + stateChanges.to.userId)
            } else {
                Log.e("TAG", "onCreate: null ")
            }
        }

//        try {
//            val config = YandexMetricaConfig.newConfigBuilder(resources.getString(R.string.app_metrica_api_key)).build()
//            // Initializing the AppMetrica SDK.
//            YandexMetrica.activate(applicationContext, config)
//            // Automatic tracking of user activity.
//            YandexMetrica.enableActivityAutoTracking(this)
//            Log.d("AppMetrica", "Configure successfully..")
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        printHashKey(this)
        startKoin {
            androidLogger()
            androidContext(applicationContext)
            modules(
                listOf(
                    appModule,
                    viewModelModule,
                    repoModule
                )
            )
        }
    }



    fun printHashKey(pContext: Context) {
        try {
            @SuppressLint("PackageManagerGetSignatures") val info =
                pContext.packageManager.getPackageInfo(
                    pContext.packageName,
                    PackageManager.GET_SIGNATURES
                )
            for (signature in info.signatures) {
                val md: MessageDigest = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                val hashKey: String = String(Base64.encode(md.digest(), 0))
                Log.i("AppOpenApplication", "printHashKey() Hash Key: $hashKey")
            }
        } catch (e: NoSuchAlgorithmException) {
            Log.e("AppOpenApplication", "printHashKey()", e)
        } catch (e: Exception) {
            Log.e("AppOpenApplication", "printHashKey()", e)
        }
    }


    class NotificationOpenedHandler(private var mContext: Context) : OneSignal.OSNotificationOpenedHandler {
        var mTAG = "AppController"
        override fun notificationOpened(result: OSNotificationOpenedResult?) {
            val data = result!!.notification.additionalData

            Log.e(mTAG, "startHome: $data")

            if (data != null) {
                val customKey = data.optString("OpenActivity", null)
                if (customKey != null) {
                    when (customKey) {
                        "MainActivity" -> {
                            val intent = Intent(mContext, MainActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("mType", 0)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "MainActivity_Video" -> {
                            val intent = Intent(mContext, MainActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("mType", 1)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "MainActivity_Vault" -> {
                            val intent = Intent(mContext, MainActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("mType", 2)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "RecoverPhotoActivity" -> {
                            val intent = Intent(mContext, RecoverPhotoNewActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "PlaceActivity" -> {
                            val intent = Intent(mContext, PlaceActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("IsFromNotification", "yes")
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "HDCameraActivity" -> {
                            val intent = Intent(mContext, com.gallery.photo.image.video.Camera.CameraActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "DuplicateFinderActivity" -> {
                            val intent = Intent(mContext, DuplicateFinderActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true

                        }
                        "ScanningActivity_Image" -> {
                            val intent = Intent(mContext, ScanningActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("IsCheckType", "Image")
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true

                        }
                        "ScanningActivity_Video" -> {
                            val intent = Intent(mContext, ScanningActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("IsCheckType", "Video")
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "ScanningActivity_Audio" -> {
                            val intent = Intent(mContext, ScanningActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("IsCheckType", "Audio")
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "ScanningActivity_Document" -> {
                            val intent = Intent(mContext, ScanningActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("IsCheckType", "Document")
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "ScanningActivity_Other" -> {
                            val intent = Intent(mContext, ScanningActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            intent.putExtra("IsCheckType", "Other")
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "TimeLineActivity" -> {
                            val intent = Intent(mContext, TimeLineActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                        "StampTemplateActivity"->{
                            val intent = Intent(mContext, StampCameraTemplateActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                            intent.putExtra("IsCheckOneSignalNotification", true)
                            mContext.startActivity(intent)
                            mContext.config.isFromOneSignalNotification = true
                        }
                    }
                }
            }
        }
    }

    fun setConnectivityListener(listener: NetworkChangeReceiver.ConnectivityReceiverListener1?) {
        NetworkChangeReceiver.connectivityReceiverListener = listener
    }

    override fun onPause(owner: LifecycleOwner) {
        super.onPause(owner)
            VaultFragment.isFirstTime = true
            VaultFragment.isTabUnlock = false
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        Log.e("TAG", "onResumeApp: fCurrentActivity::${fCurrentActivity.localClassName}")
        val isNeedToShowAd: Boolean = when {
            fCurrentActivity is OpenAdSplashActivity -> {
                Log.d("TAG", "onResumeApp: fCurrentActivity is OpenAdSplashActivity")
                false
            }
            fCurrentActivity.javaClass.simpleName.contains("MoreAppsActivity") -> {
                Log.d(LOG_TAG, "onResumeApp: fCurrentActivity is MoreAppsActivity")
                false
            }
            fCurrentActivity is AccessPermissionActivity -> {
                Log.d(LOG_TAG, "ON_RESUME: AccessPermissionActivity")
                false
            }

            isInterstitialShown -> {
                Log.d(LOG_TAG, "isInterstitialShown")
                false
            }
            fCurrentActivity!!.config.isFromOneSignalNotification -> {
                Log.d(LOG_TAG, "isFromOneSignalNotification")
                false
            }
            AdsManager(fCurrentActivity).isNeedToShowAds() -> {
                true
            }
            else -> {
                false
            }
        }
        isInternalCall = false
        fCurrentActivity.config.isFromOneSignalNotification = false

        return isNeedToShowAd
    }

}