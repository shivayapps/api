package com.gallery.photo.image.video.models

data class BrowserBookmark(var title: String, var link: String)