package com.gallery.photo.image.video.dialog

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseSimpleActivity


class EnableFakeVaultDialog(
    val activity: BaseSimpleActivity, val callback: (isConfirm: Boolean) -> Unit
) {

    private var view: View = activity.layoutInflater.inflate(R.layout.dialog_enable_fake_vault, null)
    var dialog: Dialog = Dialog(activity)

    init {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
        dialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val ivClose = dialog.findViewById(R.id.ivClose) as ImageView
        val tvTitle = dialog.findViewById(R.id.tvTitle) as TextView
        val message = dialog.findViewById(R.id.message) as TextView
//        val font = Typeface.createFromAsset(activity.assets, "fonts/avenirltpromedium.otf")
//        tvTitle.typeface = font

//        message.text = activity.getString(R.string.msg_enable_fake_vault)
        ivClose.setOnClickListener {
            dialog.dismiss()
            callback(false)
        }

        val tvDone = dialog.findViewById(R.id.tvDone) as TextView
        tvDone.setOnClickListener {
            dialog.dismiss()
            callback(true)
        }

        dialog.show()

    }


}
