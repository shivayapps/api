package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.app.ads.helper.GiftIconHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.RvAdapter
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.cameraview.APIService
import com.gallery.photo.image.video.databinding.ActivityHelpFaqBinding
import com.gallery.photo.image.video.extensions.config
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.models.QuestionDataList
import com.gallery.photo.image.video.models.QuestionResponseModel
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beVisible
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HelpFAQActivity : BaseBindingActivity<ActivityHelpFaqBinding>() {
    // get reference to the adapter class
    private var languageList = ArrayList<QuestionDataList>()
    private lateinit var rvAdapter: RvAdapter

    private var apiInterface: APIService.APIInterface? = null

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        mBinding.rvList.layoutManager = LinearLayoutManager(this)
        mBinding.imgBack.setOnClickListener {
            onBackPressed()
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.clGiftIcon.giftAdIcon,
                fivBlastIcon = mBinding.clGiftIcon.giftBlastAdIcon
            )
        }
        getQuestionData()
    }

    private fun getQuestionData() {
        mBinding.llProgress.beVisible()
        if (isOnline() && !config.isHelpQueLoaded) {
            apiInterface = APIService().getClient(this)
            val call: Call<QuestionResponseModel> = apiInterface!!.getAllQuestion(getString(R.string.api_token))
            call.enqueue(object : Callback<QuestionResponseModel> {
                override fun onResponse(call: Call<QuestionResponseModel>, response: Response<QuestionResponseModel>) {
                    Log.d(TAG, "onResponse:  -->" + response.body())
                    languageList = response.body()!!.data as ArrayList<QuestionDataList>
                    rvAdapter = RvAdapter(languageList)
                    mBinding.rvList.adapter = rvAdapter
                    config.helpQueAns = Gson().toJson(languageList)
                    config.isHelpQueLoaded=true
                    mBinding.llProgress.beGone()
                    if (languageList.isEmpty()) {
                        mBinding.mediaEmptyTextPlaceholder.beVisible()
                    }
                }

                override fun onFailure(call: Call<QuestionResponseModel>, t: Throwable) {
                    t.printStackTrace()
                }
            })
        } else {
            languageList = config.parseHelpQueAns()
            rvAdapter = RvAdapter(languageList)
            mBinding.rvList.adapter = rvAdapter
            mBinding.llProgress.beGone()
            if (languageList.isEmpty()) {
                mBinding.mediaEmptyTextPlaceholder.beVisible()
            }
        }
    }

    override fun initActions() {
    }

    override fun setBinding(): ActivityHelpFaqBinding {
        return ActivityHelpFaqBinding.inflate(inflater)
    }

}