package com.gallery.photo.image.video.adapter

import android.graphics.Color
import android.util.TypedValue
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beVisible
import com.gallery.photo.image.video.views.MyRecyclerView
import kotlinx.android.synthetic.main.item_vault_hidden_item_adapter.view.*
import java.util.LinkedHashSet

class VaultHiddenItemsAdapter(
    activity: BaseSimpleActivity, val paths: List<String>, val index: Int, recyclerView: MyRecyclerView,
    itemClick: (Any) -> Unit
) : MyRecyclerViewAdapter(activity, recyclerView, null, itemClick) {

    private var fontSize = 0f

    init {
        fontSize = resources.getDimension(com.gallery.photo.image.video.R.dimen.normal_text_size)
    }

    override fun getActionMenuId() = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = createViewHolder(R.layout.item_vault_hidden_item_adapter, parent)

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val path = paths[position]
        holder.bindView(path, true, false) { itemView, adapterPosition ->
            setupView(itemView, path, position)
        }
        bindViewHolder(holder)
    }

    override fun getItemCount() = paths.size

    override fun prepareActionMode(menu: Menu) {}

    override fun actionItemPressed(id: Int) {}

    override fun getSelectableItemCount() = paths.size

    override fun getIsItemSelectable(position: Int) = false

    override fun getItemKeyPosition(key: Int) = paths.indexOfFirst { it.hashCode() == key }

    override fun getItemSelectionKey(position: Int) = paths[position].hashCode()

    override fun onActionModeCreated() {}

    override fun onActionModeDestroyed() {}
    override fun getSelectedList(): LinkedHashSet<Int> {
        return LinkedHashSet()
    }


    private fun setupView(view: View, path: String, position: Int) {
        view.apply {
            filepicker_favorite_label.text = path
            filepicker_favorite_label.setTextColor(Color.DKGRAY)
            filepicker_favorite_label.setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize)
            if (index > position) {
                medium_check.beVisible()
            } else {
                medium_check.beGone()
            }
        }
    }
}
