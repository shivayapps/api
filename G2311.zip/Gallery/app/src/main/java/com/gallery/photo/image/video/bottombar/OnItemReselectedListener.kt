package com.gallery.photo.image.video.bottombar

interface OnItemReselectedListener {

    fun onItemReselect(pos: Int)
}
