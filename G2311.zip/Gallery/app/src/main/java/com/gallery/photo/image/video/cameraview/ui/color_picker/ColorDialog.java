package com.gallery.photo.image.video.cameraview.ui.color_picker;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;

import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

public class ColorDialog {
    private static final String TAG = "ColorDialog";

    public interface OnResultListener {
        void onCancel();

        void onColorPicked(int i);
    }

    public static void show(Context context, OnResultListener onResultListener) {
        show(context, 0, onResultListener);
    }

    public static void show(Context context, int i, OnResultListener onResultListener) {
        ColorDialogFragment colorDialogFragment = new ColorDialogFragment();
        colorDialogFragment.setOnResultListener(onResultListener);
        if (i != 0) {
            colorDialogFragment.setSelectedColorInt(i);
        } else {
            colorDialogFragment.setSelectedColorInt(Color.parseColor(ColorDialogFragment.TRANSPARENT));
        }
        colorDialogFragment.show(getFragmentManager(context), TAG);
    }

    public static int getRandomColor() {
        return ColorDialogFragment.getRandomColor();
    }

    private static FragmentManager getFragmentManager(Context context) {
        try {
            return ((FragmentActivity) context).getSupportFragmentManager();
        } catch (ClassCastException e) {
            Log.e(TAG, "Can't get the fragment manager with class. FragmentActivity required ");
            return null;
        }
    }
}
