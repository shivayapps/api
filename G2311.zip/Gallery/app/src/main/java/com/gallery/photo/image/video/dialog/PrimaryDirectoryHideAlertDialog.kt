package com.gallery.photo.image.video.dialog

import androidx.appcompat.app.AlertDialog
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.VaultHiddenItemsAdapter
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beVisible
import com.gallery.photo.image.video.extensions.setupDialogStuff
import kotlinx.android.synthetic.main.dialog_primary_directory_hide_alert.view.*

class PrimaryDirectoryHideAlertDialog(activity: BaseSimpleActivity, paths: List<String>, val index: Int, val callback: (isok: Boolean) -> Unit) {
    var dialog: AlertDialog

    init {
        val layout = R.layout.dialog_primary_directory_hide_alert
        val view = activity.layoutInflater.inflate(layout, null)


        var primaryDirPath = paths.filter {
            it == RECOVER_DIR_PATH || it == RESTORE_DIR_PATH || it == DCIM_DIR_PATH || it == PICTURE_DIR_PATH || it.lowercase() == DOWNLOAD_DIR_PATH.lowercase() || it == CAMERA_DIR_PATH || it == HD_CAMERA_DIR_PATH || it == MOVIE_DIR_PATH || it == RESTORE_TRASH_DIR_PATH || it == STORAGE_DIR_PATH || it.lowercase() == SCREENSHOT_DIR_PATH.lowercase()
        } as ArrayList<String>

        if (paths.size == 1) {
            view.alet_msg_text.text = activity.getString(R.string.msg_primary_directory_no_allow_to_hide_single, primaryDirPath[0].substringAfterLast("/"))
            view.rvHiddenFolderList.beGone()
        } else {
            view.alet_msg_text.text = activity.getString(R.string.msg_primary_directory_no_allow_to_hide)

            view.rvHiddenFolderList.beVisible()
            VaultHiddenItemsAdapter(activity, primaryDirPath, index, view.rvHiddenFolderList) {
            }.apply {
                view.rvHiddenFolderList.adapter = this
            }
        }

        dialog = AlertDialog.Builder(activity)
            .setCancelable(false)
            .setPositiveButton(R.string.ok) { dialog, which -> dialogConfirmed() }
            .setNegativeButton(R.string.cancel) { dialog, which ->
                dialog.dismiss()
                callback(false)
            }

            .setOnCancelListener {
                BaseSimpleActivity.funAfterSAFPermission?.invoke(false)
                BaseSimpleActivity.funAfterSAFPermission = null
            }
            .create().apply {
                activity.setupDialogStuff(view, this, R.string.label_alert, cancelOnTouchOutside = false)
            }
    }

    private fun dialogConfirmed() {
        dialog.dismiss()
        callback(true)
    }
}
