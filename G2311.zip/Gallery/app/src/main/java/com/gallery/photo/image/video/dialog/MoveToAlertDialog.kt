package com.gallery.photo.image.video.dialog

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.setupDialogStuff
import kotlinx.android.synthetic.main.dialog_delete_with_remember.view.*

class MoveToAlertDialog(val activity: Activity, val message: String, val callback: (remember: Boolean) -> Unit) {
    private var dialog: AlertDialog
    val view = activity.layoutInflater.inflate(R.layout.dialog_delete_with_remember, null)!!

    init {
        view.delete_remember_title.text = message
        val builder = AlertDialog.Builder(activity, R.style.MyAlertDialogNew)
            .setPositiveButton(R.string.yes) { dialog, which -> dialogConfirmed() }
            .setNegativeButton(R.string.no) { dialog, which -> callback(false) }

        dialog = builder.create().apply {
            activity.setupDialogStuff(view, this)
        }
    }

    private fun dialogConfirmed() {
        dialog.dismiss()
        callback(true)
    }
}
