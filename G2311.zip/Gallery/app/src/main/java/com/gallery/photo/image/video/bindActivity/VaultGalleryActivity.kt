package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.View.VISIBLE
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gallery.internal.entity.Album
import com.example.gallery.internal.entity.Item
import com.example.gallery.internal.entity.SelectionSpec
import com.example.gallery.internal.model.AlbumCollection
import com.example.gallery.internal.model.AlbumCollection.AlbumCallbacks
import com.example.gallery.internal.model.SelectedItemCollection
import com.example.gallery.internal.ui.MediaSelectionFragment
import com.example.gallery.internal.ui.MediaSelectionFragment.SelectionProvider
import com.example.gallery.internal.ui.adapter.AlbumMediaAdapter.*
import com.example.gallery.internal.ui.adapter.AlbumsAdapter
import com.example.gallery.internal.ui.adapter.albumNewAdapter
import com.example.gallery.internal.utils.MediaStoreCompat
import com.example.jdrodi.utilities.toast
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseActivity
import com.gallery.photo.image.video.utilities.AsyncBackgroundWork
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_LIST
import com.gallery.photo.image.video.vaultgallery.model.KEY_MEDIA_TYPE
import com.gallery.photo.image.video.extensions.beGone
import com.gallery.photo.image.video.extensions.beVisible
import com.gallery.photo.image.video.helpers.CHOOSE_IMAGE_TYPE
import kotlinx.android.synthetic.main.activity_vault_gallery.*
import kotlinx.android.synthetic.main.activity_vault_gallery.arrow
import kotlinx.android.synthetic.main.activity_vault_gallery.buttonFinish
import kotlinx.android.synthetic.main.activity_vault_gallery.imgDeSelectAll
import kotlinx.android.synthetic.main.activity_vault_gallery.imgSelectAll
import kotlinx.android.synthetic.main.activity_vault_gallery.llHideOpt
import kotlinx.android.synthetic.main.activity_vault_gallery.rlAlbumName
import java.lang.RuntimeException
import java.util.ArrayList

val ARG_FILTER_TYPE = "arg_filter_type"

class VaultGalleryActivity : BaseActivity(),
    AlbumCallbacks, android.widget.AdapterView.OnItemSelectedListener,
    SelectionProvider,
    CheckStateListener, OnMediaClickListener, albumNewAdapter.AlbumItemClick,
    OnPhotoCapture {

    private val REQUEST_CODE_CAPTURE = 24
    val CHECK_STATE = "checkState"
    private val mAlbumCollection = AlbumCollection()
    private lateinit var mMediaStoreCompat: MediaStoreCompat
    private val mSelectedCollection = SelectedItemCollection(this)
    private lateinit var mSpec: SelectionSpec


    private var mOriginalEnable = false
    var filterType = CHOOSE_IMAGE_TYPE

    //    private var mAlbumsSpinner: AlbumsSpinner? = null
    private var mAlbumsAdapter: AlbumsAdapter? = null


    companion object {
        fun newIntent(mContext: Context, FilterType: Int): Intent {
            var intent = Intent(mContext, VaultGalleryActivity::class.java)
            intent.putExtra(ARG_FILTER_TYPE, FilterType)

            return intent
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {

        mSpec = SelectionSpec.getInstance()
        setTheme(mSpec.themeId)
        super.onCreate(savedInstanceState)
        if (!mSpec.hasInited) {
            setResult(RESULT_CANCELED)
            finish()
            return
        }
        setContentView(R.layout.activity_vault_gallery)

        if (mSpec.needOrientationRestriction()) {
            requestedOrientation = mSpec.orientation
        }
        filterType = intent.getIntExtra(ARG_FILTER_TYPE, CHOOSE_IMAGE_TYPE)
        if (mSpec.capture) {
            mMediaStoreCompat = MediaStoreCompat(this)
            if (mSpec.captureStrategy == null) throw RuntimeException("Don't forget to set CaptureStrategy.")
            mMediaStoreCompat.setCaptureStrategy(mSpec.captureStrategy)
        }


        buttonBack.setOnClickListener(this)
        rlAlbumName.setOnClickListener(this)
        imgSelectAll.setOnClickListener(this)
        imgDeSelectAll.setOnClickListener(this)
        llHideOpt.setOnClickListener(this)


        mSelectedCollection.onCreate(savedInstanceState)
        if (savedInstanceState != null) {
            mOriginalEnable = savedInstanceState.getBoolean(CHECK_STATE)
        }
        updateBottomToolbar()

        mAlbumsAdapter = AlbumsAdapter(this, null, false, true)
        mAlbumCollection.onCreate(this, this)
        mAlbumCollection.onRestoreInstanceState(savedInstanceState)
        mAlbumCollection.loadAlbums()

        selected_album.text = getString(R.string.album_name_all)
        selected_album.isEnabled = false
        showProgress()
        bottom_toolbar.beVisible()


    }

    private fun updateBottomToolbar() {
        if (mSelectedCollection != null) {
            val selectedCount = mSelectedCollection.count()
            buttonFinish.text = resources.getString(R.string.hide_photo, selectedCount)
            var fragment = supportFragmentManager.findFragmentById(R.id.container)
            if (fragment is MediaSelectionFragment) {
                if (selected_album.text != getString(R.string.album_name_all)) {
                    var totalCount = fragment.mAdapter.cursor
                    if (totalCount.count == selectedCount) {
                        imgDeSelectAll.beVisible()
                        imgSelectAll.beGone()
                    } else {
                        imgDeSelectAll.beGone()
                        imgSelectAll.beVisible()
                    }
                } else {
                    imgDeSelectAll.beGone()
                    imgSelectAll.beGone()
                }
            }
        }
    }


    override fun onClick(v: View) {
        when (v.id) {
            R.id.rlAlbumName -> {
//                selected_album.performClick()
                if (recyclerviewAlbum.visibility == VISIBLE) {
                    arrow.rotation = 0f
                    recyclerviewAlbum.beGone()
                    bottom_toolbar.beVisible()
                    container.beVisible()
                    updateBottomToolbar()

                } else {
                    arrow.rotation += 180
                    recyclerviewAlbum.beVisible()
                    container.beGone()
                    bottom_toolbar.beGone()
                    imgDeSelectAll.beGone()
                    imgSelectAll.beGone()
                }
            }
            R.id.buttonBack -> {
                onBackPressed()
            }
            R.id.imgSelectAll -> {
                var fragment = supportFragmentManager.findFragmentById(R.id.container)
                if (fragment is MediaSelectionFragment) {
                    (fragment as MediaSelectionFragment).mAdapter.toggleSelection(true)
                }
            }
            R.id.imgDeSelectAll -> {
                var fragment = supportFragmentManager.findFragmentById(R.id.container)
                if (fragment is MediaSelectionFragment) {
                    (fragment as MediaSelectionFragment).mAdapter.toggleSelection(false)
                }
            }
            R.id.llHideOpt -> {
                var selectedPaths = ArrayList<String>()
                AsyncBackgroundWork({
                    showProgress(getString(R.string.please_wait))
                }, {
                    selectedPaths = mSelectedCollection.asListOfString() as ArrayList<String>
                }, {
                    dismissProgress()
                    if (selectedPaths.isEmpty()) {
                        toast(getString(R.string.error_please_select_one_item))
                    } else {
                        setResult(Activity.RESULT_OK, Intent().apply {
                            putStringArrayListExtra(KEY_MEDIA_LIST, selectedPaths)
                            putExtra(KEY_MEDIA_TYPE, filterType)
                        })
                        finish()
                    }
                })


            }
        }

    }


    fun showProgress() {
        progress.beVisible()
    }

    private fun dismissProgressBar() {
        progress.beGone()
    }

    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
    }

    override fun initActions() {
    }


    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        mAlbumCollection.setStateCurrentSelection(position)
        mAlbumsAdapter!!.cursor.moveToPosition(position)
        mSelectedCollection.clearList()
        updateBottomToolbar()
        val album = Album.valueOf(mAlbumsAdapter!!.cursor)
        if (album.isAll && SelectionSpec.getInstance().capture) {
            album.addCaptureCount()
        }
        val displayName = album.getDisplayName(this)
        if (displayName == getString(R.string.album_name_all)) {
            imgDeSelectAll.beGone()
            imgSelectAll.beGone()
        } else {
            imgDeSelectAll.beGone()
            imgSelectAll.beVisible()
        }
        onAlbumSelected(album)
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {}

    override fun onAlbumLoad(cursor: Cursor) {
        mAlbumsAdapter!!.swapCursor(cursor)
        val handler = Handler(Looper.getMainLooper())
        handler.post {
            cursor.moveToPosition(mAlbumCollection.currentSelection)
            val album = Album.valueOf(cursor)
            if (album.isAll && SelectionSpec.getInstance().capture) {
                album.addCaptureCount()
            }
            recyclerviewAlbum.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
            recyclerviewAlbum.setHasFixedSize(true)
            val adapter = albumNewAdapter(cursor, this, this)
            recyclerviewAlbum.adapter = adapter

            onAlbumSelected(album)
            dismissProgressBar()
        }
    }

    override fun onAlbumReset() {
        mAlbumsAdapter!!.swapCursor(null)
    }

    public fun onAlbumSelected(album: Album) {
        selected_album.text = album.getDisplayName(this)
        selected_album.isEnabled = true
        if (album.isAll && album.isEmpty) {
            container.beGone()
            empty_view.beVisible()
        } else {
            container.beVisible()
            empty_view.beGone()
            val fragment: Fragment = MediaSelectionFragment.newInstance(album)
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.container, fragment, MediaSelectionFragment::class.java.simpleName)
                .commitAllowingStateLoss()
        }
    }


    override fun onUpdate() {
        // notify bottom toolbar that check state changed.
        updateBottomToolbar()
        if (mSpec.onSelectedListener != null) {
            mSpec.onSelectedListener.onSelected(
                mSelectedCollection.asListOfUri(), mSelectedCollection.asListOfString()
            )
        }
    }

    override fun onMediaClick(album: Album?, item: Item?, adapterPosition: Int, isPreview: Boolean) {

    }

    override fun provideSelectedItemCollection(): SelectedItemCollection? {
        return mSelectedCollection
    }

    override fun capture() {
        if (mMediaStoreCompat != null) {
            mMediaStoreCompat.dispatchCaptureIntent(this, REQUEST_CODE_CAPTURE)
        }
    }


    override fun onAlbumSelect(album: Album?) {
        recyclerviewAlbum.beGone()
        bottom_toolbar.beVisible()
        container.beVisible()
        mSelectedCollection.clearList()
        updateBottomToolbar()
        if (album!!.isAll && SelectionSpec.getInstance().capture) {
            album!!.addCaptureCount()
        }
        val displayName = album!!.getDisplayName(this)
        if (displayName == getString(R.string.album_name_all)) {
            imgDeSelectAll.beGone()
            imgSelectAll.beGone()
        } else {
            imgDeSelectAll.beGone()
            imgSelectAll.beVisible()
        }
        onAlbumSelected(album!!)
    }

    override fun onBackPressed() {
        if (recyclerviewAlbum.visibility == VISIBLE) {
            arrow.rotation = 0f
            recyclerviewAlbum.beGone()
            bottom_toolbar.beVisible()
            container.beVisible()
        } else
            super.onBackPressed()
    }

}