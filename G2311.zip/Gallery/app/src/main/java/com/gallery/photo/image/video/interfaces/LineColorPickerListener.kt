package com.gallery.photo.image.video.interfaces

interface LineColorPickerListener {
    fun colorChanged(index: Int, color: Int)
}
