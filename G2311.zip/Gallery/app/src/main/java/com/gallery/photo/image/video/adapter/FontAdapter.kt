package com.gallery.photo.image.video.adapter

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import com.gallery.photo.image.video.databinding.ItemFontListBinding
import java.util.ArrayList


class FontAdapter(private val context: Context, private val list: ArrayList<String>) : BaseAdapter<String>(list) {

    private var mEventListener: EventListener? = null

    interface EventListener {
        fun onItemViewClicked(position: Int)
        fun onDeleteMember(position: Int)
    }

    private fun onItemViewClicked(position: Int) {
        if (mEventListener != null) {
            mEventListener!!.onItemViewClicked(position)
        }
    }

    fun getItem(position: Int): String {
        return list[position]
    }

    inner class MyViewHolder(fBinding: ItemFontListBinding) : BaseViewHolder<ItemFontListBinding>(fBinding)


    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        return MyViewHolder(ItemFontListBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun onBindHolder(holder: BaseViewHolder<*>, position: Int) {
        with(holder as MyViewHolder) {
            with(fBinding) {
                with(list[position]) {
                    tvFontName.setOnClickListener { onItemViewClicked(position) }
                    val height = (context.resources.displayMetrics.heightPixels * 0.09).toInt()
                    holder.itemView.layoutParams.height = height
                    val typeface = Typeface.createFromFile(list[position])

                    tvFontName.text = "Hello"
                    tvFontName.typeface = typeface
                }
            }
        }
    }

    fun setEventListener(eventListener: EventListener) {
        mEventListener = eventListener
    }


    override fun getItemCount(): Int {
        return list.size
    }
}