package com.gallery.photo.image.video.mainduplicate.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.ImageView
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.activity.previewactivities.PreviewVideoActivity
import com.gallery.photo.image.video.mainduplicate.adapter.ListVideoAdapter.VideoViewHolder
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.utils.MyUtils
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants
import com.gallery.photo.image.video.utilities.AsyncBackgroundWork
import java.io.File

@Suppress("DEPRECATION")
class ListVideoAdapter @SuppressLint("WrongConstant") constructor(
    var gridVideoAdapterContext: Context,
    var gridVideoAdapterActivity: Activity,
    var videosMarkedListener: MarkedListener,
    var individualGroupVideos: IndividualGroupModel,
    var video: List<ItemDuplicateModel>,
    var parentCheckbox: CheckBox
) : RecyclerView.Adapter<VideoViewHolder>() {

    var inflater: LayoutInflater = gridVideoAdapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    var totalNumberOfflineInSet = 0

    @SuppressLint("StaticFieldLeak")
    class GridViewVideoLoader internal constructor(
        var videoLoaderContext: Context,
        var imageViewReference: ImageView?,
        var checkBoxReference: CheckBox,
//        var lTxtIndividualSize: TextView
    ) : AsyncTask<ItemDuplicateModel?, Void?, String?>() {
        var checkBoxStatus: Boolean? = null
        override fun doInBackground(vararg params: ItemDuplicateModel?): String? {
            val lVideoItem = params[0]!!.filePath
            checkBoxStatus = params[0]!!.isFileCheckBox
            mSize = String.format("%s", ShareConstants.getReadableFileSize(params[0]!!.sizeOfTheFile))
            return lVideoItem
        }

        override fun onPostExecute(path: String?) {
            super.onPostExecute(path)
            if (imageViewReference != null) {
                Glide.with(videoLoaderContext)
                    .load(Uri.fromFile(File(path!!)))
                    .centerCrop()
                    .placeholder(R.drawable.img_thumb)
                    .into(imageViewReference!!)
                checkBoxReference.isChecked = checkBoxStatus!!
//                lTxtIndividualSize.text = mSize
            }
        }
    }

    class VideoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var checkBox: CheckBox = view.findViewById<View>(R.id.checkbox_video) as CheckBox
        var video: ImageView? = view.findViewById<View>(R.id.duplicate_video) as ImageView
//        var lIndividualSize: TextView = view.findViewById(R.id.individualsize)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        return VideoViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.row_list_of_group_of_video_item, parent, false))
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        val lVideoItem = video[position]
        holder.checkBox.isChecked = lVideoItem.isFileCheckBox
        holder.checkBox.tag = position
        Glide.with(gridVideoAdapterContext)
            .load(lVideoItem.filePath)
            .centerCrop()
            .placeholder(R.drawable.image_placeholder)
            .into(holder.video!!)
        holder.video!!.setOnClickListener {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1200) {
                return@setOnClickListener
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
            val intent = Intent(gridVideoAdapterActivity, PreviewVideoActivity::class.java)
            val bundle = Bundle()
            bundle.putSerializable("videoItem", lVideoItem)
            intent.putExtras(bundle)
            intent.putExtra("totalNumberOfFiles", totalNumberOfflineInSet)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            gridVideoAdapterActivity.startActivity(
                intent,
                ActivityOptionsCompat.makeCustomAnimation(
                    gridVideoAdapterContext,
                    R.anim.slide_from_left,
                    R.anim.slide_from_right
                ).toBundle()
            )
        }
        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                lVideoItem.isFileCheckBox = isChecked
                var selectCount = 0
                val numOffLine = itemCount
                if (lVideoItem.isFileCheckBox) {
                    for (i in 0 until itemCount) {
                        if (video[i].isFileCheckBox) {
                            selectCount++
                        }
                    }
                    if (selectCount != numOffLine) {
                        GlobalVarsAndFunctions.file_to_be_deleted_videos.add(lVideoItem)
                        GlobalVarsAndFunctions.addSizeVideos(lVideoItem.sizeOfTheFile)
                        videosMarkedListener.updateMarked()
                        individualGroupVideos.isCheckBox = true
                        parentCheckbox.isChecked = true
                    }
                } else {
                    GlobalVarsAndFunctions.file_to_be_deleted_videos.remove(lVideoItem)
                    GlobalVarsAndFunctions.subSizeVideos(lVideoItem.sizeOfTheFile)
                    videosMarkedListener.updateMarked()
                }
                if (selectCount < numOffLine - 1) {
                    parentCheckbox.isChecked = false
                    individualGroupVideos.isCheckBox = false
                } else {
                    individualGroupVideos.isCheckBox = true
                    parentCheckbox.isChecked = true
                }
                if (numOffLine == selectCount) {
                    MyUtils.showToastMsg(gridVideoAdapterContext, gridVideoAdapterContext.getString(R.string.error_not_select_all_video_in_same))
                    lVideoItem.isFileCheckBox = false
                    holder.checkBox.isChecked = false
                    return@setOnClickListener
                }
                lVideoItem.isFileCheckBox = isChecked
            }
        }
        if (holder.video != null) {
            var lCheckboxStatus: Boolean? = null
            AsyncBackgroundWork({}, {
                lCheckboxStatus = lVideoItem.isFileCheckBox
                mSize =
                    String.format("%s", ShareConstants.getReadableFileSize(lVideoItem.sizeOfTheFile))
            }, {
                holder.checkBox.isChecked = lCheckboxStatus!!
            })

        }
    }

    override fun getItemCount(): Int {
        totalNumberOfflineInSet = video.size
        return totalNumberOfflineInSet
    }

    companion object {
        var mSize = ""
    }

}