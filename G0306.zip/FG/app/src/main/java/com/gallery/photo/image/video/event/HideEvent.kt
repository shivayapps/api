package com.gallery.photo.image.video.event

data class HideEvent(var isUpdate: Boolean = false)
