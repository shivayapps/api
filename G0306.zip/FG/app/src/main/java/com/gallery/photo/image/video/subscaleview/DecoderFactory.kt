package com.gallery.photo.image.video.subscaleview

interface DecoderFactory<T> {
    fun make(): T
}
