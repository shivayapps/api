package com.gallery.photo.image.video.secret.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.gallery.photo.image.video.databinding.ItemSelectImagesBinding
import com.gallery.photo.image.video.model.PictureData

class SelectImageListAdapter(
    var context: Context,
    var selectedImageList: ArrayList<PictureData>,
    val deleteListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<SelectImageListAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemSelectImagesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return selectedImageList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val albumData = selectedImageList[position]
        Glide.with(context.applicationContext)
            .asBitmap()
            .load(albumData.filePath)
            .into(holder.binding.image)

        holder.binding.icClose.setOnClickListener {
            deleteListener(position)
        }
    }

    class ViewHolder(var binding: ItemSelectImagesBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}