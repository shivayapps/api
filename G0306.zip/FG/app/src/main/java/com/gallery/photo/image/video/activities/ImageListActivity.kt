package com.gallery.photo.image.video.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.gallery.photo.image.video.BuildConfig
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adapter.PictureAdapter
import com.gallery.photo.image.video.base.BaseActivity
import com.gallery.photo.image.video.customview.MyGridLayoutManager
import com.gallery.photo.image.video.customview.MyRecyclerView
import com.gallery.photo.image.video.database.AppDatabase
import com.gallery.photo.image.video.databinding.ActivityImageListBinding
import com.gallery.photo.image.video.databinding.PopBottomMenuBinding
import com.gallery.photo.image.video.dialog.ConfirmationDialog
import com.gallery.photo.image.video.dialog.CreateAlbumDialog
import com.gallery.photo.image.video.dialog.DeleteDialog
import com.gallery.photo.image.video.dialog.DetailsDialog
import com.gallery.photo.image.video.dialog.DisplayedColumnsDialog
import com.gallery.photo.image.video.dialog.FilterMediaDialog
import com.gallery.photo.image.video.dialog.GroupDialog
import com.gallery.photo.image.video.dialog.MainMenuDialog
import com.gallery.photo.image.video.dialog.ProgressDialog
import com.gallery.photo.image.video.dialog.RenameDialog
import com.gallery.photo.image.video.dialog.ResizeDialog
import com.gallery.photo.image.video.dialog.SelectAlbumFullDialog
import com.gallery.photo.image.video.dialog.SortDialog
import com.gallery.photo.image.video.dialog.BatchFolderRenameDialog
import com.gallery.photo.image.video.dialog.SelectAlbumDialog
import com.gallery.photo.image.video.event.CopyMoveEvent
import com.gallery.photo.image.video.event.DeleteEvent
import com.gallery.photo.image.video.event.DisplayDeleteEvent
import com.gallery.photo.image.video.event.RenameEvent
import com.gallery.photo.image.video.event.RestoreDataEvent
import com.gallery.photo.image.video.event.UpdateFavoriteEvent
import com.gallery.photo.image.video.extension.beGone
import com.gallery.photo.image.video.extension.beVisible
import com.gallery.photo.image.video.extension.beVisibleIf
import com.gallery.photo.image.video.extension.getFilenameExtension
import com.gallery.photo.image.video.extension.getFilenameFromPath
import com.gallery.photo.image.video.extension.getFinalUriFromPath
import com.gallery.photo.image.video.extension.getParentFolder
import com.gallery.photo.image.video.extension.getUriMimeType
import com.gallery.photo.image.video.extension.isApng
import com.gallery.photo.image.video.extension.isGif
import com.gallery.photo.image.video.extension.isImageFast
import com.gallery.photo.image.video.extension.isPng
import com.gallery.photo.image.video.extension.isPortrait
import com.gallery.photo.image.video.extension.isSvg
import com.gallery.photo.image.video.extension.isVideoFast
import com.gallery.photo.image.video.extension.openEditorIntent
import com.gallery.photo.image.video.extension.openPath
import com.gallery.photo.image.video.extension.scanPathRecursively
import com.gallery.photo.image.video.extension.showErrorToast
import com.gallery.photo.image.video.extension.toast
import com.gallery.photo.image.video.model.AlbumData
import com.gallery.photo.image.video.model.PictureData
import com.gallery.photo.image.video.utils.AdCache
import com.gallery.photo.image.video.utils.Constant
import com.gallery.photo.image.video.utils.MAX_COLUMN_COUNT_PICTURE
import com.gallery.photo.image.video.utils.PopupWindowHelper
import com.gallery.photo.image.video.utils.Preferences
import com.gallery.photo.image.video.utils.TYPE_GIFS
import com.gallery.photo.image.video.utils.TYPE_IMAGES
import com.gallery.photo.image.video.utils.TYPE_VIDEOS

import com.gallery.photo.image.video.utils.Utils
import com.gallery.photo.image.video.utils.ensureBackgroundThread
import com.gallery.photo.image.video.utils.photoExtensions
import com.gallery.photo.image.video.utils.rawExtensions
import com.gallery.photo.image.video.utils.videoExtensions
import com.gallery.photo.image.video.viewpager.PhotoVideoActivity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import vi.imagestopdf.CreatePDFListener
import vi.imagestopdf.PDFEngine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Collections
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class ImageListActivity : BaseActivity() {

    lateinit var preferences: Preferences
    var albumData = AlbumData()
    var allList = ArrayList<PictureData>()
    var allBackList = ArrayList<PictureData>()
    var pictures = ArrayList<Any>()

    var imageListAdapter: PictureAdapter? = null
    var selectedItem = 0
    var isSearch: Boolean = false
    var isStopSearch: Boolean = false
    var isCheckSearchOn = false
    var isSelectAll = false

    private var googleMap: GoogleMap? = null
    private var photoLocation: LatLng? = null
    private var folderPath: String = ""

    private var lastLongPressedItem = -1
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var binding: ActivityImageListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this)
        }
        binding = ActivityImageListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadBanner()

//        EventBus.getDefault().register(this)
        if (intent.hasExtra("folderPath")) {
            folderPath = intent.getStringExtra("folderPath")!!
        }
        Log.e("ImageListActivity", "folderPath:$folderPath")

        if (intent.hasExtra("isFromMap")) {
            val lati = intent.getFloatExtra("lati", 0f)
            val long = intent.getFloatExtra("long", 0f)
            binding.map.onCreate(savedInstanceState)
            initMap(lati, long)
        } else {
            binding.guideline.setGuidelinePercent(0f)
        }
        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
//        EventBus.getDefault().unregister(this)
    }

    private fun intView() {

        val data = Constant.albumData
        albumData =
            AlbumData(data.title, data.pictureData, data.folderPath, data.date, data.fileSize)

        allList.clear()
        allBackList.clear()

        for (model in allList) {
            Log.e("pictureData.add.001", "intView.pictureData.add:${model.filePath}")
        }
        allList.addAll(albumData.pictureData)
        allBackList.addAll(albumData.pictureData)

        binding.txtTitle.text = albumData.title
        binding.txtPlace.text = albumData.title
        binding.txtCount.text = "${albumData.pictureData.size}"

        getData()

        binding.swipeRefreshLayout.setOnRefreshListener {
            if (binding.swipeRefreshLayout.isEnabled)
                getData()
            else
                binding.swipeRefreshLayout.isRefreshing = false
        }
        intListener()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {

            val isFirstSession = preferences.splashCounter == 1
            val adId =getString(R.string.b_imageListActivity)

            BannerAdHelper.showBanner(this,
                binding.layoutBanner.mFLAd,
                binding.layoutBottomAd,
                adId,
                AdCache.imageListAdView,
                { isLoaded, adView, message ->
                    if (!isDestroyed) {
                        mAdView = adView
                        AdCache.imageListAdView = adView
                        isAdLoaded = isLoaded
                    }
                })
        }
    }

    private fun initMap(lati: Float, long: Float) {
        binding.guideline.setGuidelinePercent(0.35f)

        photoLocation = LatLng(lati.toDouble(), long.toDouble());
        binding.map.getMapAsync { map ->
            googleMap = map

            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                googleMap?.isMyLocationEnabled = true
            }
            addMarker(lati, long)

//            map.moveCamera(CameraUpdateFactory.newLatLng(photoLocation!!))
//            val maxZoom = 17.0f
//            if (map.getCameraPosition().zoom > maxZoom) map.animateCamera(
//                CameraUpdateFactory.zoomTo(
//                    maxZoom
//                )
//            )

        }

    }


    private fun addMarker(lati: Float, long: Float) {
        val lat = lati.toDouble()
        val lng = long.toDouble()
        if (lat != null && lng != null) {
            val location = LatLng(lat, lng)

            Log.e("MapExploreActivity", "getImageOnMap:::addMarker==>lat:${lat}, lng:${lng}")

            val marker = googleMap?.addMarker(
                MarkerOptions()
                    .position(location)
                    .icon(
                        BitmapDescriptorFactory.fromBitmap(
                            getMarkerBitmapFromView(
                                albumData.pictureData.firstOrNull()!!.filePath,
                                albumData.pictureData.size
                            )
                        )
                    )
            )
            googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15f));
            googleMap?.animateCamera(CameraUpdateFactory.zoomIn());
            googleMap?.animateCamera(CameraUpdateFactory.zoomTo(15f), 800, null);
//            val maxZoom = 100.0f
//            if (googleMap?.cameraPosition!!.zoom > maxZoom) googleMap?.animateCamera(
//                CameraUpdateFactory.zoomTo(
//                    maxZoom
//                )
//            )
            marker?.tag = albumData.title

        }
    }

    private fun getMarkerBitmapFromView(photoPath: String, size: Int): Bitmap {
        val customMarkerView: View =
            (getSystemService(AppCompatActivity.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.custom_marker,
                null
            )
        val markerImageView = customMarkerView.findViewById<View>(R.id.profile_image) as ImageView
        val markerCounter = customMarkerView.findViewById<View>(R.id.txtCount) as TextView
        markerCounter.text = "$size"

        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = BitmapFactory.decodeFile(photoPath, options)
        markerImageView.setImageBitmap(bitmap)

        customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        customMarkerView.layout(
            0,
            0,
            customMarkerView.measuredWidth,
            customMarkerView.measuredHeight
        )
        customMarkerView.buildDrawingCache()
        val returnedBitmap = Bitmap.createBitmap(
            customMarkerView.measuredWidth, customMarkerView.measuredHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(returnedBitmap)
        canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN)
        val drawable = customMarkerView.background
        drawable?.draw(canvas)
        customMarkerView.draw(canvas)
        return returnedBitmap
    }

    private fun initZoomListener() {
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 2) {
                        reduceColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_PICTURE) {
                        increaseColumnCount()
//                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }

    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
        binding.pictureRecycler.setupZoomListener(zoomListener)
    }

    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {
            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {
//        pictureAdapter.getItemViewType(pos)
//        if (select && !getIsItemSelectable(pos)) {
        try {
            if (select && pictures[pos] is AlbumData) {
                return
            }

            if (pictures[pos] is PictureData) {

                if (select) {
                    (pictures[pos] as PictureData).isSelected = true
//                (pictures[pos] as PictureData).isCheckboxVisible = true
//                selectedKeys.add(itemKey)
                } else {
                    (pictures[pos] as PictureData).isSelected = false
//                (pictures[pos] as PictureData).isCheckboxVisible = false
//                selectedKeys.remove(itemKey)
                }
            }
        } catch (e: Exception) {

        }


        imageListAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.btnShare.setOnClickListener {
            shareImages()

        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }
        binding.btnHide.setOnClickListener {
            setHideData()
        }

        binding.btnMore.setOnClickListener {
//            showMoreMenu()
            showDropDown(binding.btnMore)
        }

        binding.icMenu.setOnClickListener {
            showMenu()
        }

    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid > 2) {
            preferences.setGridCount(selectedGrid - 1)
        }
        setColumnView()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_PICTURE) {
            preferences.setGridCount(selectedGrid + 1)
        }
        setColumnView()
    }


    private fun setColumnView() {
        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getGridCount()
        imageListAdapter?.apply {
            notifyItemRangeChanged(0, pictures.size)
        }
        setRvLayoutManager()
    }

    private fun showMenu() {
        val dialog = MainMenuDialog(clickListener = {
            when (it) {
                1 -> {//show sort
                    showSortDialog()
                }

                2 -> {//show group
                    showGroupByDialog()
                }

                3 -> {//show filter
                    val filterMediaDialog = FilterMediaDialog(updateListener = {
                        getData()
                    })
                    filterMediaDialog.show(supportFragmentManager, filterMediaDialog.tag)
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        updateListener = {
                            setRvLayoutManager()
//                            photosFragment.setRvLayoutManager()
//                            albumFragment.setRvLayoutManager()
                        })
                    displayColumnsDialog.show(supportFragmentManager, displayColumnsDialog.tag)
                }

                5 -> {
                    startActivity(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }
            }
        })
        dialog.show(supportFragmentManager, dialog.tag)

    }

    private fun showSortDialog() {
        val sortDialog = SortDialog( updateListener = {
            getData()
//            photosFragment.setFilterData()
//            albumFragment.setFilterData()
        })
        sortDialog.show(supportFragmentManager, sortDialog.tag)
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(updateListener = {
            getData()
//            photosFragment.setList()
//            albumFragment.setFilterData()
        })
        groupDialog.show(supportFragmentManager, groupDialog.tag)
    }

    lateinit var popupWindow: PopupWindow

    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow =
            com.gallery.photo.image.video.utils.PopupWindowHelper(popUpBinding.root)

        var needToAddFav = false
        var needToRemoveFav = false
        var isVideoSelected = false

        for (i in pictures.indices) {
            if (pictures[i] is PictureData) {
                val model: PictureData = pictures[i] as PictureData
                if (model.isSelected) {
                    if (model.isVideo || model.filePath.isGif()) isVideoSelected = true

                    if (model.isFavorite)
                        needToRemoveFav = true
                    else
                        needToAddFav = true
                }
            }
        }

        popUpBinding.menuEdit.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuPdf.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuSetAs.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuResize.beVisibleIf(selectedItem == 1 && !isVideoSelected)
        popUpBinding.menuRename.beVisibleIf(selectedItem == 1)
        popUpBinding.menuInfo.beVisibleIf(selectedItem == 1)
        popUpBinding.menuAddFavourite.beVisibleIf(needToAddFav)
        popUpBinding.menuRemoveFavourite.beVisibleIf(needToRemoveFav)

        popUpBinding.menuCover.beGone()
        popUpBinding.menuExclude.beGone()

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }
        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
//            if (selectedItem > 1) {
//                showBatchRenameDialog()
//            } else
                showRenameDialog()
        }
        popUpBinding.menuSetAs.setOnClickListener {
            popupWindow.dismiss()
            setAs()
        }
        popUpBinding.menuResize.setOnClickListener {
            popupWindow.dismiss()
            showResizeDialog()
        }
        popUpBinding.menuAddFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(true)
        }

        popUpBinding.menuRemoveFavourite.setOnClickListener {
            popupWindow.dismiss()
            setFavorite(false)
        }
        popUpBinding.menuEdit.setOnClickListener {
            popupWindow.dismiss()
            val selectImage: ArrayList<PictureData> = ArrayList()
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }
            val pictureData = selectImage[0]
            openEditor(pictureData.filePath)

        }
        popUpBinding.menuPdf.setOnClickListener {
            popupWindow.dismiss()
            pdfImages()
        }
        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
//            showAddAlbumDialog(Constant.albumList, true)
            showAddAlbumDialog(Constant.deviceAlbumList, true)
            popupWindow.dismiss()
        }
        popUpBinding.menuMove.setOnClickListener {
//            showAddAlbumDialog(Constant.albumList, false)
            showAddAlbumDialog(Constant.deviceAlbumList, false)
            popupWindow.dismiss()
        }
        popupWindow.showAsPopUp(view)
    }

    fun pdfImages() {
        if (selectedItem == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {

                val uris = ArrayList<File>()
                for (i in pictures.indices) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            uris.add(File(model.filePath))
                        }
                    }
                }
                runOnUiThread {
                    var filename = System.currentTimeMillis().toString()
                    val quality = 80
                    PDFEngine.getInstance().createPDF(this, uris, object : CreatePDFListener {
                        override fun onPDFGenerated(pdfFile: File?, numOfImages: Int) {

                            if (pdfFile != null) {
                                if (pdfFile.exists()) {
                                    try {
                                        MediaScannerConnection.scanFile(
                                            this@ImageListActivity, arrayOf(pdfFile.absolutePath),
                                            null, null
                                        )
                                    } catch (e: Exception) {
                                    }
                                    Log.d("TAG", "onPDFGenerated:  Pdf file -->" + pdfFile!!.absolutePath)
                                    Log.d("TAG", "onPDFGenerated:  numberofPages -->" + numOfImages)
                                    toast("Your pdf is saved at ${pdfFile.absolutePath}")
                                    openPath(pdfFile.absolutePath, true)
                                }
                            }
                        }
                    }, filename, false, quality, true)
//                    Utils.shareFilesList(mActivity!!, uris)
                }
            }
        }
        //        (activity as BaseActivity).showProgress(activity.getString(R.string.please_wait))

    }

    fun showDetailsDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val detailsDialog = DetailsDialog(pictureData, false)
        detailsDialog.show(supportFragmentManager, detailsDialog.tag)
    }

    fun openEditor(path: String) {
        val newPath = path.removePrefix("file://")
        openEditorIntent(newPath)
    }

    fun setAs() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        ensureBackgroundThread {
            val newUri =
                getFinalUriFromPath(pictureData.filePath, BuildConfig.APPLICATION_ID)
                    ?: return@ensureBackgroundThread
            Intent().apply {
                action = Intent.ACTION_ATTACH_DATA
                setDataAndType(newUri, getUriMimeType(pictureData.filePath, newUri))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(this, getString(R.string.set_as))

                try {
                    startActivityForResult(chooser, 101)
                } catch (e: ActivityNotFoundException) {
                    toast(R.string.no_app_found)
                } catch (e: Exception) {
                    showErrorToast(e)
                }
            }
        }

    }

    fun showResizeDialog() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }
        val pictureData = selectImage[0]

        val resizeDialog =
            ResizeDialog(
                this,
                pictureData,
                updateImageListener = { path ->
                    val file = File(path)
                    pictures.add(
                        0,
                        PictureData(
                            path,
                            file.name,
                            file.parentFile.path,
                            file.lastModified(),
                            file.lastModified(),
                            file.length()
                        )
                    )
                    setCloseToolbar()

                })
        resizeDialog.show(supportFragmentManager, resizeDialog.tag)
    }

    fun setFavorite(isFavorite: Boolean) {

        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        for (i in pictures.indices) {
            if (pictures[i] is PictureData) {
                val model: PictureData = pictures[i] as PictureData
//                (pictures[i] as PictureData).isFavorite=isFavorite
                if (model.isSelected) {
                    if (isFavorite) {
                        if (!favList.contains(model.filePath))
                            favList.add(model.filePath)
                    } else {
                        if (favList.contains(model.filePath))
                            favList.remove(model.filePath)
                    }
                }
            }
        }
        preferences.setFavoriteList(favList)
        preferences.refreshMedia = true
//        refreshData(allList)
        setCloseToolbar()
        refreshData()
//        pictures.removeAll(allList.toSet())
//        getData()
//        setList()
    }

//    fun showBatchRenameDialog() {
//
//        val selectImage: ArrayList<PictureData> = ArrayList()
//        for (i in pictures.indices) {
//            if (pictures[i] != null)
//                if (pictures[i] is PictureData) {
//                    val model: PictureData = pictures[i] as PictureData
//                    if (model.isSelected) {
//                        selectImage.add(model)
//                    }
//                }
//        }
//
//        val albumData = selectImage.filter { it.isSelected }
//        val paths: ArrayList<String> = ArrayList()
//        paths.addAll(albumData.map { it.filePath })
//
//        val renameDialog =
//            BatchFolderRenameDialog(
//                this,
//                true,
//                paths,
//                updateImageListener = {
//                    preferences.scanMedia = true
//                    preferences.refreshMedia = true
//                    setCloseToolbar()
//                })
//        renameDialog.show(supportFragmentManager, renameDialog.tag)
//    }

    fun showRenameDialog() {

        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        val pictureData = selectImage.get(0)

        val renameDialog =
            RenameDialog(
                this,
                pictureData,
                positiveBtnClickListener = { renamePath, oldPath ->
                    notifyAdapter()
                })
        renameDialog.show(supportFragmentManager, renameDialog.tag)
    }

    private fun setData() {
        enableScroll()
        binding.swipeRefreshLayout.isRefreshing = false
        if (imageListAdapter != null) notifyAdapter() else initAdapter()
//        RxBus.getInstance().post(CountShowEvent())
        setEmptyData()
    }

    private fun setEmptyData() {
        if (pictures != null && pictures.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottomAd.beVisible()
//            loadBanner()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottomAd.beGone()
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()
//        val gridLayoutManager = GridLayoutManager(this, gridCount, RecyclerView.VERTICAL, false)
        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = gridCount
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                if (position >= 0 && position < pictures.size) {
                    return if (imageListAdapter!!.getItemViewType(position) == imageListAdapter!!.ITEM_HEADER_TYPE) {
                        gridCount
                    } else 1
                } else {
                    return 1
                }
            }
        }

    }

    private fun initAdapter() {
        setRvLayoutManager()
        imageListAdapter = PictureAdapter(this, pictures, clickListener = {
            if (pictures[it] is PictureData) {
                val pictureData = pictures[it] as PictureData
                if (pictureData.isCheckboxVisible && !isCheckSearchOn) {
                    pictureData.isSelected = !pictureData.isSelected
                    imageListAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    val dataList = ArrayList<PictureData>()
                    var displayPos = 0
                    for (i in pictures.indices) {
                        if (pictures[i] is PictureData) {
                            dataList.add(pictures[i] as PictureData)
                            if (it == i) {
                                displayPos = dataList.size - 1
                            }
                        }
                    }
                    Constant.displayImageList = ArrayList()
                    Constant.displayImageList.addAll(dataList)
                    Constant.selectedPosition = displayPos
                    if (Constant.displayImageList.size > 0) {
                        val intent = Intent(this, PhotoVideoActivity::class.java)
                        intent.putExtra(Constant.EXTRA_DISPLAY_POS, displayPos)
//                    startActivity(intent)
                        photoVideoLauncher.launch(intent)
                    }
                }
            }
        }, longClickListener = {

            lastLongPressedItem = it
            binding.pictureRecycler.setDragSelectActive(it)
            lastLongPressedItem = if (lastLongPressedItem == -1) {
                it
            } else {
                val min = min(lastLongPressedItem, it)
                val max = max(lastLongPressedItem, it)
                for (i in min..max) {
                    toggleItemSelection(true, i, false)
                }
//                    updateTitle()
                it
            }

            if (!isCheckSearchOn) {
                if (pictures[it] is PictureData) {
                    val pictureData = pictures[it] as PictureData
                    for (i in pictures.indices) {
                        if (pictures[i] != null)
                            if (pictures[i] is AlbumData) {
                                val model = pictures[i] as AlbumData
                                model.isCheckboxVisible = true
                            } else if (pictures[i] is PictureData) {
                                val model = pictures[i] as PictureData
                                model.isCheckboxVisible = true
                            }
                    }
                    pictureData.isCheckboxVisible = true
                    pictureData.isSelected = true
                    notifyAdapter()
                    setSelectedFile()
                }
            }
        }, headerSelectListener = {
            if (pictures[it] is AlbumData) {
                val albumData = pictures[it] as AlbumData
                val isSelectAll = !albumData.isSelected
                albumData.isSelected = isSelectAll
                var pos = it + 1
                while (pos < pictures.size) {
                    if (pictures[pos] is PictureData) {
                        val model = pictures[pos] as PictureData
                        model.isSelected = isSelectAll
                        pos++
                    } else if (pictures[pos] is AlbumData) {
                        break
                    }
                }
                notifyAdapter()
                setSelectedFile()
            }
        })

        binding.pictureRecycler.adapter = imageListAdapter
//        val primaryColor = resources.getColor(R.color.color_primary)
//        binding.imageListFastscroller.updateColors(primaryColor)


        initZoomListener()
        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)

    }


    var photoVideoLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (preferences.refreshMedia) {
                try {
                    scanPathRecursively(folderPath) {
                    }
                } catch (e: Exception) {
                }
//                selectedItem = 0
//                notifyAdapter()
//                binding.swipeRefreshLayout.isEnabled = true
//                longClickListener(false, 0, false)
//                setEmptyData()
                refreshData()
//                refreshData(allList)
            }
        }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0

        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                if (i != currentHeaderPos) {
                    if (currentHeaderPos != -1) {
                        val model = pictures[currentHeaderPos] as AlbumData
                        model.isSelected = photosCount == photosSelectCount
                        photosCount = 0
                        photosSelectCount = 0
                        imageListAdapter?.notifyItemChanged(currentHeaderPos)
                    }
                    currentHeaderPos = i
                }
            } else if (pictures[i] is PictureData) {
                val model = pictures[i] as PictureData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
            if (i == pictures.size - 1) {
                if (currentHeaderPos != -1) {
                    val model = pictures[currentHeaderPos] as AlbumData
                    model.isSelected = photosCount == photosSelectCount
                    photosCount = 0
                    photosSelectCount = 0
                    imageListAdapter?.notifyItemChanged(currentHeaderPos)
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.imageListFastscroller.isEnabled=false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    override fun onBackPressed() {
        if (isOpenMenu())
            popupWindow.dismiss()
        else if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else
            if (preferences.isNeedInterAd) {
                AdsConfig.showInterstitialAd(this) {
                    if (it) preferences.isNeedInterAd = false
                    finish()
                }
            } else {
                finish()
            }
    }

    private fun isOpenMenu(): Boolean {
        if (::popupWindow.isInitialized) {
            return popupWindow.isShowing
        }
        return false
    }

    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
//        binding.swipeRefreshLayout.isEnabled = !isShowSelection
//        binding.imageListFastscroller.isEnabled = isShowSelection

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE
        isSelectAll = isAllSelect
        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE
        binding.groupToolbarHeader.visibility = if (isShowSelection) View.GONE else View.VISIBLE

        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
//        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = (isShowSelection && selectedItem != 0)

        setSelectAllColor()
    }

    private fun setSelectAllColor() {
        val color =
            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                    }
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isSelected = isSelectAll
                    if (isSelectAll)
                        selected++

                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    private fun setClose() {
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is AlbumData) {
                    val model = pictures[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                } else if (pictures[i] is PictureData) {
                    val model = pictures[i] as PictureData
                    model.isCheckboxVisible = false
                    model.isSelected = false
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
    }

    fun shareImages() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            ensureBackgroundThread {
                val uris = ArrayList<Uri>()
                for (i in pictures.indices) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            val uri = FileProvider.getUriForFile(
                                this,
                                this.packageName + ".provider",
                                File(model.filePath)
                            )
                            uris.add(uri)
                        }
                    }
                }
                runOnUiThread {
                    Utils.shareFilesList(this, uris)
                }
            }
        }
    }

    fun setHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                this,
                this.getString(R.string.PleaseSelectImage),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val hideDialog = ConfirmationDialog(
                this,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show(supportFragmentManager, hideDialog.tag)
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {

            toast(getString(R.string.PleaseSelectImage))
        } else {
            val deleteDialog = DeleteDialog(
                this,
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show(supportFragmentManager, deleteDialog.tag)
        }
    }

    fun showAddAlbumDialog(albumList: ArrayList<AlbumData>, isCopy: Boolean) {
        if (selectedItem == 0) {
            toast(getString(R.string.PleaseSelectImage))
        } else {
            val selectImage: ArrayList<PictureData> = ArrayList()
            val selectedAlbum: ArrayList<AlbumData> = ArrayList()

            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model: PictureData = pictures[i] as PictureData
                        if (model.isSelected) {
                            selectImage.add(model)
                        }
                    }
            }

            val addAlbumDialog =
                SelectAlbumDialog(
                    this,
                    albumList,
                    selectedAlbum,
                    isCopy,
                    selectPathListener = { selectPath ->
                        setCopyMove(isCopy, selectPath, selectImage)
                    },
                    createAlbumListener = {
                        val createDialog = CreateAlbumDialog(this, createPathListener = {
                            setCopyMove(isCopy, it, selectImage)
                        })
                        createDialog.show(supportFragmentManager, createDialog.tag)
                    })
            addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
        }
    }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<PictureData>
    ) {
        Log.e("ImageListActivity", "setCopyMove.selectPath:$selectPath")
        if (isCopy)
            Utils.copyFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    setList()
                    longClickListener(false, 0, false)
                    setClose()

                })
        else
            Utils.moveFiles(
                this,
                selectPath,
                selectImage,
                selectImage.size,
                copyListener = {
                    toast(getString(R.string.move_successfully))
                    refreshData()
                    selectedItem = 0
                    preferences.refreshMedia = true
                    preferences.scanMedia = true
                    setList()
                    longClickListener(false, 0, false)
                    setClose()
                })

//        if(pictures.size == 0) {
//            finish()
//        }
    }

    //    private fun refreshData(selectImage: java.util.ArrayList<PictureData>) {
    private fun refreshData() {
//        pictures.removeAll(selectImage.toSet())
        pictures.clear()
        if (folderPath.isNotEmpty()) {

            allList.clear()
            allBackList.clear()

            disableScroll()
            binding.swipeRefreshLayout.isRefreshing = true
            Observable.fromCallable<Boolean> {
                Log.e("ImageListActivity", "getData.folderPath:$folderPath")
                if (folderPath.isNotEmpty()) getImages()
                setFilter()
                true
            }.subscribeOn(Schedulers.io())
                .doOnError { _: Throwable? ->
                    runOnUiThread { setData() }
                }
                .subscribe { _: Boolean? ->
                    runOnUiThread { setData() }
                }
        } else {
            getData()
        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<PictureData> = ArrayList()
        for (i in pictures.indices) {
            if (pictures[i] != null)
                if (pictures[i] is PictureData) {
                    val model: PictureData = pictures[i] as PictureData
                    if (model.isSelected) {
                        selectImage.add(model)
                    }
                }
        }

        Utils.hideFiles(this, selectImage, selectedItem, hideListener = {
            toast(getString(R.string.hide_successfully))
            selectedItem = 0
            longClickListener(false, 0, false)
            setClose()
//            refreshData(selectImage)
            refreshData()
        })
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.isCancelable = false
        progressDialog.show(supportFragmentManager, progressDialog.tag)

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            for (i in pictures.indices) {
                if (pictures[i] != null)
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
//                            runOnUiThread {
//                                bindingDialog.txtTitle.text = model.fileName
//                            }

//                            dataBase.dataDao().getLocationEntity(model.filePath)
                            val entity = dataBase.dataDao().getLocationEntity(model.filePath)
                            if (entity != null) {
                                dataBase.dataDao().deleteLocationEntity(entity)
                            }

                            val isDelete =
                                Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                            if (isDelete) {
                                deleteList.add(model.filePath)
                                runOnUiThread {
                                    progressDialog.setProgress(deleteList.size, selectedItem)
//                                    bindingDialog.txtProgressCount.text =
//                                        deleteList.size.toString() + "/" + selectedItem
//                                    bindingDialog.progressBar.progress = deleteList.size
                                }
                            }
                        } else {
                            model.isCheckboxVisible = false
                        }
                    } else if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
            }

            var i = 0
            while (i < pictures.size) {
                if (pictures[i] != null)
                    if (pictures[i] is AlbumData) {
                        val model = pictures[i] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                i++
            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread {
//                    if (dialog.isShowing)
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()

        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
//        if(pictures.size == 0) {
//            finish()
//        }
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in filterList) {
//                    if (pictureData.getFilePath().equalsIgnoreCase(path)) {
//                        filterList.remove(pictureData)
//                        break
//                    }
//                }
//            }
            for (path in deleteList) {
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }
            for (path in deleteList) {
                for (pictureData in allBackList) {
                    if (pictureData.filePath == path) {
                        allBackList.remove(pictureData)
                        break
                    }
                }
            }
        }
    }

    private fun getData() {
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        for (i in allList.indices) {
            allList[i].isFavorite = favList.contains(allList[i].filePath)
        }
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        Observable.fromCallable<Boolean> {
            Log.e("ImageListActivity", "getData.folderPath:$folderPath")
            setFilter()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread { setData() }
            }
            .subscribe { _: Boolean? ->
                runOnUiThread { setData() }
            }
    }


    private fun getImages() {
        Log.e("contentResolver.001", "getImages")
        val mCursor: Cursor?
        val folderList: MutableList<String> = ArrayList<String>()
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())

        try {
            val BUCKET_DISPLAY_NAME: String
            BUCKET_DISPLAY_NAME = MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
            val projection = arrayOf(
                MediaStore.Images.Media.DATA,
                BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
            )

            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

//            val selection = MediaStore.Images.Media.DATA + " like ?"
//            val selectionArgs = arrayOf(folderPath + "%")

            val filterMedia = preferences?.getFilterMedia()!!
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            mCursor = contentResolver.query(
                uri,  // Uri
                projection,  // Projection
                selection,
                selectionArgs,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )
            if (mCursor != null) {
//                Log.e("contentResolver.001", "getImages.mCursor.count::${mCursor.count}")
                mCursor.moveToFirst()
                val photoDataArrayList: ArrayList<PictureData> = ArrayList<PictureData>()
                mCursor.moveToFirst()
                while (!mCursor.isAfterLast) {
                    //2sec
                    val path =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                    val title =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                    var bucketPath = ""
                    bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                    var bucketName =
                        mCursor.getString(mCursor.getColumnIndexOrThrow(BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    Log.e(
                        "pictureData.add.001",
                        "getImages.bucketName:$bucketName, folderPath:$folderPath"
                    )

                    if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {

                        val fileSizeLength =
                            mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))

                        if (!folderList.contains(bucketPath) && !bucketName.isNullOrEmpty()) {
                            var d =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED))
                            d *= 1000
                            var dt =
                                mCursor.getLong(mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))
                            dt *= 1000
                            if (dt == 0L)
                                dt = d
                            val pictureData =
                                PictureData(path, title, bucketName, d, dt, fileSizeLength, false)
                            pictureData.isFavorite = favList.contains(path)
                            Log.e(
                                "pictureData.add.001",
                                "getImages.pictureData.add:$bucketName, $path"
                            )
                            allList.add(pictureData)
                            allBackList.add(pictureData)
                        }

//                        imageCount++
                    }
                    mCursor.moveToNext()
                }
                mCursor.close()
            } else Log.e("contentResolver.001", "getImages.mCursor.null::")
        } catch (e: Exception) {
            Log.e("contentResolver.001", "getImages.Exception::$e")
            Log.e("printStackTrace","printStackTrace:$e")
        }
        getVideos()
    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

//        if (filterMedia and TYPE_RAWS != 0) {
//            rawExtensions.forEach {
//                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            }
//        }

//        if (filterMedia and TYPE_SVGS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }
//        if (filterMedia and TYPE_PORTRAITS != 0) {
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
//        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }


        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }


        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add(folderPath + "%$it")
            }
            args.add(folderPath + "%.jpg")
            args.add(folderPath + "%.jpeg")
            rawExtensions.forEach {
                args.add(folderPath + "%$it")
            }
            args.add(folderPath + "%.svg")
        }


        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add(folderPath + "%$it")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            args.add(folderPath + "%.gif")
        }

        return args
    }

    private fun getVideos() {
        Log.e("contentResolver.001", "getVideos")
        var title: String
        var path: String
        val duration: Int

        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI


        val projection = arrayOf(
            MediaStore.Video.VideoColumns.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.VideoColumns.SIZE,
            MediaStore.Video.VideoColumns.DURATION,
            MediaStore.Video.VideoColumns.DATE_MODIFIED,
            MediaStore.Video.VideoColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
        )

        val folderList: MutableList<String> = ArrayList<String>()
        val favList: ArrayList<String> = ArrayList()
        favList.addAll(preferences.getFavoriteList())
        try {

//            val selection = MediaStore.Video.Media.DATA + " like ?"
//            val selectionArgs = arrayOf(folderPath + "%")

            val filterMedia = preferences.getFilterMedia()
            val selection = getSelectionQuery(filterMedia)
            val selectionArgs = getSelectionArgsQuery(filterMedia).toTypedArray()

            val cursor = contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
            )
//            val cursor = activity.contentResolver.query(
//                uri,
//                projection,
//                selection,
//                selectionArgs,
//                MediaStore.Video.VideoColumns.DATE_MODIFIED + " DESC"
//            )

            if (cursor != null) {
//                Log.e("contentResolver.001", "getVideos.mCursor.count::${cursor.count}")
                duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION)
                cursor.moveToFirst()
                while (!cursor.isAfterLast) {
                    path =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                    title =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                    var bucketName =
                        cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME))
                    if (bucketName == null) bucketName = path.getParentFolder()

                    Log.e(
                        "pictureData.add.001",
                        "getImages.bucketName:$bucketName, folderPath:$folderPath"
                    )
                    if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {

                        var bucketPath = ""
                        bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
                        if (!folderList.contains(bucketPath)) {
                            var d =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED))
                            d *= 1000
                            val fileSizeLength =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                            var dt =
                                cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN))

                            dt *= 1000
                            if (dt == 0L)
                                dt = d
//                        Log.e("contentResolver.001", "getVideos path:$path, title:$title, bucketName:$bucketName, d:$d, dt:$dt, fileSizeLength:$fileSizeLength, duration:$duration")
                            val pictureData = PictureData(
                                path,
                                title,
                                bucketName,
                                d,
                                dt,
                                fileSizeLength,
                                true,
                                cursor.getLong(duration)
                            )
                            pictureData.isFavorite = favList.contains(path)
                            pictureData.isVideo = true
                            Log.e(
                                "pictureData.add.001",
                                "getVideos.pictureData.add:$bucketName, $path"
                            )
                            allList.add(pictureData)
                            allBackList.add(pictureData)
                        }

//                        videoCount++
                    }
                    cursor.moveToNext()
                }
                cursor.close()
            } else
                Log.e("contentResolver.001", "getVideos.mCursor.null::")
        } catch (exp: java.lang.Exception) {
            Log.e("contentResolver.001", "Exception.getVideos::$exp")
            exp.printStackTrace()
        }
    }

    private fun setFilter() {
        Log.e("ImageListActivity", "imageVideo size==>> " + allList.size)
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        Collections.sort(allList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })
        Collections.sort(allBackList, Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileName.compareTo(p2.fileName, true)
                else
                    p2.fileName.compareTo(p1.fileName, true)
            } else if (sortType == Constant.SORT_PATH) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.filePath.compareTo(p2.filePath, true)
                else
                    p2.filePath.compareTo(p1.filePath, true)
            } else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_LAST_MODIFIED) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            } else if (sortType == Constant.SORT_DATE_TAKEN) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.dateTaken.compareTo(p2.dateTaken)
                else
                    p2.dateTaken.compareTo(p1.dateTaken)
            } else
                p2.date.compareTo(p1.date)
        })

        if (!isStopSearch)
            setList()
    }

    private fun notifyAdapter() {
        if (imageListAdapter != null) {
            binding.pictureRecycler.post {
                imageListAdapter?.notifyDataSetChanged()
            }
//            imageListAdapter?.notifyDataSetChanged()
        }
    }

    private fun setList() {
        try {
            pictures.clear()
            val favList = preferences.getFavoriteList()
            notifyAdapter()

            if (isSearch)
                runOnUiThread { notifyAdapter() }

            val dateWisePictures = LinkedHashMap<String, ArrayList<PictureData>>()
            var format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
//        var format = preferences.dateFormat

//        val currentGrouping = context.config.getFolderGrouping(pathToCheck)
            val currentGrouping = preferences.getGroupBy()
            val groupOrder = preferences.getGroupOrderBy()

            format = when (currentGrouping) {
                Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
                    SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
                }

                Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
                    SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
                }

                Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
                Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
                else -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            }

            if (allList.size != 0) {
                for (pictureData in allList) {
                    val strDate = format.format(pictureData.date)
                    var strKey = format.format(pictureData.date)

                    when (currentGrouping) {
                        Constant.GROUP_BY_NONE -> strKey = ""
                        Constant.GROUP_BY_LAST_MODIFIED_DAILY -> {
                            strKey = format.format(getDayStartTS(pictureData.date, false))
                        }

                        Constant.GROUP_BY_DATE_TAKEN_DAILY -> {
                            strKey = format.format(getDayStartTS(pictureData.dateTaken, false))
                        }

                        Constant.GROUP_BY_LAST_MODIFIED_MONTHLY -> {
                            strKey = format.format(getDayStartTS(pictureData.date, true))
                        }

                        Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> {
                            strKey = format.format(getDayStartTS(pictureData.dateTaken, true))
                        }

                        Constant.GROUP_BY_EXTENSION -> {
                            strKey = pictureData.fileName.getFilenameExtension()
                                .lowercase(Locale.getDefault())

                        }

                        Constant.GROUP_BY_FOLDER -> {
                            strKey =
                                pictureData.filePath.getParentFolder().lowercase(Locale.getDefault())
                        }

                        Constant.GROUP_BY_FILE_TYPE -> {
                            strKey = getFileTypeString(
                                pictureData.fileName
                            )
                        }

                        else -> {
                            strKey = format.format(getDayStartTS(pictureData.dateTaken, false))
                        }
                    }

                    if (isStopSearch) {
                        break
                    } else {

                        var imagesData1: ArrayList<PictureData> = ArrayList()
                        if (strKey.isNotEmpty() && dateWisePictures.containsKey(strKey)) {
                            val list: ArrayList<PictureData>? = dateWisePictures[strKey]
                            if (!list.isNullOrEmpty())
                                imagesData1.addAll(list)
                        } else {
                            imagesData1 = ArrayList()
                        }
                        imagesData1.add(pictureData)
                        if (strKey.isNotEmpty()) dateWisePictures[strKey] = imagesData1

                    }
                }

                val keys: Set<String> = dateWisePictures.keys
                val listKeys = ArrayList(keys)

                if (groupOrder == Constant.ORDER_DESCENDING) {
                    listKeys.reverse()
                }

                for (i in listKeys.indices) {
                    if (isStopSearch) {
                        break
                    } else {
                        val imagesData = dateWisePictures[listKeys[i]]
                        if (imagesData != null && imagesData.size != 0) {
                            val bucketData = AlbumData(listKeys[i], imagesData)
                            pictures.add(bucketData)
                            pictures.addAll(imagesData)
                        }
                    }
                }
                for (i in pictures.indices) {
                    val model = pictures[i]
                    if (model is PictureData) {
                        if (favList.contains((pictures[i] as PictureData).filePath)) {
                            (pictures[i] as PictureData).isFavorite = true
                        } else {
                            (pictures[i] as PictureData).isFavorite = false
                        }
                    }
                }

            }
        } catch (e:Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }


    private fun getFileTypeString(fileName: String): String {
        Log.e("getFileTypeString", "getFileTypeString.001:$fileName")
        var stringId = R.string.images
        if (fileName.isImageFast() || fileName.isApng() || fileName.isPng()) stringId =
            R.string.images
        else if (fileName.isVideoFast()) stringId = R.string.videos
        else if (fileName.isPortrait()) stringId = R.string.portraits
        else if (fileName.isSvg()) stringId = R.string.svgs
        else if (fileName.isGif()) stringId = R.string.gifs

        return getString(stringId)
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onUpdateFavoriteEvent(event: UpdateFavoriteEvent) {
        updateFavoriteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onCopyMoveEvent(event: CopyMoveEvent) {
        copyMoveEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRenameEvent(event: RenameEvent) {
        renameEvent(event)
    }

    private fun updateFavoriteEvent(event: UpdateFavoriteEvent) {

        if (event.path.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val pictureData: PictureData = picture as PictureData
                        if (pictureData.filePath == event.path) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (pictureData in allList) {
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
            if (allBackList.isNotEmpty())
                for (pictureData in allBackList) {
                    if (pictureData.filePath == event.path) {
                        pictureData.isFavorite = event.isFavorite
                        break
                    }
                }
        }
        if (event.unFavoriteList.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (favPath in event.unFavoriteList) {
                    for (picture in pictures) {
                        if (picture is PictureData) {
                            val pictureData: PictureData = picture as PictureData
                            if (pictureData.filePath == favPath) {
                                pictureData.isFavorite = event.isFavorite
                                break
                            }
                        }
                    }
                }
                notifyAdapter()
            }
            if (allList.isNotEmpty())
                for (favPath in event.unFavoriteList) {
                    for (pictureData in allList) {
                        if (pictureData.filePath == favPath) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }

            if (allBackList.isNotEmpty())
                for (favPath in event.unFavoriteList) {
                    for (pictureData in allBackList) {
                        if (pictureData.filePath == favPath) {
                            pictureData.isFavorite = event.isFavorite
                            break
                        }
                    }
                }
        }

    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun renameEvent(event: RenameEvent) {
        if (event.oldPath.isNotEmpty() && event.renamePath.isNotEmpty()) {
            if (pictures.isNotEmpty()) {
                for (picture in pictures) {
                    if (picture is PictureData) {
                        val model = pictures as PictureData
                        if (model.filePath == event.oldPath) {
                            model.filePath = event.renamePath
                            model.fileName = File(event.renamePath).name
                            model.fileSize = File(event.renamePath).length()
                            break
                        }
                    }
                }
            }
            imageListAdapter?.notifyDataSetChanged()

            if (allBackList.isNotEmpty()) {
                for (pictureData in allBackList) {
                    if (pictureData.filePath == event.oldPath) {
                        pictureData.filePath = event.renamePath
                        pictureData.fileName = File(event.renamePath).name
                        pictureData.fileSize = File(event.renamePath).length()
                        break
                    }
                }

                for (pictureData in allList) {
                    if (pictureData.filePath == event.oldPath) {
                        pictureData.filePath = event.renamePath
                        pictureData.fileName = File(event.renamePath).name
                        pictureData.fileSize = File(event.renamePath).length()
                        break
                    }
                }

            }
        }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                val list: ArrayList<String> = ArrayList()
                val imageList: ArrayList<String> = ArrayList()
                val favList = preferences.getFavoriteList()

                for (restoreData in event.restoreList) {
                    list.add(restoreData.deletedPath)
                    imageList.add(restoreData.path)
                }

                updateDeleteImageData(list)
                deleteMainList(list)

                var isAddData = false
                for (i in imageList.indices) {
                    val file1 = File(imageList[i])
                    if (file1.exists()) {
                        if (albumData.folderPath == file1.parentFile.path) {
                            val pictureData = PictureData(
                                file1.path,
                                file1.name,
                                file1.parentFile.name,
                                file1.lastModified(),
                                file1.lastModified(),
                                file1.length()
                            )
                            pictureData.isFavorite = favList.contains(file1.path)
                            if (Utils.isVideoFile(file1.path)) {
                                pictureData.isVideo = true
                            }
                            isAddData = true
                            allList.add(pictureData)
                            allBackList.add(pictureData)
                        }
                    }
                }
                if (isAddData)
                    setFilterData()
            }
    }

    private fun copyMoveEvent(event: CopyMoveEvent) {
        if (event.copyMoveList.isNotEmpty()) {
            val imageList: ArrayList<String> = ArrayList()
            imageList.addAll(event.copyMoveList)

            val favList = preferences.getFavoriteList()

            if (event.deleteList.isNotEmpty())
                if (pictures.isNotEmpty()) {
                    deleteMainList(event.deleteList)
                }

            if (albumData.folderPath == event.albumPath) {
                val file = File(event.albumPath)
                if (file.exists()) {
                    for (i in imageList.indices) {
                        val file1 = File(imageList[i])
                        if (file1.exists()) {
                            val pictureData = PictureData(
                                file1.path,
                                file1.name,
                                file1.parentFile.name,
                                file1.lastModified(),
                                file1.lastModified(),
                                file1.length()
                            )
                            pictureData.isFavorite = favList.contains(file1.path)
                            if (Utils.isVideoFile(file1.path)) {
                                pictureData.isVideo = true
                            }
                            allList.add(pictureData)
                            allBackList.add(pictureData)
                        }
                    }
                    setFilterData()
                }
            } else {
                updateDeleteImageData(event.deleteList)
            }
        }
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is PictureData) {
                        val model = pictures[i] as PictureData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }

    fun setFilterData() {
        disableScroll()
        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
            setFilter()

            runOnUiThread {
                setData()
            }
        }
//        Observable.fromCallable<Boolean> {
//            setFilter()
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                runOnUiThread { setData() }
//            }
//            .subscribe { _: Boolean? ->
//                runOnUiThread { setData() }
//            }
    }

}