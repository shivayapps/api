package com.gallery.photo.image.video.interfaces;

public interface hidedone {
        void hideComplete();
    }