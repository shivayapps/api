plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    id("com.google.devtools.ksp")
    id("kotlin-parcelize")
}

android {
    namespace = "com.shivayapps.tictactoe"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.shivayapps.tictactoe"
        minSdk = 21
        targetSdk = 34
        versionCode = 22
        versionName = "2.2"

        multiDexEnabled = true
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("app/com.shivayapps.tictactoe.jks")
            storePassword = "com.shivayapps.tictactoe"
            keyAlias = "com.shivayapps.tictactoe"
            keyPassword = "com.shivayapps.tictactoe"
        }
    }
    buildTypes {
        debug {
            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "ads_open", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "home_banner", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "chart_banner", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "ads_inter", "ca-app-pub-3940256099942544/1033173712")

            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            resValue("string", "ads_application_id", "ca-app-pub-2750800778809761~2013256725")
            resValue("string", "ads_open", "ca-app-pub-2750800778809761/7987184736")
            resValue("string", "home_banner", "ca-app-pub-2750800778809761/9216801073")
            resValue("string", "chart_banner", "ca-app-pub-2750800778809761/9300266403")
            resValue("string", "ads_inter", "ca-app-pub-2750800778809761/1033173712")

            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        viewBinding = true
//        dataBinding = true
    }

}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

//    implementation("com.android.support:multidex:2.0.1")
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("com.intuit.sdp:sdp-android:1.1.0")

    //Room
    ksp(libs.room.compiler)
    implementation(libs.room.runtime)
    implementation(libs.room.paging)
    implementation(libs.room.ktx)

    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.8.0")

    implementation("com.android.billingclient:billing:7.1.1")

    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.google.android.gms:play-services-ads:23.0.0")

//    implementation(project(":ads"))
    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:2.6.1")

}