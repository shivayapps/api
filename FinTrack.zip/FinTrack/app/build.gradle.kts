plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    id("com.google.devtools.ksp")
    id("kotlin-parcelize")
}

android {
    namespace = "com.shivayapps.tictactoe"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.shivayapps.tictactoe"
        minSdk = 21
        targetSdk = 34
        versionCode = 18
        versionName = "1.8"

        multiDexEnabled = true
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    }

    buildTypes {
        debug {
            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "ads_open", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "home_banner", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "chart_banner", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "ads_inter", "ca-app-pub-3940256099942544/1033173712")

            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
            resValue("string", "ads_open", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "home_banner", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "chart_banner", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "ads_inter", "ca-app-pub-3940256099942544/1033173712")

            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    buildFeatures {
        viewBinding = true
//        dataBinding = true
    }

}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
//    implementation("com.android.support:multidex:2.0.1")
    implementation("androidx.multidex:multidex:2.0.1")

    //Room
    ksp(libs.room.compiler)
    implementation(libs.room.runtime)
    implementation(libs.room.paging)
    implementation(libs.room.ktx)

    // MPAndroidChart
    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

    // Kotlin standard library
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.8.0")


    implementation("com.android.billingclient:billing:7.1.1")
    implementation("com.google.android.gms:play-services-ads:22.5.0")
    implementation(project(":ads"))

}