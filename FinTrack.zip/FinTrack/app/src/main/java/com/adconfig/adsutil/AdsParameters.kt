package com.adconfig.adsutil

import android.content.Context
import android.content.SharedPreferences

class AdsParameters(context: Context) {

    private val ADS_PARAMETERS = "ADS_PARAMETERS"

    private val preferences: SharedPreferences =
        context.getSharedPreferences(ADS_PARAMETERS, Context.MODE_PRIVATE)

    var isNeedInterAd: Boolean
        get() = preferences.getBoolean("isNeedInterAd", true)
        set(isNeedInterAd) = preferences.edit().putBoolean("isNeedInterAd", isNeedInterAd).apply()

    var splashCounter: Int
        get() = preferences.getInt("splashCounter", 0)
        set(splashCounter) = preferences.edit().putInt("splashCounter", splashCounter).apply()

}