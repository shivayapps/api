package com.shivayapps.tictactoe

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.shivayapps.tictactoe.ui.MainActivity

class SplashScreenActivity : AppCompatActivity() {

    private lateinit var countDownTimer: CountDownTimer
    lateinit var adsPreferences: AdsParameters
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen)

        adsPreferences = AdsParameters(this)
        adsPreferences.isNeedInterAd = true
        val fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in_animation)

        val splashScrenLayout = findViewById<LinearLayout>(R.id.ll_splashscreen)
        splashScrenLayout.startAnimation(fadeInAnimation)

        val splashScreenDuration = 2000L

        var splashCounter = adsPreferences.splashCounter
        splashCounter++
        adsPreferences.splashCounter = splashCounter

        Log.e("SplashTag", "appOpenCounter:${splashCounter}")
        val AdmobAppOpenId = getString(R.string.ads_open)
        Log.e("SplashTag", "AdmobAppOpenId:${AdmobAppOpenId}")
        if (splashCounter % 3 == 0) {
            Log.e("SplashTag", "appOpenCounter%7-true")
            createTimerSec()
            OpenAdHelper.loadOpenAdId(this, {
                countDownTimer.cancel()
                isShowOpenAd { isLoaded ->//onAdClosed
                    if (!isLoaded) {
                        splashCounter--
                        adsPreferences.splashCounter = splashCounter
                    } else {
                        adsPreferences.isNeedInterAd = false
                    }
                    gotoMainScreen()
                }
            }, AdmobAppOpenId)
        } else {
            Log.e("SplashTag", "appOpenCounter%2-else")
            splashScrenLayout.postDelayed({
                gotoMainScreen()
            }, splashScreenDuration)
//            gotoMainScreen()
        }

    }

    private fun gotoMainScreen() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun createTimerSec() {
        val totalTimeMillis = 6
        countDownTimer = object : CountDownTimer(totalTimeMillis * 1000L, 1000) {
            override fun onTick(l: Long) {

            }

            override fun onFinish() {
                gotoMainScreen()
            }
        }
        countDownTimer.start()
    }
}