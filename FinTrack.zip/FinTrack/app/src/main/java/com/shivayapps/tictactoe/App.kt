package com.shivayapps.tictactoe

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.StrictMode
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity

class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener {


    override fun onCreate() {
        super.onCreate()


        val admobAppOpenId = getString(R.string.ads_open)
        AdsConfig.builder()
            .setTestDeviceId("0")
            .setAdmobAppOpenId(admobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()
    }

    private fun enableStrictMode() {
        StrictMode.setThreadPolicy(
            StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build()
        )
        StrictMode.setVmPolicy(
            StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .detectLeakedClosableObjects()
                .penaltyLog()
                .build()
        )
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is SplashScreenActivity) {
            return false
        } else if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }
}
