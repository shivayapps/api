package com.shivayapps.tictactoe.util

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var homeBanner:AdView?=null
        var chartBanner:AdView?=null
    }
}


