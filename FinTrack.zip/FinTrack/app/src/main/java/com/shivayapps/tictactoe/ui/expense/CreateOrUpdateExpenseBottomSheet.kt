package com.shivayapps.tictactoe.ui.expense

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.core.view.isVisible
import com.shivayapps.tictactoe.R
import com.shivayapps.tictactoe.data.entities.CategoryEntity
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CreateOrUpdateExpenseBottomSheet(
    private val categoryList: List<CategoryEntity>,
    private val expense: ExpenseUiData? = null,
    private val selectedCategory: String?,
    private val onCreateClicked: (ExpenseUiData) -> Unit,
    private val onUpdateClicked: (ExpenseUiData) -> Unit,
    private val onDeleteClicked: (ExpenseUiData) -> Unit
) : BottomSheetDialogFragment() {

    private lateinit var tieExpenseDate: TextInputEditText
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.create_or_update_expense_bottom_sheet, container)

        // Inicialização dos elementos da interface
        val tvTitle = view.findViewById<TextView>(R.id.tv_title)
        val btnCreateOrUpdate = view.findViewById<Button>(R.id.btn_expense_create_or_update)
        val btnDelete = view.findViewById<Button>(R.id.btn_expense_delete)
        val tieExpenseName = view.findViewById<TextInputEditText>(R.id.tie_expense_name)
        val tieExpenseAmount = view.findViewById<TextInputEditText>(R.id.tie_expense_amount)
        tieExpenseDate = view.findViewById(R.id.tie_expense_date)
        val spinner: Spinner = view.findViewById(R.id.sp_expense_list)

//        var expenseCategory: String? = null
        var expenseCategory: String = categoryList[0].name

        // Construção da lista de categorias para o spinner
//        val categoryListTemp = mutableListOf("Select the category")
        val categoryListTemp = ArrayList<String>()
        categoryListTemp.addAll(
            categoryList.map { it.name }
        )
        val expenseStr: List<String> = categoryListTemp

        // Configuração do adapter para o spinner
        ArrayAdapter(
            requireActivity().baseContext,
            R.layout.spinner_item,
            expenseStr.toList()
        ).also { adapter ->
            adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
            spinner.adapter = adapter
        }

        // Manipulador de evento para seleção de item no spinner
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                expenseCategory = expenseStr[position]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }

        // Configuração da interface com base na presença ou ausência de uma expense existente
        if (expense == null) {
            // Configuração para adicionar uma nova despesa
            btnDelete.isVisible = false
            tvTitle.setText(R.string.add_expense_title)
            btnCreateOrUpdate.setText(R.string.add)

            // Pré-seleciona a categoria se não for "ALL"
            selectedCategory?.let {
                if (it != "ALL") {
                    val currentCategoryIndex = categoryListTemp.indexOf(it)
                    if (currentCategoryIndex != -1) {
                        spinner.setSelection(currentCategoryIndex)
                    }
                }
            }
        } else {
            // Configuração para atualizar uma despesa existente
            tvTitle.setText(R.string.update_expense_title)
            btnCreateOrUpdate.setText(R.string.update)
            tieExpenseName.setText(expense.name)
            tieExpenseAmount.setText(expense.amount.toString())
            tieExpenseDate.setText(expense.date.toString())
            btnDelete.isVisible = true

            // Seleciona a categoria da despesa existente no spinner
            val currentCategoryIndex = categoryListTemp.indexOf(expense.category)
            if (currentCategoryIndex != -1) {
                spinner.setSelection(currentCategoryIndex)
            }
        }

        // Configuração do DatePickerDialog para selecionar a data
        tieExpenseDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            if (expense != null) {
                calendar.time = expense.date
            }
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog =
                DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
                    val selectedDate = Calendar.getInstance()
                    selectedDate.set(selectedYear, selectedMonth, selectedDay)
                    tieExpenseDate.setText(dateFormat.format(selectedDate.time))
                }, year, month, day)
            datePickerDialog.show()
        }

        // Manipulador para o botão de delete
        btnDelete.setOnClickListener {
            if (expense != null) {
                onDeleteClicked.invoke(expense)
                dismiss()
            } else {
                Log.d("CreateOrUpdateExpense", "Expense not found")
            }
        }

        // Manipulador para o botão de create ou update
        btnCreateOrUpdate.setOnClickListener {
            val name = tieExpenseName.text.toString().trim()
            val amount = tieExpenseAmount.text.toString().toDoubleOrNull() ?: 0.0
            val dateStr = tieExpenseDate.text.toString().trim()
            val date = dateFormat.parse(dateStr)

            // Verifica se a categoria e o nome da despesa estão preenchidos
            if (expenseCategory != "Select" && name.isNotEmpty() && date != null) {

                requireNotNull(expenseCategory)

                // Determina se é uma criação ou atualização de expense e executa a ação correspondente
                if (expense == null) {

                    // Cria uma nova expense
                    onCreateClicked.invoke(
                        ExpenseUiData(
                            id = 0,
                            name = name,
                            category = requireNotNull(expenseCategory),
                            amount = amount,
                            date = date,
                            iconResId = 0,
                            color = 0
                        )
                    )
                } else {

                    // Atualiza uma expense existente
                    onUpdateClicked.invoke(
                        ExpenseUiData(
                            id = expense.id,
                            name = name,
                            category = requireNotNull(expenseCategory),
                            amount = amount,
                            date = date,
                            iconResId = 0,
                            color = 0
                        )
                    )
                }
                // Fecha o BottomSheet após criar ou atualizar a despesa
                dismiss()

            } else {
                Snackbar.make(btnCreateOrUpdate, "Please select a category", Snackbar.LENGTH_LONG).show()
            }
        }
        return view
    }
}