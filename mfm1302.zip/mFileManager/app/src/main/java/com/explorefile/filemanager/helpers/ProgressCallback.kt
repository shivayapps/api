package com.explorefile.filemanager.helpers

interface ProgressCallback {
    fun onStart(totalBytes: Long)
    fun onProgress(processedBytes: Long, percent: Int)
    fun onComplete(outputDir: String)
    fun onError(e: Exception?)
}
