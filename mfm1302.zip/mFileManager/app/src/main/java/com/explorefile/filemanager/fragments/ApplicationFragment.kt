package com.explorefile.filemanager.fragments

import android.app.Dialog
import android.app.ProgressDialog
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.annotation.RequiresApi
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.airbnb.lottie.LottieAnimationView

import com.bumptech.glide.Glide
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.AppManagerActivity
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.adapters.AppAdapter
import com.explorefile.filemanager.databinding.ApplicationFragmentBinding
import com.explorefile.filemanager.dialogs.AppActionDialog
import com.explorefile.filemanager.helpers.ApkInformationExtractor
import com.explorefile.filemanager.helpers.AppManager
import com.explorefile.filemanager.helpers.CreateShortcutTool
import com.explorefile.filemanager.models.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.*

class ApplicationFragment : Fragment(R.layout.application_fragment) {

    private var _binding: ApplicationFragmentBinding? = null
    private val binding get() = _binding!!

    private lateinit var mContext: FragmentActivity

    private var appType = "user"
    private var adapter: AppAdapter? = null

    private val appList = mutableListOf<AppInfo>()
    private val appToUninstall = mutableListOf<AppInfo>()
    private val userAppList = mutableListOf<AppInfo>()
    private val systemAppList = mutableListOf<AppInfo>()

    private var apkInformationExtractor: ApkInformationExtractor? = null
    private var appManOb: AppManager? = null

    private var isLoading = false
    private var path = ""

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"

        fun newInstance(type: String): ApplicationFragment {
            return ApplicationFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_SECTION_NUMBER, type)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mContext = requireActivity()
        appType = arguments?.getString(ARG_SECTION_NUMBER) ?: "user"

        val rootPath = Environment.getExternalStorageDirectory().toString()
        path = "$rootPath/RecoverMedia/Apk Backup/"
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = ApplicationFragmentBinding.bind(view)

        initData()
        initRecycler()
        initActions()
        getApps(appType)
    }

    fun deSelectAll() {
        appToUninstall?.clear()
        binding.button?.visibility = View.GONE
        adapter?.deSelectAll()
    }

    public fun filter(filter: String) {
        if (!filter.isEmpty()) {
            Log.e("AppsFragment", "filter-filterAppList: $appType")
            if (appType.equals("user")) {
                filterAppList(filter, adapter?.getAppList()!!)
            } else if (appType.equals("system")) {
                filterAppList(filter, adapter?.getAppList()!!)
            }
        } else {
            Log.e("AppsFragment", "filter-updateAppList: $appType")
            if (appType.equals("user")) {
                updateAppList(userAppList!!)
            } else if (appType.equals("system")) {
                updateAppList(systemAppList!!)
            }
        }

    }

    public fun sort(type: Int) {
        Log.e("sortAppList", "type:$type")
        val appList = adapter?.getAppList()!!

        Log.e("sortAppList", "appList:${appList.size}")
        sortAppList(type, appList)
    }

    public fun sortAppList(type: Int, newAppList: MutableList<AppInfo>) {
        if (type == 0) {
            newAppList.sortBy { it.usageTimeMillis }
        } else if (type == 1) {
            newAppList.sortByDescending { it.usageTimeMillis }
        } else if (type == 2) {
            newAppList.sortByDescending { it.appSize }
        }
        Log.e("sortAppList", "updateAppList:${newAppList.size}")
        updateAppList(newAppList)
    }

    private fun filterAppList(filter: String, newAppList: MutableList<AppInfo>) {
        val filteredList = ArrayList<AppInfo>()
//        var isUninstalledFilter=false
        for (app in newAppList) {
            if (app.appName.toString().lowercase(Locale.getDefault()).contains(filter)) {
                filteredList.add(app)
            }
//            if(app.isSelected) isUninstalledFilter=true
        }
        updateAppList(filteredList)
    }


    private fun initData() {
        apkInformationExtractor = ApkInformationExtractor(mContext)
        appManOb = AppManager()

        binding.alertSystem.visibility =
            if (appType == "system") View.VISIBLE else View.GONE

        binding.tvEmtyMsg.text = if (appType == "user") {
            getString(R.string.user_app_list_is_empty)
        } else {
            getString(R.string.system_app_list_is_empty)
        }
    }

    private fun initRecycler() {
        adapter = AppAdapter(
            activity as BaseActivity,
            appType,
            object : AppAdapter.OnAppSelect {

                override fun onAppClick(position: Int, appInfo: AppInfo) {
                    if (!adapter!!.isMultiSelect) {
                        appActionDialog(appInfo)
                    }
                }

                override fun onAppSelect(position: Int, isChecked: Boolean, appInfo: AppInfo) {
                    if (isChecked) {
                        appToUninstall.add(appInfo)
                    } else {
                        appToUninstall.remove(appInfo)
                    }
                    updateMultiSelectState()
                }
            }
        )

        binding.rvApps.apply {
            layoutManager = GridLayoutManager(context, 1)
            adapter = this@ApplicationFragment.adapter
            setItemViewCacheSize(500)
        }
    }

    private fun initActions() {
        binding.buttonUninstall.setOnClickListener {
            if (appToUninstall.isNotEmpty()) {
                uninstallApp(appToUninstall.first())
            } else {
                Toast.makeText(mContext, "Select item first", Toast.LENGTH_SHORT).show()
            }
        }

        binding.buttonRecover.setOnClickListener {
            if (appToUninstall.isNotEmpty()) {
                copyApks()
            } else {
                Toast.makeText(mContext, "Select item first", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val uninstallLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

            val app = appInAction ?: return@registerForActivityResult

            if (!ApkInformationExtractor(mContext).isPackageInstalled(app.appPackage!!)) {

                // successfully uninstalled
                appToUninstall.remove(app)

                if (appToUninstall.isNotEmpty()) {
                    uninstallApp(appToUninstall.first())
                } else {
                    adapter?.isMultiSelect = false
                    getApps(appType)
                }

            } else {
                // uninstall cancelled
                appToUninstall.remove(app)
                adapter?.isMultiSelect = appToUninstall.isNotEmpty()
            }
        }

    private fun updateMultiSelectState() {
        adapter?.isMultiSelect = appToUninstall.isNotEmpty()
        binding.button.visibility =
            if (appToUninstall.isNotEmpty()) View.VISIBLE else View.GONE

        adapter?.notifyDataSetChanged()
    }

    private fun getApps(type: String) {

        // 🔥 show loading immediately
        isLoading = true
        binding.lottieApps.visibility = View.VISIBLE
        binding.llEmpty.visibility = View.GONE
        binding.rvApps.visibility = View.GONE

        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            try {
                val result = ApkInformationExtractor(requireContext())
                    .appManagerInitValues()

                userAppList.clear()
                systemAppList.clear()

                result.userApps.let { userAppList.addAll(it) }
                result.systemApps.let { systemAppList.addAll(it) }

                withContext(Dispatchers.Main) {
                    val listToShow =
                        if (type == "user") userAppList else systemAppList

                    updateAppList(listToShow)

                    // 🔥 hide loading AFTER UI update
                    binding.lottieApps.visibility = View.GONE
                    binding.rvApps.visibility =
                        if (listToShow.isEmpty()) View.GONE else View.VISIBLE
                    binding.llEmpty.visibility =
                        if (listToShow.isEmpty()) View.VISIBLE else View.GONE

                    isLoading = false
                }

            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    binding.lottieApps.visibility = View.GONE
                    binding.llEmpty.visibility = View.VISIBLE
                    isLoading = false
                }
            }
        }
    }

    private fun updateAppList(newList: MutableList<AppInfo>) {

        appList.clear()
        appList.addAll(newList)
        adapter?.updateList(appList)

        val title = if (appType == "user") {
            getString(R.string.user_apps)
        } else {
            getString(R.string.system_apps)
        }

        (activity as AppManagerActivity).apply {
            if (appType == "user") {
                binding.tvUserApp.text = "$title (${appList.size})"
            } else {
                binding.tvSystemApp.text = "$title (${appList.size})"
            }
        }
    }

    //    private fun uninstallApp(appToUninstall: AppInfo) {
//
//        appInAction = appToUninstall
//        val appPackage: String = appInAction?.appPackage!!
//        val uri = Uri.parse("package:$appPackage")
//        val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri)
//        startActivityForResult(intent, 115)
//    }
    private fun uninstallApp(appInfo: AppInfo) {
        appInAction = appInfo
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${appInfo.appPackage}")
            }
            if (intent != null) {
//                activity?.startActivity(intent)
                uninstallLauncher.launch(intent)
                Toast.makeText(activity,"Select Uninstall", Toast.LENGTH_SHORT).show()
            }
            else Log.d("AppActionDialog", "Launch intent not found")
        } catch (e: Exception) {
            Log.d("AppActionDialog", "Launch failed: ${e.message}")
        }


    }

    private var appInAction: AppInfo? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("onActivityResult", "fragment-requestCode: $requestCode")
        Log.e("onActivityResult", "fragment-resultCode: $resultCode")
        if (requestCode == 112) {
            //public void saveAppHistory(String name, String packageName, String size, String date)
            if (!ApkInformationExtractor(mContext).isPackageInstalled(appInAction?.appPackage!!)) {
                Handler(Looper.getMainLooper()).postDelayed({
                    getApps(appType)
                }, 500)
            }
        }
//        if (requestCode == 115) {
//
//            if (!ApkInformationExtractor(mContext).isPackageInstalled(appInAction?.appPackage!!)) {
//                appToUninstall.remove(appInAction)
//
//                if (appToUninstall.size > 0) {
//                    adapter?.isMultiSelect = true
//                    uninstallApp(appToUninstall[0])
//                    binding.button?.visibility = View.VISIBLE
//                } else {
//
//                    adapter?.isMultiSelect = false
//                    Handler(Looper.getMainLooper()).postDelayed({
//                        getApps(appType)
//                    }, 500)
//                }
//            } else {
//                appToUninstall?.remove(appInAction)
//                if (appToUninstall?.size!! > 0) {
//                    adapter?.isMultiSelect = true
//                    uninstallApp(appToUninstall!![0])
//                    binding.button?.visibility = View.VISIBLE
//                } else {
//
//                    adapter?.isMultiSelect = false
//                    Handler(Looper.getMainLooper()).postDelayed({
//                        getApps(appType)
//                    }, 500)
//                }
//            }
//
//        }
    }

    private fun appActionDialog(appInfo: AppInfo) {
        AppActionDialog(
            activity as AppManagerActivity,
            appInfo,
            appType
        )
    }

    private fun copyApks() {
        mCopyApks =
            CopyFiles(appToUninstall).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR)
    }

    fun updateUi(pd: Dialog) {
        mContext.runOnUiThread {
            deSelectAll()
            pd.cancel()
        }
    }

    private fun copy(fileToCopy: File, lPackageName: String?, lAppName: String?) {
        try {
            val destinationFile = File(path, "$lAppName#$lPackageName.apk")
            Log.e("mTAG", "copy: destinationFile -- > $destinationFile")
            val fis = FileInputStream(fileToCopy)
            val fos = FileOutputStream(destinationFile)
            val b = ByteArray(1024)
            var noOfBytesRead: Int
            while (fis.read(b).also { noOfBytesRead = it } != -1) {
                fos.write(b, 0, noOfBytesRead)
            }
            fis.close()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    var mCopyApks: AsyncTask<*, *, *>? = null

    private inner class CopyFiles(var selectedApp: MutableList<AppInfo>) :
        AsyncTask<String?, String?, String?>() {
        val dialog = Dialog(activity!! as AppManagerActivity)
        var progress_text: TextView? = null
        var permission_text: TextView? = null
//        var selectedApp: MutableList<AppInfo>? = null

        override fun onPreExecute() {
            super.onPreExecute()

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(false)
            dialog.setContentView(R.layout.dialog_backup_progress)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            progress_text = dialog.findViewById<TextView>(R.id.permission)
            progress_text?.text = getString(R.string.label_please_wait)
            permission_text = dialog.findViewById<TextView>(R.id.permission_text)
            permission_text?.text = getString(R.string.copying_apk_files)
            dialog.findViewById<TextView>(R.id.dialogButtonCancel).text = getString(R.string.cancel)

            dialog.findViewById<Button>(R.id.dialogButtonCancel).setOnClickListener {
                dialog.cancel()

                AdsConfig.isSystemDialogOpen = false
                if (mCopyApks != null) {
                    mCopyApks!!.cancel(true)
                }
            }

            dialog.setOnDismissListener {
                AdsConfig.isSystemDialogOpen = false
            }

            if (!dialog.isShowing) {
                dialog.show()
                AdsConfig.isSystemDialogOpen = true
            }
        }

        override fun doInBackground(vararg strings: String?): String? {
//            val selectedInfoList = mApkBackupAdapter!!.selectedApk()
//            if (selectedInfoList.isNotEmpty()) {
            for (i in selectedApp.indices) {
                if (mCopyApks != null) {
                    if (mCopyApks!!.isCancelled) {
                        updateUi(dialog)
                    } else {
                        val file = File(selectedApp[i].publicSourceDir!!)
                        val dir = File(path)
                        if (dir.exists() || dir.mkdirs()) {
                            try {
                                copy(file, selectedApp[i].appPackage, selectedApp[i].appName)

                                activity!!.sendBroadcast(
                                    Intent(
                                        Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                                        Uri.fromFile(file)
                                    )
                                )
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }
                }
                activity?.runOnUiThread {
                    permission_text?.text =
                        "copying apk files $i/${selectedApp.size}"
                }
            }
//            }
            return null
        }

        override fun onPostExecute(s: String?) {
            super.onPostExecute(s)

            try {
                Handler(Looper.getMainLooper()).post {
                    deSelectAll()
//                    if(isAdded) {
//                        checkAll!!.isChecked = false
//                    }
                }

                Handler(Looper.getMainLooper()).postDelayed(Runnable {
                    try {
                        if (dialog != null && dialog.isShowing) {
                            dialog.cancel()
//                            MyApplication.isDialogOpen = false
                        }
                    } catch (e: Exception) {
//                        mContext!!.addEvent(e.message!!)
                    }
                }, 100)

//                mContext!!.viewpager.currentItem = 1

                Toast.makeText(mContext, "Apks copied" + path, Toast.LENGTH_LONG)
                    .show()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

}
