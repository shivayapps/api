package com.explorefile.filemanager.interfaces

interface HashListener {
    fun receivedHash(hash: String, type: Int)
}
