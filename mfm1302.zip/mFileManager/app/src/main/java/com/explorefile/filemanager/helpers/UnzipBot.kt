import com.explorefile.filemanager.helpers.ProgressCallback
import java.io.*
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import com.github.junrar.Archive
import com.github.junrar.rarfile.FileHeader
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile

enum class ArchiveType {
    ZIP, RAR, SEVEN_Z, UNKNOWN
}

fun detectType(file: File): ArchiveType =
    when {
        file.name.endsWith(".zip", true) -> ArchiveType.ZIP
        file.name.endsWith(".rar", true) -> ArchiveType.RAR
        file.name.endsWith(".7z", true) -> ArchiveType.SEVEN_Z
        else -> ArchiveType.UNKNOWN
    }


object UnzipBot {

    fun unzipFiles(
        archives: List<File>,
        destinationFolder: File,
        callback: ProgressCallback
    ) {
        var processedGlobal = 0L

        try {
            val totalBytes = getTotalSizeForFiles(archives)
            callback.onStart(totalBytes)
            var finalDir=destinationFolder.path
            archives.forEach { file ->
                val proxyCallback = object : ProgressCallback {
                    private var lastProcessed = 0L

                    override fun onStart(totalBytes: Long) {
                        // ignore per-file start
                    }

                    override fun onProgress(processedBytes: Long, percent: Int) {
                        val delta = processedBytes - lastProcessed
                        lastProcessed = processedBytes
                        processedGlobal += delta

                        callback.onProgress(
                            processedGlobal,
                            ((processedGlobal * 100) / totalBytes).toInt()
                        )
                    }

                    override fun onComplete(outputDir: String) {
                        finalDir=outputDir
                    }

                    override fun onError(e: Exception?) {
                        callback.onError(e)
                    }

                }

                when (detectType(file)) {
                    ArchiveType.ZIP ->
                        unzipZip(file, destinationFolder, proxyCallback)

                    ArchiveType.RAR ->
                        unzipRar(file, destinationFolder, proxyCallback)

                    ArchiveType.SEVEN_Z ->
                        unzip7z(file, destinationFolder, proxyCallback)

                    ArchiveType.UNKNOWN ->
                        throw IllegalArgumentException("Unsupported file: ${file.name}")
                }
            }

            callback.onComplete(finalDir)
        } catch (e: Exception) {
            callback.onError(e)
        }
    }
    fun getTotalSizeForFiles(files: List<File>): Long {
        var total = 0L

        files.forEach { file ->
            when (detectType(file)) {
                ArchiveType.ZIP -> total += getZipTotalSize(file)
                ArchiveType.RAR -> Archive(file).use {
                    total += getRarTotalSize(it)
                }
                ArchiveType.SEVEN_Z -> total += get7zTotalSize(file)
                else -> Unit
            }
        }

        return total
    }



    // -------------------- TOTAL SIZE HELPERS --------------------

    @Throws(IOException::class)
    private fun getZipTotalSize(zipFile: File): Long {
        var total = 0L
        ZipInputStream(Files.newInputStream(zipFile.toPath())).use { zis ->
            var entry: ZipEntry?
            while (zis.nextEntry.also { entry = it } != null) {
                entry?.let {
                    if (!it.isDirectory && it.size > 0) {
                        total += it.size
                    }
                }
            }
        }
        return total
    }

    private fun getRarTotalSize(archive: Archive): Long {
        var total = 0L
        for (h in archive.fileHeaders) {
            if (!h.isDirectory) {
                total += h.fullUnpackSize
            }
        }
        return total
    }

    @Throws(IOException::class)
    private fun get7zTotalSize(sevenZFile: File): Long {
        var total = 0L
        SevenZFile(sevenZFile).use { sevenZ ->
            var entry: SevenZArchiveEntry?
            while (sevenZ.nextEntry.also { entry = it } != null) {
                entry?.let {
                    if (!it.isDirectory) {
                        total += it.size
                    }
                }
            }
        }
        return total
    }

    // -------------------- ZIP --------------------

    fun unzipZip(
        zipFile: File,
        destinationFolder: File,
        callback: ProgressCallback
    ) {
        var processed = 0L

        try {
            val totalBytes = getZipTotalSize(zipFile)
            callback.onStart(totalBytes)

            val folderName = zipFile.name.replaceFirst("\\.zip$".toRegex(), "")
            val outputDir = File(destinationFolder, folderName).apply { mkdirs() }
            ZipInputStream(Files.newInputStream(zipFile.toPath())).use { zis ->

                val buffer = ByteArray(8192)
                var entry: ZipEntry?

                while (zis.nextEntry.also { entry = it } != null) {
                    val outputPath: Path =
                        Paths.get(outputDir.absolutePath, entry!!.name)

                    if (entry!!.isDirectory) {
                        Files.createDirectories(outputPath)
                    } else {
                        Files.createDirectories(outputPath.parent)
                        Files.newOutputStream(outputPath).use { out ->
                            var len: Int
                            while (zis.read(buffer).also { len = it } > 0) {
                                out.write(buffer, 0, len)
                                processed += len
                                callback.onProgress(
                                    processed,
                                    ((processed * 100) / totalBytes).toInt()
                                )
                            }
                        }
                    }
                    zis.closeEntry()
                }
            }

            callback.onComplete(outputDir.path)
        } catch (e: Exception) {
            callback.onError(e)
        }
    }

    // -------------------- RAR --------------------

    fun unzipRar(
        rarFile: File,
        destinationFolder: File,
        callback: ProgressCallback
    ) {
        var processed = 0L

        try {
            val folderName = rarFile.name.replaceFirst("\\.rar$".toRegex(), "")
            val outputDir = File(destinationFolder, folderName).apply { mkdirs() }
            Archive(rarFile).use { archive ->
                val totalBytes = getRarTotalSize(archive)
                callback.onStart(totalBytes)


                var header: FileHeader?

                while (archive.nextFileHeader().also { header = it } != null) {
                    if (header!!.isDirectory) continue

                    val outFile = File(outputDir, header!!.fileNameString.trim())
                    outFile.parentFile?.mkdirs()

                    FileOutputStream(outFile).use { fos ->
                        val countingOut = CountingOutputStream(fos) { written ->
                            val delta = written - processed
                            processed += delta

                            callback.onProgress(
                                processed,
                                ((processed * 100) / totalBytes).toInt()
                            )
                        }
                        archive.extractFile(header, countingOut)
                    }
                }

                callback.onComplete(outputDir.path)
            }
        } catch (e: Exception) {
            callback.onError(e)
        }
    }


    // -------------------- 7Z --------------------

    fun unzip7z(
        sevenZFile: File,
        destinationFolder: File,
        callback: ProgressCallback
    ) {
        var processed = 0L

        try {
            val totalBytes = get7zTotalSize(sevenZFile)
            callback.onStart(totalBytes)

            val folderName = sevenZFile.name.replaceFirst("\\.7z$".toRegex(), "")
            val outputDir = File(destinationFolder, folderName).apply { mkdirs() }
            SevenZFile(sevenZFile).use { sevenZ ->

                val buffer = ByteArray(8192)
                var entry: SevenZArchiveEntry?

                while (sevenZ.nextEntry.also { entry = it } != null) {
                    if (entry!!.isDirectory) continue

                    val outFile = File(outputDir, entry!!.name)
                    outFile.parentFile?.mkdirs()

                    FileOutputStream(outFile).use { out ->
                        var len: Int
                        while (sevenZ.read(buffer).also { len = it } > 0) {
                            out.write(buffer, 0, len)
                            processed += len
                            callback.onProgress(
                                processed,
                                ((processed * 100) / totalBytes).toInt()
                            )
                        }
                    }
                }
            }

            callback.onComplete(outputDir.path)
        } catch (e: Exception) {
            callback.onError(e)
        }
    }
}


class CountingOutputStream(
    out: OutputStream,
    private val onBytesWritten: (Long) -> Unit
) : FilterOutputStream(out) {

    private var bytesWritten = 0L

    override fun write(b: Int) {
        out.write(b)
        bytesWritten++
        onBytesWritten(bytesWritten)
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
        out.write(b, off, len)
        bytesWritten += len
        onBytesWritten(bytesWritten)
    }
}
