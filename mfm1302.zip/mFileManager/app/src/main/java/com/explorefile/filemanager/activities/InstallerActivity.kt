package com.explorefile.filemanager.activities

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityInstallerBinding
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.beVisible
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.NavigationIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream

class InstallerActivity : BaseActivity() {

    private val installReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {

            val status = intent.getIntExtra(
                PackageInstaller.EXTRA_STATUS,
                PackageInstaller.STATUS_FAILURE
            )

            when (status) {

                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    val confirmIntent =
                        intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)

                    confirmIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(confirmIntent)
                }

                PackageInstaller.STATUS_SUCCESS -> {
                    updateProgress(100)
                    updateStatus("App Installed Successfully 🎉")
//                    closeWithDelay()
                    runOnUiThread {
                        binding.progressBar.beGone()
                        binding.llButton.beVisible()
                        binding.llButtonError.beGone()
                    }
                }

                else -> {
                    val msg = intent.getStringExtra(
                        PackageInstaller.EXTRA_STATUS_MESSAGE
                    )
                    updateStatus("Install Failed: $msg")
                    //closeWithDelay()

                    runOnUiThread {
                        binding.progressBar.beGone()
                        binding.llButton.beGone()
                        binding.llButtonError.beVisible()
                    }
                }
            }
        }
    }

    private fun openInstalledApp() {
        installedPackageName?.let { packageName ->
            val launchIntent =
                packageManager.getLaunchIntentForPackage(packageName)

            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                finish()
            } else {
                updateStatus("Unable to launch app")
            }
        }
    }

    private var installedPackageName: String? = null

    private var filePath = ""
    private var fileName = ""

    val binding by viewBinding(ActivityInstallerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        filePath = intent?.getStringExtra("filePath").toString()
        fileName = intent?.getStringExtra("fileName").toString()
        registerReceiver(
            installReceiver,
            IntentFilter("INSTALL_STATUS"),
            RECEIVER_EXPORTED
        )



        setupToolbar()

        binding.btnOpen.setOnClickListener {
            openInstalledApp()
        }

        binding.btnExit.setOnClickListener {
            finish()
        }

        binding.btnError.setOnClickListener {
            finish()
        }

        startInstallFlow()

    }

    private fun startInstallFlow() {

        if (packageManager.canRequestPackageInstalls()) {
            // ✅ Already granted → install directly
            updateStatus("Installing...")
            lifecycleScope.launch(Dispatchers.IO) {
                installApk(File(filePath))
            }

        }else{

            // ❌ Not granted → open settings
            updateStatus("Please allow 'Install unknown apps'")

            val intent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:$packageName")
            )

            unknownSourceLauncher.launch(intent)
        }

    }


    private val unknownSourceLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {

            if (packageManager.canRequestPackageInstalls()) {
                updateStatus("Permission granted. Installing...")
                lifecycleScope.launch(Dispatchers.IO) {
                    installApk(File(filePath))
                }
            } else {
                updateStatus("Permission denied. Cannot install.")
            }
        }


    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(installReceiver)
    }

    private suspend fun installApk(apkFile: File) {

        val packageInstaller = packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(
            PackageInstaller.SessionParams.MODE_FULL_INSTALL
        )

        params.setSize(apkFile.length())
        params.setInstallReason(PackageManager.INSTALL_REASON_USER)

        val pkgInfo = packageManager.getPackageArchiveInfo(apkFile.path, 0)
        params.setAppPackageName(pkgInfo?.packageName)
        installedPackageName = pkgInfo?.packageName


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            params.setRequireUserAction(
                PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED
            )
        }

        val sessionId = packageInstaller.createSession(params)
        val session = packageInstaller.openSession(sessionId)

        updateStatus("Preparing APK...")
        updateProgress(5)

        val out = session.openWrite("install", 0, apkFile.length())
        val input = FileInputStream(apkFile)

        val buffer = ByteArray(65536)
        var total = 0L
        val size = apkFile.length()

        var c: Int
        while (input.read(buffer).also { c = it } != -1) {
            out.write(buffer, 0, c)
            total += c

            val progress = ((total * 70) / size).toInt()
            updateProgress(progress)
        }

        session.fsync(out)
        input.close()
        out.close()

        updateStatus("Installing…")
        updateProgress(80)


        val intent = Intent("INSTALL_STATUS").apply {
            setPackage(packageName)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            sessionId,
            intent,
            flags
        )


        session.commit(pendingIntent.intentSender)

        session.close()
    }


    private fun updateProgress(value: Int) {
        runOnUiThread { binding.progressBar.progress = value }
    }

    private fun updateStatus(msg: String) {
        runOnUiThread { binding.tvStatus.text = msg }
    }

    override fun onResume() {
        super.onResume()
        setupToolbar(binding.installerToolbar, NavigationIcon.Arrow)
        updateTopBarColors(binding.installerToolbar, getProperBackgroundColor())
    }

    private fun setupToolbar() {
        binding.installerToolbar.title = fileName
    }

}