package com.explorefile.filemanager.dialogs

import android.util.Log
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.DialogRenameItemBinding
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.getDoesFilePathExist
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getIsPathDirectory
import com.explorefile.filemanager.extensions.getParentPath
import com.explorefile.filemanager.extensions.isAValidFilename
import com.explorefile.filemanager.extensions.renameFile
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.extensions.showKeyboard
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.value

class RenameItemDialog(
    val activity: BaseActivity,
    val path: String,
    val callback: (newPath: String) -> Unit
) {
    init {
        var ignoreClicks = false
        val fullName = path.getFilenameFromPath()
        val dotAt = fullName.lastIndexOf(".")
        var name = fullName

        val view = DialogRenameItemBinding.inflate(activity.layoutInflater, null, false).apply {
            if (dotAt > 0 && !activity.getIsPathDirectory(path)) {
                name = fullName.substring(0, dotAt)
                val extension = fullName.substring(dotAt + 1)
                renameItemExtension.setText(extension)
            } else {
                renameItemExtensionHint.beGone()
            }

            renameItemName.setText(name)
        }

        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(view.root, this) { alertDialog ->
                    alertDialog.showKeyboard(view.renameItemName)
                    view.txtOk.setOnClickListener {
                        if (ignoreClicks) {
                            return@setOnClickListener
                        }

                        var newName = view.renameItemName.value
                        val newExtension = view.renameItemExtension.value

                        if (newName.isEmpty()) {
                            activity.toast(R.string.empty_name)
                            return@setOnClickListener
                        }

                        if (!newName.isAValidFilename()) {
                            activity.toast(R.string.invalid_name)
                            return@setOnClickListener
                        }

                        val updatedPaths = ArrayList<String>()
                        updatedPaths.add(path)
                        if (!newExtension.isEmpty()) {
                            newName += ".$newExtension"
                        }

                        if (!activity.getDoesFilePathExist(path)) {
                            Log.e("Exception","file_doesnt_exist:$path")
                            activity.toast(
                                String.format(
                                    activity.getString(R.string.source_file_doesnt_exist),
                                    path
                                )
                            )
                            return@setOnClickListener
                        }

                        val newPath = "${path.getParentPath()}/$newName"

                        if (path == newPath) {
                            Log.e("Exception","name_taken.01.path:$path")
                            Log.e("Exception","name_taken.01.newPath:$newPath")
                            activity.toast(R.string.name_taken)
                            return@setOnClickListener
                        }

                        if (!path.equals(
                                newPath,
                                ignoreCase = true
                            ) && activity.getDoesFilePathExist(newPath)
                        ) {
                            Log.e("Exception","name_taken.02.path:$path")
                            Log.e("Exception","name_taken.02.newPath:$newPath")
                            activity.toast(R.string.name_taken)
                            return@setOnClickListener
                        }

                        updatedPaths.add(newPath)
                        ignoreClicks = true
                        activity.renameFile(path, newPath, false) { success, _ ->
                            ignoreClicks = false
                            if (success) {
                                callback(newPath)
                                alertDialog.dismiss()
                            }
                        }
                    }

                    view.txtCancel.setOnClickListener {
                        alertDialog.dismiss()
                    }
                }
            }
    }
}
