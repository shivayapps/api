package com.explorefile.filemanager.fragments

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.FileViewerActivity
import com.explorefile.filemanager.databinding.FragmentMediaBinding
import com.explorefile.filemanager.extensions.isAudio
import com.explorefile.filemanager.extensions.isVideo
import com.explorefile.filemanager.helpers.Preferences
import com.explorefile.filemanager.models.ListItem

import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView

class MediaFragment : Fragment(R.layout.fragment_media) {

    private lateinit var filePath: String
    private var player: ExoPlayer? = null
    private var isMuted = false

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        filePath = requireArguments().getString("file_path")!!
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val imageView = view.findViewById<ImageView>(R.id.imageView)
        val audioThumb = view.findViewById<ImageView>(R.id.audioThumb)
        val playerLayout = view.findViewById<ConstraintLayout>(R.id.playerLayout)
        val playerView = view.findViewById<PlayerView>(R.id.playerView)
        val seekBar = view.findViewById<SeekBar>(R.id.playerSeekBar)
//        val btnMute = view.findViewById<ImageButton>(R.id.btnMute)
        val btnPlayPause = view.findViewById<ImageButton>(R.id.btnPlayPause)
        val btnPrev = view.findViewById<ImageButton>(R.id.btnPrev)
        val btnNext = view.findViewById<ImageButton>(R.id.btnNext)
        val tvEndTime = view.findViewById<TextView>(R.id.tvEndTime)
        val tvCurrentTime = view.findViewById<TextView>(R.id.tvCurrentTime)

        btnPrev.setOnClickListener {
            if(activity is FileViewerActivity){
                (activity as FileViewerActivity).prev()
            }
        }
        btnNext.setOnClickListener {
            if(activity is FileViewerActivity){
                (activity as FileViewerActivity).next()
            }
        }

        when {
            isVideo(filePath) -> {
                playerLayout.visibility = View.VISIBLE
                playerView.visibility = View.VISIBLE
                audioThumb.visibility = View.GONE
                imageView.visibility = View.GONE

                initPlayer(playerView, seekBar,tvEndTime,tvCurrentTime)

//                btnMute.setOnClickListener {
//                    isMuted = !isMuted
//                    player?.volume = if (isMuted) 0f else 1f
//                    btnMute.setImageResource(
//                        if (isMuted) R.drawable.ic_volume_off
//                        else R.drawable.ic_volume_on
//                    )
//                }
                btnPlayPause.setOnClickListener {
                    if (player?.isPlaying == true) {
                        player?.pause()
                        btnPlayPause.setImageResource(R.drawable.ic_play)
                    } else {
                        player?.play()
                        btnPlayPause.setImageResource(R.drawable.ic_pause)
                    }
                }
            }


            isAudio(filePath) -> {
                audioThumb.visibility = View.VISIBLE
                playerLayout.visibility = View.VISIBLE
                playerView.visibility = View.GONE
                imageView.visibility = View.GONE
                initPlayer(null, seekBar,tvEndTime,tvCurrentTime)

//                btnMute.setOnClickListener {
//                    isMuted = !isMuted
//                    player?.volume = if (isMuted) 0f else 1f
//                    btnMute.setImageResource(
//                        if (isMuted) R.drawable.ic_volume_off
//                        else R.drawable.ic_volume_on
//                    )
//                }

                btnPlayPause.setOnClickListener {
                    if (player?.isPlaying == true) {
                        player?.pause()
                        btnPlayPause.setImageResource(R.drawable.ic_play)
                    } else {
                        player?.play()
                        btnPlayPause.setImageResource(R.drawable.ic_pause)
                    }
                }
            }

            else -> {
                playerLayout.visibility = View.GONE
                imageView.visibility = View.VISIBLE
                Glide.with(this).load(filePath).into(imageView)
            }
        }
    }
    fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    private fun initPlayer(
        playerView: PlayerView?,
        seekBar: SeekBar,
        tvEndTime: TextView,
        tvCurrentTime: TextView,
    ) {
        player = ExoPlayer.Builder(requireContext()).build()
        playerView?.player = player

        player?.setMediaItem(MediaItem.fromUri(filePath))
        player?.prepare()

        player?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    val duration = player?.duration ?: 0
                    seekBar.max = player?.duration?.toInt() ?: 0
                    tvEndTime.text = formatTime(duration)
                    handler.post(updateSeek(seekBar))
                }
            }
        })

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    player?.seekTo(progress.toLong())
                }
                tvCurrentTime.text = formatTime(progress.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun updateSeek(seekBar: SeekBar) = object : Runnable {
        override fun run() {
            player?.let {
                seekBar.progress = it.currentPosition.toInt()
                handler.postDelayed(this, 500)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        player?.play()
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }

    companion object {
        fun newInstance(item: String) = MediaFragment().apply {
            arguments = bundleOf("file_path" to item)
        }
    }
}
