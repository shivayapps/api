package com.explorefile.filemanager.activities

import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityLockBinding
import com.explorefile.filemanager.helpers.Preferences
import com.explorefile.filemanager.fragments.LockFragment

class LockResetActivity : BaseActivity() {

    private val TAG = "LockResetActivity"
    var isShowPinLock = false

    lateinit var animation: Animation
    lateinit var preferences: Preferences

    private lateinit var binding: ActivityLockBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences = Preferences(this)

        isShowPinLock = preferences.getShowPINLock()
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)

        intView()
    }

    private fun intView() {

        loadFragment(
            LockFragment.getInstance(
                false,
                false,
                lockListener = {
                    if (it) {
                        setPasswordSuccess()
                    } else {
                        finish()
                    }
                }
            )
        )
    }


    private fun loadFragment(fragment: Fragment) {
        val fm = this.supportFragmentManager
        val fragmentTransaction = fm.beginTransaction()
        fragmentTransaction.replace(R.id.container_lock, fragment)
        fragmentTransaction.commit()
    }

    private fun setPasswordSuccess() {
        //startActivity(Intent(this, PrivateActivity::class.java))
        setResult(RESULT_OK)
        (this@LockResetActivity).finish()
    }
}