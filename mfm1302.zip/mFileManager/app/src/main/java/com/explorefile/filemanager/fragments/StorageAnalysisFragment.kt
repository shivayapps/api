package com.explorefile.filemanager.fragments

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.MainAnalysisFragmentBinding
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.updateTextColors
import com.explorefile.filemanager.filecleaner.viewmodel.StorageAnalysisVM
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.FileDirItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat
import kotlin.getValue
import kotlin.math.abs

class StorageAnalysisFragment(context: Context, attributeSet: AttributeSet) :
    MyViewPagerFragment<MyViewPagerFragment.AnalysisInnerBinding>(context, attributeSet) {


    private val vm: StorageAnalysisVM by (context as FragmentActivity).viewModels()

    private lateinit var binding: MainAnalysisFragmentBinding

    override fun onFinishInflate() {
        super.onFinishInflate()
        binding = MainAnalysisFragmentBinding.bind(this)
        innerBinding = AnalysisInnerBinding(binding)
    }

    override fun setupFragment(activity: BaseActivity) {
        if (this.activity == null) {
            this.activity = activity
        }
        binding.sabMain.setSegmentSpacing(10f)
        binding.sabMain.setRoundCap(true)
        binding.sabMain.setThick(22f)
        setupObservers()
        setupClickListeners()
    }

    override fun setupCategoriesBinding(activity: BaseActivity) {
    }

    override fun onResume(textColor: Int) {
        context.updateTextColors(binding.root)
        val properPrimaryColor = context.getProperPrimaryColor()

    }

    override fun refreshFragment() {
    }

    private fun setupObservers() {
        vm.startScanStorage()
        vm.scanResult.observe(activity!!) { result ->
            result?.stat?.let { stat ->
                val usedPercent = if (stat.totalSize != 0L)
                    (stat.usedSize * 100 / stat.totalSize).toInt()
                else 0
                binding.tvSaUsedPercentValue.text = "$usedPercent%"
                binding.tvSaStorageUsedSizeValue.text = formatSize(stat.usedSize) + " Used"
                binding.tvSaStorageTotalSizeValue.text = formatSize(stat.totalSize - stat.usedSize) + " Available"
            }

            result?.file?.let { file ->
                val totalSize = result.stat?.totalSize ?: 1L

                fun progressOf(size: Long): Int =
                    ((size * 100f) / totalSize).toInt()

                bindItem(
                    root = binding.itemImage.root,
                    iconRes = R.drawable.ic_scan_image,
                    title = "Images",
                    count = file.image.queueCount.get(),
                    size = file.image.queueSize.get(),
                    progress = progressOf(file.image.queueSize.get()),
                    color = Color.parseColor("#FF4E92")
                )

                bindItem(
                    root = binding.itemVideo.root,
                    iconRes = R.drawable.ic_scan_video,
                    title = "Videos",
                    count = file.video.queueCount.get(),
                    size = file.video.queueSize.get(),
                    progress = progressOf(file.video.queueSize.get()),
                    color = Color.parseColor("#6E88FF")
                )

                bindItem(
                    root = binding.itemAudio.root,
                    iconRes = R.drawable.ic_scan_audio,
                    title = "Audio",
                    count = file.audio.queueCount.get(),
                    size = file.audio.queueSize.get(),
                    progress = progressOf(file.audio.queueSize.get()),
                    color = Color.parseColor("#41BB83")
                )

                bindItem(
                    root = binding.itemDocument.root,
                    iconRes = R.drawable.ic_scan_document,
                    title = "Documents",
                    count = file.document.queueCount.get(),
                    size = file.document.queueSize.get(),
                    progress = progressOf(file.document.queueSize.get()),
                    color = Color.parseColor("#C46ED7")
                )

                bindItem(
                    root = binding.itemDownload.root,
                    iconRes = R.drawable.ic_scan_download,
                    title = "Downloads",
                    count = file.download.queueCount.get(),
                    size = file.download.queueSize.get(),
                    progress = progressOf(file.download.queueSize.get()),
                    color = Color.parseColor("#FF8000")
                )

                bindItem(
                    root = binding.itemCompressed.root,
                    iconRes = R.drawable.ic_scan_compressed,
                    title = "Compressed",
                    count = file.compressedApkFile.queueCount.get(),
                    size = file.compressedApkFile.queueSize.get(),
                    progress = progressOf(file.compressedApkFile.queueSize.get()),
                    color = Color.parseColor("#FBC919")
                )
            }

//            binding.tvSaScanCost.text = getString(R.string.scan_cost, result.file?.scanCost ?: 0)
            binding.tvSaScanCost.text =
                activity!!.getString(R.string.scan_cost, result.file?.scanCost?.toString() ?: "0")

            val listTests = vm.sabData.value?.map { it.first } ?: emptyList()
            val colorsTest = vm.sabData.value?.map { it.second } ?: emptyList()

            binding.sabMain.setColor(colorsTest)
            binding.sabMain.setData(listTests)

//            binding.sabMain.dataAndColorArray=vm.sabData.value
//            binding.sabMain.invalidate()
        }

        vm.sabData.observe(activity!!) {
            val listTests = it?.map { it.first } ?: emptyList()
            val colorsTest = it?.map { it.second } ?: emptyList()
            binding.sabMain.setColor(colorsTest)
            binding.sabMain.setData(listTests)

//            binding.sabMain.dataAndColorArray=it
//            binding.sabMain.invalidate()
        }
    }

    fun bindItem(
        root: View,
        iconRes: Int,
        title: String,
        count: Long,
        size: Long,
        progress: Int,
        color: Int
    ) {
        root.findViewById<ImageView>(R.id.iv_icon).apply {
            setImageResource(iconRes)
//            setColorFilter(color)
        }

        root.findViewById<TextView>(R.id.tv_title).text = title
        root.findViewById<TextView>(R.id.tv_count).text = "$count Files"
        root.findViewById<TextView>(R.id.tv_size).text = formatSize(size)

        root.findViewById<ProgressBar>(R.id.progress).apply {
            this.progress = progress
            // Apply color
            progressTintList = ColorStateList.valueOf(color)
            // If indeterminate, you might want:
            // indeterminateTintList = ColorStateList.valueOf(color)
        }
    }

    private fun setupClickListeners() {
//        binding.llSrImageSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrVideoSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrAudioSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrDocumentSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrDownloadFileSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrCompressedFileSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrEmptyDirSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrNoExtFileSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrUnknownExtFileSizeContainer.setOnClickListener {
//
//        }
//        binding.llSrOtherSizeContainer.setOnClickListener {
//
//        }
    }


    private fun formatSize(bytes: Long?): String {
        val size = bytes ?: return "0 B"
        if (size <= 0) return "0 B"

        val units = arrayOf("B", "kB", "MB", "GB", "TB")

        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
            .coerceIn(0, units.size - 1)

        val value = size / Math.pow(1024.0, digitGroups.toDouble())

        return "${DecimalFormat("#,##0.#").format(value)} ${units[digitGroups]}"
    }


    private fun formatCount(count: Int?): String {
        return count?.toString() ?: "0"
    }

//    override fun searchQueryChanged(text: String) {
//
//    }

//    override fun deleteFiles(files: ArrayList<FileDirItem>) {
//        //("Not yet implemented")
//    }
//
//    override fun selectedPaths(paths: ArrayList<String>) {
//        //("Not yet implemented")
//    }
//
//    override fun setupDateTimeFormat() {
//        //("Not yet implemented")
//    }
//
//    override fun toggleFilenameVisibility() {
//        //("Not yet implemented")
//    }
//
//    override fun columnCountChanged() {
//        ("Not yet implemented")
//    }
//
//    override fun finishActMode() {
//        //("Not yet implemented")
//    }

}