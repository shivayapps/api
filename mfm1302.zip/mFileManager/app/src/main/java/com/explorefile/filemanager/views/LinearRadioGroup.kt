package com.explorefile.filemanager.views

import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import com.explorefile.filemanager.R

class LinearRadioGroup(private val parent: ViewGroup) {

    private var selectedLayout: LinearLayout? = null
    private val items = mutableListOf<LinearLayout>()

    init {
        // Find all direct children (LinearLayouts)
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            if (child is LinearLayout) {
                items.add(child)
                child.setOnClickListener { select(child) }
            }
        }
    }

    private fun select(layout: LinearLayout) {
        items.forEach { l ->
//            val check = l.findViewById<ImageView>(R.id.check)
//            if (l == layout) {
//                check.setImageResource(R.drawable.ic_checkbox_checked)
//                selectedLayout = l
//            } else {
//                check.setImageResource(R.drawable.ic_checkbox_unchecked)
//            }
        }
    }

    fun getSelectedTag(): String? {
        return selectedLayout?.tag as? String
    }

    fun setSelectedByTag(tag: String) {
        val layout = items.find { it.tag == tag }
        layout?.let { select(it) }
    }
}

