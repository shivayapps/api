package com.explorefile.filemanager.wi_fi_direct

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import com.explorefile.filemanager.databinding.DialogScanBinding
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.setupDialogStuff

class ScanDialog(
    activity: Activity,
    val callback: (mode: Int) -> Unit
) {
    private var dialog: AlertDialog? = null

    init {
        val view = DialogScanBinding.inflate(activity.layoutInflater, null, false)

        val builder = activity.getAlertDialogBuilder()


        builder.apply {
            activity.setupDialogStuff(
                view.root,
                this
            ) { alertDialog ->
                dialog = alertDialog
            }
        }

        view.llScan.setOnClickListener {
            dialog?.dismiss()
            callback(0)
        }
        view.llWrite.setOnClickListener {
            dialog?.dismiss()
            callback(1)
        }
    }

}
