package com.explorefile.filemanager.models

enum class Android30RenameFormat {
    SAF,
    CONTENT_RESOLVER,
    NONE
}
