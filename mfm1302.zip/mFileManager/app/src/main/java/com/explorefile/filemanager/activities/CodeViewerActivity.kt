package com.explorefile.filemanager.activities

import android.graphics.Color
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityCodeViewerBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.NavigationIcon
import java.io.File

class CodeViewerActivity : BaseActivity() {

    private var filePath = ""
    private var fileName = ""
    private var fileType = ""

    val binding by viewBinding(ActivityCodeViewerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        filePath = intent?.getStringExtra("filePath").toString()
        fileName = intent?.getStringExtra("fileName").toString()
        fileType = intent?.getStringExtra("fileType").toString()
        initActions()
        getDataUpdateUi()

        setupToolbar()
    }

    fun initActions() {

        // Change default font to JetBrains Mono font
        val jetBrainsMono = ResourcesCompat.getFont(this, R.font.poppins_medium)
        binding.codeView.setTypeface(jetBrainsMono)
        binding.codeView.setEnableLineNumber(true)
        binding.codeView.setLineNumberTextColor(Color.GRAY)
        binding.codeView.setLineNumberTextSize(25f)
        binding.codeView.setEnableHighlightCurrentLine(true)
        binding.codeView.setHighlightCurrentLineColor(Color.GRAY)
        binding.codeView.setTabLength(4)
        binding.codeView.setEnableAutoIndentation(true)
        binding.codeView.setVerticalScrollBarEnabled(true);
        binding.codeView.setMovementMethod(ScrollingMovementMethod.getInstance());

    }

    override fun onResume() {
        super.onResume()
        setupToolbar(binding.codeviewerToolbar, NavigationIcon.Arrow)
        updateTopBarColors(binding.codeviewerToolbar, getProperBackgroundColor())
    }

    private fun setupToolbar() {
        binding.codeviewerToolbar.title = fileName
    }

    private fun getDataUpdateUi() {
        filePath = intent?.getStringExtra("filePath").toString()
        fileName = intent?.getStringExtra("fileName").toString()
        fileType = intent?.getStringExtra("fileType").toString()

        try {
            val codeString = readLargeFile(filePath)
            binding.codeView.setText(codeString.toString())
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to open document.", Toast.LENGTH_SHORT).show()
        }
    }

//    fun readFileAsText(path: String): String {
//        return File(path).readText(Charsets.UTF_8)
//    }

    fun readLargeFile(path: String): StringBuilder {
        val sb = StringBuilder()
        File(path).useLines { lines ->
            lines.forEach { sb.appendLine(it) }
        }
        return sb
    }

}