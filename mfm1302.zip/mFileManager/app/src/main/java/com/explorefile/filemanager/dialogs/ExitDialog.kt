package com.explorefile.filemanager.dialogs

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.DialogExitBinding
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.setupDialogStuff

class ExitDialog(
    activity: Activity,
    val cancelOnTouchOutside: Boolean = true,
    val callback: () -> Unit
) {
    private var dialog: AlertDialog? = null

    init {
        val view = DialogExitBinding.inflate(activity.layoutInflater, null, false)

        val builder = activity.getAlertDialogBuilder()
        view.txtOk.setOnClickListener {
            dialogConfirmed()
        }

        view.txtCancel.setOnClickListener {
            dialog?.dismiss()
        }

        builder.apply {
            activity.setupDialogStuff(
                view.root,
                this,
                cancelOnTouchOutside = cancelOnTouchOutside
            ) { alertDialog ->
                dialog = alertDialog
            }
        }
    }

    private fun dialogConfirmed() {
        dialog?.dismiss()
        callback()
    }
}
