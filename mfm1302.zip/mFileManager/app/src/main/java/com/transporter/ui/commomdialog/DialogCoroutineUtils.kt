package com.transporter.ui.commomdialog

import androidx.fragment.app.FragmentManager
import com.transporter.main.dialog.BaseDialogFragment
import com.transporter.main.dialog.DialogCancelableResultCallback
import com.transporter.main.dialog.DialogForceResultCallback
import kotlinx.coroutines.CancellableContinuation
import java.lang.ref.WeakReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class CoroutineDialogCancelableResultCallback<T : Any>(
    val cont: CancellableContinuation<T?>
) : DialogCancelableResultCallback<T> {
    override fun onCancel() {
        if (cont.isActive) {
            cont.resume(null)
        }
    }

    override fun onResult(t: T) {
        if (cont.isActive) {
            cont.resume(t)
        }
    }

}

class CoroutineDialogForceResultCallback<T : Any>(
    val cont: CancellableContinuation<T>
) : DialogForceResultCallback<T> {

    override fun onResult(t: T) {
        if (cont.isActive) {
            cont.resume(t)
        }
    }

    override fun onError(e: String) {
        if (cont.isActive) {
            cont.resumeWithException(Throwable(e))
        }
    }

}

fun FragmentManager.coroutineShowSafe(dialog: BaseDialogFragment, tag: String, cont: CancellableContinuation<*>): Boolean {
    return if (!isDestroyed) {
        dialog.showSafe(this, tag)
        val wd = WeakReference(dialog)
        cont.invokeOnCancellation {
            if (!isDestroyed) {
                wd.get()?.dismissAllowingStateLoss()
            }
        }
        true
    } else {
        false
    }
}