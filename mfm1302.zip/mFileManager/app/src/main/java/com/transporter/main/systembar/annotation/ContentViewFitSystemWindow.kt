package com.transporter.main.systembar.annotation

@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.CLASS)
annotation class ContentViewFitSystemWindow()
