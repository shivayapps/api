package com.transporter.ui.filetransport

class MyImagesFragment : BaseMediaFragment(Companion.MediaType.Image)