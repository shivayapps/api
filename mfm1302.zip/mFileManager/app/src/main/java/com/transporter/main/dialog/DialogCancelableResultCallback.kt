package com.transporter.main.dialog

interface DialogCancelableResultCallback<T : Any> {
    fun onResult(t: T)
    fun onCancel()

}