package com.transporter.ui.filetransport

import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.content.getSystemService
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.MessageFragmentBinding
import com.explorefile.filemanager.databinding.MessageItemLayoutBinding
import com.transporter.logs.AndroidLog
import com.transporter.net.transferproto.fileexplore.FileExplore
import com.transporter.net.transferproto.fileexplore.requestMsgSuspend
import com.transporter.main.adapter.impl.builders.SimpleAdapterBuilderImpl
import com.transporter.main.adapter.impl.databinders.DataBinderImpl
import com.transporter.main.adapter.impl.datasources.DataSourceImpl
import com.transporter.main.adapter.impl.viewcreatators.SingleItemViewCreatorImpl
import com.transporter.main.fragment.BaseCoroutineStateFragment
import com.transporter.main.view.clicks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MessageFragment : BaseCoroutineStateFragment<Unit>(
    Unit
) {
    override val layoutId: Int = R.layout.message_fragment

    private val inputMethodManager: InputMethodManager by lazy {
        requireActivity().getSystemService<InputMethodManager>()!!
    }

    private val fileExplore: FileExplore by lazy {
        (requireActivity() as FileTransportTransportActivity).fileExplore
    }

    override fun CoroutineScope.firstLaunchInitDataCoroutine() {  }

    private val messageDataSource: DataSourceImpl<FileTransportTransportActivity.Companion.Message> by lazy {
        DataSourceImpl()
    }

    override fun CoroutineScope.bindContentViewCoroutine(contentView: View) {
        val viewBinding = MessageFragmentBinding.bind(contentView)
        val context = requireActivity() as FileTransportTransportActivity

        viewBinding.messageRv.adapter = SimpleAdapterBuilderImpl<FileTransportTransportActivity.Companion.Message>(
            itemViewCreator = SingleItemViewCreatorImpl(R.layout.message_item_layout),
            dataSource = messageDataSource,
            dataBinder = DataBinderImpl { data, view, _ ->
                val itemViewBinding = MessageItemLayoutBinding.bind(view)
                val isRemote = data.fromRemote
                if (isRemote) {
                    itemViewBinding.remoteMessageTv.visibility = View.VISIBLE
                    itemViewBinding.myMessageTv.visibility = View.GONE
                    itemViewBinding.remoteMessageTv.text = data.msg
                } else {
                    itemViewBinding.remoteMessageTv.visibility = View.GONE
                    itemViewBinding.myMessageTv.visibility = View.VISIBLE
                    itemViewBinding.myMessageTv.text = data.msg
                }
            }
        ).build()

        launch {
            context.observeMessages()
                .map { it.reversed() }
                .distinctUntilChanged()
                .flowOn(Dispatchers.Main.immediate)
                .collect {
                    messageDataSource.submitDataList(it) {
                        if (it.isNotEmpty()) {
                            viewBinding.messageRv.scrollToPosition(0)
                        }
                    }
                }
        }

        viewBinding.sendLayout.clicks(this) {
            val text = viewBinding.editText.text.toString()
            if (text.isNotEmpty()) {
                withContext(Dispatchers.IO) {
                    runCatching {
                        fileExplore.requestMsgSuspend(text)
                    }.onSuccess {
                        context.updateNewMessage(
                            FileTransportTransportActivity.Companion.Message(
                                time = System.currentTimeMillis(),
                                msg = text,
                                fromRemote = false
                            )
                        )
                        AndroidLog.d(TAG, "Send msg success.")
                        withContext(Dispatchers.Main) {
                            viewBinding.editText.text?.clear()
                        }
                    }.onFailure {
                        AndroidLog.e(TAG, "Send msg fail: $it", it)
                    }
                }
            }
        }

        launch {
            context.stateFlow()
                .map { it.selectedTabType }
                .distinctUntilChanged()
                .flowOn(Dispatchers.Main)
                .collect {
                    inputMethodManager.hideSoftInputFromWindow(viewBinding.editText.windowToken, 0)
                }
        }

        ViewCompat.setOnApplyWindowInsetsListener(viewBinding.editLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            // SoftKeyboard
            val imeBars = insets.getInsets(WindowInsetsCompat.Type.ime())
            if (imeBars.bottom > 0) {
                // If soft keyboard show, scroll to first.
                launch {
                    val messages = context.observeMessages().first()
                    if (messages.isNotEmpty()) {
                        viewBinding.messageRv.scrollToPosition(0)
                    }
                }
                v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, imeBars.bottom)
            } else {
                // soft keyboard hide.
                v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, systemBars.bottom)
            }
            insets
        }
    }

    companion object {
        private const val TAG = "MessageFragment"
    }

}