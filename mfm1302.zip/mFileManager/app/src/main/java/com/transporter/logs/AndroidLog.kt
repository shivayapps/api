package com.transporter.logs

import android.util.Log
import com.transporter.net.ILog

object AndroidLog : ILog {

    override fun d(tag: String, msg: String) {
        Log.d(tag, msg)
    }

    override fun e(tag: String, msg: String, throwable: Throwable?) {
        Log.e(tag, msg, throwable)
    }

}