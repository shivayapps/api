package com.transporter.ui.qrcodescan

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ScanQrcodeActivityBinding
import com.transporter.logs.AndroidLog
import com.transporter.main.activity.BaseCoroutineStateTransportActivity
import com.transporter.main.permission.permissionsRequestSimplifySuspend
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

class ScanQrCodeTransportActivity : BaseCoroutineStateTransportActivity<Unit>(defaultState = Unit) {

    val TAG = "ScanQrCodeActivity"
    override val layoutId = R.layout.scan_qrcode_activity

    override fun CoroutineScope.firstLaunchInitDataCoroutine() {}

    override fun CoroutineScope.bindContentViewCoroutine(contentView: View) {
        val binding = ScanQrcodeActivityBinding.bind(contentView)
        launch {
            if (permissionsRequestSimplifySuspend(Manifest.permission.CAMERA)) {
                startScanAnimation(binding)
                setupCamera(binding)
            } else {
                AndroidLog.e(TAG, "Camera permission denied.")
                finish()
            }
        }
    }

    private fun startScanAnimation(binding: ScanQrcodeActivityBinding) {
        binding.scanLineView.post {
            val animation = TranslateAnimation(
                0f,
                0f,
                0f,
                binding.scanLineView.measuredWidth.toFloat()
            ).apply {
                duration = 1000
                repeatCount = Animation.INFINITE
                repeatMode = Animation.REVERSE
            }
            binding.scanLineView.startAnimation(animation)
        }
    }

    private suspend fun setupCamera(binding: ScanQrcodeActivityBinding) {
        val cameraProvider = withContext(Dispatchers.IO) {
            ProcessCameraProvider.getInstance(this@ScanQrCodeTransportActivity).get()
        }
        val preview = Preview.Builder().build().apply {
            setSurfaceProvider(binding.previewView.surfaceProvider)
        }

        val analysis = createAnalyzer()

        try {
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                this@ScanQrCodeTransportActivity,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                analysis
            )
        } catch (e: Exception) {
            AndroidLog.e(TAG, "Camera start error: ${e.message}", e)
        }
    }

    private fun createAnalyzer(): ImageAnalysis {
        val options =
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        val scanner = BarcodeScanning.getClient(options)
        val hasScanned = AtomicBoolean(false)

        return ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setBackgroundExecutor(Dispatchers.IO.asExecutor())
            .build().apply {
                setAnalyzer(Dispatchers.IO.asExecutor()) { imageProxy ->
                    val bitmap = imageProxy.toBitmap()
                    val inputImage =
                        InputImage.fromBitmap(bitmap, imageProxy.imageInfo.rotationDegrees)
                    if (!hasScanned.get()) {
                        scanner.process(inputImage)
                            .addOnSuccessListener { results ->
                                results?.firstOrNull()?.rawValue?.let {
                                    if (hasScanned.compareAndSet(false, true)) {
                                        handleSuccess(results)
                                    }
                                }

                            }
                            .addOnFailureListener {
                                AndroidLog.e(TAG, "QR scan error: ${it.message}")
                            }
                            .addOnCompleteListener {
                                imageProxy.close()
                            }
                    } else {
                        imageProxy.close()
                    }
                }
            }
    }

    val QR_CODE_RESULT_KEY = "QR_CODE_RESULT_KEY"
    private fun handleSuccess(barcodes: List<Barcode>) {
        runOnUiThread {
            vibrate()
            val result = Intent().apply {
                putExtra(QR_CODE_RESULT_KEY, barcodes.map { it.rawValue }.toTypedArray())
            }
            setResult(Activity.RESULT_OK, result)
            finishWithNoAnimation()
        }
    }

    private fun vibrate() {
//        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
//            getSystemService<VibratorManager>()?.defaultVibrator
//        } else {
//            getSystemService<Vibrator>()
//        }
//        vibrator?.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun finishWithNoAnimation() {
        finish()
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
//            overrideActivityTransition(Activity.OVERRIDE_TRANSITION_CLOSE, 0, 0, 0)
//        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//            overridePending
//        }
    }

    companion object {
        private const val TAG = "ScanQrCodeActivity"
        private const val QR_CODE_RESULT_KEY = "QR_CODE_RESULT_KEY"

        fun getResult(data: Intent): List<String> {
            return (data.getStringArrayExtra(QR_CODE_RESULT_KEY) ?: emptyArray()).toList()
        }
    }
}
