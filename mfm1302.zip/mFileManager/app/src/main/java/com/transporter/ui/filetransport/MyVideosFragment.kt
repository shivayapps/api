package com.transporter.ui.filetransport

class MyVideosFragment : BaseMediaFragment(Companion.MediaType.Video)