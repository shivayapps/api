package com.transporter.main.adapter.impl.builders

import androidx.recyclerview.widget.RecyclerView
import com.transporter.main.adapter.AdapterBuilder
import com.transporter.main.adapter.DataBinder
import com.transporter.main.adapter.DataSource
import com.transporter.main.adapter.DataSourceParent
import com.transporter.main.adapter.ItemViewCreator
import com.transporter.main.Internal

class SimpleAdapterBuilderImpl<Data : Any>(
    override val itemViewCreator: ItemViewCreator<Data>,
    override val dataSource: DataSource<Data>,
    override val dataBinder: DataBinder<Data>,
) : AdapterBuilder<Data> {

    @Internal
    override var isBuilderConsumed: Boolean = false
    override fun build(): RecyclerView.Adapter<*> {
        return SimpleAdapterImpl(this)
    }

    @Internal
    override var attachedRecyclerView: RecyclerView? = null
    @Internal
    override var dataSourceParent: DataSourceParent<Data>? = null
}