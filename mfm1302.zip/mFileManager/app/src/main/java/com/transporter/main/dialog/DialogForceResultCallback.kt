package com.transporter.main.dialog

interface DialogForceResultCallback<T : Any> {
    fun onResult(t: T)

    fun onError(e: String)

}