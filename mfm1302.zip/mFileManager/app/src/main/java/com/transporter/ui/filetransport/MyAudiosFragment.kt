package com.transporter.ui.filetransport

class MyAudiosFragment : BaseMediaFragment(Companion.MediaType.Audio)