package com.transporter.main.adapter

import android.view.View
import android.view.ViewGroup
import com.transporter.main.Internal

@Internal
interface ItemViewCreator<Data : Any> : AdapterBuilderLife<Data> {


    fun getItemViewType(positionInDataSource: Int, data: Data): Int?

    fun createItemView(parent: ViewGroup, itemViewType: Int): View
}