package com.ro.hith.imagic.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.ro.hith.imagic.screens.commonscreen.adapter.MediaItem


class App : MultiDexApplication() {
    companion object {
        var displayListItem: ArrayList<MediaItem> = ArrayList()
        lateinit var appContext: Context

    }

    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext
    }
}