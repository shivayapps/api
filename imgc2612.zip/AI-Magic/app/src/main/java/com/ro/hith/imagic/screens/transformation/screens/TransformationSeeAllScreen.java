package com.ro.hith.imagic.screens.transformation.screens;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.databinding.ActivityTransformationSeeAllScreenBinding;
import com.ro.hith.imagic.screens.extension.ExtensionsKt;
import com.ro.hith.imagic.screens.transformation.adapters.TransformationCharacterAdapter;
import com.ro.hith.imagic.screens.transformation.models.TransformationCharacterItem;
import com.ro.hith.imagic.screens.utils.transformation.TransformationDataLoader;

public class TransformationSeeAllScreen extends AppCompatActivity implements TransformationCharacterAdapter.OnItemClickListener {

    private ActivityTransformationSeeAllScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTransformationSeeAllScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());

        binding.onBackButton.setOnClickListener(v -> finish());

        TransformationDataLoader.setUpTransformationRecyclerview(TransformationSeeAllScreen.this, binding.tranformationRecyclerview, this);
    }

    @Override
    public void onItemClick(TransformationCharacterItem item, String imageUrl) {
//        Intent resultIntent = new Intent();
//        resultIntent.putExtra("SELECTED_IMAGE_URL", imageUrl);
//        resultIntent.putExtra("SELECTED_CHARACTER_ITEM", item);
//        setResult(RESULT_OK, resultIntent);
//        finish();
        Intent intent = new Intent(this, TransformationImageUploadScreen.class);
        intent.putExtra("transformationItem", item);
        intent.putExtra("selectedImageUrl", imageUrl);
        startActivity(intent);
        overridePendingTransition(R.anim.cusotm_slide_in_right, R.anim.custom_slide_out_left);
        finish();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}