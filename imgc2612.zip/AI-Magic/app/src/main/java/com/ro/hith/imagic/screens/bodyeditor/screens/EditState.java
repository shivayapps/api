package com.ro.hith.imagic.screens.bodyeditor.screens;

import android.graphics.Bitmap;

public class EditState {

    Bitmap bitmap;
    int progress;

    EditState(Bitmap bitmap, int progress) {
        this.bitmap = bitmap;
        this.progress = progress;
    }
}
