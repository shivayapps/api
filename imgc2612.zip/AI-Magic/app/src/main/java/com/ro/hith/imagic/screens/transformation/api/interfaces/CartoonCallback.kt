package com.ro.hith.imagic.screens.transformation.api.interfaces

import okhttp3.ResponseBody
import retrofit2.Response

interface CartoonCallback {
    fun onCartoonSuccess(response: Response<ResponseBody>)
    fun onCartoonError(errorMessage: String)
    fun onCartoonNetworkError()
    fun onCartoonUnknownError()
}