package com.ro.hith.imagic.screens.commonscreen.data

data class DrawableItem(
    val drawableRes: Int
)
