package com.ro.hith.imagic.screens.onboardingflow.core

import android.view.View
import android.widget.ImageView
import com.ro.hith.imagic.R

fun applyParallaxEffect(page: View, position: Float) {
    val parallaxView = page.findViewById<ImageView?>(R.id.img) ?: return

    when {
        position <= 1 -> parallaxView.translationX = -position * (page.width / 2)
    }
}