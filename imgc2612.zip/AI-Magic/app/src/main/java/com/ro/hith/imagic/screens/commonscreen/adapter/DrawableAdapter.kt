package com.ro.hith.imagic.screens.commonscreen.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.ro.hith.imagic.R

class DrawableAdapter(
    private val items: List<Int>,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<DrawableAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.thumbnailImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_drawable, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val drawableRes = items[position]
        holder.image.setImageResource(drawableRes)
        holder.image.setOnClickListener {
            onClick(drawableRes)
        }
    }

    override fun getItemCount() = items.size
}
