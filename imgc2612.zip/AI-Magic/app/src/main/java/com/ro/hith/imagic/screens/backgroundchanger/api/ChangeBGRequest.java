package com.ro.hith.imagic.screens.backgroundchanger.api;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.ro.hith.imagic.R;
import com.ro.hith.imagic.screens.callback.ApiCallback;
import com.ro.hith.imagic.screens.callback.ResponseCallBack;
import com.ro.hith.imagic.screens.commonscreen.screen.BgResultScreen;
import com.ro.hith.imagic.screens.singletone.CustomDialogManager;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

import kotlin.Pair;

public class ChangeBGRequest {

    private final String TAG = "RemoveBGRequest";
    private static ChangeBGRequest instance;
    private Activity context;
    private ResponseCallBack apiCallback;

    private ChangeBGRequest(Activity context, ResponseCallBack apiCallback) {
//        this.context = context.getApplicationContext();
        this.context = context;
        this.apiCallback = apiCallback;
    }

    public static synchronized ChangeBGRequest getInstance(Activity context, ResponseCallBack apiCallback) {
        if (instance == null) {
            instance = new ChangeBGRequest(context,apiCallback);
        }
        return instance;
    }

    public void makeRequest() {
        if (context == null) {
            System.out.println("Error: Context is null");
            return;
        }

        UploadRequest request = new UploadRequest()
                .withTemplateId("672c665d7c7e776a018d4071")
                .withAppName("NaturePhotoFramesandEditor")
                .withCountryCode("IN")
                .withPlatform("android")
                .withFcmToken("asd")
                .withFirebaseAppCheck("asd")
                .withSourceImage(new File(PhotoUploadManager.getInstance().getCurrentImageUriStringPath()));

        RemoveBGApiClient.getInstance().uploadImage(request, new ApiCallback() {
            @Override
            public void onSuccess(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    String requestIdFromResponse = jsonResponse.optString("request_id", "default_id");

                    final String numericRequestId = requestIdFromResponse.replaceAll("[^\\d.]", "").trim();

                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
                            showToastOnUiThread("Upload successful: " + numericRequestId);
                            processToNextScreen(numericRequestId);
                        }
                    }, 10000);

                } catch (JSONException e) {
                    Log.e(TAG, "Error parsing JSON response: " + e.getMessage());
                    final String fallbackId = String.valueOf(System.currentTimeMillis());
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "response:===========> " + response);
                            showToastOnUiThread("Upload successful with fallback ID");
                            showNoServer();
                        }
                    }, 10000);
                }
            }

            @Override
            public void onError(String errorMessage) {
                Log.d(TAG, "onError:===========> " + errorMessage);
                showToastOnUiThread("Upload failed: " + errorMessage);
                showNoServer();
                apiCallback.onError(errorMessage);
            }

            @SuppressWarnings("unchecked")
            private void processToNextScreen(String requestId) {
                Log.d(TAG, "Generate face swap button clicked");
                StartActivityGlobally.navigateToActivityWithFeature(
                        context,
                        BgResultScreen.class,
                        new Pair<>(AppConfig.INTENT_REQ_ID_FOR_GET_RESULT, requestId),
                        new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_CHANGE_BG)
                );
//                ((Activity)context).finish();
                apiCallback.onSuccess(requestId);

            }
        });
    }

    private void showNoServer() {
        if (context != null) {
            Handler handler = new Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Log.e("showNoServer", "005");
                    CustomDialogManager.getInstance().showDialog(
                            context,
                            "No Server",
                            "We are unable to connect to the server at this time. Please check your internet connection and try again",
                            "Got it",
                            R.drawable.ic_brush,
                            new CustomDialogManager.DialogButtonClickListener() {
                                @Override
                                public void onButtonClicked() {
                                    ((Activity) context).finish();
                                }
                            }
                    );

                }
            });
        }
    }

    private void showToastOnUiThread(final String message) {
        if (context != null) {
            Handler handler = new Handler(context.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, message, Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    public void setContext(Activity context) {
//        this.context = context.getApplicationContext();
        this.context = context;
    }
}