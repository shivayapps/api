package com.ro.hith.imagic.screens.utils

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.viewpager.widget.ViewPager

open class MyViewPager : ViewPager {

    private var enabled = false
    fun isPagingEnabled() = enabled
    fun setPagingEnabled(enabled: Boolean) {
        this.enabled = enabled
    }

    init {
        enabled = true
    }

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)


    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        return try {
            if (enabled) super.onInterceptTouchEvent(ev)
            else false
        } catch (ignored: Exception) {
            false
        }
    }

    /*  override fun onTouchEvent(ev: MotionEvent): Boolean {
          return try {
              if(enabled) super.onTouchEvent(ev)
              else false
          } catch (ignored: Exception) {
              false
          }
      }*/

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        return try {
            if (enabled) {
                super.onTouchEvent(ev)
            } else {
                false
            }
        } catch (ignored: Exception) {
            false
        }
    }
}