// Couple.java
package com.ro.hith.imagic.screens.aivideos;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.ro.hith.imagic.databinding.FragmentCoupleBinding;
import com.ro.hith.imagic.screens.commonscreen.screen.CommonProcessing;
import com.ro.hith.imagic.screens.fragments.BaseUploadFragment;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

import kotlin.Pair;

public class Couple extends BaseUploadFragment {
    private FragmentCoupleBinding binding;

    public Couple() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCoupleBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.coupleUpload.setOnClickListener(v -> {
            photoUploadManager.startPhotoUpload(requireActivity(), AppConfig.FEATURE_COUPLE, AppConfig.FEATURE_COUPLE);
        });

        binding.generateButton.setOnClickListener(v -> {
            if (binding.couplePhoto.getDrawable() != null) {
                generateResult();
            }
        });
    }

    @Override
    protected void handlePhotoUploaded(Uri imageUri, String uploadType) {
        if (AppConfig.FEATURE_COUPLE.equals(uploadType)) {
            Glide.with(requireContext())
                    .load(imageUri.getPath())
                    .into(binding.couplePhoto);
        }
    }


    @SuppressWarnings("unchecked")
    private void generateResult() {
        StartActivityGlobally.navigateToActivityWithFeature(
                requireActivity(),
                CommonProcessing.class,
                new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_AI_VIDEO_SINGLE)
        );
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}