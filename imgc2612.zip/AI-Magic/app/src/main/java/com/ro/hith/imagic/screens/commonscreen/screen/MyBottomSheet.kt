package com.ro.hith.imagic.screens.commonscreen.screen

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.ro.hith.imagic.R
import com.ro.hith.imagic.screens.commonscreen.adapter.DrawablePagerAdapter
import com.ro.hith.imagic.screens.commonscreen.data.DrawableCategory
import com.ro.hith.imagic.screens.commonscreen.data.OnDrawableSelectedListener

class MyBottomSheet : BottomSheetDialogFragment(), OnDrawableSelectedListener {

    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.bottomsheet_layout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewPager = view.findViewById(R.id.viewPager)
        tabLayout = view.findViewById(R.id.tabLayout)

        setupViewPager()
    }

    private fun setupViewPager() {
        val pagerAdapter = DrawablePagerAdapter(this) // ⚠️ use `this`, not requireActivity()
        viewPager.adapter = pagerAdapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = pagerAdapter.getTitle(position)
        }.attach()
    }

    private var activityCallback: OnDrawableSelectedListener? = null
    override fun onAttach(context: Context) {
        super.onAttach(context)
        activityCallback = context as? OnDrawableSelectedListener
    }

    override fun onDetach() {
        super.onDetach()
        activityCallback = null
    }

    override fun onDrawableSelected(
        category: DrawableCategory,
        drawableRes: Int
    ) {
        activityCallback?.onDrawableSelected(category, drawableRes)
    }
}
