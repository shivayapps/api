package com.ro.hith.imagic.screens.commonscreen.data

interface OnDrawableSelectedListener {
    fun onDrawableSelected(
        category: DrawableCategory,
        drawableRes: Int
    )
}
