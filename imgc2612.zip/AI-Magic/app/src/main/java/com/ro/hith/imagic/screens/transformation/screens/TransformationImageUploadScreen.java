package com.ro.hith.imagic.screens.transformation.screens;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.ro.hith.imagic.R;
import com.ro.hith.imagic.databinding.ActivityTransformationImageUploadScreenBinding;
import com.ro.hith.imagic.screens.commonscreen.screen.CommonProcessing;
import com.ro.hith.imagic.screens.extension.ExtensionsKt;
import com.ro.hith.imagic.screens.singletone.PhotoUploadManager;
import com.ro.hith.imagic.screens.transformation.models.TransformationCharacterItem;
import com.ro.hith.imagic.screens.utils.appconfig.AppConfig;
import com.ro.hith.imagic.screens.utils.appconfig.StartActivityGlobally;

import kotlin.Pair;

public class TransformationImageUploadScreen extends AppCompatActivity implements PhotoUploadManager.PhotoUploadCallback {

    private static final String UPLOAD_TYPE_TRANS_FACE_SWAP = "trans_face_swap";
    private static final String TAG = "TransformationImageUploadScreen";
    private static final int REQUEST_SELECT_CHARACTER = 1001;

    private ActivityTransformationImageUploadScreenBinding binding;
    private PhotoUploadManager photoUploadManager;
    private Uri uploadedImageUri;
    private String selectedCharacterImageUrl;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityTransformationImageUploadScreenBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ExtensionsKt.applySystemBarInsets(binding.getRoot());
        photoUploadManager = PhotoUploadManager.getInstance();
        Log.d(TAG, "Activity created");

        setupClickListeners();
        handleIntentData();
    }

    private void setupClickListeners() {
        binding.buttonBack.setOnClickListener(v -> finish());

        binding.uplodedImage.setOnClickListener(v -> {
            Log.d(TAG, "Upload image clicked");

            photoUploadManager.startPhotoUpload(
                    TransformationImageUploadScreen.this,
                    AppConfig.FEATURE_TRANSE_FACE_SWAP,
                    UPLOAD_TYPE_TRANS_FACE_SWAP
            );

        });


        binding.linearLayout.findViewById(R.id.generateButton).setOnClickListener(v -> {
            if (uploadedImageUri != null && selectedCharacterImageUrl != null) {
                if (photoUploadManager.getCurrentImageUri() != null) {
                    generateFaceSwap();
                } else {
                    Toast.makeText(this, "Select Image First", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(TransformationImageUploadScreen.this, "Cannot generate - missing " +
                        "uploaded image or character " +
                        "selection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleIntentData() {
        Intent intent = getIntent();
        if (intent != null) {
            if (intent.hasExtra("selectedImageUrl")) {
                selectedCharacterImageUrl = intent.getStringExtra("selectedImageUrl");
                loadCharacterImage(selectedCharacterImageUrl);
            }

            if (intent.hasExtra("transformationItem")) {
                TransformationCharacterItem item = intent.getParcelableExtra("transformationItem");
                if (item != null && item.model != null) {
                    selectedCharacterImageUrl = item.model.output_url;
                    loadCharacterImage(selectedCharacterImageUrl);
                }
            }
        }
    }

    private void loadCharacterImage(String imageUrl) {
        runOnUiThread(() -> {
            try {
                Glide.with(this)
                        .load(imageUrl)
                        .centerCrop()
                        .into(binding.selectedImageFaceSwap);
                Log.d(TAG, "Character image loaded: " + imageUrl);
            } catch (Exception e) {
                Log.e(TAG, "Error loading character image: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SELECT_CHARACTER && resultCode == RESULT_OK) {
            if (data != null) {
                selectedCharacterImageUrl = data.getStringExtra("SELECTED_IMAGE_URL");
                if (selectedCharacterImageUrl != null) {
                    loadCharacterImage(selectedCharacterImageUrl);
                }

                // You can also get the full item if needed
                TransformationCharacterItem item = data.getParcelableExtra("SELECTED_CHARACTER_ITEM");
                if (item != null) {
                    Log.d(TAG, "Selected character: " + item.subCategory);
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: Setting callback to this activity");
        photoUploadManager.setCallback(this);

        // Check if we already have an image URI from a previous upload
        Uri existingUri = photoUploadManager.getCurrentImageUri();
        String uploadType = photoUploadManager.getCurrentUploadType();
        String feature = photoUploadManager.getCurrentFeature();

        if (existingUri != null && UPLOAD_TYPE_TRANS_FACE_SWAP.equals(uploadType) && AppConfig.FEATURE_TRANSE_FACE_SWAP.equals(feature)) {
            Log.d(TAG, "Found existing image URI: " + existingUri);
            onPhotoUploaded(existingUri, feature, uploadType);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: Removing callback");
        if (photoUploadManager.getCallback() == this) {
            photoUploadManager.setCallback(null);
        }
    }

    @Override
    public void onPhotoUploaded(Uri imageUri, String feature, String uploadType) {
        Log.d(TAG, "onPhotoUploaded called - URI: " + imageUri + ", Feature: " + feature + ", Type: " + uploadType);

        if (UPLOAD_TYPE_TRANS_FACE_SWAP.equals(uploadType) && AppConfig.FEATURE_TRANSE_FACE_SWAP.equals(feature)) {
            uploadedImageUri = imageUri;
            runOnUiThread(() -> {
                Log.d(TAG, "Loading image into ImageView: " + imageUri);
                try {
                    Glide.with(this)
                            .load(imageUri.getPath())
                            .centerCrop()
                            .into(binding.uplodedImage);
                    Log.d(TAG, "Glide image load attempted");
                } catch (Exception e) {
                    Log.e(TAG, "Error loading image with Glide: " + e.getMessage());
                    e.printStackTrace();

                    try {
                        binding.uplodedImage.setImageURI(imageUri);
                        Log.d(TAG, "Fallback: setImageURI attempted");
                    } catch (Exception ex) {
                        Log.e(TAG, "Fallback also failed: " + ex.getMessage());
                    }
                }
            });
        }
    }

    @SuppressWarnings("unchecked")
    private void generateFaceSwap() {
        Log.d(TAG, "Generate face swap button clicked");
        Log.d(TAG, "Uploaded image URI: " + uploadedImageUri);
        Log.d(TAG, "Selected character image URL: " + selectedCharacterImageUrl);
        StartActivityGlobally.navigateToActivityWithFeature(
                TransformationImageUploadScreen.this,
                CommonProcessing.class,
                new Pair<>(AppConfig.INTENT_FEATURED_PASSED_AS, AppConfig.FEATURE_TRANSE_FACE_SWAP)
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
        Log.d(TAG, "Activity destroyed");
    }
}