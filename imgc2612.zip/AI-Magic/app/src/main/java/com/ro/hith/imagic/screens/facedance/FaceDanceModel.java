package com.ro.hith.imagic.screens.facedance;

import java.util.Map;

public class FaceDanceModel {
     final String user_type;
     final String url;
     final Map<String, String> cat_name_localised;

    public FaceDanceModel(String url, String user_type, Map<String, String> cat_name_localised) {
        this.url = url;
        this.user_type = user_type != null ? user_type : "non_pro";
        this.cat_name_localised = cat_name_localised;
    }

    public String getUserType() {
        return user_type;
    }

    public String getUrl() {
        return url;
    }

    public Map<String, String> getNameMap() {
        return cat_name_localised;
    }
}
