package com.ro.hith.imagic.screens.facedance.api.get;

import android.content.Context;
import android.widget.ProgressBar;
import android.widget.VideoView;

import com.ro.hith.imagic.screens.callback.VideoResponseCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class FaceDanceVideoApiClient {
    private static FaceDanceVideoApiClient instance;
    private final OkHttpClient httpClient;

    private FaceDanceVideoApiClient() {
        httpClient = new OkHttpClient();
    }

    public static synchronized FaceDanceVideoApiClient getInstance() {
        if (instance == null) {
            instance = new FaceDanceVideoApiClient();
        }
        return instance;
    }

    public void downloadVideo(Context context, String appName, String videoId,
                              ProgressBar loadingProgressBar, ProgressBar progressBar,
                              VideoView videoView, VideoResponseCallback callback) {
        String url = String.format("https://facedance.aapthi.in/livepotrait_results/download/%s/%s",
                appName, videoId);

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("accept", "application/json")
                .build();

        httpClient.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        // Create a temporary file to save the video
                        File videoFile = createTempVideoFile(context, "downloaded_video", ".mp4");
                        saveVideoToFile(response, videoFile, callback);
                        callback.onSuccess(videoFile);
                    } catch (IOException e) {
                        callback.onError("File error: " + e.getMessage());
                    }
                } else {
                    callback.onError("API error: " + response.code());
                }
            }
        });
    }

    private File createTempVideoFile(Context context, String prefix, String suffix) throws IOException {
        File cacheDir = context.getCacheDir();
        return File.createTempFile(prefix, suffix, cacheDir);
    }

    private void saveVideoToFile(Response response, File outputFile, VideoResponseCallback callback) throws IOException {
        InputStream inputStream = null;
        FileOutputStream outputStream = null;

        try {
            inputStream = response.body().byteStream();
            outputStream = new FileOutputStream(outputFile);

            byte[] buffer = new byte[4096];
            long totalBytes = response.body().contentLength();
            long downloadedBytes = 0;
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
                downloadedBytes += bytesRead;

                if (totalBytes > 0) {
                    int progress = (int) ((downloadedBytes * 100) / totalBytes);
                    callback.onProgress(progress);
                }
            }

            outputStream.flush();

        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
        }
    }
}