package com.ro.hith.imagic.screens.commonscreen.data

enum class DrawableCategory {
    SOLID,
    GRADIENT,
    TRENDING
}
