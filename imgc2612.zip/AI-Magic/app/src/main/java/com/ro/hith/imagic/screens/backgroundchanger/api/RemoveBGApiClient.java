package com.ro.hith.imagic.screens.backgroundchanger.api;


import android.util.Log;

import com.ro.hith.imagic.screens.callback.ApiCallback;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RemoveBGApiClient {
    private static final String TAG = "RemoveBGApiClient";
    private static final String BASE_URL = "https://faceswapmagic.com/upload";
    private static RemoveBGApiClient instance;
    private OkHttpClient client;

    private RemoveBGApiClient() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(new LoggingInterceptor())
                .build();
    }

    public static synchronized RemoveBGApiClient getInstance() {
        if (instance == null) {
            instance = new RemoveBGApiClient();
        }
        return instance;
    }

    public void uploadImage(UploadRequest request, ApiCallback callback) {
        Log.d(TAG, "uploadImage() called");

        // Validate callback
        if (callback == null) {
            Log.e(TAG, "Callback cannot be null");
            throw new IllegalArgumentException("Callback cannot be null");
        }

        // Validate request
        if (request == null) {
            Log.e(TAG, "Request object is null");
            callback.onError("Request object cannot be null");
            return;
        }

        // Log request parameters
        logRequestParameters(request);

        // Validate required parameters
        if (!validateRequiredParameters(request, callback)) {
            return;
        }

        // Build URL with query parameters
        HttpUrl.Builder urlBuilder = HttpUrl.parse(BASE_URL).newBuilder();
        urlBuilder.addQueryParameter("template_id", request.getTemplateId());
        urlBuilder.addQueryParameter("app_name", request.getAppName());
        urlBuilder.addQueryParameter("country_code", request.getCountryCode());
        urlBuilder.addQueryParameter("platform", request.getPlatform());

        String url = urlBuilder.build().toString();
        Log.d(TAG, "Final URL: " + url);

        // Create multipart form data
        MultipartBody.Builder bodyBuilder = new MultipartBody.Builder()
                .setType(MultipartBody.FORM);

        // Add source image (required)
        if (request.getSourceImage() != null && request.getSourceImage().exists()) {
            bodyBuilder.addFormDataPart("sourceImage",
                    request.getSourceImage().getName(),
                    RequestBody.create(request.getSourceImage(), MediaType.parse("image/png")));
            Log.d(TAG, "Added source image: " + request.getSourceImage().getAbsolutePath());
        }

        RequestBody requestBody = bodyBuilder.build();

        // Build headers
        Headers.Builder headersBuilder = new Headers.Builder()
                .add("accept", "application/json")
                .add("Content-Type", "multipart/form-data");

        // Add optional headers
        if (request.getFcmToken() != null && !request.getFcmToken().trim().isEmpty()) {
            headersBuilder.add("fcmtoken", request.getFcmToken());
            Log.d(TAG, "Added fcmtoken header");
        }

        if (request.getFirebaseAppCheck() != null && !request.getFirebaseAppCheck().trim().isEmpty()) {
            headersBuilder.add("x-firebase-appcheck", request.getFirebaseAppCheck());
            Log.d(TAG, "Added x-firebase-appcheck header");
        }

        Headers headers = headersBuilder.build();
        Log.d(TAG, "Request headers: " + headers.toString());

        // Build the request
        Request httpRequest = new Request.Builder()
                .url(url)
                .headers(headers)
                .post(requestBody)
                .build();

        Log.d(TAG, "Sending HTTP POST request...");

        // Execute the request
        client.newCall(httpRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Network request failed: " + e.getMessage(), e);
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    Log.d(TAG, "Received response. Code: " + response.code() + ", Message: " + response.message());
                    Log.d(TAG, "Response headers: " + response.headers().toString());

                    if (response.isSuccessful()) {
                        String responseBody = response.body() != null ? response.body().string() : "Empty response";
                        Log.d(TAG, "Success response: " + responseBody);
                        callback.onSuccess(responseBody);
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "HTTP error: " + response.code() + " - " + response.message() + ", Body: " + errorBody);
                        callback.onError("HTTP error: " + response.code() + " - " + response.message());
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error reading response: " + e.getMessage(), e);
                    callback.onError("Error reading response: " + e.getMessage());
                } finally {
                    if (response != null) {
                        response.close();
                    }
                }
            }
        });
    }

    private boolean validateRequiredParameters(UploadRequest request, ApiCallback callback) {
        // Validate template ID
        if (request.getTemplateId() == null || request.getTemplateId().trim().isEmpty()) {
            Log.e(TAG, "Template ID is required");
            callback.onError("Template ID is required");
            return false;
        }

        // Validate template ID format (optional but good to check)
        if (!isValidObjectId(request.getTemplateId())) {
            Log.w(TAG, "Template ID format may be invalid: " + request.getTemplateId());
        }

        // Validate app name
        if (request.getAppName() == null || request.getAppName().trim().isEmpty()) {
            Log.e(TAG, "App name is required");
            callback.onError("App name is required");
            return false;
        }

        // Validate country code
        if (request.getCountryCode() == null || request.getCountryCode().trim().isEmpty()) {
            Log.e(TAG, "Country code is required");
            callback.onError("Country code is required");
            return false;
        }

        // Validate platform
        if (request.getPlatform() == null || request.getPlatform().trim().isEmpty()) {
            Log.e(TAG, "Platform is required");
            callback.onError("Platform is required");
            return false;
        }

        // Validate source image
        if (request.getSourceImage() == null) {
            Log.e(TAG, "Source image is required");
            callback.onError("Source image is required");
            return false;
        }

        if (!request.getSourceImage().exists()) {
            Log.e(TAG, "Source image file does not exist: " + request.getSourceImage().getAbsolutePath());
            callback.onError("Source image file does not exist");
            return false;
        }

        // Validate image file size (optional but recommended)
        long fileSize = request.getSourceImage().length();
        if (fileSize == 0) {
            Log.e(TAG, "Source image file is empty");
            callback.onError("Source image file is empty");
            return false;
        }

        // Check if file size is reasonable (e.g., less than 10MB)
        long maxFileSize = 10 * 1024 * 1024; // 10MB
        if (fileSize > maxFileSize) {
            Log.e(TAG, "Source image file is too large: " + fileSize + " bytes");
            callback.onError("Source image file is too large (max 10MB)");
            return false;
        }

        return true;
    }

    private boolean isValidObjectId(String id) {
        // MongoDB ObjectId validation (24 character hex string)
        return id != null && id.matches("^[a-fA-F0-9]{24}$");
    }

    private void logRequestParameters(UploadRequest request) {
        Log.d(TAG, "Request parameters:");
        Log.d(TAG, "Template ID: " + request.getTemplateId());
        Log.d(TAG, "App Name: " + request.getAppName());
        Log.d(TAG, "Country Code: " + request.getCountryCode());
        Log.d(TAG, "Platform: " + request.getPlatform());
        Log.d(TAG, "FCM Token: " + (request.getFcmToken() != null ? "Provided" : "Not provided"));
        Log.d(TAG, "Firebase AppCheck: " + (request.getFirebaseAppCheck() != null ? "Provided" : "Not provided"));

        if (request.getSourceImage() != null) {
            Log.d(TAG, "Source Image: " + request.getSourceImage().getAbsolutePath() +
                    " (Exists: " + request.getSourceImage().exists() +
                    ", Size: " + request.getSourceImage().length() + " bytes)");
        } else {
            Log.d(TAG, "Source Image: Not provided");
        }
    }

    public void cancelAllRequests() {
        client.dispatcher().cancelAll();
        Log.d(TAG, "All ongoing requests cancelled");
    }

    public boolean hasOngoingRequests() {
        return client.dispatcher().runningCallsCount() > 0;
    }

    public int getOngoingRequestsCount() {
        return client.dispatcher().runningCallsCount();
    }

//    public interface ApiCallback {
//        void onSuccess(String response);
//
//        void onError(String errorMessage);
//    }

    private static class LoggingInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();

            long startTime = System.nanoTime();
            Log.d(TAG, String.format("Sending request %s on %s%n%s",
                    request.url(), chain.connection(), request.headers()));

            Response response = chain.proceed(request);

            long endTime = System.nanoTime();
            Log.d(TAG, String.format("Received response for %s in %.1fms%nStatus: %d %s%nHeaders: %s",
                    response.request().url(),
                    (endTime - startTime) / 1e6d,
                    response.code(),
                    response.message(),
                    response.headers()));

            return response;
        }
    }
}