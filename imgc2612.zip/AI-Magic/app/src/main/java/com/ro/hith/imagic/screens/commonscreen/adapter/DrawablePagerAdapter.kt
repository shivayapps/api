package com.ro.hith.imagic.screens.commonscreen.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.ro.hith.imagic.screens.commonscreen.data.DrawableCategory
import com.ro.hith.imagic.screens.commonscreen.screen.DrawableListFragment

class DrawablePagerAdapter(fragment: Fragment) :
    FragmentStateAdapter(fragment) {

    private val categories = listOf(
        DrawableCategory.SOLID,
        DrawableCategory.GRADIENT,
        DrawableCategory.TRENDING
    )

    override fun getItemCount() = categories.size

    override fun createFragment(position: Int): Fragment {
        return DrawableListFragment.newInstance(categories[position])
    }

    fun getTitle(position: Int): String {
        return categories[position].name.lowercase()
            .replaceFirstChar { it.uppercase() }
    }
}
