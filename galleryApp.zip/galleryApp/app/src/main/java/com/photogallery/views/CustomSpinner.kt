package com.photogallery.views

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import androidx.appcompat.widget.ListPopupWindow

open class CustomSpinner : androidx.appcompat.widget.AppCompatSpinner {

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    private var mOpenInitiated = false
    lateinit var listPopupWindow: ListPopupWindow
    lateinit var onPopUpClosedListener: (dropDownMenu: CustomSpinner) -> Unit
    lateinit var onPopUpOpenedListener: (dropDownMenu: CustomSpinner) -> Unit

    init {

        try {

            // get the listPopupWindow
            val listPopupWindowField =
                androidx.appcompat.widget.AppCompatSpinner::class.java.getDeclaredField("mPopup")
            listPopupWindowField.isAccessible = true
            listPopupWindow = listPopupWindowField.get(this) as ListPopupWindow
            listPopupWindow.isModal = false

        } catch (e: Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        if (hasBeenOpened() && hasFocus) {
            performClosedEvent()
        }
    }

    private fun performClosedEvent() {
        if (::onPopUpClosedListener.isInitialized) {
            onPopUpClosedListener.invoke(this)
        }
    }

    open fun hasBeenOpened(): Boolean {
        return mOpenInitiated
    }

    override fun performClick(): Boolean {
        val returnValue = super.performClick()
        mOpenInitiated = true
        // indicate that the pop-up was opened
        if (::onPopUpOpenedListener.isInitialized) {
            onPopUpOpenedListener.invoke(this)
        }

//        try {
//
//            // get the popupWindow
//            val popupWindowField = ListPopupWindow::class.java.getDeclaredField("mPopup")
//            popupWindowField.isAccessible = true
//            val popupWindow = popupWindowField.get(listPopupWindow) as PopupWindow
//
//            // get the original onDismissListener
//            val onDismissListenerField =
//                PopupWindow::class.java.getDeclaredField("mOnDismissListener")
//            onDismissListenerField.isAccessible = true
//            val onDismissListener =
//                onDismissListenerField.get(popupWindow) as PopupWindow.OnDismissListener
//
//            // now override the original OnDismissListener
//            listPopupWindow.setOnDismissListener {
//
//                // indicate that the pop-up was closed
//                if (::onPopUpClosedListener.isInitialized) {
//                    onPopUpClosedListener.invoke(this)
//                }
//
//                // now we need to call the original listener that will remove the global OnLayoutListener
//                onDismissListener.onDismiss()
//            }
//
//        } catch (e: Exception) {
//            Log.e("printStackTrace","printStackTrace:$e")
//        }

        return returnValue
    }

}