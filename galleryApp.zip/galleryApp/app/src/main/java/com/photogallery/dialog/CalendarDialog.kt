package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import androidx.core.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import com.photogallery.calendardaterangepicker.customviews.CalendarListener
import com.photogallery.R
import com.photogallery.databinding.DialogCalendarBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT

import com.photogallery.utils.Preferences
import java.util.Calendar
import java.util.Locale

class CalendarDialog(
    var mContext: Activity,
    var selectedTime: Long = 0L,
    val updateListener: (startDate: Calendar,endDate: Calendar) -> Unit,
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogCalendarBinding
    lateinit var preferences: Preferences

    lateinit var pickEndDate:Calendar
    lateinit var pickStartDate:Calendar

//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogCalendarBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog.root
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogCalendarBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {
        preferences = Preferences(mContext)

        selectedTime = Calendar.getInstance(Locale.ENGLISH).timeInMillis

//        bindingDialog.activityMainViewCustomCalendar.setOnDateSelectedListener { date ->
//            val cal = Calendar.getInstance(Locale.ENGLISH)
//            cal.set(Calendar.DATE, date.day)
//            cal.set(Calendar.MONTH, date.month)
//            cal.set(Calendar.YEAR, date.year)
//
//            selectedTime = cal.timeInMillis
//        }

        bindingDialog.cdrvCalendar.setCalendarListener(object : CalendarListener {
            override fun onFirstDateSelected(startDate: Calendar) {
                pickStartDate=startDate
            }

            override fun onDateRangeSelected(startDate: Calendar, endDate: Calendar) {
                pickEndDate=endDate
                pickStartDate=startDate
//                updateListener.invoke(startDate,endDate)
            }
        })


        intListener()
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            bindingDialog.cdrvCalendar.resetAllSelectedViews()
//            bindingDialog.activityMainViewCustomCalendar.buildCalendarView()
            //dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            dismiss()
            updateListener.invoke(pickStartDate,pickEndDate)
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}