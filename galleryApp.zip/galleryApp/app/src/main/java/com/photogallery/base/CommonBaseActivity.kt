package com.photogallery.base

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.photogallery.utils.sendEvent

open class CommonBaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    fun requestStoragePermission(okayEvent: String, cancelEvent: String, activityName: String, callback: (Boolean) -> Unit) {
        callback.invoke(true)
//        if (checkStorePermission()) {
//            callback.invoke(true)
//        } else {
//            val dialog = StoragePermissionDialog(this, cancelCallBack = {
//                logEvent(cancelEvent, activityName)
//                callback.invoke(false)
//            }, okCallBack = {
//                logEvent(okayEvent, activityName)
//                requestAllFilePermission(callback)
//            })
//            dialog.show()
//        }
    }

    fun checkStorePermission(): Boolean {
        //return Environment.isExternalStorageManager()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val result = ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            )
            val result1 = ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED
        }
    }

    var storagePermissionCallback: ((Boolean) -> Unit)? = null
    var storagePermissionDialogCallback: ((Boolean) -> Unit)? = null
    private fun requestAllFilePermission(callback: (Boolean) -> Unit) {
        storagePermissionCallback = callback
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.addCategory("android.intent.category.DEFAULT")
            intent.data = Uri.parse("package:$packageName")
            AdsConfig.isSystemDialogOpen = true
            storagePermissionLauncher.launch(intent)
        } catch (e: Exception) {
            val intent = Intent()
            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
            AdsConfig.isSystemDialogOpen = true
            storagePermissionLauncher.launch(intent)
        }

    }

    private val storagePermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (checkStorePermission()) {
            storagePermissionCallback?.invoke(true)
//            EventBus.getDefault().post("refresh_media")
            sendEvent("refresh_media")
        } else {
            storagePermissionCallback?.invoke(false)
        }
    }
}