package com.photogallery.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.databinding.ItemAlbumGridBinding
import com.photogallery.databinding.ItemAlbumListBinding
import com.photogallery.databinding.ItemHeaderDividerBinding
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences
import com.photogallery.databinding.LayoutTopBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.loadImage
import com.photogallery.model.MediaData

class AlbumListAdapter(
    var context: Context,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val utilClickListener: ((utilPos: Int) -> Unit)? = null,
) : ListAdapter<AlbumData, RecyclerView.ViewHolder>(DiffCallBack()) {

    private class DiffCallBack : DiffUtil.ItemCallback<AlbumData>() {
        override fun areItemsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem
    }

    val ITEM_ALBUM_UTIL_TYPE = 1
    val ITEM_ALBUM_GRID_TYPE = 2
    val ITEM_ALBUM_LIST_TYPE = 3

    var preferences: Preferences = Preferences(context)

    var pinList: ArrayList<String> = ArrayList()

    init {
        pinList = preferences.getPinAlbumList()
    }

    fun updatePinList() {
        pinList = preferences.getPinAlbumList()
    }


//    fun getSelectedAlbum(): List<AlbumData> {
//        return currentList.filterIsInstance<AlbumData>()
//            .filter { it.isSelected }
//    }
//
//    fun getSelectedAlbumMedia(): Pair<Int, List<MediaData>> {
//        var albumCount = 0
//        val selectedMedia = currentList.flatMap { item ->
//            when (item) {
//                is AlbumData -> if (item.isSelected) {
//                    albumCount++; item.mediaData
//                } else emptyList()
//
//                else -> emptyList()
//            }
//        }
//        return Pair(albumCount, selectedMedia)
//    }
//
//    fun getSelectedMedia(): List<MediaData> {
//        val selectedMedia = currentList.flatMap { item ->
//            when (item) {
//                is AlbumData -> if (item.isSelected) {
//                    item.mediaData
//                } else emptyList()
//
//                else -> emptyList()
//            }
//        }
//        return selectedMedia
//    }

    override fun getItemViewType(position: Int): Int {
        return if (preferences.getShowGrid()) {

            if (getItem(position).isCustomAlbum && getItem(position).title.equals("utility")) {
                ITEM_ALBUM_UTIL_TYPE
            } else {
                ITEM_ALBUM_GRID_TYPE
            }
        } else {
            if (getItem(position).isCustomAlbum && getItem(position).title.equals("utility")) {
                ITEM_ALBUM_UTIL_TYPE
            } else {
                ITEM_ALBUM_LIST_TYPE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_ALBUM_GRID_TYPE) {
            val binding =
                ItemAlbumGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumGridViewHolder(binding)
        } else if (viewType == ITEM_ALBUM_LIST_TYPE) {
            val binding =
                ItemAlbumListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AlbumListViewHolder(binding)
        } else if (viewType == ITEM_ALBUM_UTIL_TYPE) {
            val binding = LayoutTopBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            UtilViewHolder(binding)
        } else {
            val binding = ItemHeaderDividerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        if (getItemViewType(position) == ITEM_ALBUM_GRID_TYPE) {
            val albumGridViewHolder = holder as AlbumGridViewHolder
            val albumData: AlbumData = getItem(position) as AlbumData

            if (pinList.contains(albumData.folderPath)) albumGridViewHolder.binding.icPin.visibility =
                View.VISIBLE
            else albumGridViewHolder.binding.icPin.visibility = View.GONE

            albumGridViewHolder.binding.txtTitle.text = albumData.title
            if (albumData.mediaData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text = "${albumData.mediaData.size}"

                context.loadImage(
                    path = albumData.mediaData[0].filePath,
                    target = albumGridViewHolder.binding.image,
                    signature = albumData.mediaData[0].getKey(),
                    onError = {
                        albumGridViewHolder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                        albumGridViewHolder.binding.image.setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_image_placeholder))
                    }
                )
                try {
                    albumGridViewHolder.binding.ivGif!!.beVisibleIf(
                        albumData.mediaData[0].filePath.endsWith(
                            "gif",
                            true
                        )
                    )
                } catch (e: Exception) {
                }
//                }
            } else {
                albumGridViewHolder.binding.txtCount.text = "0"
                albumGridViewHolder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            if (albumData.isCheckboxVisible && !albumData.isCustomAlbum) {

                if (albumData.isSelected){
                    albumGridViewHolder.binding.icUnSelect.beGone()
                    albumGridViewHolder.binding.icSelect.beVisible()
                }else {
                    albumGridViewHolder.binding.icUnSelect.beVisible()
                    albumGridViewHolder.binding.icSelect.beGone()
                }
//                albumGridViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                albumGridViewHolder.binding.icSelect.visibility =
//                    if (albumData.isSelected) View.VISIBLE else View.GONE
            } else {
                albumGridViewHolder.binding.icUnSelect.visibility = View.GONE
                albumGridViewHolder.binding.icSelect.visibility = View.GONE
//                albumGridViewHolder.binding.icFavourite.visibility =
//                    if (albumData.isFavorite) View.VISIBLE else View.GONE
            }

            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(position)
            }
            albumGridViewHolder.binding.root.setOnLongClickListener {
                longClickListener(position)
                true
            }
        } else if (getItemViewType(position) == ITEM_ALBUM_LIST_TYPE) {
            val albumGridViewHolder = holder as AlbumListViewHolder
            val albumData: AlbumData = getItem(position) as AlbumData

            if (pinList.contains(albumData.folderPath)) albumGridViewHolder.binding.icPin.visibility =
                View.VISIBLE
            else albumGridViewHolder.binding.icPin.visibility = View.GONE

            albumGridViewHolder.binding.txtTitle.text = albumData.title


            if (albumData.mediaData.isNotEmpty()) {
                albumGridViewHolder.binding.txtCount.text =
                    "${albumData.mediaData.size} ${context.getString(R.string.items)}"

                context.loadImage(
                    path = albumData.mediaData[0].filePath,
                    target = albumGridViewHolder.binding.image,
                    signature = albumData.mediaData[0].getKey(),
                    onError = {
                        albumGridViewHolder.binding.image.scaleType = ImageView.ScaleType.CENTER_CROP
                        albumGridViewHolder.binding.image.setImageDrawable(AppCompatResources.getDrawable(context, R.drawable.ic_image_placeholder))
                    }
                )
                try {
                    albumGridViewHolder.binding.ivGif.beVisibleIf(
                        albumData.mediaData[0].filePath.endsWith(
                            "gif",
                            true
                        )
                    )
                } catch (e: Exception) {
                }

            } else {
                albumGridViewHolder.binding.txtCount.text = "0 ${context.getString(R.string.items)}"
                albumGridViewHolder.binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            if (albumData.isCheckboxVisible && !albumData.isCustomAlbum) {

                if (albumData.isSelected){
                    albumGridViewHolder.binding.icUnSelect.beGone()
                    albumGridViewHolder.binding.icSelect.beVisible()
                }else {
                    albumGridViewHolder.binding.icUnSelect.beVisible()
                    albumGridViewHolder.binding.icSelect.beGone()
                }
//                albumGridViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                albumGridViewHolder.binding.icSelect.visibility =
//                    if (albumData.isSelected) View.VISIBLE else View.GONE
            } else {
                albumGridViewHolder.binding.icUnSelect.visibility = View.GONE
                albumGridViewHolder.binding.icSelect.visibility = View.GONE
            }

            albumGridViewHolder.binding.root.setOnClickListener {
                clickListener(position)
            }
            albumGridViewHolder.binding.root.setOnLongClickListener {
                longClickListener(position)
                true
            }
        } else if (getItemViewType(position) == ITEM_ALBUM_UTIL_TYPE) {
            val albumData: AlbumData = getItem(position) as AlbumData

            val albumHeaderViewHolder = holder as UtilViewHolder
//            albumHeaderViewHolder.binding.llRecent.setOnClickListener {
//                if (!albumData.isCheckboxVisible) utilClickListener?.invoke(0)
//            }
            albumHeaderViewHolder.binding.llAllVideo.setOnClickListener {
                if (!albumData.isCheckboxVisible) utilClickListener?.invoke(1)
            }
            albumHeaderViewHolder.binding.llFavorite.setOnClickListener {
                if (!albumData.isCheckboxVisible) utilClickListener?.invoke(2)
            }
            albumHeaderViewHolder.binding.llHidden.setOnClickListener {
                if (!albumData.isCheckboxVisible) utilClickListener?.invoke(4)
            }
            if (albumData.isCheckboxVisible) {
                albumHeaderViewHolder.binding.root.alpha = 0.5f
            } else {
                albumHeaderViewHolder.binding.root.alpha = 1.0f
            }
        }
    }

    class UtilViewHolder(var binding: LayoutTopBinding) : RecyclerView.ViewHolder(binding.root)
    class HeaderViewHolder(var binding: ItemHeaderDividerBinding) : RecyclerView.ViewHolder(binding.root)

    class AlbumGridViewHolder(var binding: ItemAlbumGridBinding) :
        RecyclerView.ViewHolder(binding.root)

    class AlbumListViewHolder(var binding: ItemAlbumListBinding) :
        RecyclerView.ViewHolder(binding.root)

    fun getBubbleText(adapterPosition: Int): String {
        return getItem(adapterPosition).title
    }

//    private fun getBubbleText(
//        albumData: AlbumData,
//        sorting: Int,
//        dateFormat: String? = null,
//        timeFormat: String? = null
//    ): String {
//        var strKey = ""
//
//        when (sorting) {
//            Constant.SORT_NAME -> strKey = albumData.title
//            Constant.SORT_PATH -> strKey = albumData.title
//            Constant.SORT_SIZE -> strKey = albumData.title
//            Constant.SORT_LAST_MODIFIED -> {
//                strKey = DateFormat.format("$dateFormat, $timeFormat", albumData.date).toString()
//            }
//            Constant.SORT_DATE_TAKEN -> {
//                strKey = DateFormat.format("$dateFormat, $timeFormat", albumData.date).toString()
//            }
//        }
//
//        Log.e("PictureAdapter", "getBubbleText.002:$sorting, $strKey")
//        return strKey
//    }

}