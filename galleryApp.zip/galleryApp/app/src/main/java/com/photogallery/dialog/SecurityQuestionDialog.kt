package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import androidx.core.content.ContextCompat
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.adapter.SpinnerQueAdapter
import com.photogallery.databinding.DialogSecurityQuestionBinding
import com.photogallery.extension.beGone
import com.photogallery.utils.DIALOG_DIM_AMOUNT
//import com.photogallery.secret.PrivateActivity
import com.photogallery.utils.Preferences
import kotlin.toString

class SecurityQuestionDialog(
    var mContext: Activity,
    var type: Int = 0,
    var isChangePass: Boolean = false,
    val updateListener: (isSuccess: Boolean) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogSecurityQuestionBinding
    var preferences: Preferences = Preferences(mContext)
    var isShowPinLock = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        bindingDialog = DialogSecurityQuestionBinding.inflate(layoutInflater)

        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }

    private fun intView() {
        isShowPinLock = preferences.getShowPINLock()

        val adapter = SpinnerQueAdapter(mContext, mContext.resources.getStringArray(R.array.security_question))
        bindingDialog.questionSpinner.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#222222"))
        bindingDialog.questionSpinner.adapter = adapter

        if (type == 1) {
            bindingDialog.questionSpinner.setSelection(preferences.getSecurityQuestion())
        }
//        else {
//            bindingDialog.btnCancel.beGone()
//        }

        if (isChangePass) {
            bindingDialog.securityAnswer.setText(preferences.getAnswerQuestion())
        }
    }

    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            if (isChangePass) {
                updateListener.invoke(false)
                dismiss()
            } else {
                //preferences.putIgnoreQuestion(true)
                updateListener.invoke(false)
                dismiss()
            }
        }

        bindingDialog.btnOK.setOnClickListener {
            val answer = bindingDialog.securityAnswer.text.toString()
            if (bindingDialog.questionSpinner.selectedItemPosition == 0)
                Toast.makeText(
                    mContext,
                    mContext.getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            else if (answer.isEmpty()) {
                Toast.makeText(
                    mContext,
                    mContext.getString(R.string.PleaseSelectQue),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                hideSoftKeyboard()
                if (isChangePass) {
                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)
                    Toast.makeText(
                        mContext,
                        mContext.getString(R.string.Question_change_successfully),
                        Toast.LENGTH_SHORT
                    ).show()

                    updateListener.invoke(true)
                    dismiss()
//                    setResult(AppCompatActivity.RESULT_OK)
//                    finish()
                } else if (!preferences.getSetQuestion()) {
                    preferences.putSetQuestion(true)
                    //preferences.putIgnoreQuestion(false)
                    preferences.putSecurityQuestion(bindingDialog.questionSpinner.selectedItemPosition)
                    preferences.putAnswerQuestion(answer)

                    updateListener.invoke(true)
                    dismiss()

                } else {
                    if (bindingDialog.questionSpinner.selectedItemPosition == preferences.getSecurityQuestion()) {
                        if (preferences.getAnswerQuestion().equals(answer)) {
                            if (preferences.getShowPINLock()) {
                                preferences.putSetPass(false)
                                preferences.putPass("")
                            } else {
                                preferences.putSetPattern(false)
                                preferences.putPattern("")
                            }
                            updateListener.invoke(true)
                            dismiss()
                        } else {
                            Toast.makeText(
                                mContext,
                                R.string.msg_security_ans,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else Toast.makeText(
                        mContext,
                        R.string.msg_security_que,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

        }

    }

    fun hideSoftKeyboard() {
        val inputMethodManager =
            mContext.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(bindingDialog.securityAnswer.windowToken, 0)
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

