package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.viewbinding.ViewBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.databinding.DialogCreateAlbumBinding
import com.photogallery.extension.toast
import com.photogallery.utils.Constant
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences
import java.io.File

class CreateAlbumDialog(
    var mContext: Context,
    val createPathListener: (path: String) -> Unit,
    var isOpenFromMenu: Boolean = false,
    val useDarkMode:Boolean?=false
) : Dialog(mContext) {

    var preferences: Preferences = Preferences(mContext)
    lateinit var bindingDialog: ViewBinding

//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogCreateAlbumBinding.inflate(layoutInflater, container, false)
//        if(useDarkMode!!) bindingDialog = DialogCreateAlbumDarkBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog.root
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogCreateAlbumBinding.inflate(layoutInflater)
//        if(useDarkMode!!) bindingDialog = DialogCreateAlbumDarkBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {
//        bindingDialog.icClear.visibility = View.GONE
        bindingDialog.root.findViewById<ImageView>(R.id.icClear).visibility = View.GONE
        intListener()
    }

    private fun intListener() {
//        bindingDialog.edtAlbumName.addTextChangedListener {
        bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).addTextChangedListener {
//            bindingDialog.icClear.visibility =
            bindingDialog.root.findViewById<ImageView>(R.id.icClear).visibility =
//                if (bindingDialog.edtAlbumName.text?.trim().toString()
                if (bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).text?.trim().toString()
                        .isNotEmpty()
                ) View.VISIBLE else View.GONE
        }

//        bindingDialog.icClear.setOnClickListener {
        bindingDialog.root.findViewById<ImageView>(R.id.icClear).setOnClickListener {
            bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).setText("")
//            bindingDialog.edtAlbumName.setText("")
        }
//        bindingDialog.btnCreate.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCreate).setOnClickListener {
            val albumName = bindingDialog.root.findViewById<EditText>(R.id.edtAlbumName).text.trim()
            if (albumName.isNotEmpty()) {

                var file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).path + File.separator + albumName)

                if(useDarkMode!!) {
                    file = File(Constant.HIDE_PATH+ File.separator + albumName)
                }
                if (!file.exists()) {
                    if (!isOpenFromMenu)
                        file.mkdirs()
                    dismiss()
//                    preferences.setLastAlBumCreated(file.path)
                    createPathListener.invoke(file.path)
                } else
                    mContext.toast(mContext.getString(R.string.create_validation2))
            } else

                mContext.toast(mContext.getString(R.string.create_validation))
        }
//        bindingDialog.btnCancel.setOnClickListener {
        bindingDialog.root.findViewById<TextView>(R.id.btnCancel).setOnClickListener {
            dismiss()
        }
    }

}