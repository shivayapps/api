package com.photogallery.customview

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import com.photogallery.utils.ZOOM_IN_THRESHOLD
import com.photogallery.utils.ZOOM_OUT_THRESHOLD
import kotlin.math.max
import kotlin.math.min

open class MediaRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : RecyclerView(context, attrs, defStyleAttr) {

    interface OnSpanCountChangedListener {
        fun onSpanCountChanged(newCount: Int)
    }

//    interface DragListener {
//        fun selectItem(position: Int)
//        fun selectRange(initialSelection: Int, lastDraggedIndex: Int, minReached: Int, maxReached: Int)
//    }

    private var minSpan = 1
    private var maxSpan = 4
    private var scaleGestureEnabled = false
    private var onSpanCountChangedListener: OnSpanCountChangedListener? = null

    private val scaleGestureDetector: ScaleGestureDetector
//    private val gridLayoutManager: GridLayoutManager

    private val gridLayoutManager: GridLayoutManager?
        get() = layoutManager as? GridLayoutManager

    // Drag selection variables
//    private var dragListener: DragListener? = null
//    private var initialSelection = -1
//    private var lastDraggedIndex = -1
//    private var minReached = -1
//    private var maxReached = -1
//    var dragSelectActive = false
//        private set

    private var lastSpanCount = gridLayoutManager?.spanCount ?: 3
    private var scaleFactorAccum = 1f

    init {
//        gridLayoutManager = GridLayoutManager(context, minSpan)
        layoutManager = gridLayoutManager
        (itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false

        scaleGestureDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (!scaleGestureEnabled) return false

                scaleFactorAccum *= detector.scaleFactor

                if (scaleFactorAccum > ZOOM_IN_THRESHOLD && lastSpanCount > minSpan) {
                    // Zoom in → reduce span count
                    updateSpanCount(lastSpanCount - 1)
                    scaleFactorAccum = 1f
                } else if (scaleFactorAccum < ZOOM_OUT_THRESHOLD && lastSpanCount < maxSpan) {
                    // Zoom out → increase span count
                    updateSpanCount(lastSpanCount + 1)
                    scaleFactorAccum = 1f
                }

//                val spanCount = gridLayoutManager.spanCount
//                val scaleFactor = detector.scaleFactor
//                val newSpanCount = when {
//                    scaleFactor > 1.05f -> max(minSpan, spanCount - 1)
//                    scaleFactor < 0.95f -> min(maxSpan, spanCount + 1)
//                    else -> spanCount
//                }
//                if (newSpanCount != spanCount) {
//                    gridLayoutManager.spanCount = newSpanCount
//                    onSpanCountChangedListener?.onSpanCountChanged(newSpanCount)
//                }
                return true
            }
        })
    }

    private fun updateSpanCount(newCount: Int) {
        if (newCount != lastSpanCount) {
            gridLayoutManager?.spanCount = newCount
//            requestLayout()
            lastSpanCount = newCount
            onSpanCountChangedListener?.onSpanCountChanged(newCount)
        }
    }

    fun setSpanRange(min: Int, max: Int) {
        minSpan = min
        maxSpan = max
        gridLayoutManager?.spanCount = max(minSpan, min(maxSpan, gridLayoutManager?.spanCount?:3))
    }

    fun setScaleGestureEnabled(enabled: Boolean) {
        scaleGestureEnabled = enabled
    }

    fun setOnSpanCountChangedListener(listener: (newCount: Int) -> Unit) {
        this.onSpanCountChangedListener = object : OnSpanCountChangedListener {
            override fun onSpanCountChanged(newCount: Int) {
                listener(newCount)
            }
        }
    }

//    fun setDragListener(listener: DragListener) {
//        this.dragListener = listener
//    }

//    fun activateDragSelection(startPosition: Int) {
////        dragSelectActive = true
////        initialSelection = startPosition
////        lastDraggedIndex = startPosition
////        minReached = startPosition
////        maxReached = startPosition
////        dragListener?.selectItem(startPosition)
//    }

//    fun stopDragSelection() {
////        dragSelectActive = false
////        initialSelection = -1
////        lastDraggedIndex = -1
////        minReached = -1
////        maxReached = -1
//    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleGestureDetector.onTouchEvent(e)

//        if (dragSelectActive) {
//            when (e.action) {
//                MotionEvent.ACTION_MOVE -> {
//                    val v = findChildViewUnder(e.x, e.y) ?: return true
//                    val position = getChildAdapterPosition(v)
//                    if (position != NO_POSITION && position != lastDraggedIndex) {
//                        lastDraggedIndex = position
//                        minReached = min(minReached, position)
//                        maxReached = max(maxReached, position)
//                        dragListener?.selectRange(initialSelection, lastDraggedIndex, minReached, maxReached)
//                    }
//                }
//                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
//                    stopDragSelection()
//                }
//            }
//            return true
//        }
        return super.onTouchEvent(e)
    }
}