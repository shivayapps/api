package com.photogallery.jobs

import android.content.Context
import android.os.Build
import android.os.Environment
import android.util.Log
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.extension.getParentFolder
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isVideoFast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

suspend fun Context.startRecoverMediaWorker() {
    RecoverMediaWorker.doWork(this)
}

object RecoverMediaWorker {

    //    var recoverMediaData: Map<String, List<MediaData>> = emptyMap()
    val recoverMediaData = ArrayList<MediaData>()
    private var isRecoverMediaRunning = false
//    var scanCounter: Int = 0
//    var largeSize = 0L

    suspend fun doWork(context: Context) {

//        val pictures = ArrayList<Any>()

        if (!isRecoverMediaRunning) {
            isRecoverMediaRunning = true

            if (Constant.recoverMediaData.isNotEmpty()) {
                setFilterLarge()
            } else {

                val dirPath: String = Environment.getExternalStorageDirectory().absolutePath
                Log.d("TAG", "doInBackground: path: $dirPath")
                checkFileOfDirectory(context,getFileList(dirPath))

//                val largefile = allMedia.filter { it.fileSize > 1e+7 }
                Log.e("Cleaner.LargeFileWorker", "largefile:${recoverMediaData.size}")

//                recoverMediaData = groupPhotoDataBySize(largefile.sortedBy { it.fileSize })
//                val bucketKeys: Set<String> = recoverMediaData.keys
//                val listFolderkeys = java.util.ArrayList(bucketKeys)
                recoverMediaData.reverse()
                Log.e("Cleaner.LargeFileWorker", "RealPhotoData 003 listFolderkeys:${recoverMediaData.size}")
//                for (index in listFolderkeys.indices) {
//                    var list = recoverMediaData[listFolderkeys[index]]
//                    val bucketData = AlbumData(
//                        title = listFolderkeys[index],
//                        folderPath = listFolderkeys[index],
//                        isCustomAlbum = true,
//                        isCheckboxVisible = true
//                    )
//                    list = list!!.sortedByDescending { it.fileSize }
//                    pictures.add(bucketData)
//                    pictures.addAll(list.toMutableList())
//                }

                Log.e("Cleaner.LargeFileWorker", "RealPhotoData recoverMediaData==>${recoverMediaData.size}")
//                val totalFileSize = recoverMediaData
//                    .filterIsInstance<MediaData>()
//                    .sumOf { it.fileSize }
//                largeSize = totalFileSize
                Constant.recoverMediaData = recoverMediaData
                setFilterLarge()
            }
        }
    }


    var i = 0
    fun checkFileOfDirectory(context: Context,fileArr: Array<File>?) {
        if (fileArr == null || !isRecoverMediaRunning) return

        for (i in fileArr.indices) {
            val numArr = arrayOfNulls<Int>(1)
            val i2 = this.i
            this.i = i2 + 1
            numArr[0] = i2

            if (fileArr[i].isDirectory
                && !fileArr[i].name.startsWith("data")
                && !fileArr[i].name.startsWith("obb")
                && !fileArr[i].name.startsWith("obj")
            ) {
                checkFileOfDirectory(context,getFileList(fileArr[i].path))
            } else {
                val file1 = File(fileArr[i].path)
                sendEvent("recover_media_path", file1.path)

                if (fileArr[i].path.contains("/.")
                    && !fileArr[i].path.contains(".Gallery/${Constant.HIDE_FOLDER_NAME}")
                    && !fileArr[i].path.contains(".Gallery/${Constant.RECENT_DELETE_FOLDER_NAME}")
                ) {
                    if (fileArr[i].isImageFast()) {
                        Log.d("TAG", "checkFileOfDirectory_isImageFast:" + fileArr[i].path)

                        val file = File(file1.path)
                        val recoverData = MediaData(
                            file.path,
                            Utils.getUriFromPath(context,file.path).toString(),
                            file.path.getFilenameFromPath(),
                            file.path.getParentFolder(),
                            file.lastModified(),
                            file.lastModified(),
                            file.length(),
                            isVideo = false
                        )
                        recoverMediaData.add(recoverData)
                        Constant.recoverMediaData = recoverMediaData

                        sendEvent("recover_media_data", recoverData)
                    } else if (fileArr[i].isVideoFast()) {
                        Log.d("TAG", "checkFileOfDirectory_isVideoFast:" + fileArr[i].path)
//                        dataBase.dataDao().insertRecoverEntity(
//                            RecoverData(
//                                0,
//                                file1.path,
//                                1,
//                            )
//                        )
                        val file = File(file1.path)
                        val recoverData = MediaData(
                            file.path,
                            Utils.getUriFromPath(context,file.path).toString(),
                            file.path.getFilenameFromPath(),
                            file.path.getParentFolder(),
                            file.lastModified(),
                            file.lastModified(),
                            file.length(),
                            isVideo = true
                        )
                        recoverMediaData.add(recoverData)
                        Constant.recoverMediaData = recoverMediaData
                        sendEvent("recover_media_data", recoverData)
                    }
                }
            }
        }
    }

    fun getFileList(str: String): Array<File>? {
        val file = File(str)
        return if (file.isDirectory) {
            file.listFiles()
        } else {
            null
        }
    }

    private fun setFilterLarge() {
        Log.e("Cleaner.LargeFileWorker", "setFilterDuplicate:001")
        val pictures = ArrayList<Any>()
        pictures.addAll(Constant.recoverMediaData)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            pictures.removeIf { item ->
                item is MediaData && !File(item.filePath).exists()
            }
        } else {
            val iterator = pictures.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item is MediaData && !File(item.filePath).exists()) {
                    iterator.remove()
                }
            }
        }

        //remove empty album
        val indicesToRemove = mutableListOf<Int>()
        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                var hasMediaData = false

                for (j in (i + 1) until pictures.size) {
                    if (pictures[j] is MediaData) {
                        hasMediaData = true
                    } else if (pictures[j] is AlbumData) {
                        break
                    }
                }
                if (!hasMediaData) {
                    indicesToRemove.add(i)
                }
            }
        }
        for (index in indicesToRemove.reversed()) {
            pictures.removeAt(index)
        }

        Constant.recoverMediaData = pictures

//        val ssSize = pictures.filterIsInstance<MediaData>().size
//        val totalFileSize = pictures
//            .filterIsInstance<MediaData>()
//            .sumOf { it.fileSize }
//        largeSize = totalFileSize
//        Log.e("Cleaner.DuplicateWorker", "largeSize:$largeSize")
//        updatePercentage()

//        val sizePair = Pair(totalFileSize.toLong(), ssSize.toInt())
        isRecoverMediaRunning = false
//        sendEvent("recover_media", sizePair)
        sendEvent("recover_media_complete")
    }

//    private fun updatePercentage() {
//        val percent: Float = 0f
//        Log.e("Cleaner.LargeFileWorker", "updatePercentage:${percent},$scanCounter")
//        sendEvent("recover_media_percent", percent)
//    }

}
