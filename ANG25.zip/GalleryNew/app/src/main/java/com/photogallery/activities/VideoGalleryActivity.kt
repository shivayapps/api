package com.photogallery.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.PorterDuff
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnPreDraw
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.photogallery.R
import com.photogallery.adapter.AlbumListAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityVideoAlbumBinding
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Preferences
import com.photogallery.databinding.PopBottomMenuBinding
import com.photogallery.dialog.AlbumDetailsDialog

import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.DisplayedColumnsDialog
import com.photogallery.dialog.FilterMediaDialog
import com.photogallery.dialog.GroupDialog

import com.photogallery.dialog.MainMenuDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.FolderRenameDialog
import com.photogallery.dialog.SortingOptionsDialog
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.toast
import com.photogallery.jobs.MediaLoaderX
import com.photogallery.utils.AdCache
import com.photogallery.utils.Constant
import com.photogallery.utils.FastScroller
import com.photogallery.utils.MAX_COLUMN_COUNT_ALBUM
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.PopupWindowHelper
//import com.photogallery.utils.TYPE_PORTRAITS
//import com.photogallery.utils.TYPE_RAWS
//import com.photogallery.utils.TYPE_SVGS
import com.photogallery.utils.Utils
import com.photogallery.utils.sendEvent

import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import kotlin.math.max
import kotlin.math.min

class


VideoGalleryActivity : BaseActivity() {

    var albumList: ArrayList<AlbumData> = ArrayList()
    var videoList: ArrayList<MediaData> = ArrayList()

    //    var albumWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()
//    var albumWisePictures: LinkedHashMap<String, ArrayList<MediaData>> = linkedMapOf()
    var albumAdapter: AlbumListAdapter? = null
    lateinit var preferences: Preferences
    var albumCount = 0

    var mediaLoader: MediaLoaderX? = null
    private var lastLongPressedItem = -1
    var selectedItem = 0
//    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    lateinit var activity: AppCompatActivity

    lateinit var binding: ActivityVideoAlbumBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            val interAdId = getString(R.string.inter_all)
            AdmobIntersAdImpl().load(this, interAdId)
        } else {
            checkReInter {
                if (it) {
                    val adId = getString(R.string.inter_all)
                    AdmobIntersAdImpl().load(this, adId)
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityVideoAlbumBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        loadBanner()
        activity = this@VideoGalleryActivity

        initView()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("refresh")) {
            getData()
        }
    }

    override fun onStart() {
        super.onStart()
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)

    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }

    private fun initView() {
        if (intent.hasExtra("title")) {
            binding.txtTitle.text = intent.getStringExtra("title")
        }

        mediaLoader = MediaLoaderX(
            this,
            sortOrder = preferences.getSortOrder("pref_0"),
            sortType = preferences.getSortType("pref_0"),
            prefKey = "pref_0",
            addCustomAlbum = false,
            loadImage = false
        )

        getData()
//        binding.swipeRefreshLayout.setOnRefreshListener {
//            if (binding.swipeRefreshLayout.isEnabled)
//                getData()
//            else
//                binding.swipeRefreshLayout.isRefreshing = false
//        }

        binding.root.doOnPreDraw {
            binding.albumRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    var firstPositon =
                        (binding.albumRecycler.layoutManager as MyGridLayoutManager).findFirstVisibleItemPosition()
//                    var lastPositon =
//                        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).findLastVisibleItemPosition()
                    //binding.ivScrollTop.beVisibleIf(firstPositon > 3)

//                    if (firstPositon > 0) {
//                        setBubbleText(albumAdapter?.getBubbleText(firstPositon)!!)
//                        binding.bubble.beVisible()
//                    } else {
//                        binding.bubble.beGone()
//                    }
                }
            })
        }

        intListener()
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        if (preferences.refreshMedia) {
            getData()
        }
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {
            val adId = getString(R.string.b_albumActivity)
            BannerAdHelper.showBanner(
                this, binding.layoutBanner.mFLAd, binding.llAdplace, adId,
                AdCache.albumAdView, { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.albumAdView = adView
                    isAdLoaded = isLoaded
                })
        }
    }

    private fun intListener() {

        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        binding.icMenu.setOnClickListener {
            showMenu()
        }

        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll

            setSelectClick(isSelectAll)
            setSelectAllColor()
        }

        binding.btnDelete.setOnClickListener {
//            requestStoragePermission(app_delete_AFA_allow_nf, app_delete_AFA_denied_nf, getActivityName()) {
//                if (it) {
            showDeleteDialog(getSelectedMedia())
//                }
//            }

        }
        binding.btnHide.setOnClickListener {
//            requestStoragePermission(app_private_AFA_allow_nf, app_private_AFA_denied_nf, getActivityName()) {
//                if (it) {
            setHideData()
//                }
//            }
        }

        binding.btnMore.setOnClickListener {
//            showMoreMenu()
            showDropDown(binding.btnMore)
        }
    }

    private fun getSelectedMedia(): ArrayList<MediaData> {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i].isSelected) {
                    val pictureList = albumList[i].mediaData
                    selectImage.addAll(pictureList)
                }
        }

//            selectImage.addAll(getSelectedAlbumPhotos())
        return selectImage
    }

    fun setHideData() {
        if (selectedItem == 0) {
            activity.toast(
                activity.getString(R.string.PleaseSelectImage),
            )
        } else {
            val hideDialog = ActionConfirmationDialog(
                activity,
                getString(R.string.Private),
                getString(R.string.hide_msg),
                getString(R.string.hide),
                positiveBtnClickListener = {
                    hidePhoto()
                })
            hideDialog.show()
        }
    }

    private fun hidePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i].isSelected) {
                    val pictureList = albumList[i].mediaData
                    selectImage.addAll(pictureList)
                }
        }

        Utils.hideFiles(activity, selectImage, selectedItem, hideListener = {
            toast(
                getString(R.string.hide_successfully)
            )
            selectedItem = 0
            preferences.refreshMedia = true
            longClickListener(false, 0, false)
            setCloseToolbar()
        })
    }

    private fun showMenu() {
        val dialog = MainMenuDialog(this, 1, clickListener = {
            when (it) {
                1 -> {//btnSortBy
                    showSortDialog()
                }

                2 -> {//btnGroup
                    showGroupByDialog()
                }

                3 -> {//btnFilterMedia

                    val filterMediaDialog = FilterMediaDialog(this@VideoGalleryActivity, updateListener = {
                        getData()
                    })
                    filterMediaDialog.show()
                }

                4 -> {
                    // displayed Columns
                    val displayColumnsDialog = DisplayedColumnsDialog(
                        this, folderPath = "pref_0",
                        true,
                        updateListener = {
                            setRvLayoutManager()
                            sendEvent("refresh_layoutmanager")
                        })
                    displayColumnsDialog.show()
                }

                21 -> {
                    setRvLayoutManager()
                    sendEvent("refresh_layoutmanager")
                }

                22 -> {
                    setRvLayoutManager()
                    setListGridData()
                    sendEvent("refresh_layoutmanager")
                }

                5 -> {
                    recycleLauncher.launch(Intent(this, RecentlyDeleteActivity::class.java))
                }

                6 -> {
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }
            }
        })
        dialog.show()
    }

    var recycleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

        }

    private fun showSortDialog() {
        val sortDialog = SortingOptionsDialog(this, folderPath = "pref_0", updateListener = {
            getData()
        })
        sortDialog.show()
    }

    private fun showGroupByDialog() {
        val groupDialog = GroupDialog(this, folderPath = "pref_0", updateListener = {
            getData()
        })
        groupDialog.show()
    }

    private fun showDropDown(view: View) {

        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)
        val popupWindow = PopupWindowHelper(popUpBinding.root)

        popUpBinding.menuRename.beVisibleIf(mSelectedItem == 1)
//        popUpBinding.menuCover.beVisibleIf(mSelectedItem == 1)

        popUpBinding.menuEdit.beGone()
        popUpBinding.menuSetAs.beGone()
//        popUpBinding.menuResize.beGone()
        //popUpBinding.menuExclude.beVisible()


        popUpBinding.menuAddFavourite.beGone()
        popUpBinding.menuRemoveFavourite.beGone()

        popUpBinding.menuInfo.beVisibleIf(mSelectedItem == 1)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuRename.setOnClickListener {
            popupWindow.dismiss()
            showRenameDialog()
        }

//        popUpBinding.menuCover.setOnClickListener {
//            popUpBinding.llMain.beGone()
//            popUpBinding.llCover.beVisible()
////            popupWindow.update()
//            popupWindow.dismiss()
//            popupWindow.showAsPopUp(view)
//
//        }
//        popUpBinding.selectPhoto.setOnClickListener {
//            popupWindow.dismiss()
//            if (mSelectedItem == 1) setCoverImage()
//        }
//        popUpBinding.useDefault.setOnClickListener {
//            popupWindow.dismiss()
//            if (mSelectedItem == 1) setDefaultCoverImage()
//        }


//        popUpBinding.menuExclude.setOnClickListener {
//            popupWindow.dismiss()
//            addToExclude()
//        }

        popUpBinding.menuInfo.setOnClickListener {
            popupWindow.dismiss()
            showDetailsDialog()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
            if (selectedItem == 0) {
                toast(getString(R.string.PleaseSelectAlbum))
            } else {

                val selectedAlbum = ArrayList<String>()
                val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                albumList.filter { it.isSelected }.forEach { album ->
                    selectedAlbum.add(album.folderPath) // Add selected album
                    album.mediaData.forEach { picture ->
                        if (picture is MediaData) {
                            selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                        }
                    }
                }
                showAddAlbumDialog(
                    Constant.deviceAlbumList,
                    selectImage,
                    selectedAlbum,
                    true
                )
            }
        }

        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
//            requestStoragePermission(app_move_to_AFA_allow_nf, app_move_to_AFA_denied_nf, getActivityName()) {
//                if (it) {

            if (selectedItem == 0) {
                toast(getString(R.string.PleaseSelectAlbum))
            } else {

                val selectedAlbum = ArrayList<String>()
                val selectImage = ArrayList<MediaData>() // Use a set to avoid duplicates
                albumList.filter { it.isSelected }.forEach { album ->
                    selectedAlbum.add(album.folderPath) // Add selected album
                    album.mediaData.forEach { picture ->
                        if (picture is MediaData) {
                            selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
                        }
                    }
                }
                showAddAlbumDialog(
                    Constant.deviceAlbumList,
                    selectImage,
                    selectedAlbum,
                    true
                )
            }
//                }
//            }
        }
        popupWindow.showAsPopUp(view)

    }

    fun showDetailsDialog() {
        val albumData = albumList.filter { it.isSelected }
        val detailsDialog =
            AlbumDetailsDialog(this, albumData[0], false)
        detailsDialog.show()
    }

//    fun setDefaultCoverImage() {
//        val albumData = albumList.firstOrNull { it.isSelected }
//        preferences?.setCoverImage(albumData!!.folderPath, "")
//        setCloseToolbar()
//    }
//    fun setCoverImage() {
//        val albumData = albumList.firstOrNull { it.isSelected }
//
//        val addAlbumDialog =
//            SelectAlbumImageFullDialog(
//                activity!!,
//                albumData!!.mediaData,
//                selectPathListener = { selectPath ->
//                    preferences?.setCoverImage(albumData.folderPath, selectPath)
//                    //setCopyMove(isCopy, selectPath, selectImage)
//                    setCloseToolbar()
//                },
//                createAlbumListener = {
//
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)
//
//    }

//    fun tryUnLockFolder() {
//        unlockFolder()
//    }
//
//    fun tryLockFolder() {
//        lockFolder()
//    }
//
//    private fun lockFolder() {
//
//        val albumData = albumList.filter { it.isSelected }
//
//        val paths: ArrayList<String> = ArrayList()
//        paths.addAll(albumData.map { it.folderPath })
//        paths.filter { !preferences.isFolderProtected(it) }.forEach {
//            preferences.addFolderProtection(it)
//        }
//        setCloseToolbar()
//
//    }

//    private fun unlockFolder() {
//        lockOperation = 2
//
//        lockedAlbumAlbumList = albumList.filter { it.isSelected } as ArrayList<AlbumData>
//        val intent = Intent(activity, LockActivity::class.java)
//        intent.putExtra(Constant.EXTRA_IS_OPEN_ALBUM, true)
//        lockActivityResultLauncher.launch(intent)
//
//    }

    fun setSelectClick(isSelectAll: Boolean) {
//        if (isSelectAll) {
        var selected = 0
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                        if (isSelectAll)
                            selected++
                    }
                }
        }
        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
//        } else {
//            longClickListener(false, 0, false)
//            setClose()
//        }
    }

    fun getData() {
        disableScroll()
//        binding.swipeRefreshLayout.isRefreshing = true

        mediaLoader?.destroyLoader()
        mediaLoader?.getAllAlbum({ customAlbumList, allAlbumList, mediaList ->

            albumList.clear()
            albumList.addAll(customAlbumList)
            videoList.clear()
            videoList.addAll(mediaList)

            if (videoList.size > 0) {
                albumList.add(
                    0,
                    AlbumData(
                        getString(R.string.all_videos),
                        mediaData = videoList,
                        isCustomAlbum = true
                    )
                )
            }

//            pictures.clear()
//            pictures.addAll(groupedMediaList)

            runOnUiThread {
                enableScroll()
//                binding.swipeRefreshLayout.isRefreshing = false
                setData()
            }
        })
    }

    private fun getAlbumCount() {
//        albumCountListener(albumList.size)
    }

    private fun disableScroll() {
        binding.albumRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.albumRecycler.suppressLayout(false)
    }

    fun setFilterData() {
        disableScroll()
//        binding.swipeRefreshLayout.isRefreshing = true
        GlobalScope.launch(Dispatchers.IO) {
//            sortAlbumMain()
//            sortPhotos()
//            if (videoList.size > 0) {
//                albumList.add(
//                    0,
//                    AlbumData(
//                        getString(R.string.all_videos),
//                        mediaData = videoList,
//                        isCustomAlbum = true
//                    )
//                )
//            }

            activity.runOnUiThread {
                setData()
            }
        }

    }

    private fun sortAlbumMain() {
        val sortType = preferences.getSortType("pref_0")
        val sortOrder = preferences.getSortOrder("pref_0")

        albumList.sortWith(Comparator { p1, p2 ->
            if (sortType == Constant.SORT_NAME) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.title.compareTo(p2.title, true)
                else
                    p2.title.compareTo(p1.title, true)
            }
//            else if (sortType == Constant.SORT_PATH) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.folderPath.compareTo(p2.folderPath, true)
//                else
//                    p2.folderPath.compareTo(p1.folderPath, true)
//            }
            else if (sortType == Constant.SORT_SIZE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.fileSize.compareTo(p2.fileSize)
                else
                    p2.fileSize.compareTo(p1.fileSize)
            } else if (sortType == Constant.SORT_DATE) {
                if (sortOrder == Constant.ORDER_ASCENDING)
                    p1.date.compareTo(p2.date)
                else
                    p2.date.compareTo(p1.date)
            }
//            else if (sortType == Constant.SORT_DATE_TAKEN) {
//                if (sortOrder == Constant.ORDER_ASCENDING)
//                    p1.date.compareTo(p2.date)
//                else
//                    p2.date.compareTo(p1.date)
//            }
            else
                p2.date.compareTo(p1.date)
        })


    }

    private fun setData() {
//        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (albumAdapter != null) {
//            albumAdapter!!.notifyDataSetChanged()
            albumAdapter?.notifyItemRangeChanged(0, albumList.size)
        } else initAdapter()
        setEmptyData()
    }

    private fun setEmptyData() {
        if (albumList != null && albumList.size != 0) {
            binding.albumRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.layoutBottomAd.beVisible()
        } else {
            binding.albumRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.layoutBottomAd.beGone()
        }
    }

    private fun initAdapter() {
        setRvLayoutManager()

        albumAdapter = AlbumListAdapter(
            activity,
            clickListener = {
                val albumData = albumList[it]
                if (albumData.isCheckboxVisible) {
                    if (!albumData.isCustomAlbum) {
                        albumData.isSelected = !albumData.isSelected
                        albumAdapter?.notifyItemChanged(it)
                        setSelectedFile()
                    }
                } else {
                    if (albumData.isCustomAlbum) {
                        if (albumData.mediaData.size != 0) {
                            openImageList(albumData)
                        } else {
                            //startActivity(Intent(activity, MediaActivity::class.java))
                        }

                    } else {
                        openImageList(albumData)
                    }
                }
            },
            longClickListener = {
                if (!albumList[it].isCustomAlbum) {
                    lastLongPressedItem = it
                    binding.albumRecycler.setDragSelectActive(it)
                    lastLongPressedItem = if (lastLongPressedItem == -1) {
                        it
                    } else {
                        val min = min(lastLongPressedItem, it)
                        val max = max(lastLongPressedItem, it)
                        for (i in min..max) {
                            toggleItemSelection(true, i, false)
                        }
//                    updateTitle()
                        it
                    }

                    if (albumList[it] is AlbumData) {
                        val pictureData = albumList[it] as AlbumData
                        for (i in albumList.indices) {
                            if (albumList[i] != null) {
                                val model = albumList[i] as AlbumData
                                model.isCheckboxVisible = true
                            }
                        }
                        pictureData.isCheckboxVisible = true
                        pictureData.isSelected = true
                        notifyAdapter()
                        setSelectedFile()
                    }
                }
            })

        albumAdapter?.submitList(albumList)
        albumAdapter?.pinList?.clear()
        binding.albumRecycler.adapter = albumAdapter

        binding.albumRecycler.post {
            FastScroller(binding.handleView).bind(binding.albumRecycler)
        }
//        initZoomListener()
//        setupZoomListener(mZoomListener)
        initDragListener()
        setupDragListener(mDragListener)
    }


//    fun setBubbleText(str: String) {
//        Log.e("BubbleListener", "setBubbleText:$str")
////        binding.bubble.beGoneIf(str.isEmpty())
//        if (str.isNotEmpty()) binding.bubbleText.text = str
//    }

    public fun openImageList(albumData: AlbumData) {

        Constant.albumData = AlbumData(
            albumData.title,
            albumData.mediaData,
            albumData.folderPath,
            albumData.date,
            albumData.fileSize
        )
        startActivity(Intent(activity, ImageGalleryActivity::class.java))
        setBackAlbumData()
    }


    public fun setBackAlbumData() {
        Constant.albumList.clear()
        for (albumData in albumList) {
            Constant.albumList.add(
                AlbumData(
                    albumData.title,
                    albumData.mediaData,
                    albumData.folderPath,
                    albumData.date,
                    albumData.fileSize
                )
            )
        }
    }

    private fun setSelectedFile() {
        var selected = 0
        var allItemCount = 0
        var currentHeaderPos = -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in albumList.indices) {
            if (albumList[i] is AlbumData) {
                val model = albumList[i] as AlbumData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
//        binding.swipeRefreshLayout.isEnabled = selected == 0
        selectedItem = selected
    }

    private fun notifyAdapter() {
        if (albumAdapter != null) {
//            albumAdapter?.notifyDataSetChanged()
            albumAdapter?.notifyItemRangeChanged(0, albumList.size)
        }
    }

//    private fun initZoomListener() {
//        val isGridShow = preferences.getShowGrid()
//        if (isGridShow) {
//            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
//            mZoomListener = object : MyRecyclerView.MyZoomListener {
//                override fun zoomIn() {
//                    if (layoutManager.spanCount > 2) {
//                        reduceColumnCount()
////                        getRecyclerAdapter()?.finishActMode()
//                    }
//                }
//
//                override fun zoomOut() {
//                    if (layoutManager.spanCount < MAX_COLUMN_COUNT_ALBUM) {
//                        increaseColumnCount()
////                        getRecyclerAdapter()?.finishActMode()
//                    }
//                }
//            }
//        } else {
//            mZoomListener = null
//        }
//    }

//    fun setupZoomListener(zoomListener: MyRecyclerView.MyZoomListener?) {
//        binding.albumRecycler.setupZoomListener(zoomListener)
//    }

    private fun initDragListener() {
//        val isGridShow = preferences.getShowGrid()
//        if (isGridShow) {
//            val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager

        mDragListener = object : MyRecyclerView.MyDragListener {

            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int,
                lastDraggedIndex: Int,
                minReached: Int,
                maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
//        } else {
//            mDragListener = null
//        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.albumRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {

        if (albumList[pos] is AlbumData) {
            if (select && !albumList[pos].isCustomAlbum) {
                albumList[pos].isSelected = true
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                albumList[pos].isSelected = false
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.remove(itemKey)
            }
        }

        albumAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getAlbumGridCount()
        if (selectedGrid > 2) {
            preferences.setAlbumGridCount(selectedGrid - 1)
        }
        setColumnView()
    }


    private fun setColumnView() {
        (binding.albumRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getAlbumGridCount()
        albumAdapter?.apply {
            notifyItemRangeChanged(0, albumList.size)
        }
        setRvLayoutManager()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getAlbumGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_ALBUM) {
            preferences.setAlbumGridCount(selectedGrid + 1)
        }
        setColumnView()
    }

    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    override fun onBackPressed() {
        if (binding.groupToolbarSelectHeader.visibility == View.VISIBLE) {
            setCloseToolbar()
        } else {
            if (preferences.isNeedInterAd) {

                AdsConfig.showInterstitialAd(this@VideoGalleryActivity) {
                    if (it) preferences.isNeedInterAd = false
                    finish()
                }
            } else {
                super.onBackPressed()
            }
        }
    }

    var isSelectAll = false
    var mSelectedItem = 0
    private fun longClickListener(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        preferences.refreshMedia = true
        mSelectedItem = selectedItem
        binding.loutToolbar.visibility = View.VISIBLE
        if (isShowSelection) {
//            binding.btnUnhide.visibility = if (binding.viewPager.currentItem == 2) View.VISIBLE else View.GONE
//            binding.btnHide.visibility = if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
//            binding.btnMore.visibility = if (binding.viewPager.currentItem == 2) View.GONE else View.VISIBLE
//            binding.btnPin.visibility = if (binding.viewPager.currentItem == 0) View.VISIBLE else View.GONE
//            binding.btnShare.visibility = if (binding.viewPager.currentItem == 0) View.GONE else View.VISIBLE
        }

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE

//        binding.viewPager.setPagingEnabled(!isShowSelection)
        isSelectAll = isAllSelect

        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE

//        if (binding.viewPager.currentItem == 2) {
//            binding.groupToolbarSettingHeader.visibility = View.GONE
//            binding.groupToolbarHeaderPrivate.visibility = if (isShowSelection) View.GONE else View.VISIBLE
//        } else
        binding.groupToolbarHeader.visibility =
            if (isShowSelection) View.GONE else View.VISIBLE

//        binding.cardLoutTab.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
//        val color =
//            ContextCompat.getColor(this, if (isSelectAll) R.color.black else R.color.un_check_color)
//        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.icSelect.setImageResource(if (isSelectAll) R.drawable.ic_select_all else R.drawable.ic_unselect_all)
    }

    private fun setClose() {
        Log.e("", "setClose==>> pictures size ${albumList.size} ")
        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    model.isSelected = false
                    model.isCheckboxVisible = false
                    Log.e("", "setClose==>> AlbumData selection false")
                }
        }
        binding.swipeRefreshLayout.isEnabled = true
//        setRvLayoutManager()
//        notifyAdapter()
        setRvLayoutManager()
        getData()
        selectedItem = 0
    }


    private fun deletePhoto(selectImage: ArrayList<MediaData>, isPermanent: Boolean) {

        val deleteList = ArrayList<String>()
        val progressDialog = ProgressDialog(
            this,
            R.drawable.ic_drawer_delete,
            selectImage.size,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(this)
            selectImage.forEach { model ->

                val entity = dataBase.dataDao().getLocationEntity(model.filePath)
                if (entity != null) {
                    dataBase.dataDao().deleteLocationEntity(entity)
                }
                val isDelete = Utils.deleteFile(this, model.filePath, dataBase, isPermanent)
                MediaScannerConnection.scanFile(this, arrayOf<String>(model.filePath), null) { path: String?, uri: Uri? -> }
                if (isDelete) {
                    deleteList.add(model.filePath)
                    runOnUiThread {
                        progressDialog.setProgress(deleteList.size, selectImage.size)
                    }
                }
            }

            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                runOnUiThread {
                    progressDialog.dismiss()
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    @SuppressLint("CheckResult")
    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.Deleting),
            ""
        )
        progressDialog.setCancelable(false)
        progressDialog.show()

        preferences.refreshMedia = true
        preferences.scanMedia = true

        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)

            for (a in albumList.indices) {
                if (albumList[a].isSelected) {

//                    activity.runOnUiThread {
//                        bindingDialog.txtTitle.text = albumList[a].folderPath
//                    }
                    val pictures = albumList[a].mediaData
                    for (i in pictures.indices) {
                        if (pictures[i] != null) if (pictures[i] is MediaData) {
                            val model = pictures[i] as MediaData
//                            if (model.isSelected) {

                            val isDelete =
                                Utils.deleteFile(activity, model.filePath, dataBase, isPermanent)
                            if (isDelete) {
                                deleteList.add(model.filePath)
                                activity.runOnUiThread {
                                    progressDialog.setProgress(deleteList.size, selectedItem)
//                                    bindingDialog.txtProgressCount.text =
//                                        deleteList.size.toString() + "/" + selectedItem
//                                    bindingDialog.progressBar.progress = deleteList.size
                                }

                                triggerMediaScan(model.filePath)
                            }
//                            } else {
//                                model.isCheckboxVisible = false
//                            }
                        }
//                    else if (pictures[i] is AlbumData) {
//                        val model = pictures[i] as AlbumData
//                        model.isSelected = false
//                        model.isCheckboxVisible = false
//                    }
                    }
                    if (albumList[a] is AlbumData) {
                        val model = albumList[a] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
                }

            }

            var i = 0

            for (a in albumList.indices) {
                val pictures = albumList[a].mediaData
                while (i < pictures.size) {
                    if (pictures[i] != null)
                        if (pictures[i] is MediaData) {
                            val model = pictures[i] as MediaData
                            model.isSelected = false
                            model.isCheckboxVisible = false

                        } else if (pictures[i] is MediaData) {
                            val model = pictures[i] as MediaData
                            if (model.isSelected) {
                                var isPre = false
                                var isNext = false
                                if (i != 0) {
                                    isPre = pictures[i - 1] is MediaData
                                }
                                if (i < pictures.size - 2) {
                                    isNext = pictures[i + 1] is MediaData
                                }
                                if (isPre && isNext) {
                                    pictures.removeAt(i)
                                    pictures.removeAt(i - 1)
                                } else if (i == pictures.size - 1) {
                                    pictures.removeAt(i)
                                    if (isPre) {
                                        pictures.removeAt(i - 1)
                                    }
                                } else {
                                    pictures.removeAt(i)
                                }
                                if (i != 0) {
                                    i--
                                }
                            } else {
                                model.isSelected = false
                                model.isCheckboxVisible = false
                            }
                        }
                    i++
                }

            }
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { _: Throwable? ->
                activity.runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
            .onErrorReturn { false }
            .subscribe { _: Boolean? ->
                activity.runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (progressDialog.isShowing)
                            progressDialog.dismiss()
                    }
                    setBeforeDeleteUpdate(deleteList)
                }
            }
    }

    private fun triggerMediaScan(filePath: String) {
        try {
            MediaScannerConnection.scanFile(
                activity,
                arrayOf(filePath),
                null
            ) { _: String?, _: Uri? ->
                // Scanning completed callback, if needed
            }
        } catch (e: Exception) {
        }
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(0, deleteList))
        selectedItem = 0
        notifyAdapter()
//        enableScroll()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        sendEvent("refresh")
        toast(getString(R.string.Delete_successfully))
        deleteMainList(deleteList)
        getData()
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            for (path in deleteList) {
//                for (pictureData in albumList) {
//                    if (pictureData.folderPath == path) {
//                        albumList.remove(pictureData)
//                        break
//                    }
//                }
//            }
            albumList.iterator().let { iterator ->
                while (iterator.hasNext()) {
                    if (iterator.next().folderPath in deleteList) {
                        iterator.remove()
                    }
                }
            }

        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getAlbumGridCount()
        val isGridShow = preferences.getShowGrid()
        if (isGridShow) {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.orientation = RecyclerView.VERTICAL
            layoutManager.spanCount = gridCount
//            layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//                override fun getSpanSize(position: Int): Int {
//                    if (position >= 0 && position < albumList.size) {
////                        if (albumAdapter!!.getItemViewType(position) == albumAdapter!!.ITEM_ALBUM_HEADER_TYPE) {
//                            return gridCount
////                        } else return 1
//                    } else {
//                        return 1
//                    }
//                }
//            }
        } else {
            val layoutManager = binding.albumRecycler.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
//            mZoomListener = null

        }
    }

    fun setListGridData() {
        setRvLayoutManager()
        if (albumAdapter != null) {
//            albumAdapter!!.notifyDataSetChanged()
            albumAdapter?.notifyItemRangeChanged(0, albumList.size)
        }
    }

    private fun showDeleteDialog(selectImage: ArrayList<MediaData>) {
        if (selectImage.size == 0) {
            toast(getString(R.string.PleaseSelectAlbum))
        } else {
            val deleteDialog = DeleteDialog.newInstance(this@VideoGalleryActivity, btnClickListener = {
                deletePhoto(selectImage, it)
            })
            deleteDialog.show()
        }
    }

    fun showDeleteDialog() {
        if (selectedItem == 0) {
            toast(getString(R.string.PleaseSelectAlbum))
        } else {
            val deleteDialog = DeleteDialog.newInstance(
                activity,
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show()
        }
    }

    fun showRenameDialog() {
        try {

            val albumData = albumList.firstOrNull() { it.isSelected }
            albumData?.let { album ->
                val renameDialog = FolderRenameDialog(
                    activity,
                    album,
                    positiveBtnClickListener = { renamePath, oldPath ->
                        try {
                            MediaScannerConnection.scanFile(this, arrayOf<String>(oldPath), null) { path, uri -> }
                            MediaScannerConnection.scanFile(this, arrayOf<String>(renamePath), null) { path, uri -> }
                        } catch (e: Exception) {
                        }
//                    val file = File(renamePath)
                        notifyAdapter()
                        setCloseToolbar()
//                    displayImageList[binding.viewPager.currentItem].filePath = renamePath
//                    displayImageList[binding.viewPager.currentItem].fileName = file.name
//                    pagerAdapter.notifyDataSetChanged()

                    })
                renameDialog.show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun showAddAlbumDialog(
        albums: ArrayList<AlbumData>,
        selectedMedia: ArrayList<MediaData>,
        selectedAlbum: ArrayList<String>,
//        selectedAlbum: ArrayList<AlbumData>,
        isCopy: Boolean
    ) {
//        val selectedAlbum = ArrayList<AlbumData>()
//        val selectImage = mutableSetOf<MediaData>() // Use a set to avoid duplicates
//        albumList.filter { it.isSelected }.forEach { album ->
//            selectedAlbum.add(album) // Add selected album
//            album.mediaData.forEach { picture ->
//                if (picture is MediaData) {
//                    selectImage.add(picture) // Add MediaData to the set (duplicates automatically avoided)
//                }
//            }
//        }

//        pictures.filterIsInstance<MediaData>() // Filter only MediaData objects
//            .filter { it.isSelected } // Filter selected MediaData objects
//            .forEach { selectImage.add(it) } // Add to the set

        val uniqueSelectImage = ArrayList(selectedMedia.distinctBy { it.filePath })

        for (media in uniqueSelectImage) {
            Log.e("uniqueSelectImage", "uniqueSelectImage-->:${media.filePath}")
        }

//        val addAlbumDialog =
//            SelectAlbumFullDialog(
//                this@HomeActivity,
//                albums,
//                selectedAlbum,
//                isCopy,
//                selectPathListener = { selectPath ->
//                    setCopyMove(isCopy, selectPath, uniqueSelectImage)
//                },
//                createAlbumListener = {
////                    requestStoragePermission(app_create_album_AFA_allow_nf, app_create_album_AFA_denied_nf, getActivityName()) { value ->
////                        if (value) {
//                    val createDialog = CreateAlbumDialog(this@HomeActivity, createPathListener = {
//                        setCopyMove(isCopy, it, uniqueSelectImage)
//                    })
//                    createDialog.show()
////                        }
////                    }
//                })
//        addAlbumDialog.show(supportFragmentManager, addAlbumDialog.tag)

        isCopyForResult = isCopy
        selectImageForResult = uniqueSelectImage
        val selectAlbumIntent = Intent(this, AlbumSelectorActivity::class.java)
        selectAlbumIntent.putExtra("selectedAlbum", selectedAlbum)
        selectAlbumIntent.putExtra("isCopy", isCopy)
        addAlbumLauncher.launch(selectAlbumIntent)

    }

    private var isCopyForResult: Boolean = false
    private lateinit var selectImageForResult: ArrayList<MediaData>
    private val addAlbumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val data = result.data
                when (data?.getStringExtra("action")) {
                    "create" -> {
                        val createDialog = CreateAlbumDialog(this, createPathListener = { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        })
                        createDialog.show()
                    }

                    else -> {
                        data?.getStringExtra("selectedPath")?.let { path ->
                            setCopyMove(isCopyForResult, path, selectImageForResult)
                        }
                    }
                }
            }
        }

    private fun setCopyMove(
        isCopy: Boolean,
        selectPath: String,
        selectImage: java.util.ArrayList<MediaData>
    ) {
        if (isCopy)
            Utils.copyFiles(
                activity,
                selectPath,
                selectImage,
                selectedItem,
                copyListener = {
                    toast(getString(R.string.copy_successfully))
                    MediaScannerConnection.scanFile(this, arrayOf<String>(selectPath), null) { path, uri -> }
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                    sendEvent("refresh")
                })
        else
            Utils.moveFiles(
                activity,
                selectPath,
                selectImage,
                selectedItem,
                moveListener = {
                    toast(getString(R.string.move_successfully))
                    MediaScannerConnection.scanFile(this, arrayOf<String>(selectPath), null) { path, uri -> }
                    selectedItem = 0
                    longClickListener(false, 0, false)
                    setClose()
                    sendEvent("refresh")
                })

    }

}