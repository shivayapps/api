package com.adconfig.adsutil.admob

import android.app.Activity
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.adconfig.AdsConfig
import com.adconfig.R
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.utils.isOnline
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError


object BannerAdHelper {

    val TAG = "ADCONFIG_BannerAdHelper"
    fun showBanner(
        context: Activity,
        container: ViewGroup,
        parent: ViewGroup,
        adId: String,
        cacheAdView: AdView?,
        onLoaded: (isLoaded: Boolean, adView: AdView?, message: String) -> Unit,
        mAdSize: AdSize? = null,
    ) {
        var mShimmerLayout: Int = R.layout.layout_shimmer_ad_banner
//        Log.d(TAG, "Banner: showBanner:$adId")

        if (!context.isOnline()) {
            container.visibility = View.GONE
            return
        }


        var adView = AdView(context)

        Log.d(TAG, "001.showBanner: Banner Id -> $adId")

        adView.adListener = object : AdListener() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                onLoaded.invoke(
                    false,
                    null,
                    "001.onAdFailedToLoad:${adError.code},${adError.message}"
                )
                Log.i(
                    TAG,
                    "001.onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                )
                container.visibility = View.GONE
                parent.visibility = View.GONE
            }

            override fun onAdLoaded() {
                try {
                    onLoaded.invoke(true, adView, "ok")
                    if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
                    if (container.childCount > 0) container.removeAllViews()
                    container.addView(adView)
                    container.visibility = View.VISIBLE
                    parent.visibility = View.VISIBLE

                    Log.d(TAG, "001.onAdLoaded")
                } catch (e: Exception) {

                }

            }

            override fun onAdClicked() {
                super.onAdClicked()
                Log.d(TAG, "001.onAdClicked")
                AdsConfig.isSystemDialogOpen = true
            }
        }

        if (cacheAdView != null) {
            adView = cacheAdView

            Log.d(TAG, "onLoadCacheAdView")
            if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
//                if (adView.parent != null) (adView.parent as ViewGroup).removeAllViews()
            if (container.childCount > 0) container.removeAllViews()

            val layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            layoutParams.gravity = Gravity.CENTER or Gravity.BOTTOM
            container.post {
                try {
                    if (adView.parent != null) (adView.parent as ViewGroup).removeView(adView)
                    if (container.childCount > 0) container.removeAllViews()
                    container.addView(adView, layoutParams)
                    container.bringChildToFront(adView)
                    container.visibility = View.VISIBLE
                    parent.visibility = View.VISIBLE
                    container.invalidate()
                    container.requestLayout()
                    adView.resume()

                    Log.d(
                        TAG,
                        "adView.size:${adView.height}x${adView.width},container.size:${container.height}x${container.width}"
                    )
                } catch (e: Exception) {

                    container.visibility = View.GONE
                    parent.visibility = View.GONE
                }
            }

        } else {
            Log.d(TAG, "onLoadAdView")
            if (mAdSize != null) {
                adView.setAdSize(mAdSize)
            } else {
                adView.setAdSize(
                    getAdSize(
                        context, container
                    )
                )
            }
            adView.adUnitId = adId
            adView.loadAd(AdRequest.Builder().build())
        }

    }

    private fun getAdSize(activity: Activity, view: ViewGroup): AdSize {
        val display = activity.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()
        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()
//        val adWidth = AdsParameters(activity).adWidth
        Log.e(TAG, "adWidth:$adWidth")

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
            activity, adWidth
        )
    }


}