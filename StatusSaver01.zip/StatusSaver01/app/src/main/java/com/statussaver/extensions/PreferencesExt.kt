package com.statussaver.extensions

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.edit
import androidx.fragment.app.Fragment
import androidx.preference.PreferenceManager
import com.statussaver.R
import com.statussaver.getApp
import com.statussaver.model.PlaybackSpeed
import com.statussaver.model.SaveLocation
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun appStr(resId: Int) = getApp().applicationContext.getString(resId)

fun Context.preferences(): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)

fun Fragment.preferences() = requireContext().preferences()

//fun SharedPreferences.useCustomFont() = getBoolean(PREFERENCE_USE_CUSTOM_FONT, true)

fun SharedPreferences.getDefaultDayNightMode() = AppCompatDelegate.MODE_NIGHT_NO
//fun SharedPreferences.getDefaultDayNightMode() = getDefaultDayNightMode(getString(PREFERENCE_THEME_MODE, null))

//fun getDefaultDayNightMode(nightMode: String?): Int {
//    if (nightMode != null) when (nightMode) {
//        NightMode.VALUE_DARK -> return AppCompatDelegate.MODE_NIGHT_YES
//        NightMode.VALUE_LIGHT -> return AppCompatDelegate.MODE_NIGHT_NO
//    }
//    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
//        AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
//    } else AppCompatDelegate.MODE_NIGHT_AUTO_BATTERY
//}

//fun SharedPreferences.isJustBlack() = getBoolean(PREFERENCE_JUST_BLACK_THEME, false)

fun SharedPreferences.blacklistedSenders(): Set<String>? = getStringSet(BLACKLISTED_MESSAGE_SENDERS, null)

fun SharedPreferences.blacklistMessageSender(name: String) {
    var namesSet = getStringSet(BLACKLISTED_MESSAGE_SENDERS, null)
    if (namesSet == null) {
        edit { putStringSet(BLACKLISTED_MESSAGE_SENDERS, hashSetOf(name)) }
    } else {
        namesSet = namesSet.toMutableSet()
        namesSet.add(name)
        edit { putStringSet(BLACKLISTED_MESSAGE_SENDERS, namesSet) }
    }
}

fun SharedPreferences.whitelistMessageSender(name: String) {
    var namesSet = getStringSet(BLACKLISTED_MESSAGE_SENDERS, null)
    if (namesSet == null) {
        edit { putStringSet(BLACKLISTED_MESSAGE_SENDERS, hashSetOf(name)) }
    } else {
        namesSet = namesSet.toMutableSet()
        namesSet.remove(name)
        edit { putStringSet(BLACKLISTED_MESSAGE_SENDERS, namesSet) }
    }
}

fun SharedPreferences.isBlacklistedMessageSender(name: String): Boolean {
    val namesSet = getStringSet(BLACKLISTED_MESSAGE_SENDERS, emptySet())
    if (namesSet.isNullOrEmpty()) return false
    return namesSet.contains(name)
}

var SharedPreferences.isMessageViewEnabled
    get() = getBoolean(PREFERENCE_ENABLE_MESSAGE_VIEW, false)
    set(value) = edit {
        putBoolean(PREFERENCE_ENABLE_MESSAGE_VIEW, value)
    }

fun SharedPreferences.isExcludeSavedStatuses() = getBoolean(PREFERENCE_EXCLUDE_SAVED_STATUSES, false)

fun SharedPreferences.isWhatsappIcon() = getBoolean(PREFERENCE_WHATSAPP_ICON, false)

fun SharedPreferences.isQuickDeletion() = getBoolean(PREFERENCE_QUICK_DELETION, false)


var SharedPreferences.isShownOnboard: Boolean
    get() = getBoolean(SHOULD_SHOW_ONBOARD, true)
    set(value) = edit {
        putBoolean(SHOULD_SHOW_ONBOARD, value)
    }

var SharedPreferences.lastUpdateSearch: Long
    get() = getLong(PREFERENCE_LAST_UPDATE_SEARCH, -1)
    set(value) = edit {
        putLong(PREFERENCE_LAST_UPDATE_SEARCH, value)
    }

var SharedPreferences.lastUpdateId: Long
    get() = getLong(PREFERENCE_LAST_UPDATE_ID, -1)
    set(value) = edit {
        putLong(PREFERENCE_LAST_UPDATE_ID, value)
    }

var SharedPreferences.defaultClientPackageName: String?
    get() = getString(PREFERENCE_DEFAULT_CLIENT, null)
    set(packageName) = edit {
        putString(PREFERENCE_DEFAULT_CLIENT, packageName)
    }

var SharedPreferences.saveLocation
    get() = getString(PREFERENCE_SAVE_LOCATION, null)?.toEnum<SaveLocation>() ?: SaveLocation.DCIM
    set(value) = edit { putString(PREFERENCE_SAVE_LOCATION, value.name) }

var SharedPreferences.playbackSpeed
    get() = getString(PREFERENCE_PLAYBACK_SPEED, null)?.toEnum<PlaybackSpeed>() ?: PlaybackSpeed.Normal
    set(value) = edit { putString(PREFERENCE_PLAYBACK_SPEED, value.name) }

fun SharedPreferences.bumpPlaybackSpeed(): PlaybackSpeed {
    return playbackSpeed.next().also { playbackSpeed = it }
}

fun SharedPreferences.resetPlaybackSpeed(): PlaybackSpeed {
    return PlaybackSpeed.Normal.also { playbackSpeed = it }
}

//fun SharedPreferences.migratePreferences() {
//    if (contains("night_mode")) {
//        val oldValue = getString("night_mode", null)
//        edit {
//            val newValue = when (oldValue) {
//                "yes" -> NightMode.VALUE_DARK
//                "no" -> NightMode.VALUE_LIGHT
//                else -> null
//            }
//            putString(PREFERENCE_THEME_MODE, newValue)
//            remove("night_mode")
//        }
//    }
//}

class NightMode {
    companion object {
        const val VALUE_DARK = "dark"
        const val VALUE_LIGHT = "light"
    }
}

//class UpdateSearchMode {
//    companion object {
//        const val EVERY_DAY = "every_day"
//        const val WEEKLY = "weekly"
//        const val EVERY_FIFTEEN_DAYS = "every_fifteen_days"
//        const val MONTHLY = "monthly"
//        const val NEVER = "never"
//    }
//}

const val SHOULD_SHOW_ONBOARD = "should_show_onboard"
//const val PREFERENCE_USE_CUSTOM_FONT = "use_custom_font"
//const val PREFERENCE_THEME_MODE = "theme_mode"
//const val PREFERENCE_JUST_BLACK_THEME = "just_black_theme"
const val PREFERENCE_STATUSES_LOCATION = "statuses_location"
const val PREFERENCE_LANGUAGE = "language_name"
const val PREFERENCE_WHATSAPP_ICON = "whatsapp_icon"
const val PREFERENCE_EXCLUDE_SAVED_STATUSES = "exclude_saved_statuses"
const val PREFERENCE_SAVE_LOCATION = "preferred_save_location"
const val PREFERENCE_QUICK_DELETION = "quick_deletion"
const val PREFERENCE_DEFAULT_CLIENT = "default_client"
//const val PREFERENCE_GRANT_PERMISSIONS = "grant_permissions"
const val PREFERENCE_LAST_UPDATE_SEARCH = "last_update_search"
const val PREFERENCE_LAST_UPDATE_ID = "last_update_id"
const val BLACKLISTED_MESSAGE_SENDERS = "blacklisted_message_senders"
const val PREFERENCE_ENABLE_MESSAGE_VIEW = "enable_message_view"
const val PREFERENCE_PLAYBACK_SPEED = "playback_speed"

class Preferences(var context: Context) {

    //    private val prefs: SharedPreferences = context.getSharedPreferences("statussaver", Context.MODE_PRIVATE)
    private val prefs: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
    private val editor: SharedPreferences.Editor = prefs.edit()

    var isFirstTimeInstall: Boolean
        get() = prefs.getBoolean("isFirstTimeInstall", true)
        set(value) = prefs.edit().putBoolean("isFirstTimeInstall", value).apply()
    var isSetLanguage: Boolean
        get() = prefs.getBoolean("isSetLanguage", false)
        set(isSetLanguage) = prefs.edit().putBoolean("isSetLanguage", isSetLanguage).apply()

    var exclude_saved_statuses: Boolean
        get() = prefs.getBoolean(PREFERENCE_EXCLUDE_SAVED_STATUSES, false)
        set(value) = prefs.edit().putBoolean(PREFERENCE_EXCLUDE_SAVED_STATUSES, value).apply()
    var quick_deletion: Boolean
        get() = prefs.getBoolean(PREFERENCE_QUICK_DELETION, false)
        set(value) = prefs.edit().putBoolean(PREFERENCE_QUICK_DELETION, value).apply()
    var whatsapp_icon: Boolean
        get() = prefs.getBoolean(PREFERENCE_WHATSAPP_ICON, false)
        set(value) = prefs.edit().putBoolean(PREFERENCE_WHATSAPP_ICON, value).apply()



    fun logOnceDailyWithInterval(result: (logged: Boolean, daysInterval: Int) -> Unit) {
        try {
            val lastLoggedDate = prefs.getString("last_logged_date", null)
            val currentDate = getCurrentDate()

            val intervalDays = if (lastLoggedDate != null) {
                getDaysBetweenDates(lastLoggedDate, currentDate)
            } else {
                -1 // If there is no previous log, return -1 for interval
            }

            if (lastLoggedDate == null || lastLoggedDate != currentDate) {
                prefs.edit().putString("last_logged_date", currentDate).apply()
                result(true, intervalDays) // Log successful
            } else {
                result(false, intervalDays) // No log today, just return the interval
            }
        } catch (e: Exception) {
            result(false, -1)
        }
    }

    private fun getDaysBetweenDates(date1: String, date2: String): Int {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return try {
            val parsedDate1 = dateFormat.parse(date1)
            val parsedDate2 = dateFormat.parse(date2)
            val diffInMillis = kotlin.math.abs(parsedDate2.time - parsedDate1.time)
            val elapsedDays = (diffInMillis / (1000 * 60 * 60 * 24)).toInt()
            elapsedDays
        } catch (e: Exception) {
            -1
        }
    }

    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(Date())
    }

}