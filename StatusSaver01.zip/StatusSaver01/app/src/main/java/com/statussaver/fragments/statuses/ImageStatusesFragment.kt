package com.statussaver.fragments.statuses

import android.os.Bundle
import android.view.View
import com.statussaver.activities.MainActivity
import com.statussaver.model.StatusQueryResult
import com.statussaver.model.StatusType


class ImageStatusesFragment : StatusesFragment() {

    private val imageType: StatusType = StatusType.IMAGE

    override val lastResult: StatusQueryResult?
        get() = viewModel.getStatuses(imageType).value

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        statusesActivity.setSupportActionBar(binding.toolbar)
//        binding.toolbar.setTitle(getString(imageType.nameRes))
        viewModel.getStatuses(imageType).apply {
            observe(viewLifecycleOwner) { result ->
                data(result)
            }
        }.also { liveData ->
            if (liveData.value == StatusQueryResult.Idle) {
                onRefresh()
            }
        }
    }

    override fun onRefresh() {
        viewModel.loadStatuses(imageType)
    }

}