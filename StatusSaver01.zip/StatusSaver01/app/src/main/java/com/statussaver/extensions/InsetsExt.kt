
package com.statussaver.extensions

import  android.annotation.SuppressLint
import android.view.View
import androidx.core.view.WindowInsetsCompat
import com.statussaver.getApp
//import dev.chrisbanes.insetter.InsetterDsl
//import dev.chrisbanes.insetter.applyInsetter

@SuppressLint("DiscouragedApi", "InternalInsetResource")
fun WindowInsetsCompat?.getBottomInsets(): Int {
    var bottomInsets = this?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom
    if (bottomInsets == null) {
        val resourceId = getApp().resources.getIdentifier("navigation_bar_height", "dimen", "android")
        if (resourceId > 0) {
            bottomInsets = getApp().resources.getDimensionPixelSize(resourceId)
        }
    }
    return bottomInsets ?: 0
}

fun View.applyPortraitInsetter(
//    build: InsetterDsl.() -> Unit
) {
//    if (!isLandscape()) {
//        applyInsetter(build)
//    }
}

fun View.applyLandscapeInsetter(
//    build: InsetterDsl.() -> Unit
) {
//    if (isLandscape()) {
//        applyInsetter(build)
//    }
}