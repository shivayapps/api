
package com.statussaver.model


enum class SavedContentState {
    HasSavedContent, HasNotSavedContent, UnknownState
}