package com.statussaver.extensions

import android.content.ContentResolver
import android.content.Context
import com.statussaver.R
import com.statussaver.model.SavedContentState
import com.statussaver.model.SavedStatus
import com.statussaver.model.Status
import com.statussaver.model.StatusType
import java.io.File
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val fileDateFormat: DateFormat by lazy {
    SimpleDateFormat("MMM_d_yyyy_HH.mm.ss", Locale.ENGLISH)
}

fun Status.getFormattedDate(context: Context): String {
    val date = Date(dateModified)
    val resLocale = context.resources.configuration.locales[0]
    return DateFormat.getDateInstance(DateFormat.MEDIUM, resLocale).format(date)
}

fun getNewSaveName(type: StatusType? = null, timeMillis: Long, delta: Int): String {
    var saveName = String.format("Status_%s", fileDateFormat.format(Date(timeMillis)))
    if (delta > 0) {
        saveName += "-$delta"
    }
    if (type != null) {
        saveName += type.format
    }
    return saveName
}

fun Status.getState(context: Context): String =
    if (isSaved) context.getString(R.string.status_saved) else context.getString(R.string.status_unsaved)

fun StatusType.acceptFileName(fileName: String): Boolean = !fileName.startsWith(".") && fileName.endsWith(this.format)

fun Status.getSavedContentState(contentResolver: ContentResolver): SavedContentState {
    if (this is SavedStatus) {
        if (hasFile()) {
            return if (getFile().exists()) {
                SavedContentState.HasSavedContent
            } else {
                SavedContentState.HasNotSavedContent
            }
        }
        val isInMediaStore = contentResolver.query(fileUri, null,null,null,null)
            .use { it != null && it.moveToFirst() }
        return if (isInMediaStore) {
            SavedContentState.HasSavedContent
        } else {
            SavedContentState.HasNotSavedContent
        }
    }
    return SavedContentState.UnknownState
}

fun File.getStatusType() = StatusType.entries.firstOrNull { it.acceptFileName(name) }