package com.statussaver

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatDelegate
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.request.crossfade
import coil3.video.VideoFrameDecoder
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.google.android.gms.ads.MobileAds
import com.statussaver.extensions.getDefaultDayNightMode
//import com.statussaver.extensions.migratePreferences
import com.statussaver.extensions.preferences
import com.statussaver.appModules
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

fun getApp(): App = App.instance


class App : AppOpenApplication(), AppOpenApplication.AppLifecycleListener, SingletonImageLoader.Factory {

    companion object {
        internal lateinit var instance: App

        //        private set
        fun getFileProviderAuthority(): String = instance.packageName + ".file_provider"
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

//        preferences().migratePreferences()

        startKoin {
            androidContext(this@App)
            modules(appModules)
        }

        AppCompatDelegate.setDefaultNightMode(preferences().getDefaultDayNightMode())

        MobileAds.initialize(applicationContext)

        val admobAppOpenId = getString(R.string.open_all)
        AdsConfig.builder()
            .setTestDeviceId("43D54D26FD5DBC346211511E0DFD64F9")
            .setAdmobAppOpenId(admobAppOpenId)
            .build(this)

        setAppLifecycleListener(this)
        initMobileAds()
        fireBaseConfigGet()
    }

    private fun fireBaseConfigGet() {

    }

    override fun newImageLoader(context: PlatformContext): ImageLoader {
        return ImageLoader.Builder(context)
            .crossfade(true)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .build()
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {

//        if (fCurrentActivity is StatusesActivity) {
//            return false
//        } else if (fCurrentActivity is PermissionActivity) {
//            return false
//        } else
        if (AdsConfig.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdsConfig.isSystemDialogOpen = false
            }, 2000)
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
//            if (!OpenAdHelper.isAdAvailable()) {
                val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                fCurrentActivity.startActivity(intent)
//            }
//            else {
//                logMessages("app_appopen_created", fCurrentActivity.localClassName)
//            }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }
}