
package com.statussaver.model

import android.net.Uri
import android.os.Parcelable
import com.statussaver.extensions.canonicalOrAbsolutePath
import kotlinx.parcelize.Parcelize
import java.io.File

@Parcelize
class SavedStatus(
    override val type: StatusType,
    override val name: String,
    override val fileUri: Uri,
    override val dateModified: Long,
    override val size: Long,
    private val path: String?
) : Status(type, name, fileUri, dateModified, size, null, true), Parcelable {

    fun hasFile(): Boolean = !path.isNullOrBlank()

    fun getFile(): File {
        checkNotNull(path)
        return File(path)
    }

    fun getFilePath(): String {
        return getFile().canonicalOrAbsolutePath()
    }
}