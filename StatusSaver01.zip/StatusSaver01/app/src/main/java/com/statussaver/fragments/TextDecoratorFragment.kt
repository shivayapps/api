package com.statussaver.fragments

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.transition.MaterialSharedAxis
import com.statussaver.R
import com.statussaver.adapter.StyleAdapter
import com.statussaver.databinding.FragmentTextDecoratorBinding
import com.statussaver.utils.Constants
import java.util.Locale

class TextDecoratorFragment : Fragment(R.layout.fragment_text_decorator), View.OnClickListener {

    private var _binding: FragmentTextDecoratorBinding? = null
    private val binding get() = _binding!!

    var text: String = ""
    private var mFinalData: MutableList<String>? = null
    var adapter: StyleAdapter? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentTextDecoratorBinding.bind(view)

        setData()

        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        enterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
        reenterTransition = MaterialSharedAxis(MaterialSharedAxis.Y, true)
    }

    private fun setData() {
        mFinalData = ArrayList()

        binding.convert.setOnClickListener(this)
        makeStylishOf("Hello")

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.convert -> {
                text = binding.edText.text.toString().uppercase(Locale.getDefault())
                if (text!!.length == 0) {
                    Toast.makeText(requireActivity(), resources.getString(R.string.enter_text), Toast.LENGTH_SHORT).show()
                    return
                }
//                convert()

//                if (charSequence.toString().isEmpty()) {
//                    charSequence = "Stylish Text"
//                }
//                val sb = java.lang.StringBuilder()
//                sb.append("onTextChanged: ")
//                sb.append(text)
//                Log.d("STYLISHFONTLOG", sb.toString())
                makeStylishOf(text)

                binding.recyclerView.setHasFixedSize(false)
                binding.recyclerView.layoutManager = LinearLayoutManager(
                    requireActivity(),
                    RecyclerView.VERTICAL,
                    false
                )
                adapter = StyleAdapter(mFinalData!!, requireActivity())
                binding.recyclerView.setAdapter(adapter)
            }
        }
    }

//    private fun convert() {
//        mFinalData!!.clear()
//        tempIndexList!!.clear()
//        spaceList!!.clear()
//        val textArray = text!!.toCharArray()
//        for (i in textArray.indices) {
//            if (textArray[i] == ' ') {
//                spaceList!!.add(i)
//            }
//        }
//        for (i in textArray.indices) {
//            for (j in letterList.indices) {
//                if (textArray[i] == letterList[j]) {
//                    tempIndexList!!.add(j)
//                }
//            }
//        }
//        for (i in spaceList!!.indices) {
//            tempIndexList!!.add(spaceList!![i], -2)
//        }
//        val builder = StringBuilder()
//        val boldBuilder = StringBuilder()
//        val scriptBuilder = StringBuilder()
//        val turnedBuilder = StringBuilder()
//        val squaredBuilder = StringBuilder()
//        val filledCircleBuilder = StringBuilder()
//        val notFilledSquareBuilder = StringBuilder()
//        val doubleBuilder = StringBuilder()
//        for (i in tempIndexList!!.indices) {
//            if (tempIndexList!![i] == -2) {
//                builder.append(" ")
//                squaredBuilder.append(" ")
//                filledCircleBuilder.append(" ")
//                notFilledSquareBuilder.append(" ")
//                turnedBuilder.append(" ")
//                doubleBuilder.append(" ")
//                scriptBuilder.append(" ")
//                boldBuilder.append(" ")
//            } else {
//                builder.append(circleList!![tempIndexList!![i]])
//                turnedBuilder.append(turnedList!![tempIndexList!![i]])
//                squaredBuilder.append(getEmojiByUnicode(squaredList!![tempIndexList!![i]]))
//                filledCircleBuilder.append(getEmojiByUnicode(filledCircleList!![tempIndexList!![i]]))
//                notFilledSquareBuilder.append(
//                    getEmojiByUnicode(
//                        notFilledSquareList!![tempIndexList!![i]]
//                    )
//                )
//                doubleBuilder.append(getEmojiByUnicode(doubleStruckList!![tempIndexList!![i]]))
//                scriptBuilder.append(getEmojiByUnicode(scriptList!![tempIndexList!![i]]))
//                boldBuilder.append(getEmojiByUnicode(boldScriptList!![tempIndexList!![i]]))
//            }
//        }
//        mFinalData!!.add(builder.toString())
//        mFinalData!!.add(squaredBuilder.toString())
//        mFinalData!!.add(filledCircleBuilder.toString())
//        mFinalData!!.add(notFilledSquareBuilder.toString())
//        mFinalData!!.add(turnedBuilder.toString())
//        mFinalData!!.add(doubleBuilder.toString())
//        mFinalData!!.add(scriptBuilder.toString())
//        mFinalData!!.add(boldBuilder.toString())
//    }


    fun makeStylishOf(charSequence: String) {
        val charArray = charSequence.toString().lowercase(Locale.getDefault()).toCharArray()
//        val strArr = arrayOfNulls<String>(Constants.styles.size)
        val strArr = Array(Constants.styles.size) {""}
        for (i in 0 until Constants.styles.size) {
            val sb = java.lang.StringBuilder()
            sb.append("applyStyle: num ")
            sb.append(i)
            Log.d("STYLISHFONTLOG", sb.toString())
            strArr[i] = applyStyle(charArray, Constants.styles.get(i))
        }
        styleTheFont(strArr)
    }

    private fun applyStyle(cArr: CharArray, strArr: Array<String>): String {
        val stringBuffer = StringBuffer()
        for (i in cArr.indices) {
            if (cArr[i].code - 'a'.code < 0 || cArr[i].code - 'a'.code > 25) {
                stringBuffer.append(cArr[i])
            } else {
                stringBuffer.append(strArr[cArr[i].code - 'a'.code])
            }
        }
        return stringBuffer.toString()
    }

    private fun styleTheFont(strArr: Array<String>) {
        mFinalData?.clear()
        var i = 0
        while (i < Constants.styles.size) {
            val sb = java.lang.StringBuilder()
            sb.append("")
            val i2 = i + 1
            sb.append(i2)
            mFinalData?.add(strArr[i]!!)
            i = i2
        }
//        this.rvStylishFonts.setLayoutManager(LinearLayoutManager(activity!!.applicationContext, RecyclerView.VERTICAL, false))
//        this.rvStylishFonts.setAdapter(
//            FontAdapter(
//                this.fontList,
//                OnItemClickListener { adapterView, view, i, j ->
//                    CustomBottomSheet(this@StylishFontFragment.fontList.get(i).fontText).show(
//                        this@StylishFontFragment.getActivity().getSupportFragmentManager(), "customBottomSheetDialog"
//                    )
//                }, false
//            )
//        )
    }

    fun getEmojiByUnicode(unicode: Int): String {
        return String(Character.toChars(unicode))
    }

}