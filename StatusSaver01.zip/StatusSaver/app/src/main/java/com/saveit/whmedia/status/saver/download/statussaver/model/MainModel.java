package com.saveit.whmedia.status.saver.download.statussaver.model;

public class MainModel {
    private String title;
    private int resId;
    private String tag;


    public MainModel(String tag,String title, int resId) {
        this.tag = tag;
        this.title = title;
        this.resId = resId;
    }

    public String getTitle() {
        return this.title;
    }

    public String getTag() {
        return this.tag;
    }
    public int getResId() {
        return this.resId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }
}
