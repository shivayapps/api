package com.example.app.ads.helper.adaptive.banner

enum class BannerAdSize {
    BANNER,
    LARGE_BANNER,
    MEDIUM_RECTANGLE,
    FULL_BANNER,
    LEADERBOARD,
    ADAPTIVE_BANNER,
    SMART_BANNER,
}