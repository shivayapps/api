package com.bankbalanceinquiry.ministatement.fragment;

import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.intreset;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.loan_amount;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.loan_interest;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.loan_period_month;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.month_text;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.start_date;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.static_emi;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.static_payment;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.static_rate;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.total_emi;
import static com.bankbalanceinquiry.ministatement.fragment.emiCalculatorFragment.year_digit;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class detailEMIFragment extends Fragment {

    TextView tLoan_amount;
    TextView tInterest;
    TextView tTenture;
    TextView tMonthly_emi;
    TextView tTotal_interest;
    TextView tTotal_payment;
    String sAmount, sRate, sTenture, sEmi, sInterest, sPayment, sDate;
    int endingDate, txtYear, txtMonth;
    TableLayout table_Detail;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_emi_detail, container, false);


        tLoan_amount = view.findViewById(R.id.loan_amount);
        tInterest = view.findViewById(R.id.interest);
        tTenture = view.findViewById(R.id.tenture);
        tMonthly_emi = view.findViewById(R.id.monthly_emi);
        tTotal_interest = view.findViewById(R.id.total_interest);
        tTotal_payment = view.findViewById(R.id.total_payment);

        table_Detail = view.findViewById(R.id.table_Detail);


        sAmount = String.valueOf(loan_amount);
        sRate = String.valueOf(loan_interest);
        sTenture = loan_period_month;
        sEmi = static_emi;
        sInterest = static_rate;
        sPayment = static_payment;
        sDate = start_date;
        endingDate = Integer.parseInt(loan_period_month);

        double loan_amountDe = loan_amount;
        double first_month_emi = total_emi;

        tLoan_amount.setText(sAmount + " \u20B9");
        tInterest.setText(sRate + " %");
        tTenture.setText(sTenture + " "+getString(R.string.month));
        tMonthly_emi.setText(sEmi);
        tTotal_interest.setText(sInterest);
        tTotal_payment.setText(sPayment);


        //txtMonth=month_text;
        txtYear = year_digit;
        Calendar cal = Calendar.getInstance();
        try {
            Date date = new SimpleDateFormat("MMM").parse(month_text);//put your month name here

            cal.setTime(date);
            txtMonth = cal.get(Calendar.MONTH);
            // txtMonth = txtMonth+1;
            Log.e("Month-->", " " + txtMonth + " Year--> " + txtYear);

            cal.set(Calendar.MONTH, txtMonth);
            cal.set(Calendar.YEAR, txtYear);
        } catch (Exception e) {

        }

        SimpleDateFormat month_date = new SimpleDateFormat("MMM-yyyy");


        for (int i = 1; i <= endingDate; i++) {
            View tableRow = LayoutInflater.from(getActivity()).inflate(R.layout.table_custom_item_list, null, false);

            TextView list_month = tableRow.findViewById(R.id.month_list);
            TextView list_emi = tableRow.findViewById(R.id.list_emi);
            TextView list_rate = tableRow.findViewById(R.id.list_rate);
            TextView list_balance = tableRow.findViewById(R.id.list_balance);

            double zEMI = 1 / (1 + intreset);
            double aEMI = (1 - zEMI);
            double EMiDetail = loan_amountDe * intreset / aEMI;
            double montlyRate = EMiDetail - loan_amountDe;
            double montlyEMI = first_month_emi - montlyRate;
            loan_amountDe = Math.abs(loan_amountDe - montlyEMI);


            Log.e("Rate--)", " " + montlyRate + "  EMI--) " + montlyEMI + " AMount-) " + loan_amount);


            sDate = month_date.format(cal.getTime());
            list_month.setText(sDate);
            cal.add(Calendar.MONTH, 1);
            NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
            DecimalFormat decim = ((DecimalFormat) nf);
            decim.applyPattern("##.##");
            list_emi.setText(decim.format(montlyEMI) + " \u20B9");
            list_rate.setText(decim.format(montlyRate) + " \u20B9");
            list_balance.setText(decim.format(loan_amountDe));

            table_Detail.addView(tableRow);
        }

        return view;
    }
}
