package com.bankbalanceinquiry.ministatement.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class PermissionActivity extends AppCompatActivity {

    Toolbar toolbar;
    Button allow_Permission;
    Button dontallow_Permission;
    TextView nameText;


    long clickTime = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        toolbar = findViewById(R.id.toolbar_main);
        nameText = findViewById(R.id.nameTxt);
        setSupportActionBar(toolbar);

        if (Build.VERSION.SDK_INT >= 33) {
            nameText.setText("To get notification and account detail please allow notification and sms permissions.");
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getColor(R.color.white));
        }

        toolbar.setTitle(getString(R.string.app_name));
        allow_Permission = findViewById(R.id.allow_Permission);
        dontallow_Permission = findViewById(R.id.dontallow_Permission);

        dontallow_Permission.setOnClickListener(view -> Toast.makeText(PermissionActivity.this,
                getString(R.string.permission_deny_msg1)
                , Toast.LENGTH_LONG).show());


        allow_Permission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    clickTime = Calendar.getInstance().getTimeInMillis();
                    Get_Permission();
                } else {
                    startNextScreen();
                }
            }
        });
    }

    private void Get_Permission() {

        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();

        if (!addPermission(permissionsList, Manifest.permission.READ_SMS))
            permissionsNeeded.add("Read SMS");

        if (!addPermission(permissionsList, Manifest.permission.POST_NOTIFICATIONS))
            permissionsNeeded.add("POST NOTIFICATIONS");

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                for (int i = 0; i < 1; i++)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
                    }

                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
            }
            return;
        }

    }


    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                return shouldShowRequestPermissionRationale(permission);
            }
        }

        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            long clickTime1 = Calendar.getInstance().getTimeInMillis();
            long difference = 0;
            if (clickTime1 >= clickTime) {
                difference = clickTime1 - clickTime;
            } else {
                difference = clickTime - clickTime1;
            }
            if (difference < 500) {
                Toast.makeText(PermissionActivity.this,
                        getString(R.string.permission_deny_msg)
                        , Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                startActivityForResult(intent, 05);
            }
            if (permissions.length >= 1) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startNextScreen();
                }
            }
        }

        return;

    }


    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 05) {

            if (isStoragePermissionGranted()) {
                startNextScreen();
            }
        }
    }


    public void showInterstitialAds() {
//        if (AdmobAdManager.getInstance().isNetworkAvailable(this)) {
//            if (AdmobAdManager.getInstance().isAdLoad) {
//                Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
//                i.putExtra("isInterShow", true);
//                startActivity(i);
//                finish();
////                startActivity(new Intent(this, AdsLoadActivity.class));
//            } else {
//                new Thread(() -> {
//                    while (!AdmobAdManager.getInstance().isAdLoad &&
//                            !AdmobAdManager.getInstance().isAdLoadFailed) {
//                        Log.d("TAG", "showInterstitialAd: ");
//                    }
//                    if (!AdmobAdManager.getInstance().isAdLoad) {
//                        Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
//                        startActivity(i);
//                        i.putExtra("isInterShow", true);
//                        finish();
//                    } else {
//                        Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
//                        i.putExtra("isInterShow", true);
//                        startActivity(i);
//                        finish();
//                        // startActivity(new Intent(PermissionActivity.this, AdsLoadActivity.class));
//                    }
//                }).start();
//            }
//        } else {
            Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
            startActivity(i);
            finish();
//        }
    }

    private void startNextScreen() {
        if (!PreferenceHelper.getFromBooleans(this, Constant.LANG_SELECTED, false)) {
            startActivity(new Intent(this, LanguageSelectActivity.class).putExtra("isFromSetting", false));
        } else {
            showInterstitialAds();
        }
    }

    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(PermissionActivity.this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ActivityCompat.checkSelfPermission(PermissionActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

}
