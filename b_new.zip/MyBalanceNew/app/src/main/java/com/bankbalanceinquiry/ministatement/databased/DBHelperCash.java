package com.bankbalanceinquiry.ministatement.databased;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.bankbalanceinquiry.ministatement.model.CashModelHistory;

import java.util.ArrayList;
import java.util.HashMap;

public class DBHelperCash extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "MyDBNameCASH.db";
    public static final String CONTACTS_TABLE_NAME = "Cash";
    public static final String CONTACTS_COLUMN_NAME = "name";
    private HashMap hp;

    public DBHelperCash(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Cash " +
                "(id integer primary key,TitleDateCash,dateValCash,AccountNo,AccountAmount,CheckIsDebitCredit,BankName)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Cash");
        onCreate(db);
    }

    public void DeleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from " + CONTACTS_TABLE_NAME);
    }


    public void InsertCash(String TitleDateCash, String dateValCash,
                           String AccountNo, String AccountAmount,
                           String CheckIsDebitCredit, String BankName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("TitleDateCash", TitleDateCash);
        contentValues.put("dateValCash", dateValCash);
        contentValues.put("AccountNo", AccountNo);
        contentValues.put("AccountAmount", AccountAmount);
        contentValues.put("CheckIsDebitCredit", CheckIsDebitCredit);
        contentValues.put("BankName", BankName);
        db.insert("Cash", null, contentValues);
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from Cash where id=" + id + "", null);
        return res;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
        return numRows;
    }


    public Integer deleteContact(String OwnerId) {
      /*  SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("Cash",
                "id = ? ",
                new String[]{Integer.toString(id)});*/
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("Cash",
                "OwnerId = ? ",
                new String[]{OwnerId});
    }


    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from Cash", null);
        return res;
    }

    public ArrayList<CashModelHistory> GetCash() {
        ArrayList<CashModelHistory> ownerDetails = new ArrayList<CashModelHistory>();
        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from Cash", null);
        if (res.getCount() == 0) {

        } else {
            while (res.moveToNext()) {
                String bankNameTitle = res.getString(res.getColumnIndex("TitleDateCash"));
                String dateValCash = res.getString(res.getColumnIndex("dateValCash"));
                String AccountNo = res.getString(res.getColumnIndex("AccountNo"));
                String AccountAmount = res.getString(res.getColumnIndex("AccountAmount"));
                String CheckIsDebitCredit = res.getString(res.getColumnIndex("CheckIsDebitCredit"));
                String BankName = res.getString(res.getColumnIndex("BankName"));

                ownerDetails.add(new CashModelHistory(bankNameTitle, dateValCash,
                        AccountNo, AccountAmount, CheckIsDebitCredit,
                        "", "", BankName));
            }
        }
        return ownerDetails;
    }
}
