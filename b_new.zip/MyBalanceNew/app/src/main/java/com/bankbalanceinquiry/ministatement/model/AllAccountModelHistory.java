package com.bankbalanceinquiry.ministatement.model;

import java.io.Serializable;
import java.util.ArrayList;

public class AllAccountModelHistory  implements Serializable {

    private int GetTitleType = 1;
    private boolean isSectionHeader = false;
    private String Title;
    private String SenderName;
    private String Accountno;
    private String Accountamount;
    private String creditdebit;
    private String Date;
    private String TitleDate;
    private String FinalDescription;
    private String TransferFrom;

    private ArrayList<String> CreditedData=new ArrayList<>();
    private ArrayList<String> DebitedData=new ArrayList<>();


   /* public AllAccountModelHistory(String title, String senderName) {
        Title = title;
        SenderName = senderName;
        isSectionHeader = false;
    }*/

    public AllAccountModelHistory(String TitleDate, String Date, String Accountno,
                                  String Accountamount, String creditdebit,
                                  String FinalDescription, String TransferFrom) {
        this.TitleDate = TitleDate;
        this.Date = Date;
        this.Accountno = Accountno;
        this.Accountamount = Accountamount;
        this.creditdebit = creditdebit;
        this.FinalDescription = FinalDescription;
        this.TransferFrom = TransferFrom;
    }

    public int getGetTitleType() {
        return GetTitleType;
    }

    public void setGetTitleType(int getTitleType) {
        GetTitleType = getTitleType;
    }

    public boolean isSectionHeader() {
        return isSectionHeader;
    }

    public void setSectionHeader(boolean sectionHeader) {
        isSectionHeader = sectionHeader;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getSenderName() {
        return SenderName;
    }

    public void setSenderName(String senderName) {
        SenderName = senderName;
    }

    public String getAccountno() {
        return Accountno;
    }

    public void setAccountno(String accountno) {
        Accountno = accountno;
    }

    public String getAccountamount() {
        return Accountamount;
    }

    public void setAccountamount(String accountamount) {
        Accountamount = accountamount;
    }

    public String getCreditdebit() {
        return creditdebit;
    }

    public void setCreditdebit(String creditdebit) {
        this.creditdebit = creditdebit;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTitleDate() {
        return TitleDate;
    }

    public void setTitleDate(String titleDate) {
        TitleDate = titleDate;
    }

    public String getFinalDescription() {
        return FinalDescription;
    }

    public void setFinalDescription(String finalDescription) {
        FinalDescription = finalDescription;
    }

    public String getTransferFrom() {
        return TransferFrom;
    }

    public void setTransferFrom(String transferFrom) {
        TransferFrom = transferFrom;
    }


    public ArrayList<String> getCreditedData() {
        return CreditedData;
    }

    public void setCreditedData(ArrayList<String> creditedData) {
        CreditedData = creditedData;
    }

    public ArrayList<String> getDebitedData() {
        return DebitedData;
    }

    public void setDebitedData(ArrayList<String> debitedData) {
        DebitedData = debitedData;
    }
}
