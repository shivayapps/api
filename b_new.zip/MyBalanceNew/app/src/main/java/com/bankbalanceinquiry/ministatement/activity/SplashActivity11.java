package com.bankbalanceinquiry.ministatement.activity;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RawRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.MyVideoView;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.example.app.ads.helper.interstitialad.InterstitialAdHelper;

import kotlin.Unit;
import kotlin.jvm.functions.Function2;


public class SplashActivity11 extends AppCompatActivity {

    CheckBox checkbox;
    AppCompatTextView tvPrivacyPolicy;
    TextView btnGetStarted;
    LinearLayout llGetStarted, llAds;
    private MyVideoView video_loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_11);
        Constant.isShplashScreen = true;
        Constant.isFirsttimeshow = false;
        loadVideoView();
        tvPrivacyPolicy = this.findViewById(R.id.tvPrivacyPolicy);
        checkbox = this.findViewById(R.id.checkbox);
        btnGetStarted = this.findViewById(R.id.btnGetStarted);
        llGetStarted = this.findViewById(R.id.llGetStarted);
        llAds = this.findViewById(R.id.llAds);
//        if (!PreferenceHelper.getFromBooleans(this, Constant.LANG_SELECTED, false)) {
//            if ((AdmobAdManager.getInstance().isNetworkAvailable(SplashActivity11.this))) {
//                AdmobAdManager.getInstance().LoadLanguageNativeAd(SplashActivity11.this,
//                        getString(R.string.admob_native_language_id), null);
//            }
//        }
//        if ((AdmobAdManager.getInstance().isNetworkAvailable(SplashActivity11.this))) {
//            AdmobAdManager.getInstance().loadInterstitialAd(this, getString(R.string.admob_interstitial_splash_id));
//        }

        if (PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.LOGIN_PREF).equals("")) {
            llGetStarted.setVisibility(View.VISIBLE);
            llAds.setVisibility(View.GONE);
        } else {
            llGetStarted.setVisibility(View.GONE);
            llAds.setVisibility(View.VISIBLE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    checkndStartNextActivity();
                }
            }, 1500);
            return;
        }
        String str = "By clicking continue button, you are agree to ";
        String privacyStr = "privacy policy";
        String and = " & ";
        String terms = "Terms and conditions";
        SpannableString SpanString = new SpannableString(
                str + privacyStr + and + terms);

        ClickableSpan teremsAndCondition = new ClickableSpan() {
            @Override
            public void onClick(View textView) {
                openLink(getString(R.string.privacy_policy), getString(R.string.privacy_policy));
            }
        };

        ClickableSpan privacy = new ClickableSpan() {
            @Override
            public void onClick(View textView) {
                openLink(getString(R.string.privacy_policy), getString(R.string.privacy_policy));
            }
        };
        SpanString.setSpan(privacy, str.length(), str.length() + privacyStr.length(), 0);
        SpanString.setSpan(teremsAndCondition, str.length() + privacyStr.length() + and.length(), str.length() + privacyStr.length() + and.length() + terms.length(), 0);
        SpanString.setSpan(new ForegroundColorSpan(Color.BLUE), str.length(), str.length() + privacyStr.length(), 0);
        SpanString.setSpan(new ForegroundColorSpan(Color.BLUE), str.length() + privacyStr.length() + and.length(), str.length() + privacyStr.length() + and.length() + terms.length(), 0);
        SpanString.setSpan(new UnderlineSpan(), str.length(), str.length() + privacyStr.length(), 0);
        SpanString.setSpan(new UnderlineSpan(), str.length() + privacyStr.length() + and.length(), str.length() + privacyStr.length() + and.length() + terms.length(), 0);

        tvPrivacyPolicy.setText(Html.fromHtml("By clicking 'Get Started' you are agree to " +
                "<a href='" + getString(R.string.privacy_policy) + "'>" + "<b> " +
                "Privacy Policy </b>" + "</a>" + " & " +
                "<a href='" + getString(R.string.privacy_policy) + "'>" + "<b> " +
                "Terms and conditions</b>" + "</a>" + "."
        ));
        tvPrivacyPolicy.setMovementMethod(LinkMovementMethod.getInstance());
        tvPrivacyPolicy.setLinkTextColor(ContextCompat.getColor(this, R.color.appColor));

        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        btnGetStarted.setBackgroundTintList(ContextCompat.getColorStateList(SplashActivity11.this,
                                R.color.appColor));
                    }
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        btnGetStarted.setBackgroundTintList(ContextCompat.getColorStateList(SplashActivity11.this,
                                R.color.appColorTrans));
                    }
                }
            }
        });
        checkbox.setSelected(true);
        btnGetStarted.setOnClickListener(view -> {
            if (!checkbox.isChecked()) {
                Toast.makeText(SplashActivity11.this, "Please check privacy policy & Terms condition", Toast.LENGTH_SHORT).show();
                return;
            }
            PreferenceHelper.saveToUserDefaults(getApplicationContext(), Constant.LOGIN_PREF, "1");
          /*  llGetStarted.setVisibility(View.GONE);
            llAds.setVisibility(View.VISIBLE);*/
            init();
        });
    }


    public static Uri getUriFromRawFile(Context context, @RawRes int rawResourceId) {
        return new Uri.Builder()
                .scheme(ContentResolver.SCHEME_ANDROID_RESOURCE)
                .authority(context.getPackageName())
                .path(String.valueOf(rawResourceId))
                .build();
    }


    private void loadVideoView() {
        video_loading = findViewById(R.id.video_loading);
        Uri video = getUriFromRawFile(this, R.raw.splash_video);
        video_loading.setSource(video);
        video_loading.setLooping(true);
    }

    private void checkndStartNextActivity() {
     /*   if ((AdmobAdManager.getInstance().isNetworkAvailable(SplashActivity11.this))) {
            startActivity(new Intent(this, Splash2Activity.class));
            finish();
        } else {*/
        init();
        //  }
    }

    private void openLink(String title, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (i.resolveActivity(getPackageManager()) != null) {
                startActivity(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void init() {

        if (!PreferenceHelper.getFromBooleans(this, Constant.LANG_SELECTED, false)) {
            showInterstitialAds(true);
        } else {
            if (isStoragePermissionGranted()) {
                showInterstitialAds(false);
            } else {
                startActivity(new Intent(this, PermissionActivity.class).putExtra("isFromSetting", false));
            }
        }
    }


    public void showInterstitialAds(boolean showLanguage) {
        if (showLanguage) {
            showLangaugeScreen();
            return;
        } else {
            if(NetworkManager.isNetworkAvailable(SplashActivity11.this) &&
                    new AdsManager(SplashActivity11.this).isNeedToShowIntAds()) {

                InterstitialAdHelper.INSTANCE.showInterstitialAd(SplashActivity11.this, true, new Function2<Boolean, Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean isAdShowing, Boolean isShowFullScreenAd) {
                        Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
                        i.putExtra("isInterShow", true);
                        startActivity(i);
                        finish();
                        return null;
                    }
                });
            } else {
                Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
                i.putExtra("isInterShow", true);
                startActivity(i);
                finish();
            }
        }
        /*
        if (AdmobAdManager.getInstance().isNetworkAvailable(this)) {
            if (AdmobAdManager.getInstance().isAdLoad) {
                Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
                i.putExtra("isInterShow", true);
                startActivity(i);
                finish();
                // startActivity(new Intent(this, AdsLoadActivity.class));
            } else {
                new Thread(() -> {
                    while (!AdmobAdManager.getInstance().isAdLoad &&
                            !AdmobAdManager.getInstance().isAdLoadFailed) {
                        Log.d("TAG", "showInterstitialAd: ");
                    }
                    if (!AdmobAdManager.getInstance().isAdLoad) {
                        Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
                        i.putExtra("isInterShow", true);
                        startActivity(i);
                        finish();
                    } else {
                        Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
                        i.putExtra("isInterShow", true);
                        startActivity(i);
                        finish();
                        //  startActivity(new Intent(SplashActivity11.this, AdsLoadActivity.class));
                    }

                }).start();
            }
        } else {
            if (showLanguage) {
                showLangaugeScreen();
            } else {
                Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
                startActivity(i);
                finish();
            }
        }*/
    }

    private void showLangaugeScreen() {
        Intent mainIntent = new Intent(SplashActivity11.this, LanguageSelectActivity.class);
        startActivity(mainIntent);
        finish();
    }

    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(SplashActivity11.this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ActivityCompat.checkSelfPermission(SplashActivity11.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return true;
        }
    }


}