package com.bankbalanceinquiry.ministatement.currency.view.main

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.text.HtmlCompat
import androidx.lifecycle.ViewModelProvider
import com.bankbalanceinquiry.ministatement.R
import com.bankbalanceinquiry.ministatement.currency.util.humanReadableFee
import com.bankbalanceinquiry.ministatement.currency.view.preference.CurrencyPreferenceActivity
import com.bankbalanceinquiry.ministatement.currency.viewmodel.main.CurrentInputViewModel
import com.bankbalanceinquiry.ministatement.currency.viewmodel.main.ExchangeRatesViewModel
import com.bankbalanceinquiry.ministatement.currency.widget.searchablespinner.SearchableSpinner
import com.bankbalanceinquiry.ministatement.inapp.AdsManager
import com.bankbalanceinquiry.ministatement.utils.NetworkManager
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_currency.*
import java.util.*

class CurrencyActivity : AppCompatActivity() {

    private lateinit var ratesModel: ExchangeRatesViewModel
    private lateinit var inputModel: CurrentInputViewModel

    private lateinit var refreshIndicator: LinearProgressIndicator
    private lateinit var tvCalculations: TextView
    private lateinit var tvFrom: TextView
    private lateinit var tvTo: TextView
    private lateinit var tvCurrencyFrom: TextView
    private lateinit var tvCurrencyTo: TextView
    private lateinit var spinnerFrom: SearchableSpinner
    private lateinit var spinnerTo: SearchableSpinner
    private lateinit var tvDate: TextView
    private lateinit var tvFee: TextView
    private lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // general layout
        setContentView(R.layout.activity_currency)
        title = null

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.ic_drawer));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.app_color)
        }

        // model
        this.ratesModel = ViewModelProvider(this).get(ExchangeRatesViewModel::class.java)
        this.inputModel = ViewModelProvider(this).get(CurrentInputViewModel::class.java)

        // views
        this.refreshIndicator = findViewById(R.id.refreshIndicator)
        this.tvCalculations = findViewById(R.id.textCalculations)
        this.tvFrom = findViewById(R.id.textFrom)
        this.tvTo = findViewById(R.id.textTo)
        this.tvCurrencyFrom = findViewById(R.id.currencyFrom)
        this.tvCurrencyTo = findViewById(R.id.currencyTo)
        this.spinnerFrom = findViewById(R.id.spinnerFrom)
        this.spinnerTo = findViewById(R.id.spinnerTo)
        this.tvDate = findViewById(R.id.textRefreshed)
        this.tvFee = findViewById(R.id.textFee)

        initToolBar()
        // listeners & stuff
        setListeners()

        // heavy lifting
        observe()

        if (AdsManager(this@CurrencyActivity).isNeedToShowAds()
            && NetworkManager.isInternetConnected(this@CurrencyActivity)
        ) {
            NativeAdvancedModelHelper(this@CurrencyActivity).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                adLayout
            )
        }
    }

    private fun initToolBar() {
        toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.setTitle("Currency Converter")
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.ic_drawer));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = getColor(R.color.app_color)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_currency, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
                true
            }
            R.id.settings -> {
                if (AdsManager(this@CurrencyActivity).isNeedToShowAds()
                    && NetworkManager.isInternetConnected(this@CurrencyActivity)
                ) {
                    isShowInterstitialAd { aBoolean: Boolean? ->
                        startActivity(
                            Intent(
                                this@CurrencyActivity,
                                CurrencyPreferenceActivity::class.java
                            )
                        )
                    }
                } else {
                    startActivity(
                        Intent(
                            this@CurrencyActivity,
                            CurrencyPreferenceActivity::class.java
                        )
                    )
                }
//                startActivity(Intent(this, CurrencyPreferenceActivity().javaClass))
                true
            }
            R.id.refresh -> {
                ratesModel.forceUpdateExchangeRate()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setListeners() {
        // long click on delete
        findViewById<ImageButton>(R.id.btn_delete).setOnLongClickListener {
            inputModel.clear()
            true
        }

        // long click on input "from"
        findViewById<LinearLayout>(R.id.clickFrom).setOnLongClickListener {
            val copyText =
                "${it.findViewById<TextView>(R.id.currencyFrom).text} ${it.findViewById<TextView>(R.id.textFrom).text}"
            copyToClipboard(copyText)
            true
        }
        // long click on input "to"
        findViewById<LinearLayout>(R.id.clickTo).setOnLongClickListener {
            val copyText =
                "${it.findViewById<TextView>(R.id.currencyTo).text} ${it.findViewById<TextView>(R.id.textTo).text}"
            copyToClipboard(copyText)
            true
        }

        // spinners: listen for changes
        spinnerFrom.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                inputModel.setCurrencyFrom(
                    (parent?.adapter as SpinnerAdapter).getItem(position)
                )
            }
        }
        spinnerTo.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                inputModel.setCurrencyTo(
                    (parent?.adapter as SpinnerAdapter).getItem(position)
                )
            }
        }
    }

    private fun copyToClipboard(copyText: String) {
        // copy
        val clipboard: ClipboardManager =
            getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(null, copyText))
        // notify
        Snackbar.make(
            tvCalculations,
            HtmlCompat.fromHtml(
                getString(R.string.copied_to_clipboard, copyText),
                HtmlCompat.FROM_HTML_MODE_LEGACY
            ),
            Snackbar.LENGTH_SHORT
        ).setBackgroundTint(resources.getColor(R.color.colorAccent)).show()
    }

    private fun observe() {
        //exchange rates changed
        ratesModel.getExchangeRate().observe(this, {
            // date
//            val simpleDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
//            val dateString = it?.let { simpleDateFormat.format(it) }
//            it?.let {
//                val date = it.date?.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
//                tvDate.text = getString(R.string.last_updated, date)
//            }
            // rates
            spinnerFrom.adapter = it?.rates?.let { rates ->
                SpinnerAdapter(this, android.R.layout.simple_spinner_item, rates)
            }
            spinnerTo.adapter = it?.rates?.let { rates ->
                SpinnerAdapter(this, android.R.layout.simple_spinner_item, rates)
            }
            // restore state
            inputModel.getLastRateFrom()?.let { last ->
                (spinnerFrom.adapter as? SpinnerAdapter)?.getPosition(last)?.let { position ->
                    spinnerFrom.setSelection(position)
                }
            }
            inputModel.getLastRateTo()?.let { last ->
                (spinnerTo.adapter as? SpinnerAdapter)?.getPosition(last)?.let { position ->
                    spinnerTo.setSelection(position)
                }
            }
        })
        ratesModel.getError().observe(this, {
            // error
            it?.let {
                Snackbar.make(tvCalculations, it, Snackbar.LENGTH_LONG)
                    .setBackgroundTint(getResources().getColor(android.R.color.holo_red_light))
                    .show()
            }
        })
        ratesModel.isUpdating().observe(this, { isRefreshing ->
            refreshIndicator.visibility = if (isRefreshing) View.VISIBLE else View.GONE
        })

        // input changed
        inputModel.getCurrentInput().observe(this, {
            tvFrom.text = it
        })
        inputModel.getCurrentInputConverted().observe(this, {
            tvTo.text = it
        })
        inputModel.getCalculationInput().observe(this, {
            tvCalculations.text = it
        })
        inputModel.getCurrencyFrom().observe(this, {
            tvCurrencyFrom.text = it
        })
        inputModel.getCurrencyTo().observe(this, {
            tvCurrencyTo.text = it
        })

        // fee changed
        inputModel.getFeeEnabled().observe(this, {
            tvFee.visibility = if (it) View.VISIBLE else View.GONE
        })
        inputModel.getFee().observe(this, {
            tvFee.text = it.humanReadableFee(this)
            tvFee.setTextColor(
                if (it >= 0) {
                    getResources().getColor(android.R.color.holo_red_light)
                } else getResources().getColor(R.color.dollarBill)
            )
        })
    }

    fun numberEvent(view: View) {
        inputModel.addNumber((view as Button).text.toString())
    }

    fun decimalEvent(@Suppress("UNUSED_PARAMETER") view: View) {
        inputModel.addDecimal()
    }

    fun deleteEvent(@Suppress("UNUSED_PARAMETER") view: View) {
        inputModel.delete()
    }

    fun calculationEvent(view: View) {
        when ((view as Button).text.toString()) {
            "+" -> inputModel.addition()
            "−" -> inputModel.subtraction()
            "×" -> inputModel.multiplication()
            "÷" -> inputModel.division()
        }
    }

    fun toggleEvent(@Suppress("UNUSED_PARAMETER") view: View) {
        val from = spinnerFrom.selectedItemPosition
        val to = spinnerTo.selectedItemPosition
        spinnerFrom.setSelection(to)
        spinnerTo.setSelection(from)
    }

}
