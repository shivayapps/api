package com.bankbalanceinquiry.ministatement.utils;

import static android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;

import com.bankbalanceinquiry.ministatement.Events.ServiceStop;
import com.bankbalanceinquiry.ministatement.Events.SmsList;
import com.bankbalanceinquiry.ministatement.Events.SmsProgress;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.databased.StoreValue;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.model.newTransactionDataEvent;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.bankbalanceinquiry.ministatement.notification.DefaultNotificationReceiver;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsService extends Service {



    private final ArrayList<HomeAccoutList> homeAccoutLists = new ArrayList<>();
    private final ArrayList<HomeAccoutList> allTransactionList = new ArrayList<>();

    private final ArrayList<String> tempAccountNo = new ArrayList<>();
    public static int TotalCount = 0;
    public static int smsCount = 0;
    private String BankName;
    private final int SCREEN_RECORDER_NOTIFICATION_ID = 99;
    private boolean isStop = false;
    public static boolean isProcessRunning = false;
    DBHelperAccountNew mydbAccountNew;

    public static boolean isShowProgress = true;


    private final ArrayList<HomeAccoutList> homeAccoutLists1 = new ArrayList<>();
    HashMap<String, HomeAccoutList> hashData = new HashMap<>();
    private boolean isLangChanged = false;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);
        setNotification(false);
        mydbAccountNew = new DBHelperAccountNew(SmsService.this);
        isProcessRunning = true;
        if (intent.hasExtra("isShowProgress")) {
            isShowProgress = intent.getBooleanExtra("isShowProgress", true);
        } else {
            isShowProgress = true;
        }
        if (!mydbAccountNew.isDataAvailable()) {
            isShowProgress = true;
        }
        Uri message = Uri.parse("content://sms/inbox");
        ContentResolver cr = getContentResolver();
        mydbAccountNew.removeduplicateData();
        Date lastDateValue = mydbAccountNew.getLastTransactionDate();
        final Cursor c;
        /*  if (lastDateValue == 0) {*/
        c = cr.query(message, null, null, null, "date DESC");
        //}

        int totalSMS = 0;
        if (c != null) {
            totalSMS = c.getCount();
        }
        TotalCount = totalSMS;

        final int finalTotalSMS = totalSMS;
        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                isProcessRunning = true;

                //  JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(SmsService.this, "sms/rulestmp");
                //  JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(SmsService.this, "sms/rules_final_updated");
//                JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(SmsService.this, "sms/rules_new");

                JSONObject jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonObject(SmsService.this, "sms/rules1");

//                String t = "VK- YESBNK";
//                String b = "Rs 29,000.00 debited to Ac XX0101 on 09-JUN 14:17 for NEFT to 023443546-PARAS BHALODIYA. UTRNO is 200402668955-100. Tot Avbl Bal after TXN is Rs 605,722.90. In case you have not done this transaction, SMS BLKRNB <Space><Cust ID or LoginID> to 9840909000 from your registered mobile number to block RetailNetBanking and YES Robot services.";
//
//                CheckisTransactionSms(jsonArray, t, b, System.currentTimeMillis());
//
////                String t1 = "56161940";
////                String b1 = "Bill paid for Gujarat Gas Limited Customer ID 500001317268. Amount - Rs.1570.00. BBPS Ref#: BD01CAA9L9S9. Details:https://amzn.in/d/f3OLol7";
////
////                CheckisTransactionSms(jsonArray, t1, b1, System.currentTimeMillis());
////
////                String t2 = "GUJGAS";
////                String b2 = "Dear customer, (ID: 500001113847) Your Gujarat Gas Bill For Aug-Oct,2019 of Rs.1168/-is generated (including outstanding, if any). Bill Due Date is 12/11/2019.";
////
////                CheckisTransactionSms(jsonArray, t2, b2, System.currentTimeMillis());
//
//
//                String t2 = "GUJGAS";
//                String b2 = "Dear customer, Your Gujarat Gas Bill of Rs.1168/-for customer no 500001113847 is due on 12/11/2019. PI pay before due date to avoid penalty. Ignore if paid.";
//                CheckisTransactionSms(jsonArray, t2, b2, System.currentTimeMillis());
//
//
////                String t3 = "ICICIB";
////                String b3 = "Dear Customer, your Account XX982 has been credited with INR 22,000.00 on 10-Jul-20. Info: NEFT-N192200411596615-P PADS. Available Balance: INR 24,873.08";
////                CheckisTransactionSms(jsonArray, t3, b3, System.currentTimeMillis());
//
//
//                String t3 = "ICICIB";
//                String b3 = "Acct XX416 debited with INR 510.00 on 14-jan-2020.Info: BIL*ONL*00189.Avbl Bal:INR 6,44,021.15.Call 18002662 for dispute or SMS BLOCK 545 to 9215676766";
//                b3 = b3.replace("*", "");
//                CheckisTransactionSms(jsonArray, t3, b3, System.currentTimeMillis());
//
//                String t4 = "ICICIB";
//                String b4 = "Acct XX416 debited with INR 18,000.00 on 27-aug-19 & Acct XX791 credited. IMPS: 923914825731. Call 18002662 for dispute or SMS BLOCK 416 to 9215676766";
//                CheckisTransactionSms(jsonArray, t4, b4, System.currentTimeMillis());
//
//
//                String t5 = "AMAZON";
//                String b5 = "Bill paid for Gujarat Gas Limited Customer ID 500001317268. Amount - Rs.1570.00. BBPS Ref#: BD01CAA9L9S9. Details:https://amzn.in/d/f3OLol7";
//                CheckisTransactionSms(jsonArray, t5, b5, System.currentTimeMillis());
//
//                String t6 = "AMAZON";
//                String b6 = "Bill paid for Dakshin Gujarat Vij Consumer ID 41270281650. Amount - Rs.4920.00. BBPS Ref#: BD01CABBP53Q. Details:https://amzn.in/d/f3OLol7";
//                CheckisTransactionSms(jsonArray, t6, b6, System.currentTimeMillis());
//
//
//                String t7 = "LZYPAY";
//                String b7 = "Dear Customer, your payment of Rs.265.00 for txn LPTX22727222 on Swiggy was successfully. Pay by 3rd July,2019 using http://pmny.in/flDe0A2Nhvcv";
//                CheckisTransactionSms(jsonArray, t7, b7, System.currentTimeMillis());
//
//
//                String t8 = "IPAYTM";
//                String b8 = "Paid Rs. 149 to Paytm Mobile Bill Payment on Jun 17,2020 11:05:41 With Ref: 30207076186. For more details, visit: https://p-y.tm/Uf-Aqtq";
//                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd,yyyy", Locale.US);
//                try {
//                    Date date = simpleDateFormat.parse("Jun 17,2020");
//                    if (date != null) {
//                        CheckisTransactionSms(jsonArray, t8, b8, date.getTime());
//                    }
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//
//                String t9 = "ICICIB";
//                String b9 = "Dear Customer,EMI of Rs. 22446 towards ICICI Bank Loan Account XX9767 is due on 10-Jul-20.";
//                SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd-MMM-yy", Locale.US);
//                try {
//                    Date date = simpleDateFormat1.parse("10-Jul-20");
//                    if (date != null) {
//                        CheckisTransactionSms(jsonArray, t9, b9, date.getTime());
//                    }
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//
//
//                String t10 = "IPAYTM";
//                String b10 = "Paid Rs. 2399 to Paytm Idea Mobile Recharge on May 28,2020 15:55:15 With Ref: 30020366957. For more details, visit: https://p-y.tm/Uf-Aqtq";
//                SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MMM dd,yyyy", Locale.US);
//                try {
//                    Date date = simpleDateFormat2.parse("May 28,2020");
//                    if (date != null) {
//                        CheckisTransactionSms(jsonArray, t10, b10, date.getTime());
//                    }
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//
//                String t11 = "VK- YESBNK";
//                String b11 = "INR 10,483.00 is credited to A/C No.XX0101 on 01-Jul-20 02:27:53 - Credit Interest Capitalised. Tot avbl bal-146,205.90 0n 01-Jul-20 04:04:26";
//                SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("dd-MMM-yy", Locale.US);
//                try {
//                    Date date = simpleDateFormat3.parse("01-Jul-20");
//                    if (date != null) {
//                        CheckisTransactionSms(jsonArray, t11, b11, date.getTime());
//                    }
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }
//
//                String t12 = "ICICIB";
//                String b12 = "Dear Customer, stmt for Credit Card XX7008 has been sent to padshalakalpesh00@gmail.com. Total amt of Rs. 11483 or Min. amt of Rs. 580 is due by 15-FEB-19.";
//                SimpleDateFormat simpleDateFormat4 = new SimpleDateFormat("dd-MMM-yy", Locale.US);
//                try {
//                    Date date = simpleDateFormat4.parse("15-FEB-19");
//                    if (date != null) {
//                        CheckisTransactionSms(jsonArray, t12, b12, date.getTime());
//                    }
//                } catch (ParseException e) {
//                    e.printStackTrace();
//                }

                if (c != null && c.moveToFirst()) {
                    for (int i = 0; i < finalTotalSMS && !isStop; i++) {
                        String BankNameTitle = c.getString(c.getColumnIndexOrThrow("address"));

                        String body = c.getString(c.getColumnIndexOrThrow("body"));
                        String datestr = c.getString(c.getColumnIndexOrThrow("date"));
                        long dateV = Long.parseLong(datestr);
                       /* if (dateV * 1000 > lastDateValue) {
                            CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);
                        }*/
                        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd MMM yyyy", Locale.US);
                        String ddd = simpleDateFormat1.format(new Date(dateV));
                        try {
                            Date date3 = simpleDateFormat1.parse(ddd);
//                            Log.e("dfkcjbskjfchjdjhg", body + "::" + date3);

                           /*
                            Calendar cal = Calendar.getInstance();
                            Date today = cal.getTime();
                            System.out.println("Current Date: " + today);
                            cal.add(Calendar.DAY_OF_YEAR, -2);
                            Date datedays = cal.getTime();
                            //  Date daysAgo = new Date(lastDateValue.getTime() - Duration.ofDays(2).toMillis());
                            if (!PreferenceHelper.getFromBooleans(SmsService.this, Constant.IS_FIRST_LOADING_DONE, false)) {
                                if (new Date(dateV).before(datedays)) {
                                    CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);
                                }
                            }else {
                                if (!isShowProgress) {
                                    if (new Date(dateV).before(datedays)) {
                                        CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);
                                    }
                                } else {
                                    if (lastDateValue != null) {
                                        if (date3.after(lastDateValue)) {
                                            CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);
                                        }
                                    } else {
                                        CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);
                                    }
                                }
                            }*/
                            if (lastDateValue != null) {
                                if (date3.after(lastDateValue)) {
                                    CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);
                                }
                            } else {
                                CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);
                            }

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }


                        smsCount = i;
                        setNotification(true);
                        EventBus.getDefault().post(new SmsProgress(i, isShowProgress));
                        while (isLangChanged) {
                            Log.e("dssssjhgvbjdvkjbh", "SERVICE_CURS" + isLangChanged);
                        }
                        c.moveToNext();

                    }
                    c.close();
                }
                CallHomeScreenAllAccoutNew();
            }
        }).start();

        return START_NOT_STICKY;
    }


    public static String removeUnUsed(String string1) {
        if (string1.contains(". UPI:")) {
            if (string1.contains("credited with")) {
                string1 = string1.replace("UPI:", "UPI ref no ");
            } else if (string1.contains("debited for")) {

                string1 = string1.replace(" UPI:", "UPI:");
                string1 = string1.replace(";", ".");
            }
        }
        return string1;
    }

    private void addNotification() {
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), MODE_PRIVATE);
        if (!sharedPreferences.getBoolean("isDefaultNotificationAdd", false)) {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);

            Intent intent = new Intent(getApplicationContext(), DefaultNotificationReceiver.class);
            PendingIntent pendingIntent = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), PreferenceHelper.getNotificationRequestCode(getApplicationContext()), intent, PendingIntent.FLAG_IMMUTABLE);
            } else {
                pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), PreferenceHelper.getNotificationRequestCode(getApplicationContext()), intent, PendingIntent.FLAG_UPDATE_CURRENT);
            }
            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (alarmManager != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (canExactAlarmsBeScheduled()) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                    } else {
                        new AlertDialog.Builder(this)
                                .setMessage(getString(R.string.bootstrap_need_permission_to_schedule_alarms))
                                .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        Intent ii = new Intent(ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                                        ii.setData(Uri.fromParts("package:", SmsService.this.getPackageName(), null));
                                        ii.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(ii);
                                    }
                                });
                    }
                }

            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
            }

            PreferenceHelper.setNotificationRequestCode(getApplicationContext(), PreferenceHelper.getNotificationRequestCode(getApplicationContext()) + 1);
            Log.e("TAG", "main activity notification onReceive: ");
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isDefaultNotificationAdd", true);
        editor.apply();
    }


    private Boolean canExactAlarmsBeScheduled() {
        AlarmManager alarmManager = (AlarmManager) this.getSystemService(ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return alarmManager.canScheduleExactAlarms();
        } else {
            return true;
        }
    }

    public void checkAndAdDate(HomeAccoutList alldata) {
        /*String nameKey = alldata.full_name + "_" + alldata.FinalAccountNo;
        long currentValue = alldata.dateLong;
        if (timeDateList.containsKey(nameKey) && timeDateList.get(nameKey) < currentValue) {
            timeDateList.put(nameKey, currentValue);
        } else if (!timeDateList.containsKey(nameKey)) {
            timeDateList.put(nameKey, currentValue);
        }*/
    }


    @Subscribe
    public void OnSmsProgress(final Intent intent) {
        if (intent != null && intent.getAction().equalsIgnoreCase("LANG_CHANGED")) {
            if (!intent.getBooleanExtra("isUpdate", false)) {
                isLangChanged = true;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        EventBus.getDefault().post(new newTransactionDataEvent(homeAccoutLists1, hashData, true));
                    }
                }, 1500);

            } else {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        isLangChanged = false;
                    }
                }, 300);
            }

        }
    }


    private void addTransactionDataToDatabase(HomeAccoutList homeAccount) {
        while (isLangChanged) {
            Log.e("dssssjhgvbjdvkjbh", "TRANSAC" + isLangChanged);
        }
        mydbAccountNew.InsertTransaction(homeAccount);
        String key = homeAccount.full_name + "_" + homeAccount.FinalAccountNo;
        boolean isUpdateBalance = false;
        if (hashData.containsKey(key)) {
            if (TextUtils.isEmpty(hashData.get(key).FinalAccountBalance) &&
                    !TextUtils.isEmpty(homeAccount.FinalAccountBalance)) {
                HomeAccoutList data = hashData.get(key);
                data.FinalAccountBalance = homeAccount.FinalAccountBalance;
                hashData.put(key, data);
                isUpdateBalance = true;
                EventBus.getDefault().post(new newTransactionDataEvent(false, isUpdateBalance, key, homeAccoutLists1, hashData));
            }
        }
    }

    private void addHomeDataToDataBase(HomeAccoutList homeAccount) {
        try {
            while (isLangChanged) {
                Log.e("dssssjhgvbjdvkjbh", "ACCO" + isLangChanged);
            }
            ArrayList<HomeAccoutList> newInsertedAccoutLists = new ArrayList<>();
            boolean isInsert = mydbAccountNew.InsertAccount(homeAccount);
            if (isInsert) {
                newInsertedAccoutLists.add(homeAccount);
                String key = homeAccount.full_name + "_" + homeAccount.FinalAccountNo;
                if (!hashData.containsKey(key)) {
                    hashData.put(key, homeAccount);
                    homeAccoutLists1.add(homeAccount);
                }
                EventBus.getDefault().post(new newTransactionDataEvent(homeAccoutLists1, hashData, false));
            }

            if (newInsertedAccoutLists.size() > 0) {
                EventBus.getDefault().post(new Intent().setAction("NEW_BANK_FOUND").putExtra("count", newInsertedAccoutLists.size()));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void CallHomeScreenAllAccoutNew() {

        if (!PreferenceHelper.getFromBooleans(this, Constant.IS_FIRST_LOADING_DONE, false)) {
            PreferenceHelper.saveToBooleans(this, Constant.IS_FIRST_LOADING_DONE, true);
        }
        isProcessRunning = false;

        int accounts = mydbAccountNew.numberOfAccounts();
        int sms = TotalCount;
        Intent ii = new Intent(this, SmsDoneDataService.class);
        ii.putExtra("MsgCount", sms);
        ii.putExtra("AccountCount", accounts);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                StoreValue.SetFirstime("OK", "Ok");
                CommonFun.IsAllSmsmFill = "AllFill";
                EventBus.getDefault().post(new SmsList(homeAccoutLists, allTransactionList));
                addNotification();
                stopForeground(true);
                PreferenceHelper.saveToUserDefaults(getApplicationContext(), Constant.TRACK_PREF, "1");
                stopSelf();
                startService(ii);
            }
        }, 1000);
    }


    @Subscribe
    public void OnServiceStop(ServiceStop serviceStop) {
        isStop = true;
    }

    private void CheckisTransactionSms(JSONObject jsonObject, String bankNameTitle, String body, long dateV) {
//        JSONObject jsonObject;
        JSONArray senderss;
        int mObjectPosition = 999;

        if (body == null && TextUtils.isEmpty(body)) {
            return;
        }
        SimpleDateFormat formatterAccount = new SimpleDateFormat("dd MMMM yyyy", Locale.US);
        SimpleDateFormat FormateMontHistory = new SimpleDateFormat("MMMM", Locale.US);
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);
        String Regx = jsonObject.optString("blacklist_regex");
        Pattern regEx = Pattern.compile(Regx);
        Matcher m = regEx.matcher(body);
        JSONArray jsonArray = null;
        HomeAccoutList homeAccount = new HomeAccoutList();
        homeAccount.body = body;


//        if(jsonArray)
        if (!m.find()) {
            try {
                jsonArray = jsonObject.getJSONArray("rules");
                if (!TextUtils.isEmpty(bankNameTitle)) {
                    if (jsonArray != null) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObject = jsonArray.optJSONObject(i);
                            senderss = jsonObject.optJSONArray("senders");
                            if (senderss != null) {
                                for (int j = 0; j < senderss.length(); j++) {
                                    try {
                                        String SenderName = senderss.get(j).toString();
                                        if (bankNameTitle.toLowerCase().contains(SenderName.toLowerCase())) {
                                            mObjectPosition = i;
                                            homeAccount.full_name = jsonObject.getString("full_name");
                                            break;
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    }
                    if (mObjectPosition != 999) {
                        try {
                            getTransectionDetails(homeAccount, body, jsonArray.getJSONObject(mObjectPosition), bankNameTitle);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        homeAccount.dateValAccount = formatterAccount.format(new Date(dateV));
        homeAccount.DateTransactionHistory = FormateMontHistory.format(new Date(dateV));
        homeAccount.dateValHistory = formatterHistory.format(new Date(dateV));


        if (homeAccount.account_type.equalsIgnoreCase("electricity")) {
            try {
                if (jsonArray != null) {
                    JSONObject object = jsonArray.getJSONObject(mObjectPosition);
                    JSONArray senders = object.optJSONArray("senders");
                    if (senders != null) {
                        for (int j = 0; j < senders.length(); j++) {
                            try {
                                String SenderName = senders.get(j).toString();
                                if (bankNameTitle.toLowerCase().contains(SenderName.toLowerCase())) {
                                    homeAccount.full_name = SenderName;
                                    break;
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        // Account List
        if (!homeAccount.account_type.equalsIgnoreCase("phone")) {
            if (!TextUtils.isEmpty(homeAccount.FinalAccountBalance) || homeAccount.account_type.equalsIgnoreCase("prepaid") || homeAccount.account_type.equalsIgnoreCase("bill_pay")) {
                if (!TextUtils.isEmpty(homeAccount.full_name)) {
                    if (!TextUtils.isEmpty(homeAccount.FinalAccountNo)) {
                        if (homeAccount.FinalAccountNo.length() > 4) {
                            homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
                        }
                        if (tempAccountNo.size() != 0) {
                            if (!tempAccountNo.contains(homeAccount.FinalAccountNo)) {
                                boolean isF = false;
                                for (int i = 0; i < tempAccountNo.size() && !isF; i++) {
                                    if (tempAccountNo.get(i).length() > homeAccount.FinalAccountNo.length()) {
                                        if (tempAccountNo.get(i).contains(homeAccount.FinalAccountNo)) {
                                            isF = true;
                                            homeAccount.FinalAccountNo = tempAccountNo.get(i);
                                        }
                                    } else {
                                        if (homeAccount.FinalAccountNo.contains(tempAccountNo.get(i))) {
                                            isF = true;
                                            homeAccount.FinalAccountNo = tempAccountNo.get(i);
                                        }
                                    }
                                }
                                if (!isF) {
                                    homeAccoutLists.add(homeAccount);
                                    tempAccountNo.add(homeAccount.FinalAccountNo);
                                    addHomeDataToDataBase(homeAccount);
                                }

                            }
                        } else {
                            homeAccoutLists.add(homeAccount);
                            tempAccountNo.add(homeAccount.FinalAccountNo);
                            addHomeDataToDataBase(homeAccount);

                        }
                    } else {

                        if (!tempAccountNo.contains(homeAccount.full_name)) {
                            homeAccoutLists.add(homeAccount);
                            tempAccountNo.add(homeAccount.full_name);
                            addHomeDataToDataBase(homeAccount);

                        }
                    }

                }
            }
        }


        // Account History
        if (!TextUtils.isEmpty(homeAccount.full_name)) {
            if (!TextUtils.isEmpty(homeAccount.amount)) {
                String amount = homeAccount.amount.replaceAll(",", "");
                homeAccount.amount = amount;
//                if (homeAccount.FinalAccountNo.length() > 4) {
//                    homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
//                }

                if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
                    if (!TextUtils.isEmpty(homeAccount.mTransactionType)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.mTransactionType);
                    } else if (!TextUtils.isEmpty(homeAccount.txn_type)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.txn_type);
                    } else {
                        homeAccount.transactionDesc = "Unknown Transaction";
                    }
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("atm") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_atm")) {
                    homeAccount.transactionDesc = "ATM withdrawal";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("debit") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_card")) {
                    homeAccount.transactionDesc = "Debit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card")) {
                    homeAccount.transactionDesc = "Credit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card_bill")) {
                    homeAccount.transactionDesc = "Credit Card Bill";
                }

                if (!TextUtils.isEmpty(homeAccount.transactionPos)) {
                    homeAccount.finalTransactionDesc = homeAccount.transactionPos;
                } else if (homeAccount.transactionDescs.size() != 0) {
                    for (String s : homeAccount.transactionDescs) {
                        if (!TextUtils.isEmpty(s)) {
                            homeAccount.finalTransactionDesc = s;
                            break;
                        }
                    }
                }
                if (homeAccount.account_type.equalsIgnoreCase("prepaid")) {
                    if (homeAccount.transactionPos.toLowerCase().contains("recharge") || homeAccount.transactionPos.toLowerCase().contains("mobile")) {
                        homeAccount.account_type = "phone";
                    }
                }
                allTransactionList.add(homeAccount);
                addTransactionDataToDatabase(homeAccount);
                checkAndAdDate(homeAccount);
            }
        }
    }


    public void setNotification(boolean isUpdate) {
        String CHANNEL_ID = "com.balancecheck";
        Intent notificationIntent = new Intent();
        PendingIntent pendingIntent = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            pendingIntent = PendingIntent.getActivity(
                    this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        } else {
            pendingIntent = PendingIntent.getActivity(
                    this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        }

        int notificationId = SCREEN_RECORDER_NOTIFICATION_ID;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String channelName = "balancecheck";
        String description = "balancecheck";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel chan = new NotificationChannel(CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_LOW);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            chan.setDescription(description);
            chan.setSound(null, null);
            chan.enableLights(false);
            chan.setLightColor(Color.BLUE);
            chan.enableVibration(false);
            chan.setShowBadge(false);
            if (manager != null) {
                manager.createNotificationChannel(chan);
            }
        }
        int progress = 0;
        if (TotalCount != 0 && smsCount != 0) {
            progress = (smsCount * 100) / TotalCount;
        }
        NotificationCompat.Builder notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.account_balance)
                .setContentTitle("Analyzing From Sms Service")
                .setContentText(smsCount + "/" + (TotalCount - 1))
                .setProgress(100, isUpdate ? progress : 0, false)
                .setAutoCancel(false)
                .setOngoing(true)
                .setContentIntent(pendingIntent);


        if (!isUpdate) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startForeground(notificationId, notification.build());
            } else {
                if (manager != null) {
                    manager.notify(notificationId, notification.build());
                }
            }
        } else {
            if (manager != null) {
                manager.notify(notificationId, notification.build());
            }
        }
    }

    private String getTypeKey(String sms_type) {
        return sms_type + "_type";
    }

    private void getTransectionDetails(HomeAccoutList homeAccount, String body, JSONObject jsonObject, String bankNameTitle) {

        int posID = -1, amountId = -1, ruleId = -1, dateId = -1, eventNameId = -1, eventLocationId = -1, eventInfoId = -1;

        try {
            BankName = jsonObject.optString("full_name");
            JSONArray patternsary = jsonObject.optJSONArray("patterns");
            if (patternsary != null) {
                boolean isPatternMatch = false;
                if (body.contains("KRUPABEN THAKOR")) {
                    Log.e("JHCGAVGHCVHXBKC", body + "::");
                }
                for (int jj = 0; jj < patternsary.length() && !isPatternMatch; jj++) {
                    JSONObject jsonObjectt = patternsary.optJSONObject(jj);
                    String Regx = jsonObjectt.optString("regex");

                    String body1 = removeUnUsed(body);
                    Pattern regEx = Pattern.compile(Regx);
                    Matcher m = regEx.matcher(body1);

                    if (m.find()) {
                        if (bankNameTitle != null && bankNameTitle.endsWith("ICICIB")) {
                            Log.e("JMSGHDJAFHDGHSCFDSGHG", "------------------------------------------------------------------------");
                            Log.e("JMSGHDJAFHDGHSCFDSGHG", bankNameTitle + ":::::" + ":::MATCH:" + body + "::" + "::\n");
                        }
                        isPatternMatch = true;
                        homeAccount.account_type = jsonObjectt.optString("account_type");
                        homeAccount.sms_type = jsonObjectt.optString("sms_type");
                        String data_fields = jsonObjectt.optString("data_fields");
                        JSONObject obj_data_fields = new JSONObject(data_fields);

                        String typeKey = getTypeKey(homeAccount.sms_type);
                        if (!TextUtils.isEmpty(typeKey) && obj_data_fields.has(typeKey)) {
                            homeAccount.mTransactionType = obj_data_fields.optString(typeKey);
                        } else {
                            if (obj_data_fields.has("transaction_type_rule") &&
                                    obj_data_fields.getJSONObject("transaction_type_rule").has("rules")) {

                                ruleId = obj_data_fields.getJSONObject("transaction_type_rule").getInt("group_id");
                                String ruleValue = m.group(ruleId);
                                JSONArray transaction_type_rules = obj_data_fields.getJSONObject("transaction_type_rule").getJSONArray("rules");
                                boolean isFound = false;
                                JSONObject ruleObj = null;
                                for (int i = 0; i < transaction_type_rules.length() && !isFound; i++) {
                                    ruleObj = transaction_type_rules.getJSONObject(i);
                                    String value = ruleObj.getString("value");
                                    if (ruleObj.has("pos_override") && ruleObj.getString("pos_override").equalsIgnoreCase("ATM")) {
                                        if (body.contains("ATM") || body.contains("NFS")) {
                                            isFound = true;
                                        }
                                    }
                                    if (value.equalsIgnoreCase(ruleValue)) {
                                        isFound = true;
                                    }
                                }
                                if (ruleObj != null) {
                                    if (ruleObj.has("pos_override")) {
                                        homeAccount.transactionDesc = ruleObj.getString("pos_override");
                                    }
                                    if (ruleObj.has("txn_type")) {
                                        homeAccount.txn_type = ruleObj.getString("txn_type");
                                        if (homeAccount.txn_type.equalsIgnoreCase("debit_atm")) {
                                            homeAccount.isAtmWithDraw = true;
                                        }
                                    }
                                }

                            }
                        }

                        if (obj_data_fields.has("amount")) {
                            if (obj_data_fields.getJSONObject("amount").has("group_id")) {
                                amountId = obj_data_fields.getJSONObject("amount").getInt("group_id");
                                homeAccount.amount = m.group(amountId);  //AccountAmount
                            } else if (obj_data_fields.getJSONObject("amount").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("amount").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.amounts.add(m.group(ids.getInt(i)));
                                }
                            }
                            if (obj_data_fields.getJSONObject("amount").has("txn_direction")) {
                                homeAccount.isDebited = false;
                            }
                        }
//                        ArrayList<String> values = new ArrayList<>();
//                        if (homeAccount.amount.equalsIgnoreCase("7,999.00")) {
//
//                            int count = m.groupCount();
//                            for (int c = 0; c < count; c++) {
//                                String v = m.group(c);
//                                values.add(v);
//                            }
//                        }

                        if (obj_data_fields.has("date")) {
                            if (obj_data_fields.getJSONObject("date").has("use_sms_time")) {
                                homeAccount.use_sms_time = obj_data_fields.getJSONObject("date").getBoolean("use_sms_time");
                            } else if (obj_data_fields.getJSONObject("date").has("formats")) {
                                JSONArray array = obj_data_fields.getJSONObject("date").getJSONArray("formats");
                                for (int i = 0; i < array.length(); i++) {
                                    String format = array.getJSONObject(i).getString("format");
                                    homeAccount.dateFormats.add(format);
                                }
                                if (obj_data_fields.getJSONObject("date").has("group_id")) {
                                    dateId = obj_data_fields.getJSONObject("date").getInt("group_id");
                                    homeAccount.date = m.group(dateId);  // account_Date
                                } else if (obj_data_fields.getJSONObject("date").has("group_ids")) {
                                    JSONArray ids = obj_data_fields.getJSONObject("date").getJSONArray("group_ids");
                                    for (int i = 0; i < ids.length(); i++) {
                                        homeAccount.dates.add(m.group(ids.getInt(i)));
                                    }
                                }
                            }
                        }
//                        if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
//                            getDataFromDataFields(obj_data_fields, "pos", homeAccount.transactionDesc, posID, homeAccount.transactionDescs, m);
//                        }

                        if (obj_data_fields.has("pos")) {
                            if (obj_data_fields.getJSONObject("pos").has("value")) {
                                homeAccount.transactionDesc = obj_data_fields.getJSONObject("pos").getString("value");
                            }
                            if (obj_data_fields.getJSONObject("pos").has("group_id")) {
                                posID = obj_data_fields.getJSONObject("pos").getInt("group_id");
                                homeAccount.transactionPos = m.group(posID);
                            } else if (obj_data_fields.getJSONObject("pos").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("pos").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.transactionDescs.add(m.group(ids.getInt(i)));
                                }
                            }

                        }


                        if (homeAccount.sms_type.equalsIgnoreCase("event")) {
                            getDataFromDataFields(obj_data_fields, "name", homeAccount.eventName, eventNameId, homeAccount.eventNames, m);
                            getDataFromDataFields(obj_data_fields, "event_info", homeAccount.eventInfo, eventInfoId, homeAccount.eventInfos, m);
                            getDataFromDataFields(obj_data_fields, "event_location", homeAccount.eventLocation, eventLocationId, homeAccount.eventLocations, m);
                        }

                        // Account No
                        JSONObject objpan = obj_data_fields.optJSONObject("pan");
                        String pan = "";
                        /*if (bankNameTitle != null && bankNameTitle.endsWith("ICICIB")) {
                            Log.e("BANKKKKKKKKKKLK", bankNameTitle + ":MATSSDSDSDCH:" + body + "::");
                        }*/
                        if (objpan != null) {
                            if (objpan.has("value")) {


                                homeAccount.panValue = objpan.getString("value");
                                /*for (int i = 0; i < m.groupCount(); i++) {
                                    String value = m.group(i);
                                    Log.e("JDGHASJDGJAKSGDJAS", value + ":GROUPVALUE:::" + i);
                                }*/
                            }
                            if (objpan.has("group_id")) {
                                pan = objpan.optString("group_id");
                            }
                        }
                        // pan
                        try {

                            if (!TextUtils.isEmpty(pan)) {
                                int gpId = Integer.parseInt(pan);
                                if (!TextUtils.isEmpty(pan) && gpId != -1) {
                                    homeAccount.FinalAccountNo = m.group(gpId);
                                }
                            } else {
                                // String regex1 = "(?i).*(?:account|a/c|ac) x+\\d*(\\d{3,4})";
                                String regex1 = "(?i)x+\\d*(\\d{3,4})";
                                Pattern regEx1 = Pattern.compile(regex1);
                                Matcher m1 = regEx1.matcher(body1);
                                if (m1.find() && m1.groupCount() > 0) {
                                    homeAccount.FinalAccountNo = m1.group(0);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                       /* if (bankNameTitle != null && bankNameTitle.endsWith("ICICIB") && homeAccount.FinalAccountNo.equals("465")) {
                            Log.e("BANKKKKKKKKKKLK", bankNameTitle + ":MATCH:" + body + "::");
                        }*/

                        if (obj_data_fields.has("note")) {
                            String note = obj_data_fields.getJSONObject("note").optString("group_id");

                            if (homeAccount.account_type.equalsIgnoreCase("prepaid")) {
                                if (TextUtils.isEmpty(homeAccount.transactionPos)) {
                                    homeAccount.transactionPos = m.group(Integer.parseInt(note));
                                } else {
                                    homeAccount.transactionPos += " " + m.group(Integer.parseInt(note));
                                }
                            } else if (TextUtils.isEmpty(homeAccount.transactionPos)) {
                                homeAccount.transactionPos = m.group(Integer.parseInt(note));
                            } else if (TextUtils.isEmpty(homeAccount.panValue) || homeAccount.panValue.equalsIgnoreCase("unknown")) {
                                homeAccount.panValue = m.group(Integer.parseInt(note));
                            }
                        }
                        ArrayList<String> list = new ArrayList<>();
                        for (int i = 1; i <= m.groupCount(); i++) {
                            list.add(m.group(i));
                        }


                        // Account Balance
                        JSONObject objaccount_balance = obj_data_fields.optJSONObject("account_balance");
                        String account_balance = "";
                        if (objaccount_balance != null) {
                            account_balance = objaccount_balance.optString("group_id");
                        }
                        // Account Balance
                        if (!TextUtils.isEmpty(account_balance)) {
                            if (TextUtils.isDigitsOnly(account_balance)) {
                                homeAccount.FinalAccountBalance = m.group(Integer.parseInt(account_balance));
                            }
                        }

                        if (!TextUtils.isEmpty(homeAccount.mTransactionType) && homeAccount.mTransactionType.equalsIgnoreCase("credit")) {
                            homeAccount.isDebited = false;
                        }

                    }

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void getDataFromDataFields(JSONObject obj_data_fields, String key, String mainValue, int mainId, ArrayList<String> valuesArray, Matcher m) {
        try {
            if (obj_data_fields.has(key)) {
                if (obj_data_fields.getJSONObject(key).has("value")) {
                    mainValue = obj_data_fields.getJSONObject(key).getString("value");
                } else {
                    if (obj_data_fields.getJSONObject(key).has("group_id")) {
                        mainId = obj_data_fields.getJSONObject(key).getInt("group_id");
                        mainValue = m.group(mainId);
                    } else if (obj_data_fields.getJSONObject(key).has("group_ids")) {
                        JSONArray ids = obj_data_fields.getJSONObject(key).getJSONArray("group_ids");
                        for (int i = 0; i < ids.length(); i++) {
                            valuesArray.add(m.group(ids.getInt(i)));
                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String getTransactionDesc(String transactionType) {
        String transactionDesc = "";
        switch (transactionType) {
            case "balance":
                transactionDesc = "Your Account Balance";
                break;
            case "upi":
                transactionDesc = "UPI Transaction";
                break;
            case "debit_card":
                transactionDesc = "Debit Card Transaction";
                break;
            case "net_banking":
                transactionDesc = "Net Banking";
                break;
            case "credit":
                transactionDesc = "Credited to your Account";
                break;
            case "cheque":
                transactionDesc = "Cheque Transaction";
                break;
            case "debit_atm":
                transactionDesc = "ATM withdrawal";
                break;
            case "credit_card":
                transactionDesc = "Credit Card Transaction";
                break;
            case "credit_card_bill":
                transactionDesc = "Credit Card Bill";
                break;
            case "loan_emi":
                transactionDesc = "Loan EMI";
                break;
            case "mobile_bill":
                transactionDesc = "Mobile Bill";
                break;
            case "debit_prepaid":
                transactionDesc = "Prepaid Debit Card Transaction";
                break;
            case "bill":
                transactionDesc = "Bill";
                break;
            case "internate_bill":
                transactionDesc = "Internet Bill";
                break;
            case "electricity_bill":
                transactionDesc = "Electricity Bill";
                break;
            case "insurance_premium":
                transactionDesc = "Insurance Premium";
                break;
            case "gas_bill":
                transactionDesc = "Gas Bill";
                break;
        }
        return transactionDesc;
    }
}
