package com.bankbalanceinquiry.ministatement.fragment;

import static android.content.Intent.ACTION_DIAL;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class sendMoneyFragment extends Fragment {
    public static String money_from;
    ImageView to_mobile, to_payment, to_saved, to_ifsc, to_mmid, c_bank, c_language, my_bankl, my_payment, manage_b, reset_pin, change_pin;
    RelativeLayout send_moeny_rel, profile_rel, upi_pin_rel;

    CardView to_native_ad;
    FrameLayout fl_adplaceholder_send, fl_adplaceholder_profile, fl_adplaceholder_pin;
    Context mContext;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sendmoney, container, false);

        mContext = getActivity();
        send_moeny_rel = view.findViewById(R.id.send_moeny_rel);
        profile_rel = view.findViewById(R.id.profile_rel);
        upi_pin_rel = view.findViewById(R.id.upi_pin_rel);


        to_mobile = view.findViewById(R.id.to_mobile);
        to_payment = view.findViewById(R.id.to_payment);
        to_saved = view.findViewById(R.id.to_beneficiary);
        to_ifsc = view.findViewById(R.id.to_ifsc);
        to_mmid = view.findViewById(R.id.to_mmid);

        c_bank = view.findViewById(R.id.c_bank);
        c_language = view.findViewById(R.id.c_language);
        my_bankl = view.findViewById(R.id.my_bankl);
        my_payment = view.findViewById(R.id.my_payment);
        manage_b = view.findViewById(R.id.manage_b);

        reset_pin = view.findViewById(R.id.reset_pin);
        change_pin = view.findViewById(R.id.change_upi);
        money_from = ussdBankingFragment.money;

        to_native_ad = view.findViewById(R.id.to_native_ad);
        fl_adplaceholder_send = view.findViewById(R.id.fl_adplaceholder_send_money);
        fl_adplaceholder_profile = view.findViewById(R.id.fl_adplaceholder_profile);
        fl_adplaceholder_pin = view.findViewById(R.id.fl_adplaceholder_pin);
//        refreshAd();
        if (!TextUtils.isEmpty(money_from)) {
            if (money_from.matches("send")) {
                send_moeny_rel.setVisibility(View.VISIBLE);
                profile_rel.setVisibility(View.GONE);
                upi_pin_rel.setVisibility(View.GONE);
            } else if (money_from.matches("profile")) {
                upi_pin_rel.setVisibility(View.GONE);
                send_moeny_rel.setVisibility(View.GONE);
                profile_rel.setVisibility(View.VISIBLE);

            } else if (money_from.matches("upi")) {
                upi_pin_rel.setVisibility(View.VISIBLE);
                send_moeny_rel.setVisibility(View.GONE);
                profile_rel.setVisibility(View.GONE);
            }
        }
        to_mobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*1#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                /*  startActivity(callIntent);*/
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });
        to_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*2#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        to_saved.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*3#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        to_ifsc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*4#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        to_mmid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*1*5#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        c_bank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*1#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        c_language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*2#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        my_bankl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*3#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        my_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*4#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        manage_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*4*5#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        reset_pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Uri number = Uri.parse("tel:" + Uri.encode("*99*7*1#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        change_pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + Uri.encode("*99*7*2#"));
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });
        return view;
    }

    private void refreshAd() {

        new NativeAdvancedModelHelper(getActivity()).loadNativeAd(
                NativeAdsSize.Medium,
                fl_adplaceholder_send, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {
                        to_native_ad.setVisibility(View.VISIBLE);
                        return null;
                    }
                }
        );
//        try {
//            AdLoader.Builder builder = new AdLoader.Builder(mContext, getString(R.string.advance_native));
//
//            builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
//                // OnUnifiedNativeAdLoadedListener implementation.
//                @Override
//                public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
//                    // You must call destroy on old ads when you are done with them,
//                    // otherwise you will have a memory leak.
//                    if (nativeAdd != null) {
//                        nativeAdd.destroy();
//                    }
//
//                    nativeAdd = unifiedNativeAd;
//
//                        UnifiedNativeAdView adView1 = (UnifiedNativeAdView) LayoutInflater.from(mContext).inflate(R.layout.ad_unified, null);
//                        populateUnifiedNativeAdView(unifiedNativeAd, adView1);
//
//
//                    if (money_from.matches("send"))
//                    {
//                        fl_adplaceholder_profile.removeAllViews();
//                        fl_adplaceholder_pin.removeAllViews();
//
//                        fl_adplaceholder_send.removeAllViews();
//                        fl_adplaceholder_send.addView(adView1);
//
//
//
//                    }
//                    else if(money_from.matches("profile"))
//                    {
//                        fl_adplaceholder_send.removeAllViews();
//                        fl_adplaceholder_pin.removeAllViews();
//
//                        fl_adplaceholder_profile.removeAllViews();
//                        fl_adplaceholder_profile.addView(adView1);
//                    }
//                    else if(money_from.matches("upi"))
//                    {
//                        fl_adplaceholder_send.removeAllViews();
//                        fl_adplaceholder_profile.removeAllViews();
//
//                        fl_adplaceholder_pin.removeAllViews();
//                        fl_adplaceholder_pin.addView(adView1);
//
//
//                    }
//
//
//                }
//
//            });
//
//            AdLoader adLoader = builder.withAdListener(new AdListener() {
//                @Override
//                public void onAdFailedToLoad(int errorCode) {
//
//                }
//            }).build();
//
//            adLoader.loadAd(new AdRequest.Builder().build());
//        } catch (IllegalStateException e) {
//        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
