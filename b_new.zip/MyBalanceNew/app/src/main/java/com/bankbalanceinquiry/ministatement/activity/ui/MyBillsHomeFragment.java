package com.bankbalanceinquiry.ministatement.activity.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.BillsNewActivity;
import com.bankbalanceinquiry.ministatement.activity.CashWithdrawalActivity;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class MyBillsHomeFragment extends Fragment {


    int billClick = 0, cashClick = 0;
    CardView mCashL, mBillL;

    private FrameLayout adLayout;


    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_my_bills, container, false);


        adLayout = root.findViewById(R.id.adLayout);


        mCashL = root.findViewById(R.id.cash_l);
        mBillL = root.findViewById(R.id.bills_l);

        new NativeAdvancedModelHelper(getActivity()).loadNativeAd(
                NativeAdsSize.Medium,
                adLayout, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {
                        return null;
                    }
                }
        );
//        new NativeAdvancedModelHelper(getActivity()).loadNativeAd(
//                NativeAdsSize.Big,
//                adLayout2, new Function1<Boolean, Unit>() {
//                    @Override
//                    public Unit invoke(Boolean aBoolean) {
//                        return null;
//                    }
//                }
//        );

        mCashL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                cashClick++;
                boolean showAd = false;
                if (cashClick == 1) {
                    showAd = true;
                }
                startActivity(new Intent(getActivity(), CashWithdrawalActivity.class).putExtra("showAd", showAd));

//                startActivity(new Intent(getActivity(), CashWithdrawalActivity.class));
//                AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {});
            }
        });

        mBillL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                billClick++;
                boolean showAd = false;
                if (billClick == 1) {
                    showAd = true;
                }
                startActivity(new Intent(getActivity(), BillsNewActivity.class).putExtra("showAd", showAd));
//                startActivity(new Intent(getActivity(), BillsNewActivity.class));
//                AdmobAdManager.getInstance().loadInterstitialAd(getActivity(), getString(R.string.interstitial_id), 3, (AdmobAdManager.OnAdClosedListener) () -> {});
            }
        });
        Log.e("BoxViewfrg==", "NO");

//        loadNative();

        return root;
    }

//    public void loadNative() {
//        Log.e("HOMEMMEMMEEMEE", "JKSDFHCJS");
//        AdmobAdManager.getInstance().LoadNativeAd(getActivity(), getString(R.string.admob_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                AdmobAdManager.getInstance().populateUnifiedNativeAdView(getContext(), adLayout, (NativeAd) object, true, true);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//            }
//
//        }, true);
//    }

    @Override
    public void onDestroyView() {
        //EventBus.getDefault().unregister(this);
        super.onDestroyView();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }


}