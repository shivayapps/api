package com.bankbalanceinquiry.ministatement.adapter;

import android.app.Activity;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.AllAccountModel;

import java.util.ArrayList;
import java.util.Random;


public class AllAccountListAdapter extends RecyclerView.Adapter<AllAccountListAdapter.MyViewHolder> {
    private final Activity activity;
    private final Object rsString;
    public ClickActivDeactiveint clickActivDeactiveint;
    private final ArrayList<AllAccountModel> allAccountModels;

    public interface ClickActivDeactiveint {
        void ClickActiveDeactive(int position);

        void ClickBusinessOrPersion(int position);
    }

    public void RegisterInterface(ClickActivDeactiveint photoInterface) {
        this.clickActivDeactiveint = photoInterface;
    }

    public AllAccountListAdapter(Activity activity, ArrayList<AllAccountModel> listOfAllImages) {
        this.activity = activity;
        this.allAccountModels = listOfAllImages;
        rsString = activity.getString(R.string.Rs);

    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(activity).inflate(R.layout.raw_account_list, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final AllAccountModel alldata = allAccountModels.get(position);

//        if (alldata.isActiveOrInActive()) {
//            holder.tvActiveInActive.setText("ACTIVE");
//            holder.ivActiveInActive.setImageResource(R.drawable.ic_switch_on);
//        } else {
//            holder.tvActiveInActive.setText("INACTIVE");
//            holder.ivActiveInActive.setImageResource(R.drawable.ic_switch_off);
//        }
//
//        if (alldata.isBusinessOrPersion()) {
//            holder.tvBusinessOrPersion.setText("Mark as a business");
//            holder.ivBusinessOrPersion.setImageResource(R.drawable.ic_account_business);
//        } else {
//            holder.tvBusinessOrPersion.setText("Mark as a personal");
//            holder.ivBusinessOrPersion.setImageResource(R.drawable.ic_account_person);
//        }
        String AccountNumber = alldata.getAccountNo();
        String Date = alldata.getDateVal();
        String AccountAmount = alldata.getAvilabeClearBalance().replaceAll("Rs.", "");
        holder.tvBankNameAndAcNo.setText(alldata.getBankName() + " - " + AccountNumber);
        holder.tvBalanceAndDate.setText(rsString + " " + AccountAmount + " as on " + Date);

      /*  if (alldata.getBankIcon() != 0) {
            holder.ivBankLogo.setImageResource(alldata.getBankIcon());

        }*/

        String FirstName = alldata.getBankName();
        Random rnd = new Random();
        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
        if (!TextUtils.isEmpty(FirstName) && !FirstName.equalsIgnoreCase("")) {
            String FirstLetter = FirstName.substring(0, 1);
            TextDrawable drawable = TextDrawable.builder()
                    .buildRound(FirstLetter, color);
            holder.ivBankLogo.setImageDrawable(drawable);
        } else {
            TextDrawable drawable = TextDrawable.builder()
                    .buildRound("U", color);
            holder.ivBankLogo.setImageDrawable(drawable);
        }
        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clickActivDeactiveint != null) {
                    clickActivDeactiveint.ClickActiveDeactive(position);
                }
            }
        });
//        holder.ivActiveInActive.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//
//        holder.rlPersonBusiness.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (clickActivDeactiveint != null) {
//                    clickActivDeactiveint.ClickBusinessOrPersion(position);
//                }
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return allAccountModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final LinearLayout llMain;
        private final ImageView ivBankLogo;
        private final TextView tvBankNameAndAcNo;
        private final TextView tvBalanceAndDate;

//        private ImageView ivActiveInActive;
//        private TextView tvActiveInActive;
//
//        private RelativeLayout rlPersonBusiness;
//        private ImageView ivBusinessOrPersion;
//        private TextView tvBusinessOrPersion;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            llMain = itemView.findViewById(R.id.llMain);
            ivBankLogo = itemView.findViewById(R.id.ivBankLogo);
            tvBankNameAndAcNo = itemView.findViewById(R.id.tvBankNameAndAcNo);
            tvBalanceAndDate = itemView.findViewById(R.id.tvBalanceAndDate);

//            ivActiveInActive = itemView.findViewById(R.id.ivActiveInActive);
//            tvActiveInActive = itemView.findViewById(R.id.tvActiveInActive);
//
//            rlPersonBusiness = itemView.findViewById(R.id.rlPersonBusiness);
//            ivBusinessOrPersion = itemView.findViewById(R.id.ivBusinessOrPersion);
//            tvBusinessOrPersion = itemView.findViewById(R.id.tvBusinessOrPersion);
        }
    }
}
