package com.bankbalanceinquiry.ministatement.utils;

import static android.content.Context.MODE_PRIVATE;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bankbalanceinquiry.ministatement.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;


public class RateBottomDialog extends BottomSheetDialogFragment {
    View view;
    LinearLayout btn_close, btn_rate;
    private View img_close;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.dialog_rate_us1, container, false);
        initView();
        getDialog().setOnShowListener(dialog -> {
            new Handler(Looper.myLooper()).postDelayed(() -> {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                FrameLayout bottomSheet = d.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                bottomSheetBehavior.setSkipCollapsed(true);
//                bottomSHeetBehavior.setSkipCol
                // bottomSheetBehavior.setDraggable(false);
                //  bottomSheetBehavior.setHideable(false);
            }, 0);
        });
        return view;
    }

    private void initView() {
        img_close = view.findViewById(R.id.img_close);
        btn_close = view.findViewById(R.id.btn_close);
        btn_rate = view.findViewById(R.id.btn_rate);
        btn_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE).edit();
                editor.putBoolean("rateApp", true);
                editor.apply();
                String url = "https://play.google.com/store/apps/details?id=" + getActivity().getApplicationContext().getPackageName();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                dismiss();
                getActivity().finish();
                getActivity().finishAffinity();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getActivity().finishAndRemoveTask();
                }
            }
        });
        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(
                        Intent.ACTION_SENDTO,
                        Uri.parse(getResources().getString(R.string.mail_msg)
                                + Uri.encode(getResources().getString(R.string.email))));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
                try {
                    startActivity(Intent.createChooser(emailIntent, getResources().getString(R.string.send_to)));
                } catch (ActivityNotFoundException ex) {
                    ex.printStackTrace();
                    Toast.makeText(getContext(), getResources().getString(R.string.email_warning), Toast.LENGTH_SHORT).show();
                }
                getActivity().finish();
                getActivity().finishAffinity();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getActivity().finishAndRemoveTask();
                }
            }
        });
        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

    }


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Dialog dialog = super.onCreateDialog(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = dialog.getWindow();
            if (window != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                window.getWindowManager().getDefaultDisplay().getMetrics(metrics);

                GradientDrawable dimDrawable = new GradientDrawable();

                GradientDrawable navigationBarDrawable = new GradientDrawable();
                navigationBarDrawable.setShape(GradientDrawable.RECTANGLE);
                navigationBarDrawable.setColor(getResources().getColor(R.color.white));

                Drawable[] layers = {dimDrawable, navigationBarDrawable};

                LayerDrawable windowBackground = new LayerDrawable(layers);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    windowBackground.setLayerInsetTop(1, metrics.heightPixels);
                }

                window.setBackgroundDrawable(windowBackground);
            }
        }
        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.CustomBottomSheetDialogTheme);
    }

}
