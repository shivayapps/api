package com.bankbalanceinquiry.ministatement.utils;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.multidex.MultiDexApplication;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.SplashActivity11;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.example.app.ads.helper.VasuAdsConfig;
import com.example.app.ads.helper.openad.AppOpenApplication;
import com.example.app.ads.helper.openad.OpenAdModel;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.onesignal.OneSignal;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;


public class MyApplication extends AppOpenApplication implements AppOpenApplication.AppLifecycleListener {

    private static MyApplication application;
    public static Context context;
//    private AppOpenManager appOpenManager;
    public static boolean IS_SDK_INITIALIZED = false;

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;
        context = getApplicationContext();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            String process = getProcessName();
            if (getPackageName() != process) WebView.setDataDirectorySuffix(process);
        }
        MobileAds.initialize(getApplicationContext());
        AudienceNetworkAds.initialize(this);

        setAppLifecycleListener(this);
        VasuAdsConfig.with(this)
                .isEnableOpenAd(true) // Pass false if you don't need to show open ad in your project
                .needToTakeAllTestAdID(false) // Pass true if you need to show Ads with Test Ad ID in your project
                .needToBlockInterstitialAd(false) // Pass true if you check fullScreenNativeAds when Interstitial Ads Failed to Load
                .setAdmobAppId(getString(R.string.G_APP_ID))
//                .setAdmobBannerAdId(getString(R.string.G_BANNER_ID))
                .setAdmobInterstitialAdId(getString(R.string.G_INTERSTITIAL_ID))
                .setAdmobNativeAdvancedAdId(getString(R.string.G_NATIVE_ID))
                .setAdmobOpenAdId(getString(R.string.G_APPOPEN_ID))
//                .setAdmobRewardVideoAdId(getString(R.string.rewarded_video_ad_unit_id))
//                .setAdmobInterstitialAdRewardId(getString(R.string.rewarded_interstitial_ad_unit_id))
                .initialize();

//        new OpenAdModel(this).loadOpenAd(this, new Function0<Unit>() {
//            @Override
//            public Unit invoke() {
//                return null;
//            }
//        });
        fireBaseConfigGet();

        new Thread(() -> {
            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
            OneSignal.initWithContext(MyApplication.this);
            OneSignal.setAppId("5007b7dd-aa51-4729-878a-cc64bc96576f");
//            YandexMetricaConfig config = YandexMetricaConfig.newConfigBuilder(getResources().getString(R.string.app_metrica)).build();
//            YandexMetrica.activate(getApplicationContext(), config);
//            YandexMetrica.enableActivityAutoTracking(MyApplication.this);
        }).start();

        destroyAllLoadedAd();
//        appOpenManager = new AppOpenManager(MyApplication.this);
//        AppLifecycleObserver appLifecycleObserver = new AppLifecycleObserver(new appOpenLifeCycleChange() {
//            @Override
//            public void onBackground() {
//
//            }
//
//            @Override
//            public void onForeground() {
//                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
//                    if (!isShowingAd) {
//                        appOpenManager.appInForeground();
//                    }
//                }
//
//            }
//        });
//        ProcessLifecycleOwner.get().getLifecycle().addObserver(appLifecycleObserver);
    }

    public void fireBaseConfigGet() {
        try {
            final FirebaseRemoteConfig mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
            //Setting Developer Mode enabled to fast retrieve the values
            mFirebaseRemoteConfig.setConfigSettingsAsync(
                    new FirebaseRemoteConfigSettings.Builder()
                            .setMinimumFetchIntervalInSeconds(0)
                            .build());
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_confing_defaults);
            mFirebaseRemoteConfig.fetch(0)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            String errorString = "";
                            if (task.isSuccessful()) {
                                mFirebaseRemoteConfig.activate();
                                errorString = " task is successful  ";
//                                PreferenceManager.saveData(mApp, "isFirebaseRemoteConfigSuccessful", true);
                            } else {
                                errorString = "task is canceled";
                            }
                            Log.w("msg", "mFirebaseRemoteConfigis_ errorString ---------" + errorString);
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Context getAppContext() {
        if (application == null) {
            application = new MyApplication();
        }
        return application;
    }

    @Override
    public boolean onResumeApp(@NonNull Activity fCurrentActivity) {

        if(fCurrentActivity instanceof SplashActivity11){
            return false;
        } else if(!new AdsManager(fCurrentActivity).isNeedToShowAds()) {
            return false;
        }
        return true;
    }
}
