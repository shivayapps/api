package com.bankbalanceinquiry.ministatement.utils;

import android.content.Context;
import android.os.Build;
import android.webkit.WebView;

import androidx.multidex.MultiDexApplication;

import com.bankbalanceinquiry.ministatement.R;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.onesignal.OneSignal;
import com.yandex.metrica.YandexMetrica;
import com.yandex.metrica.YandexMetricaConfig;


public class MyApplication extends MultiDexApplication {

    private static MyApplication application;
    public static Context context;
//    private AppOpenManager appOpenManager;
    public static boolean IS_SDK_INITIALIZED = false;

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;
        context = getApplicationContext();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            String process = getProcessName();
            if (getPackageName() != process) WebView.setDataDirectorySuffix(process);
        }
        MobileAds.initialize(getApplicationContext());
        AudienceNetworkAds.initialize(this);

        new Thread(() -> {
            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
            OneSignal.initWithContext(MyApplication.this);
            OneSignal.setAppId(getResources().getString(R.string.onedsignal_id));

            YandexMetricaConfig config = YandexMetricaConfig.newConfigBuilder(getResources().getString(R.string.app_metrica)).build();
            YandexMetrica.activate(getApplicationContext(), config);
            YandexMetrica.enableActivityAutoTracking(MyApplication.this);
        }).start();

//        appOpenManager = new AppOpenManager(MyApplication.this);
//        AppLifecycleObserver appLifecycleObserver = new AppLifecycleObserver(new appOpenLifeCycleChange() {
//            @Override
//            public void onBackground() {
//
//            }
//
//            @Override
//            public void onForeground() {
//                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.Q) {
//                    if (!isShowingAd) {
//                        appOpenManager.appInForeground();
//                    }
//                }
//
//            }
//        });
//        ProcessLifecycleOwner.get().getLifecycle().addObserver(appLifecycleObserver);
    }

    public static Context getAppContext() {
        if (application == null) {
            application = new MyApplication();
        }
        return application;
    }
}
