package com.bankbalanceinquiry.ministatement.fragment;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Intent.ACTION_DIAL;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.SubActivity_homePage;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class bankBalanceFragment extends Fragment {

    String bank_name;
    List<bankname> MDetail;
    TextView balance_number, statment_number, care_number;
    CardView statment_card, ussd_service;
    ImageView care_call, statement_call, balance_call;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;
    //    FrameLayout fl_adplaceholder_bal;
    View root;
    Context context;

    private FrameLayout frameLayout;
    private FrameLayout adLayout;
    private CardView adcard;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_bankbalance, container, false);
        context = getActivity();

        ussd_service = root.findViewById(R.id.ussd_service);
        balance_number = root.findViewById(R.id.balance_number);
        statment_number = root.findViewById(R.id.statment_number);
        care_number = root.findViewById(R.id.care_number);
        statment_card = root.findViewById(R.id.statment_card);
        care_call = root.findViewById(R.id.care_call);
        statement_call = root.findViewById(R.id.statment_call);
        balance_call = root.findViewById(R.id.balance_call);
//        fl_adplaceholder_bal = (FrameLayout) root.findViewById(R.id.fl_adplaceholder_balance);

//        frameLayout = root.findViewById(R.id.fl_adplaceholder);

//        refreshAd();
        sharedPreferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = sharedPreferences.edit();


        //Check preference

        bank_name = sharedPreferences.getString("bank_name", "No Bank");
        //bank_name=bank_n;

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        MDetail = databaseAccess.getBalance_details(bank_name);
        databaseAccess.close();

        if (MDetail != null && MDetail.size() != 0) {
            balance_number.setText(MDetail.get(0).getB_inquiry());
            care_number.setText(MDetail.get(0).getB_care());
            if (MDetail.get(0).getB_mini() != null) {
                statment_card.setVisibility(View.VISIBLE);
                statment_number.setText(MDetail.get(0).getB_mini());
            } else {
                statment_card.setVisibility(View.GONE);
            }
        }
        balance_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + balance_number.getText().toString());
                Intent callIntent = new Intent(ACTION_DIAL, number);
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        ussd_service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startNextActivity(2);
            }
        });

        statement_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + statment_number.getText().toString());
                Intent callIntent = new Intent(ACTION_DIAL, number);
               /* if (getActivity() != null && callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivity(callIntent);
                }*/
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        care_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri number = Uri.parse("tel:" + care_number.getText().toString());
                Intent callIntent = new Intent(ACTION_DIAL, number);
              /*  if (getActivity() != null && callIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                    startActivity(callIntent);
                }*/
                try {
                    if (getActivity() != null) {
                        startActivity(callIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        adLayout = root.findViewById(R.id.adLayout);
        adcard = root.findViewById(R.id.adcard);
        loadNative();
        return root;
    }


    private void startNextActivity(int type) {
        Intent i = new Intent(getActivity(), SubActivity_homePage.class);
        i.putExtra("viewType", type);
        startActivity(i);
    }

    public void loadNative() {

        new NativeAdvancedModelHelper(getActivity()).loadNativeAd(
                NativeAdsSize.Medium,
                adLayout, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {
                        return null;
                    }
                }
        );
//        AdmobAdManager.getInstance().LoadNativeAd(getActivity(), getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                //  AdmobAdManager.getInstance().populateUnifiedSmallNativeAdView(context ,adLayout  , (NativeAd) object);
//                AdmobAdManager.getInstance().populateUnifiedNativeAdView(getContext(), adLayout, (NativeAd) object, true, true);
//
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//            }
//         /*   @Override
//            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
//                AdmobAdManager.getInstance(getActivity())
//                        .populateUnifiedSmallNativeApplovin(getActivity(), adLayout, maxNativeAdView, maxAd, true);
//            }*/
//        }, true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
