package com.bankbalanceinquiry.ministatement.financialcalculator;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;
import com.google.android.material.tabs.TabLayout;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class Calculations extends AppCompatActivity {


    private SectionsPagerAdapter mSectionsPagerAdapter;
//    private BottomNavigationView navigationView;
    TabLayout tabLayout;
    private Toolbar toolbar;
    private ViewPager mViewPager;
    private MenuItem prevMenuItem;
    private FrameLayout adLayout;
    private CardView adcard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculations);

        initToolBar();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getColor(R.color.app_color));
        }

        Intent i = getIntent();
        int choice = i.getIntExtra("Choice", 1);

        int[][] states = new int[][] {
                new int[] { android.R.attr.state_checked}, // enabled
                new int[] {-android.R.attr.state_enabled}, // disabled
                new int[] {-android.R.attr.state_checked}, // unchecked
                new int[] { android.R.attr.state_pressed},
                new int[] { android.R.attr.state_window_focused}
                // pressed
        };

        /*
        Nav color fix
         */

        int[] EMIcolors = new int[] {
                this.getResources().getColor(R.color.primary_fd),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                this.getResources().getColor(R.color.primary_fd)
        };

        int[] FDcolors = new int[] {
                this.getResources().getColor(R.color.primary_fd),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                this.getResources().getColor(R.color.primary_fd)
        };

        int[] RDcolors = new int[] {
                this.getResources().getColor(R.color.primary_fd),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                this.getResources().getColor(R.color.primary_fd)
        };

        int[] SIPcolors = new int[] {
                this.getResources().getColor(R.color.primary_fd),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                this.getResources().getColor(R.color.primary_fd)
        };

        int[] RPcolors = new int[] {
                this.getResources().getColor(R.color.primary_fd),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                Color.parseColor("#383838"),
                this.getResources().getColor(R.color.primary_fd)
        };

        final ColorStateList emiList = new ColorStateList(states, EMIcolors);
        final ColorStateList fdList = new ColorStateList(states, FDcolors);
        final ColorStateList rdList = new ColorStateList(states, RDcolors);
        final ColorStateList sipList = new ColorStateList(states, SIPcolors);
        final ColorStateList rpList = new ColorStateList(states, RPcolors);

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager = (ViewPager) findViewById(R.id.container);
        tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.setupWithViewPager(mViewPager);
        tabLayout.setTabMode(TabLayout.MODE_AUTO);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {

//                switch (position){
//                    case 0:
//                        navigationView.setItemIconTintList(emiList);
//                        break;
//                    case 1:
//                        navigationView.setItemIconTintList(fdList);
//                        break;
//                    case 2:
//                        navigationView.setItemIconTintList(rdList);
//                        break;
//                    case 3:
//                        navigationView.setItemIconTintList(sipList);
//                        break;
//                    case 4:
//                        navigationView.setItemIconTintList(rpList);
//                        break;
//                    default:
//                        navigationView.setItemIconTintList(rdList);
//                        break;
//                }

//                if (prevMenuItem != null) {
//                    prevMenuItem.setChecked(false);
//
//                }
//                else
//                {
//                    navigationView.getMenu().getItem(0).setChecked(false);
//                }

//                navigationView.getMenu().getItem(position).setChecked(true);
//                prevMenuItem = navigationView.getMenu().getItem(position);
//                prevMenuItem = navigationView.getMenu().getItem(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        adLayout = findViewById(R.id.adLayout);
        adcard = findViewById(R.id.adcard);

        if (new AdsManager(Calculations.this).isNeedToShowAds() && NetworkManager.isInternetConnected(Calculations.this)) {
            new NativeAdvancedModelHelper(Calculations.this).loadNativeAdvancedAd(
                    NativeAdsSize.Medium,
                    adLayout,
                    null, true, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
                            return null;
                        }
                    }, new Function0<Unit>() {
                        @Override
                        public Unit invoke() {
                            return null;
                        }
                    });
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initToolBar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.financial_calculator));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {

            switch (position){
                case 0: return new EMICalculation();
                case 1: return new FDCalculation();
                case 2: return new RDCalculation();
                case 3: return new SIPCalculation();
                case 4: return new RetirementCalculation();
                default: return new EMICalculation();
            }

        }

        @Override
        public int getCount() {
            // Show 5 total pages.
            return 5;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "EMI";
                case 1:
                    return "FD";
                case 2:
                    return "RD";
                case 3:
                    return "SIP";
                case 4:
                    return "Retirement";
            }
            return null;
        }
    }
}
