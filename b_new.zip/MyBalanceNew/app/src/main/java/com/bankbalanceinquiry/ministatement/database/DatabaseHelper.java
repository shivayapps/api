package com.bankbalanceinquiry.ministatement.database;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DatabaseHelper extends SQLiteOpenHelper
{
    private SQLiteDatabase mDatabse;
    public static final String DBNAME= "bankbalance.db";
    public static final String DBLOCATION="/data/data/com.balancecheck.allbankbalanceinquiry.balancechecker/databases/";

    private final Context mContext;

    public DatabaseHelper(Context context)
    {
        super(context,DBNAME,null,2);
        this.mContext=context;
    }


    public void createDatabase() throws IOException
    {

        boolean dbExist = checkDataBase();

        if(dbExist)
        {
            Log.v("DB Exists", "db exists");
            // By calling this method here onUpgrade will be called on a
            // writeable database, but only if the version number has been
            // bumped
            //onUpgrade(myDataBase, DATABASE_VERSION_old, DATABASE_VERSION);
        }

        boolean dbExist1 = checkDataBase();
        if(!dbExist1)
        {
            this.getReadableDatabase();
            try
            {
                this.close();
                copyDataBase();
            }
            catch (IOException e)
            {
                throw new Error("Error copying database");
            }
        }

    }
    //Check database already exist or not
    private boolean checkDataBase()
    {
        boolean checkDB = false;
        try
        {
            String myPath = DBLOCATION + DBNAME;
            File dbfile = new File(myPath);
            checkDB = dbfile.exists();
        }
        catch(SQLiteException e)
        {
        }
        return checkDB;
    }
    //Copies your database from your local assets-folder to the just created empty database in the system folder
    private void copyDataBase() throws IOException
    {

        InputStream mInput = mContext.getAssets().open(DBNAME);
        String outFileName = DBLOCATION + DBNAME;
        OutputStream mOutput = new FileOutputStream(outFileName);
        byte[] mBuffer = new byte[2024];
        int mLength;
        while ((mLength = mInput.read(mBuffer)) > 0) {
            mOutput.write(mBuffer, 0, mLength);
        }
        mOutput.flush();
        mOutput.close();
        mInput.close();
    }
    //delete database
    public void db_delete()
    {
        File file = new File(DBLOCATION + DBNAME);
        if(file.exists())
        {
            file.delete();
            System.out.println("delete database file.");
        }
    }
    //Open database
    public void openDatabase() throws SQLException
    {
        String myPath = DBLOCATION + DBNAME;
        mDatabse = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    public synchronized void closeDataBase()throws SQLException
    {
        if(mDatabse != null)
            mDatabse.close();
        super.close();
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        if (i1 > i)
        {
            Log.v("Database Upgrade", "Database version higher than old.");
            try {
                db_delete();
                copyDataBase();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

//    public void openDatabse()
//    {
//        String dbPath=mContext.getDatabasePath(DBNAME).getPath();
//
//        if(mDatabse!=null && mDatabse.isOpen())
//        {
//            return;
//        }
//        mDatabse=SQLiteDatabase.openDatabase(dbPath,null,SQLiteDatabase.OPEN_READWRITE);
//
//    }
//
//    public void closeDatabse()
//    {
//        if(mDatabse!=null)
//        {
//            mDatabse.close();
//        }
//    }
//
//    public List<bankname> getList()
//    {
//        bankname bank=null;
//
//        List<bankname> bankList=new ArrayList<>();
//
//        openDatabse();
//        Cursor cursor=mDatabse.rawQuery("SELECT * FROM tbl_bank_info",null);
//        cursor.moveToFirst();
//        while (!cursor.isAfterLast())
//        {
//            bank =new bankname(cursor.getInt(0),cursor.getString(0),cursor.getString(0),cursor.getString(0),cursor.getInt(0),cursor.getString(0),cursor.getString(0));
//            bankList.add(bank);
//            cursor.moveToNext();
//        }
//        cursor.close();
//        closeDatabse();
//
//        return bankList;
//    }
}
