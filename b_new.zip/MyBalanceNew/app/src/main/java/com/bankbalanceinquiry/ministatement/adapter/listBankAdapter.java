package com.bankbalanceinquiry.ministatement.adapter;

import static android.content.Context.MODE_PRIVATE;
import static com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment.box_view_relative;
import static com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment.list_bank_relative;
import static com.bankbalanceinquiry.ministatement.utils.Constant.findBankIcon;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.bankbalanceinquiry.ministatement.OnItemClickListner;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class listBankAdapter extends BaseAdapter {
    private final Activity mContext;
    private final List<bankname> mBanklist = new ArrayList<>();
    public static String bank_n;
    public static String bank_url;
    public static String bank_short;
    public static int sbank_id, click;
    private String bank_name_selected = "";
    String[] bankColor_array;
    SharedPreferences sharedPreferences;
    private OnItemClickListner onItemClickListner;
//    private Object nativeAd = null;


    public listBankAdapter(Activity mContext, List<bankname> mBanklist, String[] bankColor_array) {
        this.mContext = mContext;
        this.mBanklist.clear();
        this.mBanklist.addAll(mBanklist);
        this.bankColor_array = bankColor_array;
        JSONObject jsonObject = ReadJsonFile.GetAssetsFileGetDataJsonObject(mContext, "sms/bank_list_icons");
        for (int i = 0; i < mBanklist.size(); i++) {
            String name = mBanklist.get(i).getB_name();
            mBanklist.get(i).setImage_name(findBankIcon(mContext, name, jsonObject));
        }

        if (mBanklist != null && mBanklist.size() > 1 & NetworkManager.isNetworkAvailable(mContext)) {
            if (mBanklist.get(1).getType() != 1) {
                bankname info = new bankname();
                info.setType(1);
                this.mBanklist.add(1, info);
            }
        }
        sharedPreferences = mContext.getSharedPreferences("bank_select", MODE_PRIVATE);

        bank_name_selected = sharedPreferences.getString("bank_name", "No Bank");
    }


    @Override
    public int getItemViewType(int position) {
        if (mBanklist.get(position).getType() == 1) {
            return 1;
        } else {
            return 0;
        }
    }


    public void removeAdpos() {
        for (int i = 0; i < mBanklist.size(); i++) {
            if (mBanklist.get(i).getType() == 1) {
                mBanklist.remove(i);
                notifyDataSetChanged();
                break;
            }
        }
    }

    @Override
    public int getCount() {
        return mBanklist.size();
    }


    @Override
    public Object getItem(int i) {
        return mBanklist.get(i);
    }

    @Override
    public long getItemId(int i) {
        return mBanklist.get(i).getB_id();
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        if (getItemViewType(i) == 0) {
            View view1 = View.inflate(mContext, R.layout.custom_list_view_layout, null);

            ImageView select = view1.findViewById(R.id.select);

            final TextView bank_name = view1.findViewById(R.id.bank_name);
//        CircularTextView photo_card = view1.findViewById(R.id.photo_card);
            ImageView photo_card = view1.findViewById(R.id.photo_card);
            RelativeLayout bank_select = view1.findViewById(R.id.bank_select);

            bank_name.setText(mBanklist.get(i).getB_name());
            if (mBanklist.get(i).getB_name().equals(bank_name_selected)) {
                select.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.ic_check));
            } else {
                select.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.done));
            }

//            int id = mContext.getResources().getIdentifier("ic_" + mBanklist.get(i).getB_short().toLowerCase(), "drawable", mContext.getPackageName());
            int id = mContext.getResources().getIdentifier(/*"ic_" +*/ mBanklist.get(i).getImage_name(), "drawable", mContext.getPackageName());

            try {
                if (id != -1) {
                    photo_card.setImageResource(id);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            bank_select.setOnClickListener(view2 -> {
                click = 1;
                final int random = new Random().nextInt((4 - 1) + 1) + 1;
                if (random == 2) {

                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            SharedPreferences.Editor editorBank = sharedPreferences.edit();
                            bank_n = mBanklist.get(i).getB_name();
                            sbank_id = mBanklist.get(i).getB_id();
                            bank_url = mBanklist.get(i).getB_netbank();
                            bank_short = mBanklist.get(i).getB_short();

                            editorBank.putString("bank", "select");
                            editorBank.putString("bank_name", bank_n);
                            editorBank.putString("bank_url", bank_url);
                            editorBank.putString("bank_short", bank_short);
                            editorBank.putString("bank_id", String.valueOf(sbank_id));
                            editorBank.commit();

                            //navController.navigate(R.id.nav_box);

                            if (list_bank_relative != null) {
                                list_bank_relative.setVisibility(View.GONE);
                            }
                            if (box_view_relative != null) {
                                box_view_relative.setVisibility(View.VISIBLE);
                            }
                            if (onItemClickListner != null) {
                                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        EventBus.getDefault().post(new Intent().setAction("CHANGE_BANK").putExtra("bankName", bank_n));
                                        onItemClickListner.onItemClick();
                                    }
                                }, 100);
                            }
                        }
                    }, 0);
                } else {
                    sharedPreferences = mContext.getSharedPreferences("bank_select", MODE_PRIVATE);
                    SharedPreferences.Editor editorBank = sharedPreferences.edit();
                    bank_n = mBanklist.get(i).getB_name();
                    sbank_id = mBanklist.get(i).getB_id();
                    bank_url = mBanklist.get(i).getB_netbank();
                    bank_short = mBanklist.get(i).getB_short();


                    editorBank.putString("bank", "select");
                    editorBank.putString("bank_name", bank_n);
                    editorBank.putString("bank_url", bank_url);
                    editorBank.putString("bank_short", bank_short);
                    editorBank.putString("bank_id", String.valueOf(sbank_id));
                    editorBank.commit();

                    //navController.navigate(R.id.nav_box);

                    if (list_bank_relative != null) {
                        list_bank_relative.setVisibility(View.GONE);
                    }
                    if (box_view_relative != null) {
                        box_view_relative.setVisibility(View.VISIBLE);
                    }

                    if (onItemClickListner != null) {
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                EventBus.getDefault().post(new Intent().setAction("CHANGE_BANK").putExtra("bankName", bank_n));
                                onItemClickListner.onItemClick();
                            }
                        }, 100);
                    }
                }


            });
            return view1;

        } else {
            View view1 = View.inflate(mContext, R.layout.native_frame_layout_bank_list, null);
            FrameLayout adLayout = view1.findViewById(R.id.adLayout);
            LinearLayout li_adss = view1.findViewById(R.id.li_adss);
            FrameLayout layout_shimmer = view1.findViewById(R.id.layout_shimmer);

//            if (nativeAd != null) {
//                populateNativeAds(adLayout, li_adss, layout_shimmer);
//            } else {
                loadNativeAd(adLayout, li_adss, layout_shimmer);
//            }
            return view1;
        }
    }

    public void loadNativeAd(FrameLayout adLayout, LinearLayout li_adss, FrameLayout layout_shimmer) {
        layout_shimmer.setVisibility(View.VISIBLE);


        new NativeAdvancedModelHelper(mContext).loadNativeAd(
                NativeAdsSize.Banner,
                adLayout, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {
                        layout_shimmer.setVisibility(View.GONE);
                        return null;
                    }
                }
        );

//        AdmobAdManager.getInstance().LoadNativeAd(mContext, mContext.getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                nativeAd = object;
//                populateNativeAds(adLayout, li_adss, layout_shimmer);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//                layout_shimmer.setVisibility(View.GONE);
//            }
//
//        }, false);
    }


    private void populateNativeAds(FrameLayout adLayout, LinearLayout li_adss, FrameLayout layout_shimmer) {
        layout_shimmer.setVisibility(View.GONE);
//        if (nativeAd instanceof NativeAd) {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeAdView(mContext, adLayout, (NativeAd) nativeAd, 2);
//        }
    }


    public void OnItemClickListener(OnItemClickListner onItemClickListner) {
        this.onItemClickListner = onItemClickListner;
    }

}
