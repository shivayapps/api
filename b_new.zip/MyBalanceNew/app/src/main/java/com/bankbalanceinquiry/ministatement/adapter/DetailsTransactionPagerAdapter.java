package com.bankbalanceinquiry.ministatement.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;


public class DetailsTransactionPagerAdapter extends FragmentPagerAdapter {

    Context context;
    List<Fragment> fragmentList = new ArrayList<>();
    List<String> titleList = new ArrayList<>();

    public DetailsTransactionPagerAdapter(@NonNull FragmentManager fm, Context context,
                                          List<Fragment> fragmentList,List<String> titleList) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        this.context = context;
        this.fragmentList.clear();
        this.fragmentList.addAll(fragmentList);
        this.titleList.clear();
        this.titleList.addAll(titleList);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return titleList.get(position);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }
}
