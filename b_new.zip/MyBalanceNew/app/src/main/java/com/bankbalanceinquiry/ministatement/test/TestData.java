package com.bankbalanceinquiry.ministatement.test;

import java.io.Serializable;
import java.util.ArrayList;

public class TestData implements Serializable {

    private String TitleDate;
    private String Amout;
    private String CreditDebit;
    private int GetTitleType = 1;
    private boolean isSectionHeader = false;
    private String SetCreditedAmount = "";
    private ArrayList<String> strings =new ArrayList<>();
    private ArrayList<String> DebitData =new ArrayList<>();


    public TestData(String titleDate, String amout, String creditDebit) {
        TitleDate = titleDate;
        Amout = amout;
        CreditDebit = creditDebit;
    }

    public String getTitleDate() {
        return TitleDate;
    }

    public void setTitleDate(String titleDate) {
        TitleDate = titleDate;
    }

    public String getAmout() {
        return Amout;
    }

    public void setAmout(String amout) {
        Amout = amout;
    }

    public String getCreditDebit() {
        return CreditDebit;
    }

    public void setCreditDebit(String creditDebit) {
        CreditDebit = creditDebit;
    }

    public int getGetTitleType() {
        return GetTitleType;
    }

    public void setGetTitleType(int getTitleType) {
        GetTitleType = getTitleType;
    }

    public boolean isSectionHeader() {
        return isSectionHeader;
    }

    public void setSectionHeader(boolean sectionHeader) {
        isSectionHeader = sectionHeader;
    }


    public String getSetCreditedAmount() {
        return SetCreditedAmount;
    }

    public void setSetCreditedAmount(String setCreditedAmount) {
        SetCreditedAmount = setCreditedAmount;
    }

    public ArrayList<String> getStrings() {
        return strings;
    }

    public void setStrings(ArrayList<String> strings) {
        this.strings = strings;
    }

    public ArrayList<String> getDebitData() {
        return DebitData;
    }

    public void setDebitData(ArrayList<String> debitData) {
        DebitData = debitData;
    }
}
