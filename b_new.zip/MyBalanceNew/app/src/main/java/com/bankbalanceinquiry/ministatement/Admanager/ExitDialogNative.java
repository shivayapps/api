package com.bankbalanceinquiry.ministatement.Admanager;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class ExitDialogNative extends BottomSheetDialogFragment {
    View view;
    boolean isExit = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.layout_bottom_navigation_exit, container, false);
        initView();
        getDialog().setOnShowListener(dialog -> {
            new Handler(Looper.myLooper()).postDelayed(() -> {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                FrameLayout bottomSheet = d.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                bottomSheetBehavior.setSkipCollapsed(true);
            }, 0);
        });
        return view;
    }

    private void initView() {
        TextView tv_exit = view.findViewById(R.id.tv_exit);
        FrameLayout adLayout = view.findViewById(R.id.adLayout);


        new NativeAdvancedModelHelper(getActivity()).loadNativeAd(
                NativeAdsSize.Banner,
                adLayout, new Function1<Boolean, Unit>() {
                    @Override
                    public Unit invoke(Boolean aBoolean) {
                        return null;
                    }
                }
        );
//        if ((AdmobAdManager.getInstance().mNativeRateAd instanceof NativeAd)) {
//            AdmobAdManager.getInstance().populateUnifiedNativeAdView1(
//                    getContext(),
//                    adLayout,
//                    ((NativeAd) AdmobAdManager.getInstance().mNativeRateAd),
//                    true,
//                    false);
//
//        }
        tv_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isExit = true;
                dismiss();
                Constant.isShplashScreen = true;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getActivity().finishAndRemoveTask();
                }
                getActivity().finishAffinity();

            }
        });
        //tv_exit.setOnClickListener { v: View? -> this.finish() }
    }


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Dialog dialog = super.onCreateDialog(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = dialog.getWindow();
            if (window != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                window.getWindowManager().getDefaultDisplay().getMetrics(metrics);

                GradientDrawable dimDrawable = new GradientDrawable();

                GradientDrawable navigationBarDrawable = new GradientDrawable();
                navigationBarDrawable.setShape(GradientDrawable.RECTANGLE);
                navigationBarDrawable.setColor(getResources().getColor(R.color.white));

                Drawable[] layers = {dimDrawable, navigationBarDrawable};

                LayerDrawable windowBackground = new LayerDrawable(layers);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    windowBackground.setLayerInsetTop(1, metrics.heightPixels);
                }

                window.setBackgroundDrawable(windowBackground);
            }
        }
        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.CustomBottomSheetDialogTheme);
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {

//        if (AdmobAdManager.getInstance().mNativeRateAd != null) {
//            AdmobAdManager.getInstance().mNativeRateAd.destroy();
//            AdmobAdManager.getInstance().mNativeRateAd = null;
//            if (!isExit) {
//                AdmobAdManager.getInstance()
//                        .LoadNativeRateAd(getActivity(), getContext().getString(R.string.temp_adx_native_id), null);
//            }
//        }
        super.onDismiss(dialog);
    }
}
