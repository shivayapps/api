package com.bankbalanceinquiry.ministatement.activity;

import static com.bankbalanceinquiry.ministatement.utils.Constant.setLocale;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.bankbalanceinquiry.ministatement.Admanager.AdmobAdManager;
import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.databinding.ActivityAdsLoadBinding;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;


public class AdsLoadActivity extends AppCompatActivity {
    ActivityAdsLoadBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAdsLoadBinding.inflate(getLayoutInflater());
        setLocale(AdsLoadActivity.this);
        setContentView(binding.getRoot());
        showAds1();

    }


    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(AdsLoadActivity.this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33) {
                    if (ActivityCompat.checkSelfPermission(AdsLoadActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    private void showAds1() {
        if (AdmobAdManager.getInstance().isAdLoad) {
            new Handler(Looper.myLooper()).postDelayed(() -> {
                AdmobAdManager.getInstance().loadInterstitialAd(AdsLoadActivity.this, getString(R.string.temp_adx_interstitial_id), 1, () -> {
                    startNextScreen();
                });
            }, 500);
        } else {
            new Thread(() -> {
                while (!AdmobAdManager.getInstance().isAdLoad &&
                        !AdmobAdManager.getInstance().isAdLoadFailed) {
                    Log.d("TAG", "showInterstitialAd: ");
                }
                runOnUiThread(() -> {
                    new Handler(Looper.myLooper()).postDelayed(() -> {
                        AdmobAdManager.getInstance().loadInterstitialAd(AdsLoadActivity.this, getString(R.string.temp_adx_interstitial_id), 1, () -> {
                            startNextScreen();
                        });
                    }, 500);
                });
            }).start();
        }
    }

    private void startNextScreen() {
        if (isStoragePermissionGranted()) {
            if (!PreferenceHelper.getFromBooleans(this, Constant.LANG_SELECTED, false)) {
                startActivity(new Intent(this, LanguageSelectActivity.class).putExtra("isFromSetting", false));
            } else {
                Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
                startActivity(i);
            }
        } else if (!PreferenceHelper.getFromBooleans(this, Constant.LANG_SELECTED, false)) {
            startActivity(new Intent(this, PermissionActivity.class).putExtra("isFromSetting", false));
        } else {
            Intent i = new Intent(getApplicationContext(), drawerActivity1.class);
            startActivity(i);
        }

    }


}