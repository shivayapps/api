package com.bankbalanceinquiry.ministatement.common;

import java.io.Serializable;

public class BankNameLogo implements Serializable {

    private String BankName;
    private int BankLogo;

    public BankNameLogo(String bankName, int bankLogo) {
        BankName = bankName;
        BankLogo = bankLogo;
    }

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String bankName) {
        BankName = bankName;
    }

    public int getBankLogo() {
        return BankLogo;
    }

    public void setBankLogo(int bankLogo) {
        BankLogo = bankLogo;
    }
}
