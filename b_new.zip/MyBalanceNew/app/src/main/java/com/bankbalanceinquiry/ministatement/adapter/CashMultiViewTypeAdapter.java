package com.bankbalanceinquiry.ministatement.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.marcoscg.dialogsheet.DialogSheet;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CashMultiViewTypeAdapter extends
        RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final ArrayList<HomeAccoutList> dataSet;

    private Context mContext;
    private final Activity activity;
    private int total_types;

    public ClickHistory ApkDetails;
    private String rsString;
    private Object nativeAd = null;

    public interface ClickHistory {
        void ClickValue(AllAccountModelHistory callNumber);
    }

    public void RegisterInterface(ClickHistory photoInterface) {
        this.ApkDetails = photoInterface;
    }

    public static class TypeTitle extends RecyclerView.ViewHolder {
        private final TextView tvTitle;
        private final TextView tvCreditedAmount;
        private final TextView tvDebitedAmount;

        public TypeTitle(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvCreditedAmount = itemView.findViewById(R.id.tvCreditedAmount);
            tvDebitedAmount = itemView.findViewById(R.id.tvDebitedAmount);
        }
    }

    public static class TypeData extends RecyclerView.ViewHolder {
        private final ImageView micName;
        private final TextView tvDDate;
        private final TextView tvAmount;
        private final TextView tvBankName;
        private final TextView tv_description;
        private final LinearLayout llMain;

        public TypeData(View itemView) {
            super(itemView);
            micName = itemView.findViewById(R.id.micName);
            tvDDate = itemView.findViewById(R.id.tvDDate);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvBankName = itemView.findViewById(R.id.tvBankName);
            tv_description = itemView.findViewById(R.id.tv_description);
            llMain = itemView.findViewById(R.id.llMain);
        }
    }

    public CashMultiViewTypeAdapter(Activity context, ArrayList<HomeAccoutList> data) {
        this.activity = context;
        rsString = activity.getString(R.string.Rs);
        this.dataSet = data;
        int findAdPos = -1;
        for (int i = 0; i < dataSet.size(); i++) {
            if (i > 1) {
                if (dataSet.get(i).GetTitleType == 1) {
                    findAdPos = i;
                    break;
                }
            }
        }

       /* if (findAdPos != -1) {
            if (dataSet != null && dataSet.size() > 1 && dataSet.get(1).getType() != 2) {
                HomeAccoutList info = new HomeAccoutList(2);
                dataSet.add(findAdPos + 1, info);
                notifyItemInserted(findAdPos + 1);
            }
        }*/

       /* if (findAdPos != -1) {
            loadNativeAd(findAdPos);
        }*/
    }

    public void removeAdpos() {
        for (int i = 0; i < dataSet.size(); i++) {
            if (dataSet.get(i).getType() == 2) {
                dataSet.remove(i);
                notifyItemRemoved(i);
                break;
            }
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 0:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_cash_title, parent, false);
                return new TypeTitle(view);
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_cash_data, parent, false);
                return new TypeData(view);
            case 2:
                LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
                view = layoutInflater.inflate(R.layout.native_frame_layout_cash, parent, false);
                return new AdViewHolder(view);
        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        if (dataSet.get(position).getType() == 2) {
            return 2;
        } else {

            switch (dataSet.get(position).GetTitleType) {
                case 0:
                    return 0;
                case 1:
                    return 1;
                default:
                    return -1;
            }
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder,
                                 final int listPosition) {
        HomeAccoutList object = dataSet.get(listPosition);
        if (object != null) {
            if (object.getType() == 2) {
                if (nativeAd != null) {
                    populateNativeAds((AdViewHolder) holder);
                } else {
                    loadNativeAd((AdViewHolder) holder);
                }
            } else {
                switch (object.GetTitleType) {
                    case 0:
                        CallTitleType(((TypeTitle) holder), object);
                        break;
                    case 1:
                        CallDataType(((TypeData) holder), object, listPosition);
                        break;
                }
            }
        }
    }


    public void loadNativeAd(AdViewHolder holder1) {
        holder1.layout_shimmer.setVisibility(View.VISIBLE);

//        AdmobAdManager.getInstance().LoadNativeAd(activity, activity.getString(R.string.temp_adx_native_id), new AdEventListener() {
//            @Override
//            public void onAdLoaded(Object object) {
//                nativeAd = object;
//                populateNativeAds(holder1);
//            }
//
//            @Override
//            public void onAdClosed() {
//            }
//
//            @Override
//            public void onLoadError(String errorCode) {
//                holder1.layout_shimmer.setVisibility(View.GONE);
//                removeAdpos();
//            }
//
//        }, false);

       /* AdmobAdManager.getInstance().LoadNativeAdSmall(activity, activity.getString(R.string.native_id), new AdEventListener() {
            @Override
            public void onAdLoaded(Object object) {
                nativeAd = object;
                populateNativeAds(holder1);
            }

            @Override
            public void onAdClosed() {
            }

            @Override
            public void onLoadError(String errorCode) {
                holder1.layout_shimmer.setVisibility(View.GONE);
                removeAdpos();
            }
*//*
  @Override
            public void onAdLoaded(MaxNativeAdView maxNativeAdView, MaxAd maxAd) {
                nativeAd = maxNativeAdView;
                populateNativeAds(holder1);
            }*//*

        }, 2);
*/
    }


    private void populateNativeAds(AdViewHolder holder1) {
        holder1.layout_shimmer.setVisibility(View.GONE);
//        if (nativeAd instanceof NativeAd) {
//            AdmobAdManager.getInstance()
//                    .populateUnifiedSmallNativeAdView(activity, holder1.adLayout, (NativeAd) nativeAd, 6);
//        }
        /*else {
            AdmobAdManager.getInstance()
                    .populateUnifiedSmallNativeApplovin(activity, holder1.adLayout, (MaxNativeAdView) nativeAd, null, false);
        }*/
    }


    public class AdViewHolder extends RecyclerView.ViewHolder {

        private final FrameLayout adLayout;
        LinearLayout li_adss;
        FrameLayout layout_shimmer;

        AdViewHolder(View itemView) {
            super(itemView);
            adLayout = itemView.findViewById(R.id.adLayout);
            li_adss = itemView.findViewById(R.id.li_adss);
            layout_shimmer = itemView.findViewById(R.id.layout_shimmer);
        }
    }


    private void CallDataType(TypeData holder, final HomeAccoutList object, final int listPosition) {
        TextView tvDDate = holder.tvDDate;
        TextView tvAmount = holder.tvAmount;
        TextView tvBankName = holder.tvBankName;

        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy", Locale.US);
        String year = simpleDateFormat.format(date);
        String dateVal = object.dateValHistory;
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy, hh:mm aa", Locale.US);
        SimpleDateFormat formatterHistory1 = new SimpleDateFormat("dd MMM yyyy, hh:mm aa", Locale.US);
        try {
            Date date3 = formatterHistory.parse(object.dateValHistory);
            dateVal = formatterHistory1.format(date3);
        } catch (ParseException e) {
            Log.e("SHGFshvc", e.getMessage() + "::");
            e.printStackTrace();
        }
        if (dateVal.contains(year)) {
            dateVal = dateVal.replace(" " + year, "");
        }
        tvDDate.setText(dateVal);
        String AccountAmount = object.amount;
        if (TextUtils.isEmpty(AccountAmount)) {
            AccountAmount = "0";
        }

        if (!TextUtils.isEmpty(AccountAmount)) {
            if (AccountAmount.contains(",")) {
                AccountAmount = AccountAmount.replace(",", "");
            }
            double d = Double.parseDouble(AccountAmount);
            NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
            DecimalFormat decim = (DecimalFormat) nf;
            decim.applyPattern("#,##,###.##");
            if (AccountAmount.contains(".")) {
                String afterPoint = AccountAmount.substring(AccountAmount.indexOf(".") + 1);
                if (afterPoint.length() > 2) {
//                    DecimalFormat decim = new DecimalFormat("");
                    AccountAmount = decim.format(d);
                }

                //DecimalFormat decim = new DecimalFormat("#,##,###.##");
                AccountAmount = decim.format(d);
            }
            holder.tvAmount.setText(rsString + " " + AccountAmount);
        } else {
            holder.tvAmount.setText("");
        }


        String name = object.full_name.replace(" Bank", "");
        if (!TextUtils.isEmpty(object.FinalAccountNo)) {
            holder.tvBankName.setText(name + " - " + object.FinalAccountNo);
        } else {
            holder.tvBankName.setText(name);
        }
        if (!TextUtils.isEmpty(object.finalTransactionDesc)) {
            holder.tv_description.setText(object.finalTransactionDesc);
        } else {
            holder.tv_description.setVisibility(View.GONE);
        }


        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DialogSheet(activity)
                        .setTitle(TextUtils.isEmpty("Account no") ? object.full_name : ("Account no" + (object.FinalAccountNo.length() < 4 ? " - X" : " - ") + object.FinalAccountNo))
                        .setMessage(object.body)
                        .setColoredNavigationBar(true)
                        .setTitleTextSize(20)
                        .setButtonsTextSize(15)
                        .setBackgroundColor(Color.WHITE)
                        .show();
            }
        });
    }

    private void CallTitleType(TypeTitle holder, HomeAccoutList object) {
        holder.tvTitle.setText(object.DateTransactionHistory);


        String AmoutCredited = CallAccountBalanceTesting(object.CreditedData);
        String AmoutDebited = CallAccountBalanceTesting(object.DebitedData);
        holder.tvCreditedAmount.setText(rsString + " " + AmoutCredited);
        holder.tvDebitedAmount.setText(rsString + " " + AmoutDebited);
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }


    private String CallAccountBalanceTesting(ArrayList<String> tempList) {
//        StringBuilder finalallbalance = new StringBuilder();
        double sum = 0;
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                double value = Double.parseDouble(AmoutValue);
                sum += value;
//                finalallbalance.append(AmoutValue);
            }
        }
        String s = String.valueOf(sum);
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        DecimalFormat decim = (DecimalFormat) nf;
        decim.applyPattern("#,##,###.##");
        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                //    DecimalFormat decim = new DecimalFormat("#,##,###.##");
                return decim.format(sum);
            }
        }
        //   DecimalFormat decim = new DecimalFormat("#,##,###.##");
        return decim.format(sum);
//        return String.valueOf(CommonFun.findSum(finalallbalance.toString()));
    }
}
