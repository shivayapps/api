package com.locationstamp.camera.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.locationstamp.camera.databinding.ActivitySettingBinding
import com.locationstamp.camera.dialogs.RatingDialog
import com.locationstamp.camera.extentions.baseConfig

class SettingActivity : BaseActivity() {

    lateinit var binding: ActivitySettingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initView()
    }

    fun initView(){
        binding.ivBack.setOnClickListener { finish() }

//        binding.includedDrawer.clTheme.setOnClickListener {
//            binding.includedDrawer.tbTheme.toggle()
//            if (baseConfig.themeSelectedMode == 0) {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
////                delegate.applyDayNight()
//                baseConfig.themeSelectedMode = 1
//            } else {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
////                delegate.applyDayNight()
//                baseConfig.themeSelectedMode = 0
//            }
//            val intent = Intent(this@CameraActivity, CameraActivity::class.java)
//            finishAffinity()
//            overridePendingTransition(0, 0)
//            startActivity(intent)
//            overridePendingTransition(0, 0)
//        }
        binding.tvLanguagesDesc.text = baseConfig.selectLanguageString
        binding.clLanguages.setOnClickListener {
//            binding.drawerLayout.close()
            startActivity(Intent(this@SettingActivity, LanguageSelectionActivity::class.java))
        }
        binding.clTemplate.setOnClickListener {
//            startActivity(Intent(this@CameraActivity, TemplateActivity::class.java))
//            binding.drawerLayout.close()
            intentLauncher.launch(Intent(this@SettingActivity, TemplateListActivity::class.java).putExtra("showingTemplate", baseConfig.templateSelected))
        }
        binding.clShare.setOnClickListener {
//            binding.drawerLayout.close()
            baseConfig.launchShare(this@SettingActivity, packageName)
        }
        binding.clRate.setOnClickListener {
//            binding.drawerLayout.close()
            launchRateDialog()/*baseConfig.launchRate(this@CameraActivity, packageName)*/
        }
        binding.clPrivacy.setOnClickListener {
//            binding.drawerLayout.close()
            baseConfig.openWebsiteIntent(this@SettingActivity, "https://sites.google.com/view/shivayappsgallery/home")
        }
    }

    private fun launchRateDialog() {
        val rateDialog = RatingDialog(this)
        rateDialog.show()
    }

    private val intentLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
//                Log.w("msg", "template_position: " + result.data?.getIntExtra("template_position", 0))
                result.data?.getIntExtra("template_position", 0)
                //setTemplate()
            }
        }
}