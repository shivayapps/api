package com.locationstamp.camera.helper

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Looper

//import com.textmessages.chatandmessage.models.Events
//import org.greenrobot.eventbus.EventBus


const val PREFS_KEY = "Prefs"
const val THREAD_ID = "thread_id"

const val TEMPLATE_POSITION = "template_position"
const val INTRO_SCREEN_SHOW = "intro_screen_show"
const val LANGUAGE_SCREEN_SHOW = "language_screen_show"
const val DEVICE_ORIENTATION = "device_orientation"
const val PREF_KEY_LANGUAGE = "pref_key_language"
const val PREF_KEY_LANGUAGE_STRING = "pref_key_language_string"
const val SET_SYSTEM_FONT = "set_system_font"
const val THEME_SELECTED_MODE = "theme_selected_mode"
const val THEME_SELECTED_ID = "theme_selected_id"
const val IS_AUTOMATIC = "is_automatic"
const val LAST_LATITUDE = "last_latitude"
const val LAST_LONGITUDE = "last_longitude"
const val LAST_ADDRESS = "last_address"
const val LAST_NOTE = "last_note"
const val DELAY_PICTURE_CLICK = "delay_picture_click"
const val FONT_SIZE = "font_size"
//const val STAMP_POSITION = "stamp_position"
const val STAMP_FONT_STYLE = "stamp_font_style"
const val STAMP_COLOR = "stamp_color"
const val STAMP_MAP_TYPE = "stamp_map_type"
const val STAMP_PLUS_CODE = "stamp_plus_code"
const val STAMP_LAT_LONG_FORMAT = "stamp_lat_long_format"
const val STAMP_DATE_FORMAT = "stamp_date_format"
const val DATE_FORMAT = "date_format"
const val STAMP_TIMEZONE = "stamp_timezone"
const val GET_ACCURACY = "get_accuracy"
const val GET_ALTITUDE = "get_altitude"
const val WEATHER_TYPE = "weather_type"
const val WIND_TYPE = "wind_type"
const val PRESSURE_TYPE = "pressure_type"
const val ALTITUDE_TYPE = "altitude_type"
const val ACCURACY_TYPE = "accuracy_type"
const val SHOW_MAP = "show_map"
const val SHOW_ADDRESS = "show_address"
const val SHOW_LAT_LONG = "show_lat_long"
const val SHOW_PLUS_CODE = "show_plus_code"
const val SHOW_DATE_TIME = "show_date_time"
const val SHOW_TIME_ZONE = "show_time_zone"

//const val SHOW_LOGO = "show_logo"
const val SHOW_NOTE = "show_note"
const val SHOW_WEATHER = "show_weather"
const val SHOW_WIND = "show_wind"
const val SHOW_HUMIDITY = "show_humidity"
const val SHOW_PRESSURE = "show_pressure"
const val SHOW_ALTITUDE = "show_altitude"
const val SHOW_ACCURACY = "show_accuracy"
const val TEMPLATE_SELECTED = "template_selected"
const val TEMPLATE_SELECTED_TEMPORARY = "template_selected_temporary"
const val CAMERA_GRID = "camera_grid"
const val CAMERA_RATIO = "camera_ratio"
const val CAMERA_WHITE_BALANCE = "camera_white_balance"
const val CAMERA_SCENE_BALANCE = "camera_scene_balance"
const val CAMERA_FOCUS = "camera_focus"
const val CAMERA_FLASH = "camera_flash"
const val LAST_IMAGE_ICON = "last_image_icon"


//picture click delay time
const val ZERO_SECONDS = 0L
const val THREE_SECONDS = 3000L
const val FIVE_SECONDS = 5000L

//White balance
const val AUTO = "Auto"
const val INCANDESCENT = "Incandescent"
const val FLUORESCENT = "Fluorescent"
const val DAYLIGHT = "Daylight"
const val CLOUDY = "Cloudy"

//Filters
const val NONE = "None"
const val AUTO_FIX = "Auto Fix"
const val BLACK_AND_WHITE = "Black & White"
const val BRIGHTNESS = "Brightness"
const val CONTRAST = "Contrast"
const val CROSS_PROCESS = "Cross Process"
const val DOCUMENTARY = "Documentary"
const val DUOTONE = "Duotone"
const val FILL_LIGHT = "Fill Light"
const val GAMMA = "Gamma"
const val GRAIN = "Grain"
const val GRAYSCALE = "Grayscale"
const val HUE = "Hue"
const val INVERT_COLORS = "Invert colors"
const val LOMOISH = "Lomoish"
const val POSTERIZE = "Posterize"
const val SATURATION = "Saturation"
const val SEPIA = "Sepia"
const val SHARPNESS = "Sharpness"
const val TEMPERATURE = "Temperature"
const val TINT = "Tint"
const val VIGNETTE = "Vignette"

//Ratio
const val ONE_ONE = "1:1"
const val FOUR_THREE = "4:3"
const val SIXTEEN_NINE = "16:9"
const val MATCH_VIEW = "Full"

// font sizes
const val FONT_SIZE_SMALL = 0
const val FONT_SIZE_MEDIUM = 1
const val FONT_SIZE_LARGE = 2
const val FONT_SIZE_EXTRA_SMALL = 3

// stamp position
//const val STAMP_TOP = 0
//const val STAMP_BOTTOM = 1

// stamp font style
//const val FONT_HIND = 0
//const val FONT_INTER = 1
//const val FONT_ROBOTO = 2
//const val FONT_SF = 3
//const val FONT_POPPINS = 4


const val FONT_SOURCECODEPRO = 0
const val FONT_ROBOTOCONDENSED = 1
const val FONT_OPENSANS = 2
const val FONT_NOTOSANSDISPLAY = 3
const val FONT_IBMPLEXSANS = 4
const val FONT_INTER = 5
const val FONT_POPPINS = 6
const val FONT_ROBOTO = 7
const val FONT_SF_UI = 8

// map type
const val MAP_NORMAL = 0
const val MAP_SATELLITE = 1
const val MAP_TERRAIN = 2
const val MAP_HYBRID = 3


// lat/long format
const val LATLONG_DECIMAL = 0
const val LATLONG_DEGREE = 1
const val LATLONG_DEGREE_MICRO = 2
const val LATLONG_DECIMAL_MINUTES = 3
const val LATLONG_DEGREE_MINUTES_SECONDS = 4
const val LATLONG_DECIMAL_MINUTES_SECONDS = 5
const val LATLONG_UTM = 6
const val LATLONG_MGRS = 7

// date_time format
const val DATE_FORMAT_ONE = "dd/MM/yy hh:mm a"
const val DATE_FORMAT_TWO = "MM/dd/yy"
const val DATE_FORMAT_THREE = "dd/MM/yy"
const val DATE_FORMAT_FOUR = "dd/MM/yy HH:mm"
const val DATE_FORMAT_FIVE = "MM/dd/yyyy"
const val DATE_FORMAT_SIX = "dd/MM/yyyy HH:mm"
const val DATE_FORMAT_SEVEN = "dd/MM/yyyy hh:mm a"
const val DATE_FORMAT_EIGHT = "dd-MM-yyyy"
const val DATE_FORMAT_NINE = "d MMMM yyyy"
const val DATE_FORMAT_TEN = "MMMM d yyyy"

// date_time format
const val DATE_FORMAT_ONE_CONST = 0
const val DATE_FORMAT_TWO_CONST = 1
const val DATE_FORMAT_THREE_CONST = 2
const val DATE_FORMAT_FOUR_CONST = 3
const val DATE_FORMAT_FIVE_CONST = 4
const val DATE_FORMAT_SIX_CONST = 5
const val DATE_FORMAT_SEVEN_CONST = 6
const val DATE_FORMAT_EIGHT_CONST = 7
const val DATE_FORMAT_NINE_CONST = 8
const val DATE_FORMAT_TEN_CONST = 9

// timezone format
const val TIMEZONE_FORMAT_ONE = 0
const val TIMEZONE_FORMAT_TWO = 1
const val TIMEZONE_FORMAT_THREE = 2
const val TIMEZONE_FORMAT_FOUR = 3
const val TIMEZONE_FORMAT_FIVE = 4
const val TIMEZONE_FORMAT_SIX = 5

// weather format
const val WEATHER_FORMAT_CELSIUS = 0
const val WEATHER_FORMAT_FAHRENHEIT = 1

// wind format
const val WIND_FORMAT_KMH = 0
const val WIND_FORMAT_MPH = 1
const val WIND_FORMAT_MS = 2
const val WIND_FORMAT_KT = 3

// pressure format
const val PRESSURE_FORMAT_HPA = 0
const val PRESSURE_FORMAT_MMHG = 1
const val PRESSURE_FORMAT_INHG = 2

// altitude format
const val ALTITUDE_FORMAT_METER = 0
const val ALTITUDE_FORMAT_FOOT = 1

// accuracy format
const val ACCURACY_FORMAT_METER = 0
const val ACCURACY_FORMAT_FOOT = 1

const val EXTRA_IS_OPEN_FROM_SPLASH = "extra_is_open_from_splash"

fun isOnMainThread() = Looper.myLooper() == Looper.getMainLooper()

fun ensureBackgroundThread(callback: () -> Unit) {
    if (isOnMainThread()) {
        Thread {
            callback()
        }.start()
    } else {
        callback()
    }
}

/* Activity Events */
const val activity_tag: String = "activity"
const val open_tag: String = "open"

//fun refreshMessages() {
//    EventBus.getDefault().post(Events.RefreshMessages())
//}


inline val Context.isOnline: Boolean
    get() {
        (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).let { connectivityManager ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)?.let {
                    return it.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                }
            } else {
                try {
                    connectivityManager.activeNetworkInfo?.let {
                        if (it.isConnected && it.isAvailable) {
                            return true
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        return false
    }
