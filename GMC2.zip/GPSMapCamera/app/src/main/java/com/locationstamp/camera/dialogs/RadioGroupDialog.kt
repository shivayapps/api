package com.locationstamp.camera.dialogs

import android.app.Activity
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.content.res.ResourcesCompat
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.DialogRadioGroupBinding
import com.locationstamp.camera.extentions.beVisible
import com.locationstamp.camera.models.RadioItem


class RadioGroupDialog(
    val activity: Activity, val items: ArrayList<RadioItem>, val checkedItemId: Int = -1, val titleName: String = "",
    showOKButton: Boolean = false, val cancelCallback: (() -> Unit)? = null, val callback: (newValue: Any) -> Unit
) {
    private lateinit var binding: DialogRadioGroupBinding
    private var dialog: AlertDialog? = null
    private var wasInit = false
    private var selectedItemId = -1

    init {
        binding = DialogRadioGroupBinding.inflate(activity.layoutInflater)
        val view = binding.root
//        val view = activity.layoutInflater.inflate(R.layout.dialog_radio_group, null)
        if(titleName.isNotEmpty()) {
            binding.tvTitle.beVisible()
            binding.viewDialogDivider.beVisible()
            binding.tvTitle.text = titleName
            binding.dialogRadioHolder.apply {
                background = ResourcesCompat.getDrawable(activity.resources, R.drawable.bg_dialog, null)
            }
        }
        binding.dialogRadioGroup.apply {
            for (i in 0 until items.size) {
                val radioButton = (activity.layoutInflater.inflate(R.layout.radio_button, null) as RadioButton).apply {
                    text = items[i].title
                    isChecked = items[i].id == checkedItemId
                    id = i
                    setOnClickListener { itemSelected(i) }
                }

                if (items[i].id == checkedItemId) {
                    selectedItemId = i
                }

                addView(radioButton, RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        }


        val builder = AlertDialog.Builder(activity)
            .setOnCancelListener { cancelCallback?.invoke() }

        if (selectedItemId != -1 && showOKButton) {
            builder.setPositiveButton(R.string.ok) { dialog, which -> itemSelected(selectedItemId) }
        }

        builder.apply {
            /*activity.setupDialogStuff(view, this, titleId) { alertDialog ->
                dialog = alertDialog
            }*/

            create().apply {
                setView(view)
//                activity.requestWindowFeature(Window.FEATURE_NO_TITLE)
                setCancelable(true)
                if (!activity.isFinishing) {
                    show()
                }
//                val bgDrawable = ResourcesCompat.getDrawable(activity.resources, R.drawable.dialog_corner_bg, null)
//                activity.window?.setBackgroundDrawable(bgDrawable)
//                callback?.invoke(this)
            }
        }

        wasInit = true
    }

    private fun itemSelected(checkedId: Int) {
        if (wasInit) {
            callback(items[checkedId].value)
            dialog?.dismiss()
        }
    }
}
