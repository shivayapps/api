package com.locationstamp.camera.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.locationstamp.camera.R
import com.locationstamp.camera.adapters.LanguageSelectionAdapter
import com.locationstamp.camera.databinding.ActivityLanguageSelectionBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.helper.LogUtils
import com.locationstamp.camera.helper.EXTRA_IS_OPEN_FROM_SPLASH
import com.locationstamp.camera.helper.activity_tag
import com.locationstamp.camera.helper.open_tag
import com.locationstamp.camera.models.LanguageData

class LanguageSelectionActivity : BaseActivity() {

    lateinit var binding: ActivityLanguageSelectionBinding
    var selectPos = 0
    lateinit var adapter: LanguageSelectionAdapter
    var isOpenFromSplash: Boolean = false
    var languageList: ArrayList<LanguageData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageSelectionBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        //hideNavigationBar()
        LogUtils.logAdapterMessages(
            this@LanguageSelectionActivity,
            activity_tag,
            open_tag,
            LanguageSelectionActivity::class.java.simpleName.toString()
        )
        init()
        loadNative()
    }

    private fun loadIntAds() {
        val adId = getString(R.string.inter_all)
        AdmobIntersAdImpl().load(this, adId)
    }

    private fun init() {
        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra(EXTRA_IS_OPEN_FROM_SPLASH, false)

        getLanList()
        initListener()

        binding.icBack.visibility = if (isOpenFromSplash) View.GONE else View.VISIBLE

//        selectPos = preferences.getSelectLanguage()
        selectPos = baseConfig.selectLanguage
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = LanguageSelectionAdapter(
            this,
            languageList,
            clickListener = {
                selectPos = it
            })
        adapter.selectPos = selectPos
        binding.recyclerView.adapter = adapter
    }

    private fun updateViews(languageCode: String) {
        com.locationstamp.camera.helper.LocaleHelper.setLocale(this, languageCode)
    }

    private fun loadNative() {

        Log.e("loadHomeBanner", "loadNativeAd")
        val adId = getString(R.string.native_language)
        NativeAdHelper(
            this,
            binding.flNative,
            binding.flNative,
            NativeLayoutType.NativeBig,
            adId, { isLoaded, nativeAd ->

            }
        ).loadAd();
    }

    private fun initListener() {
        binding.icBack.setOnClickListener {
            finish()
        }

        binding.ivDone.setOnClickListener {
            AdsConfig.showInterstitialAd(this, {
                if (it) doneMethod()
                else doneMethod()
            })

        }
    }

    private fun doneMethod() {
        //            preferences.setSelectLanguage(selectPos)
        baseConfig.selectLanguage = selectPos
        //            preferences.putLanguage(true)
        baseConfig.languageScreenShow = 1
        baseConfig.selectLanguageString = languageList[selectPos].name
        updateViews(languageList[selectPos].languageCode)
        if (isOpenFromSplash) {

            Log.w("msg", "initListener: " + baseConfig.introScreenShow)
            val intent1 = if (baseConfig.introScreenShow == 0) {
                Intent(this, OnboardingActivity::class.java)
            } else if (!baseConfig.checkAllPermissions(this@LanguageSelectionActivity)) {
                Intent(this, AppPermissionActivity::class.java)
            } else {
                Intent(this, CameraActivity::class.java)
            }

            startActivity(intent1)
        } else {
            //                setResult(RESULT_OK)
            val intent = Intent(this, CameraActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent)
        }
        finish()
    }

    private fun getLanList() {
        languageList.add(
            LanguageData(
                getString(R.string.english),
                "en"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.spanish),
                "es"
            )
        )
        languageList.add(
            LanguageData(
                getString(R.string.german),
                "de"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.french),
                "fr"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.portuguese),
                "pt"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.hindi),
                "hi"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.swedish),
                "sv"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.norwegian),
                "no"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.italian),
                "it"
            )
        )

        languageList.add(
            LanguageData(
                getString(R.string.dutch),
                "nl"
            )
        )

    }
}