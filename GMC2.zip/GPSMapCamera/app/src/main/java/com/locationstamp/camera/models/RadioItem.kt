package com.locationstamp.camera.models

data class RadioItem(val id: Int, val title: String, val value: Any = id)
