package com.locationstamp.camera.extentions

import android.app.Activity
import android.content.Context
import android.widget.Toast
import com.locationstamp.camera.helper.Config
import com.locationstamp.camera.helper.PREFS_KEY

fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
    doToast(this, getString(id), length)
}
fun Context.toast(str: String, length: Int = Toast.LENGTH_SHORT) {
    doToast(this, str, length)
}
fun Context.getReviewEmail(): String {
    return "demo@gmail.com"
}
private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

val Context.baseConfig: Config get() = Config.newInstance(this)

