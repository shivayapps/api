package com.locationstamp.camera.activities

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ActivityOnboardingBinding
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.helper.LogUtils
import com.locationstamp.camera.helper.activity_tag
import com.locationstamp.camera.helper.open_tag
import com.zhpan.indicator.enums.IndicatorSlideMode
import com.zhpan.indicator.enums.IndicatorStyle
import com.zhpan.indicator.utils.IndicatorUtils

class OnboardingActivity : BaseActivity() {


    private val handler = Handler(Looper.getMainLooper())
    private var currentPage = 0
    private lateinit var binding: ActivityOnboardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        LogUtils.logAdapterMessages(
            this@OnboardingActivity,
            activity_tag,
            open_tag,
            OnboardingActivity::class.java.simpleName.toString()
        )
        //hideNavigationBar()
        allClicks()
    }

    private fun allClicks() {

        binding.tvGetStarted.setOnClickListener {
            baseConfig.introScreenShow = 1
            startActivity(Intent(this, AppPermissionActivity::class.java))
            finish()
        }
        val introPages = listOf(
            getString(R.string.intro_title1) to getString(R.string.intro_message1),
            getString(R.string.intro_title2) to getString(R.string.intro_message2),
            getString(R.string.intro_title3) to getString(R.string.intro_message3)
        )

        binding.viewPager.adapter = IntroPagerAdapter(introPages)

        val indicatorSize = introPages.size
//        TabLayoutMediator(binding.tabLayout, binding.viewPager) { _, _ -> }.attach()
        startAutoScroll(indicatorSize)
        binding.indicator.setPageSize(indicatorSize)
        binding.indicator.apply {
            setIndicatorStyle(IndicatorStyle.ROUND_RECT)
            setSliderGap(IndicatorUtils.dp2px(4f).toFloat())
            setSlideMode(IndicatorSlideMode.SCALE)
            setSliderHeight(
                resources.getDimensionPixelOffset(com.intuit.sdp.R.dimen._6sdp).toFloat()
            )
            setSliderColor(Color.parseColor("#BBBCC0"), Color.parseColor("#3478F6"))
            setSliderWidth(
                resources.getDimension(com.intuit.sdp.R.dimen._6sdp),
                resources.getDimension(com.intuit.sdp.R.dimen._10sdp)
            )
            notifyDataChanged()
        }

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
                binding.indicator.onPageScrolled(
                    (position % indicatorSize),
                    positionOffset,
                    positionOffsetPixels
                )
            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                binding.indicator.onPageSelected((position % indicatorSize))

            }
        })

    }

    class IntroPagerAdapter(
        private val items: List<Pair<String, String>>
    ) : RecyclerView.Adapter<IntroPagerAdapter.IntroViewHolder>() {

        inner class IntroViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvTitle: TextView = view.findViewById(R.id.tv_intro_title)
            val tvDesc: TextView = view.findViewById(R.id.tv_intro_desc)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IntroViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_intro_page, parent, false)
            return IntroViewHolder(view)
        }

        override fun onBindViewHolder(holder: IntroViewHolder, position: Int) {
            holder.tvTitle.text = items[position].first
            holder.tvDesc.text = items[position].second
        }

        override fun getItemCount(): Int = items.size
    }

    private fun startAutoScroll(pageCount: Int) {
        val runnable = object : Runnable {
            override fun run() {
                currentPage = (currentPage + 1) % pageCount
                binding.viewPager.setCurrentItem(currentPage, true)
                handler.postDelayed(this, 1500) // 3 sec delay
            }
        }
        handler.postDelayed(runnable, 1500)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null) // stop auto-scroll
    }


    /*private fun hideNavigationBar() {
        // Check if the device is running Android 11 or higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Get the WindowInsetsController
            val windowInsetsController = window.insetsController

            // Hide the navigation bar
            windowInsetsController?.hide(WindowInsets.Type.navigationBars())

            // To make the navigation bar appear temporarily when swiping from the edge of the screen
            // you can use the following line:
            windowInsetsController?.systemBarsBehavior =
                WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        } else {
            // For devices running below Android 11, you can still use the deprecated flag
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        }
    }*/
}