package com.locationstamp.camera.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ListItemBinding
import com.locationstamp.camera.extentions.baseConfig

class WhiteBalanceRecyclerAdapter(private val items: List<String>, private val context: Context, private val itemClickListener: OnItemClickListener) :
    RecyclerView.Adapter<WhiteBalanceRecyclerAdapter.ViewHolder>() {
    private var selectedPosition = context.baseConfig.cameraWhiteBalance //0 // Initialize with no selection

    inner class ViewHolder(private val binding: ListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val previousSelectedPosition = selectedPosition
                selectedPosition = adapterPosition

                // Notify item changes to update backgrounds
                notifyItemChanged(previousSelectedPosition)
                notifyItemChanged(selectedPosition)

                itemClickListener.onItemClickWhite(adapterPosition)
            }
        }
        fun bind(item: String) {
            binding.tvWhiteBalance.text = item
            if (adapterPosition == selectedPosition) {
                binding.tvWhiteBalance.setBackgroundResource(R.drawable.recycler_item_bg_select)
            } else {
                // Set the background for unselected items (if needed)
                binding.tvWhiteBalance.setBackgroundResource(R.drawable.recycler_item_bg_unselect)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    interface OnItemClickListener {
        fun onItemClickWhite(position: Int)
    }
}
