package com.gallery.photo.image.video.mainduplicate.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gallery.photo.image.video.mainduplicate.callbacks.MarkedListener
import com.gallery.photo.image.video.mainduplicate.model.IndividualGroupModel
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import java.util.*

class IndividualPhotosAdapter(
    var individualMediaAdapterContext: Context,
    var individualMediaAdapterActivity: Activity,
    var imagesMarkedListener: MarkedListener,
    var groupOfDupesPhotos: List<IndividualGroupModel>,
) : RecyclerView.Adapter<IndividualPhotosAdapter.MediaViewHolder>() {

    class MediaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var checkBox: CheckBox = itemView.findViewById(R.id.cb_grp_checkbox)
        var myGridView: RecyclerView = itemView.findViewById(R.id.gv_images)
        var textView: TextView = itemView.findViewById(R.id.tv_grp_name)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MediaViewHolder {
        return MediaViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_media, parent, false))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MediaViewHolder, position: Int) {
        val individualGroup = groupOfDupesPhotos[position]
        holder.myGridView.layoutManager = GridLayoutManager(individualMediaAdapterContext, 2)
        holder.textView.text = individualMediaAdapterContext.getString(R.string.label_duplicate_save) + individualGroup.groupTag
        holder.checkBox.isChecked = individualGroup.isCheckBox
        holder.myGridView.adapter = ListPhotosAdapter(
            individualMediaAdapterContext,
            individualMediaAdapterActivity,
            imagesMarkedListener,
            groupOfDupesPhotos[position],
            individualGroup.individualGrpOfDupes!!,
            holder.checkBox
        )
        holder.checkBox.setOnCheckedChangeListener { buttonView: CompoundButton, isChecked: Boolean ->
            buttonView.setOnClickListener {
                val individualGroup1 = groupOfDupesPhotos[position]
                individualGroup1.isCheckBox = isChecked
                val gridMediaAdapter = ListPhotosAdapter(
                    individualMediaAdapterContext,
                    individualMediaAdapterActivity,
                    imagesMarkedListener,
                    groupOfDupesPhotos[position],
                    setCheckBox(individualGroup1.individualGrpOfDupes, isChecked),
                    holder.checkBox
                )
                holder.myGridView.adapter = gridMediaAdapter
                gridMediaAdapter.notifyItemChanged(position)
            }
        }
    }

    override fun getItemCount(): Int {
        return groupOfDupesPhotos.size
    }

    private fun setCheckBox(imageItems: List<ItemDuplicateModel>?, value: Boolean): List<ItemDuplicateModel> {
        val lListOfDupes: MutableList<ItemDuplicateModel> = ArrayList()
        for (i in imageItems!!.indices) {
            val imageItem = imageItems[i]
            when {
                i != 0 -> {
                    if (!value) {
                        GlobalVarsAndFunctions.file_to_be_deleted_images.remove(imageItem)
                        GlobalVarsAndFunctions.subSizeImages(imageItem.sizeOfTheFile)
                        imagesMarkedListener.updateMarked()
                    } else if (!imageItem.isFileCheckBox) {
                        GlobalVarsAndFunctions.file_to_be_deleted_images.add(imageItem)
                        GlobalVarsAndFunctions.addSizeImages(imageItem.sizeOfTheFile)
                        imagesMarkedListener.updateMarked()
                    }
                    imageItem.isFileCheckBox = value
                    lListOfDupes.add(imageItem)
                }
                imageItem.isFileCheckBox -> {
                    GlobalVarsAndFunctions.file_to_be_deleted_images.remove(imageItem)
                    imageItem.isFileCheckBox = false
                    lListOfDupes.add(imageItem)
                }
                else -> {
                    imageItem.isFileCheckBox = false
                    lListOfDupes.add(imageItem)
                }
            }
        }
        return lListOfDupes
    }
}