package com.gallery.photo.image.video.mainduplicate.activity.scanningactivities

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseActivity
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.adshelper.AdsManager

import com.gallery.photo.image.video.mainduplicate.activity.duplicateactivities.*
import com.gallery.photo.image.video.mainduplicate.asynctask.ReadingAllFilesAsyncTask
import com.gallery.photo.image.video.mainduplicate.callbacks.SearchListener
import com.gallery.photo.image.video.mainduplicate.model.DuplicateFileRemoverSharedPreferences
import com.gallery.photo.image.video.mainduplicate.model.PopUp
import com.gallery.photo.image.video.utilities.isAppOpenAdShow
import com.gallery.photo.image.video.utilities.isInterstitialShown
import com.gallery.photo.image.video.utilities.isUnLockApp
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import io.github.inflationx.viewpump.ViewPumpContextWrapper
import kotlinx.android.synthetic.main.activity_scanning_new.*
import java.util.*

class ScanningActivity : BaseActivity(), SearchListener {

    var mTAG: String = javaClass.simpleName
    var mIsCheckType: String? = null
    var mIsScanningDone = false
    var isFromOneSignal = false
    var isFromSettings = false
    var isPause = false
    val mPermissionStorage = arrayOf(
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_scanning_new)
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = findViewById(R.id.gift_ad_icon),
                fivBlastIcon = findViewById(R.id.gift_blast_ad_icon)
            )
        }

        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(dm)
        val x = Math.pow((dm.widthPixels / dm.xdpi).toDouble(), 2.0)
        val y = Math.pow((dm.heightPixels / dm.ydpi).toDouble(), 2.0)
        val screenInches = Math.sqrt(x + y)
        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
            if (screenInches <= 5) {
                NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                    NativeAdsSize.Medium,
                    flBanner
                )
            } else {
                NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                    NativeAdsSize.Big,
                    flBanner
                )
            }
        } else {
            flBanner.visibility = View.GONE
        }
    }

    override fun getContext(): Activity {
        return this@ScanningActivity
    }

    override fun getAppIconIDs(): ArrayList<Int> = arrayListOf(
        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName(): String {
        return getString(R.string.app_name);
    }

    override fun initData() {
        mIsCheckType = intent.extras!!.getString("IsCheckType")

//        Glide.with(applicationContext)
//            .asGif() // make sure the GIF wont animate
//            .load(resources.getDrawable(R.drawable.loading_circle_animation))
//            .into(imgScanning)
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
        }
        if (checkPermissionStorage(mContext)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                checkAllFilePermission()
            } else {
                ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
            }
        } else {
            givePermissions(mPermissionStorage)
        }
    }

    private fun checkPermissionStorage(mContext: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (checkPermissionabove11()) {
                return true
            }
            return false
        } else {
            return if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) {
                isUnLockApp = true
                isAppOpenAdShow = false
                ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE),
                    101
                )
                false
            } else {
                true
            }
        }


    }

    fun checkAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
            } else {
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse(String.format("package:%s", packageName))
                )
                try {
                    launchActivityForResult(intent, 2296)
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun givePermissions(permissions: Array<String>) {

        isUnLockApp = true
        Dexter.withContext(mContext)
            .withPermissions(*permissions)
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {

                    when {
                        report.areAllPermissionsGranted() -> {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                checkAllFilePermission()
                            } else {
                                ReadingAllFilesAsyncTask(mContext, this@ScanningActivity, mIsCheckType).execute()
                            }
                        }
                        report.isAnyPermissionPermanentlyDenied -> {
                            showSettingsDialog()
                        }
                        else -> {
                            givePermissions(mPermissionStorage)
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(p0: MutableList<com.karumi.dexter.listener.PermissionRequest>?, token: PermissionToken?) {
                    token!!.continuePermissionRequest()
                }
            }).check()
    }

    private fun showSettingsDialog() {
        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
            .setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>" + getString(R.string.error_permission_required) + "</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))
            .setMessage(getString(R.string.msg_allow_permission_storage))
            .setPositiveButton(getString(R.string.ok))
            { dialog, which ->
                dialog.dismiss()
                isFromSettings = true
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", packageName, null)
                )
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launchActivityForResult(intent,2296)

//                            Share.isAppOpenAdShow = false
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
        alertDialogBuilder.show()
    }

    override fun fromActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.fromActivityResult(requestCode, resultCode, data)

        if (requestCode == 2296) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
                    Log.e(mTAG, "onActivityResult: Service Start ")
                } else {
                    if (isFromOneSignal) {
                        startActivity(MainActivity.newIntent(this))
                        finish()
                        Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(mContext, "Permission Required!!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else if (requestCode == 200) {
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
                }
            } else {
                if (isFromOneSignal) {
                    startActivity(MainActivity.newIntent(this))
                    finish()
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(mContext, getString(R.string.error_permission_required), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun initActions() {
        imgBack.setOnClickListener { onBackPressed() }

//        ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
    }

    override fun checkScanFinish() {
        Log.e(mTAG, "checkScanFinish ")
        redirectActivity()
        mIsScanningDone = true
    }


    private fun redirectActivity() {
        Log.e(mTAG, "redirectActivity: ==>>> $mIsCheckType")
        mIsScanningDone = false
        isInterstitialShown = false
        val intent: Intent = when (mIsCheckType) {
            "Image" -> Intent(mContext, DuplicateImageActivity::class.java)
            "Video" -> Intent(mContext, DuplicateVideosActivity::class.java)
            "Audio" -> Intent(mContext, DuplicateAudiosActivity::class.java)
            "Document" -> Intent(mContext, DuplicateDocumentsActivity::class.java)
            "Other" -> Intent(mContext, DuplicateOthersActivity::class.java)
            else -> throw IllegalStateException("Unexpected value: $mIsCheckType")
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
//        val pi: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
//        pi.send(this, 0, intent)
        startActivity(intent)

        Log.e(mTAG, "redirectActivity: intent ---> $intent")
        Log.e(mTAG, "redirectActivity: $mContext")
        finish()
    }

    override fun updateUi(vararg count: String?) {
        if (!DuplicateFileRemoverSharedPreferences.isScanningStop(mContext)) {
            runOnUiThread {
                if (count[0].equals("scanning", ignoreCase = true)) {
                    tvCount!!.text = count[1]
                    tvScanning_2!!.visibility = View.VISIBLE
                } else if (count[0].equals("sorting", ignoreCase = true)) {
                    tvCount!!.visibility = View.INVISIBLE
                    tvScanning_1!!.text = count[1]
                    tvScanning_2!!.visibility = View.INVISIBLE
                }
            }
        }
    }

    override fun onBackPressed() {
        PopUp(mContext, mContext).showAlertStopScanning(ReadingAllFilesAsyncTask(mContext, this, mIsCheckType))
    }

    override fun onResume() {
        super.onResume()
        Log.d("TAG1234", "onResume: Scanning activity ")
        if (isFromSettings) {
            isFromSettings = false
            if (checkPermissionStorage(mContext)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    checkAllFilePermission()
                } else {
                    ReadingAllFilesAsyncTask(mContext, this, mIsCheckType).execute()
                }
            }
        }
//        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
//            mContext.loadOfflineNativeAdvance(flBanner)
//        }


//        if (config.isAppPasswordProtectionOn && config.isEnableLock && isUnLockApp && mIsScanningDone) {
//            redirectActivity()
//        } else {
//        }
        if (mIsScanningDone) {
            redirectActivity()
        }

    }


    override fun onPause() {
        super.onPause()
        isPause = true
    }
}