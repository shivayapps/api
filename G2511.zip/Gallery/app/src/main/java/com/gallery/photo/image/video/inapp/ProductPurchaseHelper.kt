package com.gallery.photo.image.video.inapp
import android.app.Activity
import android.content.Context
import android.os.Parcelable
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.annotation.Keep
import androidx.annotation.NonNull
import com.android.billingclient.api.*
import com.gallery.photo.image.video.adshelper.AdsManager
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.android.parcel.Parcelize
import org.jetbrains.annotations.NotNull
import java.util.*


object ProductPurchaseHelper {

    @Keep
    @Parcelize
    data class ProductInfo(
        @SerializedName("id")
        @Expose
        val id: String,
        @SerializedName("formatted_price")
        @Expose
        val formattedPrice: String,
        @SerializedName("price_amount_micros")
        @Expose
        val priceAmountMicros: Long,
        @SerializedName("price_currency_code")
        @Expose
        val priceCurrencyCode: String,
        @SerializedName("billing_period")
        @Expose
        val billingPeriod: String,
        @SerializedName("free_trial_period")
        @Expose
        val freeTrialPeriod: String,
        @SerializedName("renewal_time")
        @Expose
        var renewalTime: Long,
        @SerializedName("product_detail")
        @Expose
        val productDetail: @kotlinx.android.parcel.RawValue ProductDetails
    ) : Parcelable

    private val TAG: String = javaClass.simpleName

    private val lifeTimeProductKeyList: ArrayList<String> = ArrayList()
    private val subscriptionKeyList: ArrayList<String> = ArrayList()
    private val PRODUCT_LIST: ArrayList<ProductInfo> = ArrayList()

    private var mPurchaseListener: ProductPurchaseListener? = null // Callback for listen purchase states
    private var mBillingClient: BillingClient? = null // Object of BillingClient

    private var isConsumable: Boolean = false // Flag if purchase need to consume so user can buy again

    private var mLastClickTime: Long = 0
    private const val mMinDuration = 1000

    private val Int.getPurchaseState: String
        get() {
            return when (this) {
                Purchase.PurchaseState.UNSPECIFIED_STATE -> {
                    "UNSPECIFIED_STATE"
                }
                Purchase.PurchaseState.PURCHASED -> {
                    "PURCHASED"
                }
                Purchase.PurchaseState.PENDING -> {
                    "PENDING"
                }
                else -> {
                    "Unknown"
                }
            }
        }

//    val String.getProductInfo: ProductInfo?
//        get() {
//            return PRODUCT_LIST.find { it.id.equals(this, true) }
//        }

    /**
     * get Product info
     * like formatted_price, price_amount_micros, price_currency_code,
     * billing_period, free_trial_period, renewal_time
     * and product_detail in json format
     *
     * @param id the product key
     */
    fun getProductInfo(id:String): ProductInfo? {
        return PRODUCT_LIST.find { it.id.equals(id, true) }
    }

    private fun setRenewalDate(id: String, renewalDate: Long) {
        for (i in PRODUCT_LIST.indices) {
            if (PRODUCT_LIST[i].id.equals(id, true)) {
                PRODUCT_LIST[i].renewalTime = renewalDate
            }
        }
        //return PRODUCT_LIST.find { it.id.equals(id, true) }
    }


    private val String.getPriceInDouble: Double
        get() {
            return if (this.isNotEmpty() && !(this.equals("Not Found", ignoreCase = false))) {
                this.replace("""[^0-9.]""".toRegex(), "").toDouble()
            } else {
                0.0
            }
        }


    /**
     * set lifetime product purchase key (one time purchase)
     * multiple key must separated with comma(,)
     * i.g: setLifeTimeProductKey("key1","key2",...)
     * @param keys the product key
     */
    fun setLifeTimeProductKey(vararg keys: String) {
        lifeTimeProductKeyList.removeAll(lifeTimeProductKeyList.toSet())
        lifeTimeProductKeyList.clear()
        lifeTimeProductKeyList.addAll(keys.filter { it.isNotEmpty() })
    }

    /**
     * set subscription purchase key
     * multiple key must separated with comma(,)
     * i.g: setSubscriptionKey("key1","key2",...)
     * @param keys the product key
     */
    fun setSubscriptionKey(vararg keys: String) {
        subscriptionKeyList.removeAll(subscriptionKeyList.toSet())
        subscriptionKeyList.clear()
        subscriptionKeyList.addAll(keys.filter { it.isNotEmpty() })
    }


    /**
     * Initialize billing client
     *
     * @param context The context to use. Usually your {@link android.app.Application}
     *                 or {@link android.app.Activity} object.
     * @param purchaseListener The callback that will return
     *
     */
    fun initBillingClient(context: Context, purchaseListener: ProductPurchaseListener) {
        mPurchaseListener = purchaseListener

        mBillingClient = BillingClient.newBuilder(context)
            .enablePendingPurchases()
            .setListener { billingResult, purchases ->
                if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                    return@setListener
                } else {
                    mLastClickTime = SystemClock.elapsedRealtime()
                    when (billingResult.responseCode) {
                        BillingClient.BillingResponseCode.OK -> {
                            if (purchases != null) {
                                for (purchase in purchases) {
                                    purchase?.let {
                                        handlePurchase(context, it)
                                    }
                                }
                            } else {
                                Log.i(TAG,"onPurchasesUpdated: =>> Response OK But Purchase List Null Found")

                            }
                        }
                        else -> {
                            when (billingResult.responseCode) {
                                BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED,
                                BillingClient.BillingResponseCode.BILLING_UNAVAILABLE,
                                BillingClient.BillingResponseCode.USER_CANCELED -> {
                                    if (billingResult.responseCode == BillingClient.BillingResponseCode.USER_CANCELED) {
                                        Toast.makeText(context, "You've cancelled the Google play billing process", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                else -> {
                                    Toast.makeText(context, "Item not found or Google play billing error", Toast.LENGTH_SHORT).show()
                                }
                            }
                            logResponseCode(responseMsg = "onPurchasesUpdated: ", billingResult = billingResult)
                        }
                    }
                }
            }
            .build()

        mBillingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() {
                Log.i(TAG,"onBillingServiceDisconnected: =>> DISCONNECTED")
            }

            override fun onBillingSetupFinished(billingResult: BillingResult) {
                logResponseCode("onBillingSetupFinished: ", billingResult)
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK
                    || billingResult.responseCode == BillingClient.BillingResponseCode.BILLING_UNAVAILABLE
                ) {
                    mPurchaseListener?.onBillingSetupFinished(billingResult)
                }
            }
        })
    }

    private fun getRenewalTime(purchaseTime: Long?, period: String): Long {

        val cal = Calendar.getInstance()
        cal.timeInMillis = purchaseTime!!
        if (!period.equals("Not Found", ignoreCase = true)) {
            var num = 1
            var prefix = "Month"
            if (period.contains(" ")) {
                num = period.substring(0, period.indexOf(" ")).trim { it <= ' ' }.toInt()
                prefix = period.substring(period.indexOf(" ")).trim { it <= ' ' }
            } else {
                num = 1
                prefix = period.trim { it <= ' ' }
            }

            Log.i(TAG,"getRenewalTime:period:${period}")
            Log.i(TAG,"getRenewalTime:prefix:${prefix}")
            Log.i(TAG,"getRenewalTime:num:${num}")

            if (prefix.equals("Day", ignoreCase = true)) {
                cal.add(Calendar.DAY_OF_MONTH, num)
            } else if (prefix.equals("Week", ignoreCase = true)) {
                cal.add(Calendar.WEEK_OF_MONTH, num)
            } else if (prefix.equals("Month", ignoreCase = true)) {
                cal.add(Calendar.MONTH, num)
            } else if (prefix.equals("Year", ignoreCase = true)) {
                cal.add(Calendar.YEAR, num)
            }
        }
        return cal.timeInMillis
    }

    /**
     * To Initialize Lifetime(One time) Purchase Product
     *
     * @param context The context to use. Usually your {@link android.app.Application}
     *                 or {@link android.app.Activity} object.
     * @param onInitializationComplete The callback that will return
     *
     */
    fun initProductsKeys(context: Context, onInitializationComplete: () -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            initProducts(
                context = context,
                onComplete = {
                    CoroutineScope(Dispatchers.Main).launch {
                        onInitializationComplete.invoke()
                    }
                }
            )
        }
    }

    /**
     * To Initialize Subscription Product
     *
     * @param context The context to use. Usually your {@link android.app.Application}
     *                 or {@link android.app.Activity} object.
     * @param onInitializationComplete The callback that will return
     *
     */
    fun initSubscriptionKeys(context: Context, onInitializationComplete: () -> Unit) {
        CoroutineScope(Dispatchers.Main).launch {
            initSubscription(
                context = context,
                onComplete = {
                    CoroutineScope(Dispatchers.Main).launch {
                        onInitializationComplete.invoke()
                    }
                }
            )
        }
    }

    private suspend fun initProducts(context: Context, onComplete: () -> Unit) {
        if (lifeTimeProductKeyList.isNotEmpty()) {
            val params = QueryProductDetailsParams.newBuilder()
                .setProductList(
                    lifeTimeProductKeyList.map { productId ->
                        QueryProductDetailsParams.Product.newBuilder()
                            .setProductId(productId)
                            .setProductType(BillingClient.ProductType.INAPP)
                            .build()
                    }
                )
                .build()

            initProductParams(
                context = context,
                methodName = "initProducts",
                params = params,
                productType = BillingClient.ProductType.INAPP,
                onComplete = onComplete
            )
        } else {
            onComplete.invoke()
        }
    }

    private suspend fun initSubscription(context: Context, onComplete: () -> Unit) {
        if (subscriptionKeyList.isNotEmpty()) {
            val historyParams = QueryPurchaseHistoryParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build()

            if (mBillingClient != null && mBillingClient?.isReady == true) {
                mBillingClient?.let { billingClient ->
                    val purchasesHistoryResult = billingClient.queryPurchaseHistory(historyParams)
                    if (purchasesHistoryResult.billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        purchasesHistoryResult.purchaseHistoryRecordList?.let { listOfHistoryProducts ->
                            val idList = listOfHistoryProducts.flatMap { it.products } as ArrayList<String>
                            initSubscription(context = context, historyList = idList, onComplete = onComplete)
                        } ?: initSubscription(context = context, historyList = ArrayList(), onComplete = onComplete)
                    } else {
                        initSubscription(context = context, historyList = ArrayList(), onComplete = onComplete)
                    }
                }
            } else {
                Log.e(TAG, "initSubscription: =>> The billing client is not ready")
                onComplete.invoke()
            }
        } else {
            onComplete.invoke()
        }
    }

    private suspend fun initSubscription(context: Context, historyList: ArrayList<String>, onComplete: () -> Unit) {
        if (subscriptionKeyList.isNotEmpty()) {
            val params = QueryProductDetailsParams.newBuilder()
                .setProductList(
                    subscriptionKeyList.map { productId ->
                        QueryProductDetailsParams.Product.newBuilder()
                            .setProductId(productId)
                            .setProductType(BillingClient.ProductType.SUBS)
                            .build()
                    }
                )
                .build()

            initProductParams(
                context = context,
                methodName = "initSubscription",
                params = params,
                productType = BillingClient.ProductType.SUBS,
                historyList = historyList,
                onComplete = onComplete
            )
        } else {
            onComplete.invoke()
        }
    }

    private suspend fun initProductParams(
        context: Context,
        methodName: String,
        @NotNull params: QueryProductDetailsParams,
        @NonNull productType: String,
        historyList: ArrayList<String> = ArrayList(),
        onComplete: () -> Unit
    ) {
        if (mBillingClient != null && mBillingClient?.isReady == true) {
            mBillingClient?.let { billingClient ->
                val productDetails = billingClient.queryProductDetails(params = params)

                if (productDetails.billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    productDetails.productDetailsList?.let { listOfProducts ->
                        for (productDetail in listOfProducts) {
                            val productID = productDetail.productId

                            val formattedPrice = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    productDetail.oneTimePurchaseOfferDetails?.formattedPrice ?: "Not Found"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList = productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter { !it.formattedPrice.equals("Free", ignoreCase = true) }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.formattedPrice ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

                            val priceAmountMicros = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    productDetail.oneTimePurchaseOfferDetails?.priceAmountMicros ?: 0
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList = productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter { !it.formattedPrice.equals("Free", ignoreCase = true) }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.priceAmountMicros ?: 0
                                    } else {
                                        0
                                    }
                                }
                                else -> {
                                    0
                                }
                            }

                            val priceCurrencyCode = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    productDetail.oneTimePurchaseOfferDetails?.priceCurrencyCode ?: "Not Found"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList = productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter { !it.formattedPrice.equals("Free", ignoreCase = true) }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.priceCurrencyCode ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

                            val billingPeriod = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    "One Time Purchase"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val pricingList = productDetail.subscriptionOfferDetails?.get(0)?.pricingPhases?.pricingPhaseList?.filter { !it.formattedPrice.equals("Free", ignoreCase = true) }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.billingPeriod?.getFullBillingPeriod() ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

                            val freeTrialPeriod = when (productType) {
                                BillingClient.ProductType.INAPP -> {
                                    "Not Found"
                                }
                                BillingClient.ProductType.SUBS -> {
                                    val index = if (historyList.contains(productID)) {
                                        (productDetail.subscriptionOfferDetails?.size ?: 1) - 1
                                    } else {
                                        0
                                    }
                                    val pricingList = productDetail.subscriptionOfferDetails?.get(index)?.pricingPhases?.pricingPhaseList?.filter { it.formattedPrice.equals("Free", ignoreCase = true) }
                                    if (pricingList?.isNotEmpty() == true) {
                                        pricingList[0]?.billingPeriod?.getFullBillingPeriod() ?: "Not Found"
                                    } else {
                                        "Not Found"
                                    }
                                }
                                else -> {
                                    "Not Found"
                                }
                            }

                            Log.i(TAG,"initProductParams: =>> ++++++++++++++++++++++++++++++++++")
                            Log.i(TAG,"initProductParams: =>> productID -> $productID")
                            Log.i(TAG,"initProductParams: =>> formattedPrice -> $formattedPrice")
                            Log.i(TAG,"initProductParams: =>> priceAmountMicros -> $priceAmountMicros")
                            Log.i(TAG,"initProductParams: =>> priceCurrencyCode -> $priceCurrencyCode")
                            Log.i(TAG,"initProductParams: =>> billingPeriod -> $billingPeriod")
                            Log.i(TAG,"initProductParams: =>> freeTrialPeriod -> $freeTrialPeriod")
                            Log.i(TAG,"initProductParams: =>> productDetail -> $productDetail")
                            PRODUCT_LIST.add(
                                ProductInfo(
                                    id = productID,
                                    formattedPrice = formattedPrice,
                                    priceAmountMicros = priceAmountMicros,
                                    priceCurrencyCode = priceCurrencyCode,
                                    billingPeriod = billingPeriod,
                                    freeTrialPeriod = freeTrialPeriod,
                                    renewalTime = 0,
                                    productDetail = productDetail
                                )
                            )

                            logProductDetail(fMethodName = methodName, fProductDetail = productDetail)
                        }
                    }
                } else {
                    logResponseCode(responseMsg = "$methodName: ", billingResult = productDetails.billingResult)
                }

                billingClient.queryPurchasesAsync(
                    QueryPurchasesParams.newBuilder()
                        .setProductType(productType)
                        .build()
                ) { billingResult, purchaseList ->
                    when (billingResult.responseCode) {
                        BillingClient.BillingResponseCode.OK,
                        BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
                            if (purchaseList.isNotEmpty()) {
                                AdsManager(context).onProductSubscribed()
                                onPurchased(context, productType, purchaseList)
                            } else {
                                AdsManager(context).onSubscribeExpired()
                                onExpired(context, productType)
                                Log.i(TAG,"$methodName: =>> Purchases History Not Found")
                            }
                        }
                        else -> {
                            onExpired(context, productType)
                            logResponseCode(responseMsg = "$methodName: ", billingResult = billingResult)
                        }
                    }
                    onComplete.invoke()
                }
            }
        } else {
            Log.e(TAG,"$methodName: =>> The billing client is not ready")
            onComplete.invoke()
        }
    }

    private fun onPurchased(context: Context, @NonNull productType: String, purchaseList: MutableList<Purchase>?) {
        Log.e(TAG,"onPurchased: Purchase Success")
        for (purchase in purchaseList!!) {
            Log.i(TAG,"getPackageName: =>> " + purchase.packageName)
            Log.i(TAG,"getPurchaseToken: =>> " + purchase.purchaseToken)
            Log.i(TAG,"getOriginalJson: =>> " + purchase.originalJson)
            Log.i(TAG,"getPurchaseTime: =>> " + purchase.purchaseTime)
            //val purchaseDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(purchase.purchaseTime)
            //PreferenceManager.saveData(context, "purchase_date", purchaseDate)
            //Log.i(TAG,"getPurchaseDate: =>> $purchaseDate")
            for (ids in purchase.products) {
                Log.i(TAG,"ids: =>> $ids")
                val renewalTime = getRenewalTime(purchase.purchaseTime, getProductInfo(ids)!!.billingPeriod.trim())
                setRenewalDate(ids, renewalTime)
                //val renewalDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(renewalTime)
                //Log.i(TAG,"renewalDate: =>> $renewalDate")
            }
        }
        if (productType == BillingClient.ProductType.INAPP) {
            mPurchaseListener?.onPurchasedFound(productType, purchaseList)
        } else if (productType == BillingClient.ProductType.SUBS) {
            mPurchaseListener?.onPurchasedFound(productType, purchaseList)
        }
    }

    private fun onExpired(context: Context, @NonNull productType: String) {
        Log.e(TAG,"onExpired: Purchase Expired")
        AdsManager(context).onSubscribeExpired()
        if (productType == BillingClient.ProductType.INAPP) {
            mPurchaseListener?.onPurchasedExpired(productType)
        } else if (productType == BillingClient.ProductType.SUBS) {
            mPurchaseListener?.onPurchasedExpired(productType)
        }
    }

    private fun handlePurchase(context: Context, purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            AdsManager(context).onProductSubscribed()
            for (product in purchase.products) {
                if (lifeTimeProductKeyList.contains(product)) {
                    Log.i(TAG, "handlePurchase: =>> productId -> $product")
                } else if (subscriptionKeyList.contains(product)) {
                    Log.i(TAG, "handlePurchase: =>> productId -> $product")
                }
            }
            mPurchaseListener?.onPurchasedSuccess(purchase = purchase)
        }

        CoroutineScope(Dispatchers.IO).launch {
            acknowledgePurchase(purchase = purchase)
            if (isConsumable) {
                consumePurchase(purchase = purchase)
            }
        }
    }

    private suspend fun acknowledgePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED && !purchase.isAcknowledged) {
            val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.purchaseToken)

            val ackPurchaseResult = withContext(Dispatchers.IO) {
                mBillingClient?.acknowledgePurchase(acknowledgePurchaseParams.build())
            }

            if (ackPurchaseResult != null) {
                logResponseCode("acknowledgePurchase: ", ackPurchaseResult)
            } else {
                Log.e(TAG,"acknowledgePurchase: =>> Not Found Any Purchase Result")
            }
        }

        logPurchaseItem(purchase = purchase)
    }

    private suspend fun consumePurchase(purchase: Purchase) {
        val consumeParams = ConsumeParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
        mBillingClient?.let {
            val consumeResult = it.consumePurchase(consumeParams)
            logResponseCode("consumePurchase: ", consumeResult.billingResult)
        }
    }

    /**
     * To Purchase Product (lifetime/one time purchase)
     *
     * @param activity The context to use. Usually your {@link android.app.Application}
     *                 or {@link android.app.Activity} object.
     * @param productId the product key to purchase
     * @param fIsConsumable Is Consumable or not
     *
     */
    fun purchaseProduct(activity: Activity, @NotNull productId: String, fIsConsumable: Boolean = false) {
        isConsumable = fIsConsumable
        CoroutineScope(Dispatchers.Main).launch {
            purchaseSelectedProduct(methodName = "purchaseProduct", activity = activity, productId = productId, productKeyList = lifeTimeProductKeyList, productType = BillingClient.ProductType.INAPP)
        }
    }

    /**
     * To Subscription Product
     *
     * @param activity The context to use. Usually your {@link android.app.Application}
     *                 or {@link android.app.Activity} object.
     * @param productId the product key to purchase
     * @param fIsConsumable Is Consumable or not
     *
     */
    fun subscribeProduct(activity: Activity, @NotNull productId: String, fIsConsumable: Boolean = false) {
        isConsumable = fIsConsumable
        CoroutineScope(Dispatchers.Main).launch {
            purchaseSelectedProduct(methodName = "subscribeProduct", activity = activity, productId = productId, productKeyList = subscriptionKeyList, productType = BillingClient.ProductType.SUBS)
        }
    }

    private suspend fun purchaseSelectedProduct(methodName: String, activity: Activity, @NotNull productId: String, @NotNull productKeyList: ArrayList<String>, @NonNull productType: String) {
        if (mBillingClient != null && mBillingClient?.isReady == true) {
            mBillingClient?.let { billingClient ->
                val params = QueryProductDetailsParams.newBuilder()
                    .setProductList(
                        productKeyList.map { keyId ->
                            QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(keyId)
                                .setProductType(productType)
                                .build()
                        }
                    )
                    .build()

                val productDetailsResult = withContext(Dispatchers.IO) {
                    billingClient.queryProductDetails(params)
                }

                val productDetail = getProductDetails(productId = productId, productDetailsList = productDetailsResult.productDetailsList)

                if (productDetail != null) {

                    val offerToken = if (productType == BillingClient.ProductType.SUBS) {
                        productDetail.subscriptionOfferDetails?.get(0)?.offerToken
                    } else {
                        null
                    }

                    if (offerToken == null && productType == BillingClient.ProductType.SUBS) {
                        return
                    }

                    val lBuilder: BillingFlowParams.ProductDetailsParams.Builder = BillingFlowParams.ProductDetailsParams.newBuilder()
                    lBuilder.apply {
                        setProductDetails(productDetail)
                        offerToken?.let {
                            setOfferToken(it)
                        }
                    }

                    val billingFlowParams = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(mutableListOf(lBuilder.build()))
                        .build()

                    val billingResult = billingClient.launchBillingFlow(activity, billingFlowParams)

                    when (billingResult.responseCode) {
                        BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
                            Log.e(TAG,"$methodName: =>> ITEM_ALREADY_OWNED")

                            AdsManager(activity).onProductSubscribed()
                            onPurchased(context = activity, productType = productType, null)
                            mPurchaseListener?.onPurchasedFound(productType, null)
                            logProductDetail(fMethodName = methodName, fProductDetail = productDetail)
                        }
                        BillingClient.BillingResponseCode.OK -> {
                            Log.e(TAG,"$methodName: =>> Purchase in Progress")
                        }
                        else -> {
                            logResponseCode(methodName, billingResult)
                        }
                    }

                } else {
                    CoroutineScope(Dispatchers.Main).launch {
                        mPurchaseListener?.onBillingKeyNotFound(productId)
                    }
                    Log.e(TAG,"$methodName: =>> Product Detail not found for product id:: $productId")
                }
            }
        } else {
            CoroutineScope(Dispatchers.Main).launch {
                Toast.makeText(activity, "The Billing Client Is Not Ready", Toast.LENGTH_SHORT).show()
            }
            Log.e(TAG,"$methodName: =>> The billing client is not ready")
        }
    }

    private fun getProductDetails(
        @NotNull productId: String,
        productDetailsList: List<ProductDetails>?
    ): ProductDetails? {
        return productDetailsList?.find { it.productId.equals(productId, true) }
    }

    private fun String.getFullBillingPeriod(): String {
        var billingPeriod = ""
        try {
            val size = this.length
            var period = this.substring(1, size - 1)
            //if (period.equals("1", true)) period = ""
            billingPeriod = when (this.substring(size - 1, size)) {
                "D", "d" -> "$period Day"
                "W", "w" -> "$period Week"
                "M", "m" -> "$period Month"
                "Y", "y" -> "$period Year"
                else -> "Not Found"
            }
            if (period.isNotEmpty() && period != "Not Found") billingPeriod = "${billingPeriod}s"
        } catch (e: Exception) {
            billingPeriod = "Not Found"
        }
        return billingPeriod.trim()
    }

    fun getWeekBaseYearlyDiscount(
        weekPrice: String,
        yearPrice: String,
        onDiscountCalculated: (yearlyDiscountPercentage: Double, yearlyWeekBaseDiscountPrice: String) -> Unit
    ) {
        weekPrice.getPriceInDouble.let { lWeekNumber ->
            yearPrice.getPriceInDouble.let { lYearNumber ->
                val lWeekPrize: Double = (lWeekNumber * 52) - lYearNumber
                val lYearPrizeBaseOfWeek = (lWeekNumber * 52)
                var lDiscountPercentage: Double = (lWeekPrize / lYearPrizeBaseOfWeek) * 100

                lDiscountPercentage *= 100
                lDiscountPercentage = lDiscountPercentage.toInt().toDouble()
                lDiscountPercentage /= 100

                val lDiscountPrice = weekPrice.replace(
                    String.format("%.2f", lWeekNumber),
                    String.format("%.2f", (lYearNumber / 52)),
                    false
                )

                onDiscountCalculated.invoke(lDiscountPercentage, lDiscountPrice)
            }
        }
    }

    fun getWeekBaseMonthlyDiscount(
        weekPrice: String,
        monthPrice: String,
        onDiscountCalculated: (monthlyDiscountPercentage: Double, monthlyWeekBaseDiscountPrice: String) -> Unit
    ) {
        weekPrice.getPriceInDouble.let { lWeekNumber ->
            monthPrice.getPriceInDouble.let { lMonthNumber ->
                val lWeekPrize: Double = (lWeekNumber * 4) - lMonthNumber
                val lMonthPrizeBaseOfWeek = (lWeekNumber * 4)
                var lDiscountPercentage: Double = (lWeekPrize / lMonthPrizeBaseOfWeek) * 100

                lDiscountPercentage *= 100
                lDiscountPercentage = lDiscountPercentage.toInt().toDouble()
                lDiscountPercentage /= 100

                val lDiscountPrice = weekPrice.replace(
                    String.format("%.2f", lWeekNumber),
                    String.format("%.2f", (lMonthNumber / 4)),
                    false
                )

                onDiscountCalculated.invoke(lDiscountPercentage, lDiscountPrice)
            }
        }
    }

    fun getMonthBaseYearlyDiscount(
        monthPrice: String,
        yearPrice: String,
        onDiscountCalculated: (yearlyDiscountPercentage: Double, yearlyMonthBaseDiscountPrice: String) -> Unit
    ) {
        monthPrice.getPriceInDouble.let { lMonthNumber ->
            yearPrice.getPriceInDouble.let { lYearNumber ->
                val lMonthPrize: Double = (lMonthNumber * 12) - lYearNumber
                val lYearPrizeBaseOfMonth = (lMonthNumber * 12)
                var lDiscountPercentage: Double = (lMonthPrize / lYearPrizeBaseOfMonth) * 100

                lDiscountPercentage *= 100
                lDiscountPercentage = lDiscountPercentage.toInt().toDouble()
                lDiscountPercentage /= 100

                val lDiscountPrice = monthPrice.replace(
                    String.format("%.2f", lMonthNumber),
                    String.format("%.2f", (lYearNumber / 12)),
                    false
                )

                onDiscountCalculated.invoke(lDiscountPercentage, lDiscountPrice)
            }
        }
    }


    internal fun logResponseCode(responseMsg: String, @NotNull billingResult: BillingResult) {
        val errorCode = when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.OK -> "RESULT OK"
            BillingClient.BillingResponseCode.ERROR -> "ERROR"
            BillingClient.BillingResponseCode.BILLING_UNAVAILABLE -> "BILLING_UNAVAILABLE"
            BillingClient.BillingResponseCode.DEVELOPER_ERROR -> "DEVELOPER_ERROR"
            BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED -> "FEATURE_NOT_SUPPORTED"
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> "ITEM_ALREADY_OWNED"
            BillingClient.BillingResponseCode.ITEM_NOT_OWNED -> "ITEM_NOT_OWNED"
            BillingClient.BillingResponseCode.ITEM_UNAVAILABLE -> "ITEM_UNAVAILABLE"
            BillingClient.BillingResponseCode.SERVICE_DISCONNECTED -> "SERVICE_DISCONNECTED"
            BillingClient.BillingResponseCode.SERVICE_TIMEOUT -> "SERVICE_TIMEOUT"
            BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE -> "SERVICE_UNAVAILABLE"
            BillingClient.BillingResponseCode.USER_CANCELED -> "USER_CANCELED"
            else -> "unDefined Error"
        }
        Log.e(TAG,"$responseMsg :: \nerrorCode::$errorCode,\nMessage::${billingResult.debugMessage}")
    }

    private fun logPurchaseItem(purchase: Purchase) {
        with(purchase) {
            Log.w(TAG,"<<<-----------------   Purchase Details   ----------------->>>")
            Log.w(TAG,"Order Id: $orderId")
            Log.w(TAG,"Original Json: $originalJson")
            Log.w(TAG,"Package Name: $packageName")
            Log.w(TAG,"Purchase Token: $purchaseToken")
            Log.w(TAG,"Signature: $signature")
            products.forEach {
                Log.w(TAG,"Products: $it")
                Log.w(TAG,"Price: ${getProductInfo(it)?.formattedPrice}")
            }
            Log.w(TAG,"Purchase State: ${purchaseState.getPurchaseState}")
            Log.w(TAG,"Quantity: $quantity")
            Log.w(TAG,"Purchase Time: $purchaseTime")
            Log.w(TAG,"Acknowledged: $isAcknowledged")
            Log.w(TAG,"AutoRenewing: $isAutoRenewing")
            Log.w(TAG,"<<<-----------------   End of Purchase Details   ----------------->>>")
        }
    }

    private fun logProductDetail(fMethodName: String, @NotNull fProductDetail: ProductDetails) {
        with(fProductDetail) {
            Log.w(TAG,"\n")
            Log.w(TAG,"$fMethodName: <<<-----------------   \"$productId\" Product Details   ----------------->>>")
            Log.w(TAG,"$fMethodName: Product Id:: $productId")
            Log.w(TAG,"$fMethodName: Name:: $name")
            Log.w(TAG,"$fMethodName: Title:: $title")
            Log.w(TAG,"$fMethodName: Description:: $description")
            Log.w(TAG,"$fMethodName: Product Type:: $productType")
            oneTimePurchaseOfferDetails?.let { details ->
                with(details) {
                    Log.w(TAG,"\n")
                    Log.w(TAG,"$fMethodName: <<<-----------------   Life-Time Purchase Product Price Details   ----------------->>>")
                    Log.w(TAG,"$fMethodName: Price Amount Micros:: $priceAmountMicros")
                    Log.w(TAG,"$fMethodName: Formatted Price:: $formattedPrice")
                    Log.w(TAG,"$fMethodName: Price Currency Code:: $priceCurrencyCode")
                    Log.w(TAG,"$fMethodName: <<<-----------------   End of Life-Time Purchase Product Price Details   ----------------->>>")
                }
            }
            subscriptionOfferDetails?.let { details ->
                if (details.isNotEmpty()) {
                    details.forEachIndexed { index, subscriptionOfferDetails ->
                        subscriptionOfferDetails?.let { offerDetails ->
                            with(offerDetails) {
                                Log.w(TAG,"$fMethodName: <<<-----------------   Product Offer Details of Index:: $index   ----------------->>>")
                                Log.w(TAG,"$fMethodName: Offer Token:: $offerToken")
                                Log.w(TAG,"$fMethodName: Offer Tags:: $offerTags")
                                Log.w(TAG,"$fMethodName: Installment Plan Details:: $installmentPlanDetails")

                                if (pricingPhases.pricingPhaseList.isNotEmpty()) {
                                    pricingPhases.pricingPhaseList.forEachIndexed { index, pricingPhase1 ->
                                        pricingPhase1?.let { pricingPhase ->
                                            with(pricingPhase) {
                                                Log.w(TAG,"$fMethodName: <<<-----------------   Product Offer Price Details of Index:: $index   ----------------->>>")
                                                Log.w(TAG,"$fMethodName: Billing Period:: $billingPeriod")
                                                Log.w(TAG,"$fMethodName: Formatted Price:: $formattedPrice")
                                                Log.w(TAG,"$fMethodName: Price Amount Micros:: $priceAmountMicros")
                                                Log.w(TAG,"$fMethodName: Price Currency Code:: $priceCurrencyCode")
                                                Log.w(TAG,"$fMethodName: Recurrence Mode:: $recurrenceMode")
                                                Log.w(TAG,"$fMethodName: Billing Cycle Count:: $billingCycleCount")
                                                Log.w(TAG,"$fMethodName: <<<-----------------   End of Product Offer Price Details of Index:: $index   ----------------->>>")
                                            }
                                        }
                                    }
                                }

                                Log.w(TAG,"$fMethodName: <<<-----------------   End of Product Offer Details of Index:: $index   ----------------->>>")
                            }
                        }
                    }
                }
            }
            Log.w(TAG,"$fMethodName: <<<-----------------   End of \"$productId\" Product Details   ----------------->>>")
        }
    }

    /**
     * Interface definition for a callback to be invoked when billing client initialize
     */
    interface ProductPurchaseListener {
        /**
         * Indicates Purchase no longer available
         */
        fun onPurchasedExpired(productType: String)
        /**
         * Indicates Purchase Successfully completed
         */
        fun onPurchasedSuccess(purchase: Purchase)
        /**
         * Indicates Already Purchased
         */
        fun onPurchasedFound(productType: String, purchaseList: MutableList<Purchase>?)

        /**
         * Billing client initialization finish, now you have to call initProductsKeys(), initSubscriptionKeys()
         */
        fun onBillingSetupFinished(billingResult: BillingResult)

        /**
         * Product key you have used is not found on play console
         */
        fun onBillingKeyNotFound(productId: String)
    }
}