package com.gallery.photo.image.video.fragment

import android.app.ProgressDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.View.GONE
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.RecyclerView
import com.example.jdrodi.utilities.hideKeyboard
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.AddImageInNewFolderNewActivity
import com.gallery.photo.image.video.activity.MainActivity
import com.gallery.photo.image.video.activity.MediaActivity
import com.gallery.photo.image.video.adapter.DirectoryAdapter
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.dialog.CreateNewFolderDialog
import com.gallery.photo.image.video.dialog.FilePickerDialog
import com.gallery.photo.image.video.extensions.*
import com.gallery.photo.image.video.interfaces.DirectoryOperationsListener
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.views.MyGridLayoutManager
import com.gallery.photo.image.video.views.MyRecyclerView
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.helpers.*
import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.models.Directory
import com.gallery.photo.image.video.models.ThumbnailItem
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.fragment_video_directory.directories_empty_placeholder
import kotlinx.android.synthetic.main.fragment_video_directory.directories_empty_placeholder_2
import kotlinx.android.synthetic.main.fragment_video_directory.directories_grid
import kotlinx.android.synthetic.main.fragment_video_directory.directories_refresh_layout
import kotlinx.android.synthetic.main.fragment_video_directory.directories_vertical_fastscroller
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class VideoDirectoryFragment : BaseFragment(), DirectoryOperationsListener {

    private val PICK_MEDIA = 2
    private val PICK_WALLPAPER = 3
    private val LAST_MEDIA_CHECK_PERIOD = 3000L

    private var mIsPickImageIntent = false
    private var mIsPickVideoIntent = false
    private var mIsGetImageContentIntent = false
    private var mIsGetVideoContentIntent = true
    private var mIsGetAnyContentIntent = false
    private var mIsSetWallpaperIntent = false
    private var mAllowPickingMultiple = false
    private var mIsGettingDirs = false
    private var mLoadedInitialPhotos = false
    private var mShouldStopFetching = false
    private var mIsSearchOpen = false
    private var mLatestMediaId = 0L
    private var mLatestMediaDateId = 0L
    private var mCurrentPathPrefix = ""                 // used at "Group direct subfolders" for navigation
    private var mOpenedSubfolders = arrayListOf("")     // used at "Group direct subfolders" for navigating Up with the back button
    private var mDateFormat = ""
    private var mTimeFormat = ""
    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mLastMediaFetcher: MediaFetcher? = null
    var mDirs = ArrayList<Directory>()

    private var isCreateNewFolderDialogClicked = false
    var mProgressDailog: ProgressDialog? = null
    override var mLastClickTime: Long = 0
    override var mMinDuration = 1500

    private var refreshMediaBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("554654", "onReceive: --> Media Refresh intent" + intent!!.action)
            if (intent!!.action == videoRefreshActionName) {
                Log.d("554654", "onReceive: --> Media Refresh receiver")
                if (isAdded)
                    if (requireActivity().window.decorView.isShown) {
                        requireActivity().runOnUiThread {
                            getDirectories()
                        }
                    }
            }
        }

    }

    companion object {
        var isColumnCountChange = false
        var isSortingChange = false
        var isNeedToRefresh = false
        var mMedia = ArrayList<ThumbnailItem>()
        var isFirstTime = true
        fun getInstance(position: Int): Fragment {
            val f: VideoDirectoryFragment = VideoDirectoryFragment()
            val args: Bundle = Bundle()
            args.putInt("position", position)
            f.arguments = args
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireContext().addEvent(javaClass.simpleName)
        LocalBroadcastManager.getInstance(requireContext()).registerReceiver(refreshMediaBroadcast, IntentFilter(videoRefreshActionName))
    }

    override fun onResume() {
        super.onResume()

        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).visibility = View.VISIBLE
        requireActivity().findViewById<TextView>(R.id.tvHeaderTitle).text = mContext.getString(R.string.title_my_video)
        requireActivity().findViewById<ImageView>(R.id.imgSearch).visibility = View.VISIBLE
        requireActivity().findViewById<View>(R.id.clGiftIcon).visibility = View.GONE
        requireActivity().findViewById<View>(R.id.adViewContainer).visibility = View.GONE
        requireActivity().findViewById<FloatingActionButton>(R.id.imgAddHiddenPhoto).visibility = GONE
        requireActivity().findViewById<LinearLayout>(R.id.layOpt).visibility = View.VISIBLE
        requireActivity().findViewById<EditText>(R.id.etSearch).hint = getString(R.string.msg_search_video_by_name)
        requireActivity().findViewById<ImageView>(R.id.imgSearch).setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.ic_gallery_search))
        if (isColumnCountChange && requireContext().config.viewTypeFolders == VIEW_TYPE_GRID) {
            isColumnCountChange = false
            setupLayoutManager()
            columnCountChanged()
        }
        if (isSortingChange) {
            isSortingChange = false
            getDirectories()
        }
        if (MainActivity.isNeedToRefresh || isNeedToRefresh) {
            MainActivity.isNeedToRefresh = false
            isNeedToRefresh = false
            getDirectories()
        }

    }

    override fun getLayoutRes(): Int? {
        return R.layout.fragment_video_directory
    }

    override fun initView() {
        directories_refresh_layout.setOnRefreshListener {
            if (requireActivity().findViewById<ImageView>(R.id.imgClose) != null)
                requireActivity().findViewById<ImageView>(R.id.imgClose).performClick()
            getDirectories()
        }
        directories_grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                when (newState) {

                    RecyclerView.SCROLL_STATE_DRAGGING -> {
                        if (requireActivity().findViewById<EditText>(R.id.etSearch).visibility == View.VISIBLE) {
                            requireActivity().hideKeyboard(requireActivity().findViewById<EditText>(R.id.etSearch))
                            requireActivity().findViewById<EditText>(R.id.etSearch).clearFocus()
                        }
                    }
                }
            }
        })
        getDirectories()
    }

    private fun getDirectories() {
        if (isAdded) {
            if (mIsGettingDirs) {
                return
            }
            mShouldStopFetching = true
            mIsGettingDirs = true
            setupLatestMediaId()
            if (isAdded) {
                requireContext().getCachedVideoDirectories {
                    gotDirectories(it.filter { it.mediaCnt != 0 } as ArrayList<Directory>)
                }
            }
        }
    }


    private fun setupLatestMediaId() {
        ensureBackgroundThread {
            if (requireContext().hasPermission(PERMISSION_READ_STORAGE)) {
                mLatestMediaId = requireContext().getLatestMediaId()
                mLatestMediaDateId = requireContext().getLatestMediaByDateId()
            }
        }
    }

    private fun gotDirectories(newDirs: ArrayList<Directory>) {
        if (isAdded) {
            mIsGettingDirs = false
            mShouldStopFetching = false
            setupLayoutManager()
            // if hidden item showing is disabled but all Favorite items are hidden, hide the Favorites folder
            if (!mContext.config.shouldShowHidden) {
                val favoritesFolder = newDirs.firstOrNull { it.areFavorites() }
                if (favoritesFolder != null && favoritesFolder.tmb.getFilenameFromPath().startsWith('.')) {
                    newDirs.remove(favoritesFolder)
                }
            }

            val dirs = mContext.getSortedDirectories(newDirs)
            if (mContext.config.groupDirectSubfolders) {
                mDirs = dirs.clone() as ArrayList<Directory>
            }

            (mContext as AppCompatActivity).runOnUiThread {
                if (directories_refresh_layout != null) {
                    directories_refresh_layout.isEnabled = true
                    directories_refresh_layout.isRefreshing = false
                }
                setupAdapter(dirs.clone() as ArrayList<Directory>)
            }
            try {
                ensureBackgroundThread {
                    newDirs.forEach {
                        mContext.directoryDao.insert(it)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            // cached folders have been loaded, recheck folders one by one starting with the first displayed
            mLastMediaFetcher?.shouldStop = true
            mLastMediaFetcher = MediaFetcher(mContext)

            mLoadedInitialPhotos = true

            if (isAdded) {
                requireActivity().runOnUiThread {
                    if (directories_refresh_layout != null)
                        directories_refresh_layout.isRefreshing = false
                    checkPlaceholderVisibility(dirs)
                }
            }

            mDirs = dirs.clone() as ArrayList<Directory>
            Thread {
                if (isAdded) {
                    requireActivity().runOnUiThread {

                        if (directories_grid != null && getRecyclerAdapter() != null)
                            getRecyclerAdapter()!!.dismissProgress()
                    }
                }
            }.start()
        }
    }

    fun setupAdapter(dirs: ArrayList<Directory>, textToSearch: String = "", forceRecreate: Boolean = false) {
        if (isAdded) {
            requireActivity().runOnUiThread {
                if (directories_grid != null) {
                    mDirs = dirs
                    val currAdapter = directories_grid.adapter
                    var distinctDirs = dirs
                    try {
                        distinctDirs = dirs.distinctBy { it.path.getDistinctPath() }.toMutableList() as ArrayList<Directory>
                    } catch (e: java.lang.Exception) {
                        distinctDirs = dirs
                    }
                    val sortedDirs = mContext.getSortedDirectories(distinctDirs)
                    var dirsToShow = mContext.getDirsToShow(sortedDirs, mDirs, mCurrentPathPrefix).clone() as ArrayList<Directory>
                    dirsToShow.sortWith { o1, o2 ->
                        o1 as Directory
                        o2 as Directory
                        var result = when {
                            mContext.config.directorySorting and SORT_BY_NAME != 0 -> {
                                o1.name.lowercase(Locale.getDefault()).compareTo(o2.name.lowercase(Locale.getDefault()))
                            }
                            mContext.config.directorySorting and SORT_BY_DATE_MODIFIED != 0 -> (o1.modified).compareTo(o2.modified)
                            mContext.config.directorySorting and SORT_BY_SIZE != 0 -> o1.mediaCnt.compareTo(o2.mediaCnt)
                            else -> o1.actualFolderCount.compareTo(o2.actualFolderCount)
                        }


                        if (mContext.config.directorySorting and SORT_DESCENDING != 0) {
                            result *= -1
                        }
                        result
                    }
//                    if (dirsToShow.size > 0) {
//                        dirsToShow.add(
//                            0,
//                            Directory(
//                                101,
//                                getString(R.string.label_add_album),
//                                getString(R.string.label_add_album),
//                                getString(R.string.label_add_album),
//                                mediaCnt = 4,
//                                modified = 1623827461000,
//                                taken = 1623827461000,
//                                size = 0,
//                                location = 1,
//                                types = 1,
//                                "0",
//                                subfoldersCount = 0,
//                                subfoldersMediaCount = 4,
//                                containsMediaFilesDirectly = true
//                            )
//                        )
//                    }

                    if (currAdapter == null || forceRecreate) {
//            initZoomListener()
                        val fastscroller = directories_vertical_fastscroller
                        DirectoryAdapter(
                            mContext as BaseSimpleActivity,
                            dirsToShow,
                            this,
                            directories_grid,
                            isPickIntent(requireActivity().intent) || isGetAnyContentIntent(requireActivity().intent),
                            false,
                            directories_refresh_layout,
                            fastscroller
                        ) {
                            val clickedDir = it as Directory
                            val path = clickedDir.path
                            if (clickedDir.subfoldersCount == 1 || !mContext.config.groupDirectSubfolders) {
//                                if (path != mContext.config.tempFolderPath) {
                                itemClicked(path)
//                                }
                            } else {
                                mCurrentPathPrefix = path
                                mOpenedSubfolders.add(path)
                                setupAdapter(mDirs, "")
                            }
                        }.apply {
//                setupZoomListener(mZoomListener)
                            requireActivity().runOnUiThread {
                                directories_grid.adapter = this
                                setupScrollDirection()

                                if (mContext.config.viewTypeFolders == VIEW_TYPE_LIST) {
                                    directories_grid.scheduleLayoutAnimation()
                                }
                            }
                        }
                    } else {
                        requireActivity().runOnUiThread {
                            if (textToSearch.isNotEmpty()) {
                                dirsToShow = dirsToShow.filter { !it.path.contains("Add Album") && it.name.contains(textToSearch, true) }.sortedBy { !it.name.startsWith(textToSearch, true) }
                                    .toMutableList() as ArrayList
                            }
                            checkPlaceholderVisibility(dirsToShow)

                            (directories_grid.adapter as? DirectoryAdapter)?.updateDirs(dirsToShow)
                        }
                    }

                }
            }
        }
    }

    fun itemClicked(path: String) {
        if (requireActivity().findViewById<EditText>(R.id.etSearch).visibility == View.VISIBLE) {
            if (requireActivity().findViewById<ImageView>(R.id.imgClose) != null)
                requireActivity().findViewById<ImageView>(R.id.imgClose).performClick()
        }
        if (path == getString(R.string.label_add_album)) {
            if (!isCreateNewFolderDialogClicked) {
                isCreateNewFolderDialogClicked = true
                createNewFolder()
            }
        } else {
            if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
                return
            }
            mLastClickTime = SystemClock.elapsedRealtime()
            if (mContext.config.isAnyOperationRunning && path == mContext.config.lastDestinationPath) {
                requireActivity().toast(mContext.getString(com.gallery.photo.image.video.R.string.msg_operation_already_running))
            } else {
                requireActivity().handleLockedFolderOpening(path) { success ->
                    if (success) {
                        Log.d("Tag", "clicked")
                        Intent(mContext, MediaActivity::class.java).apply {
                            putExtra(SKIP_AUTHENTICATION, true)
                            putExtra(DIRECTORY, path)
                            putExtra(SHOW_ONLY_HIDDEN, false)
                            putExtra(IS_VIDEO, true)
                            handleMediaIntent(this)
                        }
                    }
                }
            }

        }
    }


    private fun createNewFolder() {
        FilePickerDialog(requireActivity() as BaseSimpleActivity, mContext.internalStoragePath, false, mContext.config.shouldShowHidden, false, true) {
            if (it != "dismiss") {
                isCreateNewFolderDialogClicked = false
                CreateNewFolderDialog(requireActivity() as BaseSimpleActivity, it) {
                    if (it != "dismiss") {
                        if (!it.substringAfterLast("/").matches(Regex("^[^.]*\$"))) {
                            if (File(it).exists())
                                File(it).delete()
                            requireActivity().toast(getString(R.string.error_please_enter_valid_name))
                        } else {
                            mContext.config.tempFolderPath = it
                            hideKeyboard()
                            isCreateNewFolderDialogClicked = false
                            startActivity(
                                Intent(context, AddImageInNewFolderNewActivity::class.java)
                                    .putExtra("FileDir", it)
                                    .putExtra("ViewPager_Position", 1)
                                    .putExtra("Album Name", it.substringAfterLast("/"))
                            )
                        }
                    } else {
                        isCreateNewFolderDialogClicked = false
                    }
                }
            } else {
                isCreateNewFolderDialogClicked = false
            }
        }
    }


    private fun handleMediaIntent(intent: Intent) {
        intent.apply {
            if (mIsSetWallpaperIntent) {
                putExtra(SET_WALLPAPER_INTENT, true)
//                startActivityForResult(this, PICK_WALLPAPER)
                launchActivityForResult(this, PICK_WALLPAPER)
            } else {
                putExtra(GET_IMAGE_INTENT, mIsPickImageIntent || mIsGetImageContentIntent)
                putExtra(GET_VIDEO_INTENT, mIsPickVideoIntent || mIsGetVideoContentIntent)
                putExtra(GET_ANY_INTENT, mIsGetAnyContentIntent)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, mAllowPickingMultiple)
//                startActivityForResult(this, PICK_MEDIA)
                launchActivityForResult(this, PICK_MEDIA)
            }
        }
    }


    private fun initZoomListener() {
        if (mContext.config.viewTypeFolders == VIEW_TYPE_GRID) {
            val layoutManager = directories_grid.layoutManager as MyGridLayoutManager
            mZoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 1) {
                        reduceColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            mZoomListener = null
        }
    }


    fun getRecyclerAdapter() = directories_grid?.adapter as? DirectoryAdapter

    private fun setupScrollDirection() {
        val allowHorizontalScroll = mContext.config.scrollHorizontally && mContext.config.viewTypeFolders == VIEW_TYPE_GRID
        directories_vertical_fastscroller.isHorizontal = false
        directories_vertical_fastscroller.beGoneIf(allowHorizontalScroll)

    }

    private fun getBubbleTextItem(index: Int) = getRecyclerAdapter()?.dirs?.getOrNull(index)?.getBubbleText(mContext.config.directorySorting, mContext, mDateFormat, mTimeFormat)
        ?: ""

    private fun checkPlaceholderVisibility(dirs: ArrayList<Directory>) {
        if (directories_empty_placeholder != null)
            directories_empty_placeholder.beVisibleIf(dirs.isEmpty() && mLoadedInitialPhotos)
        if (directories_empty_placeholder_2 != null) {
            directories_empty_placeholder_2.beVisibleIf(dirs.isEmpty() && mLoadedInitialPhotos)
        }
        if (mIsSearchOpen) {
            if (directories_empty_placeholder != null)
                directories_empty_placeholder.text = getString(R.string.no_items_found)
            directories_empty_placeholder_2.beGone()
        } else if (dirs.isEmpty() && mContext.config.filterMedia == getDefaultFileFilter()) {
            if (directories_empty_placeholder != null)
                directories_empty_placeholder.text = getString(R.string.no_media_with_filters)
//            directories_empty_placeholder_2.text = getString(R.string.add_folder)

        } else {
            if (directories_empty_placeholder != null)
                directories_empty_placeholder.text = getString(R.string.no_media_with_filters)
//            directories_empty_placeholder_2.text = getString(R.string.change_filters_underlined)
        }
        if (directories_empty_placeholder_2 != null) {
            directories_empty_placeholder_2.underlineText()
            directories_empty_placeholder_2.beGone()
        }
        if (directories_empty_placeholder != null)
            directories_grid.beVisibleIf(directories_empty_placeholder.isGone())
        if (dirs.isEmpty()) {
            if (requireActivity() is MainActivity) {
                (requireActivity() as MainActivity).showToolbar()
            }
        }
    }


    fun setupLayoutManager() {
        if (isAdded) {
            requireActivity().runOnUiThread(Runnable {
                if (context != null) {
                    if (mContext.config.viewTypeFolders == VIEW_TYPE_GRID) {
                        setupGridLayoutManager()
                    } else {
                        setupListLayoutManager()
                    }
                }

            })
        }
    }

    private fun setupGridLayoutManager() {
        val layoutManager = directories_grid.layoutManager as MyGridLayoutManager
        if (mContext.config.scrollHorizontally) {
            layoutManager.orientation = RecyclerView.HORIZONTAL
        } else {
            layoutManager.orientation = RecyclerView.VERTICAL
        }

        layoutManager.spanCount = mContext.config.dirColumnCnt
    }

    private fun setupListLayoutManager() {
        if (isAdded) {
            val layoutManager = directories_grid.layoutManager as MyGridLayoutManager
            layoutManager.spanCount = 1
            layoutManager.orientation = RecyclerView.VERTICAL
            mZoomListener = null
        }
    }


    override fun refreshItems() {
        getDirectories()
    }

    override fun deleteFolders(folders: ArrayList<File>) {
        val fileDirItems = folders.asSequence().filter { it.isDirectory }.map { FileDirItem(it.absolutePath, it.name, true) }.toMutableList() as ArrayList<FileDirItem>
        when {
            fileDirItems.isEmpty() -> return
            fileDirItems.size == 1 -> {
                try {
                    requireActivity().toast(String.format(getString(R.string.deleting_folder), fileDirItems.first().name))
                } catch (e: Exception) {
                    requireActivity().showErrorToast(e)
                }
            }
            else -> {
                val baseString = if (mContext.config.useRecycleBin) R.plurals.moving_items_into_bin else R.plurals.delete_items
                val deletingItems = resources.getQuantityString(baseString, fileDirItems.size, fileDirItems.size)
                requireActivity().toast(deletingItems)
            }
        }

        val itemsToDelete = ArrayList<FileDirItem>()
        val filter = mContext.config.filterMedia
        val showHidden = mContext.config.shouldShowHidden
        fileDirItems.filter { it.isDirectory }.forEach {
            val files = File(it.path).listFiles()
            files?.filter {
                it.absolutePath.isMediaFile() && (showHidden || !it.name.startsWith('.')) &&
                        ((it.isImageFast() && filter and TYPE_IMAGES != 0) ||
                                (it.isVideoFast() && filter and TYPE_VIDEOS != 0) ||
                                (it.isGif() && filter and TYPE_GIFS != 0) ||
                                (it.isRawFast() && filter and TYPE_RAWS != 0) ||
                                (it.isSvg() && filter and TYPE_SVGS != 0))
            }?.mapTo(itemsToDelete) { it.toFileDirItem(mContext) }
        }

//        if (mContext.config.useRecycleBin) {
//            val pathsToDelete = ArrayList<String>()
//            itemsToDelete.mapTo(pathsToDelete) { it.path }
//
//
//        } else {
//            deleteFilteredFileDirItems(itemsToDelete, folders)
//        }

        val pathsToDelete = ArrayList<String>()
        itemsToDelete.mapTo(pathsToDelete) { it.path }
        Log.d("hfdfadsfdsf", "deleteFolders: " + itemsToDelete.size)
        if (getRecyclerAdapter() != null) {
            getRecyclerAdapter()!!.finishActMode()
            getRecyclerAdapter()!!.dismissProgress()
        }
        if (isAdded) {
            (mContext as BaseSimpleActivity).movePathsInRecoverTrash(pathsToDelete, false, VaultFragment.isFakeVaultOpen) {
                if (it) {
//                    deleteFilteredFileDirItems(itemsToDelete, folders)
                    val OTGPath = requireContext().config.OTGPath
                    ensureBackgroundThread {
                        folders.forEach {
                            Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")
                            requireActivity().updatePhotoVideoDirectoryPath(it.absolutePath, false, true)
                        }

                        folders.filter { !mContext.getDoesFilePathExist(it.absolutePath, OTGPath) }.forEach {
                            mContext.directoryDao.deleteDirPath(it.absolutePath)
                        }
                        requireActivity().runOnUiThread {
                            getRecyclerAdapter()!!.finishActMode()
                            getRecyclerAdapter()!!.dismissProgress()
                            refreshItems()
                        }

                        if (mContext.config.deleteEmptyFolders) {
                            folders.filter { !it.absolutePath.isDownloadsFolder() && it.isDirectory && it.toFileDirItem(mContext).getProperFileCount(mContext, true) == 0 }.forEach {
                                (requireActivity() as BaseSimpleActivity).tryDeleteFileDirItem(it.toFileDirItem(mContext), true, true)
                            }
                        }
                    }
                } else {
                    mContext.toast(R.string.unknown_error_occurred)
                }
            }
        }
    }

    private fun deleteFilteredFileDirItems(fileDirItems: ArrayList<FileDirItem>, folders: ArrayList<File>) {
        val OTGPath = mContext.config.OTGPath
        (requireActivity() as BaseSimpleActivity).deleteFiles(fileDirItems) {
            ensureBackgroundThread {
                folders.forEach {
                    Log.d("RefreshMedia1234", "updatePhotoVideoDirectoryPath: Called TYpe Video  ---> ")
                    requireActivity().updatePhotoVideoDirectoryPath(it.absolutePath, false, true)
                }

                folders.filter { !mContext.getDoesFilePathExist(it.absolutePath, OTGPath) }.forEach {
                    mContext.directoryDao.deleteDirPath(it.absolutePath)
                }
                requireActivity().runOnUiThread {
                    getRecyclerAdapter()!!.finishActMode()
                    getRecyclerAdapter()!!.dismissProgress()
                    refreshItems()
                }

                if (mContext.config.deleteEmptyFolders) {
                    folders.filter { !it.absolutePath.isDownloadsFolder() && it.isDirectory && it.toFileDirItem(mContext).getProperFileCount(mContext, true) == 0 }.forEach {
                        (requireActivity() as BaseSimpleActivity).tryDeleteFileDirItem(it.toFileDirItem(mContext), true, true)
                    }
                }
            }
        }
    }

    override fun recheckPinnedFolders() {

    }

    override fun updateDirectories(directories: ArrayList<Directory>) {
        ensureBackgroundThread {
            mContext.storeDirectoryItems(directories)
            mContext.removeInvalidDBDirectories()
        }
    }


    private fun increaseColumnCount() {
        mContext.config.dirColumnCnt = ++(directories_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun reduceColumnCount() {
        mContext.config.dirColumnCnt = --(directories_grid.layoutManager as MyGridLayoutManager).spanCount
        columnCountChanged()
    }

    private fun columnCountChanged() {
        getRecyclerAdapter()?.apply {
            notifyItemRangeChanged(0, dirs.size)
        }
    }


    private fun isPickIntent(intent: Intent) = intent.action == Intent.ACTION_PICK

    private fun isGetContentIntent(intent: Intent) = intent.action == Intent.ACTION_GET_CONTENT && intent.type != null

    private fun isGetAnyContentIntent(intent: Intent) = isGetContentIntent(intent) && intent.type == "*/*"

}