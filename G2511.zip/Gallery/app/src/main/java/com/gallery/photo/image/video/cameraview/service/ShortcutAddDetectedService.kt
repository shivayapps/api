package com.gallery.photo.image.video.cameraview.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.content.res.Configuration
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.cameraview.ui.CameraShortcutActivity
import com.gallery.photo.image.video.utilities.SharedPrefs
import com.gallery.photo.image.video.multilang.LocaleManager
import java.util.*

class ShortcutAddDetectedService : AccessibilityService() {

    override fun onCreate() {
//        val defaultLang = if (SharedPrefs.getString(this, SharedPrefs.PRF_KEY_LANGUAGE).isEmpty()) {
//            Resources.getSystem().configuration.locale.language
//        } else {
//            SharedPrefs.getString(this, SharedPrefs.PRF_KEY_LANGUAGE)
//        }
//        setLanguage(defaultLang)

        super.onCreate()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {

        if(event.packageName == packageName) {
            LocaleManager.setLocale(this)
            try {

                if (event.text != null) {
                    for (i in event.text) {
                        if (i != null && i.toString() == "Add automatically" || i.toString() == "Add" || i.toString() == "ADD" || i.toString() == "ADD AUTOMATICALLY") {
                            Toast.makeText(this, resources.getString(R.string.shortcut_created_successfully), Toast.LENGTH_SHORT).show()


                            SharedPrefs.save(this, "shortcut", "null")
                        }
                    }
                }
            } catch (e: Exception) {

            }
        }
    }

    private fun setLanguage(strLang: String) {

        val localeNew = Locale(strLang)
        Locale.setDefault(localeNew)

        val config = Configuration()
        config.locale = localeNew
        baseContext.resources.updateConfiguration(
            config,
            baseContext.resources.displayMetrics
        )
    }

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = AccessibilityServiceInfo()
        info.apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_VIEW_FOCUSED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_SPOKEN
            notificationTimeout = 100
        }
        this.serviceInfo = info
        if (SharedPrefs.getBoolean(this, "isOpen", false)) {
            SharedPrefs.savePref(this, "isOpen", false)
            startActivity(Intent(this, CameraShortcutActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

        }
    }

    companion object {
        private const val TAG = "ShortcutAddDetectedServ"
    }

}