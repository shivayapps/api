package com.gallery.photo.image.video.Camera.remotecontrol;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;

import com.gallery.photo.image.video.Camera.CameraActivity;
import com.gallery.photo.image.video.Camera.MyApplicationInterface;
import com.gallery.photo.image.video.Camera.PreferenceKeys;
import com.gallery.photo.image.video.Camera.ui.MainUI;

public class BluetoothRemoteControl {
    private static final String TAG = "BluetoothRemoteControl";
    /* access modifiers changed from: private */
    public BluetoothLeService bluetoothLeService;
    /* access modifiers changed from: private */
    public boolean is_connected;
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (Build.VERSION.SDK_INT >= 18) {
                BluetoothLeService unused = BluetoothRemoteControl.this.bluetoothLeService = ((BluetoothLeService.LocalBinder) iBinder).getService();
                if (!BluetoothRemoteControl.this.bluetoothLeService.initialize()) {
                    Log.e(BluetoothRemoteControl.TAG, "Unable to initialize Bluetooth");
                    BluetoothRemoteControl.this.stopRemoteControl();
                }
                BluetoothRemoteControl.this.bluetoothLeService.connect(BluetoothRemoteControl.this.remoteDeviceAddress);
            }
        }

        public void onServiceDisconnected(ComponentName componentName) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                public void run() {
                    if (Build.VERSION.SDK_INT >= 18) {
                        BluetoothRemoteControl.this.bluetoothLeService.connect(BluetoothRemoteControl.this.remoteDeviceAddress);
                    }
                }
            }, 5000);
        }
    };
    /* access modifiers changed from: private */
    public final CameraActivity main_activity;
    private final BroadcastReceiver remoteControlCommandReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            if (Build.VERSION.SDK_INT >= 18) {
                String action = intent.getAction();
                MyApplicationInterface applicationInterface = BluetoothRemoteControl.this.main_activity.getApplicationInterface();
                MainUI mainUI = BluetoothRemoteControl.this.main_activity.getMainUI();
                if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                    Log.d(BluetoothRemoteControl.TAG, "Remote connected");
                    BluetoothRemoteControl.this.bluetoothLeService.setRemoteDeviceType(BluetoothRemoteControl.this.remoteDeviceType);
                    BluetoothRemoteControl.this.main_activity.setBrightnessForCamera(false);
                } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                    Log.d(BluetoothRemoteControl.TAG, "Remote disconnected");
                    boolean unused = BluetoothRemoteControl.this.is_connected = false;
                    applicationInterface.getDrawPreview().onExtraOSDValuesChanged("-- °C", "-- m");
                    mainUI.updateRemoteConnectionIcon();
                    BluetoothRemoteControl.this.main_activity.setBrightnessToMinimumIfWanted();
                    if (mainUI.isExposureUIOpen()) {
                        mainUI.toggleExposureUI();
                    }
                } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                    Log.d(BluetoothRemoteControl.TAG, "Remote services discovered");
                    boolean unused2 = BluetoothRemoteControl.this.is_connected = true;
                    mainUI.updateRemoteConnectionIcon();
                } else if (BluetoothLeService.ACTION_SENSOR_VALUE.equals(action)) {
                    double doubleExtra = intent.getDoubleExtra(BluetoothLeService.SENSOR_TEMPERATURE, -1.0d);
                    double round = ((double) Math.round((intent.getDoubleExtra(BluetoothLeService.SENSOR_DEPTH, -1.0d) / ((double) BluetoothRemoteControl.this.main_activity.getWaterDensity())) * 10.0d)) / 10.0d;
                    Log.d(BluetoothRemoteControl.TAG, "Sensor values: depth: " + round + " - temp: " + doubleExtra);
                    StringBuilder sb = new StringBuilder();
                    sb.append("");
                    sb.append(doubleExtra);
                    sb.append(" °C");
                    String sb2 = sb.toString();
                    applicationInterface.getDrawPreview().onExtraOSDValuesChanged(sb2, "" + round + " m");
                } else if (BluetoothLeService.ACTION_REMOTE_COMMAND.equals(action)) {
                    int intExtra = intent.getIntExtra(BluetoothLeService.EXTRA_DATA, -1);
                    if (intExtra != 16) {
                        if (intExtra == 32) {
                            BluetoothRemoteControl.this.main_activity.takePicture(false);
                        } else if (intExtra != 48) {
                            if (intExtra != 64) {
                                if (intExtra != 80) {
                                    if (intExtra == 97) {
                                        mainUI.togglePopupSettings();
                                    }
                                } else if (mainUI.processRemoteDownButton()) {
                                } else {
                                    if (BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue() == null || !BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue().equals("focus_mode_manual2")) {
                                        BluetoothRemoteControl.this.main_activity.zoomOut();
                                    } else {
                                        BluetoothRemoteControl.this.main_activity.changeFocusDistance(25, false);
                                    }
                                }
                            } else if (mainUI.processRemoteUpButton()) {
                            } else {
                                if (BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue() == null || !BluetoothRemoteControl.this.main_activity.getPreview().getCurrentFocusValue().equals("focus_mode_manual2")) {
                                    BluetoothRemoteControl.this.main_activity.zoomIn();
                                } else {
                                    BluetoothRemoteControl.this.main_activity.changeFocusDistance(-25, false);
                                }
                            }
                        } else if (mainUI.popupIsOpen()) {
                            mainUI.commandMenuPopup();
                        } else if (!mainUI.isExposureUIOpen()) {
                            mainUI.toggleExposureUI();
                        } else {
                            mainUI.commandMenuExposure();
                        }
                    } else if (mainUI.popupIsOpen()) {
                        mainUI.togglePopupSettings();
                    } else if (mainUI.isExposureUIOpen()) {
                        mainUI.toggleExposureUI();
                    } else {
                        BluetoothRemoteControl.this.main_activity.clickedSwitchVideo((View) null);
                    }
                } else {
                    Log.d(BluetoothRemoteControl.TAG, "Other remote event");
                }
            }
        }
    };
    /* access modifiers changed from: private */
    public String remoteDeviceAddress;
    /* access modifiers changed from: private */
    public String remoteDeviceType;

    public BluetoothRemoteControl(CameraActivity cameraActivity) {
        this.main_activity = cameraActivity;
    }

    public boolean remoteConnected() {
        return this.is_connected;
    }

    private static IntentFilter makeRemoteCommandIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(BluetoothLeService.ACTION_REMOTE_COMMAND);
        intentFilter.addAction(BluetoothLeService.ACTION_SENSOR_VALUE);
        return intentFilter;
    }

    public void startRemoteControl() {
        Log.d(TAG, "BLE Remote control service start check...");
        if (Build.VERSION.SDK_INT >= 18) {
            Intent intent = new Intent(this.main_activity, BluetoothLeService.class);
            if (remoteEnabled()) {
                Log.d(TAG, "Remote enabled, starting service");
                this.main_activity.bindService(intent, this.mServiceConnection, Context.BIND_AUTO_CREATE);
                this.main_activity.registerReceiver(this.remoteControlCommandReceiver, makeRemoteCommandIntentFilter());
                return;
            }
            Log.d(TAG, "Remote disabled, stopping service");
            try {
                this.main_activity.unregisterReceiver(this.remoteControlCommandReceiver);
                this.main_activity.unbindService(this.mServiceConnection);
                this.is_connected = false;
                this.main_activity.getMainUI().updateRemoteConnectionIcon();
            } catch (IllegalArgumentException unused) {
                Log.d(TAG, "Remote Service was not running, that's fine");
            }
        }
    }

    public void stopRemoteControl() {
        Log.d(TAG, "BLE Remote control service shutdown...");
        if (remoteEnabled()) {
            try {
                this.main_activity.unregisterReceiver(this.remoteControlCommandReceiver);
                this.main_activity.unbindService(this.mServiceConnection);
                this.is_connected = false;
                this.main_activity.getMainUI().updateRemoteConnectionIcon();
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "Remote Service was not running, that's strange");
                e.printStackTrace();
            }
        }
    }

    public boolean remoteEnabled() {
        if (Build.VERSION.SDK_INT < 18) {
            return false;
        }
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.main_activity);
        boolean z = defaultSharedPreferences.getBoolean(PreferenceKeys.EnableRemote, false);
        this.remoteDeviceType = defaultSharedPreferences.getString(PreferenceKeys.RemoteType, "UNDEFINED_DOMAIN");
        String string = defaultSharedPreferences.getString(PreferenceKeys.RemoteName, "UNDEFINED_DOMAIN");
        this.remoteDeviceAddress = string;
        if (!z || string.equals("UNDEFINED_DOMAIN")) {
            return false;
        }
        return true;
    }
}
