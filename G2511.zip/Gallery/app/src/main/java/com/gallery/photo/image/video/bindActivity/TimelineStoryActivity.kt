package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.view.Window
import android.view.WindowManager
import com.example.app.ads.helper.InterstitialAdHelper
import com.example.app.ads.helper.InterstitialAdHelper.isShowInterstitialAd
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.databinding.ActivityTimelineStoryBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.stories.StoryContent
import com.gallery.photo.image.video.utilities.isInterstitialShown
import java.util.*


class TimelineStoryActivity : BaseBindingActivity<ActivityTimelineStoryBinding>() {
    var list = ArrayList<ArrayList<StoryContent>>()
    var isFavourite = false
    var currentPosition: Int = 0

    override fun getContext(): Activity {
        return this
    }

    override fun setParamBeforeLayoutInit() {
        super.setParamBeforeLayoutInit()
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

    }

    override fun initData() {
        list = intent.getSerializableExtra("List") as ArrayList<ArrayList<StoryContent>>
        currentPosition = intent.getIntExtra("index", 0)
        mBinding.vStories.init(this)
        mBinding.vStories.setStories(list)
        mBinding.vStories.setCurrentPosition(currentPosition)
        mBinding.vStories.setOnStoryCompletedListener {
            onBackPressed()
        }
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            InterstitialAdHelper.loadInterstitialAd(fContext = this)
        }

    }

    override fun initActions() {

    }

    override fun setBinding(): ActivityTimelineStoryBinding {
        return ActivityTimelineStoryBinding.inflate(inflater)
    }


    override fun onPause() {
        super.onPause()

    }

    override fun onBackPressed() {
        if (AdsManager(this).isNeedToShowAds() && isOnline()) {
            isInterstitialShown = true
            isShowInterstitialAd {
                isInterstitialShown = false
                finish()
            }
        } else {
            isInterstitialShown = false
            finish()
        }

    }
}