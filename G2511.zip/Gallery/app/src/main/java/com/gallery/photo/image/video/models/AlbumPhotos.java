package com.gallery.photo.image.video.models;

import android.graphics.Bitmap;

public class AlbumPhotos {

    String path;
    Bitmap bitmap;
    boolean checked;

    public AlbumPhotos(String path) {
        this.path = path;
    }

    public AlbumPhotos(String path, boolean checked) {
        this.path = path;
        this.checked = checked;
    }

    public AlbumPhotos(String path, Bitmap bitmap) {
        this.path = path;
        this.bitmap = bitmap;
    }

    public AlbumPhotos(String thumbPath, Bitmap myBitmap, boolean b) {
        this.path = thumbPath;
        this.bitmap = myBitmap;
        this.checked = b;
    }

    public AlbumPhotos() {

    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public AlbumPhotos(Bitmap myBitmap) {
        this.bitmap = bitmap;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
}
