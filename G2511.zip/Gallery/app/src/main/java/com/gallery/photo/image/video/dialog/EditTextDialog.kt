package com.gallery.photo.image.video.dialog

import android.view.LayoutInflater
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.adapters.RenameAdapter
import com.gallery.photo.image.video.extensions.*
import kotlinx.android.synthetic.main.dialog_edittext.view.*
import java.util.*

class EditTextDialog(val activity: BaseSimpleActivity,val message: String, val callback: (newMessage: String) -> Unit) {
    init {
        var ignoreClicks = false
//        val fullName = path.getFilenameFromPath()
//        val dotAt = fullName.lastIndexOf(".")
//        var name = fullName

        val view = activity.layoutInflater.inflate(R.layout.dialog_edittext, null).apply {
            edit_item_name.setText(message)
        }

        AlertDialog.Builder(activity,R.style.MyAlertDialogNew)
            .setPositiveButton(R.string.ok, null)
            .setNegativeButton(R.string.cancel, null)
            .create().apply {
                activity.setupDialogStuff(view, this, R.string.rename) {
                    showKeyboard(view.edit_item_name)
                    getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        if (ignoreClicks) {
                            return@setOnClickListener
                        }

                        var newName = view.edit_item_name.value

                        if (newName.isEmpty()) {
                            activity.toast(R.string.empty_name)
                            return@setOnClickListener
                        }

                        if (!newName.isAValidFilename()) {
                            activity.toast(R.string.invalid_name)
                            return@setOnClickListener
                        }

//                        val updatedPaths = ArrayList<String>()
//                        updatedPaths.add(path)
//                        if (!newExtension.isEmpty()) {
//                            newName += ".$newExtension"
//                        }

//                        if (!activity.getDoesFilePathExist(path)) {
//                            activity.toast(String.format(activity.getString(R.string.source_file_doesnt_exist), path))
//                            return@setOnClickListener
//                        }

//                        val newPath = "${path.getParentPath()}/$newName"
//                        if (activity.getDoesFilePathExist(newPath)) {
//                            activity.toast(R.string.name_taken)
//                            return@setOnClickListener
//                        }

//                        updatedPaths.add(newPath)
                        ignoreClicks = true
//                        activity.renameFile(path, newPath) {
//                            ignoreClicks = false
//                            if (it) {
                                callback(newName)
                                dismiss()
//                            } else {
//                                activity.toast(R.string.unknown_error_occurred)
//                            }
//                        }
                    }
                }
            }
    }
}
