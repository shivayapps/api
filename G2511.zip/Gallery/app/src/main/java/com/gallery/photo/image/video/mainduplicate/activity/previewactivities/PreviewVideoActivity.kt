package com.gallery.photo.image.video.mainduplicate.activity.previewactivities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.gallery.photo.image.video.mainduplicate.model.ItemDuplicateModel
import com.bumptech.glide.Glide
import com.example.app.ads.helper.GiftIconHelper
import com.example.app.ads.helper.NativeAdsSize
import com.example.app.ads.helper.NativeAdvancedModelHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.activity.BaseActivity
import com.gallery.photo.image.video.adshelper.AdsManager

import com.gallery.photo.image.video.mainduplicate.GlobalVarsAndFunctions
import com.gallery.photo.image.video.mainduplicate.utils.ShareConstants
import com.gallery.photo.image.video.utilities.isUnLockApp
import io.github.inflationx.viewpump.ViewPumpContextWrapper
import kotlinx.android.synthetic.main.activity_preview_video.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class PreviewVideoActivity : BaseActivity() {
    var mItemDuplicateModel: ItemDuplicateModel? = null
    var mFileName: String? = null
    var mFileSize: String? = null
    var mFileType: String? = null
    var mModifiedDate: String? = null
    var mPath: String? = null
    var mImageResolution: String? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preview_video)
    }

    override fun getContext(): Activity {
        return this@PreviewVideoActivity
    }

    override fun getAppIconIDs(): ArrayList<Int> = arrayListOf(

        R.mipmap.ic_launcher
    )

    override fun getAppLauncherName(): String {
        return getString(R.string.app_name);
    }

    override fun initData() {
        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = findViewById(R.id.gift_ad_icon),
                fivBlastIcon =findViewById(R.id.gift_blast_ad_icon)
            )
        }
        assignValuesToWidgets()
        fileName!!.text = mFileName
        fileType!!.text = mFileType
        fileSize!!.text = mFileSize
        imageResolution!!.text = mImageResolution
        if (mImageResolution == "NA") {
            zoomableImageView!!.setImageDrawable(ContextCompat.getDrawable(mContext, R.drawable.img_thumb))
        } else {
            Glide.with(this)
                .load(Uri.fromFile(File(mPath!!)))
                .centerCrop()
                .placeholder(R.drawable.img_thumb)
                .into(zoomableImageView!!)
        }
        modifiedDate!!.text = mModifiedDate
        path!!.text = mPath
    }

    override fun initActions() {
        playVideo!!.setOnClickListener(PlayVideo())
        zoomableImageView!!.setOnClickListener(PlayVideo())
        backpress_home!!.setOnClickListener(this)
    }

    inner class PlayVideo : View.OnClickListener {
        override fun onClick(v: View) {
            if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
                return
            }
            ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()

            isUnLockApp =true
            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            val lFileUri = FileProvider.getUriForFile(mContext, applicationContext.packageName + ".fileprovider", File(mPath!!))
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.setDataAndType(lFileUri, "video/*")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun assignValuesToWidgets() {
        val b = intent.extras
        if (b != null) {
            mItemDuplicateModel = b.getSerializable("videoItem") as ItemDuplicateModel?
        }
        mFileName = GlobalVarsAndFunctions.getFileName(mItemDuplicateModel!!.filePath)
        mFileType = GlobalVarsAndFunctions.getExtension(mItemDuplicateModel!!.filePath)
        mFileSize = ShareConstants.getReadableFileSize(mItemDuplicateModel!!.sizeOfTheFile)
        mImageResolution = mItemDuplicateModel!!.fileDuration
        mModifiedDate = SimpleDateFormat("MMM dd,yyyy HH:mm:ss ").format(Date(mItemDuplicateModel!!.fileDateAndTime))
        mPath = mItemDuplicateModel!!.filePath
    }

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - ShareConstants.mLastClickTime < 1000) {
            return
        }
        ShareConstants.mLastClickTime = SystemClock.elapsedRealtime()
        if (view.id == R.id.backpress_home) {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (AdsManager(mContext).isNeedToShowAds() && isOnline()) {
            NativeAdvancedModelHelper(this).loadNativeAdvancedAd(
                NativeAdsSize.Medium,
                flBanner
            )
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}