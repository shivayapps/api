package com.gallery.photo.image.video.interfaces

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy.REPLACE
import androidx.room.Query
import com.gallery.photo.image.video.models.FakeVaultMedium
import com.gallery.photo.image.video.models.Medium

@Dao
interface FakeVaultMediumDao {

    @Query("SELECT filename FROM fakeVaultMedia  WHERE type = :type ")
    fun getTotalMedia(type: Int): List<String>


    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type, video_duration, is_favorite, deleted_ts FROM fakeVaultMedia WHERE deleted_ts = 0 AND parent_path = :path COLLATE NOCASE")
    fun getMediaFromPath(path: String): List<Medium>
    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type, video_duration, is_favorite, deleted_ts FROM fakeVaultMedia WHERE parent_path = :path COLLATE NOCASE")
    fun getAllMediaFromPath(path: String): List<Medium>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type, video_duration, is_favorite, deleted_ts FROM fakeVaultMedia WHERE deleted_ts = 0 AND parent_path = :path AND type = :type  COLLATE NOCASE")
    fun getTypeMediaFromPath(path: String, type: Int): List<Medium>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type, video_duration, is_favorite, deleted_ts FROM fakeVaultMedia WHERE deleted_ts = 0 AND is_favorite = 1")
    fun getFavorites(): List<FakeVaultMedium>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type, video_duration, is_favorite, deleted_ts FROM fakeVaultMedia WHERE deleted_ts != 0")
    fun getDeletedMedia(): List<FakeVaultMedium>

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type, video_duration, is_favorite, deleted_ts FROM fakeVaultMedia WHERE  full_path like :path || '%' AND  deleted_ts != 0 AND type = :type ORDER BY deleted_ts DESC")
    fun getTypeWiseDeletedMedia(path: String,type: Int): List<Medium>

    @Query("SELECT  full_path FROM fakeVaultMedia WHERE deleted_ts != 0 AND deleted_ts <= :endDeletedTS")
    fun getTrashMediaForDelete( endDeletedTS: Long): List<String>

    @Query("DELETE  FROM fakeVaultMedia WHERE deleted_ts != 0 AND deleted_ts <= :endDeletedTS")
    fun deleteTrashMedia( endDeletedTS: Long)

    @Insert(onConflict = REPLACE)
    fun insert(medium: FakeVaultMedium)

    @Query("SELECT filename, full_path, parent_path, last_modified, date_taken, size, type, video_duration, is_favorite, deleted_ts FROM fakeVaultMedia WHERE  full_path = :path COLLATE NOCASE")
    fun getMediaDetailFromPath(path: String): Medium

    @Insert(onConflict = REPLACE)
    fun insertAll(fakeVaultMedia: List<FakeVaultMedium>)

    @Delete
    fun deleteMedia(vararg medium: FakeVaultMedium)

    @Query("DELETE FROM fakeVaultMedia WHERE full_path = :path COLLATE NOCASE")
    fun deleteMediumPath(path: String)

    @Query("DELETE FROM fakeVaultMedia WHERE deleted_ts < :timestmap AND deleted_ts != 0")
    fun deleteOldRecycleBinItems(timestmap: Long)

    @Query("UPDATE OR REPLACE fakeVaultMedia SET filename = :newFilename, full_path = :newFullPath, parent_path = :newParentPath WHERE full_path = :oldPath COLLATE NOCASE")
    fun updateMedium(newFilename: String, newFullPath: String, newParentPath: String, oldPath: String)

    @Query("UPDATE OR REPLACE fakeVaultMedia SET full_path = :newPath, deleted_ts = :deletedTS WHERE full_path = :oldPath COLLATE NOCASE")
    fun updateDeleted(newPath: String, deletedTS: Long, oldPath: String)

    @Query("UPDATE fakeVaultMedia SET date_taken = :dateTaken WHERE full_path = :path COLLATE NOCASE")
    fun updateFavoriteDateTaken(path: String, dateTaken: Long)

    @Query("UPDATE fakeVaultMedia SET is_favorite = 0")
    fun clearFavorites()

    @Query("DELETE FROM fakeVaultMedia WHERE deleted_ts != 0")
    fun clearRecycleBin()
}
