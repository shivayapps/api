package com.gallery.photo.image.video.Camera;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class TakePhoto extends Activity {
    private static final String TAG = "TakePhoto";
    public static boolean TAKE_PHOTO;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        Log.d(TAG, "onCreate");
        super.onCreate(bundle);
        Intent intent = new Intent(this, CameraActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        TAKE_PHOTO = true;
        startActivity(intent);
        Log.d(TAG, "finish");
        finish();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        Log.d(TAG, "onResume");
        super.onResume();
    }
}
