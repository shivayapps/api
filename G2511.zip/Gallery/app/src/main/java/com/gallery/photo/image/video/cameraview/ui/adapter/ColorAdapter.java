package com.gallery.photo.image.video.cameraview.ui.adapter;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.ui.interfaces.OnRecyclerItemClickListener;
import com.gallery.photo.image.video.cameraview.ui.model.ColorModel;

import java.util.List;

public class ColorAdapter extends RecyclerView.Adapter<ColorAdapter.Holder> {
    Activity mContext;
    List<ColorModel> mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;

    public ColorAdapter(Activity activity, List<ColorModel> list, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = activity;
        this.mList = list;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;

    }

    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_color, viewGroup, false));
    }

    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_color_title.setText(this.mList.get(i).getTitle());
        ((GradientDrawable) holder.tv_color_background.getBackground().getCurrent()).setColor(this.mList.get(i).getColor());
    }

    public int getItemCount() {
        return this.mList.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        RelativeLayout Rel_background;
        TextView tv_color_background;
        TextView tv_color_title;

        public Holder(final View view) {
            super(view);
            tv_color_title = (TextView) view.findViewById(R.id.tv_color_title);
            tv_color_background = (TextView) view.findViewById(R.id.tv_color_background);
            Rel_background = (RelativeLayout) view.findViewById(R.id.Rel_background);
            Rel_background.setOnClickListener(view1 -> {
                if (Holder.this.getAdapterPosition() >= 0 && view1 != null && mOnRecyclerItemClickListener != null) {
                    mOnRecyclerItemClickListener.OnClick_(Holder.this.getAdapterPosition(), view1);
                }
            });
        }
    }
}
