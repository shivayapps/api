package com.gallery.photo.image.video.Camera.ui;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.BatteryManager;
import android.util.Log;
import android.util.Pair;
import android.view.Display;
import android.view.View;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.work.WorkRequest;

import com.gallery.photo.image.video.Camera.GyroSensor;
import com.gallery.photo.image.video.Camera.ImageSaver;
import com.gallery.photo.image.video.Camera.MyApplicationInterface;
import com.gallery.photo.image.video.Camera.MyDebug;
import com.gallery.photo.image.video.Camera.PreferenceKeys;
import com.gallery.photo.image.video.utilities.SharedPrefs;
//import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.gallery.photo.image.video.Camera.CameraActivity;
import com.gallery.photo.image.video.Camera.cameracontroller.CameraController;
import com.gallery.photo.image.video.Camera.preview.ApplicationInterface;
import com.gallery.photo.image.video.Camera.preview.Preview;
import com.gallery.photo.image.video.R;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class DrawPreview {
    private static final String TAG = "DrawPreview";
    private static final double close_level_angle = 1.0d;
    private static final DecimalFormat decimalFormat = new DecimalFormat("#0.0");
    private static final int histogram_height_dp = 60;
    private static final int histogram_width_dp = 100;
    private String OSDLine1;
    private String OSDLine2;
    private long ae_started_scanning_ms;
    private boolean allow_ghost_last_image;
    private int angle_highlight_color_pref;
    private String angle_string;
    private final MyApplicationInterface applicationInterface;
    private final int[] auto_stabilise_crop;
    private boolean auto_stabilise_pref;
    private float battery_frac;
    private final IntentFilter battery_ifilter;
    private double cached_angle;
    private Calendar calendar;
    private String camera_id_string;
    private float capture_rate_factor;
    private boolean capture_started;
    private boolean continuous_focus_moving;
    private long continuous_focus_moving_ms;
    private String current_time_string;
    private DateFormat dateFormatTimeInstance;
    private final RectF draw_rect;
    private boolean enable_gyro_target_spot;
    private int focus_peaking_color_pref;
    private int focus_seekbars_margin_left;
    private float free_memory_gb;
    private String free_memory_gb_string;
    private boolean front_screen_flash;
    private int ghost_image_alpha;
    private String ghost_image_pref;
    private Bitmap ghost_selected_image_bitmap;
    private String ghost_selected_image_pref = "";
    private final int[] gui_location;
    private final float[] gyro_direction_up;
    private final List<float[]> gyro_directions;
    private boolean has_battery_frac;
    private boolean has_settings;
    private boolean has_stamp_pref;
    private boolean has_video_max_amp;
    private Preview.HistogramType histogram_type;
    private final Rect icon_dest;
    private boolean image_queue_full;
    private boolean immersive_mode_everything_pref;
    private boolean is_audio_enabled_pref;
    private boolean is_face_detection_pref;
    private boolean is_high_speed;
    private boolean is_raw_only_pref;
    private boolean is_raw_pref;
    private boolean is_scanning;
    private String iso_exposure_string;
    private long last_angle_string_time;
    private long last_battery_time;
    private long last_camera_id_time;
    private long last_current_time_time;
    private long last_free_memory_time;
    private final RectF last_image_dst_rect;
    private final Matrix last_image_matrix;
    private final RectF last_image_src_rect;
    private long last_iso_exposure_time;
    private long last_need_flash_indicator_time;
    private long last_take_photo_top_time;
    private Bitmap last_thumbnail;
    private boolean last_thumbnail_is_video;
    private long last_top_icon_shift_time;
    private long last_video_max_amp_time;
    private long last_view_angles_time;
    private final CameraActivity main_activity;
    private boolean need_flash_indicator;
    private long needs_flash_time;
    private final Paint p;
    private final Path path;
    private MyApplicationInterface.PhotoMode photoMode;
    private String preference_grid_pref;
    private boolean preview_size_wysiwyg_pref;
    private final float scale;
    private boolean show_angle_line_pref;
    private boolean show_angle_pref;
    private boolean show_battery_pref;
    private boolean show_camera_id_pref;
    private boolean show_free_memory_pref;
    private boolean show_geo_direction_lines_pref;
    private boolean show_geo_direction_pref;
    private boolean show_iso_pref;
    private boolean show_last_image;
    private boolean show_pitch_lines_pref;
    private boolean show_time_pref;
    private boolean show_video_max_amp_pref;
    private boolean show_zoom_pref;
    private boolean store_location_pref;
    private final float stroke_width;
    private boolean take_photo_border_pref;
    private int take_photo_top;
    private boolean taking_picture;
    private final int[] temp_histogram_channel;
    private Rect text_bounds_angle_double;
    private Rect text_bounds_angle_single;
    private Rect text_bounds_camera_id;
    private Rect text_bounds_free_memory;
    private Rect text_bounds_time;
    private volatile boolean thumbnail_anim;
    private final RectF thumbnail_anim_dst_rect;
    private final Matrix thumbnail_anim_matrix;
    private final RectF thumbnail_anim_src_rect;
    private long thumbnail_anim_start_ms;
    private int top_icon_shift;
    private final float[] transformed_gyro_direction;
    private final float[] transformed_gyro_direction_up;
    private int video_max_amp;
    private int video_max_amp_peak;
    private int video_max_amp_prev2;
    private float view_angle_x_preview;
    private float view_angle_y_preview;
    private boolean want_focus_peaking;
    private boolean want_histogram;
    private boolean want_zebra_stripes;
    private final String ybounds_text;
    private int zebra_stripes_color_background;
    private int zebra_stripes_color_foreground;
    private int zebra_stripes_threshold;

    public DrawPreview(CameraActivity cameraActivity, MyApplicationInterface myApplicationInterface) {
        Paint paint = new Paint();
        this.p = paint;
        this.draw_rect = new RectF();
        this.gui_location = new int[2];
        this.temp_histogram_channel = new int[256];
        this.auto_stabilise_crop = new int[2];
        this.free_memory_gb = -1.0f;
        this.need_flash_indicator = false;
        this.battery_ifilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
        this.icon_dest = new Rect();
        this.needs_flash_time = -1;
        this.path = new Path();
        this.thumbnail_anim_start_ms = -1;
        this.thumbnail_anim_src_rect = new RectF();
        this.thumbnail_anim_dst_rect = new RectF();
        this.thumbnail_anim_matrix = new Matrix();
        this.last_image_src_rect = new RectF();
        this.last_image_dst_rect = new RectF();
        this.last_image_matrix = new Matrix();
        this.ae_started_scanning_ms = -1;
        this.gyro_directions = new ArrayList();
        this.transformed_gyro_direction = new float[3];
        this.gyro_direction_up = new float[3];
        this.transformed_gyro_direction_up = new float[3];
        this.focus_seekbars_margin_left = -1;
        Log.d(TAG, TAG);
        this.main_activity = cameraActivity;
        
        this.applicationInterface = myApplicationInterface;
        paint.setAntiAlias(true);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setStrokeCap(Paint.Cap.ROUND);
        float f = getContext().getResources().getDisplayMetrics().density;
        this.scale = f;
        float f2 = (f * 1.0f) + 0.5f;
        this.stroke_width = f2;
        paint.setStrokeWidth(f2);
        this.ybounds_text = getContext().getResources().getString(R.string.zoom) + getContext().getResources().getString(R.string.angle) + getContext().getResources().getString(R.string.direction);
    }

    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        Bitmap bitmap = this.ghost_selected_image_bitmap;
        if (bitmap != null) {
            bitmap.recycle();
            this.ghost_selected_image_bitmap = null;
        }
        this.ghost_selected_image_pref = "";
    }

    private Context getContext() {
        return this.main_activity;
    }

    private int getViewOnScreenX(View view) {
        view.getLocationOnScreen(this.gui_location);
        int i = this.gui_location[0];
        int round = ((Math.round(view.getRotation()) % 360) + 360) % 360;
        return (round == 180 || round == 90) ? i - view.getWidth() : i;
    }

    public void updateThumbnail(Bitmap bitmap, boolean z, boolean z2) {
        Log.d(TAG, "updateThumbnail");
        if (z2 && this.applicationInterface.getThumbnailAnimationPref()) {
            Log.d(TAG, "thumbnail_anim started");
            this.thumbnail_anim = true;
            this.thumbnail_anim_start_ms = System.currentTimeMillis();
        }
        Bitmap bitmap2 = this.last_thumbnail;
        this.last_thumbnail = bitmap;
        this.last_thumbnail_is_video = z;
        this.allow_ghost_last_image = true;
        if (bitmap2 != null) {
            bitmap2.recycle();
        }
    }

    public boolean hasThumbnailAnimation() {
        return this.thumbnail_anim;
    }

    public void showLastImage() {
        Log.d(TAG, "showLastImage");
        this.show_last_image = true;
    }

    public void clearLastImage() {
        Log.d(TAG, "clearLastImage");
        this.show_last_image = false;
    }

    public void clearGhostImage() {
        Log.d(TAG, "clearGhostImage");
        this.allow_ghost_last_image = false;
    }

    public void cameraInOperation(boolean z) {
        if (!z || this.main_activity.getPreview().isVideo()) {
            this.taking_picture = false;
            this.front_screen_flash = false;
            this.capture_started = false;
            return;
        }
        this.taking_picture = true;
    }

    public void setImageQueueFull(boolean z) {
        this.image_queue_full = z;
    }

    public void turnFrontScreenFlashOn() {
        Log.d(TAG, "turnFrontScreenFlashOn");
        this.front_screen_flash = true;
    }

    public void onCaptureStarted() {
        Log.d(TAG, "onCaptureStarted");
        this.capture_started = true;
    }

    public void onContinuousFocusMove(boolean z) {
        Log.d(TAG, "onContinuousFocusMove: " + z);
        if (z && !this.continuous_focus_moving) {
            this.continuous_focus_moving = true;
            this.continuous_focus_moving_ms = System.currentTimeMillis();
        }
    }

    public void clearContinuousFocusMove() {
        Log.d(TAG, "clearContinuousFocusMove");
        if (this.continuous_focus_moving) {
            this.continuous_focus_moving = false;
            this.continuous_focus_moving_ms = 0;
        }
    }

    public void setGyroDirectionMarker(float f, float f2, float f3) {
        this.enable_gyro_target_spot = true;
        this.gyro_directions.clear();
        addGyroDirectionMarker(f, f2, f3);
        float[] fArr = this.gyro_direction_up;
        fArr[0] = 0.0f;
        fArr[1] = 1.0f;
        fArr[2] = 0.0f;
    }

    public void addGyroDirectionMarker(float f, float f2, float f3) {
        this.gyro_directions.add(new float[]{f, f2, f3});
    }

    public void clearGyroDirectionMarker() {
        this.enable_gyro_target_spot = false;
    }

    /**
     * For performance reasons, some of the SharedPreferences settings are cached. This method
     * should be used when the settings may have changed.
     */
    public void updateSettings() {
        if (MyDebug.LOG)
            Log.d(TAG, "updateSettings");

        photoMode = applicationInterface.getPhotoMode();
        if (MyDebug.LOG)
            Log.d(TAG, "photoMode: " + photoMode);

        show_time_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowTimePreferenceKey, true);
        // reset in case user changes the preference:
        dateFormatTimeInstance = DateFormat.getTimeInstance();
        current_time_string = null;
        last_current_time_time = 0;
        text_bounds_time = null;

        show_camera_id_pref = main_activity.isMultiCam() && SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowCameraIDPreferenceKey, true);
        //show_camera_id_pref = true; // test
        show_free_memory_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowFreeMemoryPreferenceKey, true);
        show_iso_pref = SharedPrefs.getBoolean(main_activity, PreferenceKeys.ShowISOPreferenceKey, true);
        show_video_max_amp_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowVideoMaxAmpPreferenceKey, false);
        show_zoom_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowZoomPreferenceKey, true);
        show_battery_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowBatteryPreferenceKey, true);

        show_angle_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowAnglePreferenceKey, false);
        String angle_highlight_color = SharedPrefs.getString(main_activity,PreferenceKeys.ShowAngleHighlightColorPreferenceKey, "#14e715");
        angle_highlight_color_pref = Color.parseColor(angle_highlight_color);
        show_geo_direction_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowGeoDirectionPreferenceKey, false);

        take_photo_border_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.TakePhotoBorderPreferenceKey, true);
        preview_size_wysiwyg_pref = SharedPrefs.getString(main_activity,PreferenceKeys.PreviewSizePreferenceKey, "preference_preview_size_wysiwyg").equals("preference_preview_size_wysiwyg");
        store_location_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.LocationPreferenceKey, false);

        show_angle_line_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowAngleLinePreferenceKey, false);
        show_pitch_lines_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowPitchLinesPreferenceKey, false);
        show_geo_direction_lines_pref = SharedPrefs.getBoolean(main_activity,PreferenceKeys.ShowGeoDirectionLinesPreferenceKey, false);

        String immersive_mode = SharedPrefs.getString(main_activity,PreferenceKeys.ImmersiveModePreferenceKey, "immersive_mode_low_profile");
        immersive_mode_everything_pref = immersive_mode.equals("immersive_mode_everything");

        has_stamp_pref = applicationInterface.getStampPref().equals("preference_stamp_yes");
        is_raw_pref = applicationInterface.getRawPref() != ApplicationInterface.RawPref.RAWPREF_JPEG_ONLY;
        is_raw_only_pref = applicationInterface.isRawOnly();
        is_face_detection_pref = applicationInterface.getFaceDetectionPref();
        is_audio_enabled_pref = applicationInterface.getRecordAudioPref();

        is_high_speed = applicationInterface.fpsIsHighSpeed();
        capture_rate_factor = applicationInterface.getVideoCaptureRateFactor();

        auto_stabilise_pref = applicationInterface.getAutoStabilisePref();

        preference_grid_pref = SharedPrefs.getString(main_activity,PreferenceKeys.ShowGridPreferenceKey, "preference_grid_none");

        ghost_image_pref = SharedPrefs.getString(main_activity,PreferenceKeys.GhostImagePreferenceKey, "preference_ghost_image_off");
        if (ghost_image_pref.equals("preference_ghost_image_selected")) {
            String new_ghost_selected_image_pref = SharedPrefs.getString(main_activity,PreferenceKeys.GhostSelectedImageSAFPreferenceKey, "");
            if (MyDebug.LOG)
                Log.d(TAG, "new_ghost_selected_image_pref: " + new_ghost_selected_image_pref);

            KeyguardManager keyguard_manager = (KeyguardManager) main_activity.getSystemService(Context.KEYGUARD_SERVICE);
            boolean is_locked = keyguard_manager != null && keyguard_manager.inKeyguardRestrictedInputMode();
            if (MyDebug.LOG)
                Log.d(TAG, "is_locked?: " + is_locked);

            if (is_locked) {
                // don't show selected image when device locked, as this could be a security flaw
                if (ghost_selected_image_bitmap != null) {
                    ghost_selected_image_bitmap.recycle();
                    ghost_selected_image_bitmap = null;
                    ghost_selected_image_pref = ""; // so we'll load the bitmap again when unlocked
                }
            } else if (!new_ghost_selected_image_pref.equals(ghost_selected_image_pref)) {
                if (MyDebug.LOG)
                    Log.d(TAG, "ghost_selected_image_pref has changed");
                ghost_selected_image_pref = new_ghost_selected_image_pref;
                if (ghost_selected_image_bitmap != null) {
                    ghost_selected_image_bitmap.recycle();
                    ghost_selected_image_bitmap = null;
                }
                Uri uri = Uri.parse(ghost_selected_image_pref);
                try {
                    ghost_selected_image_bitmap = loadBitmap(uri);
                } catch (IOException e) {
                    Log.e(TAG, "failed to load ghost_selected_image uri: " + uri);
                    e.printStackTrace();
                    ghost_selected_image_bitmap = null;
                    // don't set ghost_selected_image_pref to null, as we don't want to repeatedly try loading the invalid uri
                }
            }
        } else {
            if (ghost_selected_image_bitmap != null) {
                ghost_selected_image_bitmap.recycle();
                ghost_selected_image_bitmap = null;
            }
            ghost_selected_image_pref = "";
        }
        ghost_image_alpha = applicationInterface.getGhostImageAlpha();

        String histogram_pref = SharedPrefs.getString(main_activity,PreferenceKeys.HistogramPreferenceKey, "preference_histogram_off");
        want_histogram = !histogram_pref.equals("preference_histogram_off") && main_activity.supportsPreviewBitmaps();
        histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_VALUE;
        if (want_histogram) {
            switch (histogram_pref) {
                case "preference_histogram_rgb":
                    histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_RGB;
                    break;
                case "preference_histogram_luminance":
                    histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_LUMINANCE;
                    break;
                case "preference_histogram_value":
                    histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_VALUE;
                    break;
                case "preference_histogram_intensity":
                    histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_INTENSITY;
                    break;
                case "preference_histogram_lightness":
                    histogram_type = Preview.HistogramType.HISTOGRAM_TYPE_LIGHTNESS;
                    break;
            }
        }

        String zebra_stripes_value = SharedPrefs.getString(main_activity,PreferenceKeys.ZebraStripesPreferenceKey, "0");
        try {
            zebra_stripes_threshold = Integer.parseInt(zebra_stripes_value);
        } catch (NumberFormatException e) {
            if (MyDebug.LOG)
                Log.e(TAG, "failed to parse zebra_stripes_value: " + zebra_stripes_value);
            e.printStackTrace();
            zebra_stripes_threshold = 0;
        }
        want_zebra_stripes = zebra_stripes_threshold != 0 & main_activity.supportsPreviewBitmaps();

        String zebra_stripes_color_foreground_value = SharedPrefs.getString(main_activity,PreferenceKeys.ZebraStripesForegroundColorPreferenceKey, "#ff000000");
        zebra_stripes_color_foreground = Color.parseColor(zebra_stripes_color_foreground_value);
        String zebra_stripes_color_background_value = SharedPrefs.getString(main_activity,PreferenceKeys.ZebraStripesBackgroundColorPreferenceKey, "#ffffffff");
        zebra_stripes_color_background = Color.parseColor(zebra_stripes_color_background_value);

        String focus_peaking_pref = SharedPrefs.getString(main_activity,PreferenceKeys.FocusPeakingPreferenceKey, "preference_focus_peaking_off");
        want_focus_peaking = !focus_peaking_pref.equals("preference_focus_peaking_off") && main_activity.supportsPreviewBitmaps();
        String focus_peaking_color = SharedPrefs.getString(main_activity,PreferenceKeys.FocusPeakingColorPreferenceKey, "#ffffff");
        focus_peaking_color_pref = Color.parseColor(focus_peaking_color);

        last_camera_id_time = 0; // in case camera id changed
        last_view_angles_time = 0; // force view angles to be recomputed
        last_take_photo_top_time = 0;  // force take_photo_top to be recomputed
        last_top_icon_shift_time = 0; // for top_icon_shift to be recomputed

        focus_seekbars_margin_left = -1; // just in case??

        has_settings = true;
    }

    private void updateCachedViewAngles(long j) {
        long j2 = this.last_view_angles_time;
        if (j2 == 0 || j > j2 + WorkRequest.MIN_BACKOFF_MILLIS) {
            Log.d(TAG, "update cached view angles");
            Preview preview = this.main_activity.getPreview();
            this.view_angle_x_preview = preview.getViewAngleX(true);
            this.view_angle_y_preview = preview.getViewAngleY(true);
            this.last_view_angles_time = j;
        }
    }

    /**
     * Loads the bitmap from the uri.
     * The image will be downscaled if required to be comparable to the preview width.
     */
    private Bitmap loadBitmap(Uri uri) throws IOException {
        if (MyDebug.LOG)
            Log.d(TAG, "loadBitmap: " + uri);
        Bitmap bitmap;
        try {
            //bitmap = MediaStore.Images.Media.getBitmap(main_activity.getContentResolver(), uri);

            int sample_size = 1;
            {
                // attempt to compute appropriate scaling
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                InputStream input = main_activity.getContentResolver().openInputStream(uri);
                BitmapFactory.decodeStream(input, null, bounds);
                if (input != null)
                    input.close();

                if (bounds.outWidth != -1 && bounds.outHeight != -1) {
                    // compute appropriate scaling
                    int image_size = Math.max(bounds.outWidth, bounds.outHeight);

                    Point point = new Point();
                    Display display = main_activity.getWindowManager().getDefaultDisplay();
                    display.getSize(point);
                    int display_size = Math.max(point.x, point.y);

                    int ratio = (int) Math.ceil((double) image_size / display_size);
                    sample_size = Integer.highestOneBit(ratio);
                    if (MyDebug.LOG) {
                        Log.d(TAG, "display_size: " + display_size);
                        Log.d(TAG, "image_size: " + image_size);
                        Log.d(TAG, "ratio: " + ratio);
                        Log.d(TAG, "sample_size: " + sample_size);
                    }
                } else {
                    if (MyDebug.LOG)
                        Log.e(TAG, "failed to obtain width/height of bitmap");
                }
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inMutable = false;
            options.inSampleSize = sample_size;
            InputStream input = main_activity.getContentResolver().openInputStream(uri);
            bitmap = BitmapFactory.decodeStream(input, null, options);
            if (input != null)
                input.close();
            if (MyDebug.LOG && bitmap != null) {
                Log.d(TAG, "bitmap width: " + bitmap.getWidth());
                Log.d(TAG, "bitmap height: " + bitmap.getHeight());
            }
        } catch (Exception e) {
            // Although Media.getBitmap() is documented as only throwing FileNotFoundException, IOException
            // (with the former being a subset of IOException anyway), I've had SecurityException from
            // Google Play - best to catch everything just in case.
            Log.e(TAG, "MediaStore.Images.Media.getBitmap exception");
            e.printStackTrace();
            throw new IOException();
        }
        if (bitmap == null) {
            // just in case!
            Log.e(TAG, "MediaStore.Images.Media.getBitmap returned null");
            throw new IOException();
        }

        // now need to take exif orientation into account, as some devices or camera apps store the orientation in the exif tag,
        // which getBitmap() doesn't account for
        bitmap = main_activity.rotateForExif(bitmap, uri);

        return bitmap;
    }

    private String getTimeStringFromSeconds(long time) {
        int secs = (int) (time % 60);
        time /= 60;
        int mins = (int) (time % 60);
        time /= 60;
        long hours = time;
        return hours + ":" + String.format(Locale.getDefault(), "%02d", mins) + ":" + String.format(Locale.getDefault(), "%02d", secs);
    }

    private void drawGrids(Canvas canvas) {
        Preview preview = main_activity.getPreview();
        CameraController camera_controller = preview.getCameraController();
        if (camera_controller == null) {
            return;
        }

        p.setStrokeWidth(stroke_width);

        switch (preference_grid_pref) {
            case "preference_grid_3x3":
                p.setColor(Color.WHITE);
                canvas.drawLine(canvas.getWidth() / 3.0f, 0.0f, canvas.getWidth() / 3.0f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(2.0f * canvas.getWidth() / 3.0f, 0.0f, 2.0f * canvas.getWidth() / 3.0f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(0.0f, canvas.getHeight() / 3.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 3.0f, p);
                canvas.drawLine(0.0f, 2.0f * canvas.getHeight() / 3.0f, canvas.getWidth() - 1.0f, 2.0f * canvas.getHeight() / 3.0f, p);
                break;
            case "preference_grid_phi_3x3":
                p.setColor(Color.WHITE);
                canvas.drawLine(canvas.getWidth() / 2.618f, 0.0f, canvas.getWidth() / 2.618f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(1.618f * canvas.getWidth() / 2.618f, 0.0f, 1.618f * canvas.getWidth() / 2.618f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(0.0f, canvas.getHeight() / 2.618f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.618f, p);
                canvas.drawLine(0.0f, 1.618f * canvas.getHeight() / 2.618f, canvas.getWidth() - 1.0f, 1.618f * canvas.getHeight() / 2.618f, p);
                break;
            case "preference_grid_4x2":
                p.setColor(Color.GRAY);
                canvas.drawLine(canvas.getWidth() / 4.0f, 0.0f, canvas.getWidth() / 4.0f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(canvas.getWidth() / 2.0f, 0.0f, canvas.getWidth() / 2.0f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(3.0f * canvas.getWidth() / 4.0f, 0.0f, 3.0f * canvas.getWidth() / 4.0f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(0.0f, canvas.getHeight() / 2.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.0f, p);
                p.setColor(Color.WHITE);
                int crosshairs_radius = (int) (20 * scale + 0.5f); // convert dps to pixels

                canvas.drawLine(canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f - crosshairs_radius, canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f + crosshairs_radius, p);
                canvas.drawLine(canvas.getWidth() / 2.0f - crosshairs_radius, canvas.getHeight() / 2.0f, canvas.getWidth() / 2.0f + crosshairs_radius, canvas.getHeight() / 2.0f, p);
                break;
            case "preference_grid_crosshair":
                p.setColor(Color.WHITE);
                canvas.drawLine(canvas.getWidth() / 2.0f, 0.0f, canvas.getWidth() / 2.0f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(0.0f, canvas.getHeight() / 2.0f, canvas.getWidth() - 1.0f, canvas.getHeight() / 2.0f, p);
                break;
            case "preference_grid_golden_spiral_right":
            case "preference_grid_golden_spiral_left":
            case "preference_grid_golden_spiral_upside_down_right":
            case "preference_grid_golden_spiral_upside_down_left":
                canvas.save();
                switch (preference_grid_pref) {
                    case "preference_grid_golden_spiral_left":
                        canvas.scale(-1.0f, 1.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
                        break;
                    case "preference_grid_golden_spiral_right":
                        // no transformation needed
                        break;
                    case "preference_grid_golden_spiral_upside_down_left":
                        canvas.rotate(180.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
                        break;
                    case "preference_grid_golden_spiral_upside_down_right":
                        canvas.scale(1.0f, -1.0f, canvas.getWidth() * 0.5f, canvas.getHeight() * 0.5f);
                        break;
                }
                p.setColor(Color.WHITE);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(stroke_width);
                int fibb = 34;
                int fibb_n = 21;
                int left = 0, top = 0;
                int full_width = canvas.getWidth();
                int full_height = canvas.getHeight();
                int width = (int) (full_width * ((double) fibb_n) / (double) (fibb));
                int height = full_height;

                for (int count = 0; count < 2; count++) {
                    canvas.save();
                    draw_rect.set(left, top, left + width, top + height);
                    canvas.clipRect(draw_rect);
                    canvas.drawRect(draw_rect, p);
                    draw_rect.set(left, top, left + 2 * width, top + 2 * height);
                    canvas.drawOval(draw_rect, p);
                    canvas.restore();

                    int old_fibb = fibb;
                    fibb = fibb_n;
                    fibb_n = old_fibb - fibb;

                    left += width;
                    full_width = full_width - width;
                    width = full_width;
                    height = (int) (height * ((double) fibb_n) / (double) (fibb));

                    canvas.save();
                    draw_rect.set(left, top, left + width, top + height);
                    canvas.clipRect(draw_rect);
                    canvas.drawRect(draw_rect, p);
                    draw_rect.set(left - width, top, left + width, top + 2 * height);
                    canvas.drawOval(draw_rect, p);
                    canvas.restore();

                    old_fibb = fibb;
                    fibb = fibb_n;
                    fibb_n = old_fibb - fibb;

                    top += height;
                    full_height = full_height - height;
                    height = full_height;
                    width = (int) (width * ((double) fibb_n) / (double) (fibb));
                    left += full_width - width;

                    canvas.save();
                    draw_rect.set(left, top, left + width, top + height);
                    canvas.clipRect(draw_rect);
                    canvas.drawRect(draw_rect, p);
                    draw_rect.set(left - width, top - height, left + width, top + height);
                    canvas.drawOval(draw_rect, p);
                    canvas.restore();

                    old_fibb = fibb;
                    fibb = fibb_n;
                    fibb_n = old_fibb - fibb;

                    full_width = full_width - width;
                    width = full_width;
                    left -= width;
                    height = (int) (height * ((double) fibb_n) / (double) (fibb));
                    top += full_height - height;

                    canvas.save();
                    draw_rect.set(left, top, left + width, top + height);
                    canvas.clipRect(draw_rect);
                    canvas.drawRect(draw_rect, p);
                    draw_rect.set(left, top - height, left + 2 * width, top + height);
                    canvas.drawOval(draw_rect, p);
                    canvas.restore();

                    old_fibb = fibb;
                    fibb = fibb_n;
                    fibb_n = old_fibb - fibb;

                    full_height = full_height - height;
                    height = full_height;
                    top -= height;
                    width = (int) (width * ((double) fibb_n) / (double) (fibb));
                }

                canvas.restore();
                p.setStyle(Paint.Style.FILL); // reset

                break;
            case "preference_grid_golden_triangle_1":
            case "preference_grid_golden_triangle_2":
                p.setColor(Color.WHITE);
                double theta = Math.atan2(canvas.getWidth(), canvas.getHeight());
                double dist = canvas.getHeight() * Math.cos(theta);
                float dist_x = (float) (dist * Math.sin(theta));
                float dist_y = (float) (dist * Math.cos(theta));
                if (preference_grid_pref.equals("preference_grid_golden_triangle_1")) {
                    canvas.drawLine(0.0f, canvas.getHeight() - 1.0f, canvas.getWidth() - 1.0f, 0.0f, p);
                    canvas.drawLine(0.0f, 0.0f, dist_x, canvas.getHeight() - dist_y, p);
                    canvas.drawLine(canvas.getWidth() - 1.0f - dist_x, dist_y - 1.0f, canvas.getWidth() - 1.0f, canvas.getHeight() - 1.0f, p);
                } else {
                    canvas.drawLine(0.0f, 0.0f, canvas.getWidth() - 1.0f, canvas.getHeight() - 1.0f, p);
                    canvas.drawLine(canvas.getWidth() - 1.0f, 0.0f, canvas.getWidth() - 1.0f - dist_x, canvas.getHeight() - dist_y, p);
                    canvas.drawLine(dist_x, dist_y - 1.0f, 0.0f, canvas.getHeight() - 1.0f, p);
                }
                break;
            case "preference_grid_diagonals":
                p.setColor(Color.WHITE);
                canvas.drawLine(0.0f, 0.0f, canvas.getHeight() - 1.0f, canvas.getHeight() - 1.0f, p);
                canvas.drawLine(canvas.getHeight() - 1.0f, 0.0f, 0.0f, canvas.getHeight() - 1.0f, p);
                int diff = canvas.getWidth() - canvas.getHeight();
                if (diff > 0) {
                    canvas.drawLine(diff, 0.0f, diff + canvas.getHeight() - 1.0f, canvas.getHeight() - 1.0f, p);
                    canvas.drawLine(diff + canvas.getHeight() - 1.0f, 0.0f, diff, canvas.getHeight() - 1.0f, p);
                }
                break;
        }
    }

    private void drawCropGuides(Canvas canvas) {
        int i;
        Preview preview = this.main_activity.getPreview();
        CameraController cameraController = preview.getCameraController();
        if (preview.isVideo() || this.preview_size_wysiwyg_pref) {
            String string = SharedPrefs.getString(main_activity,PreferenceKeys.ShowCropGuidePreferenceKey, "crop_guide_none");
            if (cameraController != null && preview.getTargetRatio() > 0d && !string.equals("crop_guide_none")) {
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(this.stroke_width);
                this.p.setColor(Color.rgb(255, 235, 59));
                double d = -1.0d;
                string.hashCode();
                char c = 65535;
                int i2 = 1;
                switch (string.hashCode()) {
                    case -1272821505:
                        if (string.equals("crop_guide_1")) {
                            c = 0;
                            break;
                        }
                        break;
                    case -1272821504:
                        if (string.equals("crop_guide_2")) {
                            c = 1;
                            break;
                        }
                        break;
                    case 884214533:
                        if (string.equals("crop_guide_1.4")) {
                            c = 2;
                            break;
                        }
                        break;
                    case 884214534:
                        if (string.equals("crop_guide_1.5")) {
                            c = 3;
                            break;
                        }
                        break;
                    case 884215494:
                        if (string.equals("crop_guide_2.4")) {
                            c = 4;
                            break;
                        }
                        break;
                    case 1640846738:
                        if (string.equals("crop_guide_1.25")) {
                            c = 5;
                            break;
                        }
                        break;
                    case 1640846767:
                        if (string.equals("crop_guide_1.33")) {
                            c = 6;
                            break;
                        }
                        break;
                    case 1640846896:
                        if (string.equals("crop_guide_1.78")) {
                            c = 7;
                            break;
                        }
                        break;
                    case 1640846924:
                        if (string.equals("crop_guide_1.85")) {
                            c = 8;
                            break;
                        }
                        break;
                    case 1640876558:
                        if (string.equals("crop_guide_2.33")) {
                            c = 9;
                            break;
                        }
                        break;
                    case 1640876560:
                        if (string.equals("crop_guide_2.35")) {
                            c = 10;
                            break;
                        }
                        break;
                }
                switch (c) {
                    case 0:
                        d = close_level_angle;
                        break;
                    case 1:
                        d = 2.0d;
                        break;
                    case 2:
                        d = 1.4d;
                        break;
                    case 3:
                        d = 1.5d;
                        break;
                    case 4:
                        d = 2.4d;
                        break;
                    case 5:
                        d = 1.25d;
                        break;
                    case 6:
                        d = 1.33333333d;
                        break;
                    case 7:
                        d = 1.77777778d;
                        break;
                    case 8:
                        d = 1.85d;
                        break;
                    case 9:
                        d = 2.33333333d;
                        break;
                    case 10:
                        d = 2.3500612d;
                        break;
                }
                if (d > 0d && Math.abs(preview.getCurrentPreviewAspectRatio() - d) > 1.0E-5d) {
                    int width = canvas.getWidth() - 1;
                    int height = canvas.getHeight() - 1;
                    if (d > preview.getTargetRatio()) {
                        int width2 = (int) (((double) canvas.getWidth()) / (d * 2.0d));
                        i = (canvas.getHeight() / 2) - width2;
                        height = width2 + (canvas.getHeight() / 2);
                    } else {
                        int height2 = (int) ((((double) canvas.getHeight()) * d) / 2.0d);
                        width = (canvas.getWidth() / 2) + height2;
                        i2 = (canvas.getWidth() / 2) - height2;
                        i = 1;
                    }
                    canvas.drawRect((float) i2, (float) i, (float) width, (float) height, this.p);
                }
                this.p.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void onDrawInfoLines(Canvas canvas, final int top_x, final int top_y, final int bottom_y, long time_ms) {
        Preview preview = main_activity.getPreview();
        CameraController camera_controller = preview.getCameraController();
        int ui_rotation = preview.getUIRotation();

        // set up text etc for the multiple lines of "info" (time, free mem, etc)
        p.setTextSize(16 * scale + 0.5f); // convert dps to pixels
        p.setTextAlign(Paint.Align.LEFT);
        int location_x = top_x;
        int location_y = top_y;
        final int gap_x = (int) (8 * scale + 0.5f); // convert dps to pixels
        final int gap_y = (int) (0 * scale + 0.5f); // convert dps to pixels
        final int icon_gap_y = (int) (2 * scale + 0.5f); // convert dps to pixels
        if (ui_rotation == 90 || ui_rotation == 270) {
            int diff = canvas.getWidth() - canvas.getHeight();
            location_x += diff / 2;
            location_y -= diff / 2;
        }
        if (ui_rotation == 90) {
            location_y = canvas.getHeight() - location_y - (int) (20 * scale + 0.5f);
        }
        boolean align_right = false;
        if (ui_rotation == 180) {
            location_x = canvas.getWidth() - location_x;
            p.setTextAlign(Paint.Align.RIGHT);
            align_right = true;
        }


        int first_line_height = 0;
        int first_line_xshift = 0;


//        this.main_activity.runOnUiThread(new Runnable() {
//            public void run() {
//                applicationInterface.drawStamp(canvas, p);
//            }
//        });

        //TODO ENABLE STAMP
//        applicationInterface.drawStamp(canvas, p);

//        if (show_time_pref) {
//            if (current_time_string == null || time_ms / 1000 > last_current_time_time / 1000) {
//                // avoid creating a new calendar object every time
//                if (calendar == null)
//                    calendar = Calendar.getInstance();
//                else
//                    calendar.setTimeInMillis(time_ms);
//
//                current_time_string = dateFormatTimeInstance.format(calendar.getTime());
//                //current_time_string = DateUtils.formatDateTime(getContext(), c.getTimeInMillis(), DateUtils.FORMAT_SHOW_TIME);
//                last_current_time_time = time_ms;
//            }
//            // n.b., DateFormat.getTimeInstance() ignores user preferences such as 12/24 hour or date format, but this is an Android bug.
//            // Whilst DateUtils.formatDateTime doesn't have that problem, it doesn't print out seconds! See:
//            // http://stackoverflow.com/questions/15981516/simpledateformat-gettimeinstance-ignores-24-hour-format
//            // http://daniel-codes.blogspot.co.uk/2013/06/how-to-correctly-format-datetime.html
//            // http://code.google.com/p/android/issues/detail?id=42104
//            // update: now seems to be fixed
//            // also possibly related https://code.google.com/p/android/issues/detail?id=181201
//            //int height = applicationInterface.drawTextWithBackground(canvas, p, current_time_string, Color.WHITE, Color.BLACK, location_x, location_y, MyApplicationInterface.Alignment.ALIGNMENT_TOP);
//            if (text_bounds_time == null) {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "compute text_bounds_time");
//                text_bounds_time = new Rect();
//                // better to not use a fixed string like "00:00:00" as don't want to make assumptions - e.g., in 12 hour format we'll have the appended am/pm to account for!
//                Calendar calendar = Calendar.getInstance();
//                calendar.set(100, 0, 1, 10, 59, 59);
//                String bounds_time_string = dateFormatTimeInstance.format(calendar.getTime());
//                if (MyDebug.LOG)
//                    Log.d(TAG, "bounds_time_string:" + bounds_time_string);
//                p.getTextBounds(bounds_time_string, 0, bounds_time_string.length(), text_bounds_time);
//            }
//            first_line_xshift += text_bounds_time.width() + gap_x;
//            int height = applicationInterface.drawTextWithBackground(canvas, p, current_time_string, Color.WHITE, Color.BLACK, location_x, location_y, MyApplicationInterface.Alignment.ALIGNMENT_TOP, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE, text_bounds_time);
//            height += gap_y;
//            // don't update location_y yet, as we have time and cameraid shown on the same line
//            first_line_height = Math.max(first_line_height, height);
//        }
//        if (show_camera_id_pref && camera_controller != null) {
//            if (camera_id_string == null || time_ms > last_camera_id_time + 10000) {
//                // cache string for performance
//
//                camera_id_string = getContext().getResources().getString(R.string.camera_id) + ":" + preview.getCameraId(); // intentionally don't put a space
//                last_camera_id_time = time_ms;
//            }
//            if (text_bounds_camera_id == null) {
//                if (MyDebug.LOG)
//                    Log.d(TAG, "compute text_bounds_camera_id");
//                text_bounds_camera_id = new Rect();
//                p.getTextBounds(camera_id_string, 0, camera_id_string.length(), text_bounds_camera_id);
//            }
//            int xpos = align_right ? location_x - first_line_xshift : location_x + first_line_xshift;
//            int height = applicationInterface.drawTextWithBackground(canvas, p, camera_id_string, Color.WHITE, Color.BLACK, xpos, location_y, MyApplicationInterface.Alignment.ALIGNMENT_TOP, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE, text_bounds_camera_id);
//            height += gap_y;
//            // don't update location_y yet, as we have time and cameraid shown on the same line
//            first_line_height = Math.max(first_line_height, height);
//        }
        // update location_y for first line (time and camera id)
        if (ui_rotation == 90) {
            // upside-down portrait
            location_y -= first_line_height;
        } else {
            location_y += first_line_height;
        }

        if (camera_controller != null && !show_free_memory_pref) {
            if (last_free_memory_time == 0 || time_ms > last_free_memory_time + 10000) {
                // don't call this too often, for UI performance
                long free_mb = main_activity.getStorageUtils().freeMemory();
                if (free_mb >= 0) {
                    float new_free_memory_gb = free_mb / 1024.0f;
                    if (MyDebug.LOG) {
                        Log.d(TAG, "free_memory_gb: " + free_memory_gb);
                        Log.d(TAG, "new_free_memory_gb: " + new_free_memory_gb);
                    }
                    if (Math.abs(new_free_memory_gb - free_memory_gb) > 0.001f) {
                        free_memory_gb = new_free_memory_gb;
                        free_memory_gb_string = decimalFormat.format(free_memory_gb) + getContext().getResources().getString(R.string.gb_abbreviation);
                    }
                }
                last_free_memory_time = time_ms; // always set this, so that in case of free memory not being available, we aren't calling freeMemory() every frame
            }
            if (free_memory_gb >= 0.0f && free_memory_gb_string != null) {
                //int height = applicationInterface.drawTextWithBackground(canvas, p, free_memory_gb_string, Color.WHITE, Color.BLACK, location_x, location_y, MyApplicationInterface.Alignment.ALIGNMENT_TOP);
                if (text_bounds_free_memory == null) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "compute text_bounds_free_memory");
                    text_bounds_free_memory = new Rect();
                    p.getTextBounds(free_memory_gb_string, 0, free_memory_gb_string.length(), text_bounds_free_memory);
                }
                int height = applicationInterface.drawTextWithBackground(canvas, p, free_memory_gb_string, Color.WHITE, Color.BLACK, location_x, location_y, MyApplicationInterface.Alignment.ALIGNMENT_TOP, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE, text_bounds_free_memory);
                height += gap_y;
                if (ui_rotation == 90) {
                    location_y -= height;
                } else {
                    location_y += height;
                }
            }
        }

        // Now draw additional info on the lower left corner if needed
        int y_offset = (int) (27 * scale + 0.5f);
        p.setTextSize(24 * scale + 0.5f); // convert dps to pixels
        if (OSDLine1 != null && OSDLine1.length() > 0) {
            applicationInterface.drawTextWithBackground(canvas, p, OSDLine1,
                    Color.WHITE, Color.BLACK, location_x, bottom_y - y_offset,
                    MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE);
        }
        if (OSDLine2 != null && OSDLine2.length() > 0) {
            applicationInterface.drawTextWithBackground(canvas, p, OSDLine2,
                    Color.WHITE, Color.BLACK, location_x, bottom_y,
                    MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE);
        }
        p.setTextSize(16 * scale + 0.5f); // Restore text size

        if (camera_controller != null && !show_iso_pref) {
            if (iso_exposure_string == null || time_ms > last_iso_exposure_time + 500) {
                iso_exposure_string = "";
                if (camera_controller.captureResultHasIso()) {
                    int iso = camera_controller.captureResultIso();
                    if (iso_exposure_string.length() > 0)
                        iso_exposure_string += " ";
                    iso_exposure_string += preview.getISOString(iso);
                }
                if (camera_controller.captureResultHasExposureTime()) {
                    long exposure_time = camera_controller.captureResultExposureTime();
                    if (iso_exposure_string.length() > 0)
                        iso_exposure_string += " ";
                    iso_exposure_string += preview.getExposureTimeString(exposure_time);
                }
                if (preview.isVideoRecording() && camera_controller.captureResultHasFrameDuration()) {
                    long frame_duration = camera_controller.captureResultFrameDuration();
                    if (iso_exposure_string.length() > 0)
                        iso_exposure_string += " ";
                    iso_exposure_string += preview.getFrameDurationString(frame_duration);
                }
                /*if( camera_controller.captureResultHasAperture() ) {
                    float aperture = camera_controller.captureResultAperture();
                    if( iso_exposure_string.length() > 0 )
                        iso_exposure_string += " F";
                    iso_exposure_string += decimal_format_1dp_force0.format(aperture);
                }*/

                is_scanning = false;
                if (camera_controller.captureResultIsAEScanning()) {
                    // only show as scanning if in auto ISO mode (problem on Nexus 6 at least that if we're in manual ISO mode, after pausing and
                    // resuming, the camera driver continually reports CONTROL_AE_STATE_SEARCHING)
                    String value = SharedPrefs.getString(main_activity,PreferenceKeys.ISOPreferenceKey, CameraController.ISO_DEFAULT);
                    if (value.equals("auto")) {
                        is_scanning = true;
                    }
                }

                last_iso_exposure_time = time_ms;
            }

            if (iso_exposure_string.length() > 0) {
                int text_color = Color.rgb(255, 235, 59); // Yellow 500
                if (is_scanning) {
                    // we only change the color if ae scanning is at least a certain time, otherwise we get a lot of flickering of the color
                    if (ae_started_scanning_ms == -1) {
                        ae_started_scanning_ms = time_ms;
                    } else if (time_ms - ae_started_scanning_ms > 500) {
                        text_color = Color.rgb(244, 67, 54); // Red 500
                    }
                } else {
                    ae_started_scanning_ms = -1;
                }
                // can't cache the bounds rect, as the width may change significantly as the ISO or exposure values change
                int height = applicationInterface.drawTextWithBackground(canvas, p, iso_exposure_string, text_color, Color.BLACK, location_x, location_y, MyApplicationInterface.Alignment.ALIGNMENT_TOP, ybounds_text, MyApplicationInterface.Shadow.SHADOW_OUTLINE);
                height += gap_y;
                // only move location_y if we actually print something (because on old camera API, even if the ISO option has
                // been enabled, we'll never be able to display the on-screen ISO)
                if (ui_rotation == 90) {
                    location_y -= height;
                } else {
                    location_y += height;
                }
            }
        }

        // padding to align with earlier text
        final int flash_padding = (int) (1 * scale + 0.5f); // convert dps to pixels

//        if( camera_controller != null ) {
//            // draw info icons
//
//            int location_x2 = location_x - flash_padding;
//            final int icon_size = (int) (16 * scale + 0.5f); // convert dps to pixels
//            if( ui_rotation == 180 ) {
//                location_x2 = location_x - icon_size + flash_padding;
//            }
//
////            if( store_location_pref ) {
////                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
////                p.setStyle(Paint.Style.FILL);
////                p.setColor(Color.BLACK);
////                p.setAlpha(64);
////                canvas.drawRect(icon_dest, p);
////                p.setAlpha(255);
////
////                Location location = applicationInterface.getLocation(locationInfo);
////                if( location != null ) {
////                    canvas.drawBitmap(location_bitmap, null, icon_dest, p);
////                    int location_radius = icon_size / 10;
////                    int indicator_x = location_x2 + icon_size - (int)(location_radius*1.5);
////                    int indicator_y = location_y + (int)(location_radius*1.5);
////                    p.setColor(locationInfo.LocationWasCached() ? Color.rgb(127, 127, 127) :
////                            location.getAccuracy() < 25.01f ? Color.rgb(37, 155, 36) :
////                                    Color.rgb(255, 235, 59)); // Green 500 or Yellow 500
////                    canvas.drawCircle(indicator_x, indicator_y, location_radius, p);
////                }
////                else {
////                    canvas.drawBitmap(location_off_bitmap, null, icon_dest, p);
////                }
////
////                if( ui_rotation == 180 ) {
////                    location_x2 -= icon_size + flash_padding;
////                }
////                else {
////                    location_x2 += icon_size + flash_padding;
////                }
////            }
//
////            if(
////                    is_raw_pref &&
////                            preview.supportsRaw()
////                // RAW can be enabled, even if it isn't available for this camera (e.g., user enables RAW for back camera, but then
////                // switches to front camera which doesn't support it)
////            ) {
////                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
////                p.setStyle(Paint.Style.FILL);
////                p.setColor(Color.BLACK);
////                p.setAlpha(64);
////                canvas.drawRect(icon_dest, p);
////                p.setAlpha(255);
////                canvas.drawBitmap(is_raw_only_pref ? raw_only_bitmap : raw_jpeg_bitmap, null, icon_dest, p);
////
////                if( ui_rotation == 180 ) {
////                    location_x2 -= icon_size + flash_padding;
////                }
////                else {
////                    location_x2 += icon_size + flash_padding;
////                }
////            }
//
////            if( is_face_detection_pref && preview.supportsFaceDetection() ) {
////                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
////                p.setStyle(Paint.Style.FILL);
////                p.setColor(Color.BLACK);
////                p.setAlpha(64);
////                canvas.drawRect(icon_dest, p);
////                p.setAlpha(255);
////                canvas.drawBitmap(face_detection_bitmap, null, icon_dest, p);
////
////                if( ui_rotation == 180 ) {
////                    location_x2 -= icon_size + flash_padding;
////                }
////                else {
////                    location_x2 += icon_size + flash_padding;
////                }
////            }
//
////            if( auto_stabilise_pref && preview.hasLevelAngleStable() ) { // auto-level is supported for photos taken in video mode
////                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
////                p.setStyle(Paint.Style.FILL);
////                p.setColor(Color.BLACK);
////                p.setAlpha(64);
////                canvas.drawRect(icon_dest, p);
////                p.setAlpha(255);
////                canvas.drawBitmap(auto_stabilise_bitmap, null, icon_dest, p);
////
////                if( ui_rotation == 180 ) {
////                    location_x2 -= icon_size + flash_padding;
////                }
////                else {
////                    location_x2 += icon_size + flash_padding;
////                }
////            }
//
//            if( (
//                    photoMode == MyApplicationInterface.PhotoMode.DRO ||
//                            photoMode == MyApplicationInterface.PhotoMode.HDR ||
//                            photoMode == MyApplicationInterface.PhotoMode.Panorama ||
//                            photoMode == MyApplicationInterface.PhotoMode.ExpoBracketing ||
//                            photoMode == MyApplicationInterface.PhotoMode.FocusBracketing ||
//                            photoMode == MyApplicationInterface.PhotoMode.FastBurst ||
//                            photoMode == MyApplicationInterface.PhotoMode.NoiseReduction
//            ) &&
//                    !applicationInterface.isVideoPref() ) { // these photo modes not supported for video mode
//                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
//                p.setStyle(Paint.Style.FILL);
//                p.setColor(Color.BLACK);
//                p.setAlpha(64);
//                canvas.drawRect(icon_dest, p);
//                p.setAlpha(255);
//                Bitmap bitmap = photoMode == MyApplicationInterface.PhotoMode.DRO ? dro_bitmap :
//                        photoMode == MyApplicationInterface.PhotoMode.HDR ? hdr_bitmap :
//                                photoMode == MyApplicationInterface.PhotoMode.Panorama ? panorama_bitmap :
//                                        photoMode == MyApplicationInterface.PhotoMode.ExpoBracketing ? expo_bitmap :
//                                                photoMode == MyApplicationInterface.PhotoMode.FocusBracketing ? focus_bracket_bitmap :
//                                                        photoMode == MyApplicationInterface.PhotoMode.FastBurst ? burst_bitmap :
//                                                                photoMode == MyApplicationInterface.PhotoMode.NoiseReduction ? nr_bitmap :
//                                                                        null;
//                if( bitmap != null ) {
//                    if( photoMode == MyApplicationInterface.PhotoMode.NoiseReduction && applicationInterface.getNRModePref() == ApplicationInterface.NRModePref.NRMODE_LOW_LIGHT ) {
//                        p.setColorFilter(new PorterDuffColorFilter(Color.rgb(255, 235, 59), PorterDuff.Mode.SRC_IN)); // Yellow 500
//                    }
//                    canvas.drawBitmap(bitmap, null, icon_dest, p);
//                    p.setColorFilter(null);
//
//                    if( ui_rotation == 180 ) {
//                        location_x2 -= icon_size + flash_padding;
//                    }
//                    else {
//                        location_x2 += icon_size + flash_padding;
//                    }
//                }
//            }
//
//            // photo-stamp is supported for photos taken in video mode
//            // but it isn't supported in RAW-only mode
//            if( has_stamp_pref && !( is_raw_only_pref && preview.supportsRaw() ) ) {
//                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
//                p.setStyle(Paint.Style.FILL);
//                p.setColor(Color.BLACK);
//                p.setAlpha(64);
//                canvas.drawRect(icon_dest, p);
//                p.setAlpha(255);
//                canvas.drawBitmap(photostamp_bitmap, null, icon_dest, p);
//
//                if( ui_rotation == 180 ) {
//                    location_x2 -= icon_size + flash_padding;
//                }
//                else {
//                    location_x2 += icon_size + flash_padding;
//                }
//            }
//
//            if( !is_audio_enabled_pref && applicationInterface.isVideoPref() ) {
//                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
//                p.setStyle(Paint.Style.FILL);
//                p.setColor(Color.BLACK);
//                p.setAlpha(64);
//                canvas.drawRect(icon_dest, p);
//                p.setAlpha(255);
//                canvas.drawBitmap(audio_disabled_bitmap, null, icon_dest, p);
//
//                if( ui_rotation == 180 ) {
//                    location_x2 -= icon_size + flash_padding;
//                }
//                else {
//                    location_x2 += icon_size + flash_padding;
//                }
//            }
//
//            // icons for slow motion, time lapse or high speed video
//            if( Math.abs(capture_rate_factor - 1.0f) > 1.0e-5 && applicationInterface.isVideoPref() ) {
//                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
//                p.setStyle(Paint.Style.FILL);
//                p.setColor(Color.BLACK);
//                p.setAlpha(64);
//                canvas.drawRect(icon_dest, p);
//                p.setAlpha(255);
//                canvas.drawBitmap(capture_rate_factor < 1.0f ? slow_motion_bitmap : time_lapse_bitmap, null, icon_dest, p);
//
//                if( ui_rotation == 180 ) {
//                    location_x2 -= icon_size + flash_padding;
//                }
//                else {
//                    location_x2 += icon_size + flash_padding;
//                }
//            }
//            else if( is_high_speed && applicationInterface.isVideoPref() ) {
//                icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
//                p.setStyle(Paint.Style.FILL);
//                p.setColor(Color.BLACK);
//                p.setAlpha(64);
//                canvas.drawRect(icon_dest, p);
//                p.setAlpha(255);
//                canvas.drawBitmap(high_speed_fps_bitmap, null, icon_dest, p);
//
//                if( ui_rotation == 180 ) {
//                    location_x2 -= icon_size + flash_padding;
//                }
//                else {
//                    location_x2 += icon_size + flash_padding;
//                }
//            }
//
//            if( time_ms > last_need_flash_indicator_time + 100 ) {
//                need_flash_indicator = false;
//                String flash_value = preview.getCurrentFlashValue();
//                // note, flash_frontscreen_auto not yet support for the flash symbol (as camera_controller.needsFlash() only returns info on the built-in actual flash, not frontscreen flash)
//                if( flash_value != null &&
//                        ( flash_value.equals("flash_on")
//                                || ( (flash_value.equals("flash_auto") || flash_value.equals("flash_red_eye")) && camera_controller.needsFlash() )
//                                || camera_controller.needsFrontScreenFlash() ) &&
//                        !applicationInterface.isVideoPref() ) { // flash-indicator not supported for photos taken in video mode
//                    need_flash_indicator = true;
//                }
//
//                last_need_flash_indicator_time = time_ms;
//            }
//            if( need_flash_indicator ) {
//                if( needs_flash_time != -1 ) {
//                    final long fade_ms = 500;
//                    float alpha = (time_ms - needs_flash_time)/(float)fade_ms;
//                    if( time_ms - needs_flash_time >= fade_ms )
//                        alpha = 1.0f;
//                    icon_dest.set(location_x2, location_y, location_x2 + icon_size, location_y + icon_size);
//
//					/*if( MyDebug.LOG )
//						Log.d(TAG, "alpha: " + alpha);*/
//                    p.setStyle(Paint.Style.FILL);
//                    p.setColor(Color.BLACK);
//                    p.setAlpha((int)(64*alpha));
//                    canvas.drawRect(icon_dest, p);
//                    p.setAlpha((int)(255*alpha));
//                    canvas.drawBitmap(flash_bitmap, null, icon_dest, p);
//                    p.setAlpha(255);
//                }
//                else {
//                    needs_flash_time = time_ms;
//                }
//            }
//            else {
//                needs_flash_time = -1;
//            }
//
//            if( ui_rotation == 90 ) {
//                location_y -= icon_gap_y;
//            }
//            else {
//                location_y += (icon_size+icon_gap_y);
//            }
//        }

//        if (camera_controller != null) {
//            // draw histogram
//            if (preview.isPreviewBitmapEnabled()) {
//                int[] histogram = preview.getHistogram();
//                if (histogram != null) {
//					/*if( MyDebug.LOG )
//						Log.d(TAG, "histogram length: " + histogram.length);*/
//                    final int histogram_width = (int) (histogram_width_dp * scale + 0.5f); // convert dps to pixels
//                    final int histogram_height = (int) (histogram_height_dp * scale + 0.5f); // convert dps to pixels
//                    // n.b., if changing the histogram_height, remember to update focus_seekbar and
//                    // focus_bracketing_target_seekbar margins in activity_main.xml
//                    int location_x2 = location_x - flash_padding;
//                    if (ui_rotation == 180) {
//                        location_x2 = location_x - histogram_width + flash_padding;
//                    }
//                    icon_dest.set(location_x2 - flash_padding, location_y, location_x2 - flash_padding + histogram_width, location_y + histogram_height);
//                    if (ui_rotation == 90) {
//                        icon_dest.top -= histogram_height;
//                        icon_dest.bottom -= histogram_height;
//                    }
//
//                    p.setStyle(Paint.Style.FILL);
//                    p.setColor(Color.argb(64, 0, 0, 0));
//                    canvas.drawRect(icon_dest, p);
//
//                    int max = 0;
//                    for (int value : histogram) {
//                        max = Math.max(max, value);
//                    }
//
//                    if (histogram.length == 256 * 3) {
//                        int c = 0;
//
//						/* For overlapping rgb, we'll have:
//							(1, (1-a2).(1-a1).a0.r, (1-a2).a1.g, a2.b)
//						   If we wanted to have the alpha scaling the same (i.e., same r, g, b values
//						   if r=g=b, then this gives:
//						       a2 = 1/[2+1/a0]
//                               a1 = 1 - a2/[a0.(1-a2)]
//                           However this then means that for non-overlapping colours, red is too
//                           strong whilst blue is too weak, so we instead adjust to:
//                               a0' = (a0+a1)/2
//                               a1' = a1
//                               a2' = (a1+a2)/2
//						 */
//						/*final int a0 = 255;
//						final int a1 = 128;
//						final int a2 = 85;*/
//                        //final int a0 = 191;
//                        final int a0 = 151;
//                        final int a1 = 110;
//                        //final int a2 = 77;
//                        final int a2 = 94;
//						/*final int a0 = 128;
//						final int a1 = 85;
//						final int a2 = 64;*/
//                        final int r = 255;
//                        final int g = 255;
//                        final int b = 255;
//
//                        for (int i = 0; i < 256; i++)
//                            temp_histogram_channel[i] = histogram[c++];
//                        p.setColor(Color.argb(a0, r, 0, 0));
//                        drawHistogramChannel(canvas, temp_histogram_channel, max);
//
//                        for (int i = 0; i < 256; i++)
//                            temp_histogram_channel[i] = histogram[c++];
//                        p.setColor(Color.argb(a1, 0, g, 0));
//                        drawHistogramChannel(canvas, temp_histogram_channel, max);
//
//                        for (int i = 0; i < 256; i++)
//                            temp_histogram_channel[i] = histogram[c++];
//                        p.setColor(Color.argb(a2, 0, 0, b));
//                        drawHistogramChannel(canvas, temp_histogram_channel, max);
//                    } else {
//                        p.setColor(Color.argb(192, 255, 255, 255));
//                        drawHistogramChannel(canvas, histogram, max);
//                    }
//                }
//            }
//        }


    }

    private void drawHistogramChannel(Canvas canvas, int[] iArr, int i) {
        this.path.reset();
        this.path.moveTo((float) this.icon_dest.left, (float) this.icon_dest.bottom);
        for (int i2 = 0; i2 < iArr.length; i2++) {
            this.path.lineTo((float) (this.icon_dest.left + ((int) ((((double) i2) / ((double) iArr.length)) * ((double) this.icon_dest.width())))), (float) (this.icon_dest.bottom - ((iArr[i2] * this.icon_dest.height()) / i)));
        }
        this.path.lineTo((float) this.icon_dest.right, (float) this.icon_dest.bottom);
        this.path.close();
        canvas.drawPath(this.path, this.p);
    }

    public static String formatLevelAngle(double d) {
        String format = decimalFormat.format(d);
        return Math.abs(d) < 0.1d ? format.replaceAll("^-(?=0(.0*)?$)", "") : format;
    }

    private void drawUI(Canvas canvas, long time_ms) {
        Preview preview = main_activity.getPreview();
        CameraController camera_controller = preview.getCameraController();
        int ui_rotation = preview.getUIRotation();
        MainUI.UIPlacement ui_placement = main_activity.getMainUI().getUIPlacement();
        boolean has_level_angle = preview.hasLevelAngle();
        double level_angle = preview.getLevelAngle();
        boolean has_geo_direction = preview.hasGeoDirection();
        double geo_direction = preview.getGeoDirection();
        int text_base_y = 0;

        canvas.save();
        canvas.rotate(ui_rotation, canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f);

        if (camera_controller != null && !preview.isPreviewPaused()) {
			/*canvas.drawText("PREVIEW", canvas.getWidth() / 2,
					canvas.getHeight() / 2, p);*/
            int gap_y = (int) (20 * scale + 0.5f); // convert dps to pixels
            int text_y = (int) (16 * scale + 0.5f); // convert dps to pixels
            boolean avoid_ui = false;
            // fine tuning to adjust placement of text with respect to the GUI, depending on orientation
            if (ui_placement == MainUI.UIPlacement.UIPLACEMENT_TOP && (ui_rotation == 0 || ui_rotation == 180)) {
                text_base_y = canvas.getHeight() - (int) (0.1 * gap_y);
                avoid_ui = true;
            } else if (ui_rotation == (ui_placement == MainUI.UIPlacement.UIPLACEMENT_RIGHT ? 0 : 180)) {
                text_base_y = canvas.getHeight() - (int) (0.1 * gap_y);
                avoid_ui = true;
            } else if (ui_rotation == (ui_placement == MainUI.UIPlacement.UIPLACEMENT_RIGHT ? 180 : 0)) {
                text_base_y = canvas.getHeight() - (int) (2.5 * gap_y); // leave room for GUI icons
            } else if (ui_rotation == 90 || ui_rotation == 270) {
                // ui_rotation 90 is upside down portrait
                // 270 is portrait

                if (last_take_photo_top_time == 0 || time_ms > last_take_photo_top_time + 1000) {
                    /*if( MyDebug.LOG )
                        Log.d(TAG, "update cached take_photo_top");*/
                    // don't call this too often, for UI performance (due to calling View.getLocationOnScreen())
                    View view = main_activity.findViewById(R.id.take_photo);
                    // align with "top" of the take_photo button, but remember to take the rotation into account!
                    int view_left = getViewOnScreenX(view);
                    preview.getView().getLocationOnScreen(gui_location);
                    int this_left = gui_location[0];
                    take_photo_top = view_left - this_left;

                    last_take_photo_top_time = time_ms;
                    /*if( MyDebug.LOG ) {
                        Log.d(TAG, "view_left: " + view_left);
                        Log.d(TAG, "this_left: " + this_left);
                        Log.d(TAG, "take_photo_top: " + take_photo_top);
                    }*/
                }

                // diff_x is the difference from the centre of the canvas to the position we want
                int diff_x = take_photo_top - canvas.getWidth() / 2;

				/*if( MyDebug.LOG ) {
					Log.d(TAG, "view left: " + view_left);
					Log.d(TAG, "this left: " + this_left);
					Log.d(TAG, "canvas is " + canvas.getWidth() + " x " + canvas.getHeight());
                    Log.d(TAG, "compare offset_x: " + (preview.getView().getRootView().getRight()/2 - diff_x)/scale);
				}*/

                // diff_x is the difference from the centre of the canvas to the position we want
                // assumes canvas is centered
                // avoids calling getLocationOnScreen for performance
                /*int offset_x = (int) (124 * scale + 0.5f); // convert dps to pixels
                // offset_x should be enough such that on-screen level angle (this is the lowest display on-screen text) does not
                // interfere with take photo icon when using at least a 16:9 preview aspect ratio
                // should correspond to the logged "compare offset_x" above
                int diff_x = preview.getView().getRootView().getRight()/2 - offset_x;
                */

                int max_x = canvas.getWidth();
                if (ui_rotation == 90) {
                    // so we don't interfere with the top bar info (datetime, free memory, ISO) when upside down
                    max_x -= (int) (2.5 * gap_y);
                }
				/*if( MyDebug.LOG ) {
					Log.d(TAG, "root view right: " + preview.getView().getRootView().getRight());
					Log.d(TAG, "diff_x: " + diff_x);
					Log.d(TAG, "canvas.getWidth()/2 + diff_x: " + (canvas.getWidth()/2+diff_x));
					Log.d(TAG, "max_x: " + max_x);
				}*/
                if (canvas.getWidth() / 2 + diff_x > max_x) {
                    // in case goes off the size of the canvas, for "black bar" cases (when preview aspect ratio < screen aspect ratio)
                    diff_x = max_x - canvas.getWidth() / 2;
                }
                text_base_y = canvas.getHeight() / 2 + diff_x - (int) (0.5 * gap_y);
            }

//            if( avoid_ui ) {
//                // avoid parts of the UI
//                View view = main_activity.findViewById(R.id.focus_seekbar);
//                if(view.getVisibility() == View.VISIBLE ) {
//                    text_base_y -= view.getHeight();
//                }
//                view = main_activity.findViewById(R.id.focus_bracketing_target_seekbar);
//                if(view.getVisibility() == View.VISIBLE ) {
//                    text_base_y -= view.getHeight();
//                }
//                /*view = main_activity.findViewById(R.id.sliders_container);
//                if(view.getVisibility() == View.VISIBLE ) {
//                    text_base_y -= view.getHeight();
//                }*/
//            }

            boolean draw_angle = has_level_angle && show_angle_pref;
            boolean draw_geo_direction = has_geo_direction && show_geo_direction_pref;
            if (draw_angle) {
                int color = Color.WHITE;
                p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
                int pixels_offset_x;
                if (draw_geo_direction) {
                    pixels_offset_x = -(int) (35 * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.LEFT);
                } else {
                    //p.setTextAlign(Paint.Align.CENTER);
                    // slightly better for performance to use Align.LEFT, due to avoid measureText() call in drawTextWithBackground()
                    pixels_offset_x = -(int) ((level_angle < 0 ? 16 : 14) * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.LEFT);
                }
                if (Math.abs(level_angle) <= close_level_angle) {
                    color = angle_highlight_color_pref;
                    p.setUnderlineText(true);
                }
                if (angle_string == null || time_ms > this.last_angle_string_time + 500) {
                    // update cached string
					/*if( MyDebug.LOG )
						Log.d(TAG, "update angle_string: " + angle_string);*/
                    last_angle_string_time = time_ms;
                    String number_string = formatLevelAngle(level_angle);
                    //String number_string = "" + level_angle;
                    angle_string = number_string + (char) 0x00B0;
                    cached_angle = level_angle;
                    //String angle_string = "" + level_angle;
                }
                //applicationInterface.drawTextWithBackground(canvas, p, angle_string, color, Color.BLACK, canvas.getWidth() / 2 + pixels_offset_x, text_base_y, MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, ybounds_text, true);
                if (text_bounds_angle_single == null) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "compute text_bounds_angle_single");
                    text_bounds_angle_single = new Rect();
                    String bounds_angle_string = "-9.0" + (char) 0x00B0;
                    p.getTextBounds(bounds_angle_string, 0, bounds_angle_string.length(), text_bounds_angle_single);
                }
                if (text_bounds_angle_double == null) {
                    if (MyDebug.LOG)
                        Log.d(TAG, "compute text_bounds_angle_double");
                    text_bounds_angle_double = new Rect();
                    String bounds_angle_string = "-45.0" + (char) 0x00B0;
                    p.getTextBounds(bounds_angle_string, 0, bounds_angle_string.length(), text_bounds_angle_double);
                }
                applicationInterface.drawTextWithBackground(canvas, p, angle_string, color, Color.BLACK, canvas.getWidth() / 2 + pixels_offset_x, text_base_y, MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, null, MyApplicationInterface.Shadow.SHADOW_OUTLINE, Math.abs(cached_angle) < 10.0 ? text_bounds_angle_single : text_bounds_angle_double);
                p.setUnderlineText(false);
            }
            if (draw_geo_direction) {
                int color = Color.WHITE;
                p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
                int pixels_offset_x;
                if (draw_angle) {
                    pixels_offset_x = (int) (10 * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.LEFT);
                } else {
                    //p.setTextAlign(Paint.Align.CENTER);
                    // slightly better for performance to use Align.LEFT, due to avoid measureText() call in drawTextWithBackground()
                    pixels_offset_x = -(int) (14 * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.LEFT);
                }
                float geo_angle = (float) Math.toDegrees(geo_direction);
                if (geo_angle < 0.0f) {
                    geo_angle += 360.0f;
                }
                String string = "" + Math.round(geo_angle) + (char) 0x00B0;
                applicationInterface.drawTextWithBackground(canvas, p, string, color, Color.BLACK, canvas.getWidth() / 2 + pixels_offset_x, text_base_y, MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, ybounds_text, MyApplicationInterface.Shadow.SHADOW_OUTLINE);
            }
            if (preview.isOnTimer()) {
                long remaining_time = (preview.getTimerEndTime() - time_ms + 999) / 1000;
                if (MyDebug.LOG)
                    Log.d(TAG, "remaining_time: " + remaining_time);
                if (remaining_time > 0) {
                    p.setTextSize(84 * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.CENTER);
                    String time_s;
                    if (remaining_time < 60) {
                        // simpler to just show seconds when less than a minute
                        time_s = "" + remaining_time;
                    } else {
                        time_s = getTimeStringFromSeconds(remaining_time);
                    }
                    applicationInterface.drawTextWithBackground(canvas, p, time_s, R.color.colorPrimary, R.color.colorPrimary, canvas.getWidth() / 2, canvas.getHeight() / 2); // Red 500
                }
            } else if (preview.isVideoRecording()) {
                long video_time = preview.getVideoTime();
                String time_s = getTimeStringFromSeconds(video_time / 1000);
            	/*if( MyDebug.LOG )
					Log.d(TAG, "video_time: " + video_time + " " + time_s);*/
                p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
                p.setTextAlign(Paint.Align.CENTER);
                int pixels_offset_y = 2 * text_y; // avoid overwriting the zoom
                int color = Color.rgb(244, 67, 54); // Red 500
                if (main_activity.isScreenLocked()) {
                    // writing in reverse order, bottom to top
                    applicationInterface.drawTextWithBackground(canvas, p, getContext().getResources().getString(R.string.screen_lock_message_2), color, Color.BLACK, canvas.getWidth() / 2, text_base_y - pixels_offset_y);
                    pixels_offset_y += text_y;
                    applicationInterface.drawTextWithBackground(canvas, p, getContext().getResources().getString(R.string.screen_lock_message_1), color, Color.BLACK, canvas.getWidth() / 2, text_base_y - pixels_offset_y);
                    pixels_offset_y += text_y;
                }
                if (!preview.isVideoRecordingPaused() || ((int) (time_ms / 500)) % 2 == 0) { // if video is paused, then flash the video time
                    applicationInterface.drawTextWithBackground(canvas, p, time_s, color, Color.BLACK, canvas.getWidth() / 2, text_base_y - pixels_offset_y);
                    pixels_offset_y += text_y;
                }
                if (show_video_max_amp_pref && !preview.isVideoRecordingPaused()) {
                    // audio amplitude
                    if (!this.has_video_max_amp || time_ms > this.last_video_max_amp_time + 50) {
                        has_video_max_amp = true;
                        int video_max_amp_prev1 = video_max_amp_prev2;
                        video_max_amp_prev2 = video_max_amp;
                        video_max_amp = preview.getMaxAmplitude();
                        last_video_max_amp_time = time_ms;
                        if (MyDebug.LOG) {
                            if (video_max_amp > 30000) {
                                Log.d(TAG, "max_amp: " + video_max_amp);
                            }
                            if (video_max_amp > 32767) {
                                Log.e(TAG, "video_max_amp greater than max: " + video_max_amp);
                            }
                        }
                        if (video_max_amp_prev2 > video_max_amp_prev1 && video_max_amp_prev2 > video_max_amp) {
                            // new peak
                            video_max_amp_peak = video_max_amp_prev2;
                        }
                        //video_max_amp_peak = Math.max(video_max_amp_peak, video_max_amp);
                    }
                    float amp_frac = video_max_amp / 32767.0f;
                    amp_frac = Math.max(amp_frac, 0.0f);
                    amp_frac = Math.min(amp_frac, 1.0f);
                    //applicationInterface.drawTextWithBackground(canvas, p, "" + max_amp, color, Color.BLACK, canvas.getWidth() / 2, text_base_y - pixels_offset_y);

                    pixels_offset_y += text_y; // allow extra space
                    int amp_width = (int) (160 * scale + 0.5f); // convert dps to pixels
                    int amp_height = (int) (10 * scale + 0.5f); // convert dps to pixels
                    int amp_x = (canvas.getWidth() - amp_width) / 2;
                    p.setColor(Color.WHITE);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(stroke_width);
                    canvas.drawRect(amp_x, text_base_y - pixels_offset_y, amp_x + amp_width, text_base_y - pixels_offset_y + amp_height, p);
                    p.setStyle(Paint.Style.FILL);
                    canvas.drawRect(amp_x, text_base_y - pixels_offset_y, amp_x + amp_frac * amp_width, text_base_y - pixels_offset_y + amp_height, p);
                    if (amp_frac < 1.0f) {
                        p.setColor(Color.BLACK);
                        p.setAlpha(64);
                        canvas.drawRect(amp_x + amp_frac * amp_width + 1, text_base_y - pixels_offset_y, amp_x + amp_width, text_base_y - pixels_offset_y + amp_height, p);
                        p.setAlpha(255);
                    }
                    if (video_max_amp_peak > video_max_amp) {
                        float peak_frac = video_max_amp_peak / 32767.0f;
                        peak_frac = Math.max(peak_frac, 0.0f);
                        peak_frac = Math.min(peak_frac, 1.0f);
                        p.setColor(Color.YELLOW);
                        p.setStyle(Paint.Style.STROKE);
                        p.setStrokeWidth(stroke_width);
                        canvas.drawLine(amp_x + peak_frac * amp_width, text_base_y - pixels_offset_y, amp_x + peak_frac * amp_width, text_base_y - pixels_offset_y + amp_height, p);
                        p.setColor(Color.WHITE);
                    }
                }
            } else if (taking_picture && capture_started) {
                if (camera_controller.isCapturingBurst()) {
                    int n_burst_taken = camera_controller.getNBurstTaken() + 1;
                    int n_burst_total = camera_controller.getBurstTotal();
                    p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.CENTER);
                    int pixels_offset_y = 2 * text_y; // avoid overwriting the zoom
                    if (ui_rotation == 0 && applicationInterface.getPhotoMode() == MyApplicationInterface.PhotoMode.FocusBracketing) {
                        // avoid clashing with the target focus bracketing seekbar in landscape orientation
                        pixels_offset_y = 5 * gap_y;
                    }
                    String text = getContext().getResources().getString(R.string.capturing) + " " + n_burst_taken;
                    if (n_burst_total > 0) {
                        text += " / " + n_burst_total;
                    }
                    applicationInterface.drawTextWithBackground(canvas, p, text, Color.WHITE, Color.BLACK, canvas.getWidth() / 2, text_base_y - pixels_offset_y);
                } else if (camera_controller.isManualISO()) {
                    // only show "capturing" text with time for manual exposure time >= 0.5s
                    long exposure_time = camera_controller.getExposureTime();
                    if (exposure_time >= 500000000L) {
                        if (((int) (time_ms / 500)) % 2 == 0) {
                            p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
                            p.setTextAlign(Paint.Align.CENTER);
                            int pixels_offset_y = 2 * text_y; // avoid overwriting the zoom
                            int color = Color.rgb(244, 67, 54); // Red 500
                            applicationInterface.drawTextWithBackground(canvas, p, getContext().getResources().getString(R.string.capturing), color, Color.BLACK, canvas.getWidth() / 2, text_base_y - pixels_offset_y);
                        }
                    }
                }
            } else if (image_queue_full) {
                if (((int) (time_ms / 500)) % 2 == 0) {
                    p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.CENTER);
                    int pixels_offset_y = 2 * text_y; // avoid overwriting the zoom
                    int n_images_to_save = applicationInterface.getImageSaver().getNRealImagesToSave();
                    String string = getContext().getResources().getString(R.string.processing) + " (" + n_images_to_save + " " + getContext().getResources().getString(R.string.remaining) + ")";
                    applicationInterface.drawTextWithBackground(canvas, p, string, Color.LTGRAY, Color.BLACK, canvas.getWidth() / 2, text_base_y - pixels_offset_y);
                }
            }

            if (preview.supportsZoom() && show_zoom_pref) {
                float zoom_ratio = preview.getZoomRatio();
                // only show when actually zoomed in
                if (zoom_ratio > 1.0f + 1.0e-5f) {
                    // Convert the dps to pixels, based on density scale
                    p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
                    p.setTextAlign(Paint.Align.CENTER);
                    applicationInterface.drawTextWithBackground(canvas, p, getContext().getResources().getString(R.string.zoom) + ": " + zoom_ratio + "x", Color.WHITE, Color.BLACK, canvas.getWidth() / 2, text_base_y - text_y, MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM, ybounds_text, MyApplicationInterface.Shadow.SHADOW_OUTLINE);
                }
            }

        } else if (camera_controller == null) {
			/*if( MyDebug.LOG ) {
				Log.d(TAG, "no camera!");
				Log.d(TAG, "width " + canvas.getWidth() + " height " + canvas.getHeight());
			}*/
            p.setColor(Color.WHITE);
            p.setTextSize(14 * scale + 0.5f); // convert dps to pixels
            p.setTextAlign(Paint.Align.CENTER);
            int pixels_offset = (int) (20 * scale + 0.5f); // convert dps to pixels
            if (preview.hasPermissions()) {
                if (preview.openCameraFailed()) {
                    canvas.drawText(getContext().getResources().getString(R.string.failed_to_open_camera_1), canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f, p);
                    canvas.drawText(getContext().getResources().getString(R.string.failed_to_open_camera_2), canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f + pixels_offset, p);
                    canvas.drawText(getContext().getResources().getString(R.string.failed_to_open_camera_3), canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f + 2 * pixels_offset, p);
                    // n.b., use applicationInterface.getCameraIdPref(), as preview.getCameraId() returns 0 if camera_controller==null
                    canvas.drawText(getContext().getResources().getString(R.string.camera_id) + ":" + applicationInterface.getCameraIdPref(), canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f + 3 * pixels_offset, p);
                }
            } else {
                canvas.drawText(getContext().getResources().getString(R.string.no_permission), canvas.getWidth() / 2.0f, canvas.getHeight() / 2.0f, p);
            }
            //canvas.drawRect(0.0f, 0.0f, 100.0f, 100.0f, p);
            //canvas.drawRGB(255, 0, 0);
            //canvas.drawRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), p);
        }

        int top_x = (int) (5 * scale + 0.5f); // convert dps to pixels
        int top_y = (int) (5 * scale + 0.5f); // convert dps to pixels
        View top_icon = main_activity.getMainUI().getTopIcon();
        if (top_icon != null) {
            if (last_top_icon_shift_time == 0 || time_ms > last_top_icon_shift_time + 1000) {
                // avoid computing every time, due to cost of calling View.getLocationOnScreen()
                /*if( MyDebug.LOG )
                    Log.d(TAG, "update cached top_icon_shift");*/
                int top_margin = getViewOnScreenX(top_icon) + top_icon.getWidth();
                preview.getView().getLocationOnScreen(gui_location);
                int preview_left = gui_location[0];
                this.top_icon_shift = top_margin - preview_left;
                /*if( MyDebug.LOG ) {
                    Log.d(TAG, "top_icon.getRotation(): " + top_icon.getRotation());
                    Log.d(TAG, "preview_left: " + preview_left);
                    Log.d(TAG, "top_margin: " + top_margin);
                    Log.d(TAG, "top_icon_shift: " + top_icon_shift);
                }*/

                last_top_icon_shift_time = time_ms;
            }

            if (this.top_icon_shift > 0) {
                if (ui_rotation == 90 || ui_rotation == 270) {
                    // portrait
                    top_y += top_icon_shift;
                } else {
                    // landscape
                    top_x += top_icon_shift;
                }
            }
        }

        {
            /*int focus_seekbars_margin_left_dp = 85;
            if( want_histogram )
                focus_seekbars_margin_left_dp += DrawPreview.histogram_height_dp;*/
            // 135 needed to make room for on-screen info lines in DrawPreview.onDrawInfoLines(), including the histogram
            // but we also need to take the top_icon_shift into account, for widescreen aspect ratios and "icons along top" UI placement
            int focus_seekbars_margin_left_dp = 135;
            int new_focus_seekbars_margin_left = (int) (focus_seekbars_margin_left_dp * scale + 0.5f); // convert dps to pixels
            if (top_icon_shift > 0) {
                //noinspection SuspiciousNameCombination
                new_focus_seekbars_margin_left += top_icon_shift;
            }

//            if( focus_seekbars_margin_left == -1 || new_focus_seekbars_margin_left != focus_seekbars_margin_left ) {
//                // we check whether focus_seekbars_margin_left has changed, in case there is a performance cost for setting layoutparams
//                this.focus_seekbars_margin_left = new_focus_seekbars_margin_left;
//                if( MyDebug.LOG )
//                    Log.d(TAG, "set focus_seekbars_margin_left to " + focus_seekbars_margin_left);
//
//                View view = main_activity.findViewById(R.id.focus_seekbar);
//                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams)view.getLayoutParams();
//                layoutParams.setMargins(focus_seekbars_margin_left, 0, 0, 0);
//                view.setLayoutParams(layoutParams);
//
//                view = main_activity.findViewById(R.id.focus_bracketing_target_seekbar);
//                layoutParams = (RelativeLayout.LayoutParams)view.getLayoutParams();
//                layoutParams.setMargins(focus_seekbars_margin_left, 0, 0, 0);
//                view.setLayoutParams(layoutParams);
//            }
        }

        int battery_x = top_x;
        int battery_y = top_y + (int) (5 * scale + 0.5f);
        int battery_width = (int) (5 * scale + 0.5f); // convert dps to pixels
        int battery_height = 4 * battery_width;
        if (ui_rotation == 90 || ui_rotation == 270) {
            int diff = canvas.getWidth() - canvas.getHeight();
            battery_x += diff / 2;
            battery_y -= diff / 2;
        }
        if (ui_rotation == 90) {
            battery_y = canvas.getHeight() - battery_y - battery_height;
        }
        if (ui_rotation == 180) {
            battery_x = canvas.getWidth() - battery_x - battery_width;
        }
        if (!show_battery_pref) {
            if (!this.has_battery_frac || time_ms > this.last_battery_time + 60000) {
                // only check periodically - unclear if checking is costly in any way
                // note that it's fine to call registerReceiver repeatedly - we pass a null receiver, so this is fine as a "one shot" use
                Intent batteryStatus = main_activity.registerReceiver(null, battery_ifilter);
                int battery_level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int battery_scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                has_battery_frac = true;
                battery_frac = battery_level / (float) battery_scale;
                last_battery_time = time_ms;
                if (MyDebug.LOG)
                    Log.d(TAG, "Battery status is " + battery_level + " / " + battery_scale + " : " + battery_frac);
            }
            //battery_frac = 0.2999f; // test
            boolean draw_battery = true;
            if (battery_frac <= 0.05f) {
                // flash icon at this low level
                draw_battery = (((time_ms / 1000)) % 2) == 0;
            }
            if (draw_battery) {
                p.setColor(battery_frac > 0.15f ? Color.rgb(37, 155, 36) : Color.rgb(244, 67, 54)); // Green 500 or Red 500
                p.setStyle(Paint.Style.FILL);
                canvas.drawRect(battery_x, battery_y + (1.0f - battery_frac) * (battery_height - 2), battery_x + battery_width, battery_y + battery_height, p);
                if (battery_frac < 1.0f) {
                    p.setColor(Color.BLACK);
                    p.setAlpha(64);
                    canvas.drawRect(battery_x, battery_y, battery_x + battery_width, battery_y + (1.0f - battery_frac) * (battery_height - 2), p);
                    p.setAlpha(255);
                }
            }
            top_x += (int) (10 * scale + 0.5f); // convert dps to pixels
        }

//        Log.e(TAG, "drawUI: onDrawInfoLines");
        onDrawInfoLines(canvas, top_x, top_y, text_base_y, time_ms);

        canvas.restore();
    }

    private void drawAngleLines(Canvas canvas, long j) {
        boolean z;
        Preview preview;
        boolean z2;
        boolean z3;
        int i;
        int i2;
        int i3;
        int i4;
        float f;
        int i5;
        float f2;
        float f3;
        int i6;
        int i7;
        float f4;
        int i8;
        int i9;
        int i10;
        Canvas canvas2 = canvas;
        Preview preview2 = this.main_activity.getPreview();
        CameraController cameraController = preview2.getCameraController();
        boolean hasLevelAngle = preview2.hasLevelAngle();
        if (this.photoMode == MyApplicationInterface.PhotoMode.Panorama) {
            z = !this.main_activity.getApplicationInterface().getGyroSensor().isRecording();
        } else {
            z = this.show_angle_line_pref;
        }
        boolean z4 = cameraController != null && !preview2.isPreviewPaused();
        if (!z4 || !hasLevelAngle || (!z && !this.show_pitch_lines_pref && !this.show_geo_direction_lines_pref)) {
            preview = preview2;
            z2 = hasLevelAngle;
            z3 = z4;
            i = -1;
        } else {
            int uIRotation = preview2.getUIRotation();
            double levelAngle = preview2.getLevelAngle();
            boolean hasPitchAngle = preview2.hasPitchAngle();
            double pitchAngle = preview2.getPitchAngle();
            boolean hasGeoDirection = preview2.hasGeoDirection();
            double geoDirection = preview2.getGeoDirection();
            int i11 = (int) ((((float) ((uIRotation == 90 || uIRotation == 270) ? 60 : 80)) * this.scale) + 0.5f);
            z3 = z4;
            double d = -preview2.getOrigLevelAngle();
            int rotation = this.main_activity.getWindowManager().getDefaultDisplay().getRotation();
            if (rotation == 1 || rotation == 3) {
                d -= 90.0d;
            }
            int width = canvas.getWidth() / 2;
            int height = canvas.getHeight() / 2;
            boolean z5 = hasLevelAngle && Math.abs(levelAngle) <= close_level_angle;
            if (z5) {
                i11 = (int) (((double) i11) * 1.2d);
            }
            canvas.save();
            float f5 = (float) d;
            float f6 = (float) width;
            float f7 = (float) height;
            canvas2.rotate(f5, f6, f7);
            float f8 = (this.scale * 0.5f) + 0.5f;
            this.p.setStyle(Paint.Style.FILL);
            if (!z || !preview2.hasLevelAngleStable()) {
                i4 = height;
                i2 = uIRotation;
                preview = preview2;
                z2 = hasLevelAngle;
                i3 = width;
            } else {
                this.p.setColor(-16777216);
                this.p.setAlpha(64);
                float f9 = (float) (width - i11);
                float f10 = f9 - f8;
                float f11 = f8 * 2.0f;
                i4 = height;
                z2 = hasLevelAngle;
                float f12 = (float) (width + i11);
                i3 = width;
                float f13 = f12 + f8;
                i2 = uIRotation;
                this.draw_rect.set(f10, f7 - f11, f13, f7 + f11);
                canvas2.drawRoundRect(this.draw_rect, f11, f11, this.p);
                float f14 = ((float) i11) / 2.0f;
                float f15 = f7 - f14;
                preview = preview2;
                float f16 = f10;
                float f17 = f14 + f7;
                float f18 = f11;
                this.draw_rect.set(f6 - f11, f15 - f8, f6 + f11, f17 + f8);
                canvas2.drawRoundRect(this.draw_rect, f8, f8, this.p);
                if (z5) {
                    this.p.setColor(this.angle_highlight_color_pref);
                } else {
                    this.p.setColor(-1);
                }
                this.p.setAlpha(160);
                this.draw_rect.set(f9, f7 - f8, f12, f7 + f8);
                canvas2.drawRoundRect(this.draw_rect, f8, f8, this.p);
                this.draw_rect.set(f6 - f8, f15, f6 + f8, f17);
                canvas2.drawRoundRect(this.draw_rect, f8, f8, this.p);
                if (z5) {
                    this.p.setColor(-16777216);
                    this.p.setAlpha(64);
                    this.draw_rect.set(f16, f7 - (7.0f * f8), f13, f7 - (3.0f * f8));
                    float f19 = f18;
                    canvas2.drawRoundRect(this.draw_rect, f19, f19, this.p);
                    this.p.setColor(this.angle_highlight_color_pref);
                    this.p.setAlpha(160);
                    this.draw_rect.set(f9, f7 - (6.0f * f8), f12, f7 - (f8 * 4.0f));
                    canvas2.drawRoundRect(this.draw_rect, f8, f8, this.p);
                }
            }
            updateCachedViewAngles(j);
            float f20 = this.view_angle_x_preview;
            float f21 = this.view_angle_y_preview;
            float width2 = (float) (((double) canvas.getWidth()) / (Math.tan(Math.toRadians(((double) f20) / 2.0d)) * 2.0d));
            float height2 = (float) (((double) canvas.getHeight()) / (Math.tan(Math.toRadians(((double) f21) / 2.0d)) * 2.0d));
            float sqrt = ((float) Math.sqrt((double) ((width2 * width2) + (height2 * height2)))) * preview.getZoomRatio();
            if (!hasPitchAngle || !this.show_pitch_lines_pref) {
                f = f8;
                i5 = i2;
            } else {
                int i12 = i2;
                int i13 = (int) ((((float) ((i12 == 90 || i12 == 270) ? 100 : 80)) * this.scale) + 0.5f);
                int i14 = preview.getZoomRatio() >= 2.0f ? 5 : 10;
                int i15 = -90;
                for (int i16 = 90; i15 <= i16; i16 = 90) {
                    double d2 = pitchAngle - ((double) i15);
                    if (Math.abs(d2) < 90.0d) {
                        this.p.setColor(-16777216);
                        this.p.setAlpha(64);
                        float f22 = (float) (i3 - i13);
                        float tan = (((float) Math.tan(Math.toRadians(d2))) * sqrt) + f7;
                        float f23 = f8 * 2.0f;
                        float f24 = tan - f23;
                        float f25 = (float) (i3 + i13);
                        i9 = i13;
                        int i17 = i12;
                        this.draw_rect.set(f22 - f8, f24, f25 + f8, tan + f23);
                        canvas2.drawRoundRect(this.draw_rect, f23, f23, this.p);
                        this.p.setColor(-1);
                        this.p.setTextAlign(Paint.Align.LEFT);
                        if (i15 == 0 && Math.abs(pitchAngle) < close_level_angle) {
                            this.p.setAlpha(255);
                        } else if (i15 == 90 && Math.abs(pitchAngle - 90.0d) < 3.0d) {
                            this.p.setAlpha(255);
                        } else if (i15 != -90 || Math.abs(pitchAngle + 90.0d) >= 3.0d) {
                            this.p.setAlpha(160);
                            this.draw_rect.set(f22, tan - f8, f25, tan + f8);
                            canvas2.drawRoundRect(this.draw_rect, f8, f8, this.p);
                            i8 = i15;
                            f4 = f8;
                            i10 = i17;
                            this.applicationInterface.drawTextWithBackground(canvas, this.p, "" + i15 + "°", this.p.getColor(), -16777216, (int) (f25 + (f8 * 4.0f)), (int) f24, MyApplicationInterface.Alignment.ALIGNMENT_CENTRE);
                        } else {
                            this.p.setAlpha(255);
                            this.draw_rect.set(f22, tan - f8, f25, tan + f8);
                            canvas2.drawRoundRect(this.draw_rect, f8, f8, this.p);
                            i8 = i15;
                            f4 = f8;
                            i10 = i17;
                            this.applicationInterface.drawTextWithBackground(canvas, this.p, "" + i15 + "°", this.p.getColor(), -16777216, (int) (f25 + (f8 * 4.0f)), (int) f24, MyApplicationInterface.Alignment.ALIGNMENT_CENTRE);
                        }
                        this.draw_rect.set(f22, tan - f8, f25, tan + f8);
                        canvas2.drawRoundRect(this.draw_rect, f8, f8, this.p);
                        i8 = i15;
                        f4 = f8;
                        i10 = i17;
                        this.applicationInterface.drawTextWithBackground(canvas, this.p, "" + i15 + "°", this.p.getColor(), -16777216, (int) (f25 + (f8 * 4.0f)), (int) f24, MyApplicationInterface.Alignment.ALIGNMENT_CENTRE);
                    } else {
                        i8 = i15;
                        i9 = i13;
                        f4 = f8;
                        i10 = i12;
                    }
                    i15 = i8 + i14;
                    i12 = i10;
                    i13 = i9;
                    f8 = f4;
                }
                f = f8;
                i5 = i12;
            }
            if (hasGeoDirection && hasPitchAngle && this.show_geo_direction_lines_pref) {
                int i18 = (int) ((((float) ((i5 == 90 || i5 == 270) ? 80 : 100)) * this.scale) + 0.5f);
                float degrees = (float) Math.toDegrees(geoDirection);
                int i19 = preview.getZoomRatio() >= 2.0f ? 5 : 10;
                int i20 = 0;
                while (i20 < 360) {
                    double d3 = (double) (((float) i20) - degrees);
                    while (d3 >= 360.0d) {
                        d3 -= 360.0d;
                    }
                    while (d3 < -360.0d) {
                        d3 += 360.0d;
                    }
                    if (d3 > 180.0d) {
                        d3 = -(360.0d - d3);
                    }
                    if (Math.abs(d3) < 90.0d) {
                        this.p.setColor(-16777216);
                        this.p.setAlpha(64);
                        float tan2 = (((float) Math.tan(Math.toRadians(d3))) * sqrt) + f6;
                        float f26 = f;
                        float f27 = f26 * 2.0f;
                        float f28 = (float) (i4 - i18);
                        f2 = sqrt;
                        float f29 = (float) (i4 + i18);
                        i7 = i18;
                        this.draw_rect.set(tan2 - f27, f28 - f26, tan2 + f27, f29 + f26);
                        canvas2.drawRoundRect(this.draw_rect, f27, f27, this.p);
                        this.p.setColor(-1);
                        this.p.setTextAlign(Paint.Align.CENTER);
                        this.p.setAlpha(160);
                        this.draw_rect.set(tan2 - f26, f28, tan2 + f26, f29);
                        canvas2.drawRoundRect(this.draw_rect, f26, f26, this.p);
                        f3 = f26;
                        i6 = i20;
                        this.applicationInterface.drawTextWithBackground(canvas, this.p, "" + i20 + "°", this.p.getColor(), -16777216, (int) tan2, (int) (f28 - (f26 * 4.0f)), MyApplicationInterface.Alignment.ALIGNMENT_BOTTOM);
                    } else {
                        i6 = i20;
                        f2 = sqrt;
                        i7 = i18;
                        f3 = f;
                    }
                    i20 = i6 + i19;
                    sqrt = f2;
                    i18 = i7;
                    f = f3;
                }
            }
            i = -1;
            this.p.setAlpha(255);
            this.p.setStyle(Paint.Style.FILL);
            canvas.restore();
        }
        if (z3 && this.auto_stabilise_pref && preview.hasLevelAngleStable() && !preview.isVideo()) {
            double levelAngle2 = preview.getLevelAngle();
            double d4 = levelAngle2;
            while (d4 < -90.0d) {
                d4 += 180.0d;
            }
            while (d4 > 90.0d) {
                d4 -= 180.0d;
            }
            double abs = Math.abs(Math.toRadians(d4));
            int width3 = canvas.getWidth();
            int height3 = canvas.getHeight();
            double d5 = (double) width3;
            double d6 = (double) height3;
            if (ImageSaver.autoStabiliseCrop(this.auto_stabilise_crop, abs, (Math.cos(abs) * d5) + (Math.sin(abs) * d6), (d5 * Math.sin(abs)) + (d6 * Math.cos(abs)), width3, height3, canvas.getWidth(), canvas.getHeight())) {
                int[] iArr = this.auto_stabilise_crop;
                int i21 = iArr[0];
                int i22 = iArr[1];
                canvas.save();
                canvas2.rotate((float) (-levelAngle2), (float) (canvas.getWidth() / 2), (float) (canvas.getHeight() / 2));
                if (!z2 || Math.abs(levelAngle2) > close_level_angle) {
                    this.p.setColor(i);
                } else {
                    this.p.setColor(this.angle_highlight_color_pref);
                }
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(this.stroke_width);
                canvas.drawRect(((float) (canvas.getWidth() - i21)) / 2.0f, ((float) (canvas.getHeight() - i22)) / 2.0f, ((float) (canvas.getWidth() + i21)) / 2.0f, ((float) (canvas.getHeight() + i22)) / 2.0f, this.p);
                canvas.restore();
                this.p.setStyle(Paint.Style.FILL);
            }
        }
    }

    private void doThumbnailAnimation(Canvas canvas, long j) {
        Preview preview = this.main_activity.getPreview();
        if (preview.getCameraController() != null && this.thumbnail_anim && this.last_thumbnail != null) {
            int uIRotation = preview.getUIRotation();
            long j2 = j - this.thumbnail_anim_start_ms;
            if (j2 > 500) {
                Log.d(TAG, "thumbnail_anim finished");
                this.thumbnail_anim = false;
                return;
            }
            this.thumbnail_anim_src_rect.left = 0.0f;
            this.thumbnail_anim_src_rect.top = 0.0f;
            this.thumbnail_anim_src_rect.right = (float) this.last_thumbnail.getWidth();
            this.thumbnail_anim_src_rect.bottom = (float) this.last_thumbnail.getHeight();
            View findViewById = this.main_activity.findViewById(R.id.img_gallery);
            float f = ((float) j2) / 500.0f;
            int left = findViewById.getLeft() + (findViewById.getWidth() / 2);
            float f2 = 1.0f - f;
            int height = (int) ((f2 * ((float) (canvas.getHeight() / 2))) + (((float) (findViewById.getTop() + (findViewById.getHeight() / 2))) * f));
            float width = (float) canvas.getWidth();
            float height2 = (float) canvas.getHeight();
            float width2 = (float) ((int) ((((float) (canvas.getWidth() / 2)) * f2) + (((float) left) * f)));
            float width3 = ((float) ((int) (width / ((((width / ((float) findViewById.getWidth())) - 1.0f) * f) + 1.0f)))) / 2.0f;
            this.thumbnail_anim_dst_rect.left = width2 - width3;
            float f3 = (float) height;
            float height3 = ((float) ((int) (height2 / ((f * ((height2 / ((float) findViewById.getHeight())) - 1.0f)) + 1.0f)))) / 2.0f;
            this.thumbnail_anim_dst_rect.top = f3 - height3;
            this.thumbnail_anim_dst_rect.right = width2 + width3;
            this.thumbnail_anim_dst_rect.bottom = f3 + height3;
            this.thumbnail_anim_matrix.setRectToRect(this.thumbnail_anim_src_rect, this.thumbnail_anim_dst_rect, Matrix.ScaleToFit.FILL);
            if (uIRotation == 90 || uIRotation == 270) {
                float width4 = ((float) this.last_thumbnail.getWidth()) / ((float) this.last_thumbnail.getHeight());
                this.thumbnail_anim_matrix.preScale(width4, 1.0f / width4, ((float) this.last_thumbnail.getWidth()) / 2.0f, ((float) this.last_thumbnail.getHeight()) / 2.0f);
            }
            this.thumbnail_anim_matrix.preRotate((float) uIRotation, ((float) this.last_thumbnail.getWidth()) / 2.0f, ((float) this.last_thumbnail.getHeight()) / 2.0f);
            canvas.drawBitmap(this.last_thumbnail, this.thumbnail_anim_matrix, this.p);
        }
    }

    private void doFocusAnimation(Canvas canvas, long j) {
        int i;
        int i2;
        float f;
        float f2;
        float f3;
        float f4;
        Preview preview = this.main_activity.getPreview();
        if (preview.getCameraController() == null || !this.continuous_focus_moving || this.taking_picture) {
            Canvas canvas2 = canvas;
        } else {
            long j2 = j - this.continuous_focus_moving_ms;
            if (j2 <= 1000) {
                float f5 = ((float) j2) / 1000.0f;
                float width = ((float) canvas.getWidth()) / 2.0f;
                float height = ((float) canvas.getHeight()) / 2.0f;
                float f6 = this.scale;
                float f7 = (f6 * 40.0f) + 0.5f;
                float f8 = (f6 * 60.0f) + 0.5f;
                if (f5 < 0.5f) {
                    float f9 = f5 * 2.0f;
                    f3 = (1.0f - f9) * f7;
                    f4 = f9 * f8;
                } else {
                    float f10 = (f5 - 0.5f) * 2.0f;
                    f3 = (1.0f - f10) * f8;
                    f4 = f10 * f7;
                }
                this.p.setColor(-1);
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(this.stroke_width);
                Canvas canvas3 = canvas;
                canvas3.drawCircle(width, height, f3 + f4, this.p);
                this.p.setStyle(Paint.Style.FILL);
            } else {
                Canvas canvas4 = canvas;
                clearContinuousFocusMove();
            }
        }
        if (preview.isFocusWaiting() || preview.isFocusRecentSuccess() || preview.isFocusRecentFailure()) {
            long timeSinceStartedAutoFocus = preview.timeSinceStartedAutoFocus();
            float f11 = this.scale;
            float f12 = (40.0f * f11) + 0.5f;
            float f13 = (f11 * 45.0f) + 0.5f;
            if (timeSinceStartedAutoFocus > 0) {
                float f14 = ((float) timeSinceStartedAutoFocus) / 500.0f;
                if (f14 > 1.0f) {
                    f14 = 1.0f;
                }
                if (f14 < 0.5f) {
                    float f15 = f14 * 2.0f;
                    f2 = (1.0f - f15) * f12;
                    f = f15 * f13;
                } else {
                    float f16 = (f14 - 0.5f) * 2.0f;
                    f2 = (1.0f - f16) * f13;
                    f = f16 * f12;
                }
                f12 = f2 + f;
            }
            int i3 = (int) f12;
            if (preview.isFocusRecentSuccess()) {
                this.p.setColor(Color.rgb(20, 231, 21));
            } else if (preview.isFocusRecentFailure()) {
                this.p.setColor(Color.rgb(244, 67, 54));
            } else {
                this.p.setColor(-1);
            }
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(this.stroke_width);
            if (preview.hasFocusArea()) {
                Pair<Integer, Integer> focusPos = preview.getFocusPos();
                i = ((Integer) focusPos.first).intValue();
                i2 = ((Integer) focusPos.second).intValue();
            } else {
                i = canvas.getWidth() / 2;
                i2 = canvas.getHeight() / 2;
            }
            float f17 = (float) (i - i3);
            float f18 = (float) (i2 - i3);
            float f19 = (float) i;
            float f20 = ((float) i3) * 0.5f;
            float f21 = f19 - f20;
            Canvas canvas5 = canvas;
            float f22 = f18;
            float f23 = f18;
            canvas5.drawLine(f17, f22, f21, f23, this.p);
            float f24 = f19 + f20;
            float f25 = (float) (i + i3);
            canvas5.drawLine(f24, f22, f25, f23, this.p);
            float f26 = (float) (i3 + i2);
            float f27 = f26;
            float f28 = f26;
            canvas5.drawLine(f17, f27, f21, f28, this.p);
            canvas5.drawLine(f24, f27, f25, f28, this.p);
            float f29 = (float) i2;
            float f30 = f29 - f20;
            float f31 = f17;
            float f32 = f17;
            canvas5.drawLine(f31, f18, f32, f30, this.p);
            float f33 = f29 + f20;
            canvas5.drawLine(f31, f33, f32, f26, this.p);
            float f34 = f25;
            float f35 = f25;
            canvas5.drawLine(f34, f18, f35, f30, this.p);
            canvas5.drawLine(f34, f33, f35, f26, this.p);
            this.p.setStyle(Paint.Style.FILL);
        }
    }

    public void onDrawPreview(Canvas canvas) {
        int i;
        GyroSensor gyroSensor;
        float f;
        Bitmap bitmap;
        Canvas canvas2 = canvas;
        if (!this.has_settings) {
            Log.d(TAG, "onDrawPreview: need to update settings");
            updateSettings();
        }
        Preview preview = this.main_activity.getPreview();
        CameraController cameraController = preview.getCameraController();
        int uIRotation = preview.getUIRotation();
        long currentTimeMillis = System.currentTimeMillis();
        char c = 0;
        boolean z = this.want_histogram || this.want_zebra_stripes || this.want_focus_peaking;
        if (z != preview.isPreviewBitmapEnabled()) {
            if (z) {
                preview.enablePreviewBitmap();
            } else {
                preview.disablePreviewBitmap();
            }
        }
        if (z) {
            if (this.want_histogram) {
                preview.enableHistogram(this.histogram_type);
            } else {
                preview.disableHistogram();
            }
            if (this.want_zebra_stripes) {
                preview.enableZebraStripes(this.zebra_stripes_threshold, this.zebra_stripes_color_foreground, this.zebra_stripes_color_background);
            } else {
                preview.disableZebraStripes();
            }
            if (this.want_focus_peaking) {
                preview.enableFocusPeaking();
            } else {
                preview.disableFocusPeaking();
            }
        }
        if (preview.usingCamera2API() && (cameraController == null || cameraController.shouldCoverPreview())) {
            this.p.setColor(-16777216);
            canvas.drawRect(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight(), this.p);
        }
        if (cameraController == null || !this.front_screen_flash) {
            i = -1;
            if ("flash_frontscreen_torch".equals(preview.getCurrentFlashValue())) {
                this.p.setColor(-1);
                this.p.setAlpha(ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
                canvas.drawRect(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight(), this.p);
                this.p.setAlpha(255);
            }
        } else {
            this.p.setColor(-1);
            i = -1;
            canvas.drawRect(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight(), this.p);
        }
        if (!this.main_activity.getMainUI().inImmersiveMode() || !this.immersive_mode_everything_pref) {
            if (cameraController != null && this.taking_picture && !this.front_screen_flash && this.take_photo_border_pref) {
                this.p.setColor(i);
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(this.stroke_width);
                this.p.setStrokeWidth((this.scale * 5.0f) + 0.5f);
                canvas.drawRect(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight(), this.p);
                this.p.setStyle(Paint.Style.FILL);
                this.p.setStrokeWidth(this.stroke_width);
            }
            drawGrids(canvas);
            drawCropGuides(canvas);
            if (this.last_thumbnail != null && !this.last_thumbnail_is_video && cameraController != null && (this.show_last_image || (this.allow_ghost_last_image && !this.front_screen_flash && this.ghost_image_pref.equals("preference_ghost_image_last")))) {
                if (this.show_last_image) {
                    this.p.setColor(Color.rgb(0, 0, 0));
                    canvas.drawRect(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight(), this.p);
                }
                setLastImageMatrix(canvas2, this.last_thumbnail, uIRotation, !this.show_last_image);
                if (!this.show_last_image) {
                    this.p.setAlpha(this.ghost_image_alpha);
                }
                canvas2.drawBitmap(this.last_thumbnail, this.last_image_matrix, this.p);
                if (!this.show_last_image) {
                    this.p.setAlpha(255);
                }
            } else if (!(cameraController == null || this.front_screen_flash || (bitmap = this.ghost_selected_image_bitmap) == null)) {
                setLastImageMatrix(canvas2, bitmap, uIRotation, true);
                this.p.setAlpha(this.ghost_image_alpha);
                canvas2.drawBitmap(this.ghost_selected_image_bitmap, this.last_image_matrix, this.p);
                this.p.setAlpha(255);
            }
            if (preview.isPreviewBitmapEnabled()) {
                Bitmap zebraStripesBitmap = preview.getZebraStripesBitmap();
                if (zebraStripesBitmap != null) {
                    setLastImageMatrix(canvas2, zebraStripesBitmap, 0, false);
                    this.p.setAlpha(255);
                    canvas2.drawBitmap(zebraStripesBitmap, this.last_image_matrix, this.p);
                }
                Bitmap focusPeakingBitmap = preview.getFocusPeakingBitmap();
                if (focusPeakingBitmap != null) {
                    setLastImageMatrix(canvas2, focusPeakingBitmap, 0, false);
                    this.p.setAlpha(127);
                    if (this.focus_peaking_color_pref != i) {
                        this.p.setColorFilter(new PorterDuffColorFilter(this.focus_peaking_color_pref, PorterDuff.Mode.SRC_IN));
                    }
                    canvas2.drawBitmap(focusPeakingBitmap, this.last_image_matrix, this.p);
                    if (this.focus_peaking_color_pref != i) {
                        this.p.setColorFilter((ColorFilter) null);
                    }
                    this.p.setAlpha(255);
                }
            }
            doThumbnailAnimation(canvas2, currentTimeMillis);
            drawUI(canvas2, currentTimeMillis);
            drawAngleLines(canvas2, currentTimeMillis);
            doFocusAnimation(canvas2, currentTimeMillis);
            CameraController.Face[] facesDetected = preview.getFacesDetected();
            if (facesDetected != null) {
                this.p.setColor(Color.rgb(255, 235, 59));
                this.p.setStyle(Paint.Style.STROKE);
                this.p.setStrokeWidth(this.stroke_width);
                for (CameraController.Face face : facesDetected) {
                    if (face.score >= 50) {
                        canvas2.drawRect(face.rect, this.p);
                    }
                }
                this.p.setStyle(Paint.Style.FILL);
            }
            if (this.enable_gyro_target_spot && cameraController != null) {
                GyroSensor gyroSensor2 = this.main_activity.getApplicationInterface().getGyroSensor();
                if (gyroSensor2.isRecording()) {
                    for (float[] relativeInverseVector : this.gyro_directions) {
                        gyroSensor2.getRelativeInverseVector(this.transformed_gyro_direction, relativeInverseVector);
                        gyroSensor2.getRelativeInverseVector(this.transformed_gyro_direction_up, this.gyro_direction_up);
                        float f2 = -((float) Math.asin((double) this.transformed_gyro_direction[1]));
                        float f3 = -((float) Math.asin((double) this.transformed_gyro_direction[c]));
                        if (((double) Math.abs(f2)) >= 1.5707963267948966d || ((double) Math.abs(f3)) >= 1.5707963267948966d) {
                            f = f2;
                            gyroSensor = gyroSensor2;
                        } else {
                            updateCachedViewAngles(currentTimeMillis);
                            float f4 = this.view_angle_x_preview;
                            float f5 = this.view_angle_y_preview;
                            float width = (float) (((double) canvas.getWidth()) / (Math.tan(Math.toRadians(((double) f4) / 2.0d)) * 2.0d));
                            float height = (float) (((double) canvas.getHeight()) / (Math.tan(Math.toRadians(((double) f5) / 2.0d)) * 2.0d));
                            float zoomRatio = width * preview.getZoomRatio();
                            float zoomRatio2 = height * preview.getZoomRatio();
                            float tan = zoomRatio * ((float) Math.tan((double) f2));
                            float tan2 = zoomRatio2 * ((float) Math.tan((double) f3));
                            this.p.setColor(-1);
                            f = f2;
                            gyroSensor = gyroSensor2;
                            drawGyroSpot(canvas, 0.0f, 0.0f, -1.0f, 0.0f, 48, true);
                            this.p.setColor(-16776961);
                            float[] fArr = this.transformed_gyro_direction_up;
                            drawGyroSpot(canvas, tan, tan2, -fArr[1], -fArr[0], 45, false);
                        }
                        if (gyroSensor.isUpright() != 0 && Math.abs(f) <= 0.34906584f) {
                            canvas.save();
                            canvas2.rotate((float) uIRotation, ((float) canvas.getWidth()) / 2.0f, ((float) canvas.getHeight()) / 2.0f);
                            float f6 = this.scale;
                            int width2 = canvas.getWidth() / 2;
                            int height2 = (canvas.getHeight() / 2) - ((int) ((f6 * 80.0f) + 0.5f));
                            int i2 = ((int) ((64.0f * f6) + 0.5f)) / 2;
                            this.icon_dest.set(width2 - i2, height2 - i2, width2 + i2, height2 + i2);
                        }
                        gyroSensor2 = gyroSensor;
                        c = 0;
                    }
                }
            }
        }
    }

    private void setLastImageMatrix(Canvas canvas, Bitmap bitmap, int i, boolean z) {
        CameraController cameraController = this.main_activity.getPreview().getCameraController();
        this.last_image_src_rect.left = 0.0f;
        this.last_image_src_rect.top = 0.0f;
        this.last_image_src_rect.right = (float) bitmap.getWidth();
        this.last_image_src_rect.bottom = (float) bitmap.getHeight();
        if (i == 90 || i == 270) {
            this.last_image_src_rect.right = (float) bitmap.getHeight();
            this.last_image_src_rect.bottom = (float) bitmap.getWidth();
        }
        this.last_image_dst_rect.left = 0.0f;
        this.last_image_dst_rect.top = 0.0f;
        this.last_image_dst_rect.right = (float) canvas.getWidth();
        this.last_image_dst_rect.bottom = (float) canvas.getHeight();
        this.last_image_matrix.setRectToRect(this.last_image_src_rect, this.last_image_dst_rect, Matrix.ScaleToFit.CENTER);
        if (i == 90 || i == 270) {
            float height = (float) (bitmap.getHeight() - bitmap.getWidth());
            this.last_image_matrix.preTranslate(height / 2.0f, (-height) / 2.0f);
        }
        this.last_image_matrix.preRotate((float) i, ((float) bitmap.getWidth()) / 2.0f, ((float) bitmap.getHeight()) / 2.0f);
        if (z) {
            //TODO Change mirror
//            if ((cameraController != null && cameraController.getFacing() == CameraController.Facing.FACING_FRONT) && !SharedPrefs.getString(main_activity,PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo")) {
//                this.last_image_matrix.preScale(-1.0f, 1.0f, ((float) bitmap.getWidth()) / 2.0f, 0.0f);
//            }
            if ((cameraController != null && cameraController.getFacing() == CameraController.Facing.FACING_FRONT) && !SharedPrefs.getString(main_activity,PreferenceKeys.FrontCameraMirrorKey, "preference_front_camera_mirror_no").equals("preference_front_camera_mirror_photo")) {
                this.last_image_matrix.preScale(-1.0f, 1.0f, ((float) bitmap.getWidth()) / 2.0f, 0.0f);
            }
        }
    }

    private void drawGyroSpot(Canvas canvas, float f, float f2, float f3, float f4, int i,
                              boolean z) {
        if (z) {
            this.p.setStyle(Paint.Style.STROKE);
            this.p.setStrokeWidth(this.stroke_width);
            this.p.setAlpha(255);
        } else {
            this.p.setAlpha(127);
        }
        canvas.drawCircle((((float) canvas.getWidth()) / 2.0f) + f, (((float) canvas.getHeight()) / 2.0f) + f2, (((float) i) * this.scale) + 0.5f, this.p);
        this.p.setAlpha(255);
        this.p.setStyle(Paint.Style.FILL);
    }

    public void onExtraOSDValuesChanged(String str, String str2) {
        this.OSDLine1 = str;
        this.OSDLine2 = str2;
    }

    public boolean getStoredHasStampPref() {
        return this.has_stamp_pref;
    }

    public boolean getStoredAutoStabilisePref() {
        return this.auto_stabilise_pref;
    }
}
