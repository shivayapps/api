package com.gallery.photo.image.video.cameraview.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.cameraview.ui.helper.HelperClass;
import com.gallery.photo.image.video.cameraview.ui.interfaces.OnRecyclerItemClickListener;


public class DateTimeAdapter extends RecyclerView.Adapter<DateTimeAdapter.Holder> {
    Context mContext;
    String[] mList;
    OnRecyclerItemClickListener mOnRecyclerItemClickListener;
    String selected_pos="";

    public DateTimeAdapter(Context context, String[] strArr, OnRecyclerItemClickListener onRecyclerItemClickListener) {
        this.mContext = context;
        this.mList = strArr;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
//        this.selected_pos = SharedPrefs.getString(mContext, SharedPrefs.DATE_FORMAT, AppConstant.DEFAULT_DATE_FORMAT);
    }

    public DateTimeAdapter(Context context, String[] strArr, OnRecyclerItemClickListener onRecyclerItemClickListener, String selected_pos) {
        this.mContext = context;
        this.mList = strArr;
        this.mOnRecyclerItemClickListener = onRecyclerItemClickListener;
        this.selected_pos = selected_pos;
    }

    public Holder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Holder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cell_date_time, viewGroup, false));
    }

    public void onBindViewHolder(Holder holder, int i) {
        holder.tv_dateFormat.setText(HelperClass.setDateTimeFormat(this.mList[i]));
        if (this.mList[i].equals(this.selected_pos)) {
            holder.img_selection.setImageResource(R.drawable.ic_radio_btn_primary);
        } else {
            holder.img_selection.setImageResource(R.drawable.ic_radio_btn_grey);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public int getItemCount() {
        return this.mList.length;
    }

    public void refAdapter(String str) {
        this.selected_pos = str;
        notifyDataSetChanged();
    }

    public class Holder extends RecyclerView.ViewHolder {
        RelativeLayout date_main_lay;
        ImageView img_selection;
        TextView tv_dateFormat;

        public Holder(View view) {
            super(view);
            this.tv_dateFormat = (TextView) view.findViewById(R.id.tv_temp_name);
            this.date_main_lay = view.findViewById(R.id.dt_main_lay);
            this.img_selection = (ImageView) view.findViewById(R.id.img_selection);
            this.date_main_lay.setOnClickListener(view1 -> {
                if (Holder.this.getAdapterPosition() >= 0 && mOnRecyclerItemClickListener != null) {
                    mOnRecyclerItemClickListener.OnClick_(getAdapterPosition(), view1);
                }
            });
        }
    }
}
