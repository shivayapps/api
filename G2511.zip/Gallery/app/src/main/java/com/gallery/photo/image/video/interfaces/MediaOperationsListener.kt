package com.gallery.photo.image.video.interfaces

import com.gallery.photo.image.video.models.FileDirItem
import com.gallery.photo.image.video.models.ThumbnailItem


interface MediaOperationsListener {
    fun refreshItems()

    fun tryDeleteFiles(fileDirItems: ArrayList<FileDirItem>)

    fun selectedPaths(paths: ArrayList<String>)

    fun updateMediaGridDecoration(media: ArrayList<ThumbnailItem>)
}
