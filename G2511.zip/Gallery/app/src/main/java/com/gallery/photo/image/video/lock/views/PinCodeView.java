package com.gallery.photo.image.video.lock.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gallery.photo.image.video.R;

/**
 * Created by stoyan and olivier on 1/12/15.
 */
public class PinCodeView extends RelativeLayout {

    private Context mContext;

    public PinCodeView(Context context) {
        this(context, null);
    }

    public PinCodeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PinCodeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        this.mContext = context;
        initializeView(attrs, defStyleAttr);
    }

    private void initializeView(AttributeSet attrs, int defStyleAttr) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        LinearLayout view = (LinearLayout) inflater.inflate(R.layout.activity_pin_code, this);

        RelativeLayout rel_main = view.findViewById(R.id.rel_main);
        ImageView iv_back = view.findViewById(R.id.iv_back);
        TextView txt_hesder = view.findViewById(R.id.txt_hesder);
        TextView pin_code_step_textview = view.findViewById(R.id.pin_code_step_textview);
        TextView pin_code_forgot_textview = view.findViewById(R.id.pin_code_round_view);

      /*  int ColorId = Share.getAPPThemWisePrimoryColor(mContext);
        rel_main.setBackgroundColor(ColorId);
        pin_code_forgot_textview.setTextColor(ColorId);

        int HederColor = Share.getAppHeaderColorColor(mContext);
        iv_back.setColorFilter(HederColor, PorterDuff.Mode.SRC_IN);
        txt_hesder.setTextColor(HederColor);

        int PrimaryTextColor = Share.getAppPrimaryTextColor(mContext);
        pin_code_step_textview.setTextColor(PrimaryTextColor);
*/

    }

}
