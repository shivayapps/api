package com.gallery.photo.image.video.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.gallery.photo.image.video.interfaces.*
import com.gallery.photo.image.video.models.*
import com.gallery.photo.image.video.utilities.DATABASE_PATH
import com.gallery.photo.image.video.extensions.getParentPath
import java.io.File

@Database(
    entities = [HideFilesDetail::class, FakeHideFilesDetail::class,FakeHiddenFileDirectory::class,HiddenFileDirectory::class,Note::class],
    version = 2
)
abstract class FilesDatabase : RoomDatabase() {

    abstract fun hideFilesDetailDao(): HideFilesDetailDao
    abstract fun fakeHideFilesDetailDao(): FakeHideFilesDetailDao
    abstract fun noteDao(): NoteDao

    companion object {
        private var db: FilesDatabase? = null

        fun getInstance(context: Context): FilesDatabase {
            if (db == null) {
                synchronized(FilesDatabase::class) {
                    if (db == null) {
                        var sdir = File(DATABASE_PATH)
                        var parentFile = File(sdir.absolutePath.getParentPath())
                        if (!parentFile.exists()) {
                            parentFile.mkdir()
                        }
                        if (!sdir.exists()) {
                            sdir.mkdir()
                        }

                        db = Room.databaseBuilder(context.applicationContext, FilesDatabase::class.java, DATABASE_PATH + "/files.db")
                            .fallbackToDestructiveMigration()
                            .addMigrations(MIGRATION_1_2)
//                            .addMigrations(MIGRATION_2_3)
                            .build()
                    }
                }
            }
            return db!!
        }

        fun destroyInstance() {
            db = null
        }
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS `Note` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `title` TEXT NOT NULL,`description` TEXT NOT NULL,`timestamp` INTEGER NOT NULL,`isFromFakeVault` INTEGER  default 0 NOT NULL,`deleted_ts` INTEGER default 0 NOT NULL)")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {

            }
        }




    }
}
