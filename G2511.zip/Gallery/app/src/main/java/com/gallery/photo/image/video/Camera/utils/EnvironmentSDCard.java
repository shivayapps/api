package com.gallery.photo.image.video.Camera.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.util.Log;

import androidx.core.content.ContextCompat;
import androidx.core.os.EnvironmentCompat;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class EnvironmentSDCard {
    private static final String TAG = "EnvironmentSDCard";
    public static final String TYPE_INTERNAL = "intern";
    public static final String TYPE_PRIMARY = "primär";
    public static final String TYPE_SD = "MicroSD";
    public static final String TYPE_UNKNOWN = "unbekannt";
    public static final String TYPE_USB = "USB";
    public static final String WRITE_APPONLY = "apponly";
    public static final String WRITE_FULL = "readwrite";
    public static final String WRITE_NONE = "none";
    public static final String WRITE_READONLY = "readonly";
    private static Device[] devices = null;
    private static Device[] externalstorage = null;
    private static BroadcastReceiver receiver = null;
    private static Device[] storage = null;
    private static boolean useReceiver = true;
    /* access modifiers changed from: private */
    public static String userDir;

    public static Device[] getDevices(Context context) {
        if (devices == null) {
            initDevices(context);
        }
        return devices;
    }

    public static Device[] getExternalStorage(Context context) {
        if (devices == null) {
            initDevices(context);
        }
        return externalstorage;
    }

    public static Device[] getStorage(Context context) {
        if (devices == null) {
            initDevices(context);
        }
        return storage;
    }

    public static boolean isSDCardAvailable(Context context) {
        File[] externalFilesDirs = ContextCompat.getExternalFilesDirs(context, (String) null);
        return (externalFilesDirs.length <= 1 || externalFilesDirs[0] == null || externalFilesDirs[1] == null) ? false : true;
    }

    public static IntentFilter getRescanIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.MEDIA_BAD_REMOVAL");
        intentFilter.addAction("android.intent.action.MEDIA_MOUNTED");
        intentFilter.addAction("android.intent.action.MEDIA_REMOVED");
        intentFilter.addAction("android.intent.action.MEDIA_SHARED");
        intentFilter.addDataScheme("file");
        return intentFilter;
    }

    public static void setUseReceiver(Context context, boolean z) {
        BroadcastReceiver broadcastReceiver;
        if (z && receiver == null) {
            BroadcastReceiver r0 = new BroadcastReceiver() {
                public void onReceive(Context context, Intent intent) {
                    Log.i(EnvironmentSDCard.TAG, "Storage " + intent.getAction() + "-" + intent.getData());
                    EnvironmentSDCard.initDevices(context);
                }
            };
            receiver = r0;
            context.registerReceiver(r0, getRescanIntentFilter());
        } else if (!z && (broadcastReceiver = receiver) != null) {
            context.unregisterReceiver(broadcastReceiver);
            receiver = null;
        }
        useReceiver = z;
    }

    public static void initDevices(Context context) {
        if (userDir == null) {
            userDir = "/Android/data/" + context.getPackageName();
        }
        setUseReceiver(context, useReceiver);
        StorageManager storageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
        try {
            Object[] objArr = (Object[]) storageManager.getClass().getMethod("getVolumeList", (Class[]) null).invoke(storageManager, (Object[]) null);
            int length = objArr.length;
            Device[] deviceArr = new Device[length];
            for (int i = 0; i < objArr.length; i++) {
                deviceArr[i] = new Device(objArr[i]);
            }
            Device device = null;
            for (int i2 = 0; i2 < length; i2++) {
                Device device2 = deviceArr[i2];
                if (device2.mPrimary) {
                    device = device2;
                }
            }
            if (device == null) {
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        break;
                    }
                    Device device3 = deviceArr[i3];
                    if (!device3.mRemovable) {
                        device3.mPrimary = true;
                        device = device3;
                        break;
                    }
                    i3++;
                }
            }
            if (device == null) {
                device = deviceArr[0];
                device.mPrimary = true;
            }
            File[] externalFilesDirs = ContextCompat.getExternalFilesDirs(context, (String) null);
            File[] externalCacheDirs = ContextCompat.getExternalCacheDirs(context);
            for (int i4 = 0; i4 < length; i4++) {
                Device device4 = deviceArr[i4];
                if (externalFilesDirs != null) {
                    for (File file : externalFilesDirs) {
                        if (file != null && file.getAbsolutePath().startsWith(device4.getAbsolutePath())) {
                            device4.mFiles = file;
                        }
                    }
                }
                if (externalCacheDirs != null) {
                    for (File file2 : externalCacheDirs) {
                        if (file2 != null && file2.getAbsolutePath().startsWith(device4.getAbsolutePath())) {
                            device4.mCache = file2;
                        }
                    }
                }
            }
            ArrayList arrayList = new ArrayList(10);
            ArrayList arrayList2 = new ArrayList(10);
            ArrayList arrayList3 = new ArrayList(10);
            for (int i5 = 0; i5 < length; i5++) {
                Device device5 = deviceArr[i5];
                arrayList.add(device5);
                if (device5.isAvailable()) {
                    arrayList3.add(device5);
                    arrayList2.add(device5);
                }
            }
            Device device6 = new Device(context);
            arrayList2.add(0, device6);
            if (!device.mEmulated) {
                arrayList.add(0, device6);
            }
            devices = (Device[]) arrayList.toArray(new Device[arrayList.size()]);
            storage = (Device[]) arrayList2.toArray(new Device[arrayList2.size()]);
            externalstorage = (Device[]) arrayList3.toArray(new Device[arrayList3.size()]);
        } catch (Exception unused) {
        }
    }

    public static class Device extends File {
        boolean mAllowMassStorage;
        File mCache;
        boolean mEmulated;
        File mFiles;
        long mMaxFileSize;
        boolean mPrimary;
        boolean mRemovable;
        String mState;
        String mType;
        String mUserLabel;
        String mUuid;
        String mWriteState;

        Device(Context context) {
            super(Environment.getDataDirectory().getAbsolutePath());
            this.mState = "mounted";
            this.mFiles = context.getFilesDir();
            this.mCache = context.getCacheDir();
            this.mType = EnvironmentSDCard.TYPE_INTERNAL;
            this.mWriteState = EnvironmentSDCard.WRITE_APPONLY;
        }

        Device(Object obj) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
            super((String) obj.getClass().getMethod("getPath", (Class[]) null).invoke(obj, (Object[]) null));
            for (Method method : obj.getClass().getMethods()) {
                if (method.getName().equals("getUserLabel") && method.getParameterTypes().length == 0 && method.getReturnType() == String.class) {
                    this.mUserLabel = (String) method.invoke(obj, (Object[]) null);
                }
                if (method.getName().equals("getUuid") && method.getParameterTypes().length == 0 && method.getReturnType() == String.class) {
                    this.mUuid = (String) method.invoke(obj, (Object[]) null);
                }
                if (method.getName().equals("getState") && method.getParameterTypes().length == 0 && method.getReturnType() == String.class) {
                    this.mState = (String) method.invoke(obj, (Object[]) null);
                }
                if (method.getName().equals("isRemovable") && method.getParameterTypes().length == 0 && method.getReturnType() == Boolean.TYPE) {
                    this.mRemovable = ((Boolean) method.invoke(obj, (Object[]) null)).booleanValue();
                }
                if (method.getName().equals("isPrimary") && method.getParameterTypes().length == 0 && method.getReturnType() == Boolean.TYPE) {
                    this.mPrimary = ((Boolean) method.invoke(obj, (Object[]) null)).booleanValue();
                }
                if (method.getName().equals("isEmulated") && method.getParameterTypes().length == 0 && method.getReturnType() == Boolean.TYPE) {
                    this.mEmulated = ((Boolean) method.invoke(obj, (Object[]) null)).booleanValue();
                }
                if (method.getName().equals("allowMassStorage") && method.getParameterTypes().length == 0 && method.getReturnType() == Boolean.TYPE) {
                    this.mAllowMassStorage = ((Boolean) method.invoke(obj, (Object[]) null)).booleanValue();
                }
                if (method.getName().equals("getMaxFileSize") && method.getParameterTypes().length == 0 && method.getReturnType() == Long.TYPE) {
                    this.mMaxFileSize = ((Long) method.invoke(obj, (Object[]) null)).longValue();
                }
            }
            if (this.mState == null) {
                this.mState = getState();
            }
            if (this.mPrimary) {
                this.mType = EnvironmentSDCard.TYPE_PRIMARY;
                return;
            }
            String lowerCase = getAbsolutePath().toLowerCase();
            if (lowerCase.indexOf("sd") > 0) {
                this.mType = EnvironmentSDCard.TYPE_SD;
            } else if (lowerCase.indexOf("usb") > 0) {
                this.mType = EnvironmentSDCard.TYPE_USB;
            } else {
                this.mType = "unbekannt " + getAbsolutePath();
            }
        }

        public String getType() {
            return this.mType;
        }

        public String getAccess() {
            if (this.mWriteState == null) {
                try {
                    this.mWriteState = "none";
                    File[] listFiles = listFiles();
                    if (listFiles == null || listFiles.length == 0) {
                        throw new IOException("root empty/unreadable");
                    }
                    this.mWriteState = EnvironmentSDCard.WRITE_READONLY;
                    File.createTempFile("jow", (String) null, getFilesDir()).delete();
                    this.mWriteState = EnvironmentSDCard.WRITE_APPONLY;
                    File.createTempFile("jow", (String) null, this).delete();
                    this.mWriteState = EnvironmentSDCard.WRITE_FULL;
                } catch (IOException e) {
                    Log.v(EnvironmentSDCard.TAG, "test " + getAbsolutePath() + " ->" + this.mWriteState + "<- " + e.getMessage());
                }
            }
            return this.mWriteState;
        }

        public boolean isAvailable() {
            String state = getState();
            return "mounted".equals(state) || "mounted_ro".equals(state);
        }

        public String getState() {
            if (this.mRemovable || this.mState == null) {
                if (Build.VERSION.SDK_INT >= 21) {
                    this.mState = Environment.getExternalStorageState(this);
                } else if (Build.VERSION.SDK_INT >= 19) {
                    this.mState = Environment.getStorageState(this);
                } else if (!canRead() || getTotalSpace() <= 0) {
                    String str = this.mState;
                    if (str == null || "mounted".equals(str)) {
                        this.mState = EnvironmentCompat.MEDIA_UNKNOWN;
                    }
                } else {
                    this.mState = "mounted";
                }
            }
            return this.mState;
        }

        public File getFilesDir() {
            if (this.mFiles == null) {
                File file = new File(this, EnvironmentSDCard.userDir + "/files");
                this.mFiles = file;
                if (!file.isDirectory()) {
                    this.mFiles.mkdirs();
                }
            }
            return this.mFiles;
        }

        public File getCacheDir() {
            if (this.mCache == null) {
                File file = new File(this, EnvironmentSDCard.userDir + "/cache");
                this.mCache = file;
                if (!file.isDirectory()) {
                    this.mCache.mkdirs();
                }
            }
            return this.mCache;
        }

        public boolean isPrimary() {
            return this.mPrimary;
        }

        public boolean isRemovable() {
            return this.mRemovable;
        }

        public boolean isEmulated() {
            return this.mEmulated;
        }

        public boolean isAllowMassStorage() {
            return this.mAllowMassStorage;
        }

        public long getMaxFileSize() {
            return this.mMaxFileSize;
        }

        public String getUserLabel() {
            return this.mUserLabel;
        }

        public String getUuid() {
            return this.mUuid;
        }
    }
}
