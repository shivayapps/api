package com.gallery.photo.image.video.models

data class Release(val id: Int, val textId: Int)
