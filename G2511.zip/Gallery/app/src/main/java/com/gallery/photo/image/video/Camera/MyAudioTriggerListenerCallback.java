package com.gallery.photo.image.video.Camera;

import android.preference.PreferenceManager;
import android.util.Log;

public class MyAudioTriggerListenerCallback implements AudioListener.AudioListenerCallback {
    private static final String TAG = "MyAudioTriggerLstnrCb";
    private int audio_noise_sensitivity = -1;
    private int last_level = -1;
    private final CameraActivity main_activity;
    private long time_last_audio_trigger_photo = -1;
    private long time_quiet_loud = -1;

    MyAudioTriggerListenerCallback(CameraActivity cameraActivity) {
        this.main_activity = cameraActivity;
    }

    /* access modifiers changed from: package-private */
    public void setAudioNoiseSensitivity(int i) {
        this.audio_noise_sensitivity = i;
    }

    public void onAudio(int i) {
        int i2 = this.last_level;
        if (i2 == -1) {
            this.last_level = i;
            return;
        }
        int i3 = i - i2;
        Log.d(TAG, "noise_sensitivity: " + this.audio_noise_sensitivity);
        Log.d(TAG, "diff: " + i3);
        int i4 = this.audio_noise_sensitivity;
        boolean z = false;
        if (i3 > i4) {
            Log.d(TAG, "got louder!: " + this.last_level + " to " + i + " , diff: " + i3);
            this.time_quiet_loud = System.currentTimeMillis();
            StringBuilder sb = new StringBuilder();
            sb.append("    time: ");
            sb.append(this.time_quiet_loud);
            Log.d(TAG, sb.toString());
        } else if (i3 >= (-i4) || this.time_quiet_loud == -1) {
            Log.d(TAG, "audio level: " + this.last_level + " to " + i + " , diff: " + i3);
        } else {
            Log.d(TAG, "got quieter!: " + this.last_level + " to " + i + " , diff: " + i3);
            long currentTimeMillis = System.currentTimeMillis();
            long j = currentTimeMillis - this.time_quiet_loud;
            StringBuilder sb2 = new StringBuilder();
            sb2.append("stopped being loud - was loud since: ");
            sb2.append(this.time_quiet_loud);
            Log.d(TAG, sb2.toString());
            Log.d(TAG, "    time_now: " + currentTimeMillis);
            Log.d(TAG, "    duration: " + j);
            if (j < 1500) {
                Log.d(TAG, "audio_trigger set");
                z = true;
            }
            this.time_quiet_loud = -1;
        }
        this.last_level = i;
        if (z) {
            Log.d(TAG, "audio trigger");
            long currentTimeMillis2 = System.currentTimeMillis();
            boolean equals = PreferenceManager.getDefaultSharedPreferences(this.main_activity).getString(PreferenceKeys.AudioControlPreferenceKey, "none").equals("noise");
            long j2 = this.time_last_audio_trigger_photo;
            if (j2 != -1 && currentTimeMillis2 - j2 < 5000) {
                Log.d(TAG, "ignore loud noise due to too soon since last audio triggered photo: " + (currentTimeMillis2 - this.time_last_audio_trigger_photo));
            } else if (!equals) {
                Log.d(TAG, "ignore loud noise due to audio listener option turned off");
            } else {
                Log.d(TAG, "audio trigger from loud noise");
                this.time_last_audio_trigger_photo = currentTimeMillis2;
                this.main_activity.audioTrigger();
            }
        }
    }
}
