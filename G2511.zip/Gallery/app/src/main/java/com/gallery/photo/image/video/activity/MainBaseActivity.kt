package com.gallery.photo.image.video.activity

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.StrictMode
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import androidx.core.text.HtmlCompat
import com.example.jdrodi.jprogress.JProgress
import com.example.jdrodi.utilities.SPUtil
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.extensions.addPathToDB
import com.gallery.photo.image.video.extensions.updateDirectoryPath
import com.gallery.photo.image.video.utilities.addEvent
import com.gallery.photo.image.video.utilities.isUnLockApp
import com.gallery.photo.image.video.utilities.selectedLanguageCommon
import com.gallery.photo.image.video.activity.BaseSimpleActivity
import com.gallery.photo.image.video.extensions.baseConfig
import com.gallery.photo.image.video.extensions.getColoredDrawableWithColor
import com.gallery.photo.image.video.extensions.getParentPath
import com.gallery.photo.image.video.extensions.getRealPathFromURI

abstract class MainBaseActivity : BaseSimpleActivity(), View.OnClickListener {

    lateinit var mContext: Activity // Context of the current activity
    lateinit var sp: SPUtil // Obj. of SharedPreference
    private var jpDialog: JProgress? = null
    val REQ_CODE_FOR_MANAGE_STORAGE = 100;

    // variable to track event time
    open var mLastClickTime: Long = 0
    open var mMinDuration = 1000
    val observer = object : ContentObserver(null) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            super.onChange(selfChange, uri)
            if (uri != null) {
                val path = getRealPathFromURI(uri)
                if (path != null) {
                    updateDirectoryPath(path.getParentPath())
                    addPathToDB(path)
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addEvent(javaClass.simpleName)
        selectedLanguageCommon= baseConfig.appLanguage

        val policy: StrictMode.ThreadPolicy = StrictMode.ThreadPolicy.Builder()
            .permitAll().build()
        StrictMode.setThreadPolicy(policy)
        mContext = getContext()
        sp = SPUtil(mContext)
        jpDialog = JProgress.create(mContext, JProgress.Style.SPIN_INDETERMINATE)
    }

    override fun setContentView(layout: Int) {
        super.setContentView(layout)

        initViews()
        initAds()
        initData()
        initActions()
    }


    fun showGetPermissionDialog11() {

        isUnLockApp = true
        val alertDialogBuilder = AlertDialog.Builder(this, R.style.MyAlertDialogNew)
        alertDialogBuilder.setTitle(HtmlCompat.fromHtml("<font color='#0a82f3'>"+getString(R.string.error_permission_required)+"</font>", HtmlCompat.FROM_HTML_MODE_LEGACY))

            .setMessage(getString(R.string.msg_permission_required_android_11))
            .setPositiveButton(getString(R.string.ok)) { dialog, which ->
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))

                try {
                    launchActivityForResult(intent, REQ_CODE_FOR_MANAGE_STORAGE)
                } catch (e: Exception) {
                }
            }
            .setNegativeButton(getString(R.string.cancel)) { dialog, which -> //my code
                dialog.dismiss()
                finishAffinity()
            }
            .setCancelable(false)

        val alert = alertDialogBuilder.create()
        alert.show()
        val bgDrawable = resources.getColoredDrawableWithColor(com.gallery.photo.image.video.R.drawable.dialog_bg, baseConfig.backgroundColor)
        alert.window?.setBackgroundDrawable(bgDrawable)
        alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
        alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
        alert.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(resources.getColor(com.gallery.photo.image.video.R.color.color_primary))
    }


    /**
     * ToDo. Set the context of activity
     *
     * @return The context of activity.
     */
    abstract fun getContext(): Activity

    /**
     * ToDo. Use this method to setup views.
     */
    open fun initViews() {}

    /**
     * ToDo. Use this method to setup ads.
     */
    open fun initAds() {}

    /**
     * ToDo. Use this method to initialize data to view components.
     */
    abstract fun initData()

    /**
     * ToDo. Use this method to initialize action on view components.
     */
    abstract fun initActions()

    override fun onClick(view: View) {
        if (SystemClock.elapsedRealtime() - mLastClickTime < mMinDuration) {
            return
        }
        mLastClickTime = SystemClock.elapsedRealtime()
    }

    fun jpShow() {
        jpDialog?.show()
    }

    fun jpDismiss() {
        jpDialog?.dismiss()
    }

    protected fun registerFileUpdateListener() {
        try {
            contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
            contentResolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
        } catch (ignored: Exception) {
        }
    }

    protected fun unregisterFileUpdateListener() {
        try {
            contentResolver.unregisterContentObserver(observer)
        } catch (ignored: Exception) {
        }
    }

}