package com.gallery.photo.image.video.models

class Language(
    val name : String ="",
    val description : String= "",
    var expand : Boolean = false
)