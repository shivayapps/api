package com.gallery.photo.image.video.cameraview;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class ShortcutReceiver extends BroadcastReceiver {
  public static final String kInstalledAction = "general.intent.action.SHORTCUT_ADDED";

  @Override
  public void onReceive(Context context, Intent intent) {
    
    if (kInstalledAction.equals(intent.getAction())) {
      // Handle the event after the shortcut has been added 
      Toast.makeText(context, "The shortcut has been added", Toast.LENGTH_LONG).show();
    }
  
  }

}