package com.gallery.photo.image.video.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.jdrodi.utilities.OnSingleClickListener
import com.gallery.photo.image.video.databinding.ListItemBookmarksBinding
import com.gallery.photo.image.video.interfaces.onBookmarkClick
import com.gallery.photo.image.video.models.BrowserBookmark

class BookmarkAdapter(var context: Context, var mData: ArrayList<BrowserBookmark>, private var onBookmarkClick: onBookmarkClick) :
    BaseAdapter<BrowserBookmark>(mData) {

    override fun onCreateHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        return MyViewHolder(ListItemBookmarksBinding.inflate(LayoutInflater.from(context), parent, false))
    }

    override fun onBindHolder(holder: BaseViewHolder<*>, position: Int) {
        with(holder as MyViewHolder) {
            with(fBinding) {
                with(mData[position]) {
                    tvTitle.text = mData[position].title
                    tvUrl.text = mData[position].link



                    itemView.setOnClickListener(object : OnSingleClickListener() {
                        override fun onSingleClick(v: View?) {
                            onBookmarkClick.onLinkClick(mData[position].link)
                        }
                    })
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return mData.size
    }

    inner class MyViewHolder(fBinding: ListItemBookmarksBinding) : BaseViewHolder<ListItemBookmarksBinding>(fBinding)




}