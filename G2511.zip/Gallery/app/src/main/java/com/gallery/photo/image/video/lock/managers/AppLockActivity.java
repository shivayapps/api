package com.gallery.photo.image.video.lock.managers;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.app.ads.helper.GiftIconHelper;
import com.gallery.photo.image.video.R;
import com.gallery.photo.image.video.activity.MainActivity;
import com.gallery.photo.image.video.adshelper.AdsManager;
;
import com.gallery.photo.image.video.lock.activity.PinActivity;
import com.gallery.photo.image.video.lock.enums.KeyboardButtonEnum;
import com.gallery.photo.image.video.lock.interfaces.KeyboardButtonClickedListener;
import com.gallery.photo.image.video.lock.views.KeyboardView;
import com.gallery.photo.image.video.lock.views.PinCodeRoundView;
import com.gallery.photo.image.video.utilities.Config;
import com.gallery.photo.image.video.utilities.ConstantsKt;
import com.gallery.photo.image.video.utilities.UtilsKt;

import java.util.Arrays;
import java.util.List;

import static android.view.View.GONE;

/**
 * Created by stoyan and olivier on 1/13/15.
 * The activity that appears when the password needs to be set or has to be asked.
 * Call this activity in normal or singleTop mode (not singleTask or singleInstance, it does not work
 * with {@link Activity#startActivityForResult(Intent, int)}).
 */
public abstract class AppLockActivity extends PinActivity
        implements KeyboardButtonClickedListener, View.OnClickListener, FingerprintUiHelper.Callback {

    public static final String TAG = AppLockActivity.class.getSimpleName();
    public static final String ACTION_CANCEL = TAG + ".actionCancelled";
    private static final int DEFAULT_PIN_LENGTH = 4;
    protected TextView mStepTextView;
    protected TextView mForgotTextView;
    protected PinCodeRoundView mPinCodeRoundView;
    protected KeyboardView mKeyboardView;
    protected ImageView mFingerprintImageView;
    protected TextView mFingerprintTextView;
    protected LockManager mLockManager;
    protected FingerprintManager mFingerprintManager;
    protected FingerprintUiHelper mFingerprintUiHelper;
    protected int mType = AppLock.UNLOCK_PIN;
    protected int mAttempts = 1;
    protected String mPinCode;
    protected String mOldPinCode;
    private boolean isCodeSuccessful = false;
    //    private TinyDB tinyDB;
    private ImageView iv_back, iv_more_app, iv_blast;
    private LinearLayout lout_toolbar;
    private boolean is_closed = true;
    private boolean ChangePatternLock = false;
    private boolean isAuthError = false;
    private static boolean isUnlockCalled = false;
    public static Activity activity = null;
    private Config config;
    Boolean isDisabledLock = false;
    String lockType = ConstantsKt.INTENT_LOCK_TYPE_APP;

    /**
     * First creation
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        setContentView(getContentView());

        // mType=AppLock.EXTRA_TYPE_MAIN;
        ConstantsKt.setAppOpenAdShow(false);
        activity = this;
        config = Config.Companion.newInstance(this);
        mFingerprintImageView = (ImageView) this.findViewById(R.id.pin_code_fingerprint_imageview);
        mFingerprintTextView = (TextView) this.findViewById(R.id.pin_code_fingerprint_textview);

        if (savedInstanceState == null) {
            initLayout(getIntent());
//            tinyDB = new TinyDB(this);
//
//            if (mType != Share.EXTRA_TYPE_MAIN)
//                Log.e(TAG, "onCreate: ####################");
        }
    }


    /**
     * If called in singleTop mode
     */
    /*@Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.e(TAG, "onNewIntent: AppLockActivity");
        initLayout(intent);
    }*/
    @Override
    protected void onResume() {
        super.onResume();

        Log.e(TAG, "onResume: AppLockActivity");
        Log.d("TAG11", "onResume: AppLockActivity");

        if (config.isFingerprintEnable()) {
            initLayoutForFingerprint();
        } else {
            mFingerprintImageView.setVisibility(View.GONE);
            mFingerprintTextView.setVisibility(View.GONE);
        }

        //Init layout for Fingerprint
        // TODO comment finger print
        ConstantsKt.setAppOpenAdShow(false);
//        Share.isAppOpenAdShow = false;


    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.e(TAG, "onPause: AppLockActivity");
        Log.e("MainApplication", "onPause  " + mType);
//        Share.isAppOpenAdShow = false;

        ConstantsKt.setAppOpenAdShow(false);
        if (mType == AppLock.DISABLE_PINLOCK) {
//            Share.unLockApp = false;

//            Share.isRemoveLockClick = true;
            onBackPressed();
        }
        if (mFingerprintUiHelper != null) {
            mFingerprintUiHelper.stopListening();
        }
//        Share.isAppOpenAdShow = false;

    }

    /**
     * Init completely the layout, depending of the extra {@link AppLock#EXTRA_TYPE}
     */
    private void initLayout(Intent intent) {


        Bundle extras = intent.getExtras();
        mType = extras.getInt(AppLock.EXTRA_TYPE, AppLock.UNLOCK_PIN);
        lockType = extras.getString(ConstantsKt.INTENT_LOCK_TYPE);
        if (lockType == null) {
            lockType = ConstantsKt.INTENT_LOCK_TYPE_APP;
        }
        ChangePatternLock = extras.getBoolean("ChangePatternLock");
        /*if (extras != null) {
            // mType=AppLock.EXTRA_TYPE_MAIN;  //todo change for manaeg lock screen when click on remove and change lock open unlock screen

            Log.e(TAG, "initLayout: mtyp==>" + mType);
        } else {
            mType =AppLock.UNLOCK_PIN;
            Log.e(TAG, "initLayout: mtyp==>" + mType);
        }*/

        mLockManager = LockManager.getInstance();
        mPinCode = "";
        mOldPinCode = "";

        enableAppLockerIfDoesNotExist();
        mLockManager.getAppLock().setPinChallengeCancelled(false);

        mStepTextView = (TextView) this.findViewById(R.id.pin_code_step_textview);
        mPinCodeRoundView = (PinCodeRoundView) this.findViewById(R.id.pin_code_round_view);
        mPinCodeRoundView.setPinLength(this.getPinLength());
        mForgotTextView = (TextView) this.findViewById(R.id.pin_code_forgot_textview);
        mForgotTextView.setOnClickListener(this);
        mKeyboardView = (KeyboardView) this.findViewById(R.id.pin_code_keyboard_view);
        mKeyboardView.setKeyboardButtonClickedListener(this);

        iv_back = findViewById(R.id.iv_back);
        iv_more_app = (ImageView) findViewById(R.id.iv_more_app);
        iv_blast = (ImageView) findViewById(R.id.iv_blast);
        iv_back.setOnClickListener(this);
        iv_more_app.setOnClickListener(this);
        mFingerprintImageView.setOnClickListener(this);
        lout_toolbar = findViewById(R.id.lout_toolbar);


        RelativeLayout rel_main = findViewById(R.id.rel_main);
        TextView txt_hesder = findViewById(R.id.txt_hesder);

//        int ColorId = Share.getAPPThemWisePrimoryColor(getApplicationContext());
//        int ColorId = getApplicationContext().getResources().getColor(R.color.colorPrimary);
//        rel_main.setBackgroundColor(ColorId);
//        mStepTextView.setTextColor(ColorId);
//        mForgotTextView.setTextColor(ColorId);

//        int HederColor = Share.getAppHeaderColorColor(getApplicationContext());
     /*   int HederColor =getApplicationContext().getResources().getColor(R.color.colorPrimary);
        iv_back.setColorFilter(HederColor, PorterDuff.Mode.SRC_IN);
        txt_hesder.setTextColor(HederColor);*/

        // mStepTextView.setTextColor(PrimaryTextColor);
        // mForgotTextView.setTextColor(PrimaryTextColor);
        /*if(mType==AppLock.ENABLE_PINLOCK) {
            iv_more_app.setVisibility(View.GONE);
            iv_more_app.setBackgroundResource(R.drawable.animation_list_filling);
            ((AnimationDrawable) iv_more_app.getBackground()).start();
            loadInterstialAd();
        }*/
        lout_toolbar.setVisibility(View.VISIBLE);
        if (mType == AppLock.UNLOCK_PIN)
            lout_toolbar.setVisibility(View.GONE);
        else {
            if (new AdsManager(this).isNeedToShowAds()) {
                 GiftIconHelper.INSTANCE.loadGiftAd(
                        this,
                        findViewById(R.id.gift_ad_icon),
                        findViewById(R.id.gift_blast_ad_icon)
                );
//                iv_more_app.setVisibility(View.GONE);
//                iv_more_app.setBackgroundResource(R.drawable.animation_list_filling);
//                ((AnimationDrawable) iv_more_app.getBackground()).start();
//                loadInterstialAd();
            }
            lout_toolbar.setVisibility(View.VISIBLE);
        }
     /*   if (new AdsManager(this).isNeedToShowAds()) {
            loadInterstialAd();
        } else {
            iv_more_app.setVisibility(View.GONE);
        }*/

//        if (mType == AppLock.UNLOCK_PIN || mType == AppLock.CHANGE_PIN) {
        if (lockType.equals(ConstantsKt.INTENT_LOCK_TYPE_FAKE)) {
            mLockManager.getAppLock().setPasscode(config.getFakeVaultAppLock());
        } else {
            mLockManager.getAppLock().setPasscode(config.getAppVaultAppLock());
        }
//        }

        mLockManager.getAppLock().setLogoId(R.drawable.drawer_icon);
        int logoId = mLockManager.getAppLock().getLogoId();
        ImageView logoImage = ((ImageView) findViewById(R.id.pin_code_logo_imageview));
//        if (logoId != AppLock.LOGO_ID_NONE) {
        logoImage.setVisibility(View.VISIBLE);
        logoImage.setImageResource(logoId);
//        }
        // TODO: 18/03/19 remove banner ads....
//        loadAdsBanner();
        mForgotTextView.setText(getForgotText());
        setForgotTextVisibility();

        setStepText();
    }


 /*   private void loadInterstialAd() {
        InterstitialAdHelper.Companion.getInstance().load(this, new InterstitialAdHelper.InterstitialAdListener() {
            @Override
            public void onAdLoaded(@NotNull InterstitialAd interstitialAd) {
                interstitialAd.show(AppLockActivity.this);
            }

            @Override
            public void onAdFailedToLoad() {
                if (OfflineNativeAdvancedHelper.INSTANCE.getUnNativeAd() != null) {
                    OfflineNativeAdDialogHelper.Companion.display(getSupportFragmentManager(), () -> null);
                }
            }

            @Override
            public void onAdClosed() {

            }
        });
        *//*if (GalleryApplication.getInstance().mInterstitialAd != null) {
            if (GalleryApplication.getInstance().mInterstitialAd.isLoaded()) {
                Log.e("TAG", "loadInterstialAd if");
                if (iv_more_app == null) {
                    iv_more_app = (ImageView) findViewById(R.id.iv_more_app);
                }

                if (iv_more_app != null) {
                    iv_more_app.setVisibility(View.VISIBLE);
                }

            } else {
                GalleryApplication.getInstance().mInterstitialAd.setAdListener(null);
                ;
                GalleryApplication.getInstance().ins_adRequest = null;
                GalleryApplication.getInstance().LoadAds();
                GalleryApplication.getInstance().mInterstitialAd.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        Log.e("TAG", "loadInterstialAd load");
                        iv_more_app.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onAdFailedToLoad(int i) {
                        super.onAdFailedToLoad(i);
                        iv_more_app.setVisibility(View.GONE);
                        loadInterstialAd();
                    }
                });
            }
        }*//*
    }
*/

    /**
     * Init {@link FingerprintManager} of the {@link Build.VERSION#SDK_INT} is > to Marshmallow
     * and {@link FingerprintManager#isHardwareDetected()}.
     */
    private void initLayoutForFingerprint() {
        Log.d(TAG, "initLayoutForFingerprint: ---> initialize");
        Log.d("TAG11", "initLayoutForFingerprint: ---> initialize");

        if (mType == AppLock.UNLOCK_PIN && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mFingerprintManager = (FingerprintManager) getSystemService(Context.FINGERPRINT_SERVICE);
            mFingerprintUiHelper = new FingerprintUiHelper.FingerprintUiHelperBuilder(mFingerprintManager).build(mFingerprintImageView, mFingerprintTextView, this);
            try {
                if (mFingerprintManager != null && mFingerprintManager.isHardwareDetected() && mFingerprintUiHelper.isFingerprintAuthAvailable()
                        && mLockManager.getAppLock().isFingerprintAuthEnabled()) {
                    mFingerprintImageView.setVisibility(View.VISIBLE);
                    mFingerprintTextView.setVisibility(View.VISIBLE);
                    mFingerprintUiHelper.startListening();
                    isAuthError = false;
                } else {
                    mFingerprintImageView.setVisibility(View.GONE);
                    mFingerprintTextView.setVisibility(View.GONE);
                }
            } catch (SecurityException e) {
                Log.e(TAG, e.toString());
                mFingerprintImageView.setVisibility(View.GONE);
                mFingerprintTextView.setVisibility(View.GONE);
            }
        } else {
            mFingerprintImageView.setVisibility(View.GONE);
            mFingerprintTextView.setVisibility(View.GONE);
        }
    }

    /**
     * Re enable {@link AppLock} if it has been collected to avoid
     * {@link NullPointerException}.
     */
    @SuppressWarnings("unchecked")
    public void enableAppLockerIfDoesNotExist() {
        try {
            if (mLockManager.getAppLock() == null) {
                mLockManager.enableAppLock(this, getCustomAppLockActivityClass());
            }
        } catch (Exception e) {
            Log.e(TAG, e.toString());
        }
    }

    /**
     * Init the {@link #mStepTextView} based on {@link #mType}
     */
    private void setStepText() {
        mStepTextView.setText(getStepText(mType));
    }

    /**
     * Gets the {@link String} to be used in the {@link #mStepTextView} based on {@link #mType}
     *
     * @param reason The {@link #mType} to return a {@link String} for
     * @return The {@link String} for the {@link AppLockActivity}
     */
    public String getStepText(int reason) {
        String msg = null;
        switch (reason) {
            case AppLock.DISABLE_PINLOCK:
                msg = getString(R.string.pin_code_step_disable, this.getPinLength());
                break;
            case AppLock.ENABLE_PINLOCK:
                msg = getString(R.string.pin_code_step_create, this.getPinLength());
                break;
            case AppLock.CHANGE_PIN:
                msg = getString(R.string.pin_code_step_change, this.getPinLength());
                break;
            case AppLock.UNLOCK_PIN:
                Log.e(TAG, "getStepText: " + "set pin activitu");
                msg = getString(R.string.pin_code_step_unlock);  //, this.getPinLength());
                break;
            case AppLock.CONFIRM_PIN:
                msg = getString(R.string.pin_code_step_enable_confirm, this.getPinLength());
                break;
        }
        return msg;
    }

    public String getForgotText() {
        return getString(R.string.pin_code_forgot_text);
    }

    private void setForgotTextVisibility() {
        if (!lockType.equals(ConstantsKt.INTENT_LOCK_TYPE_FAKE))
            mForgotTextView.setVisibility(mLockManager.getAppLock().shouldShowForgot(mType) ? View.VISIBLE : GONE);
        else
            mForgotTextView.setVisibility(View.GONE);
    }

    /**
     * Overrides to allow a slide_down animation when finishing
     */
    @Override
    public void finish() {
        super.finish();

        //If code successful, reset the timer
        if (isCodeSuccessful) {
            if (mLockManager != null) {
                AppLock appLock = mLockManager.getAppLock();
                if (appLock != null) {
                    appLock.setLastActiveMillis();
                }
            }
        }

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD_MR1) {
            //Animate if greater than 2.3.3
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ConstantsKt.setAppOpenAdShow(false);

    }

    /**
     * Add the button clicked to {@link #mPinCode} each time.
     * Refreshes also the {@link PinCodeRoundView}
     */
    @Override
    public void onKeyboardClick(KeyboardButtonEnum keyboardButtonEnum) {
        if (mPinCode.length() < this.getPinLength()) {
            int value = keyboardButtonEnum.getButtonValue();

            if (value == KeyboardButtonEnum.BUTTON_CLEAR.getButtonValue()) {
                if (!mPinCode.isEmpty()) {
                    setPinCode(mPinCode.substring(0, mPinCode.length() - 1));
                } else {
                    setPinCode("");
                }
            } else {
                setPinCode(mPinCode + value);
            }
        }
    }


    @Override
    public void onRippleAnimationEnd() {
        if (mPinCode.length() == this.getPinLength()) {
            onPinCodeInputed();
        }
    }

    /**
     * Switch over the {@link #mType} to determine if the password is ok, if we should pass to the next step etc...
     */
    protected void onPinCodeInputed() {
        switch (mType) {
            case AppLock.DISABLE_PINLOCK:

                if (mLockManager.getAppLock().checkPasscode(mPinCode)) {
                    isDisabledLock = true;
                    setResult(RESULT_OK);
                    mLockManager.getAppLock().setPasscode(null);
                    config.setEnableLock(false);
                    config.setAppPasswordProtectionOn(false);
                    onPinCodeSuccess();
                    finish();
                } else {
                    onPinCodeError();
                }

                break;
            case AppLock.ENABLE_PINLOCK:
                if (config.getAppVaultAppLock().equals(mPinCode) && lockType.equals(ConstantsKt.INTENT_LOCK_TYPE_FAKE)) {
                    Toast.makeText(activity, activity.getString(R.string.error_app_lock_and_fake_lock_not_same), Toast.LENGTH_SHORT).show();
                    mPinCode = "";
                    mPinCodeRoundView.refresh(mPinCode.length());
                } else if (config.getFakeVaultAppLock().equals(mPinCode) && !lockType.equals(ConstantsKt.INTENT_LOCK_TYPE_FAKE)) {
                    Toast.makeText(activity, activity.getString(R.string.error_app_lock_and_fake_lock_not_same), Toast.LENGTH_SHORT).show();
                    mPinCode = "";
                    mPinCodeRoundView.refresh(mPinCode.length());
                } else {
                    mOldPinCode = mPinCode;
                    setPinCode("");
                    mType = AppLock.CONFIRM_PIN;
                    setStepText();
                    setForgotTextVisibility();
                }
                break;
            case AppLock.CONFIRM_PIN:
                if (mPinCode.equals(mOldPinCode)) {
                    setResult(RESULT_OK);
                    if (lockType.equals(ConstantsKt.INTENT_LOCK_TYPE_FAKE)) {
                        config.setFakeVaultEnable(true);
                        config.setFakeVaultAppLock(mPinCode);
                    } else {
                        config.setAppPasswordProtectionOn(true);
                        config.setAppVaultAppLock(mPinCode);
                    }
                    mLockManager.getAppLock().setPasscode(mPinCode);
                    onPinCodeSuccess();
                    finish();
                } else {
                    mOldPinCode = "";
                    setPinCode("");
                    mType = AppLock.ENABLE_PINLOCK;
                    setStepText();
                    setForgotTextVisibility();
                    onPinCodeError();
                }
                break;
            case AppLock.CHANGE_PIN:
                if (mLockManager.getAppLock().checkPasscode(mPinCode)) {
                    mType = AppLock.ENABLE_PINLOCK;
                    setStepText();
                    setForgotTextVisibility();
                    setPinCode("");
                    onPinCodeSuccess();
                } else {
                    onPinCodeError();
                }
                break;
            case AppLock.UNLOCK_PIN:

                if (mLockManager.getAppLock().checkPasscode(mPinCode)) {
                   UtilsKt.isUnLockApp = true;
                    setResult(RESULT_OK);
                    onPinCodeSuccess();
                    finish();
                } else {
                    onPinCodeError();
                }

                break;
            default:
                break;
        }
    }

    /**
     * Override {@link #onBackPressed()} to prevent user for finishing the activity
     */
    @Override
    public void onBackPressed() {

        Log.e("TAG", "mType  ======> " + mType);
        if (config.getOldLockTypePattern().equals(ConstantsKt.LOCK_PATTERN) || config.getOldLockTypeWhenFingerPrintEnable().equals(ConstantsKt.LOCK_PATTERN)) {
            finishAffinity();
        } else {
            setResult(RESULT_CANCELED);
            super.onBackPressed();
        }
    }

    @Override
    public void onAuthenticated() {
        Log.e(TAG, "Fingerprint READ!!!");
        UtilsKt.isUnLockApp = true;
        setResult(RESULT_OK);
        onPinCodeSuccess();
        finish();
    }

    @Override
    public void onError() {
        Log.e(TAG, "Fingerprint READ ERROR!!!");
        isAuthError = true;
        /*if (config.isFingerprintEnable()) {
            initLayoutForFingerprint();
        } else {
            mFingerprintImageView.setVisibility(View.GONE);
            mFingerprintTextView.setVisibility(View.GONE);
        }*/
    }

    /**
     * Gets the list of {@link AppLock} types that are acceptable to be backed out of using
     * the device's back button
     *
     * @return an {@link List<Integer>} of {@link AppLock} types which are backable
     */
    public List<Integer> getBackableTypes() {
        return Arrays.asList(AppLock.CHANGE_PIN, AppLock.DISABLE_PINLOCK, AppLock.ENABLE_PINLOCK, AppLock.CONFIRM_PIN);  //TODo Add here  ENABLE_PINLOCK
    }


    /**
     * Run a shake animation when the password is not valid.
     */
    protected void onPinCodeError() {
        onPinFailure(mAttempts++);
        Thread thread = new Thread() {
            public void run() {
                mPinCode = "";
                mPinCodeRoundView.refresh(mPinCode.length());
                Animation animation = AnimationUtils.loadAnimation(
                        AppLockActivity.this, R.anim.shake_lock);
                if (mType != AppLock.DISABLE_PINLOCK)
                    mKeyboardView.startAnimation(animation);
                if (mType == AppLock.DISABLE_PINLOCK && !isDisabledLock)
                    Toast.makeText(AppLockActivity.this, activity.getString(R.string.error_wrong_pin), Toast.LENGTH_SHORT).show();
            }
        };
        runOnUiThread(thread);
    }

    protected void onPinCodeSuccess() {
        isCodeSuccessful = true;

        onPinSuccess(mAttempts);
        mAttempts = 1;
        if (ChangePatternLock) {
            config.setAppPasswordProtectionOn(true);
            config.setEnableLock(true);
            config.setOldLockTypePattern("");
            config.setOldLockTypeWhenFingerPrintEnable("");
            startActivity(MainActivity.Companion.newIntent(this));

        }
    }

    /**
     * Set the pincode and refreshes the {@link PinCodeRoundView}
     */
    public void setPinCode(String pinCode) {
        mPinCode = pinCode;
        mPinCodeRoundView.refresh(mPinCode.length());
    }


    /**
     * Returns the type of this {@link AppLockActivity}
     */
    public int getType() {
        return mType;
    }

    /**
     * When we click on the {@link #mForgotTextView} handle the pop-up
     * dialog
     *
     * @param view {@link #mForgotTextView}
     */
    @Override
    public void onClick(View view) {
        if (view == mForgotTextView)
            selectSequrityStep();
        else if (view == iv_back)
            //for pattern lock
            if (config.getOldLockTypePattern().equals(ConstantsKt.LOCK_PATTERN) || config.getOldLockTypeWhenFingerPrintEnable().equals(ConstantsKt.LOCK_PATTERN)) {
                finishAffinity();
            } else
                onBackPressed();
        else if (view == iv_more_app) {
            ConstantsKt.setAppOpenAdShow(false);
            is_closed = false;
            iv_more_app.setVisibility(View.GONE);
            iv_blast.setVisibility(View.VISIBLE);
            ((AnimationDrawable) iv_blast.getBackground()).start();
         /*   if (GalleryApplication.getInstance().requestNewInterstitial()) {
                Share.isInertialShow=true;

                GalleryApplication.getInstance().mInterstitialAd.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        Share.isInertialShow=false;

                        super.onAdClosed();
                        Log.e("ad cloced", "ad closed");
                        iv_blast.setVisibility(View.GONE);
                        iv_more_app.setVisibility(View.GONE);
                        iv_more_app.setBackgroundResource(R.drawable.animation_list_filling);
                        ((AnimationDrawable) iv_more_app.getBackground()).start();
                        is_closed = true;
                        loadInterstialAd();
                    }

                    @Override
                    public void onAdFailedToLoad(int i) {
                        super.onAdFailedToLoad(i);
                        Log.e("fail", "fail");
                        iv_blast.setVisibility(View.GONE);
                        iv_more_app.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        Log.e("loaded", "loaded");
                        iv_blast.setVisibility(View.GONE);
                        iv_more_app.setVisibility(View.GONE);
                        is_closed = false;
                    }
                });
            } else {
                Log.e("else", "else");
                iv_blast.setVisibility(View.GONE);
                iv_more_app.setVisibility(View.GONE);
            }*/
        } else if (view == mFingerprintImageView) {
            if (mFingerprintUiHelper != null && isAuthError) {
                isAuthError = false;
                mFingerprintUiHelper.stopListening();
                initLayoutForFingerprint();
            }
        }
    }

    private void selectSequrityStep() {
        View view = getLayoutInflater().inflate(R.layout.dialog_set_security_question, null);
        Dialog dialog = new Dialog(AppLockActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(view);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        ImageView ivClose = dialog.findViewById(R.id.ivClose);
        EditText etSeqAns = dialog.findViewById(R.id.etSeqAns);
        Spinner spSecQue = dialog.findViewById(R.id.spSecQue);
        final String[] selectedSecQue = {""};
        final int[] selectedPos = {0};
        spSecQue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSecQue[0] = (String) spSecQue.getSelectedItem();
                selectedPos[0] = spSecQue.getSelectedItemPosition();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        TextView tvDone = dialog.findViewById(R.id.tvDone);
        tvDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPos[0] == 0) {
                    Toast.makeText(AppLockActivity.this, activity.getString(R.string.error_msg_please_select_que), Toast.LENGTH_SHORT).show();

                } else if (etSeqAns.getText().toString().isEmpty()) {
                    Toast.makeText(AppLockActivity.this, activity.getString(R.string.error_please_enter_answer), Toast.LENGTH_SHORT).show();
                } else if (etSeqAns.getText().toString().length() < 5) {
                    Toast.makeText(AppLockActivity.this, activity.getString(R.string.error_msg_please_enter_valid_answer), Toast.LENGTH_SHORT).show();
                } else {
                    if (selectedPos[0] != config.getSecurityQuestionIndex()
                            || !etSeqAns.getText().toString().equals(config.getSecurityAnswer())) {
                        Toast.makeText(AppLockActivity.this, getString(R.string.msg_security_invalid), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AppLockActivity.this, activity.getString(R.string.msg_match_successfully), Toast.LENGTH_SHORT).show();
                        mType = AppLock.ENABLE_PINLOCK;
                        setStepText();
                        setForgotTextVisibility();
                        mFingerprintImageView.setVisibility(View.GONE);
                        mFingerprintTextView.setVisibility(View.GONE);
                        setPinCode("");
                        onPinCodeSuccess();
                    }
                    dialog.dismiss();
                }
            }
        });
        dialog.show();



     /*   final EditText et_enteranswer = (EditText) dialog.findViewById(R.id.et_enteranswer);
        //et_enteranswer.setOnEditorActionListener(this);

        //  final EditText et_enterquestions = (EditText) dialog.findViewById(R.id.et_enterquestions);
        final LinearLayout im_remove = (LinearLayout) dialog.findViewById(R.id.im_remove);
        final LinearLayout ln_submit = (LinearLayout) dialog.findViewById(R.id.ln_submit);
        final TextView txt_submit = (TextView) dialog.findViewById(R.id.txt_submit);
        final TextView top_txt = dialog.findViewById(R.id.top_txt);

        final TextView txt1 = (TextView) dialog.findViewById(R.id.txt1);
        final TextView txt2 = (TextView) dialog.findViewById(R.id.txt2);
        final ImageView img_cancle = dialog.findViewById(R.id.img_cancle);

        Spinner spinner = (Spinner) dialog.findViewById(R.id.spinner_d);
        Drawable spinnerDrawable = spinner.getBackground().getConstantState().newDrawable();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            spinner.setBackground(spinnerDrawable);
        } else {
            spinner.setBackgroundDrawable(spinnerDrawable);
        }

        spinner.setPopupBackgroundResource(R.drawable.spinner_background);


        int Heder = Share.getAPPThemWisePrimoryColor(getApplicationContext());
        if (Share.getATEKey(AppLockActivity.this).equals("dark_theme")) {
            int TEXTCOLOR = getResources().getColor(R.color.black);
            top_txt.setTextColor(TEXTCOLOR);
            et_enteranswer.setHintTextColor(getResources().getColor(R.color.gray1));
            img_cancle.setColorFilter(TEXTCOLOR, PorterDuff.Mode.SRC_IN);
            et_enteranswer.setTextColor(TEXTCOLOR);
            // txt_submit.setTextColor(TEXTCOLOR);
            spinnerDrawable.setColorFilter(TEXTCOLOR, PorterDuff.Mode.SRC_ATOP);
            ln_submit.setBackgroundColor(TEXTCOLOR);

        } else {
            int TEXTCOLOR = Share.getAppPrimaryColor(getApplicationContext());
            top_txt.setTextColor(TEXTCOLOR);
            et_enteranswer.setHintTextColor(getResources().getColor(R.color.gray1));
            img_cancle.setColorFilter(TEXTCOLOR, PorterDuff.Mode.SRC_IN);
            et_enteranswer.setTextColor(getResources().getColor(R.color.black));
            //  txt_submit.setTextColor(TEXTCOLOR);
            spinnerDrawable.setColorFilter(TEXTCOLOR, PorterDuff.Mode.SRC_ATOP);
            ln_submit.setBackgroundColor(TEXTCOLOR);

        }


        txt1.setTextColor(Heder);
        txt2.setTextColor(Heder);


        List<String> list = new ArrayList<>();
        list.add("Select Your Question..");
        list.add("Which is your favorite movie?");
        list.add("What is your favorite food?");
        list.add("Who is your favorite actress?");
        list.add("What's your lucky number?");
        list.add("In which city were you born?");

        final String[] que = {""};

        et_enteranswer.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                *//*if (et_enteranswer.getText().toString().length() == 0) {
                    txt_submit.setTextColor(getResources().getColor(R.color.white_off));
                } else {
                    txt_submit.setTextColor(getResources().getColor(R.color.white));
                }*//*
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        im_remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_enteranswer.getText().clear();
            }
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout, list);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                et_enteranswer.getText().clear();
                que[0] = (String) parent.getItemAtPosition(position);
                if (position == 0) {
                    et_enteranswer.setEnabled(false);
                    que[0] = "none";
                } else
                    et_enteranswer.setEnabled(true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        ln_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (que[0].equals("none")) {
                    Toast.makeText(AppLockActivity.this, "Please select question", Toast.LENGTH_SHORT).show();
                } else {
                    if (et_enteranswer.getText().toString().equals(""))
                        Toast.makeText(AppLockActivity.this, "Please enter answer", Toast.LENGTH_SHORT).show();
                    else if (et_enteranswer.getText().toString().length() < 5)
                        Toast.makeText(AppLockActivity.this, "Please enter at least 5 character in answer", Toast.LENGTH_SHORT).show();
                    else {

                        //here match que  and ans
                        String stored_que = tinyDB.getString(Share.BACKUP_QUESTION);
                        String stored_ans = tinyDB.getString(Share.BACKUP_ANSWER);

                        if (stored_que.equals(que[0]) && stored_ans.equals(et_enteranswer.getText().toString().trim())) {
                            Toast.makeText(AppLockActivity.this, "Matched successfully", Toast.LENGTH_SHORT).show();

                            mType = AppLock.ENABLE_PINLOCK;
                            setStepText();
                            setForgotTextVisibility();
                            setPinCode("");
                            onPinCodeSuccess();
                            //here create new password:-
                        } else {
                            Toast.makeText(AppLockActivity.this, "Sorry it's wrong", Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                    }
                }
            }

        });
*/


    }

    /**
     * When the user has failed a pin challenge
     *
     * @param attempts the number of attempts the user has used
     */
    public abstract void onPinFailure(int attempts);

    /**
     * When the user has succeeded at a pin challenge
     *
     * @param attempts the number of attempts the user had used
     */
    public abstract void onPinSuccess(int attempts);

    /**
     * Gets the resource id to the {@link View} to be set with {@link #setContentView(int)}.
     * The custom layout must include the following:
     * - {@link TextView} with an id of pin_code_step_textview
     * - {@link TextView} with an id of pin_code_forgot_textview
     * - {@link PinCodeRoundView} with an id of pin_code_round_view
     * - {@link KeyboardView} with an id of pin_code_keyboard_view
     *
     * @return the resource id to the {@link View}
     */
    public int getContentView() {
        return R.layout.activity_pin_code;
    }

    /**
     * Gets the number of digits in the pin code.  Subclasses can override this to change the
     * length of the pin.
     *
     * @return the number of digits in the PIN
     */
    public int getPinLength() {
        return AppLockActivity.DEFAULT_PIN_LENGTH;
    }

    /**
     * Get the current class extending {@link AppLockActivity} to re-enable {@link AppLock}
     * in case it has been collected
     *
     * @return the current class extending {@link AppLockActivity}
     */
    public Class<? extends AppLockActivity> getCustomAppLockActivityClass() {
        return this.getClass();
    }
}
