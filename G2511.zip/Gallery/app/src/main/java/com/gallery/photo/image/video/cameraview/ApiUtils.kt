package com.gallery.photo.image.video.cameraview

import android.content.Context
import android.util.Base64
import com.gallery.photo.image.video.R
import java.io.UnsupportedEncodingException
import java.nio.charset.Charset

fun Context.getTestBaseUrl(): String {
    return getString(R.string.base_url)
}

