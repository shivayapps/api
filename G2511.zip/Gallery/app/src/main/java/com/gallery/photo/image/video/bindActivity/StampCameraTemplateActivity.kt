package com.gallery.photo.image.video.bindActivity

import android.app.Activity
import android.content.ContextWrapper
import android.content.Intent
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.app.ads.helper.GiftIconHelper
import com.example.jdrodi.utilities.isOnline
import com.gallery.photo.image.video.BuildConfig
import com.gallery.photo.image.video.Camera.CameraActivity
import com.gallery.photo.image.video.R
import com.gallery.photo.image.video.adshelper.AdsManager
import com.gallery.photo.image.video.cameraview.APIService
import com.gallery.photo.image.video.cameraview.database.CameraStampDatabase
import com.gallery.photo.image.video.cameraview.database.model.CameraStamp
import com.gallery.photo.image.video.cameraview.stampmodel.Data
import com.gallery.photo.image.video.cameraview.stampmodel.Stampmodel
import com.gallery.photo.image.video.cameraview.ui.NetworkChangeReceiver
import com.gallery.photo.image.video.cameraview.ui.adapter.StampAdapter
import com.gallery.photo.image.video.databinding.ActivityStampCameraTemplateBinding
import com.gallery.photo.image.video.extensions.inflater
import com.gallery.photo.image.video.utilities.*
import com.gallery.photo.image.video.videoplayer.Utils
import com.gallery.photo.image.video.views.VerticalSpaceItemDecoration
import com.google.android.material.appbar.AppBarLayout
import ir.mahdi.mzip.zip.ZipArchive
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.*
import java.util.ArrayList

class StampCameraTemplateActivity : BaseBindingActivity<ActivityStampCameraTemplateBinding>(), NetworkChangeReceiver.ConnectivityReceiverListener1 {
    private var base_path = ""
    private var mAdapter: StampAdapter? = null
    var storyList: ArrayList<Data> = ArrayList<Data>()
    private var apiInterface: APIService.APIInterface? = null
    private var mDb: CameraStampDatabase? = null
    var isFromOneSignal = false
    override fun getContext(): Activity {
        return this
    }

    override fun initData() {
        Log.d(TAG, "initData: ")
        mDb = CameraStampDatabase.getInstance(this)
        mBinding.tvTitle.text = resources.getString(R.string.stamp_template)
        mBinding.imgBack!!.visibility = View.VISIBLE
        mBinding.imgBack.setOnClickListener(this)
        if (intent.hasExtra("IsCheckOneSignalNotification")) {
            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
//            mPos = intent.getIntExtra("mType", 0)
        }
        base_path = cacheDir.path
        if (AdsManager(this).isNeedToShowAds()) {
            GiftIconHelper.loadGiftAd(
                fContext = this,
                fivGiftIcon = mBinding.giftLayout.giftAdIcon,
                fivBlastIcon = mBinding.giftLayout.giftBlastAdIcon
            )
        }
        mBinding.rvStamp!!.layoutManager = LinearLayoutManager(
            mContext,
            LinearLayoutManager.VERTICAL,
            false
        )
        if (SharedPrefs.getBoolean(this, SharedPrefs.IS_ENABLE_STAMP, true)) {
            mBinding.imgEnableStampRight.setImageDrawable(getDrawable(R.drawable.ic_switch_on))
        } else {
            mBinding.imgEnableStampRight.setImageDrawable(getDrawable(R.drawable.ic_switch_off))
        }
//
        mBinding.clFakeVault.setOnClickListener {
            if (SharedPrefs.getBoolean(this, SharedPrefs.IS_ENABLE_STAMP, true)) {
                SharedPrefs.savePref(this, SharedPrefs.IS_ENABLE_STAMP, false)
                mBinding.imgEnableStampRight.setImageDrawable(getDrawable(R.drawable.ic_switch_off))
            } else {
                SharedPrefs.savePref(this, SharedPrefs.IS_ENABLE_STAMP, true)
                mBinding.imgEnableStampRight.setImageDrawable(getDrawable(R.drawable.ic_switch_on))
            }
        }
        if (storyList.size == 0) {
            adapterset()
            apiCallAndSetAdapter()
        } else {
            adapterset()
            mBinding.rvStamp!!.addItemDecoration(
                VerticalSpaceItemDecoration(
                    Utils.dpToPx(12),
                    true,
                    storyList.size
                )
            )
            mBinding.rvStamp!!.adapter = mAdapter
            if (storyList.size == 0) {
                val params: AppBarLayout.LayoutParams = mBinding.clFakeVault.layoutParams as AppBarLayout.LayoutParams
                params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
                mBinding.appBarLayout.requestLayout()
            } else {
                val params: AppBarLayout.LayoutParams = mBinding.clFakeVault.layoutParams as AppBarLayout.LayoutParams
                params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL
                mBinding.appBarLayout.requestLayout()
            }
        }
    }

    override fun initActions() {
        Log.d(TAG, "initActions: ")

    }

    override fun onClick(view: View) {
        super.onClick(view)
        when (view.id) {
            R.id.imgBack -> {
                onBackPressed()
            }
        }
    }

    private fun apiCallAndSetAdapter() {


        Log.d(TAG, "getAndSetData()")

        if (isOnline() && SharedPrefs.getBoolean(
                mContext,
                "isdatathare",
                true
            )
        ) {
            Log.d(TAG, "setAdapter:  If condition")
            apiInterface = APIService().getClient(this)
            val call: Call<Stampmodel> = apiInterface!!.doGetAllImage()

            call.enqueue(object : Callback<Stampmodel> {
                override fun onResponse(call: Call<Stampmodel>, response: Response<Stampmodel>) {
                    Log.d(TAG, "onResponse:  -->" + response.body())
                    if (response.body() != null) {

                        val templateData: Stampmodel = response.body()!!
                        if (templateData.data != null) {
                            Log.e(TAG, "onResponse: " + templateData.data.size)

                            SharedPrefs.savePref(mContext, "isdatathare", false)
                            storyList.addAll(templateData.data)
                            saveArrayList(storyList, "stampdata", mContext)

                            mAdapter!!.notifyDataSetChanged()
                            if (storyList.size == 0) {
                                val params: AppBarLayout.LayoutParams = mBinding.clFakeVault.layoutParams as AppBarLayout.LayoutParams
                                params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
                                mBinding.appBarLayout.requestLayout()
                            } else {
                                val params: AppBarLayout.LayoutParams = mBinding.clFakeVault.layoutParams as AppBarLayout.LayoutParams
                                params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL
                                mBinding.appBarLayout.requestLayout()
                            }
                        }
                        dismissProgress()

                    }
                }

                override fun onFailure(call: Call<Stampmodel>, t: Throwable) {
                    Log.e(TAG, "onResponse: " + t.message)
                    call.cancel()
                }

            })
        } else {
            Log.d(TAG, "setAdapter:  else")
            if (getArrayList("stampdata", context = mContext).size != 0) {

                storyList = getArrayList("stampdata", context = mContext)

                Log.e(TAG, "getAndSetData: " + storyList.size)
                Log.e(TAG, "getAndSetData: " + mAdapter!!.mList.size)

                mAdapter!!.refAdapter(storyList)

                Log.e(TAG, "getAndSetData: " + mAdapter!!.mList.size)

            }
        }


        mBinding.rvStamp!!.addItemDecoration(
            VerticalSpaceItemDecoration(
                Utils.dpToPx(12),
                true,
                storyList.size
            )
        )
        mBinding.rvStamp!!.adapter = mAdapter
        if (storyList.size == 0) {
            val params: AppBarLayout.LayoutParams = mBinding.clFakeVault.layoutParams as AppBarLayout.LayoutParams
            params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_NO_SCROLL
            mBinding.appBarLayout.requestLayout()
        } else {
            val params: AppBarLayout.LayoutParams = mBinding.clFakeVault.layoutParams as AppBarLayout.LayoutParams
            params.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL
            mBinding.appBarLayout.requestLayout()
        }
    }

    private fun saveToDisk(body: ResponseBody, fileName: String): String {

        try {
            val unzipedPath = "$base_path/$fileName"

            val destinationFile = File("$base_path/$fileName.zip")

            Log.e(TAG, "saveToDisk: $destinationFile")

            File(unzipedPath).mkdir()

            var inputStream: InputStream? = null
            var outputStream: OutputStream? = null

            try {

                val filesize = body.contentLength()
                Log.d("MakeStoryActivity", "File Size=${filesize}")
                inputStream = body.byteStream()
                outputStream = FileOutputStream(destinationFile)
                val data = ByteArray(4096)
                var count: Int
                var progress = 0

                while (inputStream.read(data).also { count = it } != -1) {
                    outputStream.write(data, 0, count)
                    progress += count
                }

                outputStream.flush()
                ZipArchive.unzip(destinationFile.absolutePath, unzipedPath, "")
                Log.e("MakeStoryActivity", "File saved successfully: $unzipedPath")

                return unzipedPath
            } catch (e: IOException) {
                e.printStackTrace()
                Log.e("MakeStoryActivity", "Failed to save the file! 001:${e.message}")
                Log.e(TAG, "unzip: " + e.localizedMessage)

                return ""
            } finally {
                inputStream?.close()
                outputStream?.close()
            }
        } catch (e: IOException) {
            e.printStackTrace()
            Log.e("MakeStoryActivity", "Failed to save the file! 002:${e.message}")
            return ""
        }

    }

    private fun downloadZipFile(zip_name: String, pos: Int) {

        var fileName: String = zip_name.substring(zip_name.lastIndexOf('/') + 1)
        fileName = fileName.plus(BuildConfig.VERSION_NAME)
        if (File("$base_path/$fileName".replace(".zip", "")).exists()) {

            fileName = fileName.replace(".zip", "")

            //   openLayout("$base_path/$fileName")

            Log.e(TAG, "downloadZipFile: $base_path/$fileName")

            SharedPrefs.save(mContext, STAMP_ID, pos)
            SharedPrefs.save(mContext, STAMP_PATH, "$base_path/$fileName")


            setResult(Activity.RESULT_OK)
            mAdapter!!.notifyDataSetChanged()
            dismissProgress()

        } else {

            apiInterface = APIService().getClient(this)
            val call: Call<ResponseBody> = apiInterface!!.downloadFileByUrl(zip_name)
            fileName = fileName.replace(".zip", "")

            Log.e(TAG, "downloadZipFile: 23 $fileName")
//            showProgress("Loading...")
            call.enqueue(object : Callback<ResponseBody> {
                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: Response<ResponseBody>
                ) {
                    if (response.isSuccessful) {
                        var path = ""
                        AsyncBackgroundWork({}, {
                            path = saveToDisk(response.body()!!, fileName)
                        }, {
                            dismissProgress()
                            mAdapter!!.notifyDataSetChanged()
                            SharedPrefs.save(mContext, STAMP_ID, pos)
                            SharedPrefs.save(mContext, STAMP_PATH, path)

                            var stampList: List<CameraStamp> =
                                mDb!!.cameraStampDao().loadStampListById(pos)
                            val cameraStamp = CameraStamp(
                                null,
                                pos,
                                path,
                                "",
                                "dd MMMM, yyyy HH:mm",
                                90F,
                                0
                            )
                            if (stampList.isNotEmpty()) {
                                Log.e(TAG, "onPostExecute: ")
                                mDb!!.cameraStampDao().updateStamp(cameraStamp)
                            } else {
                                mDb!!.cameraStampDao().insertStamp(cameraStamp)
                            }

                            setResult(Activity.RESULT_OK)
                        })

                    } else {
                        Log.d("MakeStoryActivity", "Connection failed " + response.errorBody())
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    dismissProgress()
                    t.printStackTrace()
                    Log.e("MakeStoryActivity", t.message!!)
                }

            })

        }

    }

    private fun adapterset() {
        mAdapter = StampAdapter(mContext, storyList, { data, position ->
            Log.e(TAG, "adapterset: " + data.zip_name)
            addEvent(stampSelect+"_"+data.id)
            if (!NetworkManager.isInternetConnected(mContext)) {
                var fileName: String = data.zip_name.substring(data.zip_name.lastIndexOf('/') + 1)
                fileName = fileName.replace(".zip", "")

                Log.e(
                    TAG,
                    "initView: " + ContextWrapper(mContext).externalCacheDir.toString() + "/" + fileName
                )

                if (File(
                        ContextWrapper(mContext).externalCacheDir.toString() + "/" + fileName
                    ).exists()
                ) {

                    setData(data, position)
                } else {
                    NetworkManager.internetErrorDialog(mContext)
                }
            } else {
                Log.e(TAG, "initVasdiew: ")
                setData(data, position)
            }

        }, {
            mBinding.clNoDataFound!!.visibility = View.GONE
        })
    }

    private fun setData(storyData: Data, pos: Int) {

        showProgress(getString(R.string.label_loading))
        downloadZipFile(storyData.zip_name, pos)

        Log.e(TAG, "setData: " + storyData.zip_name)

    }

    override fun setBinding(): ActivityStampCameraTemplateBinding {
        return ActivityStampCameraTemplateBinding.inflate(inflater)
    }

    override fun onNetworkConnectionChanged(isConnected: Boolean) {
        Log.e(TAG, "*-*-*-*-*-**-*-*-*-*-*-*-*-*-*: $isConnected")
    }

    override fun onBackPressed() {
        if (isFromOneSignal) {
            val intent = Intent(mContext, CameraActivity::class.java)
            startActivity(intent)
        } else
            super.onBackPressed()
    }
}