package com.gallery.photo.image.video.models;

import java.io.Serializable;
import java.util.ArrayList;

public class placeModle implements Serializable {


    public String placeName;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String date;


    public String f9757b;


    public String f9758c;


    public ArrayList<String> pathList;


    public String f9760e;


    int f9761f;


    public String f9762g;


    public int mo25541a() {
        return this.f9761f;
    }


    public void mo25542a(int i) {
        this.f9761f = i;
    }


    public ArrayList<String> getFolderDataPath() {
        return this.pathList;
    }


    public void setFolderPathList(ArrayList<String> arrayList) {
        this.pathList = arrayList;
    }


    public String getplaceName() {
        return this.placeName;
    }


    public void serplaceName(String str) {
        this.placeName = str;
    }

    /* renamed from: d */
    public String mo25549d() {
        return this.f9757b;
    }


    public void mo25546b(String str) {
        this.f9757b = str;
    }


    public String mo25550e() {
        return this.f9760e;
    }


    public void mo25548c(String str) {
        this.f9760e = str;
    }

    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof placeModle)) {
            return false;
        }
        return getplaceName().equals(((placeModle) obj).getplaceName());
    }
}
