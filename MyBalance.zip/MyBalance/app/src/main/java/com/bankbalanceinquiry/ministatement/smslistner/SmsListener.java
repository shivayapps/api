package com.bankbalanceinquiry.ministatement.smslistner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.text.TextUtils;
import android.util.Log;

import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.common.ReadJsonFile;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databased.DBHelperAccountHistory;
import com.bankbalanceinquiry.ministatement.databased.DBHelperBills;
import com.bankbalanceinquiry.ministatement.databased.DBHelperCash;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;
import com.bankbalanceinquiry.ministatement.model.BilsEmiModel;
import com.bankbalanceinquiry.ministatement.model.CashModelHistory;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsListener extends BroadcastReceiver {

    private DBHelperCash mydbCash;
    private DBHelperBills mydbBill;
    private DBHelperAccountHistory dbHelperAccountHistory;
    private ArrayList<AvilabeBalanceModel> avilabeBalanceModels;

    private String BankName = "";
    private String BankNameFinal = "";
    private int BankIconFinal = 0;
    List<bankname> mData;

    private ArrayList<CashModelHistory> cashModelHistories;
    private ArrayList<BilsEmiModel> bilsEmiModels;
    private ArrayList<AllAccountModelHistory> allAccountModelHistories;
    String TodayDate = "";
    private ArrayList<String> AllBankingTransferFrom = new ArrayList<>();

    private boolean isNotify = false;
    DBHelperAccountNew mydbAccountNew;

    private ArrayList<HomeAccoutList> homeAccoutLists = new ArrayList<>();
    private ArrayList<HomeAccoutList> allTransactionList = new ArrayList<>();

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO Auto-generated method stub
        Log.e("SMSRECIVED", " onReceive");
        if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {
            Bundle bundle = intent.getExtras();           //---get the SMS message passed in---
            SmsMessage[] msgs = null;
            String msg_from;
            if (bundle != null) {
                try {

                    DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
                    Date date = new Date();
                    String TodayDatefind = dateFormat.format(date);
                    TodayDate = TodayDatefind.toUpperCase();

                    homeAccoutLists = new ArrayList<>();
                    allTransactionList = new ArrayList<>();


                    try {
                        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                        databaseAccess.open();
                        mData = databaseAccess.getList();
                        databaseAccess.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    mydbCash = new DBHelperCash(context);
                    mydbBill = new DBHelperBills(context);
                    dbHelperAccountHistory = new DBHelperAccountHistory(context);
                    JSONArray jsonArray = ReadJsonFile.GetAssetsFileGetDataJsonArray(context, "sms/rulestmp");
                    Object[] pdus = (Object[]) bundle.get("pdus");
                    msgs = new SmsMessage[pdus.length];
                    mydbAccountNew = new DBHelperAccountNew(context);
                    for (int i = 0; i < msgs.length; i++) {
                        msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                        String BankNameTitle = msgs[i].getOriginatingAddress();
                        String body = msgs[i].getMessageBody();
                        long dateV = msgs[i].getTimestampMillis();
                        if (body.contains("*")) {
                            body = body.replace("*", "");
                        }
                        CheckisTransactionSms(jsonArray, BankNameTitle, body, dateV);

                    }
                    for (int i = 0; i < homeAccoutLists.size(); i++) {
                        HomeAccoutList alldata = homeAccoutLists.get(i);
                        try {
                            mydbAccountNew.InsertAccount(alldata);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    for (int i = 0; i < allTransactionList.size(); i++) {
                        HomeAccoutList alldata = allTransactionList.get(i);
                        try {
                            mydbAccountNew.InsertTransaction(alldata);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    if (isNotify) {
                        CommonFun.isIncommingSmsNotify = "Yes";
                    } else {
                        CommonFun.isIncommingSmsNotify = "";
                    }
                } catch (Exception e) {
                    e.printStackTrace();
//                            Log.d("Exception caught",e.getMessage());
                }
            }
        }
    }

    private void CheckisTransactionSms(JSONArray jsonArray, String bankNameTitle, String body, long dateV) {
        JSONObject jsonObject;
        JSONArray senderss;
        int mObjectPosition = 999;

        SimpleDateFormat formatterAccount = new SimpleDateFormat("dd-MMM-yy");
        SimpleDateFormat FormateMontHistory = new SimpleDateFormat("MMMM");
        SimpleDateFormat formatterHistory = new SimpleDateFormat("dd MMMM yyyy");

        HomeAccoutList homeAccount = new HomeAccoutList();
        homeAccount.body = body;

        if (!TextUtils.isEmpty(bankNameTitle)) {
            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    jsonObject = jsonArray.optJSONObject(i);
                    senderss = jsonObject.optJSONArray("senders");
                    if (senderss != null) {
                        for (int j = 0; j < senderss.length(); j++) {
                            try {
                                String SenderName = senderss.get(j).toString();
                                if (bankNameTitle.toLowerCase().contains(SenderName.toLowerCase())) {
                                    mObjectPosition = i;
                                    homeAccount.full_name = jsonObject.getString("full_name");
                                    break;
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            if (mObjectPosition != 999) {
                try {
                    getTransectionDetails(homeAccount, body, jsonArray.getJSONObject(mObjectPosition));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        homeAccount.dateValAccount = formatterAccount.format(new Date(dateV));
        homeAccount.DateTransactionHistory = FormateMontHistory.format(new Date(dateV));
        homeAccount.dateValHistory = formatterHistory.format(new Date(dateV));


        if (homeAccount.account_type.equalsIgnoreCase("electricity")) {
            try {
                if (jsonArray != null) {
                    JSONObject object = jsonArray.getJSONObject(mObjectPosition);
                    JSONArray senders = object.optJSONArray("senders");
                    if (senders != null) {
                        for (int j = 0; j < senders.length(); j++) {
                            try {
                                String SenderName = senders.get(j).toString();
                                if (bankNameTitle.toLowerCase().contains(SenderName.toLowerCase())) {
                                    homeAccount.full_name = SenderName;
                                    break;
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        // Account List
        if (!homeAccount.account_type.equalsIgnoreCase("phone")) {
            if (!TextUtils.isEmpty(homeAccount.FinalAccountBalance) || homeAccount.account_type.equalsIgnoreCase("prepaid")|| homeAccount.account_type.equalsIgnoreCase("bill_pay")) {
                if (!TextUtils.isEmpty(homeAccount.full_name)) {
                    if (!TextUtils.isEmpty(homeAccount.FinalAccountNo)) {
                        if (homeAccount.FinalAccountNo.length() > 4) {
                            homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
                        }
                        ArrayList<HomeAccoutList> accountList = mydbAccountNew.GetAllAccountNew();
                        if (accountList.size() != 0) {
                            boolean isF = false;
                            for (int i = 0; i < accountList.size() && !isF; i++) {
                                if (accountList.get(i).FinalAccountNo.length() > homeAccount.FinalAccountNo.length()) {
                                    if (accountList.get(i).FinalAccountNo.contains(homeAccount.FinalAccountNo)) {
                                        isF = true;
                                        homeAccount.FinalAccountNo = accountList.get(i).FinalAccountNo;
                                    }
                                } else {
                                    if (homeAccount.FinalAccountNo.contains(accountList.get(i).FinalAccountNo)) {
                                        isF = true;
                                        homeAccount.FinalAccountNo = accountList.get(i).FinalAccountNo;
                                    }
                                }
                            }
                            if (!isF) {
                                homeAccoutLists.add(homeAccount);
                            }

                        } else {
                            homeAccoutLists.add(homeAccount);
                        }
                    } else {
                        if (!checkPrepaidAccount(homeAccount)) {
                            homeAccoutLists.add(homeAccount);
                        }
                    }
                }
            }
        }


        // Account History
        if (!TextUtils.isEmpty(homeAccount.full_name)) {
            if (!TextUtils.isEmpty(homeAccount.amount)) {
                String amount = homeAccount.amount.replaceAll(",", "");
                homeAccount.amount = amount;
                if (homeAccount.FinalAccountNo.length() > 4) {
                    homeAccount.FinalAccountNo = homeAccount.FinalAccountNo.substring(homeAccount.FinalAccountNo.length() - 4);
                }

                if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
                    if (!TextUtils.isEmpty(homeAccount.mTransactionType)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.mTransactionType);
                    } else if (!TextUtils.isEmpty(homeAccount.txn_type)) {
                        homeAccount.transactionDesc = getTransactionDesc(homeAccount.txn_type);
                    } else {
                        homeAccount.transactionDesc = "Unknown Transaction";
                    }
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("atm") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_atm")) {
                    homeAccount.transactionDesc = "ATM withdrawal";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("debit") ||
                        homeAccount.transactionDesc.equalsIgnoreCase("debit_card")) {
                    homeAccount.transactionDesc = "Debit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card")) {
                    homeAccount.transactionDesc = "Credit Card Transaction";
                } else if (homeAccount.transactionDesc.equalsIgnoreCase("credit_card_bill")) {
                    homeAccount.transactionDesc = "Credit Card Bill";
                }

                if (!TextUtils.isEmpty(homeAccount.transactionPos)) {
                    homeAccount.finalTransactionDesc = homeAccount.transactionPos;
                } else if (homeAccount.transactionDescs.size() != 0) {
                    for (String s : homeAccount.transactionDescs) {
                        if (!TextUtils.isEmpty(s)) {
                            homeAccount.finalTransactionDesc = s;
                            break;
                        }
                    }
                }
                if (homeAccount.account_type.equalsIgnoreCase("prepaid")) {
                    if (homeAccount.transactionPos.toLowerCase().contains("recharge") || homeAccount.transactionPos.toLowerCase().contains("mobile")) {
                        homeAccount.account_type = "phone";
                    }
                }
                allTransactionList.add(homeAccount);
            }
        }
    }

    private boolean checkPrepaidAccount(HomeAccoutList homeAccount) {
        ArrayList<HomeAccoutList> accountList = mydbAccountNew.GetAllAccountNew();
        boolean isF = false;
        if (accountList.size() != 0) {
            for (int i = 0; i < accountList.size() && !isF; i++) {
                if (accountList.get(i).full_name.equalsIgnoreCase(homeAccount.full_name)) {
                    isF = true;
                    if (TextUtils.isEmpty(homeAccount.FinalAccountNo)) {
                        homeAccount.FinalAccountNo = accountList.get(i).FinalAccountNo;
                    }
                }
            }
        }
        return isF;
    }


    private void getTransectionDetails(HomeAccoutList homeAccount, String body, JSONObject jsonObject) {

        int posID = -1, amountId = -1, ruleId = -1, dateId = -1, eventNameId = -1, eventLocationId = -1, eventInfoId = -1;

        try {
            BankName = jsonObject.optString("full_name");
            JSONArray patternsary = jsonObject.optJSONArray("patterns");
            if (patternsary != null) {
                boolean isPatternMatch = false;
                for (int jj = 0; jj < patternsary.length() && !isPatternMatch; jj++) {
                    JSONObject jsonObjectt = patternsary.optJSONObject(jj);
                    String Regx = jsonObjectt.optString("regex");

                    Pattern regEx = Pattern.compile(Regx);
                    Matcher m = regEx.matcher(body);
                    if (m.find()) {
                        isPatternMatch = true;
                        homeAccount.account_type = jsonObjectt.optString("account_type");
                        homeAccount.sms_type = jsonObjectt.optString("sms_type");
                        String data_fields = jsonObjectt.optString("data_fields");
                        JSONObject obj_data_fields = new JSONObject(data_fields);

                        String typeKey = getTypeKey(homeAccount.sms_type);
                        if (!TextUtils.isEmpty(typeKey) && obj_data_fields.has(typeKey)) {
                            homeAccount.mTransactionType = obj_data_fields.optString(typeKey);
                        } else {
                            if (obj_data_fields.has("transaction_type_rule") &&
                                    obj_data_fields.getJSONObject("transaction_type_rule").has("rules")) {

                                ruleId = obj_data_fields.getJSONObject("transaction_type_rule").getInt("group_id");
                                String ruleValue = m.group(ruleId);
                                JSONArray transaction_type_rules = obj_data_fields.getJSONObject("transaction_type_rule").getJSONArray("rules");
                                boolean isFound = false;
                                JSONObject ruleObj = null;
                                for (int i = 0; i < transaction_type_rules.length() && !isFound; i++) {
                                    ruleObj = transaction_type_rules.getJSONObject(i);
                                    String value = ruleObj.getString("value");
                                    if (value.equalsIgnoreCase(ruleValue)) {
                                        isFound = true;
                                    }
                                }
                                if (ruleObj != null) {
                                    if (ruleObj.has("pos_override")) {
                                        homeAccount.transactionDesc = ruleObj.getString("pos_override");
                                    }
                                    if (ruleObj.has("txn_type")) {
                                        homeAccount.txn_type = ruleObj.getString("txn_type");
                                        if (homeAccount.txn_type.equalsIgnoreCase("debit_atm")) {
                                            homeAccount.isAtmWithDraw = true;
                                        }
                                    }
                                }

                            }
                        }

                        if (obj_data_fields.has("amount")) {
                            if (obj_data_fields.getJSONObject("amount").has("group_id")) {
                                amountId = obj_data_fields.getJSONObject("amount").getInt("group_id");
                                homeAccount.amount = m.group(amountId);  //AccountAmount
                            } else if (obj_data_fields.getJSONObject("amount").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("amount").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.amounts.add(m.group(ids.getInt(i)));
                                }
                            }
                            if (obj_data_fields.getJSONObject("amount").has("txn_direction")) {
                                homeAccount.isDebited = false;
                            }
                        }

                        if (obj_data_fields.has("date")) {
                            if (obj_data_fields.getJSONObject("date").has("use_sms_time")) {
                                homeAccount.use_sms_time = obj_data_fields.getJSONObject("date").getBoolean("use_sms_time");
                            } else if (obj_data_fields.getJSONObject("date").has("formats")) {
                                JSONArray array = obj_data_fields.getJSONObject("date").getJSONArray("formats");
                                for (int i = 0; i < array.length(); i++) {
                                    String format = array.getJSONObject(i).getString("format");
                                    homeAccount.dateFormats.add(format);
                                }
                                if (obj_data_fields.getJSONObject("date").has("group_id")) {
                                    dateId = obj_data_fields.getJSONObject("date").getInt("group_id");
                                    homeAccount.date = m.group(dateId);  // account_Date
                                } else if (obj_data_fields.getJSONObject("date").has("group_ids")) {
                                    JSONArray ids = obj_data_fields.getJSONObject("date").getJSONArray("group_ids");
                                    for (int i = 0; i < ids.length(); i++) {
                                        homeAccount.dates.add(m.group(ids.getInt(i)));
                                    }
                                }
                            }
                        }
//                        if (TextUtils.isEmpty(homeAccount.transactionDesc)) {
//                            getDataFromDataFields(obj_data_fields, "pos", homeAccount.transactionDesc, posID, homeAccount.transactionDescs, m);
//                        }

                        if (obj_data_fields.has("pos")) {
                            if (obj_data_fields.getJSONObject("pos").has("value")) {
                                homeAccount.transactionDesc = obj_data_fields.getJSONObject("pos").getString("value");
                            }
                            if (obj_data_fields.getJSONObject("pos").has("group_id")) {
                                posID = obj_data_fields.getJSONObject("pos").getInt("group_id");
                                homeAccount.transactionPos = m.group(posID);
                            } else if (obj_data_fields.getJSONObject("pos").has("group_ids")) {
                                JSONArray ids = obj_data_fields.getJSONObject("pos").getJSONArray("group_ids");
                                for (int i = 0; i < ids.length(); i++) {
                                    homeAccount.transactionDescs.add(m.group(ids.getInt(i)));
                                }
                            }

                        }


                        if (homeAccount.sms_type.equalsIgnoreCase("event")) {
                            getDataFromDataFields(obj_data_fields, "name", homeAccount.eventName, eventNameId, homeAccount.eventNames, m);
                            getDataFromDataFields(obj_data_fields, "event_info", homeAccount.eventInfo, eventInfoId, homeAccount.eventInfos, m);
                            getDataFromDataFields(obj_data_fields, "event_location", homeAccount.eventLocation, eventLocationId, homeAccount.eventLocations, m);
                        }

                        // Account No
                        JSONObject objpan = obj_data_fields.optJSONObject("pan");
                        String pan = "";
                        if (objpan != null) {
                            if (objpan.has("value")) {
                                homeAccount.panValue = objpan.getString("value");
                            }
                            pan = objpan.optString("group_id");
                        }
                        // pan
                        if (!TextUtils.isEmpty(pan)) {
                            homeAccount.FinalAccountNo = m.group(Integer.parseInt(pan));
                        }

                        if (obj_data_fields.has("note")) {
                            String note = obj_data_fields.getJSONObject("note").optString("group_id");

                            if (homeAccount.account_type.equalsIgnoreCase("prepaid")) {
                                if (TextUtils.isEmpty(homeAccount.transactionPos)) {
                                    homeAccount.transactionPos = m.group(Integer.parseInt(note));
                                } else {
                                    homeAccount.transactionPos += " " + m.group(Integer.parseInt(note));
                                }
                            } else if (TextUtils.isEmpty(homeAccount.transactionPos)) {
                                homeAccount.transactionPos = m.group(Integer.parseInt(note));
                            } else if (TextUtils.isEmpty(homeAccount.panValue) || homeAccount.panValue.equalsIgnoreCase("unknown")) {
                                homeAccount.panValue = m.group(Integer.parseInt(note));
                            }
                        }


                        // Account Balance
                        JSONObject objaccount_balance = obj_data_fields.optJSONObject("account_balance");
                        String account_balance = "";
                        if (objaccount_balance != null) {
                            account_balance = objaccount_balance.optString("group_id");
                        }
                        // Account Balance
                        if (!TextUtils.isEmpty(account_balance)) {
                            if (TextUtils.isDigitsOnly(account_balance)) {
                                homeAccount.FinalAccountBalance = m.group(Integer.parseInt(account_balance));
                            }
                        }

                        if (!TextUtils.isEmpty(homeAccount.mTransactionType) && homeAccount.mTransactionType.equalsIgnoreCase("credit")) {
                            homeAccount.isDebited = false;
                        }

                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private String getTypeKey(String sms_type) {
        return sms_type + "_type";
    }


    private void getDataFromDataFields(JSONObject obj_data_fields, String key, String mainValue, int mainId, ArrayList<String> valuesArray, Matcher m) {
        try {
            if (obj_data_fields.has(key)) {
                if (obj_data_fields.getJSONObject(key).has("value")) {
                    mainValue = obj_data_fields.getJSONObject(key).getString("value");
                } else {
                    if (obj_data_fields.getJSONObject(key).has("group_id")) {
                        mainId = obj_data_fields.getJSONObject(key).getInt("group_id");
                        mainValue = m.group(mainId);
                    } else if (obj_data_fields.getJSONObject(key).has("group_ids")) {
                        JSONArray ids = obj_data_fields.getJSONObject(key).getJSONArray("group_ids");
                        for (int i = 0; i < ids.length(); i++) {
                            valuesArray.add(m.group(ids.getInt(i)));
                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private String getTransactionDesc(String transactionType) {
        String transactionDesc = "";
        switch (transactionType) {
            case "balance":
                transactionDesc = "Your Account Balance";
                break;
            case "upi":
                transactionDesc = "UPI Transaction";
                break;
            case "debit_card":
                transactionDesc = "Debit Card Transaction";
                break;
            case "net_banking":
                transactionDesc = "Net Banking";
                break;
            case "credit":
                transactionDesc = "Credited to your Account";
                break;
            case "cheque":
                transactionDesc = "Cheque Transaction";
                break;
            case "debit_atm":
                transactionDesc = "ATM withdrawal";
                break;
            case "credit_card":
                transactionDesc = "Credit Card Transaction";
                break;
            case "credit_card_bill":
                transactionDesc = "Credit Card Bill";
                break;
            case "loan_emi":
                transactionDesc = "Loan EMI";
                break;
            case "mobile_bill":
                transactionDesc = "Mobile Bill";
                break;
            case "debit_prepaid":
                transactionDesc = "Prepaid Debit Card Transaction";
                break;
            case "bill":
                transactionDesc = "Bill";
                break;
            case "internate_bill":
                transactionDesc = "Internet Bill";
                break;
            case "electricity_bill":
                transactionDesc = "Electricity Bill";
                break;
            case "insurance_premium":
                transactionDesc = "Insurance Premium";
                break;
            case "gas_bill":
                transactionDesc = "Gas Bill";
                break;
        }
        return transactionDesc;
    }
}
