package com.bankbalanceinquiry.ministatement.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.BillsAndEmilAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.databased.DBHelperAccountHistory;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;
import com.bankbalanceinquiry.ministatement.model.FirstTimeSmsModel;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BillsActivity extends AppCompatActivity {

    private Activity activity;
    private Toolbar toolbar;

    private RecyclerView rvAccountList;
    private ProgressBar pbLoading;
    private AsyncTask mMyTask = null;
    private ArrayList<HomeAccoutList> bilsEmiModels;
    private BillsAndEmilAdapter billsAndEmilAdapter;

    private ArrayList<String> stringArrayList;
    private List<bankname> mData;


    // private ArrayList<BankNameLogo> bankNameLogos;
    private String BankNameFinal = "";
    private int BankIconFinal = 0;
    private ArrayList<AvilabeBalanceModel> avilabeBalanceModels;
    private String BankName = "";

    private LinearLayout llEmpty;
    private TextView tvEmptyMessage;
    private ImageView ivEmptyImage;
    private DBHelperAccountNew mydbBill;

    private String TodayDate = "";

    private ArrayList<FirstTimeSmsModel> AccountHistory = new ArrayList<>();
    private DBHelperAccountHistory dbHelperAccountHistory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bills);

        activity = this;
        mydbBill = new DBHelperAccountNew(activity);

        InitToolBar();

        InitComponent();

    }

    private void InitToolBar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.bill_emi));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    private void InitComponent() {

        rvAccountList = findViewById(R.id.rvAccountList);
        pbLoading = findViewById(R.id.pbLoading);
        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);
        pbLoading.setVisibility(View.VISIBLE);

        llEmpty = findViewById(R.id.llEmpty);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);
        ivEmptyImage = findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText("Bills & EMIs Empty");

        try {
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
            databaseAccess.open();
            mData = databaseAccess.getList();
            Log.e("mDatamData", mData.size() + "");
            databaseAccess.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        avilabeBalanceModels = new ArrayList<>();


        pbLoading.setVisibility(View.GONE);

        CheckDataNotifyOrNot();



    }

    private void CheckDataNotifyOrNot() {
            CommonFun.isIncommingSmsNotify = "";
            bilsEmiModels = new ArrayList<>();
            bilsEmiModels.addAll(mydbBill.GetAllBills());
            CallBillsAdapterSet();
    }




    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void CallBillsAdapterSet() {
        Log.e("bilsEmiModels", bilsEmiModels.size() + "");
        if (bilsEmiModels.size() > 0) {
            rvAccountList.setVisibility(View.VISIBLE);
            llEmpty.setVisibility(View.GONE);
            billsAndEmilAdapter = new BillsAndEmilAdapter(activity, bilsEmiModels);
            rvAccountList.setAdapter(billsAndEmilAdapter);
        } else {
            rvAccountList.setVisibility(View.GONE);
            llEmpty.setVisibility(View.VISIBLE);
        }
    }


    public long printDifference(Date startDate, Date endDate) {
        //milliseconds
        Log.e("DateDifference==<", " \n TodayDateStart" + startDate + "" +
                " \n DudateDateendDate" + endDate + ""
        );
        long different = endDate.getTime() - startDate.getTime();
        System.out.println("startDate : " + startDate);
        System.out.println("endDate : " + endDate);
        System.out.println("different : " + different);

        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;

        long elapsedSeconds = different / secondsInMilli;

        Log.e("DayyyPending", elapsedDays + "");
        System.out.printf(
                "%d days, %d hours, %d minutes, %d seconds%n",
                elapsedDays, elapsedHours, elapsedMinutes, elapsedSeconds);
        return elapsedDays;
    }


    public int GetAccountIcon(String bankNameTitle) {
        int icon = 0;
        BankName = "";
        if (bankNameTitle != null) {
            for (int i = 0; i < avilabeBalanceModels.size(); i++) {
                String BankNameold = avilabeBalanceModels.get(i).getBankSMSTile();
                if (TextUtils.equals(BankNameold, bankNameTitle)) {
                    icon = avilabeBalanceModels.get(i).getBankicon();
                    BankName = avilabeBalanceModels.get(i).getBankName();
                    break;
                }
            }
            return icon;
        }
        return 0;
    }

    private String getBankName(String bankNameTitle) {
        String BankName = "";
        if (!TextUtils.isEmpty(bankNameTitle)) {
            bankNameTitle.toUpperCase();
            String[] separated = bankNameTitle.split("-");
            if (separated.length > 1) {
                bankNameTitle = separated[1];
            }
            for (int i = 0; i < mData.size(); i++) {
                String BankTitle = mData.get(i).getB_short();
                if (bankNameTitle.contains(BankTitle)) {
                    BankName = mData.get(i).getB_name();
                    break;
                }
            }
            Log.e("BankNameFIndd", BankName);
        }
        return BankName;
    }

    private void getBankNameIconGet(String bankNameTitle) {
        BankNameFinal = "";
        BankIconFinal = 0;
        if (!TextUtils.isEmpty(bankNameTitle)) {
            bankNameTitle.toUpperCase();
            String[] separated = bankNameTitle.split("-");
            if (separated.length > 1) {
                bankNameTitle = separated[1];
            }
            for (int i = 0; i < mData.size(); i++) {
                String BankTitle = mData.get(i).getB_short();
                if (bankNameTitle.contains(BankTitle)) {
                    BankNameFinal = mData.get(i).getB_name();
                    break;
                }
            }

         /*   for (int i = 0; i < bankNameLogos.size(); i++) {
                String BankShot = bankNameLogos.get(i).getBankName();
                if (BankShot.contains(bankNameTitle)) {
                    BankIconFinal = bankNameLogos.get(i).getBankLogo();
                }
            }*/
        }
    }
}