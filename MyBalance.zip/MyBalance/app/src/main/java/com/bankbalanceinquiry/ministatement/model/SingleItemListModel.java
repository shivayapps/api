package com.bankbalanceinquiry.ministatement.model;

import android.os.Parcel;
import android.os.Parcelable;

public class SingleItemListModel implements Parcelable{

    private String itemData;
    private boolean isSelected;

    public SingleItemListModel() {
        itemData = "";
        isSelected = false;
    }

    public SingleItemListModel(String itemData, boolean isSelected) {
        this.itemData = itemData;
        this.isSelected = isSelected;
    }

    private SingleItemListModel(Parcel in) {
        itemData = in.readString();
        isSelected = in.readByte() != 0;
    }

    public static final Creator<SingleItemListModel> CREATOR = new Creator<SingleItemListModel>() {
        @Override
        public SingleItemListModel createFromParcel(Parcel in) {
            return new SingleItemListModel(in);
        }

        @Override
        public SingleItemListModel[] newArray(int size) {
            return new SingleItemListModel[size];
        }
    };

    public String getItemData() {
        return itemData;
    }

    public void setItemData(String itemData) {
        this.itemData = itemData;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(itemData);
        dest.writeByte((byte) (isSelected ? 1 : 0));
    }
}
