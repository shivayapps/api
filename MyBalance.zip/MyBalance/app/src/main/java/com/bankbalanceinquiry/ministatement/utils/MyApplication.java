package com.bankbalanceinquiry.ministatement.utils;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.annotation.NonNull;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.splashActivity;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
//import com.bankbalanceinquiry.ministatement.notification.ExampleNotificationOpenedHandler;
//import com.bankbalanceinquiry.ministatement.notification.ExampleNotificationReceivedHandler;
import com.example.app.ads.helper.VasuAdsConfig;
import com.example.app.ads.helper.openad.AppOpenApplication;
import com.example.app.ads.helper.openad.OpenAdHelper;
import com.onesignal.OneSignal;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;


public class MyApplication extends AppOpenApplication implements AppOpenApplication.AppLifecycleListener {

    private static MyApplication application;


    @Override
    public void onCreate() {
        super.onCreate();
        application = this;


        VasuAdsConfig.with(this)
                .isEnableOpenAd(true) // Pass false if you don't need to show open ad in your project
                .needToTakeAllTestAdID(false) // Pass true if you need to show Ads with Test Ad ID in your project
                .needToBlockInterstitialAd(false) // Pass true if you check fullScreenNativeAds when Interstitial Ads Failed to Load
                .setAdmobAppId(getString(R.string.G_APP_ID))
                .setAdmobBannerAdId(getString(R.string.G_BANNER_ID))
                .setAdmobInterstitialAdId(getString(R.string.G_INTERSTITIAL_ID))
                .setAdmobNativeAdvancedAdId(getString(R.string.G_NATIVE_ID))
//                .setAdmobOpenAdId(getString(R.string.G_APPOPEN_ID))
//                .setAdmobRewardVideoAdId(getString(R.string.rewarded_video_ad_unit_id))
//                .setAdmobInterstitialAdRewardId(getString(R.string.rewarded_interstitial_ad_unit_id))
                .initialize();

//        initMobileAds("138C82055F352E2F7B6148F0AAA7895F");
        OpenAdHelper.INSTANCE.loadOpenAd(this, new Function0<Unit>() {
            @Override
            public Unit invoke() {
                return null;
            }
        });
        setAppLifecycleListener(this);

        try {

            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
            OneSignal.initWithContext(getApplicationContext());
            OneSignal.setAppId("5007b7dd-aa51-4729-878a-cc64bc96576f");
//            OneSignal.startInit(this)
//                    .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
//                    .setNotificationOpenedHandler(new ExampleNotificationOpenedHandler(MyApplication.this))
//                    .setNotificationReceivedHandler(new ExampleNotificationReceivedHandler(MyApplication.this))
//                    .init();
        }catch (Exception e){
            Log.e("con", "onCreate: ");
        }

    }

    public static Context getAppContext() {
        if (application == null) {
            application = new MyApplication();
        }
        return application;
    }

    /*
    public static void setShowPlateformAd(Context context, String showPlateform) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putString(Constant.PREF_SHOW_PLATEFORM_ID, showPlateform).commit();
    }
    public static String getShowPlateformAd(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getString(Constant.PREF_SHOW_PLATEFORM_ID, "");
    }
    */

    public static void setNativeAdId(Context context, String nativeId) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putString(Constant.PREF_NATIVE_AD_ID, nativeId).commit();
    }

    public static String getNativeAdId(Context context) {
        //SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        //return sp.getString(Constant.PREF_NATIVE_AD_ID, "");
        return context.getResources().getString(R.string.F_NATIVE_ID);
    }

    public static void setIntersialAdId(Context context, String intersialId) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putString(Constant.PREF_INTERSIAL_AD_ID, intersialId).commit();
    }

    public static String getIntersialAdId(Context context) {
        //SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        //return sp.getString(Constant.PREF_INTERSIAL_AD_ID, "");

        return context.getResources().getString(R.string.F_INTERSTITIAL_ID);
    }

    public static void setBannerAdId(Context context, String bannerId) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putString(Constant.PREF_BANNER_AD_ID, bannerId).commit();
    }

    public static String getBannerAdId(Context context) {
        //SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        //return sp.getString(Constant.PREF_BANNER_AD_ID, "");

        return context.getResources().getString(R.string.F_BANNER_ID);
    }
/*

    public static void setAdMobUnitId(Context context, String appId) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putString(Constant.PREF_ADMOB_UNIT_ID, appId).commit();
    }

    public static String getAdMobUnitId(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getString(Constant.PREF_ADMOB_UNIT_ID, "");
    }
*/

    public static void setLastTimeShowInterstitial(Context context, long time) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putLong(Constant.Last_Time_Show_Interstitial, time).commit();
    }

    public static long getLastTimeShowInterstitial(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getLong(Constant.Last_Time_Show_Interstitial, 0);
    }

    @Override
    public boolean onResumeApp(@NonNull Activity fCurrentActivity) {

        if(fCurrentActivity instanceof splashActivity){
            return false;
        } else if(new AdsManager(fCurrentActivity).isNeedToShowAds()) {
            return false;
        }
        return true;
    }
}
