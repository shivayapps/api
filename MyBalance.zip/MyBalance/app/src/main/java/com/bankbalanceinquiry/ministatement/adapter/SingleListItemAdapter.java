package com.bankbalanceinquiry.ministatement.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.SingleItemListModel;

import java.util.ArrayList;

public class SingleListItemAdapter extends RecyclerView.Adapter<SingleListItemAdapter.SingleListItemHolder> {

    public static final String TAG = "SingleListItemAdapter";
    private ArrayList<SingleItemListModel> mSingleItemListModels;
    private Context context;
    private int pos;

    public SingleListItemAdapter(Context context, ArrayList<SingleItemListModel> singleItemListModels,int pos) {
        this.context = context;
        this.pos = pos;
        mSingleItemListModels = singleItemListModels;

        if(mSingleItemListModels.size()>=pos){
            try {
                mSingleItemListModels.get(pos).setSelected(true);
            } catch (ArrayIndexOutOfBoundsException e){
                Log.e("::MMG::", "SingleListItemAdapter001: " + e.getMessage());
            } catch (IndexOutOfBoundsException e){
                Log.e("::MMG::", "SingleListItemAdapter002: " + e.getMessage());
            }
        }
    }

    @Override
    public SingleListItemAdapter.SingleListItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflatedView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_single, parent, false);
        return new SingleListItemAdapter.SingleListItemHolder(inflatedView);
    }

    @Override
    public void onBindViewHolder(SingleListItemAdapter.SingleListItemHolder holder, int position) {
        try {
            String CurrentString = mSingleItemListModels.get(position).getItemData();
            holder.mItemDate.setText(CurrentString);

            if (mSingleItemListModels.get(position).isSelected()) {
            } else {
            }
        } catch (IndexOutOfBoundsException ignored) {
        }
    }

    @Override
    public int getItemCount() {
        return mSingleItemListModels.size();
    }

    class SingleListItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView mItemDate;

        SingleListItemHolder(View v) {
            super(v);
            mItemDate = (TextView) v.findViewById(R.id.tv_recycler_view_list_header);
            v.setOnClickListener(this);
            this.setIsRecyclable(false);
        }

        @Override
        public void onClick(View v) {
            try {
                if(mSingleItemListModels.size()>=pos)
                    mSingleItemListModels.get(pos).setSelected(false);

                notifyItemChanged(pos, mSingleItemListModels.get(pos));
            } catch (IndexOutOfBoundsException e){
                Log.e("::MMG::", "SingleListItemAdapter003: " + e.getMessage());
            }

            pos = getAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) {

                if(mSingleItemListModels.size()>=pos)
                    mSingleItemListModels.get(pos).setSelected(true);

                notifyItemChanged(pos, mSingleItemListModels.get(pos));

            }

        }
    }
}
