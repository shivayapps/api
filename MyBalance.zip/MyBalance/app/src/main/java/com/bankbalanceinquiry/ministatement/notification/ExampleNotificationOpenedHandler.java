package com.bankbalanceinquiry.ministatement.notification;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import com.bankbalanceinquiry.ministatement.activity.drawerActivity;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.SharedPreferenceClass;
//import com.onesignal.OSNotificationOpenResult;
import com.onesignal.OneSignal;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * Created by Ebitm3 on 4/23/2018.
 */

//public class ExampleNotificationOpenedHandler implements OneSignal.NotificationOpenedHandler {
//
//    public static String notiTitle;
//    public static String notiType;
//    public static String notiOfferId;
//    public String notiExpireDate;
//    Context context;
//    float rate;
//
//
//    public ExampleNotificationOpenedHandler(Context context) {
//        this.context = context;
//    }
//
//    @Override
//    public void notificationOpened(OSNotificationOpenResult result) {
//        JSONObject jsonObj = result.notification.payload.additionalData;
//
//
//        if (jsonObj != null)
//        {
//            Log.e("OneSignalExample", "type set with value: " + jsonObj.toString());
//            try {
//                if (jsonObj.has("type"))
//                    notiType = jsonObj.getString("type");
//                if (jsonObj.has("title"))
//                    notiTitle = jsonObj.getString("title");
//                if (notiType != null && !notiType.equals("") && notiType.length() > 0) {
//                    if (notiType.equals("offer")) {
//                        if (jsonObj.has("offer_id")){
//                            notiOfferId = jsonObj.getString("offer_id");
//                        }
//                        if (jsonObj.has("expire_date")){
//                            notiExpireDate = jsonObj.getString("expire_date");
//                        }
//                    }
//                    SharedPreferenceClass.setBoolean(context, Constant.IS_FROM_NOTIFICATION, true);
//                    SharedPreferenceClass.setString(context, Constant.IS_FROM_NOTIFICATION_MESSAGE, "" + notiTitle);
//                    SharedPreferenceClass.setString(context, Constant.IS_FROM_NOTIFICATION_type, "" + notiType);
//
//                    Intent launchIntent = new Intent(context, drawerActivity.class);
//                    launchIntent.putExtra("Dialog","showDialog");
//                    launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
//                            | Intent.FLAG_ACTIVITY_CLEAR_TASK
//                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
//                            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//                    launchIntent.putExtra(Constant.IS_FROM_NOTIFICATION_type, "" + notiType);
//                    // Start activity!
//                   context.startActivity(launchIntent);
//
//                } else {
//                    Intent launchIntent = new Intent(context,drawerActivity.class);
//                   launchIntent.putExtra("Dialog","showDialog");
//                    launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
//                            | Intent.FLAG_ACTIVITY_CLEAR_TASK
//                            | Intent.FLAG_ACTIVITY_CLEAR_TOP
//                            | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//                   context.startActivity(launchIntent);
//                }
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//        }
//        else {
//            String strurl = result.notification.payload.launchURL;
//            Log.i("Launch URL", "Launch URL" + strurl);
//            notiType = "URL";
//            Intent intent = new Intent(Intent.ACTION_VIEW);
//
//            intent.setData(Uri.parse(strurl));
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
//                    | Intent.FLAG_ACTIVITY_CLEAR_TASK
//                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
//                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//            intent.putExtra(Constant.IS_FROM_NOTIFICATION_type, "" + notiType);
//            context.startActivity(intent);
//        }
//    }
//}
