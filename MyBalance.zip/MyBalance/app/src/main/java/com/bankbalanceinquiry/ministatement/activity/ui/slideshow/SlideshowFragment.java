package com.bankbalanceinquiry.ministatement.activity.ui.slideshow;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;


public class SlideshowFragment extends Fragment {



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        Intent email = new Intent(Intent.ACTION_SEND);
        email.putExtra(Intent.EXTRA_EMAIL, new String[]{getResources().getString(R.string.email)});
        email.putExtra(Intent.EXTRA_SUBJECT, "Feedback");
        email.putExtra(Intent.EXTRA_TEXT, ""+getResources().getString(R.string.app_name));
        email.setType("message/rfc822");
        startActivity(Intent.createChooser(email, "Send Mail :"));

        onbackPressed();
        return root;
    }

    public  void onbackPressed()
    {
        super.getActivity().onBackPressed();
    }
}