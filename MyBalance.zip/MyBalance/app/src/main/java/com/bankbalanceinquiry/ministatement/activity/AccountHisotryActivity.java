package com.bankbalanceinquiry.ministatement.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.AllAccountListAdapter;
import com.bankbalanceinquiry.ministatement.adapter.AccountHistoryAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.FirstTimeSmsModel;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;


public class AccountHisotryActivity extends AppCompatActivity {

    private Activity activity;
    private Toolbar toolbar;

    private RecyclerView rvAccountList;
    private ProgressBar pbLoading;
    private AllAccountListAdapter allAccountListAdapter;
    private HomeAccoutList allAccountModel;

    private LinearLayout llEmpty;
    private TextView tvEmptyMessage, mCurrentBalTxt;
    private ImageView ivEmptyImage;
    private TextView tvTotalAmout, tvAccountNo;

    private String TitleName = "Transactions";
    private ArrayList<FirstTimeSmsModel> AccountHistory = new ArrayList<>();

    private LinearLayout llDisplayData;
    private RelativeLayout rllayoutContent;

    private DBHelperAccountNew dbHelperAccountHistory;
    private ArrayList<HomeAccoutList> allAccountModelHistories = new ArrayList<>();
    private ArrayList<HomeAccoutList> allData = new ArrayList<>();
    private AccountHistoryAdapter accountHistoryAdapter;
    int color;
    RelativeLayout mBarBg;
    ImageView mEdit;
    TextView mFirstName, mLastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_hisotry_test);

        pbLoading = findViewById(R.id.pbLoading);
        mEdit = findViewById(R.id.edit);
        activity = this;
        dbHelperAccountHistory = new DBHelperAccountNew(activity);
        mBarBg = findViewById(R.id.bar_bg);
        mFirstName = findViewById(R.id.firstName);
        mLastName = findViewById(R.id.lastName);


        mEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editDialog();
            }
        });

        pbLoading.setVisibility(View.VISIBLE);
        Intent getdata = getIntent();
        if (getdata != null) {
            allAccountModel = (HomeAccoutList) getdata.getSerializableExtra("OBJ");
            color = getdata.getIntExtra("color", ContextCompat.getColor(this, R.color.colorPrimary));
            if (color == 0 || color == -1) {
                color = ContextCompat.getColor(this, R.color.colorPrimary);
            }

            if (allAccountModel != null) {
                String name = allAccountModel.full_name.replace(" Bank", "");
                TitleName = name;

                String f = getValue(allAccountModel.FinalAccountNo + "_f");
                String l = getValue(allAccountModel.FinalAccountNo + "_l");

                if (!TextUtils.isEmpty(f)) {
                    mFirstName.setText(f);
                }
                if (!TextUtils.isEmpty(l)) {
                    mLastName.setText(l);
                }
            }
            InitToolBar();

            //InitComponent();
            InitComponentNew();
        }

    }


    private void editDialog() {
        final Dialog dialog = new Dialog(this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_edit);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));


        final EditText mFname = dialog.findViewById(R.id.f_name);
        final EditText mLname = dialog.findViewById(R.id.l_name);

        String f = getValue(allAccountModel.FinalAccountNo + "_f");
        String l = getValue(allAccountModel.FinalAccountNo + "_l");

        if (!TextUtils.isEmpty(f)) {
            mFname.setText(f);
        }
        if (!TextUtils.isEmpty(l)) {
            mLname.setText(l);
        }

        TextView ok = dialog.findViewById(R.id.btnAddTextSDialog);
        TextView cancel = dialog.findViewById(R.id.btnCancelDialog);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String f = mFname.getText().toString().trim();
                String l = mLname.getText().toString().trim();
                if (TextUtils.isEmpty(f)) {
                    return;
                }
                if (TextUtils.isEmpty(l)) {
                    return;
                }
                mFirstName.setText(f);
                mLastName.setText(l);
                setValue(allAccountModel.FinalAccountNo + "_f", f);
                setValue(allAccountModel.FinalAccountNo + "_l", l);
                dialog.dismiss();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }


    public String getValue(String key) {
        SharedPreferences sp = getSharedPreferences("bank_details", MODE_PRIVATE);
        return sp.getString(key, "");
    }

    public void setValue(String key, String value) {
        SharedPreferences sp = getSharedPreferences("bank_details", MODE_PRIVATE);
        sp.edit().putString(key, value).apply();
    }


    private void InitToolBar() {
        toolbar = findViewById(R.id.toolbar);
        //toolbar.setTitle("Transactions");
        if (allAccountModel != null) {
            toolbar.setTitle(TitleName + " - X" + allAccountModel.FinalAccountNo);
        } else {
            toolbar.setTitle(TitleName);
        }
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        mBarBg.setBackgroundColor(color);
        toolbar.setBackgroundColor(color);
        int mixColor = mixTwoColors(color, Color.WHITE, 0.5f);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(color);
        }
    }

    private int mixTwoColors(int color1, int color2, float amount) {
        final byte ALPHA_CHANNEL = 24;
        final byte RED_CHANNEL = 16;
        final byte GREEN_CHANNEL = 8;
        final byte BLUE_CHANNEL = 0;

        final float inverseAmount = 1.0f - amount;

        int a = ((int) (((float) (color1 >> ALPHA_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> ALPHA_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int r = ((int) (((float) (color1 >> RED_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> RED_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int g = ((int) (((float) (color1 >> GREEN_CHANNEL & 0xff) * amount) +
                ((float) (color2 >> GREEN_CHANNEL & 0xff) * inverseAmount))) & 0xff;
        int b = ((int) (((float) (color1 & 0xff) * amount) +
                ((float) (color2 & 0xff) * inverseAmount))) & 0xff;

        return a << ALPHA_CHANNEL | r << RED_CHANNEL | g << GREEN_CHANNEL | b << BLUE_CHANNEL;
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));
        }
        super.onDestroy();
    }

    /* private void InitComponent() {
        rvAccountList = findViewById(R.id.rvAccountList);
        pbLoading = findViewById(R.id.pbLoading);

        tvTotalAmout = findViewById(R.id.tvTotalAmout);
        llDisplayData = findViewById(R.id.llDisplayData);

        rllayoutContent = findViewById(R.id.rllayoutContent);

        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        llEmpty = findViewById(R.id.llEmpty);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);
        ivEmptyImage = findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText("Transactions history empty");

        mViewAnimator = findViewById(R.id.animator);
        if (allAccountModel != null) {
            Log.e("ClickAccountNoFinal", allAccountModel.getAccountNo());
            try {
                tvTotalAmout.setText("\u20B9 " + allAccountModel.getAvilabeClearBalance());
            } catch (Exception e) {
                e.printStackTrace();
            }

            pbLoading.setVisibility(View.VISIBLE);
            avilabeBalanceModels = new ArrayList<>();
            avilabeBalanceModels.addAll(AllBankAvilabeBalancMsg.AddAvilableMsg());
            AllBankingTransferFrom.addAll(AllBankAvilabeBalancMsg.GetTransperFrom());
            //mMyTask = new GetAllSmsOnTransaction().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

            mViewAnimator.setHideBeforeReveal(true);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    //   mViewAnimator.setDisplayedChild(mViewAnimator.getDisplayedChild(), true, new Point(250, 250));
                    mViewAnimator.showNext();
                }
            }, 700);
        }


        CheckDataNotifyOrNot();
        CallDb();
        //  CallMultiviewTypeAdapter();
    }
    */

    private void InitComponentNew() {
        rvAccountList = findViewById(R.id.rvAccountList);
        tvAccountNo = findViewById(R.id.tvAccountNo);
        NestedScrollView nestedScrollView = findViewById(R.id.nested);

        tvTotalAmout = findViewById(R.id.tvTotalAmout);
        llDisplayData = findViewById(R.id.llDisplayData);
        mCurrentBalTxt = findViewById(R.id.currentBalTxt);

        rllayoutContent = findViewById(R.id.rllayoutContent);

        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        llEmpty = findViewById(R.id.llEmpty);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);
        ivEmptyImage = findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText("Transactions history empty");

        if (allAccountModel != null) {
            if (!TextUtils.isEmpty(allAccountModel.FinalAccountBalance)) {
                try {
                    tvTotalAmout.setText("\u20B9 " + allAccountModel.FinalAccountBalance);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                tvTotalAmout.setText("");
                mCurrentBalTxt.setVisibility(View.GONE);
            }
//            if (!TextUtils.isEmpty(allAccountModel.FinalAccountNo)) {
//                tvAccountNo.setText("Account No - " + "XX" + allAccountModel.FinalAccountNo);
//            } else {
//                tvAccountNo.setText("");
//            }
            tvAccountNo.setVisibility(View.GONE);

        }
        accountHistoryAdapter = new AccountHistoryAdapter(activity, allAccountModelHistories, color);
        rvAccountList.setAdapter(accountHistoryAdapter);

        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                if (v.getChildAt(v.getChildCount() - 1) != null) {
                    if ((scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight())) &&
                            scrollY > oldScrollY) {
                        int size = allAccountModelHistories.size();
                        if (allData.size() > (size + 50)) {
                            for (int i = size; i < (size + 50); i++) {
                                allAccountModelHistories.add(allData.get(i));
                            }
                        } else if (allAccountModelHistories.size() != allData.size()) {
                            for (int i = size; i < allData.size(); i++) {
                                allAccountModelHistories.add(allData.get(i));
                            }
                        }
                        accountHistoryAdapter.notifyDataSetChanged();
                    }
                }
            }
        });

        CheckDataNotifyOrNot();
        CallDb();

    }

    private void CheckDataNotifyOrNot() {
        if (CommonFun.isIncommingSmsNotify.equalsIgnoreCase("")) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    CheckDataNotifyOrNot();
                    Log.e("NotificationYes==>", "not Incomming");
                }
            }, 2000);
        } else {
            CommonFun.isIncommingSmsNotify = "";
            CallDb();
        }
    }

    private void CallDb() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                allAccountModelHistories.clear();
                allData.clear();
                allData.addAll(dbHelperAccountHistory.GetTransactions(allAccountModel.FinalAccountNo, allAccountModel.full_name));
//                allAccountModelHistories.addAll(dbHelperAccountHistory.GetTransactions(allAccountModel.FinalAccountNo, allAccountModel.full_name));
                ArrayList<HomeAccoutList> tmpdata = new ArrayList<>();
                ArrayList<HomeAccoutList> tmpdataFinal = new ArrayList<>();
                if (allData.size() > 0) {
                    String ModelClickAccountNo = allAccountModel.FinalAccountNo;
                    for (int i = 0; i < allData.size(); i++) {
                        String ForiAccountName = allData.get(i).FinalAccountNo;
                        if (ModelClickAccountNo.equalsIgnoreCase(ForiAccountName)) {
                            tmpdata.add(allData.get(i));
                        }
                    }
                    if (tmpdata.size() > 0) {
                        String header = "";
                        ArrayList<String> CreditData = new ArrayList<>();
                        ArrayList<String> DebitData = new ArrayList<>();
                        boolean istitlefound = false;
                        for (int i = 0; i < tmpdata.size(); i++) {
                            istitlefound = false;
                            HomeAccoutList adddata = tmpdata.get(i);
                            if (!(header.equals(adddata.DateTransactionHistory))) {

                                String CheckCreditDebit = isDebitedOrCredited(adddata);
                                CreditData = new ArrayList<>();
                                DebitData = new ArrayList<>();

                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }

                                istitlefound = true;
                                HomeAccoutList sectionCell = new HomeAccoutList();
                                sectionCell.DateTransactionHistory = adddata.DateTransactionHistory;
                                sectionCell.isSectionHeader = true;
                                sectionCell.GetTitleType = 0;
                                sectionCell.CreditedData = CreditData;
                                sectionCell.DebitedData = DebitData;
                                tmpdataFinal.add(sectionCell);
                                header = adddata.DateTransactionHistory;
                            }

                            if (!istitlefound) {
                                String CheckCreditDebit = isDebitedOrCredited(tmpdata.get(i));
                                if (CheckCreditDebit.equalsIgnoreCase("1")) {
                                    CreditData.add(tmpdata.get(i).amount);
                                } else {
                                    DebitData.add(tmpdata.get(i).amount);
                                }
                            }

                            adddata.GetTitleType = 1;
                            tmpdataFinal.add(adddata);
                        }
                    }

                    allData.clear();
                    allData.addAll(tmpdataFinal);
                    if (allData.size() > 50) {
                        for (int i = 0; i < 50; i++) {
                            allAccountModelHistories.add(allData.get(i));
                        }
                    } else {
                        allAccountModelHistories.addAll(allData);
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            if (allAccountModelHistories.size() > 0) {
                                rvAccountList.setVisibility(View.VISIBLE);
                                llEmpty.setVisibility(View.GONE);
                                accountHistoryAdapter.notifyDataSetChanged();
                            } else {
                                rvAccountList.setVisibility(View.GONE);
                                llEmpty.setVisibility(View.VISIBLE);
                            }
                        }
                    });

                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pbLoading.setVisibility(View.GONE);
                            rvAccountList.setVisibility(View.GONE);
                            llEmpty.setVisibility(View.VISIBLE);
                        }
                    });
                }
            }
        }).start();


    }

    private String getFormatedAmount(String amount) {
        return NumberFormat.getNumberInstance(Locale.getDefault()).format(amount);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private String isDebitedOrCredited(HomeAccoutList homeAccount) {
        String isDebitedOrCredited = "0";
        if (homeAccount.isAtmWithDraw) {
            isDebitedOrCredited = "0";
        } else if (homeAccount.isDebited) {
            isDebitedOrCredited = "0";
        } else {
            isDebitedOrCredited = "1";
        }
        return isDebitedOrCredited;
    }
}

