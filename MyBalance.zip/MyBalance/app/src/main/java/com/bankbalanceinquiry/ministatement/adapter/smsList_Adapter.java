package com.bankbalanceinquiry.ministatement.adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.smsInfo;

import java.util.List;

public class smsList_Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Context mContext;
    private static final int HEADER = 0;
    private static final int ITEM = 1;
    List<smsInfo> mSMS;

    public smsList_Adapter(FragmentActivity activity, List<smsInfo> mSMS) {
        mContext = activity;
        this.mSMS = mSMS;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        View v = layoutInflater.inflate(R.layout.sms_layout_recycle, parent, false);
        return new ItemViewHolder(v);
        /*switch (viewType) {
            case HEADER:
                v = layoutInflater.inflate(R.layout.native_frame_layout, parent, false);
                return new HeaderViewHolder(v);
            default:
        }*/

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {

        ((ItemViewHolder) holder).list_textsms.setText(mSMS.get(position).getS_title());

        ((ItemViewHolder) holder).card_sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                final String textMsg = mSMS.get(position).getS_message();
                final String phone = mSMS.get(position).getS_mobile();
                Log.e("sms_msg-->", " " + mSMS.get(position).getS_message());
                Log.e("sms_msg-->", " " + mSMS.get(position).getS_mobile());

                final Dialog smsDailog = new Dialog(mContext, R.style.WideDialog);
                smsDailog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                smsDailog.setCancelable(true);
                smsDailog.setContentView(R.layout.custom_sms_dialog);
                smsDailog.setCanceledOnTouchOutside(true);
                smsDailog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                final EditText text_sms = (EditText) smsDailog.findViewById(R.id.card_sms_edit);
                TextView send_sms = (TextView) smsDailog.findViewById(R.id.send_sms);
                TextView btn_later = (TextView) smsDailog.findViewById(R.id.btn_later);

                text_sms.setText(textMsg);
                send_sms.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse("smsto:" + phone);
                                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                                intent.putExtra("sms_body", text_sms.getText().toString().trim());
                                if (intent.resolveActivity(mContext.getPackageManager()) != null) {
                                    mContext.startActivity(intent);
                                } else {
                                    Toast.makeText(mContext, "No app found to perform this action! Please try again later.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }, 400);
                    }
                });
                btn_later.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        smsDailog.dismiss();
                    }
                });

                smsDailog.show();
            }

        });


        /*if (position % 5 == 0) {
            int colors = ContextCompat.getColor(mContext, R.color.colorAccent);

            FacebookAdsManager facebookAdsManager = new FacebookAdsManager(mContext);
            facebookAdsManager.loadNativeAd(mContext, ((ItemViewHolder) holder).adLayout, true, new AdEventListener() {
                @Override
                public void onAdLoaded() {
                    ((ItemViewHolder) holder).adcard.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdClosed() {

                }

                @Override
                public void onLoadError(String errorCode) {
                    Log.e("errorCode---->", "onLoadError: " + errorCode);
                    ((ItemViewHolder) holder).adcard.setVisibility(View.GONE);
                }
            });

        }
        else { }*/
    }


    public class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView list_textsms;
        LinearLayout card_sms;

        private final FrameLayout adLayout;
        private final LinearLayout adcard;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            adLayout = itemView.findViewById(R.id.adLayout);
            adcard = itemView.findViewById(R.id.adcard);
            list_textsms = (TextView) itemView.findViewById(R.id.list_textsms);
            card_sms = (LinearLayout) itemView.findViewById(R.id.card_sms);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return ITEM;
    }

    @Override
    public int getItemCount() {
        return mSMS.size();
    }

    private void refreshAd() { }
}
