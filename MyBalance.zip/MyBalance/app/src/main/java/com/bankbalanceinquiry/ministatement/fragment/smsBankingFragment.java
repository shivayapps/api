package com.bankbalanceinquiry.ministatement.fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.smsList_Adapter;
import com.bankbalanceinquiry.ministatement.database.DatabaseAccess;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.smsInfo;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.NativeAdsSize;
import com.example.app.ads.helper.NativeAdvancedModelHelper;

import java.util.List;

import static android.content.Context.MODE_PRIVATE;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;

public class smsBankingFragment extends Fragment {
    String bank_name;
    RecyclerView sms_recycle;
    List<smsInfo> mSMS;
    smsList_Adapter smsList_adapter;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editorBank;
    private FrameLayout adLayout;
    private View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_smsbanking, container, false);

        sms_recycle = (RecyclerView) view.findViewById(R.id.custom_sms_list);

        adLayout = view.findViewById(R.id.adContainer);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        sms_recycle.setLayoutManager(linearLayoutManager);

        sharedPreferences = getActivity().getSharedPreferences("bank_select", MODE_PRIVATE);
        editorBank = sharedPreferences.edit();

        bank_name = sharedPreferences.getString("bank_name", "No Bank");
        // bank_name=bank_n;


        refreshData();


        return view;
    }

    public void refreshData() {
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getActivity());
        databaseAccess.open();
        mSMS = databaseAccess.getSMS_detail(bank_name);
        databaseAccess.close();

        smsList_adapter = new smsList_Adapter(getActivity(), mSMS);
        sms_recycle.setAdapter(smsList_adapter);

        if (new AdsManager(getActivity()).isNeedToShowAds() && NetworkManager.isInternetConnected(getActivity())) {

            new NativeAdvancedModelHelper(getActivity()).loadNativeAdvancedAd(
                    NativeAdsSize.Medium,
                    adLayout,
                    null, true, true, new Function1<Boolean, Unit>() {
                        @Override
                        public Unit invoke(Boolean aBoolean) {
//                            to_native_ad.setVisibility(View.VISIBLE);
                            return null;
                        }
                    }, new Function0<Unit>() {
                        @Override
                        public Unit invoke() {
                            return null;
                        }
                    });
        }

    }

}
