package com.bankbalanceinquiry.ministatement.activity.ui.tools;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bankbalanceinquiry.ministatement.R;


public class ToolsFragment extends Fragment {



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_tools, container, false);

        Uri uri_privacy= Uri.parse(getResources().getString(R.string.privacy_policy));
        //url_netBank= listBankAdapter.bank_url;
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(String.valueOf(uri_privacy)));
        startActivity(i);

        onbackPressed();

        return root;
    }

    public  void onbackPressed()
    {
        super.getActivity().onBackPressed();
    }
}