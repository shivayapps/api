package com.bankbalanceinquiry.ministatement.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.AllAccountListAdapter;
import com.bankbalanceinquiry.ministatement.common.AllBankAvilabeBalancMsg;
import com.bankbalanceinquiry.ministatement.common.BankingSmsRead;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.model.AllAccountModel;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AllAccountActivity extends AppCompatActivity implements AllAccountListAdapter.ClickActivDeactiveint {

    private Activity activity;
    private Toolbar toolbar;

    private RecyclerView rvAccountList;
    private ArrayList<AllAccountModel> allAccountModels;
    private ArrayList<AllAccountModel> allAccountModelstmp;
    private AllAccountListAdapter allAccountListAdapter;
    private AsyncTask mMyTask = null;
    private ProgressBar pbLoading;

    private ArrayList<AvilabeBalanceModel> avilabeBalanceModels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_account);

        activity = this;

        InitToolBar();

        InitComponent();
    }

    private void InitToolBar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("All Account");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    private void InitComponent() {

        rvAccountList = findViewById(R.id.rvAccountList);
        pbLoading = findViewById(R.id.pbLoading);
        pbLoading.setVisibility(View.VISIBLE);
        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        avilabeBalanceModels = new ArrayList<>();
        avilabeBalanceModels.addAll(AllBankAvilabeBalancMsg.AddAvilableMsg());
        mMyTask = new GetAllSmsOnTransaction().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

    }

    public String getAmount(String data) {
        // pattern - rs. **,***.**
        String pattern1 = "(inr)+[\\s]?+[0-9]*+[\\\\,]*+[0-9]*+[\\\\.][0-9]{2}";
        Pattern regex1 = Pattern.compile(pattern1);
        // pattern - inr **,***.**
        String pattern2 = "(rs)+[\\\\.][\\s]*+[0-9]*+[\\\\,]*+[0-9]*+[\\\\.][0-9]{2}";
        Pattern regex2 = Pattern.compile(pattern2);

        Matcher matcher1 = regex1.matcher(data);
        Matcher matcher2 = regex2.matcher(data);
        if (matcher1.find()) {
            try {
                String a = (matcher1.group(0));
                a = a.replace("inr", "");
                a = a.replace(" ", "");
                a = a.replace(",", "");
                return a;
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (matcher2.find()) {
            try {
                // searched for rs or inr preceding number in the form of rs. **,***.**
                String a = (matcher2.group(0));
                a = a.replace("rs", "");
                a = a.replaceFirst(".", "");
                a = a.replace(" ", "");
                a = a.replace(",", "");
                return a;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private class GetAllSmsOnTransaction extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            allAccountModels = new ArrayList<>();
            allAccountModelstmp = new ArrayList<>();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pbLoading.setVisibility(View.GONE);
            // allAccountModels.addAll(allAccountModelstmp);
            for (int i = 0; i < allAccountModelstmp.size(); i++) {
                boolean isFound = false;
                String ForiiAccountNo = allAccountModelstmp.get(i).getAccountNo();
                for (int j = 0; j < allAccountModels.size(); j++) {
                    String ForjjAccountNo = allAccountModels.get(j).getAccountNo();
                    if (TextUtils.equals(ForiiAccountNo, ForjjAccountNo)) {
                        isFound = true;
                        break;
                    }
                }
                if (!isFound) {
                    allAccountModels.add(allAccountModelstmp.get(i));
                }
            }
            if (allAccountModels.size() > 0) {
                allAccountListAdapter = new AllAccountListAdapter(activity, allAccountModels);
                allAccountListAdapter.RegisterInterface(AllAccountActivity.this);
                rvAccountList.setAdapter(allAccountListAdapter);
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            getAllSms();
            return null;
        }
    }

    /*  public List<String> getAllSms() {
          Uri message = Uri.parse("content://sms/");
          ContentResolver cr = getContentResolver();
          Cursor c = cr.query(message, null, null, null, null);
          startManagingCursor(c);
          SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
          String dateVal = "";
          int totalSMS = c.getCount();
          if (c.moveToFirst()) {
              String header = "";
              for (int i = 0; i < totalSMS; i++)
              {
                  String id = c.getString(c.getColumnIndexOrThrow("_id"));
                  String BankNameTitle = c.getString(c.getColumnIndexOrThrow("address"));
                  String body = c.getString(c.getColumnIndexOrThrow("body"));
                  String read = c.getString(c.getColumnIndexOrThrow("read"));
                  String date = c.getString(c.getColumnIndexOrThrow("date"));
                  String type = c.getString(c.getColumnIndexOrThrow("type"));
                  if (type.contains("1")) {
                      ///inbox
                  } else {
                      //sent
                  }

                  Log.e("MessgeBody", body);
                  String CheckIsDebitCredit = BankingSmsRead.SMSBodyToGetCreditDabit(body);
                  if (!CheckIsDebitCredit.equalsIgnoreCase("NoTransaction"))
                  {
                      String AccountNo = BankingSmsRead.SMSBodyToGetAccountNumber(body);
                      String AccountAmount = BankingSmsRead.SMSBodyToGetTotalAmount(body);
                      //   String GetAvilable = BankingSmsRead.SMSBodyToAvilableBalance(body);
                      String GetAvilableClear = GetTotalAmount(body);
                      String GetBankingSMSDate = GetBankingSMSDate(body);

                      Long dateV = Long.parseLong(date);
                      dateVal = formatter.format(new Date(dateV));

                      Log.e("BodySMS", " id " + id + "\naddress " + BankNameTitle +
                              "\nbody " + body +
                              "\nAccountNo " + AccountNo +
                              "\nAccountAmount " + AccountAmount +
                              "\nCheckIsDebitCredit " + CheckIsDebitCredit +
                              "\ndate " + dateVal +
                              "\nGetAvilable " + GetAvilableClear +
                              "\nGetBankingSMSDate " + GetBankingSMSDate
                      );
                      allAccountModels.add(new AllAccountModel(BankNameTitle, AccountNo,
                              AccountAmount, dateVal, CheckIsDebitCredit, GetAvilableClear, GetBankingSMSDate));

                  }
                  c.moveToNext();
              }
              BankingSmsRead.DenaBankDetails();
          }
          c.close();
          return null;
      }
      */
    public List<String> getAllSms() {
        Uri message = Uri.parse("content://sms/inbox");
        ContentResolver cr = getContentResolver();
        Cursor c = cr.query(message, null, null, null, null);
        startManagingCursor(c);
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String dateVal = "";
        int totalSMS = c.getCount();
        if (c.moveToFirst()) {
            Log.e("okHeader", "Blabk");
            for (int i = 0; i < totalSMS; i++) {
                String id = c.getString(c.getColumnIndexOrThrow("_id"));
                String BankNameTitle = c.getString(c.getColumnIndexOrThrow("address"));
                String body = c.getString(c.getColumnIndexOrThrow("body"));
                String read = c.getString(c.getColumnIndexOrThrow("read"));
                String date = c.getString(c.getColumnIndexOrThrow("date"));
                String type = c.getString(c.getColumnIndexOrThrow("type"));
                if (type.contains("1")) {
                    ///inbox
                } else {
                    //sent
                }
                Log.e("MessgeBody", body);
                if (BankNameTitle != null) {
                    boolean isadded = CheckAddedOrNot(BankNameTitle);
                    if (isadded) {
                        String CheckIsDebitCredit = BankingSmsRead.SMSBodyToGetCreditDabit(body);
                        if (!CheckIsDebitCredit.equalsIgnoreCase("NoTransaction")) {
                            String AccountNo = BankingSmsRead.SMSBodyToGetAccountNumber(body);
                            String AccountAmount = BankingSmsRead.SMSBodyToGetTotalAmount(body);
                            //   String GetAvilable = BankingSmsRead.SMSBodyToAvilableBalance(body);
                            String GetAvilableClear = GetTotalAmount(body);
                            String GetBankingSMSDate = GetBankingSMSDate(body);

                            Long dateV = Long.parseLong(date);
                            dateVal = formatter.format(new Date(dateV));

                           /* allAccountModelstmp.add(new AllAccountModel(BankNameTitle, AccountNo,
                                    AccountAmount, dateVal, CheckIsDebitCredit, GetAvilableClear, GetBankingSMSDate));
                         */   Log.e("BodySMS", " id " + id + "\naddress " + BankNameTitle +
                                    "\nbody " + body +
                                    "\nAccountNo " + AccountNo +
                                    "\nAccountAmount " + AccountAmount +
                                    "\nCheckIsDebitCredit " + CheckIsDebitCredit +
                                    "\ndate " + dateVal +
                                    "\nGetAvilable " + GetAvilableClear +
                                    "\nGetBankingSMSDate " + GetBankingSMSDate);
                        }
                    }
                    if (BankNameTitle.equalsIgnoreCase("TM-KOTAKB")) {
                        if (body.contains("credited") || body.contains("debited") ||
                                body.contains("withdrawn") || body.contains("w/d")
                                || body.contains("Deposited") || body.contains("deposited")) {
                           /* Pattern account = Pattern.compile("[0-9]*[Xx\\*]*[0-9]*[Xx\\*]+[0-9]{3,}");
                            Matcher acMatch = account.matcher(body);
                            if (acMatch.find())
                            {
                                String element = acMatch.group(0);
                                Log.e("element", element);

                            }*/
                        }
                    }
                }
                c.moveToNext();
            }
            //BankingSmsRead.DenaBankDetails();
        }
        c.close();
        return null;
    }

    public boolean CheckAddedOrNot(String bankNameTitle) {
        if (bankNameTitle != null) {
            if (bankNameTitle.equalsIgnoreCase("VM-ICICIB") ||
                    bankNameTitle.equalsIgnoreCase("VK-CENTBK") ||
                    bankNameTitle.equalsIgnoreCase("BX-BKDENA") ||
                    bankNameTitle.equalsIgnoreCase("VK-CBSSBI")

            ) {
                return true;
            }
        }
        return false;
    }

    public String GetTotalAmount(String fullText) {
        Log.e("Msgbbb", fullText);
        Log.e("avilabeBalanceModels", avilabeBalanceModels.size() + "");
        boolean isFount = false;
        for (int i = 0; i < avilabeBalanceModels.size(); i++) {
            String AvilableMsg = avilabeBalanceModels.get(i).getAvilableMsg();
            String BankName = avilabeBalanceModels.get(i).getBankName();
            if (fullText.toLowerCase().indexOf(AvilableMsg.toLowerCase()) > -1)
            {
                isFount = true;
                Log.e("BankNameBankName", BankName);
                String[] separated = fullText.split(AvilableMsg);
                if (separated.length > 1) {
                    fullText = separated[1];
                    Log.e("separatedseparated ", separated[1] + "\n");
                } else {
                    fullText = "";
                    Log.e("separatedseparated", " Nuu");
                }
                break;
            }
        }

        if (!isFount) {
            fullText = "";
        }
        return fullText;
    }

    public String GetBankingSMSDate(String fullText) {
//        fullText = "Dear Customer, your Acct XX983 is credited with salary of INR 21,000.00 on 07-Apr-20. Info: NEFT-N098200390. The Available Balance is INR 2,23,017.00";
        boolean isFount = false;
        for (int i = 0; i < avilabeBalanceModels.size(); i++) {
            String AvilableMsg = avilabeBalanceModels.get(i).getDateonMsg();
            String BankName = avilabeBalanceModels.get(i).getBankName();
            if (fullText.toLowerCase().indexOf(AvilableMsg.toLowerCase()) > -1) {
                Log.e("BankNameBankNameDate", BankName);
                String[] separated = fullText.split(AvilableMsg);
                if (separated.length > 1) {
                    isFount = true;
                    fullText = separated[1];
                    String[] fullTextnew = fullText.split(" ");
                    fullText = fullTextnew[1];
                    Log.e("fullTextnew", fullText);
                }
                break;
            }
        }
        if (!isFount) {
            fullText = "";
        }
        return fullText;
    }

    @Override
    public void ClickActiveDeactive(int position) {
        Log.e("PositionAccount", position + "");
        if (allAccountModels.size() > 0) {
            Intent i = new Intent(activity, TransactionAllActivity.class);
            i.putExtra("OBJ", allAccountModels.get(position));
            startActivity(i);
        }
    }

    @Override
    public void ClickBusinessOrPersion(int position) {
        if (allAccountModels.size() > 0) {
            boolean isActivinactive = allAccountModels.get(position).isBusinessOrPersion();
            if (isActivinactive) {
                allAccountModels.get(position).setBusinessOrPersion(false);
            } else {
                allAccountModels.get(position).setBusinessOrPersion(true);
            }

            if (allAccountListAdapter != null) {
                allAccountListAdapter.notifyDataSetChanged();
            }
        }
    }
}
