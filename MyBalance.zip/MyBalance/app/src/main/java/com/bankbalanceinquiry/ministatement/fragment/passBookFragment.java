package com.bankbalanceinquiry.ministatement.fragment;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment;
import com.bankbalanceinquiry.ministatement.adapter.bankPass_Adapter;
import com.bankbalanceinquiry.ministatement.adapter.bankWhich_Adapter;
import com.bankbalanceinquiry.ministatement.model.passBook;

import java.util.ArrayList;
import java.util.List;

public class passBookFragment extends Fragment {


    RecyclerView recyle_pass;
    List<passBook> pData;
    bankPass_Adapter bankPassAdapter;
    String account_name;
    Integer aval_balance;
    int position;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View root = inflater.inflate(R.layout.fragment_passbook, container, false);


        position = bankWhich_Adapter.pos;

        recyle_pass = (RecyclerView) root.findViewById(R.id.recyle_pass);


        pData = new ArrayList<>();

        for (int i = 0; i < BoxviewFragment.pData.size(); i++) {

            if (BoxviewFragment.pData.get(i).getBank_type() == position) {
                passBook passNew = new passBook();

                String Description = BoxviewFragment.pData.get(i).getPass_amount();

                Log.e("Data--)", "" + Description);
                if (!TextUtils.isEmpty(Description)) {
                    passNew.setPass_which(BoxviewFragment.pData.get(i).getPass_which());
                    passNew.setPass_amount(BoxviewFragment.pData.get(i).getPass_amount());
                    passNew.setAva_balance(BoxviewFragment.pData.get(i).getAva_balance());
                    passNew.setPass_date(BoxviewFragment.pData.get(i).getPass_date());

                    Log.e("Description==)", "" + Description);
                    passNew.setPass_dec(BoxviewFragment.pData.get(i).getPass_dec());
                    pData.add(passNew);

                }
                // txtBalance.setText(passNew.getAva_balance());

                Log.e("found", "Yes");
            }

        }

        Log.e("Arry--)", " " + pData.size());
        pData= BoxviewFragment.pData;
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyle_pass.setLayoutManager(linearLayoutManager);

        aval_balance = 0;
        bankPassAdapter = new bankPass_Adapter(getActivity(), pData);

        Log.e("data", " " + pData.size());
        recyle_pass.setAdapter(bankPassAdapter);
        return root;
    }
}
