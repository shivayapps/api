package com.bankbalanceinquiry.ministatement.activity.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.BillsAndEmilAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.databasedNew.DBHelperAccountNew;
import com.bankbalanceinquiry.ministatement.model.AvilabeBalanceModel;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;

import java.util.ArrayList;


public class BillsFragment extends Fragment {

    private RecyclerView rvAccountList;
    private ProgressBar pbLoading;
    private ArrayList<AvilabeBalanceModel> avilabeBalanceModels;
    private ArrayList<HomeAccoutList> bilsEmiModels;
    private DBHelperAccountNew mydbBill;
    private BillsAndEmilAdapter billsAndEmilAdapter;

    private LinearLayout llEmpty;
    private TextView tvEmptyMessage;
    private ImageView ivEmptyImage;

    private String mKey = "";

    public BillsFragment(String mKey) {
        this.mKey = mKey;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragments_bill, container, false);
        mydbBill = new DBHelperAccountNew(getActivity());
        InitComponent(root);
        return root;
    }


    private void InitComponent(View root) {

        rvAccountList = root.findViewById(R.id.rvAccountList);
        pbLoading = root.findViewById(R.id.pbLoading);
        CommonFun.RecyclerViewLinearLayout(getActivity(), rvAccountList);
        pbLoading.setVisibility(View.VISIBLE);

        llEmpty = root.findViewById(R.id.llEmpty);
        tvEmptyMessage = root.findViewById(R.id.tvEmptyMessage);
        ivEmptyImage = root.findViewById(R.id.ivEmptyImage);
        tvEmptyMessage.setText(getEmptyMessage());

        avilabeBalanceModels = new ArrayList<>();

        pbLoading.setVisibility(View.GONE);

        CheckDataNotifyOrNot();

    }

    private void CheckDataNotifyOrNot() {
        CommonFun.isIncommingSmsNotify = "";
        bilsEmiModels = new ArrayList<>();
        bilsEmiModels.addAll(mydbBill.GetSpecificBills(mKey));
        CallBillsAdapterSet();
    }

    private void CallBillsAdapterSet() {
        Log.e("bilsEmiModels", bilsEmiModels.size() + "");
        if (bilsEmiModels.size() > 0) {
            rvAccountList.setVisibility(View.VISIBLE);
            llEmpty.setVisibility(View.GONE);
            billsAndEmilAdapter = new BillsAndEmilAdapter(getActivity(), bilsEmiModels);
            rvAccountList.setAdapter(billsAndEmilAdapter);
        } else {
            rvAccountList.setVisibility(View.GONE);
            llEmpty.setVisibility(View.VISIBLE);
        }
    }


    private String getEmptyMessage() {
        switch (mKey) {
            case "loan":
                return "Loan EMIs list is empty";
            case "prepaid":
                return "Prepaid bills list is empty";
            case "phone":
                return "Phone bills list is empty";
            case "credit_card":
                return "Credit card bills list is empty";
            case "generic":
                return "Generic bills list is empty";
            case "electricity":
                return "Electricity bills list is empty";
            case "insurance":
                return "Insurance bills list is empty";
            case "gas":
                return "Gas bills list is empty";
            default:
                return "Bills & EMIs Empty";
        }
    }
}
