package com.bankbalanceinquiry.ministatement.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.adapter.TestAdapter;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.test.TestData;

import java.util.ArrayList;

public class TitleWithHeaderActivity extends AppCompatActivity {

    private Activity activity;

    private ArrayList<TestData> testData = new ArrayList<>();
    private ArrayList<TestData> testDataFinal = new ArrayList<>();

    private TestAdapter testAdapter;
    private RecyclerView rvAccountList;

    private Toolbar toolbar;
    private AsyncTask mMyTask = null;
    private Dialog DialogProgress = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collapsing_toolbar);
        activity = this;

        initToolBar();
        CallFillData();
        mMyTask = new MyTask().execute(20);


        if (testData.size() > 0) {
            String header = "";

            ArrayList<String> CreditData = new ArrayList<>();
            ArrayList<String> DebitData = new ArrayList<>();
            boolean istitlefound = false;
            for (int i = 0; i < testData.size(); i++) {
                istitlefound = false;

                if (!(header.equals(testData.get(i).getTitleDate()))) {

                    String CheckCreditDebit = testData.get(i).getCreditDebit();
                    CreditData = new ArrayList<>();
                    DebitData = new ArrayList<>();

                    if (CheckCreditDebit.equalsIgnoreCase("1")) {
                        CreditData.add(testData.get(i).getAmout());
                    } else {
                        DebitData.add(testData.get(i).getAmout());
                    }

                    istitlefound = true;

                    TestData sectionCell = new TestData(testData.get(i).getTitleDate(), "", "");
                    sectionCell.setSectionHeader(true);
                    sectionCell.setGetTitleType(0);
                    sectionCell.setStrings(CreditData);
                    sectionCell.setDebitData(DebitData);
                    testDataFinal.add(sectionCell);

                    header = testData.get(i).getTitleDate();
                }

                if (!istitlefound) {
                    String CheckCreditDebit = testData.get(i).getCreditDebit();
                    if (CheckCreditDebit.equalsIgnoreCase("1")) {
                        CreditData.add(testData.get(i).getAmout());
                    } else {
                        DebitData.add(testData.get(i).getAmout());
                    }
                }

                testData.get(i).setGetTitleType(1);
                testDataFinal.add(testData.get(i));
            }

        }

        rvAccountList = findViewById(R.id.rvAccountList);
        CommonFun.RecyclerViewLinearLayout(activity, rvAccountList);

        testAdapter = new TestAdapter(activity, testDataFinal);
        rvAccountList.setAdapter(testAdapter);

        // new AsyncTaskRunner().execute("fs");

    }

    private void initToolBar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Cash");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    StringBuilder finalallbalance = new StringBuilder();

    private void CallAccountBalanceTesting(ArrayList<String> tempList) {
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                finalallbalance.append(AmoutValue)
                        .append("Credited");
            }
        }
        Log.e("FinalSum==>", CommonFun.findSum(finalallbalance.toString()) + "");
    }


    private int CallAllAccountBalance(String AmoutValuerepl) {
        AmoutValuerepl = AmoutValuerepl.replace(",", "");
        return CommonFun.findSum(AmoutValuerepl);
    }

    private void CallFillData() {
        testData.add(new TestData("APRIL", "21000", "1"));

        testData.add(new TestData("MARCH", "200000", "1"));
        testData.add(new TestData("MARCH", "500", "0"));
        testData.add(new TestData("MARCH", "500", "0"));
        testData.add(new TestData("MARCH", "500", "0"));
        testData.add(new TestData("MARCH", "175", "0"));
        testData.add(new TestData("MARCH", "3510", "0"));
        testData.add(new TestData("MARCH", "2000", "0"));
        testData.add(new TestData("MARCH", "9000", "0"));
        testData.add(new TestData("MARCH", "1900", "0"));
        testData.add(new TestData("MARCH", "100", "0"));
        testData.add(new TestData("MARCH", "2060", "0"));
        testData.add(new TestData("MARCH", "21000", "1"));
        testData.add(new TestData("MARCH", "100", "0"));

    }


    ProgressBar progress_horizontal;
    TextView tvValue;
    private int mycound = 0;

    class MyTask extends AsyncTask<Integer, Integer, String> {
        private int cursor = 0;

        @Override
        protected String doInBackground(Integer... params) {
            if (progress_horizontal != null) {
                progress_horizontal.setMax(50);
            }
            for (int i = 0; i < 50; i++)
            {
                try {
                    Thread.sleep(100);
                    publishProgress(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }


            return "Task Completed.";
        }

        @Override
        protected void onPostExecute(String result) {
            if (DialogProgress != null) {
                DialogProgress.dismiss();
            }
        }

        @Override
        protected void onPreExecute() {
            CallProgress();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            Log.e("onProgressUpdate==>?", values[0] + "");
            if (tvValue != null) {
                mycound++;
                Log.e("my Count", mycound + "");
                tvValue.setText(mycound + "");
            }
            if (progress_horizontal != null) {
                progress_horizontal.setProgress(mycound);
            }
        }
    }

    private void CallProgress() {
        DialogProgress = new Dialog(activity);
        DialogProgress.requestWindowFeature(Window.FEATURE_NO_TITLE);
        DialogProgress.getWindow().setBackgroundDrawable(null);
        DialogProgress.setContentView(R.layout.layout_loding_allbg);
        DialogProgress.getWindow().setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        DialogProgress.setCancelable(false);
        DialogProgress.setCanceledOnTouchOutside(false);

        tvValue = DialogProgress.findViewById(R.id.value123);
        progress_horizontal = DialogProgress.findViewById(R.id.progress_horizontal);

        DialogProgress.show();
    }

}