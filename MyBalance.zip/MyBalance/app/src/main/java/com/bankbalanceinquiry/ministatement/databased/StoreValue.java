package com.bankbalanceinquiry.ministatement.databased;

import android.content.Context;
import android.content.SharedPreferences;

import com.bankbalanceinquiry.ministatement.utils.MyApplication;

public class StoreValue {
    private static SharedPreferences get() {
        return MyApplication.getAppContext().getSharedPreferences("MyApplication", Context.MODE_PRIVATE);
    }

    public static String GetFirstime(String Key) {
        return get().getString(Key, "");
    }

    public static void SetFirstime(String Key, String Value) {
        get().edit().putString(Key, Value).apply();
    }

    public static String GetLodingData(String Key) {
        return get().getString(Key, "");
    }

    public static void SetLodingData(String Key, String Value) {
        get().edit().putString(Key, Value).apply();
    }


}

