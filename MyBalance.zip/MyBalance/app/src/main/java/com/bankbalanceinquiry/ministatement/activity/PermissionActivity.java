package com.bankbalanceinquiry.ministatement.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.activity.ui.TrackActivity;
import com.bankbalanceinquiry.ministatement.utils.Constant;
import com.bankbalanceinquiry.ministatement.utils.PreferenceHelper;
import com.bankbalanceinquiry.ministatement.utils.RippleBackground;

import java.util.ArrayList;
import java.util.List;

public class PermissionActivity extends AppCompatActivity {

    Toolbar toolbar;
    Button allow_Permission;
    TextView skip;
    RippleBackground animButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getColor(R.color.app_color));
        }

        toolbar.setTitle(getString(R.string.app_name));
        allow_Permission = (Button) findViewById(R.id.allow_Permission);
        skip = (TextView) findViewById(R.id.skip);
        animButton = (RippleBackground) findViewById(R.id.animButton);
        animButton.startRippleAnimation();

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(), drawerActivity.class);
                startActivity(i);
                finish();
            }
        });
        allow_Permission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Get_Permission();
                } else {
                    if (TextUtils.isEmpty(PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.TRACK_PREF))) {
                        Intent i = new Intent(getApplicationContext(), TrackActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        Intent i = new Intent(getApplicationContext(), drawerActivity.class);
                        startActivity(i);
                        finish();
                    }
                }
            }
        });

//        setAdMobData();
    }

//    private void setAdMobData() {
//
//        RequestQueue queue = Volley.newRequestQueue(this);
//        StringRequest request = new StringRequest(Request.Method.GET, Constant.AD_URL,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        //Log.e("setAdMobData","response:"+response);
//                        //textView.setText(response.toString());
//                        //Toast.makeText(MainActivity.this, response.toString(), Toast.LENGTH_LONG).show();
//                        try {
//                            JSONObject jsonObject = new JSONObject(response);
//                            String liveAd = jsonObject.getString("live_ad");
//
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.LIVE_AD, liveAd.trim());
//                            //JSONArray jsonAdmob=jsonObject.getJSONArray("admob");
//                            //JSONArray jsonFacebook=jsonObject.getJSONArray("facebook");
//
//                            JSONObject jsonAdmob = jsonObject.getJSONObject("admob");
//                            String g_AppId = jsonAdmob.getString("app_id");
//                            String g_NativeId = jsonAdmob.getString("native_advance");
//                            String g_InterstitialId = jsonAdmob.getString("interstitial");
//                            String g_BannerId = jsonAdmob.getString("banner");
//                            String g_AppOpen = jsonAdmob.getString("app_open");
//
//                            Log.e("setAdMobData", "g_AppId:" + g_AppId);
//                            Log.e("setAdMobData", "g_NativeId:" + g_NativeId);
//                            Log.e("setAdMobData", "g_InterstitialId:" + g_InterstitialId);
//                            Log.e("setAdMobData", "g_BannerId:" + g_BannerId);
//                            Log.e("setAdMobData", "g_AppOpen:" + g_AppOpen);
//
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.G_APP_ID, g_AppId.trim());
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.G_NATIVE_ID, g_NativeId.trim());
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.G_INTERSTITIAL_ID, g_InterstitialId.trim());
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.G_APPOPEN_ID, g_AppOpen.trim());
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.G_BANNER_ID, g_BannerId.trim());
//
//                            JSONObject jsonFacebook = jsonObject.getJSONObject("facebook");
//                            String f_NativeId = jsonFacebook.getString("native_advance");
//                            String f_InterstitialId = jsonFacebook.getString("interstitial");
//                            String f_BannerId = jsonFacebook.getString("banner");
//                            String f_NativeBannerId = jsonFacebook.getString("native_banner");
//
//                            Log.e("setAdMobData", "f_NativeId:" + f_NativeId);
//                            Log.e("setAdMobData", "f_InterstitialId:" + f_InterstitialId);
//                            Log.e("setAdMobData", "f_BannerId:" + f_BannerId);
//                            Log.e("setAdMobData", "f_NativeBannerId:" + f_NativeBannerId);
//
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.F_NATIVE_ID, f_NativeId.trim());
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.F_INTERSTITIAL_ID, f_InterstitialId.trim());
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.F_NATIVE_ID, f_NativeBannerId.trim());
//                            SharedPreferenceClass.setString(PermissionActivity.this, Constant.F_BANNER_ID, f_BannerId.trim());
//
//                            //preferenceManager.setITimeInterval("3");
//
//                            if (SharedPreferenceClass.getString(PermissionActivity.this, Constant.LIVE_AD, "admob").equalsIgnoreCase("admob")) {
//                                setAppId(g_AppId);
//                            }
//                        } catch (JSONException e) {
//                            Log.e("setAdMobData", "JSONException:" + e);
//                            e.printStackTrace();
//                        }
//
//                        if (SharedPreferenceClass.getString(PermissionActivity.this, Constant.LIVE_AD, "admob").equalsIgnoreCase("admob")) {
//                            AdmobAdManager admobAdManager = new AdmobAdManager(PermissionActivity.this);
//                            admobAdManager.loadInterstitialAd(PermissionActivity.this, SharedPreferenceClass.getString(PermissionActivity.this, Constant.G_INTERSTITIAL_ID, ""));
//                        } else {
//                            FacebookAdsManager facebookAdsManager = new FacebookAdsManager(PermissionActivity.this);
//                            facebookAdsManager.loadInterstitialAd(PermissionActivity.this, SharedPreferenceClass.getString(PermissionActivity.this, Constant.F_INTERSTITIAL_ID, ""));
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.e("setAdMobData", "onErrorResponse:" + error.networkResponse.statusCode);
//                        Log.e("setAdMobData", "onErrorResponse:" + error.getMessage());
//
//                    }
//                });
//        queue.add(request);
//    }

    private void setAppId(String appId) {
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String myApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d("TAG", "Name Found: " + myApiKey);
            ai.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", appId);//you can replace your key APPLICATION_ID here
            String ApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");
            Log.d("TAG", "ReNamed Found: " + ApiKey);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("TAG", "Failed to load meta-data, NameNotFound: " + e.getMessage());
        } catch (NullPointerException e) {
            Log.e("TAG", "Failed to load meta-data, NullPointer: " + e.getMessage());
        }
    }

    private void Get_Permission() {

        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();

        if (!addPermission(permissionsList, Manifest.permission.READ_SMS))
            permissionsNeeded.add("Read SMS");

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                for (int i = 0; i < 1; i++)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
                    }

                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
            }
            return;
        }


    }


    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                if (!shouldShowRequestPermissionRationale(permission))
                    return false;
            }
        }

        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (permissions.length >= 1)
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (TextUtils.isEmpty(PreferenceHelper.getFromUserDefaults(getApplicationContext(), Constant.TRACK_PREF))) {
                    Intent i = new Intent(getApplicationContext(), TrackActivity.class);
                    startActivity(i);
                    finish();
                } else {
                    Intent i = new Intent(getApplicationContext(), drawerActivity.class);
                    startActivity(i);
                    finish();
                }
            }


        return;

    }
}
