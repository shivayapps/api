package com.bankbalanceinquiry.ministatement.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import android.util.Log;

import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.model.smsInfo;

import java.util.ArrayList;
import java.util.List;

public class DatabaseAccess {
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase database;
    private static DatabaseAccess instance;

    /**
     * Private constructor to aboid object creation from outside classes.
     *
     * @param context
     */
    private DatabaseAccess(Context context) {
        this.openHelper = new DatabaseOpenHelper(context);
    }

    /**
     * Return a singleton instance of DatabaseAccess.
     *
     * @param context the Context
     * @return the instance of DabaseAccess
     */
    public static DatabaseAccess getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseAccess(context);
        }
        return instance;
    }

    /**
     * Open the database connection.
     */
    public void open() {
        this.database = openHelper.getWritableDatabase();
    }

    /**
     * Close the database connection.
     */
    public void close() {
        if (database != null && database.isOpen()) {
            this.database.close();
        }
    }

    /**
     * Read all quotes from the database.
     *
     * @return a List of quotes
     */
    public List<String> getBank() {
        List<String> list = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT bank_name FROM tbl_bank_info", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(0));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }


    public List<bankname> getList() {

        List<bankname> data = new ArrayList<>();

        Cursor cursor = database.rawQuery("select * from tbl_bank_info", null);
        StringBuffer stringBuffer = new StringBuffer();
        bankname dataModel = null;
        while (cursor.moveToNext()) {
            dataModel = new bankname();
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("bank_id"));
            String bname = cursor.getString(cursor.getColumnIndexOrThrow("bank_name"));
            String binquiry = cursor.getString(cursor.getColumnIndexOrThrow("bank_inquiry"));
            String bcare = cursor.getString(cursor.getColumnIndexOrThrow("bank_care"));
            int bfav = cursor.getInt(cursor.getColumnIndexOrThrow("bank_fav"));
            String bnet = cursor.getString(cursor.getColumnIndexOrThrow("netbank_api"));
            String bmini = cursor.getString(cursor.getColumnIndexOrThrow("mini_statement"));
            String bshort = cursor.getString(cursor.getColumnIndexOrThrow("bank_short"));

            /*Log.e("BankChnage==><", "bname " + bname +
                    "\n binquiry " + binquiry +
                    "\n bcare " + bcare +
                    "\n bfav " + bfav +
                    "\n bnet " + bnet +
                    "\n bmini " + bmini +
                    "\n bshort " + bshort
            );
*/
            //Log.e("BankChnage==>", "bname " + bname);

            dataModel.setB_id(id);
            dataModel.setB_name(bname);
            dataModel.setB_inquiry(binquiry);
            dataModel.setB_care(bcare);
            dataModel.setB_fav(bfav);
            dataModel.setB_netbank(bnet);
            dataModel.setB_mini(bmini);
            dataModel.setB_short(bshort);

            stringBuffer.append(dataModel);

            data.add(dataModel);
        }

//        for (bankname mo : data) {
//
//            Log.i("name", "" + mo.getB_name());
//        }

        //

        return data;
    }

    public List<bankname> getBalance_details(String bankName) {

        List<bankname> detail = new ArrayList<>();

        Cursor cursor = database.rawQuery("select * from tbl_bank_info where bank_name like '" + bankName + "'", null);
        StringBuffer stringBuffer = new StringBuffer();
        bankname dataDetail = null;
        while (cursor.moveToNext()) {
            dataDetail = new bankname();
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("bank_id"));
            String bname = cursor.getString(cursor.getColumnIndexOrThrow("bank_name"));
            String binquiry = cursor.getString(cursor.getColumnIndexOrThrow("bank_inquiry"));
            String bcare = cursor.getString(cursor.getColumnIndexOrThrow("bank_care"));
            int bfav = cursor.getInt(cursor.getColumnIndexOrThrow("bank_fav"));
            String bnet = cursor.getString(cursor.getColumnIndexOrThrow("netbank_api"));
            String bmini = cursor.getString(cursor.getColumnIndexOrThrow("mini_statement"));
            String bshort = cursor.getString(cursor.getColumnIndexOrThrow("bank_short"));
            dataDetail.setB_id(id);
            dataDetail.setB_name(bname);
            dataDetail.setB_inquiry(binquiry);
            dataDetail.setB_care(bcare);
            dataDetail.setB_fav(bfav);
            dataDetail.setB_netbank(bnet);
            dataDetail.setB_short(bshort);

            if (TextUtils.isDigitsOnly(bmini)) {
                dataDetail.setB_mini(bmini);
            }


            stringBuffer.append(dataDetail);

            detail.add(dataDetail);
        }

        cursor.close();
//        for (bankname mo : detail) {
//
//            Log.i("name", "" + mo.getB_name());
//        }

        //

        return detail;
    }

    public List<smsInfo> getSMS_detail(String bankName) {
        List<smsInfo> sDetail = new ArrayList<>();

        Cursor cursor = database.rawQuery("select * from smsinfo where bankname like '" + bankName + "'", null);
        StringBuffer stringBuffer = new StringBuffer();
        smsInfo smsDetail = null;
        while (cursor.moveToNext()) {
            smsDetail = new smsInfo();

            String stitle = cursor.getString(cursor.getColumnIndexOrThrow("title"));
            String sname = cursor.getString(cursor.getColumnIndexOrThrow("bankname"));
            String smessage = cursor.getString(cursor.getColumnIndexOrThrow("message"));
            String smobile = cursor.getString(cursor.getColumnIndexOrThrow("phno"));


            smsDetail.setS_title(stitle);
            smsDetail.setS_bankname(sname);
            smsDetail.setS_message(smessage);
            smsDetail.setS_mobile(smobile);

            stringBuffer.append(smsDetail);

            sDetail.add(smsDetail);
        }

        for (smsInfo mo : sDetail) {

            Log.i("name", "" + mo.getS_bankname());
        }

        //

        return sDetail;
    }

}
