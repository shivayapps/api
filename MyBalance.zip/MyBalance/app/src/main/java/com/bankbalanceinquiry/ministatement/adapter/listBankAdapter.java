package com.bankbalanceinquiry.ministatement.adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;

import com.bankbalanceinquiry.ministatement.CircularTextView;
import com.bankbalanceinquiry.ministatement.R;

import com.bankbalanceinquiry.ministatement.activity.drawerActivity;
import com.bankbalanceinquiry.ministatement.inapp.AdsManager;
import com.bankbalanceinquiry.ministatement.model.bankname;
import com.bankbalanceinquiry.ministatement.utils.NetworkManager;
import com.example.app.ads.helper.InterstitialAdHelper;

import java.util.List;
import java.util.Random;

import static android.content.Context.MODE_PRIVATE;
import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.navController;
import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.toolbar;
import static com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment.box_view_relative;
//import static com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment.list_bank_relative;
import static com.bankbalanceinquiry.ministatement.activity.ui.BoxviewFragment.readDirect;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class listBankAdapter extends BaseAdapter {
    private Context mContext;
    private List<bankname> mBanklist;
    public static String bank_n;
    public static String bank_url;
    public static String bank_short;
    public static int sbank_id, click;
    String[] bankColor_array;
    SharedPreferences sharedPreferences;

    public listBankAdapter(Context mContext, List<bankname> mBanklist, String[] bankColor_array) {
        this.mContext = mContext;
        this.mBanklist = mBanklist;
        this.bankColor_array = bankColor_array;
    }


    @Override
    public int getCount() {
        return mBanklist.size();
    }


    @Override
    public Object getItem(int i) {
        return mBanklist.get(i);
    }

    @Override
    public long getItemId(int i) {
        return mBanklist.get(i).getB_id();
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View view1 = View.inflate(mContext, R.layout.custom_list_view_layout, null);

        ImageView select = view1.findViewById(R.id.select);

        final TextView bank_name = view1.findViewById(R.id.bank_name);
        CircularTextView photo_card = view1.findViewById(R.id.photo_card);
        //ImageView photo_card = view1.findViewById(R.id.photo_card);
        RelativeLayout bank_select = view1.findViewById(R.id.bank_select);

        bank_name.setText(mBanklist.get(i).getB_name());

//        int id = mContext.getResources().getIdentifier("ic_" + mBanklist.get(i).getB_short().toLowerCase(), "drawable", mContext.getPackageName());
//        if (id != -1) {
//            photo_card.setImageResource(id);
//        }


        photo_card.setText(mBanklist.get(i).getB_short().toUpperCase());
        //photo_card.setBackgroundColor(Color.parseColor(bankColor_array[i]));
        photo_card.setBackgroundColor(Color.parseColor(bankColor_array[new Random().nextInt(bankColor_array.length - 1)]));

//        photo_card.setText(mBanklist.get(i).getB_name().substring(0, 1));
//        photo_card.setSolidColor(bankColor_array[i]);


        Log.e("listBankAdapter", "getB_name_"+i+":" + mBanklist.get(i).getB_name());
        Log.e("listBankAdapter", "getB_id_"+i+":" + mBanklist.get(i).getB_id());

        bank_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                click = 1;
                final int random = new Random().nextInt((4 - 1) + 1) + 1;
                if (random == 2) {
                    if (new AdsManager(mContext).isNeedToShowAds() && NetworkManager.isInternetConnected(mContext)) {

                        InterstitialAdHelper.INSTANCE.isShowInterstitialAd((FragmentActivity) mContext, false,new Function1<Boolean, Unit>(){
                            @Override
                            public Unit invoke(Boolean aBoolean) {

                                return null;
                            }
                        });
                    }

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            sharedPreferences = mContext.getSharedPreferences("bank_select", MODE_PRIVATE);
                            SharedPreferences.Editor editorBank = sharedPreferences.edit();
                            bank_n = mBanklist.get(i).getB_name();
                            sbank_id = mBanklist.get(i).getB_id();
                            bank_url = mBanklist.get(i).getB_netbank();
                            bank_short = mBanklist.get(i).getB_short();

                            editorBank.putString("bank", "select");
                            editorBank.putString("bank_name", bank_n);
                            editorBank.putString("bank_url", bank_url);
                            editorBank.putString("bank_short", bank_short);
                            editorBank.putString("bank_id", String.valueOf(sbank_id));
                            editorBank.commit();

                            //navController.navigate(R.id.nav_box);

                            /*if (list_bank_relative != null) {
                                list_bank_relative.setVisibility(View.GONE);
                            }*/
                            if (box_view_relative != null) {
                                box_view_relative.setVisibility(View.VISIBLE);
                            }
                            if (navController != null) {
                                navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
                                    @Override
                                    public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {
                                        if (destination.getId() == R.id.nav_box) {
                                            toolbar.setTitle(bank_n);
                                        }
                                    }
                                });

                            }
                            readDirect();
                            drawerActivity.check1 = 2;

                        }
                    }, 200);
                } else {
                    sharedPreferences = mContext.getSharedPreferences("bank_select", MODE_PRIVATE);
                    SharedPreferences.Editor editorBank = sharedPreferences.edit();
                    bank_n = mBanklist.get(i).getB_name();
                    sbank_id = mBanklist.get(i).getB_id();
                    bank_url = mBanklist.get(i).getB_netbank();
                    bank_short = mBanklist.get(i).getB_short();


                    editorBank.putString("bank", "select");
                    editorBank.putString("bank_name", bank_n);
                    editorBank.putString("bank_url", bank_url);
                    editorBank.putString("bank_short", bank_short);
                    editorBank.putString("bank_id", String.valueOf(sbank_id));
                    editorBank.commit();

                    //navController.navigate(R.id.nav_box);

                    /*if (list_bank_relative != null) {
                        list_bank_relative.setVisibility(View.GONE);
                    }*/
                    if (box_view_relative != null) {
                        box_view_relative.setVisibility(View.VISIBLE);
                    }

                    if (navController != null) {

                        navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
                            @Override
                            public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {

                                if (destination.getId() == R.id.nav_box) {
                                    toolbar.setTitle(bank_n);
                                }
                            }
                        });
                    }
                    readDirect();
                    drawerActivity.check1 = 2;
                }


            }
        });

        return view1;
    }

}
