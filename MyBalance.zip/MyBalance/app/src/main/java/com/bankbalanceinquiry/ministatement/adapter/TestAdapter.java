package com.bankbalanceinquiry.ministatement.adapter;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.common.CommonFun;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.test.TestData;

import java.util.ArrayList;


public class TestAdapter extends
        RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<TestData> dataSet;

    private Context mContext;
    private Activity activity;
    private int total_types;

    public ClickHistory ApkDetails;

    public interface ClickHistory {
        public void ClickValue(AllAccountModelHistory callNumber);
    }

    public void RegisterInterface(ClickHistory photoInterface) {
        this.ApkDetails = photoInterface;
    }

    public static class TypeTitle extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        private TextView tvAmoutCredited;

        public TypeTitle(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvAmoutCredited = itemView.findViewById(R.id.tvAmoutCredited);
        }
    }

    public static class TypeData extends RecyclerView.ViewHolder {
        private ImageView micName;
        private TextView tvDDate;
        private TextView tvAmount;
        private TextView tvSenderName;
        private TextView tvUnknown;

        public TypeData(View itemView) {
            super(itemView);
            micName = itemView.findViewById(R.id.micName);
            tvDDate = itemView.findViewById(R.id.tvDDate);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvSenderName = itemView.findViewById(R.id.tvSenderName);
            tvUnknown = itemView.findViewById(R.id.tvUnknown);
        }
    }

    public TestAdapter(Activity context, ArrayList<TestData> data) {
        this.activity = context;
        this.dataSet = data;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 0:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_test_title, parent, false);
                return new TypeTitle(view);
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_test_data, parent, false);
                return new TypeData(view);
        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        switch (dataSet.get(position).getGetTitleType()) {
            case 0:
                return 0;
            case 1:
                return 1;
            default:
                return -1;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder,
                                 final int listPosition) {
        TestData object = dataSet.get(listPosition);
        if (object != null) {
            switch (object.getGetTitleType()) {
                case 0:
                    CallTitleType(((TypeTitle) holder), object);
                    break;
                case 1:
                    CallDataType(((TypeData) holder), object, listPosition);
                    break;
            }
        }
    }

    private void CallDataType(TypeData holder, final TestData object, final int listPosition) {
        ImageView micName = holder.micName;
        TextView tvAmount = holder.tvAmount;

        String Amout = object.getAmout();
        if (TextUtils.isEmpty(Amout)) {
            Amout = "0";
        }

        Log.e("AmoutAmout", Amout);
        tvAmount.setText(activity.getString(R.string.Rs) + " " + Amout);
    }

    private void CallTitleType(TypeTitle holder, TestData object) {
        holder.tvTitle.setText(object.getTitleDate());

        holder.tvAmoutCredited.setText(object.getSetCreditedAmount());

        Log.e("CRDAMNT==>", object.getSetCreditedAmount());
        Log.e("WWWWW==>", object.getStrings().size() + "");

        String Amout = CallAccountBalanceTesting(object.getStrings());
        String Debit = CallAccountBalanceTesting(object.getDebitData());
        holder.tvAmoutCredited.setText(Amout + " --- " + Debit);
    }

    private String CallAccountBalanceTesting(ArrayList<String> tempList) {
        StringBuilder finalallbalance = new StringBuilder();
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                finalallbalance.append(AmoutValue)
                        .append("Credited");
            }
        }
        return String.valueOf(CommonFun.findSum(finalallbalance.toString()));
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }


}
