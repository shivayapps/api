package com.bankbalanceinquiry.ministatement.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SharedPreferenceClass {

    public static final String FCM_ID = "fcm_id";
    private static final String PREF_NAME = "preference_application";
    public static final String STORED_INTERSTITIAL_TIME = "stored_interstitial_time";
    public static final String ITIME_INTERVAL = "ITimeInterval";
    static SharedPreferences sharedPreferences;

    public static void setNightModeState(Context context,Boolean state) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("NightMode",state);
        editor.commit();
    }

    public static Boolean loadNightModeState(Context context){
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        Boolean state = sharedPreferences.getBoolean("NightMode",false);
        return  state;
    }

    public static void setString(Context context, String key, String Value) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putString(key, Value);
        sEdit.commit();
    }

    public static String getString(Context context, String key, String defaultValue) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        //String value = sharedPreferences.getString(key, defaultValue);
        return sharedPreferences.getString(key, defaultValue);
    }

    public static void setInteger(Context context, String key, int Value) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putInt(key, Value);
        sEdit.commit();
    }

    public static int getInteger(Context context, String key) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        int value = sharedPreferences.getInt(key, 0);
        return value;
    }

    public static void setFloat(Context context, String key, Float Value) {

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putFloat(key, Value);
        sEdit.commit();

    }

    public static float getFloat(Context context, String key) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        Float mFloat = sharedPreferences.getFloat(key, 0);
        return mFloat;
    }

    public static int getInteger(Context context, String key, int defaultValue) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        int value = sharedPreferences.getInt(key, defaultValue);
        return value;
    }

    public static void setBoolean(Context context, String key, Boolean Value) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putBoolean(key, Value);
        sEdit.commit();
    }

    public static Boolean getBoolean(Context context, String key) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        Boolean value = sharedPreferences.getBoolean(key, false);
        return value;
    }

    public static Boolean getBoolean(Context context, String key, Boolean Value) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        Boolean value = sharedPreferences.getBoolean(key, Value);
        return value;
    }

    public static void setLong(Context context, String key, long Value) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putLong(key, Value);
        sEdit.commit();
    }

    public static long getLong(Context context, String key, long Value) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        long value = sharedPreferences.getLong(key, Value);
        return value;
    }

    public static float getCurrentTime() {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss");
        String currentTime = dateFormat.format(new Date());
        return Float.parseFloat(currentTime.replace(":", ".")) * 1000;
    }

    public static void setShowedInterstitialTime(Context context) {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss");
        String currentTime = dateFormat.format(new Date());
        float currentTimeToStore = (Float.parseFloat(currentTime.replace(":", ".")) * 1000);

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.putString(STORED_INTERSTITIAL_TIME, String.valueOf(currentTimeToStore)).apply();
    }

    public static float getShowedInterstitialTime(Context context) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String showedTime = sharedPreferences.getString(STORED_INTERSTITIAL_TIME,"300");
        return Float.parseFloat(showedTime);
    }

    public static float getITimeInterval(Context context) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String iTimeInterval = sharedPreferences.getString(ITIME_INTERVAL,"300");
        return Float.parseFloat(iTimeInterval);
    }

    public static void setITimeInterval(Context context,String iTimeInterval) {
        float iTimeIntervalToStore = Float.parseFloat(iTimeInterval) * 1000;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        sharedPreferences.edit().putString(ITIME_INTERVAL, String.valueOf(iTimeIntervalToStore)).apply();
    }

    public static boolean isTimeToShowInterstitial(Context context) {
        if ((getCurrentTime() - getShowedInterstitialTime(context)) >= getITimeInterval(context)) {
            return true;
        } else {
            return false;
        }
    }

    public static void clearSharedPreferences(Context context) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor sEdit = sharedPreferences.edit();
        sEdit.clear();
        sEdit.commit();
    }
}
