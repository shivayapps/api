package com.bankbalanceinquiry.ministatement.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.passBook;

import java.util.ArrayList;
import java.util.List;

import static com.bankbalanceinquiry.ministatement.activity.drawerActivity.navController;

public class bankWhich_Adapter extends RecyclerView.Adapter<bankWhich_Adapter.Viewholder>
{
    Context mContext;
    List<passBook> pData;
    ArrayList<String> array_Account;
    public static int pos;
    int avaBalance=0;
    ArrayList<String> mBalanceList;

    public bankWhich_Adapter(FragmentActivity activity, List<passBook> pData, ArrayList<String> array_Account, ArrayList<String> mBalanceList)
    {
        this.mContext=activity;
        this.pData=pData;
        this.array_Account=array_Account;
        this.mBalanceList=mBalanceList;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bank_account_passbook,null);

        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final Viewholder holder, final int position) {

        try
        {

            holder.account_no.setText(array_Account.get(position));
            holder.account_amount.setText("\u20B9" + String.valueOf(Math.abs (Integer.parseInt( mBalanceList.get(position)))));
            holder.account_passbook.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {

                    pos=array_Account.indexOf(array_Account.get(position));

                    navController.navigate(R.id.nav_bank_passbook);

                }
            });
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("Error--)"," "+e.getMessage());
        }

    }

    @Override
    public int getItemCount() {
        return array_Account.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder
    {
        TextView account_no,account_amount;
        CardView care_card;
        RelativeLayout account_passbook;

        public Viewholder(@NonNull View itemView)
        {
            super(itemView);

            account_no=(TextView) itemView.findViewById(R.id.account_no);
            account_amount=(TextView) itemView.findViewById(R.id.account_balance);
            care_card=(CardView)itemView.findViewById(R.id.care_card);
            account_passbook=(RelativeLayout) itemView.findViewById(R.id.account_passbook);
        }
    }
}
