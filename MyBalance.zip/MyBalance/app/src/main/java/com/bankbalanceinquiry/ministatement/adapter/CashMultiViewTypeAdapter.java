package com.bankbalanceinquiry.ministatement.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bankbalanceinquiry.ministatement.R;
import com.bankbalanceinquiry.ministatement.model.AllAccountModelHistory;
import com.bankbalanceinquiry.ministatement.newmodel.HomeAccoutList;
import com.marcoscg.dialogsheet.DialogSheet;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class CashMultiViewTypeAdapter extends
        RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<HomeAccoutList> dataSet;

    private Context mContext;
    private Activity activity;
    private int total_types;

    public ClickHistory ApkDetails;

    public interface ClickHistory {
        public void ClickValue(AllAccountModelHistory callNumber);
    }

    public void RegisterInterface(ClickHistory photoInterface) {
        this.ApkDetails = photoInterface;
    }

    public static class TypeTitle extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        private TextView tvCreditedAmount;
        private TextView tvDebitedAmount;

        public TypeTitle(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvCreditedAmount = itemView.findViewById(R.id.tvCreditedAmount);
            tvDebitedAmount = itemView.findViewById(R.id.tvDebitedAmount);
        }
    }

    public static class TypeData extends RecyclerView.ViewHolder {
        private ImageView micName;
        private TextView tvDDate;
        private TextView tvAmount;
        private TextView tvBankName;
        private LinearLayout llMain;

        public TypeData(View itemView) {
            super(itemView);
            micName = itemView.findViewById(R.id.micName);
            tvDDate = itemView.findViewById(R.id.tvDDate);
            tvAmount = itemView.findViewById(R.id.tvAmount);
            tvBankName = itemView.findViewById(R.id.tvBankName);
            llMain = itemView.findViewById(R.id.llMain);
        }
    }

    public CashMultiViewTypeAdapter(Activity context, ArrayList<HomeAccoutList> data) {
        this.activity = context;
        this.dataSet = data;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 0:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_cash_title, parent, false);
                return new TypeTitle(view);
            case 1:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.raw_history_cash_data, parent, false);
                return new TypeData(view);
        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        switch (dataSet.get(position).GetTitleType) {
            case 0:
                return 0;
            case 1:
                return 1;
            default:
                return -1;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder,
                                 final int listPosition) {
        HomeAccoutList object = dataSet.get(listPosition);
        if (object != null) {
            switch (object.GetTitleType) {
                case 0:
                    CallTitleType(((TypeTitle) holder), object);
                    break;
                case 1:
                    CallDataType(((TypeData) holder), object, listPosition);
                    break;
            }
        }
    }

    private void CallDataType(TypeData holder, final HomeAccoutList object, final int listPosition) {
        TextView tvDDate = holder.tvDDate;
        TextView tvAmount = holder.tvAmount;
        TextView tvBankName = holder.tvBankName;

        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy", Locale.US);
        String year = simpleDateFormat.format(date);
        String dateVal = object.dateValHistory;
        if (object.dateValHistory.contains(year)) {
            dateVal = object.dateValHistory.replace(" " + year, "");
        }

        tvDDate.setText(dateVal);
        String AccountAmount = object.amount;
        if (TextUtils.isEmpty(AccountAmount)) {
            AccountAmount = "0";
        }

        if (!TextUtils.isEmpty(AccountAmount)) {
            if (AccountAmount.contains(",")) {
                AccountAmount = AccountAmount.replace(",", "");
            }
            double d = Double.parseDouble(AccountAmount);
            if (AccountAmount.contains(".")) {
                String afterPoint = AccountAmount.substring(AccountAmount.indexOf(".") + 1);
                if (afterPoint.length() > 2) {
                    DecimalFormat decim = new DecimalFormat("#,##,###.##");
                    AccountAmount = decim.format(d);
                }

                DecimalFormat decim = new DecimalFormat("#,##,###.##");
                AccountAmount = decim.format(d);
            }
            holder.tvAmount.setText(activity.getString(R.string.Rs) + " " + AccountAmount);
        } else {
            holder.tvAmount.setText("");
        }

        String name = object.full_name.replace(" Bank", "");
        if (!TextUtils.isEmpty(object.FinalAccountNo)) {
            holder.tvBankName.setText(name + " - " + object.FinalAccountNo);
        } else {
            holder.tvBankName.setText(name);
        }

        holder.llMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DialogSheet(activity)
                        .setTitle(TextUtils.isEmpty("Account no") ? object.full_name : ("Account no" + (object.FinalAccountNo.length() < 4 ? " - X" : " - ") + object.FinalAccountNo))
                        .setMessage(object.body)
                        .setColoredNavigationBar(true)
                        .setTitleTextSize(20)
                        .setButtonsTextSize(15)
                        .setBackgroundColor(Color.WHITE)
                        .show();
            }
        });
    }

    private void CallTitleType(TypeTitle holder, HomeAccoutList object) {
        holder.tvTitle.setText(object.DateTransactionHistory);


        String AmoutCredited = CallAccountBalanceTesting(object.CreditedData);
        String AmoutDebited = CallAccountBalanceTesting(object.DebitedData);
        holder.tvCreditedAmount.setText(activity.getString(R.string.Rs) + " " + AmoutCredited);
        holder.tvDebitedAmount.setText(activity.getString(R.string.Rs) + " " + AmoutDebited);
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }


    private String CallAccountBalanceTesting(ArrayList<String> tempList) {
//        StringBuilder finalallbalance = new StringBuilder();
        double sum = 0;
        for (int i = 0; i < tempList.size(); i++) {
            String AmoutValue = tempList.get(i);
            if (!TextUtils.isEmpty(AmoutValue)) {
                double value = Double.parseDouble(AmoutValue);
                sum += value;
//                finalallbalance.append(AmoutValue);
            }
        }
        String s = String.valueOf(sum);
        if (s.contains(".")) {
            String afterPoint = s.substring(s.indexOf(".") + 1);
            if (afterPoint.length() > 2) {
                DecimalFormat decim = new DecimalFormat("#,##,###.##");
                return decim.format(sum);
            }
        }
        DecimalFormat decim = new DecimalFormat("#,##,###.##");
        return decim.format(sum);
//        return String.valueOf(CommonFun.findSum(finalallbalance.toString()));
    }
}
