package com.bankbalanceinquiry.ministatement.notification;

import android.content.Context;

import com.onesignal.OSNotification;
import com.onesignal.OneSignal;

import org.json.JSONObject;

/**
 * Created by androidbash on 12/14/2016.
 */

//This will be called when a notification is received while your app is running.
//public class ExampleNotificationReceivedHandler implements OneSignal.NotificationReceivedHandler {
//    public static String notiTitle = "";
//    public static String notiOfferId = "";
//    public static String notiExpireDate = "";
//    public static boolean isNotiOffer;
//    Context mContext;
//
//    public ExampleNotificationReceivedHandler(Context mContext) {
//        this.mContext = mContext;
//    }
//
//    @Override
//    public void notificationReceived(OSNotification notification) {
//        JSONObject data = notification.payload.additionalData;
//        String type;
////        if(data!=null)
////        {
////            Dialog dialog=new Dialog(mContext);
////            dialog.setContentView(R.layout.dialog_say_thanks);
////            dialog.show();
////        }
////        Dialog dialog1 = null;
////
////
////
//////
////        Log.i("Notification Check", "Notification Check" + data);
////        //While sending a Push notification from OneSignal dashboard
////        // you can send an addtional data named "customkey" and retrieve the value of it and do necessary operation
////        if (data != null) {
////            type = data.optString("type", null);
////            if (type != null)
////            dialog1 = new Dialog(mContext);
////            dialog1.setContentView(R.layout.ratemyapp);
////            dialog1.show();
////                Log.i("OneSignalExample", "customkey set with value: " + type);
//
//        if (data.toString().contains("offer")) {
//            type = data.optString("type", null);
//            if (type.equals("offer")) {
//                isNotiOffer = true;
//                if (data.has("offer_id")) {
//                    notiOfferId = data.optString("offer_id");
//                }
//                if (data.has("expire_date")) {
//                    notiExpireDate = data.optString("expire_date");
//                }
//                if (data.has("title")) {
//                    notiTitle = data.optString("title");
//                }
//            }
//        }
//    }
//}